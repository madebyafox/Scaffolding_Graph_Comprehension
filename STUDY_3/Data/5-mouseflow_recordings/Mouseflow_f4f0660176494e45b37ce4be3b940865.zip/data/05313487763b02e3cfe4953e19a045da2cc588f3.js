var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05313487763b02e3cfe4953e19a045da2cc588f3"] = {
  "startTime": "2018-05-31T19:22:34.4984561Z",
  "websitePageUrl": "/16",
  "visitTime": 242697,
  "engagementTime": 126606,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f4f0660176494e45b37ce4be3b940865",
    "created": "2018-05-31T19:22:34.4239419+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=03QKB",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ca6b567115818f46cc35e8046acd9012",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f4f0660176494e45b37ce4be3b940865/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 643,
      "e": 643,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 669,
      "e": 669,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 496,
      "y": 740
    },
    {
      "t": 1360,
      "e": 1360,
      "ty": 6,
      "x": 449,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 1377,
      "e": 1377,
      "ty": 7,
      "x": 428,
      "y": 648,
      "ta": "#strategyButton"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 422,
      "y": 645
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 383,
      "y": 604
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 32138,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 1562,
      "e": 1562,
      "ty": 6,
      "x": 381,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 376,
      "y": 597
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 362,
      "y": 583
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 29328,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 358,
      "y": 579
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 354,
      "y": 577
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 28878,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 354,
      "y": 576
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 358,
      "y": 574
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 29553,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 360,
      "y": 574
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 398,
      "y": 560
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 33824,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 449,
      "y": 544
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 489,
      "y": 544
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 44953,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 497,
      "y": 544
    },
    {
      "t": 2898,
      "e": 2898,
      "ty": 3,
      "x": 497,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3009,
      "e": 3009,
      "ty": 4,
      "x": 44953,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3009,
      "e": 3009,
      "ty": 5,
      "x": 497,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3246,
      "e": 3246,
      "ty": 7,
      "x": 729,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 2807,
      "y": 32447,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1046,
      "y": 663
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 2,
      "x": 1073,
      "y": 664
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 20225,
      "y": 37673,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 8502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20101,
      "e": 8502,
      "ty": 2,
      "x": 1074,
      "y": 664
    },
    {
      "t": 20252,
      "e": 8653,
      "ty": 41,
      "x": 20295,
      "y": 37673,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 26223,
      "e": 13653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 26454,
      "e": 13884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26455,
      "e": 13885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26573,
      "e": 14003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 26597,
      "e": 14027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 26686,
      "e": 14116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26686,
      "e": 14116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26797,
      "e": 14227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26797,
      "e": 14227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26839,
      "e": 14269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 26941,
      "e": 14371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 26989,
      "e": 14419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26989,
      "e": 14419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27077,
      "e": 14507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27078,
      "e": 14508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27118,
      "e": 14548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and"
    },
    {
      "t": 27174,
      "e": 14604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27174,
      "e": 14604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27221,
      "e": 14651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27301,
      "e": 14731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27308,
      "e": 14738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 27445,
      "e": 14875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 27445,
      "e": 14875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27501,
      "e": 14931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 27525,
      "e": 14955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27589,
      "e": 15019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27590,
      "e": 15020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27693,
      "e": 15123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28334,
      "e": 15764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28334,
      "e": 15764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28477,
      "e": 15907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28485,
      "e": 15915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28485,
      "e": 15915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28603,
      "e": 16033,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B st"
    },
    {
      "t": 28637,
      "e": 16067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28637,
      "e": 16067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28661,
      "e": 16091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 28766,
      "e": 16196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28766,
      "e": 16196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28814,
      "e": 16244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 28894,
      "e": 16324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28989,
      "e": 16419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28991,
      "e": 16421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29110,
      "e": 16540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29118,
      "e": 16548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29119,
      "e": 16549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29237,
      "e": 16667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29502,
      "e": 16932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 29502,
      "e": 16932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29596,
      "e": 17026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 29629,
      "e": 17059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29629,
      "e": 17059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29693,
      "e": 17123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29717,
      "e": 17147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29718,
      "e": 17148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29789,
      "e": 17219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29838,
      "e": 17268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 29838,
      "e": 17268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29924,
      "e": 17354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29925,
      "e": 17355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29933,
      "e": 17363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 30001,
      "e": 17431,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30005,
      "e": 17435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30005,
      "e": 17435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30037,
      "e": 17467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30116,
      "e": 17546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30117,
      "e": 17547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30133,
      "e": 17563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30221,
      "e": 17651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30222,
      "e": 17652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30245,
      "e": 17675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30349,
      "e": 17779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34149,
      "e": 21579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34150,
      "e": 21580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34237,
      "e": 21667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34237,
      "e": 21667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34253,
      "e": 21683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 34317,
      "e": 21747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34318,
      "e": 21748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34333,
      "e": 21763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34373,
      "e": 21803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34373,
      "e": 21803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34437,
      "e": 21867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34452,
      "e": 21882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34453,
      "e": 21883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34509,
      "e": 21939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34597,
      "e": 22027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34789,
      "e": 22219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34790,
      "e": 22220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34916,
      "e": 22346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34917,
      "e": 22347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34949,
      "e": 22379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 35070,
      "e": 22500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35622,
      "e": 23052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35622,
      "e": 23052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35708,
      "e": 23138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35709,
      "e": 23139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35732,
      "e": 23162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ur"
    },
    {
      "t": 35789,
      "e": 23219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35789,
      "e": 23219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35837,
      "e": 23267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35925,
      "e": 23355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35941,
      "e": 23371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35941,
      "e": 23371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36029,
      "e": 23459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36038,
      "e": 23468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 36038,
      "e": 23468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36133,
      "e": 23563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36133,
      "e": 23563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36157,
      "e": 23587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 36244,
      "e": 23674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36718,
      "e": 24148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36719,
      "e": 24149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36813,
      "e": 24243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36869,
      "e": 24299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36869,
      "e": 24299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36965,
      "e": 24395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 36966,
      "e": 24396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36973,
      "e": 24403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ay"
    },
    {
      "t": 37053,
      "e": 24483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37077,
      "e": 24507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37078,
      "e": 24508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37203,
      "e": 24633,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day "
    },
    {
      "t": 37205,
      "e": 24635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37445,
      "e": 24875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 37446,
      "e": 24876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37533,
      "e": 24963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 37541,
      "e": 24971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37541,
      "e": 24971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37621,
      "e": 25051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37669,
      "e": 25099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 37670,
      "e": 25100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37781,
      "e": 25211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37781,
      "e": 25211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37821,
      "e": 25251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 37909,
      "e": 25339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 37910,
      "e": 25340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37916,
      "e": 25346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 37940,
      "e": 25370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37940,
      "e": 25370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37980,
      "e": 25410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 38020,
      "e": 25450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38021,
      "e": 25451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38069,
      "e": 25499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38125,
      "e": 25555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38126,
      "e": 25556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38165,
      "e": 25595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38214,
      "e": 25644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38215,
      "e": 25645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38245,
      "e": 25675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38277,
      "e": 25707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38277,
      "e": 25707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38316,
      "e": 25746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38348,
      "e": 25778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38348,
      "e": 25778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38365,
      "e": 25795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38461,
      "e": 25891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38462,
      "e": 25892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38477,
      "e": 25907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 38533,
      "e": 25963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38534,
      "e": 25964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38557,
      "e": 25987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38637,
      "e": 26067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38637,
      "e": 26067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38685,
      "e": 26115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38733,
      "e": 26163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38734,
      "e": 26164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38797,
      "e": 26227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38804,
      "e": 26234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38805,
      "e": 26235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38853,
      "e": 26283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38909,
      "e": 26339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38909,
      "e": 26339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38957,
      "e": 26387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39046,
      "e": 26476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39261,
      "e": 26691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39262,
      "e": 26692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39341,
      "e": 26771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 39341,
      "e": 26771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39373,
      "e": 26803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sc"
    },
    {
      "t": 39445,
      "e": 26875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39445,
      "e": 26875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39453,
      "e": 26883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39526,
      "e": 26956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39542,
      "e": 26972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39542,
      "e": 26972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39612,
      "e": 27042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39725,
      "e": 27155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39725,
      "e": 27155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39806,
      "e": 27155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39812,
      "e": 27161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39813,
      "e": 27162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39877,
      "e": 27226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 40002,
      "e": 27351,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are schedu"
    },
    {
      "t": 40037,
      "e": 27386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40038,
      "e": 27387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40116,
      "e": 27465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 40124,
      "e": 27473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40124,
      "e": 27473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40181,
      "e": 27530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40301,
      "e": 27650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40302,
      "e": 27651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40381,
      "e": 27730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 40445,
      "e": 27794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40445,
      "e": 27794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40534,
      "e": 27883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41030,
      "e": 28379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41030,
      "e": 28379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41092,
      "e": 28441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41092,
      "e": 28441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41141,
      "e": 28490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 41188,
      "e": 28537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41189,
      "e": 28538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41204,
      "e": 28553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41269,
      "e": 28618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41269,
      "e": 28618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41276,
      "e": 28625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41372,
      "e": 28721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41372,
      "e": 28721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41389,
      "e": 28738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 41445,
      "e": 28794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41486,
      "e": 28835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41486,
      "e": 28835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41556,
      "e": 28905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41556,
      "e": 28905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41612,
      "e": 28961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 41636,
      "e": 28985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41637,
      "e": 28986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41685,
      "e": 29034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41749,
      "e": 29098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42686,
      "e": 30035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42686,
      "e": 30035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42773,
      "e": 30122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 42796,
      "e": 30145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42797,
      "e": 30146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42909,
      "e": 30258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 42909,
      "e": 30258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42925,
      "e": 30274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 42959,
      "e": 30308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42960,
      "e": 30309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42981,
      "e": 30330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 43021,
      "e": 30370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43021,
      "e": 30370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43060,
      "e": 30409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43140,
      "e": 30489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43213,
      "e": 30562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 43213,
      "e": 30562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43301,
      "e": 30650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 43403,
      "e": 30752,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour b"
    },
    {
      "t": 43454,
      "e": 30803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 43454,
      "e": 30803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43508,
      "e": 30857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 43549,
      "e": 30898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43549,
      "e": 30898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43629,
      "e": 30978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43653,
      "e": 31002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43653,
      "e": 31002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43741,
      "e": 31090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43742,
      "e": 31091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43756,
      "e": 31105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 43781,
      "e": 31130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43781,
      "e": 31130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43797,
      "e": 31146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 43861,
      "e": 31210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43909,
      "e": 31258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43909,
      "e": 31258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44085,
      "e": 31434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44413,
      "e": 31762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 44414,
      "e": 31763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44500,
      "e": 31849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 44517,
      "e": 31866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44517,
      "e": 31866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44685,
      "e": 32034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45231,
      "e": 32580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 45233,
      "e": 32582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45340,
      "e": 32689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 45348,
      "e": 32697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45348,
      "e": 32697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45453,
      "e": 32802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45669,
      "e": 33018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45725,
      "e": 33074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they c"
    },
    {
      "t": 45813,
      "e": 33162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45868,
      "e": 33162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they "
    },
    {
      "t": 45885,
      "e": 33179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 45885,
      "e": 33179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45980,
      "e": 33274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 45980,
      "e": 33274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45980,
      "e": 33274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46093,
      "e": 33387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46094,
      "e": 33388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46101,
      "e": 33395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 46172,
      "e": 33466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46381,
      "e": 33675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 46382,
      "e": 33676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46493,
      "e": 33787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 46556,
      "e": 33850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46556,
      "e": 33850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46644,
      "e": 33938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46805,
      "e": 34099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46805,
      "e": 34099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46845,
      "e": 34139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 47003,
      "e": 34297,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary i"
    },
    {
      "t": 47317,
      "e": 34611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47318,
      "e": 34612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47476,
      "e": 34770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47501,
      "e": 34795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47501,
      "e": 34795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47603,
      "e": 34897,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in "
    },
    {
      "t": 47613,
      "e": 34907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47621,
      "e": 34915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47622,
      "e": 34916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47629,
      "e": 34923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 47630,
      "e": 34924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47684,
      "e": 34978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hj"
    },
    {
      "t": 47701,
      "e": 34995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47716,
      "e": 35010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47717,
      "e": 35011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47764,
      "e": 35058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48064,
      "e": 35358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48112,
      "e": 35406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in hj"
    },
    {
      "t": 48208,
      "e": 35502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48248,
      "e": 35542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in h"
    },
    {
      "t": 48392,
      "e": 35686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48394,
      "e": 35688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48457,
      "e": 35751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48488,
      "e": 35782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 48489,
      "e": 35783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48560,
      "e": 35854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48561,
      "e": 35855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48576,
      "e": 35870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w "
    },
    {
      "t": 48640,
      "e": 35934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 48640,
      "e": 35934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48656,
      "e": 35950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 48712,
      "e": 36006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48801,
      "e": 36095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48802,
      "e": 36096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48880,
      "e": 36174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48880,
      "e": 36174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48920,
      "e": 36214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 48953,
      "e": 36247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 48953,
      "e": 36247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48984,
      "e": 36278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 49024,
      "e": 36318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49025,
      "e": 36319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49056,
      "e": 36350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49144,
      "e": 36438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49153,
      "e": 36447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49153,
      "e": 36447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49176,
      "e": 36470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 49177,
      "e": 36471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49216,
      "e": 36510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 49249,
      "e": 36543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49322,
      "e": 36544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49324,
      "e": 36546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49384,
      "e": 36606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 49384,
      "e": 36606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49408,
      "e": 36630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ey"
    },
    {
      "t": 49472,
      "e": 36694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49536,
      "e": 36758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49537,
      "e": 36759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49664,
      "e": 36886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49688,
      "e": 36910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 49689,
      "e": 36911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49793,
      "e": 37015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 49793,
      "e": 37015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49794,
      "e": 37016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49881,
      "e": 37103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49920,
      "e": 37142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49921,
      "e": 37143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49928,
      "e": 37150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49928,
      "e": 37150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49961,
      "e": 37183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 49969,
      "e": 37191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50025,
      "e": 37247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 50025,
      "e": 37247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50105,
      "e": 37327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 50208,
      "e": 37430,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they wortk"
    },
    {
      "t": 50441,
      "e": 37663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50496,
      "e": 37718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they wort"
    },
    {
      "t": 50576,
      "e": 37798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50625,
      "e": 37847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they wor"
    },
    {
      "t": 51305,
      "e": 38527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 51306,
      "e": 38528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51392,
      "e": 38614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 51561,
      "e": 38783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 51562,
      "e": 38784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51648,
      "e": 38870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 53553,
      "e": 40775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53554,
      "e": 40776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53624,
      "e": 40846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53720,
      "e": 40942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 53857,
      "e": 41079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53857,
      "e": 41079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53904,
      "e": 41126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 53944,
      "e": 41166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53944,
      "e": 41166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 53944,
      "e": 41166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54008,
      "e": 41230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 54032,
      "e": 41254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54033,
      "e": 41255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54104,
      "e": 41326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 54105,
      "e": 41327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54136,
      "e": 41358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ey"
    },
    {
      "t": 54184,
      "e": 41406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54232,
      "e": 41454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54232,
      "e": 41454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54353,
      "e": 41575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54505,
      "e": 41727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54552,
      "e": 41774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. They"
    },
    {
      "t": 54648,
      "e": 41870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54689,
      "e": 41871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. The"
    },
    {
      "t": 54777,
      "e": 41959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54816,
      "e": 41998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. Th"
    },
    {
      "t": 54896,
      "e": 42078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54961,
      "e": 42143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. T"
    },
    {
      "t": 55505,
      "e": 42687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 55568,
      "e": 42750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. "
    },
    {
      "t": 55832,
      "e": 43014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 55833,
      "e": 43015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55904,
      "e": 43086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55904,
      "e": 43086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55952,
      "e": 43134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||we"
    },
    {
      "t": 56032,
      "e": 43214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56032,
      "e": 43214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56080,
      "e": 43262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56152,
      "e": 43334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56185,
      "e": 43367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 56186,
      "e": 43368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56288,
      "e": 43470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56288,
      "e": 43470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56312,
      "e": 43494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||co"
    },
    {
      "t": 56360,
      "e": 43542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56449,
      "e": 43631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 56449,
      "e": 43631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56536,
      "e": 43718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 56673,
      "e": 43855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56674,
      "e": 43856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56744,
      "e": 43926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56744,
      "e": 43926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56752,
      "e": 43934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ld"
    },
    {
      "t": 56856,
      "e": 44038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56857,
      "e": 44039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56888,
      "e": 44070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56969,
      "e": 44151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57160,
      "e": 44342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57162,
      "e": 44344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57288,
      "e": 44470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57296,
      "e": 44478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 57297,
      "e": 44479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57376,
      "e": 44558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 57392,
      "e": 44574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57392,
      "e": 44574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57464,
      "e": 44646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 57488,
      "e": 44670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 57489,
      "e": 44671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57537,
      "e": 44719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57537,
      "e": 44719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57552,
      "e": 44734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 57649,
      "e": 44831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57761,
      "e": 44943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57761,
      "e": 44943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57849,
      "e": 45031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57882,
      "e": 45064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57883,
      "e": 45065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57976,
      "e": 45158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58008,
      "e": 45190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 58009,
      "e": 45191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58064,
      "e": 45246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 58120,
      "e": 45302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 58121,
      "e": 45303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58169,
      "e": 45351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58170,
      "e": 45352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58177,
      "e": 45359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 58232,
      "e": 45414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58232,
      "e": 45414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58272,
      "e": 45454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 58328,
      "e": 45510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58329,
      "e": 45511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58336,
      "e": 45518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58392,
      "e": 45574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58457,
      "e": 45639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58458,
      "e": 45640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58512,
      "e": 45694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58512,
      "e": 45694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58560,
      "e": 45742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 58594,
      "e": 45776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58594,
      "e": 45776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58632,
      "e": 45814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58696,
      "e": 45878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63049,
      "e": 50231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 63312,
      "e": 50494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 63313,
      "e": 50495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63345,
      "e": 50527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||J"
    },
    {
      "t": 63401,
      "e": 50583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63473,
      "e": 50655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63473,
      "e": 50655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63520,
      "e": 50702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63520,
      "e": 50702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63568,
      "e": 50750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| e"
    },
    {
      "t": 63624,
      "e": 50806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63632,
      "e": 50814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63632,
      "e": 50814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63713,
      "e": 50895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 63752,
      "e": 50934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 63754,
      "e": 50936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63871,
      "e": 51053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63872,
      "e": 51054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63904,
      "e": 51086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 63985,
      "e": 51167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63985,
      "e": 51167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63992,
      "e": 51174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64080,
      "e": 51262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64449,
      "e": 51631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64450,
      "e": 51632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64528,
      "e": 51710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64552,
      "e": 51734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 64552,
      "e": 51734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64616,
      "e": 51798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 64648,
      "e": 51830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 64648,
      "e": 51830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64713,
      "e": 51895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 64777,
      "e": 51959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 64777,
      "e": 51959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64888,
      "e": 52070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 64968,
      "e": 52150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64969,
      "e": 52151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65096,
      "e": 52278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65128,
      "e": 52310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 65129,
      "e": 52311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65208,
      "e": 52390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 65216,
      "e": 52398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65217,
      "e": 52399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65280,
      "e": 52462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 65345,
      "e": 52527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 65345,
      "e": 52527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65455,
      "e": 52637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 65464,
      "e": 52646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65464,
      "e": 52646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65568,
      "e": 52750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 65593,
      "e": 52775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 65594,
      "e": 52776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65649,
      "e": 52831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 65681,
      "e": 52863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65681,
      "e": 52863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65761,
      "e": 52943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65761,
      "e": 52943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65823,
      "e": 53005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 65872,
      "e": 53054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65872,
      "e": 53054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65936,
      "e": 53118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66009,
      "e": 53191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66352,
      "e": 53534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66354,
      "e": 53536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66409,
      "e": 53591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66425,
      "e": 53607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66425,
      "e": 53607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66503,
      "e": 53685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 66560,
      "e": 53742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66560,
      "e": 53742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66632,
      "e": 53814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66665,
      "e": 53847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 66665,
      "e": 53847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66729,
      "e": 53911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 66809,
      "e": 53991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66809,
      "e": 53991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66912,
      "e": 54094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68713,
      "e": 55895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 68714,
      "e": 55896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68792,
      "e": 55974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 68792,
      "e": 55974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68808,
      "e": 55990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 68912,
      "e": 56094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68928,
      "e": 56110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 68928,
      "e": 56110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69008,
      "e": 56190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 69009,
      "e": 56191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69016,
      "e": 56198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 69080,
      "e": 56262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69080,
      "e": 56262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69111,
      "e": 56293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69184,
      "e": 56366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69224,
      "e": 56406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 69225,
      "e": 56407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69304,
      "e": 56486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 69311,
      "e": 56493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69312,
      "e": 56494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69368,
      "e": 56550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 69416,
      "e": 56598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69417,
      "e": 56599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69489,
      "e": 56671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 69496,
      "e": 56678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 69498,
      "e": 56680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69584,
      "e": 56766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 69624,
      "e": 56806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69624,
      "e": 56806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69736,
      "e": 56918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69760,
      "e": 56942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 69761,
      "e": 56943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69840,
      "e": 57022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 69848,
      "e": 57030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69849,
      "e": 57031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69912,
      "e": 57094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 69944,
      "e": 57126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69944,
      "e": 57126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69967,
      "e": 57149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69968,
      "e": 57150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70004,
      "e": 57186,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70007,
      "e": 57189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 70111,
      "e": 57293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70184,
      "e": 57366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70185,
      "e": 57367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70272,
      "e": 57454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70353,
      "e": 57535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 70353,
      "e": 57535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70424,
      "e": 57606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 70472,
      "e": 57654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70472,
      "e": 57654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70536,
      "e": 57718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 70560,
      "e": 57742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70560,
      "e": 57742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70656,
      "e": 57838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70736,
      "e": 57918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 70736,
      "e": 57918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70844,
      "e": 58026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 70863,
      "e": 58045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70864,
      "e": 58046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70967,
      "e": 58149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 70968,
      "e": 58150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70991,
      "e": 58173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 71064,
      "e": 58246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 71065,
      "e": 58247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71072,
      "e": 58254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 71137,
      "e": 58319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71193,
      "e": 58375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71193,
      "e": 58375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71263,
      "e": 58445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71263,
      "e": 58445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71312,
      "e": 58494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 71376,
      "e": 58558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71896,
      "e": 59078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 71897,
      "e": 59079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71999,
      "e": 59181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72000,
      "e": 59182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72007,
      "e": 59189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 72096,
      "e": 59278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72096,
      "e": 59278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72121,
      "e": 59303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72201,
      "e": 59383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 72201,
      "e": 59383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72216,
      "e": 59398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 72280,
      "e": 59462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72304,
      "e": 59486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72304,
      "e": 59486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72384,
      "e": 59566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 72400,
      "e": 59582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72400,
      "e": 59582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72504,
      "e": 59686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72680,
      "e": 59862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 72681,
      "e": 59863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72767,
      "e": 59949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72768,
      "e": 59950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72783,
      "e": 59965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 72832,
      "e": 60014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72904,
      "e": 60086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 72905,
      "e": 60087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72992,
      "e": 60174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72992,
      "e": 60174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73008,
      "e": 60190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 73071,
      "e": 60253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73087,
      "e": 60269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73087,
      "e": 60269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73207,
      "e": 60389,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. we could also tell that J ends work because they only work for two hours which means"
    },
    {
      "t": 73232,
      "e": 60414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73233,
      "e": 60415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73248,
      "e": 60430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 73329,
      "e": 60511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73329,
      "e": 60511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73351,
      "e": 60533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73440,
      "e": 60622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73440,
      "e": 60622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 73440,
      "e": 60622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73528,
      "e": 60710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 73528,
      "e": 60710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73529,
      "e": 60711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73617,
      "e": 60799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 73633,
      "e": 60815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73633,
      "e": 60815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73696,
      "e": 60878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 73711,
      "e": 60893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 73712,
      "e": 60894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73808,
      "e": 60990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 73825,
      "e": 61007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73825,
      "e": 61007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73912,
      "e": 61094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73944,
      "e": 61126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73945,
      "e": 61127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74000,
      "e": 61182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 74000,
      "e": 61182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74047,
      "e": 61229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 74080,
      "e": 61262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 74080,
      "e": 61262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74104,
      "e": 61286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 74184,
      "e": 61366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74192,
      "e": 61374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 74192,
      "e": 61374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74256,
      "e": 61438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 74353,
      "e": 61535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74353,
      "e": 61535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74416,
      "e": 61598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74417,
      "e": 61599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74423,
      "e": 61605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 74504,
      "e": 61686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74584,
      "e": 61766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74586,
      "e": 61767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74680,
      "e": 61861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 74720,
      "e": 61901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 74720,
      "e": 61901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74792,
      "e": 61973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 74825,
      "e": 62006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 74825,
      "e": 62006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74904,
      "e": 62085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74904,
      "e": 62085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74944,
      "e": 62125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 74992,
      "e": 62173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74992,
      "e": 62173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75024,
      "e": 62205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75096,
      "e": 62277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75097,
      "e": 62278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75103,
      "e": 62284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 75206,
      "e": 62387,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. we could also tell that J ends work because they only work for two hours which means their shift ends a"
    },
    {
      "t": 75216,
      "e": 62397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75216,
      "e": 62397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75264,
      "e": 62445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 75279,
      "e": 62460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75280,
      "e": 62461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75320,
      "e": 62501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75385,
      "e": 62566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76640,
      "e": 63821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 76641,
      "e": 63822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76696,
      "e": 63877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 76696,
      "e": 63877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76776,
      "e": 63957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 76832,
      "e": 64013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76832,
      "e": 64013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76896,
      "e": 64077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76968,
      "e": 64149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77471,
      "e": 64652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77543,
      "e": 64724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. we could also tell that J ends work because they only work for two hours which means their shift ends at 12"
    },
    {
      "t": 77712,
      "e": 64893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 77713,
      "e": 64894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77888,
      "e": 65069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 77889,
      "e": 65070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77935,
      "e": 65116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 78087,
      "e": 65268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79273,
      "e": 66454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 79274,
      "e": 66455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79360,
      "e": 66541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 79464,
      "e": 66645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79464,
      "e": 66645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79560,
      "e": 66741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80005,
      "e": 67186,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 95604,
      "e": 71741,
      "ty": 2,
      "x": 1076,
      "y": 666
    },
    {
      "t": 95705,
      "e": 71842,
      "ty": 2,
      "x": 1173,
      "y": 899
    },
    {
      "t": 95755,
      "e": 71892,
      "ty": 41,
      "x": 28892,
      "y": 56295,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 95805,
      "e": 71942,
      "ty": 2,
      "x": 1206,
      "y": 939
    },
    {
      "t": 95904,
      "e": 72041,
      "ty": 2,
      "x": 1212,
      "y": 943
    },
    {
      "t": 96004,
      "e": 72141,
      "ty": 2,
      "x": 1210,
      "y": 953
    },
    {
      "t": 96005,
      "e": 72142,
      "ty": 41,
      "x": 29879,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 96104,
      "e": 72241,
      "ty": 2,
      "x": 1186,
      "y": 959
    },
    {
      "t": 96254,
      "e": 72391,
      "ty": 41,
      "x": 28188,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 96404,
      "e": 72541,
      "ty": 2,
      "x": 1186,
      "y": 962
    },
    {
      "t": 96504,
      "e": 72641,
      "ty": 2,
      "x": 1185,
      "y": 964
    },
    {
      "t": 96505,
      "e": 72642,
      "ty": 41,
      "x": 24454,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 96705,
      "e": 72842,
      "ty": 2,
      "x": 1181,
      "y": 964
    },
    {
      "t": 96754,
      "e": 72891,
      "ty": 41,
      "x": 23716,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 96804,
      "e": 72941,
      "ty": 2,
      "x": 1168,
      "y": 964
    },
    {
      "t": 96905,
      "e": 73042,
      "ty": 2,
      "x": 1157,
      "y": 964
    },
    {
      "t": 97004,
      "e": 73141,
      "ty": 41,
      "x": 22160,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 97104,
      "e": 73241,
      "ty": 2,
      "x": 1148,
      "y": 957
    },
    {
      "t": 97204,
      "e": 73341,
      "ty": 2,
      "x": 1116,
      "y": 851
    },
    {
      "t": 97254,
      "e": 73391,
      "ty": 41,
      "x": 23396,
      "y": 47342,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 97304,
      "e": 73441,
      "ty": 2,
      "x": 1123,
      "y": 787
    },
    {
      "t": 97404,
      "e": 73541,
      "ty": 2,
      "x": 1132,
      "y": 764
    },
    {
      "t": 97504,
      "e": 73641,
      "ty": 2,
      "x": 1148,
      "y": 718
    },
    {
      "t": 97505,
      "e": 73642,
      "ty": 41,
      "x": 25510,
      "y": 41541,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 97604,
      "e": 73741,
      "ty": 2,
      "x": 1153,
      "y": 685
    },
    {
      "t": 97704,
      "e": 73841,
      "ty": 2,
      "x": 1155,
      "y": 666
    },
    {
      "t": 97755,
      "e": 73892,
      "ty": 41,
      "x": 25439,
      "y": 38103,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 97804,
      "e": 73941,
      "ty": 2,
      "x": 1070,
      "y": 715
    },
    {
      "t": 97905,
      "e": 74042,
      "ty": 2,
      "x": 621,
      "y": 660
    },
    {
      "t": 98004,
      "e": 74141,
      "ty": 2,
      "x": 466,
      "y": 632
    },
    {
      "t": 98005,
      "e": 74142,
      "ty": 41,
      "x": 41468,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 98504,
      "e": 74641,
      "ty": 2,
      "x": 446,
      "y": 634
    },
    {
      "t": 98504,
      "e": 74641,
      "ty": 41,
      "x": 59639,
      "y": 8038,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 98604,
      "e": 74741,
      "ty": 2,
      "x": 423,
      "y": 648
    },
    {
      "t": 98661,
      "e": 74798,
      "ty": 6,
      "x": 417,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 98704,
      "e": 74841,
      "ty": 2,
      "x": 417,
      "y": 655
    },
    {
      "t": 98755,
      "e": 74892,
      "ty": 41,
      "x": 41727,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 98805,
      "e": 74942,
      "ty": 2,
      "x": 414,
      "y": 660
    },
    {
      "t": 99005,
      "e": 75142,
      "ty": 41,
      "x": 41181,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 100069,
      "e": 76206,
      "ty": 3,
      "x": 414,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 100070,
      "e": 76207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. we could also tell that J ends work because they only work for two hours which means their shift ends at 12pm. "
    },
    {
      "t": 100072,
      "e": 76209,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100073,
      "e": 76210,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 100148,
      "e": 76285,
      "ty": 4,
      "x": 41181,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 100156,
      "e": 76293,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 100156,
      "e": 76293,
      "ty": 5,
      "x": 414,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 100162,
      "e": 76299,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 101164,
      "e": 77301,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 102005,
      "e": 78142,
      "ty": 2,
      "x": 665,
      "y": 608
    },
    {
      "t": 102005,
      "e": 78142,
      "ty": 41,
      "x": 22625,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 102105,
      "e": 78242,
      "ty": 2,
      "x": 765,
      "y": 567
    },
    {
      "t": 102180,
      "e": 78317,
      "ty": 6,
      "x": 817,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102205,
      "e": 78342,
      "ty": 2,
      "x": 818,
      "y": 562
    },
    {
      "t": 102255,
      "e": 78392,
      "ty": 41,
      "x": 2379,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102304,
      "e": 78441,
      "ty": 2,
      "x": 819,
      "y": 560
    },
    {
      "t": 102467,
      "e": 78604,
      "ty": 3,
      "x": 819,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102468,
      "e": 78605,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102563,
      "e": 78700,
      "ty": 4,
      "x": 2379,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 102565,
      "e": 78702,
      "ty": 5,
      "x": 819,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103672,
      "e": 79809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 103673,
      "e": 79810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103711,
      "e": 79848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 103823,
      "e": 79960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 103823,
      "e": 79960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 103927,
      "e": 80064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 104672,
      "e": 80809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 104751,
      "e": 80888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 104791,
      "e": 80928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "51"
    },
    {
      "t": 104792,
      "e": 80929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 104855,
      "e": 80992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 105464,
      "e": 81601,
      "ty": 7,
      "x": 961,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 105504,
      "e": 81641,
      "ty": 2,
      "x": 949,
      "y": 602
    },
    {
      "t": 105504,
      "e": 81641,
      "ty": 41,
      "x": 30496,
      "y": 2340,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 105604,
      "e": 81741,
      "ty": 2,
      "x": 947,
      "y": 607
    },
    {
      "t": 105705,
      "e": 81842,
      "ty": 2,
      "x": 932,
      "y": 630
    },
    {
      "t": 105755,
      "e": 81892,
      "ty": 41,
      "x": 26387,
      "y": 33119,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 105805,
      "e": 81942,
      "ty": 2,
      "x": 911,
      "y": 638
    },
    {
      "t": 105904,
      "e": 82041,
      "ty": 2,
      "x": 878,
      "y": 645
    },
    {
      "t": 106005,
      "e": 82142,
      "ty": 2,
      "x": 877,
      "y": 646
    },
    {
      "t": 106005,
      "e": 82142,
      "ty": 41,
      "x": 14923,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 106037,
      "e": 82174,
      "ty": 6,
      "x": 876,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106104,
      "e": 82241,
      "ty": 2,
      "x": 876,
      "y": 650
    },
    {
      "t": 106204,
      "e": 82341,
      "ty": 2,
      "x": 869,
      "y": 657
    },
    {
      "t": 106255,
      "e": 82392,
      "ty": 41,
      "x": 13193,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106357,
      "e": 82494,
      "ty": 3,
      "x": 869,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106357,
      "e": 82494,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 106357,
      "e": 82494,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 106359,
      "e": 82496,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106419,
      "e": 82556,
      "ty": 4,
      "x": 13193,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106421,
      "e": 82558,
      "ty": 5,
      "x": 869,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107127,
      "e": 83264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 107263,
      "e": 83400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 107263,
      "e": 83400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107311,
      "e": 83448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "M"
    },
    {
      "t": 107359,
      "e": 83496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 107360,
      "e": 83497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107367,
      "e": 83504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Me"
    },
    {
      "t": 107431,
      "e": 83568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Me"
    },
    {
      "t": 107568,
      "e": 83705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "88"
    },
    {
      "t": 107569,
      "e": 83706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107655,
      "e": 83792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mex"
    },
    {
      "t": 107671,
      "e": 83808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 107671,
      "e": 83808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107735,
      "e": 83872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mexi"
    },
    {
      "t": 107767,
      "e": 83904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 107768,
      "e": 83905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107855,
      "e": 83992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 107856,
      "e": 83993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 107863,
      "e": 84000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||co"
    },
    {
      "t": 107919,
      "e": 84056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 109056,
      "e": 85193,
      "ty": 7,
      "x": 888,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109071,
      "e": 85208,
      "ty": 6,
      "x": 904,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109109,
      "e": 85246,
      "ty": 2,
      "x": 923,
      "y": 685
    },
    {
      "t": 109209,
      "e": 85346,
      "ty": 2,
      "x": 946,
      "y": 692
    },
    {
      "t": 109259,
      "e": 85396,
      "ty": 41,
      "x": 28902,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109309,
      "e": 85446,
      "ty": 2,
      "x": 952,
      "y": 692
    },
    {
      "t": 109624,
      "e": 85761,
      "ty": 3,
      "x": 952,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109626,
      "e": 85763,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Mexico"
    },
    {
      "t": 109626,
      "e": 85763,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 109626,
      "e": 85763,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109687,
      "e": 85824,
      "ty": 4,
      "x": 28902,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109688,
      "e": 85825,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109689,
      "e": 85826,
      "ty": 5,
      "x": 952,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 109689,
      "e": 85826,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 110709,
      "e": 86846,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 111758,
      "e": 87895,
      "ty": 41,
      "x": 26242,
      "y": 8936,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 111809,
      "e": 87946,
      "ty": 2,
      "x": 866,
      "y": 368
    },
    {
      "t": 111858,
      "e": 87995,
      "ty": 6,
      "x": 839,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 111873,
      "e": 88010,
      "ty": 7,
      "x": 836,
      "y": 314,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 111909,
      "e": 88046,
      "ty": 2,
      "x": 835,
      "y": 309
    },
    {
      "t": 111975,
      "e": 88112,
      "ty": 6,
      "x": 827,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 111991,
      "e": 88128,
      "ty": 7,
      "x": 820,
      "y": 274,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 112009,
      "e": 88146,
      "ty": 2,
      "x": 815,
      "y": 247
    },
    {
      "t": 112009,
      "e": 88146,
      "ty": 41,
      "x": 27791,
      "y": 13239,
      "ta": "html > body"
    },
    {
      "t": 112109,
      "e": 88246,
      "ty": 2,
      "x": 821,
      "y": 217
    },
    {
      "t": 112260,
      "e": 88397,
      "ty": 41,
      "x": 2930,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 112309,
      "e": 88446,
      "ty": 2,
      "x": 825,
      "y": 233
    },
    {
      "t": 112465,
      "e": 88602,
      "ty": 6,
      "x": 826,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 112508,
      "e": 88645,
      "ty": 2,
      "x": 829,
      "y": 240
    },
    {
      "t": 112509,
      "e": 88646,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 112558,
      "e": 88695,
      "ty": 7,
      "x": 831,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 112609,
      "e": 88746,
      "ty": 2,
      "x": 832,
      "y": 249
    },
    {
      "t": 112760,
      "e": 88897,
      "ty": 41,
      "x": 2510,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 112889,
      "e": 89026,
      "ty": 3,
      "x": 832,
      "y": 249,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 112951,
      "e": 89088,
      "ty": 4,
      "x": 2510,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 112952,
      "e": 89089,
      "ty": 5,
      "x": 832,
      "y": 249,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 113087,
      "e": 89224,
      "ty": 6,
      "x": 836,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113109,
      "e": 89246,
      "ty": 2,
      "x": 836,
      "y": 260
    },
    {
      "t": 113259,
      "e": 89396,
      "ty": 41,
      "x": 48284,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113295,
      "e": 89432,
      "ty": 3,
      "x": 836,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113295,
      "e": 89432,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113359,
      "e": 89496,
      "ty": 4,
      "x": 48284,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113359,
      "e": 89496,
      "ty": 5,
      "x": 836,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113360,
      "e": 89497,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 113458,
      "e": 89595,
      "ty": 7,
      "x": 836,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 113508,
      "e": 89645,
      "ty": 2,
      "x": 862,
      "y": 326
    },
    {
      "t": 113509,
      "e": 89645,
      "ty": 41,
      "x": 40282,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 113608,
      "e": 89744,
      "ty": 2,
      "x": 901,
      "y": 356
    },
    {
      "t": 113709,
      "e": 89845,
      "ty": 2,
      "x": 901,
      "y": 357
    },
    {
      "t": 113759,
      "e": 89895,
      "ty": 41,
      "x": 17699,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 113808,
      "e": 89944,
      "ty": 2,
      "x": 893,
      "y": 357
    },
    {
      "t": 113909,
      "e": 90045,
      "ty": 2,
      "x": 872,
      "y": 385
    },
    {
      "t": 114009,
      "e": 90145,
      "ty": 2,
      "x": 859,
      "y": 397
    },
    {
      "t": 114010,
      "e": 90146,
      "ty": 41,
      "x": 8918,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 114609,
      "e": 90745,
      "ty": 2,
      "x": 856,
      "y": 397
    },
    {
      "t": 114759,
      "e": 90895,
      "ty": 41,
      "x": 8206,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115008,
      "e": 91144,
      "ty": 2,
      "x": 854,
      "y": 392
    },
    {
      "t": 115008,
      "e": 91144,
      "ty": 41,
      "x": 7731,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115110,
      "e": 91246,
      "ty": 2,
      "x": 855,
      "y": 378
    },
    {
      "t": 115259,
      "e": 91395,
      "ty": 41,
      "x": 7968,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 115609,
      "e": 91745,
      "ty": 2,
      "x": 854,
      "y": 382
    },
    {
      "t": 115709,
      "e": 91845,
      "ty": 2,
      "x": 850,
      "y": 397
    },
    {
      "t": 115760,
      "e": 91896,
      "ty": 41,
      "x": 6307,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 115809,
      "e": 91945,
      "ty": 2,
      "x": 848,
      "y": 400
    },
    {
      "t": 116010,
      "e": 92146,
      "ty": 41,
      "x": 6307,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 116109,
      "e": 92245,
      "ty": 2,
      "x": 847,
      "y": 409
    },
    {
      "t": 116209,
      "e": 92345,
      "ty": 2,
      "x": 843,
      "y": 422
    },
    {
      "t": 116259,
      "e": 92395,
      "ty": 41,
      "x": 4409,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 116293,
      "e": 92429,
      "ty": 6,
      "x": 839,
      "y": 441,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116309,
      "e": 92445,
      "ty": 2,
      "x": 839,
      "y": 441
    },
    {
      "t": 116327,
      "e": 92463,
      "ty": 7,
      "x": 839,
      "y": 455,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 116345,
      "e": 92481,
      "ty": 6,
      "x": 837,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 116378,
      "e": 92514,
      "ty": 7,
      "x": 836,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 116409,
      "e": 92545,
      "ty": 2,
      "x": 836,
      "y": 482
    },
    {
      "t": 116509,
      "e": 92645,
      "ty": 2,
      "x": 836,
      "y": 486
    },
    {
      "t": 116509,
      "e": 92645,
      "ty": 41,
      "x": 3459,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 116609,
      "e": 92745,
      "ty": 2,
      "x": 836,
      "y": 490
    },
    {
      "t": 116627,
      "e": 92763,
      "ty": 6,
      "x": 836,
      "y": 495,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 116677,
      "e": 92813,
      "ty": 7,
      "x": 838,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 116709,
      "e": 92845,
      "ty": 2,
      "x": 838,
      "y": 508
    },
    {
      "t": 116759,
      "e": 92895,
      "ty": 41,
      "x": 14879,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 117409,
      "e": 93545,
      "ty": 2,
      "x": 838,
      "y": 507
    },
    {
      "t": 117428,
      "e": 93564,
      "ty": 6,
      "x": 835,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 117509,
      "e": 93645,
      "ty": 2,
      "x": 831,
      "y": 497
    },
    {
      "t": 117509,
      "e": 93645,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 117609,
      "e": 93745,
      "ty": 2,
      "x": 829,
      "y": 494
    },
    {
      "t": 117759,
      "e": 93895,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 117809,
      "e": 93945,
      "ty": 2,
      "x": 828,
      "y": 493
    },
    {
      "t": 117812,
      "e": 93948,
      "ty": 7,
      "x": 828,
      "y": 490,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 117909,
      "e": 94045,
      "ty": 2,
      "x": 824,
      "y": 473
    },
    {
      "t": 118009,
      "e": 94145,
      "ty": 41,
      "x": 2725,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 118109,
      "e": 94245,
      "ty": 2,
      "x": 824,
      "y": 472
    },
    {
      "t": 118119,
      "e": 94255,
      "ty": 6,
      "x": 826,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118209,
      "e": 94345,
      "ty": 2,
      "x": 826,
      "y": 469
    },
    {
      "t": 118239,
      "e": 94375,
      "ty": 3,
      "x": 826,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118240,
      "e": 94376,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 118240,
      "e": 94376,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118259,
      "e": 94395,
      "ty": 41,
      "x": 0,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118310,
      "e": 94446,
      "ty": 4,
      "x": 0,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118311,
      "e": 94447,
      "ty": 5,
      "x": 826,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118312,
      "e": 94448,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 118423,
      "e": 94559,
      "ty": 7,
      "x": 824,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 118479,
      "e": 94615,
      "ty": 6,
      "x": 837,
      "y": 523,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 118495,
      "e": 94631,
      "ty": 7,
      "x": 844,
      "y": 538,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 118509,
      "e": 94645,
      "ty": 2,
      "x": 844,
      "y": 538
    },
    {
      "t": 118509,
      "e": 94645,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 118609,
      "e": 94745,
      "ty": 2,
      "x": 876,
      "y": 600
    },
    {
      "t": 118708,
      "e": 94844,
      "ty": 2,
      "x": 881,
      "y": 604
    },
    {
      "t": 118760,
      "e": 94896,
      "ty": 41,
      "x": 14139,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 118809,
      "e": 94945,
      "ty": 2,
      "x": 881,
      "y": 609
    },
    {
      "t": 118908,
      "e": 95044,
      "ty": 2,
      "x": 887,
      "y": 646
    },
    {
      "t": 119009,
      "e": 95145,
      "ty": 2,
      "x": 884,
      "y": 669
    },
    {
      "t": 119009,
      "e": 95145,
      "ty": 41,
      "x": 16802,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 119110,
      "e": 95246,
      "ty": 2,
      "x": 880,
      "y": 677
    },
    {
      "t": 119209,
      "e": 95345,
      "ty": 2,
      "x": 855,
      "y": 584
    },
    {
      "t": 119259,
      "e": 95395,
      "ty": 41,
      "x": 21546,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 119310,
      "e": 95446,
      "ty": 2,
      "x": 859,
      "y": 534
    },
    {
      "t": 119408,
      "e": 95544,
      "ty": 2,
      "x": 864,
      "y": 508
    },
    {
      "t": 119509,
      "e": 95645,
      "ty": 2,
      "x": 865,
      "y": 507
    },
    {
      "t": 119509,
      "e": 95645,
      "ty": 41,
      "x": 39113,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 119609,
      "e": 95745,
      "ty": 2,
      "x": 868,
      "y": 506
    },
    {
      "t": 119709,
      "e": 95845,
      "ty": 2,
      "x": 893,
      "y": 627
    },
    {
      "t": 119759,
      "e": 95895,
      "ty": 41,
      "x": 17936,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 119808,
      "e": 95944,
      "ty": 2,
      "x": 894,
      "y": 669
    },
    {
      "t": 119908,
      "e": 96044,
      "ty": 2,
      "x": 886,
      "y": 677
    },
    {
      "t": 120008,
      "e": 96144,
      "ty": 2,
      "x": 882,
      "y": 677
    },
    {
      "t": 120008,
      "e": 96144,
      "ty": 41,
      "x": 16265,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 123408,
      "e": 99544,
      "ty": 2,
      "x": 858,
      "y": 671
    },
    {
      "t": 123509,
      "e": 99645,
      "ty": 2,
      "x": 843,
      "y": 671
    },
    {
      "t": 123509,
      "e": 99645,
      "ty": 41,
      "x": 5793,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 123600,
      "e": 99736,
      "ty": 6,
      "x": 839,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 123609,
      "e": 99745,
      "ty": 2,
      "x": 839,
      "y": 671
    },
    {
      "t": 123708,
      "e": 99844,
      "ty": 2,
      "x": 833,
      "y": 674
    },
    {
      "t": 123758,
      "e": 99894,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 123801,
      "e": 99937,
      "ty": 7,
      "x": 828,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 123809,
      "e": 99945,
      "ty": 2,
      "x": 828,
      "y": 681
    },
    {
      "t": 123909,
      "e": 100045,
      "ty": 2,
      "x": 821,
      "y": 698
    },
    {
      "t": 124009,
      "e": 100145,
      "ty": 2,
      "x": 821,
      "y": 700
    },
    {
      "t": 124009,
      "e": 100145,
      "ty": 41,
      "x": 0,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 124508,
      "e": 100644,
      "ty": 2,
      "x": 822,
      "y": 701
    },
    {
      "t": 124509,
      "e": 100645,
      "ty": 41,
      "x": 145,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 124609,
      "e": 100745,
      "ty": 2,
      "x": 824,
      "y": 701
    },
    {
      "t": 124625,
      "e": 100761,
      "ty": 6,
      "x": 826,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 124708,
      "e": 100844,
      "ty": 2,
      "x": 826,
      "y": 701
    },
    {
      "t": 124759,
      "e": 100895,
      "ty": 41,
      "x": 12996,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 124808,
      "e": 100944,
      "ty": 2,
      "x": 830,
      "y": 699
    },
    {
      "t": 125009,
      "e": 101145,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 125208,
      "e": 101344,
      "ty": 2,
      "x": 833,
      "y": 698
    },
    {
      "t": 125259,
      "e": 101395,
      "ty": 41,
      "x": 33161,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 125708,
      "e": 101844,
      "ty": 2,
      "x": 836,
      "y": 699
    },
    {
      "t": 125759,
      "e": 101895,
      "ty": 41,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126113,
      "e": 102249,
      "ty": 3,
      "x": 836,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126114,
      "e": 102250,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 126115,
      "e": 102251,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126239,
      "e": 102375,
      "ty": 4,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126239,
      "e": 102375,
      "ty": 5,
      "x": 836,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126240,
      "e": 102376,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 126452,
      "e": 102588,
      "ty": 7,
      "x": 844,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 126509,
      "e": 102645,
      "ty": 2,
      "x": 1027,
      "y": 750
    },
    {
      "t": 126509,
      "e": 102645,
      "ty": 41,
      "x": 48788,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 126609,
      "e": 102745,
      "ty": 2,
      "x": 1181,
      "y": 791
    },
    {
      "t": 126708,
      "e": 102844,
      "ty": 2,
      "x": 1188,
      "y": 794
    },
    {
      "t": 126758,
      "e": 102894,
      "ty": 41,
      "x": 40636,
      "y": 43542,
      "ta": "html > body"
    },
    {
      "t": 127109,
      "e": 103245,
      "ty": 2,
      "x": 1134,
      "y": 795
    },
    {
      "t": 127208,
      "e": 103344,
      "ty": 2,
      "x": 1091,
      "y": 805
    },
    {
      "t": 127259,
      "e": 103395,
      "ty": 41,
      "x": 61129,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 127308,
      "e": 103444,
      "ty": 2,
      "x": 1056,
      "y": 841
    },
    {
      "t": 127408,
      "e": 103544,
      "ty": 2,
      "x": 1011,
      "y": 903
    },
    {
      "t": 127509,
      "e": 103645,
      "ty": 2,
      "x": 993,
      "y": 931
    },
    {
      "t": 127509,
      "e": 103645,
      "ty": 41,
      "x": 40719,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 127609,
      "e": 103745,
      "ty": 2,
      "x": 971,
      "y": 958
    },
    {
      "t": 127708,
      "e": 103844,
      "ty": 2,
      "x": 949,
      "y": 954
    },
    {
      "t": 127759,
      "e": 103895,
      "ty": 41,
      "x": 27192,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 127809,
      "e": 103945,
      "ty": 2,
      "x": 930,
      "y": 946
    },
    {
      "t": 127908,
      "e": 104044,
      "ty": 2,
      "x": 902,
      "y": 932
    },
    {
      "t": 128009,
      "e": 104145,
      "ty": 2,
      "x": 875,
      "y": 925
    },
    {
      "t": 128009,
      "e": 104145,
      "ty": 41,
      "x": 58520,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 128109,
      "e": 104245,
      "ty": 2,
      "x": 871,
      "y": 925
    },
    {
      "t": 128208,
      "e": 104344,
      "ty": 2,
      "x": 856,
      "y": 933
    },
    {
      "t": 128259,
      "e": 104395,
      "ty": 41,
      "x": 29029,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 128308,
      "e": 104444,
      "ty": 2,
      "x": 839,
      "y": 945
    },
    {
      "t": 128509,
      "e": 104645,
      "ty": 41,
      "x": 4171,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 128609,
      "e": 104745,
      "ty": 2,
      "x": 836,
      "y": 945
    },
    {
      "t": 128708,
      "e": 104844,
      "ty": 2,
      "x": 835,
      "y": 945
    },
    {
      "t": 128759,
      "e": 104895,
      "ty": 41,
      "x": 2747,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 128809,
      "e": 104945,
      "ty": 2,
      "x": 833,
      "y": 945
    },
    {
      "t": 129109,
      "e": 105245,
      "ty": 2,
      "x": 833,
      "y": 942
    },
    {
      "t": 129144,
      "e": 105280,
      "ty": 3,
      "x": 833,
      "y": 942,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 129145,
      "e": 105281,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 129239,
      "e": 105375,
      "ty": 4,
      "x": 12646,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 129239,
      "e": 105375,
      "ty": 5,
      "x": 833,
      "y": 942,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 129240,
      "e": 105376,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 129240,
      "e": 105376,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 129258,
      "e": 105394,
      "ty": 41,
      "x": 12646,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 129509,
      "e": 105645,
      "ty": 2,
      "x": 835,
      "y": 941
    },
    {
      "t": 129509,
      "e": 105645,
      "ty": 41,
      "x": 14830,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 130008,
      "e": 106144,
      "ty": 2,
      "x": 872,
      "y": 955
    },
    {
      "t": 130009,
      "e": 106145,
      "ty": 41,
      "x": 40913,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 130108,
      "e": 106244,
      "ty": 2,
      "x": 904,
      "y": 973
    },
    {
      "t": 130258,
      "e": 106394,
      "ty": 41,
      "x": 19597,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 130309,
      "e": 106445,
      "ty": 2,
      "x": 904,
      "y": 987
    },
    {
      "t": 130409,
      "e": 106545,
      "ty": 2,
      "x": 910,
      "y": 1003
    },
    {
      "t": 130440,
      "e": 106576,
      "ty": 6,
      "x": 911,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 130509,
      "e": 106645,
      "ty": 2,
      "x": 911,
      "y": 1007
    },
    {
      "t": 130509,
      "e": 106645,
      "ty": 41,
      "x": 42044,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 130709,
      "e": 106845,
      "ty": 2,
      "x": 912,
      "y": 1009
    },
    {
      "t": 130759,
      "e": 106895,
      "ty": 41,
      "x": 43590,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 130809,
      "e": 106945,
      "ty": 2,
      "x": 914,
      "y": 1011
    },
    {
      "t": 132233,
      "e": 108369,
      "ty": 3,
      "x": 914,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132234,
      "e": 108370,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 132235,
      "e": 108371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132335,
      "e": 108471,
      "ty": 4,
      "x": 43590,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132335,
      "e": 108471,
      "ty": 5,
      "x": 914,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132337,
      "e": 108473,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 132338,
      "e": 108474,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 132339,
      "e": 108475,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 133683,
      "e": 109819,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 140009,
      "e": 113474,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 188612,
      "e": 113474,
      "ty": 2,
      "x": 914,
      "y": 1012
    },
    {
      "t": 188764,
      "e": 113626,
      "ty": 41,
      "x": 30529,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 200014,
      "e": 118626,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 234717,
      "e": 118626,
      "ty": 2,
      "x": 914,
      "y": 1019
    },
    {
      "t": 234766,
      "e": 118675,
      "ty": 41,
      "x": 30824,
      "y": 61955,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 234816,
      "e": 118725,
      "ty": 2,
      "x": 920,
      "y": 1021
    },
    {
      "t": 234916,
      "e": 118825,
      "ty": 2,
      "x": 924,
      "y": 1021
    },
    {
      "t": 235016,
      "e": 118925,
      "ty": 2,
      "x": 991,
      "y": 1068
    },
    {
      "t": 235017,
      "e": 118926,
      "ty": 41,
      "x": 34317,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 235025,
      "e": 118934,
      "ty": 6,
      "x": 998,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 235116,
      "e": 119025,
      "ty": 2,
      "x": 1002,
      "y": 1073
    },
    {
      "t": 235267,
      "e": 119176,
      "ty": 41,
      "x": 49424,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 235317,
      "e": 119226,
      "ty": 2,
      "x": 986,
      "y": 1087
    },
    {
      "t": 235416,
      "e": 119325,
      "ty": 2,
      "x": 985,
      "y": 1092
    },
    {
      "t": 235516,
      "e": 119425,
      "ty": 2,
      "x": 984,
      "y": 1093
    },
    {
      "t": 235517,
      "e": 119426,
      "ty": 41,
      "x": 40686,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 240016,
      "e": 123925,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 240141,
      "e": 124050,
      "ty": 3,
      "x": 984,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 240141,
      "e": 124050,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 240357,
      "e": 124266,
      "ty": 4,
      "x": 40686,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 240358,
      "e": 124267,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 240360,
      "e": 124269,
      "ty": 5,
      "x": 984,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 240362,
      "e": 124271,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 241393,
      "e": 125302,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 241930,
      "e": 125839,
      "ty": 2,
      "x": 984,
      "y": 1091
    },
    {
      "t": 241930,
      "e": 125839,
      "ty": 41,
      "x": 33437,
      "y": 32921,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 242017,
      "e": 125926,
      "ty": 2,
      "x": 992,
      "y": 1084
    },
    {
      "t": 242017,
      "e": 125926,
      "ty": 41,
      "x": 33656,
      "y": 32919,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 242116,
      "e": 126025,
      "ty": 2,
      "x": 1030,
      "y": 1027
    },
    {
      "t": 242216,
      "e": 126125,
      "ty": 2,
      "x": 1115,
      "y": 826
    },
    {
      "t": 242266,
      "e": 126175,
      "ty": 41,
      "x": 38089,
      "y": 32815,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 242316,
      "e": 126225,
      "ty": 2,
      "x": 1159,
      "y": 747
    },
    {
      "t": 242416,
      "e": 126325,
      "ty": 2,
      "x": 1160,
      "y": 747
    },
    {
      "t": 242517,
      "e": 126426,
      "ty": 41,
      "x": 38253,
      "y": 32813,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 242697,
      "e": 126606,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2303},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2315},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2344},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2346},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2348},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2350},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2352},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2354},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2356},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2358},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2360},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2362},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2364},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2366},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2368},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2370},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2372},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2374},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2376},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2378},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2380},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2382},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2384},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2386},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2388},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2390},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2393,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2392},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2345}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2347}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2349}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2351}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2353}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2355}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2357}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2359}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2361}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2363}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2365}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2367}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2369}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2371}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2373}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2375}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2377}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2379}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2381}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2383}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2385}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2387}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2389}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2391}},{\"nodeType\":3,\"id\":2418,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2393}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2343}},{\"nodeType\":3,\"id\":2420,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2419}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2446},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2460},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"0\",\"parentNode\":{\"id\":2437}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"1\",\"parentNode\":{\"id\":2439}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2441}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"3\",\"parentNode\":{\"id\":2443}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"4\",\"parentNode\":{\"id\":2445}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"5\",\"parentNode\":{\"id\":2447}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"6\",\"parentNode\":{\"id\":2449}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"7\",\"parentNode\":{\"id\":2451}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"8\",\"parentNode\":{\"id\":2453}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"9\",\"parentNode\":{\"id\":2455}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"10\",\"parentNode\":{\"id\":2457}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"11\",\"parentNode\":{\"id\":2459}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"12\",\"parentNode\":{\"id\":2461}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2487},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2488}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2551},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2553},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2557},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2559},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2567},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2569},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2571},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2573},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2575},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2577},\"parentNode\":{\"id\":2542}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"A \",\"parentNode\":{\"id\":2544}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"B \",\"parentNode\":{\"id\":2546}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"C \",\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"D \",\"parentNode\":{\"id\":2550}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"E \",\"parentNode\":{\"id\":2552}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"F \",\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"G \",\"parentNode\":{\"id\":2556}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"H \",\"parentNode\":{\"id\":2558}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"I \",\"parentNode\":{\"id\":2560}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"J \",\"parentNode\":{\"id\":2562}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"K \",\"parentNode\":{\"id\":2564}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"L \",\"parentNode\":{\"id\":2566}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"M \",\"parentNode\":{\"id\":2568}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"N \",\"parentNode\":{\"id\":2570}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"O \",\"parentNode\":{\"id\":2572}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"P \",\"parentNode\":{\"id\":2574}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"Z \",\"parentNode\":{\"id\":2576}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"X \",\"parentNode\":{\"id\":2578}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2312},{\"id\":2317},{\"id\":2318},{\"id\":2344},{\"id\":2345},{\"id\":2394},{\"id\":2319},{\"id\":2346},{\"id\":2347},{\"id\":2395},{\"id\":2320},{\"id\":2348},{\"id\":2349},{\"id\":2396},{\"id\":2321},{\"id\":2350},{\"id\":2351},{\"id\":2397},{\"id\":2322},{\"id\":2352},{\"id\":2353},{\"id\":2398},{\"id\":2323},{\"id\":2354},{\"id\":2355},{\"id\":2399},{\"id\":2324},{\"id\":2356},{\"id\":2357},{\"id\":2400},{\"id\":2325},{\"id\":2358},{\"id\":2359},{\"id\":2401},{\"id\":2326},{\"id\":2360},{\"id\":2361},{\"id\":2402},{\"id\":2327},{\"id\":2362},{\"id\":2363},{\"id\":2403},{\"id\":2328},{\"id\":2364},{\"id\":2365},{\"id\":2404},{\"id\":2329},{\"id\":2366},{\"id\":2367},{\"id\":2405},{\"id\":2330},{\"id\":2368},{\"id\":2369},{\"id\":2406},{\"id\":2331},{\"id\":2370},{\"id\":2371},{\"id\":2407},{\"id\":2332},{\"id\":2372},{\"id\":2373},{\"id\":2408},{\"id\":2333},{\"id\":2374},{\"id\":2375},{\"id\":2409},{\"id\":2334},{\"id\":2376},{\"id\":2377},{\"id\":2410},{\"id\":2335},{\"id\":2378},{\"id\":2379},{\"id\":2411},{\"id\":2336},{\"id\":2380},{\"id\":2381},{\"id\":2412},{\"id\":2337},{\"id\":2382},{\"id\":2383},{\"id\":2413},{\"id\":2338},{\"id\":2384},{\"id\":2385},{\"id\":2414},{\"id\":2339},{\"id\":2386},{\"id\":2387},{\"id\":2415},{\"id\":2340},{\"id\":2388},{\"id\":2389},{\"id\":2416},{\"id\":2341},{\"id\":2390},{\"id\":2391},{\"id\":2417},{\"id\":2342},{\"id\":2392},{\"id\":2393},{\"id\":2418},{\"id\":2343},{\"id\":2419},{\"id\":2420},{\"id\":2313},{\"id\":2421},{\"id\":2422},{\"id\":2436},{\"id\":2437},{\"id\":2462},{\"id\":2423},{\"id\":2438},{\"id\":2439},{\"id\":2463},{\"id\":2424},{\"id\":2440},{\"id\":2441},{\"id\":2464},{\"id\":2425},{\"id\":2442},{\"id\":2443},{\"id\":2465},{\"id\":2426},{\"id\":2444},{\"id\":2445},{\"id\":2466},{\"id\":2427},{\"id\":2446},{\"id\":2447},{\"id\":2467},{\"id\":2428},{\"id\":2448},{\"id\":2449},{\"id\":2468},{\"id\":2429},{\"id\":2450},{\"id\":2451},{\"id\":2469},{\"id\":2430},{\"id\":2452},{\"id\":2453},{\"id\":2470},{\"id\":2431},{\"id\":2454},{\"id\":2455},{\"id\":2471},{\"id\":2432},{\"id\":2456},{\"id\":2457},{\"id\":2472},{\"id\":2433},{\"id\":2458},{\"id\":2459},{\"id\":2473},{\"id\":2434},{\"id\":2460},{\"id\":2461},{\"id\":2474},{\"id\":2435},{\"id\":2475},{\"id\":2476},{\"id\":2314},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2488},{\"id\":2500},{\"id\":2315},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2316},{\"id\":2525},{\"id\":2543},{\"id\":2544},{\"id\":2579},{\"id\":2526},{\"id\":2545},{\"id\":2546},{\"id\":2580},{\"id\":2527},{\"id\":2547},{\"id\":2548},{\"id\":2581},{\"id\":2528},{\"id\":2549},{\"id\":2550},{\"id\":2582},{\"id\":2529},{\"id\":2551},{\"id\":2552},{\"id\":2583},{\"id\":2530},{\"id\":2553},{\"id\":2554},{\"id\":2584},{\"id\":2531},{\"id\":2555},{\"id\":2556},{\"id\":2585},{\"id\":2532},{\"id\":2557},{\"id\":2558},{\"id\":2586},{\"id\":2533},{\"id\":2559},{\"id\":2560},{\"id\":2587},{\"id\":2534},{\"id\":2561},{\"id\":2562},{\"id\":2588},{\"id\":2535},{\"id\":2563},{\"id\":2564},{\"id\":2589},{\"id\":2536},{\"id\":2565},{\"id\":2566},{\"id\":2590},{\"id\":2537},{\"id\":2567},{\"id\":2568},{\"id\":2591},{\"id\":2538},{\"id\":2569},{\"id\":2570},{\"id\":2592},{\"id\":2539},{\"id\":2571},{\"id\":2572},{\"id\":2593},{\"id\":2540},{\"id\":2573},{\"id\":2574},{\"id\":2594},{\"id\":2541},{\"id\":2575},{\"id\":2576},{\"id\":2595},{\"id\":2542},{\"id\":2577},{\"id\":2578},{\"id\":2596},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"nodeType\":3,\"id\":2597,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2309},{\"id\":2310},{\"nodeType\":3,\"id\":2598,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2311}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2601},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2605,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2603}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2601}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2601}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2606}},{\"nodeType\":3,\"id\":2609,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2602}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2599},{\"id\":2600},{\"id\":2603},{\"id\":2605},{\"id\":2604},{\"id\":2601},{\"id\":2606},{\"id\":2608},{\"id\":2607},{\"id\":2602},{\"id\":2609}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2610,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":56}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2622,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2624}},{\"nodeType\":3,\"id\":2626,\"textContent\":\"English\",\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2630}},{\"nodeType\":3,\"id\":2632,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2633}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"*\",\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2643},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2645,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"First\",\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2651},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2653}},{\"nodeType\":3,\"id\":2655,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2656}},{\"nodeType\":3,\"id\":2658,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2657},\"parentNode\":{\"id\":2656}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2659}},{\"nodeType\":3,\"id\":2661,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2660},\"parentNode\":{\"id\":2659}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2662}},{\"nodeType\":3,\"id\":2664,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2663},\"parentNode\":{\"id\":2662}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2666},\"parentNode\":{\"id\":2665}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"*\",\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2675},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2677,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2683},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2685}},{\"nodeType\":3,\"id\":2687,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2686},\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2688}},{\"nodeType\":3,\"id\":2690,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2689},\"parentNode\":{\"id\":2688}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2691}},{\"nodeType\":3,\"id\":2693,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2692},\"parentNode\":{\"id\":2691}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2694}},{\"nodeType\":3,\"id\":2696,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2695},\"parentNode\":{\"id\":2694}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2698},\"parentNode\":{\"id\":2697}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"*\",\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2703},\"parentNode\":{\"id\":2615}},{\"nodeType\":3,\"id\":2705,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2707}},{\"nodeType\":3,\"id\":2709,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2707}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2711},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2714},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"*\",\"parentNode\":{\"id\":2706}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2610},{\"id\":2611},{\"id\":2612},{\"id\":2617},{\"id\":2622},{\"id\":2623},{\"id\":2636},{\"id\":2618},{\"id\":2624},{\"id\":2625},{\"id\":2626},{\"id\":2619},{\"id\":2627},{\"id\":2628},{\"id\":2629},{\"id\":2620},{\"id\":2630},{\"id\":2631},{\"id\":2632},{\"id\":2621},{\"id\":2633},{\"id\":2634},{\"id\":2635},{\"id\":2613},{\"id\":2637},{\"id\":2645},{\"id\":2646},{\"id\":2668},{\"id\":2638},{\"id\":2647},{\"id\":2648},{\"id\":2649},{\"id\":2639},{\"id\":2650},{\"id\":2651},{\"id\":2652},{\"id\":2640},{\"id\":2653},{\"id\":2654},{\"id\":2655},{\"id\":2641},{\"id\":2656},{\"id\":2657},{\"id\":2658},{\"id\":2642},{\"id\":2659},{\"id\":2660},{\"id\":2661},{\"id\":2643},{\"id\":2662},{\"id\":2663},{\"id\":2664},{\"id\":2644},{\"id\":2665},{\"id\":2666},{\"id\":2667},{\"id\":2614},{\"id\":2669},{\"id\":2677},{\"id\":2678},{\"id\":2700},{\"id\":2670},{\"id\":2679},{\"id\":2680},{\"id\":2681},{\"id\":2671},{\"id\":2682},{\"id\":2683},{\"id\":2684},{\"id\":2672},{\"id\":2685},{\"id\":2686},{\"id\":2687},{\"id\":2673},{\"id\":2688},{\"id\":2689},{\"id\":2690},{\"id\":2674},{\"id\":2691},{\"id\":2692},{\"id\":2693},{\"id\":2675},{\"id\":2694},{\"id\":2695},{\"id\":2696},{\"id\":2676},{\"id\":2697},{\"id\":2698},{\"id\":2699},{\"id\":2615},{\"id\":2701},{\"id\":2705},{\"id\":2706},{\"id\":2716},{\"id\":2702},{\"id\":2707},{\"id\":2708},{\"id\":2709},{\"id\":2703},{\"id\":2710},{\"id\":2711},{\"id\":2712},{\"id\":2704},{\"id\":2713},{\"id\":2714},{\"id\":2715},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2717,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2722,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2720}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2732,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2722}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2722}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2740,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" \",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2750}},{\"nodeType\":3,\"id\":2753,\"textContent\":\" \",\"parentNode\":{\"id\":2740}},{\"nodeType\":1,\"id\":2754,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2755,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2754},\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2754}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2763,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2764,\"textContent\":\" \",\"previousSibling\":{\"id\":2763},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2765,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2763}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2717},{\"id\":2719},{\"id\":2720},{\"id\":2726},{\"id\":2727},{\"id\":2729},{\"id\":2730},{\"id\":2732},{\"id\":2731},{\"id\":2728},{\"id\":2721},{\"id\":2722},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2748},{\"id\":2738},{\"id\":2749},{\"id\":2750},{\"id\":2752},{\"id\":2751},{\"id\":2739},{\"id\":2740},{\"id\":2753},{\"id\":2754},{\"id\":2756},{\"id\":2755},{\"id\":2741},{\"id\":2742},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2743},{\"id\":2744},{\"id\":2760},{\"id\":2745},{\"id\":2746},{\"id\":2761},{\"id\":2747},{\"id\":2735},{\"id\":2723},{\"id\":2724},{\"id\":2762},{\"id\":2763},{\"id\":2765},{\"id\":2764},{\"id\":2725},{\"id\":2718}],[],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2766,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":56}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"[ { \\\"rt\\\": 56318, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 56324, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15749, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 73163, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13096, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"uniform\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 87267, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 42797, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 131160, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 31270, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 163433, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19867, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 184923, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1130,y:664,t:1527793649301};\\\", \\\"{x:1119,y:664,t:1527793649314};\\\", \\\"{x:1039,y:662,t:1527793649330};\\\", \\\"{x:919,y:662,t:1527793649347};\\\", \\\"{x:693,y:649,t:1527793649364};\\\", \\\"{x:590,y:638,t:1527793649379};\\\", \\\"{x:545,y:627,t:1527793649396};\\\", \\\"{x:539,y:623,t:1527793649412};\\\", \\\"{x:537,y:622,t:1527793649428};\\\", \\\"{x:534,y:621,t:1527793649450};\\\", \\\"{x:534,y:620,t:1527793649462};\\\", \\\"{x:530,y:617,t:1527793649479};\\\", \\\"{x:525,y:614,t:1527793649496};\\\", \\\"{x:523,y:613,t:1527793649513};\\\", \\\"{x:510,y:603,t:1527793649530};\\\", \\\"{x:495,y:592,t:1527793649548};\\\", \\\"{x:445,y:582,t:1527793649563};\\\", \\\"{x:354,y:563,t:1527793649581};\\\", \\\"{x:253,y:541,t:1527793649597};\\\", \\\"{x:201,y:528,t:1527793649614};\\\", \\\"{x:194,y:523,t:1527793649629};\\\", \\\"{x:193,y:523,t:1527793649683};\\\", \\\"{x:194,y:522,t:1527793649696};\\\", \\\"{x:197,y:520,t:1527793649713};\\\", \\\"{x:198,y:519,t:1527793649730};\\\", \\\"{x:201,y:517,t:1527793649746};\\\", \\\"{x:204,y:514,t:1527793649763};\\\", \\\"{x:210,y:510,t:1527793649780};\\\", \\\"{x:220,y:505,t:1527793649798};\\\", \\\"{x:226,y:504,t:1527793649812};\\\", \\\"{x:232,y:503,t:1527793649830};\\\", \\\"{x:233,y:502,t:1527793649847};\\\", \\\"{x:240,y:505,t:1527793649864};\\\", \\\"{x:247,y:507,t:1527793649881};\\\", \\\"{x:259,y:514,t:1527793649897};\\\", \\\"{x:261,y:514,t:1527793649930};\\\", \\\"{x:265,y:516,t:1527793649947};\\\", \\\"{x:267,y:518,t:1527793649964};\\\", \\\"{x:275,y:519,t:1527793649981};\\\", \\\"{x:284,y:521,t:1527793649996};\\\", \\\"{x:289,y:522,t:1527793650014};\\\", \\\"{x:297,y:523,t:1527793650031};\\\", \\\"{x:299,y:523,t:1527793650047};\\\", \\\"{x:301,y:523,t:1527793650064};\\\", \\\"{x:303,y:522,t:1527793650099};\\\", \\\"{x:315,y:517,t:1527793650115};\\\", \\\"{x:330,y:515,t:1527793650131};\\\", \\\"{x:334,y:509,t:1527793650147};\\\", \\\"{x:336,y:508,t:1527793650164};\\\", \\\"{x:339,y:508,t:1527793650211};\\\", \\\"{x:342,y:508,t:1527793650219};\\\", \\\"{x:348,y:508,t:1527793650231};\\\", \\\"{x:359,y:507,t:1527793650247};\\\", \\\"{x:367,y:505,t:1527793650265};\\\", \\\"{x:374,y:504,t:1527793650282};\\\", \\\"{x:376,y:504,t:1527793650297};\\\", \\\"{x:377,y:504,t:1527793650386};\\\", \\\"{x:377,y:505,t:1527793650397};\\\", \\\"{x:379,y:510,t:1527793650415};\\\", \\\"{x:379,y:512,t:1527793650431};\\\", \\\"{x:379,y:517,t:1527793650447};\\\", \\\"{x:380,y:519,t:1527793650464};\\\", \\\"{x:380,y:520,t:1527793650481};\\\", \\\"{x:380,y:521,t:1527793650539};\\\", \\\"{x:389,y:523,t:1527793650851};\\\", \\\"{x:394,y:523,t:1527793650864};\\\", \\\"{x:406,y:524,t:1527793650881};\\\", \\\"{x:433,y:538,t:1527793650899};\\\", \\\"{x:464,y:538,t:1527793650915};\\\", \\\"{x:484,y:544,t:1527793650932};\\\", \\\"{x:489,y:544,t:1527793650948};\\\", \\\"{x:504,y:546,t:1527793650965};\\\", \\\"{x:512,y:549,t:1527793650981};\\\", \\\"{x:523,y:550,t:1527793650997};\\\", \\\"{x:525,y:551,t:1527793651014};\\\", \\\"{x:525,y:569,t:1527793658299};\\\", \\\"{x:522,y:600,t:1527793658308};\\\", \\\"{x:522,y:648,t:1527793658320};\\\", \\\"{x:517,y:692,t:1527793658352};\\\", \\\"{x:514,y:708,t:1527793658363};\\\", \\\"{x:514,y:712,t:1527793658380};\\\", \\\"{x:514,y:715,t:1527793658404};\\\", \\\"{x:513,y:715,t:1527793658906};\\\" ] }, { \\\"rt\\\": 15831, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 202009, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:710,t:1527793666315};\\\", \\\"{x:582,y:694,t:1527793666330};\\\", \\\"{x:665,y:671,t:1527793666343};\\\", \\\"{x:776,y:643,t:1527793666360};\\\", \\\"{x:864,y:606,t:1527793666373};\\\", \\\"{x:914,y:576,t:1527793666388};\\\", \\\"{x:947,y:554,t:1527793666405};\\\", \\\"{x:1028,y:511,t:1527793666423};\\\", \\\"{x:1175,y:455,t:1527793666444};\\\", \\\"{x:1214,y:430,t:1527793666461};\\\", \\\"{x:1225,y:423,t:1527793666477};\\\", \\\"{x:1235,y:404,t:1527793666494};\\\", \\\"{x:1239,y:392,t:1527793666510};\\\", \\\"{x:1241,y:388,t:1527793666527};\\\", \\\"{x:1242,y:385,t:1527793666543};\\\", \\\"{x:1242,y:382,t:1527793666561};\\\", \\\"{x:1243,y:379,t:1527793666576};\\\", \\\"{x:1248,y:372,t:1527793666594};\\\", \\\"{x:1256,y:364,t:1527793666610};\\\", \\\"{x:1271,y:355,t:1527793666626};\\\", \\\"{x:1311,y:352,t:1527793666643};\\\", \\\"{x:1381,y:350,t:1527793666661};\\\", \\\"{x:1450,y:350,t:1527793666676};\\\", \\\"{x:1528,y:350,t:1527793666693};\\\", \\\"{x:1582,y:343,t:1527793666710};\\\", \\\"{x:1603,y:340,t:1527793666727};\\\", \\\"{x:1616,y:340,t:1527793666744};\\\", \\\"{x:1620,y:339,t:1527793666760};\\\", \\\"{x:1620,y:345,t:1527793666835};\\\", \\\"{x:1620,y:350,t:1527793666843};\\\", \\\"{x:1615,y:363,t:1527793666861};\\\", \\\"{x:1604,y:374,t:1527793666877};\\\", \\\"{x:1593,y:383,t:1527793666893};\\\", \\\"{x:1576,y:399,t:1527793666911};\\\", \\\"{x:1573,y:404,t:1527793666928};\\\", \\\"{x:1572,y:412,t:1527793666944};\\\", \\\"{x:1572,y:418,t:1527793666961};\\\", \\\"{x:1572,y:420,t:1527793666977};\\\", \\\"{x:1572,y:421,t:1527793666994};\\\", \\\"{x:1573,y:421,t:1527793667043};\\\", \\\"{x:1580,y:421,t:1527793667061};\\\", \\\"{x:1586,y:421,t:1527793667078};\\\", \\\"{x:1593,y:421,t:1527793667094};\\\", \\\"{x:1594,y:421,t:1527793667111};\\\", \\\"{x:1596,y:421,t:1527793667179};\\\", \\\"{x:1599,y:421,t:1527793667194};\\\", \\\"{x:1607,y:426,t:1527793667211};\\\", \\\"{x:1609,y:428,t:1527793667231};\\\", \\\"{x:1610,y:429,t:1527793667539};\\\", \\\"{x:1612,y:429,t:1527793667546};\\\", \\\"{x:1613,y:429,t:1527793667562};\\\", \\\"{x:1613,y:431,t:1527793667931};\\\", \\\"{x:1613,y:435,t:1527793667947};\\\", \\\"{x:1613,y:438,t:1527793667963};\\\", \\\"{x:1611,y:446,t:1527793667978};\\\", \\\"{x:1611,y:452,t:1527793667995};\\\", \\\"{x:1609,y:457,t:1527793668011};\\\", \\\"{x:1608,y:459,t:1527793668028};\\\", \\\"{x:1608,y:465,t:1527793668045};\\\", \\\"{x:1608,y:472,t:1527793668061};\\\", \\\"{x:1608,y:475,t:1527793668078};\\\", \\\"{x:1608,y:478,t:1527793668095};\\\", \\\"{x:1607,y:484,t:1527793668111};\\\", \\\"{x:1606,y:490,t:1527793668128};\\\", \\\"{x:1606,y:497,t:1527793668145};\\\", \\\"{x:1606,y:505,t:1527793668163};\\\", \\\"{x:1604,y:512,t:1527793668178};\\\", \\\"{x:1602,y:514,t:1527793668195};\\\", \\\"{x:1601,y:514,t:1527793668259};\\\", \\\"{x:1600,y:515,t:1527793668282};\\\", \\\"{x:1599,y:517,t:1527793668314};\\\", \\\"{x:1599,y:519,t:1527793668328};\\\", \\\"{x:1599,y:530,t:1527793668345};\\\", \\\"{x:1599,y:536,t:1527793668362};\\\", \\\"{x:1599,y:539,t:1527793668395};\\\", \\\"{x:1600,y:543,t:1527793668412};\\\", \\\"{x:1601,y:544,t:1527793668428};\\\", \\\"{x:1602,y:544,t:1527793668467};\\\", \\\"{x:1602,y:545,t:1527793668523};\\\", \\\"{x:1602,y:546,t:1527793668547};\\\", \\\"{x:1603,y:546,t:1527793668563};\\\", \\\"{x:1604,y:548,t:1527793668579};\\\", \\\"{x:1604,y:550,t:1527793668595};\\\", \\\"{x:1608,y:553,t:1527793668643};\\\", \\\"{x:1608,y:554,t:1527793668899};\\\", \\\"{x:1608,y:556,t:1527793669683};\\\", \\\"{x:1608,y:557,t:1527793669698};\\\", \\\"{x:1608,y:559,t:1527793669843};\\\", \\\"{x:1608,y:560,t:1527793669851};\\\", \\\"{x:1608,y:562,t:1527793669875};\\\", \\\"{x:1608,y:563,t:1527793669882};\\\", \\\"{x:1609,y:564,t:1527793669899};\\\", \\\"{x:1610,y:564,t:1527793669912};\\\", \\\"{x:1610,y:565,t:1527793669929};\\\", \\\"{x:1611,y:566,t:1527793669946};\\\", \\\"{x:1613,y:567,t:1527793670001};\\\", \\\"{x:1613,y:569,t:1527793670012};\\\", \\\"{x:1615,y:570,t:1527793670028};\\\", \\\"{x:1616,y:571,t:1527793670045};\\\", \\\"{x:1616,y:572,t:1527793670506};\\\", \\\"{x:1616,y:570,t:1527793670553};\\\", \\\"{x:1617,y:570,t:1527793671587};\\\", \\\"{x:1618,y:571,t:1527793671598};\\\", \\\"{x:1618,y:573,t:1527793671613};\\\", \\\"{x:1619,y:578,t:1527793671630};\\\", \\\"{x:1621,y:580,t:1527793671647};\\\", \\\"{x:1622,y:582,t:1527793671662};\\\", \\\"{x:1623,y:584,t:1527793671680};\\\", \\\"{x:1623,y:586,t:1527793671697};\\\", \\\"{x:1623,y:590,t:1527793671713};\\\", \\\"{x:1623,y:605,t:1527793671731};\\\", \\\"{x:1625,y:613,t:1527793671746};\\\", \\\"{x:1625,y:626,t:1527793671764};\\\", \\\"{x:1625,y:631,t:1527793671780};\\\", \\\"{x:1625,y:635,t:1527793671797};\\\", \\\"{x:1625,y:641,t:1527793671812};\\\", \\\"{x:1625,y:650,t:1527793671829};\\\", \\\"{x:1624,y:657,t:1527793671847};\\\", \\\"{x:1622,y:662,t:1527793671863};\\\", \\\"{x:1619,y:668,t:1527793671880};\\\", \\\"{x:1618,y:676,t:1527793671897};\\\", \\\"{x:1616,y:689,t:1527793671913};\\\", \\\"{x:1616,y:690,t:1527793671930};\\\", \\\"{x:1615,y:695,t:1527793671946};\\\", \\\"{x:1613,y:699,t:1527793671963};\\\", \\\"{x:1612,y:701,t:1527793671979};\\\", \\\"{x:1611,y:704,t:1527793671997};\\\", \\\"{x:1610,y:705,t:1527793672013};\\\", \\\"{x:1610,y:706,t:1527793672030};\\\", \\\"{x:1610,y:707,t:1527793672046};\\\", \\\"{x:1610,y:709,t:1527793672065};\\\", \\\"{x:1610,y:710,t:1527793672079};\\\", \\\"{x:1609,y:710,t:1527793672097};\\\", \\\"{x:1609,y:712,t:1527793672114};\\\", \\\"{x:1608,y:717,t:1527793672130};\\\", \\\"{x:1608,y:719,t:1527793672162};\\\", \\\"{x:1608,y:721,t:1527793672170};\\\", \\\"{x:1608,y:723,t:1527793672202};\\\", \\\"{x:1608,y:725,t:1527793672219};\\\", \\\"{x:1609,y:728,t:1527793672230};\\\", \\\"{x:1610,y:731,t:1527793672247};\\\", \\\"{x:1610,y:733,t:1527793672265};\\\", \\\"{x:1611,y:739,t:1527793672280};\\\", \\\"{x:1612,y:750,t:1527793672297};\\\", \\\"{x:1613,y:751,t:1527793672314};\\\", \\\"{x:1616,y:755,t:1527793672379};\\\", \\\"{x:1619,y:765,t:1527793672397};\\\", \\\"{x:1620,y:773,t:1527793672414};\\\", \\\"{x:1618,y:775,t:1527793672430};\\\", \\\"{x:1618,y:777,t:1527793672447};\\\", \\\"{x:1617,y:781,t:1527793672466};\\\", \\\"{x:1617,y:784,t:1527793672499};\\\", \\\"{x:1614,y:793,t:1527793672514};\\\", \\\"{x:1613,y:803,t:1527793672531};\\\", \\\"{x:1612,y:814,t:1527793672547};\\\", \\\"{x:1610,y:821,t:1527793672564};\\\", \\\"{x:1608,y:828,t:1527793672581};\\\", \\\"{x:1606,y:833,t:1527793672597};\\\", \\\"{x:1605,y:842,t:1527793672615};\\\", \\\"{x:1605,y:844,t:1527793672630};\\\", \\\"{x:1605,y:845,t:1527793672647};\\\", \\\"{x:1603,y:850,t:1527793672664};\\\", \\\"{x:1603,y:853,t:1527793672681};\\\", \\\"{x:1603,y:858,t:1527793672697};\\\", \\\"{x:1603,y:867,t:1527793672714};\\\", \\\"{x:1606,y:875,t:1527793672731};\\\", \\\"{x:1609,y:881,t:1527793672747};\\\", \\\"{x:1611,y:891,t:1527793672764};\\\", \\\"{x:1615,y:905,t:1527793672781};\\\", \\\"{x:1616,y:910,t:1527793672797};\\\", \\\"{x:1617,y:913,t:1527793672814};\\\", \\\"{x:1617,y:921,t:1527793672831};\\\", \\\"{x:1622,y:929,t:1527793672847};\\\", \\\"{x:1623,y:937,t:1527793672865};\\\", \\\"{x:1624,y:937,t:1527793672881};\\\", \\\"{x:1627,y:943,t:1527793672898};\\\", \\\"{x:1628,y:949,t:1527793672915};\\\", \\\"{x:1628,y:950,t:1527793672931};\\\", \\\"{x:1628,y:952,t:1527793672947};\\\", \\\"{x:1628,y:953,t:1527793672978};\\\", \\\"{x:1627,y:954,t:1527793673003};\\\", \\\"{x:1625,y:956,t:1527793673115};\\\", \\\"{x:1624,y:957,t:1527793673147};\\\", \\\"{x:1623,y:957,t:1527793673154};\\\", \\\"{x:1622,y:958,t:1527793673164};\\\", \\\"{x:1620,y:959,t:1527793673182};\\\", \\\"{x:1619,y:959,t:1527793673198};\\\", \\\"{x:1619,y:960,t:1527793673214};\\\", \\\"{x:1618,y:960,t:1527793673231};\\\", \\\"{x:1618,y:961,t:1527793673248};\\\", \\\"{x:1618,y:957,t:1527793673483};\\\", \\\"{x:1618,y:947,t:1527793673499};\\\", \\\"{x:1619,y:938,t:1527793673514};\\\", \\\"{x:1620,y:929,t:1527793673531};\\\", \\\"{x:1620,y:923,t:1527793673548};\\\", \\\"{x:1620,y:916,t:1527793673565};\\\", \\\"{x:1619,y:909,t:1527793673582};\\\", \\\"{x:1617,y:899,t:1527793673599};\\\", \\\"{x:1614,y:887,t:1527793673614};\\\", \\\"{x:1613,y:879,t:1527793673631};\\\", \\\"{x:1611,y:875,t:1527793673648};\\\", \\\"{x:1610,y:868,t:1527793673665};\\\", \\\"{x:1610,y:865,t:1527793673681};\\\", \\\"{x:1607,y:856,t:1527793673699};\\\", \\\"{x:1604,y:844,t:1527793673714};\\\", \\\"{x:1599,y:835,t:1527793673732};\\\", \\\"{x:1591,y:823,t:1527793673748};\\\", \\\"{x:1580,y:807,t:1527793673766};\\\", \\\"{x:1567,y:788,t:1527793673781};\\\", \\\"{x:1545,y:764,t:1527793673799};\\\", \\\"{x:1513,y:736,t:1527793673815};\\\", \\\"{x:1441,y:691,t:1527793673832};\\\", \\\"{x:1410,y:670,t:1527793673848};\\\", \\\"{x:1390,y:659,t:1527793673866};\\\", \\\"{x:1364,y:654,t:1527793673881};\\\", \\\"{x:1266,y:652,t:1527793673899};\\\", \\\"{x:1185,y:651,t:1527793673914};\\\", \\\"{x:1092,y:647,t:1527793673932};\\\", \\\"{x:1005,y:641,t:1527793673948};\\\", \\\"{x:933,y:641,t:1527793673965};\\\", \\\"{x:897,y:641,t:1527793673982};\\\", \\\"{x:869,y:637,t:1527793673998};\\\", \\\"{x:828,y:631,t:1527793674015};\\\", \\\"{x:790,y:624,t:1527793674031};\\\", \\\"{x:768,y:618,t:1527793674048};\\\", \\\"{x:760,y:618,t:1527793674065};\\\", \\\"{x:756,y:618,t:1527793674081};\\\", \\\"{x:742,y:621,t:1527793674098};\\\", \\\"{x:720,y:621,t:1527793674116};\\\", \\\"{x:702,y:621,t:1527793674130};\\\", \\\"{x:663,y:620,t:1527793674148};\\\", \\\"{x:625,y:620,t:1527793674167};\\\", \\\"{x:591,y:620,t:1527793674182};\\\", \\\"{x:553,y:620,t:1527793674200};\\\", \\\"{x:536,y:622,t:1527793674216};\\\", \\\"{x:522,y:622,t:1527793674232};\\\", \\\"{x:510,y:622,t:1527793674249};\\\", \\\"{x:494,y:622,t:1527793674267};\\\", \\\"{x:472,y:622,t:1527793674282};\\\", \\\"{x:451,y:618,t:1527793674300};\\\", \\\"{x:429,y:616,t:1527793674317};\\\", \\\"{x:419,y:614,t:1527793674332};\\\", \\\"{x:416,y:614,t:1527793674350};\\\", \\\"{x:404,y:613,t:1527793674367};\\\", \\\"{x:397,y:613,t:1527793674382};\\\", \\\"{x:383,y:613,t:1527793674400};\\\", \\\"{x:361,y:614,t:1527793674417};\\\", \\\"{x:349,y:615,t:1527793674433};\\\", \\\"{x:345,y:615,t:1527793674450};\\\", \\\"{x:343,y:615,t:1527793674467};\\\", \\\"{x:336,y:614,t:1527793674484};\\\", \\\"{x:328,y:613,t:1527793674500};\\\", \\\"{x:327,y:613,t:1527793674517};\\\", \\\"{x:324,y:613,t:1527793674547};\\\", \\\"{x:319,y:612,t:1527793674556};\\\", \\\"{x:316,y:612,t:1527793674567};\\\", \\\"{x:300,y:612,t:1527793674583};\\\", \\\"{x:293,y:614,t:1527793674600};\\\", \\\"{x:289,y:616,t:1527793674617};\\\", \\\"{x:281,y:621,t:1527793674633};\\\", \\\"{x:277,y:621,t:1527793674649};\\\", \\\"{x:273,y:624,t:1527793674667};\\\", \\\"{x:272,y:625,t:1527793674684};\\\", \\\"{x:261,y:626,t:1527793674699};\\\", \\\"{x:249,y:626,t:1527793674717};\\\", \\\"{x:237,y:626,t:1527793674733};\\\", \\\"{x:215,y:622,t:1527793674751};\\\", \\\"{x:199,y:616,t:1527793674767};\\\", \\\"{x:183,y:614,t:1527793674784};\\\", \\\"{x:180,y:614,t:1527793674799};\\\", \\\"{x:175,y:611,t:1527793674818};\\\", \\\"{x:173,y:611,t:1527793674833};\\\", \\\"{x:172,y:611,t:1527793674947};\\\", \\\"{x:169,y:611,t:1527793674962};\\\", \\\"{x:168,y:611,t:1527793674970};\\\", \\\"{x:165,y:612,t:1527793674984};\\\", \\\"{x:163,y:616,t:1527793675001};\\\", \\\"{x:160,y:621,t:1527793675018};\\\", \\\"{x:155,y:628,t:1527793675033};\\\", \\\"{x:153,y:630,t:1527793675050};\\\", \\\"{x:152,y:630,t:1527793675073};\\\", \\\"{x:154,y:631,t:1527793675425};\\\", \\\"{x:157,y:636,t:1527793675434};\\\", \\\"{x:163,y:639,t:1527793675450};\\\", \\\"{x:205,y:648,t:1527793675467};\\\", \\\"{x:227,y:658,t:1527793675484};\\\", \\\"{x:267,y:667,t:1527793675500};\\\", \\\"{x:287,y:674,t:1527793675517};\\\", \\\"{x:299,y:681,t:1527793675534};\\\", \\\"{x:306,y:685,t:1527793675550};\\\", \\\"{x:323,y:692,t:1527793675567};\\\", \\\"{x:341,y:698,t:1527793675584};\\\", \\\"{x:359,y:704,t:1527793675600};\\\", \\\"{x:366,y:704,t:1527793675617};\\\", \\\"{x:369,y:704,t:1527793675634};\\\", \\\"{x:371,y:704,t:1527793675658};\\\", \\\"{x:372,y:704,t:1527793675667};\\\", \\\"{x:380,y:709,t:1527793675684};\\\", \\\"{x:395,y:717,t:1527793675700};\\\", \\\"{x:410,y:726,t:1527793675717};\\\", \\\"{x:426,y:738,t:1527793675735};\\\", \\\"{x:446,y:740,t:1527793675750};\\\", \\\"{x:468,y:747,t:1527793675766};\\\", \\\"{x:487,y:756,t:1527793675784};\\\", \\\"{x:526,y:764,t:1527793675799};\\\", \\\"{x:530,y:767,t:1527793675817};\\\", \\\"{x:543,y:768,t:1527793675834};\\\", \\\"{x:547,y:768,t:1527793675850};\\\", \\\"{x:547,y:767,t:1527793675882};\\\", \\\"{x:547,y:765,t:1527793675890};\\\", \\\"{x:544,y:763,t:1527793675900};\\\", \\\"{x:542,y:761,t:1527793675917};\\\", \\\"{x:542,y:758,t:1527793675934};\\\", \\\"{x:542,y:753,t:1527793675950};\\\", \\\"{x:540,y:748,t:1527793675967};\\\", \\\"{x:532,y:737,t:1527793675983};\\\", \\\"{x:526,y:730,t:1527793676001};\\\", \\\"{x:524,y:727,t:1527793676016};\\\", \\\"{x:511,y:720,t:1527793676035};\\\", \\\"{x:506,y:717,t:1527793676051};\\\", \\\"{x:504,y:716,t:1527793676067};\\\", \\\"{x:503,y:715,t:1527793676146};\\\", \\\"{x:504,y:713,t:1527793676433};\\\", \\\"{x:518,y:712,t:1527793676441};\\\", \\\"{x:552,y:711,t:1527793676452};\\\", \\\"{x:639,y:709,t:1527793676468};\\\", \\\"{x:758,y:709,t:1527793676485};\\\", \\\"{x:863,y:701,t:1527793676502};\\\", \\\"{x:965,y:687,t:1527793676517};\\\", \\\"{x:1052,y:674,t:1527793676534};\\\", \\\"{x:1073,y:662,t:1527793676552};\\\", \\\"{x:1076,y:652,t:1527793676568};\\\", \\\"{x:1088,y:644,t:1527793676585};\\\", \\\"{x:1094,y:638,t:1527793676602};\\\", \\\"{x:1096,y:636,t:1527793676617};\\\" ] }, { \\\"rt\\\": 54272, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 257621, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-A -A -C -C -A -C -A -Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1097,y:627,t:1527793684659};\\\", \\\"{x:1100,y:612,t:1527793684675};\\\", \\\"{x:1100,y:608,t:1527793684691};\\\", \\\"{x:1100,y:601,t:1527793684709};\\\", \\\"{x:1093,y:585,t:1527793684725};\\\", \\\"{x:1085,y:574,t:1527793684741};\\\", \\\"{x:1082,y:569,t:1527793684760};\\\", \\\"{x:1078,y:561,t:1527793684776};\\\", \\\"{x:1071,y:548,t:1527793684792};\\\", \\\"{x:1060,y:530,t:1527793684809};\\\", \\\"{x:1052,y:512,t:1527793684826};\\\", \\\"{x:1045,y:501,t:1527793684842};\\\", \\\"{x:1043,y:495,t:1527793684858};\\\", \\\"{x:1045,y:494,t:1527793684947};\\\", \\\"{x:1057,y:501,t:1527793684959};\\\", \\\"{x:1070,y:508,t:1527793684975};\\\", \\\"{x:1099,y:531,t:1527793684991};\\\", \\\"{x:1146,y:561,t:1527793685008};\\\", \\\"{x:1185,y:591,t:1527793685025};\\\", \\\"{x:1209,y:613,t:1527793685042};\\\", \\\"{x:1214,y:618,t:1527793685065};\\\", \\\"{x:1225,y:626,t:1527793685075};\\\", \\\"{x:1245,y:651,t:1527793685092};\\\", \\\"{x:1253,y:665,t:1527793685108};\\\", \\\"{x:1259,y:678,t:1527793685125};\\\", \\\"{x:1260,y:687,t:1527793685142};\\\", \\\"{x:1260,y:702,t:1527793685158};\\\", \\\"{x:1260,y:711,t:1527793685175};\\\", \\\"{x:1260,y:725,t:1527793685192};\\\", \\\"{x:1260,y:735,t:1527793685208};\\\", \\\"{x:1260,y:743,t:1527793685225};\\\", \\\"{x:1260,y:760,t:1527793685241};\\\", \\\"{x:1259,y:774,t:1527793685259};\\\", \\\"{x:1259,y:785,t:1527793685276};\\\", \\\"{x:1256,y:791,t:1527793685293};\\\", \\\"{x:1252,y:796,t:1527793685308};\\\", \\\"{x:1249,y:797,t:1527793685326};\\\", \\\"{x:1249,y:798,t:1527793685342};\\\", \\\"{x:1249,y:799,t:1527793685403};\\\", \\\"{x:1249,y:800,t:1527793685410};\\\", \\\"{x:1253,y:803,t:1527793685426};\\\", \\\"{x:1255,y:805,t:1527793685442};\\\", \\\"{x:1265,y:813,t:1527793685460};\\\", \\\"{x:1272,y:816,t:1527793685476};\\\", \\\"{x:1277,y:820,t:1527793685493};\\\", \\\"{x:1280,y:823,t:1527793685509};\\\", \\\"{x:1280,y:824,t:1527793685526};\\\", \\\"{x:1281,y:824,t:1527793685658};\\\", \\\"{x:1281,y:825,t:1527793685718};\\\", \\\"{x:1281,y:827,t:1527793685725};\\\", \\\"{x:1281,y:828,t:1527793685742};\\\", \\\"{x:1281,y:829,t:1527793685759};\\\", \\\"{x:1281,y:831,t:1527793685775};\\\", \\\"{x:1279,y:834,t:1527793685793};\\\", \\\"{x:1275,y:835,t:1527793685810};\\\", \\\"{x:1270,y:838,t:1527793685825};\\\", \\\"{x:1266,y:838,t:1527793685842};\\\", \\\"{x:1261,y:839,t:1527793685860};\\\", \\\"{x:1257,y:839,t:1527793685881};\\\", \\\"{x:1253,y:839,t:1527793685892};\\\", \\\"{x:1245,y:840,t:1527793685910};\\\", \\\"{x:1241,y:840,t:1527793685926};\\\", \\\"{x:1232,y:840,t:1527793685943};\\\", \\\"{x:1224,y:840,t:1527793685960};\\\", \\\"{x:1219,y:841,t:1527793685976};\\\", \\\"{x:1218,y:841,t:1527793686195};\\\", \\\"{x:1217,y:841,t:1527793686210};\\\", \\\"{x:1217,y:840,t:1527793686234};\\\", \\\"{x:1216,y:839,t:1527793686242};\\\", \\\"{x:1215,y:838,t:1527793686290};\\\", \\\"{x:1215,y:837,t:1527793686330};\\\", \\\"{x:1214,y:836,t:1527793686355};\\\", \\\"{x:1213,y:835,t:1527793686403};\\\", \\\"{x:1213,y:834,t:1527793686427};\\\", \\\"{x:1212,y:834,t:1527793686444};\\\", \\\"{x:1212,y:832,t:1527793686459};\\\", \\\"{x:1212,y:831,t:1527793686476};\\\", \\\"{x:1212,y:830,t:1527793686499};\\\", \\\"{x:1211,y:829,t:1527793686522};\\\", \\\"{x:1211,y:827,t:1527793710854};\\\", \\\"{x:1211,y:826,t:1527793710886};\\\", \\\"{x:1212,y:825,t:1527793710925};\\\", \\\"{x:1214,y:824,t:1527793710983};\\\", \\\"{x:1216,y:823,t:1527793711000};\\\", \\\"{x:1216,y:822,t:1527793711181};\\\", \\\"{x:1218,y:822,t:1527793711198};\\\", \\\"{x:1220,y:821,t:1527793711214};\\\", \\\"{x:1220,y:820,t:1527793711221};\\\", \\\"{x:1221,y:820,t:1527793711237};\\\", \\\"{x:1222,y:820,t:1527793711253};\\\", \\\"{x:1224,y:820,t:1527793711266};\\\", \\\"{x:1225,y:820,t:1527793711283};\\\", \\\"{x:1228,y:820,t:1527793711300};\\\", \\\"{x:1234,y:820,t:1527793711317};\\\", \\\"{x:1235,y:820,t:1527793711334};\\\", \\\"{x:1237,y:819,t:1527793711351};\\\", \\\"{x:1239,y:818,t:1527793711368};\\\", \\\"{x:1240,y:817,t:1527793711383};\\\", \\\"{x:1241,y:817,t:1527793711405};\\\", \\\"{x:1242,y:817,t:1527793711417};\\\", \\\"{x:1245,y:816,t:1527793711433};\\\", \\\"{x:1249,y:815,t:1527793711450};\\\", \\\"{x:1250,y:815,t:1527793711467};\\\", \\\"{x:1251,y:815,t:1527793711483};\\\", \\\"{x:1253,y:815,t:1527793711502};\\\", \\\"{x:1254,y:815,t:1527793711517};\\\", \\\"{x:1255,y:815,t:1527793711549};\\\", \\\"{x:1257,y:815,t:1527793711567};\\\", \\\"{x:1258,y:815,t:1527793711621};\\\", \\\"{x:1259,y:815,t:1527793711634};\\\", \\\"{x:1261,y:816,t:1527793711650};\\\", \\\"{x:1267,y:818,t:1527793711667};\\\", \\\"{x:1272,y:820,t:1527793711684};\\\", \\\"{x:1274,y:821,t:1527793711701};\\\", \\\"{x:1275,y:821,t:1527793711717};\\\", \\\"{x:1276,y:821,t:1527793711813};\\\", \\\"{x:1276,y:822,t:1527793711821};\\\", \\\"{x:1277,y:822,t:1527793711837};\\\", \\\"{x:1278,y:822,t:1527793711934};\\\", \\\"{x:1279,y:822,t:1527793711950};\\\", \\\"{x:1281,y:822,t:1527793712061};\\\", \\\"{x:1282,y:823,t:1527793712294};\\\", \\\"{x:1283,y:824,t:1527793712589};\\\", \\\"{x:1277,y:824,t:1527793717549};\\\", \\\"{x:1272,y:821,t:1527793717557};\\\", \\\"{x:1271,y:821,t:1527793717571};\\\", \\\"{x:1268,y:821,t:1527793717588};\\\", \\\"{x:1260,y:821,t:1527793717604};\\\", \\\"{x:1251,y:827,t:1527793717621};\\\", \\\"{x:1245,y:829,t:1527793717639};\\\", \\\"{x:1241,y:829,t:1527793717661};\\\", \\\"{x:1240,y:829,t:1527793717671};\\\", \\\"{x:1239,y:829,t:1527793717688};\\\", \\\"{x:1238,y:829,t:1527793717706};\\\", \\\"{x:1237,y:829,t:1527793717723};\\\", \\\"{x:1235,y:830,t:1527793717877};\\\", \\\"{x:1233,y:830,t:1527793717889};\\\", \\\"{x:1232,y:830,t:1527793718286};\\\", \\\"{x:1231,y:830,t:1527793718334};\\\", \\\"{x:1230,y:830,t:1527793718357};\\\", \\\"{x:1229,y:828,t:1527793718373};\\\", \\\"{x:1228,y:828,t:1527793718390};\\\", \\\"{x:1227,y:827,t:1527793718405};\\\", \\\"{x:1225,y:826,t:1527793718437};\\\", \\\"{x:1225,y:825,t:1527793718478};\\\", \\\"{x:1224,y:825,t:1527793718517};\\\", \\\"{x:1224,y:824,t:1527793718533};\\\", \\\"{x:1221,y:822,t:1527793719181};\\\", \\\"{x:1219,y:821,t:1527793719190};\\\", \\\"{x:1218,y:821,t:1527793719207};\\\", \\\"{x:1215,y:821,t:1527793719224};\\\", \\\"{x:1211,y:821,t:1527793719240};\\\", \\\"{x:1209,y:821,t:1527793719257};\\\", \\\"{x:1207,y:823,t:1527793719273};\\\", \\\"{x:1206,y:823,t:1527793719301};\\\", \\\"{x:1205,y:823,t:1527793719309};\\\", \\\"{x:1204,y:823,t:1527793719324};\\\", \\\"{x:1203,y:825,t:1527793719340};\\\", \\\"{x:1202,y:826,t:1527793719461};\\\", \\\"{x:1203,y:830,t:1527793719473};\\\", \\\"{x:1219,y:840,t:1527793719490};\\\", \\\"{x:1224,y:842,t:1527793719506};\\\", \\\"{x:1225,y:842,t:1527793719531};\\\", \\\"{x:1226,y:842,t:1527793719877};\\\", \\\"{x:1227,y:842,t:1527793719932};\\\", \\\"{x:1227,y:840,t:1527793720580};\\\", \\\"{x:1228,y:838,t:1527793720860};\\\", \\\"{x:1230,y:837,t:1527793720874};\\\", \\\"{x:1231,y:836,t:1527793720890};\\\", \\\"{x:1233,y:834,t:1527793720907};\\\", \\\"{x:1236,y:834,t:1527793720924};\\\", \\\"{x:1238,y:833,t:1527793720940};\\\", \\\"{x:1238,y:832,t:1527793720988};\\\", \\\"{x:1240,y:831,t:1527793720996};\\\", \\\"{x:1242,y:830,t:1527793721013};\\\", \\\"{x:1243,y:829,t:1527793721024};\\\", \\\"{x:1249,y:826,t:1527793721041};\\\", \\\"{x:1254,y:823,t:1527793721057};\\\", \\\"{x:1255,y:822,t:1527793721084};\\\", \\\"{x:1256,y:821,t:1527793721092};\\\", \\\"{x:1257,y:820,t:1527793721107};\\\", \\\"{x:1260,y:819,t:1527793721124};\\\", \\\"{x:1266,y:818,t:1527793721141};\\\", \\\"{x:1272,y:816,t:1527793721157};\\\", \\\"{x:1274,y:816,t:1527793721174};\\\", \\\"{x:1278,y:816,t:1527793721191};\\\", \\\"{x:1290,y:818,t:1527793721208};\\\", \\\"{x:1293,y:819,t:1527793721224};\\\", \\\"{x:1301,y:819,t:1527793721241};\\\", \\\"{x:1307,y:819,t:1527793721258};\\\", \\\"{x:1312,y:820,t:1527793721273};\\\", \\\"{x:1316,y:820,t:1527793721291};\\\", \\\"{x:1324,y:821,t:1527793721308};\\\", \\\"{x:1330,y:821,t:1527793721323};\\\", \\\"{x:1335,y:823,t:1527793721341};\\\", \\\"{x:1336,y:823,t:1527793721358};\\\", \\\"{x:1337,y:823,t:1527793721380};\\\", \\\"{x:1337,y:824,t:1527793721390};\\\", \\\"{x:1339,y:825,t:1527793721408};\\\", \\\"{x:1342,y:825,t:1527793721424};\\\", \\\"{x:1344,y:825,t:1527793721441};\\\", \\\"{x:1346,y:827,t:1527793721533};\\\", \\\"{x:1346,y:828,t:1527793721557};\\\", \\\"{x:1348,y:830,t:1527793721597};\\\", \\\"{x:1349,y:831,t:1527793721940};\\\", \\\"{x:1351,y:838,t:1527793721958};\\\", \\\"{x:1351,y:841,t:1527793721975};\\\", \\\"{x:1353,y:847,t:1527793721991};\\\", \\\"{x:1353,y:850,t:1527793722008};\\\", \\\"{x:1353,y:855,t:1527793722025};\\\", \\\"{x:1353,y:857,t:1527793722041};\\\", \\\"{x:1353,y:859,t:1527793722092};\\\", \\\"{x:1353,y:860,t:1527793722124};\\\", \\\"{x:1353,y:862,t:1527793722142};\\\", \\\"{x:1353,y:863,t:1527793722180};\\\", \\\"{x:1353,y:865,t:1527793722252};\\\", \\\"{x:1353,y:868,t:1527793722260};\\\", \\\"{x:1353,y:871,t:1527793722275};\\\", \\\"{x:1355,y:877,t:1527793722292};\\\", \\\"{x:1355,y:878,t:1527793722316};\\\", \\\"{x:1355,y:879,t:1527793722332};\\\", \\\"{x:1355,y:880,t:1527793722468};\\\", \\\"{x:1355,y:881,t:1527793722476};\\\", \\\"{x:1355,y:884,t:1527793722492};\\\", \\\"{x:1355,y:886,t:1527793722508};\\\", \\\"{x:1355,y:887,t:1527793722676};\\\", \\\"{x:1355,y:889,t:1527793722828};\\\", \\\"{x:1355,y:890,t:1527793722842};\\\", \\\"{x:1355,y:893,t:1527793722858};\\\", \\\"{x:1356,y:895,t:1527793722875};\\\", \\\"{x:1356,y:896,t:1527793722892};\\\", \\\"{x:1356,y:900,t:1527793722909};\\\", \\\"{x:1356,y:903,t:1527793722926};\\\", \\\"{x:1355,y:907,t:1527793722942};\\\", \\\"{x:1355,y:908,t:1527793722964};\\\", \\\"{x:1354,y:908,t:1527793723012};\\\", \\\"{x:1351,y:908,t:1527793723133};\\\", \\\"{x:1351,y:906,t:1527793723141};\\\", \\\"{x:1347,y:903,t:1527793723159};\\\", \\\"{x:1347,y:898,t:1527793723176};\\\", \\\"{x:1346,y:892,t:1527793723192};\\\", \\\"{x:1346,y:889,t:1527793723209};\\\", \\\"{x:1346,y:888,t:1527793723226};\\\", \\\"{x:1347,y:890,t:1527793723516};\\\", \\\"{x:1347,y:891,t:1527793723526};\\\", \\\"{x:1347,y:893,t:1527793723543};\\\", \\\"{x:1348,y:894,t:1527793723668};\\\", \\\"{x:1350,y:898,t:1527793723780};\\\", \\\"{x:1350,y:899,t:1527793723804};\\\", \\\"{x:1350,y:900,t:1527793723812};\\\", \\\"{x:1351,y:901,t:1527793723826};\\\", \\\"{x:1352,y:902,t:1527793723844};\\\", \\\"{x:1352,y:904,t:1527793723859};\\\", \\\"{x:1352,y:902,t:1527793724140};\\\", \\\"{x:1352,y:901,t:1527793724164};\\\", \\\"{x:1352,y:898,t:1527793724244};\\\", \\\"{x:1352,y:897,t:1527793724868};\\\", \\\"{x:1352,y:895,t:1527793724877};\\\", \\\"{x:1346,y:891,t:1527793724895};\\\", \\\"{x:1340,y:885,t:1527793724910};\\\", \\\"{x:1325,y:876,t:1527793724927};\\\", \\\"{x:1293,y:863,t:1527793724944};\\\", \\\"{x:1232,y:845,t:1527793724960};\\\", \\\"{x:1166,y:840,t:1527793724977};\\\", \\\"{x:1036,y:804,t:1527793724993};\\\", \\\"{x:930,y:782,t:1527793725009};\\\", \\\"{x:846,y:755,t:1527793725027};\\\", \\\"{x:764,y:731,t:1527793725044};\\\", \\\"{x:729,y:721,t:1527793725060};\\\", \\\"{x:686,y:709,t:1527793725076};\\\", \\\"{x:666,y:702,t:1527793725093};\\\", \\\"{x:651,y:700,t:1527793725111};\\\", \\\"{x:640,y:696,t:1527793725127};\\\", \\\"{x:634,y:696,t:1527793725144};\\\", \\\"{x:633,y:696,t:1527793725161};\\\", \\\"{x:632,y:696,t:1527793725204};\\\", \\\"{x:631,y:696,t:1527793725211};\\\", \\\"{x:628,y:696,t:1527793725227};\\\", \\\"{x:622,y:696,t:1527793725243};\\\", \\\"{x:616,y:694,t:1527793725261};\\\", \\\"{x:612,y:692,t:1527793725277};\\\", \\\"{x:608,y:690,t:1527793725293};\\\", \\\"{x:607,y:689,t:1527793725340};\\\", \\\"{x:609,y:685,t:1527793725347};\\\", \\\"{x:615,y:679,t:1527793725361};\\\", \\\"{x:623,y:667,t:1527793725377};\\\", \\\"{x:638,y:658,t:1527793725394};\\\", \\\"{x:654,y:649,t:1527793725411};\\\", \\\"{x:677,y:640,t:1527793725427};\\\", \\\"{x:697,y:637,t:1527793725444};\\\", \\\"{x:698,y:637,t:1527793725455};\\\", \\\"{x:708,y:632,t:1527793725473};\\\", \\\"{x:721,y:628,t:1527793725490};\\\", \\\"{x:730,y:624,t:1527793725506};\\\", \\\"{x:731,y:623,t:1527793725523};\\\", \\\"{x:733,y:623,t:1527793725544};\\\", \\\"{x:735,y:620,t:1527793725561};\\\", \\\"{x:739,y:617,t:1527793725576};\\\", \\\"{x:747,y:613,t:1527793725594};\\\", \\\"{x:757,y:602,t:1527793725612};\\\", \\\"{x:767,y:594,t:1527793725627};\\\", \\\"{x:775,y:584,t:1527793725644};\\\", \\\"{x:785,y:575,t:1527793725661};\\\", \\\"{x:791,y:565,t:1527793725678};\\\", \\\"{x:794,y:562,t:1527793725694};\\\", \\\"{x:796,y:557,t:1527793725710};\\\", \\\"{x:799,y:552,t:1527793725727};\\\", \\\"{x:800,y:551,t:1527793725744};\\\", \\\"{x:801,y:548,t:1527793725761};\\\", \\\"{x:802,y:547,t:1527793725788};\\\", \\\"{x:798,y:549,t:1527793725956};\\\", \\\"{x:790,y:552,t:1527793725964};\\\", \\\"{x:779,y:556,t:1527793725977};\\\", \\\"{x:756,y:567,t:1527793725993};\\\", \\\"{x:733,y:573,t:1527793726011};\\\", \\\"{x:719,y:576,t:1527793726028};\\\", \\\"{x:650,y:578,t:1527793726044};\\\", \\\"{x:591,y:580,t:1527793726061};\\\", \\\"{x:523,y:576,t:1527793726078};\\\", \\\"{x:491,y:574,t:1527793726094};\\\", \\\"{x:471,y:572,t:1527793726111};\\\", \\\"{x:465,y:572,t:1527793726127};\\\", \\\"{x:465,y:575,t:1527793726144};\\\", \\\"{x:462,y:575,t:1527793726164};\\\", \\\"{x:455,y:575,t:1527793726177};\\\", \\\"{x:447,y:575,t:1527793726194};\\\", \\\"{x:429,y:575,t:1527793726211};\\\", \\\"{x:412,y:573,t:1527793726228};\\\", \\\"{x:395,y:573,t:1527793726244};\\\", \\\"{x:384,y:573,t:1527793726261};\\\", \\\"{x:379,y:574,t:1527793726278};\\\", \\\"{x:377,y:574,t:1527793726295};\\\", \\\"{x:372,y:577,t:1527793726311};\\\", \\\"{x:364,y:580,t:1527793726328};\\\", \\\"{x:359,y:583,t:1527793726346};\\\", \\\"{x:354,y:585,t:1527793726361};\\\", \\\"{x:350,y:586,t:1527793726378};\\\", \\\"{x:347,y:587,t:1527793726395};\\\", \\\"{x:346,y:587,t:1527793726412};\\\", \\\"{x:340,y:587,t:1527793726428};\\\", \\\"{x:322,y:589,t:1527793726445};\\\", \\\"{x:261,y:578,t:1527793726462};\\\", \\\"{x:230,y:572,t:1527793726478};\\\", \\\"{x:226,y:572,t:1527793726495};\\\", \\\"{x:223,y:572,t:1527793726511};\\\", \\\"{x:221,y:570,t:1527793726724};\\\", \\\"{x:219,y:570,t:1527793726731};\\\", \\\"{x:213,y:569,t:1527793726745};\\\", \\\"{x:208,y:569,t:1527793726762};\\\", \\\"{x:205,y:569,t:1527793726778};\\\", \\\"{x:202,y:569,t:1527793726795};\\\", \\\"{x:196,y:569,t:1527793726812};\\\", \\\"{x:188,y:569,t:1527793726829};\\\", \\\"{x:176,y:569,t:1527793726846};\\\", \\\"{x:166,y:568,t:1527793726862};\\\", \\\"{x:154,y:565,t:1527793726879};\\\", \\\"{x:144,y:565,t:1527793726896};\\\", \\\"{x:143,y:565,t:1527793726912};\\\", \\\"{x:144,y:565,t:1527793727252};\\\", \\\"{x:147,y:564,t:1527793727263};\\\", \\\"{x:149,y:562,t:1527793727281};\\\", \\\"{x:151,y:562,t:1527793727297};\\\", \\\"{x:153,y:562,t:1527793727313};\\\", \\\"{x:153,y:561,t:1527793727330};\\\", \\\"{x:155,y:561,t:1527793727346};\\\", \\\"{x:159,y:561,t:1527793727364};\\\", \\\"{x:165,y:561,t:1527793727380};\\\", \\\"{x:167,y:562,t:1527793727396};\\\", \\\"{x:168,y:562,t:1527793727412};\\\", \\\"{x:169,y:562,t:1527793727430};\\\", \\\"{x:170,y:562,t:1527793727447};\\\", \\\"{x:172,y:563,t:1527793727476};\\\", \\\"{x:173,y:563,t:1527793727483};\\\", \\\"{x:174,y:563,t:1527793727497};\\\", \\\"{x:176,y:563,t:1527793727513};\\\", \\\"{x:178,y:563,t:1527793727530};\\\", \\\"{x:180,y:563,t:1527793727547};\\\", \\\"{x:182,y:563,t:1527793727628};\\\", \\\"{x:184,y:563,t:1527793727636};\\\", \\\"{x:185,y:563,t:1527793727651};\\\", \\\"{x:186,y:563,t:1527793727664};\\\", \\\"{x:191,y:562,t:1527793727682};\\\", \\\"{x:192,y:561,t:1527793727697};\\\", \\\"{x:193,y:560,t:1527793727714};\\\", \\\"{x:194,y:559,t:1527793727731};\\\", \\\"{x:201,y:555,t:1527793727748};\\\", \\\"{x:208,y:553,t:1527793727764};\\\", \\\"{x:212,y:553,t:1527793727781};\\\", \\\"{x:213,y:553,t:1527793727797};\\\", \\\"{x:215,y:553,t:1527793727814};\\\", \\\"{x:216,y:553,t:1527793729364};\\\", \\\"{x:222,y:556,t:1527793729372};\\\", \\\"{x:226,y:562,t:1527793729385};\\\", \\\"{x:235,y:572,t:1527793729401};\\\", \\\"{x:249,y:585,t:1527793729418};\\\", \\\"{x:263,y:596,t:1527793729435};\\\", \\\"{x:275,y:606,t:1527793729445};\\\", \\\"{x:288,y:612,t:1527793729462};\\\", \\\"{x:306,y:624,t:1527793729480};\\\", \\\"{x:329,y:648,t:1527793729497};\\\", \\\"{x:347,y:656,t:1527793729514};\\\", \\\"{x:365,y:670,t:1527793729530};\\\", \\\"{x:372,y:677,t:1527793729547};\\\", \\\"{x:376,y:681,t:1527793729563};\\\", \\\"{x:377,y:683,t:1527793729580};\\\", \\\"{x:379,y:686,t:1527793729597};\\\", \\\"{x:380,y:687,t:1527793729615};\\\", \\\"{x:381,y:688,t:1527793729630};\\\", \\\"{x:381,y:689,t:1527793729647};\\\", \\\"{x:384,y:690,t:1527793729664};\\\", \\\"{x:389,y:693,t:1527793729680};\\\", \\\"{x:396,y:697,t:1527793729697};\\\", \\\"{x:403,y:703,t:1527793729714};\\\", \\\"{x:425,y:710,t:1527793729731};\\\", \\\"{x:446,y:718,t:1527793729747};\\\", \\\"{x:470,y:724,t:1527793729764};\\\", \\\"{x:482,y:724,t:1527793729780};\\\", \\\"{x:488,y:724,t:1527793729797};\\\", \\\"{x:490,y:724,t:1527793729814};\\\", \\\"{x:491,y:722,t:1527793729891};\\\", \\\"{x:490,y:719,t:1527793729900};\\\", \\\"{x:479,y:713,t:1527793729914};\\\", \\\"{x:467,y:708,t:1527793729931};\\\", \\\"{x:331,y:659,t:1527793729948};\\\", \\\"{x:235,y:638,t:1527793729965};\\\", \\\"{x:142,y:618,t:1527793729981};\\\", \\\"{x:96,y:603,t:1527793729997};\\\", \\\"{x:80,y:595,t:1527793730014};\\\", \\\"{x:76,y:591,t:1527793730030};\\\", \\\"{x:73,y:588,t:1527793730048};\\\", \\\"{x:73,y:587,t:1527793730139};\\\", \\\"{x:73,y:584,t:1527793730147};\\\", \\\"{x:74,y:578,t:1527793730164};\\\", \\\"{x:83,y:572,t:1527793730182};\\\", \\\"{x:88,y:565,t:1527793730198};\\\", \\\"{x:95,y:563,t:1527793730214};\\\", \\\"{x:105,y:559,t:1527793730231};\\\", \\\"{x:109,y:557,t:1527793730248};\\\", \\\"{x:110,y:555,t:1527793730264};\\\", \\\"{x:121,y:555,t:1527793730281};\\\", \\\"{x:132,y:555,t:1527793730298};\\\", \\\"{x:147,y:559,t:1527793730315};\\\", \\\"{x:162,y:568,t:1527793730331};\\\", \\\"{x:169,y:576,t:1527793730349};\\\", \\\"{x:168,y:575,t:1527793730581};\\\", \\\"{x:166,y:573,t:1527793730590};\\\", \\\"{x:166,y:572,t:1527793730598};\\\", \\\"{x:165,y:572,t:1527793730615};\\\", \\\"{x:165,y:571,t:1527793730631};\\\", \\\"{x:164,y:571,t:1527793730716};\\\", \\\"{x:163,y:569,t:1527793730732};\\\", \\\"{x:163,y:565,t:1527793730747};\\\", \\\"{x:163,y:563,t:1527793730765};\\\", \\\"{x:162,y:561,t:1527793730781};\\\", \\\"{x:169,y:564,t:1527793731036};\\\", \\\"{x:198,y:578,t:1527793731049};\\\", \\\"{x:283,y:599,t:1527793731066};\\\", \\\"{x:333,y:621,t:1527793731082};\\\", \\\"{x:343,y:625,t:1527793731098};\\\", \\\"{x:350,y:625,t:1527793731115};\\\", \\\"{x:386,y:632,t:1527793731132};\\\", \\\"{x:392,y:634,t:1527793731148};\\\", \\\"{x:402,y:637,t:1527793731166};\\\", \\\"{x:405,y:638,t:1527793731182};\\\", \\\"{x:409,y:640,t:1527793731284};\\\", \\\"{x:410,y:644,t:1527793731299};\\\", \\\"{x:412,y:657,t:1527793731317};\\\", \\\"{x:415,y:667,t:1527793731331};\\\", \\\"{x:415,y:669,t:1527793731348};\\\", \\\"{x:415,y:670,t:1527793731365};\\\", \\\"{x:415,y:672,t:1527793731404};\\\", \\\"{x:419,y:675,t:1527793731415};\\\", \\\"{x:434,y:685,t:1527793731432};\\\", \\\"{x:446,y:692,t:1527793731448};\\\", \\\"{x:455,y:696,t:1527793731465};\\\", \\\"{x:461,y:700,t:1527793731482};\\\", \\\"{x:465,y:700,t:1527793731499};\\\", \\\"{x:471,y:700,t:1527793731515};\\\", \\\"{x:474,y:700,t:1527793731532};\\\", \\\"{x:475,y:700,t:1527793731644};\\\", \\\"{x:476,y:700,t:1527793731676};\\\", \\\"{x:478,y:701,t:1527793731692};\\\", \\\"{x:485,y:701,t:1527793731699};\\\", \\\"{x:486,y:701,t:1527793731715};\\\", \\\"{x:487,y:701,t:1527793731732};\\\", \\\"{x:489,y:699,t:1527793732084};\\\", \\\"{x:489,y:698,t:1527793732100};\\\", \\\"{x:498,y:692,t:1527793732116};\\\", \\\"{x:505,y:683,t:1527793732132};\\\", \\\"{x:508,y:679,t:1527793732150};\\\", \\\"{x:516,y:671,t:1527793732167};\\\", \\\"{x:518,y:664,t:1527793732182};\\\", \\\"{x:523,y:653,t:1527793732200};\\\", \\\"{x:541,y:621,t:1527793732217};\\\", \\\"{x:557,y:599,t:1527793732232};\\\", \\\"{x:572,y:571,t:1527793732249};\\\", \\\"{x:595,y:546,t:1527793732266};\\\", \\\"{x:608,y:535,t:1527793732282};\\\", \\\"{x:617,y:524,t:1527793732300};\\\", \\\"{x:623,y:516,t:1527793732316};\\\" ] }, { \\\"rt\\\": 101445, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 360354, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -K -C -C -C -U -U -B -U -U -U -K -K -O -11 AM-A -A -O -O -O -O -X -X -K -B -B -G -G -E -E -U -U -01 PM-F -03 PM-02 PM-01 PM-A -A -I -O -O -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:624,y:516,t:1527793738189};\\\", \\\"{x:625,y:516,t:1527793738261};\\\", \\\"{x:626,y:516,t:1527793738275};\\\", \\\"{x:645,y:520,t:1527793738293};\\\", \\\"{x:721,y:535,t:1527793738309};\\\", \\\"{x:848,y:567,t:1527793738328};\\\", \\\"{x:995,y:593,t:1527793738342};\\\", \\\"{x:1115,y:614,t:1527793738358};\\\", \\\"{x:1164,y:623,t:1527793738368};\\\", \\\"{x:1287,y:646,t:1527793738384};\\\", \\\"{x:1371,y:662,t:1527793738401};\\\", \\\"{x:1385,y:663,t:1527793738418};\\\", \\\"{x:1425,y:675,t:1527793738434};\\\", \\\"{x:1450,y:685,t:1527793738452};\\\", \\\"{x:1480,y:692,t:1527793738468};\\\", \\\"{x:1494,y:698,t:1527793738485};\\\", \\\"{x:1506,y:705,t:1527793738501};\\\", \\\"{x:1524,y:718,t:1527793738518};\\\", \\\"{x:1528,y:720,t:1527793738535};\\\", \\\"{x:1539,y:727,t:1527793738552};\\\", \\\"{x:1552,y:742,t:1527793738567};\\\", \\\"{x:1572,y:766,t:1527793738585};\\\", \\\"{x:1580,y:773,t:1527793738602};\\\", \\\"{x:1580,y:774,t:1527793738619};\\\", \\\"{x:1581,y:778,t:1527793738637};\\\", \\\"{x:1581,y:783,t:1527793738652};\\\", \\\"{x:1578,y:807,t:1527793738668};\\\", \\\"{x:1577,y:833,t:1527793738685};\\\", \\\"{x:1577,y:853,t:1527793738702};\\\", \\\"{x:1577,y:870,t:1527793738719};\\\", \\\"{x:1576,y:879,t:1527793738735};\\\", \\\"{x:1574,y:881,t:1527793738752};\\\", \\\"{x:1570,y:888,t:1527793738769};\\\", \\\"{x:1567,y:893,t:1527793738785};\\\", \\\"{x:1566,y:894,t:1527793738821};\\\", \\\"{x:1566,y:896,t:1527793738835};\\\", \\\"{x:1569,y:896,t:1527793738852};\\\", \\\"{x:1572,y:899,t:1527793738869};\\\", \\\"{x:1572,y:901,t:1527793738893};\\\", \\\"{x:1572,y:902,t:1527793738908};\\\", \\\"{x:1572,y:903,t:1527793738925};\\\", \\\"{x:1572,y:904,t:1527793738935};\\\", \\\"{x:1572,y:905,t:1527793738952};\\\", \\\"{x:1572,y:907,t:1527793738969};\\\", \\\"{x:1574,y:908,t:1527793738985};\\\", \\\"{x:1576,y:910,t:1527793739001};\\\", \\\"{x:1579,y:913,t:1527793739019};\\\", \\\"{x:1579,y:916,t:1527793739035};\\\", \\\"{x:1584,y:927,t:1527793739051};\\\", \\\"{x:1588,y:936,t:1527793739068};\\\", \\\"{x:1590,y:940,t:1527793739084};\\\", \\\"{x:1592,y:943,t:1527793739101};\\\", \\\"{x:1594,y:947,t:1527793739119};\\\", \\\"{x:1595,y:949,t:1527793739134};\\\", \\\"{x:1597,y:951,t:1527793739151};\\\", \\\"{x:1599,y:952,t:1527793739212};\\\", \\\"{x:1599,y:953,t:1527793739219};\\\", \\\"{x:1600,y:954,t:1527793739234};\\\", \\\"{x:1600,y:955,t:1527793739251};\\\", \\\"{x:1601,y:955,t:1527793739269};\\\", \\\"{x:1601,y:956,t:1527793739381};\\\", \\\"{x:1602,y:957,t:1527793739493};\\\", \\\"{x:1603,y:959,t:1527793739557};\\\", \\\"{x:1605,y:959,t:1527793739701};\\\", \\\"{x:1606,y:959,t:1527793739805};\\\", \\\"{x:1607,y:959,t:1527793739821};\\\", \\\"{x:1608,y:959,t:1527793739837};\\\", \\\"{x:1609,y:959,t:1527793739852};\\\", \\\"{x:1613,y:959,t:1527793739868};\\\", \\\"{x:1614,y:958,t:1527793739965};\\\", \\\"{x:1613,y:958,t:1527793750253};\\\", \\\"{x:1612,y:962,t:1527793750261};\\\", \\\"{x:1610,y:962,t:1527793750270};\\\", \\\"{x:1609,y:962,t:1527793750365};\\\", \\\"{x:1609,y:961,t:1527793750837};\\\", \\\"{x:1609,y:958,t:1527793750855};\\\", \\\"{x:1609,y:956,t:1527793750871};\\\", \\\"{x:1606,y:950,t:1527793750888};\\\", \\\"{x:1605,y:944,t:1527793750904};\\\", \\\"{x:1605,y:941,t:1527793750921};\\\", \\\"{x:1607,y:934,t:1527793750938};\\\", \\\"{x:1610,y:929,t:1527793750954};\\\", \\\"{x:1610,y:916,t:1527793750971};\\\", \\\"{x:1610,y:896,t:1527793750987};\\\", \\\"{x:1610,y:868,t:1527793751004};\\\", \\\"{x:1610,y:850,t:1527793751021};\\\", \\\"{x:1605,y:833,t:1527793751038};\\\", \\\"{x:1603,y:817,t:1527793751054};\\\", \\\"{x:1601,y:799,t:1527793751072};\\\", \\\"{x:1600,y:792,t:1527793751087};\\\", \\\"{x:1599,y:785,t:1527793751104};\\\", \\\"{x:1598,y:776,t:1527793751122};\\\", \\\"{x:1596,y:770,t:1527793751138};\\\", \\\"{x:1595,y:762,t:1527793751154};\\\", \\\"{x:1591,y:743,t:1527793751171};\\\", \\\"{x:1588,y:733,t:1527793751188};\\\", \\\"{x:1586,y:729,t:1527793751205};\\\", \\\"{x:1586,y:728,t:1527793751221};\\\", \\\"{x:1585,y:723,t:1527793751238};\\\", \\\"{x:1581,y:712,t:1527793751254};\\\", \\\"{x:1577,y:704,t:1527793751271};\\\", \\\"{x:1573,y:692,t:1527793751287};\\\", \\\"{x:1573,y:679,t:1527793751304};\\\", \\\"{x:1573,y:676,t:1527793751321};\\\", \\\"{x:1573,y:672,t:1527793751338};\\\", \\\"{x:1573,y:667,t:1527793751355};\\\", \\\"{x:1574,y:663,t:1527793751371};\\\", \\\"{x:1574,y:658,t:1527793751388};\\\", \\\"{x:1576,y:653,t:1527793751405};\\\", \\\"{x:1576,y:650,t:1527793751422};\\\", \\\"{x:1576,y:648,t:1527793751438};\\\", \\\"{x:1576,y:646,t:1527793751454};\\\", \\\"{x:1576,y:644,t:1527793751471};\\\", \\\"{x:1576,y:643,t:1527793751487};\\\", \\\"{x:1576,y:641,t:1527793751517};\\\", \\\"{x:1576,y:639,t:1527793751524};\\\", \\\"{x:1577,y:638,t:1527793751540};\\\", \\\"{x:1577,y:637,t:1527793751555};\\\", \\\"{x:1577,y:635,t:1527793751572};\\\", \\\"{x:1577,y:633,t:1527793751587};\\\", \\\"{x:1577,y:632,t:1527793751636};\\\", \\\"{x:1577,y:631,t:1527793751660};\\\", \\\"{x:1578,y:630,t:1527793751701};\\\", \\\"{x:1580,y:627,t:1527793751717};\\\", \\\"{x:1580,y:626,t:1527793751733};\\\", \\\"{x:1580,y:625,t:1527793751740};\\\", \\\"{x:1580,y:624,t:1527793751756};\\\", \\\"{x:1581,y:624,t:1527793751772};\\\", \\\"{x:1581,y:622,t:1527793752397};\\\", \\\"{x:1581,y:619,t:1527793752405};\\\", \\\"{x:1597,y:594,t:1527793752421};\\\", \\\"{x:1610,y:566,t:1527793752441};\\\", \\\"{x:1622,y:546,t:1527793752454};\\\", \\\"{x:1632,y:528,t:1527793752471};\\\", \\\"{x:1634,y:520,t:1527793752488};\\\", \\\"{x:1634,y:513,t:1527793752504};\\\", \\\"{x:1634,y:508,t:1527793752521};\\\", \\\"{x:1632,y:503,t:1527793752537};\\\", \\\"{x:1630,y:495,t:1527793752554};\\\", \\\"{x:1627,y:487,t:1527793752571};\\\", \\\"{x:1621,y:480,t:1527793752587};\\\", \\\"{x:1617,y:473,t:1527793752604};\\\", \\\"{x:1614,y:470,t:1527793752621};\\\", \\\"{x:1608,y:466,t:1527793752638};\\\", \\\"{x:1604,y:463,t:1527793752654};\\\", \\\"{x:1600,y:459,t:1527793752671};\\\", \\\"{x:1597,y:456,t:1527793752689};\\\", \\\"{x:1596,y:450,t:1527793752705};\\\", \\\"{x:1591,y:439,t:1527793752721};\\\", \\\"{x:1590,y:434,t:1527793752737};\\\", \\\"{x:1587,y:428,t:1527793752754};\\\", \\\"{x:1583,y:417,t:1527793752771};\\\", \\\"{x:1582,y:402,t:1527793752788};\\\", \\\"{x:1581,y:394,t:1527793752804};\\\", \\\"{x:1581,y:387,t:1527793752822};\\\", \\\"{x:1583,y:379,t:1527793752838};\\\", \\\"{x:1584,y:376,t:1527793752854};\\\", \\\"{x:1586,y:382,t:1527793752973};\\\", \\\"{x:1587,y:398,t:1527793752988};\\\", \\\"{x:1589,y:416,t:1527793753004};\\\", \\\"{x:1589,y:429,t:1527793753021};\\\", \\\"{x:1590,y:444,t:1527793753038};\\\", \\\"{x:1592,y:454,t:1527793753055};\\\", \\\"{x:1593,y:477,t:1527793753072};\\\", \\\"{x:1591,y:493,t:1527793753088};\\\", \\\"{x:1578,y:517,t:1527793753104};\\\", \\\"{x:1572,y:539,t:1527793753121};\\\", \\\"{x:1568,y:554,t:1527793753138};\\\", \\\"{x:1563,y:562,t:1527793753154};\\\", \\\"{x:1554,y:576,t:1527793753171};\\\", \\\"{x:1539,y:604,t:1527793753187};\\\", \\\"{x:1530,y:617,t:1527793753204};\\\", \\\"{x:1523,y:621,t:1527793753221};\\\", \\\"{x:1519,y:627,t:1527793753238};\\\", \\\"{x:1509,y:636,t:1527793753254};\\\", \\\"{x:1501,y:650,t:1527793753271};\\\", \\\"{x:1485,y:664,t:1527793753288};\\\", \\\"{x:1464,y:679,t:1527793753305};\\\", \\\"{x:1460,y:682,t:1527793753321};\\\", \\\"{x:1449,y:689,t:1527793753338};\\\", \\\"{x:1435,y:700,t:1527793753354};\\\", \\\"{x:1432,y:709,t:1527793753371};\\\", \\\"{x:1432,y:715,t:1527793753396};\\\", \\\"{x:1427,y:726,t:1527793753404};\\\", \\\"{x:1416,y:738,t:1527793753421};\\\", \\\"{x:1414,y:754,t:1527793753439};\\\", \\\"{x:1413,y:764,t:1527793753454};\\\", \\\"{x:1410,y:767,t:1527793753472};\\\", \\\"{x:1406,y:772,t:1527793753489};\\\", \\\"{x:1405,y:775,t:1527793753505};\\\", \\\"{x:1400,y:783,t:1527793753521};\\\", \\\"{x:1399,y:784,t:1527793753539};\\\", \\\"{x:1397,y:784,t:1527793753556};\\\", \\\"{x:1394,y:789,t:1527793753572};\\\", \\\"{x:1387,y:797,t:1527793753588};\\\", \\\"{x:1383,y:802,t:1527793753605};\\\", \\\"{x:1381,y:804,t:1527793753621};\\\", \\\"{x:1378,y:804,t:1527793753638};\\\", \\\"{x:1378,y:807,t:1527793753700};\\\", \\\"{x:1377,y:807,t:1527793753708};\\\", \\\"{x:1376,y:808,t:1527793753721};\\\", \\\"{x:1371,y:809,t:1527793753739};\\\", \\\"{x:1362,y:813,t:1527793753754};\\\", \\\"{x:1359,y:813,t:1527793753772};\\\", \\\"{x:1352,y:813,t:1527793753788};\\\", \\\"{x:1341,y:813,t:1527793753804};\\\", \\\"{x:1326,y:810,t:1527793753821};\\\", \\\"{x:1323,y:809,t:1527793753838};\\\", \\\"{x:1316,y:805,t:1527793753854};\\\", \\\"{x:1309,y:802,t:1527793753871};\\\", \\\"{x:1307,y:800,t:1527793753889};\\\", \\\"{x:1306,y:800,t:1527793753916};\\\", \\\"{x:1306,y:799,t:1527793754028};\\\", \\\"{x:1303,y:799,t:1527793754052};\\\", \\\"{x:1301,y:799,t:1527793754060};\\\", \\\"{x:1299,y:799,t:1527793754076};\\\", \\\"{x:1296,y:799,t:1527793754088};\\\", \\\"{x:1288,y:804,t:1527793754105};\\\", \\\"{x:1281,y:808,t:1527793754121};\\\", \\\"{x:1274,y:813,t:1527793754138};\\\", \\\"{x:1269,y:817,t:1527793754154};\\\", \\\"{x:1262,y:820,t:1527793754171};\\\", \\\"{x:1249,y:828,t:1527793754188};\\\", \\\"{x:1244,y:831,t:1527793754204};\\\", \\\"{x:1240,y:833,t:1527793754220};\\\", \\\"{x:1235,y:835,t:1527793754238};\\\", \\\"{x:1229,y:839,t:1527793754255};\\\", \\\"{x:1224,y:839,t:1527793754271};\\\", \\\"{x:1221,y:841,t:1527793754288};\\\", \\\"{x:1218,y:842,t:1527793754323};\\\", \\\"{x:1216,y:842,t:1527793754412};\\\", \\\"{x:1215,y:842,t:1527793754421};\\\", \\\"{x:1215,y:841,t:1527793754492};\\\", \\\"{x:1215,y:839,t:1527793754523};\\\", \\\"{x:1215,y:838,t:1527793754596};\\\", \\\"{x:1215,y:836,t:1527793754605};\\\", \\\"{x:1215,y:834,t:1527793754635};\\\", \\\"{x:1216,y:834,t:1527793754660};\\\", \\\"{x:1217,y:832,t:1527793754671};\\\", \\\"{x:1218,y:831,t:1527793754688};\\\", \\\"{x:1218,y:830,t:1527793754804};\\\", \\\"{x:1219,y:829,t:1527793754844};\\\", \\\"{x:1218,y:828,t:1527793754981};\\\", \\\"{x:1216,y:826,t:1527793754988};\\\", \\\"{x:1215,y:825,t:1527793755036};\\\", \\\"{x:1215,y:824,t:1527793755197};\\\", \\\"{x:1215,y:823,t:1527793755206};\\\", \\\"{x:1216,y:822,t:1527793755221};\\\", \\\"{x:1220,y:822,t:1527793755239};\\\", \\\"{x:1221,y:822,t:1527793755256};\\\", \\\"{x:1222,y:822,t:1527793755284};\\\", \\\"{x:1224,y:822,t:1527793755364};\\\", \\\"{x:1227,y:822,t:1527793755372};\\\", \\\"{x:1234,y:822,t:1527793755388};\\\", \\\"{x:1239,y:821,t:1527793755405};\\\", \\\"{x:1240,y:821,t:1527793755421};\\\", \\\"{x:1241,y:821,t:1527793755508};\\\", \\\"{x:1242,y:821,t:1527793755668};\\\", \\\"{x:1240,y:821,t:1527793755733};\\\", \\\"{x:1236,y:822,t:1527793755741};\\\", \\\"{x:1229,y:823,t:1527793755756};\\\", \\\"{x:1228,y:823,t:1527793755771};\\\", \\\"{x:1227,y:824,t:1527793755789};\\\", \\\"{x:1227,y:825,t:1527793755836};\\\", \\\"{x:1226,y:826,t:1527793755973};\\\", \\\"{x:1221,y:828,t:1527793755988};\\\", \\\"{x:1217,y:830,t:1527793756006};\\\", \\\"{x:1214,y:831,t:1527793756021};\\\", \\\"{x:1211,y:833,t:1527793756039};\\\", \\\"{x:1212,y:833,t:1527793756524};\\\", \\\"{x:1219,y:833,t:1527793756539};\\\", \\\"{x:1256,y:834,t:1527793756557};\\\", \\\"{x:1320,y:834,t:1527793756572};\\\", \\\"{x:1377,y:837,t:1527793756589};\\\", \\\"{x:1432,y:850,t:1527793756605};\\\", \\\"{x:1456,y:854,t:1527793756621};\\\", \\\"{x:1460,y:856,t:1527793756638};\\\", \\\"{x:1470,y:859,t:1527793756654};\\\", \\\"{x:1474,y:859,t:1527793756672};\\\", \\\"{x:1477,y:861,t:1527793756688};\\\", \\\"{x:1480,y:862,t:1527793756705};\\\", \\\"{x:1481,y:863,t:1527793756723};\\\", \\\"{x:1481,y:864,t:1527793756763};\\\", \\\"{x:1481,y:865,t:1527793756795};\\\", \\\"{x:1481,y:866,t:1527793756877};\\\", \\\"{x:1482,y:866,t:1527793756889};\\\", \\\"{x:1483,y:866,t:1527793756916};\\\", \\\"{x:1486,y:863,t:1527793756923};\\\", \\\"{x:1486,y:861,t:1527793756938};\\\", \\\"{x:1490,y:843,t:1527793756955};\\\", \\\"{x:1495,y:833,t:1527793756971};\\\", \\\"{x:1497,y:824,t:1527793756989};\\\", \\\"{x:1497,y:817,t:1527793757005};\\\", \\\"{x:1497,y:816,t:1527793757022};\\\", \\\"{x:1497,y:812,t:1527793757038};\\\", \\\"{x:1497,y:810,t:1527793757055};\\\", \\\"{x:1497,y:809,t:1527793757132};\\\", \\\"{x:1496,y:809,t:1527793757172};\\\", \\\"{x:1495,y:814,t:1527793757189};\\\", \\\"{x:1492,y:817,t:1527793757205};\\\", \\\"{x:1491,y:818,t:1527793757228};\\\", \\\"{x:1490,y:818,t:1527793757260};\\\", \\\"{x:1489,y:819,t:1527793757317};\\\", \\\"{x:1488,y:821,t:1527793757668};\\\", \\\"{x:1487,y:822,t:1527793757676};\\\", \\\"{x:1482,y:826,t:1527793757689};\\\", \\\"{x:1478,y:829,t:1527793757706};\\\", \\\"{x:1475,y:835,t:1527793757724};\\\", \\\"{x:1475,y:836,t:1527793757740};\\\", \\\"{x:1477,y:836,t:1527793758325};\\\", \\\"{x:1477,y:835,t:1527793758381};\\\", \\\"{x:1477,y:834,t:1527793758419};\\\", \\\"{x:1477,y:833,t:1527793758556};\\\", \\\"{x:1478,y:833,t:1527793758572};\\\", \\\"{x:1479,y:832,t:1527793758603};\\\", \\\"{x:1479,y:831,t:1527793758619};\\\", \\\"{x:1471,y:828,t:1527793761927};\\\", \\\"{x:1335,y:773,t:1527793761941};\\\", \\\"{x:1141,y:737,t:1527793761958};\\\", \\\"{x:971,y:705,t:1527793761975};\\\", \\\"{x:873,y:684,t:1527793761991};\\\", \\\"{x:784,y:671,t:1527793762008};\\\", \\\"{x:774,y:670,t:1527793762023};\\\", \\\"{x:741,y:661,t:1527793762041};\\\", \\\"{x:739,y:660,t:1527793762058};\\\", \\\"{x:738,y:659,t:1527793762074};\\\", \\\"{x:737,y:659,t:1527793762091};\\\", \\\"{x:736,y:659,t:1527793762141};\\\", \\\"{x:732,y:656,t:1527793762157};\\\", \\\"{x:727,y:652,t:1527793762174};\\\", \\\"{x:720,y:647,t:1527793762193};\\\", \\\"{x:716,y:642,t:1527793762207};\\\", \\\"{x:705,y:637,t:1527793762223};\\\", \\\"{x:697,y:633,t:1527793762240};\\\", \\\"{x:695,y:633,t:1527793762257};\\\", \\\"{x:684,y:630,t:1527793762274};\\\", \\\"{x:679,y:626,t:1527793762292};\\\", \\\"{x:672,y:624,t:1527793762307};\\\", \\\"{x:663,y:619,t:1527793762324};\\\", \\\"{x:662,y:619,t:1527793762372};\\\", \\\"{x:660,y:617,t:1527793762396};\\\", \\\"{x:659,y:617,t:1527793762407};\\\", \\\"{x:658,y:617,t:1527793762428};\\\", \\\"{x:657,y:616,t:1527793762461};\\\", \\\"{x:652,y:614,t:1527793762474};\\\", \\\"{x:649,y:613,t:1527793762501};\\\", \\\"{x:646,y:610,t:1527793762510};\\\", \\\"{x:643,y:609,t:1527793762523};\\\", \\\"{x:640,y:609,t:1527793762541};\\\", \\\"{x:639,y:609,t:1527793762558};\\\", \\\"{x:636,y:607,t:1527793762644};\\\", \\\"{x:634,y:605,t:1527793762828};\\\", \\\"{x:633,y:605,t:1527793762852};\\\", \\\"{x:631,y:604,t:1527793762869};\\\", \\\"{x:628,y:603,t:1527793762877};\\\", \\\"{x:627,y:602,t:1527793762891};\\\", \\\"{x:626,y:602,t:1527793762908};\\\", \\\"{x:625,y:601,t:1527793762948};\\\", \\\"{x:624,y:600,t:1527793762965};\\\", \\\"{x:623,y:600,t:1527793762976};\\\", \\\"{x:623,y:599,t:1527793764045};\\\", \\\"{x:625,y:599,t:1527793764058};\\\", \\\"{x:633,y:599,t:1527793764076};\\\", \\\"{x:654,y:599,t:1527793764094};\\\", \\\"{x:698,y:600,t:1527793764109};\\\", \\\"{x:806,y:600,t:1527793764127};\\\", \\\"{x:870,y:599,t:1527793764142};\\\", \\\"{x:1034,y:602,t:1527793764160};\\\", \\\"{x:1181,y:599,t:1527793764175};\\\", \\\"{x:1269,y:593,t:1527793764192};\\\", \\\"{x:1352,y:593,t:1527793764209};\\\", \\\"{x:1453,y:589,t:1527793764225};\\\", \\\"{x:1489,y:589,t:1527793764243};\\\", \\\"{x:1505,y:595,t:1527793764260};\\\", \\\"{x:1586,y:601,t:1527793764276};\\\", \\\"{x:1645,y:610,t:1527793764292};\\\", \\\"{x:1675,y:617,t:1527793764310};\\\", \\\"{x:1704,y:623,t:1527793764325};\\\", \\\"{x:1726,y:628,t:1527793764343};\\\", \\\"{x:1736,y:635,t:1527793764359};\\\", \\\"{x:1742,y:639,t:1527793764375};\\\", \\\"{x:1759,y:652,t:1527793764392};\\\", \\\"{x:1773,y:672,t:1527793764409};\\\", \\\"{x:1779,y:687,t:1527793764425};\\\", \\\"{x:1783,y:689,t:1527793764442};\\\", \\\"{x:1795,y:706,t:1527793764460};\\\", \\\"{x:1807,y:735,t:1527793764476};\\\", \\\"{x:1811,y:760,t:1527793764492};\\\", \\\"{x:1811,y:765,t:1527793764510};\\\", \\\"{x:1805,y:773,t:1527793764525};\\\", \\\"{x:1795,y:778,t:1527793764543};\\\", \\\"{x:1780,y:791,t:1527793764560};\\\", \\\"{x:1751,y:804,t:1527793764577};\\\", \\\"{x:1726,y:820,t:1527793764593};\\\", \\\"{x:1703,y:828,t:1527793764609};\\\", \\\"{x:1691,y:833,t:1527793764627};\\\", \\\"{x:1678,y:834,t:1527793764643};\\\", \\\"{x:1673,y:835,t:1527793764660};\\\", \\\"{x:1670,y:835,t:1527793764677};\\\", \\\"{x:1666,y:837,t:1527793764693};\\\", \\\"{x:1658,y:837,t:1527793764710};\\\", \\\"{x:1645,y:837,t:1527793764727};\\\", \\\"{x:1628,y:837,t:1527793764743};\\\", \\\"{x:1618,y:837,t:1527793764760};\\\", \\\"{x:1607,y:833,t:1527793764777};\\\", \\\"{x:1601,y:830,t:1527793764792};\\\", \\\"{x:1591,y:827,t:1527793764810};\\\", \\\"{x:1578,y:826,t:1527793764827};\\\", \\\"{x:1571,y:824,t:1527793764843};\\\", \\\"{x:1558,y:824,t:1527793764859};\\\", \\\"{x:1550,y:820,t:1527793764876};\\\", \\\"{x:1547,y:819,t:1527793764893};\\\", \\\"{x:1540,y:819,t:1527793764909};\\\", \\\"{x:1538,y:819,t:1527793764926};\\\", \\\"{x:1536,y:819,t:1527793764943};\\\", \\\"{x:1534,y:819,t:1527793764965};\\\", \\\"{x:1532,y:819,t:1527793764997};\\\", \\\"{x:1528,y:821,t:1527793765013};\\\", \\\"{x:1526,y:822,t:1527793765028};\\\", \\\"{x:1524,y:824,t:1527793765043};\\\", \\\"{x:1520,y:825,t:1527793765060};\\\", \\\"{x:1513,y:830,t:1527793765077};\\\", \\\"{x:1508,y:834,t:1527793765093};\\\", \\\"{x:1508,y:835,t:1527793765110};\\\", \\\"{x:1508,y:836,t:1527793765127};\\\", \\\"{x:1508,y:837,t:1527793765142};\\\", \\\"{x:1508,y:835,t:1527793765373};\\\", \\\"{x:1505,y:833,t:1527793765381};\\\", \\\"{x:1502,y:833,t:1527793765394};\\\", \\\"{x:1498,y:833,t:1527793765410};\\\", \\\"{x:1497,y:832,t:1527793765445};\\\", \\\"{x:1496,y:832,t:1527793765469};\\\", \\\"{x:1494,y:830,t:1527793765477};\\\", \\\"{x:1490,y:829,t:1527793765494};\\\", \\\"{x:1486,y:827,t:1527793765511};\\\", \\\"{x:1477,y:825,t:1527793765528};\\\", \\\"{x:1471,y:823,t:1527793765544};\\\", \\\"{x:1467,y:822,t:1527793765560};\\\", \\\"{x:1463,y:822,t:1527793765577};\\\", \\\"{x:1462,y:822,t:1527793765605};\\\", \\\"{x:1460,y:821,t:1527793765613};\\\", \\\"{x:1460,y:819,t:1527793765629};\\\", \\\"{x:1459,y:819,t:1527793765644};\\\", \\\"{x:1458,y:819,t:1527793765660};\\\", \\\"{x:1457,y:819,t:1527793765677};\\\", \\\"{x:1457,y:818,t:1527793765781};\\\", \\\"{x:1457,y:817,t:1527793765829};\\\", \\\"{x:1457,y:816,t:1527793765845};\\\", \\\"{x:1457,y:815,t:1527793765861};\\\", \\\"{x:1458,y:815,t:1527793765877};\\\", \\\"{x:1466,y:815,t:1527793765894};\\\", \\\"{x:1473,y:818,t:1527793765910};\\\", \\\"{x:1475,y:819,t:1527793765927};\\\", \\\"{x:1476,y:820,t:1527793765944};\\\", \\\"{x:1478,y:821,t:1527793765961};\\\", \\\"{x:1478,y:822,t:1527793765997};\\\", \\\"{x:1478,y:823,t:1527793766011};\\\", \\\"{x:1478,y:824,t:1527793766125};\\\", \\\"{x:1478,y:825,t:1527793766133};\\\", \\\"{x:1477,y:827,t:1527793766229};\\\", \\\"{x:1475,y:827,t:1527793766246};\\\", \\\"{x:1475,y:821,t:1527793766494};\\\", \\\"{x:1479,y:793,t:1527793766511};\\\", \\\"{x:1475,y:708,t:1527793766528};\\\", \\\"{x:1465,y:634,t:1527793766544};\\\", \\\"{x:1464,y:620,t:1527793766561};\\\", \\\"{x:1464,y:619,t:1527793766578};\\\", \\\"{x:1463,y:618,t:1527793766630};\\\", \\\"{x:1465,y:617,t:1527793766749};\\\", \\\"{x:1469,y:617,t:1527793766761};\\\", \\\"{x:1472,y:617,t:1527793766778};\\\", \\\"{x:1472,y:618,t:1527793766794};\\\", \\\"{x:1474,y:618,t:1527793766811};\\\", \\\"{x:1476,y:618,t:1527793766828};\\\", \\\"{x:1477,y:619,t:1527793766844};\\\", \\\"{x:1479,y:620,t:1527793766861};\\\", \\\"{x:1479,y:621,t:1527793766925};\\\", \\\"{x:1483,y:621,t:1527793767013};\\\", \\\"{x:1485,y:621,t:1527793767029};\\\", \\\"{x:1489,y:621,t:1527793767044};\\\", \\\"{x:1490,y:621,t:1527793767317};\\\", \\\"{x:1491,y:621,t:1527793767329};\\\", \\\"{x:1494,y:621,t:1527793767346};\\\", \\\"{x:1495,y:621,t:1527793767365};\\\", \\\"{x:1496,y:621,t:1527793767378};\\\", \\\"{x:1498,y:621,t:1527793767421};\\\", \\\"{x:1500,y:621,t:1527793767429};\\\", \\\"{x:1501,y:621,t:1527793767445};\\\", \\\"{x:1502,y:621,t:1527793767485};\\\", \\\"{x:1503,y:621,t:1527793767501};\\\", \\\"{x:1506,y:621,t:1527793767511};\\\", \\\"{x:1510,y:622,t:1527793767528};\\\", \\\"{x:1513,y:624,t:1527793767545};\\\", \\\"{x:1514,y:624,t:1527793767565};\\\", \\\"{x:1514,y:625,t:1527793767646};\\\", \\\"{x:1516,y:627,t:1527793767728};\\\", \\\"{x:1517,y:628,t:1527793767744};\\\", \\\"{x:1519,y:631,t:1527793767761};\\\", \\\"{x:1521,y:633,t:1527793767778};\\\", \\\"{x:1523,y:634,t:1527793767795};\\\", \\\"{x:1524,y:635,t:1527793767812};\\\", \\\"{x:1526,y:636,t:1527793767828};\\\", \\\"{x:1526,y:637,t:1527793767965};\\\", \\\"{x:1525,y:637,t:1527793767989};\\\", \\\"{x:1523,y:637,t:1527793768004};\\\", \\\"{x:1521,y:637,t:1527793768125};\\\", \\\"{x:1520,y:637,t:1527793768157};\\\", \\\"{x:1518,y:637,t:1527793768173};\\\", \\\"{x:1517,y:637,t:1527793768206};\\\", \\\"{x:1516,y:637,t:1527793768253};\\\", \\\"{x:1515,y:636,t:1527793768285};\\\", \\\"{x:1513,y:636,t:1527793768893};\\\", \\\"{x:1510,y:636,t:1527793768901};\\\", \\\"{x:1507,y:635,t:1527793768912};\\\", \\\"{x:1498,y:633,t:1527793768929};\\\", \\\"{x:1491,y:632,t:1527793768945};\\\", \\\"{x:1485,y:629,t:1527793768962};\\\", \\\"{x:1482,y:629,t:1527793768979};\\\", \\\"{x:1473,y:624,t:1527793768995};\\\", \\\"{x:1468,y:622,t:1527793769012};\\\", \\\"{x:1462,y:618,t:1527793769028};\\\", \\\"{x:1460,y:618,t:1527793769044};\\\", \\\"{x:1459,y:618,t:1527793769061};\\\", \\\"{x:1455,y:616,t:1527793769079};\\\", \\\"{x:1450,y:616,t:1527793769096};\\\", \\\"{x:1448,y:616,t:1527793769112};\\\", \\\"{x:1444,y:616,t:1527793769129};\\\", \\\"{x:1442,y:616,t:1527793769146};\\\", \\\"{x:1437,y:616,t:1527793769162};\\\", \\\"{x:1430,y:618,t:1527793769178};\\\", \\\"{x:1423,y:619,t:1527793769195};\\\", \\\"{x:1417,y:622,t:1527793769212};\\\", \\\"{x:1410,y:626,t:1527793769229};\\\", \\\"{x:1403,y:628,t:1527793769245};\\\", \\\"{x:1401,y:628,t:1527793769261};\\\", \\\"{x:1396,y:628,t:1527793769278};\\\", \\\"{x:1394,y:628,t:1527793769295};\\\", \\\"{x:1389,y:628,t:1527793769311};\\\", \\\"{x:1373,y:629,t:1527793769328};\\\", \\\"{x:1360,y:629,t:1527793769345};\\\", \\\"{x:1354,y:629,t:1527793769362};\\\", \\\"{x:1346,y:629,t:1527793769378};\\\", \\\"{x:1343,y:629,t:1527793769395};\\\", \\\"{x:1339,y:629,t:1527793769411};\\\", \\\"{x:1336,y:628,t:1527793769428};\\\", \\\"{x:1335,y:628,t:1527793769614};\\\", \\\"{x:1334,y:628,t:1527793769701};\\\", \\\"{x:1333,y:628,t:1527793769712};\\\", \\\"{x:1332,y:628,t:1527793769733};\\\", \\\"{x:1331,y:628,t:1527793769748};\\\", \\\"{x:1328,y:628,t:1527793769765};\\\", \\\"{x:1326,y:628,t:1527793769779};\\\", \\\"{x:1321,y:628,t:1527793769796};\\\", \\\"{x:1318,y:628,t:1527793769813};\\\", \\\"{x:1317,y:628,t:1527793769828};\\\", \\\"{x:1316,y:628,t:1527793769853};\\\", \\\"{x:1314,y:628,t:1527793769862};\\\", \\\"{x:1312,y:628,t:1527793769879};\\\", \\\"{x:1311,y:628,t:1527793769896};\\\", \\\"{x:1311,y:636,t:1527793772430};\\\", \\\"{x:1310,y:659,t:1527793772447};\\\", \\\"{x:1310,y:667,t:1527793772463};\\\", \\\"{x:1310,y:670,t:1527793772481};\\\", \\\"{x:1312,y:685,t:1527793772497};\\\", \\\"{x:1313,y:689,t:1527793772514};\\\", \\\"{x:1315,y:694,t:1527793772531};\\\", \\\"{x:1316,y:707,t:1527793772547};\\\", \\\"{x:1316,y:714,t:1527793772565};\\\", \\\"{x:1316,y:727,t:1527793772581};\\\", \\\"{x:1316,y:734,t:1527793772597};\\\", \\\"{x:1316,y:742,t:1527793772614};\\\", \\\"{x:1316,y:754,t:1527793772631};\\\", \\\"{x:1313,y:770,t:1527793772647};\\\", \\\"{x:1312,y:775,t:1527793772664};\\\", \\\"{x:1310,y:786,t:1527793772681};\\\", \\\"{x:1309,y:795,t:1527793772697};\\\", \\\"{x:1308,y:801,t:1527793772714};\\\", \\\"{x:1305,y:811,t:1527793772731};\\\", \\\"{x:1304,y:816,t:1527793772747};\\\", \\\"{x:1304,y:830,t:1527793772764};\\\", \\\"{x:1306,y:848,t:1527793772780};\\\", \\\"{x:1306,y:854,t:1527793772798};\\\", \\\"{x:1309,y:856,t:1527793772814};\\\", \\\"{x:1310,y:857,t:1527793772844};\\\", \\\"{x:1312,y:859,t:1527793772877};\\\", \\\"{x:1313,y:860,t:1527793772885};\\\", \\\"{x:1313,y:861,t:1527793772898};\\\", \\\"{x:1313,y:865,t:1527793772914};\\\", \\\"{x:1314,y:872,t:1527793772931};\\\", \\\"{x:1314,y:875,t:1527793772947};\\\", \\\"{x:1314,y:882,t:1527793772964};\\\", \\\"{x:1314,y:890,t:1527793772980};\\\", \\\"{x:1314,y:891,t:1527793772998};\\\", \\\"{x:1310,y:899,t:1527793773013};\\\", \\\"{x:1310,y:904,t:1527793773031};\\\", \\\"{x:1307,y:904,t:1527793773048};\\\", \\\"{x:1303,y:908,t:1527793773064};\\\", \\\"{x:1301,y:911,t:1527793773081};\\\", \\\"{x:1300,y:914,t:1527793773097};\\\", \\\"{x:1298,y:918,t:1527793773114};\\\", \\\"{x:1298,y:919,t:1527793773131};\\\", \\\"{x:1297,y:924,t:1527793773147};\\\", \\\"{x:1294,y:928,t:1527793773164};\\\", \\\"{x:1294,y:929,t:1527793773212};\\\", \\\"{x:1294,y:932,t:1527793773245};\\\", \\\"{x:1294,y:934,t:1527793773260};\\\", \\\"{x:1294,y:935,t:1527793773268};\\\", \\\"{x:1294,y:936,t:1527793773280};\\\", \\\"{x:1294,y:938,t:1527793773297};\\\", \\\"{x:1295,y:943,t:1527793773314};\\\", \\\"{x:1295,y:945,t:1527793773332};\\\", \\\"{x:1295,y:946,t:1527793773348};\\\", \\\"{x:1296,y:951,t:1527793773364};\\\", \\\"{x:1300,y:958,t:1527793773381};\\\", \\\"{x:1300,y:961,t:1527793773398};\\\", \\\"{x:1301,y:961,t:1527793773414};\\\", \\\"{x:1302,y:961,t:1527793773518};\\\", \\\"{x:1303,y:960,t:1527793773533};\\\", \\\"{x:1306,y:960,t:1527793773548};\\\", \\\"{x:1308,y:958,t:1527793773565};\\\", \\\"{x:1312,y:957,t:1527793773582};\\\", \\\"{x:1315,y:956,t:1527793773598};\\\", \\\"{x:1317,y:954,t:1527793773616};\\\", \\\"{x:1318,y:953,t:1527793773631};\\\", \\\"{x:1318,y:954,t:1527793773853};\\\", \\\"{x:1318,y:956,t:1527793773885};\\\", \\\"{x:1318,y:957,t:1527793773898};\\\", \\\"{x:1318,y:958,t:1527793776205};\\\", \\\"{x:1316,y:962,t:1527793776217};\\\", \\\"{x:1305,y:967,t:1527793776234};\\\", \\\"{x:1296,y:972,t:1527793776250};\\\", \\\"{x:1295,y:973,t:1527793776267};\\\", \\\"{x:1292,y:973,t:1527793776364};\\\", \\\"{x:1285,y:974,t:1527793776383};\\\", \\\"{x:1284,y:974,t:1527793776405};\\\", \\\"{x:1283,y:974,t:1527793776621};\\\", \\\"{x:1281,y:971,t:1527793776644};\\\", \\\"{x:1281,y:968,t:1527793776661};\\\", \\\"{x:1281,y:967,t:1527793776676};\\\", \\\"{x:1281,y:965,t:1527793776693};\\\", \\\"{x:1279,y:965,t:1527793776701};\\\", \\\"{x:1279,y:964,t:1527793776717};\\\", \\\"{x:1279,y:963,t:1527793776765};\\\", \\\"{x:1279,y:962,t:1527793776773};\\\", \\\"{x:1278,y:962,t:1527793776784};\\\", \\\"{x:1278,y:961,t:1527793776801};\\\", \\\"{x:1277,y:959,t:1527793776816};\\\", \\\"{x:1276,y:959,t:1527793776885};\\\", \\\"{x:1276,y:958,t:1527793776925};\\\", \\\"{x:1276,y:956,t:1527793776949};\\\", \\\"{x:1275,y:955,t:1527793776957};\\\", \\\"{x:1275,y:954,t:1527793777069};\\\", \\\"{x:1275,y:949,t:1527793777084};\\\", \\\"{x:1272,y:932,t:1527793777101};\\\", \\\"{x:1268,y:913,t:1527793777117};\\\", \\\"{x:1267,y:895,t:1527793777133};\\\", \\\"{x:1262,y:877,t:1527793777150};\\\", \\\"{x:1261,y:865,t:1527793777167};\\\", \\\"{x:1257,y:856,t:1527793777183};\\\", \\\"{x:1257,y:854,t:1527793777200};\\\", \\\"{x:1256,y:852,t:1527793777216};\\\", \\\"{x:1256,y:851,t:1527793777237};\\\", \\\"{x:1256,y:850,t:1527793777253};\\\", \\\"{x:1256,y:849,t:1527793777269};\\\", \\\"{x:1256,y:848,t:1527793777284};\\\", \\\"{x:1262,y:842,t:1527793777300};\\\", \\\"{x:1267,y:837,t:1527793777317};\\\", \\\"{x:1271,y:831,t:1527793777333};\\\", \\\"{x:1278,y:824,t:1527793777351};\\\", \\\"{x:1282,y:816,t:1527793777367};\\\", \\\"{x:1285,y:812,t:1527793777383};\\\", \\\"{x:1286,y:811,t:1527793777437};\\\", \\\"{x:1287,y:811,t:1527793777485};\\\", \\\"{x:1288,y:811,t:1527793777629};\\\", \\\"{x:1288,y:812,t:1527793777645};\\\", \\\"{x:1289,y:813,t:1527793777661};\\\", \\\"{x:1289,y:814,t:1527793777668};\\\", \\\"{x:1289,y:815,t:1527793777693};\\\", \\\"{x:1289,y:816,t:1527793777708};\\\", \\\"{x:1289,y:817,t:1527793777724};\\\", \\\"{x:1289,y:818,t:1527793777765};\\\", \\\"{x:1289,y:819,t:1527793777813};\\\", \\\"{x:1289,y:821,t:1527793777829};\\\", \\\"{x:1289,y:823,t:1527793777837};\\\", \\\"{x:1288,y:825,t:1527793777851};\\\", \\\"{x:1287,y:827,t:1527793777867};\\\", \\\"{x:1285,y:828,t:1527793777884};\\\", \\\"{x:1285,y:827,t:1527793778469};\\\", \\\"{x:1285,y:826,t:1527793782677};\\\", \\\"{x:1288,y:819,t:1527793782688};\\\", \\\"{x:1296,y:808,t:1527793782702};\\\", \\\"{x:1302,y:796,t:1527793782718};\\\", \\\"{x:1304,y:786,t:1527793782736};\\\", \\\"{x:1307,y:770,t:1527793782753};\\\", \\\"{x:1308,y:751,t:1527793782769};\\\", \\\"{x:1309,y:742,t:1527793782786};\\\", \\\"{x:1309,y:733,t:1527793782803};\\\", \\\"{x:1310,y:729,t:1527793782820};\\\", \\\"{x:1312,y:726,t:1527793782836};\\\", \\\"{x:1312,y:718,t:1527793782853};\\\", \\\"{x:1312,y:716,t:1527793782869};\\\", \\\"{x:1312,y:709,t:1527793782886};\\\", \\\"{x:1312,y:707,t:1527793782904};\\\", \\\"{x:1312,y:706,t:1527793782919};\\\", \\\"{x:1310,y:700,t:1527793782936};\\\", \\\"{x:1310,y:692,t:1527793782954};\\\", \\\"{x:1310,y:691,t:1527793782969};\\\", \\\"{x:1311,y:685,t:1527793782986};\\\", \\\"{x:1311,y:680,t:1527793783003};\\\", \\\"{x:1311,y:675,t:1527793783019};\\\", \\\"{x:1311,y:663,t:1527793783036};\\\", \\\"{x:1311,y:660,t:1527793783053};\\\", \\\"{x:1311,y:656,t:1527793783070};\\\", \\\"{x:1311,y:653,t:1527793783086};\\\", \\\"{x:1311,y:651,t:1527793783103};\\\", \\\"{x:1311,y:643,t:1527793783120};\\\", \\\"{x:1311,y:642,t:1527793783136};\\\", \\\"{x:1313,y:634,t:1527793783153};\\\", \\\"{x:1314,y:628,t:1527793783170};\\\", \\\"{x:1315,y:617,t:1527793783186};\\\", \\\"{x:1318,y:609,t:1527793783203};\\\", \\\"{x:1319,y:602,t:1527793783220};\\\", \\\"{x:1319,y:598,t:1527793783236};\\\", \\\"{x:1319,y:597,t:1527793783253};\\\", \\\"{x:1319,y:596,t:1527793783309};\\\", \\\"{x:1319,y:595,t:1527793783320};\\\", \\\"{x:1319,y:594,t:1527793783337};\\\", \\\"{x:1319,y:597,t:1527793783661};\\\", \\\"{x:1319,y:600,t:1527793783670};\\\", \\\"{x:1319,y:608,t:1527793783687};\\\", \\\"{x:1319,y:610,t:1527793783703};\\\", \\\"{x:1319,y:611,t:1527793783721};\\\", \\\"{x:1319,y:615,t:1527793783737};\\\", \\\"{x:1319,y:617,t:1527793783754};\\\", \\\"{x:1319,y:618,t:1527793784013};\\\", \\\"{x:1318,y:621,t:1527793784023};\\\", \\\"{x:1318,y:623,t:1527793784044};\\\", \\\"{x:1318,y:624,t:1527793784277};\\\", \\\"{x:1317,y:625,t:1527793784326};\\\", \\\"{x:1317,y:626,t:1527793784354};\\\", \\\"{x:1317,y:627,t:1527793784370};\\\", \\\"{x:1317,y:628,t:1527793784404};\\\", \\\"{x:1315,y:632,t:1527793785573};\\\", \\\"{x:1314,y:635,t:1527793785588};\\\", \\\"{x:1310,y:648,t:1527793785606};\\\", \\\"{x:1305,y:659,t:1527793785622};\\\", \\\"{x:1301,y:670,t:1527793785638};\\\", \\\"{x:1298,y:681,t:1527793785654};\\\", \\\"{x:1295,y:692,t:1527793785672};\\\", \\\"{x:1295,y:698,t:1527793785688};\\\", \\\"{x:1291,y:709,t:1527793785705};\\\", \\\"{x:1286,y:727,t:1527793785722};\\\", \\\"{x:1282,y:736,t:1527793785738};\\\", \\\"{x:1281,y:738,t:1527793785755};\\\", \\\"{x:1281,y:742,t:1527793785771};\\\", \\\"{x:1282,y:746,t:1527793785788};\\\", \\\"{x:1282,y:748,t:1527793785813};\\\", \\\"{x:1282,y:749,t:1527793785822};\\\", \\\"{x:1282,y:755,t:1527793785839};\\\", \\\"{x:1282,y:757,t:1527793785855};\\\", \\\"{x:1283,y:762,t:1527793785872};\\\", \\\"{x:1284,y:765,t:1527793785889};\\\", \\\"{x:1284,y:769,t:1527793785904};\\\", \\\"{x:1284,y:771,t:1527793785921};\\\", \\\"{x:1284,y:773,t:1527793785939};\\\", \\\"{x:1284,y:775,t:1527793785954};\\\", \\\"{x:1284,y:777,t:1527793785971};\\\", \\\"{x:1284,y:780,t:1527793785989};\\\", \\\"{x:1283,y:782,t:1527793786021};\\\", \\\"{x:1283,y:783,t:1527793786221};\\\", \\\"{x:1282,y:783,t:1527793786239};\\\", \\\"{x:1281,y:783,t:1527793786256};\\\", \\\"{x:1281,y:779,t:1527793786284};\\\", \\\"{x:1281,y:778,t:1527793786292};\\\", \\\"{x:1281,y:775,t:1527793786306};\\\", \\\"{x:1281,y:769,t:1527793786322};\\\", \\\"{x:1282,y:747,t:1527793786339};\\\", \\\"{x:1283,y:737,t:1527793786356};\\\", \\\"{x:1285,y:712,t:1527793786372};\\\", \\\"{x:1290,y:697,t:1527793786389};\\\", \\\"{x:1295,y:687,t:1527793786406};\\\", \\\"{x:1295,y:679,t:1527793786422};\\\", \\\"{x:1292,y:662,t:1527793786439};\\\", \\\"{x:1292,y:655,t:1527793786456};\\\", \\\"{x:1291,y:650,t:1527793786472};\\\", \\\"{x:1291,y:644,t:1527793786489};\\\", \\\"{x:1291,y:640,t:1527793786506};\\\", \\\"{x:1292,y:629,t:1527793786521};\\\", \\\"{x:1292,y:615,t:1527793786539};\\\", \\\"{x:1292,y:607,t:1527793786556};\\\", \\\"{x:1288,y:593,t:1527793786572};\\\", \\\"{x:1286,y:586,t:1527793786589};\\\", \\\"{x:1282,y:578,t:1527793786606};\\\", \\\"{x:1281,y:571,t:1527793786622};\\\", \\\"{x:1281,y:570,t:1527793786638};\\\", \\\"{x:1281,y:569,t:1527793786667};\\\", \\\"{x:1281,y:567,t:1527793786700};\\\", \\\"{x:1281,y:565,t:1527793786708};\\\", \\\"{x:1281,y:563,t:1527793786721};\\\", \\\"{x:1281,y:556,t:1527793786738};\\\", \\\"{x:1281,y:549,t:1527793786755};\\\", \\\"{x:1281,y:544,t:1527793786771};\\\", \\\"{x:1281,y:540,t:1527793786788};\\\", \\\"{x:1281,y:538,t:1527793786806};\\\", \\\"{x:1282,y:537,t:1527793787067};\\\", \\\"{x:1289,y:534,t:1527793787075};\\\", \\\"{x:1306,y:526,t:1527793787088};\\\", \\\"{x:1349,y:505,t:1527793787106};\\\", \\\"{x:1383,y:480,t:1527793787122};\\\", \\\"{x:1430,y:442,t:1527793787138};\\\", \\\"{x:1455,y:420,t:1527793787155};\\\", \\\"{x:1474,y:405,t:1527793787171};\\\", \\\"{x:1479,y:393,t:1527793787188};\\\", \\\"{x:1487,y:382,t:1527793787205};\\\", \\\"{x:1494,y:377,t:1527793787223};\\\", \\\"{x:1500,y:364,t:1527793787238};\\\", \\\"{x:1506,y:348,t:1527793787255};\\\", \\\"{x:1509,y:328,t:1527793787273};\\\", \\\"{x:1509,y:313,t:1527793787288};\\\", \\\"{x:1507,y:294,t:1527793787305};\\\", \\\"{x:1499,y:267,t:1527793787322};\\\", \\\"{x:1496,y:253,t:1527793787338};\\\", \\\"{x:1492,y:236,t:1527793787356};\\\", \\\"{x:1478,y:209,t:1527793787372};\\\", \\\"{x:1469,y:185,t:1527793787388};\\\", \\\"{x:1453,y:144,t:1527793787405};\\\", \\\"{x:1445,y:120,t:1527793787422};\\\", \\\"{x:1436,y:103,t:1527793787439};\\\", \\\"{x:1432,y:94,t:1527793787456};\\\", \\\"{x:1432,y:93,t:1527793787472};\\\", \\\"{x:1433,y:93,t:1527793787581};\\\", \\\"{x:1435,y:97,t:1527793787590};\\\", \\\"{x:1441,y:112,t:1527793787605};\\\", \\\"{x:1447,y:128,t:1527793787622};\\\", \\\"{x:1452,y:133,t:1527793787639};\\\", \\\"{x:1460,y:144,t:1527793787656};\\\", \\\"{x:1463,y:150,t:1527793787672};\\\", \\\"{x:1465,y:151,t:1527793787689};\\\", \\\"{x:1466,y:152,t:1527793787705};\\\", \\\"{x:1469,y:152,t:1527793787940};\\\", \\\"{x:1470,y:152,t:1527793787956};\\\", \\\"{x:1472,y:152,t:1527793787989};\\\", \\\"{x:1473,y:152,t:1527793788012};\\\", \\\"{x:1475,y:154,t:1527793788309};\\\", \\\"{x:1476,y:155,t:1527793788323};\\\", \\\"{x:1480,y:161,t:1527793788340};\\\", \\\"{x:1484,y:166,t:1527793788357};\\\", \\\"{x:1486,y:168,t:1527793788374};\\\", \\\"{x:1486,y:169,t:1527793788390};\\\", \\\"{x:1486,y:170,t:1527793788407};\\\", \\\"{x:1486,y:174,t:1527793788821};\\\", \\\"{x:1486,y:181,t:1527793788829};\\\", \\\"{x:1486,y:188,t:1527793788840};\\\", \\\"{x:1486,y:206,t:1527793788857};\\\", \\\"{x:1484,y:228,t:1527793788874};\\\", \\\"{x:1483,y:243,t:1527793788890};\\\", \\\"{x:1483,y:269,t:1527793788907};\\\", \\\"{x:1479,y:288,t:1527793788923};\\\", \\\"{x:1484,y:321,t:1527793788940};\\\", \\\"{x:1487,y:362,t:1527793788957};\\\", \\\"{x:1490,y:378,t:1527793788975};\\\", \\\"{x:1495,y:393,t:1527793788990};\\\", \\\"{x:1502,y:409,t:1527793789007};\\\", \\\"{x:1503,y:422,t:1527793789024};\\\", \\\"{x:1507,y:436,t:1527793789039};\\\", \\\"{x:1510,y:456,t:1527793789057};\\\", \\\"{x:1514,y:470,t:1527793789074};\\\", \\\"{x:1515,y:477,t:1527793789090};\\\", \\\"{x:1520,y:490,t:1527793789107};\\\", \\\"{x:1521,y:493,t:1527793789124};\\\", \\\"{x:1525,y:507,t:1527793789140};\\\", \\\"{x:1526,y:529,t:1527793789157};\\\", \\\"{x:1526,y:551,t:1527793789174};\\\", \\\"{x:1526,y:563,t:1527793789190};\\\", \\\"{x:1526,y:580,t:1527793789207};\\\", \\\"{x:1524,y:593,t:1527793789224};\\\", \\\"{x:1521,y:608,t:1527793789239};\\\", \\\"{x:1518,y:613,t:1527793789257};\\\", \\\"{x:1518,y:615,t:1527793789273};\\\", \\\"{x:1511,y:634,t:1527793789290};\\\", \\\"{x:1509,y:642,t:1527793789308};\\\", \\\"{x:1507,y:643,t:1527793789324};\\\", \\\"{x:1506,y:660,t:1527793789340};\\\", \\\"{x:1506,y:668,t:1527793789357};\\\", \\\"{x:1506,y:681,t:1527793789374};\\\", \\\"{x:1506,y:682,t:1527793789427};\\\", \\\"{x:1506,y:683,t:1527793789440};\\\", \\\"{x:1505,y:685,t:1527793789476};\\\", \\\"{x:1505,y:690,t:1527793789491};\\\", \\\"{x:1505,y:693,t:1527793789507};\\\", \\\"{x:1505,y:697,t:1527793789523};\\\", \\\"{x:1505,y:698,t:1527793789540};\\\", \\\"{x:1505,y:699,t:1527793789556};\\\", \\\"{x:1506,y:699,t:1527793789574};\\\", \\\"{x:1507,y:699,t:1527793789590};\\\", \\\"{x:1507,y:700,t:1527793789852};\\\", \\\"{x:1507,y:701,t:1527793789877};\\\", \\\"{x:1507,y:702,t:1527793789891};\\\", \\\"{x:1509,y:706,t:1527793789907};\\\", \\\"{x:1509,y:707,t:1527793789925};\\\", \\\"{x:1509,y:708,t:1527793789941};\\\", \\\"{x:1510,y:708,t:1527793790044};\\\", \\\"{x:1514,y:712,t:1527793790267};\\\", \\\"{x:1534,y:728,t:1527793790275};\\\", \\\"{x:1549,y:748,t:1527793790290};\\\", \\\"{x:1575,y:766,t:1527793790307};\\\", \\\"{x:1575,y:768,t:1527793790323};\\\", \\\"{x:1579,y:772,t:1527793790340};\\\", \\\"{x:1596,y:779,t:1527793790357};\\\", \\\"{x:1610,y:780,t:1527793790373};\\\", \\\"{x:1624,y:782,t:1527793790390};\\\", \\\"{x:1634,y:786,t:1527793790407};\\\", \\\"{x:1635,y:787,t:1527793790424};\\\", \\\"{x:1644,y:788,t:1527793790441};\\\", \\\"{x:1647,y:788,t:1527793790457};\\\", \\\"{x:1648,y:788,t:1527793790492};\\\", \\\"{x:1649,y:788,t:1527793790507};\\\", \\\"{x:1650,y:787,t:1527793790524};\\\", \\\"{x:1655,y:785,t:1527793790541};\\\", \\\"{x:1656,y:784,t:1527793790558};\\\", \\\"{x:1658,y:787,t:1527793790613};\\\", \\\"{x:1660,y:797,t:1527793790624};\\\", \\\"{x:1664,y:814,t:1527793790641};\\\", \\\"{x:1670,y:836,t:1527793790658};\\\", \\\"{x:1675,y:853,t:1527793790674};\\\", \\\"{x:1678,y:862,t:1527793790691};\\\", \\\"{x:1678,y:865,t:1527793790708};\\\", \\\"{x:1679,y:864,t:1527793790893};\\\", \\\"{x:1680,y:864,t:1527793790908};\\\", \\\"{x:1680,y:862,t:1527793790925};\\\", \\\"{x:1680,y:858,t:1527793790941};\\\", \\\"{x:1681,y:856,t:1527793790958};\\\", \\\"{x:1681,y:854,t:1527793791021};\\\", \\\"{x:1681,y:853,t:1527793791044};\\\", \\\"{x:1682,y:852,t:1527793791058};\\\", \\\"{x:1682,y:849,t:1527793791075};\\\", \\\"{x:1683,y:847,t:1527793791092};\\\", \\\"{x:1685,y:846,t:1527793791108};\\\", \\\"{x:1686,y:845,t:1527793791125};\\\", \\\"{x:1686,y:844,t:1527793791140};\\\", \\\"{x:1686,y:843,t:1527793791172};\\\", \\\"{x:1686,y:842,t:1527793791197};\\\", \\\"{x:1687,y:841,t:1527793791208};\\\", \\\"{x:1687,y:840,t:1527793791237};\\\", \\\"{x:1687,y:839,t:1527793791501};\\\", \\\"{x:1687,y:836,t:1527793791517};\\\", \\\"{x:1687,y:833,t:1527793791524};\\\", \\\"{x:1684,y:827,t:1527793791542};\\\", \\\"{x:1683,y:826,t:1527793791558};\\\", \\\"{x:1681,y:823,t:1527793791576};\\\", \\\"{x:1680,y:818,t:1527793791591};\\\", \\\"{x:1678,y:814,t:1527793791607};\\\", \\\"{x:1676,y:812,t:1527793791624};\\\", \\\"{x:1676,y:810,t:1527793791642};\\\", \\\"{x:1675,y:808,t:1527793791660};\\\", \\\"{x:1674,y:807,t:1527793791684};\\\", \\\"{x:1674,y:806,t:1527793791693};\\\", \\\"{x:1673,y:806,t:1527793791708};\\\", \\\"{x:1671,y:803,t:1527793791725};\\\", \\\"{x:1668,y:796,t:1527793791742};\\\", \\\"{x:1664,y:790,t:1527793791758};\\\", \\\"{x:1661,y:788,t:1527793791775};\\\", \\\"{x:1661,y:787,t:1527793791812};\\\", \\\"{x:1660,y:786,t:1527793791829};\\\", \\\"{x:1659,y:786,t:1527793791861};\\\", \\\"{x:1658,y:786,t:1527793791885};\\\", \\\"{x:1657,y:785,t:1527793792101};\\\", \\\"{x:1657,y:783,t:1527793792116};\\\", \\\"{x:1655,y:782,t:1527793792132};\\\", \\\"{x:1651,y:778,t:1527793792149};\\\", \\\"{x:1650,y:774,t:1527793792164};\\\", \\\"{x:1649,y:771,t:1527793792176};\\\", \\\"{x:1648,y:768,t:1527793792191};\\\", \\\"{x:1648,y:767,t:1527793792208};\\\", \\\"{x:1648,y:765,t:1527793792224};\\\", \\\"{x:1648,y:764,t:1527793792241};\\\", \\\"{x:1648,y:763,t:1527793792259};\\\", \\\"{x:1647,y:761,t:1527793792274};\\\", \\\"{x:1644,y:757,t:1527793792291};\\\", \\\"{x:1641,y:753,t:1527793792308};\\\", \\\"{x:1640,y:752,t:1527793792339};\\\", \\\"{x:1639,y:751,t:1527793792348};\\\", \\\"{x:1638,y:750,t:1527793792358};\\\", \\\"{x:1637,y:749,t:1527793792376};\\\", \\\"{x:1637,y:747,t:1527793792391};\\\", \\\"{x:1637,y:746,t:1527793792408};\\\", \\\"{x:1636,y:744,t:1527793792425};\\\", \\\"{x:1634,y:743,t:1527793792442};\\\", \\\"{x:1631,y:741,t:1527793792459};\\\", \\\"{x:1628,y:739,t:1527793792474};\\\", \\\"{x:1627,y:737,t:1527793792491};\\\", \\\"{x:1627,y:736,t:1527793792813};\\\", \\\"{x:1627,y:737,t:1527793793436};\\\", \\\"{x:1630,y:760,t:1527793793444};\\\", \\\"{x:1637,y:795,t:1527793793459};\\\", \\\"{x:1640,y:858,t:1527793793476};\\\", \\\"{x:1640,y:873,t:1527793793492};\\\", \\\"{x:1640,y:893,t:1527793793509};\\\", \\\"{x:1638,y:902,t:1527793793525};\\\", \\\"{x:1637,y:903,t:1527793793542};\\\", \\\"{x:1637,y:904,t:1527793793579};\\\", \\\"{x:1637,y:905,t:1527793793619};\\\", \\\"{x:1637,y:906,t:1527793793668};\\\", \\\"{x:1636,y:907,t:1527793793675};\\\", \\\"{x:1636,y:908,t:1527793793691};\\\", \\\"{x:1636,y:911,t:1527793793709};\\\", \\\"{x:1635,y:913,t:1527793793726};\\\", \\\"{x:1634,y:917,t:1527793793743};\\\", \\\"{x:1630,y:921,t:1527793793759};\\\", \\\"{x:1624,y:926,t:1527793793775};\\\", \\\"{x:1622,y:931,t:1527793793796};\\\", \\\"{x:1622,y:933,t:1527793793811};\\\", \\\"{x:1621,y:937,t:1527793793826};\\\", \\\"{x:1620,y:938,t:1527793793842};\\\", \\\"{x:1619,y:941,t:1527793793859};\\\", \\\"{x:1616,y:946,t:1527793796053};\\\", \\\"{x:1616,y:950,t:1527793796060};\\\", \\\"{x:1616,y:951,t:1527793796084};\\\", \\\"{x:1616,y:953,t:1527793796094};\\\", \\\"{x:1615,y:955,t:1527793796111};\\\", \\\"{x:1615,y:958,t:1527793796127};\\\", \\\"{x:1615,y:959,t:1527793796548};\\\", \\\"{x:1618,y:955,t:1527793796561};\\\", \\\"{x:1619,y:943,t:1527793796579};\\\", \\\"{x:1624,y:906,t:1527793796594};\\\", \\\"{x:1624,y:888,t:1527793796611};\\\", \\\"{x:1622,y:858,t:1527793796629};\\\", \\\"{x:1620,y:830,t:1527793796644};\\\", \\\"{x:1613,y:809,t:1527793796661};\\\", \\\"{x:1614,y:771,t:1527793796678};\\\", \\\"{x:1611,y:743,t:1527793796694};\\\", \\\"{x:1611,y:729,t:1527793796711};\\\", \\\"{x:1611,y:726,t:1527793796728};\\\", \\\"{x:1605,y:717,t:1527793796744};\\\", \\\"{x:1605,y:710,t:1527793796761};\\\", \\\"{x:1604,y:701,t:1527793796778};\\\", \\\"{x:1604,y:688,t:1527793796794};\\\", \\\"{x:1604,y:683,t:1527793796811};\\\", \\\"{x:1604,y:678,t:1527793796828};\\\", \\\"{x:1606,y:667,t:1527793796844};\\\", \\\"{x:1607,y:664,t:1527793796861};\\\", \\\"{x:1609,y:661,t:1527793796878};\\\", \\\"{x:1609,y:660,t:1527793796894};\\\", \\\"{x:1613,y:646,t:1527793796911};\\\", \\\"{x:1613,y:630,t:1527793796929};\\\", \\\"{x:1613,y:619,t:1527793796944};\\\", \\\"{x:1613,y:611,t:1527793796961};\\\", \\\"{x:1614,y:598,t:1527793796978};\\\", \\\"{x:1615,y:592,t:1527793796994};\\\", \\\"{x:1615,y:590,t:1527793797011};\\\", \\\"{x:1613,y:576,t:1527793797029};\\\", \\\"{x:1613,y:570,t:1527793797044};\\\", \\\"{x:1613,y:566,t:1527793797061};\\\", \\\"{x:1613,y:564,t:1527793797095};\\\", \\\"{x:1613,y:563,t:1527793797115};\\\", \\\"{x:1613,y:561,t:1527793797127};\\\", \\\"{x:1613,y:560,t:1527793797144};\\\", \\\"{x:1613,y:558,t:1527793797160};\\\", \\\"{x:1613,y:557,t:1527793797177};\\\", \\\"{x:1613,y:553,t:1527793797828};\\\", \\\"{x:1614,y:540,t:1527793797846};\\\", \\\"{x:1619,y:529,t:1527793797863};\\\", \\\"{x:1622,y:522,t:1527793797879};\\\", \\\"{x:1622,y:519,t:1527793797895};\\\", \\\"{x:1622,y:516,t:1527793797913};\\\", \\\"{x:1622,y:506,t:1527793797928};\\\", \\\"{x:1617,y:494,t:1527793797945};\\\", \\\"{x:1613,y:475,t:1527793797962};\\\", \\\"{x:1609,y:457,t:1527793797978};\\\", \\\"{x:1606,y:448,t:1527793797995};\\\", \\\"{x:1601,y:426,t:1527793798012};\\\", \\\"{x:1601,y:424,t:1527793798027};\\\", \\\"{x:1601,y:421,t:1527793798045};\\\", \\\"{x:1600,y:420,t:1527793798062};\\\", \\\"{x:1599,y:417,t:1527793798078};\\\", \\\"{x:1599,y:416,t:1527793798095};\\\", \\\"{x:1599,y:414,t:1527793798112};\\\", \\\"{x:1599,y:413,t:1527793798128};\\\", \\\"{x:1599,y:414,t:1527793798292};\\\", \\\"{x:1600,y:417,t:1527793798300};\\\", \\\"{x:1600,y:418,t:1527793798312};\\\", \\\"{x:1602,y:423,t:1527793798328};\\\", \\\"{x:1602,y:424,t:1527793798345};\\\", \\\"{x:1602,y:425,t:1527793798362};\\\", \\\"{x:1602,y:426,t:1527793798669};\\\", \\\"{x:1603,y:430,t:1527793798781};\\\", \\\"{x:1603,y:434,t:1527793798795};\\\", \\\"{x:1603,y:454,t:1527793798812};\\\", \\\"{x:1601,y:478,t:1527793798828};\\\", \\\"{x:1594,y:499,t:1527793798845};\\\", \\\"{x:1581,y:554,t:1527793798863};\\\", \\\"{x:1569,y:629,t:1527793798879};\\\", \\\"{x:1560,y:685,t:1527793798895};\\\", \\\"{x:1562,y:707,t:1527793798912};\\\", \\\"{x:1562,y:720,t:1527793798929};\\\", \\\"{x:1562,y:724,t:1527793798946};\\\", \\\"{x:1562,y:726,t:1527793798962};\\\", \\\"{x:1561,y:727,t:1527793799052};\\\", \\\"{x:1559,y:726,t:1527793799061};\\\", \\\"{x:1555,y:722,t:1527793799079};\\\", \\\"{x:1550,y:716,t:1527793799095};\\\", \\\"{x:1543,y:702,t:1527793799111};\\\", \\\"{x:1538,y:688,t:1527793799129};\\\", \\\"{x:1532,y:670,t:1527793799146};\\\", \\\"{x:1518,y:649,t:1527793799162};\\\", \\\"{x:1511,y:639,t:1527793799179};\\\", \\\"{x:1503,y:630,t:1527793799196};\\\", \\\"{x:1499,y:626,t:1527793799212};\\\", \\\"{x:1499,y:622,t:1527793799229};\\\", \\\"{x:1499,y:621,t:1527793799246};\\\", \\\"{x:1499,y:620,t:1527793799262};\\\", \\\"{x:1498,y:620,t:1527793799308};\\\", \\\"{x:1498,y:619,t:1527793799316};\\\", \\\"{x:1497,y:618,t:1527793799332};\\\", \\\"{x:1497,y:620,t:1527793799509};\\\", \\\"{x:1497,y:622,t:1527793799516};\\\", \\\"{x:1499,y:623,t:1527793799528};\\\", \\\"{x:1502,y:629,t:1527793799545};\\\", \\\"{x:1507,y:634,t:1527793799563};\\\", \\\"{x:1509,y:636,t:1527793799578};\\\", \\\"{x:1511,y:639,t:1527793799595};\\\", \\\"{x:1511,y:644,t:1527793799612};\\\", \\\"{x:1510,y:654,t:1527793799628};\\\", \\\"{x:1505,y:673,t:1527793799645};\\\", \\\"{x:1504,y:677,t:1527793799662};\\\", \\\"{x:1490,y:696,t:1527793799678};\\\", \\\"{x:1483,y:721,t:1527793799695};\\\", \\\"{x:1482,y:728,t:1527793799712};\\\", \\\"{x:1482,y:742,t:1527793799728};\\\", \\\"{x:1482,y:746,t:1527793799745};\\\", \\\"{x:1481,y:751,t:1527793799763};\\\", \\\"{x:1479,y:754,t:1527793799779};\\\", \\\"{x:1479,y:759,t:1527793799795};\\\", \\\"{x:1479,y:762,t:1527793799861};\\\", \\\"{x:1479,y:763,t:1527793799869};\\\", \\\"{x:1479,y:767,t:1527793799884};\\\", \\\"{x:1479,y:768,t:1527793799908};\\\", \\\"{x:1479,y:769,t:1527793799916};\\\", \\\"{x:1479,y:770,t:1527793799929};\\\", \\\"{x:1478,y:773,t:1527793799946};\\\", \\\"{x:1478,y:774,t:1527793799964};\\\", \\\"{x:1478,y:775,t:1527793799979};\\\", \\\"{x:1475,y:781,t:1527793799996};\\\", \\\"{x:1472,y:790,t:1527793800013};\\\", \\\"{x:1471,y:798,t:1527793800029};\\\", \\\"{x:1470,y:800,t:1527793800046};\\\", \\\"{x:1470,y:801,t:1527793800092};\\\", \\\"{x:1469,y:801,t:1527793800100};\\\", \\\"{x:1468,y:802,t:1527793800114};\\\", \\\"{x:1468,y:804,t:1527793800129};\\\", \\\"{x:1468,y:806,t:1527793800147};\\\", \\\"{x:1468,y:807,t:1527793800211};\\\", \\\"{x:1468,y:810,t:1527793800219};\\\", \\\"{x:1468,y:811,t:1527793800229};\\\", \\\"{x:1468,y:815,t:1527793800246};\\\", \\\"{x:1468,y:823,t:1527793800262};\\\", \\\"{x:1470,y:828,t:1527793800279};\\\", \\\"{x:1471,y:831,t:1527793800295};\\\", \\\"{x:1472,y:832,t:1527793800312};\\\", \\\"{x:1473,y:832,t:1527793800524};\\\", \\\"{x:1476,y:832,t:1527793800532};\\\", \\\"{x:1480,y:831,t:1527793800546};\\\", \\\"{x:1486,y:825,t:1527793800563};\\\", \\\"{x:1488,y:821,t:1527793800580};\\\", \\\"{x:1489,y:822,t:1527793800979};\\\", \\\"{x:1489,y:825,t:1527793801003};\\\", \\\"{x:1489,y:826,t:1527793801019};\\\", \\\"{x:1489,y:827,t:1527793801075};\\\", \\\"{x:1488,y:827,t:1527793801164};\\\", \\\"{x:1487,y:827,t:1527793801180};\\\", \\\"{x:1487,y:828,t:1527793801244};\\\", \\\"{x:1486,y:829,t:1527793801259};\\\", \\\"{x:1485,y:829,t:1527793801411};\\\", \\\"{x:1482,y:830,t:1527793801435};\\\", \\\"{x:1481,y:831,t:1527793801492};\\\", \\\"{x:1480,y:832,t:1527793801548};\\\", \\\"{x:1476,y:833,t:1527793803550};\\\", \\\"{x:1472,y:835,t:1527793803565};\\\", \\\"{x:1470,y:836,t:1527793803613};\\\", \\\"{x:1469,y:836,t:1527793803636};\\\", \\\"{x:1467,y:841,t:1527793803648};\\\", \\\"{x:1464,y:845,t:1527793803665};\\\", \\\"{x:1463,y:852,t:1527793803681};\\\", \\\"{x:1462,y:858,t:1527793803698};\\\", \\\"{x:1462,y:859,t:1527793803715};\\\", \\\"{x:1460,y:861,t:1527793803731};\\\", \\\"{x:1459,y:864,t:1527793803748};\\\", \\\"{x:1455,y:871,t:1527793803765};\\\", \\\"{x:1446,y:887,t:1527793803781};\\\", \\\"{x:1438,y:902,t:1527793803798};\\\", \\\"{x:1425,y:913,t:1527793803815};\\\", \\\"{x:1417,y:928,t:1527793803831};\\\", \\\"{x:1408,y:940,t:1527793803848};\\\", \\\"{x:1406,y:947,t:1527793803866};\\\", \\\"{x:1404,y:951,t:1527793803881};\\\", \\\"{x:1401,y:955,t:1527793803898};\\\", \\\"{x:1399,y:960,t:1527793803915};\\\", \\\"{x:1399,y:962,t:1527793803931};\\\", \\\"{x:1399,y:963,t:1527793803948};\\\", \\\"{x:1398,y:964,t:1527793803972};\\\", \\\"{x:1401,y:964,t:1527793804157};\\\", \\\"{x:1402,y:964,t:1527793804165};\\\", \\\"{x:1404,y:964,t:1527793804182};\\\", \\\"{x:1403,y:965,t:1527793804627};\\\", \\\"{x:1402,y:965,t:1527793804643};\\\", \\\"{x:1402,y:966,t:1527793804732};\\\", \\\"{x:1400,y:967,t:1527793804756};\\\", \\\"{x:1400,y:968,t:1527793804796};\\\", \\\"{x:1401,y:968,t:1527793805485};\\\", \\\"{x:1402,y:970,t:1527793805500};\\\", \\\"{x:1405,y:973,t:1527793805516};\\\", \\\"{x:1408,y:974,t:1527793805533};\\\", \\\"{x:1409,y:975,t:1527793805549};\\\", \\\"{x:1409,y:967,t:1527793807437};\\\", \\\"{x:1409,y:960,t:1527793807451};\\\", \\\"{x:1409,y:946,t:1527793807467};\\\", \\\"{x:1406,y:932,t:1527793807483};\\\", \\\"{x:1403,y:917,t:1527793807500};\\\", \\\"{x:1398,y:900,t:1527793807517};\\\", \\\"{x:1392,y:884,t:1527793807533};\\\", \\\"{x:1389,y:873,t:1527793807551};\\\", \\\"{x:1387,y:870,t:1527793807567};\\\", \\\"{x:1385,y:858,t:1527793807583};\\\", \\\"{x:1379,y:847,t:1527793807600};\\\", \\\"{x:1375,y:832,t:1527793807617};\\\", \\\"{x:1374,y:832,t:1527793807633};\\\", \\\"{x:1374,y:831,t:1527793807660};\\\", \\\"{x:1373,y:829,t:1527793807668};\\\", \\\"{x:1371,y:824,t:1527793807684};\\\", \\\"{x:1369,y:820,t:1527793807701};\\\", \\\"{x:1367,y:817,t:1527793807717};\\\", \\\"{x:1367,y:814,t:1527793807734};\\\", \\\"{x:1369,y:802,t:1527793807750};\\\", \\\"{x:1374,y:783,t:1527793807768};\\\", \\\"{x:1379,y:776,t:1527793807783};\\\", \\\"{x:1382,y:772,t:1527793807801};\\\", \\\"{x:1382,y:771,t:1527793807818};\\\", \\\"{x:1382,y:770,t:1527793807834};\\\", \\\"{x:1383,y:769,t:1527793807909};\\\", \\\"{x:1383,y:767,t:1527793807997};\\\", \\\"{x:1384,y:766,t:1527793808017};\\\", \\\"{x:1384,y:764,t:1527793808034};\\\", \\\"{x:1383,y:769,t:1527793810621};\\\", \\\"{x:1384,y:779,t:1527793810636};\\\", \\\"{x:1386,y:799,t:1527793810652};\\\", \\\"{x:1387,y:805,t:1527793810669};\\\", \\\"{x:1387,y:814,t:1527793810686};\\\", \\\"{x:1387,y:817,t:1527793810702};\\\", \\\"{x:1387,y:818,t:1527793810732};\\\", \\\"{x:1387,y:820,t:1527793810828};\\\", \\\"{x:1387,y:827,t:1527793810836};\\\", \\\"{x:1389,y:843,t:1527793810852};\\\", \\\"{x:1392,y:856,t:1527793810868};\\\", \\\"{x:1396,y:895,t:1527793810886};\\\", \\\"{x:1408,y:919,t:1527793810902};\\\", \\\"{x:1415,y:932,t:1527793810918};\\\", \\\"{x:1419,y:940,t:1527793810935};\\\", \\\"{x:1420,y:940,t:1527793810952};\\\", \\\"{x:1421,y:941,t:1527793810968};\\\", \\\"{x:1423,y:943,t:1527793811252};\\\", \\\"{x:1423,y:944,t:1527793811381};\\\", \\\"{x:1419,y:944,t:1527793811388};\\\", \\\"{x:1412,y:943,t:1527793811403};\\\", \\\"{x:1398,y:943,t:1527793811420};\\\", \\\"{x:1397,y:942,t:1527793811436};\\\", \\\"{x:1395,y:942,t:1527793811453};\\\", \\\"{x:1394,y:942,t:1527793811469};\\\", \\\"{x:1392,y:942,t:1527793811524};\\\", \\\"{x:1391,y:943,t:1527793811540};\\\", \\\"{x:1389,y:944,t:1527793811552};\\\", \\\"{x:1387,y:946,t:1527793811569};\\\", \\\"{x:1386,y:946,t:1527793811586};\\\", \\\"{x:1385,y:947,t:1527793811628};\\\", \\\"{x:1384,y:949,t:1527793811636};\\\", \\\"{x:1383,y:953,t:1527793811652};\\\", \\\"{x:1382,y:956,t:1527793811670};\\\", \\\"{x:1380,y:957,t:1527793811686};\\\", \\\"{x:1379,y:959,t:1527793811702};\\\", \\\"{x:1379,y:961,t:1527793811756};\\\", \\\"{x:1379,y:962,t:1527793811769};\\\", \\\"{x:1380,y:966,t:1527793811786};\\\", \\\"{x:1381,y:970,t:1527793811803};\\\", \\\"{x:1381,y:971,t:1527793811820};\\\", \\\"{x:1381,y:972,t:1527793811836};\\\", \\\"{x:1382,y:973,t:1527793811972};\\\", \\\"{x:1383,y:973,t:1527793811986};\\\", \\\"{x:1385,y:972,t:1527793812003};\\\", \\\"{x:1389,y:970,t:1527793812020};\\\", \\\"{x:1390,y:968,t:1527793812044};\\\", \\\"{x:1392,y:966,t:1527793812052};\\\", \\\"{x:1394,y:965,t:1527793812156};\\\", \\\"{x:1395,y:964,t:1527793812180};\\\", \\\"{x:1397,y:963,t:1527793812188};\\\", \\\"{x:1398,y:962,t:1527793812204};\\\", \\\"{x:1400,y:962,t:1527793812220};\\\", \\\"{x:1402,y:960,t:1527793812260};\\\", \\\"{x:1404,y:960,t:1527793812270};\\\", \\\"{x:1407,y:958,t:1527793812287};\\\", \\\"{x:1411,y:956,t:1527793812303};\\\", \\\"{x:1414,y:955,t:1527793812320};\\\", \\\"{x:1418,y:955,t:1527793812337};\\\", \\\"{x:1419,y:955,t:1527793812353};\\\", \\\"{x:1420,y:956,t:1527793812372};\\\", \\\"{x:1421,y:957,t:1527793812396};\\\", \\\"{x:1422,y:957,t:1527793812444};\\\", \\\"{x:1423,y:957,t:1527793812524};\\\", \\\"{x:1425,y:957,t:1527793812940};\\\", \\\"{x:1426,y:957,t:1527793812980};\\\", \\\"{x:1427,y:957,t:1527793813052};\\\", \\\"{x:1428,y:956,t:1527793813076};\\\", \\\"{x:1432,y:955,t:1527793813091};\\\", \\\"{x:1432,y:953,t:1527793813103};\\\", \\\"{x:1437,y:950,t:1527793813120};\\\", \\\"{x:1439,y:950,t:1527793813136};\\\", \\\"{x:1439,y:951,t:1527793813524};\\\", \\\"{x:1439,y:952,t:1527793813556};\\\", \\\"{x:1439,y:953,t:1527793813588};\\\", \\\"{x:1439,y:956,t:1527793813620};\\\", \\\"{x:1439,y:958,t:1527793813635};\\\", \\\"{x:1439,y:960,t:1527793813659};\\\", \\\"{x:1439,y:962,t:1527793813675};\\\", \\\"{x:1439,y:964,t:1527793813699};\\\", \\\"{x:1439,y:965,t:1527793813731};\\\", \\\"{x:1440,y:966,t:1527793813827};\\\", \\\"{x:1442,y:966,t:1527793813915};\\\", \\\"{x:1445,y:966,t:1527793813947};\\\", \\\"{x:1445,y:965,t:1527793813971};\\\", \\\"{x:1446,y:965,t:1527793814027};\\\", \\\"{x:1447,y:964,t:1527793814099};\\\", \\\"{x:1448,y:963,t:1527793814107};\\\", \\\"{x:1450,y:962,t:1527793814120};\\\", \\\"{x:1451,y:960,t:1527793814137};\\\", \\\"{x:1453,y:960,t:1527793814154};\\\", \\\"{x:1453,y:959,t:1527793814169};\\\", \\\"{x:1455,y:958,t:1527793814186};\\\", \\\"{x:1459,y:956,t:1527793814204};\\\", \\\"{x:1463,y:955,t:1527793814220};\\\", \\\"{x:1465,y:953,t:1527793814237};\\\", \\\"{x:1469,y:952,t:1527793814254};\\\", \\\"{x:1470,y:951,t:1527793814270};\\\", \\\"{x:1474,y:948,t:1527793814287};\\\", \\\"{x:1476,y:947,t:1527793814304};\\\", \\\"{x:1479,y:946,t:1527793814320};\\\", \\\"{x:1481,y:945,t:1527793814337};\\\", \\\"{x:1484,y:945,t:1527793814354};\\\", \\\"{x:1489,y:945,t:1527793814369};\\\", \\\"{x:1495,y:945,t:1527793814387};\\\", \\\"{x:1496,y:945,t:1527793814404};\\\", \\\"{x:1497,y:945,t:1527793814691};\\\", \\\"{x:1499,y:945,t:1527793814704};\\\", \\\"{x:1500,y:945,t:1527793814755};\\\", \\\"{x:1502,y:945,t:1527793814771};\\\", \\\"{x:1503,y:947,t:1527793814786};\\\", \\\"{x:1505,y:950,t:1527793814804};\\\", \\\"{x:1506,y:950,t:1527793814820};\\\", \\\"{x:1506,y:951,t:1527793814931};\\\", \\\"{x:1507,y:954,t:1527793814947};\\\", \\\"{x:1508,y:956,t:1527793814963};\\\", \\\"{x:1509,y:957,t:1527793814971};\\\", \\\"{x:1510,y:957,t:1527793815460};\\\", \\\"{x:1512,y:955,t:1527793815475};\\\", \\\"{x:1513,y:954,t:1527793815488};\\\", \\\"{x:1515,y:953,t:1527793815505};\\\", \\\"{x:1518,y:952,t:1527793815521};\\\", \\\"{x:1522,y:949,t:1527793815538};\\\", \\\"{x:1523,y:949,t:1527793815555};\\\", \\\"{x:1525,y:948,t:1527793815572};\\\", \\\"{x:1529,y:946,t:1527793815587};\\\", \\\"{x:1530,y:945,t:1527793815605};\\\", \\\"{x:1533,y:943,t:1527793815622};\\\", \\\"{x:1536,y:941,t:1527793815638};\\\", \\\"{x:1538,y:941,t:1527793815676};\\\", \\\"{x:1539,y:941,t:1527793815689};\\\", \\\"{x:1542,y:941,t:1527793815705};\\\", \\\"{x:1543,y:941,t:1527793815721};\\\", \\\"{x:1545,y:941,t:1527793815739};\\\", \\\"{x:1547,y:941,t:1527793815755};\\\", \\\"{x:1554,y:944,t:1527793815771};\\\", \\\"{x:1557,y:944,t:1527793815789};\\\", \\\"{x:1561,y:946,t:1527793815805};\\\", \\\"{x:1563,y:947,t:1527793815877};\\\", \\\"{x:1565,y:947,t:1527793815889};\\\", \\\"{x:1568,y:948,t:1527793815905};\\\", \\\"{x:1569,y:950,t:1527793815922};\\\", \\\"{x:1571,y:951,t:1527793815939};\\\", \\\"{x:1571,y:952,t:1527793816140};\\\", \\\"{x:1572,y:953,t:1527793816155};\\\", \\\"{x:1572,y:954,t:1527793816180};\\\", \\\"{x:1573,y:956,t:1527793816188};\\\", \\\"{x:1574,y:957,t:1527793816205};\\\", \\\"{x:1577,y:959,t:1527793816244};\\\", \\\"{x:1577,y:960,t:1527793816268};\\\", \\\"{x:1578,y:961,t:1527793816292};\\\", \\\"{x:1578,y:962,t:1527793816306};\\\", \\\"{x:1578,y:963,t:1527793816324};\\\", \\\"{x:1579,y:965,t:1527793816340};\\\", \\\"{x:1581,y:966,t:1527793816356};\\\", \\\"{x:1582,y:966,t:1527793818284};\\\", \\\"{x:1582,y:967,t:1527793818299};\\\", \\\"{x:1579,y:967,t:1527793818308};\\\", \\\"{x:1571,y:967,t:1527793818322};\\\", \\\"{x:1555,y:970,t:1527793818340};\\\", \\\"{x:1543,y:977,t:1527793818356};\\\", \\\"{x:1524,y:983,t:1527793818373};\\\", \\\"{x:1517,y:986,t:1527793818390};\\\", \\\"{x:1515,y:987,t:1527793818407};\\\", \\\"{x:1515,y:988,t:1527793818422};\\\", \\\"{x:1515,y:989,t:1527793818483};\\\", \\\"{x:1515,y:990,t:1527793818490};\\\", \\\"{x:1515,y:991,t:1527793818540};\\\", \\\"{x:1510,y:991,t:1527793818556};\\\", \\\"{x:1500,y:990,t:1527793818572};\\\", \\\"{x:1477,y:983,t:1527793818589};\\\", \\\"{x:1452,y:979,t:1527793818606};\\\", \\\"{x:1450,y:977,t:1527793818623};\\\", \\\"{x:1445,y:977,t:1527793818651};\\\", \\\"{x:1435,y:978,t:1527793818660};\\\", \\\"{x:1432,y:978,t:1527793818673};\\\", \\\"{x:1426,y:978,t:1527793818690};\\\", \\\"{x:1417,y:974,t:1527793818707};\\\", \\\"{x:1401,y:965,t:1527793818724};\\\", \\\"{x:1400,y:965,t:1527793818740};\\\", \\\"{x:1399,y:965,t:1527793818980};\\\", \\\"{x:1397,y:965,t:1527793818989};\\\", \\\"{x:1396,y:964,t:1527793819043};\\\", \\\"{x:1395,y:964,t:1527793819056};\\\", \\\"{x:1392,y:962,t:1527793819075};\\\", \\\"{x:1389,y:961,t:1527793819091};\\\", \\\"{x:1386,y:960,t:1527793819106};\\\", \\\"{x:1382,y:959,t:1527793819123};\\\", \\\"{x:1378,y:956,t:1527793819139};\\\", \\\"{x:1374,y:955,t:1527793819156};\\\", \\\"{x:1369,y:954,t:1527793819174};\\\", \\\"{x:1363,y:950,t:1527793819190};\\\", \\\"{x:1351,y:944,t:1527793819206};\\\", \\\"{x:1339,y:940,t:1527793819224};\\\", \\\"{x:1329,y:938,t:1527793819239};\\\", \\\"{x:1327,y:938,t:1527793819256};\\\", \\\"{x:1325,y:937,t:1527793819274};\\\", \\\"{x:1323,y:937,t:1527793819460};\\\", \\\"{x:1324,y:937,t:1527793819540};\\\", \\\"{x:1331,y:938,t:1527793819557};\\\", \\\"{x:1334,y:939,t:1527793819573};\\\", \\\"{x:1335,y:940,t:1527793819644};\\\", \\\"{x:1335,y:942,t:1527793819660};\\\", \\\"{x:1335,y:943,t:1527793819674};\\\", \\\"{x:1334,y:948,t:1527793819690};\\\", \\\"{x:1333,y:955,t:1527793819707};\\\", \\\"{x:1333,y:961,t:1527793819725};\\\", \\\"{x:1333,y:962,t:1527793819948};\\\", \\\"{x:1333,y:961,t:1527793819979};\\\", \\\"{x:1334,y:960,t:1527793819991};\\\", \\\"{x:1336,y:959,t:1527793820020};\\\", \\\"{x:1339,y:958,t:1527793820028};\\\", \\\"{x:1340,y:957,t:1527793820041};\\\", \\\"{x:1343,y:953,t:1527793820059};\\\", \\\"{x:1348,y:953,t:1527793820073};\\\", \\\"{x:1355,y:955,t:1527793820091};\\\", \\\"{x:1368,y:958,t:1527793820107};\\\", \\\"{x:1375,y:959,t:1527793820123};\\\", \\\"{x:1381,y:959,t:1527793820140};\\\", \\\"{x:1384,y:959,t:1527793820163};\\\", \\\"{x:1387,y:959,t:1527793820173};\\\", \\\"{x:1390,y:959,t:1527793820190};\\\", \\\"{x:1394,y:959,t:1527793820207};\\\", \\\"{x:1395,y:959,t:1527793820275};\\\", \\\"{x:1397,y:959,t:1527793820291};\\\", \\\"{x:1398,y:959,t:1527793820308};\\\", \\\"{x:1399,y:959,t:1527793820380};\\\", \\\"{x:1403,y:959,t:1527793820390};\\\", \\\"{x:1404,y:959,t:1527793820408};\\\", \\\"{x:1406,y:958,t:1527793820779};\\\", \\\"{x:1408,y:958,t:1527793820803};\\\", \\\"{x:1409,y:957,t:1527793820844};\\\", \\\"{x:1409,y:956,t:1527793821020};\\\", \\\"{x:1409,y:955,t:1527793821027};\\\", \\\"{x:1403,y:949,t:1527793821076};\\\", \\\"{x:1398,y:944,t:1527793821091};\\\", \\\"{x:1392,y:937,t:1527793821107};\\\", \\\"{x:1382,y:924,t:1527793821125};\\\", \\\"{x:1374,y:904,t:1527793821142};\\\", \\\"{x:1361,y:888,t:1527793821158};\\\", \\\"{x:1350,y:872,t:1527793821176};\\\", \\\"{x:1345,y:867,t:1527793821192};\\\", \\\"{x:1343,y:866,t:1527793821208};\\\", \\\"{x:1338,y:866,t:1527793821225};\\\", \\\"{x:1334,y:863,t:1527793821242};\\\", \\\"{x:1334,y:862,t:1527793821258};\\\", \\\"{x:1334,y:861,t:1527793821340};\\\", \\\"{x:1333,y:861,t:1527793821355};\\\", \\\"{x:1331,y:857,t:1527793821364};\\\", \\\"{x:1330,y:857,t:1527793821375};\\\", \\\"{x:1325,y:856,t:1527793821392};\\\", \\\"{x:1316,y:853,t:1527793821408};\\\", \\\"{x:1312,y:851,t:1527793821424};\\\", \\\"{x:1311,y:851,t:1527793821442};\\\", \\\"{x:1307,y:847,t:1527793821458};\\\", \\\"{x:1305,y:846,t:1527793821474};\\\", \\\"{x:1304,y:846,t:1527793821492};\\\", \\\"{x:1302,y:845,t:1527793821508};\\\", \\\"{x:1301,y:844,t:1527793821532};\\\", \\\"{x:1299,y:843,t:1527793821629};\\\", \\\"{x:1297,y:842,t:1527793821644};\\\", \\\"{x:1295,y:841,t:1527793821676};\\\", \\\"{x:1294,y:841,t:1527793821690};\\\", \\\"{x:1290,y:838,t:1527793821707};\\\", \\\"{x:1284,y:833,t:1527793821724};\\\", \\\"{x:1274,y:828,t:1527793821742};\\\", \\\"{x:1272,y:828,t:1527793821757};\\\", \\\"{x:1270,y:827,t:1527793821774};\\\", \\\"{x:1268,y:827,t:1527793821794};\\\", \\\"{x:1267,y:827,t:1527793821807};\\\", \\\"{x:1265,y:825,t:1527793821822};\\\", \\\"{x:1263,y:825,t:1527793821840};\\\", \\\"{x:1265,y:825,t:1527793821987};\\\", \\\"{x:1266,y:825,t:1527793822001};\\\", \\\"{x:1267,y:825,t:1527793822010};\\\", \\\"{x:1269,y:824,t:1527793822058};\\\", \\\"{x:1270,y:823,t:1527793822074};\\\", \\\"{x:1272,y:823,t:1527793822090};\\\", \\\"{x:1272,y:822,t:1527793822114};\\\", \\\"{x:1273,y:822,t:1527793822163};\\\", \\\"{x:1275,y:822,t:1527793822174};\\\", \\\"{x:1277,y:822,t:1527793822190};\\\", \\\"{x:1281,y:822,t:1527793822207};\\\", \\\"{x:1281,y:821,t:1527793822387};\\\", \\\"{x:1274,y:821,t:1527793822402};\\\", \\\"{x:1269,y:821,t:1527793822410};\\\", \\\"{x:1253,y:821,t:1527793822424};\\\", \\\"{x:1236,y:818,t:1527793822441};\\\", \\\"{x:1230,y:818,t:1527793822458};\\\", \\\"{x:1225,y:817,t:1527793822474};\\\", \\\"{x:1224,y:817,t:1527793822586};\\\", \\\"{x:1225,y:816,t:1527793822674};\\\", \\\"{x:1237,y:816,t:1527793822690};\\\", \\\"{x:1240,y:816,t:1527793822706};\\\", \\\"{x:1251,y:816,t:1527793822724};\\\", \\\"{x:1261,y:815,t:1527793822740};\\\", \\\"{x:1261,y:814,t:1527793822757};\\\", \\\"{x:1262,y:814,t:1527793822774};\\\", \\\"{x:1261,y:814,t:1527793822906};\\\", \\\"{x:1250,y:814,t:1527793822925};\\\", \\\"{x:1240,y:814,t:1527793822940};\\\", \\\"{x:1237,y:814,t:1527793822957};\\\", \\\"{x:1235,y:814,t:1527793822977};\\\", \\\"{x:1234,y:814,t:1527793822990};\\\", \\\"{x:1239,y:812,t:1527793823057};\\\", \\\"{x:1255,y:810,t:1527793823073};\\\", \\\"{x:1267,y:809,t:1527793823090};\\\", \\\"{x:1275,y:807,t:1527793823107};\\\", \\\"{x:1291,y:802,t:1527793823124};\\\", \\\"{x:1293,y:801,t:1527793823140};\\\", \\\"{x:1295,y:799,t:1527793823315};\\\", \\\"{x:1297,y:781,t:1527793823323};\\\", \\\"{x:1312,y:713,t:1527793823341};\\\", \\\"{x:1326,y:648,t:1527793823356};\\\", \\\"{x:1343,y:615,t:1527793823374};\\\", \\\"{x:1352,y:587,t:1527793823390};\\\", \\\"{x:1365,y:569,t:1527793823407};\\\", \\\"{x:1365,y:566,t:1527793823424};\\\", \\\"{x:1367,y:560,t:1527793823441};\\\", \\\"{x:1367,y:554,t:1527793823457};\\\", \\\"{x:1368,y:541,t:1527793823474};\\\", \\\"{x:1372,y:522,t:1527793823491};\\\", \\\"{x:1376,y:511,t:1527793823507};\\\", \\\"{x:1379,y:502,t:1527793823524};\\\", \\\"{x:1379,y:494,t:1527793823541};\\\", \\\"{x:1380,y:490,t:1527793823557};\\\", \\\"{x:1380,y:486,t:1527793823574};\\\", \\\"{x:1380,y:482,t:1527793823591};\\\", \\\"{x:1380,y:481,t:1527793823618};\\\", \\\"{x:1380,y:480,t:1527793823626};\\\", \\\"{x:1379,y:479,t:1527793823642};\\\", \\\"{x:1378,y:478,t:1527793823658};\\\", \\\"{x:1377,y:477,t:1527793823674};\\\", \\\"{x:1376,y:477,t:1527793823698};\\\", \\\"{x:1374,y:477,t:1527793823714};\\\", \\\"{x:1372,y:477,t:1527793823724};\\\", \\\"{x:1369,y:477,t:1527793823741};\\\", \\\"{x:1365,y:477,t:1527793823757};\\\", \\\"{x:1362,y:480,t:1527793823774};\\\", \\\"{x:1358,y:482,t:1527793823791};\\\", \\\"{x:1355,y:485,t:1527793823809};\\\", \\\"{x:1351,y:487,t:1527793823824};\\\", \\\"{x:1344,y:490,t:1527793823841};\\\", \\\"{x:1331,y:496,t:1527793823857};\\\", \\\"{x:1326,y:499,t:1527793823874};\\\", \\\"{x:1321,y:502,t:1527793823891};\\\", \\\"{x:1320,y:502,t:1527793823907};\\\", \\\"{x:1318,y:503,t:1527793823924};\\\", \\\"{x:1317,y:503,t:1527793823941};\\\", \\\"{x:1316,y:503,t:1527793823961};\\\", \\\"{x:1316,y:504,t:1527793823978};\\\", \\\"{x:1315,y:504,t:1527793823993};\\\", \\\"{x:1314,y:504,t:1527793824008};\\\", \\\"{x:1311,y:505,t:1527793824024};\\\", \\\"{x:1310,y:505,t:1527793824171};\\\", \\\"{x:1310,y:504,t:1527793824307};\\\", \\\"{x:1310,y:503,t:1527793824355};\\\", \\\"{x:1310,y:501,t:1527793824362};\\\", \\\"{x:1310,y:499,t:1527793824395};\\\", \\\"{x:1311,y:498,t:1527793825170};\\\", \\\"{x:1312,y:499,t:1527793825178};\\\", \\\"{x:1312,y:507,t:1527793825193};\\\", \\\"{x:1312,y:522,t:1527793825207};\\\", \\\"{x:1315,y:536,t:1527793825224};\\\", \\\"{x:1315,y:540,t:1527793825242};\\\", \\\"{x:1316,y:546,t:1527793825257};\\\", \\\"{x:1316,y:564,t:1527793825275};\\\", \\\"{x:1316,y:579,t:1527793825291};\\\", \\\"{x:1315,y:589,t:1527793825307};\\\", \\\"{x:1314,y:598,t:1527793825324};\\\", \\\"{x:1314,y:601,t:1527793825341};\\\", \\\"{x:1313,y:606,t:1527793825358};\\\", \\\"{x:1313,y:608,t:1527793825375};\\\", \\\"{x:1311,y:609,t:1527793825391};\\\", \\\"{x:1311,y:610,t:1527793825497};\\\", \\\"{x:1311,y:611,t:1527793825508};\\\", \\\"{x:1309,y:617,t:1527793825525};\\\", \\\"{x:1308,y:623,t:1527793825545};\\\", \\\"{x:1307,y:627,t:1527793825559};\\\", \\\"{x:1306,y:636,t:1527793825574};\\\", \\\"{x:1305,y:643,t:1527793825592};\\\", \\\"{x:1305,y:655,t:1527793825609};\\\", \\\"{x:1305,y:657,t:1527793825624};\\\", \\\"{x:1305,y:656,t:1527793825793};\\\", \\\"{x:1307,y:653,t:1527793825809};\\\", \\\"{x:1308,y:651,t:1527793825825};\\\", \\\"{x:1309,y:650,t:1527793825842};\\\", \\\"{x:1310,y:649,t:1527793825859};\\\", \\\"{x:1310,y:648,t:1527793825875};\\\", \\\"{x:1311,y:646,t:1527793825905};\\\", \\\"{x:1312,y:645,t:1527793825929};\\\", \\\"{x:1312,y:644,t:1527793825945};\\\", \\\"{x:1313,y:643,t:1527793825960};\\\", \\\"{x:1315,y:640,t:1527793826033};\\\", \\\"{x:1315,y:638,t:1527793826041};\\\", \\\"{x:1318,y:634,t:1527793826060};\\\", \\\"{x:1318,y:632,t:1527793826092};\\\", \\\"{x:1318,y:631,t:1527793826109};\\\", \\\"{x:1320,y:628,t:1527793826125};\\\", \\\"{x:1321,y:627,t:1527793826143};\\\", \\\"{x:1323,y:625,t:1527793826195};\\\", \\\"{x:1324,y:625,t:1527793826331};\\\", \\\"{x:1324,y:630,t:1527793826343};\\\", \\\"{x:1324,y:649,t:1527793826359};\\\", \\\"{x:1324,y:666,t:1527793826377};\\\", \\\"{x:1324,y:691,t:1527793826393};\\\", \\\"{x:1325,y:707,t:1527793826409};\\\", \\\"{x:1334,y:732,t:1527793826426};\\\", \\\"{x:1337,y:750,t:1527793826442};\\\", \\\"{x:1341,y:768,t:1527793826459};\\\", \\\"{x:1344,y:773,t:1527793826477};\\\", \\\"{x:1348,y:787,t:1527793826492};\\\", \\\"{x:1350,y:798,t:1527793826509};\\\", \\\"{x:1352,y:812,t:1527793826526};\\\", \\\"{x:1352,y:815,t:1527793826542};\\\", \\\"{x:1352,y:818,t:1527793826559};\\\", \\\"{x:1352,y:824,t:1527793826576};\\\", \\\"{x:1352,y:827,t:1527793826592};\\\", \\\"{x:1352,y:832,t:1527793826609};\\\", \\\"{x:1351,y:856,t:1527793826625};\\\", \\\"{x:1346,y:871,t:1527793826642};\\\", \\\"{x:1339,y:879,t:1527793826660};\\\", \\\"{x:1335,y:886,t:1527793826676};\\\", \\\"{x:1327,y:896,t:1527793826692};\\\", \\\"{x:1319,y:913,t:1527793826709};\\\", \\\"{x:1312,y:921,t:1527793826726};\\\", \\\"{x:1312,y:923,t:1527793826742};\\\", \\\"{x:1311,y:927,t:1527793826759};\\\", \\\"{x:1310,y:928,t:1527793826776};\\\", \\\"{x:1307,y:929,t:1527793826792};\\\", \\\"{x:1307,y:931,t:1527793826810};\\\", \\\"{x:1308,y:931,t:1527793826939};\\\", \\\"{x:1310,y:933,t:1527793826946};\\\", \\\"{x:1311,y:934,t:1527793826959};\\\", \\\"{x:1312,y:935,t:1527793826977};\\\", \\\"{x:1312,y:938,t:1527793827018};\\\", \\\"{x:1313,y:941,t:1527793827026};\\\", \\\"{x:1314,y:949,t:1527793827043};\\\", \\\"{x:1320,y:963,t:1527793827060};\\\", \\\"{x:1321,y:965,t:1527793827076};\\\", \\\"{x:1323,y:965,t:1527793827642};\\\", \\\"{x:1324,y:965,t:1527793827665};\\\", \\\"{x:1326,y:964,t:1527793827723};\\\", \\\"{x:1329,y:964,t:1527793827753};\\\", \\\"{x:1331,y:964,t:1527793827761};\\\", \\\"{x:1333,y:964,t:1527793827793};\\\", \\\"{x:1336,y:964,t:1527793827825};\\\", \\\"{x:1338,y:964,t:1527793827833};\\\", \\\"{x:1339,y:964,t:1527793827843};\\\", \\\"{x:1341,y:964,t:1527793827860};\\\", \\\"{x:1343,y:964,t:1527793827921};\\\", \\\"{x:1344,y:964,t:1527793827938};\\\", \\\"{x:1346,y:964,t:1527793827962};\\\", \\\"{x:1346,y:963,t:1527793827976};\\\", \\\"{x:1347,y:963,t:1527793827993};\\\", \\\"{x:1350,y:962,t:1527793828018};\\\", \\\"{x:1351,y:962,t:1527793828033};\\\", \\\"{x:1352,y:962,t:1527793828043};\\\", \\\"{x:1353,y:962,t:1527793828060};\\\", \\\"{x:1355,y:961,t:1527793828076};\\\", \\\"{x:1356,y:960,t:1527793828094};\\\", \\\"{x:1357,y:959,t:1527793828110};\\\", \\\"{x:1358,y:958,t:1527793828127};\\\", \\\"{x:1359,y:958,t:1527793828143};\\\", \\\"{x:1363,y:958,t:1527793828160};\\\", \\\"{x:1365,y:958,t:1527793828176};\\\", \\\"{x:1368,y:958,t:1527793828193};\\\", \\\"{x:1369,y:958,t:1527793828610};\\\", \\\"{x:1374,y:957,t:1527793828628};\\\", \\\"{x:1376,y:957,t:1527793828650};\\\", \\\"{x:1378,y:957,t:1527793828660};\\\", \\\"{x:1380,y:956,t:1527793828678};\\\", \\\"{x:1387,y:956,t:1527793828694};\\\", \\\"{x:1395,y:957,t:1527793828711};\\\", \\\"{x:1402,y:960,t:1527793828727};\\\", \\\"{x:1411,y:963,t:1527793828744};\\\", \\\"{x:1414,y:964,t:1527793828761};\\\", \\\"{x:1423,y:966,t:1527793828778};\\\", \\\"{x:1426,y:967,t:1527793828793};\\\", \\\"{x:1427,y:967,t:1527793828811};\\\", \\\"{x:1428,y:967,t:1527793828833};\\\", \\\"{x:1432,y:967,t:1527793828845};\\\", \\\"{x:1437,y:967,t:1527793828861};\\\", \\\"{x:1441,y:969,t:1527793828877};\\\", \\\"{x:1442,y:969,t:1527793828893};\\\", \\\"{x:1444,y:969,t:1527793828911};\\\", \\\"{x:1444,y:970,t:1527793828978};\\\", \\\"{x:1445,y:970,t:1527793829250};\\\", \\\"{x:1446,y:970,t:1527793829261};\\\", \\\"{x:1447,y:970,t:1527793829278};\\\", \\\"{x:1452,y:970,t:1527793829294};\\\", \\\"{x:1455,y:970,t:1527793829311};\\\", \\\"{x:1462,y:967,t:1527793829328};\\\", \\\"{x:1465,y:967,t:1527793829345};\\\", \\\"{x:1468,y:965,t:1527793829360};\\\", \\\"{x:1472,y:963,t:1527793829378};\\\", \\\"{x:1477,y:959,t:1527793829394};\\\", \\\"{x:1480,y:959,t:1527793829411};\\\", \\\"{x:1481,y:959,t:1527793829427};\\\", \\\"{x:1481,y:958,t:1527793829444};\\\", \\\"{x:1485,y:958,t:1527793829482};\\\", \\\"{x:1493,y:958,t:1527793829495};\\\", \\\"{x:1499,y:958,t:1527793829511};\\\", \\\"{x:1505,y:958,t:1527793829528};\\\", \\\"{x:1506,y:958,t:1527793829544};\\\", \\\"{x:1509,y:958,t:1527793829561};\\\", \\\"{x:1510,y:958,t:1527793829642};\\\", \\\"{x:1511,y:958,t:1527793829649};\\\", \\\"{x:1514,y:958,t:1527793829661};\\\", \\\"{x:1517,y:958,t:1527793829678};\\\", \\\"{x:1521,y:960,t:1527793829695};\\\", \\\"{x:1522,y:960,t:1527793830169};\\\", \\\"{x:1523,y:960,t:1527793830193};\\\", \\\"{x:1526,y:961,t:1527793830241};\\\", \\\"{x:1530,y:961,t:1527793830257};\\\", \\\"{x:1532,y:963,t:1527793830265};\\\", \\\"{x:1535,y:963,t:1527793830281};\\\", \\\"{x:1537,y:963,t:1527793830294};\\\", \\\"{x:1541,y:963,t:1527793830310};\\\", \\\"{x:1543,y:963,t:1527793830328};\\\", \\\"{x:1544,y:963,t:1527793830378};\\\", \\\"{x:1545,y:963,t:1527793830394};\\\", \\\"{x:1546,y:964,t:1527793830411};\\\", \\\"{x:1548,y:965,t:1527793830428};\\\", \\\"{x:1552,y:965,t:1527793830444};\\\", \\\"{x:1554,y:965,t:1527793830461};\\\", \\\"{x:1559,y:965,t:1527793830478};\\\", \\\"{x:1560,y:965,t:1527793830494};\\\", \\\"{x:1562,y:965,t:1527793830514};\\\", \\\"{x:1563,y:965,t:1527793830538};\\\", \\\"{x:1564,y:965,t:1527793830545};\\\", \\\"{x:1569,y:965,t:1527793830561};\\\", \\\"{x:1573,y:965,t:1527793830577};\\\", \\\"{x:1576,y:966,t:1527793830594};\\\", \\\"{x:1577,y:967,t:1527793830611};\\\", \\\"{x:1579,y:967,t:1527793830628};\\\", \\\"{x:1582,y:967,t:1527793830644};\\\", \\\"{x:1584,y:967,t:1527793831002};\\\", \\\"{x:1588,y:967,t:1527793831012};\\\", \\\"{x:1592,y:967,t:1527793831028};\\\", \\\"{x:1597,y:967,t:1527793831045};\\\", \\\"{x:1602,y:967,t:1527793831061};\\\", \\\"{x:1605,y:970,t:1527793831079};\\\", \\\"{x:1606,y:971,t:1527793831096};\\\", \\\"{x:1609,y:971,t:1527793831112};\\\", \\\"{x:1611,y:972,t:1527793831128};\\\", \\\"{x:1616,y:972,t:1527793831146};\\\", \\\"{x:1620,y:972,t:1527793831162};\\\", \\\"{x:1624,y:972,t:1527793831178};\\\", \\\"{x:1625,y:972,t:1527793831202};\\\", \\\"{x:1626,y:972,t:1527793831226};\\\", \\\"{x:1627,y:972,t:1527793831234};\\\", \\\"{x:1628,y:972,t:1527793831245};\\\", \\\"{x:1629,y:972,t:1527793831282};\\\", \\\"{x:1629,y:971,t:1527793831346};\\\", \\\"{x:1630,y:970,t:1527793831363};\\\", \\\"{x:1632,y:969,t:1527793831386};\\\", \\\"{x:1632,y:968,t:1527793831396};\\\", \\\"{x:1633,y:967,t:1527793831411};\\\", \\\"{x:1634,y:967,t:1527793831474};\\\", \\\"{x:1635,y:967,t:1527793831482};\\\", \\\"{x:1636,y:966,t:1527793831738};\\\", \\\"{x:1636,y:964,t:1527793831779};\\\", \\\"{x:1635,y:954,t:1527793831796};\\\", \\\"{x:1635,y:951,t:1527793831813};\\\", \\\"{x:1634,y:950,t:1527793832185};\\\", \\\"{x:1632,y:950,t:1527793832195};\\\", \\\"{x:1629,y:947,t:1527793832649};\\\", \\\"{x:1624,y:940,t:1527793832662};\\\", \\\"{x:1609,y:921,t:1527793832679};\\\", \\\"{x:1594,y:907,t:1527793832696};\\\", \\\"{x:1564,y:880,t:1527793832712};\\\", \\\"{x:1464,y:809,t:1527793832729};\\\", \\\"{x:1375,y:769,t:1527793832745};\\\", \\\"{x:1259,y:732,t:1527793832762};\\\", \\\"{x:1146,y:706,t:1527793832779};\\\", \\\"{x:1046,y:676,t:1527793832796};\\\", \\\"{x:958,y:655,t:1527793832812};\\\", \\\"{x:846,y:635,t:1527793832829};\\\", \\\"{x:732,y:618,t:1527793832846};\\\", \\\"{x:639,y:623,t:1527793832863};\\\", \\\"{x:584,y:620,t:1527793832879};\\\", \\\"{x:577,y:615,t:1527793832897};\\\", \\\"{x:561,y:615,t:1527793832912};\\\", \\\"{x:547,y:615,t:1527793832929};\\\", \\\"{x:544,y:615,t:1527793832945};\\\", \\\"{x:543,y:615,t:1527793832962};\\\", \\\"{x:542,y:615,t:1527793832979};\\\", \\\"{x:541,y:615,t:1527793833001};\\\", \\\"{x:539,y:615,t:1527793833012};\\\", \\\"{x:523,y:608,t:1527793833030};\\\", \\\"{x:506,y:605,t:1527793833046};\\\", \\\"{x:494,y:602,t:1527793833063};\\\", \\\"{x:492,y:602,t:1527793833434};\\\", \\\"{x:491,y:604,t:1527793833445};\\\", \\\"{x:497,y:614,t:1527793833463};\\\", \\\"{x:505,y:630,t:1527793833478};\\\", \\\"{x:508,y:650,t:1527793833496};\\\", \\\"{x:509,y:674,t:1527793833512};\\\", \\\"{x:510,y:688,t:1527793833529};\\\", \\\"{x:508,y:693,t:1527793833545};\\\", \\\"{x:508,y:694,t:1527793833561};\\\", \\\"{x:508,y:695,t:1527793833579};\\\", \\\"{x:508,y:697,t:1527793833762};\\\", \\\"{x:508,y:699,t:1527793833777};\\\", \\\"{x:508,y:700,t:1527793833850};\\\", \\\"{x:510,y:703,t:1527793834068};\\\", \\\"{x:512,y:704,t:1527793834080};\\\", \\\"{x:513,y:706,t:1527793834096};\\\", \\\"{x:514,y:707,t:1527793834113};\\\", \\\"{x:516,y:709,t:1527793834130};\\\", \\\"{x:517,y:710,t:1527793834145};\\\", \\\"{x:519,y:712,t:1527793834241};\\\", \\\"{x:520,y:713,t:1527793834402};\\\" ] }, { \\\"rt\\\": 141398, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 503248, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:713,t:1527793843466};\\\", \\\"{x:525,y:713,t:1527793843486};\\\", \\\"{x:530,y:710,t:1527793843504};\\\", \\\"{x:542,y:705,t:1527793843520};\\\", \\\"{x:556,y:697,t:1527793843536};\\\", \\\"{x:596,y:678,t:1527793843553};\\\", \\\"{x:608,y:672,t:1527793843571};\\\", \\\"{x:628,y:663,t:1527793843587};\\\", \\\"{x:696,y:662,t:1527793843604};\\\", \\\"{x:744,y:662,t:1527793843621};\\\", \\\"{x:826,y:658,t:1527793843638};\\\", \\\"{x:893,y:658,t:1527793843655};\\\", \\\"{x:947,y:653,t:1527793843671};\\\", \\\"{x:1015,y:648,t:1527793843687};\\\", \\\"{x:1098,y:639,t:1527793843704};\\\", \\\"{x:1125,y:632,t:1527793843720};\\\", \\\"{x:1165,y:632,t:1527793843737};\\\", \\\"{x:1171,y:631,t:1527793843755};\\\", \\\"{x:1181,y:629,t:1527793843771};\\\", \\\"{x:1191,y:629,t:1527793843787};\\\", \\\"{x:1206,y:630,t:1527793843805};\\\", \\\"{x:1218,y:639,t:1527793843820};\\\", \\\"{x:1241,y:642,t:1527793843838};\\\", \\\"{x:1264,y:642,t:1527793843855};\\\", \\\"{x:1331,y:642,t:1527793843870};\\\", \\\"{x:1425,y:656,t:1527793843887};\\\", \\\"{x:1506,y:668,t:1527793843905};\\\", \\\"{x:1537,y:679,t:1527793843921};\\\", \\\"{x:1549,y:685,t:1527793843938};\\\", \\\"{x:1553,y:691,t:1527793843954};\\\", \\\"{x:1555,y:694,t:1527793843972};\\\", \\\"{x:1555,y:703,t:1527793843988};\\\", \\\"{x:1560,y:719,t:1527793844005};\\\", \\\"{x:1560,y:737,t:1527793844022};\\\", \\\"{x:1560,y:750,t:1527793844038};\\\", \\\"{x:1558,y:765,t:1527793844055};\\\", \\\"{x:1550,y:782,t:1527793844072};\\\", \\\"{x:1545,y:795,t:1527793844088};\\\", \\\"{x:1539,y:805,t:1527793844105};\\\", \\\"{x:1531,y:822,t:1527793844122};\\\", \\\"{x:1528,y:824,t:1527793844138};\\\", \\\"{x:1523,y:835,t:1527793844155};\\\", \\\"{x:1519,y:843,t:1527793844172};\\\", \\\"{x:1517,y:848,t:1527793844188};\\\", \\\"{x:1516,y:851,t:1527793844205};\\\", \\\"{x:1515,y:853,t:1527793844222};\\\", \\\"{x:1515,y:854,t:1527793844238};\\\", \\\"{x:1515,y:855,t:1527793844281};\\\", \\\"{x:1515,y:856,t:1527793844370};\\\", \\\"{x:1519,y:856,t:1527793844377};\\\", \\\"{x:1521,y:853,t:1527793844389};\\\", \\\"{x:1525,y:848,t:1527793844405};\\\", \\\"{x:1539,y:825,t:1527793844426};\\\", \\\"{x:1559,y:760,t:1527793844453};\\\", \\\"{x:1559,y:740,t:1527793844456};\\\", \\\"{x:1560,y:728,t:1527793844471};\\\", \\\"{x:1566,y:708,t:1527793844488};\\\", \\\"{x:1569,y:690,t:1527793844504};\\\", \\\"{x:1571,y:681,t:1527793844521};\\\", \\\"{x:1572,y:670,t:1527793844538};\\\", \\\"{x:1574,y:661,t:1527793844554};\\\", \\\"{x:1574,y:656,t:1527793844571};\\\", \\\"{x:1574,y:653,t:1527793844589};\\\", \\\"{x:1575,y:652,t:1527793844682};\\\", \\\"{x:1575,y:651,t:1527793844689};\\\", \\\"{x:1577,y:649,t:1527793844705};\\\", \\\"{x:1579,y:645,t:1527793844722};\\\", \\\"{x:1582,y:640,t:1527793844739};\\\", \\\"{x:1588,y:632,t:1527793844756};\\\", \\\"{x:1593,y:622,t:1527793844772};\\\", \\\"{x:1602,y:612,t:1527793844789};\\\", \\\"{x:1609,y:590,t:1527793844806};\\\", \\\"{x:1619,y:569,t:1527793844822};\\\", \\\"{x:1622,y:558,t:1527793844840};\\\", \\\"{x:1624,y:543,t:1527793844856};\\\", \\\"{x:1625,y:532,t:1527793844872};\\\", \\\"{x:1625,y:516,t:1527793844889};\\\", \\\"{x:1618,y:497,t:1527793844905};\\\", \\\"{x:1609,y:482,t:1527793844921};\\\", \\\"{x:1605,y:473,t:1527793844938};\\\", \\\"{x:1604,y:468,t:1527793844955};\\\", \\\"{x:1597,y:459,t:1527793844971};\\\", \\\"{x:1590,y:448,t:1527793844988};\\\", \\\"{x:1582,y:440,t:1527793845005};\\\", \\\"{x:1575,y:436,t:1527793845021};\\\", \\\"{x:1569,y:432,t:1527793845039};\\\", \\\"{x:1562,y:428,t:1527793845074};\\\", \\\"{x:1559,y:427,t:1527793845089};\\\", \\\"{x:1554,y:426,t:1527793845105};\\\", \\\"{x:1553,y:426,t:1527793845122};\\\", \\\"{x:1550,y:425,t:1527793845139};\\\", \\\"{x:1545,y:425,t:1527793845156};\\\", \\\"{x:1542,y:425,t:1527793845173};\\\", \\\"{x:1525,y:425,t:1527793845188};\\\", \\\"{x:1515,y:429,t:1527793845205};\\\", \\\"{x:1493,y:434,t:1527793845222};\\\", \\\"{x:1462,y:444,t:1527793845238};\\\", \\\"{x:1437,y:450,t:1527793845255};\\\", \\\"{x:1392,y:456,t:1527793845272};\\\", \\\"{x:1374,y:466,t:1527793845288};\\\", \\\"{x:1354,y:483,t:1527793845305};\\\", \\\"{x:1343,y:491,t:1527793845322};\\\", \\\"{x:1339,y:494,t:1527793845345};\\\", \\\"{x:1338,y:494,t:1527793845355};\\\", \\\"{x:1338,y:495,t:1527793845578};\\\", \\\"{x:1336,y:496,t:1527793845590};\\\", \\\"{x:1328,y:496,t:1527793845606};\\\", \\\"{x:1317,y:496,t:1527793845623};\\\", \\\"{x:1312,y:496,t:1527793845640};\\\", \\\"{x:1308,y:497,t:1527793845656};\\\", \\\"{x:1304,y:497,t:1527793942979};\\\", \\\"{x:1301,y:497,t:1527793942986};\\\", \\\"{x:1278,y:494,t:1527793942999};\\\", \\\"{x:1228,y:488,t:1527793943016};\\\", \\\"{x:1212,y:483,t:1527793943032};\\\", \\\"{x:1203,y:480,t:1527793943048};\\\", \\\"{x:1156,y:465,t:1527793943066};\\\", \\\"{x:1144,y:464,t:1527793943083};\\\", \\\"{x:1141,y:464,t:1527793943098};\\\", \\\"{x:1137,y:463,t:1527793943116};\\\", \\\"{x:1133,y:463,t:1527793943133};\\\", \\\"{x:1130,y:463,t:1527793943150};\\\", \\\"{x:1120,y:466,t:1527793943166};\\\", \\\"{x:1106,y:471,t:1527793943183};\\\", \\\"{x:1091,y:483,t:1527793943199};\\\", \\\"{x:1071,y:503,t:1527793943216};\\\", \\\"{x:1052,y:518,t:1527793943233};\\\", \\\"{x:1030,y:529,t:1527793943250};\\\", \\\"{x:1024,y:538,t:1527793943266};\\\", \\\"{x:988,y:556,t:1527793943283};\\\", \\\"{x:979,y:559,t:1527793943300};\\\", \\\"{x:950,y:559,t:1527793943316};\\\", \\\"{x:908,y:559,t:1527793943333};\\\", \\\"{x:894,y:559,t:1527793943353};\\\", \\\"{x:877,y:559,t:1527793943370};\\\", \\\"{x:845,y:547,t:1527793943387};\\\", \\\"{x:795,y:535,t:1527793943404};\\\", \\\"{x:770,y:522,t:1527793943421};\\\", \\\"{x:750,y:514,t:1527793943437};\\\", \\\"{x:732,y:509,t:1527793943454};\\\", \\\"{x:728,y:509,t:1527793943471};\\\", \\\"{x:722,y:509,t:1527793943486};\\\", \\\"{x:720,y:509,t:1527793943503};\\\", \\\"{x:716,y:509,t:1527793943521};\\\", \\\"{x:709,y:513,t:1527793943536};\\\", \\\"{x:705,y:518,t:1527793943554};\\\", \\\"{x:687,y:541,t:1527793943571};\\\", \\\"{x:670,y:560,t:1527793943588};\\\", \\\"{x:656,y:572,t:1527793943604};\\\", \\\"{x:645,y:579,t:1527793943621};\\\", \\\"{x:639,y:585,t:1527793943637};\\\", \\\"{x:634,y:591,t:1527793943654};\\\", \\\"{x:630,y:598,t:1527793943671};\\\", \\\"{x:628,y:602,t:1527793943688};\\\", \\\"{x:628,y:603,t:1527793943704};\\\", \\\"{x:628,y:605,t:1527793943755};\\\", \\\"{x:623,y:610,t:1527793943770};\\\", \\\"{x:622,y:612,t:1527793943788};\\\", \\\"{x:622,y:612,t:1527793944012};\\\", \\\"{x:622,y:613,t:1527793944195};\\\", \\\"{x:624,y:614,t:1527793944204};\\\", \\\"{x:637,y:610,t:1527793944221};\\\", \\\"{x:655,y:611,t:1527793944238};\\\", \\\"{x:695,y:612,t:1527793944254};\\\", \\\"{x:827,y:644,t:1527793944271};\\\", \\\"{x:904,y:662,t:1527793944288};\\\", \\\"{x:950,y:683,t:1527793944305};\\\", \\\"{x:995,y:699,t:1527793944321};\\\", \\\"{x:1008,y:705,t:1527793944338};\\\", \\\"{x:1010,y:705,t:1527793944354};\\\", \\\"{x:1011,y:705,t:1527793973570};\\\", \\\"{x:985,y:720,t:1527793976010};\\\", \\\"{x:854,y:776,t:1527793976022};\\\", \\\"{x:664,y:910,t:1527793976039};\\\", \\\"{x:468,y:1077,t:1527793976056};\\\", \\\"{x:377,y:1172,t:1527793976072};\\\", \\\"{x:376,y:1177,t:1527793976089};\\\", \\\"{x:376,y:1178,t:1527793976106};\\\", \\\"{x:375,y:1178,t:1527793976338};\\\", \\\"{x:374,y:1178,t:1527793976345};\\\", \\\"{x:367,y:1173,t:1527793976356};\\\", \\\"{x:355,y:1145,t:1527793976372};\\\", \\\"{x:353,y:1105,t:1527793976389};\\\", \\\"{x:359,y:1020,t:1527793976406};\\\", \\\"{x:362,y:936,t:1527793976422};\\\", \\\"{x:364,y:916,t:1527793976439};\\\", \\\"{x:364,y:912,t:1527793976456};\\\", \\\"{x:362,y:907,t:1527793976472};\\\", \\\"{x:354,y:893,t:1527793976489};\\\", \\\"{x:353,y:893,t:1527793976505};\\\", \\\"{x:337,y:884,t:1527793976522};\\\", \\\"{x:331,y:878,t:1527793976539};\\\", \\\"{x:331,y:877,t:1527793976562};\\\", \\\"{x:333,y:875,t:1527793976610};\\\", \\\"{x:333,y:874,t:1527793976623};\\\", \\\"{x:354,y:861,t:1527793976638};\\\", \\\"{x:379,y:849,t:1527793976656};\\\", \\\"{x:406,y:828,t:1527793976673};\\\", \\\"{x:425,y:810,t:1527793976689};\\\", \\\"{x:446,y:776,t:1527793976706};\\\", \\\"{x:451,y:766,t:1527793976723};\\\", \\\"{x:453,y:759,t:1527793976738};\\\", \\\"{x:453,y:756,t:1527793976755};\\\", \\\"{x:453,y:752,t:1527793976786};\\\", \\\"{x:455,y:748,t:1527793976794};\\\", \\\"{x:459,y:742,t:1527793976806};\\\", \\\"{x:467,y:735,t:1527793976823};\\\", \\\"{x:470,y:730,t:1527793976847};\\\", \\\"{x:473,y:724,t:1527793976864};\\\", \\\"{x:475,y:721,t:1527793976881};\\\", \\\"{x:478,y:718,t:1527793976897};\\\", \\\"{x:484,y:719,t:1527793977762};\\\", \\\"{x:498,y:719,t:1527793977769};\\\", \\\"{x:516,y:719,t:1527793977781};\\\", \\\"{x:551,y:719,t:1527793977798};\\\", \\\"{x:556,y:719,t:1527793977814};\\\", \\\"{x:590,y:714,t:1527793977830};\\\", \\\"{x:596,y:712,t:1527793977848};\\\" ] }, { \\\"rt\\\": 25341, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 530141, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:596,y:711,t:1527793987730};\\\", \\\"{x:597,y:711,t:1527793987762};\\\", \\\"{x:598,y:710,t:1527793987777};\\\", \\\"{x:600,y:709,t:1527793987788};\\\", \\\"{x:602,y:707,t:1527793987806};\\\", \\\"{x:604,y:705,t:1527793987825};\\\", \\\"{x:605,y:705,t:1527793987838};\\\", \\\"{x:606,y:704,t:1527793987855};\\\", \\\"{x:610,y:704,t:1527793987872};\\\", \\\"{x:618,y:701,t:1527793987888};\\\", \\\"{x:643,y:695,t:1527793987905};\\\", \\\"{x:667,y:688,t:1527793987922};\\\", \\\"{x:693,y:679,t:1527793987939};\\\", \\\"{x:722,y:668,t:1527793987955};\\\", \\\"{x:788,y:651,t:1527793987972};\\\", \\\"{x:870,y:634,t:1527793987988};\\\", \\\"{x:930,y:608,t:1527793988006};\\\", \\\"{x:1015,y:589,t:1527793988023};\\\", \\\"{x:1095,y:568,t:1527793988040};\\\", \\\"{x:1153,y:553,t:1527793988057};\\\", \\\"{x:1185,y:547,t:1527793988072};\\\", \\\"{x:1226,y:540,t:1527793988089};\\\", \\\"{x:1262,y:536,t:1527793988107};\\\", \\\"{x:1282,y:532,t:1527793988122};\\\", \\\"{x:1299,y:529,t:1527793988139};\\\", \\\"{x:1360,y:515,t:1527793988156};\\\", \\\"{x:1384,y:504,t:1527793988174};\\\", \\\"{x:1392,y:505,t:1527793988189};\\\", \\\"{x:1410,y:503,t:1527793988207};\\\", \\\"{x:1416,y:503,t:1527793988224};\\\", \\\"{x:1413,y:503,t:1527793988291};\\\", \\\"{x:1394,y:511,t:1527793988306};\\\", \\\"{x:1385,y:521,t:1527793988323};\\\", \\\"{x:1353,y:538,t:1527793988339};\\\", \\\"{x:1336,y:546,t:1527793988356};\\\", \\\"{x:1321,y:556,t:1527793988373};\\\", \\\"{x:1316,y:557,t:1527793988390};\\\", \\\"{x:1314,y:558,t:1527793988407};\\\", \\\"{x:1309,y:561,t:1527793988424};\\\", \\\"{x:1306,y:564,t:1527793988439};\\\", \\\"{x:1301,y:566,t:1527793988457};\\\", \\\"{x:1297,y:567,t:1527793988474};\\\", \\\"{x:1296,y:568,t:1527793988490};\\\", \\\"{x:1294,y:570,t:1527793988522};\\\", \\\"{x:1293,y:570,t:1527793988538};\\\", \\\"{x:1292,y:570,t:1527793988578};\\\", \\\"{x:1289,y:570,t:1527793988778};\\\", \\\"{x:1286,y:570,t:1527793988791};\\\", \\\"{x:1281,y:571,t:1527793988808};\\\", \\\"{x:1278,y:571,t:1527793988823};\\\", \\\"{x:1278,y:572,t:1527793988840};\\\", \\\"{x:1275,y:573,t:1527793988857};\\\", \\\"{x:1274,y:573,t:1527793989170};\\\", \\\"{x:1275,y:573,t:1527793989186};\\\", \\\"{x:1275,y:572,t:1527793989194};\\\", \\\"{x:1278,y:571,t:1527793989207};\\\", \\\"{x:1284,y:568,t:1527793989225};\\\", \\\"{x:1290,y:566,t:1527793989241};\\\", \\\"{x:1295,y:563,t:1527793989257};\\\", \\\"{x:1299,y:562,t:1527793989274};\\\", \\\"{x:1300,y:561,t:1527793989290};\\\", \\\"{x:1305,y:560,t:1527793989308};\\\", \\\"{x:1310,y:559,t:1527793989324};\\\", \\\"{x:1311,y:559,t:1527793989340};\\\", \\\"{x:1316,y:559,t:1527793989358};\\\", \\\"{x:1317,y:559,t:1527793989374};\\\", \\\"{x:1320,y:559,t:1527793989391};\\\", \\\"{x:1327,y:558,t:1527793989407};\\\", \\\"{x:1341,y:558,t:1527793989424};\\\", \\\"{x:1357,y:558,t:1527793989441};\\\", \\\"{x:1372,y:558,t:1527793989457};\\\", \\\"{x:1376,y:558,t:1527793989474};\\\", \\\"{x:1378,y:558,t:1527793989490};\\\", \\\"{x:1379,y:558,t:1527793989507};\\\", \\\"{x:1380,y:558,t:1527793989658};\\\", \\\"{x:1383,y:558,t:1527793989675};\\\", \\\"{x:1386,y:558,t:1527793989691};\\\", \\\"{x:1388,y:558,t:1527793989707};\\\", \\\"{x:1389,y:558,t:1527793989725};\\\", \\\"{x:1391,y:558,t:1527793989769};\\\", \\\"{x:1393,y:558,t:1527793989777};\\\", \\\"{x:1396,y:558,t:1527793989791};\\\", \\\"{x:1399,y:558,t:1527793989807};\\\", \\\"{x:1404,y:558,t:1527793989825};\\\", \\\"{x:1408,y:558,t:1527793989841};\\\", \\\"{x:1410,y:558,t:1527793989857};\\\", \\\"{x:1412,y:558,t:1527793989946};\\\", \\\"{x:1415,y:558,t:1527793990002};\\\", \\\"{x:1413,y:557,t:1527793990522};\\\", \\\"{x:1405,y:555,t:1527793990529};\\\", \\\"{x:1399,y:554,t:1527793990542};\\\", \\\"{x:1387,y:554,t:1527793990558};\\\", \\\"{x:1373,y:554,t:1527793990575};\\\", \\\"{x:1365,y:555,t:1527793990593};\\\", \\\"{x:1359,y:557,t:1527793990608};\\\", \\\"{x:1348,y:559,t:1527793990626};\\\", \\\"{x:1335,y:565,t:1527793990642};\\\", \\\"{x:1318,y:570,t:1527793990658};\\\", \\\"{x:1295,y:579,t:1527793990675};\\\", \\\"{x:1284,y:582,t:1527793990693};\\\", \\\"{x:1280,y:582,t:1527793991009};\\\", \\\"{x:1266,y:573,t:1527793991026};\\\", \\\"{x:1255,y:566,t:1527793991043};\\\", \\\"{x:1208,y:557,t:1527793991060};\\\", \\\"{x:1130,y:553,t:1527793991076};\\\", \\\"{x:999,y:544,t:1527793991093};\\\", \\\"{x:891,y:533,t:1527793991110};\\\", \\\"{x:790,y:529,t:1527793991126};\\\", \\\"{x:767,y:529,t:1527793991141};\\\", \\\"{x:756,y:529,t:1527793991158};\\\", \\\"{x:753,y:528,t:1527793991173};\\\", \\\"{x:751,y:528,t:1527793991190};\\\", \\\"{x:751,y:527,t:1527793991208};\\\", \\\"{x:750,y:528,t:1527793991241};\\\", \\\"{x:744,y:529,t:1527793991257};\\\", \\\"{x:743,y:529,t:1527793991273};\\\", \\\"{x:735,y:529,t:1527793991290};\\\", \\\"{x:720,y:528,t:1527793991307};\\\", \\\"{x:712,y:526,t:1527793991323};\\\", \\\"{x:704,y:523,t:1527793991343};\\\", \\\"{x:698,y:522,t:1527793991358};\\\", \\\"{x:692,y:520,t:1527793991375};\\\", \\\"{x:688,y:520,t:1527793991392};\\\", \\\"{x:681,y:519,t:1527793991408};\\\", \\\"{x:676,y:516,t:1527793991425};\\\", \\\"{x:675,y:516,t:1527793991442};\\\", \\\"{x:672,y:516,t:1527793991459};\\\", \\\"{x:664,y:515,t:1527793991476};\\\", \\\"{x:656,y:511,t:1527793991493};\\\", \\\"{x:645,y:507,t:1527793991509};\\\", \\\"{x:636,y:506,t:1527793991526};\\\", \\\"{x:635,y:506,t:1527793991543};\\\", \\\"{x:634,y:505,t:1527793991558};\\\", \\\"{x:632,y:503,t:1527793991578};\\\", \\\"{x:631,y:503,t:1527793991592};\\\", \\\"{x:628,y:503,t:1527793991608};\\\", \\\"{x:617,y:503,t:1527793991625};\\\", \\\"{x:612,y:503,t:1527793991642};\\\", \\\"{x:606,y:502,t:1527793991658};\\\", \\\"{x:605,y:502,t:1527793991676};\\\", \\\"{x:604,y:502,t:1527793991898};\\\", \\\"{x:605,y:502,t:1527793991913};\\\", \\\"{x:611,y:500,t:1527793991925};\\\", \\\"{x:620,y:501,t:1527793991943};\\\", \\\"{x:645,y:514,t:1527793991959};\\\", \\\"{x:659,y:522,t:1527793991976};\\\", \\\"{x:681,y:526,t:1527793991993};\\\", \\\"{x:702,y:532,t:1527793992009};\\\", \\\"{x:711,y:533,t:1527793992025};\\\", \\\"{x:724,y:534,t:1527793992043};\\\", \\\"{x:738,y:534,t:1527793992060};\\\", \\\"{x:742,y:534,t:1527793992076};\\\", \\\"{x:747,y:535,t:1527793992092};\\\", \\\"{x:752,y:537,t:1527793992109};\\\", \\\"{x:753,y:537,t:1527793992145};\\\", \\\"{x:759,y:537,t:1527793992160};\\\", \\\"{x:772,y:541,t:1527793992175};\\\", \\\"{x:777,y:541,t:1527793992192};\\\", \\\"{x:780,y:541,t:1527793992210};\\\", \\\"{x:781,y:541,t:1527793992226};\\\", \\\"{x:783,y:541,t:1527793992242};\\\", \\\"{x:789,y:541,t:1527793992260};\\\", \\\"{x:792,y:540,t:1527793992276};\\\", \\\"{x:794,y:540,t:1527793992293};\\\", \\\"{x:799,y:540,t:1527793992310};\\\", \\\"{x:802,y:540,t:1527793992326};\\\", \\\"{x:807,y:540,t:1527793992342};\\\", \\\"{x:809,y:540,t:1527793992360};\\\", \\\"{x:812,y:540,t:1527793992417};\\\", \\\"{x:816,y:540,t:1527793992427};\\\", \\\"{x:827,y:543,t:1527793992442};\\\", \\\"{x:830,y:545,t:1527793992459};\\\", \\\"{x:832,y:545,t:1527793992476};\\\", \\\"{x:833,y:545,t:1527793992826};\\\", \\\"{x:832,y:545,t:1527794001577};\\\", \\\"{x:824,y:547,t:1527794001586};\\\", \\\"{x:813,y:554,t:1527794001600};\\\", \\\"{x:794,y:567,t:1527794001617};\\\", \\\"{x:783,y:572,t:1527794001633};\\\", \\\"{x:763,y:578,t:1527794001650};\\\", \\\"{x:751,y:585,t:1527794001667};\\\", \\\"{x:743,y:591,t:1527794001683};\\\", \\\"{x:741,y:593,t:1527794001705};\\\", \\\"{x:738,y:597,t:1527794001717};\\\", \\\"{x:724,y:606,t:1527794001734};\\\", \\\"{x:721,y:610,t:1527794001750};\\\", \\\"{x:714,y:612,t:1527794001767};\\\", \\\"{x:714,y:613,t:1527794001784};\\\", \\\"{x:713,y:614,t:1527794001800};\\\", \\\"{x:713,y:616,t:1527794001817};\\\", \\\"{x:703,y:623,t:1527794001833};\\\", \\\"{x:692,y:633,t:1527794001850};\\\", \\\"{x:684,y:640,t:1527794001871};\\\", \\\"{x:680,y:644,t:1527794001888};\\\", \\\"{x:677,y:645,t:1527794001905};\\\", \\\"{x:676,y:645,t:1527794001933};\\\", \\\"{x:669,y:650,t:1527794001941};\\\", \\\"{x:663,y:653,t:1527794001955};\\\", \\\"{x:657,y:653,t:1527794001971};\\\", \\\"{x:653,y:654,t:1527794001988};\\\", \\\"{x:651,y:655,t:1527794002005};\\\", \\\"{x:649,y:655,t:1527794002022};\\\", \\\"{x:640,y:655,t:1527794002038};\\\", \\\"{x:632,y:655,t:1527794002055};\\\", \\\"{x:631,y:655,t:1527794002071};\\\", \\\"{x:629,y:655,t:1527794002109};\\\", \\\"{x:623,y:659,t:1527794002309};\\\", \\\"{x:620,y:666,t:1527794002322};\\\", \\\"{x:611,y:680,t:1527794002338};\\\", \\\"{x:605,y:682,t:1527794002354};\\\", \\\"{x:604,y:684,t:1527794002371};\\\", \\\"{x:598,y:687,t:1527794002388};\\\", \\\"{x:591,y:693,t:1527794002405};\\\", \\\"{x:587,y:697,t:1527794002421};\\\", \\\"{x:586,y:697,t:1527794002445};\\\", \\\"{x:585,y:697,t:1527794002461};\\\", \\\"{x:583,y:699,t:1527794002477};\\\", \\\"{x:581,y:699,t:1527794002493};\\\", \\\"{x:577,y:701,t:1527794002621};\\\", \\\"{x:572,y:706,t:1527794002638};\\\", \\\"{x:568,y:710,t:1527794002949};\\\", \\\"{x:562,y:716,t:1527794002957};\\\", \\\"{x:557,y:720,t:1527794002974};\\\", \\\"{x:552,y:722,t:1527794002989};\\\", \\\"{x:552,y:724,t:1527794003004};\\\", \\\"{x:544,y:726,t:1527794003022};\\\", \\\"{x:539,y:729,t:1527794003039};\\\", \\\"{x:538,y:730,t:1527794003061};\\\", \\\"{x:537,y:731,t:1527794003077};\\\", \\\"{x:535,y:733,t:1527794003093};\\\", \\\"{x:533,y:733,t:1527794003109};\\\" ] }, { \\\"rt\\\": 61265, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 592654, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:732,t:1527794025374};\\\", \\\"{x:533,y:725,t:1527794025389};\\\", \\\"{x:528,y:711,t:1527794025405};\\\", \\\"{x:520,y:696,t:1527794025422};\\\", \\\"{x:514,y:675,t:1527794025439};\\\", \\\"{x:508,y:647,t:1527794025457};\\\", \\\"{x:497,y:622,t:1527794025474};\\\", \\\"{x:484,y:598,t:1527794025490};\\\", \\\"{x:475,y:588,t:1527794025507};\\\", \\\"{x:475,y:587,t:1527794025522};\\\", \\\"{x:482,y:590,t:1527794025557};\\\", \\\"{x:485,y:590,t:1527794025573};\\\", \\\"{x:495,y:593,t:1527794025590};\\\", \\\"{x:501,y:593,t:1527794025607};\\\", \\\"{x:515,y:592,t:1527794025623};\\\", \\\"{x:556,y:583,t:1527794025640};\\\", \\\"{x:646,y:581,t:1527794025657};\\\", \\\"{x:733,y:585,t:1527794025674};\\\", \\\"{x:788,y:591,t:1527794025690};\\\", \\\"{x:825,y:589,t:1527794025707};\\\", \\\"{x:882,y:587,t:1527794025724};\\\", \\\"{x:993,y:584,t:1527794025740};\\\", \\\"{x:1170,y:569,t:1527794025757};\\\", \\\"{x:1248,y:568,t:1527794025774};\\\", \\\"{x:1272,y:568,t:1527794025790};\\\", \\\"{x:1275,y:568,t:1527794025807};\\\", \\\"{x:1276,y:568,t:1527794025824};\\\", \\\"{x:1278,y:568,t:1527794025841};\\\", \\\"{x:1279,y:568,t:1527794025857};\\\", \\\"{x:1280,y:568,t:1527794025873};\\\", \\\"{x:1282,y:569,t:1527794025925};\\\", \\\"{x:1299,y:587,t:1527794025941};\\\", \\\"{x:1321,y:606,t:1527794025957};\\\", \\\"{x:1326,y:611,t:1527794025974};\\\", \\\"{x:1327,y:615,t:1527794025991};\\\", \\\"{x:1332,y:620,t:1527794026007};\\\", \\\"{x:1332,y:621,t:1527794026024};\\\", \\\"{x:1332,y:625,t:1527794026041};\\\", \\\"{x:1330,y:634,t:1527794026057};\\\", \\\"{x:1326,y:640,t:1527794026074};\\\", \\\"{x:1326,y:642,t:1527794026117};\\\", \\\"{x:1326,y:644,t:1527794026197};\\\", \\\"{x:1326,y:646,t:1527794026208};\\\", \\\"{x:1331,y:653,t:1527794026224};\\\", \\\"{x:1335,y:663,t:1527794026241};\\\", \\\"{x:1339,y:668,t:1527794026258};\\\", \\\"{x:1340,y:668,t:1527794026274};\\\", \\\"{x:1342,y:670,t:1527794026291};\\\", \\\"{x:1343,y:670,t:1527794026380};\\\", \\\"{x:1343,y:672,t:1527794026461};\\\", \\\"{x:1343,y:673,t:1527794026477};\\\", \\\"{x:1343,y:674,t:1527794026491};\\\", \\\"{x:1343,y:675,t:1527794026508};\\\", \\\"{x:1343,y:678,t:1527794026525};\\\", \\\"{x:1343,y:679,t:1527794026541};\\\", \\\"{x:1343,y:682,t:1527794026558};\\\", \\\"{x:1345,y:685,t:1527794026575};\\\", \\\"{x:1345,y:687,t:1527794026592};\\\", \\\"{x:1345,y:688,t:1527794026608};\\\", \\\"{x:1345,y:689,t:1527794026624};\\\", \\\"{x:1346,y:690,t:1527794026642};\\\", \\\"{x:1346,y:692,t:1527794026658};\\\", \\\"{x:1347,y:692,t:1527794026692};\\\", \\\"{x:1348,y:694,t:1527794026708};\\\", \\\"{x:1349,y:695,t:1527794026741};\\\", \\\"{x:1351,y:698,t:1527794027756};\\\", \\\"{x:1352,y:701,t:1527794027765};\\\", \\\"{x:1352,y:706,t:1527794027777};\\\", \\\"{x:1355,y:713,t:1527794027793};\\\", \\\"{x:1356,y:719,t:1527794027810};\\\", \\\"{x:1357,y:727,t:1527794027827};\\\", \\\"{x:1360,y:735,t:1527794027843};\\\", \\\"{x:1362,y:736,t:1527794027860};\\\", \\\"{x:1362,y:737,t:1527794027877};\\\", \\\"{x:1362,y:739,t:1527794027901};\\\", \\\"{x:1362,y:742,t:1527794027910};\\\", \\\"{x:1362,y:743,t:1527794027927};\\\", \\\"{x:1362,y:745,t:1527794027989};\\\", \\\"{x:1362,y:746,t:1527794027997};\\\", \\\"{x:1362,y:747,t:1527794028013};\\\", \\\"{x:1362,y:748,t:1527794028101};\\\", \\\"{x:1362,y:749,t:1527794028117};\\\", \\\"{x:1362,y:750,t:1527794028173};\\\", \\\"{x:1362,y:751,t:1527794028229};\\\", \\\"{x:1362,y:753,t:1527794028245};\\\", \\\"{x:1362,y:755,t:1527794028261};\\\", \\\"{x:1362,y:756,t:1527794028285};\\\", \\\"{x:1362,y:759,t:1527794028300};\\\", \\\"{x:1361,y:760,t:1527794028325};\\\", \\\"{x:1361,y:761,t:1527794028341};\\\", \\\"{x:1360,y:761,t:1527794028405};\\\", \\\"{x:1360,y:762,t:1527794028413};\\\", \\\"{x:1359,y:762,t:1527794028637};\\\", \\\"{x:1357,y:759,t:1527794028669};\\\", \\\"{x:1357,y:758,t:1527794028678};\\\", \\\"{x:1354,y:755,t:1527794028695};\\\", \\\"{x:1354,y:748,t:1527794028711};\\\", \\\"{x:1352,y:736,t:1527794028728};\\\", \\\"{x:1349,y:728,t:1527794028745};\\\", \\\"{x:1349,y:722,t:1527794028761};\\\", \\\"{x:1347,y:720,t:1527794028778};\\\", \\\"{x:1346,y:714,t:1527794028795};\\\", \\\"{x:1345,y:710,t:1527794028811};\\\", \\\"{x:1344,y:707,t:1527794028828};\\\", \\\"{x:1342,y:701,t:1527794028844};\\\", \\\"{x:1342,y:699,t:1527794028861};\\\", \\\"{x:1341,y:697,t:1527794028893};\\\", \\\"{x:1341,y:693,t:1527794028901};\\\", \\\"{x:1341,y:692,t:1527794028917};\\\", \\\"{x:1341,y:691,t:1527794028928};\\\", \\\"{x:1341,y:690,t:1527794028945};\\\", \\\"{x:1341,y:688,t:1527794028973};\\\", \\\"{x:1341,y:693,t:1527794029421};\\\", \\\"{x:1339,y:697,t:1527794029429};\\\", \\\"{x:1339,y:701,t:1527794029460};\\\", \\\"{x:1337,y:706,t:1527794029469};\\\", \\\"{x:1337,y:707,t:1527794029479};\\\", \\\"{x:1337,y:710,t:1527794029496};\\\", \\\"{x:1338,y:710,t:1527794029512};\\\", \\\"{x:1338,y:712,t:1527794029581};\\\", \\\"{x:1338,y:714,t:1527794029596};\\\", \\\"{x:1340,y:721,t:1527794029613};\\\", \\\"{x:1341,y:724,t:1527794029629};\\\", \\\"{x:1343,y:728,t:1527794029646};\\\", \\\"{x:1343,y:731,t:1527794029663};\\\", \\\"{x:1345,y:733,t:1527794029680};\\\", \\\"{x:1345,y:735,t:1527794029696};\\\", \\\"{x:1345,y:737,t:1527794029713};\\\", \\\"{x:1346,y:739,t:1527794029729};\\\", \\\"{x:1349,y:747,t:1527794029746};\\\", \\\"{x:1350,y:753,t:1527794029762};\\\", \\\"{x:1354,y:760,t:1527794029779};\\\", \\\"{x:1355,y:763,t:1527794029796};\\\", \\\"{x:1356,y:765,t:1527794029813};\\\", \\\"{x:1355,y:765,t:1527794042788};\\\", \\\"{x:1337,y:763,t:1527794042799};\\\", \\\"{x:1220,y:738,t:1527794042816};\\\", \\\"{x:1161,y:727,t:1527794042832};\\\", \\\"{x:1073,y:718,t:1527794042848};\\\", \\\"{x:961,y:710,t:1527794042865};\\\", \\\"{x:902,y:708,t:1527794042881};\\\", \\\"{x:895,y:706,t:1527794042898};\\\", \\\"{x:885,y:685,t:1527794043140};\\\", \\\"{x:860,y:654,t:1527794043149};\\\", \\\"{x:829,y:616,t:1527794043166};\\\", \\\"{x:726,y:564,t:1527794043182};\\\", \\\"{x:583,y:491,t:1527794043205};\\\", \\\"{x:474,y:454,t:1527794043220};\\\", \\\"{x:381,y:437,t:1527794043238};\\\", \\\"{x:320,y:428,t:1527794043254};\\\", \\\"{x:302,y:422,t:1527794043271};\\\", \\\"{x:294,y:420,t:1527794043287};\\\", \\\"{x:303,y:428,t:1527794043397};\\\", \\\"{x:309,y:437,t:1527794043405};\\\", \\\"{x:331,y:452,t:1527794043420};\\\", \\\"{x:367,y:463,t:1527794043438};\\\", \\\"{x:407,y:475,t:1527794043454};\\\", \\\"{x:463,y:482,t:1527794043470};\\\", \\\"{x:515,y:487,t:1527794043488};\\\", \\\"{x:584,y:487,t:1527794043504};\\\", \\\"{x:658,y:490,t:1527794043521};\\\", \\\"{x:696,y:492,t:1527794043537};\\\", \\\"{x:714,y:492,t:1527794043554};\\\", \\\"{x:729,y:492,t:1527794043572};\\\", \\\"{x:735,y:492,t:1527794043589};\\\", \\\"{x:736,y:492,t:1527794043620};\\\", \\\"{x:737,y:492,t:1527794043724};\\\", \\\"{x:739,y:492,t:1527794043737};\\\", \\\"{x:743,y:492,t:1527794043754};\\\", \\\"{x:746,y:492,t:1527794043771};\\\", \\\"{x:753,y:490,t:1527794043787};\\\", \\\"{x:781,y:488,t:1527794043804};\\\", \\\"{x:791,y:488,t:1527794043822};\\\", \\\"{x:803,y:485,t:1527794043838};\\\", \\\"{x:811,y:485,t:1527794043854};\\\", \\\"{x:812,y:485,t:1527794043871};\\\", \\\"{x:813,y:487,t:1527794044125};\\\", \\\"{x:815,y:489,t:1527794044138};\\\", \\\"{x:818,y:496,t:1527794044154};\\\", \\\"{x:824,y:503,t:1527794044171};\\\", \\\"{x:828,y:510,t:1527794044189};\\\", \\\"{x:832,y:511,t:1527794044205};\\\", \\\"{x:833,y:512,t:1527794044229};\\\", \\\"{x:833,y:513,t:1527794044492};\\\", \\\"{x:827,y:518,t:1527794044506};\\\", \\\"{x:818,y:523,t:1527794044521};\\\", \\\"{x:801,y:531,t:1527794044539};\\\", \\\"{x:789,y:540,t:1527794044556};\\\", \\\"{x:777,y:545,t:1527794044572};\\\", \\\"{x:742,y:555,t:1527794044588};\\\", \\\"{x:733,y:565,t:1527794044606};\\\", \\\"{x:694,y:582,t:1527794044622};\\\", \\\"{x:678,y:595,t:1527794044638};\\\", \\\"{x:647,y:607,t:1527794044656};\\\", \\\"{x:606,y:614,t:1527794044672};\\\", \\\"{x:541,y:628,t:1527794044688};\\\", \\\"{x:500,y:637,t:1527794044706};\\\", \\\"{x:424,y:651,t:1527794044722};\\\", \\\"{x:345,y:668,t:1527794044738};\\\", \\\"{x:308,y:669,t:1527794044755};\\\", \\\"{x:294,y:669,t:1527794044773};\\\", \\\"{x:288,y:666,t:1527794044789};\\\", \\\"{x:273,y:662,t:1527794044805};\\\", \\\"{x:270,y:660,t:1527794044822};\\\", \\\"{x:267,y:660,t:1527794044838};\\\", \\\"{x:263,y:656,t:1527794044856};\\\", \\\"{x:254,y:647,t:1527794044872};\\\", \\\"{x:240,y:637,t:1527794044889};\\\", \\\"{x:222,y:634,t:1527794044905};\\\", \\\"{x:216,y:633,t:1527794044922};\\\", \\\"{x:212,y:632,t:1527794044939};\\\", \\\"{x:209,y:632,t:1527794044955};\\\", \\\"{x:207,y:632,t:1527794044972};\\\", \\\"{x:202,y:627,t:1527794044989};\\\", \\\"{x:199,y:625,t:1527794045005};\\\", \\\"{x:199,y:622,t:1527794045023};\\\", \\\"{x:199,y:620,t:1527794045038};\\\", \\\"{x:197,y:618,t:1527794045055};\\\", \\\"{x:195,y:615,t:1527794045072};\\\", \\\"{x:193,y:609,t:1527794045088};\\\", \\\"{x:187,y:603,t:1527794045105};\\\", \\\"{x:187,y:602,t:1527794045123};\\\", \\\"{x:183,y:600,t:1527794045138};\\\", \\\"{x:182,y:598,t:1527794045156};\\\", \\\"{x:180,y:595,t:1527794045173};\\\", \\\"{x:178,y:589,t:1527794045189};\\\", \\\"{x:177,y:587,t:1527794045206};\\\", \\\"{x:177,y:580,t:1527794045222};\\\", \\\"{x:176,y:564,t:1527794045239};\\\", \\\"{x:174,y:557,t:1527794045256};\\\", \\\"{x:172,y:556,t:1527794045273};\\\", \\\"{x:172,y:554,t:1527794045289};\\\", \\\"{x:172,y:553,t:1527794045365};\\\", \\\"{x:171,y:550,t:1527794045373};\\\", \\\"{x:170,y:549,t:1527794045390};\\\", \\\"{x:169,y:547,t:1527794045405};\\\", \\\"{x:169,y:545,t:1527794045422};\\\", \\\"{x:167,y:542,t:1527794045439};\\\", \\\"{x:166,y:541,t:1527794045455};\\\", \\\"{x:165,y:540,t:1527794045472};\\\", \\\"{x:164,y:539,t:1527794045490};\\\", \\\"{x:164,y:538,t:1527794045506};\\\", \\\"{x:164,y:540,t:1527794045788};\\\", \\\"{x:204,y:547,t:1527794045796};\\\", \\\"{x:266,y:551,t:1527794045806};\\\", \\\"{x:365,y:561,t:1527794045823};\\\", \\\"{x:485,y:567,t:1527794045840};\\\", \\\"{x:600,y:558,t:1527794045856};\\\", \\\"{x:720,y:563,t:1527794045872};\\\", \\\"{x:794,y:575,t:1527794045890};\\\", \\\"{x:807,y:581,t:1527794045907};\\\", \\\"{x:838,y:589,t:1527794045923};\\\", \\\"{x:856,y:593,t:1527794045940};\\\", \\\"{x:948,y:609,t:1527794045956};\\\", \\\"{x:983,y:610,t:1527794045973};\\\", \\\"{x:998,y:613,t:1527794045989};\\\", \\\"{x:1006,y:616,t:1527794046007};\\\", \\\"{x:1020,y:616,t:1527794046024};\\\", \\\"{x:1031,y:619,t:1527794046040};\\\", \\\"{x:1074,y:628,t:1527794046057};\\\", \\\"{x:1146,y:635,t:1527794046074};\\\", \\\"{x:1244,y:652,t:1527794046089};\\\", \\\"{x:1298,y:662,t:1527794046107};\\\", \\\"{x:1369,y:676,t:1527794046123};\\\", \\\"{x:1393,y:687,t:1527794046139};\\\", \\\"{x:1408,y:693,t:1527794046156};\\\", \\\"{x:1423,y:688,t:1527794046174};\\\", \\\"{x:1439,y:684,t:1527794046191};\\\", \\\"{x:1443,y:680,t:1527794046207};\\\", \\\"{x:1422,y:680,t:1527794063641};\\\", \\\"{x:1354,y:690,t:1527794063652};\\\", \\\"{x:1248,y:708,t:1527794063668};\\\", \\\"{x:1150,y:728,t:1527794063685};\\\", \\\"{x:1053,y:739,t:1527794063702};\\\", \\\"{x:966,y:743,t:1527794063719};\\\", \\\"{x:897,y:743,t:1527794063735};\\\", \\\"{x:881,y:743,t:1527794063751};\\\", \\\"{x:874,y:743,t:1527794063768};\\\", \\\"{x:861,y:743,t:1527794063785};\\\", \\\"{x:852,y:744,t:1527794063802};\\\", \\\"{x:847,y:747,t:1527794063819};\\\", \\\"{x:841,y:752,t:1527794063835};\\\", \\\"{x:824,y:763,t:1527794063852};\\\", \\\"{x:807,y:776,t:1527794063869};\\\", \\\"{x:792,y:788,t:1527794063886};\\\", \\\"{x:776,y:804,t:1527794063902};\\\", \\\"{x:765,y:812,t:1527794063919};\\\", \\\"{x:725,y:815,t:1527794063936};\\\", \\\"{x:647,y:799,t:1527794063952};\\\", \\\"{x:588,y:787,t:1527794063969};\\\", \\\"{x:468,y:759,t:1527794063986};\\\", \\\"{x:369,y:749,t:1527794064003};\\\", \\\"{x:353,y:744,t:1527794064019};\\\", \\\"{x:343,y:742,t:1527794064036};\\\", \\\"{x:342,y:742,t:1527794064104};\\\", \\\"{x:343,y:739,t:1527794064176};\\\", \\\"{x:347,y:736,t:1527794064186};\\\", \\\"{x:365,y:729,t:1527794064203};\\\", \\\"{x:378,y:725,t:1527794064220};\\\", \\\"{x:396,y:720,t:1527794064235};\\\", \\\"{x:398,y:719,t:1527794064253};\\\", \\\"{x:409,y:716,t:1527794064270};\\\", \\\"{x:413,y:714,t:1527794064287};\\\", \\\"{x:414,y:714,t:1527794064304};\\\", \\\"{x:417,y:714,t:1527794064320};\\\", \\\"{x:418,y:714,t:1527794064384};\\\", \\\"{x:421,y:715,t:1527794064392};\\\", \\\"{x:428,y:721,t:1527794064403};\\\", \\\"{x:440,y:727,t:1527794064420};\\\", \\\"{x:452,y:731,t:1527794064437};\\\", \\\"{x:459,y:738,t:1527794064454};\\\", \\\"{x:469,y:748,t:1527794064470};\\\", \\\"{x:484,y:759,t:1527794064484};\\\", \\\"{x:487,y:762,t:1527794064500};\\\", \\\"{x:489,y:764,t:1527794064517};\\\", \\\"{x:491,y:764,t:1527794064648};\\\", \\\"{x:493,y:763,t:1527794064664};\\\", \\\"{x:493,y:762,t:1527794064672};\\\", \\\"{x:495,y:760,t:1527794064684};\\\", \\\"{x:496,y:758,t:1527794064701};\\\", \\\"{x:498,y:756,t:1527794064718};\\\", \\\"{x:500,y:753,t:1527794064735};\\\", \\\"{x:501,y:751,t:1527794064751};\\\", \\\"{x:501,y:748,t:1527794064773};\\\", \\\"{x:504,y:746,t:1527794064791};\\\", \\\"{x:506,y:743,t:1527794064807};\\\", \\\"{x:508,y:741,t:1527794064824};\\\", \\\"{x:508,y:740,t:1527794064848};\\\" ] }, { \\\"rt\\\": 59774, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 653953, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:740,t:1527794072568};\\\", \\\"{x:559,y:723,t:1527794072581};\\\", \\\"{x:670,y:673,t:1527794072598};\\\", \\\"{x:776,y:632,t:1527794072615};\\\", \\\"{x:864,y:595,t:1527794072631};\\\", \\\"{x:886,y:581,t:1527794072647};\\\", \\\"{x:910,y:567,t:1527794072663};\\\", \\\"{x:944,y:545,t:1527794072682};\\\", \\\"{x:948,y:536,t:1527794072699};\\\", \\\"{x:950,y:531,t:1527794072714};\\\", \\\"{x:993,y:518,t:1527794072731};\\\", \\\"{x:1050,y:503,t:1527794072748};\\\", \\\"{x:1153,y:483,t:1527794072764};\\\", \\\"{x:1236,y:475,t:1527794072781};\\\", \\\"{x:1349,y:463,t:1527794072799};\\\", \\\"{x:1452,y:459,t:1527794072815};\\\", \\\"{x:1506,y:459,t:1527794072832};\\\", \\\"{x:1524,y:464,t:1527794072849};\\\", \\\"{x:1525,y:464,t:1527794072888};\\\", \\\"{x:1528,y:468,t:1527794072899};\\\", \\\"{x:1533,y:476,t:1527794072916};\\\", \\\"{x:1539,y:486,t:1527794072932};\\\", \\\"{x:1542,y:489,t:1527794072948};\\\", \\\"{x:1542,y:491,t:1527794072966};\\\", \\\"{x:1542,y:493,t:1527794072983};\\\", \\\"{x:1542,y:499,t:1527794072998};\\\", \\\"{x:1540,y:506,t:1527794073015};\\\", \\\"{x:1531,y:524,t:1527794073032};\\\", \\\"{x:1524,y:529,t:1527794073049};\\\", \\\"{x:1497,y:541,t:1527794073066};\\\", \\\"{x:1477,y:551,t:1527794073082};\\\", \\\"{x:1472,y:554,t:1527794073099};\\\", \\\"{x:1469,y:556,t:1527794073144};\\\", \\\"{x:1467,y:558,t:1527794073160};\\\", \\\"{x:1465,y:559,t:1527794073184};\\\", \\\"{x:1465,y:560,t:1527794073200};\\\", \\\"{x:1461,y:563,t:1527794073279};\\\", \\\"{x:1456,y:564,t:1527794073296};\\\", \\\"{x:1449,y:564,t:1527794073304};\\\", \\\"{x:1441,y:566,t:1527794073316};\\\", \\\"{x:1440,y:566,t:1527794073334};\\\", \\\"{x:1439,y:566,t:1527794073352};\\\", \\\"{x:1438,y:566,t:1527794073366};\\\", \\\"{x:1435,y:566,t:1527794073384};\\\", \\\"{x:1431,y:566,t:1527794073399};\\\", \\\"{x:1431,y:565,t:1527794073496};\\\", \\\"{x:1430,y:565,t:1527794073503};\\\", \\\"{x:1429,y:563,t:1527794073516};\\\", \\\"{x:1428,y:553,t:1527794073533};\\\", \\\"{x:1428,y:547,t:1527794073550};\\\", \\\"{x:1427,y:544,t:1527794073566};\\\", \\\"{x:1427,y:535,t:1527794073583};\\\", \\\"{x:1425,y:522,t:1527794073601};\\\", \\\"{x:1422,y:511,t:1527794073618};\\\", \\\"{x:1418,y:493,t:1527794073634};\\\", \\\"{x:1414,y:477,t:1527794073650};\\\", \\\"{x:1414,y:470,t:1527794073667};\\\", \\\"{x:1410,y:460,t:1527794073683};\\\", \\\"{x:1410,y:451,t:1527794073701};\\\", \\\"{x:1409,y:447,t:1527794073717};\\\", \\\"{x:1409,y:444,t:1527794073734};\\\", \\\"{x:1409,y:443,t:1527794073750};\\\", \\\"{x:1407,y:439,t:1527794073768};\\\", \\\"{x:1406,y:439,t:1527794073784};\\\", \\\"{x:1406,y:441,t:1527794074088};\\\", \\\"{x:1406,y:443,t:1527794074101};\\\", \\\"{x:1406,y:444,t:1527794074119};\\\", \\\"{x:1407,y:447,t:1527794074136};\\\", \\\"{x:1408,y:455,t:1527794074152};\\\", \\\"{x:1411,y:460,t:1527794074169};\\\", \\\"{x:1414,y:468,t:1527794074186};\\\", \\\"{x:1416,y:472,t:1527794074202};\\\", \\\"{x:1420,y:475,t:1527794074218};\\\", \\\"{x:1427,y:484,t:1527794074236};\\\", \\\"{x:1432,y:487,t:1527794074251};\\\", \\\"{x:1436,y:488,t:1527794074269};\\\", \\\"{x:1436,y:489,t:1527794074286};\\\", \\\"{x:1440,y:489,t:1527794074303};\\\", \\\"{x:1443,y:489,t:1527794074318};\\\", \\\"{x:1444,y:489,t:1527794074335};\\\", \\\"{x:1460,y:489,t:1527794074352};\\\", \\\"{x:1470,y:492,t:1527794074368};\\\", \\\"{x:1477,y:492,t:1527794074386};\\\", \\\"{x:1479,y:492,t:1527794074407};\\\", \\\"{x:1481,y:492,t:1527794074431};\\\", \\\"{x:1482,y:492,t:1527794074448};\\\", \\\"{x:1484,y:492,t:1527794074464};\\\", \\\"{x:1485,y:492,t:1527794074480};\\\", \\\"{x:1486,y:492,t:1527794074487};\\\", \\\"{x:1489,y:492,t:1527794074504};\\\", \\\"{x:1494,y:492,t:1527794074519};\\\", \\\"{x:1505,y:494,t:1527794074536};\\\", \\\"{x:1515,y:494,t:1527794074552};\\\", \\\"{x:1519,y:494,t:1527794074569};\\\", \\\"{x:1532,y:494,t:1527794074586};\\\", \\\"{x:1551,y:494,t:1527794074603};\\\", \\\"{x:1560,y:494,t:1527794074619};\\\", \\\"{x:1562,y:494,t:1527794074636};\\\", \\\"{x:1564,y:493,t:1527794074672};\\\", \\\"{x:1565,y:492,t:1527794074719};\\\", \\\"{x:1568,y:491,t:1527794074736};\\\", \\\"{x:1570,y:491,t:1527794074824};\\\", \\\"{x:1571,y:491,t:1527794074856};\\\", \\\"{x:1574,y:491,t:1527794074912};\\\", \\\"{x:1575,y:491,t:1527794074927};\\\", \\\"{x:1578,y:492,t:1527794075017};\\\", \\\"{x:1579,y:492,t:1527794075048};\\\", \\\"{x:1581,y:494,t:1527794075103};\\\", \\\"{x:1580,y:494,t:1527794075424};\\\", \\\"{x:1579,y:494,t:1527794075439};\\\", \\\"{x:1578,y:493,t:1527794075455};\\\", \\\"{x:1576,y:492,t:1527794075528};\\\", \\\"{x:1576,y:491,t:1527794124548};\\\", \\\"{x:1564,y:490,t:1527794124562};\\\", \\\"{x:1452,y:525,t:1527794124578};\\\", \\\"{x:1432,y:542,t:1527794124595};\\\", \\\"{x:1431,y:542,t:1527794124611};\\\", \\\"{x:1429,y:542,t:1527794124651};\\\", \\\"{x:1422,y:537,t:1527794124661};\\\", \\\"{x:1389,y:510,t:1527794124677};\\\", \\\"{x:1349,y:476,t:1527794124694};\\\", \\\"{x:1312,y:429,t:1527794124711};\\\", \\\"{x:1294,y:409,t:1527794124728};\\\", \\\"{x:1261,y:383,t:1527794124744};\\\", \\\"{x:1237,y:372,t:1527794124762};\\\", \\\"{x:1218,y:371,t:1527794124779};\\\", \\\"{x:1196,y:384,t:1527794124795};\\\", \\\"{x:1167,y:413,t:1527794124811};\\\", \\\"{x:1153,y:424,t:1527794124828};\\\", \\\"{x:1139,y:435,t:1527794124845};\\\", \\\"{x:1130,y:441,t:1527794124861};\\\", \\\"{x:1128,y:442,t:1527794124878};\\\", \\\"{x:1127,y:440,t:1527794124939};\\\", \\\"{x:1124,y:436,t:1527794124948};\\\", \\\"{x:1123,y:434,t:1527794124961};\\\", \\\"{x:1116,y:432,t:1527794124978};\\\", \\\"{x:1098,y:437,t:1527794124994};\\\", \\\"{x:1012,y:475,t:1527794125010};\\\", \\\"{x:872,y:527,t:1527794125028};\\\", \\\"{x:718,y:560,t:1527794125045};\\\", \\\"{x:604,y:557,t:1527794125062};\\\", \\\"{x:514,y:552,t:1527794125077};\\\", \\\"{x:500,y:551,t:1527794125094};\\\", \\\"{x:476,y:551,t:1527794125110};\\\", \\\"{x:473,y:551,t:1527794125126};\\\", \\\"{x:460,y:557,t:1527794125144};\\\", \\\"{x:456,y:564,t:1527794125161};\\\", \\\"{x:452,y:569,t:1527794125176};\\\", \\\"{x:451,y:569,t:1527794125193};\\\", \\\"{x:457,y:566,t:1527794125234};\\\", \\\"{x:464,y:561,t:1527794125244};\\\", \\\"{x:474,y:545,t:1527794125260};\\\", \\\"{x:482,y:532,t:1527794125277};\\\", \\\"{x:491,y:520,t:1527794125295};\\\", \\\"{x:501,y:512,t:1527794125310};\\\", \\\"{x:503,y:511,t:1527794125326};\\\", \\\"{x:505,y:511,t:1527794125412};\\\", \\\"{x:515,y:521,t:1527794125428};\\\", \\\"{x:531,y:534,t:1527794125445};\\\", \\\"{x:541,y:542,t:1527794125461};\\\", \\\"{x:557,y:545,t:1527794125477};\\\", \\\"{x:566,y:547,t:1527794125494};\\\", \\\"{x:567,y:547,t:1527794125510};\\\", \\\"{x:568,y:547,t:1527794125547};\\\", \\\"{x:572,y:547,t:1527794125562};\\\", \\\"{x:581,y:532,t:1527794125577};\\\", \\\"{x:586,y:517,t:1527794125595};\\\", \\\"{x:589,y:508,t:1527794125610};\\\", \\\"{x:589,y:505,t:1527794125628};\\\", \\\"{x:589,y:503,t:1527794125675};\\\", \\\"{x:589,y:508,t:1527794126003};\\\", \\\"{x:589,y:516,t:1527794126013};\\\", \\\"{x:590,y:530,t:1527794126031};\\\", \\\"{x:590,y:549,t:1527794126046};\\\", \\\"{x:592,y:569,t:1527794126061};\\\", \\\"{x:592,y:575,t:1527794126078};\\\", \\\"{x:592,y:582,t:1527794126093};\\\", \\\"{x:588,y:597,t:1527794126111};\\\", \\\"{x:587,y:613,t:1527794126128};\\\", \\\"{x:585,y:624,t:1527794126144};\\\", \\\"{x:588,y:636,t:1527794126161};\\\", \\\"{x:600,y:638,t:1527794126177};\\\", \\\"{x:607,y:638,t:1527794126193};\\\", \\\"{x:622,y:634,t:1527794126211};\\\", \\\"{x:630,y:621,t:1527794126228};\\\", \\\"{x:642,y:563,t:1527794126244};\\\", \\\"{x:635,y:473,t:1527794126261};\\\", \\\"{x:611,y:366,t:1527794126278};\\\", \\\"{x:603,y:343,t:1527794126295};\\\", \\\"{x:602,y:339,t:1527794126311};\\\", \\\"{x:601,y:339,t:1527794126387};\\\", \\\"{x:599,y:339,t:1527794126395};\\\", \\\"{x:594,y:346,t:1527794126411};\\\", \\\"{x:583,y:364,t:1527794126428};\\\", \\\"{x:579,y:381,t:1527794126445};\\\", \\\"{x:575,y:402,t:1527794126460};\\\", \\\"{x:571,y:408,t:1527794126478};\\\", \\\"{x:569,y:416,t:1527794126495};\\\", \\\"{x:568,y:425,t:1527794126511};\\\", \\\"{x:568,y:431,t:1527794126528};\\\", \\\"{x:569,y:434,t:1527794126545};\\\", \\\"{x:570,y:436,t:1527794126571};\\\", \\\"{x:572,y:436,t:1527794126578};\\\", \\\"{x:574,y:437,t:1527794126594};\\\", \\\"{x:576,y:439,t:1527794126611};\\\", \\\"{x:579,y:441,t:1527794126628};\\\", \\\"{x:591,y:452,t:1527794126645};\\\", \\\"{x:602,y:462,t:1527794126661};\\\", \\\"{x:608,y:470,t:1527794126678};\\\", \\\"{x:608,y:472,t:1527794126699};\\\", \\\"{x:609,y:474,t:1527794126722};\\\", \\\"{x:609,y:478,t:1527794126731};\\\", \\\"{x:609,y:480,t:1527794126745};\\\", \\\"{x:609,y:481,t:1527794126762};\\\", \\\"{x:609,y:484,t:1527794126779};\\\", \\\"{x:609,y:485,t:1527794126795};\\\", \\\"{x:609,y:487,t:1527794126876};\\\", \\\"{x:609,y:491,t:1527794126895};\\\", \\\"{x:609,y:492,t:1527794126910};\\\", \\\"{x:609,y:494,t:1527794127002};\\\", \\\"{x:607,y:497,t:1527794127009};\\\", \\\"{x:605,y:501,t:1527794127025};\\\", \\\"{x:604,y:504,t:1527794127042};\\\", \\\"{x:604,y:505,t:1527794127059};\\\", \\\"{x:603,y:506,t:1527794127563};\\\", \\\"{x:590,y:517,t:1527794127579};\\\", \\\"{x:572,y:543,t:1527794127598};\\\", \\\"{x:549,y:595,t:1527794127612};\\\", \\\"{x:533,y:617,t:1527794127629};\\\", \\\"{x:521,y:627,t:1527794127646};\\\", \\\"{x:514,y:634,t:1527794127661};\\\", \\\"{x:514,y:635,t:1527794127678};\\\", \\\"{x:513,y:635,t:1527794127695};\\\", \\\"{x:513,y:636,t:1527794127714};\\\", \\\"{x:513,y:647,t:1527794127729};\\\", \\\"{x:513,y:657,t:1527794127745};\\\", \\\"{x:510,y:674,t:1527794127762};\\\", \\\"{x:508,y:678,t:1527794127778};\\\", \\\"{x:507,y:679,t:1527794127796};\\\", \\\"{x:506,y:681,t:1527794127813};\\\", \\\"{x:505,y:686,t:1527794127858};\\\", \\\"{x:503,y:691,t:1527794127867};\\\", \\\"{x:502,y:702,t:1527794127880};\\\", \\\"{x:499,y:712,t:1527794127896};\\\", \\\"{x:497,y:716,t:1527794127913};\\\", \\\"{x:495,y:720,t:1527794127930};\\\", \\\"{x:494,y:722,t:1527794127945};\\\", \\\"{x:494,y:725,t:1527794127962};\\\", \\\"{x:494,y:729,t:1527794127979};\\\", \\\"{x:493,y:729,t:1527794127995};\\\", \\\"{x:500,y:725,t:1527794128442};\\\", \\\"{x:511,y:711,t:1527794128451};\\\", \\\"{x:515,y:701,t:1527794128463};\\\", \\\"{x:533,y:676,t:1527794128480};\\\", \\\"{x:549,y:655,t:1527794128496};\\\", \\\"{x:558,y:650,t:1527794128513};\\\", \\\"{x:566,y:637,t:1527794128530};\\\", \\\"{x:567,y:636,t:1527794128545};\\\" ] }, { \\\"rt\\\": 98142, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 753677, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:568,y:636,t:1527794225606};\\\", \\\"{x:542,y:633,t:1527794225623};\\\", \\\"{x:510,y:625,t:1527794225641};\\\", \\\"{x:441,y:608,t:1527794225656};\\\", \\\"{x:380,y:591,t:1527794225672};\\\", \\\"{x:357,y:580,t:1527794225694};\\\", \\\"{x:353,y:578,t:1527794225711};\\\", \\\"{x:352,y:577,t:1527794225727};\\\", \\\"{x:351,y:576,t:1527794225744};\\\", \\\"{x:347,y:573,t:1527794225780};\\\", \\\"{x:340,y:573,t:1527794225794};\\\", \\\"{x:333,y:568,t:1527794225811};\\\", \\\"{x:316,y:559,t:1527794225828};\\\", \\\"{x:290,y:546,t:1527794225845};\\\", \\\"{x:269,y:535,t:1527794225862};\\\", \\\"{x:259,y:526,t:1527794225877};\\\", \\\"{x:244,y:515,t:1527794225896};\\\", \\\"{x:223,y:504,t:1527794225911};\\\", \\\"{x:207,y:495,t:1527794225928};\\\", \\\"{x:179,y:482,t:1527794225945};\\\", \\\"{x:158,y:480,t:1527794225961};\\\", \\\"{x:146,y:477,t:1527794225977};\\\", \\\"{x:145,y:477,t:1527794225995};\\\", \\\"{x:143,y:477,t:1527794226028};\\\", \\\"{x:141,y:477,t:1527794226044};\\\", \\\"{x:138,y:480,t:1527794226062};\\\", \\\"{x:133,y:504,t:1527794226079};\\\", \\\"{x:133,y:515,t:1527794226095};\\\", \\\"{x:134,y:525,t:1527794226112};\\\", \\\"{x:136,y:528,t:1527794226128};\\\", \\\"{x:137,y:530,t:1527794226144};\\\", \\\"{x:138,y:531,t:1527794226172};\\\", \\\"{x:139,y:531,t:1527794226229};\\\", \\\"{x:145,y:530,t:1527794226245};\\\", \\\"{x:151,y:525,t:1527794226261};\\\", \\\"{x:153,y:523,t:1527794226280};\\\", \\\"{x:157,y:520,t:1527794226295};\\\", \\\"{x:157,y:518,t:1527794226311};\\\", \\\"{x:158,y:516,t:1527794226329};\\\", \\\"{x:161,y:512,t:1527794226345};\\\", \\\"{x:168,y:506,t:1527794226362};\\\", \\\"{x:169,y:506,t:1527794226380};\\\", \\\"{x:169,y:505,t:1527794226676};\\\", \\\"{x:175,y:507,t:1527794226684};\\\", \\\"{x:184,y:514,t:1527794226695};\\\", \\\"{x:221,y:550,t:1527794226712};\\\", \\\"{x:258,y:592,t:1527794226729};\\\", \\\"{x:287,y:620,t:1527794226746};\\\", \\\"{x:346,y:671,t:1527794226762};\\\", \\\"{x:402,y:712,t:1527794226778};\\\", \\\"{x:427,y:738,t:1527794226796};\\\", \\\"{x:446,y:756,t:1527794226812};\\\", \\\"{x:449,y:758,t:1527794226828};\\\", \\\"{x:453,y:761,t:1527794226845};\\\", \\\"{x:454,y:761,t:1527794226862};\\\", \\\"{x:456,y:761,t:1527794226879};\\\", \\\"{x:455,y:761,t:1527794226909};\\\", \\\"{x:453,y:760,t:1527794226916};\\\", \\\"{x:453,y:759,t:1527794226929};\\\", \\\"{x:453,y:756,t:1527794226946};\\\", \\\"{x:455,y:754,t:1527794226965};\\\", \\\"{x:461,y:748,t:1527794229068};\\\", \\\"{x:464,y:743,t:1527794229080};\\\", \\\"{x:472,y:739,t:1527794229097};\\\", \\\"{x:476,y:739,t:1527794229113};\\\", \\\"{x:488,y:741,t:1527794229130};\\\", \\\"{x:491,y:741,t:1527794229148};\\\", \\\"{x:492,y:741,t:1527794229163};\\\", \\\"{x:492,y:739,t:1527794229196};\\\", \\\"{x:493,y:737,t:1527794229204};\\\", \\\"{x:497,y:733,t:1527794229213};\\\", \\\"{x:501,y:729,t:1527794229230};\\\", \\\"{x:511,y:718,t:1527794229247};\\\", \\\"{x:525,y:705,t:1527794229263};\\\", \\\"{x:544,y:677,t:1527794229281};\\\", \\\"{x:557,y:654,t:1527794229297};\\\", \\\"{x:574,y:632,t:1527794229313};\\\" ] }, { \\\"rt\\\": 81453, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 836684, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:633,y:496,t:1527794229506};\\\", \\\"{x:630,y:496,t:1527794229909};\\\", \\\"{x:625,y:496,t:1527794229917};\\\", \\\"{x:619,y:496,t:1527794229931};\\\", \\\"{x:609,y:502,t:1527794229947};\\\", \\\"{x:598,y:506,t:1527794229965};\\\", \\\"{x:596,y:506,t:1527794229982};\\\", \\\"{x:595,y:506,t:1527794229997};\\\", \\\"{x:594,y:506,t:1527794230037};\\\", \\\"{x:592,y:506,t:1527794230053};\\\", \\\"{x:590,y:506,t:1527794230065};\\\", \\\"{x:584,y:506,t:1527794230082};\\\", \\\"{x:577,y:508,t:1527794230098};\\\", \\\"{x:572,y:510,t:1527794230115};\\\", \\\"{x:566,y:514,t:1527794230131};\\\", \\\"{x:558,y:517,t:1527794230148};\\\", \\\"{x:546,y:518,t:1527794230166};\\\", \\\"{x:546,y:519,t:1527794230182};\\\", \\\"{x:543,y:519,t:1527794230220};\\\", \\\"{x:542,y:519,t:1527794230231};\\\", \\\"{x:541,y:519,t:1527794230252};\\\", \\\"{x:543,y:519,t:1527794244809};\\\", \\\"{x:548,y:519,t:1527794244817};\\\", \\\"{x:555,y:521,t:1527794244830};\\\", \\\"{x:572,y:532,t:1527794244848};\\\", \\\"{x:588,y:538,t:1527794244863};\\\", \\\"{x:601,y:543,t:1527794244879};\\\", \\\"{x:607,y:548,t:1527794244896};\\\", \\\"{x:608,y:548,t:1527794244914};\\\", \\\"{x:613,y:555,t:1527794244930};\\\", \\\"{x:620,y:560,t:1527794244948};\\\", \\\"{x:620,y:562,t:1527794244964};\\\", \\\"{x:620,y:563,t:1527794244980};\\\", \\\"{x:620,y:566,t:1527794244997};\\\", \\\"{x:615,y:571,t:1527794245014};\\\", \\\"{x:608,y:575,t:1527794245030};\\\", \\\"{x:606,y:576,t:1527794245047};\\\", \\\"{x:603,y:578,t:1527794245064};\\\", \\\"{x:603,y:579,t:1527794245104};\\\", \\\"{x:598,y:580,t:1527794309788};\\\", \\\"{x:593,y:588,t:1527794309795};\\\", \\\"{x:588,y:596,t:1527794309810};\\\", \\\"{x:577,y:619,t:1527794309826};\\\", \\\"{x:566,y:641,t:1527794309841};\\\", \\\"{x:560,y:649,t:1527794309857};\\\", \\\"{x:558,y:653,t:1527794309869};\\\", \\\"{x:553,y:663,t:1527794309886};\\\", \\\"{x:549,y:670,t:1527794309902};\\\", \\\"{x:547,y:675,t:1527794309919};\\\", \\\"{x:545,y:679,t:1527794309936};\\\", \\\"{x:542,y:685,t:1527794309952};\\\", \\\"{x:541,y:690,t:1527794309969};\\\", \\\"{x:540,y:695,t:1527794309986};\\\", \\\"{x:537,y:697,t:1527794310107};\\\", \\\"{x:537,y:700,t:1527794310119};\\\", \\\"{x:537,y:703,t:1527794310136};\\\", \\\"{x:537,y:709,t:1527794310152};\\\", \\\"{x:537,y:710,t:1527794310170};\\\", \\\"{x:537,y:715,t:1527794310186};\\\", \\\"{x:537,y:716,t:1527794310227};\\\", \\\"{x:537,y:717,t:1527794310371};\\\", \\\"{x:537,y:718,t:1527794310411};\\\", \\\"{x:537,y:719,t:1527794310427};\\\", \\\"{x:537,y:721,t:1527794310541};\\\", \\\"{x:537,y:722,t:1527794310554};\\\", \\\"{x:537,y:725,t:1527794310569};\\\", \\\"{x:536,y:728,t:1527794310586};\\\", \\\"{x:536,y:731,t:1527794310603};\\\", \\\"{x:536,y:732,t:1527794310626};\\\", \\\"{x:534,y:734,t:1527794310650};\\\", \\\"{x:534,y:735,t:1527794310698};\\\", \\\"{x:534,y:736,t:1527794310707};\\\", \\\"{x:534,y:737,t:1527794310720};\\\", \\\"{x:534,y:738,t:1527794310736};\\\", \\\"{x:541,y:737,t:1527794311227};\\\", \\\"{x:548,y:734,t:1527794311237};\\\", \\\"{x:566,y:725,t:1527794311254};\\\", \\\"{x:602,y:701,t:1527794311270};\\\", \\\"{x:701,y:656,t:1527794311287};\\\", \\\"{x:775,y:613,t:1527794311304};\\\", \\\"{x:803,y:586,t:1527794311320};\\\", \\\"{x:867,y:543,t:1527794311337};\\\", \\\"{x:898,y:516,t:1527794311355};\\\", \\\"{x:911,y:501,t:1527794311371};\\\", \\\"{x:914,y:494,t:1527794311387};\\\", \\\"{x:916,y:492,t:1527794311405};\\\", \\\"{x:917,y:490,t:1527794311442};\\\", \\\"{x:918,y:488,t:1527794311458};\\\", \\\"{x:919,y:486,t:1527794311471};\\\", \\\"{x:921,y:480,t:1527794311487};\\\", \\\"{x:924,y:477,t:1527794311504};\\\" ] }, { \\\"rt\\\": 19555, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 857792, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:924,y:476,t:1527794319587};\\\", \\\"{x:928,y:475,t:1527794319595};\\\", \\\"{x:932,y:474,t:1527794319610};\\\", \\\"{x:958,y:465,t:1527794319627};\\\", \\\"{x:988,y:464,t:1527794319644};\\\", \\\"{x:1033,y:466,t:1527794319660};\\\", \\\"{x:1069,y:466,t:1527794319677};\\\", \\\"{x:1107,y:466,t:1527794319694};\\\", \\\"{x:1130,y:468,t:1527794319711};\\\", \\\"{x:1136,y:469,t:1527794319727};\\\", \\\"{x:1145,y:469,t:1527794319744};\\\", \\\"{x:1146,y:469,t:1527794319761};\\\", \\\"{x:1147,y:469,t:1527794319777};\\\", \\\"{x:1149,y:473,t:1527794319844};\\\", \\\"{x:1162,y:498,t:1527794319861};\\\", \\\"{x:1177,y:532,t:1527794319877};\\\", \\\"{x:1180,y:542,t:1527794319894};\\\", \\\"{x:1187,y:555,t:1527794319911};\\\", \\\"{x:1191,y:563,t:1527794319928};\\\", \\\"{x:1204,y:578,t:1527794319945};\\\", \\\"{x:1211,y:586,t:1527794319961};\\\", \\\"{x:1215,y:592,t:1527794319977};\\\", \\\"{x:1215,y:593,t:1527794319994};\\\", \\\"{x:1215,y:594,t:1527794320092};\\\", \\\"{x:1216,y:596,t:1527794321171};\\\", \\\"{x:1232,y:612,t:1527794321178};\\\", \\\"{x:1260,y:641,t:1527794321195};\\\", \\\"{x:1270,y:657,t:1527794321213};\\\", \\\"{x:1279,y:673,t:1527794321228};\\\", \\\"{x:1289,y:697,t:1527794321245};\\\", \\\"{x:1296,y:717,t:1527794321262};\\\", \\\"{x:1301,y:733,t:1527794321278};\\\", \\\"{x:1304,y:745,t:1527794321295};\\\", \\\"{x:1309,y:752,t:1527794321312};\\\", \\\"{x:1314,y:770,t:1527794321328};\\\", \\\"{x:1315,y:807,t:1527794321345};\\\", \\\"{x:1311,y:833,t:1527794321363};\\\", \\\"{x:1310,y:843,t:1527794321378};\\\", \\\"{x:1307,y:857,t:1527794321395};\\\", \\\"{x:1307,y:864,t:1527794321412};\\\", \\\"{x:1307,y:870,t:1527794321428};\\\", \\\"{x:1308,y:872,t:1527794321446};\\\", \\\"{x:1309,y:873,t:1527794321462};\\\", \\\"{x:1309,y:876,t:1527794321478};\\\", \\\"{x:1312,y:880,t:1527794321496};\\\", \\\"{x:1312,y:888,t:1527794321512};\\\", \\\"{x:1316,y:907,t:1527794321529};\\\", \\\"{x:1321,y:922,t:1527794321545};\\\", \\\"{x:1327,y:936,t:1527794321562};\\\", \\\"{x:1341,y:950,t:1527794321578};\\\", \\\"{x:1349,y:961,t:1527794321595};\\\", \\\"{x:1365,y:974,t:1527794321612};\\\", \\\"{x:1372,y:979,t:1527794321630};\\\", \\\"{x:1373,y:981,t:1527794321645};\\\", \\\"{x:1373,y:982,t:1527794321667};\\\", \\\"{x:1373,y:983,t:1527794321683};\\\", \\\"{x:1373,y:985,t:1527794321731};\\\", \\\"{x:1372,y:985,t:1527794321803};\\\", \\\"{x:1369,y:985,t:1527794321819};\\\", \\\"{x:1368,y:985,t:1527794321829};\\\", \\\"{x:1362,y:984,t:1527794321845};\\\", \\\"{x:1353,y:981,t:1527794321862};\\\", \\\"{x:1351,y:978,t:1527794321879};\\\", \\\"{x:1348,y:977,t:1527794321895};\\\", \\\"{x:1348,y:976,t:1527794321947};\\\", \\\"{x:1348,y:974,t:1527794321963};\\\", \\\"{x:1348,y:971,t:1527794321979};\\\", \\\"{x:1348,y:970,t:1527794322002};\\\", \\\"{x:1348,y:968,t:1527794322050};\\\", \\\"{x:1348,y:967,t:1527794322061};\\\", \\\"{x:1348,y:966,t:1527794322145};\\\", \\\"{x:1348,y:965,t:1527794322170};\\\", \\\"{x:1347,y:964,t:1527794322419};\\\", \\\"{x:1347,y:963,t:1527794322442};\\\", \\\"{x:1346,y:963,t:1527794322449};\\\", \\\"{x:1346,y:961,t:1527794322462};\\\", \\\"{x:1346,y:958,t:1527794322478};\\\", \\\"{x:1344,y:950,t:1527794322495};\\\", \\\"{x:1341,y:934,t:1527794322512};\\\", \\\"{x:1341,y:919,t:1527794322528};\\\", \\\"{x:1340,y:901,t:1527794322545};\\\", \\\"{x:1340,y:886,t:1527794322562};\\\", \\\"{x:1340,y:876,t:1527794322579};\\\", \\\"{x:1340,y:864,t:1527794322596};\\\", \\\"{x:1339,y:850,t:1527794322612};\\\", \\\"{x:1338,y:848,t:1527794322628};\\\", \\\"{x:1337,y:847,t:1527794322646};\\\", \\\"{x:1336,y:836,t:1527794322663};\\\", \\\"{x:1336,y:822,t:1527794322679};\\\", \\\"{x:1336,y:812,t:1527794322696};\\\", \\\"{x:1334,y:798,t:1527794322713};\\\", \\\"{x:1334,y:789,t:1527794322729};\\\", \\\"{x:1334,y:786,t:1527794322746};\\\", \\\"{x:1334,y:780,t:1527794322762};\\\", \\\"{x:1334,y:776,t:1527794322779};\\\", \\\"{x:1334,y:775,t:1527794322811};\\\", \\\"{x:1334,y:773,t:1527794322835};\\\", \\\"{x:1334,y:772,t:1527794322846};\\\", \\\"{x:1334,y:771,t:1527794322863};\\\", \\\"{x:1334,y:768,t:1527794322879};\\\", \\\"{x:1334,y:767,t:1527794322896};\\\", \\\"{x:1334,y:766,t:1527794322913};\\\", \\\"{x:1335,y:765,t:1527794322930};\\\", \\\"{x:1336,y:764,t:1527794322955};\\\", \\\"{x:1336,y:763,t:1527794322995};\\\", \\\"{x:1337,y:763,t:1527794323051};\\\", \\\"{x:1338,y:761,t:1527794323067};\\\", \\\"{x:1339,y:760,t:1527794323099};\\\", \\\"{x:1339,y:759,t:1527794323123};\\\", \\\"{x:1339,y:756,t:1527794323139};\\\", \\\"{x:1339,y:755,t:1527794323212};\\\", \\\"{x:1339,y:754,t:1527794323235};\\\", \\\"{x:1339,y:753,t:1527794323246};\\\", \\\"{x:1339,y:752,t:1527794323264};\\\", \\\"{x:1340,y:749,t:1527794323281};\\\", \\\"{x:1340,y:746,t:1527794323297};\\\", \\\"{x:1340,y:744,t:1527794323323};\\\", \\\"{x:1341,y:744,t:1527794323330};\\\", \\\"{x:1341,y:743,t:1527794323347};\\\", \\\"{x:1342,y:743,t:1527794323363};\\\", \\\"{x:1342,y:741,t:1527794323386};\\\", \\\"{x:1342,y:740,t:1527794323396};\\\", \\\"{x:1342,y:737,t:1527794323414};\\\", \\\"{x:1342,y:736,t:1527794323467};\\\", \\\"{x:1342,y:735,t:1527794323491};\\\", \\\"{x:1343,y:734,t:1527794323498};\\\", \\\"{x:1343,y:733,t:1527794323513};\\\", \\\"{x:1345,y:730,t:1527794323619};\\\", \\\"{x:1346,y:728,t:1527794323630};\\\", \\\"{x:1346,y:726,t:1527794323647};\\\", \\\"{x:1346,y:722,t:1527794323663};\\\", \\\"{x:1347,y:717,t:1527794323680};\\\", \\\"{x:1348,y:714,t:1527794323697};\\\", \\\"{x:1348,y:713,t:1527794323713};\\\", \\\"{x:1348,y:708,t:1527794323730};\\\", \\\"{x:1348,y:703,t:1527794323747};\\\", \\\"{x:1348,y:698,t:1527794323765};\\\", \\\"{x:1348,y:696,t:1527794323779};\\\", \\\"{x:1349,y:699,t:1527794324019};\\\", \\\"{x:1349,y:703,t:1527794324031};\\\", \\\"{x:1349,y:708,t:1527794324047};\\\", \\\"{x:1349,y:713,t:1527794324064};\\\", \\\"{x:1349,y:718,t:1527794324081};\\\", \\\"{x:1348,y:719,t:1527794324097};\\\", \\\"{x:1348,y:723,t:1527794324114};\\\", \\\"{x:1347,y:734,t:1527794324131};\\\", \\\"{x:1347,y:738,t:1527794324147};\\\", \\\"{x:1347,y:739,t:1527794324171};\\\", \\\"{x:1347,y:740,t:1527794324180};\\\", \\\"{x:1346,y:743,t:1527794324197};\\\", \\\"{x:1345,y:746,t:1527794324215};\\\", \\\"{x:1345,y:749,t:1527794324230};\\\", \\\"{x:1344,y:752,t:1527794324248};\\\", \\\"{x:1341,y:758,t:1527794324265};\\\", \\\"{x:1341,y:763,t:1527794324280};\\\", \\\"{x:1341,y:767,t:1527794324298};\\\", \\\"{x:1341,y:771,t:1527794324314};\\\", \\\"{x:1340,y:773,t:1527794324330};\\\", \\\"{x:1340,y:774,t:1527794324347};\\\", \\\"{x:1339,y:777,t:1527794324427};\\\", \\\"{x:1337,y:777,t:1527794324515};\\\", \\\"{x:1337,y:768,t:1527794324531};\\\", \\\"{x:1337,y:756,t:1527794324547};\\\", \\\"{x:1337,y:744,t:1527794324564};\\\", \\\"{x:1337,y:742,t:1527794324581};\\\", \\\"{x:1339,y:731,t:1527794324597};\\\", \\\"{x:1340,y:724,t:1527794324615};\\\", \\\"{x:1340,y:720,t:1527794324631};\\\", \\\"{x:1340,y:717,t:1527794324648};\\\", \\\"{x:1340,y:710,t:1527794324664};\\\", \\\"{x:1340,y:705,t:1527794324682};\\\", \\\"{x:1340,y:703,t:1527794324697};\\\", \\\"{x:1339,y:702,t:1527794324755};\\\", \\\"{x:1338,y:701,t:1527794325043};\\\", \\\"{x:1326,y:701,t:1527794325051};\\\", \\\"{x:1314,y:701,t:1527794325064};\\\", \\\"{x:1297,y:700,t:1527794325081};\\\", \\\"{x:1257,y:695,t:1527794325098};\\\", \\\"{x:1253,y:695,t:1527794325611};\\\", \\\"{x:1242,y:693,t:1527794325619};\\\", \\\"{x:1236,y:689,t:1527794325631};\\\", \\\"{x:1226,y:689,t:1527794325648};\\\", \\\"{x:1220,y:689,t:1527794325665};\\\", \\\"{x:1214,y:686,t:1527794325681};\\\", \\\"{x:1213,y:686,t:1527794325698};\\\", \\\"{x:1210,y:684,t:1527794325715};\\\", \\\"{x:1201,y:684,t:1527794325732};\\\", \\\"{x:1193,y:683,t:1527794325748};\\\", \\\"{x:1192,y:682,t:1527794325765};\\\", \\\"{x:1190,y:681,t:1527794325843};\\\", \\\"{x:1182,y:673,t:1527794325850};\\\", \\\"{x:1177,y:668,t:1527794325865};\\\", \\\"{x:1141,y:643,t:1527794325882};\\\", \\\"{x:1123,y:627,t:1527794325899};\\\", \\\"{x:1073,y:605,t:1527794325915};\\\", \\\"{x:1003,y:591,t:1527794325932};\\\", \\\"{x:905,y:559,t:1527794325949};\\\", \\\"{x:853,y:538,t:1527794325967};\\\", \\\"{x:837,y:535,t:1527794325981};\\\", \\\"{x:833,y:532,t:1527794325998};\\\", \\\"{x:833,y:531,t:1527794326015};\\\", \\\"{x:833,y:530,t:1527794326106};\\\", \\\"{x:833,y:528,t:1527794326116};\\\", \\\"{x:829,y:522,t:1527794326133};\\\", \\\"{x:826,y:514,t:1527794326149};\\\", \\\"{x:824,y:511,t:1527794326165};\\\", \\\"{x:823,y:506,t:1527794326182};\\\", \\\"{x:822,y:505,t:1527794326199};\\\", \\\"{x:822,y:502,t:1527794326216};\\\", \\\"{x:821,y:498,t:1527794326232};\\\", \\\"{x:819,y:494,t:1527794326249};\\\", \\\"{x:819,y:493,t:1527794326266};\\\", \\\"{x:819,y:491,t:1527794326282};\\\", \\\"{x:819,y:489,t:1527794326299};\\\", \\\"{x:820,y:489,t:1527794326554};\\\", \\\"{x:822,y:493,t:1527794326566};\\\", \\\"{x:823,y:494,t:1527794326583};\\\", \\\"{x:824,y:496,t:1527794326600};\\\", \\\"{x:825,y:496,t:1527794326939};\\\", \\\"{x:820,y:505,t:1527794326949};\\\", \\\"{x:767,y:532,t:1527794326967};\\\", \\\"{x:716,y:561,t:1527794326983};\\\", \\\"{x:695,y:575,t:1527794326999};\\\", \\\"{x:660,y:593,t:1527794327016};\\\", \\\"{x:646,y:605,t:1527794327033};\\\", \\\"{x:638,y:620,t:1527794327050};\\\", \\\"{x:625,y:626,t:1527794327065};\\\", \\\"{x:612,y:626,t:1527794327082};\\\", \\\"{x:608,y:629,t:1527794327100};\\\", \\\"{x:597,y:634,t:1527794327117};\\\", \\\"{x:588,y:635,t:1527794327132};\\\", \\\"{x:551,y:628,t:1527794327150};\\\", \\\"{x:536,y:624,t:1527794327165};\\\", \\\"{x:530,y:619,t:1527794327183};\\\", \\\"{x:524,y:618,t:1527794327199};\\\", \\\"{x:515,y:617,t:1527794327216};\\\", \\\"{x:503,y:611,t:1527794327233};\\\", \\\"{x:499,y:610,t:1527794327250};\\\", \\\"{x:493,y:610,t:1527794327267};\\\", \\\"{x:485,y:607,t:1527794327284};\\\", \\\"{x:471,y:604,t:1527794327299};\\\", \\\"{x:462,y:604,t:1527794327316};\\\", \\\"{x:446,y:604,t:1527794327333};\\\", \\\"{x:432,y:604,t:1527794327350};\\\", \\\"{x:427,y:604,t:1527794327367};\\\", \\\"{x:407,y:607,t:1527794327384};\\\", \\\"{x:395,y:614,t:1527794327400};\\\", \\\"{x:394,y:614,t:1527794327417};\\\", \\\"{x:394,y:615,t:1527794327458};\\\", \\\"{x:394,y:616,t:1527794327467};\\\", \\\"{x:378,y:614,t:1527794327484};\\\", \\\"{x:354,y:601,t:1527794327501};\\\", \\\"{x:302,y:574,t:1527794327519};\\\", \\\"{x:281,y:559,t:1527794327534};\\\", \\\"{x:270,y:549,t:1527794327550};\\\", \\\"{x:259,y:537,t:1527794327567};\\\", \\\"{x:252,y:529,t:1527794327583};\\\", \\\"{x:249,y:527,t:1527794327600};\\\", \\\"{x:247,y:527,t:1527794327706};\\\", \\\"{x:245,y:527,t:1527794327717};\\\", \\\"{x:236,y:530,t:1527794327734};\\\", \\\"{x:224,y:535,t:1527794327750};\\\", \\\"{x:220,y:537,t:1527794327767};\\\", \\\"{x:220,y:539,t:1527794327784};\\\", \\\"{x:224,y:545,t:1527794327800};\\\", \\\"{x:226,y:547,t:1527794327817};\\\", \\\"{x:226,y:548,t:1527794327955};\\\", \\\"{x:230,y:548,t:1527794327971};\\\", \\\"{x:230,y:550,t:1527794328050};\\\", \\\"{x:223,y:554,t:1527794328067};\\\", \\\"{x:195,y:555,t:1527794328084};\\\", \\\"{x:173,y:557,t:1527794328101};\\\", \\\"{x:168,y:557,t:1527794328117};\\\", \\\"{x:164,y:559,t:1527794328134};\\\", \\\"{x:163,y:559,t:1527794328283};\\\", \\\"{x:163,y:558,t:1527794328314};\\\", \\\"{x:163,y:557,t:1527794328322};\\\", \\\"{x:163,y:555,t:1527794328347};\\\", \\\"{x:163,y:552,t:1527794328367};\\\", \\\"{x:163,y:551,t:1527794328384};\\\", \\\"{x:165,y:550,t:1527794328665};\\\", \\\"{x:170,y:546,t:1527794328674};\\\", \\\"{x:185,y:538,t:1527794328684};\\\", \\\"{x:212,y:533,t:1527794328701};\\\", \\\"{x:332,y:536,t:1527794328718};\\\", \\\"{x:484,y:538,t:1527794328735};\\\", \\\"{x:615,y:544,t:1527794328751};\\\", \\\"{x:730,y:552,t:1527794328768};\\\", \\\"{x:822,y:551,t:1527794328785};\\\", \\\"{x:919,y:551,t:1527794328801};\\\", \\\"{x:1003,y:553,t:1527794328818};\\\", \\\"{x:1012,y:554,t:1527794328835};\\\", \\\"{x:1015,y:555,t:1527794328850};\\\", \\\"{x:1016,y:555,t:1527794328868};\\\", \\\"{x:1018,y:555,t:1527794328890};\\\", \\\"{x:1023,y:557,t:1527794328901};\\\", \\\"{x:1028,y:558,t:1527794328917};\\\", \\\"{x:1038,y:558,t:1527794328934};\\\", \\\"{x:1040,y:558,t:1527794328951};\\\", \\\"{x:1047,y:558,t:1527794328968};\\\", \\\"{x:1050,y:558,t:1527794328985};\\\", \\\"{x:1051,y:558,t:1527794329001};\\\", \\\"{x:1052,y:558,t:1527794329018};\\\", \\\"{x:1052,y:557,t:1527794329106};\\\", \\\"{x:1052,y:555,t:1527794329129};\\\", \\\"{x:1052,y:553,t:1527794329146};\\\", \\\"{x:1052,y:550,t:1527794329154};\\\", \\\"{x:1051,y:550,t:1527794329168};\\\", \\\"{x:1045,y:546,t:1527794329185};\\\", \\\"{x:1025,y:537,t:1527794329201};\\\", \\\"{x:997,y:526,t:1527794329218};\\\", \\\"{x:982,y:525,t:1527794329234};\\\", \\\"{x:972,y:519,t:1527794329251};\\\", \\\"{x:969,y:518,t:1527794329268};\\\", \\\"{x:960,y:515,t:1527794329285};\\\", \\\"{x:955,y:514,t:1527794329301};\\\", \\\"{x:954,y:514,t:1527794329318};\\\", \\\"{x:951,y:514,t:1527794329435};\\\", \\\"{x:946,y:514,t:1527794329452};\\\", \\\"{x:926,y:512,t:1527794329468};\\\", \\\"{x:921,y:512,t:1527794329485};\\\", \\\"{x:865,y:512,t:1527794329503};\\\", \\\"{x:835,y:512,t:1527794329519};\\\", \\\"{x:822,y:510,t:1527794329536};\\\", \\\"{x:819,y:510,t:1527794329552};\\\", \\\"{x:821,y:510,t:1527794329722};\\\", \\\"{x:823,y:510,t:1527794329735};\\\", \\\"{x:827,y:508,t:1527794329753};\\\", \\\"{x:834,y:505,t:1527794329769};\\\", \\\"{x:835,y:504,t:1527794329786};\\\", \\\"{x:835,y:503,t:1527794330354};\\\", \\\"{x:835,y:502,t:1527794330675};\\\", \\\"{x:833,y:501,t:1527794330690};\\\", \\\"{x:827,y:501,t:1527794330754};\\\", \\\"{x:788,y:530,t:1527794330771};\\\", \\\"{x:745,y:563,t:1527794330788};\\\", \\\"{x:712,y:586,t:1527794330804};\\\", \\\"{x:686,y:607,t:1527794330820};\\\", \\\"{x:670,y:620,t:1527794330836};\\\", \\\"{x:652,y:631,t:1527794330853};\\\", \\\"{x:640,y:637,t:1527794330871};\\\", \\\"{x:623,y:647,t:1527794330885};\\\", \\\"{x:612,y:651,t:1527794330902};\\\", \\\"{x:607,y:654,t:1527794330920};\\\", \\\"{x:596,y:659,t:1527794330936};\\\", \\\"{x:595,y:661,t:1527794330952};\\\", \\\"{x:592,y:663,t:1527794330970};\\\", \\\"{x:592,y:665,t:1527794331001};\\\", \\\"{x:592,y:666,t:1527794331010};\\\", \\\"{x:592,y:667,t:1527794331019};\\\", \\\"{x:592,y:671,t:1527794331036};\\\", \\\"{x:590,y:674,t:1527794331053};\\\", \\\"{x:583,y:683,t:1527794331070};\\\", \\\"{x:577,y:691,t:1527794331087};\\\", \\\"{x:570,y:700,t:1527794331103};\\\", \\\"{x:570,y:702,t:1527794331123};\\\", \\\"{x:569,y:705,t:1527794331137};\\\", \\\"{x:568,y:707,t:1527794331153};\\\", \\\"{x:565,y:709,t:1527794331170};\\\", \\\"{x:561,y:710,t:1527794331187};\\\", \\\"{x:557,y:712,t:1527794331203};\\\", \\\"{x:548,y:713,t:1527794331220};\\\", \\\"{x:542,y:714,t:1527794331237};\\\", \\\"{x:540,y:717,t:1527794331254};\\\", \\\"{x:538,y:717,t:1527794331270};\\\", \\\"{x:538,y:718,t:1527794331298};\\\", \\\"{x:538,y:719,t:1527794331313};\\\", \\\"{x:536,y:724,t:1527794331322};\\\", \\\"{x:534,y:725,t:1527794331336};\\\", \\\"{x:534,y:726,t:1527794331353};\\\", \\\"{x:534,y:728,t:1527794331369};\\\", \\\"{x:532,y:731,t:1527794331385};\\\" ] }, { \\\"rt\\\": 26033, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 885052, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:731,t:1527794340379};\\\", \\\"{x:534,y:731,t:1527794340393};\\\", \\\"{x:539,y:729,t:1527794340402};\\\", \\\"{x:545,y:726,t:1527794340416};\\\", \\\"{x:563,y:718,t:1527794340433};\\\", \\\"{x:565,y:714,t:1527794340449};\\\", \\\"{x:572,y:704,t:1527794340460};\\\", \\\"{x:622,y:685,t:1527794340477};\\\", \\\"{x:683,y:670,t:1527794340494};\\\", \\\"{x:779,y:649,t:1527794340509};\\\", \\\"{x:900,y:634,t:1527794340527};\\\", \\\"{x:1020,y:616,t:1527794340544};\\\", \\\"{x:1137,y:610,t:1527794340560};\\\", \\\"{x:1232,y:611,t:1527794340578};\\\", \\\"{x:1317,y:612,t:1527794340593};\\\", \\\"{x:1359,y:611,t:1527794340610};\\\", \\\"{x:1384,y:610,t:1527794340627};\\\", \\\"{x:1398,y:619,t:1527794340645};\\\", \\\"{x:1415,y:620,t:1527794340661};\\\", \\\"{x:1420,y:620,t:1527794340678};\\\", \\\"{x:1435,y:622,t:1527794340695};\\\", \\\"{x:1440,y:622,t:1527794340711};\\\", \\\"{x:1440,y:624,t:1527794340809};\\\", \\\"{x:1437,y:628,t:1527794340817};\\\", \\\"{x:1434,y:630,t:1527794340827};\\\", \\\"{x:1427,y:634,t:1527794340844};\\\", \\\"{x:1416,y:646,t:1527794340861};\\\", \\\"{x:1406,y:655,t:1527794340877};\\\", \\\"{x:1395,y:668,t:1527794340894};\\\", \\\"{x:1390,y:670,t:1527794340911};\\\", \\\"{x:1377,y:681,t:1527794340927};\\\", \\\"{x:1367,y:690,t:1527794340944};\\\", \\\"{x:1366,y:692,t:1527794340961};\\\", \\\"{x:1358,y:711,t:1527794340977};\\\", \\\"{x:1358,y:715,t:1527794340994};\\\", \\\"{x:1356,y:721,t:1527794341012};\\\", \\\"{x:1356,y:722,t:1527794341029};\\\", \\\"{x:1356,y:723,t:1527794341058};\\\", \\\"{x:1356,y:724,t:1527794341067};\\\", \\\"{x:1356,y:726,t:1527794341091};\\\", \\\"{x:1356,y:727,t:1527794341099};\\\", \\\"{x:1356,y:729,t:1527794341114};\\\", \\\"{x:1356,y:730,t:1527794341130};\\\", \\\"{x:1356,y:732,t:1527794341146};\\\", \\\"{x:1356,y:733,t:1527794341162};\\\", \\\"{x:1356,y:734,t:1527794341179};\\\", \\\"{x:1356,y:738,t:1527794341196};\\\", \\\"{x:1357,y:742,t:1527794341212};\\\", \\\"{x:1358,y:746,t:1527794341229};\\\", \\\"{x:1358,y:747,t:1527794341246};\\\", \\\"{x:1358,y:748,t:1527794341290};\\\", \\\"{x:1358,y:749,t:1527794341475};\\\", \\\"{x:1358,y:750,t:1527794341482};\\\", \\\"{x:1358,y:752,t:1527794341495};\\\", \\\"{x:1358,y:754,t:1527794341512};\\\", \\\"{x:1358,y:756,t:1527794341528};\\\", \\\"{x:1358,y:757,t:1527794341546};\\\", \\\"{x:1358,y:759,t:1527794341579};\\\", \\\"{x:1358,y:760,t:1527794341596};\\\", \\\"{x:1358,y:762,t:1527794341618};\\\", \\\"{x:1356,y:762,t:1527794341819};\\\", \\\"{x:1355,y:763,t:1527794341859};\\\", \\\"{x:1354,y:763,t:1527794341882};\\\", \\\"{x:1352,y:763,t:1527794341909};\\\", \\\"{x:1351,y:764,t:1527794341970};\\\", \\\"{x:1350,y:764,t:1527794341994};\\\", \\\"{x:1350,y:765,t:1527794342098};\\\", \\\"{x:1349,y:765,t:1527794342187};\\\", \\\"{x:1347,y:765,t:1527794342371};\\\", \\\"{x:1347,y:763,t:1527794342381};\\\", \\\"{x:1347,y:760,t:1527794342397};\\\", \\\"{x:1347,y:759,t:1527794342442};\\\", \\\"{x:1347,y:758,t:1527794342450};\\\", \\\"{x:1347,y:757,t:1527794342463};\\\", \\\"{x:1347,y:753,t:1527794342480};\\\", \\\"{x:1347,y:752,t:1527794342496};\\\", \\\"{x:1349,y:747,t:1527794342513};\\\", \\\"{x:1349,y:746,t:1527794342530};\\\", \\\"{x:1349,y:742,t:1527794342546};\\\", \\\"{x:1351,y:736,t:1527794342564};\\\", \\\"{x:1352,y:732,t:1527794342580};\\\", \\\"{x:1352,y:728,t:1527794342597};\\\", \\\"{x:1352,y:727,t:1527794342618};\\\", \\\"{x:1352,y:725,t:1527794342630};\\\", \\\"{x:1349,y:721,t:1527794342647};\\\", \\\"{x:1349,y:718,t:1527794342664};\\\", \\\"{x:1348,y:715,t:1527794342681};\\\", \\\"{x:1345,y:711,t:1527794342697};\\\", \\\"{x:1345,y:709,t:1527794342714};\\\", \\\"{x:1345,y:707,t:1527794342730};\\\", \\\"{x:1344,y:704,t:1527794342747};\\\", \\\"{x:1344,y:702,t:1527794342764};\\\", \\\"{x:1342,y:699,t:1527794342780};\\\", \\\"{x:1341,y:697,t:1527794342798};\\\", \\\"{x:1341,y:696,t:1527794342815};\\\", \\\"{x:1341,y:693,t:1527794342831};\\\", \\\"{x:1340,y:691,t:1527794342848};\\\", \\\"{x:1340,y:690,t:1527794342865};\\\", \\\"{x:1340,y:687,t:1527794342882};\\\", \\\"{x:1340,y:686,t:1527794342906};\\\", \\\"{x:1340,y:685,t:1527794342922};\\\", \\\"{x:1340,y:684,t:1527794342939};\\\", \\\"{x:1339,y:685,t:1527794346354};\\\", \\\"{x:1338,y:686,t:1527794346411};\\\", \\\"{x:1338,y:688,t:1527794346442};\\\", \\\"{x:1338,y:689,t:1527794346459};\\\", \\\"{x:1338,y:690,t:1527794346470};\\\", \\\"{x:1338,y:694,t:1527794346486};\\\", \\\"{x:1338,y:697,t:1527794346504};\\\", \\\"{x:1338,y:700,t:1527794346522};\\\", \\\"{x:1338,y:704,t:1527794346536};\\\", \\\"{x:1338,y:708,t:1527794346553};\\\", \\\"{x:1338,y:714,t:1527794346570};\\\", \\\"{x:1338,y:716,t:1527794346586};\\\", \\\"{x:1338,y:719,t:1527794346619};\\\", \\\"{x:1338,y:721,t:1527794346651};\\\", \\\"{x:1338,y:722,t:1527794346666};\\\", \\\"{x:1338,y:724,t:1527794346723};\\\", \\\"{x:1338,y:726,t:1527794346737};\\\", \\\"{x:1337,y:730,t:1527794346753};\\\", \\\"{x:1337,y:734,t:1527794346770};\\\", \\\"{x:1337,y:739,t:1527794346786};\\\", \\\"{x:1337,y:741,t:1527794346804};\\\", \\\"{x:1336,y:743,t:1527794346923};\\\", \\\"{x:1335,y:743,t:1527794346937};\\\", \\\"{x:1335,y:747,t:1527794346954};\\\", \\\"{x:1335,y:749,t:1527794346970};\\\", \\\"{x:1335,y:750,t:1527794346987};\\\", \\\"{x:1335,y:751,t:1527794347004};\\\", \\\"{x:1337,y:753,t:1527794347021};\\\", \\\"{x:1337,y:754,t:1527794347042};\\\", \\\"{x:1338,y:754,t:1527794347067};\\\", \\\"{x:1339,y:756,t:1527794347074};\\\", \\\"{x:1341,y:759,t:1527794347087};\\\", \\\"{x:1345,y:762,t:1527794347105};\\\", \\\"{x:1345,y:763,t:1527794347121};\\\", \\\"{x:1346,y:764,t:1527794347137};\\\", \\\"{x:1350,y:769,t:1527794347155};\\\", \\\"{x:1352,y:771,t:1527794347194};\\\", \\\"{x:1352,y:770,t:1527794347706};\\\", \\\"{x:1351,y:770,t:1527794347722};\\\", \\\"{x:1350,y:768,t:1527794347851};\\\", \\\"{x:1350,y:767,t:1527794347871};\\\", \\\"{x:1349,y:767,t:1527794347898};\\\", \\\"{x:1349,y:765,t:1527794348018};\\\", \\\"{x:1338,y:764,t:1527794351044};\\\", \\\"{x:1247,y:764,t:1527794351060};\\\", \\\"{x:1215,y:757,t:1527794351076};\\\", \\\"{x:1209,y:757,t:1527794351094};\\\", \\\"{x:1204,y:756,t:1527794351110};\\\", \\\"{x:1172,y:755,t:1527794351126};\\\", \\\"{x:1119,y:739,t:1527794351143};\\\", \\\"{x:1061,y:724,t:1527794351160};\\\", \\\"{x:1025,y:711,t:1527794351176};\\\", \\\"{x:1012,y:703,t:1527794351193};\\\", \\\"{x:939,y:670,t:1527794351210};\\\", \\\"{x:887,y:651,t:1527794351226};\\\", \\\"{x:858,y:634,t:1527794351243};\\\", \\\"{x:836,y:625,t:1527794351261};\\\", \\\"{x:830,y:620,t:1527794351277};\\\", \\\"{x:819,y:617,t:1527794351293};\\\", \\\"{x:817,y:616,t:1527794351303};\\\", \\\"{x:800,y:611,t:1527794351319};\\\", \\\"{x:790,y:606,t:1527794351336};\\\", \\\"{x:778,y:602,t:1527794351352};\\\", \\\"{x:751,y:593,t:1527794351369};\\\", \\\"{x:709,y:579,t:1527794351385};\\\", \\\"{x:678,y:571,t:1527794351402};\\\", \\\"{x:654,y:565,t:1527794351419};\\\", \\\"{x:632,y:556,t:1527794351435};\\\", \\\"{x:599,y:549,t:1527794351453};\\\", \\\"{x:560,y:544,t:1527794351469};\\\", \\\"{x:522,y:544,t:1527794351486};\\\", \\\"{x:459,y:548,t:1527794351504};\\\", \\\"{x:431,y:558,t:1527794351519};\\\", \\\"{x:421,y:560,t:1527794351535};\\\", \\\"{x:408,y:567,t:1527794351553};\\\", \\\"{x:392,y:580,t:1527794351569};\\\", \\\"{x:386,y:585,t:1527794351585};\\\", \\\"{x:376,y:593,t:1527794351603};\\\", \\\"{x:361,y:600,t:1527794351620};\\\", \\\"{x:348,y:605,t:1527794351636};\\\", \\\"{x:339,y:607,t:1527794351652};\\\", \\\"{x:337,y:607,t:1527794351669};\\\", \\\"{x:334,y:607,t:1527794351685};\\\", \\\"{x:332,y:607,t:1527794351703};\\\", \\\"{x:330,y:606,t:1527794351719};\\\", \\\"{x:323,y:604,t:1527794351735};\\\", \\\"{x:315,y:601,t:1527794351753};\\\", \\\"{x:304,y:594,t:1527794351770};\\\", \\\"{x:297,y:590,t:1527794351786};\\\", \\\"{x:293,y:588,t:1527794351803};\\\", \\\"{x:282,y:585,t:1527794351819};\\\", \\\"{x:269,y:579,t:1527794351836};\\\", \\\"{x:250,y:569,t:1527794351852};\\\", \\\"{x:233,y:558,t:1527794351870};\\\", \\\"{x:216,y:546,t:1527794351887};\\\", \\\"{x:202,y:537,t:1527794351903};\\\", \\\"{x:190,y:532,t:1527794351920};\\\", \\\"{x:189,y:531,t:1527794351937};\\\", \\\"{x:188,y:531,t:1527794351952};\\\", \\\"{x:184,y:532,t:1527794352082};\\\", \\\"{x:184,y:533,t:1527794352090};\\\", \\\"{x:181,y:534,t:1527794352103};\\\", \\\"{x:180,y:536,t:1527794352120};\\\", \\\"{x:179,y:537,t:1527794352137};\\\", \\\"{x:178,y:538,t:1527794352153};\\\", \\\"{x:177,y:539,t:1527794352170};\\\", \\\"{x:176,y:539,t:1527794352194};\\\", \\\"{x:175,y:539,t:1527794352203};\\\", \\\"{x:174,y:540,t:1527794352220};\\\", \\\"{x:173,y:540,t:1527794352237};\\\", \\\"{x:172,y:540,t:1527794352314};\\\", \\\"{x:171,y:540,t:1527794352338};\\\", \\\"{x:170,y:540,t:1527794352353};\\\", \\\"{x:169,y:540,t:1527794352458};\\\", \\\"{x:170,y:539,t:1527794358275};\\\", \\\"{x:190,y:548,t:1527794358291};\\\", \\\"{x:265,y:582,t:1527794358310};\\\", \\\"{x:333,y:607,t:1527794358325};\\\", \\\"{x:371,y:623,t:1527794358341};\\\", \\\"{x:383,y:633,t:1527794358358};\\\", \\\"{x:412,y:641,t:1527794358375};\\\", \\\"{x:425,y:649,t:1527794358391};\\\", \\\"{x:431,y:650,t:1527794358408};\\\", \\\"{x:445,y:651,t:1527794358425};\\\", \\\"{x:463,y:663,t:1527794358441};\\\", \\\"{x:464,y:663,t:1527794358458};\\\", \\\"{x:469,y:667,t:1527794358474};\\\", \\\"{x:472,y:668,t:1527794358492};\\\", \\\"{x:473,y:671,t:1527794358667};\\\", \\\"{x:473,y:672,t:1527794358674};\\\", \\\"{x:474,y:679,t:1527794358691};\\\", \\\"{x:477,y:688,t:1527794358709};\\\", \\\"{x:486,y:696,t:1527794358724};\\\", \\\"{x:493,y:702,t:1527794358741};\\\", \\\"{x:496,y:703,t:1527794358758};\\\", \\\"{x:502,y:710,t:1527794358775};\\\", \\\"{x:512,y:715,t:1527794358792};\\\", \\\"{x:515,y:718,t:1527794358808};\\\", \\\"{x:517,y:719,t:1527794358825};\\\", \\\"{x:518,y:720,t:1527794358843};\\\", \\\"{x:519,y:720,t:1527794358898};\\\", \\\"{x:520,y:720,t:1527794358971};\\\", \\\"{x:521,y:720,t:1527794358978};\\\", \\\"{x:522,y:722,t:1527794359002};\\\", \\\"{x:523,y:722,t:1527794359025};\\\", \\\"{x:524,y:725,t:1527794359041};\\\", \\\"{x:525,y:727,t:1527794359059};\\\", \\\"{x:526,y:728,t:1527794359075};\\\", \\\"{x:527,y:729,t:1527794359569};\\\", \\\"{x:529,y:728,t:1527794359577};\\\", \\\"{x:530,y:727,t:1527794359593};\\\", \\\"{x:532,y:725,t:1527794359608};\\\", \\\"{x:535,y:723,t:1527794359625};\\\", \\\"{x:537,y:721,t:1527794359642};\\\", \\\"{x:538,y:720,t:1527794359659};\\\", \\\"{x:538,y:719,t:1527794359706};\\\", \\\"{x:539,y:718,t:1527794359714};\\\", \\\"{x:540,y:717,t:1527794359730};\\\", \\\"{x:540,y:716,t:1527794359741};\\\", \\\"{x:540,y:715,t:1527794359758};\\\", \\\"{x:540,y:714,t:1527794359802};\\\", \\\"{x:540,y:713,t:1527794359825};\\\", \\\"{x:540,y:709,t:1527794359843};\\\", \\\"{x:540,y:706,t:1527794359859};\\\", \\\"{x:538,y:700,t:1527794359876};\\\", \\\"{x:537,y:699,t:1527794359898};\\\" ] }, { \\\"rt\\\": 45225, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 931563, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -F -Z -Z -5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:698,t:1527794365214};\\\", \\\"{x:539,y:695,t:1527794365222};\\\", \\\"{x:540,y:692,t:1527794365235};\\\", \\\"{x:567,y:689,t:1527794365251};\\\", \\\"{x:600,y:687,t:1527794365268};\\\", \\\"{x:655,y:672,t:1527794365284};\\\", \\\"{x:773,y:673,t:1527794365301};\\\", \\\"{x:956,y:677,t:1527794365318};\\\", \\\"{x:1141,y:658,t:1527794365335};\\\", \\\"{x:1323,y:635,t:1527794365352};\\\", \\\"{x:1512,y:601,t:1527794365367};\\\", \\\"{x:1656,y:557,t:1527794365384};\\\", \\\"{x:1754,y:521,t:1527794365400};\\\", \\\"{x:1807,y:494,t:1527794365417};\\\", \\\"{x:1838,y:473,t:1527794365434};\\\", \\\"{x:1885,y:444,t:1527794365451};\\\", \\\"{x:1919,y:418,t:1527794365467};\\\", \\\"{x:1919,y:398,t:1527794365484};\\\", \\\"{x:1919,y:384,t:1527794365500};\\\", \\\"{x:1919,y:373,t:1527794365516};\\\", \\\"{x:1919,y:365,t:1527794365533};\\\", \\\"{x:1919,y:363,t:1527794365550};\\\", \\\"{x:1919,y:361,t:1527794365630};\\\", \\\"{x:1919,y:358,t:1527794365637};\\\", \\\"{x:1919,y:350,t:1527794365650};\\\", \\\"{x:1919,y:340,t:1527794365666};\\\", \\\"{x:1919,y:331,t:1527794365683};\\\", \\\"{x:1919,y:311,t:1527794365701};\\\", \\\"{x:1919,y:299,t:1527794365716};\\\", \\\"{x:1919,y:264,t:1527794365733};\\\", \\\"{x:1919,y:233,t:1527794365750};\\\", \\\"{x:1919,y:203,t:1527794365766};\\\", \\\"{x:1919,y:179,t:1527794365783};\\\", \\\"{x:1919,y:163,t:1527794365800};\\\", \\\"{x:1919,y:149,t:1527794365817};\\\", \\\"{x:1919,y:130,t:1527794365834};\\\", \\\"{x:1919,y:123,t:1527794365851};\\\", \\\"{x:1919,y:115,t:1527794365868};\\\", \\\"{x:1919,y:110,t:1527794365884};\\\", \\\"{x:1919,y:101,t:1527794365900};\\\", \\\"{x:1919,y:94,t:1527794365917};\\\", \\\"{x:1919,y:87,t:1527794365934};\\\", \\\"{x:1919,y:79,t:1527794365950};\\\", \\\"{x:1919,y:73,t:1527794365968};\\\", \\\"{x:1919,y:68,t:1527794365984};\\\", \\\"{x:1919,y:66,t:1527794366000};\\\", \\\"{x:1919,y:65,t:1527794366018};\\\", \\\"{x:1918,y:65,t:1527794366198};\\\", \\\"{x:1907,y:65,t:1527794366206};\\\", \\\"{x:1898,y:65,t:1527794366218};\\\", \\\"{x:1880,y:60,t:1527794366234};\\\", \\\"{x:1855,y:58,t:1527794366251};\\\", \\\"{x:1834,y:57,t:1527794366268};\\\", \\\"{x:1813,y:55,t:1527794366286};\\\", \\\"{x:1808,y:52,t:1527794366302};\\\", \\\"{x:1790,y:52,t:1527794366318};\\\", \\\"{x:1777,y:52,t:1527794366336};\\\", \\\"{x:1758,y:55,t:1527794366352};\\\", \\\"{x:1738,y:59,t:1527794366369};\\\", \\\"{x:1718,y:64,t:1527794366385};\\\", \\\"{x:1705,y:66,t:1527794366402};\\\", \\\"{x:1680,y:80,t:1527794366418};\\\", \\\"{x:1658,y:91,t:1527794366435};\\\", \\\"{x:1631,y:111,t:1527794366452};\\\", \\\"{x:1606,y:143,t:1527794366469};\\\", \\\"{x:1571,y:210,t:1527794366486};\\\", \\\"{x:1530,y:269,t:1527794366502};\\\", \\\"{x:1483,y:341,t:1527794366518};\\\", \\\"{x:1449,y:401,t:1527794366536};\\\", \\\"{x:1437,y:431,t:1527794366552};\\\", \\\"{x:1428,y:466,t:1527794366569};\\\", \\\"{x:1422,y:501,t:1527794366585};\\\", \\\"{x:1423,y:555,t:1527794366603};\\\", \\\"{x:1423,y:573,t:1527794366619};\\\", \\\"{x:1420,y:577,t:1527794366636};\\\", \\\"{x:1418,y:591,t:1527794366653};\\\", \\\"{x:1415,y:603,t:1527794366669};\\\", \\\"{x:1416,y:617,t:1527794366685};\\\", \\\"{x:1424,y:640,t:1527794366702};\\\", \\\"{x:1427,y:650,t:1527794366719};\\\", \\\"{x:1430,y:655,t:1527794366735};\\\", \\\"{x:1435,y:658,t:1527794366753};\\\", \\\"{x:1436,y:659,t:1527794366769};\\\", \\\"{x:1436,y:658,t:1527794366785};\\\", \\\"{x:1436,y:657,t:1527794367103};\\\", \\\"{x:1436,y:656,t:1527794367119};\\\", \\\"{x:1436,y:655,t:1527794367182};\\\", \\\"{x:1434,y:655,t:1527794367189};\\\", \\\"{x:1426,y:655,t:1527794367203};\\\", \\\"{x:1411,y:664,t:1527794367220};\\\", \\\"{x:1404,y:669,t:1527794367236};\\\", \\\"{x:1395,y:677,t:1527794367253};\\\", \\\"{x:1380,y:691,t:1527794367270};\\\", \\\"{x:1368,y:702,t:1527794367286};\\\", \\\"{x:1356,y:709,t:1527794367302};\\\", \\\"{x:1346,y:717,t:1527794367319};\\\", \\\"{x:1342,y:721,t:1527794367336};\\\", \\\"{x:1337,y:730,t:1527794367352};\\\", \\\"{x:1329,y:738,t:1527794367369};\\\", \\\"{x:1320,y:746,t:1527794367386};\\\", \\\"{x:1313,y:755,t:1527794367402};\\\", \\\"{x:1305,y:762,t:1527794367419};\\\", \\\"{x:1300,y:766,t:1527794367436};\\\", \\\"{x:1292,y:774,t:1527794367452};\\\", \\\"{x:1288,y:780,t:1527794367469};\\\", \\\"{x:1284,y:785,t:1527794367486};\\\", \\\"{x:1282,y:790,t:1527794367502};\\\", \\\"{x:1279,y:795,t:1527794367519};\\\", \\\"{x:1272,y:804,t:1527794367536};\\\", \\\"{x:1266,y:812,t:1527794367552};\\\", \\\"{x:1262,y:814,t:1527794367569};\\\", \\\"{x:1252,y:820,t:1527794367586};\\\", \\\"{x:1241,y:828,t:1527794367602};\\\", \\\"{x:1235,y:831,t:1527794367619};\\\", \\\"{x:1228,y:833,t:1527794367637};\\\", \\\"{x:1223,y:834,t:1527794367653};\\\", \\\"{x:1222,y:834,t:1527794367669};\\\", \\\"{x:1214,y:834,t:1527794367689};\\\", \\\"{x:1204,y:834,t:1527794367703};\\\", \\\"{x:1200,y:834,t:1527794367719};\\\", \\\"{x:1198,y:834,t:1527794367736};\\\", \\\"{x:1198,y:833,t:1527794367752};\\\", \\\"{x:1196,y:832,t:1527794367769};\\\", \\\"{x:1198,y:830,t:1527794367786};\\\", \\\"{x:1206,y:815,t:1527794367803};\\\", \\\"{x:1212,y:791,t:1527794367819};\\\", \\\"{x:1222,y:746,t:1527794367836};\\\", \\\"{x:1242,y:709,t:1527794367853};\\\", \\\"{x:1256,y:694,t:1527794367869};\\\", \\\"{x:1267,y:679,t:1527794367886};\\\", \\\"{x:1277,y:656,t:1527794367903};\\\", \\\"{x:1287,y:628,t:1527794367919};\\\", \\\"{x:1293,y:613,t:1527794367936};\\\", \\\"{x:1300,y:596,t:1527794367953};\\\", \\\"{x:1308,y:585,t:1527794367969};\\\", \\\"{x:1312,y:574,t:1527794367986};\\\", \\\"{x:1315,y:565,t:1527794368003};\\\", \\\"{x:1319,y:553,t:1527794368019};\\\", \\\"{x:1322,y:547,t:1527794368037};\\\", \\\"{x:1322,y:557,t:1527794368150};\\\", \\\"{x:1322,y:563,t:1527794368158};\\\", \\\"{x:1322,y:576,t:1527794368170};\\\", \\\"{x:1323,y:602,t:1527794368186};\\\", \\\"{x:1330,y:636,t:1527794368203};\\\", \\\"{x:1337,y:655,t:1527794368220};\\\", \\\"{x:1343,y:667,t:1527794368237};\\\", \\\"{x:1348,y:694,t:1527794368254};\\\", \\\"{x:1360,y:713,t:1527794368271};\\\", \\\"{x:1366,y:727,t:1527794368286};\\\", \\\"{x:1366,y:729,t:1527794368304};\\\", \\\"{x:1366,y:735,t:1527794368320};\\\", \\\"{x:1369,y:741,t:1527794368337};\\\", \\\"{x:1370,y:745,t:1527794368353};\\\", \\\"{x:1371,y:751,t:1527794368371};\\\", \\\"{x:1373,y:759,t:1527794368387};\\\", \\\"{x:1374,y:767,t:1527794368403};\\\", \\\"{x:1376,y:781,t:1527794368421};\\\", \\\"{x:1379,y:789,t:1527794368436};\\\", \\\"{x:1385,y:815,t:1527794368453};\\\", \\\"{x:1387,y:830,t:1527794368471};\\\", \\\"{x:1390,y:842,t:1527794368487};\\\", \\\"{x:1395,y:858,t:1527794368503};\\\", \\\"{x:1396,y:875,t:1527794368520};\\\", \\\"{x:1398,y:881,t:1527794368537};\\\", \\\"{x:1403,y:875,t:1527794368718};\\\", \\\"{x:1408,y:857,t:1527794368726};\\\", \\\"{x:1416,y:839,t:1527794368737};\\\", \\\"{x:1431,y:807,t:1527794368753};\\\", \\\"{x:1443,y:792,t:1527794368771};\\\", \\\"{x:1451,y:780,t:1527794368787};\\\", \\\"{x:1453,y:775,t:1527794368803};\\\", \\\"{x:1454,y:767,t:1527794368821};\\\", \\\"{x:1457,y:754,t:1527794368837};\\\", \\\"{x:1459,y:750,t:1527794368854};\\\", \\\"{x:1462,y:747,t:1527794368871};\\\", \\\"{x:1462,y:746,t:1527794368888};\\\", \\\"{x:1462,y:745,t:1527794368903};\\\", \\\"{x:1465,y:742,t:1527794368921};\\\", \\\"{x:1468,y:741,t:1527794368938};\\\", \\\"{x:1472,y:738,t:1527794368954};\\\", \\\"{x:1482,y:732,t:1527794368970};\\\", \\\"{x:1487,y:728,t:1527794368988};\\\", \\\"{x:1500,y:723,t:1527794369004};\\\", \\\"{x:1507,y:719,t:1527794369021};\\\", \\\"{x:1517,y:714,t:1527794369037};\\\", \\\"{x:1520,y:711,t:1527794369053};\\\", \\\"{x:1523,y:709,t:1527794369070};\\\", \\\"{x:1527,y:705,t:1527794369087};\\\", \\\"{x:1533,y:693,t:1527794369103};\\\", \\\"{x:1544,y:677,t:1527794369120};\\\", \\\"{x:1551,y:666,t:1527794369137};\\\", \\\"{x:1556,y:657,t:1527794369153};\\\", \\\"{x:1557,y:654,t:1527794369170};\\\", \\\"{x:1558,y:653,t:1527794369188};\\\", \\\"{x:1561,y:647,t:1527794369203};\\\", \\\"{x:1562,y:643,t:1527794369220};\\\", \\\"{x:1564,y:635,t:1527794369237};\\\", \\\"{x:1566,y:627,t:1527794369254};\\\", \\\"{x:1568,y:621,t:1527794369270};\\\", \\\"{x:1570,y:615,t:1527794369288};\\\", \\\"{x:1572,y:606,t:1527794369305};\\\", \\\"{x:1573,y:601,t:1527794369320};\\\", \\\"{x:1575,y:599,t:1527794369338};\\\", \\\"{x:1577,y:594,t:1527794369355};\\\", \\\"{x:1581,y:595,t:1527794369422};\\\", \\\"{x:1593,y:612,t:1527794369437};\\\", \\\"{x:1600,y:630,t:1527794369455};\\\", \\\"{x:1606,y:647,t:1527794369471};\\\", \\\"{x:1609,y:660,t:1527794369488};\\\", \\\"{x:1616,y:672,t:1527794369505};\\\", \\\"{x:1617,y:675,t:1527794369522};\\\", \\\"{x:1618,y:681,t:1527794369538};\\\", \\\"{x:1619,y:686,t:1527794369555};\\\", \\\"{x:1620,y:688,t:1527794369570};\\\", \\\"{x:1620,y:689,t:1527794369629};\\\", \\\"{x:1620,y:690,t:1527794369637};\\\", \\\"{x:1620,y:691,t:1527794369774};\\\", \\\"{x:1619,y:692,t:1527794369822};\\\", \\\"{x:1618,y:692,t:1527794369870};\\\", \\\"{x:1617,y:692,t:1527794371422};\\\", \\\"{x:1616,y:692,t:1527794371445};\\\", \\\"{x:1615,y:692,t:1527794371461};\\\", \\\"{x:1613,y:692,t:1527794371486};\\\", \\\"{x:1612,y:692,t:1527794371526};\\\", \\\"{x:1611,y:692,t:1527794377269};\\\", \\\"{x:1606,y:692,t:1527794377279};\\\", \\\"{x:1545,y:694,t:1527794377294};\\\", \\\"{x:1453,y:693,t:1527794377310};\\\", \\\"{x:1383,y:689,t:1527794377327};\\\", \\\"{x:1356,y:689,t:1527794377344};\\\", \\\"{x:1259,y:676,t:1527794377360};\\\", \\\"{x:1161,y:670,t:1527794377377};\\\", \\\"{x:1112,y:665,t:1527794377394};\\\", \\\"{x:1076,y:665,t:1527794377410};\\\", \\\"{x:1045,y:668,t:1527794377427};\\\", \\\"{x:1007,y:659,t:1527794377444};\\\", \\\"{x:991,y:650,t:1527794377461};\\\", \\\"{x:976,y:649,t:1527794377478};\\\", \\\"{x:969,y:645,t:1527794377493};\\\", \\\"{x:951,y:643,t:1527794377509};\\\", \\\"{x:937,y:643,t:1527794377526};\\\", \\\"{x:927,y:643,t:1527794377543};\\\", \\\"{x:901,y:641,t:1527794377559};\\\", \\\"{x:892,y:639,t:1527794377576};\\\", \\\"{x:883,y:639,t:1527794377594};\\\", \\\"{x:849,y:635,t:1527794377609};\\\", \\\"{x:824,y:635,t:1527794377626};\\\", \\\"{x:813,y:634,t:1527794377643};\\\", \\\"{x:791,y:632,t:1527794377659};\\\", \\\"{x:769,y:630,t:1527794377678};\\\", \\\"{x:750,y:626,t:1527794377694};\\\", \\\"{x:736,y:623,t:1527794377709};\\\", \\\"{x:727,y:618,t:1527794377727};\\\", \\\"{x:715,y:618,t:1527794377745};\\\", \\\"{x:700,y:612,t:1527794377760};\\\", \\\"{x:677,y:607,t:1527794377778};\\\", \\\"{x:658,y:602,t:1527794377794};\\\", \\\"{x:647,y:598,t:1527794377811};\\\", \\\"{x:644,y:595,t:1527794377828};\\\", \\\"{x:643,y:594,t:1527794377861};\\\", \\\"{x:641,y:590,t:1527794377878};\\\", \\\"{x:636,y:583,t:1527794377895};\\\", \\\"{x:631,y:579,t:1527794377910};\\\", \\\"{x:627,y:575,t:1527794377928};\\\", \\\"{x:619,y:572,t:1527794377944};\\\", \\\"{x:616,y:570,t:1527794377961};\\\", \\\"{x:614,y:570,t:1527794377978};\\\", \\\"{x:612,y:568,t:1527794377995};\\\", \\\"{x:606,y:564,t:1527794378011};\\\", \\\"{x:605,y:562,t:1527794378029};\\\", \\\"{x:598,y:558,t:1527794378044};\\\", \\\"{x:596,y:556,t:1527794378061};\\\", \\\"{x:595,y:556,t:1527794378101};\\\", \\\"{x:592,y:556,t:1527794378112};\\\", \\\"{x:589,y:556,t:1527794378128};\\\", \\\"{x:584,y:558,t:1527794378145};\\\", \\\"{x:583,y:561,t:1527794378161};\\\", \\\"{x:583,y:564,t:1527794378179};\\\", \\\"{x:583,y:565,t:1527794378260};\\\", \\\"{x:583,y:567,t:1527794378277};\\\", \\\"{x:584,y:568,t:1527794378295};\\\", \\\"{x:588,y:571,t:1527794378311};\\\", \\\"{x:595,y:571,t:1527794378327};\\\", \\\"{x:611,y:573,t:1527794378345};\\\", \\\"{x:622,y:576,t:1527794378362};\\\", \\\"{x:627,y:577,t:1527794378377};\\\", \\\"{x:628,y:577,t:1527794378395};\\\", \\\"{x:628,y:578,t:1527794378949};\\\", \\\"{x:627,y:578,t:1527794378982};\\\", \\\"{x:625,y:578,t:1527794379277};\\\", \\\"{x:622,y:578,t:1527794379285};\\\", \\\"{x:618,y:578,t:1527794379295};\\\", \\\"{x:615,y:578,t:1527794379312};\\\", \\\"{x:614,y:579,t:1527794380046};\\\", \\\"{x:614,y:580,t:1527794380063};\\\", \\\"{x:695,y:588,t:1527794380080};\\\", \\\"{x:841,y:603,t:1527794380098};\\\", \\\"{x:1051,y:612,t:1527794380113};\\\", \\\"{x:1230,y:628,t:1527794380130};\\\", \\\"{x:1381,y:641,t:1527794380146};\\\", \\\"{x:1532,y:654,t:1527794380163};\\\", \\\"{x:1692,y:662,t:1527794380179};\\\", \\\"{x:1816,y:655,t:1527794380195};\\\", \\\"{x:1876,y:660,t:1527794380213};\\\", \\\"{x:1890,y:663,t:1527794380229};\\\", \\\"{x:1894,y:664,t:1527794380245};\\\", \\\"{x:1891,y:665,t:1527794380358};\\\", \\\"{x:1883,y:670,t:1527794380365};\\\", \\\"{x:1875,y:671,t:1527794380379};\\\", \\\"{x:1852,y:681,t:1527794380396};\\\", \\\"{x:1834,y:692,t:1527794380412};\\\", \\\"{x:1808,y:700,t:1527794380429};\\\", \\\"{x:1780,y:704,t:1527794380447};\\\", \\\"{x:1744,y:708,t:1527794380462};\\\", \\\"{x:1737,y:712,t:1527794380480};\\\", \\\"{x:1732,y:713,t:1527794380496};\\\", \\\"{x:1730,y:713,t:1527794380513};\\\", \\\"{x:1718,y:713,t:1527794380530};\\\", \\\"{x:1703,y:714,t:1527794380546};\\\", \\\"{x:1681,y:715,t:1527794380563};\\\", \\\"{x:1680,y:715,t:1527794380645};\\\", \\\"{x:1677,y:715,t:1527794380664};\\\", \\\"{x:1667,y:708,t:1527794380681};\\\", \\\"{x:1657,y:702,t:1527794380698};\\\", \\\"{x:1641,y:697,t:1527794380713};\\\", \\\"{x:1633,y:696,t:1527794380730};\\\", \\\"{x:1630,y:696,t:1527794380748};\\\", \\\"{x:1628,y:696,t:1527794380764};\\\", \\\"{x:1624,y:696,t:1527794380780};\\\", \\\"{x:1606,y:696,t:1527794380797};\\\", \\\"{x:1602,y:698,t:1527794380814};\\\", \\\"{x:1601,y:699,t:1527794380830};\\\", \\\"{x:1603,y:699,t:1527794381021};\\\", \\\"{x:1604,y:699,t:1527794381030};\\\", \\\"{x:1608,y:698,t:1527794381046};\\\", \\\"{x:1611,y:697,t:1527794381063};\\\", \\\"{x:1613,y:696,t:1527794381205};\\\", \\\"{x:1615,y:695,t:1527794381213};\\\", \\\"{x:1616,y:694,t:1527794381230};\\\", \\\"{x:1601,y:693,t:1527794397269};\\\", \\\"{x:1529,y:693,t:1527794397276};\\\", \\\"{x:1369,y:694,t:1527794397292};\\\", \\\"{x:1252,y:691,t:1527794397309};\\\", \\\"{x:1180,y:682,t:1527794397325};\\\", \\\"{x:1160,y:672,t:1527794397342};\\\", \\\"{x:1131,y:665,t:1527794397358};\\\", \\\"{x:1108,y:656,t:1527794397375};\\\", \\\"{x:1099,y:652,t:1527794397392};\\\", \\\"{x:1098,y:652,t:1527794397409};\\\", \\\"{x:1089,y:651,t:1527794397425};\\\", \\\"{x:1082,y:647,t:1527794397442};\\\", \\\"{x:1071,y:645,t:1527794397459};\\\", \\\"{x:1069,y:645,t:1527794397475};\\\", \\\"{x:1064,y:642,t:1527794397492};\\\", \\\"{x:1059,y:635,t:1527794397508};\\\", \\\"{x:1051,y:621,t:1527794397525};\\\", \\\"{x:1040,y:606,t:1527794397543};\\\", \\\"{x:1033,y:597,t:1527794397559};\\\", \\\"{x:1024,y:581,t:1527794397576};\\\", \\\"{x:1015,y:571,t:1527794397593};\\\", \\\"{x:1007,y:563,t:1527794397609};\\\", \\\"{x:989,y:544,t:1527794397625};\\\", \\\"{x:969,y:518,t:1527794397643};\\\", \\\"{x:940,y:478,t:1527794397659};\\\", \\\"{x:916,y:463,t:1527794397676};\\\", \\\"{x:902,y:455,t:1527794397692};\\\", \\\"{x:879,y:443,t:1527794397709};\\\", \\\"{x:872,y:437,t:1527794397726};\\\", \\\"{x:863,y:435,t:1527794397743};\\\", \\\"{x:857,y:435,t:1527794397760};\\\", \\\"{x:855,y:436,t:1527794397775};\\\", \\\"{x:850,y:438,t:1527794397793};\\\", \\\"{x:847,y:443,t:1527794397810};\\\", \\\"{x:845,y:462,t:1527794397827};\\\", \\\"{x:844,y:481,t:1527794397843};\\\", \\\"{x:844,y:489,t:1527794397861};\\\", \\\"{x:841,y:496,t:1527794397877};\\\", \\\"{x:840,y:508,t:1527794397892};\\\", \\\"{x:841,y:514,t:1527794397911};\\\", \\\"{x:842,y:514,t:1527794398997};\\\", \\\"{x:842,y:513,t:1527794399078};\\\", \\\"{x:842,y:504,t:1527794399095};\\\", \\\"{x:842,y:503,t:1527794399112};\\\", \\\"{x:843,y:501,t:1527794399149};\\\", \\\"{x:844,y:500,t:1527794399162};\\\", \\\"{x:848,y:497,t:1527794399179};\\\", \\\"{x:848,y:495,t:1527794399196};\\\", \\\"{x:848,y:494,t:1527794399211};\\\", \\\"{x:848,y:492,t:1527794399228};\\\", \\\"{x:848,y:491,t:1527794399245};\\\", \\\"{x:848,y:492,t:1527794399652};\\\", \\\"{x:848,y:494,t:1527794399668};\\\", \\\"{x:848,y:495,t:1527794399678};\\\", \\\"{x:846,y:501,t:1527794399695};\\\", \\\"{x:845,y:502,t:1527794399711};\\\", \\\"{x:845,y:503,t:1527794399728};\\\", \\\"{x:845,y:504,t:1527794399813};\\\", \\\"{x:847,y:507,t:1527794399829};\\\", \\\"{x:862,y:516,t:1527794399846};\\\", \\\"{x:914,y:533,t:1527794399864};\\\", \\\"{x:979,y:554,t:1527794399879};\\\", \\\"{x:1053,y:565,t:1527794399895};\\\", \\\"{x:1116,y:575,t:1527794399911};\\\", \\\"{x:1185,y:575,t:1527794399929};\\\", \\\"{x:1203,y:576,t:1527794399945};\\\", \\\"{x:1220,y:578,t:1527794399962};\\\", \\\"{x:1225,y:579,t:1527794399978};\\\", \\\"{x:1224,y:580,t:1527794403805};\\\", \\\"{x:1222,y:583,t:1527794403815};\\\", \\\"{x:1220,y:584,t:1527794403832};\\\", \\\"{x:1215,y:586,t:1527794403849};\\\", \\\"{x:1211,y:588,t:1527794403865};\\\", \\\"{x:1207,y:590,t:1527794403882};\\\", \\\"{x:1198,y:595,t:1527794403899};\\\", \\\"{x:1184,y:597,t:1527794403915};\\\", \\\"{x:1163,y:601,t:1527794403932};\\\", \\\"{x:1141,y:602,t:1527794403949};\\\", \\\"{x:1136,y:602,t:1527794403964};\\\", \\\"{x:1135,y:602,t:1527794404094};\\\", \\\"{x:1134,y:602,t:1527794404660};\\\", \\\"{x:1131,y:602,t:1527794404685};\\\", \\\"{x:1129,y:602,t:1527794404699};\\\", \\\"{x:1116,y:599,t:1527794404716};\\\", \\\"{x:1091,y:594,t:1527794404732};\\\", \\\"{x:1073,y:592,t:1527794404748};\\\", \\\"{x:1069,y:590,t:1527794404765};\\\", \\\"{x:1049,y:590,t:1527794404782};\\\", \\\"{x:1030,y:591,t:1527794404798};\\\", \\\"{x:1010,y:601,t:1527794404815};\\\", \\\"{x:989,y:617,t:1527794404833};\\\", \\\"{x:949,y:634,t:1527794404849};\\\", \\\"{x:922,y:654,t:1527794404866};\\\", \\\"{x:837,y:687,t:1527794404882};\\\", \\\"{x:752,y:720,t:1527794404899};\\\", \\\"{x:717,y:741,t:1527794404916};\\\", \\\"{x:657,y:767,t:1527794404932};\\\", \\\"{x:639,y:780,t:1527794404949};\\\", \\\"{x:620,y:790,t:1527794404965};\\\", \\\"{x:603,y:794,t:1527794404982};\\\", \\\"{x:600,y:795,t:1527794404999};\\\", \\\"{x:597,y:794,t:1527794405117};\\\", \\\"{x:584,y:783,t:1527794405133};\\\", \\\"{x:570,y:778,t:1527794405149};\\\", \\\"{x:555,y:772,t:1527794405166};\\\", \\\"{x:550,y:769,t:1527794405183};\\\", \\\"{x:540,y:764,t:1527794405200};\\\", \\\"{x:528,y:758,t:1527794405216};\\\", \\\"{x:514,y:750,t:1527794405233};\\\", \\\"{x:500,y:744,t:1527794405249};\\\", \\\"{x:486,y:732,t:1527794405266};\\\", \\\"{x:478,y:727,t:1527794405283};\\\", \\\"{x:478,y:726,t:1527794405300};\\\" ] }, { \\\"rt\\\": 58087, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 990871, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:726,t:1527794419525};\\\", \\\"{x:471,y:728,t:1527794419531};\\\", \\\"{x:463,y:731,t:1527794419545};\\\", \\\"{x:447,y:738,t:1527794419562};\\\", \\\"{x:441,y:738,t:1527794419578};\\\", \\\"{x:432,y:733,t:1527794419595};\\\", \\\"{x:426,y:731,t:1527794419611};\\\", \\\"{x:413,y:727,t:1527794419627};\\\", \\\"{x:391,y:725,t:1527794419643};\\\", \\\"{x:381,y:724,t:1527794419661};\\\", \\\"{x:372,y:722,t:1527794419677};\\\", \\\"{x:368,y:722,t:1527794419694};\\\", \\\"{x:363,y:722,t:1527794419711};\\\", \\\"{x:356,y:722,t:1527794419727};\\\", \\\"{x:347,y:722,t:1527794419743};\\\", \\\"{x:342,y:722,t:1527794419761};\\\", \\\"{x:338,y:722,t:1527794419777};\\\", \\\"{x:336,y:722,t:1527794419794};\\\", \\\"{x:335,y:721,t:1527794419811};\\\", \\\"{x:333,y:721,t:1527794419827};\\\", \\\"{x:335,y:715,t:1527794419844};\\\", \\\"{x:347,y:703,t:1527794419861};\\\", \\\"{x:354,y:685,t:1527794419877};\\\", \\\"{x:371,y:670,t:1527794419894};\\\", \\\"{x:390,y:654,t:1527794419912};\\\", \\\"{x:403,y:635,t:1527794419928};\\\", \\\"{x:416,y:617,t:1527794419944};\\\", \\\"{x:427,y:608,t:1527794419961};\\\", \\\"{x:435,y:603,t:1527794419977};\\\", \\\"{x:445,y:596,t:1527794419995};\\\", \\\"{x:457,y:591,t:1527794420012};\\\", \\\"{x:469,y:584,t:1527794420027};\\\", \\\"{x:472,y:581,t:1527794420045};\\\", \\\"{x:479,y:579,t:1527794420061};\\\", \\\"{x:495,y:572,t:1527794420078};\\\", \\\"{x:515,y:566,t:1527794420096};\\\", \\\"{x:525,y:562,t:1527794420112};\\\", \\\"{x:534,y:559,t:1527794420128};\\\", \\\"{x:542,y:557,t:1527794420144};\\\", \\\"{x:547,y:554,t:1527794420161};\\\", \\\"{x:553,y:553,t:1527794420178};\\\", \\\"{x:559,y:551,t:1527794420194};\\\", \\\"{x:563,y:551,t:1527794420211};\\\", \\\"{x:573,y:550,t:1527794420228};\\\", \\\"{x:577,y:550,t:1527794420244};\\\", \\\"{x:581,y:550,t:1527794420261};\\\", \\\"{x:582,y:550,t:1527794420278};\\\", \\\"{x:584,y:550,t:1527794420333};\\\", \\\"{x:586,y:549,t:1527794420345};\\\", \\\"{x:590,y:547,t:1527794420361};\\\", \\\"{x:592,y:547,t:1527794420378};\\\", \\\"{x:592,y:546,t:1527794420395};\\\", \\\"{x:593,y:545,t:1527794420411};\\\", \\\"{x:594,y:544,t:1527794420429};\\\", \\\"{x:597,y:543,t:1527794420445};\\\", \\\"{x:600,y:539,t:1527794420463};\\\", \\\"{x:606,y:536,t:1527794420477};\\\", \\\"{x:611,y:533,t:1527794420495};\\\", \\\"{x:612,y:532,t:1527794420523};\\\", \\\"{x:612,y:533,t:1527794420644};\\\", \\\"{x:605,y:535,t:1527794420662};\\\", \\\"{x:598,y:539,t:1527794420679};\\\", \\\"{x:592,y:540,t:1527794420695};\\\", \\\"{x:584,y:542,t:1527794420715};\\\", \\\"{x:577,y:543,t:1527794420727};\\\", \\\"{x:567,y:545,t:1527794420744};\\\", \\\"{x:549,y:545,t:1527794420761};\\\", \\\"{x:524,y:548,t:1527794420778};\\\", \\\"{x:503,y:552,t:1527794420794};\\\", \\\"{x:477,y:552,t:1527794420812};\\\", \\\"{x:455,y:553,t:1527794420827};\\\", \\\"{x:453,y:553,t:1527794420845};\\\", \\\"{x:441,y:552,t:1527794420861};\\\", \\\"{x:427,y:553,t:1527794420878};\\\", \\\"{x:415,y:553,t:1527794420895};\\\", \\\"{x:393,y:554,t:1527794420911};\\\", \\\"{x:378,y:552,t:1527794420928};\\\", \\\"{x:364,y:551,t:1527794420945};\\\", \\\"{x:358,y:551,t:1527794420962};\\\", \\\"{x:355,y:551,t:1527794420978};\\\", \\\"{x:352,y:551,t:1527794420995};\\\", \\\"{x:346,y:551,t:1527794421011};\\\", \\\"{x:334,y:552,t:1527794421028};\\\", \\\"{x:319,y:555,t:1527794421045};\\\", \\\"{x:306,y:556,t:1527794421062};\\\", \\\"{x:299,y:557,t:1527794421078};\\\", \\\"{x:286,y:557,t:1527794421095};\\\", \\\"{x:271,y:557,t:1527794421112};\\\", \\\"{x:261,y:557,t:1527794421129};\\\", \\\"{x:243,y:557,t:1527794421145};\\\", \\\"{x:231,y:557,t:1527794421162};\\\", \\\"{x:217,y:557,t:1527794421180};\\\", \\\"{x:214,y:557,t:1527794421195};\\\", \\\"{x:210,y:557,t:1527794421212};\\\", \\\"{x:210,y:556,t:1527794421316};\\\", \\\"{x:209,y:555,t:1527794421330};\\\", \\\"{x:196,y:552,t:1527794421346};\\\", \\\"{x:187,y:550,t:1527794421363};\\\", \\\"{x:183,y:546,t:1527794421379};\\\", \\\"{x:177,y:543,t:1527794421396};\\\", \\\"{x:170,y:540,t:1527794421412};\\\", \\\"{x:169,y:539,t:1527794421430};\\\", \\\"{x:166,y:536,t:1527794421445};\\\", \\\"{x:161,y:535,t:1527794421463};\\\", \\\"{x:157,y:533,t:1527794421479};\\\", \\\"{x:157,y:532,t:1527794421900};\\\", \\\"{x:162,y:528,t:1527794421913};\\\", \\\"{x:198,y:528,t:1527794421929};\\\", \\\"{x:209,y:528,t:1527794421946};\\\", \\\"{x:215,y:529,t:1527794421963};\\\", \\\"{x:224,y:527,t:1527794421979};\\\", \\\"{x:255,y:523,t:1527794421997};\\\", \\\"{x:280,y:518,t:1527794422013};\\\", \\\"{x:342,y:510,t:1527794422031};\\\", \\\"{x:409,y:508,t:1527794422046};\\\", \\\"{x:500,y:513,t:1527794422063};\\\", \\\"{x:625,y:529,t:1527794422079};\\\", \\\"{x:738,y:541,t:1527794422096};\\\", \\\"{x:834,y:563,t:1527794422114};\\\", \\\"{x:901,y:571,t:1527794422130};\\\", \\\"{x:970,y:578,t:1527794422147};\\\", \\\"{x:994,y:582,t:1527794422163};\\\", \\\"{x:1030,y:584,t:1527794422179};\\\", \\\"{x:1047,y:587,t:1527794422195};\\\", \\\"{x:1048,y:587,t:1527794422212};\\\", \\\"{x:1048,y:588,t:1527794459569};\\\", \\\"{x:1046,y:593,t:1527794459585};\\\", \\\"{x:1041,y:599,t:1527794459602};\\\", \\\"{x:1038,y:601,t:1527794459618};\\\", \\\"{x:1038,y:602,t:1527794459635};\\\", \\\"{x:1038,y:636,t:1527794459817};\\\", \\\"{x:1034,y:684,t:1527794459824};\\\", \\\"{x:1026,y:728,t:1527794459835};\\\", \\\"{x:1016,y:762,t:1527794459851};\\\", \\\"{x:1004,y:778,t:1527794459868};\\\", \\\"{x:990,y:791,t:1527794459884};\\\", \\\"{x:975,y:803,t:1527794459902};\\\", \\\"{x:955,y:811,t:1527794459918};\\\", \\\"{x:913,y:814,t:1527794459934};\\\", \\\"{x:859,y:819,t:1527794459952};\\\", \\\"{x:832,y:820,t:1527794459968};\\\", \\\"{x:781,y:832,t:1527794459984};\\\", \\\"{x:724,y:841,t:1527794460001};\\\", \\\"{x:702,y:844,t:1527794460018};\\\", \\\"{x:701,y:845,t:1527794460035};\\\", \\\"{x:700,y:845,t:1527794460055};\\\", \\\"{x:699,y:845,t:1527794460072};\\\", \\\"{x:698,y:844,t:1527794460085};\\\", \\\"{x:691,y:839,t:1527794460101};\\\", \\\"{x:680,y:827,t:1527794460118};\\\", \\\"{x:665,y:820,t:1527794460134};\\\", \\\"{x:659,y:814,t:1527794460151};\\\", \\\"{x:651,y:811,t:1527794460168};\\\", \\\"{x:636,y:805,t:1527794460185};\\\", \\\"{x:620,y:796,t:1527794460202};\\\", \\\"{x:587,y:776,t:1527794460218};\\\", \\\"{x:563,y:768,t:1527794460235};\\\", \\\"{x:554,y:762,t:1527794460252};\\\", \\\"{x:550,y:762,t:1527794460268};\\\", \\\"{x:549,y:762,t:1527794460296};\\\", \\\"{x:547,y:762,t:1527794460303};\\\", \\\"{x:544,y:761,t:1527794460318};\\\", \\\"{x:539,y:760,t:1527794460334};\\\", \\\"{x:534,y:756,t:1527794460351};\\\", \\\"{x:534,y:755,t:1527794460368};\\\", \\\"{x:532,y:753,t:1527794460393};\\\", \\\"{x:532,y:752,t:1527794460408};\\\", \\\"{x:532,y:749,t:1527794460417};\\\", \\\"{x:533,y:748,t:1527794460435};\\\", \\\"{x:534,y:746,t:1527794460447};\\\", \\\"{x:536,y:745,t:1527794460465};\\\", \\\"{x:537,y:743,t:1527794460487};\\\", \\\"{x:539,y:742,t:1527794460497};\\\", \\\"{x:543,y:740,t:1527794460514};\\\", \\\"{x:544,y:740,t:1527794460531};\\\", \\\"{x:544,y:739,t:1527794464392};\\\", \\\"{x:543,y:739,t:1527794464401};\\\", \\\"{x:540,y:739,t:1527794464417};\\\", \\\"{x:537,y:741,t:1527794464435};\\\", \\\"{x:527,y:746,t:1527794464451};\\\", \\\"{x:523,y:747,t:1527794464468};\\\", \\\"{x:523,y:748,t:1527794464485};\\\", \\\"{x:522,y:748,t:1527794464502};\\\", \\\"{x:521,y:748,t:1527794464518};\\\", \\\"{x:520,y:749,t:1527794464535};\\\", \\\"{x:517,y:750,t:1527794464552};\\\", \\\"{x:516,y:750,t:1527794464848};\\\", \\\"{x:516,y:748,t:1527794464880};\\\", \\\"{x:517,y:745,t:1527794464887};\\\", \\\"{x:517,y:744,t:1527794464901};\\\", \\\"{x:518,y:741,t:1527794464918};\\\", \\\"{x:519,y:739,t:1527794464934};\\\", \\\"{x:519,y:738,t:1527794464952};\\\", \\\"{x:519,y:737,t:1527794465568};\\\", \\\"{x:520,y:737,t:1527794465585};\\\" ] }, { \\\"rt\\\": 87146, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1079276, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -02 PM-C -E -I -10 AM-J -10 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:737,t:1527794478592};\\\", \\\"{x:521,y:735,t:1527794479247};\\\", \\\"{x:522,y:731,t:1527794479263};\\\", \\\"{x:545,y:725,t:1527794479278};\\\", \\\"{x:565,y:716,t:1527794479294};\\\", \\\"{x:579,y:706,t:1527794479312};\\\", \\\"{x:586,y:699,t:1527794479328};\\\", \\\"{x:607,y:692,t:1527794479344};\\\", \\\"{x:616,y:688,t:1527794479361};\\\", \\\"{x:640,y:684,t:1527794479379};\\\", \\\"{x:659,y:676,t:1527794479395};\\\", \\\"{x:663,y:670,t:1527794479412};\\\", \\\"{x:687,y:660,t:1527794479429};\\\", \\\"{x:691,y:650,t:1527794479446};\\\", \\\"{x:758,y:641,t:1527794479463};\\\", \\\"{x:879,y:627,t:1527794479478};\\\", \\\"{x:926,y:620,t:1527794479496};\\\", \\\"{x:1025,y:611,t:1527794479512};\\\", \\\"{x:1133,y:611,t:1527794479529};\\\", \\\"{x:1211,y:611,t:1527794479546};\\\", \\\"{x:1267,y:611,t:1527794479563};\\\", \\\"{x:1307,y:617,t:1527794479579};\\\", \\\"{x:1390,y:616,t:1527794479597};\\\", \\\"{x:1477,y:628,t:1527794479613};\\\", \\\"{x:1588,y:642,t:1527794479630};\\\", \\\"{x:1668,y:651,t:1527794479646};\\\", \\\"{x:1709,y:658,t:1527794479663};\\\", \\\"{x:1718,y:658,t:1527794479679};\\\", \\\"{x:1719,y:658,t:1527794479696};\\\", \\\"{x:1718,y:658,t:1527794479831};\\\", \\\"{x:1716,y:658,t:1527794479847};\\\", \\\"{x:1706,y:658,t:1527794479863};\\\", \\\"{x:1679,y:659,t:1527794479879};\\\", \\\"{x:1647,y:671,t:1527794479897};\\\", \\\"{x:1621,y:688,t:1527794479914};\\\", \\\"{x:1614,y:693,t:1527794479932};\\\", \\\"{x:1600,y:705,t:1527794479946};\\\", \\\"{x:1600,y:711,t:1527794479963};\\\", \\\"{x:1593,y:725,t:1527794479980};\\\", \\\"{x:1580,y:737,t:1527794479996};\\\", \\\"{x:1564,y:750,t:1527794480013};\\\", \\\"{x:1510,y:777,t:1527794480030};\\\", \\\"{x:1492,y:787,t:1527794480046};\\\", \\\"{x:1475,y:793,t:1527794480063};\\\", \\\"{x:1470,y:796,t:1527794480080};\\\", \\\"{x:1467,y:797,t:1527794480096};\\\", \\\"{x:1466,y:798,t:1527794480112};\\\", \\\"{x:1465,y:798,t:1527794480206};\\\", \\\"{x:1463,y:798,t:1527794480215};\\\", \\\"{x:1462,y:798,t:1527794480295};\\\", \\\"{x:1462,y:797,t:1527794480303};\\\", \\\"{x:1460,y:797,t:1527794480313};\\\", \\\"{x:1458,y:796,t:1527794480330};\\\", \\\"{x:1455,y:794,t:1527794480347};\\\", \\\"{x:1453,y:793,t:1527794480363};\\\", \\\"{x:1452,y:792,t:1527794480380};\\\", \\\"{x:1452,y:793,t:1527794480423};\\\", \\\"{x:1452,y:801,t:1527794480431};\\\", \\\"{x:1448,y:810,t:1527794480446};\\\", \\\"{x:1447,y:817,t:1527794480463};\\\", \\\"{x:1444,y:820,t:1527794480480};\\\", \\\"{x:1444,y:826,t:1527794480497};\\\", \\\"{x:1446,y:832,t:1527794480513};\\\", \\\"{x:1446,y:836,t:1527794480530};\\\", \\\"{x:1450,y:841,t:1527794480547};\\\", \\\"{x:1457,y:845,t:1527794480563};\\\", \\\"{x:1462,y:848,t:1527794480580};\\\", \\\"{x:1464,y:849,t:1527794480597};\\\", \\\"{x:1467,y:852,t:1527794480613};\\\", \\\"{x:1474,y:859,t:1527794480630};\\\", \\\"{x:1484,y:871,t:1527794480646};\\\", \\\"{x:1490,y:879,t:1527794480664};\\\", \\\"{x:1494,y:881,t:1527794480680};\\\", \\\"{x:1496,y:883,t:1527794480697};\\\", \\\"{x:1502,y:890,t:1527794480714};\\\", \\\"{x:1513,y:907,t:1527794480730};\\\", \\\"{x:1514,y:917,t:1527794480748};\\\", \\\"{x:1517,y:933,t:1527794480764};\\\", \\\"{x:1515,y:942,t:1527794480781};\\\", \\\"{x:1511,y:947,t:1527794480798};\\\", \\\"{x:1511,y:949,t:1527794480815};\\\", \\\"{x:1509,y:951,t:1527794480831};\\\", \\\"{x:1508,y:952,t:1527794480847};\\\", \\\"{x:1505,y:955,t:1527794480864};\\\", \\\"{x:1500,y:959,t:1527794480881};\\\", \\\"{x:1497,y:962,t:1527794480898};\\\", \\\"{x:1493,y:965,t:1527794480915};\\\", \\\"{x:1492,y:965,t:1527794480931};\\\", \\\"{x:1491,y:965,t:1527794480948};\\\", \\\"{x:1490,y:966,t:1527794480964};\\\", \\\"{x:1488,y:966,t:1527794480983};\\\", \\\"{x:1487,y:967,t:1527794480997};\\\", \\\"{x:1486,y:967,t:1527794481015};\\\", \\\"{x:1482,y:969,t:1527794481031};\\\", \\\"{x:1479,y:968,t:1527794481281};\\\", \\\"{x:1477,y:965,t:1527794481304};\\\", \\\"{x:1477,y:963,t:1527794481315};\\\", \\\"{x:1476,y:960,t:1527794481332};\\\", \\\"{x:1475,y:960,t:1527794481348};\\\", \\\"{x:1475,y:958,t:1527794486203};\\\", \\\"{x:1475,y:957,t:1527794486211};\\\", \\\"{x:1458,y:956,t:1527794521035};\\\", \\\"{x:1448,y:955,t:1527794521053};\\\", \\\"{x:1367,y:931,t:1527794521069};\\\", \\\"{x:1258,y:911,t:1527794521086};\\\", \\\"{x:1168,y:890,t:1527794521103};\\\", \\\"{x:1121,y:876,t:1527794521119};\\\", \\\"{x:1100,y:866,t:1527794521136};\\\", \\\"{x:1093,y:859,t:1527794521153};\\\", \\\"{x:1073,y:833,t:1527794521170};\\\", \\\"{x:1062,y:814,t:1527794521186};\\\", \\\"{x:1057,y:807,t:1527794521202};\\\", \\\"{x:1057,y:801,t:1527794521220};\\\", \\\"{x:1054,y:784,t:1527794521236};\\\", \\\"{x:1047,y:769,t:1527794521253};\\\", \\\"{x:1027,y:751,t:1527794521270};\\\", \\\"{x:1002,y:733,t:1527794521286};\\\", \\\"{x:985,y:728,t:1527794521303};\\\", \\\"{x:980,y:720,t:1527794521320};\\\", \\\"{x:964,y:712,t:1527794521335};\\\", \\\"{x:938,y:698,t:1527794521353};\\\", \\\"{x:915,y:684,t:1527794521370};\\\", \\\"{x:877,y:672,t:1527794521386};\\\", \\\"{x:833,y:664,t:1527794521402};\\\", \\\"{x:805,y:659,t:1527794521420};\\\", \\\"{x:786,y:659,t:1527794521435};\\\", \\\"{x:778,y:658,t:1527794521452};\\\", \\\"{x:770,y:653,t:1527794521470};\\\", \\\"{x:759,y:645,t:1527794521487};\\\", \\\"{x:744,y:638,t:1527794521502};\\\", \\\"{x:733,y:628,t:1527794521519};\\\", \\\"{x:720,y:618,t:1527794521533};\\\", \\\"{x:708,y:611,t:1527794521550};\\\", \\\"{x:697,y:601,t:1527794521566};\\\", \\\"{x:691,y:589,t:1527794521583};\\\", \\\"{x:682,y:571,t:1527794521601};\\\", \\\"{x:675,y:550,t:1527794521617};\\\", \\\"{x:667,y:516,t:1527794521633};\\\", \\\"{x:658,y:494,t:1527794521651};\\\", \\\"{x:649,y:485,t:1527794521666};\\\", \\\"{x:643,y:475,t:1527794521684};\\\", \\\"{x:636,y:467,t:1527794521701};\\\", \\\"{x:633,y:467,t:1527794521770};\\\", \\\"{x:627,y:471,t:1527794521783};\\\", \\\"{x:620,y:476,t:1527794521800};\\\", \\\"{x:612,y:483,t:1527794521816};\\\", \\\"{x:608,y:491,t:1527794521834};\\\", \\\"{x:607,y:496,t:1527794521850};\\\", \\\"{x:605,y:499,t:1527794521866};\\\", \\\"{x:605,y:500,t:1527794521890};\\\", \\\"{x:605,y:501,t:1527794521901};\\\", \\\"{x:605,y:502,t:1527794522082};\\\", \\\"{x:605,y:503,t:1527794522090};\\\", \\\"{x:607,y:506,t:1527794522101};\\\", \\\"{x:615,y:510,t:1527794522118};\\\", \\\"{x:617,y:512,t:1527794522134};\\\", \\\"{x:616,y:512,t:1527794522251};\\\", \\\"{x:610,y:511,t:1527794522268};\\\", \\\"{x:607,y:509,t:1527794522283};\\\", \\\"{x:606,y:509,t:1527794522301};\\\", \\\"{x:605,y:509,t:1527794522338};\\\", \\\"{x:606,y:511,t:1527794527786};\\\", \\\"{x:613,y:521,t:1527794527794};\\\", \\\"{x:636,y:548,t:1527794527807};\\\", \\\"{x:662,y:581,t:1527794527822};\\\", \\\"{x:674,y:589,t:1527794527837};\\\", \\\"{x:690,y:595,t:1527794527855};\\\", \\\"{x:697,y:601,t:1527794527871};\\\", \\\"{x:715,y:605,t:1527794527889};\\\", \\\"{x:720,y:606,t:1527794527904};\\\", \\\"{x:724,y:606,t:1527794527922};\\\", \\\"{x:729,y:606,t:1527794527939};\\\", \\\"{x:736,y:603,t:1527794527954};\\\", \\\"{x:740,y:602,t:1527794527971};\\\", \\\"{x:744,y:599,t:1527794527988};\\\", \\\"{x:752,y:595,t:1527794528005};\\\", \\\"{x:764,y:589,t:1527794528021};\\\", \\\"{x:769,y:585,t:1527794528039};\\\", \\\"{x:794,y:580,t:1527794528055};\\\", \\\"{x:812,y:580,t:1527794528072};\\\", \\\"{x:867,y:580,t:1527794528089};\\\", \\\"{x:974,y:583,t:1527794528106};\\\", \\\"{x:1078,y:593,t:1527794528122};\\\", \\\"{x:1202,y:605,t:1527794528139};\\\", \\\"{x:1294,y:609,t:1527794528156};\\\", \\\"{x:1366,y:612,t:1527794528172};\\\", \\\"{x:1404,y:611,t:1527794528189};\\\", \\\"{x:1406,y:613,t:1527794528206};\\\", \\\"{x:1419,y:616,t:1527794528221};\\\", \\\"{x:1430,y:619,t:1527794528238};\\\", \\\"{x:1433,y:619,t:1527794528255};\\\", \\\"{x:1443,y:619,t:1527794528272};\\\", \\\"{x:1454,y:619,t:1527794528289};\\\", \\\"{x:1468,y:619,t:1527794528306};\\\", \\\"{x:1475,y:619,t:1527794528322};\\\", \\\"{x:1476,y:619,t:1527794528339};\\\", \\\"{x:1473,y:618,t:1527794528418};\\\", \\\"{x:1467,y:614,t:1527794528426};\\\", \\\"{x:1464,y:612,t:1527794528440};\\\", \\\"{x:1453,y:606,t:1527794528457};\\\", \\\"{x:1437,y:599,t:1527794528473};\\\", \\\"{x:1431,y:594,t:1527794528489};\\\", \\\"{x:1402,y:582,t:1527794528506};\\\", \\\"{x:1389,y:574,t:1527794528522};\\\", \\\"{x:1380,y:572,t:1527794528539};\\\", \\\"{x:1372,y:562,t:1527794528556};\\\", \\\"{x:1363,y:552,t:1527794528573};\\\", \\\"{x:1354,y:549,t:1527794528589};\\\", \\\"{x:1350,y:547,t:1527794528606};\\\", \\\"{x:1349,y:546,t:1527794528623};\\\", \\\"{x:1348,y:546,t:1527794528658};\\\", \\\"{x:1339,y:546,t:1527794528673};\\\", \\\"{x:1330,y:546,t:1527794528690};\\\", \\\"{x:1317,y:548,t:1527794528707};\\\", \\\"{x:1314,y:548,t:1527794528723};\\\", \\\"{x:1312,y:548,t:1527794528740};\\\", \\\"{x:1309,y:548,t:1527794528756};\\\", \\\"{x:1302,y:550,t:1527794528773};\\\", \\\"{x:1295,y:554,t:1527794528789};\\\", \\\"{x:1284,y:563,t:1527794528807};\\\", \\\"{x:1274,y:568,t:1527794528824};\\\", \\\"{x:1268,y:572,t:1527794528840};\\\", \\\"{x:1266,y:573,t:1527794528856};\\\", \\\"{x:1266,y:571,t:1527794529147};\\\", \\\"{x:1266,y:567,t:1527794529156};\\\", \\\"{x:1268,y:565,t:1527794529173};\\\", \\\"{x:1268,y:564,t:1527794529194};\\\", \\\"{x:1269,y:563,t:1527794529207};\\\", \\\"{x:1269,y:562,t:1527794529224};\\\", \\\"{x:1270,y:560,t:1527794529240};\\\", \\\"{x:1268,y:560,t:1527794529370};\\\", \\\"{x:1264,y:561,t:1527794529377};\\\", \\\"{x:1261,y:562,t:1527794529389};\\\", \\\"{x:1257,y:577,t:1527794529407};\\\", \\\"{x:1256,y:592,t:1527794529423};\\\", \\\"{x:1254,y:607,t:1527794529440};\\\", \\\"{x:1250,y:619,t:1527794529457};\\\", \\\"{x:1240,y:634,t:1527794529473};\\\", \\\"{x:1227,y:656,t:1527794529490};\\\", \\\"{x:1221,y:667,t:1527794529507};\\\", \\\"{x:1214,y:677,t:1527794529523};\\\", \\\"{x:1211,y:680,t:1527794529540};\\\", \\\"{x:1211,y:682,t:1527794529556};\\\", \\\"{x:1205,y:687,t:1527794529574};\\\", \\\"{x:1200,y:694,t:1527794529590};\\\", \\\"{x:1198,y:700,t:1527794529607};\\\", \\\"{x:1195,y:702,t:1527794529625};\\\", \\\"{x:1193,y:705,t:1527794529640};\\\", \\\"{x:1191,y:709,t:1527794529657};\\\", \\\"{x:1187,y:721,t:1527794529674};\\\", \\\"{x:1184,y:728,t:1527794529690};\\\", \\\"{x:1183,y:730,t:1527794529707};\\\", \\\"{x:1181,y:732,t:1527794529723};\\\", \\\"{x:1180,y:734,t:1527794529740};\\\", \\\"{x:1180,y:736,t:1527794529763};\\\", \\\"{x:1180,y:739,t:1527794529775};\\\", \\\"{x:1180,y:744,t:1527794529790};\\\", \\\"{x:1180,y:748,t:1527794529808};\\\", \\\"{x:1179,y:751,t:1527794529825};\\\", \\\"{x:1176,y:754,t:1527794529840};\\\", \\\"{x:1176,y:757,t:1527794530434};\\\", \\\"{x:1176,y:759,t:1527794530443};\\\", \\\"{x:1169,y:787,t:1527794530457};\\\", \\\"{x:1168,y:804,t:1527794530474};\\\", \\\"{x:1159,y:826,t:1527794530490};\\\", \\\"{x:1157,y:848,t:1527794530508};\\\", \\\"{x:1157,y:859,t:1527794530523};\\\", \\\"{x:1157,y:874,t:1527794530541};\\\", \\\"{x:1164,y:896,t:1527794530557};\\\", \\\"{x:1171,y:914,t:1527794530573};\\\", \\\"{x:1173,y:920,t:1527794530590};\\\", \\\"{x:1175,y:920,t:1527794530608};\\\", \\\"{x:1175,y:922,t:1527794530623};\\\", \\\"{x:1178,y:931,t:1527794530641};\\\", \\\"{x:1179,y:932,t:1527794530658};\\\", \\\"{x:1180,y:935,t:1527794530706};\\\", \\\"{x:1180,y:938,t:1527794530713};\\\", \\\"{x:1183,y:941,t:1527794530724};\\\", \\\"{x:1183,y:942,t:1527794530741};\\\", \\\"{x:1184,y:943,t:1527794530758};\\\", \\\"{x:1184,y:946,t:1527794530946};\\\", \\\"{x:1184,y:948,t:1527794530962};\\\", \\\"{x:1184,y:949,t:1527794530975};\\\", \\\"{x:1182,y:954,t:1527794530992};\\\", \\\"{x:1182,y:958,t:1527794531009};\\\", \\\"{x:1182,y:962,t:1527794531027};\\\", \\\"{x:1181,y:964,t:1527794531042};\\\", \\\"{x:1181,y:966,t:1527794531123};\\\", \\\"{x:1180,y:966,t:1527794531130};\\\", \\\"{x:1180,y:965,t:1527794531939};\\\", \\\"{x:1180,y:964,t:1527794531963};\\\", \\\"{x:1180,y:962,t:1527794531995};\\\", \\\"{x:1181,y:961,t:1527794532027};\\\", \\\"{x:1183,y:960,t:1527794532043};\\\", \\\"{x:1187,y:960,t:1527794532059};\\\", \\\"{x:1203,y:962,t:1527794532076};\\\", \\\"{x:1218,y:967,t:1527794532092};\\\", \\\"{x:1230,y:972,t:1527794532109};\\\", \\\"{x:1239,y:973,t:1527794532127};\\\", \\\"{x:1243,y:974,t:1527794532143};\\\", \\\"{x:1244,y:976,t:1527794532160};\\\", \\\"{x:1246,y:976,t:1527794532176};\\\", \\\"{x:1247,y:976,t:1527794532193};\\\", \\\"{x:1249,y:976,t:1527794532210};\\\", \\\"{x:1250,y:976,t:1527794532227};\\\", \\\"{x:1250,y:975,t:1527794532418};\\\", \\\"{x:1250,y:973,t:1527794532555};\\\", \\\"{x:1250,y:972,t:1527794532562};\\\", \\\"{x:1250,y:969,t:1527794532578};\\\", \\\"{x:1250,y:968,t:1527794532593};\\\", \\\"{x:1250,y:966,t:1527794532610};\\\", \\\"{x:1250,y:965,t:1527794532627};\\\", \\\"{x:1250,y:963,t:1527794532659};\\\", \\\"{x:1250,y:962,t:1527794532676};\\\", \\\"{x:1250,y:961,t:1527794532930};\\\", \\\"{x:1249,y:961,t:1527794533074};\\\", \\\"{x:1249,y:959,t:1527794533115};\\\", \\\"{x:1250,y:959,t:1527794533127};\\\", \\\"{x:1253,y:959,t:1527794533143};\\\", \\\"{x:1257,y:959,t:1527794533161};\\\", \\\"{x:1260,y:959,t:1527794533176};\\\", \\\"{x:1264,y:959,t:1527794533194};\\\", \\\"{x:1265,y:959,t:1527794533467};\\\", \\\"{x:1266,y:961,t:1527794533477};\\\", \\\"{x:1268,y:961,t:1527794533493};\\\", \\\"{x:1269,y:962,t:1527794533510};\\\", \\\"{x:1270,y:962,t:1527794533538};\\\", \\\"{x:1272,y:962,t:1527794533554};\\\", \\\"{x:1274,y:962,t:1527794533562};\\\", \\\"{x:1275,y:963,t:1527794533586};\\\", \\\"{x:1276,y:963,t:1527794533594};\\\", \\\"{x:1275,y:963,t:1527794534258};\\\", \\\"{x:1274,y:956,t:1527794534274};\\\", \\\"{x:1269,y:947,t:1527794534282};\\\", \\\"{x:1259,y:938,t:1527794534294};\\\", \\\"{x:1240,y:915,t:1527794534312};\\\", \\\"{x:1228,y:893,t:1527794534327};\\\", \\\"{x:1221,y:876,t:1527794534345};\\\", \\\"{x:1212,y:867,t:1527794534361};\\\", \\\"{x:1200,y:847,t:1527794534377};\\\", \\\"{x:1194,y:837,t:1527794534394};\\\", \\\"{x:1191,y:835,t:1527794534412};\\\", \\\"{x:1189,y:832,t:1527794534427};\\\", \\\"{x:1190,y:832,t:1527794534578};\\\", \\\"{x:1194,y:833,t:1527794534595};\\\", \\\"{x:1195,y:833,t:1527794534612};\\\", \\\"{x:1196,y:834,t:1527794534629};\\\", \\\"{x:1199,y:834,t:1527794534644};\\\", \\\"{x:1202,y:836,t:1527794534690};\\\", \\\"{x:1203,y:836,t:1527794534706};\\\", \\\"{x:1205,y:836,t:1527794534714};\\\", \\\"{x:1208,y:836,t:1527794534728};\\\", \\\"{x:1215,y:836,t:1527794534744};\\\", \\\"{x:1220,y:836,t:1527794534761};\\\", \\\"{x:1221,y:835,t:1527794534930};\\\", \\\"{x:1221,y:834,t:1527794534945};\\\", \\\"{x:1222,y:832,t:1527794534962};\\\", \\\"{x:1224,y:828,t:1527794534978};\\\", \\\"{x:1224,y:827,t:1527794534995};\\\", \\\"{x:1223,y:827,t:1527794535075};\\\", \\\"{x:1220,y:830,t:1527794535083};\\\", \\\"{x:1217,y:839,t:1527794535097};\\\", \\\"{x:1212,y:857,t:1527794535112};\\\", \\\"{x:1205,y:876,t:1527794535128};\\\", \\\"{x:1202,y:889,t:1527794535146};\\\", \\\"{x:1202,y:896,t:1527794535162};\\\", \\\"{x:1202,y:906,t:1527794535178};\\\", \\\"{x:1202,y:910,t:1527794535196};\\\", \\\"{x:1208,y:921,t:1527794535211};\\\", \\\"{x:1208,y:925,t:1527794535229};\\\", \\\"{x:1209,y:929,t:1527794535245};\\\", \\\"{x:1209,y:931,t:1527794535261};\\\", \\\"{x:1211,y:937,t:1527794535279};\\\", \\\"{x:1215,y:943,t:1527794535295};\\\", \\\"{x:1218,y:948,t:1527794535312};\\\", \\\"{x:1220,y:951,t:1527794535329};\\\", \\\"{x:1220,y:952,t:1527794535345};\\\", \\\"{x:1227,y:959,t:1527794535362};\\\", \\\"{x:1228,y:960,t:1527794535378};\\\", \\\"{x:1229,y:961,t:1527794535443};\\\", \\\"{x:1229,y:962,t:1527794535466};\\\", \\\"{x:1230,y:963,t:1527794535907};\\\", \\\"{x:1230,y:964,t:1527794535923};\\\", \\\"{x:1230,y:965,t:1527794535946};\\\", \\\"{x:1230,y:967,t:1527794535970};\\\", \\\"{x:1228,y:967,t:1527794535986};\\\", \\\"{x:1226,y:968,t:1527794535996};\\\", \\\"{x:1223,y:970,t:1527794536014};\\\", \\\"{x:1219,y:970,t:1527794536029};\\\", \\\"{x:1217,y:970,t:1527794536045};\\\", \\\"{x:1214,y:970,t:1527794536062};\\\", \\\"{x:1212,y:970,t:1527794536079};\\\", \\\"{x:1211,y:970,t:1527794536095};\\\", \\\"{x:1212,y:970,t:1527794536257};\\\", \\\"{x:1213,y:971,t:1527794536265};\\\", \\\"{x:1216,y:973,t:1527794536279};\\\", \\\"{x:1232,y:975,t:1527794536295};\\\", \\\"{x:1240,y:976,t:1527794536312};\\\", \\\"{x:1248,y:979,t:1527794536329};\\\", \\\"{x:1260,y:984,t:1527794536345};\\\", \\\"{x:1262,y:984,t:1527794536499};\\\", \\\"{x:1263,y:984,t:1527794536522};\\\", \\\"{x:1264,y:984,t:1527794536530};\\\", \\\"{x:1274,y:980,t:1527794536546};\\\", \\\"{x:1278,y:975,t:1527794536564};\\\", \\\"{x:1286,y:970,t:1527794536579};\\\", \\\"{x:1292,y:965,t:1527794536596};\\\", \\\"{x:1299,y:963,t:1527794536613};\\\", \\\"{x:1303,y:959,t:1527794536629};\\\", \\\"{x:1302,y:959,t:1527794536745};\\\", \\\"{x:1300,y:959,t:1527794536777};\\\", \\\"{x:1299,y:959,t:1527794536785};\\\", \\\"{x:1299,y:960,t:1527794536796};\\\", \\\"{x:1296,y:960,t:1527794536818};\\\", \\\"{x:1294,y:960,t:1527794536829};\\\", \\\"{x:1293,y:962,t:1527794536847};\\\", \\\"{x:1290,y:962,t:1527794536866};\\\", \\\"{x:1289,y:963,t:1527794536879};\\\", \\\"{x:1287,y:963,t:1527794536896};\\\", \\\"{x:1281,y:963,t:1527794536914};\\\", \\\"{x:1275,y:963,t:1527794536930};\\\", \\\"{x:1272,y:963,t:1527794536946};\\\", \\\"{x:1272,y:962,t:1527794537387};\\\", \\\"{x:1274,y:960,t:1527794537398};\\\", \\\"{x:1275,y:959,t:1527794537413};\\\", \\\"{x:1275,y:958,t:1527794551006};\\\", \\\"{x:1275,y:957,t:1527794551013};\\\", \\\"{x:1271,y:957,t:1527794551031};\\\", \\\"{x:1263,y:957,t:1527794551046};\\\", \\\"{x:1257,y:959,t:1527794551063};\\\", \\\"{x:1250,y:962,t:1527794551080};\\\", \\\"{x:1246,y:962,t:1527794551095};\\\", \\\"{x:1235,y:963,t:1527794551113};\\\", \\\"{x:1221,y:961,t:1527794551130};\\\", \\\"{x:1204,y:959,t:1527794551146};\\\", \\\"{x:1201,y:959,t:1527794551163};\\\", \\\"{x:1199,y:959,t:1527794551182};\\\", \\\"{x:1197,y:959,t:1527794551196};\\\", \\\"{x:1195,y:958,t:1527794551213};\\\", \\\"{x:1184,y:952,t:1527794551231};\\\", \\\"{x:1163,y:945,t:1527794551246};\\\", \\\"{x:1141,y:940,t:1527794551263};\\\", \\\"{x:1122,y:934,t:1527794551280};\\\", \\\"{x:1112,y:933,t:1527794551296};\\\", \\\"{x:1100,y:931,t:1527794551313};\\\", \\\"{x:1092,y:929,t:1527794551330};\\\", \\\"{x:1087,y:927,t:1527794551346};\\\", \\\"{x:1074,y:922,t:1527794551363};\\\", \\\"{x:1073,y:922,t:1527794551380};\\\", \\\"{x:1071,y:921,t:1527794551396};\\\", \\\"{x:1068,y:919,t:1527794551412};\\\", \\\"{x:1058,y:919,t:1527794551430};\\\", \\\"{x:1057,y:918,t:1527794551469};\\\", \\\"{x:1056,y:915,t:1527794551479};\\\", \\\"{x:1051,y:892,t:1527794551497};\\\", \\\"{x:1021,y:836,t:1527794551512};\\\", \\\"{x:983,y:768,t:1527794551530};\\\", \\\"{x:949,y:696,t:1527794551547};\\\", \\\"{x:924,y:596,t:1527794551564};\\\", \\\"{x:888,y:503,t:1527794551581};\\\", \\\"{x:865,y:459,t:1527794551596};\\\", \\\"{x:823,y:378,t:1527794551627};\\\", \\\"{x:812,y:358,t:1527794551644};\\\", \\\"{x:807,y:341,t:1527794551661};\\\", \\\"{x:805,y:338,t:1527794551677};\\\", \\\"{x:804,y:336,t:1527794551700};\\\", \\\"{x:803,y:336,t:1527794551725};\\\", \\\"{x:803,y:342,t:1527794551789};\\\", \\\"{x:803,y:361,t:1527794551797};\\\", \\\"{x:806,y:382,t:1527794551812};\\\", \\\"{x:815,y:416,t:1527794551830};\\\", \\\"{x:817,y:422,t:1527794551845};\\\", \\\"{x:833,y:452,t:1527794551862};\\\", \\\"{x:840,y:465,t:1527794551879};\\\", \\\"{x:842,y:468,t:1527794551894};\\\", \\\"{x:843,y:470,t:1527794551912};\\\", \\\"{x:843,y:471,t:1527794551929};\\\", \\\"{x:843,y:472,t:1527794551944};\\\", \\\"{x:843,y:473,t:1527794552005};\\\", \\\"{x:842,y:473,t:1527794552078};\\\", \\\"{x:842,y:478,t:1527794552095};\\\", \\\"{x:842,y:482,t:1527794552150};\\\", \\\"{x:841,y:486,t:1527794552162};\\\", \\\"{x:841,y:497,t:1527794552179};\\\", \\\"{x:838,y:503,t:1527794552196};\\\", \\\"{x:837,y:504,t:1527794552213};\\\", \\\"{x:837,y:506,t:1527794552269};\\\", \\\"{x:835,y:507,t:1527794552285};\\\", \\\"{x:835,y:508,t:1527794552324};\\\", \\\"{x:832,y:512,t:1527794552333};\\\", \\\"{x:830,y:515,t:1527794552344};\\\", \\\"{x:830,y:516,t:1527794552360};\\\", \\\"{x:830,y:517,t:1527794552605};\\\", \\\"{x:831,y:520,t:1527794552613};\\\", \\\"{x:833,y:520,t:1527794552629};\\\", \\\"{x:833,y:522,t:1527794552981};\\\", \\\"{x:833,y:527,t:1527794552995};\\\", \\\"{x:818,y:541,t:1527794553015};\\\", \\\"{x:801,y:553,t:1527794553029};\\\", \\\"{x:783,y:579,t:1527794553046};\\\", \\\"{x:728,y:622,t:1527794553063};\\\", \\\"{x:652,y:660,t:1527794553080};\\\", \\\"{x:611,y:681,t:1527794553095};\\\", \\\"{x:585,y:703,t:1527794553112};\\\", \\\"{x:568,y:719,t:1527794553129};\\\", \\\"{x:555,y:727,t:1527794553145};\\\", \\\"{x:538,y:737,t:1527794553163};\\\", \\\"{x:527,y:741,t:1527794553179};\\\", \\\"{x:518,y:742,t:1527794553195};\\\", \\\"{x:515,y:742,t:1527794553212};\\\", \\\"{x:507,y:745,t:1527794553229};\\\", \\\"{x:502,y:746,t:1527794553246};\\\" ] }, { \\\"rt\\\": 99583, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1180452, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"F and B start work at that hour of day because they are scheduled on that hour but they vary in how long they work. we could also tell that J ends work because they only work for two hours which means their shift ends at 12pm. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8525, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Mexico\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1189985, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 21630, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1212633, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 106682, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1320655, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"03QKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"uniform\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2766}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":6,\"textContent\":\" \"},{\"nodeType\":1,\"id\":7,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":8,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":9,\"textContent\":\" \"},{\"nodeType\":8,\"id\":10},{\"nodeType\":3,\"id\":11,\"textContent\":\" \"},{\"nodeType\":1,\"id\":12,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":13,\"textContent\":\" \"},{\"nodeType\":1,\"id\":14,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":15,\"textContent\":\" \"},{\"nodeType\":1,\"id\":16,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":17,\"textContent\":\" \"},{\"nodeType\":1,\"id\":18,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":19,\"textContent\":\" \"},{\"nodeType\":1,\"id\":20,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":21,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":22,\"textContent\":\" \"},{\"nodeType\":8,\"id\":23},{\"nodeType\":3,\"id\":24,\"textContent\":\" \"},{\"nodeType\":1,\"id\":25,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":26,\"textContent\":\" \"},{\"nodeType\":1,\"id\":27,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":28,\"textContent\":\" \"},{\"nodeType\":1,\"id\":29,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":30,\"textContent\":\" \"},{\"nodeType\":1,\"id\":31,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":32,\"textContent\":\" \"},{\"nodeType\":1,\"id\":33,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":34,\"textContent\":\" \"},{\"nodeType\":1,\"id\":35,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":36,\"textContent\":\" \"},{\"nodeType\":1,\"id\":37,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":38,\"textContent\":\" \"},{\"nodeType\":8,\"id\":39},{\"nodeType\":3,\"id\":40,\"textContent\":\" \"},{\"nodeType\":1,\"id\":41,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":42,\"textContent\":\" \"},{\"nodeType\":8,\"id\":43},{\"nodeType\":3,\"id\":44,\"textContent\":\" \"},{\"nodeType\":8,\"id\":45},{\"nodeType\":3,\"id\":46,\"textContent\":\" \"},{\"nodeType\":1,\"id\":47,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":48,\"textContent\":\" \"},{\"nodeType\":1,\"id\":49,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":50,\"textContent\":\" \"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":52,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":53,\"textContent\":\" \"},{\"nodeType\":8,\"id\":54},{\"nodeType\":3,\"id\":55,\"textContent\":\" \"},{\"nodeType\":1,\"id\":56,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":57,\"textContent\":\" \"},{\"nodeType\":1,\"id\":58,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":59,\"textContent\":\" \"},{\"nodeType\":8,\"id\":60},{\"nodeType\":3,\"id\":61,\"textContent\":\" \"},{\"nodeType\":1,\"id\":62,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":63,\"textContent\":\" \"},{\"nodeType\":1,\"id\":64,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":65,\"textContent\":\" \"},{\"nodeType\":1,\"id\":66,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":67,\"textContent\":\" \"},{\"nodeType\":1,\"id\":68,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":69,\"textContent\":\" \"},{\"nodeType\":1,\"id\":70,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":71,\"textContent\":\" \"},{\"nodeType\":1,\"id\":72,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":73,\"textContent\":\" \"},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\"03QKB\"}]},{\"nodeType\":3,\"id\":78,\"textContent\":\" \"},{\"nodeType\":1,\"id\":79,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":80,\"textContent\":\" \"},{\"nodeType\":8,\"id\":81},{\"nodeType\":3,\"id\":82,\"textContent\":\" \"},{\"nodeType\":1,\"id\":83,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":84,\"textContent\":\" \"},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":86,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":88,\"textContent\":\" \"},{\"nodeType\":8,\"id\":89},{\"nodeType\":3,\"id\":90,\"textContent\":\" \"},{\"nodeType\":8,\"id\":91},{\"nodeType\":3,\"id\":92,\"textContent\":\" \"},{\"nodeType\":1,\"id\":93,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":94,\"textContent\":\" \"},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":99,\"textContent\":\" \"},{\"nodeType\":1,\"id\":100,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":106,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":114,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":122,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":130,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":138,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":146,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":154,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":162,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":197,\"textContent\":\" \"},{\"nodeType\":1,\"id\":198,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":199,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":203,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":206,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":207,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":211,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":213,\"textContent\":\" \"},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":215,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":219,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":226,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":227,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":229,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":235,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":299,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":307,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":315,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":323,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":331,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":339,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":347,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":356,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":372,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":380,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":388,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":396,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":404,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":412,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":420,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":428,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":444,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":484,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":485,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":486,\"textContent\":\" \"},{\"nodeType\":1,\"id\":487,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":493,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":501,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":504,\"textContent\":\" \"},{\"nodeType\":1,\"id\":505,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":506,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":508,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":509,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":517,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":525,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":605,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":610,\"textContent\":\" \"},{\"nodeType\":1,\"id\":611,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":613,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":614,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":615,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":616,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":618,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":622,\"textContent\":\" \"},{\"nodeType\":1,\"id\":623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":624,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":625,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":630,\"textContent\":\" \"},{\"nodeType\":1,\"id\":631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":632,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":633,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":638,\"textContent\":\" \"},{\"nodeType\":1,\"id\":639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":640,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":641,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":646,\"textContent\":\" \"},{\"nodeType\":1,\"id\":647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":648,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":649,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":654,\"textContent\":\" \"},{\"nodeType\":1,\"id\":655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":656,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":657,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":662,\"textContent\":\" \"},{\"nodeType\":1,\"id\":663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":664,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":665,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":672,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":673,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":680,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":681,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":688,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":691,\"textContent\":\" \"},{\"nodeType\":1,\"id\":692,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":696,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":699,\"textContent\":\" \"},{\"nodeType\":1,\"id\":700,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":703,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":704,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":707,\"textContent\":\" \"},{\"nodeType\":1,\"id\":708,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":712,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":715,\"textContent\":\" \"},{\"nodeType\":1,\"id\":716,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":719,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":720,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":723,\"textContent\":\" \"},{\"nodeType\":1,\"id\":724,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":725,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":727,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":728,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":731,\"textContent\":\" \"},{\"nodeType\":1,\"id\":732,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":733,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":735,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":736,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":742,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":743,\"textContent\":\" \"},{\"nodeType\":1,\"id\":744,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":745,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":747,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":751,\"textContent\":\" \"},{\"nodeType\":1,\"id\":752,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":753,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":754,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":759,\"textContent\":\" \"},{\"nodeType\":1,\"id\":760,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":761,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":762,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":766,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":769,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":773,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":774,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":775,\"textContent\":\" \"},{\"nodeType\":1,\"id\":776,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":777,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":781,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":782,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":783,\"textContent\":\" \"},{\"nodeType\":1,\"id\":784,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":785,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":789,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":790,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":791,\"textContent\":\" \"},{\"nodeType\":1,\"id\":792,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":793,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":797,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":798,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":799,\"textContent\":\" \"},{\"nodeType\":1,\"id\":800,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":801,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":805,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":806,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":807,\"textContent\":\" \"},{\"nodeType\":1,\"id\":808,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":809,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":813,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":814,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":815,\"textContent\":\" \"},{\"nodeType\":1,\"id\":816,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":817,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":820,\"textContent\":\" \"},{\"nodeType\":1,\"id\":821,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":822,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":824,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":825,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":828,\"textContent\":\" \"},{\"nodeType\":1,\"id\":829,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":830,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":832,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":833,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":836,\"textContent\":\" \"},{\"nodeType\":1,\"id\":837,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":838,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":840,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":841,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":842,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":844,\"textContent\":\" \"},{\"nodeType\":1,\"id\":845,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":846,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":848,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":849,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":850,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":852,\"textContent\":\" \"},{\"nodeType\":1,\"id\":853,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":854,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":858,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":860,\"textContent\":\" \"},{\"nodeType\":1,\"id\":861,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":862,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":866,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":868,\"textContent\":\" \"},{\"nodeType\":1,\"id\":869,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":870,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":874,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":876,\"textContent\":\" \"},{\"nodeType\":1,\"id\":877,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":878,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":882,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":884,\"textContent\":\" \"},{\"nodeType\":1,\"id\":885,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":886,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":890,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":896,\"textContent\":\" \"},{\"nodeType\":1,\"id\":897,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":898,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":900,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":902,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":903,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":904,\"textContent\":\" \"},{\"nodeType\":1,\"id\":905,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":906,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":910,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":911,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":912,\"textContent\":\" \"},{\"nodeType\":1,\"id\":913,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":914,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":918,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":919,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":920,\"textContent\":\" \"},{\"nodeType\":1,\"id\":921,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":922,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":923,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":926,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":927,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\" \"},{\"nodeType\":1,\"id\":929,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":930,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":931,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":934,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":935,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":936,\"textContent\":\" \"},{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":939,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":942,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":943,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":944,\"textContent\":\" \"},{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":947,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":950,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":951,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":952,\"textContent\":\" \"},{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":955,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":958,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":959,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":960,\"textContent\":\" \"},{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":963,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":966,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":967,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":968,\"textContent\":\" \"},{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":971,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":973,\"textContent\":\" \"},{\"nodeType\":1,\"id\":974,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":975,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":979,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":981,\"textContent\":\" \"},{\"nodeType\":1,\"id\":982,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":983,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":987,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":989,\"textContent\":\" \"},{\"nodeType\":1,\"id\":990,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":991,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":995,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":997,\"textContent\":\" \"},{\"nodeType\":1,\"id\":998,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":999,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1003,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1007,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1009,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1010,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1013,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1014,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1015,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1018,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1019,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1021,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1022,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1023,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1026,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1027,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1029,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1030,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1031,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1034,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1035,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1037,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1038,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1039,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1042,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1043,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1048,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1049,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1050,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1051,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1055,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1056,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1057,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1060,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1063,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1064,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1065,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1068,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1071,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1072,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1073,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1076,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1079,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1080,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1081,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1084,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1088,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1089,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1090,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1091,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1095,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1096,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1099,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1100,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1103,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1107,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1108,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1111,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1112,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1115,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1116,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1119,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1120,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1123,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1131,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1139,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1147,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1155,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1163,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1171,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1203,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1204,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1206,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1212,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1220,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1228,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1236,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1244,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1252,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1260,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1268,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1272,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1275,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1276,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1277,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1280,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1283,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1284,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1285,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1288,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1291,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1292,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1293,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1296,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1299,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1300,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1301,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1304,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1308,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1309,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1312,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1316,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1317,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1319,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1320,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1324,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1325,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1327,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1328,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1332,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1333,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1335,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1336,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1340,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1341,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1343,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1344,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1348,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1349,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1354,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1356,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1357,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1359,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1360,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1361,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1362,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1364,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1365,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1366,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1368,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1369,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1370,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1372,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1373,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1374,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1377,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1378,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1380,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1381,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1382,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1385,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1386,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1388,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1389,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1390,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1393,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1394,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1396,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1397,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1398,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1401,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1402,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1404,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1405,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1406,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1409,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1410,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1412,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1413,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1414,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1417,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1418,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1420,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1421,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1422,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1425,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1426,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1428,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1429,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1430,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1433,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1434,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1436,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1437,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1438,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1441,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1442,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1444,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1445,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1446,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1448,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1449,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1450,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1452,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1453,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1454,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1456,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1457,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1460,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1461,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1462,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1464,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1465,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1466,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1468,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1469,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1470,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1472,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1473,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1474,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1476,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1477,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1478,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1481,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1482,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1484,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1485,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1486,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1493,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1501,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1507,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1509,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1512,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1514,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1515,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1519,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1522,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1523,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1525,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1526,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1527,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1529,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1530,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1531,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1533,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1534,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1535,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1537,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1538,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1541,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1542,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1543,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1545,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1546,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1547,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1550,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1551,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1553,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1554,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1555,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1557,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1558,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1561,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1562,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1563,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1565,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1566,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1569,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1570,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1573,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1575,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1577,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1578,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1579,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1582,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1583,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1585,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1586,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1587,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1589,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1590,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1591,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1594,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1595,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1599,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1602,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1603,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1606,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1610,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1611,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1614,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1615,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1618,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1620,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1622,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1623,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1625,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1626,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1628,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1631,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1633,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1634,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1636,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1638,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1641,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1642,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1644,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1646,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1647,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1649,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1650,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1652,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1654,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1655,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1660,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1662,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1663,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1664,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1665,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1687,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1695,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1703,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1711,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1719,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1735,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1739,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1740,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1743,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1744,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1747,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1748,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1749,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1751,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1752,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1754,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1755,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1756,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1757,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1759,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1760,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1763,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1764,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1765,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1766,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1767,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1768,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1770,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1771,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1772,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1774,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1775,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1776,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1778,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1779,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1780,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1782,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1783,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1784,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1786,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1787,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1788,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1790,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1791,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1792,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1794,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1795,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1796,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1798,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1799,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1800,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1802,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1803,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1804,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1806,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1807,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1808,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1813,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1815,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1816,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1818,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1824,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1832,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1840,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1848,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1856,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1864,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1872,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1880,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1888,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1891,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1892,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1893,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1895,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1896,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1897,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1900,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1901,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1903,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1904,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1905,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1907,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1908,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1909,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1911,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1912,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1913,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1915,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1916,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1917,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1919,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1920,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1921,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1923,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1924,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1925,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1927,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1928,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1929,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1932,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1933,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1934,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1935,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1936,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1937,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1940,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1941,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1942,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1943,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1944,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1945,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1948,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1949,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1950,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1951,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1952,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1953,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1956,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1957,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1958,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1959,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1960,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1961,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1966,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1968,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1969,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1970,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1971,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1977,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1985,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1993,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2001,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2009,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2017,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2025,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2033,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2041,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2045,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2046,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2048,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2049,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2050,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2053,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2054,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2055,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2056,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2057,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2058,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2061,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2062,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2063,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2064,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2065,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2066,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2069,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2070,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2071,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2072,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2073,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2074,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2077,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2078,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2079,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2080,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2081,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2082,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2084,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2085,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2086,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2087,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2088,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2089,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2090,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2092,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2093,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2094,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2095,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2096,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2097,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2098,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2105,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2113,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2119,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2121,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2122,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2123,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2124,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2126,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2128,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2129,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2132,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2136,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2137,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2140,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2144,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2145,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2148,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2152,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2153,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2156,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2160,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2161,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2164,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2165,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2168,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2169,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2171,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2172,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2173,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2176,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2177,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2179,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2180,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2181,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2184,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2185,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2187,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2188,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2189,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2192,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2193,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2195,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2196,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2197,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2200,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2201,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2203,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2204,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2205,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2212,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2220,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2228,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2236,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2244,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2252,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2260,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2268,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2274,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2276,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2277,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2279,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2283},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2289,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2290,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2292,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2293,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2296,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2297},{\"nodeType\":3,\"id\":2298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2305,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2306},{\"nodeType\":3,\"id\":2307,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2308,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2310,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2311,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 3300, dom: 3976, initialDom: 4480",
  "javascriptErrors": []
}