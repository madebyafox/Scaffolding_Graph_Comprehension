var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5e092766873996b2e645b2f14b0a5b77",
  "created": "2018-05-22T13:10:51.7460975-07:00",
  "lastActivity": "2018-05-22T13:12:49.5691832-07:00",
  "pageViews": [
    {
      "id": "0522512841729091a974c4bc3c31a3a0db023d5c",
      "startTime": "2018-05-22T13:10:51.7641832-07:00",
      "endTime": "2018-05-22T13:12:49.5691832-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 117805,
      "engagementTime": 107734,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 117805,
  "engagementTime": 107734,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=H1RGT",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0a374e87a794701aca52190030fa0f47",
  "gdpr": false
}