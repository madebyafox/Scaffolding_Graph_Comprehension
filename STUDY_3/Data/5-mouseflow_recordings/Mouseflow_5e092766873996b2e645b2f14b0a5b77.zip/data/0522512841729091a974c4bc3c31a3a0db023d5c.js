var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522512841729091a974c4bc3c31a3a0db023d5c"] = {
  "startTime": "2018-05-22T20:10:51.7641832Z",
  "websitePageUrl": "/16",
  "visitTime": 117805,
  "engagementTime": 107734,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5e092766873996b2e645b2f14b0a5b77",
    "created": "2018-05-22T20:10:51.7460975+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=H1RGT",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0a374e87a794701aca52190030fa0f47",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5e092766873996b2e645b2f14b0a5b77/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 211,
      "e": 211,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 602,
      "e": 602,
      "ty": 2,
      "x": 556,
      "y": 803
    },
    {
      "t": 702,
      "e": 702,
      "ty": 2,
      "x": 555,
      "y": 806
    },
    {
      "t": 797,
      "e": 797,
      "ty": 41,
      "x": 51473,
      "y": 44207,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 802,
      "e": 802,
      "ty": 2,
      "x": 554,
      "y": 806
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 537,
      "y": 806
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 535,
      "y": 806
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 49225,
      "y": 44207,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 532,
      "y": 799
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 47651,
      "y": 42323,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 505,
      "y": 737
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 472,
      "y": 626
    },
    {
      "t": 1451,
      "e": 1451,
      "ty": 6,
      "x": 465,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 463,
      "y": 583
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 41131,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 467,
      "y": 563
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 467,
      "y": 573
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 41805,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 469,
      "y": 587
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 424,
      "y": 579
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 7,
      "x": 230,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2003,
      "e": 2003,
      "ty": 2,
      "x": 230,
      "y": 521
    },
    {
      "t": 2004,
      "e": 2004,
      "ty": 41,
      "x": 14939,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 2,
      "x": 229,
      "y": 517
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 2,
      "x": 238,
      "y": 519
    },
    {
      "t": 2235,
      "e": 2235,
      "ty": 6,
      "x": 251,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 18874,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2302,
      "e": 2302,
      "ty": 2,
      "x": 292,
      "y": 522
    },
    {
      "t": 2385,
      "e": 2385,
      "ty": 7,
      "x": 332,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 334,
      "y": 520
    },
    {
      "t": 2503,
      "e": 2503,
      "ty": 2,
      "x": 337,
      "y": 520
    },
    {
      "t": 2503,
      "e": 2503,
      "ty": 41,
      "x": 26967,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 2602,
      "e": 2602,
      "ty": 2,
      "x": 340,
      "y": 521
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 363,
      "y": 511
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 35173,
      "y": 38070,
      "ta": "#.strategy > p"
    },
    {
      "t": 2802,
      "e": 2802,
      "ty": 2,
      "x": 459,
      "y": 515
    },
    {
      "t": 2902,
      "e": 2902,
      "ty": 2,
      "x": 481,
      "y": 517
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 2,
      "x": 564,
      "y": 519
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 52484,
      "y": 56794,
      "ta": "#.strategy > p"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 582,
      "y": 518
    },
    {
      "t": 3203,
      "e": 3203,
      "ty": 2,
      "x": 501,
      "y": 516
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 44728,
      "y": 49772,
      "ta": "#.strategy > p"
    },
    {
      "t": 3302,
      "e": 3302,
      "ty": 2,
      "x": 494,
      "y": 516
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 2,
      "x": 480,
      "y": 516
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 2,
      "x": 511,
      "y": 514
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 46527,
      "y": 45091,
      "ta": "#.strategy > p"
    },
    {
      "t": 3602,
      "e": 3602,
      "ty": 2,
      "x": 545,
      "y": 516
    },
    {
      "t": 3636,
      "e": 3636,
      "ty": 6,
      "x": 575,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 599,
      "y": 541
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 61477,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 7,
      "x": 661,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3799,
      "e": 3799,
      "ty": 2,
      "x": 717,
      "y": 629
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1064,
      "y": 766
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1310,
      "y": 1012
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 36926,
      "y": 62598,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1326,
      "y": 1044
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1267,
      "y": 1048
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 24688,
      "y": 22937,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1219,
      "y": 1016
    },
    {
      "t": 4399,
      "e": 4399,
      "ty": 2,
      "x": 1194,
      "y": 999
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1191,
      "y": 993
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 28540,
      "y": 61237,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1189,
      "y": 991
    },
    {
      "t": 4699,
      "e": 4699,
      "ty": 2,
      "x": 1185,
      "y": 987
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 27976,
      "y": 60664,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1183,
      "y": 985
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1180,
      "y": 979
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1178,
      "y": 978
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 27624,
      "y": 60163,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1171,
      "y": 973
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1138,
      "y": 970
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 8209,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1118,
      "y": 967
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1125,
      "y": 967
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 24453,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5799,
      "e": 5799,
      "ty": 2,
      "x": 1133,
      "y": 967
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1133,
      "y": 966
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1135,
      "y": 963
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 41,
      "x": 20358,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 6099,
      "e": 6099,
      "ty": 2,
      "x": 1135,
      "y": 961
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1138,
      "y": 958
    },
    {
      "t": 6250,
      "e": 6250,
      "ty": 41,
      "x": 25017,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1145,
      "y": 952
    },
    {
      "t": 6399,
      "e": 6399,
      "ty": 2,
      "x": 1152,
      "y": 948
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1161,
      "y": 941
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 41,
      "x": 26426,
      "y": 57513,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6599,
      "e": 6599,
      "ty": 2,
      "x": 1164,
      "y": 929
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1167,
      "y": 924
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 27060,
      "y": 55937,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1175,
      "y": 912
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1177,
      "y": 909
    },
    {
      "t": 6998,
      "e": 6998,
      "ty": 2,
      "x": 1178,
      "y": 902
    },
    {
      "t": 6999,
      "e": 6999,
      "ty": 41,
      "x": 27624,
      "y": 54719,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8599,
      "e": 8599,
      "ty": 2,
      "x": 1088,
      "y": 876
    },
    {
      "t": 8671,
      "e": 8671,
      "ty": 6,
      "x": 442,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 360,
      "y": 666
    },
    {
      "t": 8704,
      "e": 8704,
      "ty": 7,
      "x": 322,
      "y": 652,
      "ta": "#strategyButton"
    },
    {
      "t": 8749,
      "e": 8749,
      "ty": 41,
      "x": 20448,
      "y": 34955,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8799,
      "e": 8799,
      "ty": 2,
      "x": 263,
      "y": 633
    },
    {
      "t": 8835,
      "e": 8835,
      "ty": 6,
      "x": 247,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8899,
      "e": 8899,
      "ty": 2,
      "x": 265,
      "y": 556
    },
    {
      "t": 8999,
      "e": 8999,
      "ty": 2,
      "x": 310,
      "y": 548
    },
    {
      "t": 8999,
      "e": 8999,
      "ty": 41,
      "x": 23932,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9099,
      "e": 9099,
      "ty": 2,
      "x": 311,
      "y": 548
    },
    {
      "t": 9134,
      "e": 9134,
      "ty": 3,
      "x": 311,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9136,
      "e": 9136,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9220,
      "e": 9220,
      "ty": 4,
      "x": 24045,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9220,
      "e": 9220,
      "ty": 5,
      "x": 311,
      "y": 548,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9249,
      "e": 9249,
      "ty": 41,
      "x": 24045,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9999,
      "e": 9999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11297,
      "e": 11297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11377,
      "e": 11377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 11378,
      "e": 11378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11464,
      "e": 11464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 11472,
      "e": 11472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 11520,
      "e": 11520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11520,
      "e": 11520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11602,
      "e": 11602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11602,
      "e": 11602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11648,
      "e": 11648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 11736,
      "e": 11736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 12057,
      "e": 12057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12058,
      "e": 12058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12184,
      "e": 12184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 12208,
      "e": 12208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 12208,
      "e": 12208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12320,
      "e": 12320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12320,
      "e": 12320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12344,
      "e": 12344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12416,
      "e": 12416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12504,
      "e": 12504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13041,
      "e": 13041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13042,
      "e": 13042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13185,
      "e": 13185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13185,
      "e": 13185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13201,
      "e": 13201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 13360,
      "e": 13360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13384,
      "e": 13384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13385,
      "e": 13385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13513,
      "e": 13513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14729,
      "e": 14729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 14730,
      "e": 14730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14849,
      "e": 14849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 14849,
      "e": 14849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14897,
      "e": 14897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 14929,
      "e": 14929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14929,
      "e": 14929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14977,
      "e": 14977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15048,
      "e": 15048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15089,
      "e": 15089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15090,
      "e": 15090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15192,
      "e": 15192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 15377,
      "e": 15377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 15377,
      "e": 15377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15512,
      "e": 15512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 15825,
      "e": 15825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15896,
      "e": 15896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p"
    },
    {
      "t": 16001,
      "e": 16001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p"
    },
    {
      "t": 16297,
      "e": 16297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 16299,
      "e": 16299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16401,
      "e": 16401,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p."
    },
    {
      "t": 16432,
      "e": 16432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 16497,
      "e": 16497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16498,
      "e": 16498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16592,
      "e": 16592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 16593,
      "e": 16593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16640,
      "e": 16640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m."
    },
    {
      "t": 16696,
      "e": 16696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16776,
      "e": 16776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16776,
      "e": 16776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16888,
      "e": 16888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17009,
      "e": 17009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17010,
      "e": 17010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17145,
      "e": 17145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17192,
      "e": 17192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17193,
      "e": 17193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17296,
      "e": 17296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17489,
      "e": 17489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17490,
      "e": 17490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17600,
      "e": 17600,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on "
    },
    {
      "t": 17608,
      "e": 17608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17640,
      "e": 17640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17641,
      "e": 17641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17720,
      "e": 17720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17736,
      "e": 17736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17784,
      "e": 17784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17816,
      "e": 17816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17816,
      "e": 17816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17904,
      "e": 17904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17912,
      "e": 17912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17912,
      "e": 17912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18033,
      "e": 18033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18185,
      "e": 18185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18185,
      "e": 18185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18289,
      "e": 18289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18465,
      "e": 18465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18466,
      "e": 18466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18560,
      "e": 18560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18697,
      "e": 18697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18697,
      "e": 18697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18802,
      "e": 18802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-a"
    },
    {
      "t": 18809,
      "e": 18809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19233,
      "e": 19233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19234,
      "e": 19234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19328,
      "e": 19328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19336,
      "e": 19336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19336,
      "e": 19336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19449,
      "e": 19449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19481,
      "e": 19481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19481,
      "e": 19481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19584,
      "e": 19584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19697,
      "e": 19697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 19698,
      "e": 19698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19792,
      "e": 19792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 19889,
      "e": 19889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19889,
      "e": 19889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19999,
      "e": 19999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20417,
      "e": 20417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20417,
      "e": 20417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20520,
      "e": 20520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20520,
      "e": 20520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20528,
      "e": 20528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 20616,
      "e": 20616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20616,
      "e": 20616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20624,
      "e": 20624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20680,
      "e": 20680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20681,
      "e": 20681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20696,
      "e": 20696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20800,
      "e": 20800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20913,
      "e": 20913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20913,
      "e": 20913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20953,
      "e": 20953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 20985,
      "e": 20985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21048,
      "e": 21048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21048,
      "e": 21048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21128,
      "e": 21128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21135,
      "e": 21135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21136,
      "e": 21136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21216,
      "e": 21216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21216,
      "e": 21216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21223,
      "e": 21223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 21312,
      "e": 21312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29999,
      "e": 26312,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 35952,
      "e": 26312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 35952,
      "e": 26312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36031,
      "e": 26391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36032,
      "e": 26392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36080,
      "e": 26440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 36103,
      "e": 26463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36375,
      "e": 26735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36376,
      "e": 26736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36415,
      "e": 26775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36520,
      "e": 26880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36520,
      "e": 26880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36560,
      "e": 26920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36913,
      "e": 27273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36913,
      "e": 27273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37040,
      "e": 27400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37144,
      "e": 27504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 37145,
      "e": 27505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37264,
      "e": 27624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 37280,
      "e": 27640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37281,
      "e": 27641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37392,
      "e": 27752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37489,
      "e": 27849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37489,
      "e": 27849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37584,
      "e": 27944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37599,
      "e": 27959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37600,
      "e": 27960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37712,
      "e": 28072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37712,
      "e": 28072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37719,
      "e": 28079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 37792,
      "e": 28152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37807,
      "e": 28167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37807,
      "e": 28167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37912,
      "e": 28272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38921,
      "e": 29281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38921,
      "e": 29281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39008,
      "e": 29368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39008,
      "e": 29368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39055,
      "e": 29415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ri"
    },
    {
      "t": 39120,
      "e": 29480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39129,
      "e": 29489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 39129,
      "e": 29489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39208,
      "e": 29568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 39231,
      "e": 29591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39231,
      "e": 29591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39303,
      "e": 29663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39304,
      "e": 29664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39352,
      "e": 29712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 39359,
      "e": 29719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39360,
      "e": 29720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39416,
      "e": 29776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39497,
      "e": 29857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39600,
      "e": 29960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39601,
      "e": 29961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39704,
      "e": 30064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39704,
      "e": 30064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39719,
      "e": 30079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 39792,
      "e": 30152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39792,
      "e": 30152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39801,
      "e": 30161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39903,
      "e": 30263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40104,
      "e": 30464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 40105,
      "e": 30465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40192,
      "e": 30552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 40480,
      "e": 30840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40481,
      "e": 30841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40599,
      "e": 30959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40737,
      "e": 31097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40737,
      "e": 31097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40841,
      "e": 31201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40864,
      "e": 31224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40864,
      "e": 31224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40976,
      "e": 31336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40983,
      "e": 31343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40984,
      "e": 31344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41081,
      "e": 31441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41128,
      "e": 31488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41129,
      "e": 31489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41232,
      "e": 31592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41592,
      "e": 31952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41593,
      "e": 31953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41735,
      "e": 32095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41809,
      "e": 32169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41809,
      "e": 32169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41928,
      "e": 32288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41952,
      "e": 32312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41952,
      "e": 32312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42088,
      "e": 32448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42496,
      "e": 32856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42497,
      "e": 32857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42601,
      "e": 32961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line"
    },
    {
      "t": 42624,
      "e": 32984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42688,
      "e": 33048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42689,
      "e": 33049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42801,
      "e": 33161,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line "
    },
    {
      "t": 42824,
      "e": 33184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43320,
      "e": 33680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 43321,
      "e": 33681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43399,
      "e": 33759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 43552,
      "e": 33912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43553,
      "e": 33913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43647,
      "e": 34007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 47669,
      "e": 38029,
      "ty": 7,
      "x": 443,
      "y": 622,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47699,
      "e": 38059,
      "ty": 2,
      "x": 558,
      "y": 681
    },
    {
      "t": 47749,
      "e": 38109,
      "ty": 41,
      "x": 2890,
      "y": 45623,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 47799,
      "e": 38159,
      "ty": 2,
      "x": 905,
      "y": 812
    },
    {
      "t": 47899,
      "e": 38259,
      "ty": 2,
      "x": 934,
      "y": 803
    },
    {
      "t": 47999,
      "e": 38359,
      "ty": 2,
      "x": 1114,
      "y": 807
    },
    {
      "t": 47999,
      "e": 38359,
      "ty": 41,
      "x": 23114,
      "y": 47915,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48099,
      "e": 38459,
      "ty": 2,
      "x": 1244,
      "y": 831
    },
    {
      "t": 48199,
      "e": 38559,
      "ty": 2,
      "x": 1215,
      "y": 888
    },
    {
      "t": 48250,
      "e": 38610,
      "ty": 41,
      "x": 27131,
      "y": 55651,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48299,
      "e": 38659,
      "ty": 2,
      "x": 1167,
      "y": 918
    },
    {
      "t": 48399,
      "e": 38759,
      "ty": 2,
      "x": 1163,
      "y": 916
    },
    {
      "t": 48499,
      "e": 38859,
      "ty": 2,
      "x": 1167,
      "y": 906
    },
    {
      "t": 48500,
      "e": 38860,
      "ty": 41,
      "x": 26849,
      "y": 55006,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48599,
      "e": 38959,
      "ty": 2,
      "x": 1169,
      "y": 906
    },
    {
      "t": 48700,
      "e": 39060,
      "ty": 2,
      "x": 1172,
      "y": 904
    },
    {
      "t": 48751,
      "e": 39062,
      "ty": 41,
      "x": 27272,
      "y": 54791,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48799,
      "e": 39110,
      "ty": 2,
      "x": 1173,
      "y": 903
    },
    {
      "t": 49833,
      "e": 40144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49911,
      "e": 40222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line u"
    },
    {
      "t": 50032,
      "e": 40343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50096,
      "e": 40407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line "
    },
    {
      "t": 50203,
      "e": 40514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line "
    },
    {
      "t": 50248,
      "e": 40559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50352,
      "e": 40663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line"
    },
    {
      "t": 51567,
      "e": 41878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51567,
      "e": 41878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51687,
      "e": 41998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52297,
      "e": 42608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 52297,
      "e": 42608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52400,
      "e": 42711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 52552,
      "e": 42863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52553,
      "e": 42864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52672,
      "e": 42983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53176,
      "e": 43487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53223,
      "e": 43534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line u"
    },
    {
      "t": 53303,
      "e": 43614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53384,
      "e": 43695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line "
    },
    {
      "t": 53568,
      "e": 43879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 53569,
      "e": 43880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53648,
      "e": 43959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 53768,
      "e": 44079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53768,
      "e": 44079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53871,
      "e": 44182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53936,
      "e": 44247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53936,
      "e": 44247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53991,
      "e": 44302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53992,
      "e": 44303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54023,
      "e": 44334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 54080,
      "e": 44391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 54080,
      "e": 44391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54128,
      "e": 44439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 54151,
      "e": 44462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54153,
      "e": 44464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54191,
      "e": 44502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54271,
      "e": 44582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54544,
      "e": 44855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54607,
      "e": 44918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line untio"
    },
    {
      "t": 54687,
      "e": 44998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54759,
      "e": 45070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line unti"
    },
    {
      "t": 55080,
      "e": 45391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55081,
      "e": 45392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55191,
      "e": 45502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 55239,
      "e": 45550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55240,
      "e": 45551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55328,
      "e": 45639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55424,
      "e": 45735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 55426,
      "e": 45737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55519,
      "e": 45830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 55528,
      "e": 45839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55528,
      "e": 45839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55632,
      "e": 45839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 55634,
      "e": 45841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55695,
      "e": 45902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 55703,
      "e": 45910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55703,
      "e": 45910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55743,
      "e": 45950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55816,
      "e": 46023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55831,
      "e": 46038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55832,
      "e": 46039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55960,
      "e": 46167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55961,
      "e": 46168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55983,
      "e": 46190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 56031,
      "e": 46238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56151,
      "e": 46358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56152,
      "e": 46359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56223,
      "e": 46430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 57112,
      "e": 47319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57113,
      "e": 47320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57239,
      "e": 47446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59296,
      "e": 49503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59296,
      "e": 49503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59402,
      "e": 49609,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a"
    },
    {
      "t": 59424,
      "e": 49631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59424,
      "e": 49631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59425,
      "e": 49632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59535,
      "e": 49742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59559,
      "e": 49766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 59559,
      "e": 49766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59664,
      "e": 49871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 59672,
      "e": 49879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59673,
      "e": 49880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59751,
      "e": 49958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 59865,
      "e": 50072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59865,
      "e": 50072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59927,
      "e": 50134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60015,
      "e": 50222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60015,
      "e": 50222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60112,
      "e": 50319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60144,
      "e": 50351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60145,
      "e": 50352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60247,
      "e": 50454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60247,
      "e": 50454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60303,
      "e": 50510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 60344,
      "e": 50551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60504,
      "e": 50711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60624,
      "e": 50831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 60624,
      "e": 50831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60679,
      "e": 50886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 60792,
      "e": 50999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 60792,
      "e": 50999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60839,
      "e": 51046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 60871,
      "e": 51078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61272,
      "e": 51479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 61367,
      "e": 51574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61688,
      "e": 51895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 61688,
      "e": 51895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61783,
      "e": 51990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 61783,
      "e": 51990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61815,
      "e": 52022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(sh)"
    },
    {
      "t": 61847,
      "e": 52054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61847,
      "e": 52054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61903,
      "e": 52110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shi)"
    },
    {
      "t": 61936,
      "e": 52143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 61936,
      "e": 52143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61959,
      "e": 52166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shif)"
    },
    {
      "t": 62031,
      "e": 52238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62368,
      "e": 52575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62369,
      "e": 52576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62447,
      "e": 52654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shift)"
    },
    {
      "t": 62576,
      "e": 52655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 62687,
      "e": 52766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64278,
      "e": 54357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 64278,
      "e": 54357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64399,
      "e": 54478,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shift)."
    },
    {
      "t": 64406,
      "e": 54485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 65597,
      "e": 55676,
      "ty": 2,
      "x": 1021,
      "y": 942
    },
    {
      "t": 65698,
      "e": 55777,
      "ty": 2,
      "x": 897,
      "y": 922
    },
    {
      "t": 65748,
      "e": 55827,
      "ty": 41,
      "x": 7823,
      "y": 56080,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 65798,
      "e": 55877,
      "ty": 2,
      "x": 912,
      "y": 915
    },
    {
      "t": 65898,
      "e": 55977,
      "ty": 2,
      "x": 1495,
      "y": 891
    },
    {
      "t": 65997,
      "e": 56076,
      "ty": 2,
      "x": 1400,
      "y": 955
    },
    {
      "t": 65998,
      "e": 56077,
      "ty": 41,
      "x": 43268,
      "y": 58515,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66098,
      "e": 56177,
      "ty": 2,
      "x": 1288,
      "y": 947
    },
    {
      "t": 66198,
      "e": 56277,
      "ty": 2,
      "x": 1207,
      "y": 923
    },
    {
      "t": 66248,
      "e": 56327,
      "ty": 41,
      "x": 29527,
      "y": 55937,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66297,
      "e": 56376,
      "ty": 2,
      "x": 1202,
      "y": 908
    },
    {
      "t": 66397,
      "e": 56476,
      "ty": 2,
      "x": 1200,
      "y": 904
    },
    {
      "t": 66497,
      "e": 56576,
      "ty": 2,
      "x": 1191,
      "y": 897
    },
    {
      "t": 66497,
      "e": 56576,
      "ty": 41,
      "x": 60159,
      "y": 36408,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 66597,
      "e": 56676,
      "ty": 2,
      "x": 1189,
      "y": 890
    },
    {
      "t": 66698,
      "e": 56777,
      "ty": 2,
      "x": 1197,
      "y": 832
    },
    {
      "t": 66748,
      "e": 56827,
      "ty": 41,
      "x": 29597,
      "y": 47271,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66797,
      "e": 56876,
      "ty": 2,
      "x": 1212,
      "y": 782
    },
    {
      "t": 66898,
      "e": 56977,
      "ty": 2,
      "x": 1239,
      "y": 723
    },
    {
      "t": 66998,
      "e": 57077,
      "ty": 2,
      "x": 1271,
      "y": 664
    },
    {
      "t": 66998,
      "e": 57077,
      "ty": 41,
      "x": 34177,
      "y": 37673,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67098,
      "e": 57177,
      "ty": 2,
      "x": 1273,
      "y": 661
    },
    {
      "t": 67248,
      "e": 57327,
      "ty": 41,
      "x": 32134,
      "y": 38389,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67298,
      "e": 57377,
      "ty": 2,
      "x": 962,
      "y": 679
    },
    {
      "t": 67367,
      "e": 57446,
      "ty": 6,
      "x": 430,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67398,
      "e": 57477,
      "ty": 2,
      "x": 337,
      "y": 570
    },
    {
      "t": 67433,
      "e": 57512,
      "ty": 7,
      "x": 197,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67497,
      "e": 57576,
      "ty": 2,
      "x": 191,
      "y": 510
    },
    {
      "t": 67497,
      "e": 57576,
      "ty": 41,
      "x": 10555,
      "y": 35729,
      "ta": "#.strategy > p"
    },
    {
      "t": 67597,
      "e": 57676,
      "ty": 2,
      "x": 205,
      "y": 500
    },
    {
      "t": 67697,
      "e": 57776,
      "ty": 2,
      "x": 227,
      "y": 496
    },
    {
      "t": 67748,
      "e": 57827,
      "ty": 41,
      "x": 16850,
      "y": 7643,
      "ta": "#.strategy > p"
    },
    {
      "t": 67798,
      "e": 57877,
      "ty": 2,
      "x": 256,
      "y": 501
    },
    {
      "t": 67898,
      "e": 57977,
      "ty": 2,
      "x": 278,
      "y": 508
    },
    {
      "t": 67916,
      "e": 57995,
      "ty": 6,
      "x": 304,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67998,
      "e": 58077,
      "ty": 2,
      "x": 325,
      "y": 538
    },
    {
      "t": 67998,
      "e": 58077,
      "ty": 41,
      "x": 25618,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69053,
      "e": 59132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69055,
      "e": 59134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69181,
      "e": 59260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69285,
      "e": 59364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 69325,
      "e": 59404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69326,
      "e": 59405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69412,
      "e": 59491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 69444,
      "e": 59523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69461,
      "e": 59540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69461,
      "e": 59540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69573,
      "e": 59652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69574,
      "e": 59653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69613,
      "e": 59692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 69653,
      "e": 59732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69653,
      "e": 59732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69660,
      "e": 59739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 69741,
      "e": 59820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69741,
      "e": 59820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69757,
      "e": 59836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69805,
      "e": 59884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69806,
      "e": 59885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69861,
      "e": 59940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 69862,
      "e": 59941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69869,
      "e": 59948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 69948,
      "e": 60027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69981,
      "e": 60060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69996,
      "e": 60075,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70005,
      "e": 60084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70007,
      "e": 60086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70109,
      "e": 60188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70326,
      "e": 60405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 70326,
      "e": 60405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70428,
      "e": 60507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70428,
      "e": 60507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70461,
      "e": 60540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 70533,
      "e": 60612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 70534,
      "e": 60613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70549,
      "e": 60628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 70645,
      "e": 60724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70646,
      "e": 60725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70685,
      "e": 60764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 70756,
      "e": 60835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 70757,
      "e": 60836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70780,
      "e": 60859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 70869,
      "e": 60948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70950,
      "e": 61029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70950,
      "e": 61029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71094,
      "e": 61173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71229,
      "e": 61308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71230,
      "e": 61309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71341,
      "e": 61420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71341,
      "e": 61420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71348,
      "e": 61427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 71437,
      "e": 61516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71614,
      "e": 61693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 71614,
      "e": 61693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71708,
      "e": 61787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'"
    },
    {
      "t": 71765,
      "e": 61844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 71765,
      "e": 61844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71861,
      "e": 61940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 71894,
      "e": 61973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71894,
      "e": 61973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71998,
      "e": 62077,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shift). In this case, it'd "
    },
    {
      "t": 72012,
      "e": 62091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72053,
      "e": 62132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 72053,
      "e": 62132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72133,
      "e": 62212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 72278,
      "e": 62357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72278,
      "e": 62357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72380,
      "e": 62459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 72389,
      "e": 62468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72389,
      "e": 62468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72501,
      "e": 62580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72669,
      "e": 62748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 72781,
      "e": 62860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 72781,
      "e": 62860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72877,
      "e": 62956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 72893,
      "e": 62972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72957,
      "e": 63036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72958,
      "e": 63037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73085,
      "e": 63164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73085,
      "e": 63164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73085,
      "e": 63164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73198,
      "e": 63277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 73221,
      "e": 63300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73222,
      "e": 63301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73317,
      "e": 63396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 73317,
      "e": 63396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73341,
      "e": 63420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 73397,
      "e": 63476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73397,
      "e": 63476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73445,
      "e": 63524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73501,
      "e": 63580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73542,
      "e": 63621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 73621,
      "e": 63700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 73622,
      "e": 63701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73694,
      "e": 63773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 73717,
      "e": 63796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73933,
      "e": 64012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 73934,
      "e": 64013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74021,
      "e": 64100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 74789,
      "e": 64868,
      "ty": 7,
      "x": 279,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74797,
      "e": 64876,
      "ty": 2,
      "x": 279,
      "y": 611
    },
    {
      "t": 74897,
      "e": 64976,
      "ty": 2,
      "x": 181,
      "y": 704
    },
    {
      "t": 74997,
      "e": 65076,
      "ty": 2,
      "x": 200,
      "y": 692
    },
    {
      "t": 74997,
      "e": 65076,
      "ty": 41,
      "x": 11567,
      "y": 37891,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 75097,
      "e": 65176,
      "ty": 2,
      "x": 360,
      "y": 705
    },
    {
      "t": 75197,
      "e": 65276,
      "ty": 2,
      "x": 385,
      "y": 702
    },
    {
      "t": 75247,
      "e": 65326,
      "ty": 41,
      "x": 32021,
      "y": 49980,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 75290,
      "e": 65369,
      "ty": 6,
      "x": 389,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 75297,
      "e": 65376,
      "ty": 2,
      "x": 389,
      "y": 688
    },
    {
      "t": 75397,
      "e": 65476,
      "ty": 2,
      "x": 403,
      "y": 663
    },
    {
      "t": 75433,
      "e": 65512,
      "ty": 3,
      "x": 403,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 75434,
      "e": 65513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shift). In this case, it'd be M and L."
    },
    {
      "t": 75434,
      "e": 65513,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75434,
      "e": 65513,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 75497,
      "e": 65576,
      "ty": 41,
      "x": 35173,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 75514,
      "e": 65593,
      "ty": 4,
      "x": 35173,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 75528,
      "e": 65607,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 75530,
      "e": 65609,
      "ty": 5,
      "x": 403,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 75535,
      "e": 65614,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 75897,
      "e": 65976,
      "ty": 2,
      "x": 414,
      "y": 558
    },
    {
      "t": 75997,
      "e": 66076,
      "ty": 2,
      "x": 417,
      "y": 545
    },
    {
      "t": 75997,
      "e": 66076,
      "ty": 41,
      "x": 14085,
      "y": 29748,
      "ta": "html > body"
    },
    {
      "t": 76538,
      "e": 66617,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 77096,
      "e": 67175,
      "ty": 2,
      "x": 444,
      "y": 552
    },
    {
      "t": 77197,
      "e": 67276,
      "ty": 2,
      "x": 576,
      "y": 567
    },
    {
      "t": 77247,
      "e": 67326,
      "ty": 41,
      "x": 23245,
      "y": 31410,
      "ta": "html > body"
    },
    {
      "t": 77297,
      "e": 67376,
      "ty": 2,
      "x": 787,
      "y": 576
    },
    {
      "t": 77397,
      "e": 67476,
      "ty": 2,
      "x": 815,
      "y": 576
    },
    {
      "t": 77457,
      "e": 67536,
      "ty": 6,
      "x": 829,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77497,
      "e": 67576,
      "ty": 2,
      "x": 835,
      "y": 565
    },
    {
      "t": 77498,
      "e": 67577,
      "ty": 41,
      "x": 5839,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77597,
      "e": 67676,
      "ty": 2,
      "x": 840,
      "y": 563
    },
    {
      "t": 77618,
      "e": 67697,
      "ty": 3,
      "x": 840,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77618,
      "e": 67697,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77713,
      "e": 67792,
      "ty": 4,
      "x": 6921,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77713,
      "e": 67792,
      "ty": 5,
      "x": 840,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77747,
      "e": 67826,
      "ty": 41,
      "x": 6921,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78606,
      "e": 68685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 78606,
      "e": 68685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78700,
      "e": 68779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 78709,
      "e": 68788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 78709,
      "e": 68788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78789,
      "e": 68868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 79143,
      "e": 69222,
      "ty": 7,
      "x": 870,
      "y": 544,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79197,
      "e": 69276,
      "ty": 2,
      "x": 904,
      "y": 530
    },
    {
      "t": 79248,
      "e": 69327,
      "ty": 41,
      "x": 16870,
      "y": 11979,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 79292,
      "e": 69371,
      "ty": 6,
      "x": 897,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79297,
      "e": 69376,
      "ty": 2,
      "x": 897,
      "y": 651
    },
    {
      "t": 79397,
      "e": 69476,
      "ty": 2,
      "x": 898,
      "y": 662
    },
    {
      "t": 79498,
      "e": 69577,
      "ty": 2,
      "x": 899,
      "y": 663
    },
    {
      "t": 79498,
      "e": 69577,
      "ty": 41,
      "x": 19682,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79597,
      "e": 69676,
      "ty": 2,
      "x": 892,
      "y": 656
    },
    {
      "t": 79681,
      "e": 69760,
      "ty": 3,
      "x": 892,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79683,
      "e": 69762,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 79683,
      "e": 69762,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79684,
      "e": 69763,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79748,
      "e": 69827,
      "ty": 41,
      "x": 18168,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79794,
      "e": 69873,
      "ty": 4,
      "x": 18168,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79794,
      "e": 69873,
      "ty": 5,
      "x": 892,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80038,
      "e": 70117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80181,
      "e": 70260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 80182,
      "e": 70261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80301,
      "e": 70380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 80325,
      "e": 70404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 80365,
      "e": 70444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 80366,
      "e": 70445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80478,
      "e": 70557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Th"
    },
    {
      "t": 80494,
      "e": 70573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 80494,
      "e": 70573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80565,
      "e": 70644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 80568,
      "e": 70647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80597,
      "e": 70676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Thai"
    },
    {
      "t": 80636,
      "e": 70715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 80692,
      "e": 70771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 80692,
      "e": 70771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80764,
      "e": 70843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 80765,
      "e": 70844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80789,
      "e": 70868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||la"
    },
    {
      "t": 80861,
      "e": 70940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 80878,
      "e": 70957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 80878,
      "e": 70957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80932,
      "e": 71011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 81005,
      "e": 71084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 81005,
      "e": 71084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81069,
      "e": 71148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 81199,
      "e": 71278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Thailand"
    },
    {
      "t": 81597,
      "e": 71676,
      "ty": 2,
      "x": 889,
      "y": 656
    },
    {
      "t": 81645,
      "e": 71724,
      "ty": 7,
      "x": 886,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81697,
      "e": 71776,
      "ty": 2,
      "x": 885,
      "y": 672
    },
    {
      "t": 81748,
      "e": 71827,
      "ty": 41,
      "x": 30201,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 81778,
      "e": 71857,
      "ty": 6,
      "x": 908,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 81797,
      "e": 71876,
      "ty": 2,
      "x": 927,
      "y": 693
    },
    {
      "t": 81897,
      "e": 71976,
      "ty": 2,
      "x": 954,
      "y": 696
    },
    {
      "t": 81993,
      "e": 72072,
      "ty": 3,
      "x": 955,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 81995,
      "e": 72074,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Thailand"
    },
    {
      "t": 81995,
      "e": 72074,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81996,
      "e": 72075,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 81998,
      "e": 72077,
      "ty": 2,
      "x": 955,
      "y": 694
    },
    {
      "t": 81998,
      "e": 72077,
      "ty": 41,
      "x": 30448,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82089,
      "e": 72168,
      "ty": 4,
      "x": 30448,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82089,
      "e": 72168,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82089,
      "e": 72168,
      "ty": 5,
      "x": 955,
      "y": 694,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82089,
      "e": 72168,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 82297,
      "e": 72376,
      "ty": 2,
      "x": 947,
      "y": 701
    },
    {
      "t": 82397,
      "e": 72476,
      "ty": 2,
      "x": 674,
      "y": 875
    },
    {
      "t": 82497,
      "e": 72576,
      "ty": 2,
      "x": 667,
      "y": 878
    },
    {
      "t": 82497,
      "e": 72576,
      "ty": 41,
      "x": 22694,
      "y": 48195,
      "ta": "html > body"
    },
    {
      "t": 82597,
      "e": 72676,
      "ty": 2,
      "x": 667,
      "y": 883
    },
    {
      "t": 82747,
      "e": 72826,
      "ty": 41,
      "x": 22694,
      "y": 48472,
      "ta": "html > body"
    },
    {
      "t": 83110,
      "e": 73189,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 83398,
      "e": 73477,
      "ty": 2,
      "x": 668,
      "y": 883
    },
    {
      "t": 83497,
      "e": 73576,
      "ty": 2,
      "x": 675,
      "y": 868
    },
    {
      "t": 83497,
      "e": 73576,
      "ty": 41,
      "x": 22969,
      "y": 47641,
      "ta": "html > body"
    },
    {
      "t": 83598,
      "e": 73677,
      "ty": 2,
      "x": 792,
      "y": 566
    },
    {
      "t": 83696,
      "e": 73775,
      "ty": 2,
      "x": 892,
      "y": 241
    },
    {
      "t": 83747,
      "e": 73826,
      "ty": 41,
      "x": 31303,
      "y": 7090,
      "ta": "html > body"
    },
    {
      "t": 83797,
      "e": 73876,
      "ty": 2,
      "x": 921,
      "y": 113
    },
    {
      "t": 83998,
      "e": 74077,
      "ty": 2,
      "x": 918,
      "y": 135
    },
    {
      "t": 83998,
      "e": 74077,
      "ty": 41,
      "x": 31338,
      "y": 7035,
      "ta": "html > body"
    },
    {
      "t": 84097,
      "e": 74176,
      "ty": 2,
      "x": 949,
      "y": 181
    },
    {
      "t": 84197,
      "e": 74276,
      "ty": 2,
      "x": 940,
      "y": 189
    },
    {
      "t": 84248,
      "e": 74327,
      "ty": 41,
      "x": 27904,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 84298,
      "e": 74377,
      "ty": 2,
      "x": 938,
      "y": 190
    },
    {
      "t": 84498,
      "e": 74577,
      "ty": 2,
      "x": 927,
      "y": 204
    },
    {
      "t": 84498,
      "e": 74577,
      "ty": 41,
      "x": 25056,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 84597,
      "e": 74676,
      "ty": 2,
      "x": 904,
      "y": 227
    },
    {
      "t": 84697,
      "e": 74776,
      "ty": 2,
      "x": 893,
      "y": 232
    },
    {
      "t": 84747,
      "e": 74826,
      "ty": 41,
      "x": 56156,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 84798,
      "e": 74877,
      "ty": 2,
      "x": 883,
      "y": 232
    },
    {
      "t": 84897,
      "e": 74976,
      "ty": 2,
      "x": 882,
      "y": 232
    },
    {
      "t": 84961,
      "e": 75040,
      "ty": 3,
      "x": 882,
      "y": 232,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 84998,
      "e": 75077,
      "ty": 41,
      "x": 49605,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85041,
      "e": 75120,
      "ty": 4,
      "x": 49605,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85041,
      "e": 75120,
      "ty": 5,
      "x": 882,
      "y": 232,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85044,
      "e": 75123,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 85047,
      "e": 75126,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 85398,
      "e": 75477,
      "ty": 2,
      "x": 842,
      "y": 264
    },
    {
      "t": 85497,
      "e": 75576,
      "ty": 2,
      "x": 803,
      "y": 323
    },
    {
      "t": 85497,
      "e": 75576,
      "ty": 41,
      "x": 27377,
      "y": 17450,
      "ta": "html > body"
    },
    {
      "t": 85598,
      "e": 75677,
      "ty": 2,
      "x": 798,
      "y": 336
    },
    {
      "t": 85697,
      "e": 75776,
      "ty": 2,
      "x": 797,
      "y": 337
    },
    {
      "t": 85748,
      "e": 75827,
      "ty": 41,
      "x": 27343,
      "y": 17782,
      "ta": "html > body"
    },
    {
      "t": 85798,
      "e": 75877,
      "ty": 2,
      "x": 810,
      "y": 322
    },
    {
      "t": 85898,
      "e": 75977,
      "ty": 2,
      "x": 840,
      "y": 303
    },
    {
      "t": 85997,
      "e": 76076,
      "ty": 2,
      "x": 853,
      "y": 305
    },
    {
      "t": 85998,
      "e": 76077,
      "ty": 41,
      "x": 7494,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 86097,
      "e": 76176,
      "ty": 2,
      "x": 870,
      "y": 308
    },
    {
      "t": 86198,
      "e": 76277,
      "ty": 2,
      "x": 864,
      "y": 326
    },
    {
      "t": 86247,
      "e": 76326,
      "ty": 41,
      "x": 39289,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86297,
      "e": 76376,
      "ty": 2,
      "x": 861,
      "y": 330
    },
    {
      "t": 86398,
      "e": 76477,
      "ty": 2,
      "x": 861,
      "y": 324
    },
    {
      "t": 86425,
      "e": 76504,
      "ty": 3,
      "x": 861,
      "y": 324,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86427,
      "e": 76506,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 86497,
      "e": 76576,
      "ty": 41,
      "x": 39289,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86528,
      "e": 76607,
      "ty": 4,
      "x": 39289,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86528,
      "e": 76607,
      "ty": 5,
      "x": 861,
      "y": 324,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 86529,
      "e": 76608,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 86530,
      "e": 76609,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 86697,
      "e": 76776,
      "ty": 2,
      "x": 858,
      "y": 327
    },
    {
      "t": 86748,
      "e": 76827,
      "ty": 41,
      "x": 5595,
      "y": 14123,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86797,
      "e": 76876,
      "ty": 2,
      "x": 813,
      "y": 393
    },
    {
      "t": 86897,
      "e": 76976,
      "ty": 2,
      "x": 764,
      "y": 451
    },
    {
      "t": 86998,
      "e": 77077,
      "ty": 2,
      "x": 759,
      "y": 455
    },
    {
      "t": 86998,
      "e": 77077,
      "ty": 41,
      "x": 25862,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 87247,
      "e": 77326,
      "ty": 41,
      "x": 25931,
      "y": 24651,
      "ta": "html > body"
    },
    {
      "t": 87298,
      "e": 77377,
      "ty": 2,
      "x": 772,
      "y": 441
    },
    {
      "t": 87397,
      "e": 77476,
      "ty": 2,
      "x": 842,
      "y": 380
    },
    {
      "t": 87497,
      "e": 77576,
      "ty": 2,
      "x": 889,
      "y": 369
    },
    {
      "t": 87497,
      "e": 77576,
      "ty": 41,
      "x": 16037,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 87597,
      "e": 77676,
      "ty": 2,
      "x": 904,
      "y": 371
    },
    {
      "t": 87697,
      "e": 77776,
      "ty": 2,
      "x": 912,
      "y": 375
    },
    {
      "t": 87748,
      "e": 77827,
      "ty": 41,
      "x": 22445,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 87797,
      "e": 77876,
      "ty": 2,
      "x": 920,
      "y": 375
    },
    {
      "t": 87897,
      "e": 77976,
      "ty": 2,
      "x": 923,
      "y": 382
    },
    {
      "t": 87998,
      "e": 78077,
      "ty": 2,
      "x": 892,
      "y": 410
    },
    {
      "t": 87998,
      "e": 78077,
      "ty": 41,
      "x": 16749,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 88097,
      "e": 78176,
      "ty": 2,
      "x": 883,
      "y": 434
    },
    {
      "t": 88197,
      "e": 78276,
      "ty": 2,
      "x": 872,
      "y": 461
    },
    {
      "t": 88248,
      "e": 78327,
      "ty": 41,
      "x": 52404,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 88298,
      "e": 78377,
      "ty": 2,
      "x": 871,
      "y": 478
    },
    {
      "t": 88398,
      "e": 78477,
      "ty": 2,
      "x": 868,
      "y": 498
    },
    {
      "t": 88497,
      "e": 78576,
      "ty": 2,
      "x": 868,
      "y": 500
    },
    {
      "t": 88497,
      "e": 78576,
      "ty": 41,
      "x": 41806,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 88745,
      "e": 78824,
      "ty": 3,
      "x": 868,
      "y": 500,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 88747,
      "e": 78826,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 88808,
      "e": 78887,
      "ty": 4,
      "x": 41806,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 88808,
      "e": 78887,
      "ty": 5,
      "x": 868,
      "y": 500,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 88809,
      "e": 78888,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 88809,
      "e": 78888,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 88897,
      "e": 78976,
      "ty": 2,
      "x": 864,
      "y": 501
    },
    {
      "t": 88997,
      "e": 79076,
      "ty": 2,
      "x": 782,
      "y": 542
    },
    {
      "t": 88998,
      "e": 79077,
      "ty": 41,
      "x": 26654,
      "y": 29582,
      "ta": "html > body"
    },
    {
      "t": 89097,
      "e": 79176,
      "ty": 2,
      "x": 747,
      "y": 570
    },
    {
      "t": 89169,
      "e": 79248,
      "ty": 3,
      "x": 746,
      "y": 570,
      "ta": "html > body"
    },
    {
      "t": 89169,
      "e": 79248,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 89198,
      "e": 79277,
      "ty": 2,
      "x": 746,
      "y": 570
    },
    {
      "t": 89241,
      "e": 79320,
      "ty": 4,
      "x": 25415,
      "y": 31133,
      "ta": "html > body"
    },
    {
      "t": 89241,
      "e": 79320,
      "ty": 5,
      "x": 746,
      "y": 570,
      "ta": "html > body"
    },
    {
      "t": 89247,
      "e": 79326,
      "ty": 41,
      "x": 25415,
      "y": 31133,
      "ta": "html > body"
    },
    {
      "t": 89397,
      "e": 79476,
      "ty": 2,
      "x": 746,
      "y": 572
    },
    {
      "t": 89497,
      "e": 79576,
      "ty": 2,
      "x": 743,
      "y": 575
    },
    {
      "t": 89497,
      "e": 79576,
      "ty": 41,
      "x": 25311,
      "y": 31410,
      "ta": "html > body"
    },
    {
      "t": 89698,
      "e": 79777,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 89797,
      "e": 79876,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 89897,
      "e": 79976,
      "ty": 2,
      "x": 744,
      "y": 591
    },
    {
      "t": 89897,
      "e": 79976,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 89997,
      "e": 80076,
      "ty": 2,
      "x": 875,
      "y": 633
    },
    {
      "t": 89998,
      "e": 80077,
      "ty": 41,
      "x": 12715,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 90097,
      "e": 80176,
      "ty": 2,
      "x": 962,
      "y": 660
    },
    {
      "t": 90198,
      "e": 80277,
      "ty": 2,
      "x": 961,
      "y": 662
    },
    {
      "t": 90247,
      "e": 80326,
      "ty": 41,
      "x": 33717,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 90297,
      "e": 80376,
      "ty": 2,
      "x": 924,
      "y": 681
    },
    {
      "t": 90398,
      "e": 80477,
      "ty": 2,
      "x": 896,
      "y": 702
    },
    {
      "t": 90498,
      "e": 80577,
      "ty": 41,
      "x": 18792,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 90598,
      "e": 80677,
      "ty": 2,
      "x": 894,
      "y": 704
    },
    {
      "t": 90698,
      "e": 80777,
      "ty": 2,
      "x": 886,
      "y": 715
    },
    {
      "t": 90748,
      "e": 80827,
      "ty": 41,
      "x": 15325,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 90798,
      "e": 80877,
      "ty": 2,
      "x": 886,
      "y": 716
    },
    {
      "t": 90898,
      "e": 80977,
      "ty": 2,
      "x": 886,
      "y": 714
    },
    {
      "t": 90997,
      "e": 81076,
      "ty": 2,
      "x": 899,
      "y": 707
    },
    {
      "t": 90998,
      "e": 81077,
      "ty": 41,
      "x": 19548,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 91098,
      "e": 81177,
      "ty": 2,
      "x": 902,
      "y": 706
    },
    {
      "t": 91197,
      "e": 81276,
      "ty": 2,
      "x": 904,
      "y": 706
    },
    {
      "t": 91248,
      "e": 81327,
      "ty": 41,
      "x": 21312,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 91297,
      "e": 81376,
      "ty": 2,
      "x": 907,
      "y": 703
    },
    {
      "t": 91498,
      "e": 81577,
      "ty": 41,
      "x": 21564,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 91897,
      "e": 81976,
      "ty": 2,
      "x": 898,
      "y": 734
    },
    {
      "t": 91998,
      "e": 82077,
      "ty": 2,
      "x": 888,
      "y": 772
    },
    {
      "t": 91998,
      "e": 82077,
      "ty": 41,
      "x": 15800,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 92098,
      "e": 82177,
      "ty": 2,
      "x": 885,
      "y": 790
    },
    {
      "t": 92198,
      "e": 82277,
      "ty": 2,
      "x": 884,
      "y": 796
    },
    {
      "t": 92247,
      "e": 82326,
      "ty": 41,
      "x": 35033,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 92497,
      "e": 82576,
      "ty": 2,
      "x": 885,
      "y": 783
    },
    {
      "t": 92498,
      "e": 82577,
      "ty": 41,
      "x": 35592,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 92597,
      "e": 82676,
      "ty": 2,
      "x": 889,
      "y": 769
    },
    {
      "t": 92697,
      "e": 82776,
      "ty": 2,
      "x": 891,
      "y": 766
    },
    {
      "t": 92748,
      "e": 82827,
      "ty": 41,
      "x": 37272,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 92797,
      "e": 82876,
      "ty": 2,
      "x": 881,
      "y": 820
    },
    {
      "t": 92897,
      "e": 82976,
      "ty": 2,
      "x": 877,
      "y": 844
    },
    {
      "t": 92997,
      "e": 83076,
      "ty": 2,
      "x": 876,
      "y": 855
    },
    {
      "t": 92997,
      "e": 83076,
      "ty": 41,
      "x": 12952,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 93097,
      "e": 83176,
      "ty": 2,
      "x": 874,
      "y": 856
    },
    {
      "t": 93198,
      "e": 83277,
      "ty": 2,
      "x": 873,
      "y": 850
    },
    {
      "t": 93248,
      "e": 83327,
      "ty": 41,
      "x": 36339,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 93297,
      "e": 83376,
      "ty": 2,
      "x": 873,
      "y": 837
    },
    {
      "t": 93397,
      "e": 83476,
      "ty": 2,
      "x": 872,
      "y": 797
    },
    {
      "t": 93498,
      "e": 83577,
      "ty": 2,
      "x": 871,
      "y": 776
    },
    {
      "t": 93498,
      "e": 83577,
      "ty": 41,
      "x": 11766,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 93597,
      "e": 83676,
      "ty": 2,
      "x": 871,
      "y": 769
    },
    {
      "t": 93697,
      "e": 83776,
      "ty": 2,
      "x": 871,
      "y": 753
    },
    {
      "t": 93749,
      "e": 83778,
      "ty": 41,
      "x": 20269,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 93797,
      "e": 83826,
      "ty": 2,
      "x": 869,
      "y": 748
    },
    {
      "t": 93897,
      "e": 83926,
      "ty": 2,
      "x": 867,
      "y": 742
    },
    {
      "t": 93997,
      "e": 84026,
      "ty": 2,
      "x": 858,
      "y": 707
    },
    {
      "t": 93997,
      "e": 84026,
      "ty": 41,
      "x": 9217,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 94098,
      "e": 84127,
      "ty": 2,
      "x": 854,
      "y": 695
    },
    {
      "t": 94197,
      "e": 84226,
      "ty": 2,
      "x": 853,
      "y": 690
    },
    {
      "t": 94247,
      "e": 84276,
      "ty": 41,
      "x": 7494,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 94298,
      "e": 84327,
      "ty": 2,
      "x": 852,
      "y": 688
    },
    {
      "t": 94398,
      "e": 84427,
      "ty": 2,
      "x": 854,
      "y": 682
    },
    {
      "t": 94497,
      "e": 84526,
      "ty": 2,
      "x": 867,
      "y": 674
    },
    {
      "t": 94497,
      "e": 84526,
      "ty": 41,
      "x": 12237,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 94598,
      "e": 84627,
      "ty": 2,
      "x": 915,
      "y": 671
    },
    {
      "t": 94697,
      "e": 84726,
      "ty": 2,
      "x": 921,
      "y": 676
    },
    {
      "t": 94748,
      "e": 84777,
      "ty": 41,
      "x": 21971,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 94798,
      "e": 84827,
      "ty": 2,
      "x": 898,
      "y": 704
    },
    {
      "t": 94897,
      "e": 84926,
      "ty": 2,
      "x": 893,
      "y": 711
    },
    {
      "t": 94998,
      "e": 85027,
      "ty": 41,
      "x": 18036,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95097,
      "e": 85126,
      "ty": 2,
      "x": 893,
      "y": 708
    },
    {
      "t": 95198,
      "e": 85227,
      "ty": 2,
      "x": 896,
      "y": 702
    },
    {
      "t": 95248,
      "e": 85277,
      "ty": 41,
      "x": 19296,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 95298,
      "e": 85327,
      "ty": 2,
      "x": 898,
      "y": 701
    },
    {
      "t": 96698,
      "e": 86727,
      "ty": 2,
      "x": 898,
      "y": 704
    },
    {
      "t": 96748,
      "e": 86777,
      "ty": 41,
      "x": 19296,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 96798,
      "e": 86827,
      "ty": 2,
      "x": 898,
      "y": 705
    },
    {
      "t": 96898,
      "e": 86927,
      "ty": 2,
      "x": 895,
      "y": 706
    },
    {
      "t": 96998,
      "e": 87027,
      "ty": 41,
      "x": 18540,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 97938,
      "e": 87967,
      "ty": 3,
      "x": 895,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 98073,
      "e": 88102,
      "ty": 4,
      "x": 18540,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 98074,
      "e": 88103,
      "ty": 5,
      "x": 895,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 98075,
      "e": 88104,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 98076,
      "e": 88105,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 98398,
      "e": 88427,
      "ty": 2,
      "x": 886,
      "y": 711
    },
    {
      "t": 98458,
      "e": 88487,
      "ty": 6,
      "x": 833,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98475,
      "e": 88504,
      "ty": 7,
      "x": 810,
      "y": 740,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98498,
      "e": 88527,
      "ty": 2,
      "x": 790,
      "y": 747
    },
    {
      "t": 98498,
      "e": 88527,
      "ty": 41,
      "x": 26930,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 98598,
      "e": 88627,
      "ty": 2,
      "x": 748,
      "y": 767
    },
    {
      "t": 98697,
      "e": 88726,
      "ty": 2,
      "x": 743,
      "y": 772
    },
    {
      "t": 98748,
      "e": 88777,
      "ty": 41,
      "x": 25311,
      "y": 42323,
      "ta": "html > body"
    },
    {
      "t": 98761,
      "e": 88790,
      "ty": 3,
      "x": 743,
      "y": 772,
      "ta": "html > body"
    },
    {
      "t": 98762,
      "e": 88791,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 98833,
      "e": 88862,
      "ty": 4,
      "x": 25311,
      "y": 42323,
      "ta": "html > body"
    },
    {
      "t": 98833,
      "e": 88862,
      "ty": 5,
      "x": 743,
      "y": 772,
      "ta": "html > body"
    },
    {
      "t": 99096,
      "e": 89125,
      "ty": 2,
      "x": 748,
      "y": 777
    },
    {
      "t": 99196,
      "e": 89225,
      "ty": 2,
      "x": 852,
      "y": 812
    },
    {
      "t": 99247,
      "e": 89276,
      "ty": 41,
      "x": 28672,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 99297,
      "e": 89326,
      "ty": 2,
      "x": 873,
      "y": 817
    },
    {
      "t": 99397,
      "e": 89426,
      "ty": 2,
      "x": 874,
      "y": 817
    },
    {
      "t": 99497,
      "e": 89526,
      "ty": 41,
      "x": 31033,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 99896,
      "e": 89925,
      "ty": 2,
      "x": 875,
      "y": 829
    },
    {
      "t": 99997,
      "e": 90026,
      "ty": 2,
      "x": 872,
      "y": 839
    },
    {
      "t": 99997,
      "e": 90026,
      "ty": 41,
      "x": 35635,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 99997,
      "e": 90026,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100097,
      "e": 90126,
      "ty": 2,
      "x": 860,
      "y": 852
    },
    {
      "t": 100197,
      "e": 90226,
      "ty": 2,
      "x": 820,
      "y": 866
    },
    {
      "t": 100247,
      "e": 90276,
      "ty": 41,
      "x": 27102,
      "y": 47697,
      "ta": "html > body"
    },
    {
      "t": 100296,
      "e": 90325,
      "ty": 2,
      "x": 792,
      "y": 870
    },
    {
      "t": 100397,
      "e": 90426,
      "ty": 2,
      "x": 784,
      "y": 873
    },
    {
      "t": 100497,
      "e": 90526,
      "ty": 2,
      "x": 769,
      "y": 888
    },
    {
      "t": 100497,
      "e": 90526,
      "ty": 41,
      "x": 26207,
      "y": 48749,
      "ta": "html > body"
    },
    {
      "t": 100596,
      "e": 90625,
      "ty": 2,
      "x": 764,
      "y": 895
    },
    {
      "t": 100747,
      "e": 90776,
      "ty": 41,
      "x": 26034,
      "y": 49137,
      "ta": "html > body"
    },
    {
      "t": 101097,
      "e": 91126,
      "ty": 2,
      "x": 761,
      "y": 895
    },
    {
      "t": 101197,
      "e": 91226,
      "ty": 2,
      "x": 760,
      "y": 895
    },
    {
      "t": 101247,
      "e": 91276,
      "ty": 41,
      "x": 25897,
      "y": 49137,
      "ta": "html > body"
    },
    {
      "t": 101497,
      "e": 91526,
      "ty": 2,
      "x": 759,
      "y": 897
    },
    {
      "t": 101497,
      "e": 91526,
      "ty": 41,
      "x": 25862,
      "y": 49248,
      "ta": "html > body"
    },
    {
      "t": 101597,
      "e": 91626,
      "ty": 2,
      "x": 758,
      "y": 898
    },
    {
      "t": 101747,
      "e": 91776,
      "ty": 41,
      "x": 25828,
      "y": 49303,
      "ta": "html > body"
    },
    {
      "t": 101997,
      "e": 92026,
      "ty": 2,
      "x": 780,
      "y": 902
    },
    {
      "t": 101997,
      "e": 92026,
      "ty": 41,
      "x": 26585,
      "y": 49525,
      "ta": "html > body"
    },
    {
      "t": 102097,
      "e": 92126,
      "ty": 2,
      "x": 835,
      "y": 894
    },
    {
      "t": 102197,
      "e": 92226,
      "ty": 2,
      "x": 876,
      "y": 889
    },
    {
      "t": 102247,
      "e": 92276,
      "ty": 41,
      "x": 13190,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 102297,
      "e": 92326,
      "ty": 2,
      "x": 877,
      "y": 918
    },
    {
      "t": 102397,
      "e": 92426,
      "ty": 2,
      "x": 874,
      "y": 932
    },
    {
      "t": 102496,
      "e": 92525,
      "ty": 2,
      "x": 867,
      "y": 951
    },
    {
      "t": 102497,
      "e": 92526,
      "ty": 41,
      "x": 10816,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 102597,
      "e": 92626,
      "ty": 2,
      "x": 865,
      "y": 958
    },
    {
      "t": 102697,
      "e": 92726,
      "ty": 3,
      "x": 865,
      "y": 959,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102700,
      "e": 92729,
      "ty": 2,
      "x": 865,
      "y": 959
    },
    {
      "t": 102747,
      "e": 92776,
      "ty": 41,
      "x": 35251,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102769,
      "e": 92798,
      "ty": 4,
      "x": 35251,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102769,
      "e": 92798,
      "ty": 5,
      "x": 865,
      "y": 959,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102771,
      "e": 92800,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102772,
      "e": 92801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 102897,
      "e": 92926,
      "ty": 2,
      "x": 865,
      "y": 975
    },
    {
      "t": 102928,
      "e": 92957,
      "ty": 6,
      "x": 872,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102997,
      "e": 93026,
      "ty": 2,
      "x": 880,
      "y": 1020
    },
    {
      "t": 102997,
      "e": 93026,
      "ty": 41,
      "x": 26067,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103097,
      "e": 93126,
      "ty": 2,
      "x": 892,
      "y": 1028
    },
    {
      "t": 103197,
      "e": 93226,
      "ty": 2,
      "x": 893,
      "y": 1028
    },
    {
      "t": 103232,
      "e": 93261,
      "ty": 3,
      "x": 893,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103232,
      "e": 93261,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103232,
      "e": 93261,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103247,
      "e": 93276,
      "ty": 41,
      "x": 32767,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103296,
      "e": 93325,
      "ty": 4,
      "x": 32767,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103296,
      "e": 93325,
      "ty": 5,
      "x": 893,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103299,
      "e": 93328,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103300,
      "e": 93329,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 103301,
      "e": 93330,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 103497,
      "e": 93526,
      "ty": 2,
      "x": 891,
      "y": 1021
    },
    {
      "t": 103497,
      "e": 93526,
      "ty": 41,
      "x": 30408,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 103596,
      "e": 93625,
      "ty": 2,
      "x": 619,
      "y": 842
    },
    {
      "t": 103696,
      "e": 93725,
      "ty": 2,
      "x": 566,
      "y": 800
    },
    {
      "t": 103747,
      "e": 93776,
      "ty": 41,
      "x": 19216,
      "y": 43874,
      "ta": "html > body"
    },
    {
      "t": 104597,
      "e": 94626,
      "ty": 2,
      "x": 565,
      "y": 796
    },
    {
      "t": 104697,
      "e": 94726,
      "ty": 2,
      "x": 566,
      "y": 793
    },
    {
      "t": 104747,
      "e": 94776,
      "ty": 41,
      "x": 19388,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 104797,
      "e": 94826,
      "ty": 2,
      "x": 582,
      "y": 785
    },
    {
      "t": 104897,
      "e": 94926,
      "ty": 2,
      "x": 600,
      "y": 776
    },
    {
      "t": 104997,
      "e": 95026,
      "ty": 2,
      "x": 662,
      "y": 710
    },
    {
      "t": 104997,
      "e": 95026,
      "ty": 41,
      "x": 22522,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 105096,
      "e": 95125,
      "ty": 2,
      "x": 758,
      "y": 584
    },
    {
      "t": 105196,
      "e": 95225,
      "ty": 2,
      "x": 759,
      "y": 580
    },
    {
      "t": 105247,
      "e": 95276,
      "ty": 41,
      "x": 25862,
      "y": 31687,
      "ta": "html > body"
    },
    {
      "t": 105783,
      "e": 95812,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 106497,
      "e": 96526,
      "ty": 2,
      "x": 783,
      "y": 565
    },
    {
      "t": 106497,
      "e": 96526,
      "ty": 41,
      "x": 24084,
      "y": 32188,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 106597,
      "e": 96626,
      "ty": 2,
      "x": 900,
      "y": 231
    },
    {
      "t": 106697,
      "e": 96726,
      "ty": 2,
      "x": 1026,
      "y": 80
    },
    {
      "t": 106747,
      "e": 96776,
      "ty": 41,
      "x": 35643,
      "y": 2880,
      "ta": "> div.masterdiv"
    },
    {
      "t": 106797,
      "e": 96826,
      "ty": 2,
      "x": 1043,
      "y": 60
    },
    {
      "t": 106897,
      "e": 96926,
      "ty": 2,
      "x": 990,
      "y": 86
    },
    {
      "t": 106997,
      "e": 97026,
      "ty": 2,
      "x": 698,
      "y": 176
    },
    {
      "t": 106997,
      "e": 97026,
      "ty": 41,
      "x": 19902,
      "y": 3441,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 107097,
      "e": 97126,
      "ty": 2,
      "x": 440,
      "y": 283
    },
    {
      "t": 107197,
      "e": 97226,
      "ty": 2,
      "x": 353,
      "y": 359
    },
    {
      "t": 107248,
      "e": 97277,
      "ty": 41,
      "x": 2929,
      "y": 3301,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 107297,
      "e": 97326,
      "ty": 2,
      "x": 352,
      "y": 365
    },
    {
      "t": 107397,
      "e": 97426,
      "ty": 2,
      "x": 351,
      "y": 367
    },
    {
      "t": 107498,
      "e": 97527,
      "ty": 41,
      "x": 2831,
      "y": 3764,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 107597,
      "e": 97626,
      "ty": 2,
      "x": 376,
      "y": 394
    },
    {
      "t": 107697,
      "e": 97726,
      "ty": 2,
      "x": 483,
      "y": 426
    },
    {
      "t": 107747,
      "e": 97776,
      "ty": 41,
      "x": 9571,
      "y": 35510,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 107797,
      "e": 97826,
      "ty": 2,
      "x": 489,
      "y": 426
    },
    {
      "t": 107897,
      "e": 97926,
      "ty": 2,
      "x": 501,
      "y": 423
    },
    {
      "t": 107997,
      "e": 98026,
      "ty": 2,
      "x": 531,
      "y": 419
    },
    {
      "t": 107997,
      "e": 98026,
      "ty": 41,
      "x": 11686,
      "y": 30049,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 108097,
      "e": 98126,
      "ty": 2,
      "x": 582,
      "y": 419
    },
    {
      "t": 108201,
      "e": 98130,
      "ty": 2,
      "x": 604,
      "y": 422
    },
    {
      "t": 108247,
      "e": 98176,
      "ty": 41,
      "x": 15277,
      "y": 32389,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 108897,
      "e": 98826,
      "ty": 2,
      "x": 605,
      "y": 422
    },
    {
      "t": 108997,
      "e": 98926,
      "ty": 2,
      "x": 607,
      "y": 423
    },
    {
      "t": 108997,
      "e": 98926,
      "ty": 41,
      "x": 15425,
      "y": 33169,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 109097,
      "e": 99026,
      "ty": 2,
      "x": 614,
      "y": 433
    },
    {
      "t": 109197,
      "e": 99126,
      "ty": 2,
      "x": 622,
      "y": 447
    },
    {
      "t": 109248,
      "e": 99177,
      "ty": 41,
      "x": 16360,
      "y": 15111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 109297,
      "e": 99226,
      "ty": 2,
      "x": 620,
      "y": 474
    },
    {
      "t": 109498,
      "e": 99427,
      "ty": 41,
      "x": 16065,
      "y": 16153,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 109697,
      "e": 99626,
      "ty": 2,
      "x": 616,
      "y": 474
    },
    {
      "t": 109747,
      "e": 99676,
      "ty": 41,
      "x": 15573,
      "y": 16269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 109797,
      "e": 99726,
      "ty": 2,
      "x": 598,
      "y": 478
    },
    {
      "t": 109897,
      "e": 99826,
      "ty": 2,
      "x": 547,
      "y": 494
    },
    {
      "t": 109997,
      "e": 99926,
      "ty": 2,
      "x": 543,
      "y": 499
    },
    {
      "t": 109998,
      "e": 99927,
      "ty": 41,
      "x": 12276,
      "y": 6442,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 110097,
      "e": 100026,
      "ty": 2,
      "x": 543,
      "y": 501
    },
    {
      "t": 110197,
      "e": 100126,
      "ty": 2,
      "x": 543,
      "y": 510
    },
    {
      "t": 110247,
      "e": 100176,
      "ty": 41,
      "x": 12916,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 110297,
      "e": 100226,
      "ty": 2,
      "x": 584,
      "y": 609
    },
    {
      "t": 110397,
      "e": 100326,
      "ty": 2,
      "x": 662,
      "y": 705
    },
    {
      "t": 110497,
      "e": 100426,
      "ty": 2,
      "x": 734,
      "y": 745
    },
    {
      "t": 110497,
      "e": 100426,
      "ty": 41,
      "x": 21673,
      "y": 44771,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111197,
      "e": 101126,
      "ty": 2,
      "x": 735,
      "y": 747
    },
    {
      "t": 111247,
      "e": 101176,
      "ty": 41,
      "x": 21722,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111397,
      "e": 101326,
      "ty": 2,
      "x": 736,
      "y": 747
    },
    {
      "t": 111497,
      "e": 101426,
      "ty": 41,
      "x": 21771,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111597,
      "e": 101526,
      "ty": 2,
      "x": 745,
      "y": 745
    },
    {
      "t": 111697,
      "e": 101626,
      "ty": 2,
      "x": 796,
      "y": 752
    },
    {
      "t": 111748,
      "e": 101677,
      "ty": 41,
      "x": 26937,
      "y": 62325,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111797,
      "e": 101726,
      "ty": 2,
      "x": 875,
      "y": 799
    },
    {
      "t": 111897,
      "e": 101826,
      "ty": 2,
      "x": 894,
      "y": 833
    },
    {
      "t": 111997,
      "e": 101926,
      "ty": 2,
      "x": 900,
      "y": 852
    },
    {
      "t": 111998,
      "e": 101927,
      "ty": 41,
      "x": 29840,
      "y": 62627,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 112097,
      "e": 102026,
      "ty": 2,
      "x": 922,
      "y": 902
    },
    {
      "t": 112248,
      "e": 102177,
      "ty": 41,
      "x": 30922,
      "y": 53715,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112498,
      "e": 102427,
      "ty": 2,
      "x": 922,
      "y": 905
    },
    {
      "t": 112498,
      "e": 102427,
      "ty": 41,
      "x": 30922,
      "y": 53923,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112597,
      "e": 102526,
      "ty": 2,
      "x": 930,
      "y": 909
    },
    {
      "t": 112697,
      "e": 102626,
      "ty": 2,
      "x": 935,
      "y": 915
    },
    {
      "t": 112748,
      "e": 102677,
      "ty": 41,
      "x": 31857,
      "y": 55515,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 112797,
      "e": 102726,
      "ty": 2,
      "x": 961,
      "y": 973
    },
    {
      "t": 112897,
      "e": 102826,
      "ty": 2,
      "x": 998,
      "y": 1047
    },
    {
      "t": 112952,
      "e": 102881,
      "ty": 6,
      "x": 1007,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 112997,
      "e": 102926,
      "ty": 2,
      "x": 1011,
      "y": 1096
    },
    {
      "t": 112997,
      "e": 102926,
      "ty": 41,
      "x": 55431,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 113053,
      "e": 102982,
      "ty": 7,
      "x": 1014,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 113097,
      "e": 103026,
      "ty": 2,
      "x": 1014,
      "y": 1111
    },
    {
      "t": 113197,
      "e": 103126,
      "ty": 2,
      "x": 1008,
      "y": 1117
    },
    {
      "t": 113247,
      "e": 103176,
      "ty": 41,
      "x": 52662,
      "y": 24548,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 113298,
      "e": 103227,
      "ty": 2,
      "x": 999,
      "y": 1117
    },
    {
      "t": 113370,
      "e": 103299,
      "ty": 6,
      "x": 992,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 113397,
      "e": 103326,
      "ty": 2,
      "x": 992,
      "y": 1105
    },
    {
      "t": 113497,
      "e": 103426,
      "ty": 2,
      "x": 989,
      "y": 1098
    },
    {
      "t": 113497,
      "e": 103426,
      "ty": 41,
      "x": 43416,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 113597,
      "e": 103526,
      "ty": 2,
      "x": 988,
      "y": 1094
    },
    {
      "t": 113697,
      "e": 103626,
      "ty": 2,
      "x": 988,
      "y": 1092
    },
    {
      "t": 113747,
      "e": 103676,
      "ty": 41,
      "x": 42870,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 115153,
      "e": 105082,
      "ty": 3,
      "x": 988,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 115154,
      "e": 105083,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 115256,
      "e": 105185,
      "ty": 4,
      "x": 42870,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 115256,
      "e": 105185,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 115257,
      "e": 105186,
      "ty": 5,
      "x": 988,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 115257,
      "e": 105186,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 115998,
      "e": 105927,
      "ty": 2,
      "x": 988,
      "y": 1089
    },
    {
      "t": 115998,
      "e": 105927,
      "ty": 41,
      "x": 33748,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 116097,
      "e": 106026,
      "ty": 2,
      "x": 991,
      "y": 1074
    },
    {
      "t": 116197,
      "e": 106126,
      "ty": 2,
      "x": 1015,
      "y": 907
    },
    {
      "t": 116248,
      "e": 106177,
      "ty": 41,
      "x": 34678,
      "y": 47475,
      "ta": "html > body"
    },
    {
      "t": 116294,
      "e": 106223,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 117137,
      "e": 107066,
      "ty": 2,
      "x": 1015,
      "y": 858
    },
    {
      "t": 117137,
      "e": 107066,
      "ty": 41,
      "x": 35234,
      "y": 32822,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 117805,
      "e": 107734,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 79906, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 79910, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8264, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 89514, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 5801, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"golf\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 96321, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 28951, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 126361, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16940, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 144304, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 29752, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 175411, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-O -C -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:872,y:994,t:1527019522009};\\\", \\\"{x:871,y:995,t:1527019522228};\\\", \\\"{x:870,y:995,t:1527019523313};\\\", \\\"{x:870,y:992,t:1527019523425};\\\", \\\"{x:866,y:986,t:1527019523437};\\\", \\\"{x:853,y:978,t:1527019523453};\\\", \\\"{x:836,y:966,t:1527019523470};\\\", \\\"{x:817,y:949,t:1527019523487};\\\", \\\"{x:786,y:919,t:1527019523504};\\\", \\\"{x:746,y:881,t:1527019523520};\\\", \\\"{x:706,y:842,t:1527019523537};\\\", \\\"{x:640,y:771,t:1527019523553};\\\", \\\"{x:602,y:727,t:1527019523571};\\\", \\\"{x:580,y:697,t:1527019523586};\\\", \\\"{x:558,y:669,t:1527019523603};\\\", \\\"{x:528,y:641,t:1527019523621};\\\", \\\"{x:503,y:622,t:1527019523637};\\\", \\\"{x:489,y:612,t:1527019523654};\\\", \\\"{x:478,y:601,t:1527019523670};\\\", \\\"{x:464,y:591,t:1527019523688};\\\", \\\"{x:450,y:580,t:1527019523703};\\\", \\\"{x:436,y:568,t:1527019523721};\\\", \\\"{x:432,y:558,t:1527019523736};\\\", \\\"{x:425,y:545,t:1527019523753};\\\", \\\"{x:415,y:530,t:1527019523771};\\\", \\\"{x:411,y:523,t:1527019523788};\\\", \\\"{x:407,y:516,t:1527019523803};\\\", \\\"{x:402,y:508,t:1527019523821};\\\", \\\"{x:401,y:503,t:1527019523838};\\\", \\\"{x:400,y:501,t:1527019523854};\\\", \\\"{x:400,y:500,t:1527019523871};\\\", \\\"{x:400,y:499,t:1527019523887};\\\", \\\"{x:400,y:495,t:1527019523904};\\\", \\\"{x:399,y:492,t:1527019523921};\\\", \\\"{x:399,y:490,t:1527019523937};\\\", \\\"{x:399,y:489,t:1527019523961};\\\", \\\"{x:399,y:487,t:1527019523984};\\\", \\\"{x:400,y:485,t:1527019524008};\\\", \\\"{x:401,y:485,t:1527019524020};\\\", \\\"{x:402,y:483,t:1527019524037};\\\", \\\"{x:407,y:482,t:1527019524054};\\\", \\\"{x:419,y:481,t:1527019524071};\\\", \\\"{x:436,y:481,t:1527019524087};\\\", \\\"{x:451,y:481,t:1527019524104};\\\", \\\"{x:464,y:479,t:1527019524120};\\\", \\\"{x:474,y:479,t:1527019524137};\\\", \\\"{x:475,y:479,t:1527019524154};\\\", \\\"{x:476,y:479,t:1527019524170};\\\", \\\"{x:477,y:479,t:1527019524187};\\\", \\\"{x:478,y:479,t:1527019524217};\\\", \\\"{x:479,y:479,t:1527019524289};\\\", \\\"{x:481,y:479,t:1527019524305};\\\", \\\"{x:489,y:482,t:1527019524321};\\\", \\\"{x:494,y:483,t:1527019524337};\\\", \\\"{x:498,y:484,t:1527019524354};\\\", \\\"{x:501,y:484,t:1527019524370};\\\", \\\"{x:504,y:484,t:1527019524388};\\\", \\\"{x:509,y:485,t:1527019524404};\\\", \\\"{x:519,y:486,t:1527019524422};\\\", \\\"{x:529,y:486,t:1527019524438};\\\", \\\"{x:538,y:486,t:1527019524454};\\\", \\\"{x:548,y:486,t:1527019524471};\\\", \\\"{x:554,y:486,t:1527019524487};\\\", \\\"{x:564,y:485,t:1527019524504};\\\", \\\"{x:575,y:485,t:1527019524522};\\\", \\\"{x:579,y:484,t:1527019524538};\\\", \\\"{x:580,y:484,t:1527019524555};\\\", \\\"{x:581,y:484,t:1527019524572};\\\", \\\"{x:584,y:482,t:1527019524618};\\\", \\\"{x:586,y:482,t:1527019524641};\\\", \\\"{x:587,y:482,t:1527019524655};\\\", \\\"{x:588,y:482,t:1527019524672};\\\", \\\"{x:589,y:482,t:1527019524978};\\\", \\\"{x:588,y:483,t:1527019524994};\\\", \\\"{x:587,y:485,t:1527019525005};\\\", \\\"{x:584,y:485,t:1527019525022};\\\", \\\"{x:582,y:487,t:1527019525039};\\\", \\\"{x:581,y:487,t:1527019525055};\\\", \\\"{x:580,y:488,t:1527019525072};\\\", \\\"{x:577,y:489,t:1527019525089};\\\", \\\"{x:575,y:490,t:1527019525106};\\\", \\\"{x:571,y:492,t:1527019525122};\\\", \\\"{x:570,y:493,t:1527019525140};\\\", \\\"{x:569,y:493,t:1527019525242};\\\", \\\"{x:569,y:492,t:1527019525255};\\\", \\\"{x:568,y:492,t:1527019525272};\\\", \\\"{x:568,y:491,t:1527019525313};\\\", \\\"{x:568,y:489,t:1527019525337};\\\", \\\"{x:568,y:488,t:1527019525378};\\\", \\\"{x:568,y:486,t:1527019525402};\\\", \\\"{x:568,y:484,t:1527019525426};\\\", \\\"{x:569,y:482,t:1527019525442};\\\", \\\"{x:570,y:482,t:1527019525466};\\\", \\\"{x:571,y:481,t:1527019525473};\\\", \\\"{x:571,y:480,t:1527019525514};\\\", \\\"{x:573,y:479,t:1527019525850};\\\", \\\"{x:580,y:479,t:1527019525858};\\\", \\\"{x:594,y:482,t:1527019525873};\\\", \\\"{x:604,y:484,t:1527019525889};\\\", \\\"{x:637,y:491,t:1527019525906};\\\", \\\"{x:656,y:497,t:1527019525923};\\\", \\\"{x:682,y:502,t:1527019525940};\\\", \\\"{x:705,y:506,t:1527019525957};\\\", \\\"{x:727,y:509,t:1527019525973};\\\", \\\"{x:744,y:510,t:1527019525989};\\\", \\\"{x:759,y:512,t:1527019526005};\\\", \\\"{x:773,y:512,t:1527019526022};\\\", \\\"{x:786,y:512,t:1527019526038};\\\", \\\"{x:791,y:513,t:1527019526055};\\\", \\\"{x:799,y:513,t:1527019526072};\\\", \\\"{x:817,y:518,t:1527019526089};\\\", \\\"{x:834,y:525,t:1527019526105};\\\", \\\"{x:845,y:530,t:1527019526121};\\\", \\\"{x:854,y:537,t:1527019526140};\\\", \\\"{x:864,y:544,t:1527019526156};\\\", \\\"{x:880,y:552,t:1527019526173};\\\", \\\"{x:895,y:561,t:1527019526190};\\\", \\\"{x:910,y:569,t:1527019526205};\\\", \\\"{x:926,y:574,t:1527019526222};\\\", \\\"{x:939,y:580,t:1527019526240};\\\", \\\"{x:952,y:587,t:1527019526255};\\\", \\\"{x:970,y:598,t:1527019526273};\\\", \\\"{x:980,y:608,t:1527019526288};\\\", \\\"{x:987,y:612,t:1527019526305};\\\", \\\"{x:991,y:616,t:1527019526322};\\\", \\\"{x:994,y:618,t:1527019526339};\\\", \\\"{x:995,y:620,t:1527019526377};\\\", \\\"{x:995,y:621,t:1527019526388};\\\", \\\"{x:996,y:625,t:1527019526405};\\\", \\\"{x:999,y:632,t:1527019526423};\\\", \\\"{x:1000,y:640,t:1527019526439};\\\", \\\"{x:1002,y:645,t:1527019526456};\\\", \\\"{x:1003,y:657,t:1527019526473};\\\", \\\"{x:1007,y:670,t:1527019526489};\\\", \\\"{x:1010,y:682,t:1527019526506};\\\", \\\"{x:1013,y:685,t:1527019526522};\\\", \\\"{x:1015,y:688,t:1527019526539};\\\", \\\"{x:1015,y:689,t:1527019526555};\\\", \\\"{x:1016,y:690,t:1527019526572};\\\", \\\"{x:1017,y:690,t:1527019526642};\\\", \\\"{x:1018,y:690,t:1527019526658};\\\", \\\"{x:1019,y:690,t:1527019526737};\\\", \\\"{x:1020,y:690,t:1527019526744};\\\", \\\"{x:1021,y:690,t:1527019526756};\\\", \\\"{x:1023,y:689,t:1527019526772};\\\", \\\"{x:1026,y:685,t:1527019526788};\\\", \\\"{x:1028,y:680,t:1527019526806};\\\", \\\"{x:1029,y:677,t:1527019526822};\\\", \\\"{x:1032,y:669,t:1527019526838};\\\", \\\"{x:1034,y:660,t:1527019526856};\\\", \\\"{x:1035,y:646,t:1527019526873};\\\", \\\"{x:1035,y:631,t:1527019526889};\\\", \\\"{x:1035,y:619,t:1527019526906};\\\", \\\"{x:1035,y:613,t:1527019526922};\\\", \\\"{x:1035,y:608,t:1527019526938};\\\", \\\"{x:1035,y:605,t:1527019526956};\\\", \\\"{x:1033,y:602,t:1527019526973};\\\", \\\"{x:1032,y:600,t:1527019526989};\\\", \\\"{x:1032,y:596,t:1527019527005};\\\", \\\"{x:1031,y:595,t:1527019527023};\\\", \\\"{x:1031,y:594,t:1527019527039};\\\", \\\"{x:1031,y:601,t:1527019527130};\\\", \\\"{x:1031,y:612,t:1527019527139};\\\", \\\"{x:1031,y:640,t:1527019527156};\\\", \\\"{x:1037,y:678,t:1527019527172};\\\", \\\"{x:1047,y:727,t:1527019527189};\\\", \\\"{x:1067,y:779,t:1527019527206};\\\", \\\"{x:1086,y:830,t:1527019527222};\\\", \\\"{x:1101,y:878,t:1527019527239};\\\", \\\"{x:1124,y:919,t:1527019527255};\\\", \\\"{x:1142,y:958,t:1527019527272};\\\", \\\"{x:1168,y:1002,t:1527019527289};\\\", \\\"{x:1179,y:1020,t:1527019527305};\\\", \\\"{x:1197,y:1040,t:1527019527321};\\\", \\\"{x:1212,y:1053,t:1527019527339};\\\", \\\"{x:1230,y:1066,t:1527019527356};\\\", \\\"{x:1240,y:1076,t:1527019527372};\\\", \\\"{x:1255,y:1085,t:1527019527389};\\\", \\\"{x:1275,y:1092,t:1527019527406};\\\", \\\"{x:1293,y:1095,t:1527019527422};\\\", \\\"{x:1310,y:1095,t:1527019527439};\\\", \\\"{x:1326,y:1095,t:1527019527456};\\\", \\\"{x:1337,y:1089,t:1527019527473};\\\", \\\"{x:1348,y:1078,t:1527019527489};\\\", \\\"{x:1356,y:1070,t:1527019527505};\\\", \\\"{x:1363,y:1064,t:1527019527522};\\\", \\\"{x:1366,y:1060,t:1527019527540};\\\", \\\"{x:1370,y:1058,t:1527019527556};\\\", \\\"{x:1371,y:1057,t:1527019527572};\\\", \\\"{x:1371,y:1056,t:1527019527609};\\\", \\\"{x:1371,y:1055,t:1527019527625};\\\", \\\"{x:1372,y:1054,t:1527019527640};\\\", \\\"{x:1373,y:1054,t:1527019527656};\\\", \\\"{x:1375,y:1052,t:1527019527673};\\\", \\\"{x:1377,y:1050,t:1527019527689};\\\", \\\"{x:1381,y:1048,t:1527019527706};\\\", \\\"{x:1386,y:1047,t:1527019527721};\\\", \\\"{x:1390,y:1045,t:1527019527739};\\\", \\\"{x:1392,y:1044,t:1527019527755};\\\", \\\"{x:1394,y:1043,t:1527019527772};\\\", \\\"{x:1395,y:1043,t:1527019527788};\\\", \\\"{x:1396,y:1042,t:1527019527806};\\\", \\\"{x:1396,y:1041,t:1527019527821};\\\", \\\"{x:1397,y:1041,t:1527019527838};\\\", \\\"{x:1401,y:1040,t:1527019527856};\\\", \\\"{x:1409,y:1037,t:1527019527871};\\\", \\\"{x:1420,y:1036,t:1527019527889};\\\", \\\"{x:1430,y:1034,t:1527019527905};\\\", \\\"{x:1442,y:1033,t:1527019527922};\\\", \\\"{x:1450,y:1032,t:1527019527939};\\\", \\\"{x:1456,y:1031,t:1527019527955};\\\", \\\"{x:1459,y:1029,t:1527019527972};\\\", \\\"{x:1460,y:1029,t:1527019527989};\\\", \\\"{x:1461,y:1029,t:1527019528018};\\\", \\\"{x:1462,y:1029,t:1527019528026};\\\", \\\"{x:1463,y:1029,t:1527019528039};\\\", \\\"{x:1468,y:1029,t:1527019528055};\\\", \\\"{x:1471,y:1029,t:1527019528072};\\\", \\\"{x:1474,y:1029,t:1527019528090};\\\", \\\"{x:1476,y:1029,t:1527019528105};\\\", \\\"{x:1477,y:1029,t:1527019528122};\\\", \\\"{x:1477,y:1028,t:1527019528154};\\\", \\\"{x:1475,y:1028,t:1527019528162};\\\", \\\"{x:1469,y:1028,t:1527019528173};\\\", \\\"{x:1458,y:1027,t:1527019528189};\\\", \\\"{x:1443,y:1027,t:1527019528205};\\\", \\\"{x:1423,y:1027,t:1527019528222};\\\", \\\"{x:1399,y:1023,t:1527019528239};\\\", \\\"{x:1377,y:1022,t:1527019528255};\\\", \\\"{x:1368,y:1017,t:1527019528272};\\\", \\\"{x:1356,y:1009,t:1527019528290};\\\", \\\"{x:1351,y:1005,t:1527019528305};\\\", \\\"{x:1347,y:1003,t:1527019528322};\\\", \\\"{x:1347,y:1002,t:1527019528339};\\\", \\\"{x:1344,y:1001,t:1527019528355};\\\", \\\"{x:1341,y:999,t:1527019528372};\\\", \\\"{x:1338,y:999,t:1527019528389};\\\", \\\"{x:1333,y:998,t:1527019528405};\\\", \\\"{x:1329,y:996,t:1527019528422};\\\", \\\"{x:1326,y:995,t:1527019528440};\\\", \\\"{x:1322,y:994,t:1527019528455};\\\", \\\"{x:1319,y:993,t:1527019528472};\\\", \\\"{x:1317,y:992,t:1527019528488};\\\", \\\"{x:1316,y:991,t:1527019528536};\\\", \\\"{x:1315,y:991,t:1527019528553};\\\", \\\"{x:1313,y:990,t:1527019528560};\\\", \\\"{x:1312,y:990,t:1527019528577};\\\", \\\"{x:1311,y:990,t:1527019528588};\\\", \\\"{x:1311,y:989,t:1527019528604};\\\", \\\"{x:1310,y:989,t:1527019528622};\\\", \\\"{x:1309,y:987,t:1527019528639};\\\", \\\"{x:1307,y:986,t:1527019528655};\\\", \\\"{x:1305,y:982,t:1527019528671};\\\", \\\"{x:1302,y:979,t:1527019528688};\\\", \\\"{x:1299,y:978,t:1527019528705};\\\", \\\"{x:1297,y:977,t:1527019528722};\\\", \\\"{x:1295,y:975,t:1527019528738};\\\", \\\"{x:1294,y:974,t:1527019528761};\\\", \\\"{x:1293,y:974,t:1527019528810};\\\", \\\"{x:1292,y:972,t:1527019528914};\\\", \\\"{x:1290,y:972,t:1527019528930};\\\", \\\"{x:1289,y:972,t:1527019528978};\\\", \\\"{x:1287,y:972,t:1527019529010};\\\", \\\"{x:1286,y:971,t:1527019529417};\\\", \\\"{x:1285,y:970,t:1527019529433};\\\", \\\"{x:1285,y:969,t:1527019529441};\\\", \\\"{x:1285,y:968,t:1527019529455};\\\", \\\"{x:1284,y:967,t:1527019529472};\\\", \\\"{x:1283,y:967,t:1527019529698};\\\", \\\"{x:1283,y:966,t:1527019529905};\\\", \\\"{x:1283,y:965,t:1527019529928};\\\", \\\"{x:1282,y:963,t:1527019529953};\\\", \\\"{x:1281,y:962,t:1527019529985};\\\", \\\"{x:1280,y:961,t:1527019530001};\\\", \\\"{x:1280,y:960,t:1527019530009};\\\", \\\"{x:1280,y:959,t:1527019530025};\\\", \\\"{x:1280,y:958,t:1527019530040};\\\", \\\"{x:1280,y:957,t:1527019530055};\\\", \\\"{x:1280,y:954,t:1527019530073};\\\", \\\"{x:1280,y:953,t:1527019530088};\\\", \\\"{x:1281,y:950,t:1527019530105};\\\", \\\"{x:1281,y:947,t:1527019530121};\\\", \\\"{x:1281,y:944,t:1527019530138};\\\", \\\"{x:1281,y:940,t:1527019530154};\\\", \\\"{x:1281,y:939,t:1527019530171};\\\", \\\"{x:1281,y:937,t:1527019530188};\\\", \\\"{x:1281,y:936,t:1527019530204};\\\", \\\"{x:1281,y:930,t:1527019530221};\\\", \\\"{x:1281,y:927,t:1527019530238};\\\", \\\"{x:1281,y:923,t:1527019530254};\\\", \\\"{x:1281,y:920,t:1527019530271};\\\", \\\"{x:1281,y:916,t:1527019530288};\\\", \\\"{x:1281,y:912,t:1527019530305};\\\", \\\"{x:1281,y:907,t:1527019530321};\\\", \\\"{x:1281,y:901,t:1527019530338};\\\", \\\"{x:1281,y:897,t:1527019530354};\\\", \\\"{x:1281,y:893,t:1527019530371};\\\", \\\"{x:1281,y:890,t:1527019530388};\\\", \\\"{x:1281,y:886,t:1527019530404};\\\", \\\"{x:1281,y:883,t:1527019530421};\\\", \\\"{x:1281,y:880,t:1527019530438};\\\", \\\"{x:1281,y:877,t:1527019530454};\\\", \\\"{x:1281,y:873,t:1527019530471};\\\", \\\"{x:1281,y:870,t:1527019530487};\\\", \\\"{x:1281,y:866,t:1527019530503};\\\", \\\"{x:1280,y:863,t:1527019530520};\\\", \\\"{x:1280,y:862,t:1527019530538};\\\", \\\"{x:1280,y:860,t:1527019530553};\\\", \\\"{x:1280,y:859,t:1527019530571};\\\", \\\"{x:1280,y:857,t:1527019530588};\\\", \\\"{x:1280,y:856,t:1527019530604};\\\", \\\"{x:1280,y:855,t:1527019530621};\\\", \\\"{x:1280,y:853,t:1527019530638};\\\", \\\"{x:1279,y:851,t:1527019530655};\\\", \\\"{x:1279,y:850,t:1527019530673};\\\", \\\"{x:1279,y:848,t:1527019530688};\\\", \\\"{x:1278,y:847,t:1527019530704};\\\", \\\"{x:1278,y:846,t:1527019530720};\\\", \\\"{x:1278,y:845,t:1527019530738};\\\", \\\"{x:1278,y:844,t:1527019530793};\\\", \\\"{x:1278,y:843,t:1527019530809};\\\", \\\"{x:1277,y:843,t:1527019530820};\\\", \\\"{x:1277,y:842,t:1527019530838};\\\", \\\"{x:1276,y:842,t:1527019530857};\\\", \\\"{x:1276,y:841,t:1527019530871};\\\", \\\"{x:1276,y:840,t:1527019530897};\\\", \\\"{x:1276,y:839,t:1527019530953};\\\", \\\"{x:1275,y:838,t:1527019530978};\\\", \\\"{x:1274,y:837,t:1527019531065};\\\", \\\"{x:1274,y:836,t:1527019531081};\\\", \\\"{x:1274,y:835,t:1527019531290};\\\", \\\"{x:1274,y:834,t:1527019531305};\\\", \\\"{x:1275,y:834,t:1527019531346};\\\", \\\"{x:1276,y:832,t:1527019532538};\\\", \\\"{x:1276,y:831,t:1527019532561};\\\", \\\"{x:1277,y:830,t:1527019532570};\\\", \\\"{x:1277,y:829,t:1527019532588};\\\", \\\"{x:1277,y:828,t:1527019532604};\\\", \\\"{x:1278,y:827,t:1527019532620};\\\", \\\"{x:1278,y:826,t:1527019532658};\\\", \\\"{x:1278,y:825,t:1527019532674};\\\", \\\"{x:1279,y:824,t:1527019532687};\\\", \\\"{x:1279,y:823,t:1527019532703};\\\", \\\"{x:1280,y:820,t:1527019532720};\\\", \\\"{x:1281,y:815,t:1527019532737};\\\", \\\"{x:1281,y:808,t:1527019532753};\\\", \\\"{x:1281,y:801,t:1527019532770};\\\", \\\"{x:1281,y:793,t:1527019532787};\\\", \\\"{x:1281,y:789,t:1527019532802};\\\", \\\"{x:1281,y:785,t:1527019532820};\\\", \\\"{x:1281,y:779,t:1527019532836};\\\", \\\"{x:1281,y:777,t:1527019532853};\\\", \\\"{x:1281,y:774,t:1527019532870};\\\", \\\"{x:1281,y:770,t:1527019532887};\\\", \\\"{x:1281,y:763,t:1527019532903};\\\", \\\"{x:1281,y:756,t:1527019532920};\\\", \\\"{x:1281,y:751,t:1527019532937};\\\", \\\"{x:1281,y:746,t:1527019532953};\\\", \\\"{x:1281,y:743,t:1527019532970};\\\", \\\"{x:1281,y:740,t:1527019532987};\\\", \\\"{x:1281,y:737,t:1527019533003};\\\", \\\"{x:1281,y:735,t:1527019533020};\\\", \\\"{x:1281,y:732,t:1527019533037};\\\", \\\"{x:1281,y:728,t:1527019533053};\\\", \\\"{x:1281,y:724,t:1527019533070};\\\", \\\"{x:1281,y:719,t:1527019533087};\\\", \\\"{x:1281,y:716,t:1527019533103};\\\", \\\"{x:1281,y:713,t:1527019533120};\\\", \\\"{x:1281,y:710,t:1527019533137};\\\", \\\"{x:1281,y:708,t:1527019533153};\\\", \\\"{x:1282,y:706,t:1527019533170};\\\", \\\"{x:1283,y:704,t:1527019533186};\\\", \\\"{x:1283,y:703,t:1527019533209};\\\", \\\"{x:1283,y:701,t:1527019533224};\\\", \\\"{x:1283,y:700,t:1527019533241};\\\", \\\"{x:1283,y:697,t:1527019533257};\\\", \\\"{x:1283,y:696,t:1527019533270};\\\", \\\"{x:1284,y:694,t:1527019533287};\\\", \\\"{x:1284,y:693,t:1527019533303};\\\", \\\"{x:1284,y:692,t:1527019533320};\\\", \\\"{x:1284,y:691,t:1527019533337};\\\", \\\"{x:1284,y:690,t:1527019533650};\\\", \\\"{x:1282,y:686,t:1527019533658};\\\", \\\"{x:1281,y:683,t:1527019533670};\\\", \\\"{x:1275,y:672,t:1527019533687};\\\", \\\"{x:1268,y:660,t:1527019533703};\\\", \\\"{x:1263,y:650,t:1527019533719};\\\", \\\"{x:1261,y:640,t:1527019533736};\\\", \\\"{x:1257,y:632,t:1527019533753};\\\", \\\"{x:1254,y:626,t:1527019533770};\\\", \\\"{x:1253,y:620,t:1527019533786};\\\", \\\"{x:1250,y:615,t:1527019533803};\\\", \\\"{x:1250,y:609,t:1527019533821};\\\", \\\"{x:1247,y:604,t:1527019533836};\\\", \\\"{x:1247,y:599,t:1527019533853};\\\", \\\"{x:1247,y:596,t:1527019533870};\\\", \\\"{x:1247,y:590,t:1527019533886};\\\", \\\"{x:1246,y:587,t:1527019533903};\\\", \\\"{x:1246,y:582,t:1527019533920};\\\", \\\"{x:1246,y:578,t:1527019533936};\\\", \\\"{x:1246,y:571,t:1527019533953};\\\", \\\"{x:1247,y:569,t:1527019533970};\\\", \\\"{x:1249,y:566,t:1527019533986};\\\", \\\"{x:1251,y:562,t:1527019534003};\\\", \\\"{x:1252,y:560,t:1527019534019};\\\", \\\"{x:1253,y:560,t:1527019534074};\\\", \\\"{x:1254,y:560,t:1527019534105};\\\", \\\"{x:1256,y:560,t:1527019534121};\\\", \\\"{x:1258,y:560,t:1527019534136};\\\", \\\"{x:1261,y:560,t:1527019534154};\\\", \\\"{x:1263,y:560,t:1527019534170};\\\", \\\"{x:1265,y:561,t:1527019534187};\\\", \\\"{x:1266,y:562,t:1527019534203};\\\", \\\"{x:1267,y:563,t:1527019534220};\\\", \\\"{x:1268,y:564,t:1527019534250};\\\", \\\"{x:1268,y:565,t:1527019534434};\\\", \\\"{x:1269,y:565,t:1527019534457};\\\", \\\"{x:1269,y:566,t:1527019534474};\\\", \\\"{x:1269,y:567,t:1527019534546};\\\", \\\"{x:1270,y:568,t:1527019534658};\\\", \\\"{x:1270,y:569,t:1527019535346};\\\", \\\"{x:1270,y:570,t:1527019535353};\\\", \\\"{x:1271,y:574,t:1527019535369};\\\", \\\"{x:1272,y:579,t:1527019535386};\\\", \\\"{x:1275,y:585,t:1527019535403};\\\", \\\"{x:1278,y:593,t:1527019535419};\\\", \\\"{x:1283,y:604,t:1527019535437};\\\", \\\"{x:1287,y:613,t:1527019535452};\\\", \\\"{x:1290,y:626,t:1527019535470};\\\", \\\"{x:1292,y:638,t:1527019535487};\\\", \\\"{x:1294,y:656,t:1527019535502};\\\", \\\"{x:1299,y:674,t:1527019535520};\\\", \\\"{x:1299,y:688,t:1527019535536};\\\", \\\"{x:1299,y:703,t:1527019535553};\\\", \\\"{x:1300,y:736,t:1527019535570};\\\", \\\"{x:1300,y:760,t:1527019535585};\\\", \\\"{x:1302,y:782,t:1527019535603};\\\", \\\"{x:1302,y:804,t:1527019535620};\\\", \\\"{x:1303,y:830,t:1527019535636};\\\", \\\"{x:1303,y:858,t:1527019535653};\\\", \\\"{x:1303,y:879,t:1527019535670};\\\", \\\"{x:1303,y:898,t:1527019535685};\\\", \\\"{x:1303,y:917,t:1527019535702};\\\", \\\"{x:1303,y:930,t:1527019535719};\\\", \\\"{x:1303,y:940,t:1527019535735};\\\", \\\"{x:1302,y:947,t:1527019535751};\\\", \\\"{x:1302,y:949,t:1527019535768};\\\", \\\"{x:1301,y:952,t:1527019535785};\\\", \\\"{x:1300,y:955,t:1527019535802};\\\", \\\"{x:1299,y:956,t:1527019535819};\\\", \\\"{x:1299,y:957,t:1527019535849};\\\", \\\"{x:1298,y:958,t:1527019535881};\\\", \\\"{x:1297,y:959,t:1527019535939};\\\", \\\"{x:1296,y:959,t:1527019535960};\\\", \\\"{x:1295,y:960,t:1527019535976};\\\", \\\"{x:1294,y:961,t:1527019535984};\\\", \\\"{x:1293,y:962,t:1527019536001};\\\", \\\"{x:1291,y:964,t:1527019536049};\\\", \\\"{x:1290,y:964,t:1527019536097};\\\", \\\"{x:1289,y:964,t:1527019536145};\\\", \\\"{x:1288,y:964,t:1527019536233};\\\", \\\"{x:1288,y:965,t:1527019536306};\\\", \\\"{x:1287,y:965,t:1527019536922};\\\", \\\"{x:1285,y:965,t:1527019536937};\\\", \\\"{x:1284,y:965,t:1527019536961};\\\", \\\"{x:1283,y:965,t:1527019536969};\\\", \\\"{x:1282,y:965,t:1527019536987};\\\", \\\"{x:1281,y:965,t:1527019537674};\\\", \\\"{x:1280,y:965,t:1527019537770};\\\", \\\"{x:1280,y:964,t:1527019538154};\\\", \\\"{x:1280,y:963,t:1527019538169};\\\", \\\"{x:1280,y:961,t:1527019538184};\\\", \\\"{x:1280,y:958,t:1527019538202};\\\", \\\"{x:1281,y:955,t:1527019538218};\\\", \\\"{x:1282,y:953,t:1527019538234};\\\", \\\"{x:1282,y:952,t:1527019538252};\\\", \\\"{x:1283,y:951,t:1527019538269};\\\", \\\"{x:1284,y:949,t:1527019538284};\\\", \\\"{x:1285,y:947,t:1527019538301};\\\", \\\"{x:1286,y:944,t:1527019538319};\\\", \\\"{x:1288,y:940,t:1527019538335};\\\", \\\"{x:1289,y:937,t:1527019538351};\\\", \\\"{x:1291,y:932,t:1527019538368};\\\", \\\"{x:1293,y:927,t:1527019538385};\\\", \\\"{x:1297,y:918,t:1527019538402};\\\", \\\"{x:1299,y:915,t:1527019538418};\\\", \\\"{x:1301,y:909,t:1527019538435};\\\", \\\"{x:1303,y:898,t:1527019538452};\\\", \\\"{x:1305,y:891,t:1527019538467};\\\", \\\"{x:1308,y:884,t:1527019538485};\\\", \\\"{x:1309,y:877,t:1527019538501};\\\", \\\"{x:1313,y:870,t:1527019538518};\\\", \\\"{x:1314,y:864,t:1527019538534};\\\", \\\"{x:1317,y:853,t:1527019538551};\\\", \\\"{x:1321,y:840,t:1527019538568};\\\", \\\"{x:1323,y:830,t:1527019538584};\\\", \\\"{x:1328,y:821,t:1527019538601};\\\", \\\"{x:1330,y:816,t:1527019538618};\\\", \\\"{x:1331,y:812,t:1527019538634};\\\", \\\"{x:1332,y:806,t:1527019538651};\\\", \\\"{x:1335,y:802,t:1527019538668};\\\", \\\"{x:1336,y:799,t:1527019538685};\\\", \\\"{x:1339,y:796,t:1527019538701};\\\", \\\"{x:1342,y:792,t:1527019538717};\\\", \\\"{x:1345,y:790,t:1527019538734};\\\", \\\"{x:1347,y:788,t:1527019538752};\\\", \\\"{x:1349,y:787,t:1527019538767};\\\", \\\"{x:1351,y:786,t:1527019538784};\\\", \\\"{x:1354,y:784,t:1527019538800};\\\", \\\"{x:1355,y:783,t:1527019538818};\\\", \\\"{x:1356,y:783,t:1527019538835};\\\", \\\"{x:1358,y:781,t:1527019538851};\\\", \\\"{x:1361,y:781,t:1527019538867};\\\", \\\"{x:1362,y:780,t:1527019538884};\\\", \\\"{x:1364,y:780,t:1527019538921};\\\", \\\"{x:1365,y:778,t:1527019538935};\\\", \\\"{x:1367,y:777,t:1527019538961};\\\", \\\"{x:1368,y:777,t:1527019538985};\\\", \\\"{x:1369,y:776,t:1527019539001};\\\", \\\"{x:1371,y:775,t:1527019539201};\\\", \\\"{x:1371,y:774,t:1527019539218};\\\", \\\"{x:1372,y:774,t:1527019539258};\\\", \\\"{x:1372,y:772,t:1527019539297};\\\", \\\"{x:1373,y:772,t:1527019539722};\\\", \\\"{x:1374,y:771,t:1527019539734};\\\", \\\"{x:1375,y:770,t:1527019540090};\\\", \\\"{x:1375,y:769,t:1527019540105};\\\", \\\"{x:1375,y:770,t:1527019540777};\\\", \\\"{x:1368,y:774,t:1527019540786};\\\", \\\"{x:1357,y:774,t:1527019540801};\\\", \\\"{x:1267,y:776,t:1527019540817};\\\", \\\"{x:1164,y:776,t:1527019540834};\\\", \\\"{x:1042,y:776,t:1527019540851};\\\", \\\"{x:916,y:768,t:1527019540866};\\\", \\\"{x:794,y:747,t:1527019540884};\\\", \\\"{x:696,y:730,t:1527019540900};\\\", \\\"{x:623,y:718,t:1527019540916};\\\", \\\"{x:559,y:701,t:1527019540934};\\\", \\\"{x:527,y:689,t:1527019540950};\\\", \\\"{x:502,y:676,t:1527019540968};\\\", \\\"{x:449,y:654,t:1527019540984};\\\", \\\"{x:422,y:644,t:1527019541002};\\\", \\\"{x:396,y:633,t:1527019541018};\\\", \\\"{x:358,y:621,t:1527019541035};\\\", \\\"{x:328,y:612,t:1527019541051};\\\", \\\"{x:301,y:602,t:1527019541068};\\\", \\\"{x:280,y:595,t:1527019541084};\\\", \\\"{x:270,y:590,t:1527019541102};\\\", \\\"{x:268,y:590,t:1527019541118};\\\", \\\"{x:268,y:589,t:1527019541134};\\\", \\\"{x:268,y:588,t:1527019541160};\\\", \\\"{x:271,y:588,t:1527019541168};\\\", \\\"{x:271,y:586,t:1527019541184};\\\", \\\"{x:273,y:583,t:1527019541201};\\\", \\\"{x:280,y:579,t:1527019541219};\\\", \\\"{x:298,y:575,t:1527019541235};\\\", \\\"{x:313,y:568,t:1527019541252};\\\", \\\"{x:324,y:563,t:1527019541268};\\\", \\\"{x:331,y:560,t:1527019541285};\\\", \\\"{x:334,y:559,t:1527019541301};\\\", \\\"{x:336,y:558,t:1527019541318};\\\", \\\"{x:338,y:558,t:1527019541335};\\\", \\\"{x:341,y:558,t:1527019541352};\\\", \\\"{x:350,y:555,t:1527019541368};\\\", \\\"{x:356,y:552,t:1527019541385};\\\", \\\"{x:357,y:551,t:1527019541402};\\\", \\\"{x:359,y:551,t:1527019541418};\\\", \\\"{x:360,y:551,t:1527019541497};\\\", \\\"{x:361,y:551,t:1527019541512};\\\", \\\"{x:363,y:551,t:1527019541521};\\\", \\\"{x:364,y:551,t:1527019541536};\\\", \\\"{x:369,y:551,t:1527019541552};\\\", \\\"{x:380,y:552,t:1527019541569};\\\", \\\"{x:384,y:553,t:1527019541585};\\\", \\\"{x:385,y:553,t:1527019541602};\\\", \\\"{x:386,y:554,t:1527019541880};\\\", \\\"{x:387,y:555,t:1527019541888};\\\", \\\"{x:387,y:556,t:1527019541902};\\\", \\\"{x:387,y:561,t:1527019541919};\\\", \\\"{x:390,y:568,t:1527019541934};\\\", \\\"{x:394,y:579,t:1527019541952};\\\", \\\"{x:399,y:587,t:1527019541969};\\\", \\\"{x:404,y:595,t:1527019541985};\\\", \\\"{x:411,y:605,t:1527019542002};\\\", \\\"{x:419,y:616,t:1527019542019};\\\", \\\"{x:428,y:632,t:1527019542036};\\\", \\\"{x:440,y:647,t:1527019542052};\\\", \\\"{x:452,y:664,t:1527019542070};\\\", \\\"{x:464,y:681,t:1527019542085};\\\", \\\"{x:480,y:701,t:1527019542103};\\\", \\\"{x:494,y:722,t:1527019542119};\\\", \\\"{x:509,y:743,t:1527019542135};\\\", \\\"{x:525,y:762,t:1527019542152};\\\", \\\"{x:536,y:771,t:1527019542169};\\\", \\\"{x:541,y:775,t:1527019542185};\\\", \\\"{x:544,y:778,t:1527019542202};\\\", \\\"{x:546,y:779,t:1527019542219};\\\", \\\"{x:547,y:779,t:1527019542474};\\\", \\\"{x:553,y:779,t:1527019542486};\\\", \\\"{x:574,y:785,t:1527019542502};\\\", \\\"{x:599,y:788,t:1527019542519};\\\", \\\"{x:660,y:798,t:1527019542536};\\\", \\\"{x:721,y:806,t:1527019542552};\\\", \\\"{x:788,y:815,t:1527019542569};\\\", \\\"{x:831,y:824,t:1527019542587};\\\", \\\"{x:872,y:829,t:1527019542602};\\\", \\\"{x:891,y:832,t:1527019542620};\\\", \\\"{x:917,y:840,t:1527019542636};\\\", \\\"{x:936,y:846,t:1527019542653};\\\", \\\"{x:956,y:851,t:1527019542670};\\\", \\\"{x:965,y:853,t:1527019542686};\\\", \\\"{x:978,y:857,t:1527019542702};\\\", \\\"{x:998,y:863,t:1527019542720};\\\", \\\"{x:1015,y:868,t:1527019542737};\\\", \\\"{x:1026,y:871,t:1527019542752};\\\", \\\"{x:1034,y:872,t:1527019542769};\\\", \\\"{x:1036,y:872,t:1527019542787};\\\", \\\"{x:1038,y:873,t:1527019542803};\\\", \\\"{x:1048,y:873,t:1527019542820};\\\", \\\"{x:1068,y:874,t:1527019542837};\\\", \\\"{x:1103,y:877,t:1527019542853};\\\", \\\"{x:1163,y:880,t:1527019542870};\\\", \\\"{x:1224,y:880,t:1527019542886};\\\", \\\"{x:1291,y:880,t:1527019542903};\\\", \\\"{x:1329,y:887,t:1527019542920};\\\", \\\"{x:1370,y:896,t:1527019542937};\\\", \\\"{x:1384,y:901,t:1527019542953};\\\", \\\"{x:1386,y:901,t:1527019542970};\\\", \\\"{x:1387,y:901,t:1527019542993};\\\", \\\"{x:1387,y:902,t:1527019543034};\\\", \\\"{x:1387,y:903,t:1527019543042};\\\", \\\"{x:1387,y:904,t:1527019543054};\\\", \\\"{x:1387,y:906,t:1527019543070};\\\", \\\"{x:1387,y:910,t:1527019543087};\\\", \\\"{x:1383,y:914,t:1527019543103};\\\", \\\"{x:1364,y:919,t:1527019543119};\\\", \\\"{x:1327,y:927,t:1527019543136};\\\", \\\"{x:1300,y:932,t:1527019543153};\\\", \\\"{x:1281,y:935,t:1527019543170};\\\", \\\"{x:1268,y:939,t:1527019543186};\\\", \\\"{x:1265,y:939,t:1527019543203};\\\", \\\"{x:1265,y:940,t:1527019543219};\\\", \\\"{x:1264,y:941,t:1527019543265};\\\", \\\"{x:1264,y:942,t:1527019543281};\\\", \\\"{x:1264,y:943,t:1527019543305};\\\", \\\"{x:1264,y:944,t:1527019543319};\\\", \\\"{x:1264,y:945,t:1527019543336};\\\", \\\"{x:1265,y:947,t:1527019543353};\\\", \\\"{x:1268,y:950,t:1527019543370};\\\", \\\"{x:1272,y:954,t:1527019543386};\\\", \\\"{x:1274,y:959,t:1527019543403};\\\", \\\"{x:1276,y:961,t:1527019543420};\\\", \\\"{x:1278,y:962,t:1527019543437};\\\", \\\"{x:1278,y:963,t:1527019543453};\\\", \\\"{x:1279,y:964,t:1527019543470};\\\", \\\"{x:1279,y:965,t:1527019543486};\\\", \\\"{x:1280,y:966,t:1527019543504};\\\", \\\"{x:1281,y:966,t:1527019543520};\\\", \\\"{x:1281,y:965,t:1527019543602};\\\", \\\"{x:1280,y:963,t:1527019543617};\\\", \\\"{x:1278,y:960,t:1527019543626};\\\", \\\"{x:1276,y:957,t:1527019543637};\\\", \\\"{x:1271,y:950,t:1527019543654};\\\", \\\"{x:1263,y:943,t:1527019543670};\\\", \\\"{x:1254,y:937,t:1527019543687};\\\", \\\"{x:1246,y:929,t:1527019543703};\\\", \\\"{x:1240,y:923,t:1527019543721};\\\", \\\"{x:1238,y:919,t:1527019543736};\\\", \\\"{x:1233,y:913,t:1527019543753};\\\", \\\"{x:1232,y:907,t:1527019543770};\\\", \\\"{x:1231,y:902,t:1527019543786};\\\", \\\"{x:1229,y:897,t:1527019543803};\\\", \\\"{x:1227,y:893,t:1527019543820};\\\", \\\"{x:1225,y:888,t:1527019543837};\\\", \\\"{x:1223,y:883,t:1527019543854};\\\", \\\"{x:1222,y:878,t:1527019543871};\\\", \\\"{x:1220,y:871,t:1527019543887};\\\", \\\"{x:1216,y:864,t:1527019543903};\\\", \\\"{x:1213,y:858,t:1527019543921};\\\", \\\"{x:1212,y:855,t:1527019543937};\\\", \\\"{x:1211,y:852,t:1527019543953};\\\", \\\"{x:1211,y:851,t:1527019543970};\\\", \\\"{x:1209,y:848,t:1527019543987};\\\", \\\"{x:1209,y:846,t:1527019544003};\\\", \\\"{x:1206,y:844,t:1527019544021};\\\", \\\"{x:1206,y:841,t:1527019544037};\\\", \\\"{x:1205,y:839,t:1527019544054};\\\", \\\"{x:1204,y:837,t:1527019544070};\\\", \\\"{x:1204,y:836,t:1527019544087};\\\", \\\"{x:1203,y:835,t:1527019544103};\\\", \\\"{x:1202,y:833,t:1527019544121};\\\", \\\"{x:1202,y:832,t:1527019544138};\\\", \\\"{x:1202,y:831,t:1527019544169};\\\", \\\"{x:1202,y:830,t:1527019545866};\\\", \\\"{x:1202,y:831,t:1527019546666};\\\", \\\"{x:1202,y:832,t:1527019546698};\\\", \\\"{x:1202,y:834,t:1527019546770};\\\", \\\"{x:1202,y:835,t:1527019546785};\\\", \\\"{x:1202,y:836,t:1527019546793};\\\", \\\"{x:1202,y:837,t:1527019546806};\\\", \\\"{x:1202,y:840,t:1527019546823};\\\", \\\"{x:1202,y:842,t:1527019546840};\\\", \\\"{x:1201,y:848,t:1527019546856};\\\", \\\"{x:1198,y:859,t:1527019546874};\\\", \\\"{x:1196,y:868,t:1527019546889};\\\", \\\"{x:1192,y:877,t:1527019546906};\\\", \\\"{x:1188,y:889,t:1527019546923};\\\", \\\"{x:1186,y:895,t:1527019546940};\\\", \\\"{x:1184,y:904,t:1527019546956};\\\", \\\"{x:1179,y:912,t:1527019546973};\\\", \\\"{x:1179,y:916,t:1527019546990};\\\", \\\"{x:1176,y:922,t:1527019547006};\\\", \\\"{x:1171,y:930,t:1527019547023};\\\", \\\"{x:1169,y:937,t:1527019547040};\\\", \\\"{x:1167,y:942,t:1527019547056};\\\", \\\"{x:1166,y:947,t:1527019547073};\\\", \\\"{x:1166,y:948,t:1527019547090};\\\", \\\"{x:1166,y:947,t:1527019547184};\\\", \\\"{x:1167,y:942,t:1527019547192};\\\", \\\"{x:1168,y:936,t:1527019547206};\\\", \\\"{x:1174,y:919,t:1527019547222};\\\", \\\"{x:1182,y:900,t:1527019547240};\\\", \\\"{x:1192,y:875,t:1527019547256};\\\", \\\"{x:1199,y:859,t:1527019547273};\\\", \\\"{x:1202,y:849,t:1527019547290};\\\", \\\"{x:1204,y:842,t:1527019547307};\\\", \\\"{x:1205,y:838,t:1527019547322};\\\", \\\"{x:1205,y:837,t:1527019547340};\\\", \\\"{x:1205,y:836,t:1527019547356};\\\", \\\"{x:1205,y:835,t:1527019547434};\\\", \\\"{x:1205,y:834,t:1527019547449};\\\", \\\"{x:1207,y:832,t:1527019547465};\\\", \\\"{x:1207,y:831,t:1527019547473};\\\", \\\"{x:1208,y:830,t:1527019547490};\\\", \\\"{x:1209,y:828,t:1527019547510};\\\", \\\"{x:1211,y:827,t:1527019547522};\\\", \\\"{x:1213,y:827,t:1527019547539};\\\", \\\"{x:1214,y:826,t:1527019547556};\\\", \\\"{x:1216,y:826,t:1527019547664};\\\", \\\"{x:1218,y:830,t:1527019547673};\\\", \\\"{x:1220,y:836,t:1527019547690};\\\", \\\"{x:1222,y:846,t:1527019547706};\\\", \\\"{x:1228,y:860,t:1527019547724};\\\", \\\"{x:1233,y:869,t:1527019547740};\\\", \\\"{x:1236,y:876,t:1527019547756};\\\", \\\"{x:1241,y:884,t:1527019547774};\\\", \\\"{x:1244,y:891,t:1527019547790};\\\", \\\"{x:1245,y:894,t:1527019547807};\\\", \\\"{x:1248,y:899,t:1527019547823};\\\", \\\"{x:1252,y:905,t:1527019547840};\\\", \\\"{x:1257,y:915,t:1527019547856};\\\", \\\"{x:1260,y:920,t:1527019547873};\\\", \\\"{x:1262,y:924,t:1527019547890};\\\", \\\"{x:1265,y:931,t:1527019547907};\\\", \\\"{x:1267,y:936,t:1527019547923};\\\", \\\"{x:1270,y:940,t:1527019547940};\\\", \\\"{x:1270,y:943,t:1527019547957};\\\", \\\"{x:1272,y:945,t:1527019547974};\\\", \\\"{x:1272,y:946,t:1527019547990};\\\", \\\"{x:1272,y:947,t:1527019548007};\\\", \\\"{x:1272,y:948,t:1527019548024};\\\", \\\"{x:1272,y:949,t:1527019548041};\\\", \\\"{x:1273,y:951,t:1527019548089};\\\", \\\"{x:1273,y:952,t:1527019548113};\\\", \\\"{x:1274,y:952,t:1527019548124};\\\", \\\"{x:1275,y:953,t:1527019548141};\\\", \\\"{x:1275,y:954,t:1527019548266};\\\", \\\"{x:1276,y:954,t:1527019548273};\\\", \\\"{x:1277,y:955,t:1527019548290};\\\", \\\"{x:1278,y:956,t:1527019548306};\\\", \\\"{x:1278,y:958,t:1527019548324};\\\", \\\"{x:1279,y:959,t:1527019548352};\\\", \\\"{x:1280,y:960,t:1527019548385};\\\", \\\"{x:1280,y:962,t:1527019548538};\\\", \\\"{x:1281,y:962,t:1527019548666};\\\", \\\"{x:1281,y:961,t:1527019548674};\\\", \\\"{x:1282,y:957,t:1527019548691};\\\", \\\"{x:1284,y:952,t:1527019548708};\\\", \\\"{x:1286,y:948,t:1527019548724};\\\", \\\"{x:1290,y:940,t:1527019548741};\\\", \\\"{x:1296,y:928,t:1527019548758};\\\", \\\"{x:1306,y:915,t:1527019548774};\\\", \\\"{x:1313,y:897,t:1527019548792};\\\", \\\"{x:1320,y:881,t:1527019548808};\\\", \\\"{x:1323,y:865,t:1527019548824};\\\", \\\"{x:1331,y:837,t:1527019548841};\\\", \\\"{x:1334,y:827,t:1527019548858};\\\", \\\"{x:1342,y:809,t:1527019548874};\\\", \\\"{x:1346,y:801,t:1527019548891};\\\", \\\"{x:1346,y:800,t:1527019548909};\\\", \\\"{x:1347,y:798,t:1527019548925};\\\", \\\"{x:1347,y:796,t:1527019548941};\\\", \\\"{x:1348,y:794,t:1527019548957};\\\", \\\"{x:1349,y:793,t:1527019548974};\\\", \\\"{x:1350,y:793,t:1527019549033};\\\", \\\"{x:1350,y:792,t:1527019549040};\\\", \\\"{x:1352,y:791,t:1527019549057};\\\", \\\"{x:1355,y:789,t:1527019549074};\\\", \\\"{x:1358,y:789,t:1527019549091};\\\", \\\"{x:1360,y:787,t:1527019549107};\\\", \\\"{x:1363,y:785,t:1527019549124};\\\", \\\"{x:1366,y:784,t:1527019549140};\\\", \\\"{x:1368,y:781,t:1527019549158};\\\", \\\"{x:1368,y:780,t:1527019549175};\\\", \\\"{x:1370,y:778,t:1527019549190};\\\", \\\"{x:1371,y:776,t:1527019549207};\\\", \\\"{x:1373,y:773,t:1527019549225};\\\", \\\"{x:1374,y:772,t:1527019549241};\\\", \\\"{x:1376,y:772,t:1527019549410};\\\", \\\"{x:1376,y:773,t:1527019549425};\\\", \\\"{x:1377,y:776,t:1527019549441};\\\", \\\"{x:1378,y:780,t:1527019549458};\\\", \\\"{x:1381,y:784,t:1527019549475};\\\", \\\"{x:1384,y:789,t:1527019549491};\\\", \\\"{x:1384,y:793,t:1527019549507};\\\", \\\"{x:1388,y:798,t:1527019549524};\\\", \\\"{x:1388,y:801,t:1527019549542};\\\", \\\"{x:1391,y:806,t:1527019549558};\\\", \\\"{x:1394,y:811,t:1527019549574};\\\", \\\"{x:1397,y:819,t:1527019549591};\\\", \\\"{x:1402,y:826,t:1527019549608};\\\", \\\"{x:1406,y:838,t:1527019549624};\\\", \\\"{x:1408,y:843,t:1527019549642};\\\", \\\"{x:1411,y:848,t:1527019549658};\\\", \\\"{x:1413,y:854,t:1527019549675};\\\", \\\"{x:1417,y:860,t:1527019549692};\\\", \\\"{x:1419,y:864,t:1527019549707};\\\", \\\"{x:1422,y:867,t:1527019549725};\\\", \\\"{x:1422,y:869,t:1527019549741};\\\", \\\"{x:1423,y:871,t:1527019549758};\\\", \\\"{x:1424,y:873,t:1527019549774};\\\", \\\"{x:1424,y:874,t:1527019549792};\\\", \\\"{x:1425,y:876,t:1527019549808};\\\", \\\"{x:1426,y:879,t:1527019549825};\\\", \\\"{x:1427,y:880,t:1527019549842};\\\", \\\"{x:1428,y:881,t:1527019549858};\\\", \\\"{x:1429,y:882,t:1527019549875};\\\", \\\"{x:1430,y:884,t:1527019549892};\\\", \\\"{x:1432,y:885,t:1527019549913};\\\", \\\"{x:1432,y:886,t:1527019549925};\\\", \\\"{x:1433,y:887,t:1527019549942};\\\", \\\"{x:1434,y:889,t:1527019549957};\\\", \\\"{x:1435,y:890,t:1527019549975};\\\", \\\"{x:1436,y:891,t:1527019549991};\\\", \\\"{x:1438,y:892,t:1527019550009};\\\", \\\"{x:1438,y:893,t:1527019550033};\\\", \\\"{x:1439,y:893,t:1527019550049};\\\", \\\"{x:1440,y:894,t:1527019550065};\\\", \\\"{x:1441,y:896,t:1527019550076};\\\", \\\"{x:1442,y:896,t:1527019550093};\\\", \\\"{x:1444,y:897,t:1527019550109};\\\", \\\"{x:1446,y:899,t:1527019550125};\\\", \\\"{x:1446,y:900,t:1527019550142};\\\", \\\"{x:1448,y:903,t:1527019550160};\\\", \\\"{x:1449,y:906,t:1527019550175};\\\", \\\"{x:1451,y:908,t:1527019550193};\\\", \\\"{x:1455,y:913,t:1527019550209};\\\", \\\"{x:1457,y:916,t:1527019550225};\\\", \\\"{x:1458,y:918,t:1527019550242};\\\", \\\"{x:1460,y:920,t:1527019550258};\\\", \\\"{x:1463,y:923,t:1527019550276};\\\", \\\"{x:1464,y:925,t:1527019550292};\\\", \\\"{x:1464,y:926,t:1527019550309};\\\", \\\"{x:1466,y:927,t:1527019550326};\\\", \\\"{x:1467,y:929,t:1527019550342};\\\", \\\"{x:1467,y:931,t:1527019550361};\\\", \\\"{x:1467,y:932,t:1527019550378};\\\", \\\"{x:1467,y:934,t:1527019550392};\\\", \\\"{x:1469,y:935,t:1527019550409};\\\", \\\"{x:1470,y:936,t:1527019550434};\\\", \\\"{x:1470,y:935,t:1527019550921};\\\", \\\"{x:1470,y:932,t:1527019550929};\\\", \\\"{x:1470,y:930,t:1527019550942};\\\", \\\"{x:1469,y:924,t:1527019550958};\\\", \\\"{x:1467,y:920,t:1527019550975};\\\", \\\"{x:1465,y:916,t:1527019550992};\\\", \\\"{x:1462,y:913,t:1527019551008};\\\", \\\"{x:1455,y:911,t:1527019551025};\\\", \\\"{x:1445,y:907,t:1527019551042};\\\", \\\"{x:1417,y:904,t:1527019551059};\\\", \\\"{x:1374,y:902,t:1527019551075};\\\", \\\"{x:1316,y:902,t:1527019551092};\\\", \\\"{x:1222,y:902,t:1527019551109};\\\", \\\"{x:1110,y:900,t:1527019551125};\\\", \\\"{x:1005,y:900,t:1527019551143};\\\", \\\"{x:930,y:900,t:1527019551158};\\\", \\\"{x:852,y:889,t:1527019551175};\\\", \\\"{x:780,y:868,t:1527019551192};\\\", \\\"{x:755,y:857,t:1527019551209};\\\", \\\"{x:739,y:848,t:1527019551226};\\\", \\\"{x:724,y:837,t:1527019551242};\\\", \\\"{x:710,y:824,t:1527019551258};\\\", \\\"{x:692,y:809,t:1527019551275};\\\", \\\"{x:674,y:795,t:1527019551292};\\\", \\\"{x:649,y:782,t:1527019551308};\\\", \\\"{x:623,y:772,t:1527019551325};\\\", \\\"{x:599,y:762,t:1527019551343};\\\", \\\"{x:567,y:752,t:1527019551360};\\\", \\\"{x:546,y:744,t:1527019551377};\\\", \\\"{x:531,y:740,t:1527019551392};\\\", \\\"{x:529,y:739,t:1527019551409};\\\", \\\"{x:528,y:738,t:1527019551425};\\\", \\\"{x:524,y:735,t:1527019551443};\\\", \\\"{x:522,y:733,t:1527019551459};\\\", \\\"{x:522,y:732,t:1527019551475};\\\", \\\"{x:521,y:732,t:1527019551504};\\\", \\\"{x:520,y:730,t:1527019551528};\\\", \\\"{x:520,y:728,t:1527019551544};\\\", \\\"{x:519,y:725,t:1527019551559};\\\", \\\"{x:518,y:724,t:1527019551577};\\\", \\\"{x:517,y:722,t:1527019551592};\\\", \\\"{x:517,y:721,t:1527019551609};\\\", \\\"{x:517,y:720,t:1527019551632};\\\", \\\"{x:517,y:719,t:1527019551848};\\\", \\\"{x:516,y:720,t:1527019551860};\\\", \\\"{x:515,y:729,t:1527019551876};\\\", \\\"{x:514,y:742,t:1527019551893};\\\", \\\"{x:514,y:759,t:1527019551910};\\\", \\\"{x:516,y:781,t:1527019551926};\\\", \\\"{x:528,y:809,t:1527019551944};\\\", \\\"{x:547,y:839,t:1527019551960};\\\", \\\"{x:562,y:856,t:1527019551976};\\\", \\\"{x:579,y:868,t:1527019551993};\\\", \\\"{x:582,y:876,t:1527019552011};\\\" ] }, { \\\"rt\\\": 10638, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 187306, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-D -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:582,y:874,t:1527019553289};\\\", \\\"{x:582,y:872,t:1527019553304};\\\", \\\"{x:582,y:870,t:1527019553337};\\\", \\\"{x:582,y:868,t:1527019553352};\\\", \\\"{x:582,y:866,t:1527019553362};\\\", \\\"{x:582,y:862,t:1527019553377};\\\", \\\"{x:578,y:852,t:1527019553395};\\\", \\\"{x:576,y:843,t:1527019553412};\\\", \\\"{x:571,y:826,t:1527019553427};\\\", \\\"{x:565,y:798,t:1527019553444};\\\", \\\"{x:550,y:755,t:1527019553462};\\\", \\\"{x:537,y:710,t:1527019553478};\\\", \\\"{x:525,y:668,t:1527019553495};\\\", \\\"{x:511,y:635,t:1527019553512};\\\", \\\"{x:462,y:507,t:1527019553632};\\\", \\\"{x:457,y:497,t:1527019553644};\\\", \\\"{x:454,y:487,t:1527019553662};\\\", \\\"{x:452,y:480,t:1527019553678};\\\", \\\"{x:451,y:476,t:1527019553694};\\\", \\\"{x:450,y:473,t:1527019553711};\\\", \\\"{x:450,y:472,t:1527019553930};\\\", \\\"{x:452,y:472,t:1527019553953};\\\", \\\"{x:453,y:472,t:1527019553977};\\\", \\\"{x:458,y:470,t:1527019553995};\\\", \\\"{x:464,y:468,t:1527019554011};\\\", \\\"{x:476,y:463,t:1527019554028};\\\", \\\"{x:484,y:460,t:1527019554044};\\\", \\\"{x:486,y:459,t:1527019554061};\\\", \\\"{x:487,y:459,t:1527019554078};\\\", \\\"{x:489,y:458,t:1527019554094};\\\", \\\"{x:490,y:458,t:1527019554111};\\\", \\\"{x:491,y:458,t:1527019554185};\\\", \\\"{x:493,y:459,t:1527019554337};\\\", \\\"{x:493,y:461,t:1527019554344};\\\", \\\"{x:496,y:463,t:1527019554360};\\\", \\\"{x:496,y:465,t:1527019554377};\\\", \\\"{x:497,y:465,t:1527019554394};\\\", \\\"{x:499,y:466,t:1527019554410};\\\", \\\"{x:499,y:467,t:1527019554427};\\\", \\\"{x:501,y:469,t:1527019554444};\\\", \\\"{x:502,y:470,t:1527019554460};\\\", \\\"{x:504,y:471,t:1527019554477};\\\", \\\"{x:504,y:472,t:1527019554494};\\\", \\\"{x:505,y:473,t:1527019554520};\\\", \\\"{x:506,y:474,t:1527019554561};\\\", \\\"{x:507,y:474,t:1527019554578};\\\", \\\"{x:509,y:474,t:1527019554594};\\\", \\\"{x:513,y:475,t:1527019554611};\\\", \\\"{x:521,y:476,t:1527019554628};\\\", \\\"{x:533,y:478,t:1527019554645};\\\", \\\"{x:545,y:480,t:1527019554660};\\\", \\\"{x:553,y:480,t:1527019554677};\\\", \\\"{x:562,y:480,t:1527019554694};\\\", \\\"{x:566,y:480,t:1527019554710};\\\", \\\"{x:568,y:480,t:1527019554728};\\\", \\\"{x:570,y:480,t:1527019554745};\\\", \\\"{x:571,y:480,t:1527019554760};\\\", \\\"{x:574,y:480,t:1527019554778};\\\", \\\"{x:576,y:480,t:1527019554795};\\\", \\\"{x:578,y:480,t:1527019554811};\\\", \\\"{x:582,y:479,t:1527019554828};\\\", \\\"{x:584,y:479,t:1527019554845};\\\", \\\"{x:585,y:479,t:1527019554861};\\\", \\\"{x:586,y:479,t:1527019554878};\\\", \\\"{x:587,y:479,t:1527019554894};\\\", \\\"{x:588,y:479,t:1527019555049};\\\", \\\"{x:589,y:478,t:1527019555061};\\\", \\\"{x:592,y:478,t:1527019555077};\\\", \\\"{x:598,y:477,t:1527019555094};\\\", \\\"{x:606,y:476,t:1527019555111};\\\", \\\"{x:614,y:475,t:1527019555128};\\\", \\\"{x:629,y:474,t:1527019555144};\\\", \\\"{x:652,y:471,t:1527019555160};\\\", \\\"{x:664,y:470,t:1527019555178};\\\", \\\"{x:673,y:470,t:1527019555193};\\\", \\\"{x:678,y:470,t:1527019555211};\\\", \\\"{x:684,y:470,t:1527019555227};\\\", \\\"{x:689,y:470,t:1527019555243};\\\", \\\"{x:700,y:470,t:1527019555260};\\\", \\\"{x:715,y:470,t:1527019555277};\\\", \\\"{x:739,y:470,t:1527019555294};\\\", \\\"{x:768,y:473,t:1527019555311};\\\", \\\"{x:812,y:485,t:1527019555327};\\\", \\\"{x:854,y:490,t:1527019555344};\\\", \\\"{x:916,y:509,t:1527019555362};\\\", \\\"{x:953,y:520,t:1527019555378};\\\", \\\"{x:986,y:535,t:1527019555394};\\\", \\\"{x:1017,y:552,t:1527019555410};\\\", \\\"{x:1047,y:569,t:1527019555427};\\\", \\\"{x:1074,y:583,t:1527019555443};\\\", \\\"{x:1098,y:597,t:1527019555459};\\\", \\\"{x:1117,y:612,t:1527019555476};\\\", \\\"{x:1132,y:626,t:1527019555494};\\\", \\\"{x:1147,y:642,t:1527019555510};\\\", \\\"{x:1160,y:663,t:1527019555526};\\\", \\\"{x:1172,y:687,t:1527019555544};\\\", \\\"{x:1182,y:710,t:1527019555560};\\\", \\\"{x:1195,y:744,t:1527019555576};\\\", \\\"{x:1200,y:765,t:1527019555594};\\\", \\\"{x:1209,y:792,t:1527019555607};\\\", \\\"{x:1218,y:821,t:1527019555624};\\\", \\\"{x:1225,y:845,t:1527019555641};\\\", \\\"{x:1229,y:870,t:1527019555658};\\\", \\\"{x:1235,y:894,t:1527019555674};\\\", \\\"{x:1242,y:916,t:1527019555691};\\\", \\\"{x:1248,y:934,t:1527019555707};\\\", \\\"{x:1256,y:948,t:1527019555725};\\\", \\\"{x:1260,y:956,t:1527019555741};\\\", \\\"{x:1263,y:960,t:1527019555758};\\\", \\\"{x:1266,y:963,t:1527019555775};\\\", \\\"{x:1267,y:964,t:1527019555792};\\\", \\\"{x:1267,y:965,t:1527019555808};\\\", \\\"{x:1269,y:968,t:1527019555824};\\\", \\\"{x:1270,y:969,t:1527019555841};\\\", \\\"{x:1271,y:969,t:1527019555935};\\\", \\\"{x:1273,y:969,t:1527019555959};\\\", \\\"{x:1277,y:969,t:1527019555974};\\\", \\\"{x:1282,y:969,t:1527019555991};\\\", \\\"{x:1290,y:967,t:1527019556009};\\\", \\\"{x:1304,y:967,t:1527019556025};\\\", \\\"{x:1315,y:967,t:1527019556041};\\\", \\\"{x:1329,y:967,t:1527019556058};\\\", \\\"{x:1337,y:965,t:1527019556075};\\\", \\\"{x:1350,y:962,t:1527019556091};\\\", \\\"{x:1368,y:958,t:1527019556108};\\\", \\\"{x:1381,y:953,t:1527019556125};\\\", \\\"{x:1388,y:950,t:1527019556141};\\\", \\\"{x:1402,y:947,t:1527019556157};\\\", \\\"{x:1408,y:943,t:1527019556174};\\\", \\\"{x:1413,y:939,t:1527019556190};\\\", \\\"{x:1415,y:937,t:1527019556208};\\\", \\\"{x:1419,y:934,t:1527019556225};\\\", \\\"{x:1419,y:933,t:1527019556241};\\\", \\\"{x:1422,y:930,t:1527019556258};\\\", \\\"{x:1423,y:930,t:1527019556273};\\\", \\\"{x:1425,y:929,t:1527019556290};\\\", \\\"{x:1427,y:928,t:1527019556309};\\\", \\\"{x:1428,y:927,t:1527019556323};\\\", \\\"{x:1433,y:924,t:1527019556340};\\\", \\\"{x:1438,y:920,t:1527019556357};\\\", \\\"{x:1445,y:918,t:1527019556373};\\\", \\\"{x:1453,y:913,t:1527019556390};\\\", \\\"{x:1455,y:911,t:1527019556408};\\\", \\\"{x:1456,y:910,t:1527019556423};\\\", \\\"{x:1460,y:907,t:1527019556440};\\\", \\\"{x:1463,y:902,t:1527019556457};\\\", \\\"{x:1467,y:894,t:1527019556474};\\\", \\\"{x:1472,y:888,t:1527019556490};\\\", \\\"{x:1478,y:881,t:1527019556508};\\\", \\\"{x:1482,y:876,t:1527019556523};\\\", \\\"{x:1485,y:873,t:1527019556540};\\\", \\\"{x:1488,y:868,t:1527019556557};\\\", \\\"{x:1493,y:858,t:1527019556574};\\\", \\\"{x:1497,y:849,t:1527019556590};\\\", \\\"{x:1501,y:837,t:1527019556606};\\\", \\\"{x:1505,y:825,t:1527019556623};\\\", \\\"{x:1510,y:813,t:1527019556640};\\\", \\\"{x:1514,y:805,t:1527019556656};\\\", \\\"{x:1517,y:798,t:1527019556673};\\\", \\\"{x:1521,y:785,t:1527019556690};\\\", \\\"{x:1526,y:771,t:1527019556706};\\\", \\\"{x:1531,y:758,t:1527019556724};\\\", \\\"{x:1537,y:743,t:1527019556741};\\\", \\\"{x:1539,y:725,t:1527019556756};\\\", \\\"{x:1541,y:706,t:1527019556774};\\\", \\\"{x:1541,y:677,t:1527019556791};\\\", \\\"{x:1539,y:661,t:1527019556807};\\\", \\\"{x:1539,y:648,t:1527019556824};\\\", \\\"{x:1539,y:636,t:1527019556840};\\\", \\\"{x:1539,y:628,t:1527019556856};\\\", \\\"{x:1537,y:620,t:1527019556874};\\\", \\\"{x:1536,y:615,t:1527019556891};\\\", \\\"{x:1533,y:606,t:1527019556907};\\\", \\\"{x:1530,y:597,t:1527019556923};\\\", \\\"{x:1526,y:589,t:1527019556940};\\\", \\\"{x:1518,y:578,t:1527019556957};\\\", \\\"{x:1511,y:569,t:1527019556973};\\\", \\\"{x:1505,y:564,t:1527019556990};\\\", \\\"{x:1493,y:559,t:1527019557007};\\\", \\\"{x:1488,y:559,t:1527019557024};\\\", \\\"{x:1484,y:557,t:1527019557040};\\\", \\\"{x:1481,y:557,t:1527019557057};\\\", \\\"{x:1478,y:557,t:1527019557073};\\\", \\\"{x:1475,y:557,t:1527019557090};\\\", \\\"{x:1471,y:557,t:1527019557106};\\\", \\\"{x:1469,y:558,t:1527019557124};\\\", \\\"{x:1465,y:560,t:1527019557139};\\\", \\\"{x:1464,y:560,t:1527019557156};\\\", \\\"{x:1462,y:560,t:1527019557174};\\\", \\\"{x:1458,y:562,t:1527019557190};\\\", \\\"{x:1452,y:564,t:1527019557206};\\\", \\\"{x:1443,y:568,t:1527019557223};\\\", \\\"{x:1435,y:569,t:1527019557240};\\\", \\\"{x:1423,y:570,t:1527019557257};\\\", \\\"{x:1416,y:574,t:1527019557273};\\\", \\\"{x:1412,y:575,t:1527019557295};\\\", \\\"{x:1408,y:576,t:1527019557307};\\\", \\\"{x:1401,y:579,t:1527019557324};\\\", \\\"{x:1399,y:580,t:1527019557340};\\\", \\\"{x:1397,y:582,t:1527019557357};\\\", \\\"{x:1395,y:582,t:1527019557373};\\\", \\\"{x:1394,y:584,t:1527019557390};\\\", \\\"{x:1393,y:585,t:1527019557406};\\\", \\\"{x:1391,y:585,t:1527019557558};\\\", \\\"{x:1393,y:585,t:1527019557742};\\\", \\\"{x:1395,y:585,t:1527019557756};\\\", \\\"{x:1397,y:585,t:1527019557772};\\\", \\\"{x:1401,y:585,t:1527019557790};\\\", \\\"{x:1401,y:584,t:1527019557806};\\\", \\\"{x:1403,y:583,t:1527019557879};\\\", \\\"{x:1408,y:577,t:1527019557890};\\\", \\\"{x:1447,y:541,t:1527019557905};\\\", \\\"{x:1524,y:493,t:1527019557923};\\\", \\\"{x:1615,y:437,t:1527019557940};\\\", \\\"{x:1698,y:383,t:1527019557955};\\\", \\\"{x:1753,y:347,t:1527019557973};\\\", \\\"{x:1771,y:331,t:1527019557990};\\\", \\\"{x:1776,y:327,t:1527019558005};\\\", \\\"{x:1776,y:322,t:1527019558022};\\\", \\\"{x:1766,y:315,t:1527019558040};\\\", \\\"{x:1755,y:309,t:1527019558056};\\\", \\\"{x:1751,y:306,t:1527019558073};\\\", \\\"{x:1740,y:295,t:1527019558090};\\\", \\\"{x:1714,y:281,t:1527019558106};\\\", \\\"{x:1674,y:254,t:1527019558123};\\\", \\\"{x:1636,y:230,t:1527019558140};\\\", \\\"{x:1608,y:212,t:1527019558156};\\\", \\\"{x:1577,y:198,t:1527019558173};\\\", \\\"{x:1556,y:188,t:1527019558189};\\\", \\\"{x:1549,y:182,t:1527019558205};\\\", \\\"{x:1547,y:176,t:1527019558222};\\\", \\\"{x:1547,y:175,t:1527019558240};\\\", \\\"{x:1547,y:180,t:1527019558294};\\\", \\\"{x:1547,y:185,t:1527019558305};\\\", \\\"{x:1550,y:206,t:1527019558323};\\\", \\\"{x:1556,y:231,t:1527019558339};\\\", \\\"{x:1561,y:259,t:1527019558355};\\\", \\\"{x:1569,y:287,t:1527019558372};\\\", \\\"{x:1572,y:305,t:1527019558389};\\\", \\\"{x:1577,y:330,t:1527019558406};\\\", \\\"{x:1580,y:345,t:1527019558423};\\\", \\\"{x:1587,y:357,t:1527019558440};\\\", \\\"{x:1589,y:361,t:1527019558456};\\\", \\\"{x:1591,y:363,t:1527019558478};\\\", \\\"{x:1591,y:364,t:1527019558495};\\\", \\\"{x:1593,y:366,t:1527019558510};\\\", \\\"{x:1593,y:367,t:1527019558523};\\\", \\\"{x:1596,y:373,t:1527019558538};\\\", \\\"{x:1598,y:380,t:1527019558556};\\\", \\\"{x:1601,y:386,t:1527019558573};\\\", \\\"{x:1604,y:390,t:1527019558588};\\\", \\\"{x:1608,y:399,t:1527019558605};\\\", \\\"{x:1615,y:413,t:1527019558622};\\\", \\\"{x:1618,y:419,t:1527019558641};\\\", \\\"{x:1623,y:426,t:1527019558656};\\\", \\\"{x:1625,y:428,t:1527019558672};\\\", \\\"{x:1626,y:431,t:1527019558689};\\\", \\\"{x:1626,y:432,t:1527019558706};\\\", \\\"{x:1627,y:432,t:1527019558722};\\\", \\\"{x:1627,y:433,t:1527019558738};\\\", \\\"{x:1627,y:434,t:1527019558823};\\\", \\\"{x:1627,y:435,t:1527019558863};\\\", \\\"{x:1626,y:436,t:1527019558887};\\\", \\\"{x:1625,y:437,t:1527019558910};\\\", \\\"{x:1625,y:438,t:1527019558927};\\\", \\\"{x:1625,y:439,t:1527019558942};\\\", \\\"{x:1624,y:440,t:1527019558958};\\\", \\\"{x:1623,y:440,t:1527019558982};\\\", \\\"{x:1621,y:442,t:1527019559015};\\\", \\\"{x:1621,y:443,t:1527019559055};\\\", \\\"{x:1619,y:446,t:1527019559073};\\\", \\\"{x:1617,y:450,t:1527019559088};\\\", \\\"{x:1613,y:457,t:1527019559105};\\\", \\\"{x:1609,y:465,t:1527019559121};\\\", \\\"{x:1604,y:474,t:1527019559139};\\\", \\\"{x:1599,y:484,t:1527019559155};\\\", \\\"{x:1592,y:496,t:1527019559172};\\\", \\\"{x:1585,y:507,t:1527019559189};\\\", \\\"{x:1581,y:513,t:1527019559205};\\\", \\\"{x:1577,y:520,t:1527019559222};\\\", \\\"{x:1570,y:532,t:1527019559238};\\\", \\\"{x:1567,y:537,t:1527019559254};\\\", \\\"{x:1563,y:544,t:1527019559272};\\\", \\\"{x:1558,y:551,t:1527019559289};\\\", \\\"{x:1557,y:555,t:1527019559305};\\\", \\\"{x:1554,y:560,t:1527019559322};\\\", \\\"{x:1552,y:561,t:1527019559338};\\\", \\\"{x:1550,y:564,t:1527019559355};\\\", \\\"{x:1548,y:567,t:1527019559372};\\\", \\\"{x:1544,y:571,t:1527019559388};\\\", \\\"{x:1540,y:577,t:1527019559405};\\\", \\\"{x:1538,y:583,t:1527019559423};\\\", \\\"{x:1536,y:586,t:1527019559437};\\\", \\\"{x:1531,y:594,t:1527019559454};\\\", \\\"{x:1527,y:601,t:1527019559472};\\\", \\\"{x:1524,y:611,t:1527019559488};\\\", \\\"{x:1522,y:617,t:1527019559505};\\\", \\\"{x:1521,y:621,t:1527019559522};\\\", \\\"{x:1519,y:624,t:1527019559538};\\\", \\\"{x:1519,y:625,t:1527019559555};\\\", \\\"{x:1518,y:627,t:1527019559574};\\\", \\\"{x:1518,y:628,t:1527019559588};\\\", \\\"{x:1516,y:631,t:1527019559605};\\\", \\\"{x:1516,y:633,t:1527019559621};\\\", \\\"{x:1515,y:636,t:1527019559638};\\\", \\\"{x:1514,y:638,t:1527019559654};\\\", \\\"{x:1513,y:639,t:1527019559671};\\\", \\\"{x:1512,y:643,t:1527019559687};\\\", \\\"{x:1511,y:644,t:1527019559704};\\\", \\\"{x:1510,y:646,t:1527019559722};\\\", \\\"{x:1509,y:649,t:1527019559738};\\\", \\\"{x:1506,y:655,t:1527019559754};\\\", \\\"{x:1504,y:658,t:1527019559771};\\\", \\\"{x:1500,y:667,t:1527019559788};\\\", \\\"{x:1497,y:671,t:1527019559804};\\\", \\\"{x:1493,y:677,t:1527019559821};\\\", \\\"{x:1488,y:684,t:1527019559837};\\\", \\\"{x:1485,y:686,t:1527019559854};\\\", \\\"{x:1484,y:688,t:1527019559870};\\\", \\\"{x:1484,y:689,t:1527019559888};\\\", \\\"{x:1483,y:690,t:1527019559904};\\\", \\\"{x:1482,y:690,t:1527019559966};\\\", \\\"{x:1482,y:692,t:1527019559975};\\\", \\\"{x:1482,y:695,t:1527019559991};\\\", \\\"{x:1482,y:696,t:1527019560005};\\\", \\\"{x:1479,y:702,t:1527019560021};\\\", \\\"{x:1474,y:711,t:1527019560038};\\\", \\\"{x:1469,y:718,t:1527019560054};\\\", \\\"{x:1463,y:729,t:1527019560070};\\\", \\\"{x:1458,y:737,t:1527019560088};\\\", \\\"{x:1451,y:748,t:1527019560105};\\\", \\\"{x:1444,y:761,t:1527019560120};\\\", \\\"{x:1438,y:772,t:1527019560137};\\\", \\\"{x:1433,y:780,t:1527019560154};\\\", \\\"{x:1428,y:788,t:1527019560171};\\\", \\\"{x:1426,y:793,t:1527019560188};\\\", \\\"{x:1422,y:801,t:1527019560204};\\\", \\\"{x:1421,y:804,t:1527019560221};\\\", \\\"{x:1416,y:811,t:1527019560238};\\\", \\\"{x:1408,y:822,t:1527019560254};\\\", \\\"{x:1397,y:838,t:1527019560270};\\\", \\\"{x:1392,y:849,t:1527019560288};\\\", \\\"{x:1388,y:858,t:1527019560304};\\\", \\\"{x:1382,y:873,t:1527019560320};\\\", \\\"{x:1376,y:883,t:1527019560338};\\\", \\\"{x:1369,y:892,t:1527019560354};\\\", \\\"{x:1363,y:896,t:1527019560371};\\\", \\\"{x:1361,y:897,t:1527019560387};\\\", \\\"{x:1358,y:897,t:1527019560403};\\\", \\\"{x:1341,y:888,t:1527019560420};\\\", \\\"{x:1323,y:874,t:1527019560437};\\\", \\\"{x:1284,y:857,t:1527019560454};\\\", \\\"{x:1229,y:826,t:1527019560470};\\\", \\\"{x:1166,y:799,t:1527019560487};\\\", \\\"{x:1100,y:773,t:1527019560504};\\\", \\\"{x:1011,y:743,t:1527019560520};\\\", \\\"{x:915,y:720,t:1527019560537};\\\", \\\"{x:825,y:704,t:1527019560553};\\\", \\\"{x:769,y:697,t:1527019560571};\\\", \\\"{x:735,y:696,t:1527019560586};\\\", \\\"{x:709,y:694,t:1527019560603};\\\", \\\"{x:683,y:694,t:1527019560620};\\\", \\\"{x:664,y:694,t:1527019560637};\\\", \\\"{x:628,y:696,t:1527019560654};\\\", \\\"{x:608,y:698,t:1527019560670};\\\", \\\"{x:582,y:702,t:1527019560686};\\\", \\\"{x:563,y:707,t:1527019560704};\\\", \\\"{x:537,y:710,t:1527019560720};\\\", \\\"{x:512,y:710,t:1527019560737};\\\", \\\"{x:501,y:710,t:1527019560748};\\\", \\\"{x:460,y:693,t:1527019560765};\\\", \\\"{x:437,y:681,t:1527019560781};\\\", \\\"{x:417,y:663,t:1527019560798};\\\", \\\"{x:401,y:643,t:1527019560816};\\\", \\\"{x:389,y:627,t:1527019560832};\\\", \\\"{x:377,y:616,t:1527019560849};\\\", \\\"{x:374,y:612,t:1527019560865};\\\", \\\"{x:372,y:606,t:1527019560881};\\\", \\\"{x:369,y:602,t:1527019560898};\\\", \\\"{x:366,y:595,t:1527019560915};\\\", \\\"{x:364,y:590,t:1527019560931};\\\", \\\"{x:361,y:584,t:1527019560948};\\\", \\\"{x:360,y:582,t:1527019560965};\\\", \\\"{x:360,y:581,t:1527019560982};\\\", \\\"{x:360,y:579,t:1527019560999};\\\", \\\"{x:362,y:573,t:1527019561016};\\\", \\\"{x:362,y:571,t:1527019561031};\\\", \\\"{x:363,y:570,t:1527019561078};\\\", \\\"{x:365,y:570,t:1527019561110};\\\", \\\"{x:366,y:571,t:1527019561118};\\\", \\\"{x:365,y:572,t:1527019561132};\\\", \\\"{x:366,y:573,t:1527019561149};\\\", \\\"{x:371,y:579,t:1527019561166};\\\", \\\"{x:372,y:580,t:1527019561182};\\\", \\\"{x:375,y:582,t:1527019561199};\\\", \\\"{x:375,y:583,t:1527019561245};\\\", \\\"{x:376,y:584,t:1527019561270};\\\", \\\"{x:377,y:585,t:1527019561301};\\\", \\\"{x:378,y:585,t:1527019561315};\\\", \\\"{x:379,y:587,t:1527019561331};\\\", \\\"{x:381,y:590,t:1527019561349};\\\", \\\"{x:385,y:595,t:1527019561365};\\\", \\\"{x:386,y:596,t:1527019561382};\\\", \\\"{x:387,y:597,t:1527019561398};\\\", \\\"{x:387,y:598,t:1527019561462};\\\", \\\"{x:387,y:599,t:1527019561693};\\\", \\\"{x:389,y:601,t:1527019561701};\\\", \\\"{x:390,y:603,t:1527019561715};\\\", \\\"{x:398,y:613,t:1527019561733};\\\", \\\"{x:407,y:626,t:1527019561750};\\\", \\\"{x:415,y:637,t:1527019561766};\\\", \\\"{x:431,y:650,t:1527019561783};\\\", \\\"{x:446,y:660,t:1527019561800};\\\", \\\"{x:460,y:666,t:1527019561815};\\\", \\\"{x:468,y:670,t:1527019561833};\\\", \\\"{x:474,y:674,t:1527019561849};\\\", \\\"{x:479,y:678,t:1527019561865};\\\", \\\"{x:482,y:679,t:1527019561883};\\\", \\\"{x:483,y:680,t:1527019561900};\\\", \\\"{x:484,y:681,t:1527019561933};\\\", \\\"{x:485,y:681,t:1527019561950};\\\", \\\"{x:487,y:681,t:1527019561982};\\\", \\\"{x:489,y:682,t:1527019562014};\\\", \\\"{x:491,y:685,t:1527019562030};\\\", \\\"{x:491,y:686,t:1527019562046};\\\", \\\"{x:492,y:687,t:1527019562061};\\\", \\\"{x:492,y:689,t:1527019562069};\\\", \\\"{x:494,y:691,t:1527019562082};\\\", \\\"{x:496,y:694,t:1527019562099};\\\", \\\"{x:497,y:696,t:1527019562117};\\\", \\\"{x:498,y:698,t:1527019562134};\\\", \\\"{x:498,y:700,t:1527019562149};\\\", \\\"{x:498,y:701,t:1527019562167};\\\", \\\"{x:498,y:702,t:1527019562190};\\\", \\\"{x:498,y:703,t:1527019562199};\\\", \\\"{x:500,y:704,t:1527019562216};\\\", \\\"{x:501,y:706,t:1527019562233};\\\", \\\"{x:502,y:706,t:1527019562249};\\\", \\\"{x:502,y:707,t:1527019562294};\\\", \\\"{x:504,y:707,t:1527019563590};\\\", \\\"{x:504,y:707,t:1527019563679};\\\", \\\"{x:505,y:707,t:1527019563878};\\\", \\\"{x:505,y:708,t:1527019563894};\\\", \\\"{x:505,y:709,t:1527019563910};\\\", \\\"{x:506,y:710,t:1527019563926};\\\", \\\"{x:507,y:710,t:1527019563942};\\\", \\\"{x:508,y:711,t:1527019563951};\\\", \\\"{x:517,y:716,t:1527019563968};\\\", \\\"{x:522,y:719,t:1527019563985};\\\", \\\"{x:530,y:724,t:1527019564001};\\\", \\\"{x:539,y:728,t:1527019564017};\\\", \\\"{x:547,y:730,t:1527019564034};\\\", \\\"{x:552,y:732,t:1527019564050};\\\", \\\"{x:555,y:732,t:1527019564068};\\\", \\\"{x:557,y:732,t:1527019564094};\\\" ] }, { \\\"rt\\\": 11542, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 200116, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:713,t:1527019565370};\\\", \\\"{x:528,y:693,t:1527019565383};\\\", \\\"{x:515,y:667,t:1527019565400};\\\", \\\"{x:506,y:637,t:1527019565418};\\\", \\\"{x:499,y:609,t:1527019565436};\\\", \\\"{x:494,y:580,t:1527019565451};\\\", \\\"{x:491,y:557,t:1527019565469};\\\", \\\"{x:489,y:534,t:1527019565485};\\\", \\\"{x:486,y:523,t:1527019565502};\\\", \\\"{x:485,y:511,t:1527019565518};\\\", \\\"{x:484,y:503,t:1527019565536};\\\", \\\"{x:483,y:496,t:1527019565552};\\\", \\\"{x:481,y:490,t:1527019565568};\\\", \\\"{x:481,y:486,t:1527019565585};\\\", \\\"{x:480,y:481,t:1527019565601};\\\", \\\"{x:479,y:480,t:1527019565621};\\\", \\\"{x:480,y:480,t:1527019565830};\\\", \\\"{x:484,y:480,t:1527019565838};\\\", \\\"{x:488,y:480,t:1527019565852};\\\", \\\"{x:495,y:482,t:1527019565868};\\\", \\\"{x:501,y:483,t:1527019565884};\\\", \\\"{x:507,y:486,t:1527019565901};\\\", \\\"{x:510,y:487,t:1527019565918};\\\", \\\"{x:511,y:488,t:1527019565990};\\\", \\\"{x:512,y:488,t:1527019566006};\\\", \\\"{x:513,y:488,t:1527019566018};\\\", \\\"{x:513,y:486,t:1527019566035};\\\", \\\"{x:513,y:484,t:1527019566052};\\\", \\\"{x:514,y:481,t:1527019566068};\\\", \\\"{x:515,y:479,t:1527019566085};\\\", \\\"{x:516,y:474,t:1527019566102};\\\", \\\"{x:516,y:473,t:1527019566118};\\\", \\\"{x:516,y:472,t:1527019566135};\\\", \\\"{x:517,y:472,t:1527019566246};\\\", \\\"{x:518,y:472,t:1527019566253};\\\", \\\"{x:521,y:472,t:1527019566269};\\\", \\\"{x:523,y:472,t:1527019566284};\\\", \\\"{x:529,y:472,t:1527019566300};\\\", \\\"{x:537,y:472,t:1527019566317};\\\", \\\"{x:540,y:472,t:1527019566334};\\\", \\\"{x:542,y:473,t:1527019566350};\\\", \\\"{x:543,y:473,t:1527019566367};\\\", \\\"{x:545,y:473,t:1527019566838};\\\", \\\"{x:547,y:473,t:1527019566850};\\\", \\\"{x:548,y:473,t:1527019566867};\\\", \\\"{x:553,y:473,t:1527019566884};\\\", \\\"{x:557,y:472,t:1527019566900};\\\", \\\"{x:558,y:472,t:1527019566917};\\\", \\\"{x:560,y:472,t:1527019566933};\\\", \\\"{x:561,y:472,t:1527019566966};\\\", \\\"{x:562,y:472,t:1527019567054};\\\", \\\"{x:563,y:472,t:1527019567239};\\\", \\\"{x:565,y:472,t:1527019567250};\\\", \\\"{x:567,y:472,t:1527019567266};\\\", \\\"{x:568,y:472,t:1527019567294};\\\", \\\"{x:569,y:472,t:1527019567311};\\\", \\\"{x:570,y:473,t:1527019567319};\\\", \\\"{x:571,y:473,t:1527019567343};\\\", \\\"{x:572,y:473,t:1527019567703};\\\", \\\"{x:572,y:474,t:1527019567715};\\\", \\\"{x:569,y:476,t:1527019567732};\\\", \\\"{x:567,y:477,t:1527019567749};\\\", \\\"{x:563,y:480,t:1527019567765};\\\", \\\"{x:554,y:484,t:1527019567782};\\\", \\\"{x:550,y:486,t:1527019567798};\\\", \\\"{x:547,y:487,t:1527019567815};\\\", \\\"{x:548,y:487,t:1527019568094};\\\", \\\"{x:552,y:487,t:1527019568102};\\\", \\\"{x:559,y:488,t:1527019568115};\\\", \\\"{x:584,y:494,t:1527019568132};\\\", \\\"{x:614,y:502,t:1527019568148};\\\", \\\"{x:659,y:517,t:1527019568167};\\\", \\\"{x:701,y:529,t:1527019568181};\\\", \\\"{x:777,y:561,t:1527019568198};\\\", \\\"{x:821,y:581,t:1527019568214};\\\", \\\"{x:879,y:610,t:1527019568237};\\\", \\\"{x:908,y:625,t:1527019568254};\\\", \\\"{x:949,y:643,t:1527019568270};\\\", \\\"{x:981,y:658,t:1527019568287};\\\", \\\"{x:1012,y:675,t:1527019568305};\\\", \\\"{x:1040,y:687,t:1527019568321};\\\", \\\"{x:1057,y:696,t:1527019568337};\\\", \\\"{x:1075,y:706,t:1527019568355};\\\", \\\"{x:1092,y:715,t:1527019568371};\\\", \\\"{x:1107,y:727,t:1527019568388};\\\", \\\"{x:1120,y:737,t:1527019568405};\\\", \\\"{x:1129,y:746,t:1527019568422};\\\", \\\"{x:1135,y:750,t:1527019568439};\\\", \\\"{x:1141,y:756,t:1527019568454};\\\", \\\"{x:1149,y:763,t:1527019568472};\\\", \\\"{x:1151,y:770,t:1527019568488};\\\", \\\"{x:1154,y:779,t:1527019568505};\\\", \\\"{x:1157,y:789,t:1527019568522};\\\", \\\"{x:1161,y:803,t:1527019568539};\\\", \\\"{x:1167,y:816,t:1527019568556};\\\", \\\"{x:1170,y:831,t:1527019568573};\\\", \\\"{x:1176,y:841,t:1527019568588};\\\", \\\"{x:1183,y:858,t:1527019568605};\\\", \\\"{x:1191,y:869,t:1527019568622};\\\", \\\"{x:1195,y:881,t:1527019568639};\\\", \\\"{x:1200,y:892,t:1527019568656};\\\", \\\"{x:1205,y:900,t:1527019568673};\\\", \\\"{x:1212,y:907,t:1527019568690};\\\", \\\"{x:1222,y:913,t:1527019568705};\\\", \\\"{x:1230,y:914,t:1527019568723};\\\", \\\"{x:1234,y:917,t:1527019568740};\\\", \\\"{x:1239,y:917,t:1527019568756};\\\", \\\"{x:1244,y:918,t:1527019568773};\\\", \\\"{x:1256,y:921,t:1527019568790};\\\", \\\"{x:1263,y:922,t:1527019568807};\\\", \\\"{x:1272,y:925,t:1527019568823};\\\", \\\"{x:1283,y:930,t:1527019568840};\\\", \\\"{x:1291,y:931,t:1527019568857};\\\", \\\"{x:1297,y:933,t:1527019568874};\\\", \\\"{x:1301,y:934,t:1527019568890};\\\", \\\"{x:1305,y:936,t:1527019568907};\\\", \\\"{x:1307,y:936,t:1527019568924};\\\", \\\"{x:1308,y:937,t:1527019568941};\\\", \\\"{x:1309,y:940,t:1527019568957};\\\", \\\"{x:1309,y:944,t:1527019568974};\\\", \\\"{x:1309,y:947,t:1527019568992};\\\", \\\"{x:1309,y:950,t:1527019569008};\\\", \\\"{x:1309,y:952,t:1527019569024};\\\", \\\"{x:1307,y:954,t:1527019569041};\\\", \\\"{x:1306,y:956,t:1527019569058};\\\", \\\"{x:1303,y:957,t:1527019569074};\\\", \\\"{x:1303,y:958,t:1527019569091};\\\", \\\"{x:1300,y:959,t:1527019569108};\\\", \\\"{x:1299,y:960,t:1527019569126};\\\", \\\"{x:1298,y:961,t:1527019569141};\\\", \\\"{x:1303,y:959,t:1527019569302};\\\", \\\"{x:1312,y:955,t:1527019569310};\\\", \\\"{x:1321,y:953,t:1527019569325};\\\", \\\"{x:1350,y:949,t:1527019569342};\\\", \\\"{x:1367,y:945,t:1527019569360};\\\", \\\"{x:1386,y:940,t:1527019569376};\\\", \\\"{x:1400,y:938,t:1527019569392};\\\", \\\"{x:1415,y:932,t:1527019569409};\\\", \\\"{x:1431,y:925,t:1527019569426};\\\", \\\"{x:1443,y:918,t:1527019569443};\\\", \\\"{x:1457,y:908,t:1527019569459};\\\", \\\"{x:1472,y:896,t:1527019569476};\\\", \\\"{x:1491,y:881,t:1527019569494};\\\", \\\"{x:1509,y:867,t:1527019569510};\\\", \\\"{x:1524,y:849,t:1527019569526};\\\", \\\"{x:1527,y:832,t:1527019569543};\\\", \\\"{x:1528,y:811,t:1527019569560};\\\", \\\"{x:1532,y:796,t:1527019569576};\\\", \\\"{x:1534,y:791,t:1527019569592};\\\", \\\"{x:1536,y:787,t:1527019569610};\\\", \\\"{x:1537,y:784,t:1527019569627};\\\", \\\"{x:1538,y:778,t:1527019569643};\\\", \\\"{x:1539,y:775,t:1527019569659};\\\", \\\"{x:1539,y:774,t:1527019569677};\\\", \\\"{x:1539,y:772,t:1527019569693};\\\", \\\"{x:1540,y:771,t:1527019569709};\\\", \\\"{x:1541,y:770,t:1527019569726};\\\", \\\"{x:1542,y:770,t:1527019569743};\\\", \\\"{x:1545,y:767,t:1527019569760};\\\", \\\"{x:1547,y:766,t:1527019569777};\\\", \\\"{x:1549,y:763,t:1527019569794};\\\", \\\"{x:1552,y:760,t:1527019569810};\\\", \\\"{x:1556,y:751,t:1527019569827};\\\", \\\"{x:1563,y:733,t:1527019569843};\\\", \\\"{x:1571,y:706,t:1527019569860};\\\", \\\"{x:1574,y:666,t:1527019569877};\\\", \\\"{x:1574,y:643,t:1527019569894};\\\", \\\"{x:1572,y:625,t:1527019569911};\\\", \\\"{x:1567,y:605,t:1527019569928};\\\", \\\"{x:1558,y:586,t:1527019569944};\\\", \\\"{x:1547,y:566,t:1527019569960};\\\", \\\"{x:1530,y:549,t:1527019569977};\\\", \\\"{x:1513,y:537,t:1527019569994};\\\", \\\"{x:1497,y:527,t:1527019570011};\\\", \\\"{x:1484,y:518,t:1527019570027};\\\", \\\"{x:1472,y:514,t:1527019570044};\\\", \\\"{x:1467,y:513,t:1527019570062};\\\", \\\"{x:1466,y:512,t:1527019570118};\\\", \\\"{x:1466,y:511,t:1527019570128};\\\", \\\"{x:1466,y:508,t:1527019570145};\\\", \\\"{x:1468,y:502,t:1527019570162};\\\", \\\"{x:1475,y:492,t:1527019570179};\\\", \\\"{x:1479,y:486,t:1527019570194};\\\", \\\"{x:1483,y:479,t:1527019570211};\\\", \\\"{x:1488,y:473,t:1527019570229};\\\", \\\"{x:1492,y:466,t:1527019570245};\\\", \\\"{x:1496,y:461,t:1527019570262};\\\", \\\"{x:1500,y:459,t:1527019570278};\\\", \\\"{x:1503,y:457,t:1527019570296};\\\", \\\"{x:1504,y:457,t:1527019570313};\\\", \\\"{x:1505,y:456,t:1527019570329};\\\", \\\"{x:1507,y:456,t:1527019570358};\\\", \\\"{x:1508,y:456,t:1527019570374};\\\", \\\"{x:1511,y:456,t:1527019570390};\\\", \\\"{x:1512,y:458,t:1527019570406};\\\", \\\"{x:1516,y:460,t:1527019570413};\\\", \\\"{x:1519,y:463,t:1527019570429};\\\", \\\"{x:1524,y:467,t:1527019570446};\\\", \\\"{x:1529,y:472,t:1527019570463};\\\", \\\"{x:1534,y:477,t:1527019570480};\\\", \\\"{x:1541,y:484,t:1527019570497};\\\", \\\"{x:1551,y:493,t:1527019570513};\\\", \\\"{x:1563,y:504,t:1527019570530};\\\", \\\"{x:1577,y:513,t:1527019570547};\\\", \\\"{x:1589,y:523,t:1527019570563};\\\", \\\"{x:1599,y:528,t:1527019570580};\\\", \\\"{x:1604,y:532,t:1527019570597};\\\", \\\"{x:1605,y:534,t:1527019570615};\\\", \\\"{x:1607,y:537,t:1527019570630};\\\", \\\"{x:1609,y:541,t:1527019570648};\\\", \\\"{x:1610,y:546,t:1527019570664};\\\", \\\"{x:1613,y:561,t:1527019570681};\\\", \\\"{x:1619,y:575,t:1527019570698};\\\", \\\"{x:1621,y:586,t:1527019570714};\\\", \\\"{x:1625,y:596,t:1527019570731};\\\", \\\"{x:1628,y:605,t:1527019570748};\\\", \\\"{x:1631,y:613,t:1527019570764};\\\", \\\"{x:1631,y:619,t:1527019570781};\\\", \\\"{x:1635,y:627,t:1527019570797};\\\", \\\"{x:1636,y:630,t:1527019570814};\\\", \\\"{x:1638,y:636,t:1527019570831};\\\", \\\"{x:1639,y:644,t:1527019570848};\\\", \\\"{x:1642,y:649,t:1527019570865};\\\", \\\"{x:1642,y:652,t:1527019570882};\\\", \\\"{x:1643,y:657,t:1527019570898};\\\", \\\"{x:1644,y:660,t:1527019570916};\\\", \\\"{x:1644,y:668,t:1527019570932};\\\", \\\"{x:1646,y:671,t:1527019570948};\\\", \\\"{x:1645,y:676,t:1527019570965};\\\", \\\"{x:1642,y:682,t:1527019570981};\\\", \\\"{x:1637,y:687,t:1527019570997};\\\", \\\"{x:1630,y:695,t:1527019571014};\\\", \\\"{x:1624,y:700,t:1527019571031};\\\", \\\"{x:1618,y:704,t:1527019571049};\\\", \\\"{x:1612,y:709,t:1527019571064};\\\", \\\"{x:1608,y:712,t:1527019571081};\\\", \\\"{x:1599,y:717,t:1527019571098};\\\", \\\"{x:1586,y:724,t:1527019571115};\\\", \\\"{x:1572,y:731,t:1527019571132};\\\", \\\"{x:1553,y:739,t:1527019571149};\\\", \\\"{x:1534,y:749,t:1527019571166};\\\", \\\"{x:1521,y:752,t:1527019571183};\\\", \\\"{x:1517,y:756,t:1527019571199};\\\", \\\"{x:1503,y:765,t:1527019571216};\\\", \\\"{x:1499,y:769,t:1527019571233};\\\", \\\"{x:1491,y:772,t:1527019571249};\\\", \\\"{x:1487,y:775,t:1527019571266};\\\", \\\"{x:1481,y:777,t:1527019571283};\\\", \\\"{x:1475,y:778,t:1527019571300};\\\", \\\"{x:1473,y:782,t:1527019571316};\\\", \\\"{x:1472,y:782,t:1527019571582};\\\", \\\"{x:1471,y:782,t:1527019571591};\\\", \\\"{x:1468,y:782,t:1527019571614};\\\", \\\"{x:1467,y:782,t:1527019571622};\\\", \\\"{x:1465,y:782,t:1527019571646};\\\", \\\"{x:1463,y:782,t:1527019571655};\\\", \\\"{x:1462,y:782,t:1527019571669};\\\", \\\"{x:1458,y:782,t:1527019571685};\\\", \\\"{x:1456,y:780,t:1527019571701};\\\", \\\"{x:1456,y:779,t:1527019571718};\\\", \\\"{x:1454,y:778,t:1527019571766};\\\", \\\"{x:1454,y:777,t:1527019571782};\\\", \\\"{x:1454,y:774,t:1527019571790};\\\", \\\"{x:1453,y:771,t:1527019571801};\\\", \\\"{x:1450,y:765,t:1527019571818};\\\", \\\"{x:1449,y:760,t:1527019571835};\\\", \\\"{x:1448,y:757,t:1527019571852};\\\", \\\"{x:1446,y:754,t:1527019571868};\\\", \\\"{x:1442,y:752,t:1527019571885};\\\", \\\"{x:1420,y:752,t:1527019571902};\\\", \\\"{x:1389,y:761,t:1527019571919};\\\", \\\"{x:1346,y:782,t:1527019571935};\\\", \\\"{x:1297,y:810,t:1527019571953};\\\", \\\"{x:1268,y:827,t:1527019571969};\\\", \\\"{x:1247,y:840,t:1527019571986};\\\", \\\"{x:1239,y:847,t:1527019572002};\\\", \\\"{x:1237,y:849,t:1527019572019};\\\", \\\"{x:1236,y:850,t:1527019572036};\\\", \\\"{x:1236,y:852,t:1527019572053};\\\", \\\"{x:1236,y:854,t:1527019572069};\\\", \\\"{x:1236,y:857,t:1527019572086};\\\", \\\"{x:1236,y:860,t:1527019572103};\\\", \\\"{x:1236,y:861,t:1527019572120};\\\", \\\"{x:1236,y:863,t:1527019572136};\\\", \\\"{x:1235,y:860,t:1527019572215};\\\", \\\"{x:1234,y:855,t:1527019572222};\\\", \\\"{x:1234,y:850,t:1527019572238};\\\", \\\"{x:1229,y:838,t:1527019572253};\\\", \\\"{x:1226,y:832,t:1527019572270};\\\", \\\"{x:1224,y:830,t:1527019572287};\\\", \\\"{x:1223,y:829,t:1527019572304};\\\", \\\"{x:1221,y:827,t:1527019572321};\\\", \\\"{x:1220,y:827,t:1527019572337};\\\", \\\"{x:1217,y:827,t:1527019572357};\\\", \\\"{x:1216,y:827,t:1527019572370};\\\", \\\"{x:1215,y:827,t:1527019572429};\\\", \\\"{x:1214,y:828,t:1527019572462};\\\", \\\"{x:1214,y:830,t:1527019572471};\\\", \\\"{x:1214,y:831,t:1527019572487};\\\", \\\"{x:1214,y:832,t:1527019572549};\\\", \\\"{x:1214,y:834,t:1527019572565};\\\", \\\"{x:1214,y:835,t:1527019572589};\\\", \\\"{x:1214,y:836,t:1527019572605};\\\", \\\"{x:1214,y:838,t:1527019572620};\\\", \\\"{x:1217,y:843,t:1527019572637};\\\", \\\"{x:1219,y:846,t:1527019572655};\\\", \\\"{x:1221,y:850,t:1527019572671};\\\", \\\"{x:1224,y:855,t:1527019572688};\\\", \\\"{x:1225,y:857,t:1527019572705};\\\", \\\"{x:1228,y:861,t:1527019572722};\\\", \\\"{x:1230,y:866,t:1527019572738};\\\", \\\"{x:1233,y:870,t:1527019572755};\\\", \\\"{x:1237,y:876,t:1527019572772};\\\", \\\"{x:1240,y:882,t:1527019572789};\\\", \\\"{x:1241,y:885,t:1527019572806};\\\", \\\"{x:1244,y:893,t:1527019572822};\\\", \\\"{x:1247,y:898,t:1527019572840};\\\", \\\"{x:1249,y:904,t:1527019572856};\\\", \\\"{x:1252,y:910,t:1527019572872};\\\", \\\"{x:1253,y:915,t:1527019572889};\\\", \\\"{x:1256,y:919,t:1527019572907};\\\", \\\"{x:1259,y:925,t:1527019572922};\\\", \\\"{x:1260,y:927,t:1527019572939};\\\", \\\"{x:1261,y:928,t:1527019572956};\\\", \\\"{x:1261,y:931,t:1527019572973};\\\", \\\"{x:1262,y:932,t:1527019572990};\\\", \\\"{x:1263,y:935,t:1527019573005};\\\", \\\"{x:1266,y:941,t:1527019573023};\\\", \\\"{x:1269,y:947,t:1527019573040};\\\", \\\"{x:1271,y:950,t:1527019573056};\\\", \\\"{x:1273,y:954,t:1527019573073};\\\", \\\"{x:1278,y:958,t:1527019573090};\\\", \\\"{x:1279,y:960,t:1527019573106};\\\", \\\"{x:1279,y:962,t:1527019573123};\\\", \\\"{x:1281,y:964,t:1527019573141};\\\", \\\"{x:1281,y:966,t:1527019573166};\\\", \\\"{x:1283,y:963,t:1527019573479};\\\", \\\"{x:1284,y:962,t:1527019573492};\\\", \\\"{x:1286,y:959,t:1527019573508};\\\", \\\"{x:1287,y:955,t:1527019573525};\\\", \\\"{x:1288,y:953,t:1527019573542};\\\", \\\"{x:1289,y:951,t:1527019573559};\\\", \\\"{x:1291,y:947,t:1527019573575};\\\", \\\"{x:1293,y:942,t:1527019573592};\\\", \\\"{x:1297,y:937,t:1527019573608};\\\", \\\"{x:1302,y:923,t:1527019573624};\\\", \\\"{x:1310,y:911,t:1527019573641};\\\", \\\"{x:1317,y:903,t:1527019573659};\\\", \\\"{x:1327,y:891,t:1527019573675};\\\", \\\"{x:1331,y:880,t:1527019573691};\\\", \\\"{x:1337,y:864,t:1527019573709};\\\", \\\"{x:1348,y:839,t:1527019573725};\\\", \\\"{x:1354,y:826,t:1527019573741};\\\", \\\"{x:1359,y:818,t:1527019573759};\\\", \\\"{x:1360,y:815,t:1527019573776};\\\", \\\"{x:1360,y:813,t:1527019573792};\\\", \\\"{x:1360,y:812,t:1527019573821};\\\", \\\"{x:1361,y:810,t:1527019573829};\\\", \\\"{x:1363,y:808,t:1527019573843};\\\", \\\"{x:1366,y:801,t:1527019573859};\\\", \\\"{x:1369,y:794,t:1527019573876};\\\", \\\"{x:1371,y:791,t:1527019573893};\\\", \\\"{x:1373,y:788,t:1527019573909};\\\", \\\"{x:1374,y:787,t:1527019573926};\\\", \\\"{x:1375,y:785,t:1527019573943};\\\", \\\"{x:1376,y:785,t:1527019573960};\\\", \\\"{x:1377,y:784,t:1527019573976};\\\", \\\"{x:1377,y:783,t:1527019573998};\\\", \\\"{x:1378,y:783,t:1527019574010};\\\", \\\"{x:1378,y:782,t:1527019574027};\\\", \\\"{x:1379,y:782,t:1527019574070};\\\", \\\"{x:1378,y:782,t:1527019574198};\\\", \\\"{x:1366,y:782,t:1527019574212};\\\", \\\"{x:1310,y:776,t:1527019574227};\\\", \\\"{x:1185,y:757,t:1527019574245};\\\", \\\"{x:1075,y:743,t:1527019574261};\\\", \\\"{x:815,y:694,t:1527019574278};\\\", \\\"{x:662,y:665,t:1527019574294};\\\", \\\"{x:538,y:634,t:1527019574312};\\\", \\\"{x:462,y:608,t:1527019574328};\\\", \\\"{x:446,y:603,t:1527019574344};\\\", \\\"{x:445,y:600,t:1527019574359};\\\", \\\"{x:445,y:598,t:1527019574381};\\\", \\\"{x:445,y:596,t:1527019574393};\\\", \\\"{x:447,y:592,t:1527019574408};\\\", \\\"{x:447,y:590,t:1527019574437};\\\", \\\"{x:447,y:586,t:1527019574453};\\\", \\\"{x:443,y:581,t:1527019574462};\\\", \\\"{x:437,y:579,t:1527019574475};\\\", \\\"{x:435,y:578,t:1527019574493};\\\", \\\"{x:434,y:577,t:1527019574582};\\\", \\\"{x:432,y:578,t:1527019574592};\\\", \\\"{x:429,y:581,t:1527019574609};\\\", \\\"{x:422,y:586,t:1527019574625};\\\", \\\"{x:418,y:589,t:1527019574642};\\\", \\\"{x:415,y:590,t:1527019574660};\\\", \\\"{x:411,y:590,t:1527019574676};\\\", \\\"{x:409,y:590,t:1527019574692};\\\", \\\"{x:407,y:589,t:1527019574709};\\\", \\\"{x:404,y:587,t:1527019574726};\\\", \\\"{x:403,y:585,t:1527019574743};\\\", \\\"{x:400,y:582,t:1527019574759};\\\", \\\"{x:398,y:578,t:1527019574776};\\\", \\\"{x:398,y:575,t:1527019574792};\\\", \\\"{x:397,y:574,t:1527019574810};\\\", \\\"{x:396,y:573,t:1527019574825};\\\", \\\"{x:396,y:571,t:1527019574842};\\\", \\\"{x:396,y:569,t:1527019574860};\\\", \\\"{x:395,y:568,t:1527019574876};\\\", \\\"{x:393,y:564,t:1527019574893};\\\", \\\"{x:393,y:563,t:1527019574998};\\\", \\\"{x:393,y:567,t:1527019575437};\\\", \\\"{x:394,y:571,t:1527019575446};\\\", \\\"{x:394,y:574,t:1527019575459};\\\", \\\"{x:398,y:581,t:1527019575477};\\\", \\\"{x:405,y:591,t:1527019575494};\\\", \\\"{x:411,y:597,t:1527019575510};\\\", \\\"{x:421,y:610,t:1527019575527};\\\", \\\"{x:431,y:622,t:1527019575545};\\\", \\\"{x:439,y:633,t:1527019575560};\\\", \\\"{x:444,y:642,t:1527019575577};\\\", \\\"{x:446,y:647,t:1527019575594};\\\", \\\"{x:449,y:651,t:1527019575610};\\\", \\\"{x:451,y:654,t:1527019575626};\\\", \\\"{x:453,y:658,t:1527019575643};\\\", \\\"{x:456,y:662,t:1527019575660};\\\", \\\"{x:462,y:671,t:1527019575677};\\\", \\\"{x:470,y:684,t:1527019575693};\\\", \\\"{x:474,y:689,t:1527019575709};\\\", \\\"{x:478,y:694,t:1527019575727};\\\", \\\"{x:481,y:699,t:1527019575744};\\\", \\\"{x:485,y:703,t:1527019575760};\\\", \\\"{x:489,y:707,t:1527019575776};\\\", \\\"{x:493,y:711,t:1527019575794};\\\", \\\"{x:498,y:715,t:1527019575811};\\\", \\\"{x:503,y:719,t:1527019575826};\\\", \\\"{x:510,y:724,t:1527019575843};\\\", \\\"{x:514,y:727,t:1527019575861};\\\", \\\"{x:517,y:732,t:1527019575877};\\\", \\\"{x:521,y:737,t:1527019575894};\\\", \\\"{x:523,y:741,t:1527019575911};\\\", \\\"{x:523,y:744,t:1527019575926};\\\", \\\"{x:526,y:747,t:1527019575944};\\\", \\\"{x:526,y:748,t:1527019575965};\\\", \\\"{x:526,y:749,t:1527019575989};\\\", \\\"{x:526,y:750,t:1527019576005};\\\", \\\"{x:526,y:751,t:1527019576013};\\\", \\\"{x:526,y:749,t:1527019576134};\\\", \\\"{x:526,y:745,t:1527019576144};\\\", \\\"{x:526,y:742,t:1527019576161};\\\", \\\"{x:526,y:739,t:1527019576177};\\\", \\\"{x:526,y:737,t:1527019576194};\\\", \\\"{x:526,y:735,t:1527019576212};\\\", \\\"{x:526,y:734,t:1527019576228};\\\", \\\"{x:526,y:732,t:1527019576244};\\\", \\\"{x:526,y:731,t:1527019576261};\\\", \\\"{x:526,y:729,t:1527019576277};\\\", \\\"{x:526,y:728,t:1527019576294};\\\", \\\"{x:527,y:728,t:1527019576311};\\\", \\\"{x:527,y:726,t:1527019577262};\\\", \\\"{x:527,y:724,t:1527019577286};\\\", \\\"{x:527,y:723,t:1527019577302};\\\", \\\"{x:527,y:722,t:1527019577317};\\\", \\\"{x:527,y:721,t:1527019577334};\\\", \\\"{x:527,y:720,t:1527019577345};\\\", \\\"{x:527,y:719,t:1527019577374};\\\", \\\"{x:527,y:717,t:1527019577406};\\\", \\\"{x:527,y:716,t:1527019577414};\\\" ] }, { \\\"rt\\\": 6292, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 207635, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:715,t:1527019577901};\\\", \\\"{x:528,y:713,t:1527019577916};\\\", \\\"{x:528,y:712,t:1527019578038};\\\", \\\"{x:528,y:709,t:1527019578047};\\\", \\\"{x:531,y:699,t:1527019578064};\\\", \\\"{x:531,y:676,t:1527019578080};\\\", \\\"{x:527,y:509,t:1527019578179};\\\", \\\"{x:525,y:503,t:1527019578196};\\\", \\\"{x:524,y:496,t:1527019578211};\\\", \\\"{x:523,y:491,t:1527019578228};\\\", \\\"{x:523,y:489,t:1527019578245};\\\", \\\"{x:522,y:486,t:1527019578262};\\\", \\\"{x:521,y:485,t:1527019578278};\\\", \\\"{x:520,y:484,t:1527019578295};\\\", \\\"{x:518,y:483,t:1527019578311};\\\", \\\"{x:518,y:482,t:1527019578329};\\\", \\\"{x:517,y:482,t:1527019578345};\\\", \\\"{x:516,y:481,t:1527019578361};\\\", \\\"{x:515,y:481,t:1527019578397};\\\", \\\"{x:515,y:479,t:1527019578478};\\\", \\\"{x:516,y:478,t:1527019578496};\\\", \\\"{x:523,y:478,t:1527019578513};\\\", \\\"{x:537,y:477,t:1527019578529};\\\", \\\"{x:557,y:477,t:1527019578546};\\\", \\\"{x:576,y:478,t:1527019578563};\\\", \\\"{x:595,y:480,t:1527019578579};\\\", \\\"{x:610,y:481,t:1527019578596};\\\", \\\"{x:615,y:481,t:1527019578613};\\\", \\\"{x:617,y:481,t:1527019578694};\\\", \\\"{x:619,y:481,t:1527019578798};\\\", \\\"{x:621,y:481,t:1527019578814};\\\", \\\"{x:622,y:481,t:1527019578830};\\\", \\\"{x:624,y:481,t:1527019578846};\\\", \\\"{x:632,y:481,t:1527019578863};\\\", \\\"{x:649,y:485,t:1527019578879};\\\", \\\"{x:676,y:490,t:1527019578896};\\\", \\\"{x:715,y:500,t:1527019578913};\\\", \\\"{x:777,y:513,t:1527019578931};\\\", \\\"{x:857,y:534,t:1527019578945};\\\", \\\"{x:948,y:553,t:1527019578963};\\\", \\\"{x:1033,y:576,t:1527019578979};\\\", \\\"{x:1112,y:602,t:1527019578995};\\\", \\\"{x:1229,y:637,t:1527019579013};\\\", \\\"{x:1292,y:666,t:1527019579030};\\\", \\\"{x:1336,y:682,t:1527019579045};\\\", \\\"{x:1374,y:700,t:1527019579063};\\\", \\\"{x:1393,y:711,t:1527019579080};\\\", \\\"{x:1413,y:723,t:1527019579096};\\\", \\\"{x:1429,y:735,t:1527019579112};\\\", \\\"{x:1444,y:743,t:1527019579130};\\\", \\\"{x:1462,y:753,t:1527019579146};\\\", \\\"{x:1483,y:764,t:1527019579163};\\\", \\\"{x:1507,y:777,t:1527019579181};\\\", \\\"{x:1541,y:796,t:1527019579198};\\\", \\\"{x:1549,y:801,t:1527019579213};\\\", \\\"{x:1580,y:821,t:1527019579230};\\\", \\\"{x:1601,y:839,t:1527019579248};\\\", \\\"{x:1620,y:853,t:1527019579264};\\\", \\\"{x:1642,y:866,t:1527019579280};\\\", \\\"{x:1661,y:876,t:1527019579297};\\\", \\\"{x:1677,y:888,t:1527019579313};\\\", \\\"{x:1695,y:902,t:1527019579330};\\\", \\\"{x:1709,y:912,t:1527019579347};\\\", \\\"{x:1712,y:915,t:1527019579363};\\\", \\\"{x:1712,y:916,t:1527019579380};\\\", \\\"{x:1712,y:920,t:1527019579398};\\\", \\\"{x:1711,y:923,t:1527019579413};\\\", \\\"{x:1707,y:929,t:1527019579431};\\\", \\\"{x:1704,y:930,t:1527019579447};\\\", \\\"{x:1702,y:931,t:1527019579464};\\\", \\\"{x:1702,y:932,t:1527019579480};\\\", \\\"{x:1702,y:933,t:1527019579497};\\\", \\\"{x:1700,y:934,t:1527019579513};\\\", \\\"{x:1698,y:938,t:1527019579530};\\\", \\\"{x:1690,y:943,t:1527019579548};\\\", \\\"{x:1682,y:948,t:1527019579563};\\\", \\\"{x:1674,y:952,t:1527019579580};\\\", \\\"{x:1658,y:957,t:1527019579597};\\\", \\\"{x:1648,y:959,t:1527019579614};\\\", \\\"{x:1639,y:960,t:1527019579630};\\\", \\\"{x:1634,y:961,t:1527019579647};\\\", \\\"{x:1629,y:961,t:1527019579664};\\\", \\\"{x:1623,y:961,t:1527019579680};\\\", \\\"{x:1619,y:961,t:1527019579697};\\\", \\\"{x:1617,y:962,t:1527019579714};\\\", \\\"{x:1615,y:963,t:1527019579730};\\\", \\\"{x:1614,y:963,t:1527019579748};\\\", \\\"{x:1614,y:964,t:1527019579998};\\\", \\\"{x:1612,y:964,t:1527019580630};\\\", \\\"{x:1610,y:962,t:1527019580648};\\\", \\\"{x:1609,y:959,t:1527019580665};\\\", \\\"{x:1607,y:956,t:1527019580682};\\\", \\\"{x:1606,y:954,t:1527019580698};\\\", \\\"{x:1603,y:950,t:1527019580714};\\\", \\\"{x:1600,y:945,t:1527019580731};\\\", \\\"{x:1596,y:939,t:1527019580749};\\\", \\\"{x:1593,y:935,t:1527019580764};\\\", \\\"{x:1588,y:929,t:1527019580782};\\\", \\\"{x:1586,y:926,t:1527019580798};\\\", \\\"{x:1584,y:922,t:1527019580814};\\\", \\\"{x:1579,y:914,t:1527019580832};\\\", \\\"{x:1574,y:903,t:1527019580848};\\\", \\\"{x:1564,y:888,t:1527019580865};\\\", \\\"{x:1557,y:876,t:1527019580881};\\\", \\\"{x:1552,y:867,t:1527019580898};\\\", \\\"{x:1547,y:857,t:1527019580914};\\\", \\\"{x:1545,y:851,t:1527019580931};\\\", \\\"{x:1542,y:844,t:1527019580948};\\\", \\\"{x:1539,y:837,t:1527019580965};\\\", \\\"{x:1536,y:831,t:1527019580981};\\\", \\\"{x:1534,y:826,t:1527019580998};\\\", \\\"{x:1533,y:825,t:1527019581015};\\\", \\\"{x:1532,y:823,t:1527019581031};\\\", \\\"{x:1530,y:819,t:1527019581048};\\\", \\\"{x:1529,y:818,t:1527019581065};\\\", \\\"{x:1528,y:816,t:1527019581081};\\\", \\\"{x:1525,y:809,t:1527019581099};\\\", \\\"{x:1521,y:799,t:1527019581115};\\\", \\\"{x:1517,y:794,t:1527019581131};\\\", \\\"{x:1516,y:790,t:1527019581148};\\\", \\\"{x:1513,y:784,t:1527019581166};\\\", \\\"{x:1510,y:781,t:1527019581181};\\\", \\\"{x:1507,y:775,t:1527019581198};\\\", \\\"{x:1502,y:767,t:1527019581215};\\\", \\\"{x:1497,y:759,t:1527019581231};\\\", \\\"{x:1493,y:752,t:1527019581248};\\\", \\\"{x:1488,y:742,t:1527019581265};\\\", \\\"{x:1485,y:736,t:1527019581281};\\\", \\\"{x:1481,y:729,t:1527019581299};\\\", \\\"{x:1476,y:721,t:1527019581315};\\\", \\\"{x:1471,y:713,t:1527019581331};\\\", \\\"{x:1462,y:698,t:1527019581348};\\\", \\\"{x:1448,y:680,t:1527019581365};\\\", \\\"{x:1444,y:672,t:1527019581382};\\\", \\\"{x:1440,y:665,t:1527019581399};\\\", \\\"{x:1438,y:659,t:1527019581415};\\\", \\\"{x:1434,y:652,t:1527019581433};\\\", \\\"{x:1429,y:642,t:1527019581448};\\\", \\\"{x:1426,y:635,t:1527019581465};\\\", \\\"{x:1421,y:623,t:1527019581482};\\\", \\\"{x:1416,y:612,t:1527019581499};\\\", \\\"{x:1412,y:603,t:1527019581515};\\\", \\\"{x:1411,y:599,t:1527019581533};\\\", \\\"{x:1408,y:593,t:1527019581548};\\\", \\\"{x:1407,y:588,t:1527019581566};\\\", \\\"{x:1404,y:582,t:1527019581582};\\\", \\\"{x:1403,y:577,t:1527019581599};\\\", \\\"{x:1399,y:569,t:1527019581615};\\\", \\\"{x:1398,y:566,t:1527019581632};\\\", \\\"{x:1398,y:564,t:1527019581648};\\\", \\\"{x:1397,y:563,t:1527019581665};\\\", \\\"{x:1393,y:562,t:1527019582079};\\\", \\\"{x:1376,y:563,t:1527019582086};\\\", \\\"{x:1353,y:564,t:1527019582099};\\\", \\\"{x:1280,y:572,t:1527019582116};\\\", \\\"{x:1147,y:572,t:1527019582132};\\\", \\\"{x:895,y:574,t:1527019582150};\\\", \\\"{x:748,y:569,t:1527019582165};\\\", \\\"{x:648,y:569,t:1527019582182};\\\", \\\"{x:570,y:569,t:1527019582199};\\\", \\\"{x:547,y:571,t:1527019582215};\\\", \\\"{x:541,y:574,t:1527019582232};\\\", \\\"{x:542,y:572,t:1527019582494};\\\", \\\"{x:544,y:572,t:1527019582502};\\\", \\\"{x:550,y:569,t:1527019582516};\\\", \\\"{x:555,y:568,t:1527019582532};\\\", \\\"{x:565,y:566,t:1527019582548};\\\", \\\"{x:568,y:566,t:1527019582566};\\\", \\\"{x:570,y:565,t:1527019582582};\\\", \\\"{x:571,y:565,t:1527019582621};\\\", \\\"{x:573,y:565,t:1527019582637};\\\", \\\"{x:574,y:565,t:1527019582653};\\\", \\\"{x:576,y:565,t:1527019582701};\\\", \\\"{x:578,y:564,t:1527019582716};\\\", \\\"{x:580,y:564,t:1527019582733};\\\", \\\"{x:582,y:562,t:1527019582749};\\\", \\\"{x:584,y:562,t:1527019582765};\\\", \\\"{x:586,y:562,t:1527019582783};\\\", \\\"{x:592,y:560,t:1527019582799};\\\", \\\"{x:594,y:560,t:1527019582816};\\\", \\\"{x:595,y:559,t:1527019582833};\\\", \\\"{x:596,y:558,t:1527019582849};\\\", \\\"{x:597,y:558,t:1527019582885};\\\", \\\"{x:598,y:558,t:1527019582899};\\\", \\\"{x:600,y:557,t:1527019582916};\\\", \\\"{x:600,y:562,t:1527019583117};\\\", \\\"{x:590,y:576,t:1527019583133};\\\", \\\"{x:576,y:591,t:1527019583150};\\\", \\\"{x:562,y:603,t:1527019583166};\\\", \\\"{x:555,y:613,t:1527019583183};\\\", \\\"{x:552,y:619,t:1527019583200};\\\", \\\"{x:550,y:623,t:1527019583216};\\\", \\\"{x:548,y:628,t:1527019583233};\\\", \\\"{x:546,y:636,t:1527019583250};\\\", \\\"{x:542,y:643,t:1527019583266};\\\", \\\"{x:541,y:647,t:1527019583283};\\\", \\\"{x:540,y:651,t:1527019583301};\\\", \\\"{x:538,y:654,t:1527019583316};\\\", \\\"{x:538,y:658,t:1527019583333};\\\", \\\"{x:538,y:659,t:1527019583350};\\\", \\\"{x:537,y:661,t:1527019583373};\\\", \\\"{x:537,y:662,t:1527019583383};\\\", \\\"{x:537,y:665,t:1527019583400};\\\", \\\"{x:537,y:667,t:1527019583421};\\\", \\\"{x:537,y:668,t:1527019583446};\\\", \\\"{x:537,y:670,t:1527019583461};\\\", \\\"{x:536,y:671,t:1527019583477};\\\", \\\"{x:536,y:675,t:1527019583493};\\\", \\\"{x:536,y:678,t:1527019583501};\\\", \\\"{x:535,y:680,t:1527019583517};\\\", \\\"{x:535,y:684,t:1527019583533};\\\", \\\"{x:535,y:686,t:1527019583550};\\\", \\\"{x:535,y:687,t:1527019583567};\\\", \\\"{x:535,y:689,t:1527019583584};\\\", \\\"{x:535,y:690,t:1527019583600};\\\", \\\"{x:535,y:695,t:1527019583618};\\\", \\\"{x:535,y:697,t:1527019583638};\\\", \\\"{x:534,y:699,t:1527019583650};\\\", \\\"{x:533,y:703,t:1527019583668};\\\", \\\"{x:533,y:704,t:1527019583709};\\\", \\\"{x:533,y:705,t:1527019583725};\\\", \\\"{x:533,y:706,t:1527019583748};\\\", \\\"{x:533,y:707,t:1527019583764};\\\", \\\"{x:532,y:708,t:1527019583781};\\\", \\\"{x:531,y:708,t:1527019584060};\\\", \\\"{x:530,y:708,t:1527019584077};\\\", \\\"{x:528,y:708,t:1527019584109};\\\", \\\"{x:527,y:708,t:1527019584149};\\\", \\\"{x:526,y:708,t:1527019584157};\\\", \\\"{x:525,y:708,t:1527019584167};\\\", \\\"{x:524,y:708,t:1527019584189};\\\", \\\"{x:522,y:707,t:1527019584205};\\\", \\\"{x:520,y:705,t:1527019584253};\\\" ] }, { \\\"rt\\\": 23387, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 232252, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -I -I -I -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:704,t:1527019585309};\\\", \\\"{x:526,y:703,t:1527019585318};\\\", \\\"{x:530,y:701,t:1527019585334};\\\", \\\"{x:532,y:701,t:1527019585351};\\\", \\\"{x:533,y:701,t:1527019585368};\\\", \\\"{x:533,y:700,t:1527019585402};\\\", \\\"{x:513,y:549,t:1527019585692};\\\", \\\"{x:502,y:507,t:1527019585703};\\\", \\\"{x:491,y:484,t:1527019585718};\\\", \\\"{x:482,y:472,t:1527019585734};\\\", \\\"{x:477,y:462,t:1527019585752};\\\", \\\"{x:471,y:452,t:1527019585768};\\\", \\\"{x:469,y:449,t:1527019585785};\\\", \\\"{x:466,y:446,t:1527019585802};\\\", \\\"{x:459,y:442,t:1527019585818};\\\", \\\"{x:454,y:440,t:1527019585835};\\\", \\\"{x:450,y:439,t:1527019585852};\\\", \\\"{x:444,y:438,t:1527019585868};\\\", \\\"{x:432,y:438,t:1527019585885};\\\", \\\"{x:419,y:441,t:1527019585902};\\\", \\\"{x:406,y:442,t:1527019585918};\\\", \\\"{x:389,y:445,t:1527019585935};\\\", \\\"{x:377,y:446,t:1527019585952};\\\", \\\"{x:366,y:452,t:1527019585968};\\\", \\\"{x:365,y:452,t:1527019585985};\\\", \\\"{x:364,y:453,t:1527019586002};\\\", \\\"{x:364,y:454,t:1527019586021};\\\", \\\"{x:367,y:455,t:1527019586045};\\\", \\\"{x:368,y:456,t:1527019586053};\\\", \\\"{x:369,y:456,t:1527019586069};\\\", \\\"{x:381,y:458,t:1527019586085};\\\", \\\"{x:393,y:460,t:1527019586103};\\\", \\\"{x:404,y:462,t:1527019586120};\\\", \\\"{x:413,y:463,t:1527019586136};\\\", \\\"{x:421,y:463,t:1527019586152};\\\", \\\"{x:425,y:463,t:1527019586169};\\\", \\\"{x:427,y:463,t:1527019586186};\\\", \\\"{x:428,y:463,t:1527019586213};\\\", \\\"{x:429,y:463,t:1527019586222};\\\", \\\"{x:430,y:464,t:1527019586235};\\\", \\\"{x:432,y:464,t:1527019586251};\\\", \\\"{x:439,y:466,t:1527019586268};\\\", \\\"{x:447,y:466,t:1527019586285};\\\", \\\"{x:452,y:468,t:1527019586302};\\\", \\\"{x:457,y:470,t:1527019586319};\\\", \\\"{x:459,y:470,t:1527019586335};\\\", \\\"{x:461,y:470,t:1527019586352};\\\", \\\"{x:462,y:470,t:1527019586369};\\\", \\\"{x:463,y:470,t:1527019586397};\\\", \\\"{x:464,y:470,t:1527019586413};\\\", \\\"{x:465,y:470,t:1527019586421};\\\", \\\"{x:466,y:470,t:1527019586436};\\\", \\\"{x:468,y:470,t:1527019586452};\\\", \\\"{x:471,y:470,t:1527019586470};\\\", \\\"{x:474,y:470,t:1527019586485};\\\", \\\"{x:476,y:471,t:1527019586502};\\\", \\\"{x:478,y:471,t:1527019586519};\\\", \\\"{x:481,y:471,t:1527019586536};\\\", \\\"{x:486,y:471,t:1527019586552};\\\", \\\"{x:490,y:472,t:1527019586570};\\\", \\\"{x:495,y:474,t:1527019586586};\\\", \\\"{x:500,y:475,t:1527019586602};\\\", \\\"{x:502,y:475,t:1527019586619};\\\", \\\"{x:503,y:475,t:1527019586636};\\\", \\\"{x:504,y:475,t:1527019586670};\\\", \\\"{x:507,y:477,t:1527019586685};\\\", \\\"{x:511,y:477,t:1527019586702};\\\", \\\"{x:516,y:478,t:1527019586719};\\\", \\\"{x:522,y:478,t:1527019586736};\\\", \\\"{x:530,y:479,t:1527019586752};\\\", \\\"{x:541,y:482,t:1527019586769};\\\", \\\"{x:547,y:482,t:1527019586786};\\\", \\\"{x:548,y:483,t:1527019586802};\\\", \\\"{x:549,y:483,t:1527019586819};\\\", \\\"{x:551,y:483,t:1527019586966};\\\", \\\"{x:555,y:483,t:1527019586981};\\\", \\\"{x:558,y:483,t:1527019586989};\\\", \\\"{x:562,y:483,t:1527019587003};\\\", \\\"{x:572,y:483,t:1527019587019};\\\", \\\"{x:589,y:483,t:1527019587037};\\\", \\\"{x:618,y:486,t:1527019587053};\\\", \\\"{x:630,y:486,t:1527019587069};\\\", \\\"{x:643,y:486,t:1527019587086};\\\", \\\"{x:646,y:486,t:1527019587103};\\\", \\\"{x:648,y:486,t:1527019587120};\\\", \\\"{x:648,y:487,t:1527019587198};\\\", \\\"{x:648,y:488,t:1527019587205};\\\", \\\"{x:645,y:489,t:1527019587219};\\\", \\\"{x:631,y:491,t:1527019587236};\\\", \\\"{x:601,y:493,t:1527019587252};\\\", \\\"{x:578,y:493,t:1527019587269};\\\", \\\"{x:562,y:496,t:1527019587286};\\\", \\\"{x:554,y:497,t:1527019587303};\\\", \\\"{x:548,y:497,t:1527019587320};\\\", \\\"{x:542,y:497,t:1527019587336};\\\", \\\"{x:541,y:497,t:1527019587353};\\\", \\\"{x:539,y:497,t:1527019587370};\\\", \\\"{x:535,y:497,t:1527019587386};\\\", \\\"{x:527,y:497,t:1527019587403};\\\", \\\"{x:512,y:498,t:1527019587420};\\\", \\\"{x:501,y:498,t:1527019587436};\\\", \\\"{x:478,y:501,t:1527019587452};\\\", \\\"{x:467,y:501,t:1527019587470};\\\", \\\"{x:460,y:501,t:1527019587486};\\\", \\\"{x:454,y:501,t:1527019587503};\\\", \\\"{x:447,y:502,t:1527019587520};\\\", \\\"{x:441,y:502,t:1527019587536};\\\", \\\"{x:431,y:502,t:1527019587554};\\\", \\\"{x:424,y:502,t:1527019587570};\\\", \\\"{x:419,y:502,t:1527019587587};\\\", \\\"{x:415,y:502,t:1527019587603};\\\", \\\"{x:414,y:502,t:1527019587686};\\\", \\\"{x:418,y:501,t:1527019587704};\\\", \\\"{x:422,y:500,t:1527019587721};\\\", \\\"{x:427,y:499,t:1527019587737};\\\", \\\"{x:434,y:499,t:1527019587754};\\\", \\\"{x:441,y:499,t:1527019587770};\\\", \\\"{x:446,y:499,t:1527019587787};\\\", \\\"{x:450,y:499,t:1527019587803};\\\", \\\"{x:457,y:499,t:1527019587820};\\\", \\\"{x:466,y:499,t:1527019587837};\\\", \\\"{x:471,y:499,t:1527019587853};\\\", \\\"{x:475,y:499,t:1527019587870};\\\", \\\"{x:478,y:499,t:1527019587887};\\\", \\\"{x:479,y:499,t:1527019587903};\\\", \\\"{x:480,y:499,t:1527019587925};\\\", \\\"{x:481,y:499,t:1527019587942};\\\", \\\"{x:482,y:499,t:1527019587953};\\\", \\\"{x:483,y:499,t:1527019587970};\\\", \\\"{x:485,y:499,t:1527019587987};\\\", \\\"{x:487,y:499,t:1527019588014};\\\", \\\"{x:488,y:499,t:1527019588045};\\\", \\\"{x:489,y:499,t:1527019588061};\\\", \\\"{x:491,y:499,t:1527019588078};\\\", \\\"{x:492,y:499,t:1527019588088};\\\", \\\"{x:495,y:499,t:1527019588103};\\\", \\\"{x:498,y:499,t:1527019588121};\\\", \\\"{x:500,y:499,t:1527019588137};\\\", \\\"{x:501,y:499,t:1527019588153};\\\", \\\"{x:502,y:499,t:1527019588310};\\\", \\\"{x:503,y:499,t:1527019588320};\\\", \\\"{x:507,y:499,t:1527019588338};\\\", \\\"{x:511,y:499,t:1527019588354};\\\", \\\"{x:515,y:499,t:1527019588370};\\\", \\\"{x:518,y:499,t:1527019588387};\\\", \\\"{x:519,y:499,t:1527019588405};\\\", \\\"{x:522,y:499,t:1527019588421};\\\", \\\"{x:525,y:499,t:1527019588437};\\\", \\\"{x:528,y:500,t:1527019588454};\\\", \\\"{x:530,y:500,t:1527019588477};\\\", \\\"{x:532,y:500,t:1527019588488};\\\", \\\"{x:533,y:500,t:1527019588505};\\\", \\\"{x:535,y:500,t:1527019588521};\\\", \\\"{x:538,y:500,t:1527019588538};\\\", \\\"{x:541,y:500,t:1527019588554};\\\", \\\"{x:545,y:500,t:1527019588570};\\\", \\\"{x:549,y:501,t:1527019588587};\\\", \\\"{x:552,y:501,t:1527019588605};\\\", \\\"{x:555,y:501,t:1527019588621};\\\", \\\"{x:556,y:501,t:1527019588646};\\\", \\\"{x:557,y:501,t:1527019588950};\\\", \\\"{x:558,y:501,t:1527019588958};\\\", \\\"{x:558,y:500,t:1527019589174};\\\", \\\"{x:559,y:499,t:1527019589189};\\\", \\\"{x:560,y:499,t:1527019589205};\\\", \\\"{x:561,y:498,t:1527019589221};\\\", \\\"{x:564,y:498,t:1527019589854};\\\", \\\"{x:566,y:498,t:1527019589861};\\\", \\\"{x:568,y:498,t:1527019589872};\\\", \\\"{x:573,y:498,t:1527019589888};\\\", \\\"{x:577,y:499,t:1527019589906};\\\", \\\"{x:580,y:499,t:1527019589922};\\\", \\\"{x:581,y:501,t:1527019589939};\\\", \\\"{x:582,y:501,t:1527019589955};\\\", \\\"{x:583,y:501,t:1527019590085};\\\", \\\"{x:585,y:500,t:1527019590093};\\\", \\\"{x:587,y:499,t:1527019590106};\\\", \\\"{x:590,y:498,t:1527019590123};\\\", \\\"{x:591,y:497,t:1527019590139};\\\", \\\"{x:592,y:497,t:1527019590214};\\\", \\\"{x:593,y:497,t:1527019590223};\\\", \\\"{x:594,y:497,t:1527019590261};\\\", \\\"{x:597,y:497,t:1527019590284};\\\", \\\"{x:599,y:497,t:1527019590293};\\\", \\\"{x:600,y:497,t:1527019590305};\\\", \\\"{x:605,y:496,t:1527019590322};\\\", \\\"{x:610,y:493,t:1527019590339};\\\", \\\"{x:614,y:492,t:1527019590355};\\\", \\\"{x:615,y:492,t:1527019590372};\\\", \\\"{x:617,y:492,t:1527019590534};\\\", \\\"{x:618,y:492,t:1527019590550};\\\", \\\"{x:619,y:492,t:1527019590614};\\\", \\\"{x:620,y:492,t:1527019590637};\\\", \\\"{x:621,y:492,t:1527019590653};\\\", \\\"{x:622,y:492,t:1527019590669};\\\", \\\"{x:623,y:492,t:1527019590693};\\\", \\\"{x:624,y:492,t:1527019590710};\\\", \\\"{x:625,y:492,t:1527019590797};\\\", \\\"{x:627,y:492,t:1527019590878};\\\", \\\"{x:629,y:494,t:1527019590890};\\\", \\\"{x:634,y:495,t:1527019590906};\\\", \\\"{x:645,y:500,t:1527019590923};\\\", \\\"{x:666,y:510,t:1527019590939};\\\", \\\"{x:700,y:522,t:1527019590956};\\\", \\\"{x:731,y:538,t:1527019590973};\\\", \\\"{x:805,y:570,t:1527019590990};\\\", \\\"{x:866,y:597,t:1527019591006};\\\", \\\"{x:934,y:638,t:1527019591023};\\\", \\\"{x:1009,y:690,t:1527019591039};\\\", \\\"{x:1099,y:757,t:1527019591056};\\\", \\\"{x:1174,y:809,t:1527019591073};\\\", \\\"{x:1242,y:860,t:1527019591089};\\\", \\\"{x:1298,y:899,t:1527019591106};\\\", \\\"{x:1348,y:932,t:1527019591123};\\\", \\\"{x:1382,y:950,t:1527019591139};\\\", \\\"{x:1400,y:957,t:1527019591157};\\\", \\\"{x:1421,y:966,t:1527019591173};\\\", \\\"{x:1427,y:967,t:1527019591190};\\\", \\\"{x:1428,y:967,t:1527019591206};\\\", \\\"{x:1428,y:966,t:1527019591990};\\\", \\\"{x:1429,y:963,t:1527019592006};\\\", \\\"{x:1429,y:962,t:1527019592014};\\\", \\\"{x:1429,y:958,t:1527019592026};\\\", \\\"{x:1430,y:951,t:1527019592043};\\\", \\\"{x:1432,y:943,t:1527019592059};\\\", \\\"{x:1432,y:935,t:1527019592076};\\\", \\\"{x:1430,y:920,t:1527019592093};\\\", \\\"{x:1418,y:882,t:1527019592110};\\\", \\\"{x:1397,y:820,t:1527019592127};\\\", \\\"{x:1373,y:716,t:1527019592143};\\\", \\\"{x:1348,y:624,t:1527019592160};\\\", \\\"{x:1324,y:544,t:1527019592177};\\\", \\\"{x:1309,y:498,t:1527019592196};\\\", \\\"{x:1292,y:457,t:1527019592210};\\\", \\\"{x:1278,y:438,t:1527019592226};\\\", \\\"{x:1263,y:425,t:1527019592243};\\\", \\\"{x:1257,y:420,t:1527019592260};\\\", \\\"{x:1257,y:418,t:1527019592276};\\\", \\\"{x:1257,y:419,t:1527019592357};\\\", \\\"{x:1257,y:422,t:1527019592365};\\\", \\\"{x:1258,y:428,t:1527019592376};\\\", \\\"{x:1267,y:442,t:1527019592393};\\\", \\\"{x:1277,y:458,t:1527019592411};\\\", \\\"{x:1286,y:469,t:1527019592426};\\\", \\\"{x:1297,y:484,t:1527019592444};\\\", \\\"{x:1302,y:492,t:1527019592461};\\\", \\\"{x:1304,y:497,t:1527019592477};\\\", \\\"{x:1308,y:502,t:1527019592494};\\\", \\\"{x:1308,y:504,t:1527019592510};\\\", \\\"{x:1308,y:505,t:1527019592528};\\\", \\\"{x:1309,y:506,t:1527019592544};\\\", \\\"{x:1310,y:506,t:1527019592574};\\\", \\\"{x:1310,y:507,t:1527019592813};\\\", \\\"{x:1312,y:507,t:1527019593047};\\\", \\\"{x:1313,y:507,t:1527019593062};\\\", \\\"{x:1315,y:507,t:1527019593102};\\\", \\\"{x:1316,y:507,t:1527019593113};\\\", \\\"{x:1317,y:506,t:1527019593158};\\\", \\\"{x:1318,y:506,t:1527019593238};\\\", \\\"{x:1319,y:506,t:1527019593246};\\\", \\\"{x:1321,y:507,t:1527019593270};\\\", \\\"{x:1323,y:510,t:1527019593280};\\\", \\\"{x:1324,y:514,t:1527019593296};\\\", \\\"{x:1328,y:521,t:1527019593313};\\\", \\\"{x:1328,y:525,t:1527019593330};\\\", \\\"{x:1330,y:527,t:1527019593347};\\\", \\\"{x:1332,y:530,t:1527019593363};\\\", \\\"{x:1334,y:534,t:1527019593379};\\\", \\\"{x:1335,y:536,t:1527019593396};\\\", \\\"{x:1337,y:538,t:1527019593414};\\\", \\\"{x:1337,y:540,t:1527019593430};\\\", \\\"{x:1339,y:541,t:1527019593447};\\\", \\\"{x:1340,y:544,t:1527019593464};\\\", \\\"{x:1341,y:546,t:1527019593480};\\\", \\\"{x:1343,y:550,t:1527019593497};\\\", \\\"{x:1345,y:552,t:1527019593514};\\\", \\\"{x:1347,y:554,t:1527019593531};\\\", \\\"{x:1347,y:556,t:1527019593547};\\\", \\\"{x:1348,y:557,t:1527019593564};\\\", \\\"{x:1349,y:559,t:1527019593581};\\\", \\\"{x:1350,y:560,t:1527019593597};\\\", \\\"{x:1351,y:562,t:1527019593614};\\\", \\\"{x:1351,y:563,t:1527019593631};\\\", \\\"{x:1351,y:560,t:1527019593798};\\\", \\\"{x:1351,y:556,t:1527019593815};\\\", \\\"{x:1349,y:546,t:1527019593831};\\\", \\\"{x:1345,y:534,t:1527019593848};\\\", \\\"{x:1343,y:524,t:1527019593865};\\\", \\\"{x:1339,y:517,t:1527019593882};\\\", \\\"{x:1338,y:512,t:1527019593898};\\\", \\\"{x:1335,y:507,t:1527019593915};\\\", \\\"{x:1332,y:504,t:1527019593932};\\\", \\\"{x:1330,y:502,t:1527019593948};\\\", \\\"{x:1330,y:500,t:1527019593965};\\\", \\\"{x:1329,y:500,t:1527019594014};\\\", \\\"{x:1328,y:500,t:1527019594038};\\\", \\\"{x:1326,y:500,t:1527019594061};\\\", \\\"{x:1325,y:500,t:1527019594070};\\\", \\\"{x:1324,y:501,t:1527019594082};\\\", \\\"{x:1321,y:504,t:1527019594099};\\\", \\\"{x:1319,y:507,t:1527019594116};\\\", \\\"{x:1317,y:510,t:1527019594132};\\\", \\\"{x:1315,y:512,t:1527019594149};\\\", \\\"{x:1313,y:516,t:1527019594165};\\\", \\\"{x:1311,y:520,t:1527019594182};\\\", \\\"{x:1307,y:526,t:1527019594199};\\\", \\\"{x:1300,y:536,t:1527019594216};\\\", \\\"{x:1296,y:545,t:1527019594233};\\\", \\\"{x:1289,y:557,t:1527019594249};\\\", \\\"{x:1282,y:571,t:1527019594266};\\\", \\\"{x:1279,y:579,t:1527019594283};\\\", \\\"{x:1273,y:588,t:1527019594299};\\\", \\\"{x:1267,y:598,t:1527019594316};\\\", \\\"{x:1264,y:606,t:1527019594332};\\\", \\\"{x:1258,y:618,t:1527019594349};\\\", \\\"{x:1253,y:628,t:1527019594367};\\\", \\\"{x:1248,y:636,t:1527019594384};\\\", \\\"{x:1246,y:642,t:1527019594400};\\\", \\\"{x:1242,y:650,t:1527019594416};\\\", \\\"{x:1239,y:659,t:1527019594433};\\\", \\\"{x:1235,y:669,t:1527019594450};\\\", \\\"{x:1227,y:685,t:1527019594467};\\\", \\\"{x:1221,y:696,t:1527019594484};\\\", \\\"{x:1215,y:707,t:1527019594500};\\\", \\\"{x:1207,y:721,t:1527019594517};\\\", \\\"{x:1201,y:735,t:1527019594533};\\\", \\\"{x:1188,y:756,t:1527019594550};\\\", \\\"{x:1180,y:766,t:1527019594567};\\\", \\\"{x:1174,y:779,t:1527019594585};\\\", \\\"{x:1169,y:790,t:1527019594600};\\\", \\\"{x:1163,y:803,t:1527019594617};\\\", \\\"{x:1155,y:821,t:1527019594634};\\\", \\\"{x:1149,y:837,t:1527019594650};\\\", \\\"{x:1141,y:854,t:1527019594667};\\\", \\\"{x:1133,y:871,t:1527019594684};\\\", \\\"{x:1126,y:882,t:1527019594701};\\\", \\\"{x:1123,y:891,t:1527019594718};\\\", \\\"{x:1118,y:905,t:1527019594734};\\\", \\\"{x:1114,y:912,t:1527019594752};\\\", \\\"{x:1109,y:920,t:1527019594767};\\\", \\\"{x:1101,y:932,t:1527019594784};\\\", \\\"{x:1096,y:939,t:1527019594801};\\\", \\\"{x:1090,y:945,t:1527019594818};\\\", \\\"{x:1088,y:950,t:1527019594834};\\\", \\\"{x:1087,y:951,t:1527019594850};\\\", \\\"{x:1087,y:947,t:1527019594917};\\\", \\\"{x:1092,y:934,t:1527019594934};\\\", \\\"{x:1106,y:903,t:1527019594951};\\\", \\\"{x:1135,y:840,t:1527019594967};\\\", \\\"{x:1165,y:773,t:1527019594985};\\\", \\\"{x:1196,y:704,t:1527019595000};\\\", \\\"{x:1216,y:652,t:1527019595017};\\\", \\\"{x:1227,y:613,t:1527019595034};\\\", \\\"{x:1234,y:591,t:1527019595052};\\\", \\\"{x:1240,y:573,t:1527019595067};\\\", \\\"{x:1249,y:553,t:1527019595084};\\\", \\\"{x:1259,y:537,t:1527019595101};\\\", \\\"{x:1264,y:528,t:1527019595118};\\\", \\\"{x:1269,y:518,t:1527019595134};\\\", \\\"{x:1273,y:508,t:1527019595152};\\\", \\\"{x:1276,y:504,t:1527019595168};\\\", \\\"{x:1278,y:499,t:1527019595184};\\\", \\\"{x:1279,y:497,t:1527019595202};\\\", \\\"{x:1281,y:495,t:1527019595219};\\\", \\\"{x:1285,y:492,t:1527019595234};\\\", \\\"{x:1287,y:489,t:1527019595251};\\\", \\\"{x:1291,y:487,t:1527019595268};\\\", \\\"{x:1298,y:484,t:1527019595285};\\\", \\\"{x:1301,y:483,t:1527019595301};\\\", \\\"{x:1302,y:483,t:1527019595319};\\\", \\\"{x:1303,y:483,t:1527019595336};\\\", \\\"{x:1304,y:483,t:1527019595352};\\\", \\\"{x:1306,y:484,t:1527019595368};\\\", \\\"{x:1306,y:488,t:1527019595385};\\\", \\\"{x:1307,y:491,t:1527019595402};\\\", \\\"{x:1309,y:495,t:1527019595419};\\\", \\\"{x:1310,y:499,t:1527019595435};\\\", \\\"{x:1314,y:510,t:1527019595453};\\\", \\\"{x:1315,y:514,t:1527019595468};\\\", \\\"{x:1318,y:517,t:1527019595485};\\\", \\\"{x:1318,y:518,t:1527019595502};\\\", \\\"{x:1319,y:520,t:1527019595519};\\\", \\\"{x:1322,y:526,t:1527019595536};\\\", \\\"{x:1322,y:531,t:1527019595553};\\\", \\\"{x:1325,y:533,t:1527019595570};\\\", \\\"{x:1326,y:535,t:1527019595585};\\\", \\\"{x:1327,y:538,t:1527019595602};\\\", \\\"{x:1328,y:539,t:1527019595619};\\\", \\\"{x:1332,y:545,t:1527019595637};\\\", \\\"{x:1335,y:550,t:1527019595653};\\\", \\\"{x:1339,y:557,t:1527019595670};\\\", \\\"{x:1340,y:560,t:1527019595687};\\\", \\\"{x:1343,y:566,t:1527019595703};\\\", \\\"{x:1346,y:571,t:1527019595720};\\\", \\\"{x:1349,y:576,t:1527019595737};\\\", \\\"{x:1351,y:581,t:1527019595754};\\\", \\\"{x:1354,y:586,t:1527019595769};\\\", \\\"{x:1356,y:589,t:1527019595787};\\\", \\\"{x:1356,y:591,t:1527019595804};\\\", \\\"{x:1356,y:593,t:1527019595820};\\\", \\\"{x:1358,y:595,t:1527019595837};\\\", \\\"{x:1359,y:601,t:1527019595853};\\\", \\\"{x:1360,y:606,t:1527019595871};\\\", \\\"{x:1362,y:609,t:1527019595887};\\\", \\\"{x:1365,y:614,t:1527019595904};\\\", \\\"{x:1367,y:619,t:1527019595921};\\\", \\\"{x:1369,y:623,t:1527019595937};\\\", \\\"{x:1371,y:626,t:1527019595954};\\\", \\\"{x:1374,y:629,t:1527019595971};\\\", \\\"{x:1374,y:632,t:1527019595988};\\\", \\\"{x:1374,y:634,t:1527019596004};\\\", \\\"{x:1374,y:635,t:1527019596021};\\\", \\\"{x:1374,y:636,t:1527019596038};\\\", \\\"{x:1374,y:638,t:1527019596054};\\\", \\\"{x:1375,y:639,t:1527019596071};\\\", \\\"{x:1376,y:641,t:1527019596088};\\\", \\\"{x:1377,y:642,t:1527019596109};\\\", \\\"{x:1377,y:644,t:1527019596125};\\\", \\\"{x:1377,y:645,t:1527019596138};\\\", \\\"{x:1379,y:648,t:1527019596155};\\\", \\\"{x:1380,y:649,t:1527019596171};\\\", \\\"{x:1380,y:651,t:1527019596188};\\\", \\\"{x:1381,y:652,t:1527019596205};\\\", \\\"{x:1382,y:655,t:1527019596221};\\\", \\\"{x:1383,y:657,t:1527019596238};\\\", \\\"{x:1383,y:658,t:1527019596254};\\\", \\\"{x:1384,y:660,t:1527019596271};\\\", \\\"{x:1387,y:663,t:1527019596288};\\\", \\\"{x:1388,y:667,t:1527019596305};\\\", \\\"{x:1391,y:672,t:1527019596321};\\\", \\\"{x:1394,y:676,t:1527019596338};\\\", \\\"{x:1396,y:680,t:1527019596354};\\\", \\\"{x:1398,y:685,t:1527019596372};\\\", \\\"{x:1399,y:687,t:1527019596388};\\\", \\\"{x:1399,y:689,t:1527019596413};\\\", \\\"{x:1401,y:691,t:1527019596429};\\\", \\\"{x:1401,y:692,t:1527019596439};\\\", \\\"{x:1402,y:695,t:1527019596456};\\\", \\\"{x:1403,y:698,t:1527019596472};\\\", \\\"{x:1406,y:704,t:1527019596489};\\\", \\\"{x:1407,y:707,t:1527019596506};\\\", \\\"{x:1409,y:711,t:1527019596522};\\\", \\\"{x:1410,y:714,t:1527019596538};\\\", \\\"{x:1412,y:716,t:1527019596555};\\\", \\\"{x:1415,y:721,t:1527019596573};\\\", \\\"{x:1416,y:724,t:1527019596589};\\\", \\\"{x:1418,y:730,t:1527019596606};\\\", \\\"{x:1422,y:737,t:1527019596624};\\\", \\\"{x:1426,y:742,t:1527019596639};\\\", \\\"{x:1429,y:747,t:1527019596656};\\\", \\\"{x:1433,y:751,t:1527019596673};\\\", \\\"{x:1434,y:754,t:1527019596690};\\\", \\\"{x:1437,y:758,t:1527019596706};\\\", \\\"{x:1441,y:762,t:1527019596723};\\\", \\\"{x:1445,y:767,t:1527019596740};\\\", \\\"{x:1449,y:773,t:1527019596756};\\\", \\\"{x:1454,y:780,t:1527019596774};\\\", \\\"{x:1460,y:788,t:1527019596789};\\\", \\\"{x:1465,y:799,t:1527019596808};\\\", \\\"{x:1471,y:809,t:1527019596823};\\\", \\\"{x:1474,y:814,t:1527019596841};\\\", \\\"{x:1478,y:819,t:1527019596857};\\\", \\\"{x:1480,y:822,t:1527019596874};\\\", \\\"{x:1482,y:827,t:1527019596891};\\\", \\\"{x:1484,y:832,t:1527019596908};\\\", \\\"{x:1484,y:834,t:1527019596924};\\\", \\\"{x:1488,y:836,t:1527019596940};\\\", \\\"{x:1496,y:849,t:1527019596958};\\\", \\\"{x:1502,y:858,t:1527019596973};\\\", \\\"{x:1508,y:869,t:1527019596990};\\\", \\\"{x:1512,y:879,t:1527019597007};\\\", \\\"{x:1516,y:887,t:1527019597025};\\\", \\\"{x:1519,y:893,t:1527019597040};\\\", \\\"{x:1520,y:901,t:1527019597057};\\\", \\\"{x:1524,y:907,t:1527019597073};\\\", \\\"{x:1527,y:912,t:1527019597090};\\\", \\\"{x:1528,y:914,t:1527019597107};\\\", \\\"{x:1528,y:915,t:1527019597125};\\\", \\\"{x:1528,y:916,t:1527019597141};\\\", \\\"{x:1528,y:920,t:1527019597156};\\\", \\\"{x:1528,y:923,t:1527019597181};\\\", \\\"{x:1528,y:924,t:1527019597190};\\\", \\\"{x:1528,y:926,t:1527019597238};\\\", \\\"{x:1527,y:926,t:1527019597310};\\\", \\\"{x:1526,y:928,t:1527019597350};\\\", \\\"{x:1526,y:930,t:1527019597358};\\\", \\\"{x:1521,y:936,t:1527019597375};\\\", \\\"{x:1521,y:937,t:1527019597392};\\\", \\\"{x:1521,y:938,t:1527019597408};\\\", \\\"{x:1519,y:938,t:1527019597718};\\\", \\\"{x:1515,y:932,t:1527019597726};\\\", \\\"{x:1505,y:917,t:1527019597744};\\\", \\\"{x:1495,y:898,t:1527019597760};\\\", \\\"{x:1483,y:878,t:1527019597776};\\\", \\\"{x:1472,y:859,t:1527019597793};\\\", \\\"{x:1462,y:841,t:1527019597809};\\\", \\\"{x:1451,y:820,t:1527019597827};\\\", \\\"{x:1441,y:804,t:1527019597843};\\\", \\\"{x:1426,y:782,t:1527019597860};\\\", \\\"{x:1413,y:759,t:1527019597877};\\\", \\\"{x:1391,y:722,t:1527019597893};\\\", \\\"{x:1381,y:702,t:1527019597909};\\\", \\\"{x:1371,y:683,t:1527019597926};\\\", \\\"{x:1365,y:669,t:1527019597943};\\\", \\\"{x:1358,y:653,t:1527019597960};\\\", \\\"{x:1355,y:640,t:1527019597978};\\\", \\\"{x:1352,y:622,t:1527019597993};\\\", \\\"{x:1348,y:607,t:1527019598010};\\\", \\\"{x:1345,y:598,t:1527019598027};\\\", \\\"{x:1345,y:595,t:1527019598043};\\\", \\\"{x:1344,y:591,t:1527019598060};\\\", \\\"{x:1344,y:588,t:1527019598077};\\\", \\\"{x:1344,y:585,t:1527019598094};\\\", \\\"{x:1343,y:579,t:1527019598109};\\\", \\\"{x:1341,y:572,t:1527019598127};\\\", \\\"{x:1339,y:564,t:1527019598143};\\\", \\\"{x:1337,y:558,t:1527019598159};\\\", \\\"{x:1336,y:552,t:1527019598177};\\\", \\\"{x:1335,y:549,t:1527019598194};\\\", \\\"{x:1333,y:544,t:1527019598211};\\\", \\\"{x:1332,y:538,t:1527019598227};\\\", \\\"{x:1329,y:531,t:1527019598244};\\\", \\\"{x:1328,y:525,t:1527019598260};\\\", \\\"{x:1325,y:517,t:1527019598276};\\\", \\\"{x:1324,y:512,t:1527019598294};\\\", \\\"{x:1323,y:509,t:1527019598311};\\\", \\\"{x:1321,y:505,t:1527019598328};\\\", \\\"{x:1319,y:501,t:1527019598343};\\\", \\\"{x:1318,y:495,t:1527019598361};\\\", \\\"{x:1317,y:493,t:1527019598377};\\\", \\\"{x:1316,y:491,t:1527019598394};\\\", \\\"{x:1316,y:490,t:1527019598414};\\\", \\\"{x:1314,y:490,t:1527019598725};\\\", \\\"{x:1314,y:491,t:1527019598838};\\\", \\\"{x:1314,y:493,t:1527019598901};\\\", \\\"{x:1314,y:494,t:1527019598942};\\\", \\\"{x:1314,y:496,t:1527019599086};\\\", \\\"{x:1314,y:497,t:1527019599125};\\\", \\\"{x:1314,y:499,t:1527019599157};\\\", \\\"{x:1314,y:500,t:1527019599182};\\\", \\\"{x:1314,y:502,t:1527019599206};\\\", \\\"{x:1314,y:503,t:1527019599342};\\\", \\\"{x:1314,y:505,t:1527019599382};\\\", \\\"{x:1314,y:506,t:1527019599438};\\\", \\\"{x:1314,y:509,t:1527019599918};\\\", \\\"{x:1314,y:514,t:1527019599932};\\\", \\\"{x:1314,y:523,t:1527019599949};\\\", \\\"{x:1314,y:528,t:1527019599965};\\\", \\\"{x:1314,y:533,t:1527019599982};\\\", \\\"{x:1314,y:537,t:1527019599999};\\\", \\\"{x:1314,y:541,t:1527019600016};\\\", \\\"{x:1314,y:547,t:1527019600033};\\\", \\\"{x:1314,y:554,t:1527019600049};\\\", \\\"{x:1315,y:560,t:1527019600066};\\\", \\\"{x:1315,y:569,t:1527019600083};\\\", \\\"{x:1315,y:580,t:1527019600099};\\\", \\\"{x:1315,y:588,t:1527019600117};\\\", \\\"{x:1315,y:605,t:1527019600133};\\\", \\\"{x:1315,y:619,t:1527019600149};\\\", \\\"{x:1315,y:633,t:1527019600166};\\\", \\\"{x:1315,y:646,t:1527019600183};\\\", \\\"{x:1315,y:653,t:1527019600200};\\\", \\\"{x:1315,y:658,t:1527019600216};\\\", \\\"{x:1315,y:662,t:1527019600233};\\\", \\\"{x:1316,y:666,t:1527019600250};\\\", \\\"{x:1316,y:669,t:1527019600266};\\\", \\\"{x:1316,y:672,t:1527019600283};\\\", \\\"{x:1318,y:678,t:1527019600300};\\\", \\\"{x:1318,y:690,t:1527019600317};\\\", \\\"{x:1318,y:698,t:1527019600333};\\\", \\\"{x:1318,y:703,t:1527019600351};\\\", \\\"{x:1319,y:709,t:1527019600367};\\\", \\\"{x:1321,y:722,t:1527019600384};\\\", \\\"{x:1324,y:736,t:1527019600400};\\\", \\\"{x:1325,y:750,t:1527019600417};\\\", \\\"{x:1328,y:759,t:1527019600434};\\\", \\\"{x:1328,y:767,t:1527019600450};\\\", \\\"{x:1328,y:773,t:1527019600467};\\\", \\\"{x:1328,y:779,t:1527019600485};\\\", \\\"{x:1329,y:786,t:1527019600501};\\\", \\\"{x:1329,y:807,t:1527019600517};\\\", \\\"{x:1329,y:817,t:1527019600534};\\\", \\\"{x:1328,y:828,t:1527019600551};\\\", \\\"{x:1327,y:838,t:1527019600567};\\\", \\\"{x:1327,y:848,t:1527019600585};\\\", \\\"{x:1327,y:856,t:1527019600601};\\\", \\\"{x:1327,y:866,t:1527019600618};\\\", \\\"{x:1327,y:880,t:1527019600634};\\\", \\\"{x:1327,y:888,t:1527019600651};\\\", \\\"{x:1327,y:894,t:1527019600669};\\\", \\\"{x:1327,y:901,t:1527019600684};\\\", \\\"{x:1327,y:913,t:1527019600701};\\\", \\\"{x:1327,y:924,t:1527019600717};\\\", \\\"{x:1327,y:933,t:1527019600734};\\\", \\\"{x:1327,y:939,t:1527019600752};\\\", \\\"{x:1327,y:944,t:1527019600768};\\\", \\\"{x:1327,y:946,t:1527019600785};\\\", \\\"{x:1327,y:947,t:1527019600801};\\\", \\\"{x:1327,y:948,t:1527019600819};\\\", \\\"{x:1327,y:949,t:1527019600835};\\\", \\\"{x:1327,y:952,t:1527019600851};\\\", \\\"{x:1327,y:956,t:1527019600868};\\\", \\\"{x:1327,y:961,t:1527019600885};\\\", \\\"{x:1327,y:962,t:1527019600903};\\\", \\\"{x:1327,y:963,t:1527019600919};\\\", \\\"{x:1327,y:964,t:1527019600934};\\\", \\\"{x:1327,y:965,t:1527019600952};\\\", \\\"{x:1327,y:967,t:1527019600967};\\\", \\\"{x:1328,y:968,t:1527019600985};\\\", \\\"{x:1328,y:969,t:1527019601002};\\\", \\\"{x:1328,y:970,t:1527019601021};\\\", \\\"{x:1328,y:971,t:1527019601109};\\\", \\\"{x:1327,y:972,t:1527019601247};\\\", \\\"{x:1325,y:972,t:1527019601294};\\\", \\\"{x:1323,y:972,t:1527019601630};\\\", \\\"{x:1321,y:970,t:1527019601646};\\\", \\\"{x:1321,y:969,t:1527019601661};\\\", \\\"{x:1321,y:968,t:1527019601670};\\\", \\\"{x:1320,y:968,t:1527019601687};\\\", \\\"{x:1320,y:967,t:1527019601966};\\\", \\\"{x:1318,y:967,t:1527019601997};\\\", \\\"{x:1316,y:967,t:1527019602006};\\\", \\\"{x:1316,y:965,t:1527019602029};\\\", \\\"{x:1315,y:965,t:1527019602910};\\\", \\\"{x:1314,y:965,t:1527019602924};\\\", \\\"{x:1314,y:964,t:1527019602950};\\\", \\\"{x:1314,y:963,t:1527019602957};\\\", \\\"{x:1314,y:959,t:1527019602975};\\\", \\\"{x:1314,y:951,t:1527019602991};\\\", \\\"{x:1314,y:946,t:1527019603008};\\\", \\\"{x:1314,y:939,t:1527019603025};\\\", \\\"{x:1313,y:929,t:1527019603042};\\\", \\\"{x:1309,y:912,t:1527019603058};\\\", \\\"{x:1303,y:896,t:1527019603076};\\\", \\\"{x:1302,y:883,t:1527019603092};\\\", \\\"{x:1299,y:873,t:1527019603108};\\\", \\\"{x:1298,y:861,t:1527019603125};\\\", \\\"{x:1297,y:856,t:1527019603141};\\\", \\\"{x:1297,y:850,t:1527019603159};\\\", \\\"{x:1297,y:843,t:1527019603176};\\\", \\\"{x:1297,y:836,t:1527019603192};\\\", \\\"{x:1297,y:826,t:1527019603208};\\\", \\\"{x:1297,y:817,t:1527019603226};\\\", \\\"{x:1297,y:811,t:1527019603243};\\\", \\\"{x:1297,y:806,t:1527019603258};\\\", \\\"{x:1297,y:804,t:1527019603275};\\\", \\\"{x:1297,y:800,t:1527019603292};\\\", \\\"{x:1297,y:795,t:1527019603308};\\\", \\\"{x:1299,y:789,t:1527019603325};\\\", \\\"{x:1301,y:786,t:1527019603343};\\\", \\\"{x:1301,y:785,t:1527019603360};\\\", \\\"{x:1303,y:783,t:1527019603375};\\\", \\\"{x:1304,y:781,t:1527019603392};\\\", \\\"{x:1305,y:780,t:1527019603410};\\\", \\\"{x:1306,y:779,t:1527019603427};\\\", \\\"{x:1306,y:778,t:1527019603442};\\\", \\\"{x:1307,y:776,t:1527019603460};\\\", \\\"{x:1308,y:774,t:1527019603525};\\\", \\\"{x:1308,y:773,t:1527019603544};\\\", \\\"{x:1309,y:772,t:1527019603581};\\\", \\\"{x:1309,y:771,t:1527019603605};\\\", \\\"{x:1310,y:770,t:1527019603893};\\\", \\\"{x:1310,y:769,t:1527019603958};\\\", \\\"{x:1310,y:768,t:1527019605030};\\\", \\\"{x:1280,y:768,t:1527019605047};\\\", \\\"{x:1192,y:758,t:1527019605063};\\\", \\\"{x:1061,y:737,t:1527019605080};\\\", \\\"{x:924,y:705,t:1527019605097};\\\", \\\"{x:786,y:668,t:1527019605114};\\\", \\\"{x:654,y:634,t:1527019605130};\\\", \\\"{x:545,y:599,t:1527019605148};\\\", \\\"{x:414,y:561,t:1527019605168};\\\", \\\"{x:382,y:549,t:1527019605185};\\\", \\\"{x:360,y:542,t:1527019605201};\\\", \\\"{x:346,y:538,t:1527019605218};\\\", \\\"{x:341,y:535,t:1527019605233};\\\", \\\"{x:339,y:534,t:1527019605250};\\\", \\\"{x:337,y:534,t:1527019605268};\\\", \\\"{x:332,y:533,t:1527019605284};\\\", \\\"{x:327,y:532,t:1527019605301};\\\", \\\"{x:324,y:532,t:1527019605318};\\\", \\\"{x:321,y:532,t:1527019605335};\\\", \\\"{x:315,y:533,t:1527019605350};\\\", \\\"{x:309,y:534,t:1527019605367};\\\", \\\"{x:299,y:536,t:1527019605384};\\\", \\\"{x:288,y:537,t:1527019605400};\\\", \\\"{x:278,y:539,t:1527019605418};\\\", \\\"{x:268,y:540,t:1527019605436};\\\", \\\"{x:261,y:540,t:1527019605451};\\\", \\\"{x:254,y:541,t:1527019605467};\\\", \\\"{x:240,y:541,t:1527019605484};\\\", \\\"{x:233,y:541,t:1527019605501};\\\", \\\"{x:226,y:541,t:1527019605518};\\\", \\\"{x:219,y:541,t:1527019605535};\\\", \\\"{x:213,y:541,t:1527019605552};\\\", \\\"{x:211,y:541,t:1527019605568};\\\", \\\"{x:209,y:541,t:1527019605585};\\\", \\\"{x:208,y:541,t:1527019605613};\\\", \\\"{x:206,y:540,t:1527019605622};\\\", \\\"{x:205,y:540,t:1527019605635};\\\", \\\"{x:198,y:538,t:1527019605651};\\\", \\\"{x:189,y:535,t:1527019605669};\\\", \\\"{x:173,y:530,t:1527019605685};\\\", \\\"{x:164,y:527,t:1527019605702};\\\", \\\"{x:157,y:524,t:1527019605719};\\\", \\\"{x:152,y:522,t:1527019605736};\\\", \\\"{x:150,y:521,t:1527019605752};\\\", \\\"{x:149,y:520,t:1527019605768};\\\", \\\"{x:148,y:518,t:1527019605805};\\\", \\\"{x:147,y:518,t:1527019605817};\\\", \\\"{x:146,y:517,t:1527019605834};\\\", \\\"{x:145,y:516,t:1527019605851};\\\", \\\"{x:142,y:514,t:1527019605868};\\\", \\\"{x:137,y:510,t:1527019605884};\\\", \\\"{x:134,y:509,t:1527019605901};\\\", \\\"{x:132,y:508,t:1527019605918};\\\", \\\"{x:130,y:508,t:1527019605941};\\\", \\\"{x:129,y:508,t:1527019605952};\\\", \\\"{x:128,y:508,t:1527019605973};\\\", \\\"{x:127,y:508,t:1527019605985};\\\", \\\"{x:127,y:511,t:1527019606002};\\\", \\\"{x:127,y:515,t:1527019606017};\\\", \\\"{x:129,y:518,t:1527019606035};\\\", \\\"{x:132,y:521,t:1527019606053};\\\", \\\"{x:138,y:530,t:1527019606068};\\\", \\\"{x:144,y:538,t:1527019606084};\\\", \\\"{x:149,y:548,t:1527019606102};\\\", \\\"{x:153,y:558,t:1527019606120};\\\", \\\"{x:159,y:565,t:1527019606135};\\\", \\\"{x:160,y:567,t:1527019606152};\\\", \\\"{x:160,y:569,t:1527019606180};\\\", \\\"{x:163,y:570,t:1527019606204};\\\", \\\"{x:167,y:571,t:1527019606219};\\\", \\\"{x:183,y:574,t:1527019606235};\\\", \\\"{x:203,y:576,t:1527019606252};\\\", \\\"{x:238,y:580,t:1527019606268};\\\", \\\"{x:275,y:581,t:1527019606285};\\\", \\\"{x:301,y:581,t:1527019606302};\\\", \\\"{x:315,y:581,t:1527019606318};\\\", \\\"{x:327,y:581,t:1527019606334};\\\", \\\"{x:336,y:581,t:1527019606352};\\\", \\\"{x:339,y:581,t:1527019606368};\\\", \\\"{x:340,y:581,t:1527019606413};\\\", \\\"{x:341,y:580,t:1527019606430};\\\", \\\"{x:344,y:576,t:1527019606437};\\\", \\\"{x:344,y:575,t:1527019606452};\\\", \\\"{x:347,y:569,t:1527019606469};\\\", \\\"{x:349,y:562,t:1527019606485};\\\", \\\"{x:351,y:559,t:1527019606502};\\\", \\\"{x:352,y:556,t:1527019606520};\\\", \\\"{x:353,y:555,t:1527019606535};\\\", \\\"{x:354,y:552,t:1527019606551};\\\", \\\"{x:355,y:551,t:1527019606569};\\\", \\\"{x:356,y:548,t:1527019606586};\\\", \\\"{x:358,y:544,t:1527019606601};\\\", \\\"{x:360,y:542,t:1527019606619};\\\", \\\"{x:361,y:541,t:1527019606636};\\\", \\\"{x:362,y:540,t:1527019606652};\\\", \\\"{x:369,y:537,t:1527019606668};\\\", \\\"{x:370,y:536,t:1527019606686};\\\", \\\"{x:371,y:536,t:1527019606821};\\\", \\\"{x:373,y:536,t:1527019607005};\\\", \\\"{x:378,y:539,t:1527019607020};\\\", \\\"{x:384,y:555,t:1527019607036};\\\", \\\"{x:389,y:575,t:1527019607052};\\\", \\\"{x:396,y:590,t:1527019607069};\\\", \\\"{x:402,y:605,t:1527019607086};\\\", \\\"{x:408,y:619,t:1527019607101};\\\", \\\"{x:419,y:641,t:1527019607119};\\\", \\\"{x:437,y:664,t:1527019607136};\\\", \\\"{x:451,y:679,t:1527019607153};\\\", \\\"{x:464,y:691,t:1527019607169};\\\", \\\"{x:471,y:697,t:1527019607186};\\\", \\\"{x:475,y:700,t:1527019607203};\\\", \\\"{x:478,y:703,t:1527019607218};\\\", \\\"{x:480,y:705,t:1527019607236};\\\", \\\"{x:482,y:707,t:1527019607253};\\\", \\\"{x:483,y:708,t:1527019607269};\\\", \\\"{x:487,y:703,t:1527019607317};\\\", \\\"{x:487,y:692,t:1527019607325};\\\", \\\"{x:487,y:681,t:1527019607336};\\\", \\\"{x:483,y:649,t:1527019607353};\\\", \\\"{x:449,y:577,t:1527019607369};\\\", \\\"{x:420,y:535,t:1527019607386};\\\", \\\"{x:407,y:515,t:1527019607403};\\\", \\\"{x:402,y:506,t:1527019607420};\\\", \\\"{x:401,y:505,t:1527019607436};\\\", \\\"{x:401,y:507,t:1527019607566};\\\", \\\"{x:401,y:510,t:1527019607573};\\\", \\\"{x:401,y:514,t:1527019607587};\\\", \\\"{x:401,y:519,t:1527019607603};\\\", \\\"{x:401,y:522,t:1527019607621};\\\", \\\"{x:399,y:526,t:1527019607636};\\\", \\\"{x:398,y:527,t:1527019607653};\\\", \\\"{x:398,y:528,t:1527019607670};\\\", \\\"{x:396,y:531,t:1527019607687};\\\", \\\"{x:395,y:532,t:1527019607764};\\\", \\\"{x:395,y:534,t:1527019607780};\\\", \\\"{x:394,y:535,t:1527019607947};\\\", \\\"{x:394,y:537,t:1527019607988};\\\", \\\"{x:394,y:538,t:1527019608003};\\\", \\\"{x:394,y:546,t:1527019608020};\\\", \\\"{x:402,y:567,t:1527019608037};\\\", \\\"{x:412,y:584,t:1527019608053};\\\", \\\"{x:421,y:602,t:1527019608071};\\\", \\\"{x:433,y:618,t:1527019608086};\\\", \\\"{x:441,y:633,t:1527019608103};\\\", \\\"{x:450,y:647,t:1527019608120};\\\", \\\"{x:459,y:660,t:1527019608136};\\\", \\\"{x:464,y:667,t:1527019608153};\\\", \\\"{x:467,y:670,t:1527019608169};\\\", \\\"{x:472,y:674,t:1527019608186};\\\", \\\"{x:476,y:678,t:1527019608204};\\\", \\\"{x:484,y:687,t:1527019608220};\\\", \\\"{x:498,y:701,t:1527019608237};\\\", \\\"{x:506,y:711,t:1527019608253};\\\", \\\"{x:511,y:717,t:1527019608271};\\\", \\\"{x:513,y:721,t:1527019608287};\\\", \\\"{x:515,y:723,t:1527019608304};\\\", \\\"{x:515,y:724,t:1527019608320};\\\", \\\"{x:516,y:724,t:1527019608337};\\\", \\\"{x:516,y:725,t:1527019608354};\\\", \\\"{x:517,y:730,t:1527019608370};\\\", \\\"{x:518,y:731,t:1527019608387};\\\", \\\"{x:520,y:732,t:1527019608420};\\\", \\\"{x:520,y:733,t:1527019608540};\\\", \\\"{x:520,y:733,t:1527019608624};\\\", \\\"{x:520,y:734,t:1527019608764};\\\", \\\"{x:522,y:738,t:1527019608772};\\\", \\\"{x:525,y:744,t:1527019608786};\\\", \\\"{x:533,y:757,t:1527019608804};\\\", \\\"{x:547,y:773,t:1527019608820};\\\", \\\"{x:550,y:774,t:1527019608837};\\\" ] }, { \\\"rt\\\": 35405, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 268992, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -G -X -X -X -H -Z -O -O -O -G -G -02 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:774,t:1527019610044};\\\", \\\"{x:558,y:774,t:1527019610055};\\\", \\\"{x:563,y:773,t:1527019610072};\\\", \\\"{x:567,y:772,t:1527019610088};\\\", \\\"{x:577,y:770,t:1527019610105};\\\", \\\"{x:581,y:770,t:1527019610121};\\\", \\\"{x:582,y:769,t:1527019610382};\\\", \\\"{x:574,y:765,t:1527019610388};\\\", \\\"{x:539,y:739,t:1527019610404};\\\", \\\"{x:496,y:657,t:1527019610422};\\\", \\\"{x:470,y:571,t:1527019610438};\\\", \\\"{x:444,y:498,t:1527019610456};\\\", \\\"{x:426,y:456,t:1527019610472};\\\", \\\"{x:423,y:440,t:1527019610489};\\\", \\\"{x:421,y:422,t:1527019610505};\\\", \\\"{x:418,y:407,t:1527019610522};\\\", \\\"{x:417,y:401,t:1527019610539};\\\", \\\"{x:416,y:396,t:1527019610556};\\\", \\\"{x:413,y:387,t:1527019610572};\\\", \\\"{x:412,y:381,t:1527019610589};\\\", \\\"{x:412,y:377,t:1527019610606};\\\", \\\"{x:412,y:375,t:1527019610622};\\\", \\\"{x:413,y:372,t:1527019610640};\\\", \\\"{x:413,y:370,t:1527019610656};\\\", \\\"{x:415,y:370,t:1527019610674};\\\", \\\"{x:419,y:370,t:1527019610689};\\\", \\\"{x:435,y:377,t:1527019610706};\\\", \\\"{x:455,y:392,t:1527019610723};\\\", \\\"{x:472,y:410,t:1527019610740};\\\", \\\"{x:490,y:426,t:1527019610757};\\\", \\\"{x:514,y:450,t:1527019610773};\\\", \\\"{x:522,y:461,t:1527019610791};\\\", \\\"{x:525,y:468,t:1527019610807};\\\", \\\"{x:526,y:471,t:1527019610824};\\\", \\\"{x:526,y:472,t:1527019610845};\\\", \\\"{x:527,y:473,t:1527019610894};\\\", \\\"{x:527,y:474,t:1527019610907};\\\", \\\"{x:527,y:475,t:1527019610925};\\\", \\\"{x:527,y:473,t:1527019611046};\\\", \\\"{x:527,y:472,t:1527019611057};\\\", \\\"{x:528,y:468,t:1527019611075};\\\", \\\"{x:532,y:466,t:1527019611092};\\\", \\\"{x:535,y:464,t:1527019611109};\\\", \\\"{x:539,y:463,t:1527019611124};\\\", \\\"{x:548,y:462,t:1527019611141};\\\", \\\"{x:557,y:462,t:1527019611158};\\\", \\\"{x:564,y:462,t:1527019611175};\\\", \\\"{x:577,y:462,t:1527019611191};\\\", \\\"{x:589,y:462,t:1527019611208};\\\", \\\"{x:595,y:462,t:1527019611225};\\\", \\\"{x:598,y:462,t:1527019611242};\\\", \\\"{x:599,y:462,t:1527019611301};\\\", \\\"{x:600,y:463,t:1527019611309};\\\", \\\"{x:601,y:463,t:1527019611365};\\\", \\\"{x:602,y:463,t:1527019611414};\\\", \\\"{x:610,y:463,t:1527019611427};\\\", \\\"{x:667,y:489,t:1527019611443};\\\", \\\"{x:782,y:533,t:1527019611459};\\\", \\\"{x:925,y:595,t:1527019611473};\\\", \\\"{x:1068,y:650,t:1527019611490};\\\", \\\"{x:1194,y:699,t:1527019611506};\\\", \\\"{x:1304,y:745,t:1527019611522};\\\", \\\"{x:1389,y:780,t:1527019611539};\\\", \\\"{x:1427,y:804,t:1527019611556};\\\", \\\"{x:1445,y:818,t:1527019611573};\\\", \\\"{x:1446,y:820,t:1527019611933};\\\", \\\"{x:1445,y:820,t:1527019612094};\\\", \\\"{x:1444,y:820,t:1527019612174};\\\", \\\"{x:1442,y:820,t:1527019612190};\\\", \\\"{x:1436,y:822,t:1527019612208};\\\", \\\"{x:1425,y:825,t:1527019612224};\\\", \\\"{x:1408,y:827,t:1527019612241};\\\", \\\"{x:1387,y:831,t:1527019612256};\\\", \\\"{x:1362,y:838,t:1527019612274};\\\", \\\"{x:1345,y:844,t:1527019612290};\\\", \\\"{x:1333,y:847,t:1527019612308};\\\", \\\"{x:1318,y:854,t:1527019612324};\\\", \\\"{x:1306,y:858,t:1527019612340};\\\", \\\"{x:1291,y:863,t:1527019612356};\\\", \\\"{x:1275,y:872,t:1527019612373};\\\", \\\"{x:1262,y:879,t:1527019612390};\\\", \\\"{x:1243,y:887,t:1527019612407};\\\", \\\"{x:1232,y:894,t:1527019612423};\\\", \\\"{x:1224,y:901,t:1527019612440};\\\", \\\"{x:1217,y:908,t:1527019612457};\\\", \\\"{x:1210,y:918,t:1527019612473};\\\", \\\"{x:1203,y:925,t:1527019612490};\\\", \\\"{x:1196,y:934,t:1527019612507};\\\", \\\"{x:1190,y:941,t:1527019612523};\\\", \\\"{x:1181,y:948,t:1527019612541};\\\", \\\"{x:1178,y:951,t:1527019612556};\\\", \\\"{x:1173,y:955,t:1527019612573};\\\", \\\"{x:1169,y:958,t:1527019612590};\\\", \\\"{x:1167,y:960,t:1527019612607};\\\", \\\"{x:1163,y:963,t:1527019612623};\\\", \\\"{x:1163,y:962,t:1527019612950};\\\", \\\"{x:1165,y:962,t:1527019613133};\\\", \\\"{x:1166,y:962,t:1527019613190};\\\", \\\"{x:1167,y:962,t:1527019613518};\\\", \\\"{x:1169,y:962,t:1527019613550};\\\", \\\"{x:1171,y:964,t:1527019613582};\\\", \\\"{x:1171,y:965,t:1527019613592};\\\", \\\"{x:1174,y:967,t:1527019613607};\\\", \\\"{x:1178,y:967,t:1527019613625};\\\", \\\"{x:1180,y:967,t:1527019613642};\\\", \\\"{x:1181,y:967,t:1527019613659};\\\", \\\"{x:1182,y:967,t:1527019613901};\\\", \\\"{x:1182,y:965,t:1527019614078};\\\", \\\"{x:1182,y:964,t:1527019614093};\\\", \\\"{x:1182,y:961,t:1527019614109};\\\", \\\"{x:1183,y:958,t:1527019614125};\\\", \\\"{x:1183,y:957,t:1527019614141};\\\", \\\"{x:1184,y:953,t:1527019614159};\\\", \\\"{x:1184,y:948,t:1527019614176};\\\", \\\"{x:1184,y:946,t:1527019614191};\\\", \\\"{x:1183,y:941,t:1527019614209};\\\", \\\"{x:1177,y:941,t:1527019614226};\\\", \\\"{x:1168,y:941,t:1527019614242};\\\", \\\"{x:1151,y:939,t:1527019614259};\\\", \\\"{x:1139,y:937,t:1527019614276};\\\", \\\"{x:1127,y:933,t:1527019614292};\\\", \\\"{x:1117,y:930,t:1527019614308};\\\", \\\"{x:1103,y:927,t:1527019614325};\\\", \\\"{x:1100,y:925,t:1527019614342};\\\", \\\"{x:1098,y:925,t:1527019614390};\\\", \\\"{x:1098,y:924,t:1527019614397};\\\", \\\"{x:1098,y:921,t:1527019614409};\\\", \\\"{x:1098,y:914,t:1527019614425};\\\", \\\"{x:1100,y:896,t:1527019614442};\\\", \\\"{x:1110,y:869,t:1527019614459};\\\", \\\"{x:1117,y:847,t:1527019614475};\\\", \\\"{x:1127,y:823,t:1527019614491};\\\", \\\"{x:1136,y:807,t:1527019614509};\\\", \\\"{x:1145,y:795,t:1527019614525};\\\", \\\"{x:1149,y:791,t:1527019614542};\\\", \\\"{x:1151,y:788,t:1527019614558};\\\", \\\"{x:1153,y:786,t:1527019614575};\\\", \\\"{x:1154,y:785,t:1527019614593};\\\", \\\"{x:1157,y:785,t:1527019614637};\\\", \\\"{x:1159,y:789,t:1527019614645};\\\", \\\"{x:1162,y:796,t:1527019614658};\\\", \\\"{x:1170,y:815,t:1527019614675};\\\", \\\"{x:1187,y:852,t:1527019614692};\\\", \\\"{x:1204,y:875,t:1527019614708};\\\", \\\"{x:1214,y:896,t:1527019614725};\\\", \\\"{x:1218,y:911,t:1527019614742};\\\", \\\"{x:1221,y:920,t:1527019614758};\\\", \\\"{x:1224,y:925,t:1527019614775};\\\", \\\"{x:1225,y:921,t:1527019614845};\\\", \\\"{x:1225,y:914,t:1527019614858};\\\", \\\"{x:1222,y:901,t:1527019614875};\\\", \\\"{x:1218,y:891,t:1527019614892};\\\", \\\"{x:1214,y:884,t:1527019614908};\\\", \\\"{x:1212,y:880,t:1527019614925};\\\", \\\"{x:1208,y:877,t:1527019614942};\\\", \\\"{x:1206,y:875,t:1527019614959};\\\", \\\"{x:1205,y:872,t:1527019614975};\\\", \\\"{x:1205,y:865,t:1527019614993};\\\", \\\"{x:1203,y:861,t:1527019615009};\\\", \\\"{x:1203,y:856,t:1527019615025};\\\", \\\"{x:1204,y:853,t:1527019615042};\\\", \\\"{x:1204,y:849,t:1527019615060};\\\", \\\"{x:1208,y:844,t:1527019615076};\\\", \\\"{x:1213,y:836,t:1527019615093};\\\", \\\"{x:1220,y:827,t:1527019615109};\\\", \\\"{x:1229,y:818,t:1527019615125};\\\", \\\"{x:1234,y:815,t:1527019615143};\\\", \\\"{x:1236,y:812,t:1527019615160};\\\", \\\"{x:1236,y:813,t:1527019615237};\\\", \\\"{x:1235,y:819,t:1527019615245};\\\", \\\"{x:1231,y:827,t:1527019615259};\\\", \\\"{x:1213,y:852,t:1527019615275};\\\", \\\"{x:1181,y:900,t:1527019615292};\\\", \\\"{x:1175,y:904,t:1527019615309};\\\", \\\"{x:1175,y:905,t:1527019615325};\\\", \\\"{x:1174,y:906,t:1527019615342};\\\", \\\"{x:1174,y:911,t:1527019615359};\\\", \\\"{x:1176,y:911,t:1527019615446};\\\", \\\"{x:1179,y:910,t:1527019615460};\\\", \\\"{x:1186,y:901,t:1527019615476};\\\", \\\"{x:1204,y:881,t:1527019615492};\\\", \\\"{x:1214,y:869,t:1527019615509};\\\", \\\"{x:1220,y:854,t:1527019615525};\\\", \\\"{x:1228,y:843,t:1527019615542};\\\", \\\"{x:1233,y:838,t:1527019615559};\\\", \\\"{x:1238,y:834,t:1527019615576};\\\", \\\"{x:1240,y:833,t:1527019615592};\\\", \\\"{x:1241,y:832,t:1527019615607};\\\", \\\"{x:1242,y:832,t:1527019615627};\\\", \\\"{x:1244,y:835,t:1527019615640};\\\", \\\"{x:1246,y:843,t:1527019615657};\\\", \\\"{x:1253,y:870,t:1527019615673};\\\", \\\"{x:1256,y:884,t:1527019615690};\\\", \\\"{x:1259,y:897,t:1527019615707};\\\", \\\"{x:1260,y:906,t:1527019615724};\\\", \\\"{x:1260,y:912,t:1527019615740};\\\", \\\"{x:1261,y:914,t:1527019615757};\\\", \\\"{x:1262,y:915,t:1527019615818};\\\", \\\"{x:1263,y:915,t:1527019615826};\\\", \\\"{x:1263,y:914,t:1527019615840};\\\", \\\"{x:1264,y:909,t:1527019615857};\\\", \\\"{x:1264,y:906,t:1527019615874};\\\", \\\"{x:1262,y:907,t:1527019615947};\\\", \\\"{x:1262,y:909,t:1527019615957};\\\", \\\"{x:1259,y:917,t:1527019615974};\\\", \\\"{x:1256,y:927,t:1527019615991};\\\", \\\"{x:1254,y:933,t:1527019616008};\\\", \\\"{x:1253,y:936,t:1527019616024};\\\", \\\"{x:1253,y:937,t:1527019616041};\\\", \\\"{x:1251,y:939,t:1527019616059};\\\", \\\"{x:1250,y:939,t:1527019616083};\\\", \\\"{x:1250,y:940,t:1527019616099};\\\", \\\"{x:1248,y:940,t:1527019616387};\\\", \\\"{x:1247,y:940,t:1527019616668};\\\", \\\"{x:1248,y:940,t:1527019617499};\\\", \\\"{x:1249,y:940,t:1527019617509};\\\", \\\"{x:1255,y:940,t:1527019617525};\\\", \\\"{x:1258,y:942,t:1527019617542};\\\", \\\"{x:1261,y:944,t:1527019617558};\\\", \\\"{x:1266,y:944,t:1527019617575};\\\", \\\"{x:1268,y:944,t:1527019617627};\\\", \\\"{x:1271,y:947,t:1527019617642};\\\", \\\"{x:1280,y:948,t:1527019617658};\\\", \\\"{x:1282,y:948,t:1527019617675};\\\", \\\"{x:1286,y:950,t:1527019617692};\\\", \\\"{x:1289,y:951,t:1527019617708};\\\", \\\"{x:1294,y:954,t:1527019617725};\\\", \\\"{x:1303,y:956,t:1527019617742};\\\", \\\"{x:1313,y:959,t:1527019617758};\\\", \\\"{x:1324,y:960,t:1527019617775};\\\", \\\"{x:1334,y:961,t:1527019617792};\\\", \\\"{x:1349,y:962,t:1527019617808};\\\", \\\"{x:1364,y:964,t:1527019617825};\\\", \\\"{x:1378,y:966,t:1527019617843};\\\", \\\"{x:1385,y:966,t:1527019617858};\\\", \\\"{x:1397,y:967,t:1527019617875};\\\", \\\"{x:1404,y:968,t:1527019617892};\\\", \\\"{x:1411,y:968,t:1527019617910};\\\", \\\"{x:1418,y:968,t:1527019617925};\\\", \\\"{x:1425,y:968,t:1527019617942};\\\", \\\"{x:1434,y:968,t:1527019617959};\\\", \\\"{x:1443,y:968,t:1527019617975};\\\", \\\"{x:1452,y:968,t:1527019617992};\\\", \\\"{x:1462,y:968,t:1527019618009};\\\", \\\"{x:1464,y:968,t:1527019618025};\\\", \\\"{x:1466,y:968,t:1527019618042};\\\", \\\"{x:1468,y:968,t:1527019618059};\\\", \\\"{x:1470,y:968,t:1527019618075};\\\", \\\"{x:1472,y:968,t:1527019618092};\\\", \\\"{x:1476,y:968,t:1527019618109};\\\", \\\"{x:1477,y:968,t:1527019618125};\\\", \\\"{x:1478,y:968,t:1527019618179};\\\", \\\"{x:1477,y:968,t:1527019619091};\\\", \\\"{x:1468,y:967,t:1527019619098};\\\", \\\"{x:1456,y:964,t:1527019619110};\\\", \\\"{x:1431,y:960,t:1527019619127};\\\", \\\"{x:1406,y:956,t:1527019619143};\\\", \\\"{x:1388,y:952,t:1527019619159};\\\", \\\"{x:1368,y:946,t:1527019619176};\\\", \\\"{x:1350,y:942,t:1527019619194};\\\", \\\"{x:1337,y:938,t:1527019619210};\\\", \\\"{x:1325,y:934,t:1527019619227};\\\", \\\"{x:1324,y:932,t:1527019619243};\\\", \\\"{x:1323,y:929,t:1527019619260};\\\", \\\"{x:1323,y:923,t:1527019619277};\\\", \\\"{x:1323,y:917,t:1527019619294};\\\", \\\"{x:1321,y:908,t:1527019619311};\\\", \\\"{x:1319,y:899,t:1527019619327};\\\", \\\"{x:1319,y:893,t:1527019619343};\\\", \\\"{x:1320,y:887,t:1527019619361};\\\", \\\"{x:1321,y:879,t:1527019619377};\\\", \\\"{x:1322,y:873,t:1527019619394};\\\", \\\"{x:1322,y:870,t:1527019619411};\\\", \\\"{x:1324,y:863,t:1527019619427};\\\", \\\"{x:1327,y:849,t:1527019619444};\\\", \\\"{x:1328,y:835,t:1527019619461};\\\", \\\"{x:1330,y:825,t:1527019619477};\\\", \\\"{x:1334,y:812,t:1527019619493};\\\", \\\"{x:1339,y:800,t:1527019619511};\\\", \\\"{x:1343,y:780,t:1527019619526};\\\", \\\"{x:1350,y:763,t:1527019619546};\\\", \\\"{x:1353,y:746,t:1527019619560};\\\", \\\"{x:1355,y:727,t:1527019619576};\\\", \\\"{x:1359,y:706,t:1527019619593};\\\", \\\"{x:1372,y:676,t:1527019619610};\\\", \\\"{x:1378,y:651,t:1527019619626};\\\", \\\"{x:1384,y:630,t:1527019619643};\\\", \\\"{x:1389,y:616,t:1527019619660};\\\", \\\"{x:1391,y:600,t:1527019619676};\\\", \\\"{x:1392,y:585,t:1527019619693};\\\", \\\"{x:1393,y:576,t:1527019619710};\\\", \\\"{x:1394,y:572,t:1527019619727};\\\", \\\"{x:1396,y:568,t:1527019619743};\\\", \\\"{x:1399,y:563,t:1527019619760};\\\", \\\"{x:1400,y:561,t:1527019619777};\\\", \\\"{x:1401,y:559,t:1527019619793};\\\", \\\"{x:1403,y:557,t:1527019619811};\\\", \\\"{x:1403,y:556,t:1527019619826};\\\", \\\"{x:1404,y:555,t:1527019619844};\\\", \\\"{x:1406,y:556,t:1527019620019};\\\", \\\"{x:1407,y:558,t:1527019620027};\\\", \\\"{x:1408,y:559,t:1527019620043};\\\", \\\"{x:1410,y:562,t:1527019620061};\\\", \\\"{x:1411,y:564,t:1527019620077};\\\", \\\"{x:1412,y:567,t:1527019620093};\\\", \\\"{x:1414,y:569,t:1527019620112};\\\", \\\"{x:1414,y:571,t:1527019620131};\\\", \\\"{x:1414,y:572,t:1527019620144};\\\", \\\"{x:1416,y:575,t:1527019620160};\\\", \\\"{x:1416,y:577,t:1527019620177};\\\", \\\"{x:1418,y:580,t:1527019620194};\\\", \\\"{x:1421,y:585,t:1527019620210};\\\", \\\"{x:1423,y:588,t:1527019620228};\\\", \\\"{x:1424,y:593,t:1527019620245};\\\", \\\"{x:1427,y:598,t:1527019620260};\\\", \\\"{x:1429,y:603,t:1527019620277};\\\", \\\"{x:1432,y:610,t:1527019620294};\\\", \\\"{x:1435,y:615,t:1527019620310};\\\", \\\"{x:1435,y:618,t:1527019620328};\\\", \\\"{x:1436,y:621,t:1527019620344};\\\", \\\"{x:1438,y:626,t:1527019620361};\\\", \\\"{x:1438,y:628,t:1527019620378};\\\", \\\"{x:1440,y:634,t:1527019620394};\\\", \\\"{x:1443,y:638,t:1527019620411};\\\", \\\"{x:1444,y:641,t:1527019620428};\\\", \\\"{x:1446,y:647,t:1527019620444};\\\", \\\"{x:1448,y:654,t:1527019620460};\\\", \\\"{x:1451,y:659,t:1527019620477};\\\", \\\"{x:1452,y:662,t:1527019620494};\\\", \\\"{x:1454,y:665,t:1527019620511};\\\", \\\"{x:1454,y:666,t:1527019620527};\\\", \\\"{x:1455,y:669,t:1527019620545};\\\", \\\"{x:1456,y:671,t:1527019620560};\\\", \\\"{x:1457,y:673,t:1527019620578};\\\", \\\"{x:1458,y:675,t:1527019620595};\\\", \\\"{x:1459,y:676,t:1527019620619};\\\", \\\"{x:1459,y:677,t:1527019620627};\\\", \\\"{x:1459,y:678,t:1527019620644};\\\", \\\"{x:1460,y:678,t:1527019620661};\\\", \\\"{x:1460,y:681,t:1527019620677};\\\", \\\"{x:1460,y:682,t:1527019620694};\\\", \\\"{x:1461,y:683,t:1527019620712};\\\", \\\"{x:1461,y:684,t:1527019620739};\\\", \\\"{x:1462,y:684,t:1527019620747};\\\", \\\"{x:1463,y:686,t:1527019620763};\\\", \\\"{x:1464,y:688,t:1527019620779};\\\", \\\"{x:1465,y:690,t:1527019620794};\\\", \\\"{x:1467,y:693,t:1527019620811};\\\", \\\"{x:1468,y:696,t:1527019620828};\\\", \\\"{x:1470,y:699,t:1527019620845};\\\", \\\"{x:1472,y:702,t:1527019620862};\\\", \\\"{x:1475,y:706,t:1527019620878};\\\", \\\"{x:1477,y:711,t:1527019620894};\\\", \\\"{x:1480,y:717,t:1527019620912};\\\", \\\"{x:1485,y:725,t:1527019620927};\\\", \\\"{x:1488,y:732,t:1527019620944};\\\", \\\"{x:1493,y:743,t:1527019620961};\\\", \\\"{x:1498,y:753,t:1527019620977};\\\", \\\"{x:1504,y:767,t:1527019620994};\\\", \\\"{x:1507,y:772,t:1527019621011};\\\", \\\"{x:1509,y:777,t:1527019621027};\\\", \\\"{x:1510,y:779,t:1527019621044};\\\", \\\"{x:1512,y:783,t:1527019621061};\\\", \\\"{x:1513,y:785,t:1527019621077};\\\", \\\"{x:1513,y:789,t:1527019621094};\\\", \\\"{x:1517,y:792,t:1527019621111};\\\", \\\"{x:1517,y:796,t:1527019621128};\\\", \\\"{x:1519,y:800,t:1527019621145};\\\", \\\"{x:1521,y:805,t:1527019621162};\\\", \\\"{x:1525,y:813,t:1527019621178};\\\", \\\"{x:1526,y:817,t:1527019621194};\\\", \\\"{x:1527,y:820,t:1527019621211};\\\", \\\"{x:1528,y:823,t:1527019621228};\\\", \\\"{x:1531,y:828,t:1527019621244};\\\", \\\"{x:1534,y:834,t:1527019621261};\\\", \\\"{x:1537,y:840,t:1527019621278};\\\", \\\"{x:1539,y:845,t:1527019621294};\\\", \\\"{x:1541,y:851,t:1527019621312};\\\", \\\"{x:1544,y:855,t:1527019621329};\\\", \\\"{x:1546,y:860,t:1527019621345};\\\", \\\"{x:1548,y:866,t:1527019621362};\\\", \\\"{x:1553,y:875,t:1527019621378};\\\", \\\"{x:1556,y:881,t:1527019621394};\\\", \\\"{x:1559,y:887,t:1527019621412};\\\", \\\"{x:1561,y:891,t:1527019621429};\\\", \\\"{x:1564,y:896,t:1527019621445};\\\", \\\"{x:1565,y:899,t:1527019621462};\\\", \\\"{x:1569,y:906,t:1527019621479};\\\", \\\"{x:1572,y:909,t:1527019621494};\\\", \\\"{x:1574,y:913,t:1527019621512};\\\", \\\"{x:1575,y:915,t:1527019621529};\\\", \\\"{x:1577,y:918,t:1527019621545};\\\", \\\"{x:1579,y:920,t:1527019621562};\\\", \\\"{x:1583,y:925,t:1527019621578};\\\", \\\"{x:1586,y:928,t:1527019621595};\\\", \\\"{x:1589,y:932,t:1527019621611};\\\", \\\"{x:1591,y:934,t:1527019621628};\\\", \\\"{x:1592,y:935,t:1527019621645};\\\", \\\"{x:1593,y:937,t:1527019621661};\\\", \\\"{x:1595,y:939,t:1527019621678};\\\", \\\"{x:1597,y:941,t:1527019621695};\\\", \\\"{x:1597,y:942,t:1527019621711};\\\", \\\"{x:1600,y:945,t:1527019621728};\\\", \\\"{x:1602,y:946,t:1527019621745};\\\", \\\"{x:1603,y:948,t:1527019621761};\\\", \\\"{x:1603,y:949,t:1527019621778};\\\", \\\"{x:1605,y:950,t:1527019621795};\\\", \\\"{x:1605,y:951,t:1527019621818};\\\", \\\"{x:1606,y:952,t:1527019621829};\\\", \\\"{x:1607,y:954,t:1527019621845};\\\", \\\"{x:1607,y:955,t:1527019621891};\\\", \\\"{x:1608,y:955,t:1527019621964};\\\", \\\"{x:1608,y:956,t:1527019621979};\\\", \\\"{x:1608,y:957,t:1527019622002};\\\", \\\"{x:1608,y:959,t:1527019622059};\\\", \\\"{x:1608,y:960,t:1527019622074};\\\", \\\"{x:1608,y:961,t:1527019622090};\\\", \\\"{x:1608,y:962,t:1527019622098};\\\", \\\"{x:1606,y:962,t:1527019622899};\\\", \\\"{x:1605,y:962,t:1527019622963};\\\", \\\"{x:1604,y:962,t:1527019623003};\\\", \\\"{x:1603,y:962,t:1527019623908};\\\", \\\"{x:1596,y:959,t:1527019624563};\\\", \\\"{x:1552,y:934,t:1527019624581};\\\", \\\"{x:1466,y:897,t:1527019624598};\\\", \\\"{x:1351,y:848,t:1527019624614};\\\", \\\"{x:1242,y:792,t:1527019624631};\\\", \\\"{x:1135,y:736,t:1527019624648};\\\", \\\"{x:1026,y:695,t:1527019624664};\\\", \\\"{x:948,y:661,t:1527019624680};\\\", \\\"{x:940,y:658,t:1527019624698};\\\", \\\"{x:939,y:658,t:1527019624731};\\\", \\\"{x:939,y:657,t:1527019624762};\\\", \\\"{x:937,y:657,t:1527019624835};\\\", \\\"{x:936,y:657,t:1527019624850};\\\", \\\"{x:933,y:657,t:1527019624863};\\\", \\\"{x:929,y:657,t:1527019624881};\\\", \\\"{x:923,y:657,t:1527019624897};\\\", \\\"{x:914,y:658,t:1527019624913};\\\", \\\"{x:886,y:658,t:1527019624930};\\\", \\\"{x:877,y:658,t:1527019624948};\\\", \\\"{x:869,y:658,t:1527019624964};\\\", \\\"{x:864,y:656,t:1527019624980};\\\", \\\"{x:860,y:656,t:1527019624998};\\\", \\\"{x:854,y:653,t:1527019625015};\\\", \\\"{x:851,y:648,t:1527019625030};\\\", \\\"{x:841,y:646,t:1527019625047};\\\", \\\"{x:822,y:637,t:1527019625064};\\\", \\\"{x:801,y:629,t:1527019625081};\\\", \\\"{x:766,y:616,t:1527019625097};\\\", \\\"{x:724,y:602,t:1527019625113};\\\", \\\"{x:702,y:590,t:1527019625131};\\\", \\\"{x:688,y:583,t:1527019625148};\\\", \\\"{x:683,y:579,t:1527019625164};\\\", \\\"{x:679,y:574,t:1527019625181};\\\", \\\"{x:679,y:571,t:1527019625198};\\\", \\\"{x:676,y:569,t:1527019625215};\\\", \\\"{x:676,y:564,t:1527019625231};\\\", \\\"{x:676,y:558,t:1527019625249};\\\", \\\"{x:676,y:554,t:1527019625266};\\\", \\\"{x:676,y:551,t:1527019625281};\\\", \\\"{x:677,y:547,t:1527019625298};\\\", \\\"{x:690,y:546,t:1527019625314};\\\", \\\"{x:713,y:546,t:1527019625331};\\\", \\\"{x:745,y:546,t:1527019625349};\\\", \\\"{x:778,y:546,t:1527019625364};\\\", \\\"{x:810,y:542,t:1527019625382};\\\", \\\"{x:837,y:542,t:1527019625399};\\\", \\\"{x:851,y:543,t:1527019625414};\\\", \\\"{x:858,y:543,t:1527019625432};\\\", \\\"{x:860,y:543,t:1527019625448};\\\", \\\"{x:861,y:543,t:1527019625465};\\\", \\\"{x:856,y:543,t:1527019625681};\\\", \\\"{x:850,y:542,t:1527019625699};\\\", \\\"{x:842,y:541,t:1527019625715};\\\", \\\"{x:838,y:539,t:1527019625732};\\\", \\\"{x:835,y:538,t:1527019625748};\\\", \\\"{x:838,y:538,t:1527019626074};\\\", \\\"{x:843,y:538,t:1527019626082};\\\", \\\"{x:860,y:541,t:1527019626099};\\\", \\\"{x:888,y:547,t:1527019626115};\\\", \\\"{x:918,y:558,t:1527019626133};\\\", \\\"{x:947,y:569,t:1527019626150};\\\", \\\"{x:976,y:580,t:1527019626166};\\\", \\\"{x:1021,y:600,t:1527019626182};\\\", \\\"{x:1077,y:627,t:1527019626199};\\\", \\\"{x:1124,y:641,t:1527019626216};\\\", \\\"{x:1161,y:658,t:1527019626232};\\\", \\\"{x:1185,y:673,t:1527019626250};\\\", \\\"{x:1222,y:690,t:1527019626266};\\\", \\\"{x:1238,y:699,t:1527019626283};\\\", \\\"{x:1245,y:704,t:1527019626299};\\\", \\\"{x:1257,y:709,t:1527019626316};\\\", \\\"{x:1270,y:713,t:1527019626332};\\\", \\\"{x:1292,y:724,t:1527019626349};\\\", \\\"{x:1309,y:732,t:1527019626366};\\\", \\\"{x:1328,y:742,t:1527019626382};\\\", \\\"{x:1351,y:749,t:1527019626400};\\\", \\\"{x:1376,y:755,t:1527019626416};\\\", \\\"{x:1398,y:762,t:1527019626432};\\\", \\\"{x:1419,y:775,t:1527019626449};\\\", \\\"{x:1436,y:788,t:1527019626465};\\\", \\\"{x:1445,y:798,t:1527019626482};\\\", \\\"{x:1454,y:808,t:1527019626499};\\\", \\\"{x:1458,y:815,t:1527019626516};\\\", \\\"{x:1460,y:821,t:1527019626533};\\\", \\\"{x:1461,y:825,t:1527019626549};\\\", \\\"{x:1463,y:831,t:1527019626567};\\\", \\\"{x:1463,y:836,t:1527019626582};\\\", \\\"{x:1463,y:841,t:1527019626600};\\\", \\\"{x:1463,y:845,t:1527019626617};\\\", \\\"{x:1463,y:848,t:1527019626633};\\\", \\\"{x:1463,y:851,t:1527019626650};\\\", \\\"{x:1464,y:853,t:1527019626666};\\\", \\\"{x:1464,y:855,t:1527019626682};\\\", \\\"{x:1465,y:855,t:1527019626763};\\\", \\\"{x:1468,y:853,t:1527019626779};\\\", \\\"{x:1470,y:848,t:1527019626786};\\\", \\\"{x:1474,y:843,t:1527019626800};\\\", \\\"{x:1478,y:832,t:1527019626817};\\\", \\\"{x:1482,y:826,t:1527019626834};\\\", \\\"{x:1483,y:823,t:1527019626851};\\\", \\\"{x:1483,y:826,t:1527019626908};\\\", \\\"{x:1482,y:833,t:1527019626917};\\\", \\\"{x:1478,y:846,t:1527019626934};\\\", \\\"{x:1473,y:858,t:1527019626949};\\\", \\\"{x:1471,y:870,t:1527019626967};\\\", \\\"{x:1466,y:878,t:1527019626983};\\\", \\\"{x:1465,y:881,t:1527019627000};\\\", \\\"{x:1464,y:883,t:1527019627017};\\\", \\\"{x:1464,y:880,t:1527019627075};\\\", \\\"{x:1464,y:877,t:1527019627084};\\\", \\\"{x:1464,y:865,t:1527019627100};\\\", \\\"{x:1466,y:844,t:1527019627117};\\\", \\\"{x:1470,y:824,t:1527019627134};\\\", \\\"{x:1479,y:799,t:1527019627151};\\\", \\\"{x:1489,y:776,t:1527019627167};\\\", \\\"{x:1498,y:755,t:1527019627184};\\\", \\\"{x:1507,y:737,t:1527019627201};\\\", \\\"{x:1511,y:725,t:1527019627216};\\\", \\\"{x:1513,y:716,t:1527019627234};\\\", \\\"{x:1516,y:711,t:1527019627250};\\\", \\\"{x:1518,y:706,t:1527019627267};\\\", \\\"{x:1519,y:705,t:1527019627284};\\\", \\\"{x:1519,y:704,t:1527019627301};\\\", \\\"{x:1520,y:702,t:1527019627317};\\\", \\\"{x:1523,y:697,t:1527019627334};\\\", \\\"{x:1525,y:694,t:1527019627351};\\\", \\\"{x:1531,y:687,t:1527019627366};\\\", \\\"{x:1535,y:680,t:1527019627384};\\\", \\\"{x:1539,y:675,t:1527019627401};\\\", \\\"{x:1544,y:666,t:1527019627416};\\\", \\\"{x:1552,y:656,t:1527019627434};\\\", \\\"{x:1561,y:643,t:1527019627450};\\\", \\\"{x:1565,y:638,t:1527019627466};\\\", \\\"{x:1567,y:636,t:1527019627484};\\\", \\\"{x:1568,y:635,t:1527019627501};\\\", \\\"{x:1568,y:634,t:1527019627529};\\\", \\\"{x:1570,y:633,t:1527019627537};\\\", \\\"{x:1571,y:632,t:1527019627554};\\\", \\\"{x:1572,y:631,t:1527019627566};\\\", \\\"{x:1573,y:630,t:1527019627584};\\\", \\\"{x:1574,y:629,t:1527019627618};\\\", \\\"{x:1575,y:629,t:1527019627634};\\\", \\\"{x:1576,y:629,t:1527019627650};\\\", \\\"{x:1578,y:629,t:1527019627668};\\\", \\\"{x:1579,y:629,t:1527019627731};\\\", \\\"{x:1580,y:630,t:1527019627738};\\\", \\\"{x:1580,y:632,t:1527019627750};\\\", \\\"{x:1580,y:636,t:1527019627768};\\\", \\\"{x:1580,y:641,t:1527019627784};\\\", \\\"{x:1580,y:644,t:1527019627801};\\\", \\\"{x:1578,y:649,t:1527019627818};\\\", \\\"{x:1577,y:651,t:1527019627834};\\\", \\\"{x:1577,y:652,t:1527019627850};\\\", \\\"{x:1576,y:653,t:1527019627868};\\\", \\\"{x:1575,y:654,t:1527019627884};\\\", \\\"{x:1571,y:658,t:1527019627901};\\\", \\\"{x:1567,y:665,t:1527019627918};\\\", \\\"{x:1561,y:672,t:1527019627934};\\\", \\\"{x:1553,y:682,t:1527019627951};\\\", \\\"{x:1548,y:691,t:1527019627968};\\\", \\\"{x:1543,y:706,t:1527019627985};\\\", \\\"{x:1539,y:721,t:1527019628001};\\\", \\\"{x:1532,y:736,t:1527019628018};\\\", \\\"{x:1528,y:753,t:1527019628035};\\\", \\\"{x:1516,y:780,t:1527019628051};\\\", \\\"{x:1510,y:797,t:1527019628068};\\\", \\\"{x:1506,y:814,t:1527019628084};\\\", \\\"{x:1501,y:833,t:1527019628101};\\\", \\\"{x:1499,y:848,t:1527019628118};\\\", \\\"{x:1496,y:860,t:1527019628135};\\\", \\\"{x:1495,y:868,t:1527019628151};\\\", \\\"{x:1494,y:877,t:1527019628168};\\\", \\\"{x:1490,y:890,t:1527019628185};\\\", \\\"{x:1486,y:900,t:1527019628201};\\\", \\\"{x:1482,y:908,t:1527019628218};\\\", \\\"{x:1477,y:916,t:1527019628235};\\\", \\\"{x:1475,y:921,t:1527019628251};\\\", \\\"{x:1472,y:926,t:1527019628268};\\\", \\\"{x:1469,y:931,t:1527019628284};\\\", \\\"{x:1466,y:934,t:1527019628301};\\\", \\\"{x:1465,y:936,t:1527019628318};\\\", \\\"{x:1464,y:938,t:1527019628335};\\\", \\\"{x:1462,y:940,t:1527019628351};\\\", \\\"{x:1462,y:942,t:1527019628368};\\\", \\\"{x:1461,y:943,t:1527019628385};\\\", \\\"{x:1462,y:943,t:1527019628483};\\\", \\\"{x:1467,y:942,t:1527019628491};\\\", \\\"{x:1471,y:942,t:1527019628502};\\\", \\\"{x:1493,y:940,t:1527019628518};\\\", \\\"{x:1516,y:940,t:1527019628535};\\\", \\\"{x:1543,y:940,t:1527019628552};\\\", \\\"{x:1566,y:940,t:1527019628568};\\\", \\\"{x:1586,y:940,t:1527019628585};\\\", \\\"{x:1593,y:940,t:1527019628602};\\\", \\\"{x:1598,y:939,t:1527019628618};\\\", \\\"{x:1605,y:936,t:1527019628635};\\\", \\\"{x:1611,y:935,t:1527019628651};\\\", \\\"{x:1616,y:933,t:1527019628667};\\\", \\\"{x:1623,y:929,t:1527019628685};\\\", \\\"{x:1632,y:927,t:1527019628701};\\\", \\\"{x:1641,y:926,t:1527019628717};\\\", \\\"{x:1648,y:926,t:1527019628734};\\\", \\\"{x:1652,y:926,t:1527019628752};\\\", \\\"{x:1653,y:926,t:1527019628768};\\\", \\\"{x:1655,y:926,t:1527019628785};\\\", \\\"{x:1656,y:926,t:1527019628802};\\\", \\\"{x:1660,y:926,t:1527019628818};\\\", \\\"{x:1668,y:928,t:1527019628834};\\\", \\\"{x:1674,y:931,t:1527019628852};\\\", \\\"{x:1681,y:933,t:1527019628869};\\\", \\\"{x:1685,y:935,t:1527019628884};\\\", \\\"{x:1689,y:938,t:1527019628902};\\\", \\\"{x:1692,y:942,t:1527019628919};\\\", \\\"{x:1693,y:942,t:1527019628935};\\\", \\\"{x:1696,y:944,t:1527019628951};\\\", \\\"{x:1696,y:945,t:1527019628969};\\\", \\\"{x:1698,y:945,t:1527019628985};\\\", \\\"{x:1701,y:948,t:1527019629002};\\\", \\\"{x:1703,y:951,t:1527019629019};\\\", \\\"{x:1705,y:952,t:1527019629034};\\\", \\\"{x:1708,y:953,t:1527019629052};\\\", \\\"{x:1711,y:954,t:1527019629069};\\\", \\\"{x:1713,y:955,t:1527019629085};\\\", \\\"{x:1716,y:957,t:1527019629102};\\\", \\\"{x:1718,y:959,t:1527019629119};\\\", \\\"{x:1720,y:959,t:1527019629135};\\\", \\\"{x:1723,y:961,t:1527019629152};\\\", \\\"{x:1725,y:961,t:1527019629168};\\\", \\\"{x:1726,y:961,t:1527019629187};\\\", \\\"{x:1727,y:961,t:1527019629202};\\\", \\\"{x:1728,y:962,t:1527019629219};\\\", \\\"{x:1729,y:962,t:1527019629235};\\\", \\\"{x:1732,y:963,t:1527019629251};\\\", \\\"{x:1733,y:964,t:1527019629269};\\\", \\\"{x:1735,y:964,t:1527019629284};\\\", \\\"{x:1735,y:965,t:1527019629523};\\\", \\\"{x:1736,y:965,t:1527019629555};\\\", \\\"{x:1736,y:966,t:1527019629634};\\\", \\\"{x:1736,y:967,t:1527019629652};\\\", \\\"{x:1735,y:967,t:1527019630483};\\\", \\\"{x:1732,y:966,t:1527019630491};\\\", \\\"{x:1724,y:959,t:1527019630503};\\\", \\\"{x:1702,y:944,t:1527019630520};\\\", \\\"{x:1676,y:926,t:1527019630536};\\\", \\\"{x:1652,y:905,t:1527019630553};\\\", \\\"{x:1635,y:886,t:1527019630570};\\\", \\\"{x:1622,y:850,t:1527019630587};\\\", \\\"{x:1619,y:806,t:1527019630603};\\\", \\\"{x:1619,y:779,t:1527019630620};\\\", \\\"{x:1619,y:756,t:1527019630636};\\\", \\\"{x:1619,y:734,t:1527019630653};\\\", \\\"{x:1619,y:719,t:1527019630670};\\\", \\\"{x:1619,y:709,t:1527019630687};\\\", \\\"{x:1619,y:698,t:1527019630703};\\\", \\\"{x:1623,y:682,t:1527019630721};\\\", \\\"{x:1630,y:661,t:1527019630737};\\\", \\\"{x:1634,y:644,t:1527019630753};\\\", \\\"{x:1635,y:630,t:1527019630770};\\\", \\\"{x:1636,y:608,t:1527019630787};\\\", \\\"{x:1633,y:594,t:1527019630803};\\\", \\\"{x:1629,y:583,t:1527019630820};\\\", \\\"{x:1621,y:571,t:1527019630837};\\\", \\\"{x:1613,y:559,t:1527019630853};\\\", \\\"{x:1606,y:548,t:1527019630870};\\\", \\\"{x:1603,y:541,t:1527019630887};\\\", \\\"{x:1600,y:536,t:1527019630903};\\\", \\\"{x:1600,y:531,t:1527019630920};\\\", \\\"{x:1599,y:523,t:1527019630936};\\\", \\\"{x:1595,y:517,t:1527019630953};\\\", \\\"{x:1592,y:512,t:1527019630970};\\\", \\\"{x:1591,y:511,t:1527019630986};\\\", \\\"{x:1589,y:511,t:1527019631002};\\\", \\\"{x:1588,y:511,t:1527019631020};\\\", \\\"{x:1586,y:511,t:1527019631037};\\\", \\\"{x:1585,y:511,t:1527019631052};\\\", \\\"{x:1584,y:511,t:1527019631070};\\\", \\\"{x:1583,y:511,t:1527019631087};\\\", \\\"{x:1582,y:511,t:1527019631104};\\\", \\\"{x:1581,y:511,t:1527019631130};\\\", \\\"{x:1579,y:511,t:1527019631146};\\\", \\\"{x:1579,y:512,t:1527019631154};\\\", \\\"{x:1576,y:513,t:1527019631170};\\\", \\\"{x:1573,y:515,t:1527019631186};\\\", \\\"{x:1573,y:516,t:1527019631204};\\\", \\\"{x:1572,y:516,t:1527019631523};\\\", \\\"{x:1570,y:519,t:1527019631537};\\\", \\\"{x:1565,y:532,t:1527019631554};\\\", \\\"{x:1563,y:539,t:1527019631570};\\\", \\\"{x:1560,y:546,t:1527019631587};\\\", \\\"{x:1558,y:549,t:1527019631604};\\\", \\\"{x:1557,y:551,t:1527019631621};\\\", \\\"{x:1556,y:553,t:1527019631643};\\\", \\\"{x:1557,y:553,t:1527019632354};\\\", \\\"{x:1559,y:551,t:1527019632371};\\\", \\\"{x:1561,y:549,t:1527019632387};\\\", \\\"{x:1563,y:547,t:1527019632404};\\\", \\\"{x:1566,y:545,t:1527019632420};\\\", \\\"{x:1567,y:544,t:1527019632438};\\\", \\\"{x:1567,y:543,t:1527019632454};\\\", \\\"{x:1569,y:542,t:1527019632471};\\\", \\\"{x:1572,y:539,t:1527019632488};\\\", \\\"{x:1574,y:537,t:1527019632504};\\\", \\\"{x:1576,y:536,t:1527019632520};\\\", \\\"{x:1577,y:536,t:1527019632555};\\\", \\\"{x:1579,y:535,t:1527019632570};\\\", \\\"{x:1580,y:535,t:1527019632588};\\\", \\\"{x:1584,y:535,t:1527019632605};\\\", \\\"{x:1586,y:535,t:1527019632621};\\\", \\\"{x:1589,y:535,t:1527019632639};\\\", \\\"{x:1591,y:535,t:1527019632655};\\\", \\\"{x:1593,y:535,t:1527019632671};\\\", \\\"{x:1596,y:536,t:1527019632688};\\\", \\\"{x:1596,y:538,t:1527019632704};\\\", \\\"{x:1600,y:541,t:1527019632721};\\\", \\\"{x:1603,y:547,t:1527019632738};\\\", \\\"{x:1608,y:554,t:1527019632755};\\\", \\\"{x:1610,y:555,t:1527019632772};\\\", \\\"{x:1611,y:556,t:1527019632795};\\\", \\\"{x:1611,y:555,t:1527019632923};\\\", \\\"{x:1611,y:554,t:1527019632938};\\\", \\\"{x:1607,y:546,t:1527019632955};\\\", \\\"{x:1602,y:539,t:1527019632972};\\\", \\\"{x:1596,y:532,t:1527019632988};\\\", \\\"{x:1592,y:529,t:1527019633005};\\\", \\\"{x:1588,y:526,t:1527019633022};\\\", \\\"{x:1584,y:526,t:1527019633039};\\\", \\\"{x:1583,y:526,t:1527019633055};\\\", \\\"{x:1581,y:526,t:1527019633072};\\\", \\\"{x:1580,y:526,t:1527019633107};\\\", \\\"{x:1578,y:526,t:1527019633139};\\\", \\\"{x:1576,y:526,t:1527019633155};\\\", \\\"{x:1573,y:527,t:1527019633172};\\\", \\\"{x:1566,y:532,t:1527019633188};\\\", \\\"{x:1555,y:543,t:1527019633205};\\\", \\\"{x:1544,y:557,t:1527019633222};\\\", \\\"{x:1533,y:575,t:1527019633241};\\\", \\\"{x:1526,y:589,t:1527019633255};\\\", \\\"{x:1521,y:608,t:1527019633272};\\\", \\\"{x:1515,y:624,t:1527019633289};\\\", \\\"{x:1511,y:637,t:1527019633305};\\\", \\\"{x:1506,y:647,t:1527019633322};\\\", \\\"{x:1504,y:649,t:1527019633339};\\\", \\\"{x:1502,y:650,t:1527019633355};\\\", \\\"{x:1497,y:652,t:1527019633372};\\\", \\\"{x:1493,y:652,t:1527019633389};\\\", \\\"{x:1488,y:652,t:1527019633405};\\\", \\\"{x:1481,y:652,t:1527019633422};\\\", \\\"{x:1474,y:652,t:1527019633439};\\\", \\\"{x:1469,y:650,t:1527019633455};\\\", \\\"{x:1466,y:648,t:1527019633471};\\\", \\\"{x:1463,y:647,t:1527019633488};\\\", \\\"{x:1462,y:645,t:1527019633505};\\\", \\\"{x:1461,y:645,t:1527019633522};\\\", \\\"{x:1461,y:644,t:1527019633539};\\\", \\\"{x:1460,y:643,t:1527019633555};\\\", \\\"{x:1460,y:642,t:1527019633586};\\\", \\\"{x:1460,y:641,t:1527019633602};\\\", \\\"{x:1460,y:640,t:1527019633626};\\\", \\\"{x:1459,y:639,t:1527019633658};\\\", \\\"{x:1459,y:638,t:1527019633779};\\\", \\\"{x:1458,y:638,t:1527019633810};\\\", \\\"{x:1457,y:638,t:1527019634298};\\\", \\\"{x:1456,y:638,t:1527019635027};\\\", \\\"{x:1454,y:640,t:1527019635041};\\\", \\\"{x:1449,y:642,t:1527019635057};\\\", \\\"{x:1444,y:645,t:1527019635073};\\\", \\\"{x:1442,y:647,t:1527019635090};\\\", \\\"{x:1438,y:649,t:1527019635107};\\\", \\\"{x:1437,y:652,t:1527019635123};\\\", \\\"{x:1436,y:655,t:1527019635140};\\\", \\\"{x:1434,y:657,t:1527019635158};\\\", \\\"{x:1433,y:658,t:1527019635174};\\\", \\\"{x:1432,y:659,t:1527019635190};\\\", \\\"{x:1431,y:660,t:1527019635211};\\\", \\\"{x:1431,y:661,t:1527019635282};\\\", \\\"{x:1432,y:663,t:1527019635339};\\\", \\\"{x:1435,y:663,t:1527019635357};\\\", \\\"{x:1441,y:663,t:1527019635373};\\\", \\\"{x:1448,y:664,t:1527019635390};\\\", \\\"{x:1459,y:665,t:1527019635407};\\\", \\\"{x:1471,y:668,t:1527019635424};\\\", \\\"{x:1478,y:669,t:1527019635441};\\\", \\\"{x:1483,y:672,t:1527019635457};\\\", \\\"{x:1484,y:673,t:1527019635474};\\\", \\\"{x:1486,y:678,t:1527019635491};\\\", \\\"{x:1489,y:685,t:1527019635507};\\\", \\\"{x:1493,y:695,t:1527019635524};\\\", \\\"{x:1497,y:706,t:1527019635540};\\\", \\\"{x:1502,y:718,t:1527019635556};\\\", \\\"{x:1507,y:731,t:1527019635574};\\\", \\\"{x:1510,y:740,t:1527019635590};\\\", \\\"{x:1511,y:746,t:1527019635607};\\\", \\\"{x:1511,y:748,t:1527019635624};\\\", \\\"{x:1513,y:751,t:1527019635639};\\\", \\\"{x:1513,y:754,t:1527019635657};\\\", \\\"{x:1514,y:756,t:1527019635673};\\\", \\\"{x:1514,y:755,t:1527019635923};\\\", \\\"{x:1514,y:756,t:1527019636027};\\\", \\\"{x:1514,y:758,t:1527019636042};\\\", \\\"{x:1514,y:763,t:1527019636057};\\\", \\\"{x:1514,y:767,t:1527019636074};\\\", \\\"{x:1514,y:769,t:1527019636091};\\\", \\\"{x:1515,y:770,t:1527019636107};\\\", \\\"{x:1515,y:768,t:1527019636276};\\\", \\\"{x:1513,y:760,t:1527019636290};\\\", \\\"{x:1507,y:748,t:1527019636309};\\\", \\\"{x:1501,y:732,t:1527019636324};\\\", \\\"{x:1492,y:710,t:1527019636341};\\\", \\\"{x:1485,y:690,t:1527019636358};\\\", \\\"{x:1474,y:652,t:1527019636374};\\\", \\\"{x:1466,y:627,t:1527019636391};\\\", \\\"{x:1457,y:612,t:1527019636409};\\\", \\\"{x:1455,y:599,t:1527019636424};\\\", \\\"{x:1451,y:588,t:1527019636441};\\\", \\\"{x:1445,y:575,t:1527019636458};\\\", \\\"{x:1442,y:569,t:1527019636474};\\\", \\\"{x:1441,y:566,t:1527019636491};\\\", \\\"{x:1439,y:564,t:1527019636509};\\\", \\\"{x:1437,y:562,t:1527019636524};\\\", \\\"{x:1435,y:560,t:1527019636541};\\\", \\\"{x:1434,y:560,t:1527019636558};\\\", \\\"{x:1429,y:560,t:1527019636574};\\\", \\\"{x:1426,y:560,t:1527019636591};\\\", \\\"{x:1422,y:560,t:1527019636609};\\\", \\\"{x:1417,y:560,t:1527019636624};\\\", \\\"{x:1410,y:562,t:1527019636641};\\\", \\\"{x:1402,y:566,t:1527019636659};\\\", \\\"{x:1398,y:569,t:1527019636674};\\\", \\\"{x:1394,y:570,t:1527019636691};\\\", \\\"{x:1393,y:570,t:1527019636954};\\\", \\\"{x:1393,y:569,t:1527019637018};\\\", \\\"{x:1394,y:568,t:1527019637035};\\\", \\\"{x:1395,y:568,t:1527019637058};\\\", \\\"{x:1396,y:568,t:1527019637089};\\\", \\\"{x:1397,y:568,t:1527019637105};\\\", \\\"{x:1398,y:566,t:1527019637113};\\\", \\\"{x:1400,y:566,t:1527019637146};\\\", \\\"{x:1401,y:566,t:1527019637157};\\\", \\\"{x:1403,y:566,t:1527019637186};\\\", \\\"{x:1404,y:565,t:1527019637194};\\\", \\\"{x:1405,y:565,t:1527019637207};\\\", \\\"{x:1406,y:565,t:1527019637225};\\\", \\\"{x:1409,y:565,t:1527019637242};\\\", \\\"{x:1410,y:565,t:1527019637275};\\\", \\\"{x:1409,y:565,t:1527019638074};\\\", \\\"{x:1404,y:565,t:1527019638093};\\\", \\\"{x:1396,y:565,t:1527019638109};\\\", \\\"{x:1390,y:565,t:1527019638126};\\\", \\\"{x:1378,y:565,t:1527019638142};\\\", \\\"{x:1370,y:564,t:1527019638160};\\\", \\\"{x:1364,y:564,t:1527019638176};\\\", \\\"{x:1358,y:564,t:1527019638192};\\\", \\\"{x:1353,y:564,t:1527019638209};\\\", \\\"{x:1341,y:564,t:1527019638226};\\\", \\\"{x:1326,y:564,t:1527019638242};\\\", \\\"{x:1317,y:564,t:1527019638259};\\\", \\\"{x:1310,y:564,t:1527019638276};\\\", \\\"{x:1305,y:564,t:1527019638292};\\\", \\\"{x:1300,y:565,t:1527019638309};\\\", \\\"{x:1298,y:567,t:1527019638326};\\\", \\\"{x:1297,y:567,t:1527019638342};\\\", \\\"{x:1296,y:568,t:1527019638359};\\\", \\\"{x:1295,y:569,t:1527019638474};\\\", \\\"{x:1295,y:570,t:1527019638490};\\\", \\\"{x:1294,y:572,t:1527019638499};\\\", \\\"{x:1291,y:572,t:1527019638522};\\\", \\\"{x:1290,y:572,t:1527019639611};\\\", \\\"{x:1292,y:579,t:1527019639627};\\\", \\\"{x:1294,y:588,t:1527019639644};\\\", \\\"{x:1296,y:594,t:1527019639660};\\\", \\\"{x:1296,y:597,t:1527019639677};\\\", \\\"{x:1298,y:600,t:1527019639694};\\\", \\\"{x:1298,y:604,t:1527019639709};\\\", \\\"{x:1299,y:607,t:1527019639726};\\\", \\\"{x:1301,y:612,t:1527019639744};\\\", \\\"{x:1304,y:619,t:1527019639759};\\\", \\\"{x:1304,y:622,t:1527019639777};\\\", \\\"{x:1306,y:626,t:1527019639794};\\\", \\\"{x:1308,y:629,t:1527019639809};\\\", \\\"{x:1311,y:637,t:1527019639827};\\\", \\\"{x:1315,y:648,t:1527019639845};\\\", \\\"{x:1319,y:657,t:1527019639859};\\\", \\\"{x:1323,y:664,t:1527019639876};\\\", \\\"{x:1327,y:670,t:1527019639894};\\\", \\\"{x:1330,y:678,t:1527019639910};\\\", \\\"{x:1334,y:686,t:1527019639927};\\\", \\\"{x:1340,y:697,t:1527019639944};\\\", \\\"{x:1345,y:706,t:1527019639959};\\\", \\\"{x:1348,y:712,t:1527019639977};\\\", \\\"{x:1352,y:721,t:1527019639994};\\\", \\\"{x:1357,y:728,t:1527019640010};\\\", \\\"{x:1361,y:733,t:1527019640026};\\\", \\\"{x:1365,y:739,t:1527019640043};\\\", \\\"{x:1369,y:745,t:1527019640060};\\\", \\\"{x:1373,y:751,t:1527019640076};\\\", \\\"{x:1376,y:756,t:1527019640094};\\\", \\\"{x:1379,y:760,t:1527019640110};\\\", \\\"{x:1382,y:764,t:1527019640127};\\\", \\\"{x:1386,y:772,t:1527019640143};\\\", \\\"{x:1391,y:780,t:1527019640160};\\\", \\\"{x:1394,y:786,t:1527019640177};\\\", \\\"{x:1401,y:798,t:1527019640193};\\\", \\\"{x:1407,y:808,t:1527019640211};\\\", \\\"{x:1412,y:817,t:1527019640227};\\\", \\\"{x:1414,y:825,t:1527019640244};\\\", \\\"{x:1419,y:833,t:1527019640261};\\\", \\\"{x:1422,y:840,t:1527019640277};\\\", \\\"{x:1422,y:844,t:1527019640294};\\\", \\\"{x:1426,y:851,t:1527019640312};\\\", \\\"{x:1427,y:857,t:1527019640327};\\\", \\\"{x:1429,y:864,t:1527019640344};\\\", \\\"{x:1430,y:870,t:1527019640360};\\\", \\\"{x:1432,y:878,t:1527019640377};\\\", \\\"{x:1435,y:887,t:1527019640394};\\\", \\\"{x:1436,y:894,t:1527019640411};\\\", \\\"{x:1437,y:899,t:1527019640427};\\\", \\\"{x:1439,y:909,t:1527019640444};\\\", \\\"{x:1444,y:923,t:1527019640461};\\\", \\\"{x:1450,y:935,t:1527019640477};\\\", \\\"{x:1454,y:943,t:1527019640494};\\\", \\\"{x:1456,y:947,t:1527019640511};\\\", \\\"{x:1457,y:949,t:1527019640527};\\\", \\\"{x:1460,y:952,t:1527019640544};\\\", \\\"{x:1461,y:955,t:1527019640562};\\\", \\\"{x:1463,y:957,t:1527019640577};\\\", \\\"{x:1465,y:961,t:1527019640594};\\\", \\\"{x:1468,y:964,t:1527019640611};\\\", \\\"{x:1472,y:968,t:1527019640627};\\\", \\\"{x:1473,y:970,t:1527019640658};\\\", \\\"{x:1474,y:970,t:1527019640738};\\\", \\\"{x:1475,y:970,t:1527019642034};\\\", \\\"{x:1476,y:970,t:1527019642065};\\\", \\\"{x:1476,y:966,t:1527019643299};\\\", \\\"{x:1465,y:958,t:1527019643313};\\\", \\\"{x:1380,y:890,t:1527019643330};\\\", \\\"{x:1259,y:815,t:1527019643347};\\\", \\\"{x:1134,y:727,t:1527019643363};\\\", \\\"{x:1004,y:632,t:1527019643380};\\\", \\\"{x:900,y:578,t:1527019643397};\\\", \\\"{x:861,y:541,t:1527019643413};\\\", \\\"{x:828,y:522,t:1527019643430};\\\", \\\"{x:822,y:518,t:1527019643446};\\\", \\\"{x:818,y:516,t:1527019643463};\\\", \\\"{x:817,y:516,t:1527019643602};\\\", \\\"{x:816,y:518,t:1527019643618};\\\", \\\"{x:815,y:519,t:1527019643630};\\\", \\\"{x:812,y:524,t:1527019643647};\\\", \\\"{x:808,y:529,t:1527019643663};\\\", \\\"{x:801,y:537,t:1527019643680};\\\", \\\"{x:791,y:546,t:1527019643696};\\\", \\\"{x:778,y:552,t:1527019643713};\\\", \\\"{x:769,y:556,t:1527019643730};\\\", \\\"{x:768,y:557,t:1527019643746};\\\", \\\"{x:771,y:554,t:1527019643823};\\\", \\\"{x:776,y:552,t:1527019643829};\\\", \\\"{x:788,y:543,t:1527019643845};\\\", \\\"{x:801,y:534,t:1527019643863};\\\", \\\"{x:804,y:531,t:1527019643880};\\\", \\\"{x:808,y:529,t:1527019643896};\\\", \\\"{x:812,y:526,t:1527019643913};\\\", \\\"{x:813,y:525,t:1527019643929};\\\", \\\"{x:810,y:523,t:1527019643963};\\\", \\\"{x:795,y:521,t:1527019643980};\\\", \\\"{x:766,y:516,t:1527019643996};\\\", \\\"{x:730,y:511,t:1527019644013};\\\", \\\"{x:689,y:501,t:1527019644030};\\\", \\\"{x:662,y:498,t:1527019644047};\\\", \\\"{x:647,y:497,t:1527019644064};\\\", \\\"{x:641,y:496,t:1527019644080};\\\", \\\"{x:640,y:496,t:1527019644130};\\\", \\\"{x:639,y:496,t:1527019644147};\\\", \\\"{x:638,y:496,t:1527019644164};\\\", \\\"{x:637,y:497,t:1527019644180};\\\", \\\"{x:635,y:497,t:1527019644197};\\\", \\\"{x:632,y:500,t:1527019644214};\\\", \\\"{x:630,y:501,t:1527019644231};\\\", \\\"{x:628,y:503,t:1527019644247};\\\", \\\"{x:628,y:504,t:1527019644282};\\\", \\\"{x:626,y:505,t:1527019644298};\\\", \\\"{x:624,y:506,t:1527019644314};\\\", \\\"{x:622,y:507,t:1527019644331};\\\", \\\"{x:620,y:507,t:1527019644362};\\\", \\\"{x:619,y:507,t:1527019644370};\\\", \\\"{x:618,y:507,t:1527019644382};\\\", \\\"{x:616,y:504,t:1527019644397};\\\", \\\"{x:615,y:503,t:1527019644418};\\\", \\\"{x:614,y:502,t:1527019644434};\\\", \\\"{x:614,y:501,t:1527019644448};\\\", \\\"{x:613,y:500,t:1527019644464};\\\", \\\"{x:612,y:500,t:1527019644490};\\\", \\\"{x:612,y:508,t:1527019644681};\\\", \\\"{x:612,y:527,t:1527019644698};\\\", \\\"{x:612,y:550,t:1527019644714};\\\", \\\"{x:612,y:572,t:1527019644732};\\\", \\\"{x:612,y:591,t:1527019644748};\\\", \\\"{x:611,y:602,t:1527019644764};\\\", \\\"{x:611,y:614,t:1527019644781};\\\", \\\"{x:611,y:626,t:1527019644797};\\\", \\\"{x:611,y:641,t:1527019644815};\\\", \\\"{x:611,y:654,t:1527019644831};\\\", \\\"{x:607,y:665,t:1527019644847};\\\", \\\"{x:604,y:678,t:1527019644864};\\\", \\\"{x:601,y:684,t:1527019644881};\\\", \\\"{x:597,y:696,t:1527019644897};\\\", \\\"{x:594,y:701,t:1527019644915};\\\", \\\"{x:589,y:707,t:1527019644931};\\\", \\\"{x:582,y:712,t:1527019644948};\\\", \\\"{x:577,y:715,t:1527019644965};\\\", \\\"{x:568,y:717,t:1527019644980};\\\", \\\"{x:563,y:719,t:1527019644998};\\\", \\\"{x:561,y:719,t:1527019645015};\\\", \\\"{x:552,y:720,t:1527019645032};\\\", \\\"{x:549,y:721,t:1527019645048};\\\", \\\"{x:543,y:724,t:1527019645063};\\\", \\\"{x:539,y:727,t:1527019645081};\\\", \\\"{x:535,y:730,t:1527019645098};\\\", \\\"{x:534,y:732,t:1527019645130};\\\", \\\"{x:533,y:733,t:1527019645138};\\\", \\\"{x:532,y:735,t:1527019645148};\\\", \\\"{x:530,y:738,t:1527019645164};\\\", \\\"{x:530,y:740,t:1527019645181};\\\", \\\"{x:528,y:743,t:1527019645198};\\\", \\\"{x:527,y:743,t:1527019645226};\\\", \\\"{x:526,y:743,t:1527019645345};\\\", \\\"{x:525,y:743,t:1527019645363};\\\", \\\"{x:525,y:742,t:1527019645498};\\\", \\\"{x:527,y:741,t:1527019645515};\\\", \\\"{x:535,y:739,t:1527019645532};\\\", \\\"{x:545,y:738,t:1527019645548};\\\", \\\"{x:558,y:737,t:1527019645565};\\\", \\\"{x:577,y:737,t:1527019645581};\\\", \\\"{x:577,y:736,t:1527019645597};\\\", \\\"{x:576,y:736,t:1527019646123};\\\", \\\"{x:572,y:734,t:1527019646132};\\\", \\\"{x:571,y:733,t:1527019646150};\\\", \\\"{x:571,y:732,t:1527019646202};\\\", \\\"{x:571,y:730,t:1527019646218};\\\", \\\"{x:571,y:728,t:1527019646232};\\\", \\\"{x:572,y:724,t:1527019646249};\\\", \\\"{x:573,y:720,t:1527019646265};\\\", \\\"{x:576,y:714,t:1527019646282};\\\" ] }, { \\\"rt\\\": 36886, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 307229, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -01 PM-12 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:587,y:695,t:1527019646733};\\\", \\\"{x:594,y:686,t:1527019646749};\\\", \\\"{x:595,y:679,t:1527019646766};\\\", \\\"{x:596,y:668,t:1527019646786};\\\", \\\"{x:596,y:665,t:1527019646799};\\\", \\\"{x:596,y:659,t:1527019646816};\\\", \\\"{x:599,y:648,t:1527019646833};\\\", \\\"{x:600,y:640,t:1527019646849};\\\", \\\"{x:600,y:638,t:1527019646866};\\\", \\\"{x:600,y:636,t:1527019646883};\\\", \\\"{x:601,y:634,t:1527019646899};\\\", \\\"{x:601,y:631,t:1527019646916};\\\", \\\"{x:601,y:628,t:1527019646933};\\\", \\\"{x:601,y:627,t:1527019646949};\\\", \\\"{x:580,y:573,t:1527019647049};\\\", \\\"{x:538,y:543,t:1527019647066};\\\", \\\"{x:518,y:525,t:1527019647083};\\\", \\\"{x:485,y:507,t:1527019647099};\\\", \\\"{x:446,y:496,t:1527019647116};\\\", \\\"{x:413,y:490,t:1527019647133};\\\", \\\"{x:382,y:486,t:1527019647150};\\\", \\\"{x:361,y:482,t:1527019647166};\\\", \\\"{x:354,y:480,t:1527019647184};\\\", \\\"{x:350,y:478,t:1527019647198};\\\", \\\"{x:348,y:478,t:1527019647217};\\\", \\\"{x:347,y:478,t:1527019647233};\\\", \\\"{x:345,y:478,t:1527019647249};\\\", \\\"{x:342,y:478,t:1527019647266};\\\", \\\"{x:337,y:477,t:1527019647283};\\\", \\\"{x:328,y:471,t:1527019647299};\\\", \\\"{x:323,y:464,t:1527019647316};\\\", \\\"{x:318,y:460,t:1527019647333};\\\", \\\"{x:315,y:456,t:1527019647349};\\\", \\\"{x:315,y:455,t:1527019647366};\\\", \\\"{x:315,y:454,t:1527019647394};\\\", \\\"{x:315,y:453,t:1527019647418};\\\", \\\"{x:315,y:452,t:1527019647433};\\\", \\\"{x:315,y:450,t:1527019647449};\\\", \\\"{x:316,y:448,t:1527019647466};\\\", \\\"{x:317,y:448,t:1527019647674};\\\", \\\"{x:318,y:448,t:1527019647697};\\\", \\\"{x:319,y:448,t:1527019647706};\\\", \\\"{x:319,y:447,t:1527019647716};\\\", \\\"{x:321,y:447,t:1527019647733};\\\", \\\"{x:322,y:447,t:1527019647749};\\\", \\\"{x:323,y:447,t:1527019647767};\\\", \\\"{x:325,y:447,t:1527019647783};\\\", \\\"{x:326,y:447,t:1527019647800};\\\", \\\"{x:327,y:447,t:1527019647834};\\\", \\\"{x:328,y:447,t:1527019647898};\\\", \\\"{x:329,y:447,t:1527019648154};\\\", \\\"{x:334,y:449,t:1527019648167};\\\", \\\"{x:342,y:450,t:1527019648182};\\\", \\\"{x:347,y:451,t:1527019648199};\\\", \\\"{x:351,y:451,t:1527019648216};\\\", \\\"{x:352,y:452,t:1527019648234};\\\", \\\"{x:355,y:453,t:1527019648355};\\\", \\\"{x:355,y:454,t:1527019648367};\\\", \\\"{x:358,y:457,t:1527019648383};\\\", \\\"{x:359,y:458,t:1527019648399};\\\", \\\"{x:361,y:460,t:1527019648416};\\\", \\\"{x:363,y:461,t:1527019648432};\\\", \\\"{x:367,y:465,t:1527019648448};\\\", \\\"{x:371,y:466,t:1527019648465};\\\", \\\"{x:372,y:466,t:1527019648554};\\\", \\\"{x:373,y:466,t:1527019648566};\\\", \\\"{x:375,y:465,t:1527019648582};\\\", \\\"{x:377,y:463,t:1527019648600};\\\", \\\"{x:379,y:462,t:1527019648616};\\\", \\\"{x:381,y:461,t:1527019648632};\\\", \\\"{x:382,y:460,t:1527019648649};\\\", \\\"{x:383,y:460,t:1527019648674};\\\", \\\"{x:384,y:460,t:1527019648690};\\\", \\\"{x:385,y:459,t:1527019648706};\\\", \\\"{x:386,y:458,t:1527019648835};\\\", \\\"{x:384,y:458,t:1527019649058};\\\", \\\"{x:383,y:458,t:1527019649074};\\\", \\\"{x:381,y:458,t:1527019649082};\\\", \\\"{x:373,y:458,t:1527019649099};\\\", \\\"{x:364,y:458,t:1527019649117};\\\", \\\"{x:352,y:455,t:1527019649132};\\\", \\\"{x:334,y:448,t:1527019649149};\\\", \\\"{x:320,y:440,t:1527019649165};\\\", \\\"{x:309,y:435,t:1527019649182};\\\", \\\"{x:302,y:432,t:1527019649199};\\\", \\\"{x:300,y:431,t:1527019649216};\\\", \\\"{x:300,y:430,t:1527019649234};\\\", \\\"{x:300,y:429,t:1527019649298};\\\", \\\"{x:301,y:429,t:1527019649315};\\\", \\\"{x:304,y:429,t:1527019649333};\\\", \\\"{x:310,y:429,t:1527019649349};\\\", \\\"{x:318,y:429,t:1527019649365};\\\", \\\"{x:323,y:429,t:1527019649383};\\\", \\\"{x:333,y:429,t:1527019649399};\\\", \\\"{x:343,y:429,t:1527019649415};\\\", \\\"{x:348,y:430,t:1527019649432};\\\", \\\"{x:353,y:430,t:1527019649449};\\\", \\\"{x:354,y:431,t:1527019649465};\\\", \\\"{x:356,y:432,t:1527019649481};\\\", \\\"{x:357,y:433,t:1527019649499};\\\", \\\"{x:358,y:433,t:1527019649515};\\\", \\\"{x:360,y:435,t:1527019649532};\\\", \\\"{x:362,y:436,t:1527019649549};\\\", \\\"{x:364,y:436,t:1527019649565};\\\", \\\"{x:369,y:437,t:1527019649582};\\\", \\\"{x:374,y:439,t:1527019649600};\\\", \\\"{x:379,y:440,t:1527019649615};\\\", \\\"{x:381,y:441,t:1527019649633};\\\", \\\"{x:384,y:443,t:1527019649650};\\\", \\\"{x:387,y:443,t:1527019649666};\\\", \\\"{x:392,y:444,t:1527019649683};\\\", \\\"{x:395,y:445,t:1527019649699};\\\", \\\"{x:400,y:445,t:1527019649716};\\\", \\\"{x:403,y:447,t:1527019649732};\\\", \\\"{x:407,y:447,t:1527019649749};\\\", \\\"{x:411,y:450,t:1527019649765};\\\", \\\"{x:422,y:452,t:1527019649782};\\\", \\\"{x:432,y:456,t:1527019649799};\\\", \\\"{x:440,y:457,t:1527019649815};\\\", \\\"{x:452,y:460,t:1527019649832};\\\", \\\"{x:464,y:461,t:1527019649849};\\\", \\\"{x:465,y:462,t:1527019649865};\\\", \\\"{x:469,y:463,t:1527019649882};\\\", \\\"{x:471,y:463,t:1527019649899};\\\", \\\"{x:472,y:463,t:1527019649915};\\\", \\\"{x:475,y:464,t:1527019649933};\\\", \\\"{x:482,y:465,t:1527019649949};\\\", \\\"{x:492,y:466,t:1527019649965};\\\", \\\"{x:500,y:466,t:1527019649982};\\\", \\\"{x:501,y:467,t:1527019649999};\\\", \\\"{x:504,y:467,t:1527019650123};\\\", \\\"{x:504,y:465,t:1527019650178};\\\", \\\"{x:504,y:464,t:1527019650194};\\\", \\\"{x:504,y:463,t:1527019650202};\\\", \\\"{x:504,y:462,t:1527019650216};\\\", \\\"{x:504,y:461,t:1527019650233};\\\", \\\"{x:504,y:459,t:1527019650250};\\\", \\\"{x:504,y:458,t:1527019650282};\\\", \\\"{x:504,y:457,t:1527019650300};\\\", \\\"{x:504,y:456,t:1527019650315};\\\", \\\"{x:506,y:455,t:1527019650578};\\\", \\\"{x:507,y:455,t:1527019650594};\\\", \\\"{x:509,y:455,t:1527019650602};\\\", \\\"{x:511,y:455,t:1527019650618};\\\", \\\"{x:512,y:455,t:1527019650632};\\\", \\\"{x:513,y:455,t:1527019650649};\\\", \\\"{x:514,y:455,t:1527019650665};\\\", \\\"{x:516,y:455,t:1527019650682};\\\", \\\"{x:519,y:455,t:1527019650795};\\\", \\\"{x:521,y:456,t:1527019650810};\\\", \\\"{x:522,y:456,t:1527019650818};\\\", \\\"{x:524,y:456,t:1527019650833};\\\", \\\"{x:524,y:457,t:1527019650848};\\\", \\\"{x:526,y:459,t:1527019650866};\\\", \\\"{x:527,y:459,t:1527019651033};\\\", \\\"{x:528,y:459,t:1527019651057};\\\", \\\"{x:530,y:459,t:1527019651073};\\\", \\\"{x:533,y:459,t:1527019651081};\\\", \\\"{x:538,y:457,t:1527019651098};\\\", \\\"{x:543,y:455,t:1527019651115};\\\", \\\"{x:550,y:455,t:1527019651132};\\\", \\\"{x:555,y:454,t:1527019651148};\\\", \\\"{x:558,y:454,t:1527019651165};\\\", \\\"{x:559,y:454,t:1527019651183};\\\", \\\"{x:559,y:455,t:1527019651793};\\\", \\\"{x:558,y:456,t:1527019651809};\\\", \\\"{x:555,y:457,t:1527019651817};\\\", \\\"{x:550,y:458,t:1527019651832};\\\", \\\"{x:539,y:458,t:1527019651848};\\\", \\\"{x:534,y:458,t:1527019651865};\\\", \\\"{x:535,y:458,t:1527019651937};\\\", \\\"{x:538,y:458,t:1527019651949};\\\", \\\"{x:544,y:457,t:1527019651966};\\\", \\\"{x:549,y:457,t:1527019651982};\\\", \\\"{x:557,y:457,t:1527019651998};\\\", \\\"{x:561,y:457,t:1527019652015};\\\", \\\"{x:562,y:457,t:1527019652032};\\\", \\\"{x:563,y:457,t:1527019652082};\\\", \\\"{x:565,y:457,t:1527019652099};\\\", \\\"{x:569,y:457,t:1527019652115};\\\", \\\"{x:575,y:457,t:1527019652132};\\\", \\\"{x:586,y:457,t:1527019652149};\\\", \\\"{x:593,y:457,t:1527019652166};\\\", \\\"{x:607,y:457,t:1527019652181};\\\", \\\"{x:617,y:459,t:1527019652198};\\\", \\\"{x:627,y:460,t:1527019652216};\\\", \\\"{x:631,y:460,t:1527019652232};\\\", \\\"{x:633,y:460,t:1527019652248};\\\", \\\"{x:638,y:460,t:1527019652265};\\\", \\\"{x:638,y:461,t:1527019652538};\\\", \\\"{x:636,y:461,t:1527019652548};\\\", \\\"{x:632,y:460,t:1527019652566};\\\", \\\"{x:688,y:346,t:1527019652582};\\\", \\\"{x:710,y:308,t:1527019652599};\\\", \\\"{x:723,y:306,t:1527019652615};\\\", \\\"{x:723,y:307,t:1527019652987};\\\", \\\"{x:721,y:310,t:1527019652999};\\\", \\\"{x:712,y:317,t:1527019653015};\\\", \\\"{x:705,y:330,t:1527019653032};\\\", \\\"{x:692,y:340,t:1527019653049};\\\", \\\"{x:677,y:353,t:1527019653066};\\\", \\\"{x:665,y:371,t:1527019653082};\\\", \\\"{x:650,y:392,t:1527019653098};\\\", \\\"{x:636,y:412,t:1527019653115};\\\", \\\"{x:624,y:432,t:1527019653132};\\\", \\\"{x:615,y:445,t:1527019653149};\\\", \\\"{x:612,y:449,t:1527019653165};\\\", \\\"{x:610,y:451,t:1527019653182};\\\", \\\"{x:608,y:453,t:1527019653198};\\\", \\\"{x:608,y:454,t:1527019653242};\\\", \\\"{x:604,y:457,t:1527019653250};\\\", \\\"{x:601,y:460,t:1527019653264};\\\", \\\"{x:579,y:469,t:1527019653282};\\\", \\\"{x:571,y:474,t:1527019653298};\\\", \\\"{x:566,y:474,t:1527019653314};\\\", \\\"{x:566,y:473,t:1527019653378};\\\", \\\"{x:574,y:470,t:1527019653386};\\\", \\\"{x:591,y:469,t:1527019653399};\\\", \\\"{x:652,y:469,t:1527019653414};\\\", \\\"{x:671,y:462,t:1527019653431};\\\", \\\"{x:788,y:482,t:1527019653449};\\\", \\\"{x:945,y:547,t:1527019653466};\\\", \\\"{x:1190,y:701,t:1527019653482};\\\", \\\"{x:1313,y:800,t:1527019653497};\\\", \\\"{x:1433,y:894,t:1527019653516};\\\", \\\"{x:1512,y:972,t:1527019653533};\\\", \\\"{x:1545,y:1015,t:1527019653549};\\\", \\\"{x:1549,y:1022,t:1527019653566};\\\", \\\"{x:1547,y:1022,t:1527019653914};\\\", \\\"{x:1540,y:1021,t:1527019653922};\\\", \\\"{x:1536,y:1018,t:1527019653933};\\\", \\\"{x:1531,y:1015,t:1527019653948};\\\", \\\"{x:1524,y:1015,t:1527019653966};\\\", \\\"{x:1505,y:1015,t:1527019653983};\\\", \\\"{x:1487,y:1015,t:1527019653998};\\\", \\\"{x:1476,y:1015,t:1527019654016};\\\", \\\"{x:1455,y:1015,t:1527019654032};\\\", \\\"{x:1435,y:1017,t:1527019654049};\\\", \\\"{x:1402,y:1023,t:1527019654065};\\\", \\\"{x:1381,y:1029,t:1527019654082};\\\", \\\"{x:1363,y:1034,t:1527019654098};\\\", \\\"{x:1340,y:1042,t:1527019654115};\\\", \\\"{x:1316,y:1044,t:1527019654132};\\\", \\\"{x:1289,y:1044,t:1527019654149};\\\", \\\"{x:1266,y:1041,t:1527019654164};\\\", \\\"{x:1247,y:1035,t:1527019654182};\\\", \\\"{x:1224,y:1030,t:1527019654198};\\\", \\\"{x:1204,y:1023,t:1527019654215};\\\", \\\"{x:1187,y:1019,t:1527019654232};\\\", \\\"{x:1170,y:1014,t:1527019654249};\\\", \\\"{x:1153,y:1012,t:1527019654264};\\\", \\\"{x:1131,y:1009,t:1527019654282};\\\", \\\"{x:1123,y:1006,t:1527019654298};\\\", \\\"{x:1118,y:1005,t:1527019654315};\\\", \\\"{x:1117,y:1004,t:1527019654331};\\\", \\\"{x:1116,y:1003,t:1527019654394};\\\", \\\"{x:1115,y:1001,t:1527019654410};\\\", \\\"{x:1115,y:999,t:1527019654417};\\\", \\\"{x:1115,y:998,t:1527019654431};\\\", \\\"{x:1115,y:992,t:1527019654447};\\\", \\\"{x:1115,y:987,t:1527019654465};\\\", \\\"{x:1119,y:979,t:1527019654481};\\\", \\\"{x:1122,y:973,t:1527019654498};\\\", \\\"{x:1123,y:971,t:1527019654514};\\\", \\\"{x:1123,y:970,t:1527019654538};\\\", \\\"{x:1123,y:969,t:1527019654548};\\\", \\\"{x:1125,y:968,t:1527019654564};\\\", \\\"{x:1127,y:965,t:1527019654581};\\\", \\\"{x:1128,y:963,t:1527019654598};\\\", \\\"{x:1129,y:962,t:1527019654614};\\\", \\\"{x:1129,y:961,t:1527019654634};\\\", \\\"{x:1130,y:960,t:1527019654650};\\\", \\\"{x:1132,y:959,t:1527019654682};\\\", \\\"{x:1133,y:958,t:1527019654706};\\\", \\\"{x:1134,y:958,t:1527019654722};\\\", \\\"{x:1134,y:957,t:1527019654738};\\\", \\\"{x:1135,y:957,t:1527019654762};\\\", \\\"{x:1138,y:956,t:1527019654778};\\\", \\\"{x:1138,y:955,t:1527019654794};\\\", \\\"{x:1139,y:955,t:1527019654802};\\\", \\\"{x:1141,y:954,t:1527019654818};\\\", \\\"{x:1142,y:954,t:1527019654830};\\\", \\\"{x:1145,y:952,t:1527019654846};\\\", \\\"{x:1148,y:951,t:1527019654864};\\\", \\\"{x:1149,y:950,t:1527019654880};\\\", \\\"{x:1150,y:949,t:1527019654896};\\\", \\\"{x:1151,y:948,t:1527019654913};\\\", \\\"{x:1153,y:946,t:1527019654930};\\\", \\\"{x:1155,y:943,t:1527019654946};\\\", \\\"{x:1156,y:940,t:1527019654962};\\\", \\\"{x:1160,y:932,t:1527019654979};\\\", \\\"{x:1160,y:923,t:1527019654997};\\\", \\\"{x:1163,y:916,t:1527019655012};\\\", \\\"{x:1167,y:907,t:1527019655030};\\\", \\\"{x:1169,y:896,t:1527019655046};\\\", \\\"{x:1173,y:884,t:1527019655063};\\\", \\\"{x:1180,y:867,t:1527019655080};\\\", \\\"{x:1187,y:848,t:1527019655096};\\\", \\\"{x:1191,y:831,t:1527019655113};\\\", \\\"{x:1200,y:811,t:1527019655130};\\\", \\\"{x:1207,y:795,t:1527019655146};\\\", \\\"{x:1215,y:783,t:1527019655163};\\\", \\\"{x:1219,y:776,t:1527019655180};\\\", \\\"{x:1229,y:764,t:1527019655216};\\\", \\\"{x:1232,y:757,t:1527019655228};\\\", \\\"{x:1238,y:747,t:1527019655245};\\\", \\\"{x:1243,y:739,t:1527019655262};\\\", \\\"{x:1249,y:730,t:1527019655278};\\\", \\\"{x:1253,y:722,t:1527019655295};\\\", \\\"{x:1257,y:716,t:1527019655311};\\\", \\\"{x:1263,y:709,t:1527019655328};\\\", \\\"{x:1270,y:698,t:1527019655345};\\\", \\\"{x:1274,y:691,t:1527019655361};\\\", \\\"{x:1279,y:683,t:1527019655378};\\\", \\\"{x:1284,y:675,t:1527019655395};\\\", \\\"{x:1287,y:669,t:1527019655411};\\\", \\\"{x:1291,y:662,t:1527019655428};\\\", \\\"{x:1295,y:652,t:1527019655444};\\\", \\\"{x:1302,y:639,t:1527019655461};\\\", \\\"{x:1310,y:624,t:1527019655478};\\\", \\\"{x:1317,y:614,t:1527019655495};\\\", \\\"{x:1324,y:601,t:1527019655511};\\\", \\\"{x:1333,y:585,t:1527019655529};\\\", \\\"{x:1342,y:567,t:1527019655545};\\\", \\\"{x:1347,y:551,t:1527019655561};\\\", \\\"{x:1351,y:543,t:1527019655577};\\\", \\\"{x:1353,y:537,t:1527019655594};\\\", \\\"{x:1356,y:534,t:1527019655611};\\\", \\\"{x:1358,y:529,t:1527019655627};\\\", \\\"{x:1359,y:525,t:1527019655644};\\\", \\\"{x:1366,y:514,t:1527019655661};\\\", \\\"{x:1369,y:507,t:1527019655677};\\\", \\\"{x:1370,y:501,t:1527019655694};\\\", \\\"{x:1372,y:494,t:1527019655711};\\\", \\\"{x:1373,y:490,t:1527019655727};\\\", \\\"{x:1374,y:484,t:1527019655744};\\\", \\\"{x:1374,y:478,t:1527019655760};\\\", \\\"{x:1376,y:469,t:1527019655777};\\\", \\\"{x:1377,y:467,t:1527019655794};\\\", \\\"{x:1379,y:464,t:1527019655810};\\\", \\\"{x:1380,y:464,t:1527019655837};\\\", \\\"{x:1380,y:463,t:1527019655843};\\\", \\\"{x:1380,y:462,t:1527019655860};\\\", \\\"{x:1380,y:461,t:1527019655877};\\\", \\\"{x:1381,y:461,t:1527019655893};\\\", \\\"{x:1383,y:459,t:1527019655910};\\\", \\\"{x:1386,y:456,t:1527019655926};\\\", \\\"{x:1388,y:454,t:1527019655943};\\\", \\\"{x:1390,y:453,t:1527019655961};\\\", \\\"{x:1391,y:452,t:1527019655977};\\\", \\\"{x:1397,y:448,t:1527019655993};\\\", \\\"{x:1399,y:447,t:1527019656010};\\\", \\\"{x:1401,y:445,t:1527019656027};\\\", \\\"{x:1403,y:443,t:1527019656044};\\\", \\\"{x:1404,y:443,t:1527019656059};\\\", \\\"{x:1405,y:442,t:1527019656077};\\\", \\\"{x:1406,y:442,t:1527019656093};\\\", \\\"{x:1407,y:442,t:1527019656109};\\\", \\\"{x:1408,y:442,t:1527019656211};\\\", \\\"{x:1410,y:442,t:1527019657955};\\\", \\\"{x:1418,y:448,t:1527019657972};\\\", \\\"{x:1425,y:455,t:1527019657989};\\\", \\\"{x:1431,y:460,t:1527019658005};\\\", \\\"{x:1435,y:464,t:1527019658022};\\\", \\\"{x:1437,y:466,t:1527019658038};\\\", \\\"{x:1438,y:466,t:1527019658054};\\\", \\\"{x:1439,y:468,t:1527019658071};\\\", \\\"{x:1440,y:471,t:1527019658088};\\\", \\\"{x:1441,y:472,t:1527019658105};\\\", \\\"{x:1444,y:478,t:1527019658122};\\\", \\\"{x:1448,y:484,t:1527019658138};\\\", \\\"{x:1451,y:493,t:1527019658155};\\\", \\\"{x:1455,y:503,t:1527019658172};\\\", \\\"{x:1460,y:517,t:1527019658188};\\\", \\\"{x:1465,y:532,t:1527019658205};\\\", \\\"{x:1470,y:545,t:1527019658221};\\\", \\\"{x:1474,y:559,t:1527019658238};\\\", \\\"{x:1477,y:570,t:1527019658255};\\\", \\\"{x:1479,y:578,t:1527019658271};\\\", \\\"{x:1481,y:587,t:1527019658288};\\\", \\\"{x:1484,y:603,t:1527019658304};\\\", \\\"{x:1485,y:615,t:1527019658320};\\\", \\\"{x:1490,y:634,t:1527019658338};\\\", \\\"{x:1492,y:646,t:1527019658354};\\\", \\\"{x:1499,y:658,t:1527019658371};\\\", \\\"{x:1504,y:666,t:1527019658388};\\\", \\\"{x:1508,y:675,t:1527019658404};\\\", \\\"{x:1511,y:684,t:1527019658421};\\\", \\\"{x:1519,y:695,t:1527019658437};\\\", \\\"{x:1525,y:708,t:1527019658454};\\\", \\\"{x:1530,y:718,t:1527019658471};\\\", \\\"{x:1535,y:733,t:1527019658487};\\\", \\\"{x:1541,y:745,t:1527019658504};\\\", \\\"{x:1549,y:761,t:1527019658521};\\\", \\\"{x:1555,y:773,t:1527019658536};\\\", \\\"{x:1564,y:792,t:1527019658554};\\\", \\\"{x:1569,y:807,t:1527019658570};\\\", \\\"{x:1569,y:819,t:1527019658587};\\\", \\\"{x:1572,y:831,t:1527019658604};\\\", \\\"{x:1576,y:848,t:1527019658620};\\\", \\\"{x:1582,y:864,t:1527019658637};\\\", \\\"{x:1585,y:872,t:1527019658654};\\\", \\\"{x:1586,y:877,t:1527019658670};\\\", \\\"{x:1589,y:884,t:1527019658686};\\\", \\\"{x:1594,y:895,t:1527019658703};\\\", \\\"{x:1597,y:899,t:1527019658719};\\\", \\\"{x:1599,y:902,t:1527019658737};\\\", \\\"{x:1602,y:907,t:1527019658753};\\\", \\\"{x:1610,y:913,t:1527019658770};\\\", \\\"{x:1617,y:921,t:1527019658787};\\\", \\\"{x:1627,y:927,t:1527019658803};\\\", \\\"{x:1639,y:934,t:1527019658820};\\\", \\\"{x:1651,y:940,t:1527019658835};\\\", \\\"{x:1656,y:941,t:1527019658852};\\\", \\\"{x:1660,y:945,t:1527019658869};\\\", \\\"{x:1665,y:946,t:1527019658885};\\\", \\\"{x:1670,y:949,t:1527019658903};\\\", \\\"{x:1674,y:951,t:1527019658919};\\\", \\\"{x:1678,y:954,t:1527019658936};\\\", \\\"{x:1681,y:956,t:1527019658952};\\\", \\\"{x:1681,y:957,t:1527019658969};\\\", \\\"{x:1683,y:959,t:1527019658988};\\\", \\\"{x:1683,y:960,t:1527019659002};\\\", \\\"{x:1682,y:960,t:1527019659106};\\\", \\\"{x:1675,y:954,t:1527019659119};\\\", \\\"{x:1657,y:944,t:1527019659136};\\\", \\\"{x:1637,y:935,t:1527019659152};\\\", \\\"{x:1603,y:917,t:1527019659169};\\\", \\\"{x:1559,y:901,t:1527019659185};\\\", \\\"{x:1488,y:874,t:1527019659202};\\\", \\\"{x:1445,y:853,t:1527019659219};\\\", \\\"{x:1418,y:840,t:1527019659234};\\\", \\\"{x:1397,y:830,t:1527019659252};\\\", \\\"{x:1383,y:820,t:1527019659269};\\\", \\\"{x:1362,y:809,t:1527019659285};\\\", \\\"{x:1346,y:797,t:1527019659302};\\\", \\\"{x:1329,y:782,t:1527019659318};\\\", \\\"{x:1308,y:764,t:1527019659335};\\\", \\\"{x:1293,y:747,t:1527019659352};\\\", \\\"{x:1274,y:729,t:1527019659368};\\\", \\\"{x:1250,y:708,t:1527019659386};\\\", \\\"{x:1238,y:698,t:1527019659402};\\\", \\\"{x:1228,y:685,t:1527019659417};\\\", \\\"{x:1226,y:679,t:1527019659435};\\\", \\\"{x:1224,y:671,t:1527019659450};\\\", \\\"{x:1223,y:667,t:1527019659468};\\\", \\\"{x:1223,y:664,t:1527019659485};\\\", \\\"{x:1224,y:662,t:1527019659501};\\\", \\\"{x:1224,y:661,t:1527019659517};\\\", \\\"{x:1224,y:664,t:1527019659561};\\\", \\\"{x:1224,y:673,t:1527019659570};\\\", \\\"{x:1224,y:680,t:1527019659584};\\\", \\\"{x:1217,y:702,t:1527019659601};\\\", \\\"{x:1205,y:727,t:1527019659618};\\\", \\\"{x:1203,y:731,t:1527019659634};\\\", \\\"{x:1202,y:734,t:1527019659651};\\\", \\\"{x:1204,y:728,t:1527019659714};\\\", \\\"{x:1209,y:716,t:1527019659722};\\\", \\\"{x:1214,y:702,t:1527019659734};\\\", \\\"{x:1228,y:679,t:1527019659751};\\\", \\\"{x:1236,y:661,t:1527019659767};\\\", \\\"{x:1243,y:646,t:1527019659784};\\\", \\\"{x:1247,y:638,t:1527019659800};\\\", \\\"{x:1247,y:635,t:1527019659817};\\\", \\\"{x:1246,y:640,t:1527019659866};\\\", \\\"{x:1238,y:659,t:1527019659884};\\\", \\\"{x:1231,y:674,t:1527019659900};\\\", \\\"{x:1229,y:680,t:1527019659916};\\\", \\\"{x:1229,y:681,t:1527019659933};\\\", \\\"{x:1231,y:678,t:1527019660002};\\\", \\\"{x:1236,y:672,t:1527019660017};\\\", \\\"{x:1249,y:647,t:1527019660033};\\\", \\\"{x:1269,y:613,t:1527019660050};\\\", \\\"{x:1276,y:602,t:1527019660066};\\\", \\\"{x:1279,y:595,t:1527019660083};\\\", \\\"{x:1280,y:593,t:1527019660100};\\\", \\\"{x:1281,y:592,t:1527019660116};\\\", \\\"{x:1281,y:590,t:1527019660138};\\\", \\\"{x:1281,y:589,t:1527019660227};\\\", \\\"{x:1281,y:587,t:1527019660258};\\\", \\\"{x:1280,y:587,t:1527019660322};\\\", \\\"{x:1278,y:588,t:1527019660332};\\\", \\\"{x:1271,y:598,t:1527019660349};\\\", \\\"{x:1261,y:611,t:1527019660366};\\\", \\\"{x:1247,y:632,t:1527019660382};\\\", \\\"{x:1234,y:656,t:1527019660399};\\\", \\\"{x:1229,y:671,t:1527019660416};\\\", \\\"{x:1222,y:684,t:1527019660432};\\\", \\\"{x:1219,y:694,t:1527019660449};\\\", \\\"{x:1216,y:707,t:1527019660465};\\\", \\\"{x:1203,y:732,t:1527019660482};\\\", \\\"{x:1193,y:748,t:1527019660499};\\\", \\\"{x:1182,y:767,t:1527019660517};\\\", \\\"{x:1170,y:790,t:1527019660532};\\\", \\\"{x:1160,y:809,t:1527019660549};\\\", \\\"{x:1148,y:832,t:1527019660564};\\\", \\\"{x:1139,y:848,t:1527019660581};\\\", \\\"{x:1131,y:865,t:1527019660597};\\\", \\\"{x:1123,y:881,t:1527019660614};\\\", \\\"{x:1116,y:895,t:1527019660631};\\\", \\\"{x:1111,y:905,t:1527019660647};\\\", \\\"{x:1109,y:910,t:1527019660664};\\\", \\\"{x:1108,y:913,t:1527019660681};\\\", \\\"{x:1108,y:911,t:1527019660770};\\\", \\\"{x:1109,y:908,t:1527019660781};\\\", \\\"{x:1116,y:897,t:1527019660798};\\\", \\\"{x:1120,y:890,t:1527019660814};\\\", \\\"{x:1128,y:881,t:1527019660831};\\\", \\\"{x:1132,y:876,t:1527019660848};\\\", \\\"{x:1133,y:875,t:1527019660864};\\\", \\\"{x:1134,y:874,t:1527019660881};\\\", \\\"{x:1135,y:872,t:1527019661377};\\\", \\\"{x:1136,y:865,t:1527019661384};\\\", \\\"{x:1138,y:859,t:1527019661395};\\\", \\\"{x:1142,y:849,t:1527019661412};\\\", \\\"{x:1143,y:838,t:1527019661430};\\\", \\\"{x:1144,y:830,t:1527019661446};\\\", \\\"{x:1146,y:823,t:1527019661463};\\\", \\\"{x:1146,y:822,t:1527019661479};\\\", \\\"{x:1146,y:819,t:1527019661496};\\\", \\\"{x:1146,y:816,t:1527019661513};\\\", \\\"{x:1146,y:814,t:1527019661528};\\\", \\\"{x:1146,y:810,t:1527019661546};\\\", \\\"{x:1147,y:808,t:1527019661561};\\\", \\\"{x:1148,y:806,t:1527019661578};\\\", \\\"{x:1149,y:804,t:1527019661609};\\\", \\\"{x:1149,y:803,t:1527019661625};\\\", \\\"{x:1149,y:802,t:1527019661633};\\\", \\\"{x:1149,y:801,t:1527019661645};\\\", \\\"{x:1151,y:798,t:1527019661662};\\\", \\\"{x:1151,y:797,t:1527019661679};\\\", \\\"{x:1152,y:796,t:1527019661694};\\\", \\\"{x:1152,y:794,t:1527019661712};\\\", \\\"{x:1153,y:793,t:1527019661729};\\\", \\\"{x:1154,y:792,t:1527019661745};\\\", \\\"{x:1155,y:791,t:1527019661978};\\\", \\\"{x:1156,y:790,t:1527019661995};\\\", \\\"{x:1157,y:789,t:1527019662026};\\\", \\\"{x:1159,y:788,t:1527019662114};\\\", \\\"{x:1159,y:787,t:1527019662128};\\\", \\\"{x:1161,y:786,t:1527019662144};\\\", \\\"{x:1164,y:783,t:1527019662161};\\\", \\\"{x:1165,y:782,t:1527019662188};\\\", \\\"{x:1166,y:781,t:1527019662209};\\\", \\\"{x:1167,y:780,t:1527019662322};\\\", \\\"{x:1168,y:780,t:1527019662354};\\\", \\\"{x:1170,y:779,t:1527019662370};\\\", \\\"{x:1170,y:778,t:1527019662378};\\\", \\\"{x:1171,y:777,t:1527019662393};\\\", \\\"{x:1172,y:776,t:1527019662409};\\\", \\\"{x:1173,y:776,t:1527019662433};\\\", \\\"{x:1173,y:775,t:1527019662490};\\\", \\\"{x:1174,y:775,t:1527019663154};\\\", \\\"{x:1175,y:775,t:1527019663306};\\\", \\\"{x:1176,y:775,t:1527019663347};\\\", \\\"{x:1177,y:775,t:1527019663842};\\\", \\\"{x:1178,y:775,t:1527019663856};\\\", \\\"{x:1181,y:773,t:1527019663873};\\\", \\\"{x:1184,y:771,t:1527019663890};\\\", \\\"{x:1185,y:771,t:1527019663907};\\\", \\\"{x:1187,y:770,t:1527019663923};\\\", \\\"{x:1188,y:770,t:1527019664178};\\\", \\\"{x:1189,y:770,t:1527019664189};\\\", \\\"{x:1189,y:769,t:1527019664204};\\\", \\\"{x:1190,y:768,t:1527019664221};\\\", \\\"{x:1191,y:767,t:1527019664238};\\\", \\\"{x:1192,y:766,t:1527019664254};\\\", \\\"{x:1194,y:765,t:1527019664273};\\\", \\\"{x:1194,y:764,t:1527019664289};\\\", \\\"{x:1195,y:763,t:1527019664304};\\\", \\\"{x:1197,y:760,t:1527019664321};\\\", \\\"{x:1197,y:759,t:1527019664337};\\\", \\\"{x:1199,y:758,t:1527019664355};\\\", \\\"{x:1199,y:755,t:1527019664372};\\\", \\\"{x:1200,y:753,t:1527019664387};\\\", \\\"{x:1201,y:752,t:1527019664405};\\\", \\\"{x:1202,y:750,t:1527019664422};\\\", \\\"{x:1204,y:747,t:1527019664438};\\\", \\\"{x:1205,y:744,t:1527019664455};\\\", \\\"{x:1205,y:743,t:1527019664471};\\\", \\\"{x:1207,y:741,t:1527019664488};\\\", \\\"{x:1207,y:739,t:1527019664505};\\\", \\\"{x:1208,y:738,t:1527019664521};\\\", \\\"{x:1210,y:735,t:1527019664538};\\\", \\\"{x:1211,y:732,t:1527019664555};\\\", \\\"{x:1212,y:731,t:1527019664571};\\\", \\\"{x:1213,y:729,t:1527019664588};\\\", \\\"{x:1214,y:728,t:1527019664604};\\\", \\\"{x:1216,y:725,t:1527019664621};\\\", \\\"{x:1216,y:723,t:1527019664638};\\\", \\\"{x:1218,y:721,t:1527019664654};\\\", \\\"{x:1219,y:720,t:1527019664672};\\\", \\\"{x:1219,y:719,t:1527019664688};\\\", \\\"{x:1220,y:717,t:1527019664704};\\\", \\\"{x:1221,y:716,t:1527019664721};\\\", \\\"{x:1222,y:714,t:1527019664737};\\\", \\\"{x:1223,y:711,t:1527019664754};\\\", \\\"{x:1225,y:710,t:1527019664771};\\\", \\\"{x:1225,y:708,t:1527019664789};\\\", \\\"{x:1227,y:705,t:1527019664804};\\\", \\\"{x:1229,y:699,t:1527019664820};\\\", \\\"{x:1231,y:692,t:1527019664837};\\\", \\\"{x:1237,y:683,t:1527019664854};\\\", \\\"{x:1241,y:673,t:1527019664870};\\\", \\\"{x:1245,y:665,t:1527019664887};\\\", \\\"{x:1248,y:657,t:1527019664904};\\\", \\\"{x:1249,y:653,t:1527019664920};\\\", \\\"{x:1252,y:647,t:1527019664938};\\\", \\\"{x:1253,y:645,t:1527019664954};\\\", \\\"{x:1254,y:643,t:1527019664970};\\\", \\\"{x:1256,y:640,t:1527019664988};\\\", \\\"{x:1256,y:637,t:1527019665003};\\\", \\\"{x:1258,y:633,t:1527019665020};\\\", \\\"{x:1259,y:631,t:1527019665037};\\\", \\\"{x:1261,y:625,t:1527019665053};\\\", \\\"{x:1263,y:621,t:1527019665070};\\\", \\\"{x:1265,y:617,t:1527019665086};\\\", \\\"{x:1266,y:616,t:1527019665103};\\\", \\\"{x:1267,y:614,t:1527019665120};\\\", \\\"{x:1269,y:611,t:1527019665136};\\\", \\\"{x:1270,y:606,t:1527019665153};\\\", \\\"{x:1273,y:599,t:1527019665170};\\\", \\\"{x:1274,y:595,t:1527019665188};\\\", \\\"{x:1276,y:592,t:1527019665204};\\\", \\\"{x:1277,y:589,t:1527019665220};\\\", \\\"{x:1278,y:588,t:1527019665237};\\\", \\\"{x:1278,y:587,t:1527019665253};\\\", \\\"{x:1279,y:585,t:1527019665269};\\\", \\\"{x:1280,y:586,t:1527019666826};\\\", \\\"{x:1283,y:591,t:1527019666833};\\\", \\\"{x:1288,y:597,t:1527019666848};\\\", \\\"{x:1297,y:610,t:1527019666866};\\\", \\\"{x:1310,y:627,t:1527019666882};\\\", \\\"{x:1316,y:635,t:1527019666899};\\\", \\\"{x:1320,y:643,t:1527019666916};\\\", \\\"{x:1322,y:647,t:1527019666932};\\\", \\\"{x:1324,y:650,t:1527019666948};\\\", \\\"{x:1325,y:652,t:1527019666965};\\\", \\\"{x:1326,y:656,t:1527019666981};\\\", \\\"{x:1326,y:660,t:1527019666998};\\\", \\\"{x:1328,y:667,t:1527019667015};\\\", \\\"{x:1328,y:675,t:1527019667031};\\\", \\\"{x:1328,y:689,t:1527019667048};\\\", \\\"{x:1329,y:721,t:1527019667066};\\\", \\\"{x:1329,y:745,t:1527019667081};\\\", \\\"{x:1329,y:769,t:1527019667097};\\\", \\\"{x:1329,y:791,t:1527019667114};\\\", \\\"{x:1331,y:812,t:1527019667131};\\\", \\\"{x:1334,y:826,t:1527019667148};\\\", \\\"{x:1338,y:839,t:1527019667165};\\\", \\\"{x:1343,y:850,t:1527019667181};\\\", \\\"{x:1348,y:859,t:1527019667199};\\\", \\\"{x:1353,y:870,t:1527019667215};\\\", \\\"{x:1359,y:879,t:1527019667232};\\\", \\\"{x:1362,y:886,t:1527019667248};\\\", \\\"{x:1365,y:890,t:1527019667265};\\\", \\\"{x:1368,y:895,t:1527019667282};\\\", \\\"{x:1372,y:899,t:1527019667298};\\\", \\\"{x:1373,y:899,t:1527019667314};\\\", \\\"{x:1375,y:901,t:1527019667330};\\\", \\\"{x:1376,y:902,t:1527019667353};\\\", \\\"{x:1376,y:903,t:1527019667378};\\\", \\\"{x:1378,y:903,t:1527019667394};\\\", \\\"{x:1379,y:905,t:1527019667402};\\\", \\\"{x:1380,y:907,t:1527019667426};\\\", \\\"{x:1380,y:908,t:1527019667434};\\\", \\\"{x:1380,y:910,t:1527019667447};\\\", \\\"{x:1382,y:914,t:1527019667464};\\\", \\\"{x:1383,y:919,t:1527019667480};\\\", \\\"{x:1383,y:925,t:1527019667497};\\\", \\\"{x:1383,y:929,t:1527019667514};\\\", \\\"{x:1383,y:930,t:1527019667530};\\\", \\\"{x:1383,y:933,t:1527019667547};\\\", \\\"{x:1382,y:935,t:1527019667563};\\\", \\\"{x:1382,y:936,t:1527019667580};\\\", \\\"{x:1381,y:937,t:1527019667609};\\\", \\\"{x:1379,y:938,t:1527019667633};\\\", \\\"{x:1379,y:940,t:1527019667647};\\\", \\\"{x:1378,y:940,t:1527019667664};\\\", \\\"{x:1377,y:941,t:1527019667681};\\\", \\\"{x:1374,y:943,t:1527019667697};\\\", \\\"{x:1370,y:945,t:1527019667713};\\\", \\\"{x:1368,y:945,t:1527019667730};\\\", \\\"{x:1365,y:946,t:1527019667747};\\\", \\\"{x:1361,y:947,t:1527019667764};\\\", \\\"{x:1359,y:947,t:1527019667780};\\\", \\\"{x:1359,y:948,t:1527019667796};\\\", \\\"{x:1359,y:946,t:1527019667930};\\\", \\\"{x:1361,y:943,t:1527019667946};\\\", \\\"{x:1367,y:939,t:1527019667962};\\\", \\\"{x:1370,y:937,t:1527019667979};\\\", \\\"{x:1371,y:934,t:1527019667996};\\\", \\\"{x:1375,y:930,t:1527019668012};\\\", \\\"{x:1377,y:926,t:1527019668029};\\\", \\\"{x:1378,y:925,t:1527019668045};\\\", \\\"{x:1381,y:923,t:1527019668062};\\\", \\\"{x:1382,y:922,t:1527019668079};\\\", \\\"{x:1383,y:921,t:1527019668095};\\\", \\\"{x:1384,y:918,t:1527019668112};\\\", \\\"{x:1385,y:917,t:1527019668129};\\\", \\\"{x:1385,y:916,t:1527019668145};\\\", \\\"{x:1385,y:915,t:1527019668163};\\\", \\\"{x:1385,y:913,t:1527019668178};\\\", \\\"{x:1386,y:912,t:1527019668195};\\\", \\\"{x:1387,y:912,t:1527019668297};\\\", \\\"{x:1387,y:916,t:1527019668313};\\\", \\\"{x:1388,y:918,t:1527019668328};\\\", \\\"{x:1389,y:927,t:1527019668343};\\\", \\\"{x:1395,y:938,t:1527019668361};\\\", \\\"{x:1402,y:947,t:1527019668377};\\\", \\\"{x:1406,y:953,t:1527019668394};\\\", \\\"{x:1409,y:956,t:1527019668410};\\\", \\\"{x:1411,y:961,t:1527019668428};\\\", \\\"{x:1413,y:966,t:1527019668443};\\\", \\\"{x:1416,y:970,t:1527019668461};\\\", \\\"{x:1419,y:976,t:1527019668477};\\\", \\\"{x:1421,y:979,t:1527019668494};\\\", \\\"{x:1421,y:981,t:1527019668511};\\\", \\\"{x:1422,y:981,t:1527019668530};\\\", \\\"{x:1421,y:981,t:1527019668610};\\\", \\\"{x:1417,y:981,t:1527019668627};\\\", \\\"{x:1407,y:979,t:1527019668644};\\\", \\\"{x:1388,y:975,t:1527019668661};\\\", \\\"{x:1364,y:969,t:1527019668677};\\\", \\\"{x:1339,y:966,t:1527019668695};\\\", \\\"{x:1321,y:963,t:1527019668710};\\\", \\\"{x:1303,y:961,t:1527019668727};\\\", \\\"{x:1296,y:959,t:1527019668744};\\\", \\\"{x:1299,y:958,t:1527019668826};\\\", \\\"{x:1304,y:956,t:1527019668843};\\\", \\\"{x:1311,y:953,t:1527019668860};\\\", \\\"{x:1318,y:951,t:1527019668877};\\\", \\\"{x:1326,y:950,t:1527019668894};\\\", \\\"{x:1333,y:950,t:1527019668910};\\\", \\\"{x:1336,y:950,t:1527019668926};\\\", \\\"{x:1340,y:950,t:1527019668943};\\\", \\\"{x:1348,y:950,t:1527019668959};\\\", \\\"{x:1356,y:948,t:1527019668976};\\\", \\\"{x:1372,y:945,t:1527019668992};\\\", \\\"{x:1380,y:945,t:1527019669008};\\\", \\\"{x:1388,y:945,t:1527019669026};\\\", \\\"{x:1394,y:945,t:1527019669043};\\\", \\\"{x:1396,y:945,t:1527019669059};\\\", \\\"{x:1398,y:945,t:1527019669076};\\\", \\\"{x:1401,y:945,t:1527019669092};\\\", \\\"{x:1402,y:945,t:1527019669113};\\\", \\\"{x:1404,y:945,t:1527019669129};\\\", \\\"{x:1405,y:945,t:1527019669178};\\\", \\\"{x:1407,y:945,t:1527019669194};\\\", \\\"{x:1408,y:945,t:1527019669226};\\\", \\\"{x:1409,y:945,t:1527019669242};\\\", \\\"{x:1410,y:945,t:1527019669259};\\\", \\\"{x:1410,y:946,t:1527019669330};\\\", \\\"{x:1411,y:947,t:1527019669345};\\\", \\\"{x:1411,y:948,t:1527019669361};\\\", \\\"{x:1411,y:949,t:1527019669376};\\\", \\\"{x:1412,y:951,t:1527019669392};\\\", \\\"{x:1412,y:952,t:1527019669408};\\\", \\\"{x:1412,y:954,t:1527019669424};\\\", \\\"{x:1412,y:953,t:1527019669530};\\\", \\\"{x:1414,y:951,t:1527019669541};\\\", \\\"{x:1415,y:947,t:1527019669558};\\\", \\\"{x:1417,y:943,t:1527019669575};\\\", \\\"{x:1417,y:942,t:1527019669591};\\\", \\\"{x:1418,y:941,t:1527019669608};\\\", \\\"{x:1419,y:939,t:1527019669624};\\\", \\\"{x:1420,y:937,t:1527019669642};\\\", \\\"{x:1421,y:936,t:1527019669657};\\\", \\\"{x:1422,y:936,t:1527019669674};\\\", \\\"{x:1422,y:934,t:1527019669692};\\\", \\\"{x:1424,y:931,t:1527019669709};\\\", \\\"{x:1425,y:928,t:1527019669724};\\\", \\\"{x:1427,y:924,t:1527019669741};\\\", \\\"{x:1429,y:920,t:1527019669757};\\\", \\\"{x:1432,y:914,t:1527019669775};\\\", \\\"{x:1435,y:910,t:1527019669792};\\\", \\\"{x:1438,y:904,t:1527019669807};\\\", \\\"{x:1441,y:899,t:1527019669824};\\\", \\\"{x:1441,y:898,t:1527019669866};\\\", \\\"{x:1441,y:897,t:1527019669890};\\\", \\\"{x:1442,y:895,t:1527019669929};\\\", \\\"{x:1443,y:894,t:1527019669940};\\\", \\\"{x:1443,y:893,t:1527019669958};\\\", \\\"{x:1444,y:892,t:1527019669973};\\\", \\\"{x:1445,y:890,t:1527019669990};\\\", \\\"{x:1446,y:889,t:1527019670007};\\\", \\\"{x:1447,y:887,t:1527019670024};\\\", \\\"{x:1448,y:883,t:1527019670041};\\\", \\\"{x:1454,y:877,t:1527019670058};\\\", \\\"{x:1456,y:874,t:1527019670074};\\\", \\\"{x:1459,y:869,t:1527019670090};\\\", \\\"{x:1461,y:867,t:1527019670105};\\\", \\\"{x:1462,y:865,t:1527019670122};\\\", \\\"{x:1463,y:863,t:1527019670139};\\\", \\\"{x:1464,y:861,t:1527019670156};\\\", \\\"{x:1465,y:860,t:1527019670173};\\\", \\\"{x:1466,y:857,t:1527019670189};\\\", \\\"{x:1468,y:855,t:1527019670205};\\\", \\\"{x:1469,y:853,t:1527019670223};\\\", \\\"{x:1470,y:851,t:1527019670239};\\\", \\\"{x:1471,y:850,t:1527019670255};\\\", \\\"{x:1471,y:848,t:1527019670273};\\\", \\\"{x:1472,y:848,t:1527019670289};\\\", \\\"{x:1472,y:847,t:1527019670305};\\\", \\\"{x:1474,y:847,t:1527019670354};\\\", \\\"{x:1475,y:845,t:1527019670377};\\\", \\\"{x:1476,y:845,t:1527019670474};\\\", \\\"{x:1476,y:844,t:1527019670594};\\\", \\\"{x:1476,y:843,t:1527019670606};\\\", \\\"{x:1477,y:842,t:1527019670622};\\\", \\\"{x:1478,y:841,t:1527019670658};\\\", \\\"{x:1478,y:840,t:1527019670682};\\\", \\\"{x:1479,y:838,t:1527019670697};\\\", \\\"{x:1480,y:838,t:1527019671242};\\\", \\\"{x:1480,y:839,t:1527019671254};\\\", \\\"{x:1481,y:841,t:1527019671270};\\\", \\\"{x:1482,y:842,t:1527019671287};\\\", \\\"{x:1482,y:843,t:1527019671303};\\\", \\\"{x:1484,y:844,t:1527019671321};\\\", \\\"{x:1484,y:846,t:1527019671337};\\\", \\\"{x:1484,y:847,t:1527019671352};\\\", \\\"{x:1484,y:848,t:1527019671392};\\\", \\\"{x:1485,y:848,t:1527019671402};\\\", \\\"{x:1486,y:850,t:1527019671425};\\\", \\\"{x:1487,y:851,t:1527019671441};\\\", \\\"{x:1487,y:853,t:1527019671457};\\\", \\\"{x:1488,y:855,t:1527019671470};\\\", \\\"{x:1490,y:858,t:1527019671489};\\\", \\\"{x:1491,y:859,t:1527019671505};\\\", \\\"{x:1491,y:861,t:1527019671519};\\\", \\\"{x:1492,y:864,t:1527019671535};\\\", \\\"{x:1494,y:867,t:1527019671553};\\\", \\\"{x:1495,y:869,t:1527019671569};\\\", \\\"{x:1496,y:870,t:1527019671587};\\\", \\\"{x:1497,y:871,t:1527019671602};\\\", \\\"{x:1498,y:873,t:1527019671619};\\\", \\\"{x:1499,y:874,t:1527019671636};\\\", \\\"{x:1501,y:877,t:1527019671652};\\\", \\\"{x:1501,y:880,t:1527019671669};\\\", \\\"{x:1504,y:882,t:1527019671686};\\\", \\\"{x:1504,y:886,t:1527019671703};\\\", \\\"{x:1507,y:889,t:1527019671719};\\\", \\\"{x:1508,y:892,t:1527019671735};\\\", \\\"{x:1508,y:894,t:1527019671752};\\\", \\\"{x:1510,y:897,t:1527019671770};\\\", \\\"{x:1511,y:899,t:1527019671787};\\\", \\\"{x:1512,y:902,t:1527019671802};\\\", \\\"{x:1513,y:904,t:1527019671820};\\\", \\\"{x:1514,y:905,t:1527019671836};\\\", \\\"{x:1515,y:908,t:1527019671853};\\\", \\\"{x:1517,y:910,t:1527019671873};\\\", \\\"{x:1517,y:912,t:1527019671898};\\\", \\\"{x:1518,y:912,t:1527019671905};\\\", \\\"{x:1518,y:913,t:1527019671919};\\\", \\\"{x:1520,y:915,t:1527019671935};\\\", \\\"{x:1520,y:917,t:1527019671953};\\\", \\\"{x:1521,y:919,t:1527019671969};\\\", \\\"{x:1525,y:928,t:1527019671987};\\\", \\\"{x:1529,y:934,t:1527019672001};\\\", \\\"{x:1533,y:939,t:1527019672018};\\\", \\\"{x:1534,y:942,t:1527019672035};\\\", \\\"{x:1536,y:945,t:1527019672051};\\\", \\\"{x:1538,y:949,t:1527019672068};\\\", \\\"{x:1541,y:952,t:1527019672084};\\\", \\\"{x:1541,y:954,t:1527019672102};\\\", \\\"{x:1542,y:955,t:1527019672119};\\\", \\\"{x:1542,y:956,t:1527019672134};\\\", \\\"{x:1542,y:957,t:1527019672178};\\\", \\\"{x:1542,y:958,t:1527019672187};\\\", \\\"{x:1542,y:959,t:1527019672209};\\\", \\\"{x:1539,y:962,t:1527019672218};\\\", \\\"{x:1525,y:962,t:1527019672234};\\\", \\\"{x:1500,y:962,t:1527019672250};\\\", \\\"{x:1476,y:961,t:1527019672267};\\\", \\\"{x:1454,y:959,t:1527019672283};\\\", \\\"{x:1432,y:956,t:1527019672301};\\\", \\\"{x:1419,y:954,t:1527019672317};\\\", \\\"{x:1414,y:951,t:1527019672334};\\\", \\\"{x:1416,y:945,t:1527019672434};\\\", \\\"{x:1427,y:925,t:1527019672450};\\\", \\\"{x:1439,y:903,t:1527019672467};\\\", \\\"{x:1456,y:880,t:1527019672483};\\\", \\\"{x:1467,y:867,t:1527019672501};\\\", \\\"{x:1478,y:852,t:1527019672517};\\\", \\\"{x:1486,y:840,t:1527019672534};\\\", \\\"{x:1493,y:827,t:1527019672550};\\\", \\\"{x:1494,y:823,t:1527019672567};\\\", \\\"{x:1495,y:821,t:1527019672583};\\\", \\\"{x:1495,y:819,t:1527019672600};\\\", \\\"{x:1497,y:816,t:1527019672642};\\\", \\\"{x:1501,y:813,t:1527019672665};\\\", \\\"{x:1502,y:813,t:1527019672683};\\\", \\\"{x:1502,y:812,t:1527019672701};\\\", \\\"{x:1504,y:810,t:1527019672717};\\\", \\\"{x:1506,y:808,t:1527019672733};\\\", \\\"{x:1508,y:806,t:1527019672750};\\\", \\\"{x:1509,y:804,t:1527019672767};\\\", \\\"{x:1510,y:804,t:1527019672784};\\\", \\\"{x:1511,y:803,t:1527019672799};\\\", \\\"{x:1512,y:802,t:1527019672816};\\\", \\\"{x:1515,y:800,t:1527019672833};\\\", \\\"{x:1515,y:799,t:1527019672849};\\\", \\\"{x:1516,y:798,t:1527019672866};\\\", \\\"{x:1518,y:797,t:1527019672883};\\\", \\\"{x:1518,y:796,t:1527019672899};\\\", \\\"{x:1518,y:797,t:1527019673034};\\\", \\\"{x:1522,y:806,t:1527019673049};\\\", \\\"{x:1527,y:818,t:1527019673065};\\\", \\\"{x:1531,y:828,t:1527019673082};\\\", \\\"{x:1535,y:841,t:1527019673099};\\\", \\\"{x:1537,y:847,t:1527019673115};\\\", \\\"{x:1541,y:853,t:1527019673132};\\\", \\\"{x:1545,y:858,t:1527019673148};\\\", \\\"{x:1547,y:859,t:1527019673166};\\\", \\\"{x:1549,y:863,t:1527019673182};\\\", \\\"{x:1552,y:868,t:1527019673198};\\\", \\\"{x:1556,y:873,t:1527019673215};\\\", \\\"{x:1558,y:877,t:1527019673232};\\\", \\\"{x:1560,y:879,t:1527019673249};\\\", \\\"{x:1563,y:882,t:1527019673265};\\\", \\\"{x:1563,y:883,t:1527019673281};\\\", \\\"{x:1565,y:886,t:1527019673298};\\\", \\\"{x:1567,y:889,t:1527019673316};\\\", \\\"{x:1569,y:891,t:1527019673331};\\\", \\\"{x:1569,y:892,t:1527019673349};\\\", \\\"{x:1570,y:894,t:1527019673365};\\\", \\\"{x:1571,y:894,t:1527019673382};\\\", \\\"{x:1571,y:895,t:1527019673466};\\\", \\\"{x:1571,y:896,t:1527019675130};\\\", \\\"{x:1572,y:896,t:1527019675143};\\\", \\\"{x:1572,y:897,t:1527019675161};\\\", \\\"{x:1572,y:898,t:1527019675201};\\\", \\\"{x:1573,y:899,t:1527019675250};\\\", \\\"{x:1574,y:900,t:1527019675282};\\\", \\\"{x:1575,y:901,t:1527019675330};\\\", \\\"{x:1575,y:902,t:1527019675378};\\\", \\\"{x:1576,y:903,t:1527019675401};\\\", \\\"{x:1577,y:905,t:1527019675418};\\\", \\\"{x:1578,y:906,t:1527019675427};\\\", \\\"{x:1579,y:906,t:1527019675443};\\\", \\\"{x:1579,y:908,t:1527019675466};\\\", \\\"{x:1579,y:906,t:1527019677936};\\\", \\\"{x:1579,y:904,t:1527019677952};\\\", \\\"{x:1578,y:901,t:1527019677967};\\\", \\\"{x:1577,y:899,t:1527019677983};\\\", \\\"{x:1577,y:898,t:1527019678001};\\\", \\\"{x:1577,y:897,t:1527019678018};\\\", \\\"{x:1577,y:896,t:1527019678034};\\\", \\\"{x:1576,y:896,t:1527019678051};\\\", \\\"{x:1576,y:895,t:1527019678068};\\\", \\\"{x:1575,y:895,t:1527019678084};\\\", \\\"{x:1574,y:893,t:1527019678100};\\\", \\\"{x:1572,y:891,t:1527019678117};\\\", \\\"{x:1571,y:890,t:1527019678134};\\\", \\\"{x:1571,y:889,t:1527019678151};\\\", \\\"{x:1568,y:885,t:1527019678167};\\\", \\\"{x:1566,y:881,t:1527019678184};\\\", \\\"{x:1564,y:879,t:1527019678200};\\\", \\\"{x:1562,y:876,t:1527019678217};\\\", \\\"{x:1559,y:874,t:1527019678234};\\\", \\\"{x:1557,y:872,t:1527019678250};\\\", \\\"{x:1556,y:870,t:1527019678266};\\\", \\\"{x:1552,y:867,t:1527019678284};\\\", \\\"{x:1548,y:861,t:1527019678300};\\\", \\\"{x:1545,y:858,t:1527019678317};\\\", \\\"{x:1543,y:856,t:1527019678334};\\\", \\\"{x:1541,y:854,t:1527019678349};\\\", \\\"{x:1539,y:850,t:1527019678367};\\\", \\\"{x:1537,y:848,t:1527019678383};\\\", \\\"{x:1534,y:844,t:1527019678399};\\\", \\\"{x:1530,y:840,t:1527019678417};\\\", \\\"{x:1528,y:838,t:1527019678432};\\\", \\\"{x:1525,y:836,t:1527019678450};\\\", \\\"{x:1522,y:835,t:1527019678467};\\\", \\\"{x:1514,y:833,t:1527019678483};\\\", \\\"{x:1507,y:831,t:1527019678500};\\\", \\\"{x:1501,y:831,t:1527019678516};\\\", \\\"{x:1493,y:831,t:1527019678533};\\\", \\\"{x:1483,y:831,t:1527019678550};\\\", \\\"{x:1475,y:834,t:1527019678567};\\\", \\\"{x:1469,y:837,t:1527019678582};\\\", \\\"{x:1464,y:840,t:1527019678600};\\\", \\\"{x:1462,y:842,t:1527019678616};\\\", \\\"{x:1460,y:844,t:1527019678633};\\\", \\\"{x:1460,y:846,t:1527019678663};\\\", \\\"{x:1459,y:846,t:1527019678744};\\\", \\\"{x:1459,y:847,t:1527019678752};\\\", \\\"{x:1459,y:846,t:1527019679279};\\\", \\\"{x:1459,y:844,t:1527019679298};\\\", \\\"{x:1459,y:843,t:1527019679326};\\\", \\\"{x:1460,y:842,t:1527019679334};\\\", \\\"{x:1462,y:840,t:1527019679347};\\\", \\\"{x:1463,y:840,t:1527019679363};\\\", \\\"{x:1464,y:839,t:1527019679390};\\\", \\\"{x:1465,y:839,t:1527019679399};\\\", \\\"{x:1467,y:839,t:1527019679568};\\\", \\\"{x:1471,y:836,t:1527019679580};\\\", \\\"{x:1479,y:826,t:1527019679597};\\\", \\\"{x:1483,y:824,t:1527019679614};\\\", \\\"{x:1487,y:819,t:1527019679631};\\\", \\\"{x:1487,y:817,t:1527019679647};\\\", \\\"{x:1489,y:813,t:1527019679663};\\\", \\\"{x:1491,y:811,t:1527019679680};\\\", \\\"{x:1492,y:809,t:1527019679697};\\\", \\\"{x:1494,y:805,t:1527019679713};\\\", \\\"{x:1496,y:801,t:1527019679729};\\\", \\\"{x:1499,y:796,t:1527019679746};\\\", \\\"{x:1500,y:794,t:1527019679762};\\\", \\\"{x:1502,y:790,t:1527019679780};\\\", \\\"{x:1503,y:786,t:1527019679796};\\\", \\\"{x:1504,y:784,t:1527019679812};\\\", \\\"{x:1505,y:783,t:1527019679847};\\\", \\\"{x:1503,y:783,t:1527019680144};\\\", \\\"{x:1492,y:785,t:1527019680162};\\\", \\\"{x:1460,y:793,t:1527019680179};\\\", \\\"{x:1406,y:805,t:1527019680195};\\\", \\\"{x:1325,y:806,t:1527019680212};\\\", \\\"{x:1243,y:814,t:1527019680227};\\\", \\\"{x:1157,y:822,t:1527019680244};\\\", \\\"{x:1041,y:824,t:1527019680262};\\\", \\\"{x:957,y:823,t:1527019680277};\\\", \\\"{x:900,y:808,t:1527019680294};\\\", \\\"{x:831,y:782,t:1527019680310};\\\", \\\"{x:807,y:772,t:1527019680327};\\\", \\\"{x:771,y:755,t:1527019680344};\\\", \\\"{x:750,y:739,t:1527019680361};\\\", \\\"{x:736,y:731,t:1527019680377};\\\", \\\"{x:729,y:721,t:1527019680394};\\\", \\\"{x:717,y:702,t:1527019680410};\\\", \\\"{x:702,y:685,t:1527019680427};\\\", \\\"{x:679,y:668,t:1527019680444};\\\", \\\"{x:660,y:653,t:1527019680460};\\\", \\\"{x:646,y:639,t:1527019680478};\\\", \\\"{x:629,y:625,t:1527019680494};\\\", \\\"{x:612,y:612,t:1527019680511};\\\", \\\"{x:603,y:600,t:1527019680527};\\\", \\\"{x:603,y:599,t:1527019680537};\\\", \\\"{x:603,y:596,t:1527019680554};\\\", \\\"{x:603,y:590,t:1527019680570};\\\", \\\"{x:603,y:587,t:1527019680587};\\\", \\\"{x:603,y:584,t:1527019680608};\\\", \\\"{x:603,y:582,t:1527019680625};\\\", \\\"{x:603,y:580,t:1527019680647};\\\", \\\"{x:603,y:579,t:1527019680663};\\\", \\\"{x:603,y:576,t:1527019680675};\\\", \\\"{x:604,y:572,t:1527019680691};\\\", \\\"{x:606,y:570,t:1527019680708};\\\", \\\"{x:606,y:569,t:1527019680725};\\\", \\\"{x:611,y:569,t:1527019681038};\\\", \\\"{x:622,y:569,t:1527019681046};\\\", \\\"{x:631,y:569,t:1527019681058};\\\", \\\"{x:654,y:569,t:1527019681076};\\\", \\\"{x:695,y:569,t:1527019681091};\\\", \\\"{x:740,y:574,t:1527019681109};\\\", \\\"{x:776,y:577,t:1527019681125};\\\", \\\"{x:796,y:577,t:1527019681142};\\\", \\\"{x:808,y:577,t:1527019681159};\\\", \\\"{x:818,y:576,t:1527019681175};\\\", \\\"{x:823,y:574,t:1527019681192};\\\", \\\"{x:827,y:573,t:1527019681209};\\\", \\\"{x:835,y:569,t:1527019681225};\\\", \\\"{x:847,y:566,t:1527019681242};\\\", \\\"{x:860,y:563,t:1527019681258};\\\", \\\"{x:873,y:563,t:1527019681275};\\\", \\\"{x:886,y:563,t:1527019681292};\\\", \\\"{x:890,y:563,t:1527019681308};\\\", \\\"{x:891,y:563,t:1527019681325};\\\", \\\"{x:889,y:563,t:1527019681414};\\\", \\\"{x:884,y:565,t:1527019681425};\\\", \\\"{x:879,y:566,t:1527019681442};\\\", \\\"{x:872,y:568,t:1527019681460};\\\", \\\"{x:866,y:570,t:1527019681476};\\\", \\\"{x:858,y:573,t:1527019681492};\\\", \\\"{x:853,y:573,t:1527019681510};\\\", \\\"{x:847,y:578,t:1527019681525};\\\", \\\"{x:845,y:578,t:1527019681543};\\\", \\\"{x:841,y:580,t:1527019681559};\\\", \\\"{x:839,y:580,t:1527019681575};\\\", \\\"{x:838,y:580,t:1527019681592};\\\", \\\"{x:837,y:581,t:1527019681614};\\\", \\\"{x:833,y:584,t:1527019682071};\\\", \\\"{x:827,y:589,t:1527019682079};\\\", \\\"{x:821,y:595,t:1527019682093};\\\", \\\"{x:803,y:609,t:1527019682110};\\\", \\\"{x:784,y:622,t:1527019682126};\\\", \\\"{x:761,y:635,t:1527019682143};\\\", \\\"{x:724,y:656,t:1527019682159};\\\", \\\"{x:704,y:668,t:1527019682176};\\\", \\\"{x:685,y:677,t:1527019682192};\\\", \\\"{x:671,y:685,t:1527019682209};\\\", \\\"{x:661,y:692,t:1527019682226};\\\", \\\"{x:652,y:696,t:1527019682244};\\\", \\\"{x:642,y:704,t:1527019682259};\\\", \\\"{x:636,y:708,t:1527019682276};\\\", \\\"{x:632,y:713,t:1527019682293};\\\", \\\"{x:630,y:716,t:1527019682309};\\\", \\\"{x:626,y:718,t:1527019682326};\\\", \\\"{x:618,y:723,t:1527019682343};\\\", \\\"{x:613,y:725,t:1527019682359};\\\", \\\"{x:609,y:726,t:1527019682376};\\\", \\\"{x:607,y:727,t:1527019682393};\\\", \\\"{x:604,y:728,t:1527019682410};\\\", \\\"{x:603,y:729,t:1527019682426};\\\", \\\"{x:601,y:729,t:1527019682444};\\\", \\\"{x:599,y:730,t:1527019682471};\\\", \\\"{x:598,y:730,t:1527019682479};\\\", \\\"{x:594,y:730,t:1527019682494};\\\", \\\"{x:593,y:730,t:1527019682510};\\\", \\\"{x:590,y:731,t:1527019682527};\\\", \\\"{x:586,y:732,t:1527019682543};\\\", \\\"{x:584,y:732,t:1527019682559};\\\", \\\"{x:583,y:732,t:1527019682591};\\\", \\\"{x:581,y:732,t:1527019682696};\\\", \\\"{x:579,y:732,t:1527019682711};\\\", \\\"{x:578,y:733,t:1527019682743};\\\", \\\"{x:571,y:733,t:1527019682761};\\\", \\\"{x:569,y:733,t:1527019682776};\\\", \\\"{x:568,y:734,t:1527019683232};\\\", \\\"{x:565,y:735,t:1527019683244};\\\", \\\"{x:564,y:735,t:1527019683262};\\\", \\\"{x:562,y:735,t:1527019683278};\\\", \\\"{x:559,y:735,t:1527019683293};\\\", \\\"{x:551,y:735,t:1527019683310};\\\", \\\"{x:543,y:733,t:1527019683326};\\\", \\\"{x:539,y:732,t:1527019683344};\\\", \\\"{x:533,y:729,t:1527019683360};\\\", \\\"{x:530,y:729,t:1527019683377};\\\", \\\"{x:529,y:729,t:1527019683393};\\\", \\\"{x:527,y:728,t:1527019683410};\\\", \\\"{x:526,y:729,t:1527019683726};\\\", \\\"{x:523,y:743,t:1527019683744};\\\", \\\"{x:521,y:760,t:1527019683760};\\\", \\\"{x:514,y:780,t:1527019683777};\\\", \\\"{x:505,y:799,t:1527019683794};\\\", \\\"{x:494,y:821,t:1527019683810};\\\", \\\"{x:477,y:846,t:1527019683827};\\\", \\\"{x:468,y:863,t:1527019683845};\\\", \\\"{x:465,y:865,t:1527019683860};\\\" ] }, { \\\"rt\\\": 54531, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 363080, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B -B -B -B -B -B -B -C -C -C -C -G -G -04 PM-O -G -10 AM-04 PM-X -G -G -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:463,y:865,t:1527019685374};\\\", \\\"{x:461,y:865,t:1527019685407};\\\", \\\"{x:461,y:866,t:1527019685503};\\\", \\\"{x:459,y:865,t:1527019685519};\\\", \\\"{x:458,y:860,t:1527019685528};\\\", \\\"{x:447,y:839,t:1527019685545};\\\", \\\"{x:428,y:815,t:1527019685562};\\\", \\\"{x:412,y:781,t:1527019685578};\\\", \\\"{x:389,y:724,t:1527019685595};\\\", \\\"{x:359,y:662,t:1527019685613};\\\", \\\"{x:325,y:614,t:1527019685630};\\\", \\\"{x:295,y:572,t:1527019685647};\\\", \\\"{x:268,y:532,t:1527019685664};\\\", \\\"{x:255,y:508,t:1527019685679};\\\", \\\"{x:250,y:492,t:1527019685695};\\\", \\\"{x:246,y:481,t:1527019685713};\\\", \\\"{x:246,y:478,t:1527019685728};\\\", \\\"{x:246,y:474,t:1527019685746};\\\", \\\"{x:247,y:471,t:1527019685762};\\\", \\\"{x:247,y:466,t:1527019685780};\\\", \\\"{x:249,y:460,t:1527019685796};\\\", \\\"{x:249,y:456,t:1527019685812};\\\", \\\"{x:251,y:455,t:1527019685829};\\\", \\\"{x:251,y:454,t:1527019685862};\\\", \\\"{x:251,y:453,t:1527019685879};\\\", \\\"{x:253,y:453,t:1527019685950};\\\", \\\"{x:255,y:453,t:1527019685962};\\\", \\\"{x:260,y:453,t:1527019685979};\\\", \\\"{x:266,y:454,t:1527019685996};\\\", \\\"{x:270,y:457,t:1527019686012};\\\", \\\"{x:276,y:458,t:1527019686029};\\\", \\\"{x:281,y:460,t:1527019686047};\\\", \\\"{x:284,y:461,t:1527019686063};\\\", \\\"{x:287,y:461,t:1527019686079};\\\", \\\"{x:290,y:461,t:1527019686097};\\\", \\\"{x:291,y:461,t:1527019686113};\\\", \\\"{x:296,y:461,t:1527019686129};\\\", \\\"{x:298,y:461,t:1527019686146};\\\", \\\"{x:300,y:461,t:1527019686162};\\\", \\\"{x:303,y:461,t:1527019686180};\\\", \\\"{x:307,y:461,t:1527019686197};\\\", \\\"{x:311,y:461,t:1527019686212};\\\", \\\"{x:314,y:461,t:1527019686230};\\\", \\\"{x:319,y:461,t:1527019686247};\\\", \\\"{x:323,y:461,t:1527019686263};\\\", \\\"{x:325,y:461,t:1527019686280};\\\", \\\"{x:330,y:461,t:1527019686297};\\\", \\\"{x:337,y:461,t:1527019686314};\\\", \\\"{x:343,y:461,t:1527019686329};\\\", \\\"{x:349,y:460,t:1527019686347};\\\", \\\"{x:355,y:459,t:1527019686363};\\\", \\\"{x:358,y:459,t:1527019686380};\\\", \\\"{x:363,y:459,t:1527019686397};\\\", \\\"{x:367,y:459,t:1527019686414};\\\", \\\"{x:376,y:458,t:1527019686429};\\\", \\\"{x:392,y:458,t:1527019686448};\\\", \\\"{x:401,y:458,t:1527019686464};\\\", \\\"{x:412,y:458,t:1527019686479};\\\", \\\"{x:424,y:458,t:1527019686496};\\\", \\\"{x:435,y:458,t:1527019686514};\\\", \\\"{x:448,y:458,t:1527019686529};\\\", \\\"{x:452,y:458,t:1527019686547};\\\", \\\"{x:456,y:458,t:1527019686564};\\\", \\\"{x:457,y:458,t:1527019686579};\\\", \\\"{x:460,y:459,t:1527019686597};\\\", \\\"{x:462,y:459,t:1527019686614};\\\", \\\"{x:465,y:460,t:1527019686630};\\\", \\\"{x:467,y:460,t:1527019686655};\\\", \\\"{x:468,y:460,t:1527019686671};\\\", \\\"{x:469,y:460,t:1527019686695};\\\", \\\"{x:470,y:460,t:1527019686704};\\\", \\\"{x:471,y:460,t:1527019686713};\\\", \\\"{x:472,y:460,t:1527019686730};\\\", \\\"{x:474,y:460,t:1527019686747};\\\", \\\"{x:475,y:460,t:1527019686764};\\\", \\\"{x:476,y:460,t:1527019686783};\\\", \\\"{x:478,y:460,t:1527019686797};\\\", \\\"{x:480,y:460,t:1527019686816};\\\", \\\"{x:481,y:460,t:1527019686830};\\\", \\\"{x:482,y:460,t:1527019686849};\\\", \\\"{x:483,y:460,t:1527019686864};\\\", \\\"{x:485,y:460,t:1527019686960};\\\", \\\"{x:486,y:460,t:1527019686975};\\\", \\\"{x:487,y:460,t:1527019686984};\\\", \\\"{x:488,y:460,t:1527019686998};\\\", \\\"{x:490,y:460,t:1527019687014};\\\", \\\"{x:493,y:460,t:1527019687031};\\\", \\\"{x:495,y:460,t:1527019687048};\\\", \\\"{x:496,y:460,t:1527019687064};\\\", \\\"{x:497,y:460,t:1527019687081};\\\", \\\"{x:499,y:460,t:1527019687098};\\\", \\\"{x:501,y:460,t:1527019687114};\\\", \\\"{x:502,y:460,t:1527019687131};\\\", \\\"{x:503,y:460,t:1527019687148};\\\", \\\"{x:504,y:460,t:1527019687200};\\\", \\\"{x:505,y:460,t:1527019687223};\\\", \\\"{x:506,y:460,t:1527019687231};\\\", \\\"{x:507,y:459,t:1527019687248};\\\", \\\"{x:508,y:459,t:1527019687271};\\\", \\\"{x:509,y:459,t:1527019687281};\\\", \\\"{x:514,y:457,t:1527019687303};\\\", \\\"{x:515,y:456,t:1527019687319};\\\", \\\"{x:516,y:456,t:1527019687439};\\\", \\\"{x:517,y:456,t:1527019687448};\\\", \\\"{x:518,y:456,t:1527019687488};\\\", \\\"{x:519,y:456,t:1527019687503};\\\", \\\"{x:520,y:456,t:1527019687515};\\\", \\\"{x:522,y:456,t:1527019687531};\\\", \\\"{x:523,y:456,t:1527019687547};\\\", \\\"{x:524,y:456,t:1527019687565};\\\", \\\"{x:526,y:456,t:1527019687581};\\\", \\\"{x:528,y:456,t:1527019687598};\\\", \\\"{x:531,y:456,t:1527019687615};\\\", \\\"{x:533,y:456,t:1527019687632};\\\", \\\"{x:535,y:456,t:1527019687648};\\\", \\\"{x:536,y:456,t:1527019687665};\\\", \\\"{x:537,y:456,t:1527019687687};\\\", \\\"{x:538,y:456,t:1527019687711};\\\", \\\"{x:539,y:456,t:1527019687727};\\\", \\\"{x:540,y:456,t:1527019687735};\\\", \\\"{x:541,y:456,t:1527019687748};\\\", \\\"{x:542,y:456,t:1527019687764};\\\", \\\"{x:544,y:455,t:1527019687782};\\\", \\\"{x:545,y:455,t:1527019688079};\\\", \\\"{x:549,y:455,t:1527019688087};\\\", \\\"{x:556,y:455,t:1527019688099};\\\", \\\"{x:574,y:455,t:1527019688115};\\\", \\\"{x:593,y:457,t:1527019688132};\\\", \\\"{x:610,y:460,t:1527019688149};\\\", \\\"{x:620,y:464,t:1527019688165};\\\", \\\"{x:623,y:464,t:1527019688182};\\\", \\\"{x:624,y:464,t:1527019688399};\\\", \\\"{x:626,y:464,t:1527019688431};\\\", \\\"{x:629,y:464,t:1527019688448};\\\", \\\"{x:630,y:464,t:1527019688466};\\\", \\\"{x:632,y:463,t:1527019688495};\\\", \\\"{x:633,y:463,t:1527019688816};\\\", \\\"{x:634,y:463,t:1527019688833};\\\", \\\"{x:637,y:463,t:1527019688850};\\\", \\\"{x:637,y:464,t:1527019688879};\\\", \\\"{x:637,y:463,t:1527019689535};\\\", \\\"{x:637,y:462,t:1527019689592};\\\", \\\"{x:637,y:461,t:1527019689650};\\\", \\\"{x:637,y:460,t:1527019689666};\\\", \\\"{x:641,y:460,t:1527019689684};\\\", \\\"{x:649,y:460,t:1527019689699};\\\", \\\"{x:664,y:460,t:1527019689716};\\\", \\\"{x:682,y:462,t:1527019689734};\\\", \\\"{x:696,y:465,t:1527019689749};\\\", \\\"{x:720,y:471,t:1527019689766};\\\", \\\"{x:734,y:472,t:1527019689784};\\\", \\\"{x:745,y:476,t:1527019689800};\\\", \\\"{x:751,y:476,t:1527019689816};\\\", \\\"{x:762,y:478,t:1527019689833};\\\", \\\"{x:778,y:481,t:1527019689851};\\\", \\\"{x:790,y:485,t:1527019689867};\\\", \\\"{x:809,y:490,t:1527019689884};\\\", \\\"{x:829,y:496,t:1527019689900};\\\", \\\"{x:843,y:503,t:1527019689916};\\\", \\\"{x:857,y:508,t:1527019689932};\\\", \\\"{x:875,y:518,t:1527019689948};\\\", \\\"{x:891,y:529,t:1527019689965};\\\", \\\"{x:920,y:549,t:1527019689982};\\\", \\\"{x:940,y:565,t:1527019690000};\\\", \\\"{x:962,y:581,t:1527019690016};\\\", \\\"{x:981,y:598,t:1527019690033};\\\", \\\"{x:1004,y:613,t:1527019690049};\\\", \\\"{x:1026,y:628,t:1527019690065};\\\", \\\"{x:1051,y:646,t:1527019690082};\\\", \\\"{x:1081,y:672,t:1527019690098};\\\", \\\"{x:1126,y:703,t:1527019690115};\\\", \\\"{x:1196,y:752,t:1527019690133};\\\", \\\"{x:1251,y:788,t:1527019690149};\\\", \\\"{x:1307,y:827,t:1527019690165};\\\", \\\"{x:1343,y:856,t:1527019690181};\\\", \\\"{x:1398,y:898,t:1527019690199};\\\", \\\"{x:1440,y:919,t:1527019690215};\\\", \\\"{x:1473,y:938,t:1527019690232};\\\", \\\"{x:1479,y:944,t:1527019690248};\\\", \\\"{x:1480,y:944,t:1527019691062};\\\", \\\"{x:1480,y:943,t:1527019691128};\\\", \\\"{x:1480,y:942,t:1527019691390};\\\", \\\"{x:1480,y:941,t:1527019691398};\\\", \\\"{x:1481,y:940,t:1527019691413};\\\", \\\"{x:1482,y:940,t:1527019691447};\\\", \\\"{x:1482,y:939,t:1527019691494};\\\", \\\"{x:1481,y:938,t:1527019691518};\\\", \\\"{x:1480,y:937,t:1527019691535};\\\", \\\"{x:1479,y:937,t:1527019691547};\\\", \\\"{x:1478,y:936,t:1527019691563};\\\", \\\"{x:1477,y:936,t:1527019691583};\\\", \\\"{x:1476,y:935,t:1527019691597};\\\", \\\"{x:1475,y:934,t:1527019691612};\\\", \\\"{x:1473,y:933,t:1527019691630};\\\", \\\"{x:1472,y:932,t:1527019691646};\\\", \\\"{x:1471,y:932,t:1527019691680};\\\", \\\"{x:1470,y:931,t:1527019691728};\\\", \\\"{x:1469,y:931,t:1527019691736};\\\", \\\"{x:1468,y:931,t:1527019691746};\\\", \\\"{x:1467,y:931,t:1527019691763};\\\", \\\"{x:1464,y:930,t:1527019691781};\\\", \\\"{x:1461,y:929,t:1527019691796};\\\", \\\"{x:1456,y:927,t:1527019691813};\\\", \\\"{x:1452,y:925,t:1527019691829};\\\", \\\"{x:1449,y:923,t:1527019691846};\\\", \\\"{x:1441,y:920,t:1527019691862};\\\", \\\"{x:1438,y:920,t:1527019691879};\\\", \\\"{x:1436,y:918,t:1527019691896};\\\", \\\"{x:1433,y:916,t:1527019691913};\\\", \\\"{x:1430,y:915,t:1527019691929};\\\", \\\"{x:1424,y:913,t:1527019691945};\\\", \\\"{x:1415,y:910,t:1527019691962};\\\", \\\"{x:1410,y:908,t:1527019691979};\\\", \\\"{x:1407,y:907,t:1527019691996};\\\", \\\"{x:1405,y:907,t:1527019692012};\\\", \\\"{x:1405,y:906,t:1527019692328};\\\", \\\"{x:1403,y:904,t:1527019692335};\\\", \\\"{x:1401,y:902,t:1527019692346};\\\", \\\"{x:1399,y:900,t:1527019692363};\\\", \\\"{x:1394,y:893,t:1527019692378};\\\", \\\"{x:1387,y:887,t:1527019692395};\\\", \\\"{x:1384,y:883,t:1527019692412};\\\", \\\"{x:1381,y:880,t:1527019692428};\\\", \\\"{x:1378,y:873,t:1527019692447};\\\", \\\"{x:1377,y:866,t:1527019692462};\\\", \\\"{x:1373,y:859,t:1527019692478};\\\", \\\"{x:1370,y:854,t:1527019692496};\\\", \\\"{x:1366,y:850,t:1527019692512};\\\", \\\"{x:1364,y:845,t:1527019692528};\\\", \\\"{x:1359,y:842,t:1527019692545};\\\", \\\"{x:1354,y:837,t:1527019692561};\\\", \\\"{x:1347,y:832,t:1527019692578};\\\", \\\"{x:1337,y:826,t:1527019692596};\\\", \\\"{x:1331,y:818,t:1527019692611};\\\", \\\"{x:1328,y:808,t:1527019692628};\\\", \\\"{x:1326,y:797,t:1527019692645};\\\", \\\"{x:1326,y:790,t:1527019692661};\\\", \\\"{x:1327,y:776,t:1527019692677};\\\", \\\"{x:1329,y:770,t:1527019692695};\\\", \\\"{x:1331,y:767,t:1527019692711};\\\", \\\"{x:1332,y:765,t:1527019692728};\\\", \\\"{x:1334,y:762,t:1527019692743};\\\", \\\"{x:1334,y:761,t:1527019692760};\\\", \\\"{x:1336,y:761,t:1527019692777};\\\", \\\"{x:1337,y:759,t:1527019692794};\\\", \\\"{x:1338,y:759,t:1527019692810};\\\", \\\"{x:1341,y:759,t:1527019692847};\\\", \\\"{x:1341,y:758,t:1527019692870};\\\", \\\"{x:1342,y:758,t:1527019692886};\\\", \\\"{x:1342,y:757,t:1527019692894};\\\", \\\"{x:1347,y:756,t:1527019692910};\\\", \\\"{x:1348,y:755,t:1527019692927};\\\", \\\"{x:1349,y:755,t:1527019692943};\\\", \\\"{x:1352,y:754,t:1527019692961};\\\", \\\"{x:1353,y:754,t:1527019692991};\\\", \\\"{x:1354,y:754,t:1527019693047};\\\", \\\"{x:1355,y:754,t:1527019693103};\\\", \\\"{x:1355,y:755,t:1527019693119};\\\", \\\"{x:1355,y:756,t:1527019693127};\\\", \\\"{x:1357,y:761,t:1527019693144};\\\", \\\"{x:1357,y:762,t:1527019693160};\\\", \\\"{x:1357,y:763,t:1527019693178};\\\", \\\"{x:1357,y:764,t:1527019693200};\\\", \\\"{x:1357,y:765,t:1527019693296};\\\", \\\"{x:1355,y:765,t:1527019693311};\\\", \\\"{x:1354,y:765,t:1527019693327};\\\", \\\"{x:1351,y:765,t:1527019693346};\\\", \\\"{x:1347,y:764,t:1527019693359};\\\", \\\"{x:1344,y:763,t:1527019693376};\\\", \\\"{x:1342,y:763,t:1527019693393};\\\", \\\"{x:1341,y:763,t:1527019693410};\\\", \\\"{x:1340,y:763,t:1527019693463};\\\", \\\"{x:1340,y:762,t:1527019693712};\\\", \\\"{x:1340,y:761,t:1527019693727};\\\", \\\"{x:1341,y:761,t:1527019693743};\\\", \\\"{x:1343,y:761,t:1527019694128};\\\", \\\"{x:1343,y:760,t:1527019694215};\\\", \\\"{x:1341,y:760,t:1527019694450};\\\", \\\"{x:1340,y:761,t:1527019694463};\\\", \\\"{x:1340,y:762,t:1527019694487};\\\", \\\"{x:1339,y:763,t:1527019694511};\\\", \\\"{x:1339,y:764,t:1527019694935};\\\", \\\"{x:1339,y:765,t:1527019694943};\\\", \\\"{x:1339,y:767,t:1527019694959};\\\", \\\"{x:1339,y:768,t:1527019694975};\\\", \\\"{x:1339,y:770,t:1527019694990};\\\", \\\"{x:1339,y:772,t:1527019695007};\\\", \\\"{x:1337,y:773,t:1527019695024};\\\", \\\"{x:1337,y:774,t:1527019695055};\\\", \\\"{x:1336,y:777,t:1527019695087};\\\", \\\"{x:1336,y:778,t:1527019695103};\\\", \\\"{x:1335,y:780,t:1527019695119};\\\", \\\"{x:1335,y:781,t:1527019695143};\\\", \\\"{x:1334,y:782,t:1527019695157};\\\", \\\"{x:1334,y:783,t:1527019695174};\\\", \\\"{x:1334,y:785,t:1527019695190};\\\", \\\"{x:1333,y:787,t:1527019695207};\\\", \\\"{x:1332,y:788,t:1527019695231};\\\", \\\"{x:1332,y:789,t:1527019695255};\\\", \\\"{x:1332,y:790,t:1527019695271};\\\", \\\"{x:1331,y:791,t:1527019695295};\\\", \\\"{x:1330,y:793,t:1527019695334};\\\", \\\"{x:1330,y:791,t:1527019695446};\\\", \\\"{x:1332,y:786,t:1527019695455};\\\", \\\"{x:1334,y:776,t:1527019695472};\\\", \\\"{x:1337,y:769,t:1527019695489};\\\", \\\"{x:1338,y:762,t:1527019695505};\\\", \\\"{x:1341,y:759,t:1527019695523};\\\", \\\"{x:1341,y:756,t:1527019695539};\\\", \\\"{x:1342,y:755,t:1527019695556};\\\", \\\"{x:1343,y:753,t:1527019695573};\\\", \\\"{x:1345,y:752,t:1527019695589};\\\", \\\"{x:1345,y:751,t:1527019695606};\\\", \\\"{x:1346,y:750,t:1527019695623};\\\", \\\"{x:1346,y:751,t:1527019695799};\\\", \\\"{x:1346,y:752,t:1527019695807};\\\", \\\"{x:1346,y:753,t:1527019695839};\\\", \\\"{x:1345,y:754,t:1527019696112};\\\", \\\"{x:1342,y:754,t:1527019696122};\\\", \\\"{x:1335,y:755,t:1527019696138};\\\", \\\"{x:1332,y:756,t:1527019696155};\\\", \\\"{x:1324,y:758,t:1527019696172};\\\", \\\"{x:1322,y:758,t:1527019696188};\\\", \\\"{x:1320,y:758,t:1527019696205};\\\", \\\"{x:1319,y:759,t:1527019696223};\\\", \\\"{x:1319,y:760,t:1527019696239};\\\", \\\"{x:1318,y:761,t:1527019696296};\\\", \\\"{x:1317,y:761,t:1527019696327};\\\", \\\"{x:1317,y:762,t:1527019696343};\\\", \\\"{x:1315,y:764,t:1527019696407};\\\", \\\"{x:1315,y:765,t:1527019696420};\\\", \\\"{x:1315,y:766,t:1527019696471};\\\", \\\"{x:1317,y:766,t:1527019696535};\\\", \\\"{x:1322,y:766,t:1527019696543};\\\", \\\"{x:1326,y:766,t:1527019696554};\\\", \\\"{x:1334,y:766,t:1527019696571};\\\", \\\"{x:1343,y:766,t:1527019696587};\\\", \\\"{x:1348,y:766,t:1527019696604};\\\", \\\"{x:1350,y:766,t:1527019696621};\\\", \\\"{x:1351,y:766,t:1527019696637};\\\", \\\"{x:1354,y:765,t:1527019696697};\\\", \\\"{x:1353,y:767,t:1527019696840};\\\", \\\"{x:1352,y:770,t:1527019696855};\\\", \\\"{x:1347,y:780,t:1527019696870};\\\", \\\"{x:1335,y:790,t:1527019696887};\\\", \\\"{x:1332,y:793,t:1527019696905};\\\", \\\"{x:1331,y:794,t:1527019696921};\\\", \\\"{x:1330,y:795,t:1527019696938};\\\", \\\"{x:1330,y:796,t:1527019696954};\\\", \\\"{x:1329,y:797,t:1527019696971};\\\", \\\"{x:1329,y:798,t:1527019696987};\\\", \\\"{x:1328,y:800,t:1527019697003};\\\", \\\"{x:1326,y:804,t:1527019697020};\\\", \\\"{x:1324,y:808,t:1527019697037};\\\", \\\"{x:1323,y:813,t:1527019697053};\\\", \\\"{x:1320,y:819,t:1527019697070};\\\", \\\"{x:1316,y:831,t:1527019697087};\\\", \\\"{x:1312,y:841,t:1527019697103};\\\", \\\"{x:1308,y:851,t:1527019697120};\\\", \\\"{x:1303,y:863,t:1527019697137};\\\", \\\"{x:1298,y:875,t:1527019697153};\\\", \\\"{x:1292,y:888,t:1527019697170};\\\", \\\"{x:1286,y:899,t:1527019697186};\\\", \\\"{x:1283,y:907,t:1527019697203};\\\", \\\"{x:1282,y:914,t:1527019697220};\\\", \\\"{x:1278,y:921,t:1527019697236};\\\", \\\"{x:1275,y:928,t:1527019697253};\\\", \\\"{x:1272,y:935,t:1527019697270};\\\", \\\"{x:1269,y:943,t:1527019697287};\\\", \\\"{x:1266,y:951,t:1527019697303};\\\", \\\"{x:1264,y:959,t:1527019697320};\\\", \\\"{x:1260,y:966,t:1527019697336};\\\", \\\"{x:1257,y:971,t:1527019697354};\\\", \\\"{x:1256,y:973,t:1527019697369};\\\", \\\"{x:1254,y:975,t:1527019697387};\\\", \\\"{x:1254,y:976,t:1527019697407};\\\", \\\"{x:1252,y:978,t:1527019697419};\\\", \\\"{x:1251,y:978,t:1527019697568};\\\", \\\"{x:1250,y:977,t:1527019697575};\\\", \\\"{x:1249,y:972,t:1527019697587};\\\", \\\"{x:1249,y:969,t:1527019697602};\\\", \\\"{x:1249,y:967,t:1527019697620};\\\", \\\"{x:1249,y:964,t:1527019697636};\\\", \\\"{x:1249,y:963,t:1527019697652};\\\", \\\"{x:1249,y:962,t:1527019697670};\\\", \\\"{x:1249,y:963,t:1527019698271};\\\", \\\"{x:1249,y:964,t:1527019698284};\\\", \\\"{x:1249,y:965,t:1527019698301};\\\", \\\"{x:1249,y:963,t:1527019698607};\\\", \\\"{x:1249,y:962,t:1527019698631};\\\", \\\"{x:1249,y:959,t:1527019698639};\\\", \\\"{x:1251,y:959,t:1527019698651};\\\", \\\"{x:1253,y:956,t:1527019698667};\\\", \\\"{x:1255,y:954,t:1527019698684};\\\", \\\"{x:1259,y:951,t:1527019698700};\\\", \\\"{x:1267,y:946,t:1527019698716};\\\", \\\"{x:1274,y:938,t:1527019698734};\\\", \\\"{x:1286,y:924,t:1527019698750};\\\", \\\"{x:1296,y:907,t:1527019698766};\\\", \\\"{x:1301,y:895,t:1527019698784};\\\", \\\"{x:1311,y:879,t:1527019698800};\\\", \\\"{x:1317,y:868,t:1527019698817};\\\", \\\"{x:1321,y:861,t:1527019698833};\\\", \\\"{x:1324,y:855,t:1527019698850};\\\", \\\"{x:1327,y:848,t:1527019698867};\\\", \\\"{x:1328,y:846,t:1527019698883};\\\", \\\"{x:1330,y:843,t:1527019698900};\\\", \\\"{x:1329,y:841,t:1527019698918};\\\", \\\"{x:1329,y:837,t:1527019698933};\\\", \\\"{x:1329,y:835,t:1527019698950};\\\", \\\"{x:1328,y:834,t:1527019698967};\\\", \\\"{x:1329,y:829,t:1527019698983};\\\", \\\"{x:1331,y:823,t:1527019699000};\\\", \\\"{x:1331,y:819,t:1527019699016};\\\", \\\"{x:1332,y:816,t:1527019699033};\\\", \\\"{x:1332,y:814,t:1527019699050};\\\", \\\"{x:1333,y:812,t:1527019699066};\\\", \\\"{x:1334,y:811,t:1527019699084};\\\", \\\"{x:1334,y:807,t:1527019699100};\\\", \\\"{x:1334,y:803,t:1527019699117};\\\", \\\"{x:1334,y:800,t:1527019699133};\\\", \\\"{x:1334,y:797,t:1527019699149};\\\", \\\"{x:1334,y:794,t:1527019699167};\\\", \\\"{x:1333,y:786,t:1527019699183};\\\", \\\"{x:1333,y:782,t:1527019699199};\\\", \\\"{x:1333,y:781,t:1527019699217};\\\", \\\"{x:1333,y:779,t:1527019699233};\\\", \\\"{x:1333,y:776,t:1527019699249};\\\", \\\"{x:1333,y:773,t:1527019699267};\\\", \\\"{x:1333,y:769,t:1527019699284};\\\", \\\"{x:1333,y:768,t:1527019699359};\\\", \\\"{x:1333,y:767,t:1527019699399};\\\", \\\"{x:1333,y:766,t:1527019699448};\\\", \\\"{x:1333,y:765,t:1527019699471};\\\", \\\"{x:1334,y:765,t:1527019699503};\\\", \\\"{x:1335,y:765,t:1527019699527};\\\", \\\"{x:1336,y:765,t:1527019699559};\\\", \\\"{x:1338,y:765,t:1527019699575};\\\", \\\"{x:1338,y:764,t:1527019699583};\\\", \\\"{x:1339,y:764,t:1527019699607};\\\", \\\"{x:1341,y:764,t:1527019699623};\\\", \\\"{x:1342,y:764,t:1527019699640};\\\", \\\"{x:1344,y:764,t:1527019699649};\\\", \\\"{x:1346,y:765,t:1527019699669};\\\", \\\"{x:1347,y:765,t:1527019699710};\\\", \\\"{x:1348,y:765,t:1527019701430};\\\", \\\"{x:1349,y:765,t:1527019701510};\\\", \\\"{x:1349,y:763,t:1527019718821};\\\", \\\"{x:1349,y:759,t:1527019718830};\\\", \\\"{x:1349,y:756,t:1527019718848};\\\", \\\"{x:1349,y:754,t:1527019718864};\\\", \\\"{x:1349,y:753,t:1527019718880};\\\", \\\"{x:1349,y:752,t:1527019718898};\\\", \\\"{x:1349,y:750,t:1527019719046};\\\", \\\"{x:1349,y:748,t:1527019719062};\\\", \\\"{x:1349,y:745,t:1527019719069};\\\", \\\"{x:1349,y:741,t:1527019719081};\\\", \\\"{x:1352,y:734,t:1527019719097};\\\", \\\"{x:1355,y:723,t:1527019719113};\\\", \\\"{x:1356,y:716,t:1527019719131};\\\", \\\"{x:1362,y:704,t:1527019719148};\\\", \\\"{x:1365,y:693,t:1527019719164};\\\", \\\"{x:1369,y:682,t:1527019719181};\\\", \\\"{x:1373,y:670,t:1527019719196};\\\", \\\"{x:1378,y:660,t:1527019719213};\\\", \\\"{x:1384,y:648,t:1527019719230};\\\", \\\"{x:1386,y:642,t:1527019719248};\\\", \\\"{x:1388,y:639,t:1527019719264};\\\", \\\"{x:1390,y:634,t:1527019719281};\\\", \\\"{x:1392,y:631,t:1527019719296};\\\", \\\"{x:1397,y:626,t:1527019719313};\\\", \\\"{x:1404,y:619,t:1527019719330};\\\", \\\"{x:1406,y:614,t:1527019719346};\\\", \\\"{x:1411,y:610,t:1527019719363};\\\", \\\"{x:1418,y:597,t:1527019719380};\\\", \\\"{x:1422,y:590,t:1527019719397};\\\", \\\"{x:1425,y:587,t:1527019719414};\\\", \\\"{x:1427,y:584,t:1527019719429};\\\", \\\"{x:1428,y:585,t:1527019719671};\\\", \\\"{x:1430,y:592,t:1527019719680};\\\", \\\"{x:1432,y:598,t:1527019719697};\\\", \\\"{x:1433,y:602,t:1527019719713};\\\", \\\"{x:1434,y:607,t:1527019719730};\\\", \\\"{x:1436,y:608,t:1527019719747};\\\", \\\"{x:1439,y:611,t:1527019719763};\\\", \\\"{x:1439,y:613,t:1527019719780};\\\", \\\"{x:1441,y:615,t:1527019719796};\\\", \\\"{x:1442,y:617,t:1527019719813};\\\", \\\"{x:1443,y:619,t:1527019719830};\\\", \\\"{x:1443,y:622,t:1527019719846};\\\", \\\"{x:1446,y:629,t:1527019719863};\\\", \\\"{x:1450,y:635,t:1527019719880};\\\", \\\"{x:1451,y:638,t:1527019719897};\\\", \\\"{x:1453,y:642,t:1527019719913};\\\", \\\"{x:1456,y:649,t:1527019719929};\\\", \\\"{x:1459,y:653,t:1527019719946};\\\", \\\"{x:1461,y:661,t:1527019719963};\\\", \\\"{x:1462,y:665,t:1527019719979};\\\", \\\"{x:1464,y:672,t:1527019719997};\\\", \\\"{x:1466,y:677,t:1527019720014};\\\", \\\"{x:1469,y:685,t:1527019720029};\\\", \\\"{x:1473,y:693,t:1527019720046};\\\", \\\"{x:1475,y:697,t:1527019720063};\\\", \\\"{x:1476,y:700,t:1527019720079};\\\", \\\"{x:1478,y:702,t:1527019720096};\\\", \\\"{x:1479,y:707,t:1527019720112};\\\", \\\"{x:1482,y:712,t:1527019720129};\\\", \\\"{x:1485,y:720,t:1527019720146};\\\", \\\"{x:1488,y:725,t:1527019720162};\\\", \\\"{x:1492,y:733,t:1527019720179};\\\", \\\"{x:1496,y:741,t:1527019720196};\\\", \\\"{x:1500,y:750,t:1527019720212};\\\", \\\"{x:1502,y:757,t:1527019720229};\\\", \\\"{x:1504,y:759,t:1527019720245};\\\", \\\"{x:1508,y:766,t:1527019720262};\\\", \\\"{x:1512,y:772,t:1527019720279};\\\", \\\"{x:1517,y:783,t:1527019720295};\\\", \\\"{x:1520,y:791,t:1527019720312};\\\", \\\"{x:1522,y:794,t:1527019720329};\\\", \\\"{x:1524,y:796,t:1527019720345};\\\", \\\"{x:1525,y:797,t:1527019720362};\\\", \\\"{x:1525,y:798,t:1527019720379};\\\", \\\"{x:1525,y:797,t:1527019721118};\\\", \\\"{x:1525,y:796,t:1527019721127};\\\", \\\"{x:1524,y:795,t:1527019721144};\\\", \\\"{x:1523,y:792,t:1527019721161};\\\", \\\"{x:1523,y:790,t:1527019721178};\\\", \\\"{x:1522,y:789,t:1527019721194};\\\", \\\"{x:1521,y:786,t:1527019721210};\\\", \\\"{x:1520,y:785,t:1527019721227};\\\", \\\"{x:1519,y:783,t:1527019721244};\\\", \\\"{x:1518,y:779,t:1527019721261};\\\", \\\"{x:1517,y:777,t:1527019721277};\\\", \\\"{x:1513,y:773,t:1527019721295};\\\", \\\"{x:1511,y:769,t:1527019721311};\\\", \\\"{x:1508,y:764,t:1527019721326};\\\", \\\"{x:1506,y:761,t:1527019721343};\\\", \\\"{x:1501,y:752,t:1527019721359};\\\", \\\"{x:1497,y:746,t:1527019721376};\\\", \\\"{x:1492,y:739,t:1527019721392};\\\", \\\"{x:1488,y:732,t:1527019721410};\\\", \\\"{x:1484,y:724,t:1527019721426};\\\", \\\"{x:1477,y:714,t:1527019721442};\\\", \\\"{x:1467,y:702,t:1527019721460};\\\", \\\"{x:1453,y:683,t:1527019721477};\\\", \\\"{x:1442,y:668,t:1527019721493};\\\", \\\"{x:1434,y:654,t:1527019721509};\\\", \\\"{x:1430,y:648,t:1527019721525};\\\", \\\"{x:1423,y:639,t:1527019721542};\\\", \\\"{x:1421,y:637,t:1527019721559};\\\", \\\"{x:1419,y:635,t:1527019721576};\\\", \\\"{x:1416,y:633,t:1527019721593};\\\", \\\"{x:1414,y:630,t:1527019721609};\\\", \\\"{x:1410,y:624,t:1527019721626};\\\", \\\"{x:1408,y:620,t:1527019721643};\\\", \\\"{x:1405,y:615,t:1527019721660};\\\", \\\"{x:1405,y:612,t:1527019721675};\\\", \\\"{x:1404,y:608,t:1527019721693};\\\", \\\"{x:1404,y:604,t:1527019721709};\\\", \\\"{x:1404,y:597,t:1527019721726};\\\", \\\"{x:1404,y:591,t:1527019721742};\\\", \\\"{x:1404,y:589,t:1527019721759};\\\", \\\"{x:1404,y:587,t:1527019721776};\\\", \\\"{x:1406,y:585,t:1527019721793};\\\", \\\"{x:1406,y:584,t:1527019721815};\\\", \\\"{x:1406,y:583,t:1527019721826};\\\", \\\"{x:1407,y:582,t:1527019721844};\\\", \\\"{x:1407,y:580,t:1527019721859};\\\", \\\"{x:1407,y:578,t:1527019721976};\\\", \\\"{x:1407,y:577,t:1527019721999};\\\", \\\"{x:1407,y:576,t:1527019722031};\\\", \\\"{x:1408,y:574,t:1527019722042};\\\", \\\"{x:1408,y:573,t:1527019722743};\\\", \\\"{x:1397,y:573,t:1527019722758};\\\", \\\"{x:1369,y:581,t:1527019722774};\\\", \\\"{x:1306,y:586,t:1527019722791};\\\", \\\"{x:1206,y:590,t:1527019722808};\\\", \\\"{x:1103,y:590,t:1527019722824};\\\", \\\"{x:981,y:590,t:1527019722841};\\\", \\\"{x:868,y:590,t:1527019722858};\\\", \\\"{x:778,y:588,t:1527019722873};\\\", \\\"{x:715,y:583,t:1527019722891};\\\", \\\"{x:675,y:583,t:1527019722903};\\\", \\\"{x:648,y:583,t:1527019722918};\\\", \\\"{x:620,y:585,t:1527019722935};\\\", \\\"{x:585,y:590,t:1527019722953};\\\", \\\"{x:516,y:594,t:1527019722976};\\\", \\\"{x:474,y:594,t:1527019722993};\\\", \\\"{x:443,y:594,t:1527019723009};\\\", \\\"{x:414,y:592,t:1527019723026};\\\", \\\"{x:389,y:587,t:1527019723042};\\\", \\\"{x:372,y:584,t:1527019723059};\\\", \\\"{x:358,y:582,t:1527019723075};\\\", \\\"{x:353,y:582,t:1527019723092};\\\", \\\"{x:352,y:582,t:1527019723109};\\\", \\\"{x:352,y:581,t:1527019723133};\\\", \\\"{x:352,y:580,t:1527019723143};\\\", \\\"{x:353,y:579,t:1527019723160};\\\", \\\"{x:359,y:574,t:1527019723176};\\\", \\\"{x:373,y:570,t:1527019723193};\\\", \\\"{x:390,y:565,t:1527019723209};\\\", \\\"{x:409,y:562,t:1527019723227};\\\", \\\"{x:426,y:560,t:1527019723242};\\\", \\\"{x:452,y:555,t:1527019723260};\\\", \\\"{x:486,y:554,t:1527019723275};\\\", \\\"{x:527,y:554,t:1527019723293};\\\", \\\"{x:575,y:554,t:1527019723310};\\\", \\\"{x:597,y:554,t:1527019723325};\\\", \\\"{x:613,y:554,t:1527019723343};\\\", \\\"{x:621,y:554,t:1527019723360};\\\", \\\"{x:626,y:554,t:1527019723376};\\\", \\\"{x:627,y:554,t:1527019723393};\\\", \\\"{x:629,y:554,t:1527019723409};\\\", \\\"{x:632,y:554,t:1527019723425};\\\", \\\"{x:641,y:553,t:1527019723443};\\\", \\\"{x:663,y:553,t:1527019723460};\\\", \\\"{x:695,y:553,t:1527019723476};\\\", \\\"{x:728,y:553,t:1527019723495};\\\", \\\"{x:755,y:553,t:1527019723509};\\\", \\\"{x:765,y:553,t:1527019723525};\\\", \\\"{x:769,y:553,t:1527019723542};\\\", \\\"{x:771,y:553,t:1527019723559};\\\", \\\"{x:773,y:552,t:1527019723589};\\\", \\\"{x:774,y:551,t:1527019723598};\\\", \\\"{x:778,y:547,t:1527019723609};\\\", \\\"{x:786,y:542,t:1527019723626};\\\", \\\"{x:790,y:540,t:1527019723642};\\\", \\\"{x:792,y:539,t:1527019723660};\\\", \\\"{x:793,y:538,t:1527019723685};\\\", \\\"{x:793,y:537,t:1527019723726};\\\", \\\"{x:795,y:536,t:1527019723743};\\\", \\\"{x:796,y:535,t:1527019723766};\\\", \\\"{x:798,y:535,t:1527019723806};\\\", \\\"{x:799,y:535,t:1527019723814};\\\", \\\"{x:802,y:535,t:1527019723826};\\\", \\\"{x:808,y:535,t:1527019723843};\\\", \\\"{x:815,y:535,t:1527019723859};\\\", \\\"{x:821,y:535,t:1527019723876};\\\", \\\"{x:827,y:536,t:1527019723894};\\\", \\\"{x:832,y:537,t:1527019723908};\\\", \\\"{x:837,y:538,t:1527019723926};\\\", \\\"{x:838,y:538,t:1527019724246};\\\", \\\"{x:840,y:540,t:1527019724259};\\\", \\\"{x:863,y:542,t:1527019724276};\\\", \\\"{x:955,y:545,t:1527019724294};\\\", \\\"{x:1043,y:548,t:1527019724310};\\\", \\\"{x:1120,y:559,t:1527019724326};\\\", \\\"{x:1171,y:567,t:1527019724343};\\\", \\\"{x:1197,y:572,t:1527019724361};\\\", \\\"{x:1215,y:575,t:1527019724377};\\\", \\\"{x:1224,y:578,t:1527019724394};\\\", \\\"{x:1231,y:581,t:1527019724411};\\\", \\\"{x:1239,y:581,t:1527019724427};\\\", \\\"{x:1244,y:586,t:1527019724443};\\\", \\\"{x:1265,y:595,t:1527019724461};\\\", \\\"{x:1300,y:614,t:1527019724477};\\\", \\\"{x:1353,y:641,t:1527019724495};\\\", \\\"{x:1371,y:654,t:1527019724510};\\\", \\\"{x:1379,y:667,t:1527019724527};\\\", \\\"{x:1380,y:680,t:1527019724544};\\\", \\\"{x:1380,y:694,t:1527019724561};\\\", \\\"{x:1380,y:705,t:1527019724577};\\\", \\\"{x:1378,y:711,t:1527019724594};\\\", \\\"{x:1374,y:719,t:1527019724611};\\\", \\\"{x:1372,y:724,t:1527019724627};\\\", \\\"{x:1371,y:726,t:1527019724644};\\\", \\\"{x:1370,y:727,t:1527019724660};\\\", \\\"{x:1370,y:728,t:1527019724677};\\\", \\\"{x:1368,y:729,t:1527019724701};\\\", \\\"{x:1368,y:730,t:1527019725495};\\\", \\\"{x:1366,y:731,t:1527019725511};\\\", \\\"{x:1365,y:731,t:1527019725528};\\\", \\\"{x:1364,y:732,t:1527019725855};\\\", \\\"{x:1362,y:732,t:1527019725862};\\\", \\\"{x:1362,y:731,t:1527019726102};\\\", \\\"{x:1362,y:730,t:1527019726112};\\\", \\\"{x:1362,y:726,t:1527019726130};\\\", \\\"{x:1362,y:725,t:1527019726150};\\\", \\\"{x:1362,y:724,t:1527019726162};\\\", \\\"{x:1364,y:718,t:1527019726179};\\\", \\\"{x:1366,y:715,t:1527019726195};\\\", \\\"{x:1372,y:706,t:1527019726213};\\\", \\\"{x:1380,y:698,t:1527019726229};\\\", \\\"{x:1396,y:690,t:1527019726245};\\\", \\\"{x:1424,y:674,t:1527019726261};\\\", \\\"{x:1436,y:660,t:1527019726279};\\\", \\\"{x:1442,y:650,t:1527019726295};\\\", \\\"{x:1444,y:646,t:1527019726312};\\\", \\\"{x:1445,y:642,t:1527019726329};\\\", \\\"{x:1446,y:637,t:1527019726345};\\\", \\\"{x:1447,y:626,t:1527019726362};\\\", \\\"{x:1447,y:618,t:1527019726379};\\\", \\\"{x:1447,y:610,t:1527019726395};\\\", \\\"{x:1446,y:604,t:1527019726412};\\\", \\\"{x:1443,y:600,t:1527019726429};\\\", \\\"{x:1440,y:599,t:1527019726445};\\\", \\\"{x:1437,y:597,t:1527019726462};\\\", \\\"{x:1436,y:597,t:1527019726479};\\\", \\\"{x:1435,y:596,t:1527019726497};\\\", \\\"{x:1434,y:596,t:1527019726513};\\\", \\\"{x:1432,y:595,t:1527019726529};\\\", \\\"{x:1431,y:593,t:1527019726546};\\\", \\\"{x:1427,y:588,t:1527019726562};\\\", \\\"{x:1421,y:576,t:1527019726579};\\\", \\\"{x:1417,y:572,t:1527019726597};\\\", \\\"{x:1414,y:567,t:1527019726612};\\\", \\\"{x:1410,y:563,t:1527019726629};\\\", \\\"{x:1409,y:563,t:1527019726648};\\\", \\\"{x:1409,y:562,t:1527019726670};\\\", \\\"{x:1408,y:562,t:1527019726680};\\\", \\\"{x:1410,y:566,t:1527019727183};\\\", \\\"{x:1411,y:569,t:1527019727197};\\\", \\\"{x:1416,y:576,t:1527019727213};\\\", \\\"{x:1419,y:582,t:1527019727230};\\\", \\\"{x:1427,y:594,t:1527019727246};\\\", \\\"{x:1428,y:600,t:1527019727262};\\\", \\\"{x:1433,y:607,t:1527019727278};\\\", \\\"{x:1434,y:613,t:1527019727296};\\\", \\\"{x:1437,y:621,t:1527019727313};\\\", \\\"{x:1441,y:628,t:1527019727330};\\\", \\\"{x:1445,y:639,t:1527019727345};\\\", \\\"{x:1446,y:645,t:1527019727363};\\\", \\\"{x:1450,y:653,t:1527019727380};\\\", \\\"{x:1451,y:660,t:1527019727396};\\\", \\\"{x:1453,y:666,t:1527019727413};\\\", \\\"{x:1455,y:676,t:1527019727430};\\\", \\\"{x:1457,y:682,t:1527019727446};\\\", \\\"{x:1459,y:689,t:1527019727463};\\\", \\\"{x:1460,y:695,t:1527019727480};\\\", \\\"{x:1461,y:701,t:1527019727496};\\\", \\\"{x:1464,y:710,t:1527019727513};\\\", \\\"{x:1467,y:718,t:1527019727530};\\\", \\\"{x:1472,y:728,t:1527019727546};\\\", \\\"{x:1477,y:741,t:1527019727563};\\\", \\\"{x:1482,y:753,t:1527019727580};\\\", \\\"{x:1489,y:764,t:1527019727596};\\\", \\\"{x:1495,y:773,t:1527019727613};\\\", \\\"{x:1503,y:789,t:1527019727630};\\\", \\\"{x:1511,y:807,t:1527019727647};\\\", \\\"{x:1518,y:819,t:1527019727663};\\\", \\\"{x:1527,y:835,t:1527019727680};\\\", \\\"{x:1535,y:846,t:1527019727697};\\\", \\\"{x:1544,y:860,t:1527019727713};\\\", \\\"{x:1552,y:872,t:1527019727730};\\\", \\\"{x:1560,y:881,t:1527019727747};\\\", \\\"{x:1566,y:890,t:1527019727764};\\\", \\\"{x:1573,y:900,t:1527019727780};\\\", \\\"{x:1584,y:913,t:1527019727797};\\\", \\\"{x:1594,y:924,t:1527019727813};\\\", \\\"{x:1608,y:938,t:1527019727830};\\\", \\\"{x:1612,y:946,t:1527019727846};\\\", \\\"{x:1615,y:953,t:1527019727863};\\\", \\\"{x:1618,y:957,t:1527019727881};\\\", \\\"{x:1620,y:963,t:1527019727897};\\\", \\\"{x:1623,y:968,t:1527019727914};\\\", \\\"{x:1624,y:970,t:1527019727931};\\\", \\\"{x:1625,y:971,t:1527019727947};\\\", \\\"{x:1625,y:972,t:1527019727999};\\\", \\\"{x:1626,y:972,t:1527019728014};\\\", \\\"{x:1626,y:973,t:1527019728030};\\\", \\\"{x:1626,y:974,t:1527019728048};\\\", \\\"{x:1626,y:975,t:1527019728063};\\\", \\\"{x:1626,y:977,t:1527019728087};\\\", \\\"{x:1625,y:977,t:1527019728183};\\\", \\\"{x:1624,y:975,t:1527019728198};\\\", \\\"{x:1623,y:971,t:1527019728214};\\\", \\\"{x:1622,y:970,t:1527019728231};\\\", \\\"{x:1621,y:968,t:1527019728250};\\\", \\\"{x:1620,y:967,t:1527019728311};\\\", \\\"{x:1619,y:966,t:1527019728327};\\\", \\\"{x:1619,y:965,t:1527019728342};\\\", \\\"{x:1618,y:964,t:1527019728350};\\\", \\\"{x:1617,y:963,t:1527019728398};\\\", \\\"{x:1617,y:962,t:1527019728575};\\\", \\\"{x:1615,y:962,t:1527019728583};\\\", \\\"{x:1614,y:962,t:1527019728599};\\\", \\\"{x:1613,y:962,t:1527019728623};\\\", \\\"{x:1612,y:962,t:1527019728910};\\\", \\\"{x:1612,y:961,t:1527019729447};\\\", \\\"{x:1612,y:959,t:1527019729471};\\\", \\\"{x:1609,y:957,t:1527019729481};\\\", \\\"{x:1608,y:949,t:1527019729499};\\\", \\\"{x:1605,y:942,t:1527019729515};\\\", \\\"{x:1597,y:931,t:1527019729532};\\\", \\\"{x:1591,y:918,t:1527019729548};\\\", \\\"{x:1585,y:906,t:1527019729566};\\\", \\\"{x:1581,y:898,t:1527019729581};\\\", \\\"{x:1572,y:880,t:1527019729599};\\\", \\\"{x:1566,y:868,t:1527019729615};\\\", \\\"{x:1560,y:856,t:1527019729632};\\\", \\\"{x:1551,y:841,t:1527019729649};\\\", \\\"{x:1545,y:825,t:1527019729666};\\\", \\\"{x:1536,y:809,t:1527019729682};\\\", \\\"{x:1525,y:785,t:1527019729698};\\\", \\\"{x:1513,y:764,t:1527019729715};\\\", \\\"{x:1495,y:739,t:1527019729733};\\\", \\\"{x:1487,y:721,t:1527019729748};\\\", \\\"{x:1477,y:705,t:1527019729766};\\\", \\\"{x:1471,y:689,t:1527019729782};\\\", \\\"{x:1461,y:667,t:1527019729798};\\\", \\\"{x:1458,y:658,t:1527019729815};\\\", \\\"{x:1453,y:649,t:1527019729832};\\\", \\\"{x:1448,y:637,t:1527019729849};\\\", \\\"{x:1442,y:623,t:1527019729865};\\\", \\\"{x:1436,y:611,t:1527019729881};\\\", \\\"{x:1433,y:599,t:1527019729898};\\\", \\\"{x:1431,y:593,t:1527019729916};\\\", \\\"{x:1430,y:589,t:1527019729931};\\\", \\\"{x:1428,y:583,t:1527019729949};\\\", \\\"{x:1425,y:580,t:1527019729966};\\\", \\\"{x:1423,y:573,t:1527019729982};\\\", \\\"{x:1419,y:569,t:1527019729999};\\\", \\\"{x:1416,y:565,t:1527019730016};\\\", \\\"{x:1412,y:560,t:1527019730032};\\\", \\\"{x:1405,y:555,t:1527019730051};\\\", \\\"{x:1397,y:550,t:1527019730065};\\\", \\\"{x:1391,y:547,t:1527019730083};\\\", \\\"{x:1387,y:545,t:1527019730099};\\\", \\\"{x:1385,y:545,t:1527019730115};\\\", \\\"{x:1383,y:545,t:1527019730133};\\\", \\\"{x:1380,y:551,t:1527019730149};\\\", \\\"{x:1375,y:559,t:1527019730166};\\\", \\\"{x:1368,y:574,t:1527019730183};\\\", \\\"{x:1363,y:584,t:1527019730198};\\\", \\\"{x:1361,y:593,t:1527019730215};\\\", \\\"{x:1360,y:600,t:1527019730232};\\\", \\\"{x:1358,y:606,t:1527019730249};\\\", \\\"{x:1357,y:611,t:1527019730266};\\\", \\\"{x:1355,y:619,t:1527019730283};\\\", \\\"{x:1353,y:627,t:1527019730298};\\\", \\\"{x:1350,y:636,t:1527019730315};\\\", \\\"{x:1347,y:648,t:1527019730332};\\\", \\\"{x:1342,y:665,t:1527019730349};\\\", \\\"{x:1332,y:681,t:1527019730365};\\\", \\\"{x:1320,y:710,t:1527019730383};\\\", \\\"{x:1312,y:731,t:1527019730399};\\\", \\\"{x:1305,y:752,t:1527019730416};\\\", \\\"{x:1295,y:768,t:1527019730432};\\\", \\\"{x:1288,y:789,t:1527019730450};\\\", \\\"{x:1278,y:808,t:1527019730466};\\\", \\\"{x:1272,y:824,t:1527019730482};\\\", \\\"{x:1264,y:844,t:1527019730499};\\\", \\\"{x:1258,y:856,t:1527019730515};\\\", \\\"{x:1251,y:875,t:1527019730532};\\\", \\\"{x:1241,y:888,t:1527019730550};\\\", \\\"{x:1231,y:909,t:1527019730565};\\\", \\\"{x:1218,y:936,t:1527019730582};\\\", \\\"{x:1212,y:951,t:1527019730600};\\\", \\\"{x:1207,y:960,t:1527019730616};\\\", \\\"{x:1204,y:966,t:1527019730632};\\\", \\\"{x:1201,y:971,t:1527019730649};\\\", \\\"{x:1200,y:978,t:1527019730665};\\\", \\\"{x:1198,y:985,t:1527019730682};\\\", \\\"{x:1196,y:989,t:1527019730698};\\\", \\\"{x:1195,y:990,t:1527019730715};\\\", \\\"{x:1204,y:990,t:1527019730838};\\\", \\\"{x:1213,y:990,t:1527019730849};\\\", \\\"{x:1241,y:988,t:1527019730867};\\\", \\\"{x:1277,y:988,t:1527019730882};\\\", \\\"{x:1314,y:986,t:1527019730899};\\\", \\\"{x:1348,y:985,t:1527019730916};\\\", \\\"{x:1367,y:985,t:1527019730932};\\\", \\\"{x:1389,y:985,t:1527019730949};\\\", \\\"{x:1413,y:985,t:1527019730966};\\\", \\\"{x:1431,y:985,t:1527019730982};\\\", \\\"{x:1454,y:985,t:1527019730999};\\\", \\\"{x:1483,y:985,t:1527019731016};\\\", \\\"{x:1507,y:985,t:1527019731032};\\\", \\\"{x:1530,y:985,t:1527019731049};\\\", \\\"{x:1548,y:985,t:1527019731066};\\\", \\\"{x:1557,y:985,t:1527019731082};\\\", \\\"{x:1560,y:985,t:1527019731099};\\\", \\\"{x:1568,y:985,t:1527019731116};\\\", \\\"{x:1574,y:985,t:1527019731132};\\\", \\\"{x:1584,y:986,t:1527019731150};\\\", \\\"{x:1599,y:990,t:1527019731166};\\\", \\\"{x:1602,y:990,t:1527019731182};\\\", \\\"{x:1603,y:990,t:1527019731206};\\\", \\\"{x:1604,y:990,t:1527019731216};\\\", \\\"{x:1606,y:987,t:1527019731234};\\\", \\\"{x:1606,y:969,t:1527019731249};\\\", \\\"{x:1595,y:935,t:1527019731267};\\\", \\\"{x:1563,y:883,t:1527019731283};\\\", \\\"{x:1532,y:843,t:1527019731299};\\\", \\\"{x:1505,y:814,t:1527019731316};\\\", \\\"{x:1486,y:794,t:1527019731334};\\\", \\\"{x:1472,y:783,t:1527019731349};\\\", \\\"{x:1468,y:780,t:1527019731366};\\\", \\\"{x:1468,y:785,t:1527019731423};\\\", \\\"{x:1469,y:793,t:1527019731433};\\\", \\\"{x:1473,y:806,t:1527019731450};\\\", \\\"{x:1478,y:814,t:1527019731467};\\\", \\\"{x:1482,y:821,t:1527019731483};\\\", \\\"{x:1489,y:829,t:1527019731500};\\\", \\\"{x:1495,y:834,t:1527019731517};\\\", \\\"{x:1501,y:839,t:1527019731534};\\\", \\\"{x:1506,y:848,t:1527019731549};\\\", \\\"{x:1513,y:859,t:1527019731566};\\\", \\\"{x:1517,y:866,t:1527019731584};\\\", \\\"{x:1526,y:882,t:1527019731599};\\\", \\\"{x:1533,y:897,t:1527019731617};\\\", \\\"{x:1540,y:906,t:1527019731633};\\\", \\\"{x:1544,y:912,t:1527019731649};\\\", \\\"{x:1544,y:917,t:1527019731666};\\\", \\\"{x:1548,y:922,t:1527019731683};\\\", \\\"{x:1548,y:924,t:1527019731700};\\\", \\\"{x:1549,y:925,t:1527019731717};\\\", \\\"{x:1551,y:927,t:1527019731733};\\\", \\\"{x:1551,y:928,t:1527019731750};\\\", \\\"{x:1552,y:931,t:1527019731766};\\\", \\\"{x:1552,y:933,t:1527019731790};\\\", \\\"{x:1553,y:933,t:1527019731800};\\\", \\\"{x:1553,y:934,t:1527019731817};\\\", \\\"{x:1554,y:934,t:1527019731839};\\\", \\\"{x:1554,y:935,t:1527019731851};\\\", \\\"{x:1554,y:936,t:1527019731866};\\\", \\\"{x:1550,y:928,t:1527019731950};\\\", \\\"{x:1528,y:899,t:1527019731966};\\\", \\\"{x:1497,y:851,t:1527019731983};\\\", \\\"{x:1456,y:780,t:1527019732000};\\\", \\\"{x:1422,y:698,t:1527019732016};\\\", \\\"{x:1398,y:650,t:1527019732033};\\\", \\\"{x:1383,y:614,t:1527019732050};\\\", \\\"{x:1378,y:590,t:1527019732068};\\\", \\\"{x:1378,y:569,t:1527019732083};\\\", \\\"{x:1377,y:553,t:1527019732100};\\\", \\\"{x:1377,y:547,t:1527019732116};\\\", \\\"{x:1377,y:543,t:1527019732134};\\\", \\\"{x:1377,y:536,t:1527019732150};\\\", \\\"{x:1377,y:527,t:1527019732167};\\\", \\\"{x:1379,y:520,t:1527019732183};\\\", \\\"{x:1380,y:518,t:1527019732200};\\\", \\\"{x:1381,y:518,t:1527019732279};\\\", \\\"{x:1382,y:518,t:1527019732286};\\\", \\\"{x:1386,y:518,t:1527019732300};\\\", \\\"{x:1395,y:522,t:1527019732317};\\\", \\\"{x:1405,y:530,t:1527019732332};\\\", \\\"{x:1413,y:538,t:1527019732350};\\\", \\\"{x:1416,y:541,t:1527019732366};\\\", \\\"{x:1417,y:544,t:1527019732383};\\\", \\\"{x:1417,y:548,t:1527019732399};\\\", \\\"{x:1418,y:549,t:1527019732417};\\\", \\\"{x:1418,y:552,t:1527019732710};\\\", \\\"{x:1416,y:553,t:1527019732718};\\\", \\\"{x:1414,y:555,t:1527019732734};\\\", \\\"{x:1411,y:559,t:1527019732751};\\\", \\\"{x:1409,y:561,t:1527019732767};\\\", \\\"{x:1408,y:561,t:1527019732786};\\\", \\\"{x:1408,y:562,t:1527019732801};\\\", \\\"{x:1406,y:563,t:1527019732818};\\\", \\\"{x:1405,y:564,t:1527019732834};\\\", \\\"{x:1403,y:566,t:1527019732850};\\\", \\\"{x:1402,y:566,t:1527019732867};\\\", \\\"{x:1400,y:567,t:1527019732884};\\\", \\\"{x:1399,y:567,t:1527019732900};\\\", \\\"{x:1396,y:568,t:1527019732917};\\\", \\\"{x:1388,y:569,t:1527019732934};\\\", \\\"{x:1380,y:570,t:1527019732952};\\\", \\\"{x:1371,y:571,t:1527019732967};\\\", \\\"{x:1361,y:574,t:1527019732985};\\\", \\\"{x:1346,y:575,t:1527019733001};\\\", \\\"{x:1331,y:580,t:1527019733017};\\\", \\\"{x:1326,y:581,t:1527019733034};\\\", \\\"{x:1319,y:582,t:1527019733051};\\\", \\\"{x:1312,y:583,t:1527019733068};\\\", \\\"{x:1308,y:583,t:1527019733085};\\\", \\\"{x:1305,y:584,t:1527019733102};\\\", \\\"{x:1304,y:584,t:1527019733117};\\\", \\\"{x:1302,y:584,t:1527019733150};\\\", \\\"{x:1301,y:584,t:1527019733183};\\\", \\\"{x:1298,y:584,t:1527019733223};\\\", \\\"{x:1297,y:583,t:1527019733238};\\\", \\\"{x:1297,y:582,t:1527019733252};\\\", \\\"{x:1296,y:582,t:1527019733267};\\\", \\\"{x:1295,y:580,t:1527019733284};\\\", \\\"{x:1294,y:580,t:1527019733375};\\\", \\\"{x:1293,y:580,t:1527019733390};\\\", \\\"{x:1292,y:580,t:1527019733401};\\\", \\\"{x:1290,y:581,t:1527019733418};\\\", \\\"{x:1288,y:583,t:1527019733434};\\\", \\\"{x:1287,y:588,t:1527019733452};\\\", \\\"{x:1285,y:593,t:1527019733467};\\\", \\\"{x:1285,y:595,t:1527019733484};\\\", \\\"{x:1286,y:601,t:1527019733501};\\\", \\\"{x:1291,y:621,t:1527019733517};\\\", \\\"{x:1296,y:638,t:1527019733533};\\\", \\\"{x:1302,y:656,t:1527019733551};\\\", \\\"{x:1306,y:671,t:1527019733568};\\\", \\\"{x:1310,y:686,t:1527019733584};\\\", \\\"{x:1312,y:698,t:1527019733601};\\\", \\\"{x:1314,y:704,t:1527019733618};\\\", \\\"{x:1316,y:712,t:1527019733634};\\\", \\\"{x:1319,y:720,t:1527019733651};\\\", \\\"{x:1320,y:726,t:1527019733668};\\\", \\\"{x:1321,y:730,t:1527019733685};\\\", \\\"{x:1321,y:732,t:1527019733702};\\\", \\\"{x:1322,y:733,t:1527019733718};\\\", \\\"{x:1322,y:735,t:1527019733734};\\\", \\\"{x:1322,y:737,t:1527019733751};\\\", \\\"{x:1322,y:742,t:1527019733769};\\\", \\\"{x:1322,y:745,t:1527019733784};\\\", \\\"{x:1321,y:751,t:1527019733801};\\\", \\\"{x:1319,y:756,t:1527019733818};\\\", \\\"{x:1317,y:762,t:1527019733835};\\\", \\\"{x:1316,y:766,t:1527019733852};\\\", \\\"{x:1315,y:767,t:1527019733869};\\\", \\\"{x:1314,y:769,t:1527019733885};\\\", \\\"{x:1315,y:768,t:1527019733990};\\\", \\\"{x:1315,y:767,t:1527019734002};\\\", \\\"{x:1317,y:765,t:1527019734019};\\\", \\\"{x:1319,y:763,t:1527019734036};\\\", \\\"{x:1321,y:761,t:1527019734052};\\\", \\\"{x:1322,y:760,t:1527019734068};\\\", \\\"{x:1323,y:760,t:1527019734084};\\\", \\\"{x:1326,y:759,t:1527019734101};\\\", \\\"{x:1327,y:759,t:1527019734118};\\\", \\\"{x:1328,y:759,t:1527019734135};\\\", \\\"{x:1329,y:759,t:1527019734150};\\\", \\\"{x:1330,y:759,t:1527019734189};\\\", \\\"{x:1332,y:759,t:1527019734238};\\\", \\\"{x:1334,y:759,t:1527019734261};\\\", \\\"{x:1335,y:759,t:1527019734286};\\\", \\\"{x:1336,y:759,t:1527019734302};\\\", \\\"{x:1341,y:756,t:1527019734318};\\\", \\\"{x:1342,y:755,t:1527019734335};\\\", \\\"{x:1344,y:753,t:1527019734353};\\\", \\\"{x:1346,y:749,t:1527019734369};\\\", \\\"{x:1349,y:743,t:1527019734386};\\\", \\\"{x:1354,y:734,t:1527019734402};\\\", \\\"{x:1354,y:728,t:1527019734419};\\\", \\\"{x:1357,y:721,t:1527019734435};\\\", \\\"{x:1358,y:716,t:1527019734452};\\\", \\\"{x:1361,y:708,t:1527019734469};\\\", \\\"{x:1362,y:701,t:1527019734485};\\\", \\\"{x:1364,y:693,t:1527019734502};\\\", \\\"{x:1366,y:686,t:1527019734518};\\\", \\\"{x:1367,y:683,t:1527019734536};\\\", \\\"{x:1369,y:682,t:1527019734553};\\\", \\\"{x:1370,y:678,t:1527019734569};\\\", \\\"{x:1375,y:670,t:1527019734585};\\\", \\\"{x:1378,y:663,t:1527019734602};\\\", \\\"{x:1383,y:656,t:1527019734619};\\\", \\\"{x:1387,y:651,t:1527019734635};\\\", \\\"{x:1388,y:649,t:1527019734652};\\\", \\\"{x:1390,y:646,t:1527019734668};\\\", \\\"{x:1393,y:642,t:1527019734685};\\\", \\\"{x:1395,y:637,t:1527019734701};\\\", \\\"{x:1397,y:634,t:1527019734719};\\\", \\\"{x:1398,y:632,t:1527019734734};\\\", \\\"{x:1399,y:631,t:1527019734752};\\\", \\\"{x:1399,y:630,t:1527019734769};\\\", \\\"{x:1400,y:629,t:1527019734785};\\\", \\\"{x:1400,y:628,t:1527019734805};\\\", \\\"{x:1401,y:628,t:1527019734829};\\\", \\\"{x:1403,y:627,t:1527019734837};\\\", \\\"{x:1404,y:626,t:1527019734853};\\\", \\\"{x:1404,y:625,t:1527019734869};\\\", \\\"{x:1405,y:624,t:1527019734885};\\\", \\\"{x:1407,y:623,t:1527019734902};\\\", \\\"{x:1408,y:622,t:1527019734926};\\\", \\\"{x:1408,y:621,t:1527019734935};\\\", \\\"{x:1409,y:620,t:1527019734952};\\\", \\\"{x:1410,y:620,t:1527019734969};\\\", \\\"{x:1410,y:618,t:1527019735070};\\\", \\\"{x:1412,y:615,t:1527019735086};\\\", \\\"{x:1412,y:614,t:1527019735102};\\\", \\\"{x:1414,y:610,t:1527019735119};\\\", \\\"{x:1414,y:608,t:1527019735136};\\\", \\\"{x:1417,y:605,t:1527019735153};\\\", \\\"{x:1418,y:602,t:1527019735169};\\\", \\\"{x:1419,y:601,t:1527019735187};\\\", \\\"{x:1419,y:600,t:1527019735214};\\\", \\\"{x:1420,y:599,t:1527019735231};\\\", \\\"{x:1421,y:597,t:1527019735238};\\\", \\\"{x:1421,y:596,t:1527019735252};\\\", \\\"{x:1423,y:592,t:1527019735269};\\\", \\\"{x:1424,y:590,t:1527019735287};\\\", \\\"{x:1424,y:589,t:1527019735303};\\\", \\\"{x:1424,y:587,t:1527019735342};\\\", \\\"{x:1425,y:587,t:1527019735358};\\\", \\\"{x:1423,y:587,t:1527019736357};\\\", \\\"{x:1422,y:588,t:1527019736369};\\\", \\\"{x:1416,y:592,t:1527019736383};\\\", \\\"{x:1411,y:596,t:1527019736401};\\\", \\\"{x:1407,y:600,t:1527019736418};\\\", \\\"{x:1403,y:602,t:1527019736434};\\\", \\\"{x:1400,y:604,t:1527019736451};\\\", \\\"{x:1399,y:605,t:1527019736468};\\\", \\\"{x:1397,y:607,t:1527019736485};\\\", \\\"{x:1395,y:609,t:1527019736501};\\\", \\\"{x:1392,y:612,t:1527019736518};\\\", \\\"{x:1388,y:620,t:1527019736535};\\\", \\\"{x:1385,y:625,t:1527019736551};\\\", \\\"{x:1381,y:632,t:1527019736568};\\\", \\\"{x:1376,y:641,t:1527019736585};\\\", \\\"{x:1373,y:649,t:1527019736601};\\\", \\\"{x:1370,y:654,t:1527019736618};\\\", \\\"{x:1370,y:659,t:1527019736635};\\\", \\\"{x:1368,y:662,t:1527019736652};\\\", \\\"{x:1366,y:666,t:1527019736668};\\\", \\\"{x:1366,y:670,t:1527019736685};\\\", \\\"{x:1365,y:674,t:1527019736701};\\\", \\\"{x:1364,y:677,t:1527019736718};\\\", \\\"{x:1363,y:680,t:1527019736735};\\\", \\\"{x:1363,y:682,t:1527019736751};\\\", \\\"{x:1363,y:684,t:1527019736769};\\\", \\\"{x:1361,y:685,t:1527019736786};\\\", \\\"{x:1361,y:686,t:1527019736801};\\\", \\\"{x:1361,y:687,t:1527019736818};\\\", \\\"{x:1361,y:688,t:1527019736836};\\\", \\\"{x:1360,y:689,t:1527019736852};\\\", \\\"{x:1360,y:692,t:1527019736892};\\\", \\\"{x:1359,y:693,t:1527019736948};\\\", \\\"{x:1358,y:693,t:1527019736956};\\\", \\\"{x:1358,y:694,t:1527019736980};\\\", \\\"{x:1358,y:695,t:1527019736988};\\\", \\\"{x:1357,y:695,t:1527019737004};\\\", \\\"{x:1357,y:696,t:1527019737018};\\\", \\\"{x:1356,y:696,t:1527019737036};\\\", \\\"{x:1355,y:696,t:1527019737052};\\\", \\\"{x:1355,y:698,t:1527019737067};\\\", \\\"{x:1354,y:699,t:1527019737085};\\\", \\\"{x:1353,y:699,t:1527019737101};\\\", \\\"{x:1352,y:699,t:1527019737134};\\\", \\\"{x:1349,y:701,t:1527019737152};\\\", \\\"{x:1348,y:701,t:1527019737168};\\\", \\\"{x:1346,y:701,t:1527019737185};\\\", \\\"{x:1345,y:702,t:1527019738805};\\\", \\\"{x:1325,y:706,t:1527019738820};\\\", \\\"{x:1262,y:706,t:1527019738837};\\\", \\\"{x:1168,y:706,t:1527019738854};\\\", \\\"{x:1070,y:706,t:1527019738871};\\\", \\\"{x:957,y:706,t:1527019738887};\\\", \\\"{x:856,y:710,t:1527019738903};\\\", \\\"{x:773,y:719,t:1527019738920};\\\", \\\"{x:713,y:726,t:1527019738937};\\\", \\\"{x:675,y:732,t:1527019738953};\\\", \\\"{x:633,y:745,t:1527019738971};\\\", \\\"{x:600,y:755,t:1527019738986};\\\", \\\"{x:551,y:765,t:1527019739004};\\\", \\\"{x:525,y:767,t:1527019739020};\\\", \\\"{x:502,y:769,t:1527019739036};\\\", \\\"{x:487,y:769,t:1527019739053};\\\", \\\"{x:477,y:769,t:1527019739070};\\\", \\\"{x:470,y:769,t:1527019739087};\\\", \\\"{x:468,y:769,t:1527019739108};\\\", \\\"{x:468,y:767,t:1527019739124};\\\", \\\"{x:468,y:765,t:1527019739140};\\\", \\\"{x:468,y:763,t:1527019739153};\\\", \\\"{x:467,y:758,t:1527019739170};\\\", \\\"{x:464,y:751,t:1527019739190};\\\", \\\"{x:464,y:749,t:1527019739204};\\\", \\\"{x:464,y:748,t:1527019739227};\\\", \\\"{x:464,y:747,t:1527019739243};\\\", \\\"{x:465,y:744,t:1527019739267};\\\", \\\"{x:466,y:744,t:1527019739275};\\\", \\\"{x:466,y:742,t:1527019739287};\\\", \\\"{x:466,y:741,t:1527019739304};\\\", \\\"{x:468,y:739,t:1527019739651};\\\", \\\"{x:470,y:738,t:1527019739660};\\\", \\\"{x:471,y:737,t:1527019739671};\\\", \\\"{x:477,y:735,t:1527019739687};\\\", \\\"{x:490,y:729,t:1527019739704};\\\", \\\"{x:505,y:723,t:1527019739721};\\\", \\\"{x:523,y:712,t:1527019739737};\\\", \\\"{x:542,y:699,t:1527019739754};\\\", \\\"{x:575,y:670,t:1527019739772};\\\", \\\"{x:607,y:647,t:1527019739787};\\\", \\\"{x:631,y:629,t:1527019739805};\\\", \\\"{x:651,y:614,t:1527019739821};\\\", \\\"{x:663,y:605,t:1527019739837};\\\", \\\"{x:668,y:601,t:1527019739855};\\\", \\\"{x:671,y:598,t:1527019739871};\\\", \\\"{x:673,y:597,t:1527019739887};\\\", \\\"{x:677,y:593,t:1527019739904};\\\", \\\"{x:678,y:592,t:1527019739921};\\\" ] }, { \\\"rt\\\": 31180, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 395484, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -B -B -J -J -I -J -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:663,y:603,t:1527019741228};\\\", \\\"{x:660,y:605,t:1527019741240};\\\", \\\"{x:655,y:607,t:1527019741254};\\\", \\\"{x:649,y:607,t:1527019741272};\\\", \\\"{x:646,y:608,t:1527019741287};\\\", \\\"{x:637,y:610,t:1527019741305};\\\", \\\"{x:630,y:610,t:1527019741322};\\\", \\\"{x:622,y:610,t:1527019741338};\\\", \\\"{x:608,y:610,t:1527019741355};\\\", \\\"{x:604,y:610,t:1527019741372};\\\", \\\"{x:602,y:610,t:1527019741388};\\\", \\\"{x:601,y:610,t:1527019741405};\\\", \\\"{x:600,y:610,t:1527019742612};\\\", \\\"{x:604,y:612,t:1527019743868};\\\", \\\"{x:610,y:615,t:1527019743875};\\\", \\\"{x:619,y:619,t:1527019743891};\\\", \\\"{x:649,y:628,t:1527019743908};\\\", \\\"{x:677,y:636,t:1527019743926};\\\", \\\"{x:738,y:647,t:1527019743957};\\\", \\\"{x:768,y:654,t:1527019743974};\\\", \\\"{x:789,y:656,t:1527019743991};\\\", \\\"{x:801,y:659,t:1527019744007};\\\", \\\"{x:810,y:660,t:1527019744024};\\\", \\\"{x:813,y:661,t:1527019744041};\\\", \\\"{x:815,y:661,t:1527019744091};\\\", \\\"{x:816,y:661,t:1527019744107};\\\", \\\"{x:817,y:661,t:1527019744131};\\\", \\\"{x:817,y:663,t:1527019744756};\\\", \\\"{x:818,y:664,t:1527019744764};\\\", \\\"{x:819,y:665,t:1527019744788};\\\", \\\"{x:820,y:666,t:1527019744804};\\\", \\\"{x:821,y:667,t:1527019744812};\\\", \\\"{x:822,y:667,t:1527019744828};\\\", \\\"{x:823,y:667,t:1527019744842};\\\", \\\"{x:825,y:668,t:1527019744956};\\\", \\\"{x:826,y:668,t:1527019744964};\\\", \\\"{x:828,y:668,t:1527019744976};\\\", \\\"{x:838,y:669,t:1527019744992};\\\", \\\"{x:847,y:670,t:1527019745009};\\\", \\\"{x:861,y:672,t:1527019745025};\\\", \\\"{x:884,y:677,t:1527019745043};\\\", \\\"{x:912,y:684,t:1527019745059};\\\", \\\"{x:971,y:700,t:1527019745076};\\\", \\\"{x:1028,y:711,t:1527019745093};\\\", \\\"{x:1071,y:719,t:1527019745108};\\\", \\\"{x:1121,y:726,t:1527019745126};\\\", \\\"{x:1156,y:732,t:1527019745142};\\\", \\\"{x:1182,y:736,t:1527019745158};\\\", \\\"{x:1199,y:741,t:1527019745175};\\\", \\\"{x:1205,y:741,t:1527019745192};\\\", \\\"{x:1207,y:741,t:1527019745209};\\\", \\\"{x:1207,y:742,t:1527019745548};\\\", \\\"{x:1208,y:742,t:1527019745620};\\\", \\\"{x:1210,y:742,t:1527019745643};\\\", \\\"{x:1215,y:742,t:1527019745659};\\\", \\\"{x:1221,y:742,t:1527019745676};\\\", \\\"{x:1232,y:745,t:1527019745693};\\\", \\\"{x:1242,y:746,t:1527019745710};\\\", \\\"{x:1250,y:746,t:1527019745727};\\\", \\\"{x:1258,y:747,t:1527019745743};\\\", \\\"{x:1263,y:749,t:1527019745760};\\\", \\\"{x:1266,y:749,t:1527019745777};\\\", \\\"{x:1272,y:749,t:1527019745793};\\\", \\\"{x:1279,y:749,t:1527019745809};\\\", \\\"{x:1291,y:751,t:1527019745827};\\\", \\\"{x:1318,y:755,t:1527019745844};\\\", \\\"{x:1334,y:757,t:1527019745860};\\\", \\\"{x:1350,y:761,t:1527019745878};\\\", \\\"{x:1361,y:763,t:1527019745894};\\\", \\\"{x:1369,y:763,t:1527019745909};\\\", \\\"{x:1374,y:766,t:1527019745926};\\\", \\\"{x:1379,y:766,t:1527019745943};\\\", \\\"{x:1381,y:766,t:1527019745959};\\\", \\\"{x:1383,y:768,t:1527019745976};\\\", \\\"{x:1383,y:770,t:1527019746123};\\\", \\\"{x:1383,y:771,t:1527019746131};\\\", \\\"{x:1383,y:772,t:1527019746155};\\\", \\\"{x:1383,y:773,t:1527019746163};\\\", \\\"{x:1383,y:774,t:1527019746176};\\\", \\\"{x:1383,y:775,t:1527019746193};\\\", \\\"{x:1383,y:776,t:1527019746210};\\\", \\\"{x:1383,y:777,t:1527019746226};\\\", \\\"{x:1383,y:780,t:1527019746244};\\\", \\\"{x:1384,y:782,t:1527019746261};\\\", \\\"{x:1391,y:785,t:1527019746276};\\\", \\\"{x:1393,y:785,t:1527019746293};\\\", \\\"{x:1398,y:786,t:1527019746310};\\\", \\\"{x:1403,y:788,t:1527019746326};\\\", \\\"{x:1416,y:789,t:1527019746343};\\\", \\\"{x:1420,y:792,t:1527019746360};\\\", \\\"{x:1433,y:792,t:1527019746377};\\\", \\\"{x:1447,y:793,t:1527019746393};\\\", \\\"{x:1456,y:793,t:1527019746410};\\\", \\\"{x:1471,y:795,t:1527019746427};\\\", \\\"{x:1480,y:798,t:1527019746443};\\\", \\\"{x:1490,y:805,t:1527019746460};\\\", \\\"{x:1494,y:811,t:1527019746477};\\\", \\\"{x:1502,y:815,t:1527019746493};\\\", \\\"{x:1506,y:818,t:1527019746510};\\\", \\\"{x:1507,y:819,t:1527019746644};\\\", \\\"{x:1509,y:819,t:1527019746661};\\\", \\\"{x:1513,y:819,t:1527019746678};\\\", \\\"{x:1527,y:819,t:1527019746694};\\\", \\\"{x:1542,y:820,t:1527019746711};\\\", \\\"{x:1561,y:824,t:1527019746728};\\\", \\\"{x:1585,y:827,t:1527019746745};\\\", \\\"{x:1599,y:831,t:1527019746761};\\\", \\\"{x:1607,y:834,t:1527019746778};\\\", \\\"{x:1609,y:835,t:1527019746793};\\\", \\\"{x:1610,y:835,t:1527019746835};\\\", \\\"{x:1610,y:836,t:1527019746869};\\\", \\\"{x:1611,y:837,t:1527019746900};\\\", \\\"{x:1613,y:835,t:1527019746989};\\\", \\\"{x:1613,y:833,t:1527019746996};\\\", \\\"{x:1613,y:829,t:1527019747011};\\\", \\\"{x:1606,y:815,t:1527019747028};\\\", \\\"{x:1596,y:804,t:1527019747045};\\\", \\\"{x:1585,y:791,t:1527019747062};\\\", \\\"{x:1570,y:778,t:1527019747078};\\\", \\\"{x:1561,y:769,t:1527019747095};\\\", \\\"{x:1555,y:760,t:1527019747111};\\\", \\\"{x:1552,y:750,t:1527019747128};\\\", \\\"{x:1550,y:742,t:1527019747145};\\\", \\\"{x:1547,y:733,t:1527019747162};\\\", \\\"{x:1543,y:726,t:1527019747177};\\\", \\\"{x:1539,y:719,t:1527019747195};\\\", \\\"{x:1536,y:715,t:1527019747211};\\\", \\\"{x:1534,y:712,t:1527019747228};\\\", \\\"{x:1533,y:711,t:1527019747244};\\\", \\\"{x:1531,y:710,t:1527019747262};\\\", \\\"{x:1530,y:709,t:1527019747283};\\\", \\\"{x:1529,y:709,t:1527019747294};\\\", \\\"{x:1526,y:708,t:1527019747311};\\\", \\\"{x:1519,y:708,t:1527019747327};\\\", \\\"{x:1508,y:708,t:1527019747344};\\\", \\\"{x:1496,y:708,t:1527019747362};\\\", \\\"{x:1483,y:708,t:1527019747378};\\\", \\\"{x:1469,y:708,t:1527019747395};\\\", \\\"{x:1444,y:715,t:1527019747411};\\\", \\\"{x:1424,y:721,t:1527019747429};\\\", \\\"{x:1404,y:729,t:1527019747445};\\\", \\\"{x:1390,y:734,t:1527019747462};\\\", \\\"{x:1374,y:739,t:1527019747479};\\\", \\\"{x:1362,y:742,t:1527019747495};\\\", \\\"{x:1352,y:745,t:1527019747512};\\\", \\\"{x:1346,y:748,t:1527019747529};\\\", \\\"{x:1338,y:752,t:1527019747545};\\\", \\\"{x:1333,y:755,t:1527019747561};\\\", \\\"{x:1330,y:756,t:1527019747578};\\\", \\\"{x:1326,y:760,t:1527019747595};\\\", \\\"{x:1322,y:762,t:1527019747612};\\\", \\\"{x:1320,y:763,t:1527019747629};\\\", \\\"{x:1319,y:764,t:1527019747645};\\\", \\\"{x:1319,y:765,t:1527019747684};\\\", \\\"{x:1319,y:767,t:1527019747708};\\\", \\\"{x:1319,y:768,t:1527019747748};\\\", \\\"{x:1318,y:768,t:1527019747762};\\\", \\\"{x:1318,y:770,t:1527019747788};\\\", \\\"{x:1320,y:771,t:1527019747805};\\\", \\\"{x:1323,y:771,t:1527019747812};\\\", \\\"{x:1327,y:772,t:1527019747829};\\\", \\\"{x:1333,y:772,t:1527019747846};\\\", \\\"{x:1336,y:772,t:1527019747861};\\\", \\\"{x:1338,y:772,t:1527019747878};\\\", \\\"{x:1340,y:772,t:1527019747896};\\\", \\\"{x:1341,y:772,t:1527019747916};\\\", \\\"{x:1342,y:771,t:1527019747929};\\\", \\\"{x:1343,y:770,t:1527019747946};\\\", \\\"{x:1344,y:769,t:1527019747962};\\\", \\\"{x:1345,y:766,t:1527019747980};\\\", \\\"{x:1347,y:765,t:1527019748012};\\\", \\\"{x:1349,y:768,t:1527019752596};\\\", \\\"{x:1350,y:770,t:1527019752604};\\\", \\\"{x:1350,y:771,t:1527019752617};\\\", \\\"{x:1352,y:774,t:1527019752633};\\\", \\\"{x:1352,y:775,t:1527019752650};\\\", \\\"{x:1353,y:776,t:1527019752876};\\\", \\\"{x:1354,y:777,t:1527019752884};\\\", \\\"{x:1355,y:778,t:1527019752902};\\\", \\\"{x:1355,y:779,t:1527019752919};\\\", \\\"{x:1356,y:781,t:1527019752934};\\\", \\\"{x:1357,y:783,t:1527019752951};\\\", \\\"{x:1358,y:784,t:1527019752968};\\\", \\\"{x:1358,y:787,t:1527019752984};\\\", \\\"{x:1359,y:789,t:1527019753001};\\\", \\\"{x:1361,y:792,t:1527019753019};\\\", \\\"{x:1363,y:795,t:1527019753035};\\\", \\\"{x:1364,y:798,t:1527019753051};\\\", \\\"{x:1365,y:798,t:1527019753068};\\\", \\\"{x:1365,y:800,t:1527019753085};\\\", \\\"{x:1366,y:802,t:1527019753102};\\\", \\\"{x:1369,y:808,t:1527019753118};\\\", \\\"{x:1373,y:813,t:1527019753135};\\\", \\\"{x:1373,y:817,t:1527019753151};\\\", \\\"{x:1375,y:820,t:1527019753168};\\\", \\\"{x:1376,y:823,t:1527019753185};\\\", \\\"{x:1377,y:824,t:1527019753201};\\\", \\\"{x:1377,y:825,t:1527019753218};\\\", \\\"{x:1379,y:828,t:1527019753235};\\\", \\\"{x:1380,y:831,t:1527019753251};\\\", \\\"{x:1380,y:832,t:1527019753269};\\\", \\\"{x:1380,y:833,t:1527019753292};\\\", \\\"{x:1380,y:834,t:1527019753302};\\\", \\\"{x:1381,y:835,t:1527019753318};\\\", \\\"{x:1382,y:837,t:1527019753335};\\\", \\\"{x:1383,y:839,t:1527019753352};\\\", \\\"{x:1384,y:842,t:1527019753369};\\\", \\\"{x:1384,y:843,t:1527019753385};\\\", \\\"{x:1386,y:845,t:1527019753402};\\\", \\\"{x:1386,y:849,t:1527019753418};\\\", \\\"{x:1389,y:854,t:1527019753435};\\\", \\\"{x:1390,y:855,t:1527019753452};\\\", \\\"{x:1390,y:857,t:1527019753468};\\\", \\\"{x:1391,y:858,t:1527019753485};\\\", \\\"{x:1391,y:859,t:1527019753502};\\\", \\\"{x:1393,y:862,t:1527019753518};\\\", \\\"{x:1393,y:863,t:1527019753535};\\\", \\\"{x:1393,y:864,t:1527019753552};\\\", \\\"{x:1393,y:866,t:1527019753569};\\\", \\\"{x:1394,y:866,t:1527019753585};\\\", \\\"{x:1394,y:868,t:1527019753602};\\\", \\\"{x:1394,y:869,t:1527019753619};\\\", \\\"{x:1394,y:868,t:1527019753764};\\\", \\\"{x:1394,y:863,t:1527019753771};\\\", \\\"{x:1394,y:857,t:1527019753785};\\\", \\\"{x:1394,y:846,t:1527019753803};\\\", \\\"{x:1391,y:836,t:1527019753819};\\\", \\\"{x:1385,y:822,t:1527019753835};\\\", \\\"{x:1382,y:814,t:1527019753851};\\\", \\\"{x:1380,y:808,t:1527019753871};\\\", \\\"{x:1379,y:806,t:1527019753884};\\\", \\\"{x:1375,y:797,t:1527019753901};\\\", \\\"{x:1367,y:783,t:1527019753918};\\\", \\\"{x:1363,y:776,t:1527019753936};\\\", \\\"{x:1360,y:771,t:1527019753952};\\\", \\\"{x:1356,y:763,t:1527019753969};\\\", \\\"{x:1353,y:757,t:1527019753986};\\\", \\\"{x:1350,y:754,t:1527019754001};\\\", \\\"{x:1348,y:751,t:1527019754019};\\\", \\\"{x:1347,y:750,t:1527019754035};\\\", \\\"{x:1346,y:749,t:1527019754051};\\\", \\\"{x:1345,y:749,t:1527019754075};\\\", \\\"{x:1344,y:748,t:1527019754164};\\\", \\\"{x:1343,y:748,t:1527019754203};\\\", \\\"{x:1342,y:748,t:1527019754219};\\\", \\\"{x:1341,y:751,t:1527019754236};\\\", \\\"{x:1341,y:753,t:1527019754253};\\\", \\\"{x:1341,y:754,t:1527019754269};\\\", \\\"{x:1341,y:755,t:1527019754292};\\\", \\\"{x:1341,y:756,t:1527019754315};\\\", \\\"{x:1340,y:757,t:1527019754434};\\\", \\\"{x:1340,y:758,t:1527019754613};\\\", \\\"{x:1340,y:759,t:1527019754661};\\\", \\\"{x:1340,y:760,t:1527019754670};\\\", \\\"{x:1340,y:761,t:1527019754740};\\\", \\\"{x:1340,y:762,t:1527019755404};\\\", \\\"{x:1342,y:763,t:1527019755420};\\\", \\\"{x:1346,y:764,t:1527019755437};\\\", \\\"{x:1349,y:764,t:1527019755454};\\\", \\\"{x:1354,y:765,t:1527019755471};\\\", \\\"{x:1355,y:765,t:1527019755490};\\\", \\\"{x:1356,y:765,t:1527019755504};\\\", \\\"{x:1357,y:766,t:1527019755571};\\\", \\\"{x:1356,y:766,t:1527019755707};\\\", \\\"{x:1354,y:767,t:1527019755720};\\\", \\\"{x:1350,y:767,t:1527019755736};\\\", \\\"{x:1343,y:767,t:1527019755754};\\\", \\\"{x:1342,y:768,t:1527019755771};\\\", \\\"{x:1341,y:768,t:1527019755826};\\\", \\\"{x:1341,y:767,t:1527019755867};\\\", \\\"{x:1342,y:766,t:1527019755882};\\\", \\\"{x:1342,y:765,t:1527019755890};\\\", \\\"{x:1343,y:765,t:1527019755904};\\\", \\\"{x:1345,y:763,t:1527019755920};\\\", \\\"{x:1347,y:763,t:1527019755937};\\\", \\\"{x:1348,y:763,t:1527019755953};\\\", \\\"{x:1349,y:762,t:1527019755971};\\\", \\\"{x:1348,y:762,t:1527019757852};\\\", \\\"{x:1346,y:762,t:1527019757859};\\\", \\\"{x:1344,y:762,t:1527019757873};\\\", \\\"{x:1340,y:764,t:1527019757891};\\\", \\\"{x:1336,y:765,t:1527019757906};\\\", \\\"{x:1330,y:767,t:1527019757923};\\\", \\\"{x:1328,y:768,t:1527019757940};\\\", \\\"{x:1326,y:769,t:1527019757957};\\\", \\\"{x:1322,y:770,t:1527019757973};\\\", \\\"{x:1319,y:771,t:1527019757990};\\\", \\\"{x:1313,y:772,t:1527019758008};\\\", \\\"{x:1306,y:775,t:1527019758023};\\\", \\\"{x:1294,y:777,t:1527019758041};\\\", \\\"{x:1284,y:780,t:1527019758057};\\\", \\\"{x:1274,y:784,t:1527019758074};\\\", \\\"{x:1268,y:785,t:1527019758090};\\\", \\\"{x:1259,y:789,t:1527019758108};\\\", \\\"{x:1250,y:794,t:1527019758124};\\\", \\\"{x:1231,y:802,t:1527019758140};\\\", \\\"{x:1215,y:806,t:1527019758157};\\\", \\\"{x:1206,y:810,t:1527019758173};\\\", \\\"{x:1202,y:812,t:1527019758190};\\\", \\\"{x:1202,y:813,t:1527019758228};\\\", \\\"{x:1202,y:814,t:1527019758260};\\\", \\\"{x:1202,y:815,t:1527019758274};\\\", \\\"{x:1200,y:817,t:1527019758292};\\\", \\\"{x:1200,y:818,t:1527019758469};\\\", \\\"{x:1200,y:819,t:1527019758476};\\\", \\\"{x:1200,y:820,t:1527019758490};\\\", \\\"{x:1203,y:823,t:1527019758506};\\\", \\\"{x:1206,y:827,t:1527019758523};\\\", \\\"{x:1207,y:828,t:1527019758540};\\\", \\\"{x:1207,y:829,t:1527019758557};\\\", \\\"{x:1207,y:830,t:1527019760284};\\\", \\\"{x:1208,y:830,t:1527019760603};\\\", \\\"{x:1209,y:830,t:1527019761877};\\\", \\\"{x:1210,y:829,t:1527019761894};\\\", \\\"{x:1211,y:828,t:1527019763164};\\\", \\\"{x:1211,y:827,t:1527019763211};\\\", \\\"{x:1211,y:826,t:1527019763229};\\\", \\\"{x:1212,y:824,t:1527019763260};\\\", \\\"{x:1213,y:823,t:1527019763284};\\\", \\\"{x:1213,y:821,t:1527019763572};\\\", \\\"{x:1213,y:820,t:1527019763579};\\\", \\\"{x:1213,y:811,t:1527019763596};\\\", \\\"{x:1207,y:798,t:1527019763613};\\\", \\\"{x:1204,y:788,t:1527019763629};\\\", \\\"{x:1201,y:780,t:1527019763647};\\\", \\\"{x:1197,y:774,t:1527019763663};\\\", \\\"{x:1195,y:772,t:1527019763679};\\\", \\\"{x:1194,y:770,t:1527019763696};\\\", \\\"{x:1193,y:769,t:1527019763713};\\\", \\\"{x:1192,y:769,t:1527019763764};\\\", \\\"{x:1191,y:768,t:1527019763780};\\\", \\\"{x:1190,y:767,t:1527019763796};\\\", \\\"{x:1188,y:766,t:1527019763814};\\\", \\\"{x:1187,y:765,t:1527019763843};\\\", \\\"{x:1186,y:765,t:1527019763908};\\\", \\\"{x:1186,y:767,t:1527019764220};\\\", \\\"{x:1186,y:769,t:1527019764230};\\\", \\\"{x:1186,y:770,t:1527019764247};\\\", \\\"{x:1186,y:771,t:1527019764264};\\\", \\\"{x:1187,y:772,t:1527019764292};\\\", \\\"{x:1187,y:773,t:1527019764308};\\\", \\\"{x:1187,y:774,t:1527019764315};\\\", \\\"{x:1188,y:776,t:1527019764332};\\\", \\\"{x:1190,y:779,t:1527019764348};\\\", \\\"{x:1194,y:784,t:1527019764363};\\\", \\\"{x:1197,y:790,t:1527019764381};\\\", \\\"{x:1199,y:796,t:1527019764397};\\\", \\\"{x:1203,y:802,t:1527019764414};\\\", \\\"{x:1210,y:812,t:1527019764431};\\\", \\\"{x:1214,y:818,t:1527019764447};\\\", \\\"{x:1220,y:827,t:1527019764464};\\\", \\\"{x:1226,y:836,t:1527019764480};\\\", \\\"{x:1227,y:838,t:1527019764497};\\\", \\\"{x:1229,y:839,t:1527019764512};\\\", \\\"{x:1230,y:839,t:1527019764659};\\\", \\\"{x:1230,y:838,t:1527019764669};\\\", \\\"{x:1231,y:837,t:1527019764680};\\\", \\\"{x:1234,y:831,t:1527019764697};\\\", \\\"{x:1238,y:826,t:1527019764714};\\\", \\\"{x:1241,y:823,t:1527019764730};\\\", \\\"{x:1244,y:817,t:1527019764746};\\\", \\\"{x:1244,y:812,t:1527019764763};\\\", \\\"{x:1244,y:808,t:1527019764780};\\\", \\\"{x:1245,y:805,t:1527019764797};\\\", \\\"{x:1245,y:803,t:1527019764814};\\\", \\\"{x:1247,y:799,t:1527019764831};\\\", \\\"{x:1247,y:795,t:1527019764847};\\\", \\\"{x:1248,y:791,t:1527019764864};\\\", \\\"{x:1252,y:781,t:1527019764881};\\\", \\\"{x:1256,y:768,t:1527019764896};\\\", \\\"{x:1257,y:762,t:1527019764914};\\\", \\\"{x:1258,y:756,t:1527019764930};\\\", \\\"{x:1260,y:752,t:1527019764946};\\\", \\\"{x:1260,y:751,t:1527019764987};\\\", \\\"{x:1260,y:749,t:1527019764997};\\\", \\\"{x:1260,y:748,t:1527019765019};\\\", \\\"{x:1261,y:748,t:1527019765035};\\\", \\\"{x:1261,y:747,t:1527019765047};\\\", \\\"{x:1263,y:744,t:1527019765064};\\\", \\\"{x:1267,y:738,t:1527019765081};\\\", \\\"{x:1268,y:735,t:1527019765097};\\\", \\\"{x:1270,y:732,t:1527019765114};\\\", \\\"{x:1274,y:725,t:1527019765131};\\\", \\\"{x:1276,y:720,t:1527019765148};\\\", \\\"{x:1277,y:715,t:1527019765164};\\\", \\\"{x:1278,y:711,t:1527019765181};\\\", \\\"{x:1280,y:703,t:1527019765198};\\\", \\\"{x:1280,y:696,t:1527019765214};\\\", \\\"{x:1281,y:693,t:1527019765231};\\\", \\\"{x:1282,y:687,t:1527019765248};\\\", \\\"{x:1282,y:684,t:1527019765264};\\\", \\\"{x:1283,y:681,t:1527019765281};\\\", \\\"{x:1283,y:678,t:1527019765298};\\\", \\\"{x:1284,y:675,t:1527019765314};\\\", \\\"{x:1288,y:663,t:1527019765331};\\\", \\\"{x:1291,y:657,t:1527019765348};\\\", \\\"{x:1295,y:647,t:1527019765364};\\\", \\\"{x:1299,y:638,t:1527019765382};\\\", \\\"{x:1301,y:630,t:1527019765399};\\\", \\\"{x:1304,y:621,t:1527019765415};\\\", \\\"{x:1305,y:613,t:1527019765432};\\\", \\\"{x:1305,y:610,t:1527019765448};\\\", \\\"{x:1305,y:609,t:1527019765465};\\\", \\\"{x:1305,y:607,t:1527019765481};\\\", \\\"{x:1305,y:606,t:1527019765516};\\\", \\\"{x:1305,y:605,t:1527019765539};\\\", \\\"{x:1305,y:604,t:1527019765563};\\\", \\\"{x:1304,y:603,t:1527019765572};\\\", \\\"{x:1302,y:601,t:1527019765588};\\\", \\\"{x:1301,y:599,t:1527019765598};\\\", \\\"{x:1296,y:596,t:1527019765615};\\\", \\\"{x:1290,y:593,t:1527019765631};\\\", \\\"{x:1286,y:587,t:1527019765648};\\\", \\\"{x:1283,y:583,t:1527019765665};\\\", \\\"{x:1281,y:579,t:1527019765682};\\\", \\\"{x:1280,y:576,t:1527019765698};\\\", \\\"{x:1280,y:573,t:1527019765716};\\\", \\\"{x:1278,y:570,t:1527019765732};\\\", \\\"{x:1278,y:568,t:1527019765749};\\\", \\\"{x:1278,y:567,t:1527019765766};\\\", \\\"{x:1278,y:566,t:1527019765891};\\\", \\\"{x:1278,y:565,t:1527019765899};\\\", \\\"{x:1278,y:564,t:1527019765915};\\\", \\\"{x:1278,y:566,t:1527019766069};\\\", \\\"{x:1278,y:570,t:1527019766083};\\\", \\\"{x:1278,y:574,t:1527019766099};\\\", \\\"{x:1278,y:579,t:1527019766115};\\\", \\\"{x:1279,y:585,t:1527019766133};\\\", \\\"{x:1280,y:588,t:1527019766149};\\\", \\\"{x:1280,y:591,t:1527019766166};\\\", \\\"{x:1281,y:595,t:1527019766182};\\\", \\\"{x:1281,y:598,t:1527019766199};\\\", \\\"{x:1282,y:601,t:1527019766215};\\\", \\\"{x:1282,y:602,t:1527019766232};\\\", \\\"{x:1285,y:605,t:1527019766249};\\\", \\\"{x:1285,y:606,t:1527019766266};\\\", \\\"{x:1286,y:609,t:1527019766283};\\\", \\\"{x:1287,y:611,t:1527019766300};\\\", \\\"{x:1287,y:612,t:1527019766316};\\\", \\\"{x:1289,y:614,t:1527019766332};\\\", \\\"{x:1289,y:615,t:1527019766355};\\\", \\\"{x:1290,y:616,t:1527019766366};\\\", \\\"{x:1291,y:618,t:1527019766387};\\\", \\\"{x:1292,y:618,t:1527019766399};\\\", \\\"{x:1294,y:622,t:1527019766416};\\\", \\\"{x:1296,y:623,t:1527019766432};\\\", \\\"{x:1298,y:626,t:1527019766449};\\\", \\\"{x:1301,y:629,t:1527019766470};\\\", \\\"{x:1302,y:630,t:1527019766482};\\\", \\\"{x:1304,y:631,t:1527019766498};\\\", \\\"{x:1306,y:633,t:1527019766516};\\\", \\\"{x:1306,y:635,t:1527019766532};\\\", \\\"{x:1307,y:636,t:1527019766549};\\\", \\\"{x:1309,y:639,t:1527019766566};\\\", \\\"{x:1311,y:642,t:1527019766582};\\\", \\\"{x:1313,y:644,t:1527019766599};\\\", \\\"{x:1313,y:645,t:1527019766616};\\\", \\\"{x:1316,y:649,t:1527019766632};\\\", \\\"{x:1316,y:650,t:1527019766659};\\\", \\\"{x:1317,y:650,t:1527019766668};\\\", \\\"{x:1317,y:651,t:1527019766682};\\\", \\\"{x:1319,y:653,t:1527019766700};\\\", \\\"{x:1319,y:655,t:1527019766717};\\\", \\\"{x:1319,y:656,t:1527019766732};\\\", \\\"{x:1321,y:658,t:1527019766749};\\\", \\\"{x:1321,y:660,t:1527019766766};\\\", \\\"{x:1323,y:662,t:1527019766784};\\\", \\\"{x:1324,y:664,t:1527019766799};\\\", \\\"{x:1325,y:665,t:1527019766816};\\\", \\\"{x:1326,y:668,t:1527019766833};\\\", \\\"{x:1328,y:671,t:1527019766849};\\\", \\\"{x:1332,y:679,t:1527019766867};\\\", \\\"{x:1337,y:687,t:1527019766883};\\\", \\\"{x:1340,y:693,t:1527019766899};\\\", \\\"{x:1346,y:703,t:1527019766916};\\\", \\\"{x:1352,y:708,t:1527019766933};\\\", \\\"{x:1355,y:712,t:1527019766949};\\\", \\\"{x:1355,y:713,t:1527019766967};\\\", \\\"{x:1356,y:714,t:1527019766983};\\\", \\\"{x:1356,y:715,t:1527019767004};\\\", \\\"{x:1357,y:716,t:1527019767163};\\\", \\\"{x:1358,y:717,t:1527019767179};\\\", \\\"{x:1358,y:718,t:1527019767195};\\\", \\\"{x:1358,y:719,t:1527019767203};\\\", \\\"{x:1358,y:720,t:1527019767227};\\\", \\\"{x:1359,y:721,t:1527019767243};\\\", \\\"{x:1359,y:722,t:1527019767275};\\\", \\\"{x:1360,y:723,t:1527019767324};\\\", \\\"{x:1361,y:725,t:1527019767356};\\\", \\\"{x:1362,y:726,t:1527019767372};\\\", \\\"{x:1362,y:727,t:1527019767387};\\\", \\\"{x:1363,y:727,t:1527019767412};\\\", \\\"{x:1363,y:728,t:1527019767443};\\\", \\\"{x:1363,y:729,t:1527019767492};\\\", \\\"{x:1363,y:730,t:1527019767524};\\\", \\\"{x:1364,y:730,t:1527019767533};\\\", \\\"{x:1364,y:731,t:1527019767588};\\\", \\\"{x:1365,y:731,t:1527019767601};\\\", \\\"{x:1365,y:732,t:1527019767618};\\\", \\\"{x:1366,y:732,t:1527019767634};\\\", \\\"{x:1366,y:733,t:1527019767724};\\\", \\\"{x:1352,y:733,t:1527019770316};\\\", \\\"{x:1327,y:733,t:1527019770323};\\\", \\\"{x:1281,y:728,t:1527019770337};\\\", \\\"{x:1165,y:712,t:1527019770354};\\\", \\\"{x:1025,y:686,t:1527019770371};\\\", \\\"{x:901,y:655,t:1527019770387};\\\", \\\"{x:767,y:612,t:1527019770405};\\\", \\\"{x:702,y:588,t:1527019770420};\\\", \\\"{x:673,y:575,t:1527019770435};\\\", \\\"{x:652,y:567,t:1527019770455};\\\", \\\"{x:633,y:558,t:1527019770472};\\\", \\\"{x:608,y:552,t:1527019770489};\\\", \\\"{x:585,y:542,t:1527019770512};\\\", \\\"{x:577,y:538,t:1527019770529};\\\", \\\"{x:568,y:536,t:1527019770545};\\\", \\\"{x:567,y:536,t:1527019770562};\\\", \\\"{x:566,y:535,t:1527019770626};\\\", \\\"{x:567,y:533,t:1527019770642};\\\", \\\"{x:572,y:530,t:1527019770650};\\\", \\\"{x:578,y:527,t:1527019770662};\\\", \\\"{x:589,y:520,t:1527019770679};\\\", \\\"{x:596,y:516,t:1527019770696};\\\", \\\"{x:600,y:514,t:1527019770713};\\\", \\\"{x:603,y:512,t:1527019770729};\\\", \\\"{x:604,y:511,t:1527019770745};\\\", \\\"{x:608,y:508,t:1527019770762};\\\", \\\"{x:613,y:505,t:1527019770779};\\\", \\\"{x:614,y:504,t:1527019770796};\\\", \\\"{x:618,y:501,t:1527019770812};\\\", \\\"{x:621,y:499,t:1527019770830};\\\", \\\"{x:622,y:495,t:1527019770846};\\\", \\\"{x:623,y:494,t:1527019770862};\\\", \\\"{x:623,y:493,t:1527019770879};\\\", \\\"{x:623,y:492,t:1527019770896};\\\", \\\"{x:622,y:492,t:1527019771114};\\\", \\\"{x:622,y:493,t:1527019771129};\\\", \\\"{x:621,y:494,t:1527019771146};\\\", \\\"{x:621,y:495,t:1527019771163};\\\", \\\"{x:621,y:497,t:1527019771179};\\\", \\\"{x:619,y:499,t:1527019771196};\\\", \\\"{x:617,y:501,t:1527019771213};\\\", \\\"{x:616,y:506,t:1527019771229};\\\", \\\"{x:612,y:514,t:1527019771246};\\\", \\\"{x:607,y:529,t:1527019771264};\\\", \\\"{x:598,y:555,t:1527019771279};\\\", \\\"{x:590,y:574,t:1527019771296};\\\", \\\"{x:569,y:624,t:1527019771313};\\\", \\\"{x:552,y:662,t:1527019771330};\\\", \\\"{x:539,y:683,t:1527019771346};\\\", \\\"{x:531,y:705,t:1527019771362};\\\", \\\"{x:526,y:713,t:1527019771381};\\\", \\\"{x:525,y:715,t:1527019771396};\\\", \\\"{x:524,y:716,t:1527019771413};\\\", \\\"{x:524,y:717,t:1527019771580};\\\", \\\"{x:524,y:724,t:1527019771600};\\\", \\\"{x:524,y:731,t:1527019771614};\\\", \\\"{x:524,y:733,t:1527019771629};\\\", \\\"{x:524,y:734,t:1527019772059};\\\", \\\"{x:525,y:734,t:1527019772067};\\\", \\\"{x:526,y:734,t:1527019772080};\\\", \\\"{x:539,y:732,t:1527019772097};\\\", \\\"{x:556,y:728,t:1527019772113};\\\", \\\"{x:581,y:724,t:1527019772129};\\\", \\\"{x:624,y:720,t:1527019772147};\\\", \\\"{x:663,y:718,t:1527019772163};\\\", \\\"{x:688,y:717,t:1527019772180};\\\", \\\"{x:705,y:717,t:1527019772197};\\\", \\\"{x:709,y:717,t:1527019772213};\\\", \\\"{x:711,y:717,t:1527019772275};\\\", \\\"{x:715,y:717,t:1527019772283};\\\", \\\"{x:718,y:720,t:1527019772298};\\\", \\\"{x:732,y:721,t:1527019772315};\\\" ] }, { \\\"rt\\\": 12892, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 409597, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:731,y:721,t:1527019773250};\\\", \\\"{x:731,y:720,t:1527019773274};\\\", \\\"{x:731,y:719,t:1527019773323};\\\", \\\"{x:731,y:718,t:1527019773354};\\\", \\\"{x:729,y:716,t:1527019773364};\\\", \\\"{x:726,y:716,t:1527019773381};\\\", \\\"{x:720,y:715,t:1527019773398};\\\", \\\"{x:712,y:713,t:1527019773414};\\\", \\\"{x:695,y:711,t:1527019773431};\\\", \\\"{x:676,y:708,t:1527019773448};\\\", \\\"{x:632,y:702,t:1527019773514};\\\", \\\"{x:631,y:702,t:1527019773602};\\\", \\\"{x:630,y:702,t:1527019773618};\\\", \\\"{x:629,y:702,t:1527019773631};\\\", \\\"{x:626,y:702,t:1527019773648};\\\", \\\"{x:622,y:702,t:1527019773665};\\\", \\\"{x:617,y:701,t:1527019773681};\\\", \\\"{x:609,y:699,t:1527019773698};\\\", \\\"{x:605,y:699,t:1527019773714};\\\", \\\"{x:605,y:698,t:1527019773731};\\\", \\\"{x:607,y:698,t:1527019773875};\\\", \\\"{x:610,y:699,t:1527019773883};\\\", \\\"{x:618,y:700,t:1527019773898};\\\", \\\"{x:626,y:702,t:1527019773915};\\\", \\\"{x:634,y:704,t:1527019773931};\\\", \\\"{x:650,y:710,t:1527019773948};\\\", \\\"{x:663,y:715,t:1527019773965};\\\", \\\"{x:679,y:723,t:1527019773981};\\\", \\\"{x:686,y:728,t:1527019773999};\\\", \\\"{x:694,y:730,t:1527019774015};\\\", \\\"{x:698,y:732,t:1527019774031};\\\", \\\"{x:699,y:732,t:1527019774049};\\\", \\\"{x:699,y:733,t:1527019774292};\\\", \\\"{x:698,y:733,t:1527019778499};\\\", \\\"{x:697,y:733,t:1527019778507};\\\", \\\"{x:696,y:733,t:1527019778519};\\\", \\\"{x:694,y:733,t:1527019778535};\\\", \\\"{x:688,y:733,t:1527019778552};\\\", \\\"{x:685,y:733,t:1527019778569};\\\", \\\"{x:683,y:733,t:1527019778585};\\\", \\\"{x:682,y:733,t:1527019778602};\\\", \\\"{x:685,y:733,t:1527019778675};\\\", \\\"{x:690,y:731,t:1527019778685};\\\", \\\"{x:705,y:731,t:1527019778702};\\\", \\\"{x:727,y:731,t:1527019778719};\\\", \\\"{x:754,y:731,t:1527019778736};\\\", \\\"{x:792,y:732,t:1527019778753};\\\", \\\"{x:870,y:734,t:1527019778769};\\\", \\\"{x:950,y:742,t:1527019778785};\\\", \\\"{x:1036,y:751,t:1527019778802};\\\", \\\"{x:1168,y:770,t:1527019778819};\\\", \\\"{x:1248,y:781,t:1527019778836};\\\", \\\"{x:1314,y:788,t:1527019778853};\\\", \\\"{x:1370,y:794,t:1527019778869};\\\", \\\"{x:1410,y:801,t:1527019778886};\\\", \\\"{x:1422,y:803,t:1527019778903};\\\", \\\"{x:1423,y:803,t:1527019778919};\\\", \\\"{x:1425,y:803,t:1527019778936};\\\", \\\"{x:1427,y:804,t:1527019779252};\\\", \\\"{x:1429,y:805,t:1527019779270};\\\", \\\"{x:1430,y:805,t:1527019779286};\\\", \\\"{x:1431,y:805,t:1527019779303};\\\", \\\"{x:1434,y:805,t:1527019779320};\\\", \\\"{x:1436,y:805,t:1527019779336};\\\", \\\"{x:1439,y:805,t:1527019779353};\\\", \\\"{x:1443,y:805,t:1527019779370};\\\", \\\"{x:1450,y:805,t:1527019779386};\\\", \\\"{x:1469,y:806,t:1527019779403};\\\", \\\"{x:1483,y:808,t:1527019779420};\\\", \\\"{x:1494,y:809,t:1527019779436};\\\", \\\"{x:1508,y:812,t:1527019779453};\\\", \\\"{x:1527,y:813,t:1527019779470};\\\", \\\"{x:1545,y:816,t:1527019779486};\\\", \\\"{x:1559,y:816,t:1527019779503};\\\", \\\"{x:1570,y:810,t:1527019779520};\\\", \\\"{x:1588,y:794,t:1527019779536};\\\", \\\"{x:1611,y:752,t:1527019779553};\\\", \\\"{x:1623,y:705,t:1527019779570};\\\", \\\"{x:1632,y:663,t:1527019779586};\\\", \\\"{x:1634,y:617,t:1527019779603};\\\", \\\"{x:1630,y:585,t:1527019779620};\\\", \\\"{x:1630,y:576,t:1527019779636};\\\", \\\"{x:1631,y:565,t:1527019779653};\\\", \\\"{x:1623,y:549,t:1527019779670};\\\", \\\"{x:1615,y:539,t:1527019779686};\\\", \\\"{x:1611,y:527,t:1527019779703};\\\", \\\"{x:1608,y:516,t:1527019779720};\\\", \\\"{x:1599,y:504,t:1527019779737};\\\", \\\"{x:1595,y:491,t:1527019779753};\\\", \\\"{x:1588,y:480,t:1527019779770};\\\", \\\"{x:1584,y:477,t:1527019779786};\\\", \\\"{x:1579,y:475,t:1527019779802};\\\", \\\"{x:1578,y:473,t:1527019779820};\\\", \\\"{x:1577,y:471,t:1527019779837};\\\", \\\"{x:1577,y:470,t:1527019779868};\\\", \\\"{x:1576,y:468,t:1527019779891};\\\", \\\"{x:1575,y:468,t:1527019779903};\\\", \\\"{x:1575,y:467,t:1527019779987};\\\", \\\"{x:1569,y:470,t:1527019780003};\\\", \\\"{x:1559,y:479,t:1527019780020};\\\", \\\"{x:1553,y:486,t:1527019780037};\\\", \\\"{x:1546,y:493,t:1527019780053};\\\", \\\"{x:1542,y:499,t:1527019780070};\\\", \\\"{x:1538,y:507,t:1527019780087};\\\", \\\"{x:1534,y:516,t:1527019780103};\\\", \\\"{x:1531,y:522,t:1527019780120};\\\", \\\"{x:1528,y:526,t:1527019780137};\\\", \\\"{x:1526,y:532,t:1527019780153};\\\", \\\"{x:1521,y:543,t:1527019780170};\\\", \\\"{x:1508,y:565,t:1527019780187};\\\", \\\"{x:1500,y:577,t:1527019780203};\\\", \\\"{x:1495,y:588,t:1527019780220};\\\", \\\"{x:1492,y:593,t:1527019780236};\\\", \\\"{x:1485,y:604,t:1527019780254};\\\", \\\"{x:1481,y:612,t:1527019780270};\\\", \\\"{x:1479,y:615,t:1527019780287};\\\", \\\"{x:1474,y:621,t:1527019780304};\\\", \\\"{x:1469,y:627,t:1527019780320};\\\", \\\"{x:1461,y:632,t:1527019780337};\\\", \\\"{x:1457,y:636,t:1527019780354};\\\", \\\"{x:1454,y:639,t:1527019780370};\\\", \\\"{x:1449,y:643,t:1527019780387};\\\", \\\"{x:1445,y:647,t:1527019780404};\\\", \\\"{x:1437,y:654,t:1527019780420};\\\", \\\"{x:1424,y:666,t:1527019780437};\\\", \\\"{x:1410,y:673,t:1527019780454};\\\", \\\"{x:1398,y:680,t:1527019780470};\\\", \\\"{x:1390,y:687,t:1527019780487};\\\", \\\"{x:1384,y:691,t:1527019780504};\\\", \\\"{x:1381,y:693,t:1527019780520};\\\", \\\"{x:1380,y:694,t:1527019780538};\\\", \\\"{x:1378,y:695,t:1527019780554};\\\", \\\"{x:1378,y:696,t:1527019780571};\\\", \\\"{x:1373,y:698,t:1527019780587};\\\", \\\"{x:1370,y:701,t:1527019780603};\\\", \\\"{x:1367,y:704,t:1527019780620};\\\", \\\"{x:1364,y:706,t:1527019780637};\\\", \\\"{x:1360,y:709,t:1527019780654};\\\", \\\"{x:1359,y:710,t:1527019780671};\\\", \\\"{x:1357,y:711,t:1527019780688};\\\", \\\"{x:1357,y:712,t:1527019780704};\\\", \\\"{x:1355,y:714,t:1527019780721};\\\", \\\"{x:1355,y:716,t:1527019781291};\\\", \\\"{x:1355,y:717,t:1527019781304};\\\", \\\"{x:1355,y:721,t:1527019781321};\\\", \\\"{x:1357,y:725,t:1527019781338};\\\", \\\"{x:1359,y:729,t:1527019781354};\\\", \\\"{x:1359,y:730,t:1527019781379};\\\", \\\"{x:1360,y:730,t:1527019781387};\\\", \\\"{x:1361,y:732,t:1527019781404};\\\", \\\"{x:1362,y:733,t:1527019781426};\\\", \\\"{x:1363,y:735,t:1527019781437};\\\", \\\"{x:1363,y:736,t:1527019781453};\\\", \\\"{x:1365,y:739,t:1527019781470};\\\", \\\"{x:1366,y:741,t:1527019781488};\\\", \\\"{x:1368,y:745,t:1527019781503};\\\", \\\"{x:1370,y:749,t:1527019781520};\\\", \\\"{x:1373,y:756,t:1527019781537};\\\", \\\"{x:1375,y:760,t:1527019781554};\\\", \\\"{x:1379,y:767,t:1527019781571};\\\", \\\"{x:1382,y:772,t:1527019781588};\\\", \\\"{x:1385,y:778,t:1527019781604};\\\", \\\"{x:1387,y:785,t:1527019781621};\\\", \\\"{x:1391,y:795,t:1527019781642};\\\", \\\"{x:1406,y:830,t:1527019781686};\\\", \\\"{x:1411,y:839,t:1527019781691};\\\", \\\"{x:1414,y:846,t:1527019781704};\\\", \\\"{x:1420,y:861,t:1527019781720};\\\", \\\"{x:1425,y:877,t:1527019781737};\\\", \\\"{x:1437,y:896,t:1527019781754};\\\", \\\"{x:1439,y:902,t:1527019781771};\\\", \\\"{x:1441,y:905,t:1527019781787};\\\", \\\"{x:1441,y:906,t:1527019781804};\\\", \\\"{x:1441,y:910,t:1527019781820};\\\", \\\"{x:1444,y:917,t:1527019781837};\\\", \\\"{x:1445,y:921,t:1527019781854};\\\", \\\"{x:1449,y:927,t:1527019781871};\\\", \\\"{x:1450,y:931,t:1527019781887};\\\", \\\"{x:1452,y:933,t:1527019781905};\\\", \\\"{x:1454,y:937,t:1527019781920};\\\", \\\"{x:1456,y:941,t:1527019781937};\\\", \\\"{x:1460,y:946,t:1527019781954};\\\", \\\"{x:1463,y:949,t:1527019781971};\\\", \\\"{x:1464,y:950,t:1527019781987};\\\", \\\"{x:1465,y:951,t:1527019782005};\\\", \\\"{x:1466,y:952,t:1527019782021};\\\", \\\"{x:1467,y:953,t:1527019782038};\\\", \\\"{x:1468,y:954,t:1527019782055};\\\", \\\"{x:1468,y:952,t:1527019782147};\\\", \\\"{x:1466,y:948,t:1527019782155};\\\", \\\"{x:1464,y:939,t:1527019782172};\\\", \\\"{x:1462,y:932,t:1527019782187};\\\", \\\"{x:1459,y:927,t:1527019782205};\\\", \\\"{x:1458,y:922,t:1527019782222};\\\", \\\"{x:1455,y:916,t:1527019782237};\\\", \\\"{x:1454,y:911,t:1527019782255};\\\", \\\"{x:1450,y:903,t:1527019782272};\\\", \\\"{x:1446,y:896,t:1527019782288};\\\", \\\"{x:1436,y:877,t:1527019782319};\\\", \\\"{x:1433,y:872,t:1527019782324};\\\", \\\"{x:1431,y:865,t:1527019782337};\\\", \\\"{x:1417,y:845,t:1527019782354};\\\", \\\"{x:1410,y:830,t:1527019782372};\\\", \\\"{x:1401,y:813,t:1527019782387};\\\", \\\"{x:1392,y:799,t:1527019782405};\\\", \\\"{x:1385,y:782,t:1527019782421};\\\", \\\"{x:1373,y:763,t:1527019782437};\\\", \\\"{x:1365,y:751,t:1527019782455};\\\", \\\"{x:1359,y:738,t:1527019782471};\\\", \\\"{x:1355,y:733,t:1527019782487};\\\", \\\"{x:1351,y:725,t:1527019782505};\\\", \\\"{x:1350,y:722,t:1527019782522};\\\", \\\"{x:1350,y:718,t:1527019782539};\\\", \\\"{x:1350,y:714,t:1527019782554};\\\", \\\"{x:1349,y:708,t:1527019782572};\\\", \\\"{x:1349,y:704,t:1527019782589};\\\", \\\"{x:1347,y:699,t:1527019782606};\\\", \\\"{x:1345,y:692,t:1527019782622};\\\", \\\"{x:1343,y:687,t:1527019782639};\\\", \\\"{x:1343,y:683,t:1527019782655};\\\", \\\"{x:1341,y:680,t:1527019782672};\\\", \\\"{x:1339,y:677,t:1527019782688};\\\", \\\"{x:1338,y:677,t:1527019782704};\\\", \\\"{x:1338,y:676,t:1527019782722};\\\", \\\"{x:1336,y:674,t:1527019782739};\\\", \\\"{x:1335,y:673,t:1527019782755};\\\", \\\"{x:1335,y:672,t:1527019782908};\\\", \\\"{x:1335,y:670,t:1527019782922};\\\", \\\"{x:1331,y:663,t:1527019782938};\\\", \\\"{x:1322,y:649,t:1527019782955};\\\", \\\"{x:1316,y:638,t:1527019782972};\\\", \\\"{x:1309,y:630,t:1527019782988};\\\", \\\"{x:1302,y:621,t:1527019783005};\\\", \\\"{x:1298,y:616,t:1527019783022};\\\", \\\"{x:1298,y:615,t:1527019783039};\\\", \\\"{x:1298,y:614,t:1527019783055};\\\", \\\"{x:1298,y:612,t:1527019783071};\\\", \\\"{x:1296,y:609,t:1527019783088};\\\", \\\"{x:1295,y:607,t:1527019783106};\\\", \\\"{x:1293,y:602,t:1527019783121};\\\", \\\"{x:1291,y:599,t:1527019783138};\\\", \\\"{x:1289,y:594,t:1527019783156};\\\", \\\"{x:1288,y:592,t:1527019783172};\\\", \\\"{x:1284,y:586,t:1527019783188};\\\", \\\"{x:1283,y:579,t:1527019783205};\\\", \\\"{x:1279,y:572,t:1527019783222};\\\", \\\"{x:1278,y:568,t:1527019783239};\\\", \\\"{x:1275,y:565,t:1527019783256};\\\", \\\"{x:1275,y:564,t:1527019783272};\\\", \\\"{x:1274,y:562,t:1527019783289};\\\", \\\"{x:1268,y:563,t:1527019783932};\\\", \\\"{x:1257,y:570,t:1527019783939};\\\", \\\"{x:1218,y:582,t:1527019783956};\\\", \\\"{x:1161,y:592,t:1527019783973};\\\", \\\"{x:1083,y:596,t:1527019783990};\\\", \\\"{x:1008,y:596,t:1527019784007};\\\", \\\"{x:935,y:595,t:1527019784023};\\\", \\\"{x:843,y:581,t:1527019784041};\\\", \\\"{x:768,y:571,t:1527019784056};\\\", \\\"{x:693,y:562,t:1527019784072};\\\", \\\"{x:612,y:548,t:1527019784107};\\\", \\\"{x:583,y:544,t:1527019784124};\\\", \\\"{x:560,y:542,t:1527019784139};\\\", \\\"{x:538,y:538,t:1527019784156};\\\", \\\"{x:518,y:536,t:1527019784173};\\\", \\\"{x:502,y:531,t:1527019784191};\\\", \\\"{x:482,y:528,t:1527019784207};\\\", \\\"{x:464,y:526,t:1527019784224};\\\", \\\"{x:440,y:522,t:1527019784241};\\\", \\\"{x:416,y:521,t:1527019784256};\\\", \\\"{x:397,y:521,t:1527019784274};\\\", \\\"{x:389,y:521,t:1527019784289};\\\", \\\"{x:385,y:521,t:1527019784307};\\\", \\\"{x:384,y:521,t:1527019784323};\\\", \\\"{x:388,y:521,t:1527019784531};\\\", \\\"{x:398,y:521,t:1527019784540};\\\", \\\"{x:426,y:521,t:1527019784556};\\\", \\\"{x:482,y:521,t:1527019784573};\\\", \\\"{x:557,y:521,t:1527019784589};\\\", \\\"{x:621,y:521,t:1527019784607};\\\", \\\"{x:658,y:521,t:1527019784623};\\\", \\\"{x:677,y:521,t:1527019784640};\\\", \\\"{x:686,y:520,t:1527019784656};\\\", \\\"{x:690,y:520,t:1527019784674};\\\", \\\"{x:691,y:518,t:1527019784689};\\\", \\\"{x:696,y:513,t:1527019784707};\\\", \\\"{x:699,y:511,t:1527019784723};\\\", \\\"{x:700,y:509,t:1527019784740};\\\", \\\"{x:701,y:505,t:1527019784757};\\\", \\\"{x:701,y:503,t:1527019784775};\\\", \\\"{x:701,y:502,t:1527019784795};\\\", \\\"{x:701,y:501,t:1527019784810};\\\", \\\"{x:698,y:501,t:1527019784825};\\\", \\\"{x:683,y:497,t:1527019784841};\\\", \\\"{x:663,y:494,t:1527019784858};\\\", \\\"{x:641,y:491,t:1527019784876};\\\", \\\"{x:635,y:491,t:1527019784890};\\\", \\\"{x:634,y:491,t:1527019784907};\\\", \\\"{x:632,y:491,t:1527019784994};\\\", \\\"{x:631,y:491,t:1527019785018};\\\", \\\"{x:630,y:491,t:1527019785026};\\\", \\\"{x:628,y:492,t:1527019785066};\\\", \\\"{x:627,y:492,t:1527019785074};\\\", \\\"{x:622,y:494,t:1527019785091};\\\", \\\"{x:621,y:495,t:1527019785108};\\\", \\\"{x:614,y:506,t:1527019785291};\\\", \\\"{x:605,y:525,t:1527019785308};\\\", \\\"{x:595,y:549,t:1527019785324};\\\", \\\"{x:584,y:573,t:1527019785341};\\\", \\\"{x:573,y:598,t:1527019785358};\\\", \\\"{x:566,y:617,t:1527019785375};\\\", \\\"{x:562,y:634,t:1527019785391};\\\", \\\"{x:559,y:648,t:1527019785408};\\\", \\\"{x:554,y:662,t:1527019785424};\\\", \\\"{x:551,y:673,t:1527019785441};\\\", \\\"{x:549,y:683,t:1527019785458};\\\", \\\"{x:545,y:695,t:1527019785474};\\\", \\\"{x:545,y:697,t:1527019785491};\\\", \\\"{x:543,y:699,t:1527019785507};\\\", \\\"{x:542,y:699,t:1527019785525};\\\", \\\"{x:542,y:702,t:1527019785541};\\\", \\\"{x:542,y:703,t:1527019785570};\\\", \\\"{x:541,y:705,t:1527019785587};\\\", \\\"{x:540,y:706,t:1527019785603};\\\", \\\"{x:540,y:707,t:1527019785634};\\\", \\\"{x:540,y:708,t:1527019785658};\\\", \\\"{x:540,y:711,t:1527019785675};\\\", \\\"{x:537,y:716,t:1527019785692};\\\", \\\"{x:534,y:723,t:1527019785710};\\\", \\\"{x:533,y:733,t:1527019785725};\\\", \\\"{x:531,y:736,t:1527019785742};\\\", \\\"{x:531,y:737,t:1527019785757};\\\", \\\"{x:531,y:738,t:1527019785810};\\\", \\\"{x:530,y:738,t:1527019786122};\\\", \\\"{x:529,y:738,t:1527019786138};\\\", \\\"{x:529,y:735,t:1527019786146};\\\", \\\"{x:539,y:732,t:1527019786158};\\\", \\\"{x:561,y:730,t:1527019786174};\\\", \\\"{x:583,y:727,t:1527019786191};\\\", \\\"{x:617,y:727,t:1527019786209};\\\", \\\"{x:647,y:727,t:1527019786226};\\\", \\\"{x:672,y:727,t:1527019786242};\\\", \\\"{x:706,y:727,t:1527019786258};\\\", \\\"{x:716,y:726,t:1527019786276};\\\", \\\"{x:725,y:725,t:1527019786292};\\\", \\\"{x:734,y:721,t:1527019786308};\\\", \\\"{x:741,y:719,t:1527019786325};\\\", \\\"{x:744,y:717,t:1527019786342};\\\", \\\"{x:750,y:715,t:1527019786359};\\\", \\\"{x:757,y:713,t:1527019786376};\\\", \\\"{x:765,y:712,t:1527019786391};\\\", \\\"{x:771,y:708,t:1527019786409};\\\", \\\"{x:779,y:704,t:1527019786425};\\\", \\\"{x:789,y:701,t:1527019786441};\\\", \\\"{x:802,y:699,t:1527019786458};\\\", \\\"{x:810,y:699,t:1527019786476};\\\", \\\"{x:811,y:699,t:1527019786492};\\\" ] }, { \\\"rt\\\": 10853, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 421713, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -12 PM-M -L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:807,y:700,t:1527019787213};\\\", \\\"{x:806,y:701,t:1527019787289};\\\", \\\"{x:801,y:701,t:1527019787298};\\\", \\\"{x:799,y:701,t:1527019787309};\\\", \\\"{x:791,y:700,t:1527019787325};\\\", \\\"{x:786,y:699,t:1527019787342};\\\", \\\"{x:774,y:698,t:1527019787358};\\\", \\\"{x:770,y:696,t:1527019787392};\\\", \\\"{x:769,y:696,t:1527019787530};\\\", \\\"{x:767,y:695,t:1527019787542};\\\", \\\"{x:751,y:693,t:1527019787560};\\\", \\\"{x:735,y:686,t:1527019787576};\\\", \\\"{x:714,y:679,t:1527019787593};\\\", \\\"{x:604,y:611,t:1527019787697};\\\", \\\"{x:587,y:573,t:1527019787710};\\\", \\\"{x:571,y:532,t:1527019787727};\\\", \\\"{x:557,y:502,t:1527019787750};\\\", \\\"{x:556,y:497,t:1527019787760};\\\", \\\"{x:545,y:480,t:1527019787776};\\\", \\\"{x:536,y:468,t:1527019787792};\\\", \\\"{x:533,y:464,t:1527019787809};\\\", \\\"{x:530,y:461,t:1527019787825};\\\", \\\"{x:528,y:459,t:1527019787842};\\\", \\\"{x:526,y:459,t:1527019787859};\\\", \\\"{x:523,y:457,t:1527019787876};\\\", \\\"{x:520,y:457,t:1527019787893};\\\", \\\"{x:518,y:455,t:1527019787909};\\\", \\\"{x:516,y:455,t:1527019787926};\\\", \\\"{x:515,y:455,t:1527019787943};\\\", \\\"{x:512,y:455,t:1527019787959};\\\", \\\"{x:509,y:455,t:1527019787976};\\\", \\\"{x:508,y:455,t:1527019787993};\\\", \\\"{x:509,y:455,t:1527019788107};\\\", \\\"{x:516,y:457,t:1527019788115};\\\", \\\"{x:527,y:460,t:1527019788126};\\\", \\\"{x:552,y:463,t:1527019788142};\\\", \\\"{x:578,y:468,t:1527019788159};\\\", \\\"{x:603,y:473,t:1527019788175};\\\", \\\"{x:618,y:474,t:1527019788192};\\\", \\\"{x:622,y:476,t:1527019788209};\\\", \\\"{x:623,y:476,t:1527019788225};\\\", \\\"{x:628,y:477,t:1527019788515};\\\", \\\"{x:636,y:479,t:1527019788525};\\\", \\\"{x:667,y:482,t:1527019788541};\\\", \\\"{x:719,y:493,t:1527019788559};\\\", \\\"{x:758,y:502,t:1527019788574};\\\", \\\"{x:822,y:511,t:1527019788594};\\\", \\\"{x:904,y:522,t:1527019788610};\\\", \\\"{x:939,y:525,t:1527019788627};\\\", \\\"{x:968,y:526,t:1527019788644};\\\", \\\"{x:1000,y:533,t:1527019788660};\\\", \\\"{x:1029,y:539,t:1527019788677};\\\", \\\"{x:1058,y:546,t:1527019788694};\\\", \\\"{x:1086,y:556,t:1527019788710};\\\", \\\"{x:1111,y:564,t:1527019788726};\\\", \\\"{x:1137,y:571,t:1527019788743};\\\", \\\"{x:1162,y:579,t:1527019788761};\\\", \\\"{x:1198,y:589,t:1527019788776};\\\", \\\"{x:1231,y:600,t:1527019788793};\\\", \\\"{x:1298,y:623,t:1527019788810};\\\", \\\"{x:1323,y:634,t:1527019788827};\\\", \\\"{x:1340,y:639,t:1527019788844};\\\", \\\"{x:1350,y:643,t:1527019788860};\\\", \\\"{x:1354,y:645,t:1527019788877};\\\", \\\"{x:1355,y:645,t:1527019788894};\\\", \\\"{x:1355,y:646,t:1527019788922};\\\", \\\"{x:1356,y:647,t:1527019788930};\\\", \\\"{x:1357,y:648,t:1527019788944};\\\", \\\"{x:1357,y:651,t:1527019788961};\\\", \\\"{x:1357,y:655,t:1527019788978};\\\", \\\"{x:1357,y:657,t:1527019788994};\\\", \\\"{x:1354,y:665,t:1527019789011};\\\", \\\"{x:1351,y:670,t:1527019789028};\\\", \\\"{x:1349,y:673,t:1527019789043};\\\", \\\"{x:1347,y:681,t:1527019789062};\\\", \\\"{x:1345,y:687,t:1527019789077};\\\", \\\"{x:1342,y:695,t:1527019789095};\\\", \\\"{x:1341,y:704,t:1527019789112};\\\", \\\"{x:1340,y:711,t:1527019789128};\\\", \\\"{x:1340,y:716,t:1527019789144};\\\", \\\"{x:1338,y:726,t:1527019789161};\\\", \\\"{x:1338,y:736,t:1527019789178};\\\", \\\"{x:1342,y:751,t:1527019789194};\\\", \\\"{x:1344,y:762,t:1527019789211};\\\", \\\"{x:1344,y:774,t:1527019789229};\\\", \\\"{x:1344,y:783,t:1527019789244};\\\", \\\"{x:1340,y:793,t:1527019789261};\\\", \\\"{x:1334,y:804,t:1527019789278};\\\", \\\"{x:1330,y:811,t:1527019789293};\\\", \\\"{x:1328,y:825,t:1527019789311};\\\", \\\"{x:1327,y:838,t:1527019789328};\\\", \\\"{x:1326,y:847,t:1527019789344};\\\", \\\"{x:1322,y:852,t:1527019789361};\\\", \\\"{x:1316,y:857,t:1527019789378};\\\", \\\"{x:1307,y:862,t:1527019789395};\\\", \\\"{x:1307,y:863,t:1527019789411};\\\", \\\"{x:1306,y:863,t:1527019789428};\\\", \\\"{x:1302,y:865,t:1527019789445};\\\", \\\"{x:1292,y:867,t:1527019789461};\\\", \\\"{x:1288,y:870,t:1527019789479};\\\", \\\"{x:1284,y:871,t:1527019789495};\\\", \\\"{x:1282,y:873,t:1527019789511};\\\", \\\"{x:1279,y:876,t:1527019789547};\\\", \\\"{x:1278,y:877,t:1527019789561};\\\", \\\"{x:1270,y:886,t:1527019789578};\\\", \\\"{x:1260,y:896,t:1527019789595};\\\", \\\"{x:1256,y:903,t:1527019789612};\\\", \\\"{x:1250,y:914,t:1527019789628};\\\", \\\"{x:1245,y:922,t:1527019789645};\\\", \\\"{x:1243,y:929,t:1527019789661};\\\", \\\"{x:1242,y:938,t:1527019789679};\\\", \\\"{x:1242,y:940,t:1527019789695};\\\", \\\"{x:1242,y:942,t:1527019789711};\\\", \\\"{x:1242,y:943,t:1527019789728};\\\", \\\"{x:1242,y:945,t:1527019789745};\\\", \\\"{x:1242,y:946,t:1527019789761};\\\", \\\"{x:1245,y:947,t:1527019789778};\\\", \\\"{x:1257,y:948,t:1527019789795};\\\", \\\"{x:1267,y:950,t:1527019789811};\\\", \\\"{x:1278,y:951,t:1527019789828};\\\", \\\"{x:1286,y:951,t:1527019789845};\\\", \\\"{x:1295,y:953,t:1527019789861};\\\", \\\"{x:1304,y:953,t:1527019789878};\\\", \\\"{x:1307,y:953,t:1527019789895};\\\", \\\"{x:1314,y:953,t:1527019789911};\\\", \\\"{x:1320,y:953,t:1527019789928};\\\", \\\"{x:1326,y:953,t:1527019789945};\\\", \\\"{x:1330,y:953,t:1527019789963};\\\", \\\"{x:1335,y:953,t:1527019789979};\\\", \\\"{x:1336,y:954,t:1527019790044};\\\", \\\"{x:1337,y:954,t:1527019790051};\\\", \\\"{x:1338,y:955,t:1527019790067};\\\", \\\"{x:1339,y:955,t:1527019790083};\\\", \\\"{x:1339,y:956,t:1527019790106};\\\", \\\"{x:1339,y:958,t:1527019790123};\\\", \\\"{x:1341,y:960,t:1527019790131};\\\", \\\"{x:1342,y:961,t:1527019790145};\\\", \\\"{x:1346,y:966,t:1527019790162};\\\", \\\"{x:1346,y:967,t:1527019790178};\\\", \\\"{x:1347,y:968,t:1527019790195};\\\", \\\"{x:1347,y:969,t:1527019790213};\\\", \\\"{x:1347,y:968,t:1527019790404};\\\", \\\"{x:1347,y:966,t:1527019790443};\\\", \\\"{x:1346,y:964,t:1527019790452};\\\", \\\"{x:1346,y:963,t:1527019790483};\\\", \\\"{x:1346,y:962,t:1527019790496};\\\", \\\"{x:1345,y:961,t:1527019790513};\\\", \\\"{x:1345,y:960,t:1527019790547};\\\", \\\"{x:1346,y:958,t:1527019790563};\\\", \\\"{x:1349,y:952,t:1527019790579};\\\", \\\"{x:1350,y:945,t:1527019790595};\\\", \\\"{x:1353,y:937,t:1527019790613};\\\", \\\"{x:1354,y:928,t:1527019790629};\\\", \\\"{x:1354,y:924,t:1527019790645};\\\", \\\"{x:1355,y:919,t:1527019790662};\\\", \\\"{x:1357,y:914,t:1527019790679};\\\", \\\"{x:1357,y:910,t:1527019790695};\\\", \\\"{x:1358,y:907,t:1527019790712};\\\", \\\"{x:1359,y:906,t:1527019790728};\\\", \\\"{x:1360,y:904,t:1527019790745};\\\", \\\"{x:1361,y:901,t:1527019790762};\\\", \\\"{x:1362,y:898,t:1527019790778};\\\", \\\"{x:1362,y:897,t:1527019790796};\\\", \\\"{x:1363,y:896,t:1527019790812};\\\", \\\"{x:1365,y:895,t:1527019790829};\\\", \\\"{x:1366,y:895,t:1527019790846};\\\", \\\"{x:1367,y:895,t:1527019790862};\\\", \\\"{x:1369,y:895,t:1527019790905};\\\", \\\"{x:1369,y:894,t:1527019790914};\\\", \\\"{x:1370,y:894,t:1527019790938};\\\", \\\"{x:1371,y:894,t:1527019790946};\\\", \\\"{x:1372,y:894,t:1527019790961};\\\", \\\"{x:1373,y:894,t:1527019790978};\\\", \\\"{x:1375,y:894,t:1527019791002};\\\", \\\"{x:1375,y:893,t:1527019791411};\\\", \\\"{x:1375,y:892,t:1527019791418};\\\", \\\"{x:1376,y:891,t:1527019791435};\\\", \\\"{x:1377,y:889,t:1527019791446};\\\", \\\"{x:1379,y:886,t:1527019791463};\\\", \\\"{x:1381,y:880,t:1527019791479};\\\", \\\"{x:1383,y:875,t:1527019791495};\\\", \\\"{x:1384,y:873,t:1527019791512};\\\", \\\"{x:1385,y:871,t:1527019791529};\\\", \\\"{x:1386,y:869,t:1527019791546};\\\", \\\"{x:1388,y:866,t:1527019791563};\\\", \\\"{x:1388,y:865,t:1527019791586};\\\", \\\"{x:1390,y:864,t:1527019791595};\\\", \\\"{x:1390,y:863,t:1527019791613};\\\", \\\"{x:1391,y:859,t:1527019791629};\\\", \\\"{x:1393,y:856,t:1527019791646};\\\", \\\"{x:1394,y:852,t:1527019791663};\\\", \\\"{x:1396,y:848,t:1527019791679};\\\", \\\"{x:1398,y:846,t:1527019791696};\\\", \\\"{x:1398,y:844,t:1527019791712};\\\", \\\"{x:1400,y:843,t:1527019791729};\\\", \\\"{x:1400,y:841,t:1527019791746};\\\", \\\"{x:1401,y:835,t:1527019791762};\\\", \\\"{x:1403,y:831,t:1527019791780};\\\", \\\"{x:1405,y:827,t:1527019791796};\\\", \\\"{x:1406,y:824,t:1527019791814};\\\", \\\"{x:1407,y:820,t:1527019791830};\\\", \\\"{x:1408,y:818,t:1527019791851};\\\", \\\"{x:1408,y:816,t:1527019791863};\\\", \\\"{x:1409,y:813,t:1527019791880};\\\", \\\"{x:1412,y:806,t:1527019791896};\\\", \\\"{x:1413,y:800,t:1527019791912};\\\", \\\"{x:1417,y:789,t:1527019791929};\\\", \\\"{x:1420,y:784,t:1527019791946};\\\", \\\"{x:1425,y:774,t:1527019791962};\\\", \\\"{x:1432,y:760,t:1527019791979};\\\", \\\"{x:1441,y:742,t:1527019791996};\\\", \\\"{x:1447,y:727,t:1527019792013};\\\", \\\"{x:1454,y:709,t:1527019792029};\\\", \\\"{x:1463,y:689,t:1527019792046};\\\", \\\"{x:1470,y:672,t:1527019792063};\\\", \\\"{x:1473,y:658,t:1527019792080};\\\", \\\"{x:1474,y:645,t:1527019792096};\\\", \\\"{x:1475,y:633,t:1527019792113};\\\", \\\"{x:1477,y:622,t:1527019792130};\\\", \\\"{x:1479,y:617,t:1527019792146};\\\", \\\"{x:1481,y:612,t:1527019792163};\\\", \\\"{x:1483,y:607,t:1527019792180};\\\", \\\"{x:1485,y:601,t:1527019792196};\\\", \\\"{x:1488,y:595,t:1527019792213};\\\", \\\"{x:1491,y:590,t:1527019792231};\\\", \\\"{x:1498,y:580,t:1527019792247};\\\", \\\"{x:1504,y:570,t:1527019792263};\\\", \\\"{x:1514,y:558,t:1527019792280};\\\", \\\"{x:1524,y:547,t:1527019792297};\\\", \\\"{x:1532,y:538,t:1527019792313};\\\", \\\"{x:1539,y:529,t:1527019792330};\\\", \\\"{x:1548,y:520,t:1527019792347};\\\", \\\"{x:1553,y:516,t:1527019792363};\\\", \\\"{x:1559,y:511,t:1527019792381};\\\", \\\"{x:1566,y:504,t:1527019792397};\\\", \\\"{x:1569,y:503,t:1527019792413};\\\", \\\"{x:1572,y:499,t:1527019792430};\\\", \\\"{x:1576,y:498,t:1527019792447};\\\", \\\"{x:1577,y:497,t:1527019792463};\\\", \\\"{x:1578,y:496,t:1527019792480};\\\", \\\"{x:1579,y:495,t:1527019792497};\\\", \\\"{x:1580,y:494,t:1527019792513};\\\", \\\"{x:1582,y:493,t:1527019792531};\\\", \\\"{x:1586,y:491,t:1527019792547};\\\", \\\"{x:1585,y:491,t:1527019794388};\\\", \\\"{x:1580,y:496,t:1527019794399};\\\", \\\"{x:1567,y:507,t:1527019794416};\\\", \\\"{x:1548,y:514,t:1527019794431};\\\", \\\"{x:1528,y:525,t:1527019794448};\\\", \\\"{x:1502,y:533,t:1527019794466};\\\", \\\"{x:1455,y:543,t:1527019794482};\\\", \\\"{x:1358,y:571,t:1527019794498};\\\", \\\"{x:1223,y:607,t:1527019794515};\\\", \\\"{x:1070,y:631,t:1527019794534};\\\", \\\"{x:899,y:653,t:1527019794548};\\\", \\\"{x:740,y:666,t:1527019794564};\\\", \\\"{x:615,y:666,t:1527019794581};\\\", \\\"{x:520,y:654,t:1527019794598};\\\", \\\"{x:462,y:646,t:1527019794616};\\\", \\\"{x:403,y:638,t:1527019794632};\\\", \\\"{x:365,y:630,t:1527019794648};\\\", \\\"{x:348,y:628,t:1527019794659};\\\", \\\"{x:326,y:624,t:1527019794677};\\\", \\\"{x:316,y:621,t:1527019794693};\\\", \\\"{x:301,y:614,t:1527019794709};\\\", \\\"{x:292,y:609,t:1527019794726};\\\", \\\"{x:291,y:608,t:1527019794743};\\\", \\\"{x:291,y:606,t:1527019794761};\\\", \\\"{x:291,y:604,t:1527019794777};\\\", \\\"{x:291,y:601,t:1527019794794};\\\", \\\"{x:291,y:598,t:1527019794810};\\\", \\\"{x:294,y:595,t:1527019794827};\\\", \\\"{x:296,y:592,t:1527019794849};\\\", \\\"{x:299,y:590,t:1527019794865};\\\", \\\"{x:310,y:589,t:1527019794882};\\\", \\\"{x:314,y:588,t:1527019794899};\\\", \\\"{x:319,y:588,t:1527019794915};\\\", \\\"{x:325,y:587,t:1527019794932};\\\", \\\"{x:330,y:587,t:1527019794948};\\\", \\\"{x:335,y:585,t:1527019794966};\\\", \\\"{x:338,y:584,t:1527019794982};\\\", \\\"{x:342,y:584,t:1527019794999};\\\", \\\"{x:345,y:583,t:1527019795016};\\\", \\\"{x:346,y:581,t:1527019795032};\\\", \\\"{x:347,y:581,t:1527019795049};\\\", \\\"{x:353,y:578,t:1527019795065};\\\", \\\"{x:356,y:576,t:1527019795082};\\\", \\\"{x:364,y:569,t:1527019795099};\\\", \\\"{x:369,y:566,t:1527019795116};\\\", \\\"{x:374,y:561,t:1527019795133};\\\", \\\"{x:377,y:559,t:1527019795149};\\\", \\\"{x:380,y:556,t:1527019795164};\\\", \\\"{x:384,y:553,t:1527019795182};\\\", \\\"{x:387,y:552,t:1527019795199};\\\", \\\"{x:390,y:550,t:1527019795215};\\\", \\\"{x:391,y:549,t:1527019795232};\\\", \\\"{x:392,y:548,t:1527019795249};\\\", \\\"{x:393,y:547,t:1527019795266};\\\", \\\"{x:394,y:547,t:1527019795315};\\\", \\\"{x:396,y:547,t:1527019795642};\\\", \\\"{x:398,y:547,t:1527019795648};\\\", \\\"{x:405,y:547,t:1527019795664};\\\", \\\"{x:421,y:547,t:1527019795681};\\\", \\\"{x:440,y:548,t:1527019795698};\\\", \\\"{x:453,y:551,t:1527019795714};\\\", \\\"{x:475,y:555,t:1527019795731};\\\", \\\"{x:498,y:558,t:1527019795749};\\\", \\\"{x:518,y:560,t:1527019795765};\\\", \\\"{x:538,y:564,t:1527019795782};\\\", \\\"{x:555,y:566,t:1527019795799};\\\", \\\"{x:568,y:568,t:1527019795815};\\\", \\\"{x:578,y:570,t:1527019795831};\\\", \\\"{x:587,y:570,t:1527019795848};\\\", \\\"{x:593,y:570,t:1527019795864};\\\", \\\"{x:603,y:570,t:1527019795882};\\\", \\\"{x:616,y:570,t:1527019795898};\\\", \\\"{x:638,y:574,t:1527019795914};\\\", \\\"{x:659,y:578,t:1527019795932};\\\", \\\"{x:691,y:579,t:1527019795948};\\\", \\\"{x:722,y:580,t:1527019795964};\\\", \\\"{x:746,y:580,t:1527019795982};\\\", \\\"{x:765,y:581,t:1527019795998};\\\", \\\"{x:774,y:581,t:1527019796014};\\\", \\\"{x:778,y:582,t:1527019796031};\\\", \\\"{x:779,y:582,t:1527019796121};\\\", \\\"{x:780,y:582,t:1527019796131};\\\", \\\"{x:781,y:582,t:1527019796149};\\\", \\\"{x:782,y:581,t:1527019796177};\\\", \\\"{x:774,y:581,t:1527019796201};\\\", \\\"{x:739,y:584,t:1527019796217};\\\", \\\"{x:684,y:590,t:1527019796235};\\\", \\\"{x:610,y:606,t:1527019796249};\\\", \\\"{x:534,y:622,t:1527019796265};\\\", \\\"{x:526,y:623,t:1527019796281};\\\", \\\"{x:525,y:623,t:1527019796304};\\\", \\\"{x:519,y:620,t:1527019796315};\\\", \\\"{x:513,y:617,t:1527019796331};\\\", \\\"{x:512,y:617,t:1527019796348};\\\", \\\"{x:510,y:615,t:1527019796365};\\\", \\\"{x:506,y:614,t:1527019796382};\\\", \\\"{x:505,y:614,t:1527019796398};\\\", \\\"{x:505,y:613,t:1527019796415};\\\", \\\"{x:505,y:612,t:1527019796431};\\\", \\\"{x:502,y:611,t:1527019796449};\\\", \\\"{x:502,y:609,t:1527019796472};\\\", \\\"{x:502,y:608,t:1527019796482};\\\", \\\"{x:500,y:608,t:1527019796499};\\\", \\\"{x:496,y:608,t:1527019796518};\\\", \\\"{x:492,y:608,t:1527019796531};\\\", \\\"{x:484,y:608,t:1527019796548};\\\", \\\"{x:478,y:609,t:1527019796565};\\\", \\\"{x:473,y:612,t:1527019796582};\\\", \\\"{x:469,y:613,t:1527019796599};\\\", \\\"{x:465,y:615,t:1527019796616};\\\", \\\"{x:457,y:617,t:1527019796632};\\\", \\\"{x:453,y:618,t:1527019796648};\\\", \\\"{x:448,y:618,t:1527019796665};\\\", \\\"{x:440,y:618,t:1527019796682};\\\", \\\"{x:436,y:618,t:1527019796698};\\\", \\\"{x:433,y:618,t:1527019796715};\\\", \\\"{x:432,y:618,t:1527019796732};\\\", \\\"{x:431,y:618,t:1527019796769};\\\", \\\"{x:430,y:618,t:1527019796782};\\\", \\\"{x:425,y:617,t:1527019796798};\\\", \\\"{x:413,y:616,t:1527019796818};\\\", \\\"{x:410,y:616,t:1527019796832};\\\", \\\"{x:409,y:616,t:1527019796856};\\\", \\\"{x:409,y:618,t:1527019797176};\\\", \\\"{x:409,y:622,t:1527019797184};\\\", \\\"{x:409,y:626,t:1527019797200};\\\", \\\"{x:414,y:636,t:1527019797217};\\\", \\\"{x:420,y:647,t:1527019797233};\\\", \\\"{x:424,y:652,t:1527019797249};\\\", \\\"{x:432,y:661,t:1527019797266};\\\", \\\"{x:437,y:671,t:1527019797283};\\\", \\\"{x:445,y:681,t:1527019797300};\\\", \\\"{x:453,y:690,t:1527019797316};\\\", \\\"{x:457,y:694,t:1527019797332};\\\", \\\"{x:459,y:697,t:1527019797350};\\\", \\\"{x:460,y:698,t:1527019797367};\\\", \\\"{x:461,y:702,t:1527019797382};\\\", \\\"{x:463,y:704,t:1527019797400};\\\", \\\"{x:466,y:707,t:1527019797416};\\\", \\\"{x:467,y:707,t:1527019797432};\\\", \\\"{x:469,y:710,t:1527019797450};\\\", \\\"{x:472,y:714,t:1527019797467};\\\", \\\"{x:473,y:717,t:1527019797484};\\\", \\\"{x:475,y:720,t:1527019797501};\\\", \\\"{x:476,y:722,t:1527019797516};\\\", \\\"{x:476,y:724,t:1527019797532};\\\", \\\"{x:478,y:727,t:1527019797549};\\\", \\\"{x:478,y:728,t:1527019797567};\\\", \\\"{x:480,y:731,t:1527019797582};\\\", \\\"{x:481,y:733,t:1527019797624};\\\", \\\"{x:481,y:734,t:1527019797649};\\\", \\\"{x:482,y:735,t:1527019797664};\\\", \\\"{x:482,y:737,t:1527019797705};\\\", \\\"{x:483,y:738,t:1527019797717};\\\", \\\"{x:483,y:740,t:1527019797761};\\\", \\\"{x:483,y:741,t:1527019797802};\\\", \\\"{x:483,y:742,t:1527019798313};\\\", \\\"{x:482,y:742,t:1527019798320};\\\", \\\"{x:481,y:743,t:1527019798333};\\\", \\\"{x:480,y:744,t:1527019798351};\\\", \\\"{x:476,y:745,t:1527019798367};\\\", \\\"{x:474,y:748,t:1527019798384};\\\", \\\"{x:471,y:749,t:1527019798400};\\\", \\\"{x:468,y:753,t:1527019798416};\\\", \\\"{x:468,y:757,t:1527019798434};\\\", \\\"{x:468,y:760,t:1527019798451};\\\", \\\"{x:468,y:762,t:1527019798467};\\\", \\\"{x:469,y:762,t:1527019798483};\\\", \\\"{x:469,y:761,t:1527019799136};\\\", \\\"{x:469,y:760,t:1527019799150};\\\" ] }, { \\\"rt\\\": 10824, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 433799, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:469,y:754,t:1527019799329};\\\", \\\"{x:470,y:754,t:1527019799355};\\\", \\\"{x:470,y:752,t:1527019799400};\\\", \\\"{x:471,y:752,t:1527019799419};\\\", \\\"{x:472,y:750,t:1527019799576};\\\", \\\"{x:472,y:749,t:1527019799592};\\\", \\\"{x:473,y:748,t:1527019799600};\\\", \\\"{x:475,y:740,t:1527019799618};\\\", \\\"{x:476,y:720,t:1527019799635};\\\", \\\"{x:477,y:690,t:1527019799651};\\\", \\\"{x:477,y:640,t:1527019799668};\\\", \\\"{x:473,y:588,t:1527019799685};\\\", \\\"{x:464,y:549,t:1527019799701};\\\", \\\"{x:458,y:524,t:1527019799718};\\\", \\\"{x:454,y:507,t:1527019799735};\\\", \\\"{x:449,y:493,t:1527019799752};\\\", \\\"{x:447,y:486,t:1527019799768};\\\", \\\"{x:444,y:479,t:1527019799784};\\\", \\\"{x:441,y:476,t:1527019799801};\\\", \\\"{x:438,y:472,t:1527019799817};\\\", \\\"{x:413,y:449,t:1527019799920};\\\", \\\"{x:412,y:448,t:1527019799936};\\\", \\\"{x:413,y:448,t:1527019800032};\\\", \\\"{x:416,y:448,t:1527019800040};\\\", \\\"{x:421,y:448,t:1527019800052};\\\", \\\"{x:431,y:448,t:1527019800069};\\\", \\\"{x:442,y:448,t:1527019800085};\\\", \\\"{x:452,y:449,t:1527019800102};\\\", \\\"{x:457,y:449,t:1527019800118};\\\", \\\"{x:464,y:449,t:1527019800135};\\\", \\\"{x:474,y:451,t:1527019800152};\\\", \\\"{x:481,y:453,t:1527019800169};\\\", \\\"{x:485,y:455,t:1527019800185};\\\", \\\"{x:487,y:455,t:1527019800203};\\\", \\\"{x:488,y:455,t:1527019800219};\\\", \\\"{x:489,y:456,t:1527019800235};\\\", \\\"{x:491,y:456,t:1527019800322};\\\", \\\"{x:492,y:456,t:1527019800337};\\\", \\\"{x:495,y:456,t:1527019800353};\\\", \\\"{x:497,y:456,t:1527019800370};\\\", \\\"{x:498,y:457,t:1527019800387};\\\", \\\"{x:500,y:457,t:1527019800402};\\\", \\\"{x:502,y:457,t:1527019800419};\\\", \\\"{x:504,y:457,t:1527019800436};\\\", \\\"{x:508,y:457,t:1527019800453};\\\", \\\"{x:509,y:457,t:1527019800473};\\\", \\\"{x:510,y:457,t:1527019800487};\\\", \\\"{x:511,y:457,t:1527019800503};\\\", \\\"{x:514,y:457,t:1527019800519};\\\", \\\"{x:518,y:457,t:1527019800536};\\\", \\\"{x:526,y:457,t:1527019800554};\\\", \\\"{x:536,y:458,t:1527019800570};\\\", \\\"{x:544,y:458,t:1527019800587};\\\", \\\"{x:549,y:458,t:1527019800603};\\\", \\\"{x:552,y:458,t:1527019800620};\\\", \\\"{x:555,y:458,t:1527019800637};\\\", \\\"{x:557,y:458,t:1527019800653};\\\", \\\"{x:558,y:458,t:1527019800671};\\\", \\\"{x:560,y:458,t:1527019800825};\\\", \\\"{x:561,y:458,t:1527019800890};\\\", \\\"{x:564,y:458,t:1527019800904};\\\", \\\"{x:573,y:458,t:1527019800920};\\\", \\\"{x:581,y:458,t:1527019800938};\\\", \\\"{x:594,y:458,t:1527019800954};\\\", \\\"{x:602,y:458,t:1527019800971};\\\", \\\"{x:605,y:458,t:1527019800987};\\\", \\\"{x:606,y:458,t:1527019801113};\\\", \\\"{x:609,y:457,t:1527019801434};\\\", \\\"{x:613,y:457,t:1527019801440};\\\", \\\"{x:616,y:457,t:1527019801456};\\\", \\\"{x:628,y:456,t:1527019801473};\\\", \\\"{x:640,y:463,t:1527019801488};\\\", \\\"{x:668,y:468,t:1527019801505};\\\", \\\"{x:689,y:472,t:1527019801523};\\\", \\\"{x:711,y:475,t:1527019801539};\\\", \\\"{x:730,y:479,t:1527019801556};\\\", \\\"{x:751,y:479,t:1527019801572};\\\", \\\"{x:782,y:489,t:1527019801591};\\\", \\\"{x:792,y:494,t:1527019801606};\\\", \\\"{x:799,y:499,t:1527019801620};\\\", \\\"{x:816,y:505,t:1527019801636};\\\", \\\"{x:832,y:509,t:1527019801653};\\\", \\\"{x:839,y:510,t:1527019801669};\\\", \\\"{x:847,y:511,t:1527019801686};\\\", \\\"{x:857,y:514,t:1527019801703};\\\", \\\"{x:870,y:517,t:1527019801720};\\\", \\\"{x:890,y:523,t:1527019801736};\\\", \\\"{x:922,y:532,t:1527019801753};\\\", \\\"{x:944,y:537,t:1527019801770};\\\", \\\"{x:966,y:540,t:1527019801786};\\\", \\\"{x:995,y:544,t:1527019801803};\\\", \\\"{x:1030,y:553,t:1527019801819};\\\", \\\"{x:1070,y:554,t:1527019801836};\\\", \\\"{x:1112,y:559,t:1527019801852};\\\", \\\"{x:1164,y:562,t:1527019801870};\\\", \\\"{x:1203,y:562,t:1527019801886};\\\", \\\"{x:1233,y:562,t:1527019801903};\\\", \\\"{x:1260,y:566,t:1527019801920};\\\", \\\"{x:1290,y:566,t:1527019801936};\\\", \\\"{x:1324,y:568,t:1527019801952};\\\", \\\"{x:1347,y:571,t:1527019801968};\\\", \\\"{x:1365,y:573,t:1527019801987};\\\", \\\"{x:1381,y:577,t:1527019802003};\\\", \\\"{x:1392,y:582,t:1527019802019};\\\", \\\"{x:1404,y:587,t:1527019802037};\\\", \\\"{x:1411,y:589,t:1527019802053};\\\", \\\"{x:1417,y:592,t:1527019802069};\\\", \\\"{x:1419,y:592,t:1527019802086};\\\", \\\"{x:1420,y:593,t:1527019802105};\\\", \\\"{x:1422,y:593,t:1527019802119};\\\", \\\"{x:1425,y:595,t:1527019802137};\\\", \\\"{x:1425,y:596,t:1527019802152};\\\", \\\"{x:1426,y:596,t:1527019802169};\\\", \\\"{x:1427,y:597,t:1527019802233};\\\", \\\"{x:1432,y:592,t:1527019802553};\\\", \\\"{x:1435,y:586,t:1527019802568};\\\", \\\"{x:1448,y:566,t:1527019802585};\\\", \\\"{x:1455,y:555,t:1527019802601};\\\", \\\"{x:1458,y:550,t:1527019802618};\\\", \\\"{x:1464,y:543,t:1527019802635};\\\", \\\"{x:1468,y:538,t:1527019802651};\\\", \\\"{x:1471,y:534,t:1527019802669};\\\", \\\"{x:1473,y:530,t:1527019802684};\\\", \\\"{x:1475,y:528,t:1527019802701};\\\", \\\"{x:1477,y:526,t:1527019802718};\\\", \\\"{x:1482,y:521,t:1527019802735};\\\", \\\"{x:1485,y:517,t:1527019802752};\\\", \\\"{x:1487,y:515,t:1527019802767};\\\", \\\"{x:1490,y:512,t:1527019802784};\\\", \\\"{x:1492,y:508,t:1527019802801};\\\", \\\"{x:1494,y:506,t:1527019802817};\\\", \\\"{x:1495,y:504,t:1527019802834};\\\", \\\"{x:1496,y:501,t:1527019802851};\\\", \\\"{x:1497,y:499,t:1527019802868};\\\", \\\"{x:1498,y:495,t:1527019802884};\\\", \\\"{x:1498,y:494,t:1527019802901};\\\", \\\"{x:1499,y:488,t:1527019802917};\\\", \\\"{x:1500,y:486,t:1527019802934};\\\", \\\"{x:1501,y:479,t:1527019802952};\\\", \\\"{x:1502,y:475,t:1527019802968};\\\", \\\"{x:1502,y:472,t:1527019802984};\\\", \\\"{x:1502,y:469,t:1527019803000};\\\", \\\"{x:1503,y:469,t:1527019803090};\\\", \\\"{x:1504,y:470,t:1527019803100};\\\", \\\"{x:1511,y:484,t:1527019803117};\\\", \\\"{x:1520,y:500,t:1527019803133};\\\", \\\"{x:1529,y:510,t:1527019803150};\\\", \\\"{x:1535,y:519,t:1527019803168};\\\", \\\"{x:1538,y:522,t:1527019803183};\\\", \\\"{x:1540,y:524,t:1527019803200};\\\", \\\"{x:1541,y:526,t:1527019803217};\\\", \\\"{x:1542,y:528,t:1527019803233};\\\", \\\"{x:1543,y:531,t:1527019803251};\\\", \\\"{x:1545,y:537,t:1527019803267};\\\", \\\"{x:1547,y:544,t:1527019803283};\\\", \\\"{x:1549,y:550,t:1527019803301};\\\", \\\"{x:1550,y:557,t:1527019803315};\\\", \\\"{x:1553,y:565,t:1527019803332};\\\", \\\"{x:1557,y:571,t:1527019803349};\\\", \\\"{x:1557,y:575,t:1527019803365};\\\", \\\"{x:1558,y:580,t:1527019803382};\\\", \\\"{x:1560,y:584,t:1527019803398};\\\", \\\"{x:1561,y:587,t:1527019803416};\\\", \\\"{x:1562,y:590,t:1527019803432};\\\", \\\"{x:1562,y:592,t:1527019803448};\\\", \\\"{x:1563,y:593,t:1527019803466};\\\", \\\"{x:1564,y:596,t:1527019803483};\\\", \\\"{x:1564,y:597,t:1527019803498};\\\", \\\"{x:1564,y:598,t:1527019803515};\\\", \\\"{x:1564,y:600,t:1527019803532};\\\", \\\"{x:1564,y:603,t:1527019803549};\\\", \\\"{x:1565,y:604,t:1527019803566};\\\", \\\"{x:1565,y:606,t:1527019803581};\\\", \\\"{x:1565,y:608,t:1527019803599};\\\", \\\"{x:1565,y:610,t:1527019803624};\\\", \\\"{x:1565,y:611,t:1527019803632};\\\", \\\"{x:1565,y:614,t:1527019803648};\\\", \\\"{x:1563,y:619,t:1527019803665};\\\", \\\"{x:1560,y:624,t:1527019803682};\\\", \\\"{x:1547,y:636,t:1527019803698};\\\", \\\"{x:1529,y:653,t:1527019803715};\\\", \\\"{x:1499,y:676,t:1527019803732};\\\", \\\"{x:1469,y:700,t:1527019803749};\\\", \\\"{x:1450,y:714,t:1527019803765};\\\", \\\"{x:1437,y:723,t:1527019803782};\\\", \\\"{x:1429,y:729,t:1527019803799};\\\", \\\"{x:1427,y:731,t:1527019803815};\\\", \\\"{x:1426,y:732,t:1527019804041};\\\", \\\"{x:1425,y:733,t:1527019804633};\\\", \\\"{x:1423,y:733,t:1527019804649};\\\", \\\"{x:1423,y:734,t:1527019804664};\\\", \\\"{x:1421,y:734,t:1527019804680};\\\", \\\"{x:1418,y:734,t:1527019804697};\\\", \\\"{x:1415,y:735,t:1527019804714};\\\", \\\"{x:1413,y:735,t:1527019804730};\\\", \\\"{x:1410,y:735,t:1527019804746};\\\", \\\"{x:1408,y:735,t:1527019804763};\\\", \\\"{x:1407,y:735,t:1527019804779};\\\", \\\"{x:1406,y:736,t:1527019804800};\\\", \\\"{x:1405,y:736,t:1527019805291};\\\", \\\"{x:1405,y:735,t:1527019805418};\\\", \\\"{x:1405,y:734,t:1527019805433};\\\", \\\"{x:1405,y:733,t:1527019806184};\\\", \\\"{x:1405,y:731,t:1527019806192};\\\", \\\"{x:1396,y:725,t:1527019806209};\\\", \\\"{x:1377,y:717,t:1527019806226};\\\", \\\"{x:1358,y:710,t:1527019806243};\\\", \\\"{x:1343,y:704,t:1527019806260};\\\", \\\"{x:1336,y:702,t:1527019806276};\\\", \\\"{x:1333,y:701,t:1527019806293};\\\", \\\"{x:1332,y:700,t:1527019806308};\\\", \\\"{x:1332,y:698,t:1527019806514};\\\", \\\"{x:1332,y:697,t:1527019806526};\\\", \\\"{x:1332,y:696,t:1527019806543};\\\", \\\"{x:1335,y:695,t:1527019806560};\\\", \\\"{x:1336,y:695,t:1527019806576};\\\", \\\"{x:1337,y:695,t:1527019806592};\\\", \\\"{x:1338,y:695,t:1527019806753};\\\", \\\"{x:1339,y:696,t:1527019806778};\\\", \\\"{x:1339,y:695,t:1527019806978};\\\", \\\"{x:1339,y:694,t:1527019806992};\\\", \\\"{x:1339,y:691,t:1527019807008};\\\", \\\"{x:1339,y:684,t:1527019807025};\\\", \\\"{x:1343,y:668,t:1527019807041};\\\", \\\"{x:1344,y:660,t:1527019807058};\\\", \\\"{x:1346,y:651,t:1527019807074};\\\", \\\"{x:1347,y:646,t:1527019807091};\\\", \\\"{x:1348,y:640,t:1527019807108};\\\", \\\"{x:1349,y:635,t:1527019807123};\\\", \\\"{x:1352,y:629,t:1527019807140};\\\", \\\"{x:1353,y:625,t:1527019807158};\\\", \\\"{x:1356,y:619,t:1527019807174};\\\", \\\"{x:1357,y:616,t:1527019807190};\\\", \\\"{x:1360,y:612,t:1527019807207};\\\", \\\"{x:1364,y:605,t:1527019807224};\\\", \\\"{x:1371,y:593,t:1527019807240};\\\", \\\"{x:1376,y:588,t:1527019807257};\\\", \\\"{x:1382,y:580,t:1527019807274};\\\", \\\"{x:1386,y:572,t:1527019807291};\\\", \\\"{x:1388,y:565,t:1527019807307};\\\", \\\"{x:1391,y:562,t:1527019807324};\\\", \\\"{x:1397,y:555,t:1527019807340};\\\", \\\"{x:1399,y:553,t:1527019807357};\\\", \\\"{x:1399,y:552,t:1527019807374};\\\", \\\"{x:1401,y:551,t:1527019807432};\\\", \\\"{x:1401,y:550,t:1527019807480};\\\", \\\"{x:1402,y:550,t:1527019807496};\\\", \\\"{x:1403,y:550,t:1527019807520};\\\", \\\"{x:1404,y:549,t:1527019807544};\\\", \\\"{x:1405,y:549,t:1527019807567};\\\", \\\"{x:1406,y:549,t:1527019807592};\\\", \\\"{x:1407,y:548,t:1527019807606};\\\", \\\"{x:1408,y:548,t:1527019807632};\\\", \\\"{x:1409,y:548,t:1527019807641};\\\", \\\"{x:1410,y:548,t:1527019807656};\\\", \\\"{x:1411,y:548,t:1527019807673};\\\", \\\"{x:1412,y:547,t:1527019807690};\\\", \\\"{x:1413,y:547,t:1527019807706};\\\", \\\"{x:1414,y:548,t:1527019807723};\\\", \\\"{x:1417,y:550,t:1527019807740};\\\", \\\"{x:1418,y:552,t:1527019807761};\\\", \\\"{x:1418,y:553,t:1527019807777};\\\", \\\"{x:1420,y:555,t:1527019807794};\\\", \\\"{x:1420,y:556,t:1527019807806};\\\", \\\"{x:1420,y:557,t:1527019807823};\\\", \\\"{x:1420,y:558,t:1527019807839};\\\", \\\"{x:1420,y:559,t:1527019807856};\\\", \\\"{x:1420,y:560,t:1527019807873};\\\", \\\"{x:1420,y:561,t:1527019807889};\\\", \\\"{x:1420,y:562,t:1527019807908};\\\", \\\"{x:1420,y:563,t:1527019807944};\\\", \\\"{x:1420,y:565,t:1527019808000};\\\", \\\"{x:1419,y:566,t:1527019808032};\\\", \\\"{x:1418,y:567,t:1527019808056};\\\", \\\"{x:1417,y:569,t:1527019808072};\\\", \\\"{x:1416,y:570,t:1527019808089};\\\", \\\"{x:1414,y:572,t:1527019808105};\\\", \\\"{x:1413,y:573,t:1527019808122};\\\", \\\"{x:1412,y:575,t:1527019808225};\\\", \\\"{x:1411,y:575,t:1527019808239};\\\", \\\"{x:1409,y:576,t:1527019808256};\\\", \\\"{x:1402,y:580,t:1527019808272};\\\", \\\"{x:1374,y:587,t:1527019808289};\\\", \\\"{x:1341,y:593,t:1527019808305};\\\", \\\"{x:1265,y:607,t:1527019808321};\\\", \\\"{x:1169,y:617,t:1527019808338};\\\", \\\"{x:1047,y:631,t:1527019808355};\\\", \\\"{x:918,y:646,t:1527019808372};\\\", \\\"{x:790,y:663,t:1527019808388};\\\", \\\"{x:680,y:677,t:1527019808405};\\\", \\\"{x:599,y:688,t:1527019808421};\\\", \\\"{x:565,y:693,t:1527019808438};\\\", \\\"{x:549,y:693,t:1527019808455};\\\", \\\"{x:545,y:693,t:1527019808472};\\\", \\\"{x:541,y:690,t:1527019808490};\\\", \\\"{x:537,y:687,t:1527019808504};\\\", \\\"{x:532,y:681,t:1527019808520};\\\", \\\"{x:519,y:670,t:1527019808537};\\\", \\\"{x:507,y:660,t:1527019808553};\\\", \\\"{x:501,y:649,t:1527019808571};\\\", \\\"{x:498,y:634,t:1527019808587};\\\", \\\"{x:498,y:616,t:1527019808605};\\\", \\\"{x:500,y:600,t:1527019808621};\\\", \\\"{x:507,y:588,t:1527019808637};\\\", \\\"{x:518,y:577,t:1527019808653};\\\", \\\"{x:533,y:565,t:1527019808670};\\\", \\\"{x:553,y:554,t:1527019808688};\\\", \\\"{x:576,y:540,t:1527019808703};\\\", \\\"{x:597,y:533,t:1527019808725};\\\", \\\"{x:611,y:532,t:1527019808742};\\\", \\\"{x:618,y:532,t:1527019808759};\\\", \\\"{x:625,y:532,t:1527019808774};\\\", \\\"{x:642,y:532,t:1527019808792};\\\", \\\"{x:659,y:532,t:1527019808809};\\\", \\\"{x:676,y:532,t:1527019808825};\\\", \\\"{x:692,y:532,t:1527019808841};\\\", \\\"{x:709,y:532,t:1527019808859};\\\", \\\"{x:719,y:532,t:1527019808875};\\\", \\\"{x:726,y:532,t:1527019808893};\\\", \\\"{x:732,y:532,t:1527019808908};\\\", \\\"{x:738,y:532,t:1527019808925};\\\", \\\"{x:745,y:532,t:1527019808942};\\\", \\\"{x:753,y:532,t:1527019808959};\\\", \\\"{x:761,y:532,t:1527019808975};\\\", \\\"{x:778,y:532,t:1527019808993};\\\", \\\"{x:784,y:532,t:1527019809009};\\\", \\\"{x:790,y:532,t:1527019809026};\\\", \\\"{x:793,y:532,t:1527019809042};\\\", \\\"{x:794,y:532,t:1527019809058};\\\", \\\"{x:796,y:532,t:1527019809137};\\\", \\\"{x:797,y:532,t:1527019809144};\\\", \\\"{x:797,y:531,t:1527019809159};\\\", \\\"{x:799,y:531,t:1527019809184};\\\", \\\"{x:800,y:531,t:1527019809192};\\\", \\\"{x:801,y:531,t:1527019809208};\\\", \\\"{x:804,y:531,t:1527019809226};\\\", \\\"{x:808,y:531,t:1527019809241};\\\", \\\"{x:811,y:531,t:1527019809259};\\\", \\\"{x:812,y:531,t:1527019809281};\\\", \\\"{x:814,y:531,t:1527019809292};\\\", \\\"{x:816,y:531,t:1527019809309};\\\", \\\"{x:821,y:532,t:1527019809326};\\\", \\\"{x:824,y:533,t:1527019809343};\\\", \\\"{x:825,y:533,t:1527019809359};\\\", \\\"{x:826,y:534,t:1527019809576};\\\", \\\"{x:809,y:551,t:1527019809593};\\\", \\\"{x:774,y:577,t:1527019809610};\\\", \\\"{x:726,y:614,t:1527019809626};\\\", \\\"{x:693,y:637,t:1527019809643};\\\", \\\"{x:671,y:648,t:1527019809659};\\\", \\\"{x:655,y:661,t:1527019809676};\\\", \\\"{x:644,y:670,t:1527019809692};\\\", \\\"{x:635,y:677,t:1527019809708};\\\", \\\"{x:626,y:685,t:1527019809726};\\\", \\\"{x:616,y:695,t:1527019809744};\\\", \\\"{x:601,y:703,t:1527019809759};\\\", \\\"{x:578,y:713,t:1527019809776};\\\", \\\"{x:565,y:718,t:1527019809792};\\\", \\\"{x:553,y:720,t:1527019809809};\\\", \\\"{x:544,y:723,t:1527019809826};\\\", \\\"{x:533,y:724,t:1527019809843};\\\", \\\"{x:522,y:725,t:1527019809860};\\\", \\\"{x:514,y:727,t:1527019809876};\\\", \\\"{x:508,y:728,t:1527019809893};\\\", \\\"{x:507,y:728,t:1527019809912};\\\", \\\"{x:506,y:729,t:1527019809928};\\\", \\\"{x:504,y:731,t:1527019809952};\\\", \\\"{x:503,y:733,t:1527019809960};\\\", \\\"{x:501,y:735,t:1527019809976};\\\", \\\"{x:497,y:739,t:1527019809993};\\\", \\\"{x:496,y:739,t:1527019810170};\\\", \\\"{x:496,y:740,t:1527019810296};\\\", \\\"{x:496,y:742,t:1527019810310};\\\", \\\"{x:497,y:749,t:1527019810327};\\\", \\\"{x:501,y:762,t:1527019810343};\\\", \\\"{x:506,y:782,t:1527019810360};\\\", \\\"{x:509,y:793,t:1527019810376};\\\", \\\"{x:511,y:798,t:1527019810392};\\\", \\\"{x:512,y:805,t:1527019810409};\\\", \\\"{x:512,y:814,t:1527019810426};\\\", \\\"{x:512,y:822,t:1527019810443};\\\", \\\"{x:512,y:831,t:1527019810460};\\\", \\\"{x:510,y:838,t:1527019810477};\\\", \\\"{x:509,y:843,t:1527019810493};\\\", \\\"{x:507,y:847,t:1527019810510};\\\", \\\"{x:506,y:849,t:1527019810527};\\\", \\\"{x:506,y:850,t:1527019810543};\\\", \\\"{x:506,y:851,t:1527019810585};\\\" ] }, { \\\"rt\\\": 13465, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 448486, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"N\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:852,t:1527019812193};\\\", \\\"{x:510,y:854,t:1527019812211};\\\", \\\"{x:512,y:855,t:1527019812228};\\\", \\\"{x:514,y:855,t:1527019812252};\\\", \\\"{x:514,y:857,t:1527019812641};\\\", \\\"{x:515,y:857,t:1527019812657};\\\", \\\"{x:516,y:857,t:1527019812721};\\\", \\\"{x:518,y:857,t:1527019812753};\\\", \\\"{x:521,y:857,t:1527019812763};\\\", \\\"{x:526,y:856,t:1527019812778};\\\", \\\"{x:535,y:853,t:1527019812795};\\\", \\\"{x:541,y:853,t:1527019812812};\\\", \\\"{x:551,y:851,t:1527019812828};\\\", \\\"{x:570,y:851,t:1527019812845};\\\", \\\"{x:596,y:851,t:1527019812862};\\\", \\\"{x:646,y:851,t:1527019812879};\\\", \\\"{x:723,y:851,t:1527019812895};\\\", \\\"{x:848,y:851,t:1527019812912};\\\", \\\"{x:932,y:851,t:1527019812929};\\\", \\\"{x:1004,y:851,t:1527019812946};\\\", \\\"{x:1068,y:851,t:1527019812963};\\\", \\\"{x:1124,y:851,t:1527019812978};\\\", \\\"{x:1160,y:847,t:1527019812996};\\\", \\\"{x:1188,y:843,t:1527019813013};\\\", \\\"{x:1220,y:840,t:1527019813029};\\\", \\\"{x:1237,y:839,t:1527019813046};\\\", \\\"{x:1259,y:839,t:1527019813063};\\\", \\\"{x:1278,y:839,t:1527019813079};\\\", \\\"{x:1300,y:839,t:1527019813096};\\\", \\\"{x:1338,y:839,t:1527019813113};\\\", \\\"{x:1364,y:839,t:1527019813129};\\\", \\\"{x:1394,y:839,t:1527019813146};\\\", \\\"{x:1429,y:839,t:1527019813163};\\\", \\\"{x:1460,y:839,t:1527019813180};\\\", \\\"{x:1488,y:839,t:1527019813195};\\\", \\\"{x:1510,y:839,t:1527019813213};\\\", \\\"{x:1530,y:839,t:1527019813229};\\\", \\\"{x:1547,y:839,t:1527019813245};\\\", \\\"{x:1559,y:839,t:1527019813263};\\\", \\\"{x:1569,y:839,t:1527019813279};\\\", \\\"{x:1577,y:837,t:1527019813295};\\\", \\\"{x:1580,y:836,t:1527019813313};\\\", \\\"{x:1581,y:836,t:1527019813329};\\\", \\\"{x:1582,y:835,t:1527019813345};\\\", \\\"{x:1583,y:835,t:1527019813488};\\\", \\\"{x:1585,y:834,t:1527019813496};\\\", \\\"{x:1594,y:811,t:1527019813512};\\\", \\\"{x:1608,y:778,t:1527019813529};\\\", \\\"{x:1624,y:753,t:1527019813546};\\\", \\\"{x:1636,y:727,t:1527019813563};\\\", \\\"{x:1638,y:711,t:1527019813580};\\\", \\\"{x:1638,y:701,t:1527019813596};\\\", \\\"{x:1632,y:692,t:1527019813612};\\\", \\\"{x:1627,y:690,t:1527019813629};\\\", \\\"{x:1621,y:688,t:1527019813646};\\\", \\\"{x:1616,y:688,t:1527019813663};\\\", \\\"{x:1611,y:688,t:1527019813679};\\\", \\\"{x:1608,y:688,t:1527019813697};\\\", \\\"{x:1607,y:688,t:1527019813712};\\\", \\\"{x:1605,y:691,t:1527019813729};\\\", \\\"{x:1604,y:696,t:1527019813747};\\\", \\\"{x:1604,y:699,t:1527019813762};\\\", \\\"{x:1604,y:702,t:1527019813780};\\\", \\\"{x:1604,y:704,t:1527019813796};\\\", \\\"{x:1604,y:706,t:1527019813813};\\\", \\\"{x:1604,y:708,t:1527019813969};\\\", \\\"{x:1604,y:709,t:1527019813979};\\\", \\\"{x:1604,y:712,t:1527019813997};\\\", \\\"{x:1604,y:717,t:1527019814013};\\\", \\\"{x:1604,y:724,t:1527019814030};\\\", \\\"{x:1602,y:735,t:1527019814046};\\\", \\\"{x:1600,y:743,t:1527019814064};\\\", \\\"{x:1598,y:753,t:1527019814080};\\\", \\\"{x:1594,y:760,t:1527019814097};\\\", \\\"{x:1594,y:763,t:1527019814113};\\\", \\\"{x:1593,y:765,t:1527019814130};\\\", \\\"{x:1592,y:766,t:1527019814147};\\\", \\\"{x:1591,y:770,t:1527019814164};\\\", \\\"{x:1589,y:774,t:1527019814179};\\\", \\\"{x:1588,y:777,t:1527019814197};\\\", \\\"{x:1586,y:785,t:1527019814214};\\\", \\\"{x:1585,y:788,t:1527019814229};\\\", \\\"{x:1584,y:792,t:1527019814247};\\\", \\\"{x:1582,y:797,t:1527019814263};\\\", \\\"{x:1581,y:800,t:1527019814279};\\\", \\\"{x:1578,y:812,t:1527019814296};\\\", \\\"{x:1577,y:818,t:1527019814313};\\\", \\\"{x:1575,y:822,t:1527019814329};\\\", \\\"{x:1574,y:824,t:1527019814346};\\\", \\\"{x:1573,y:826,t:1527019814364};\\\", \\\"{x:1573,y:827,t:1527019814380};\\\", \\\"{x:1573,y:830,t:1527019814397};\\\", \\\"{x:1571,y:833,t:1527019814414};\\\", \\\"{x:1571,y:834,t:1527019814429};\\\", \\\"{x:1570,y:837,t:1527019814446};\\\", \\\"{x:1569,y:837,t:1527019814464};\\\", \\\"{x:1568,y:840,t:1527019814480};\\\", \\\"{x:1567,y:843,t:1527019814496};\\\", \\\"{x:1566,y:843,t:1527019814609};\\\", \\\"{x:1566,y:839,t:1527019814616};\\\", \\\"{x:1567,y:832,t:1527019814630};\\\", \\\"{x:1575,y:813,t:1527019814646};\\\", \\\"{x:1583,y:796,t:1527019814664};\\\", \\\"{x:1591,y:774,t:1527019814680};\\\", \\\"{x:1596,y:758,t:1527019814696};\\\", \\\"{x:1599,y:739,t:1527019814714};\\\", \\\"{x:1601,y:724,t:1527019814730};\\\", \\\"{x:1601,y:708,t:1527019814747};\\\", \\\"{x:1601,y:699,t:1527019814764};\\\", \\\"{x:1601,y:696,t:1527019814780};\\\", \\\"{x:1602,y:693,t:1527019814797};\\\", \\\"{x:1603,y:693,t:1527019814813};\\\", \\\"{x:1604,y:691,t:1527019814831};\\\", \\\"{x:1605,y:689,t:1527019814846};\\\", \\\"{x:1605,y:688,t:1527019814864};\\\", \\\"{x:1605,y:687,t:1527019814881};\\\", \\\"{x:1605,y:686,t:1527019814937};\\\", \\\"{x:1605,y:689,t:1527019814953};\\\", \\\"{x:1605,y:692,t:1527019814964};\\\", \\\"{x:1605,y:700,t:1527019814981};\\\", \\\"{x:1605,y:703,t:1527019814998};\\\", \\\"{x:1605,y:704,t:1527019815013};\\\", \\\"{x:1605,y:705,t:1527019815031};\\\", \\\"{x:1605,y:707,t:1527019815047};\\\", \\\"{x:1605,y:708,t:1527019815063};\\\", \\\"{x:1605,y:710,t:1527019815080};\\\", \\\"{x:1605,y:712,t:1527019815113};\\\", \\\"{x:1603,y:716,t:1527019815131};\\\", \\\"{x:1601,y:718,t:1527019815147};\\\", \\\"{x:1598,y:721,t:1527019815164};\\\", \\\"{x:1597,y:723,t:1527019815181};\\\", \\\"{x:1594,y:726,t:1527019815197};\\\", \\\"{x:1593,y:728,t:1527019815213};\\\", \\\"{x:1590,y:733,t:1527019815230};\\\", \\\"{x:1588,y:737,t:1527019815248};\\\", \\\"{x:1585,y:741,t:1527019815264};\\\", \\\"{x:1579,y:751,t:1527019815281};\\\", \\\"{x:1574,y:759,t:1527019815298};\\\", \\\"{x:1568,y:769,t:1527019815314};\\\", \\\"{x:1562,y:780,t:1527019815330};\\\", \\\"{x:1560,y:787,t:1527019815347};\\\", \\\"{x:1557,y:793,t:1527019815364};\\\", \\\"{x:1554,y:799,t:1527019815381};\\\", \\\"{x:1551,y:805,t:1527019815398};\\\", \\\"{x:1546,y:813,t:1527019815414};\\\", \\\"{x:1542,y:819,t:1527019815431};\\\", \\\"{x:1539,y:826,t:1527019815448};\\\", \\\"{x:1536,y:832,t:1527019815465};\\\", \\\"{x:1534,y:837,t:1527019815481};\\\", \\\"{x:1533,y:841,t:1527019815497};\\\", \\\"{x:1529,y:849,t:1527019815514};\\\", \\\"{x:1524,y:860,t:1527019815530};\\\", \\\"{x:1520,y:868,t:1527019815548};\\\", \\\"{x:1516,y:876,t:1527019815565};\\\", \\\"{x:1509,y:887,t:1527019815581};\\\", \\\"{x:1506,y:892,t:1527019815597};\\\", \\\"{x:1503,y:899,t:1527019815615};\\\", \\\"{x:1500,y:904,t:1527019815630};\\\", \\\"{x:1498,y:910,t:1527019815647};\\\", \\\"{x:1494,y:919,t:1527019815665};\\\", \\\"{x:1492,y:924,t:1527019815680};\\\", \\\"{x:1491,y:929,t:1527019815698};\\\", \\\"{x:1489,y:934,t:1527019815715};\\\", \\\"{x:1488,y:936,t:1527019815731};\\\", \\\"{x:1488,y:938,t:1527019815747};\\\", \\\"{x:1487,y:941,t:1527019815764};\\\", \\\"{x:1485,y:946,t:1527019815781};\\\", \\\"{x:1483,y:951,t:1527019815797};\\\", \\\"{x:1482,y:952,t:1527019815815};\\\", \\\"{x:1482,y:953,t:1527019815830};\\\", \\\"{x:1482,y:954,t:1527019815849};\\\", \\\"{x:1482,y:955,t:1527019815864};\\\", \\\"{x:1482,y:956,t:1527019815880};\\\", \\\"{x:1481,y:957,t:1527019815897};\\\", \\\"{x:1481,y:958,t:1527019815914};\\\", \\\"{x:1480,y:958,t:1527019815931};\\\", \\\"{x:1480,y:959,t:1527019815947};\\\", \\\"{x:1480,y:960,t:1527019815964};\\\", \\\"{x:1480,y:961,t:1527019815981};\\\", \\\"{x:1479,y:961,t:1527019815997};\\\", \\\"{x:1479,y:960,t:1527019816088};\\\", \\\"{x:1480,y:957,t:1527019816097};\\\", \\\"{x:1485,y:948,t:1527019816114};\\\", \\\"{x:1486,y:943,t:1527019816132};\\\", \\\"{x:1489,y:938,t:1527019816147};\\\", \\\"{x:1493,y:932,t:1527019816165};\\\", \\\"{x:1496,y:924,t:1527019816181};\\\", \\\"{x:1504,y:912,t:1527019816198};\\\", \\\"{x:1517,y:896,t:1527019816215};\\\", \\\"{x:1529,y:880,t:1527019816232};\\\", \\\"{x:1539,y:866,t:1527019816247};\\\", \\\"{x:1550,y:849,t:1527019816265};\\\", \\\"{x:1557,y:833,t:1527019816282};\\\", \\\"{x:1562,y:820,t:1527019816298};\\\", \\\"{x:1566,y:808,t:1527019816314};\\\", \\\"{x:1570,y:795,t:1527019816331};\\\", \\\"{x:1573,y:786,t:1527019816347};\\\", \\\"{x:1577,y:778,t:1527019816364};\\\", \\\"{x:1581,y:768,t:1527019816381};\\\", \\\"{x:1586,y:761,t:1527019816397};\\\", \\\"{x:1589,y:752,t:1527019816414};\\\", \\\"{x:1592,y:747,t:1527019816432};\\\", \\\"{x:1593,y:741,t:1527019816448};\\\", \\\"{x:1595,y:738,t:1527019816465};\\\", \\\"{x:1596,y:733,t:1527019816482};\\\", \\\"{x:1597,y:726,t:1527019816499};\\\", \\\"{x:1598,y:720,t:1527019816515};\\\", \\\"{x:1600,y:714,t:1527019816531};\\\", \\\"{x:1601,y:706,t:1527019816549};\\\", \\\"{x:1602,y:700,t:1527019816564};\\\", \\\"{x:1603,y:696,t:1527019816582};\\\", \\\"{x:1604,y:695,t:1527019816599};\\\", \\\"{x:1604,y:693,t:1527019816615};\\\", \\\"{x:1605,y:691,t:1527019816631};\\\", \\\"{x:1605,y:690,t:1527019816648};\\\", \\\"{x:1607,y:688,t:1527019816961};\\\", \\\"{x:1608,y:688,t:1527019817713};\\\", \\\"{x:1610,y:688,t:1527019817729};\\\", \\\"{x:1611,y:688,t:1527019817744};\\\", \\\"{x:1613,y:688,t:1527019817913};\\\", \\\"{x:1614,y:689,t:1527019817960};\\\", \\\"{x:1614,y:690,t:1527019817976};\\\", \\\"{x:1614,y:691,t:1527019818040};\\\", \\\"{x:1614,y:693,t:1527019818146};\\\", \\\"{x:1614,y:695,t:1527019818165};\\\", \\\"{x:1614,y:696,t:1527019818183};\\\", \\\"{x:1617,y:700,t:1527019818199};\\\", \\\"{x:1621,y:710,t:1527019818217};\\\", \\\"{x:1634,y:733,t:1527019818233};\\\", \\\"{x:1640,y:749,t:1527019818250};\\\", \\\"{x:1646,y:764,t:1527019818266};\\\", \\\"{x:1653,y:774,t:1527019818282};\\\", \\\"{x:1660,y:786,t:1527019818299};\\\", \\\"{x:1664,y:794,t:1527019818317};\\\", \\\"{x:1668,y:806,t:1527019818333};\\\", \\\"{x:1672,y:811,t:1527019818349};\\\", \\\"{x:1675,y:821,t:1527019818367};\\\", \\\"{x:1675,y:823,t:1527019818382};\\\", \\\"{x:1675,y:824,t:1527019818401};\\\", \\\"{x:1675,y:825,t:1527019818425};\\\", \\\"{x:1676,y:825,t:1527019818449};\\\", \\\"{x:1677,y:825,t:1527019818537};\\\", \\\"{x:1677,y:823,t:1527019818550};\\\", \\\"{x:1671,y:808,t:1527019818567};\\\", \\\"{x:1665,y:794,t:1527019818582};\\\", \\\"{x:1652,y:776,t:1527019818600};\\\", \\\"{x:1643,y:756,t:1527019818616};\\\", \\\"{x:1635,y:744,t:1527019818633};\\\", \\\"{x:1629,y:723,t:1527019818649};\\\", \\\"{x:1620,y:706,t:1527019818666};\\\", \\\"{x:1609,y:691,t:1527019818683};\\\", \\\"{x:1600,y:683,t:1527019818700};\\\", \\\"{x:1592,y:677,t:1527019818716};\\\", \\\"{x:1587,y:673,t:1527019818732};\\\", \\\"{x:1584,y:669,t:1527019818750};\\\", \\\"{x:1582,y:668,t:1527019818767};\\\", \\\"{x:1581,y:667,t:1527019818783};\\\", \\\"{x:1581,y:666,t:1527019818800};\\\", \\\"{x:1579,y:664,t:1527019818817};\\\", \\\"{x:1577,y:660,t:1527019818833};\\\", \\\"{x:1574,y:658,t:1527019818850};\\\", \\\"{x:1571,y:654,t:1527019818867};\\\", \\\"{x:1570,y:652,t:1527019818884};\\\", \\\"{x:1569,y:647,t:1527019818900};\\\", \\\"{x:1568,y:644,t:1527019818916};\\\", \\\"{x:1566,y:639,t:1527019818933};\\\", \\\"{x:1566,y:638,t:1527019818953};\\\", \\\"{x:1565,y:638,t:1527019819080};\\\", \\\"{x:1564,y:638,t:1527019819087};\\\", \\\"{x:1561,y:639,t:1527019819099};\\\", \\\"{x:1546,y:645,t:1527019819116};\\\", \\\"{x:1510,y:648,t:1527019819133};\\\", \\\"{x:1443,y:648,t:1527019819149};\\\", \\\"{x:1337,y:644,t:1527019819166};\\\", \\\"{x:1215,y:627,t:1527019819184};\\\", \\\"{x:1098,y:609,t:1527019819199};\\\", \\\"{x:936,y:587,t:1527019819217};\\\", \\\"{x:862,y:580,t:1527019819234};\\\", \\\"{x:784,y:571,t:1527019819266};\\\", \\\"{x:754,y:571,t:1527019819283};\\\", \\\"{x:722,y:569,t:1527019819300};\\\", \\\"{x:691,y:563,t:1527019819317};\\\", \\\"{x:654,y:558,t:1527019819335};\\\", \\\"{x:623,y:552,t:1527019819350};\\\", \\\"{x:594,y:546,t:1527019819367};\\\", \\\"{x:576,y:541,t:1527019819383};\\\", \\\"{x:562,y:537,t:1527019819400};\\\", \\\"{x:559,y:536,t:1527019819417};\\\", \\\"{x:558,y:535,t:1527019819496};\\\", \\\"{x:558,y:534,t:1527019819512};\\\", \\\"{x:562,y:532,t:1527019819520};\\\", \\\"{x:563,y:530,t:1527019819534};\\\", \\\"{x:579,y:525,t:1527019819551};\\\", \\\"{x:588,y:524,t:1527019819567};\\\", \\\"{x:625,y:524,t:1527019819583};\\\", \\\"{x:692,y:524,t:1527019819600};\\\", \\\"{x:722,y:524,t:1527019819618};\\\", \\\"{x:750,y:524,t:1527019819633};\\\", \\\"{x:761,y:524,t:1527019819651};\\\", \\\"{x:768,y:524,t:1527019819666};\\\", \\\"{x:771,y:524,t:1527019819683};\\\", \\\"{x:773,y:524,t:1527019819700};\\\", \\\"{x:774,y:524,t:1527019819717};\\\", \\\"{x:775,y:524,t:1527019819733};\\\", \\\"{x:776,y:524,t:1527019819750};\\\", \\\"{x:777,y:525,t:1527019819767};\\\", \\\"{x:779,y:525,t:1527019819783};\\\", \\\"{x:781,y:527,t:1527019819801};\\\", \\\"{x:784,y:529,t:1527019819823};\\\", \\\"{x:784,y:530,t:1527019819839};\\\", \\\"{x:785,y:531,t:1527019819851};\\\", \\\"{x:787,y:531,t:1527019819867};\\\", \\\"{x:791,y:531,t:1527019819884};\\\", \\\"{x:796,y:531,t:1527019819901};\\\", \\\"{x:807,y:531,t:1527019819917};\\\", \\\"{x:817,y:531,t:1527019819934};\\\", \\\"{x:822,y:531,t:1527019819951};\\\", \\\"{x:824,y:531,t:1527019819967};\\\", \\\"{x:825,y:532,t:1527019820111};\\\", \\\"{x:825,y:534,t:1527019820128};\\\", \\\"{x:822,y:538,t:1527019820136};\\\", \\\"{x:819,y:540,t:1527019820151};\\\", \\\"{x:807,y:548,t:1527019820167};\\\", \\\"{x:780,y:553,t:1527019820184};\\\", \\\"{x:761,y:554,t:1527019820201};\\\", \\\"{x:743,y:556,t:1527019820218};\\\", \\\"{x:730,y:558,t:1527019820234};\\\", \\\"{x:724,y:559,t:1527019820251};\\\", \\\"{x:722,y:561,t:1527019820268};\\\", \\\"{x:722,y:562,t:1527019820385};\\\", \\\"{x:722,y:564,t:1527019820402};\\\", \\\"{x:721,y:572,t:1527019820418};\\\", \\\"{x:713,y:583,t:1527019820434};\\\", \\\"{x:706,y:589,t:1527019820451};\\\", \\\"{x:698,y:595,t:1527019820468};\\\", \\\"{x:694,y:599,t:1527019820485};\\\", \\\"{x:686,y:603,t:1527019820503};\\\", \\\"{x:678,y:607,t:1527019820518};\\\", \\\"{x:671,y:608,t:1527019820534};\\\", \\\"{x:666,y:608,t:1527019820552};\\\", \\\"{x:661,y:608,t:1527019820567};\\\", \\\"{x:659,y:608,t:1527019820585};\\\", \\\"{x:657,y:608,t:1527019820601};\\\", \\\"{x:656,y:608,t:1527019820624};\\\", \\\"{x:653,y:610,t:1527019820636};\\\", \\\"{x:644,y:611,t:1527019820651};\\\", \\\"{x:637,y:611,t:1527019820669};\\\", \\\"{x:628,y:611,t:1527019820685};\\\", \\\"{x:622,y:611,t:1527019820701};\\\", \\\"{x:617,y:611,t:1527019820718};\\\", \\\"{x:613,y:611,t:1527019820736};\\\", \\\"{x:609,y:613,t:1527019820751};\\\", \\\"{x:606,y:616,t:1527019820768};\\\", \\\"{x:604,y:616,t:1527019820785};\\\", \\\"{x:602,y:618,t:1527019820801};\\\", \\\"{x:600,y:618,t:1527019820819};\\\", \\\"{x:600,y:619,t:1527019820920};\\\", \\\"{x:598,y:619,t:1527019820961};\\\", \\\"{x:597,y:618,t:1527019821032};\\\", \\\"{x:597,y:615,t:1527019821040};\\\", \\\"{x:597,y:614,t:1527019821052};\\\", \\\"{x:597,y:609,t:1527019821069};\\\", \\\"{x:597,y:606,t:1527019821086};\\\", \\\"{x:597,y:602,t:1527019821102};\\\", \\\"{x:597,y:601,t:1527019821118};\\\", \\\"{x:597,y:600,t:1527019821137};\\\", \\\"{x:597,y:599,t:1527019821183};\\\", \\\"{x:598,y:599,t:1527019821208};\\\", \\\"{x:600,y:601,t:1527019821218};\\\", \\\"{x:601,y:603,t:1527019821235};\\\", \\\"{x:602,y:607,t:1527019821252};\\\", \\\"{x:605,y:611,t:1527019821268};\\\", \\\"{x:606,y:613,t:1527019821286};\\\", \\\"{x:606,y:615,t:1527019821302};\\\", \\\"{x:605,y:615,t:1527019821608};\\\", \\\"{x:600,y:616,t:1527019821619};\\\", \\\"{x:584,y:616,t:1527019821636};\\\", \\\"{x:562,y:616,t:1527019821652};\\\", \\\"{x:541,y:616,t:1527019821669};\\\", \\\"{x:521,y:616,t:1527019821685};\\\", \\\"{x:511,y:616,t:1527019821702};\\\", \\\"{x:507,y:615,t:1527019821719};\\\", \\\"{x:503,y:613,t:1527019821735};\\\", \\\"{x:492,y:608,t:1527019821753};\\\", \\\"{x:478,y:601,t:1527019821769};\\\", \\\"{x:465,y:594,t:1527019821786};\\\", \\\"{x:448,y:589,t:1527019821803};\\\", \\\"{x:436,y:588,t:1527019821819};\\\", \\\"{x:428,y:586,t:1527019821836};\\\", \\\"{x:424,y:586,t:1527019821853};\\\", \\\"{x:420,y:586,t:1527019821869};\\\", \\\"{x:419,y:586,t:1527019821888};\\\", \\\"{x:416,y:586,t:1527019821903};\\\", \\\"{x:414,y:587,t:1527019821919};\\\", \\\"{x:409,y:590,t:1527019821935};\\\", \\\"{x:405,y:592,t:1527019821952};\\\", \\\"{x:402,y:593,t:1527019821969};\\\", \\\"{x:401,y:594,t:1527019822000};\\\", \\\"{x:399,y:595,t:1527019822019};\\\", \\\"{x:395,y:597,t:1527019822036};\\\", \\\"{x:387,y:599,t:1527019822053};\\\", \\\"{x:386,y:600,t:1527019822069};\\\", \\\"{x:382,y:601,t:1527019822129};\\\", \\\"{x:379,y:602,t:1527019822143};\\\", \\\"{x:376,y:602,t:1527019822154};\\\", \\\"{x:366,y:602,t:1527019822169};\\\", \\\"{x:351,y:602,t:1527019822186};\\\", \\\"{x:338,y:602,t:1527019822204};\\\", \\\"{x:324,y:602,t:1527019822220};\\\", \\\"{x:307,y:602,t:1527019822236};\\\", \\\"{x:284,y:606,t:1527019822254};\\\", \\\"{x:269,y:613,t:1527019822270};\\\", \\\"{x:250,y:618,t:1527019822286};\\\", \\\"{x:240,y:621,t:1527019822302};\\\", \\\"{x:236,y:622,t:1527019822320};\\\", \\\"{x:231,y:620,t:1527019822336};\\\", \\\"{x:230,y:620,t:1527019822353};\\\", \\\"{x:226,y:620,t:1527019822370};\\\", \\\"{x:226,y:621,t:1527019822387};\\\", \\\"{x:223,y:621,t:1527019822403};\\\", \\\"{x:218,y:623,t:1527019822420};\\\", \\\"{x:216,y:623,t:1527019822436};\\\", \\\"{x:215,y:623,t:1527019822456};\\\", \\\"{x:213,y:623,t:1527019822469};\\\", \\\"{x:210,y:623,t:1527019822486};\\\", \\\"{x:207,y:625,t:1527019822503};\\\", \\\"{x:200,y:628,t:1527019822519};\\\", \\\"{x:184,y:635,t:1527019822537};\\\", \\\"{x:178,y:639,t:1527019822554};\\\", \\\"{x:175,y:639,t:1527019822569};\\\", \\\"{x:169,y:642,t:1527019822587};\\\", \\\"{x:165,y:645,t:1527019822604};\\\", \\\"{x:158,y:649,t:1527019822619};\\\", \\\"{x:153,y:652,t:1527019822636};\\\", \\\"{x:145,y:655,t:1527019822654};\\\", \\\"{x:140,y:658,t:1527019822669};\\\", \\\"{x:138,y:659,t:1527019822686};\\\", \\\"{x:137,y:660,t:1527019822703};\\\", \\\"{x:137,y:659,t:1527019822944};\\\", \\\"{x:138,y:658,t:1527019822953};\\\", \\\"{x:138,y:657,t:1527019822971};\\\", \\\"{x:139,y:657,t:1527019822986};\\\", \\\"{x:140,y:657,t:1527019823265};\\\", \\\"{x:151,y:660,t:1527019823273};\\\", \\\"{x:164,y:666,t:1527019823288};\\\", \\\"{x:199,y:678,t:1527019823304};\\\", \\\"{x:251,y:694,t:1527019823320};\\\", \\\"{x:277,y:702,t:1527019823337};\\\", \\\"{x:288,y:705,t:1527019823354};\\\", \\\"{x:294,y:709,t:1527019823371};\\\", \\\"{x:301,y:709,t:1527019823387};\\\", \\\"{x:310,y:711,t:1527019823404};\\\", \\\"{x:320,y:714,t:1527019823421};\\\", \\\"{x:327,y:717,t:1527019823437};\\\", \\\"{x:335,y:720,t:1527019823453};\\\", \\\"{x:344,y:720,t:1527019823470};\\\", \\\"{x:358,y:722,t:1527019823488};\\\", \\\"{x:368,y:723,t:1527019823504};\\\", \\\"{x:381,y:726,t:1527019823520};\\\", \\\"{x:391,y:727,t:1527019823537};\\\", \\\"{x:396,y:727,t:1527019823554};\\\", \\\"{x:398,y:727,t:1527019823570};\\\", \\\"{x:398,y:726,t:1527019823600};\\\", \\\"{x:390,y:721,t:1527019823609};\\\", \\\"{x:379,y:716,t:1527019823621};\\\", \\\"{x:360,y:705,t:1527019823638};\\\", \\\"{x:329,y:695,t:1527019823654};\\\", \\\"{x:295,y:685,t:1527019823671};\\\", \\\"{x:263,y:673,t:1527019823689};\\\", \\\"{x:257,y:670,t:1527019823705};\\\", \\\"{x:254,y:669,t:1527019823722};\\\", \\\"{x:250,y:666,t:1527019823737};\\\", \\\"{x:241,y:663,t:1527019823755};\\\", \\\"{x:229,y:660,t:1527019823772};\\\", \\\"{x:219,y:657,t:1527019823788};\\\", \\\"{x:212,y:656,t:1527019823804};\\\", \\\"{x:202,y:655,t:1527019823821};\\\", \\\"{x:192,y:655,t:1527019823838};\\\", \\\"{x:179,y:655,t:1527019823854};\\\", \\\"{x:174,y:655,t:1527019823871};\\\", \\\"{x:171,y:655,t:1527019823887};\\\", \\\"{x:166,y:655,t:1527019823903};\\\", \\\"{x:164,y:655,t:1527019823921};\\\", \\\"{x:162,y:655,t:1527019823937};\\\", \\\"{x:160,y:655,t:1527019823954};\\\", \\\"{x:160,y:657,t:1527019824216};\\\", \\\"{x:167,y:661,t:1527019824223};\\\", \\\"{x:182,y:668,t:1527019824238};\\\", \\\"{x:207,y:680,t:1527019824255};\\\", \\\"{x:239,y:696,t:1527019824271};\\\", \\\"{x:263,y:707,t:1527019824287};\\\", \\\"{x:304,y:725,t:1527019824304};\\\", \\\"{x:321,y:726,t:1527019824321};\\\", \\\"{x:343,y:729,t:1527019824337};\\\", \\\"{x:357,y:730,t:1527019824355};\\\", \\\"{x:373,y:730,t:1527019824371};\\\", \\\"{x:390,y:730,t:1527019824387};\\\", \\\"{x:403,y:730,t:1527019824404};\\\", \\\"{x:415,y:730,t:1527019824422};\\\", \\\"{x:424,y:730,t:1527019824437};\\\", \\\"{x:430,y:730,t:1527019824454};\\\", \\\"{x:434,y:729,t:1527019824472};\\\", \\\"{x:439,y:727,t:1527019824487};\\\", \\\"{x:440,y:726,t:1527019824505};\\\", \\\"{x:441,y:725,t:1527019824522};\\\", \\\"{x:443,y:722,t:1527019824538};\\\", \\\"{x:444,y:722,t:1527019824555};\\\", \\\"{x:448,y:722,t:1527019824573};\\\", \\\"{x:454,y:722,t:1527019824589};\\\", \\\"{x:462,y:725,t:1527019824604};\\\", \\\"{x:467,y:728,t:1527019824621};\\\", \\\"{x:469,y:730,t:1527019824638};\\\", \\\"{x:469,y:731,t:1527019824944};\\\", \\\"{x:469,y:732,t:1527019824955};\\\", \\\"{x:471,y:738,t:1527019824971};\\\", \\\"{x:480,y:751,t:1527019824988};\\\", \\\"{x:501,y:766,t:1527019825005};\\\", \\\"{x:521,y:781,t:1527019825021};\\\", \\\"{x:545,y:794,t:1527019825038};\\\", \\\"{x:561,y:802,t:1527019825056};\\\", \\\"{x:563,y:802,t:1527019825072};\\\" ] }, { \\\"rt\\\": 9440, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 459136, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:563,y:801,t:1527019826344};\\\", \\\"{x:561,y:799,t:1527019826357};\\\", \\\"{x:559,y:797,t:1527019826373};\\\", \\\"{x:557,y:797,t:1527019826389};\\\", \\\"{x:556,y:797,t:1527019826640};\\\", \\\"{x:554,y:795,t:1527019826656};\\\", \\\"{x:552,y:794,t:1527019826673};\\\", \\\"{x:552,y:788,t:1527019826689};\\\", \\\"{x:549,y:774,t:1527019826706};\\\", \\\"{x:543,y:752,t:1527019826723};\\\", \\\"{x:532,y:691,t:1527019826739};\\\", \\\"{x:523,y:634,t:1527019826756};\\\", \\\"{x:512,y:588,t:1527019826774};\\\", \\\"{x:503,y:552,t:1527019826790};\\\", \\\"{x:496,y:527,t:1527019826807};\\\", \\\"{x:491,y:500,t:1527019826824};\\\", \\\"{x:490,y:489,t:1527019826839};\\\", \\\"{x:487,y:477,t:1527019826856};\\\", \\\"{x:486,y:470,t:1527019826873};\\\", \\\"{x:485,y:467,t:1527019826890};\\\", \\\"{x:485,y:466,t:1527019826912};\\\", \\\"{x:485,y:465,t:1527019826935};\\\", \\\"{x:485,y:464,t:1527019826944};\\\", \\\"{x:484,y:462,t:1527019826960};\\\", \\\"{x:483,y:461,t:1527019826973};\\\", \\\"{x:481,y:456,t:1527019826990};\\\", \\\"{x:478,y:452,t:1527019827008};\\\", \\\"{x:477,y:451,t:1527019827023};\\\", \\\"{x:475,y:446,t:1527019827041};\\\", \\\"{x:474,y:445,t:1527019827064};\\\", \\\"{x:474,y:444,t:1527019827089};\\\", \\\"{x:474,y:443,t:1527019827104};\\\", \\\"{x:474,y:442,t:1527019827112};\\\", \\\"{x:475,y:439,t:1527019827128};\\\", \\\"{x:477,y:435,t:1527019827142};\\\", \\\"{x:483,y:430,t:1527019827158};\\\", \\\"{x:484,y:430,t:1527019827174};\\\", \\\"{x:486,y:429,t:1527019827192};\\\", \\\"{x:487,y:429,t:1527019827208};\\\", \\\"{x:491,y:430,t:1527019827225};\\\", \\\"{x:495,y:437,t:1527019827241};\\\", \\\"{x:499,y:443,t:1527019827259};\\\", \\\"{x:502,y:447,t:1527019827275};\\\", \\\"{x:505,y:450,t:1527019827292};\\\", \\\"{x:506,y:451,t:1527019827309};\\\", \\\"{x:507,y:452,t:1527019827326};\\\", \\\"{x:508,y:452,t:1527019827342};\\\", \\\"{x:509,y:453,t:1527019827359};\\\", \\\"{x:511,y:454,t:1527019827385};\\\", \\\"{x:513,y:454,t:1527019827428};\\\", \\\"{x:516,y:454,t:1527019827442};\\\", \\\"{x:520,y:454,t:1527019827459};\\\", \\\"{x:525,y:454,t:1527019827475};\\\", \\\"{x:529,y:454,t:1527019827493};\\\", \\\"{x:530,y:454,t:1527019827509};\\\", \\\"{x:531,y:454,t:1527019827528};\\\", \\\"{x:532,y:454,t:1527019827544};\\\", \\\"{x:533,y:454,t:1527019827560};\\\", \\\"{x:535,y:454,t:1527019828192};\\\", \\\"{x:539,y:454,t:1527019828200};\\\", \\\"{x:544,y:454,t:1527019828213};\\\", \\\"{x:552,y:454,t:1527019828229};\\\", \\\"{x:557,y:454,t:1527019828246};\\\", \\\"{x:560,y:454,t:1527019828263};\\\", \\\"{x:561,y:454,t:1527019828279};\\\", \\\"{x:562,y:453,t:1527019828497};\\\", \\\"{x:563,y:453,t:1527019828576};\\\", \\\"{x:564,y:453,t:1527019828600};\\\", \\\"{x:565,y:453,t:1527019828614};\\\", \\\"{x:567,y:453,t:1527019828631};\\\", \\\"{x:568,y:453,t:1527019828648};\\\", \\\"{x:569,y:453,t:1527019828665};\\\", \\\"{x:570,y:453,t:1527019829057};\\\", \\\"{x:571,y:453,t:1527019829136};\\\", \\\"{x:572,y:452,t:1527019829152};\\\", \\\"{x:573,y:452,t:1527019829176};\\\", \\\"{x:576,y:451,t:1527019829192};\\\", \\\"{x:577,y:451,t:1527019829200};\\\", \\\"{x:581,y:451,t:1527019829216};\\\", \\\"{x:582,y:450,t:1527019829234};\\\", \\\"{x:584,y:450,t:1527019829250};\\\", \\\"{x:588,y:450,t:1527019829266};\\\", \\\"{x:594,y:449,t:1527019829284};\\\", \\\"{x:603,y:448,t:1527019829300};\\\", \\\"{x:611,y:448,t:1527019829317};\\\", \\\"{x:621,y:448,t:1527019829334};\\\", \\\"{x:629,y:448,t:1527019829351};\\\", \\\"{x:639,y:448,t:1527019829367};\\\", \\\"{x:670,y:448,t:1527019829384};\\\", \\\"{x:697,y:448,t:1527019829400};\\\", \\\"{x:729,y:448,t:1527019829418};\\\", \\\"{x:775,y:451,t:1527019829434};\\\", \\\"{x:852,y:460,t:1527019829451};\\\", \\\"{x:930,y:471,t:1527019829468};\\\", \\\"{x:1027,y:485,t:1527019829485};\\\", \\\"{x:1125,y:500,t:1527019829501};\\\", \\\"{x:1250,y:523,t:1527019829518};\\\", \\\"{x:1380,y:555,t:1527019829535};\\\", \\\"{x:1502,y:595,t:1527019829552};\\\", \\\"{x:1654,y:650,t:1527019829568};\\\", \\\"{x:1734,y:684,t:1527019829585};\\\", \\\"{x:1792,y:723,t:1527019829602};\\\", \\\"{x:1839,y:754,t:1527019829618};\\\", \\\"{x:1861,y:772,t:1527019829635};\\\", \\\"{x:1876,y:786,t:1527019829652};\\\", \\\"{x:1887,y:796,t:1527019829669};\\\", \\\"{x:1891,y:804,t:1527019829685};\\\", \\\"{x:1892,y:807,t:1527019829702};\\\", \\\"{x:1892,y:809,t:1527019829953};\\\", \\\"{x:1881,y:811,t:1527019829970};\\\", \\\"{x:1866,y:813,t:1527019829987};\\\", \\\"{x:1853,y:814,t:1527019830003};\\\", \\\"{x:1842,y:818,t:1527019830020};\\\", \\\"{x:1839,y:820,t:1527019830037};\\\", \\\"{x:1833,y:824,t:1527019830054};\\\", \\\"{x:1826,y:830,t:1527019830071};\\\", \\\"{x:1808,y:838,t:1527019830087};\\\", \\\"{x:1770,y:857,t:1527019830104};\\\", \\\"{x:1719,y:883,t:1527019830119};\\\", \\\"{x:1672,y:910,t:1527019830137};\\\", \\\"{x:1638,y:926,t:1527019830153};\\\", \\\"{x:1620,y:936,t:1527019830171};\\\", \\\"{x:1612,y:943,t:1527019830187};\\\", \\\"{x:1606,y:949,t:1527019830203};\\\", \\\"{x:1603,y:950,t:1527019830221};\\\", \\\"{x:1588,y:953,t:1527019830238};\\\", \\\"{x:1579,y:960,t:1527019830254};\\\", \\\"{x:1568,y:966,t:1527019830271};\\\", \\\"{x:1566,y:967,t:1527019830287};\\\", \\\"{x:1566,y:966,t:1527019830464};\\\", \\\"{x:1566,y:965,t:1527019830472};\\\", \\\"{x:1557,y:965,t:1527019830489};\\\", \\\"{x:1549,y:965,t:1527019830505};\\\", \\\"{x:1539,y:965,t:1527019830522};\\\", \\\"{x:1534,y:965,t:1527019830539};\\\", \\\"{x:1533,y:965,t:1527019830556};\\\", \\\"{x:1532,y:964,t:1527019830573};\\\", \\\"{x:1532,y:963,t:1527019830593};\\\", \\\"{x:1532,y:961,t:1527019830609};\\\", \\\"{x:1532,y:960,t:1527019830624};\\\", \\\"{x:1532,y:959,t:1527019830639};\\\", \\\"{x:1533,y:959,t:1527019830656};\\\", \\\"{x:1533,y:958,t:1527019830711};\\\", \\\"{x:1534,y:958,t:1527019830727};\\\", \\\"{x:1535,y:957,t:1527019830739};\\\", \\\"{x:1538,y:957,t:1527019830755};\\\", \\\"{x:1541,y:957,t:1527019830773};\\\", \\\"{x:1542,y:957,t:1527019830789};\\\", \\\"{x:1543,y:957,t:1527019830831};\\\", \\\"{x:1544,y:957,t:1527019830863};\\\", \\\"{x:1545,y:957,t:1527019830880};\\\", \\\"{x:1545,y:958,t:1527019830912};\\\", \\\"{x:1545,y:956,t:1527019831145};\\\", \\\"{x:1545,y:954,t:1527019831161};\\\", \\\"{x:1545,y:952,t:1527019831175};\\\", \\\"{x:1542,y:945,t:1527019831193};\\\", \\\"{x:1539,y:941,t:1527019831208};\\\", \\\"{x:1538,y:937,t:1527019831225};\\\", \\\"{x:1536,y:933,t:1527019831242};\\\", \\\"{x:1535,y:928,t:1527019831258};\\\", \\\"{x:1533,y:925,t:1527019831275};\\\", \\\"{x:1533,y:924,t:1527019831292};\\\", \\\"{x:1531,y:919,t:1527019831309};\\\", \\\"{x:1529,y:916,t:1527019831325};\\\", \\\"{x:1527,y:913,t:1527019831342};\\\", \\\"{x:1525,y:911,t:1527019831359};\\\", \\\"{x:1524,y:908,t:1527019831377};\\\", \\\"{x:1523,y:904,t:1527019831393};\\\", \\\"{x:1520,y:897,t:1527019831410};\\\", \\\"{x:1517,y:890,t:1527019831426};\\\", \\\"{x:1512,y:882,t:1527019831445};\\\", \\\"{x:1511,y:880,t:1527019831458};\\\", \\\"{x:1508,y:875,t:1527019831476};\\\", \\\"{x:1505,y:871,t:1527019831492};\\\", \\\"{x:1500,y:863,t:1527019831510};\\\", \\\"{x:1496,y:858,t:1527019831526};\\\", \\\"{x:1488,y:850,t:1527019831543};\\\", \\\"{x:1484,y:846,t:1527019831559};\\\", \\\"{x:1482,y:843,t:1527019831575};\\\", \\\"{x:1482,y:842,t:1527019831593};\\\", \\\"{x:1481,y:841,t:1527019831609};\\\", \\\"{x:1481,y:840,t:1527019831626};\\\", \\\"{x:1481,y:839,t:1527019831642};\\\", \\\"{x:1480,y:836,t:1527019831660};\\\", \\\"{x:1479,y:834,t:1527019831678};\\\", \\\"{x:1477,y:829,t:1527019831694};\\\", \\\"{x:1476,y:828,t:1527019831712};\\\", \\\"{x:1476,y:826,t:1527019832130};\\\", \\\"{x:1460,y:812,t:1527019832145};\\\", \\\"{x:1416,y:774,t:1527019832162};\\\", \\\"{x:1318,y:714,t:1527019832179};\\\", \\\"{x:1177,y:648,t:1527019832196};\\\", \\\"{x:1020,y:581,t:1527019832212};\\\", \\\"{x:878,y:535,t:1527019832231};\\\", \\\"{x:748,y:497,t:1527019832246};\\\", \\\"{x:575,y:468,t:1527019832278};\\\", \\\"{x:529,y:467,t:1527019832294};\\\", \\\"{x:495,y:467,t:1527019832310};\\\", \\\"{x:461,y:474,t:1527019832327};\\\", \\\"{x:438,y:478,t:1527019832345};\\\", \\\"{x:418,y:481,t:1527019832361};\\\", \\\"{x:392,y:488,t:1527019832378};\\\", \\\"{x:372,y:496,t:1527019832394};\\\", \\\"{x:359,y:502,t:1527019832411};\\\", \\\"{x:356,y:505,t:1527019832427};\\\", \\\"{x:355,y:506,t:1527019832444};\\\", \\\"{x:355,y:508,t:1527019832461};\\\", \\\"{x:355,y:509,t:1527019832477};\\\", \\\"{x:355,y:511,t:1527019832495};\\\", \\\"{x:352,y:519,t:1527019832512};\\\", \\\"{x:351,y:523,t:1527019832528};\\\", \\\"{x:349,y:526,t:1527019832545};\\\", \\\"{x:348,y:529,t:1527019832561};\\\", \\\"{x:348,y:530,t:1527019832664};\\\", \\\"{x:349,y:532,t:1527019832678};\\\", \\\"{x:365,y:532,t:1527019832694};\\\", \\\"{x:410,y:534,t:1527019832713};\\\", \\\"{x:440,y:537,t:1527019832728};\\\", \\\"{x:465,y:540,t:1527019832745};\\\", \\\"{x:492,y:542,t:1527019832761};\\\", \\\"{x:502,y:543,t:1527019832778};\\\", \\\"{x:518,y:546,t:1527019832795};\\\", \\\"{x:532,y:548,t:1527019832811};\\\", \\\"{x:548,y:551,t:1527019832827};\\\", \\\"{x:562,y:553,t:1527019832845};\\\", \\\"{x:577,y:555,t:1527019832861};\\\", \\\"{x:588,y:561,t:1527019832878};\\\", \\\"{x:602,y:566,t:1527019832895};\\\", \\\"{x:608,y:569,t:1527019832911};\\\", \\\"{x:608,y:570,t:1527019832944};\\\", \\\"{x:608,y:572,t:1527019832968};\\\", \\\"{x:608,y:573,t:1527019832983};\\\", \\\"{x:607,y:574,t:1527019832994};\\\", \\\"{x:603,y:576,t:1527019833012};\\\", \\\"{x:597,y:580,t:1527019833029};\\\", \\\"{x:592,y:581,t:1527019833044};\\\", \\\"{x:589,y:582,t:1527019833061};\\\", \\\"{x:591,y:582,t:1527019833625};\\\", \\\"{x:592,y:582,t:1527019833632};\\\", \\\"{x:595,y:582,t:1527019833646};\\\", \\\"{x:596,y:582,t:1527019833663};\\\", \\\"{x:597,y:582,t:1527019833680};\\\", \\\"{x:598,y:582,t:1527019833736};\\\", \\\"{x:599,y:583,t:1527019833912};\\\", \\\"{x:597,y:595,t:1527019833931};\\\", \\\"{x:591,y:610,t:1527019833946};\\\", \\\"{x:585,y:629,t:1527019833962};\\\", \\\"{x:578,y:646,t:1527019833978};\\\", \\\"{x:574,y:656,t:1527019833995};\\\", \\\"{x:572,y:661,t:1527019834012};\\\", \\\"{x:569,y:666,t:1527019834028};\\\", \\\"{x:568,y:669,t:1527019834046};\\\", \\\"{x:567,y:672,t:1527019834063};\\\", \\\"{x:566,y:673,t:1527019834080};\\\", \\\"{x:566,y:675,t:1527019834095};\\\", \\\"{x:563,y:680,t:1527019834112};\\\", \\\"{x:563,y:684,t:1527019834130};\\\", \\\"{x:562,y:688,t:1527019834146};\\\", \\\"{x:560,y:690,t:1527019834162};\\\", \\\"{x:560,y:687,t:1527019834233};\\\", \\\"{x:560,y:680,t:1527019834247};\\\", \\\"{x:567,y:658,t:1527019834263};\\\", \\\"{x:587,y:632,t:1527019834280};\\\", \\\"{x:595,y:620,t:1527019834298};\\\", \\\"{x:601,y:611,t:1527019834313};\\\", \\\"{x:603,y:607,t:1527019834329};\\\", \\\"{x:603,y:606,t:1527019834345};\\\", \\\"{x:603,y:605,t:1527019834367};\\\", \\\"{x:603,y:604,t:1527019834379};\\\", \\\"{x:604,y:604,t:1527019834395};\\\", \\\"{x:604,y:601,t:1527019834413};\\\", \\\"{x:605,y:601,t:1527019834429};\\\", \\\"{x:606,y:599,t:1527019834480};\\\", \\\"{x:606,y:596,t:1527019834496};\\\", \\\"{x:609,y:588,t:1527019834513};\\\", \\\"{x:610,y:585,t:1527019834530};\\\", \\\"{x:610,y:584,t:1527019834546};\\\", \\\"{x:611,y:582,t:1527019834563};\\\", \\\"{x:611,y:581,t:1527019834608};\\\", \\\"{x:609,y:583,t:1527019834831};\\\", \\\"{x:605,y:593,t:1527019834847};\\\", \\\"{x:595,y:611,t:1527019834863};\\\", \\\"{x:586,y:630,t:1527019834879};\\\", \\\"{x:581,y:645,t:1527019834896};\\\", \\\"{x:576,y:657,t:1527019834912};\\\", \\\"{x:571,y:672,t:1527019834930};\\\", \\\"{x:568,y:685,t:1527019834947};\\\", \\\"{x:568,y:694,t:1527019834963};\\\", \\\"{x:566,y:698,t:1527019834979};\\\", \\\"{x:565,y:703,t:1527019834997};\\\", \\\"{x:565,y:706,t:1527019835012};\\\", \\\"{x:565,y:712,t:1527019835030};\\\", \\\"{x:564,y:715,t:1527019835047};\\\", \\\"{x:563,y:717,t:1527019835063};\\\", \\\"{x:563,y:719,t:1527019835079};\\\", \\\"{x:561,y:721,t:1527019835098};\\\", \\\"{x:561,y:722,t:1527019835112};\\\", \\\"{x:560,y:723,t:1527019835129};\\\", \\\"{x:560,y:725,t:1527019835147};\\\", \\\"{x:559,y:725,t:1527019835164};\\\", \\\"{x:558,y:726,t:1527019835183};\\\", \\\"{x:556,y:727,t:1527019835199};\\\", \\\"{x:555,y:727,t:1527019835213};\\\", \\\"{x:554,y:728,t:1527019835231};\\\", \\\"{x:554,y:729,t:1527019835247};\\\", \\\"{x:551,y:729,t:1527019835263};\\\", \\\"{x:549,y:729,t:1527019835280};\\\", \\\"{x:545,y:730,t:1527019835297};\\\", \\\"{x:541,y:732,t:1527019835313};\\\", \\\"{x:540,y:732,t:1527019835331};\\\", \\\"{x:539,y:732,t:1527019835346};\\\", \\\"{x:538,y:732,t:1527019835506};\\\", \\\"{x:538,y:731,t:1527019835599};\\\", \\\"{x:539,y:730,t:1527019835613};\\\", \\\"{x:545,y:727,t:1527019835630};\\\", \\\"{x:559,y:725,t:1527019835646};\\\", \\\"{x:577,y:724,t:1527019835663};\\\", \\\"{x:594,y:724,t:1527019835681};\\\", \\\"{x:601,y:724,t:1527019835697};\\\", \\\"{x:603,y:725,t:1527019835713};\\\", \\\"{x:605,y:725,t:1527019835731};\\\" ] }, { \\\"rt\\\": 14134, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 474552, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X -K -K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:606,y:724,t:1527019837224};\\\", \\\"{x:606,y:713,t:1527019837232};\\\", \\\"{x:595,y:693,t:1527019837248};\\\", \\\"{x:571,y:645,t:1527019837265};\\\", \\\"{x:397,y:463,t:1527019837353};\\\", \\\"{x:382,y:453,t:1527019837369};\\\", \\\"{x:377,y:449,t:1527019837382};\\\", \\\"{x:365,y:443,t:1527019837398};\\\", \\\"{x:361,y:441,t:1527019837414};\\\", \\\"{x:360,y:439,t:1527019837432};\\\", \\\"{x:361,y:438,t:1527019837567};\\\", \\\"{x:362,y:436,t:1527019837583};\\\", \\\"{x:363,y:436,t:1527019837599};\\\", \\\"{x:365,y:436,t:1527019837615};\\\", \\\"{x:371,y:436,t:1527019837631};\\\", \\\"{x:374,y:436,t:1527019837649};\\\", \\\"{x:379,y:437,t:1527019837665};\\\", \\\"{x:386,y:440,t:1527019837682};\\\", \\\"{x:394,y:441,t:1527019837698};\\\", \\\"{x:403,y:442,t:1527019837715};\\\", \\\"{x:407,y:442,t:1527019837732};\\\", \\\"{x:411,y:444,t:1527019837748};\\\", \\\"{x:415,y:444,t:1527019837765};\\\", \\\"{x:418,y:444,t:1527019837782};\\\", \\\"{x:421,y:444,t:1527019837799};\\\", \\\"{x:425,y:444,t:1527019837815};\\\", \\\"{x:429,y:444,t:1527019837832};\\\", \\\"{x:435,y:444,t:1527019837848};\\\", \\\"{x:440,y:445,t:1527019837865};\\\", \\\"{x:448,y:445,t:1527019837882};\\\", \\\"{x:455,y:445,t:1527019837900};\\\", \\\"{x:464,y:445,t:1527019837917};\\\", \\\"{x:468,y:445,t:1527019837932};\\\", \\\"{x:470,y:445,t:1527019837949};\\\", \\\"{x:471,y:445,t:1527019838008};\\\", \\\"{x:473,y:445,t:1527019838024};\\\", \\\"{x:475,y:445,t:1527019838032};\\\", \\\"{x:477,y:445,t:1527019838050};\\\", \\\"{x:478,y:445,t:1527019838066};\\\", \\\"{x:481,y:445,t:1527019838082};\\\", \\\"{x:484,y:444,t:1527019838099};\\\", \\\"{x:486,y:444,t:1527019838128};\\\", \\\"{x:488,y:443,t:1527019838144};\\\", \\\"{x:490,y:443,t:1527019838160};\\\", \\\"{x:491,y:443,t:1527019838168};\\\", \\\"{x:493,y:443,t:1527019838182};\\\", \\\"{x:495,y:443,t:1527019838200};\\\", \\\"{x:497,y:443,t:1527019838216};\\\", \\\"{x:499,y:443,t:1527019838232};\\\", \\\"{x:501,y:443,t:1527019838249};\\\", \\\"{x:503,y:443,t:1527019838266};\\\", \\\"{x:507,y:442,t:1527019838282};\\\", \\\"{x:509,y:442,t:1527019838299};\\\", \\\"{x:510,y:442,t:1527019838320};\\\", \\\"{x:511,y:442,t:1527019838336};\\\", \\\"{x:512,y:442,t:1527019838349};\\\", \\\"{x:514,y:441,t:1527019838367};\\\", \\\"{x:516,y:441,t:1527019838383};\\\", \\\"{x:520,y:441,t:1527019838399};\\\", \\\"{x:524,y:441,t:1527019838416};\\\", \\\"{x:527,y:440,t:1527019838433};\\\", \\\"{x:530,y:440,t:1527019838449};\\\", \\\"{x:531,y:440,t:1527019838466};\\\", \\\"{x:535,y:440,t:1527019838484};\\\", \\\"{x:540,y:440,t:1527019838499};\\\", \\\"{x:552,y:440,t:1527019838517};\\\", \\\"{x:565,y:440,t:1527019838533};\\\", \\\"{x:581,y:440,t:1527019838549};\\\", \\\"{x:600,y:440,t:1527019838566};\\\", \\\"{x:615,y:440,t:1527019838582};\\\", \\\"{x:627,y:440,t:1527019838599};\\\", \\\"{x:633,y:440,t:1527019838616};\\\", \\\"{x:625,y:440,t:1527019838729};\\\", \\\"{x:615,y:443,t:1527019838736};\\\", \\\"{x:604,y:444,t:1527019838749};\\\", \\\"{x:582,y:444,t:1527019838766};\\\", \\\"{x:565,y:444,t:1527019838784};\\\", \\\"{x:552,y:444,t:1527019838799};\\\", \\\"{x:539,y:444,t:1527019838815};\\\", \\\"{x:528,y:444,t:1527019838833};\\\", \\\"{x:515,y:444,t:1527019838849};\\\", \\\"{x:498,y:444,t:1527019838866};\\\", \\\"{x:473,y:444,t:1527019838883};\\\", \\\"{x:450,y:444,t:1527019838900};\\\", \\\"{x:427,y:444,t:1527019838916};\\\", \\\"{x:412,y:444,t:1527019838933};\\\", \\\"{x:405,y:444,t:1527019838950};\\\", \\\"{x:404,y:445,t:1527019838992};\\\", \\\"{x:403,y:446,t:1527019839007};\\\", \\\"{x:402,y:447,t:1527019839016};\\\", \\\"{x:400,y:450,t:1527019839033};\\\", \\\"{x:399,y:451,t:1527019839050};\\\", \\\"{x:397,y:452,t:1527019839066};\\\", \\\"{x:397,y:453,t:1527019839083};\\\", \\\"{x:397,y:454,t:1527019839100};\\\", \\\"{x:397,y:455,t:1527019839120};\\\", \\\"{x:397,y:457,t:1527019839134};\\\", \\\"{x:397,y:458,t:1527019839150};\\\", \\\"{x:397,y:460,t:1527019839166};\\\", \\\"{x:397,y:464,t:1527019839184};\\\", \\\"{x:401,y:467,t:1527019839200};\\\", \\\"{x:402,y:468,t:1527019839216};\\\", \\\"{x:405,y:468,t:1527019839233};\\\", \\\"{x:411,y:468,t:1527019839250};\\\", \\\"{x:415,y:470,t:1527019839266};\\\", \\\"{x:422,y:471,t:1527019839283};\\\", \\\"{x:429,y:471,t:1527019839301};\\\", \\\"{x:435,y:472,t:1527019839316};\\\", \\\"{x:439,y:474,t:1527019839333};\\\", \\\"{x:443,y:474,t:1527019839350};\\\", \\\"{x:447,y:474,t:1527019839366};\\\", \\\"{x:454,y:474,t:1527019839383};\\\", \\\"{x:459,y:474,t:1527019839400};\\\", \\\"{x:462,y:474,t:1527019839417};\\\", \\\"{x:465,y:474,t:1527019839434};\\\", \\\"{x:467,y:474,t:1527019839451};\\\", \\\"{x:468,y:474,t:1527019839467};\\\", \\\"{x:471,y:474,t:1527019839483};\\\", \\\"{x:473,y:474,t:1527019839500};\\\", \\\"{x:477,y:474,t:1527019839518};\\\", \\\"{x:480,y:474,t:1527019839534};\\\", \\\"{x:482,y:474,t:1527019839550};\\\", \\\"{x:484,y:474,t:1527019839567};\\\", \\\"{x:487,y:474,t:1527019839584};\\\", \\\"{x:488,y:474,t:1527019839600};\\\", \\\"{x:489,y:473,t:1527019839640};\\\", \\\"{x:490,y:473,t:1527019839664};\\\", \\\"{x:491,y:473,t:1527019839696};\\\", \\\"{x:492,y:473,t:1527019839704};\\\", \\\"{x:493,y:473,t:1527019839717};\\\", \\\"{x:495,y:473,t:1527019839734};\\\", \\\"{x:497,y:473,t:1527019839750};\\\", \\\"{x:502,y:473,t:1527019839767};\\\", \\\"{x:505,y:473,t:1527019839784};\\\", \\\"{x:512,y:473,t:1527019839799};\\\", \\\"{x:516,y:473,t:1527019839817};\\\", \\\"{x:521,y:474,t:1527019839833};\\\", \\\"{x:525,y:475,t:1527019839850};\\\", \\\"{x:528,y:475,t:1527019839867};\\\", \\\"{x:532,y:475,t:1527019839884};\\\", \\\"{x:534,y:475,t:1527019839900};\\\", \\\"{x:538,y:475,t:1527019839917};\\\", \\\"{x:545,y:475,t:1527019839934};\\\", \\\"{x:553,y:476,t:1527019839950};\\\", \\\"{x:557,y:476,t:1527019839967};\\\", \\\"{x:563,y:476,t:1527019839984};\\\", \\\"{x:565,y:476,t:1527019840000};\\\", \\\"{x:566,y:476,t:1527019840017};\\\", \\\"{x:567,y:476,t:1527019840034};\\\", \\\"{x:568,y:476,t:1527019840056};\\\", \\\"{x:569,y:476,t:1527019840079};\\\", \\\"{x:570,y:476,t:1527019840136};\\\", \\\"{x:572,y:476,t:1527019840192};\\\", \\\"{x:573,y:476,t:1527019840200};\\\", \\\"{x:575,y:476,t:1527019840217};\\\", \\\"{x:580,y:476,t:1527019840234};\\\", \\\"{x:585,y:478,t:1527019840250};\\\", \\\"{x:592,y:479,t:1527019840267};\\\", \\\"{x:606,y:484,t:1527019840284};\\\", \\\"{x:616,y:486,t:1527019840300};\\\", \\\"{x:625,y:488,t:1527019840317};\\\", \\\"{x:629,y:489,t:1527019840333};\\\", \\\"{x:633,y:491,t:1527019840350};\\\", \\\"{x:634,y:491,t:1527019840367};\\\", \\\"{x:636,y:491,t:1527019840391};\\\", \\\"{x:637,y:491,t:1527019840400};\\\", \\\"{x:641,y:493,t:1527019840745};\\\", \\\"{x:643,y:494,t:1527019840751};\\\", \\\"{x:648,y:495,t:1527019840767};\\\", \\\"{x:669,y:503,t:1527019840785};\\\", \\\"{x:694,y:506,t:1527019840801};\\\", \\\"{x:742,y:514,t:1527019840818};\\\", \\\"{x:797,y:518,t:1527019840834};\\\", \\\"{x:836,y:524,t:1527019840850};\\\", \\\"{x:888,y:536,t:1527019840868};\\\", \\\"{x:943,y:549,t:1527019840885};\\\", \\\"{x:1005,y:568,t:1527019840901};\\\", \\\"{x:1069,y:587,t:1527019840918};\\\", \\\"{x:1129,y:613,t:1527019840934};\\\", \\\"{x:1176,y:640,t:1527019840951};\\\", \\\"{x:1277,y:701,t:1527019840968};\\\", \\\"{x:1340,y:755,t:1527019840985};\\\", \\\"{x:1391,y:804,t:1527019841001};\\\", \\\"{x:1434,y:847,t:1527019841018};\\\", \\\"{x:1461,y:874,t:1527019841034};\\\", \\\"{x:1476,y:900,t:1527019841050};\\\", \\\"{x:1484,y:924,t:1527019841068};\\\", \\\"{x:1493,y:947,t:1527019841085};\\\", \\\"{x:1497,y:965,t:1527019841101};\\\", \\\"{x:1507,y:981,t:1527019841118};\\\", \\\"{x:1513,y:991,t:1527019841135};\\\", \\\"{x:1525,y:1006,t:1527019841151};\\\", \\\"{x:1530,y:1012,t:1527019841168};\\\", \\\"{x:1535,y:1020,t:1527019841185};\\\", \\\"{x:1539,y:1026,t:1527019841201};\\\", \\\"{x:1541,y:1027,t:1527019841217};\\\", \\\"{x:1541,y:1028,t:1527019841235};\\\", \\\"{x:1541,y:1029,t:1527019841255};\\\", \\\"{x:1537,y:1029,t:1527019841268};\\\", \\\"{x:1531,y:1029,t:1527019841284};\\\", \\\"{x:1517,y:1021,t:1527019841302};\\\", \\\"{x:1504,y:1012,t:1527019841318};\\\", \\\"{x:1491,y:1001,t:1527019841335};\\\", \\\"{x:1484,y:988,t:1527019841352};\\\", \\\"{x:1483,y:984,t:1527019841368};\\\", \\\"{x:1483,y:979,t:1527019841385};\\\", \\\"{x:1483,y:974,t:1527019841402};\\\", \\\"{x:1483,y:969,t:1527019841418};\\\", \\\"{x:1482,y:960,t:1527019841435};\\\", \\\"{x:1480,y:956,t:1527019841452};\\\", \\\"{x:1480,y:955,t:1527019841468};\\\", \\\"{x:1480,y:952,t:1527019841485};\\\", \\\"{x:1479,y:952,t:1527019841502};\\\", \\\"{x:1479,y:951,t:1527019841519};\\\", \\\"{x:1479,y:952,t:1527019841768};\\\", \\\"{x:1479,y:953,t:1527019841786};\\\", \\\"{x:1479,y:954,t:1527019841803};\\\", \\\"{x:1480,y:953,t:1527019842625};\\\", \\\"{x:1480,y:950,t:1527019842637};\\\", \\\"{x:1481,y:941,t:1527019842654};\\\", \\\"{x:1481,y:932,t:1527019842669};\\\", \\\"{x:1481,y:925,t:1527019842686};\\\", \\\"{x:1481,y:920,t:1527019842703};\\\", \\\"{x:1481,y:918,t:1527019842719};\\\", \\\"{x:1482,y:916,t:1527019842736};\\\", \\\"{x:1482,y:914,t:1527019842753};\\\", \\\"{x:1483,y:910,t:1527019842770};\\\", \\\"{x:1484,y:908,t:1527019842786};\\\", \\\"{x:1484,y:907,t:1527019842804};\\\", \\\"{x:1484,y:905,t:1527019842820};\\\", \\\"{x:1484,y:904,t:1527019842836};\\\", \\\"{x:1484,y:902,t:1527019842853};\\\", \\\"{x:1484,y:901,t:1527019842870};\\\", \\\"{x:1484,y:899,t:1527019842886};\\\", \\\"{x:1484,y:894,t:1527019842903};\\\", \\\"{x:1484,y:892,t:1527019842919};\\\", \\\"{x:1484,y:888,t:1527019842936};\\\", \\\"{x:1484,y:886,t:1527019842953};\\\", \\\"{x:1484,y:884,t:1527019842969};\\\", \\\"{x:1484,y:883,t:1527019842986};\\\", \\\"{x:1484,y:882,t:1527019843003};\\\", \\\"{x:1484,y:880,t:1527019843019};\\\", \\\"{x:1485,y:878,t:1527019843036};\\\", \\\"{x:1485,y:875,t:1527019843053};\\\", \\\"{x:1485,y:872,t:1527019843070};\\\", \\\"{x:1485,y:870,t:1527019843087};\\\", \\\"{x:1484,y:867,t:1527019843104};\\\", \\\"{x:1484,y:866,t:1527019843120};\\\", \\\"{x:1484,y:865,t:1527019843136};\\\", \\\"{x:1484,y:863,t:1527019843159};\\\", \\\"{x:1483,y:863,t:1527019843176};\\\", \\\"{x:1482,y:862,t:1527019843186};\\\", \\\"{x:1482,y:861,t:1527019843208};\\\", \\\"{x:1482,y:860,t:1527019843221};\\\", \\\"{x:1482,y:859,t:1527019843240};\\\", \\\"{x:1482,y:858,t:1527019843253};\\\", \\\"{x:1480,y:857,t:1527019843270};\\\", \\\"{x:1480,y:855,t:1527019843288};\\\", \\\"{x:1479,y:855,t:1527019843312};\\\", \\\"{x:1479,y:853,t:1527019843384};\\\", \\\"{x:1479,y:852,t:1527019843441};\\\", \\\"{x:1479,y:851,t:1527019843454};\\\", \\\"{x:1479,y:850,t:1527019843471};\\\", \\\"{x:1480,y:849,t:1527019843487};\\\", \\\"{x:1480,y:848,t:1527019843504};\\\", \\\"{x:1480,y:846,t:1527019843521};\\\", \\\"{x:1480,y:845,t:1527019843552};\\\", \\\"{x:1480,y:844,t:1527019843585};\\\", \\\"{x:1481,y:843,t:1527019843592};\\\", \\\"{x:1482,y:843,t:1527019843632};\\\", \\\"{x:1482,y:842,t:1527019843689};\\\", \\\"{x:1482,y:841,t:1527019843728};\\\", \\\"{x:1482,y:840,t:1527019843744};\\\", \\\"{x:1482,y:839,t:1527019843816};\\\", \\\"{x:1482,y:838,t:1527019843840};\\\", \\\"{x:1482,y:837,t:1527019843880};\\\", \\\"{x:1482,y:836,t:1527019843929};\\\", \\\"{x:1482,y:835,t:1527019843963};\\\", \\\"{x:1482,y:834,t:1527019843987};\\\", \\\"{x:1482,y:833,t:1527019844015};\\\", \\\"{x:1481,y:833,t:1527019844023};\\\", \\\"{x:1481,y:832,t:1527019845233};\\\", \\\"{x:1481,y:828,t:1527019845240};\\\", \\\"{x:1481,y:825,t:1527019845255};\\\", \\\"{x:1481,y:820,t:1527019845273};\\\", \\\"{x:1481,y:817,t:1527019845287};\\\", \\\"{x:1481,y:816,t:1527019845312};\\\", \\\"{x:1481,y:815,t:1527019845327};\\\", \\\"{x:1481,y:814,t:1527019845339};\\\", \\\"{x:1481,y:812,t:1527019845360};\\\", \\\"{x:1481,y:810,t:1527019845376};\\\", \\\"{x:1481,y:809,t:1527019845392};\\\", \\\"{x:1481,y:808,t:1527019845405};\\\", \\\"{x:1479,y:806,t:1527019845422};\\\", \\\"{x:1479,y:805,t:1527019845440};\\\", \\\"{x:1479,y:802,t:1527019845456};\\\", \\\"{x:1478,y:797,t:1527019845472};\\\", \\\"{x:1478,y:794,t:1527019845488};\\\", \\\"{x:1475,y:789,t:1527019845505};\\\", \\\"{x:1473,y:780,t:1527019845522};\\\", \\\"{x:1473,y:774,t:1527019845538};\\\", \\\"{x:1472,y:770,t:1527019845555};\\\", \\\"{x:1472,y:766,t:1527019845571};\\\", \\\"{x:1472,y:762,t:1527019845588};\\\", \\\"{x:1472,y:760,t:1527019845606};\\\", \\\"{x:1472,y:759,t:1527019845622};\\\", \\\"{x:1472,y:756,t:1527019845639};\\\", \\\"{x:1472,y:754,t:1527019845656};\\\", \\\"{x:1472,y:753,t:1527019845672};\\\", \\\"{x:1472,y:752,t:1527019845689};\\\", \\\"{x:1472,y:749,t:1527019845705};\\\", \\\"{x:1472,y:746,t:1527019845722};\\\", \\\"{x:1472,y:744,t:1527019845738};\\\", \\\"{x:1472,y:740,t:1527019845756};\\\", \\\"{x:1472,y:738,t:1527019845772};\\\", \\\"{x:1472,y:733,t:1527019845789};\\\", \\\"{x:1472,y:731,t:1527019845805};\\\", \\\"{x:1472,y:726,t:1527019845822};\\\", \\\"{x:1472,y:723,t:1527019845839};\\\", \\\"{x:1472,y:719,t:1527019845856};\\\", \\\"{x:1472,y:713,t:1527019845872};\\\", \\\"{x:1472,y:709,t:1527019845889};\\\", \\\"{x:1472,y:705,t:1527019845906};\\\", \\\"{x:1472,y:701,t:1527019845923};\\\", \\\"{x:1472,y:695,t:1527019845938};\\\", \\\"{x:1472,y:690,t:1527019845955};\\\", \\\"{x:1472,y:686,t:1527019845972};\\\", \\\"{x:1472,y:680,t:1527019845988};\\\", \\\"{x:1472,y:674,t:1527019846005};\\\", \\\"{x:1471,y:670,t:1527019846022};\\\", \\\"{x:1470,y:666,t:1527019846039};\\\", \\\"{x:1470,y:664,t:1527019846055};\\\", \\\"{x:1470,y:662,t:1527019846071};\\\", \\\"{x:1470,y:661,t:1527019846088};\\\", \\\"{x:1470,y:659,t:1527019846105};\\\", \\\"{x:1470,y:657,t:1527019846122};\\\", \\\"{x:1468,y:649,t:1527019846138};\\\", \\\"{x:1468,y:646,t:1527019846155};\\\", \\\"{x:1468,y:638,t:1527019846172};\\\", \\\"{x:1468,y:627,t:1527019846188};\\\", \\\"{x:1468,y:614,t:1527019846205};\\\", \\\"{x:1467,y:602,t:1527019846223};\\\", \\\"{x:1467,y:593,t:1527019846239};\\\", \\\"{x:1467,y:585,t:1527019846255};\\\", \\\"{x:1467,y:581,t:1527019846272};\\\", \\\"{x:1466,y:579,t:1527019846288};\\\", \\\"{x:1466,y:575,t:1527019846305};\\\", \\\"{x:1465,y:570,t:1527019846322};\\\", \\\"{x:1465,y:567,t:1527019846339};\\\", \\\"{x:1464,y:566,t:1527019846355};\\\", \\\"{x:1464,y:564,t:1527019846372};\\\", \\\"{x:1464,y:563,t:1527019846416};\\\", \\\"{x:1464,y:561,t:1527019846431};\\\", \\\"{x:1463,y:559,t:1527019846447};\\\", \\\"{x:1463,y:558,t:1527019846472};\\\", \\\"{x:1463,y:557,t:1527019846489};\\\", \\\"{x:1463,y:556,t:1527019846506};\\\", \\\"{x:1463,y:555,t:1527019846523};\\\", \\\"{x:1462,y:554,t:1527019846539};\\\", \\\"{x:1462,y:553,t:1527019846881};\\\", \\\"{x:1462,y:551,t:1527019846889};\\\", \\\"{x:1462,y:547,t:1527019846907};\\\", \\\"{x:1465,y:542,t:1527019846922};\\\", \\\"{x:1466,y:537,t:1527019846940};\\\", \\\"{x:1468,y:532,t:1527019846957};\\\", \\\"{x:1468,y:528,t:1527019846972};\\\", \\\"{x:1470,y:522,t:1527019846990};\\\", \\\"{x:1471,y:516,t:1527019847007};\\\", \\\"{x:1474,y:508,t:1527019847022};\\\", \\\"{x:1477,y:496,t:1527019847040};\\\", \\\"{x:1478,y:490,t:1527019847056};\\\", \\\"{x:1481,y:478,t:1527019847073};\\\", \\\"{x:1483,y:472,t:1527019847089};\\\", \\\"{x:1486,y:461,t:1527019847107};\\\", \\\"{x:1487,y:454,t:1527019847122};\\\", \\\"{x:1487,y:448,t:1527019847140};\\\", \\\"{x:1489,y:444,t:1527019847157};\\\", \\\"{x:1489,y:441,t:1527019847172};\\\", \\\"{x:1489,y:438,t:1527019847190};\\\", \\\"{x:1489,y:434,t:1527019847206};\\\", \\\"{x:1489,y:427,t:1527019847223};\\\", \\\"{x:1489,y:418,t:1527019847240};\\\", \\\"{x:1489,y:414,t:1527019847257};\\\", \\\"{x:1489,y:409,t:1527019847274};\\\", \\\"{x:1489,y:403,t:1527019847289};\\\", \\\"{x:1489,y:396,t:1527019847307};\\\", \\\"{x:1489,y:385,t:1527019847324};\\\", \\\"{x:1489,y:375,t:1527019847339};\\\", \\\"{x:1489,y:361,t:1527019847357};\\\", \\\"{x:1489,y:349,t:1527019847374};\\\", \\\"{x:1489,y:343,t:1527019847390};\\\", \\\"{x:1487,y:335,t:1527019847406};\\\", \\\"{x:1485,y:322,t:1527019847424};\\\", \\\"{x:1484,y:316,t:1527019847439};\\\", \\\"{x:1482,y:309,t:1527019847457};\\\", \\\"{x:1482,y:307,t:1527019847474};\\\", \\\"{x:1481,y:305,t:1527019847489};\\\", \\\"{x:1480,y:303,t:1527019847506};\\\", \\\"{x:1479,y:298,t:1527019847524};\\\", \\\"{x:1478,y:296,t:1527019847540};\\\", \\\"{x:1478,y:295,t:1527019847556};\\\", \\\"{x:1478,y:293,t:1527019847573};\\\", \\\"{x:1477,y:290,t:1527019847591};\\\", \\\"{x:1477,y:289,t:1527019847616};\\\", \\\"{x:1477,y:290,t:1527019847832};\\\", \\\"{x:1478,y:291,t:1527019847840};\\\", \\\"{x:1478,y:292,t:1527019847865};\\\", \\\"{x:1478,y:293,t:1527019847890};\\\", \\\"{x:1478,y:297,t:1527019848032};\\\", \\\"{x:1477,y:303,t:1527019848041};\\\", \\\"{x:1468,y:324,t:1527019848057};\\\", \\\"{x:1441,y:371,t:1527019848074};\\\", \\\"{x:1388,y:436,t:1527019848090};\\\", \\\"{x:1328,y:500,t:1527019848107};\\\", \\\"{x:1258,y:554,t:1527019848124};\\\", \\\"{x:1184,y:597,t:1527019848141};\\\", \\\"{x:1119,y:630,t:1527019848157};\\\", \\\"{x:1041,y:672,t:1527019848174};\\\", \\\"{x:954,y:701,t:1527019848191};\\\", \\\"{x:890,y:720,t:1527019848206};\\\", \\\"{x:822,y:735,t:1527019848223};\\\", \\\"{x:801,y:737,t:1527019848240};\\\", \\\"{x:783,y:740,t:1527019848258};\\\", \\\"{x:764,y:741,t:1527019848274};\\\", \\\"{x:747,y:743,t:1527019848290};\\\", \\\"{x:741,y:747,t:1527019848307};\\\", \\\"{x:734,y:748,t:1527019848324};\\\", \\\"{x:730,y:748,t:1527019848340};\\\", \\\"{x:725,y:748,t:1527019848358};\\\", \\\"{x:719,y:742,t:1527019848373};\\\", \\\"{x:710,y:728,t:1527019848390};\\\", \\\"{x:694,y:692,t:1527019848408};\\\", \\\"{x:683,y:666,t:1527019848424};\\\", \\\"{x:673,y:648,t:1527019848441};\\\", \\\"{x:662,y:631,t:1527019848458};\\\", \\\"{x:655,y:623,t:1527019848473};\\\", \\\"{x:650,y:616,t:1527019848490};\\\", \\\"{x:649,y:614,t:1527019848507};\\\", \\\"{x:647,y:614,t:1527019848524};\\\", \\\"{x:644,y:614,t:1527019848541};\\\", \\\"{x:642,y:613,t:1527019848557};\\\", \\\"{x:637,y:612,t:1527019848574};\\\", \\\"{x:628,y:610,t:1527019848591};\\\", \\\"{x:619,y:607,t:1527019848608};\\\", \\\"{x:613,y:606,t:1527019848624};\\\", \\\"{x:611,y:605,t:1527019848641};\\\", \\\"{x:610,y:603,t:1527019848657};\\\", \\\"{x:609,y:601,t:1527019848674};\\\", \\\"{x:609,y:600,t:1527019848691};\\\", \\\"{x:608,y:598,t:1527019848708};\\\", \\\"{x:607,y:597,t:1527019848760};\\\", \\\"{x:606,y:597,t:1527019848775};\\\", \\\"{x:605,y:596,t:1527019848792};\\\", \\\"{x:598,y:596,t:1527019849297};\\\", \\\"{x:592,y:596,t:1527019849308};\\\", \\\"{x:575,y:598,t:1527019849326};\\\", \\\"{x:554,y:601,t:1527019849341};\\\", \\\"{x:530,y:601,t:1527019849358};\\\", \\\"{x:497,y:601,t:1527019849377};\\\", \\\"{x:476,y:601,t:1527019849391};\\\", \\\"{x:459,y:601,t:1527019849408};\\\", \\\"{x:443,y:601,t:1527019849425};\\\", \\\"{x:432,y:597,t:1527019849441};\\\", \\\"{x:428,y:595,t:1527019849458};\\\", \\\"{x:427,y:595,t:1527019849475};\\\", \\\"{x:426,y:595,t:1527019849559};\\\", \\\"{x:424,y:596,t:1527019849624};\\\", \\\"{x:424,y:597,t:1527019849631};\\\", \\\"{x:422,y:599,t:1527019849641};\\\", \\\"{x:416,y:605,t:1527019849658};\\\", \\\"{x:413,y:606,t:1527019849675};\\\", \\\"{x:412,y:606,t:1527019849696};\\\", \\\"{x:411,y:606,t:1527019849792};\\\", \\\"{x:410,y:606,t:1527019849824};\\\", \\\"{x:410,y:605,t:1527019849848};\\\", \\\"{x:410,y:603,t:1527019849863};\\\", \\\"{x:410,y:602,t:1527019849905};\\\", \\\"{x:408,y:606,t:1527019850119};\\\", \\\"{x:408,y:613,t:1527019850128};\\\", \\\"{x:408,y:622,t:1527019850142};\\\", \\\"{x:413,y:647,t:1527019850159};\\\", \\\"{x:423,y:663,t:1527019850175};\\\", \\\"{x:433,y:680,t:1527019850192};\\\", \\\"{x:441,y:693,t:1527019850209};\\\", \\\"{x:450,y:710,t:1527019850225};\\\", \\\"{x:458,y:725,t:1527019850242};\\\", \\\"{x:463,y:737,t:1527019850259};\\\", \\\"{x:471,y:753,t:1527019850275};\\\", \\\"{x:476,y:766,t:1527019850292};\\\", \\\"{x:482,y:778,t:1527019850311};\\\", \\\"{x:485,y:784,t:1527019850326};\\\", \\\"{x:487,y:786,t:1527019850342};\\\", \\\"{x:488,y:787,t:1527019850359};\\\", \\\"{x:489,y:788,t:1527019850375};\\\", \\\"{x:490,y:788,t:1527019850432};\\\", \\\"{x:491,y:788,t:1527019850442};\\\", \\\"{x:493,y:788,t:1527019850459};\\\", \\\"{x:494,y:788,t:1527019850476};\\\", \\\"{x:498,y:788,t:1527019850492};\\\", \\\"{x:499,y:788,t:1527019850510};\\\", \\\"{x:500,y:788,t:1527019850552};\\\", \\\"{x:501,y:788,t:1527019850568};\\\", \\\"{x:504,y:788,t:1527019850583};\\\", \\\"{x:506,y:788,t:1527019850592};\\\", \\\"{x:509,y:786,t:1527019850610};\\\", \\\"{x:512,y:782,t:1527019850627};\\\", \\\"{x:516,y:776,t:1527019850643};\\\", \\\"{x:517,y:771,t:1527019850660};\\\", \\\"{x:520,y:764,t:1527019850677};\\\", \\\"{x:520,y:760,t:1527019850692};\\\", \\\"{x:520,y:759,t:1527019850710};\\\", \\\"{x:521,y:758,t:1527019850727};\\\", \\\"{x:521,y:757,t:1527019850743};\\\", \\\"{x:525,y:760,t:1527019851176};\\\", \\\"{x:536,y:772,t:1527019851193};\\\", \\\"{x:550,y:789,t:1527019851209};\\\", \\\"{x:556,y:802,t:1527019851227};\\\" ] }, { \\\"rt\\\": 75306, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 551093, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You go to 12 p.m. on the x-axis, and then follow the right diagonal line until you see a letter(shift). In this case, it'd be M and L.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5555, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Thailand\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 557653, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 20189, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 578864, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9482, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 590821, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"H1RGT\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"H1RGT\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 194, dom: 1157, initialDom: 1256",
  "javascriptErrors": []
}