var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05223891d42e0fcc2ad6a4ef1d6bca2484e1403d"] = {
  "startTime": "2018-05-22T20:15:38.2679569Z",
  "websitePageUrl": "/16",
  "visitTime": 164243,
  "engagementTime": 162390,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "18f5ea1858c96e78e4427f6aa5688487",
    "created": "2018-05-22T20:15:38.2679569+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ZKB08",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0cb91269590ffd086aabef2db08bf691",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/18f5ea1858c96e78e4427f6aa5688487/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 251,
      "e": 251,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 251,
      "e": 251,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 623,
      "y": 671
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 59117,
      "y": 36728,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 616,
      "y": 637
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 612,
      "y": 624
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 57880,
      "y": 34124,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 611,
      "y": 610
    },
    {
      "t": 1384,
      "e": 1384,
      "ty": 6,
      "x": 610,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 609,
      "y": 598
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 605,
      "y": 579
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 57093,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 606,
      "y": 558
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 609,
      "y": 556
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 57543,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2093,
      "e": 2093,
      "ty": 3,
      "x": 609,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2095,
      "e": 2095,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2220,
      "e": 2220,
      "ty": 4,
      "x": 57543,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2220,
      "e": 2220,
      "ty": 5,
      "x": 609,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2469,
      "e": 2469,
      "ty": 7,
      "x": 693,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 2,
      "x": 853,
      "y": 622
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 4722,
      "y": 34665,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2602,
      "e": 2602,
      "ty": 2,
      "x": 1131,
      "y": 728
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 1217,
      "y": 777
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 30584,
      "y": 46411,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2802,
      "e": 2802,
      "ty": 2,
      "x": 1220,
      "y": 793
    },
    {
      "t": 2902,
      "e": 2902,
      "ty": 2,
      "x": 1188,
      "y": 836
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 1132,
      "y": 868
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 24382,
      "y": 52284,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 842,
      "y": 876
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 209,
      "y": 790
    },
    {
      "t": 3252,
      "e": 3252,
      "ty": 41,
      "x": 9094,
      "y": 42988,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 178,
      "y": 784
    },
    {
      "t": 4702,
      "e": 4702,
      "ty": 2,
      "x": 177,
      "y": 784
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 8982,
      "y": 42988,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8102,
      "e": 8102,
      "ty": 2,
      "x": 204,
      "y": 768
    },
    {
      "t": 8202,
      "e": 8202,
      "ty": 2,
      "x": 273,
      "y": 730
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 22808,
      "y": 39221,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8302,
      "e": 8302,
      "ty": 2,
      "x": 337,
      "y": 693
    },
    {
      "t": 8374,
      "e": 8374,
      "ty": 6,
      "x": 347,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 8402,
      "e": 8402,
      "ty": 2,
      "x": 356,
      "y": 670
    },
    {
      "t": 8423,
      "e": 8423,
      "ty": 7,
      "x": 400,
      "y": 643,
      "ta": "#strategyButton"
    },
    {
      "t": 8473,
      "e": 8473,
      "ty": 6,
      "x": 600,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8489,
      "e": 8489,
      "ty": 7,
      "x": 722,
      "y": 578,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 722,
      "y": 578
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 2405,
      "y": 31240,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 8602,
      "e": 8602,
      "ty": 2,
      "x": 795,
      "y": 560
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 635,
      "y": 30224,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13562,
      "e": 13562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13801,
      "e": 13801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13802,
      "e": 13802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13839,
      "e": 13839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14273,
      "e": 14273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 14369,
      "e": 14369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 14552,
      "e": 14552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14984,
      "e": 14984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 14985,
      "e": 14985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 15112,
      "e": 15112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 15273,
      "e": 15273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15273,
      "e": 15273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15352,
      "e": 15352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Yo"
    },
    {
      "t": 15481,
      "e": 15481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 15481,
      "e": 15481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15568,
      "e": 15568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 15648,
      "e": 15648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15648,
      "e": 15648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15752,
      "e": 15752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 15968,
      "e": 15968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15968,
      "e": 15968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16080,
      "e": 16080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 16096,
      "e": 16096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16097,
      "e": 16097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16168,
      "e": 16168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16312,
      "e": 16312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16313,
      "e": 16313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16431,
      "e": 16431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16456,
      "e": 16456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 16456,
      "e": 16456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16536,
      "e": 16536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 16593,
      "e": 16593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16593,
      "e": 16593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16680,
      "e": 16680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16757,
      "e": 16757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 16757,
      "e": 16757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16870,
      "e": 16870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 16982,
      "e": 16982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 16983,
      "e": 16983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17085,
      "e": 17085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 17254,
      "e": 17254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17255,
      "e": 17255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17333,
      "e": 17333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 17542,
      "e": 17542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 17543,
      "e": 17543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17629,
      "e": 17629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 17750,
      "e": 17750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17751,
      "e": 17751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17838,
      "e": 17838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17901,
      "e": 17901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17902,
      "e": 17902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17981,
      "e": 17981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18134,
      "e": 18134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18135,
      "e": 18135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18237,
      "e": 18237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18270,
      "e": 18270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18270,
      "e": 18270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18334,
      "e": 18334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18334,
      "e": 18334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18373,
      "e": 18373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 18421,
      "e": 18421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18445,
      "e": 18445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18446,
      "e": 18446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18543,
      "e": 18543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18558,
      "e": 18558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18559,
      "e": 18559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18670,
      "e": 18670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18717,
      "e": 18717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18718,
      "e": 18718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18806,
      "e": 18806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19006,
      "e": 19006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19007,
      "e": 19007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19109,
      "e": 19109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19350,
      "e": 19350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 19351,
      "e": 19351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19445,
      "e": 19445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 19742,
      "e": 19742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19743,
      "e": 19743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19829,
      "e": 19829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19983,
      "e": 19983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19983,
      "e": 19983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19999,
      "e": 19999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20078,
      "e": 20078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 20173,
      "e": 20173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20173,
      "e": 20173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20286,
      "e": 20286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20350,
      "e": 20350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20351,
      "e": 20351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20445,
      "e": 20445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20461,
      "e": 20461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20462,
      "e": 20462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20582,
      "e": 20582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20582,
      "e": 20582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20590,
      "e": 20590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 20661,
      "e": 20661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20725,
      "e": 20725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20725,
      "e": 20725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20838,
      "e": 20838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20846,
      "e": 20846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20847,
      "e": 20847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20982,
      "e": 20982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20990,
      "e": 20990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20991,
      "e": 20991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21109,
      "e": 21109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21158,
      "e": 21158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21158,
      "e": 21158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21286,
      "e": 21286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21310,
      "e": 21310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21310,
      "e": 21310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21405,
      "e": 21405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21478,
      "e": 21478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21478,
      "e": 21478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21598,
      "e": 21598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21614,
      "e": 21614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21615,
      "e": 21615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21749,
      "e": 21749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21798,
      "e": 21798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21799,
      "e": 21799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21910,
      "e": 21910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22918,
      "e": 22918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 22919,
      "e": 22919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23005,
      "e": 23005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 23022,
      "e": 23022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23022,
      "e": 23022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23110,
      "e": 23110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23230,
      "e": 23230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 23230,
      "e": 23230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23302,
      "e": 23302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 23398,
      "e": 23398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23400,
      "e": 23400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23494,
      "e": 23494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27455,
      "e": 27455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27456,
      "e": 27456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27566,
      "e": 27566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27918,
      "e": 27918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28061,
      "e": 28061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you "
    },
    {
      "t": 28093,
      "e": 28093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28094,
      "e": 28094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28174,
      "e": 28174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28294,
      "e": 28294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28295,
      "e": 28295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28374,
      "e": 28374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28462,
      "e": 28462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28462,
      "e": 28462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28549,
      "e": 28549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28598,
      "e": 28598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28598,
      "e": 28598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28702,
      "e": 28702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28918,
      "e": 28918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28919,
      "e": 28919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29038,
      "e": 29038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29061,
      "e": 29061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29062,
      "e": 29062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29150,
      "e": 29150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 29158,
      "e": 29158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29158,
      "e": 29158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29277,
      "e": 29277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29277,
      "e": 29277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29293,
      "e": 29293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 29357,
      "e": 29357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29382,
      "e": 29382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29382,
      "e": 29382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29485,
      "e": 29485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29526,
      "e": 29526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29526,
      "e": 29526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29630,
      "e": 29630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29726,
      "e": 29726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29726,
      "e": 29726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29798,
      "e": 29798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29910,
      "e": 29910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29911,
      "e": 29911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30005,
      "e": 30005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30013,
      "e": 30013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30014,
      "e": 30014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30118,
      "e": 30118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30134,
      "e": 30134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30134,
      "e": 30134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30278,
      "e": 30278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30430,
      "e": 30430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30430,
      "e": 30430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30493,
      "e": 30493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 30603,
      "e": 30603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there ar"
    },
    {
      "t": 30630,
      "e": 30630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30631,
      "e": 30631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30725,
      "e": 30725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30741,
      "e": 30741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30742,
      "e": 30742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30845,
      "e": 30845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30909,
      "e": 30909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30909,
      "e": 30909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31029,
      "e": 31029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31037,
      "e": 31037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31038,
      "e": 31038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31125,
      "e": 31125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31262,
      "e": 31262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 31263,
      "e": 31263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31357,
      "e": 31357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 31413,
      "e": 31413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31413,
      "e": 31413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31509,
      "e": 31509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31654,
      "e": 31654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31654,
      "e": 31654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31749,
      "e": 31749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31854,
      "e": 31854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31854,
      "e": 31854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31942,
      "e": 31942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32086,
      "e": 32086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32087,
      "e": 32087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32117,
      "e": 32117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32670,
      "e": 32670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32670,
      "e": 32670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32790,
      "e": 32790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32822,
      "e": 32822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32823,
      "e": 32823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32925,
      "e": 32925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33102,
      "e": 33102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33103,
      "e": 33103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33230,
      "e": 33230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33230,
      "e": 33230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33231,
      "e": 33231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33349,
      "e": 33349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33389,
      "e": 33389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33390,
      "e": 33390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33486,
      "e": 33486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33487,
      "e": 33487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33501,
      "e": 33501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 33525,
      "e": 33525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33758,
      "e": 33758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33759,
      "e": 33759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33894,
      "e": 33894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34126,
      "e": 34126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34126,
      "e": 34126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34270,
      "e": 34270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34328,
      "e": 34328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34328,
      "e": 34328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34437,
      "e": 34437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38774,
      "e": 38774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38778,
      "e": 38778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38902,
      "e": 38902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39094,
      "e": 39094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39095,
      "e": 39095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39200,
      "e": 39200,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that ar"
    },
    {
      "t": 39205,
      "e": 39205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39350,
      "e": 39350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39351,
      "e": 39351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39453,
      "e": 39453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39502,
      "e": 39502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39502,
      "e": 39502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39598,
      "e": 39598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39621,
      "e": 39621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 39622,
      "e": 39622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39717,
      "e": 39717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 39757,
      "e": 39757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39758,
      "e": 39758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39837,
      "e": 39837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39862,
      "e": 39862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39862,
      "e": 39862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39933,
      "e": 39933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39999,
      "e": 39999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40086,
      "e": 40086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40086,
      "e": 40086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40125,
      "e": 40125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40157,
      "e": 40157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40157,
      "e": 40157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40189,
      "e": 40189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40510,
      "e": 40510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40511,
      "e": 40511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40606,
      "e": 40606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 40781,
      "e": 40781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40783,
      "e": 40783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40902,
      "e": 40902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41909,
      "e": 41909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41981,
      "e": 41981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are direec"
    },
    {
      "t": 42150,
      "e": 42150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42253,
      "e": 42253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are diree"
    },
    {
      "t": 42590,
      "e": 42590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42629,
      "e": 42629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are dire"
    },
    {
      "t": 43333,
      "e": 43333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 43334,
      "e": 43334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43437,
      "e": 43437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 43622,
      "e": 43622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43623,
      "e": 43623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43733,
      "e": 43733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43773,
      "e": 43773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43773,
      "e": 43773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43877,
      "e": 43877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 43885,
      "e": 43885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 43886,
      "e": 43886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43965,
      "e": 43965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 43981,
      "e": 43981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43982,
      "e": 43982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44078,
      "e": 44078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44270,
      "e": 44270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44270,
      "e": 44270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44373,
      "e": 44373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44646,
      "e": 44646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 44647,
      "e": 44647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44741,
      "e": 44741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 44781,
      "e": 44781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44782,
      "e": 44782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44910,
      "e": 44910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44926,
      "e": 44926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 44926,
      "e": 44926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44989,
      "e": 44989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 45173,
      "e": 45173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45175,
      "e": 45175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45285,
      "e": 45285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45325,
      "e": 45325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45325,
      "e": 45325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45437,
      "e": 45437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45469,
      "e": 45469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45471,
      "e": 45471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45597,
      "e": 45597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45637,
      "e": 45637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45638,
      "e": 45638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45734,
      "e": 45734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 45797,
      "e": 45797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45798,
      "e": 45798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45917,
      "e": 45917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46502,
      "e": 46502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46557,
      "e": 46557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above th"
    },
    {
      "t": 46693,
      "e": 46693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46756,
      "e": 46756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above t"
    },
    {
      "t": 47062,
      "e": 47062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47157,
      "e": 47062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above "
    },
    {
      "t": 48086,
      "e": 47991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48087,
      "e": 47992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48182,
      "e": 48087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48246,
      "e": 48151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48246,
      "e": 48151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48341,
      "e": 48246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 48357,
      "e": 48262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48357,
      "e": 48262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48478,
      "e": 48383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 48485,
      "e": 48390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48487,
      "e": 48392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48601,
      "e": 48506,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the "
    },
    {
      "t": 48605,
      "e": 48510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48742,
      "e": 48647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 48742,
      "e": 48647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48861,
      "e": 48766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 48991,
      "e": 48896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 48991,
      "e": 48896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49085,
      "e": 48990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 49205,
      "e": 49110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49206,
      "e": 49111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49245,
      "e": 49150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49402,
      "e": 49307,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12o"
    },
    {
      "t": 49678,
      "e": 49583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49757,
      "e": 49662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12"
    },
    {
      "t": 49878,
      "e": 49783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49974,
      "e": 49879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 1"
    },
    {
      "t": 50126,
      "e": 50031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50213,
      "e": 50118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the "
    },
    {
      "t": 53038,
      "e": 52943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 53038,
      "e": 52943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53149,
      "e": 53054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 53277,
      "e": 53182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 53279,
      "e": 53184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53365,
      "e": 53270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 53485,
      "e": 53390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53487,
      "e": 53392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53557,
      "e": 53462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53734,
      "e": 53639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53735,
      "e": 53640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53837,
      "e": 53742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 53885,
      "e": 53790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53885,
      "e": 53790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53988,
      "e": 53893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54037,
      "e": 53942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54037,
      "e": 53942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54118,
      "e": 54023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54270,
      "e": 54175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54270,
      "e": 54175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54364,
      "e": 54269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54405,
      "e": 54310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 54405,
      "e": 54310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54477,
      "e": 54382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 54603,
      "e": 54384,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm inc"
    },
    {
      "t": 54644,
      "e": 54425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 54644,
      "e": 54425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54733,
      "e": 54514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 54837,
      "e": 54618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54838,
      "e": 54619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54949,
      "e": 54730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54997,
      "e": 54778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54997,
      "e": 54778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55101,
      "e": 54882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 55150,
      "e": 54931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55151,
      "e": 54932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55268,
      "e": 55049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55308,
      "e": 55089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55309,
      "e": 55090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55412,
      "e": 55193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55429,
      "e": 55210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55429,
      "e": 55210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55525,
      "e": 55306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55733,
      "e": 55514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55734,
      "e": 55515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55805,
      "e": 55586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55805,
      "e": 55586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55821,
      "e": 55602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 55917,
      "e": 55698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55957,
      "e": 55738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55958,
      "e": 55739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56037,
      "e": 55818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 56102,
      "e": 55883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56102,
      "e": 55883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56173,
      "e": 55954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 56173,
      "e": 55954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56205,
      "e": 55986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 56221,
      "e": 56002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56414,
      "e": 56195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56415,
      "e": 56196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56493,
      "e": 56274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56589,
      "e": 56370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56589,
      "e": 56370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56653,
      "e": 56434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56653,
      "e": 56434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56661,
      "e": 56442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 56757,
      "e": 56538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56797,
      "e": 56578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56797,
      "e": 56578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56901,
      "e": 56682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 56903,
      "e": 56684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56917,
      "e": 56698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 56965,
      "e": 56746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57005,
      "e": 56786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57005,
      "e": 56786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57109,
      "e": 56890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58454,
      "e": 58235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58455,
      "e": 58236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58597,
      "e": 58378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 58597,
      "e": 58378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58598,
      "e": 58379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58709,
      "e": 58490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 58837,
      "e": 58618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 58839,
      "e": 58620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58925,
      "e": 58706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 59054,
      "e": 58835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59054,
      "e": 58835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59164,
      "e": 58945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59310,
      "e": 59091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59310,
      "e": 59091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59437,
      "e": 59218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59477,
      "e": 59258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59477,
      "e": 59258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59534,
      "e": 59315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 59686,
      "e": 59467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59686,
      "e": 59467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59772,
      "e": 59553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59877,
      "e": 59658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 59878,
      "e": 59659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59957,
      "e": 59738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 59998,
      "e": 59779,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60077,
      "e": 59858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60077,
      "e": 59858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60165,
      "e": 59946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60342,
      "e": 60123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 60343,
      "e": 60124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60461,
      "e": 60242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 60477,
      "e": 60258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60477,
      "e": 60258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60601,
      "e": 60382,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts "
    },
    {
      "t": 60606,
      "e": 60387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60765,
      "e": 60546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 60766,
      "e": 60547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60781,
      "e": 60562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 61822,
      "e": 61603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61964,
      "e": 61745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts "
    },
    {
      "t": 62093,
      "e": 61874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62094,
      "e": 61875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62189,
      "e": 61970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 62389,
      "e": 62170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62390,
      "e": 62171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62485,
      "e": 62266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62485,
      "e": 62266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62492,
      "e": 62273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 62601,
      "e": 62382,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts sta"
    },
    {
      "t": 62613,
      "e": 62394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62637,
      "e": 62418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 62637,
      "e": 62418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62725,
      "e": 62506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 62846,
      "e": 62627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62846,
      "e": 62627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62950,
      "e": 62731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63125,
      "e": 62906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63126,
      "e": 62907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63229,
      "e": 63010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63293,
      "e": 63074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63293,
      "e": 63074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63390,
      "e": 63171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 63430,
      "e": 63211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63430,
      "e": 63211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63502,
      "e": 63283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 63550,
      "e": 63331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63551,
      "e": 63332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63685,
      "e": 63466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63741,
      "e": 63522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63743,
      "e": 63524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63805,
      "e": 63586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 64269,
      "e": 64050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 64271,
      "e": 64052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64332,
      "e": 64113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 64493,
      "e": 64274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64494,
      "e": 64275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64589,
      "e": 64370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64621,
      "e": 64402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 64965,
      "e": 64746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65477,
      "e": 65258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 65741,
      "e": 65522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65742,
      "e": 65523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65813,
      "e": 65594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 65877,
      "e": 65658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66102,
      "e": 65883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66102,
      "e": 65883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66205,
      "e": 65986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 66334,
      "e": 66115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66335,
      "e": 66116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66420,
      "e": 66201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 66421,
      "e": 66202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66437,
      "e": 66218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 66541,
      "e": 66322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66557,
      "e": 66338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66558,
      "e": 66339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66629,
      "e": 66410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 66773,
      "e": 66554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66774,
      "e": 66555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66853,
      "e": 66634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 66925,
      "e": 66706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 66926,
      "e": 66707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67046,
      "e": 66827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67046,
      "e": 66827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67054,
      "e": 66827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 67133,
      "e": 66906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67181,
      "e": 66954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67181,
      "e": 66954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67285,
      "e": 67058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67406,
      "e": 67179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 67406,
      "e": 67179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67477,
      "e": 67250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 67533,
      "e": 67306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67534,
      "e": 67307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67620,
      "e": 67393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67621,
      "e": 67394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67621,
      "e": 67394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67725,
      "e": 67498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67877,
      "e": 67650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 67878,
      "e": 67651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67989,
      "e": 67762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 68021,
      "e": 67794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68021,
      "e": 67794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68093,
      "e": 67866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68133,
      "e": 67906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68134,
      "e": 67907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68237,
      "e": 68010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 68269,
      "e": 68042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 68269,
      "e": 68042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68373,
      "e": 68146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 68421,
      "e": 68194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68422,
      "e": 68195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68501,
      "e": 68274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68532,
      "e": 68305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68532,
      "e": 68305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68629,
      "e": 68402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 68646,
      "e": 68419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68646,
      "e": 68419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68725,
      "e": 68498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68941,
      "e": 68714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 68942,
      "e": 68715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69028,
      "e": 68801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 69069,
      "e": 68842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69069,
      "e": 68842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69165,
      "e": 68938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 69358,
      "e": 69131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69358,
      "e": 69131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69453,
      "e": 69226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69605,
      "e": 69378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69606,
      "e": 69379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69716,
      "e": 69489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 69716,
      "e": 69489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 69716,
      "e": 69489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69781,
      "e": 69554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 69853,
      "e": 69626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69853,
      "e": 69626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69941,
      "e": 69714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69973,
      "e": 69746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69974,
      "e": 69747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70093,
      "e": 69866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 70278,
      "e": 70051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 70278,
      "e": 70051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70372,
      "e": 70145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 70405,
      "e": 70178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70405,
      "e": 70178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70509,
      "e": 70282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70568,
      "e": 70341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70569,
      "e": 70342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70661,
      "e": 70434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70886,
      "e": 70659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70887,
      "e": 70660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71001,
      "e": 70774,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is ta"
    },
    {
      "t": 71005,
      "e": 70778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 71022,
      "e": 70795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 71022,
      "e": 70795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71093,
      "e": 70866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 71202,
      "e": 70975,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is tak"
    },
    {
      "t": 71205,
      "e": 70978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71207,
      "e": 70980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71261,
      "e": 71034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 71397,
      "e": 71170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71397,
      "e": 71170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71493,
      "e": 71266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 71509,
      "e": 71282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 71509,
      "e": 71282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71621,
      "e": 71394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 71645,
      "e": 71418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71646,
      "e": 71419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71733,
      "e": 71419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71917,
      "e": 71603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 71918,
      "e": 71604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72028,
      "e": 71714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 72133,
      "e": 71819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 72134,
      "e": 71820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72245,
      "e": 71931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 72269,
      "e": 71955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 72269,
      "e": 71955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72341,
      "e": 72027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 72509,
      "e": 72195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 72510,
      "e": 72196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72573,
      "e": 72259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 72814,
      "e": 72500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72814,
      "e": 72500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72916,
      "e": 72602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 72989,
      "e": 72675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72990,
      "e": 72676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73069,
      "e": 72755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73118,
      "e": 72804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73118,
      "e": 72804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73228,
      "e": 72914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 73445,
      "e": 73131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73446,
      "e": 73132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73580,
      "e": 73266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73709,
      "e": 73395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73710,
      "e": 73396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73805,
      "e": 73491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74277,
      "e": 73963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 74277,
      "e": 73963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74388,
      "e": 74074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 74525,
      "e": 74211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 74525,
      "e": 74211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74636,
      "e": 74322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 74701,
      "e": 74387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 74701,
      "e": 74387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74788,
      "e": 74474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 74990,
      "e": 74676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 74990,
      "e": 74676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75109,
      "e": 74795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 75165,
      "e": 74851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75165,
      "e": 74851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75237,
      "e": 74923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75381,
      "e": 75067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 75382,
      "e": 75068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75509,
      "e": 75195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 75517,
      "e": 75203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75517,
      "e": 75203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75605,
      "e": 75291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 75756,
      "e": 75442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 75756,
      "e": 75442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75845,
      "e": 75531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 75925,
      "e": 75611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75926,
      "e": 75612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76020,
      "e": 75706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77498,
      "e": 77184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 77499,
      "e": 77185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77610,
      "e": 77296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 77626,
      "e": 77312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 77627,
      "e": 77313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77714,
      "e": 77400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 77866,
      "e": 77552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 77867,
      "e": 77553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77969,
      "e": 77655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 78403,
      "e": 78089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 78403,
      "e": 78089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78490,
      "e": 78176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 78562,
      "e": 78248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78562,
      "e": 78248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78642,
      "e": 78328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78746,
      "e": 78432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 78747,
      "e": 78433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78850,
      "e": 78536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 78946,
      "e": 78632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 78946,
      "e": 78632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79057,
      "e": 78743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 79162,
      "e": 78848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 79164,
      "e": 78850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79234,
      "e": 78920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 79403,
      "e": 79089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 79403,
      "e": 79089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79405,
      "e": 79091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79405,
      "e": 79091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79425,
      "e": 79111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bn"
    },
    {
      "t": 79449,
      "e": 79135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79506,
      "e": 79192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 79506,
      "e": 79192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79594,
      "e": 79280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 79858,
      "e": 79544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 79859,
      "e": 79545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79978,
      "e": 79664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 79996,
      "e": 79682,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80058,
      "e": 79744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80058,
      "e": 79744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80162,
      "e": 79848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80354,
      "e": 80040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80377,
      "e": 80063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find poibnts"
    },
    {
      "t": 80506,
      "e": 80192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80561,
      "e": 80247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find poibnt"
    },
    {
      "t": 80666,
      "e": 80352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80737,
      "e": 80423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find poibn"
    },
    {
      "t": 80834,
      "e": 80520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80906,
      "e": 80592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find poib"
    },
    {
      "t": 80995,
      "e": 80681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81074,
      "e": 80682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find poi"
    },
    {
      "t": 81995,
      "e": 81603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82089,
      "e": 81697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find po"
    },
    {
      "t": 82201,
      "e": 81809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82273,
      "e": 81881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find p"
    },
    {
      "t": 82393,
      "e": 82001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82473,
      "e": 82081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find "
    },
    {
      "t": 82586,
      "e": 82194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82650,
      "e": 82194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find"
    },
    {
      "t": 83427,
      "e": 82971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83427,
      "e": 82971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83513,
      "e": 83057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84250,
      "e": 83794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84313,
      "e": 83857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you find"
    },
    {
      "t": 84433,
      "e": 83977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84482,
      "e": 84026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you fin"
    },
    {
      "t": 84598,
      "e": 84142,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you fin"
    },
    {
      "t": 84618,
      "e": 84162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84682,
      "e": 84162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you fi"
    },
    {
      "t": 84786,
      "e": 84266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84874,
      "e": 84354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you f"
    },
    {
      "t": 85089,
      "e": 84569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 85161,
      "e": 84641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you "
    },
    {
      "t": 87322,
      "e": 86802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87323,
      "e": 86803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87441,
      "e": 86921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 87578,
      "e": 87058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 87579,
      "e": 87059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87674,
      "e": 87154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 87794,
      "e": 87274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 87795,
      "e": 87275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87889,
      "e": 87369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 88027,
      "e": 87507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88027,
      "e": 87507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88145,
      "e": 87625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 88218,
      "e": 87698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88223,
      "e": 87703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88321,
      "e": 87801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 88426,
      "e": 87906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 88426,
      "e": 87906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88530,
      "e": 88010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 88546,
      "e": 88026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88548,
      "e": 88028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88634,
      "e": 88114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 88666,
      "e": 88146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88666,
      "e": 88146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88778,
      "e": 88258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 88834,
      "e": 88314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 88835,
      "e": 88315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88897,
      "e": 88377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 88998,
      "e": 88377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a sh"
    },
    {
      "t": 89034,
      "e": 88413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 89034,
      "e": 88413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89147,
      "e": 88526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 89187,
      "e": 88566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 89187,
      "e": 88566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89273,
      "e": 88652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 89394,
      "e": 88773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89395,
      "e": 88774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89489,
      "e": 88868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89818,
      "e": 89197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 89881,
      "e": 89260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a shif"
    },
    {
      "t": 89986,
      "e": 89365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90074,
      "e": 89453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a shi"
    },
    {
      "t": 90137,
      "e": 89516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90258,
      "e": 89637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a sh"
    },
    {
      "t": 90331,
      "e": 89710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90450,
      "e": 89711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a s"
    },
    {
      "t": 90922,
      "e": 90183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91025,
      "e": 90286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a "
    },
    {
      "t": 91258,
      "e": 90519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91322,
      "e": 90583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test a"
    },
    {
      "t": 91450,
      "e": 90711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91507,
      "e": 90768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test "
    },
    {
      "t": 92050,
      "e": 91311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 92050,
      "e": 91311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92145,
      "e": 91406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 92306,
      "e": 91567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 92307,
      "e": 91568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92401,
      "e": 91662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 92531,
      "e": 91792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 92531,
      "e": 91792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92657,
      "e": 91918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 92978,
      "e": 92239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 92978,
      "e": 92239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93145,
      "e": 92406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'"
    },
    {
      "t": 93186,
      "e": 92447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 93186,
      "e": 92447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93306,
      "e": 92567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 93338,
      "e": 92599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93339,
      "e": 92600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93426,
      "e": 92600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93442,
      "e": 92616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 93442,
      "e": 92616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93554,
      "e": 92728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 93554,
      "e": 92728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93561,
      "e": 92735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 93633,
      "e": 92807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93770,
      "e": 92944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 93771,
      "e": 92945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93866,
      "e": 93040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 94018,
      "e": 93192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 94019,
      "e": 93193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94129,
      "e": 93303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 94266,
      "e": 93440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94267,
      "e": 93441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94362,
      "e": 93536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 94370,
      "e": 93544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94371,
      "e": 93545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94489,
      "e": 93663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 94618,
      "e": 93792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 94618,
      "e": 93792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94657,
      "e": 93831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 94799,
      "e": 93973,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift b"
    },
    {
      "t": 94850,
      "e": 94024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 94851,
      "e": 94025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94954,
      "e": 94128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 95010,
      "e": 94184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95011,
      "e": 94185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95129,
      "e": 94303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 98490,
      "e": 97664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 98490,
      "e": 97664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98593,
      "e": 97767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 98626,
      "e": 97800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 98626,
      "e": 97800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98729,
      "e": 97903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 98786,
      "e": 97960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 98787,
      "e": 97961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98882,
      "e": 98056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 98889,
      "e": 98063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 98890,
      "e": 98064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98962,
      "e": 98136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 99082,
      "e": 98256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 99083,
      "e": 98257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99178,
      "e": 98352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 99194,
      "e": 98368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 99196,
      "e": 98370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99257,
      "e": 98431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 99402,
      "e": 98576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 99403,
      "e": 98577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99497,
      "e": 98671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 99498,
      "e": 98672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99505,
      "e": 98679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 99577,
      "e": 98751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99618,
      "e": 98792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99618,
      "e": 98792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99714,
      "e": 98888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99762,
      "e": 98936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 99762,
      "e": 98936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99890,
      "e": 99064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 99914,
      "e": 99088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 99914,
      "e": 99088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99997,
      "e": 99171,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100017,
      "e": 99191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 101705,
      "e": 100879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 101706,
      "e": 100880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101810,
      "e": 100984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 101834,
      "e": 101008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 101834,
      "e": 101008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101914,
      "e": 101088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 101945,
      "e": 101119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 101946,
      "e": 101120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102058,
      "e": 101232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 102098,
      "e": 101272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102099,
      "e": 101273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102185,
      "e": 101359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 102786,
      "e": 101960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 102786,
      "e": 101960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102898,
      "e": 102072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 102986,
      "e": 102160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 102986,
      "e": 102160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103073,
      "e": 102247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 103129,
      "e": 102303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 103129,
      "e": 102303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103234,
      "e": 102408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 103418,
      "e": 102592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 103418,
      "e": 102592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103466,
      "e": 102640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 103505,
      "e": 102679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 103505,
      "e": 102679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103522,
      "e": 102696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 103778,
      "e": 102952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 103778,
      "e": 102952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103881,
      "e": 103055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 103938,
      "e": 103112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 103938,
      "e": 103112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103978,
      "e": 103152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 104106,
      "e": 103280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 104107,
      "e": 103281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104194,
      "e": 103368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 104202,
      "e": 103376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 104202,
      "e": 103376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104281,
      "e": 103455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 104398,
      "e": 103572,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duraation"
    },
    {
      "t": 104417,
      "e": 103591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104418,
      "e": 103592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104522,
      "e": 103696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 104658,
      "e": 103832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 104659,
      "e": 103833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104761,
      "e": 103935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 104810,
      "e": 103984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 104810,
      "e": 103984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104905,
      "e": 104079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 104978,
      "e": 104152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104978,
      "e": 104152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105065,
      "e": 104239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 105114,
      "e": 104288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 105115,
      "e": 104289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105194,
      "e": 104368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 105602,
      "e": 104776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 105745,
      "e": 104919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duraation by "
    },
    {
      "t": 105769,
      "e": 104943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 105770,
      "e": 104944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105866,
      "e": 105040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 105906,
      "e": 105080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105907,
      "e": 105081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106049,
      "e": 105223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 106065,
      "e": 105239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 106066,
      "e": 105240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106171,
      "e": 105241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||q"
    },
    {
      "t": 106233,
      "e": 105303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 106233,
      "e": 105303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106337,
      "e": 105407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 106658,
      "e": 105728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 106753,
      "e": 105823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duraation by 2 q"
    },
    {
      "t": 106857,
      "e": 105927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 106998,
      "e": 106068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duraation by 2 "
    },
    {
      "t": 107357,
      "e": 106427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107391,
      "e": 106461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107424,
      "e": 106494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107457,
      "e": 106527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107490,
      "e": 106560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107523,
      "e": 106593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107555,
      "e": 106625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107588,
      "e": 106658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107621,
      "e": 106691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107654,
      "e": 106724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107687,
      "e": 106757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107720,
      "e": 106790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 107745,
      "e": 106815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their dur"
    },
    {
      "t": 108505,
      "e": 107575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 108505,
      "e": 107575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108618,
      "e": 107688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 108857,
      "e": 107927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 108859,
      "e": 107929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108961,
      "e": 108031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 109010,
      "e": 108080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 109010,
      "e": 108080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109057,
      "e": 108127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 109161,
      "e": 108231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 109163,
      "e": 108233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109258,
      "e": 108328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 109267,
      "e": 108337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 109268,
      "e": 108338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109337,
      "e": 108407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 109410,
      "e": 108480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109410,
      "e": 108480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109505,
      "e": 108575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 109618,
      "e": 108688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 109618,
      "e": 108688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109738,
      "e": 108808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 109810,
      "e": 108880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 109810,
      "e": 108880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109929,
      "e": 108999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 109993,
      "e": 109063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109994,
      "e": 109064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110081,
      "e": 109151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 110417,
      "e": 109487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 110417,
      "e": 109487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110521,
      "e": 109591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 110553,
      "e": 109623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 110553,
      "e": 109623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110689,
      "e": 109759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 110738,
      "e": 109808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 110739,
      "e": 109809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110866,
      "e": 109936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 110890,
      "e": 109960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 110891,
      "e": 109961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110998,
      "e": 110068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 an"
    },
    {
      "t": 111009,
      "e": 110079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 111130,
      "e": 110200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 111131,
      "e": 110201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111249,
      "e": 110319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 111281,
      "e": 110351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111281,
      "e": 110351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111370,
      "e": 110440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111418,
      "e": 110488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 111418,
      "e": 110488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111513,
      "e": 110583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 111658,
      "e": 110728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 111658,
      "e": 110728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111721,
      "e": 110791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 111817,
      "e": 110887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 111817,
      "e": 110887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111922,
      "e": 110992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 111930,
      "e": 111000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 111931,
      "e": 111001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111985,
      "e": 111055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 112129,
      "e": 111199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 112130,
      "e": 111200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112218,
      "e": 111288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 112282,
      "e": 111352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 112283,
      "e": 111353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112378,
      "e": 111448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 112401,
      "e": 111471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 112403,
      "e": 111473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112489,
      "e": 111559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 112569,
      "e": 111639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 112569,
      "e": 111639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112681,
      "e": 111751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 112682,
      "e": 111752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112689,
      "e": 111759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 112769,
      "e": 111839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 112849,
      "e": 111919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 112850,
      "e": 111920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112905,
      "e": 111975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 112905,
      "e": 111975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112946,
      "e": 112016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 113002,
      "e": 112072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 113122,
      "e": 112192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 113123,
      "e": 112193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113250,
      "e": 112320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 113378,
      "e": 112448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113379,
      "e": 112449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113489,
      "e": 112559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 113530,
      "e": 112600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 113530,
      "e": 112600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113634,
      "e": 112704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 113866,
      "e": 112936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113889,
      "e": 112936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it tp "
    },
    {
      "t": 113997,
      "e": 113044,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it tp "
    },
    {
      "t": 114033,
      "e": 113080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 114073,
      "e": 113120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it tp"
    },
    {
      "t": 114199,
      "e": 113121,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it tp"
    },
    {
      "t": 114202,
      "e": 113124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 114249,
      "e": 113171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it t"
    },
    {
      "t": 114398,
      "e": 113320,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it t"
    },
    {
      "t": 115081,
      "e": 114003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 115137,
      "e": 114003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it "
    },
    {
      "t": 115249,
      "e": 114115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 115314,
      "e": 114180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding it"
    },
    {
      "t": 115402,
      "e": 114268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 115472,
      "e": 114338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding i"
    },
    {
      "t": 115585,
      "e": 114451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 115633,
      "e": 114452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding "
    },
    {
      "t": 116225,
      "e": 115044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116226,
      "e": 115045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116313,
      "e": 115132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 116337,
      "e": 115156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116337,
      "e": 115156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116409,
      "e": 115228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116522,
      "e": 115341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 116522,
      "e": 115341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116650,
      "e": 115469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 116809,
      "e": 115628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 116810,
      "e": 115629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116929,
      "e": 115748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 116945,
      "e": 115764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116945,
      "e": 115764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117049,
      "e": 115868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117081,
      "e": 115900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 117084,
      "e": 115903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117186,
      "e": 116005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 117186,
      "e": 116005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117193,
      "e": 116012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 117298,
      "e": 116117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 117321,
      "e": 116140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117322,
      "e": 116141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117434,
      "e": 116253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117889,
      "e": 116708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 117889,
      "e": 116708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117998,
      "e": 116817,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to w"
    },
    {
      "t": 118009,
      "e": 116828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 118033,
      "e": 116852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 118034,
      "e": 116853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118122,
      "e": 116941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 118154,
      "e": 116973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118155,
      "e": 116974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118281,
      "e": 117100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 118289,
      "e": 117108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 118289,
      "e": 117108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118394,
      "e": 117213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 118425,
      "e": 117244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118426,
      "e": 117245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118521,
      "e": 117340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 118529,
      "e": 117348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 118529,
      "e": 117348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118650,
      "e": 117469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 118650,
      "e": 117469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 118651,
      "e": 117470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118745,
      "e": 117564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 118865,
      "e": 117684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118867,
      "e": 117686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119000,
      "e": 117687,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when the"
    },
    {
      "t": 119008,
      "e": 117695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 119137,
      "e": 117824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 119137,
      "e": 117824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119274,
      "e": 117961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 119314,
      "e": 118001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 119315,
      "e": 118002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119441,
      "e": 118128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119481,
      "e": 118168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 119481,
      "e": 118168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119598,
      "e": 118285,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they s"
    },
    {
      "t": 119626,
      "e": 118313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 119665,
      "e": 118352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 119667,
      "e": 118354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119785,
      "e": 118472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 119801,
      "e": 118488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 119801,
      "e": 118488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119922,
      "e": 118609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 119946,
      "e": 118633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 119946,
      "e": 118633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120009,
      "e": 118696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 120194,
      "e": 118881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 120194,
      "e": 118881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120289,
      "e": 118976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 120362,
      "e": 119049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120362,
      "e": 119049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120441,
      "e": 119128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 120570,
      "e": 119257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 120572,
      "e": 119259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120641,
      "e": 119328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 120802,
      "e": 119489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120802,
      "e": 119489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120817,
      "e": 119504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 120817,
      "e": 119504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120873,
      "e": 119560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 120897,
      "e": 119584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120999,
      "e": 119584,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started t"
    },
    {
      "t": 121562,
      "e": 120147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 121625,
      "e": 120210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started "
    },
    {
      "t": 122081,
      "e": 120666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 122082,
      "e": 120667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122185,
      "e": 120770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 122290,
      "e": 120875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 122291,
      "e": 120876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122393,
      "e": 120978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 122425,
      "e": 121010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 122425,
      "e": 121010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122538,
      "e": 121123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 122538,
      "e": 121123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122561,
      "e": 121146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ei"
    },
    {
      "t": 122665,
      "e": 121250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 122681,
      "e": 121266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 122681,
      "e": 121266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122786,
      "e": 121371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 122857,
      "e": 121442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122859,
      "e": 121444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122945,
      "e": 121530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 122993,
      "e": 121578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 122993,
      "e": 121578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123153,
      "e": 121738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 123154,
      "e": 121739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123161,
      "e": 121746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 123217,
      "e": 121802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 123353,
      "e": 121938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 123354,
      "e": 121939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123458,
      "e": 122043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 123459,
      "e": 122044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123465,
      "e": 122050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 123538,
      "e": 122123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 123665,
      "e": 122250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 123666,
      "e": 122251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123753,
      "e": 122338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 124370,
      "e": 122955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 124370,
      "e": 122955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124458,
      "e": 123043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 124577,
      "e": 123162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 124578,
      "e": 123163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124713,
      "e": 123298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 125225,
      "e": 123810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 125578,
      "e": 124163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 125579,
      "e": 124164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125657,
      "e": 124242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 125681,
      "e": 124266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 125866,
      "e": 124451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 125866,
      "e": 124451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125998,
      "e": 124452,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If"
    },
    {
      "t": 126009,
      "e": 124463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 126041,
      "e": 124495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 126041,
      "e": 124495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126169,
      "e": 124623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 126505,
      "e": 124959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 126507,
      "e": 124961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126609,
      "e": 125063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 126641,
      "e": 125095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 126641,
      "e": 125095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126730,
      "e": 125184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 126793,
      "e": 125247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 126795,
      "e": 125249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126905,
      "e": 125359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 126953,
      "e": 125407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 126954,
      "e": 125408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127073,
      "e": 125527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 127121,
      "e": 125575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 127121,
      "e": 125575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127226,
      "e": 125680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 127258,
      "e": 125712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 127259,
      "e": 125713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127377,
      "e": 125831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 127377,
      "e": 125831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127384,
      "e": 125838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ns"
    },
    {
      "t": 127465,
      "e": 125919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 127570,
      "e": 126024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 127570,
      "e": 126024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127673,
      "e": 126127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 127794,
      "e": 126248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 127795,
      "e": 126249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127809,
      "e": 126263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 127809,
      "e": 126263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127833,
      "e": 126287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 127849,
      "e": 126303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 127998,
      "e": 126452,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answer"
    },
    {
      "t": 128017,
      "e": 126471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 128018,
      "e": 126472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128129,
      "e": 126583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 128169,
      "e": 126623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 128170,
      "e": 126624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128249,
      "e": 126703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 128289,
      "e": 126743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 128290,
      "e": 126744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128399,
      "e": 126744,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answerr i"
    },
    {
      "t": 128402,
      "e": 126747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 128403,
      "e": 126748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128417,
      "e": 126762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 128513,
      "e": 126858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 128577,
      "e": 126922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 128578,
      "e": 126923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128665,
      "e": 127010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 128906,
      "e": 127251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 128993,
      "e": 127338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answerr is"
    },
    {
      "t": 129105,
      "e": 127450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129161,
      "e": 127450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answerr i"
    },
    {
      "t": 129257,
      "e": 127546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129313,
      "e": 127602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answerr "
    },
    {
      "t": 129401,
      "e": 127690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129473,
      "e": 127762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answerr"
    },
    {
      "t": 129560,
      "e": 127849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 129634,
      "e": 127850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answer"
    },
    {
      "t": 130218,
      "e": 128434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130219,
      "e": 128435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130345,
      "e": 128561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130546,
      "e": 128762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 130546,
      "e": 128762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130633,
      "e": 128849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 130665,
      "e": 128881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 130665,
      "e": 128881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130770,
      "e": 128986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 130818,
      "e": 129034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130819,
      "e": 129035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130912,
      "e": 129128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 131033,
      "e": 129249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 131033,
      "e": 129249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131121,
      "e": 129337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 131249,
      "e": 129465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 131250,
      "e": 129466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131337,
      "e": 129553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 131361,
      "e": 129577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131361,
      "e": 129577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131449,
      "e": 129665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 131554,
      "e": 129770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 131554,
      "e": 129770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131650,
      "e": 129866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 131794,
      "e": 130010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 131795,
      "e": 130011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131905,
      "e": 130121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 131977,
      "e": 130193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131978,
      "e": 130194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132081,
      "e": 130297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 132082,
      "e": 130298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132089,
      "e": 130305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 132177,
      "e": 130393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 132193,
      "e": 130409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 132194,
      "e": 130410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132241,
      "e": 130457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 132369,
      "e": 130585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 132369,
      "e": 130585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132466,
      "e": 130682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 132467,
      "e": 130683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132473,
      "e": 130689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 132577,
      "e": 130793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 132577,
      "e": 130793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 132578,
      "e": 130794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132673,
      "e": 130889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132705,
      "e": 130921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 132705,
      "e": 130921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132778,
      "e": 130994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 132778,
      "e": 130994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132801,
      "e": 131017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 132881,
      "e": 131097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 133033,
      "e": 131249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 133034,
      "e": 131250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133136,
      "e": 131352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 133161,
      "e": 131377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 133161,
      "e": 131377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133250,
      "e": 131466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 133283,
      "e": 131499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 133283,
      "e": 131499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133337,
      "e": 131553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 133386,
      "e": 131602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 133386,
      "e": 131602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133481,
      "e": 131697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 133505,
      "e": 131721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 133505,
      "e": 131721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133585,
      "e": 131801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 133617,
      "e": 131833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 133618,
      "e": 131834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133713,
      "e": 131929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 133737,
      "e": 131953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 133737,
      "e": 131953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133841,
      "e": 132057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 133866,
      "e": 132082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 133866,
      "e": 132082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133953,
      "e": 132169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 134026,
      "e": 132242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 134026,
      "e": 132242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134089,
      "e": 132305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 134089,
      "e": 132305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134113,
      "e": 132329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 134193,
      "e": 132409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 134233,
      "e": 132449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 134233,
      "e": 132449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134297,
      "e": 132513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 134346,
      "e": 132562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 134346,
      "e": 132562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134457,
      "e": 132673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 134474,
      "e": 132690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 134474,
      "e": 132690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134585,
      "e": 132801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 134593,
      "e": 132801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 134594,
      "e": 132802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134673,
      "e": 132881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 134730,
      "e": 132938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 134730,
      "e": 132938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134817,
      "e": 133025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 135113,
      "e": 133321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 135115,
      "e": 133323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135185,
      "e": 133393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 135241,
      "e": 133449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 135241,
      "e": 133449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135329,
      "e": 133537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 135458,
      "e": 133666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 135458,
      "e": 133666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135521,
      "e": 133729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 135681,
      "e": 133889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 135682,
      "e": 133890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135799,
      "e": 134007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answer is 12 pm then thats when their brea"
    },
    {
      "t": 135809,
      "e": 134017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 135810,
      "e": 134018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 135811,
      "e": 134019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135881,
      "e": 134089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 135961,
      "e": 134169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 135961,
      "e": 134169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136049,
      "e": 134257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 136145,
      "e": 134353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 136146,
      "e": 134354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136217,
      "e": 134425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 136266,
      "e": 134474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 136267,
      "e": 134475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136361,
      "e": 134569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 136705,
      "e": 134913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 136707,
      "e": 134915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136713,
      "e": 134921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "18"
    },
    {
      "t": 136745,
      "e": 134953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 136761,
      "e": 134969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138594,
      "e": 136802,
      "ty": 2,
      "x": 560,
      "y": 845
    },
    {
      "t": 138693,
      "e": 136901,
      "ty": 2,
      "x": 283,
      "y": 1086
    },
    {
      "t": 138744,
      "e": 136952,
      "ty": 41,
      "x": 14939,
      "y": 59496,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 138794,
      "e": 137002,
      "ty": 2,
      "x": 234,
      "y": 1020
    },
    {
      "t": 138893,
      "e": 137101,
      "ty": 2,
      "x": 413,
      "y": 805
    },
    {
      "t": 138994,
      "e": 137202,
      "ty": 2,
      "x": 441,
      "y": 718
    },
    {
      "t": 138994,
      "e": 137202,
      "ty": 41,
      "x": 57299,
      "y": 63087,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 139094,
      "e": 137302,
      "ty": 2,
      "x": 446,
      "y": 707
    },
    {
      "t": 139193,
      "e": 137401,
      "ty": 2,
      "x": 446,
      "y": 693
    },
    {
      "t": 139236,
      "e": 137444,
      "ty": 6,
      "x": 446,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 139244,
      "e": 137452,
      "ty": 41,
      "x": 58657,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 139293,
      "e": 137501,
      "ty": 2,
      "x": 445,
      "y": 686
    },
    {
      "t": 139394,
      "e": 137602,
      "ty": 2,
      "x": 444,
      "y": 676
    },
    {
      "t": 139484,
      "e": 137692,
      "ty": 3,
      "x": 444,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 139485,
      "e": 137692,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answer is 12 pm then thats when their break is."
    },
    {
      "t": 139486,
      "e": 137693,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139487,
      "e": 137694,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 139493,
      "e": 137700,
      "ty": 2,
      "x": 444,
      "y": 675
    },
    {
      "t": 139494,
      "e": 137701,
      "ty": 41,
      "x": 57564,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 139587,
      "e": 137794,
      "ty": 4,
      "x": 57564,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 139597,
      "e": 137804,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 139598,
      "e": 137805,
      "ty": 5,
      "x": 444,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 139607,
      "e": 137814,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 139993,
      "e": 138200,
      "ty": 2,
      "x": 1183,
      "y": 926
    },
    {
      "t": 139994,
      "e": 138201,
      "ty": 41,
      "x": 40464,
      "y": 50854,
      "ta": "html > body"
    },
    {
      "t": 140093,
      "e": 138300,
      "ty": 2,
      "x": 1857,
      "y": 1215
    },
    {
      "t": 140605,
      "e": 138812,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 143394,
      "e": 141601,
      "ty": 2,
      "x": 1745,
      "y": 1053
    },
    {
      "t": 143494,
      "e": 141701,
      "ty": 2,
      "x": 1807,
      "y": 1012
    },
    {
      "t": 143494,
      "e": 141701,
      "ty": 41,
      "x": 61953,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 143594,
      "e": 141801,
      "ty": 2,
      "x": 1919,
      "y": 1014
    },
    {
      "t": 143694,
      "e": 141901,
      "ty": 2,
      "x": 1837,
      "y": 967
    },
    {
      "t": 143744,
      "e": 141951,
      "ty": 41,
      "x": 49934,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 143778,
      "e": 141985,
      "ty": 6,
      "x": 986,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 143793,
      "e": 142000,
      "ty": 7,
      "x": 830,
      "y": 638,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 143794,
      "e": 142001,
      "ty": 2,
      "x": 830,
      "y": 638
    },
    {
      "t": 143894,
      "e": 142101,
      "ty": 2,
      "x": 740,
      "y": 578
    },
    {
      "t": 143994,
      "e": 142201,
      "ty": 2,
      "x": 731,
      "y": 563
    },
    {
      "t": 143994,
      "e": 142201,
      "ty": 41,
      "x": 24898,
      "y": 30745,
      "ta": "html > body"
    },
    {
      "t": 144094,
      "e": 142301,
      "ty": 2,
      "x": 841,
      "y": 522
    },
    {
      "t": 144193,
      "e": 142400,
      "ty": 2,
      "x": 914,
      "y": 538
    },
    {
      "t": 144244,
      "e": 142451,
      "ty": 41,
      "x": 23142,
      "y": 38757,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 144262,
      "e": 142469,
      "ty": 6,
      "x": 917,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144294,
      "e": 142501,
      "ty": 2,
      "x": 918,
      "y": 555
    },
    {
      "t": 144394,
      "e": 142601,
      "ty": 2,
      "x": 918,
      "y": 558
    },
    {
      "t": 144459,
      "e": 142666,
      "ty": 3,
      "x": 918,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144460,
      "e": 142667,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144494,
      "e": 142701,
      "ty": 41,
      "x": 23791,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144546,
      "e": 142753,
      "ty": 4,
      "x": 23791,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 144546,
      "e": 142753,
      "ty": 5,
      "x": 918,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 145167,
      "e": 143374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 145168,
      "e": 143375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 145295,
      "e": 143502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 145358,
      "e": 143565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "104"
    },
    {
      "t": 145359,
      "e": 143566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 145487,
      "e": 143694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 146183,
      "e": 144390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 146184,
      "e": 144391,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 146185,
      "e": 144392,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 146186,
      "e": 144393,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 146310,
      "e": 144517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 146663,
      "e": 144870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 146815,
      "e": 145022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 146816,
      "e": 145023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 146887,
      "e": 145094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 146995,
      "e": 145202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 147111,
      "e": 145318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 147112,
      "e": 145319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147182,
      "e": 145389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 147311,
      "e": 145518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 147311,
      "e": 145518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147415,
      "e": 145622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 147471,
      "e": 145678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 148157,
      "e": 146364,
      "ty": 7,
      "x": 905,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148193,
      "e": 146400,
      "ty": 2,
      "x": 900,
      "y": 611
    },
    {
      "t": 148243,
      "e": 146450,
      "ty": 41,
      "x": 19898,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 148280,
      "e": 146487,
      "ty": 6,
      "x": 899,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 148293,
      "e": 146500,
      "ty": 2,
      "x": 899,
      "y": 659
    },
    {
      "t": 148314,
      "e": 146521,
      "ty": 7,
      "x": 902,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 148315,
      "e": 146522,
      "ty": 6,
      "x": 902,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148393,
      "e": 146600,
      "ty": 2,
      "x": 903,
      "y": 682
    },
    {
      "t": 148493,
      "e": 146700,
      "ty": 2,
      "x": 918,
      "y": 700
    },
    {
      "t": 148493,
      "e": 146700,
      "ty": 41,
      "x": 11378,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148498,
      "e": 146705,
      "ty": 7,
      "x": 929,
      "y": 714,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148593,
      "e": 146800,
      "ty": 2,
      "x": 956,
      "y": 722
    },
    {
      "t": 148666,
      "e": 146873,
      "ty": 6,
      "x": 962,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148693,
      "e": 146900,
      "ty": 2,
      "x": 963,
      "y": 702
    },
    {
      "t": 148743,
      "e": 146950,
      "ty": 41,
      "x": 36632,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 148793,
      "e": 147000,
      "ty": 2,
      "x": 968,
      "y": 691
    },
    {
      "t": 148994,
      "e": 147201,
      "ty": 41,
      "x": 37148,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149019,
      "e": 147226,
      "ty": 3,
      "x": 968,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149021,
      "e": 147228,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 149021,
      "e": 147228,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149023,
      "e": 147230,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149082,
      "e": 147289,
      "ty": 4,
      "x": 37148,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149082,
      "e": 147289,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149083,
      "e": 147290,
      "ty": 5,
      "x": 968,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 149083,
      "e": 147290,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 149693,
      "e": 147900,
      "ty": 2,
      "x": 975,
      "y": 700
    },
    {
      "t": 149743,
      "e": 147950,
      "ty": 41,
      "x": 34368,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 149793,
      "e": 148000,
      "ty": 2,
      "x": 1029,
      "y": 828
    },
    {
      "t": 149893,
      "e": 148100,
      "ty": 2,
      "x": 1049,
      "y": 859
    },
    {
      "t": 149994,
      "e": 148201,
      "ty": 41,
      "x": 35849,
      "y": 47143,
      "ta": "html > body"
    },
    {
      "t": 150104,
      "e": 148311,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 150693,
      "e": 148900,
      "ty": 2,
      "x": 910,
      "y": 388
    },
    {
      "t": 150744,
      "e": 148951,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 150793,
      "e": 149000,
      "ty": 2,
      "x": 842,
      "y": 264
    },
    {
      "t": 150894,
      "e": 149101,
      "ty": 2,
      "x": 842,
      "y": 261
    },
    {
      "t": 150993,
      "e": 149200,
      "ty": 2,
      "x": 841,
      "y": 261
    },
    {
      "t": 150994,
      "e": 149201,
      "ty": 41,
      "x": 14911,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 151108,
      "e": 149315,
      "ty": 6,
      "x": 839,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 151117,
      "e": 149324,
      "ty": 7,
      "x": 839,
      "y": 258,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 151193,
      "e": 149400,
      "ty": 2,
      "x": 836,
      "y": 253
    },
    {
      "t": 151243,
      "e": 149450,
      "ty": 41,
      "x": 3459,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 151294,
      "e": 149501,
      "ty": 2,
      "x": 835,
      "y": 252
    },
    {
      "t": 151384,
      "e": 149591,
      "ty": 6,
      "x": 832,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151393,
      "e": 149600,
      "ty": 2,
      "x": 832,
      "y": 244
    },
    {
      "t": 151450,
      "e": 149657,
      "ty": 7,
      "x": 830,
      "y": 231,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151493,
      "e": 149700,
      "ty": 2,
      "x": 830,
      "y": 231
    },
    {
      "t": 151494,
      "e": 149701,
      "ty": 41,
      "x": 7024,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151563,
      "e": 149770,
      "ty": 3,
      "x": 830,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151659,
      "e": 149866,
      "ty": 4,
      "x": 7024,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151659,
      "e": 149866,
      "ty": 5,
      "x": 830,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151661,
      "e": 149868,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151662,
      "e": 149869,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 151811,
      "e": 150018,
      "ty": 6,
      "x": 833,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151834,
      "e": 150041,
      "ty": 7,
      "x": 839,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151893,
      "e": 150100,
      "ty": 2,
      "x": 847,
      "y": 270
    },
    {
      "t": 151993,
      "e": 150200,
      "ty": 2,
      "x": 851,
      "y": 282
    },
    {
      "t": 151993,
      "e": 150200,
      "ty": 41,
      "x": 7019,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 152193,
      "e": 150400,
      "ty": 2,
      "x": 852,
      "y": 290
    },
    {
      "t": 152243,
      "e": 150450,
      "ty": 41,
      "x": 9896,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 152293,
      "e": 150500,
      "ty": 2,
      "x": 853,
      "y": 317
    },
    {
      "t": 152393,
      "e": 150600,
      "ty": 2,
      "x": 854,
      "y": 320
    },
    {
      "t": 152493,
      "e": 150700,
      "ty": 2,
      "x": 844,
      "y": 261
    },
    {
      "t": 152493,
      "e": 150700,
      "ty": 41,
      "x": 17195,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 152593,
      "e": 150800,
      "ty": 2,
      "x": 843,
      "y": 257
    },
    {
      "t": 152693,
      "e": 150900,
      "ty": 2,
      "x": 837,
      "y": 351
    },
    {
      "t": 152743,
      "e": 150950,
      "ty": 41,
      "x": 3697,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 152794,
      "e": 151001,
      "ty": 2,
      "x": 837,
      "y": 384
    },
    {
      "t": 152894,
      "e": 151101,
      "ty": 2,
      "x": 837,
      "y": 399
    },
    {
      "t": 152993,
      "e": 151200,
      "ty": 2,
      "x": 834,
      "y": 407
    },
    {
      "t": 152994,
      "e": 151201,
      "ty": 41,
      "x": 14723,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 153003,
      "e": 151201,
      "ty": 6,
      "x": 832,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153035,
      "e": 151233,
      "ty": 7,
      "x": 828,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153094,
      "e": 151292,
      "ty": 2,
      "x": 828,
      "y": 429
    },
    {
      "t": 153193,
      "e": 151391,
      "ty": 2,
      "x": 827,
      "y": 431
    },
    {
      "t": 153244,
      "e": 151442,
      "ty": 41,
      "x": 1323,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 153294,
      "e": 151492,
      "ty": 2,
      "x": 827,
      "y": 424
    },
    {
      "t": 153393,
      "e": 151591,
      "ty": 2,
      "x": 827,
      "y": 423
    },
    {
      "t": 153476,
      "e": 151674,
      "ty": 6,
      "x": 827,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153494,
      "e": 151692,
      "ty": 2,
      "x": 827,
      "y": 417
    },
    {
      "t": 153494,
      "e": 151692,
      "ty": 41,
      "x": 2914,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153593,
      "e": 151791,
      "ty": 2,
      "x": 831,
      "y": 409
    },
    {
      "t": 153643,
      "e": 151841,
      "ty": 3,
      "x": 831,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153645,
      "e": 151843,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 153645,
      "e": 151843,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153738,
      "e": 151936,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153738,
      "e": 151936,
      "ty": 5,
      "x": 831,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153739,
      "e": 151937,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 153743,
      "e": 151941,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 153793,
      "e": 151991,
      "ty": 2,
      "x": 832,
      "y": 408
    },
    {
      "t": 153994,
      "e": 152192,
      "ty": 41,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 154018,
      "e": 152216,
      "ty": 7,
      "x": 844,
      "y": 427,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 154094,
      "e": 152292,
      "ty": 2,
      "x": 853,
      "y": 454
    },
    {
      "t": 154193,
      "e": 152391,
      "ty": 2,
      "x": 862,
      "y": 501
    },
    {
      "t": 154243,
      "e": 152441,
      "ty": 41,
      "x": 48657,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 154293,
      "e": 152491,
      "ty": 2,
      "x": 863,
      "y": 555
    },
    {
      "t": 154393,
      "e": 152591,
      "ty": 2,
      "x": 858,
      "y": 586
    },
    {
      "t": 154493,
      "e": 152691,
      "ty": 2,
      "x": 854,
      "y": 619
    },
    {
      "t": 154493,
      "e": 152691,
      "ty": 41,
      "x": 7731,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 154594,
      "e": 152792,
      "ty": 2,
      "x": 851,
      "y": 640
    },
    {
      "t": 154693,
      "e": 152891,
      "ty": 2,
      "x": 849,
      "y": 649
    },
    {
      "t": 154744,
      "e": 152942,
      "ty": 41,
      "x": 6070,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 154794,
      "e": 152992,
      "ty": 2,
      "x": 847,
      "y": 661
    },
    {
      "t": 154894,
      "e": 153092,
      "ty": 2,
      "x": 843,
      "y": 673
    },
    {
      "t": 154993,
      "e": 153191,
      "ty": 2,
      "x": 840,
      "y": 684
    },
    {
      "t": 154993,
      "e": 153191,
      "ty": 41,
      "x": 4988,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155093,
      "e": 153291,
      "ty": 2,
      "x": 837,
      "y": 693
    },
    {
      "t": 155244,
      "e": 153442,
      "ty": 41,
      "x": 3925,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 155393,
      "e": 153591,
      "ty": 2,
      "x": 837,
      "y": 691
    },
    {
      "t": 155420,
      "e": 153618,
      "ty": 6,
      "x": 837,
      "y": 677,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 155454,
      "e": 153652,
      "ty": 7,
      "x": 840,
      "y": 667,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 155494,
      "e": 153692,
      "ty": 2,
      "x": 841,
      "y": 666
    },
    {
      "t": 155494,
      "e": 153692,
      "ty": 41,
      "x": 5256,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155693,
      "e": 153891,
      "ty": 2,
      "x": 841,
      "y": 667
    },
    {
      "t": 155743,
      "e": 153941,
      "ty": 41,
      "x": 5256,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155794,
      "e": 153992,
      "ty": 2,
      "x": 841,
      "y": 673
    },
    {
      "t": 155893,
      "e": 154091,
      "ty": 2,
      "x": 842,
      "y": 674
    },
    {
      "t": 155900,
      "e": 154098,
      "ty": 3,
      "x": 842,
      "y": 674,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155900,
      "e": 154098,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 155979,
      "e": 154177,
      "ty": 4,
      "x": 5525,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155979,
      "e": 154177,
      "ty": 5,
      "x": 842,
      "y": 674,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 155980,
      "e": 154178,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 155981,
      "e": 154179,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 155994,
      "e": 154192,
      "ty": 41,
      "x": 5525,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 156393,
      "e": 154591,
      "ty": 2,
      "x": 848,
      "y": 818
    },
    {
      "t": 156494,
      "e": 154692,
      "ty": 2,
      "x": 853,
      "y": 863
    },
    {
      "t": 156494,
      "e": 154692,
      "ty": 41,
      "x": 7494,
      "y": 52457,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 156594,
      "e": 154792,
      "ty": 2,
      "x": 846,
      "y": 881
    },
    {
      "t": 156693,
      "e": 154891,
      "ty": 2,
      "x": 828,
      "y": 915
    },
    {
      "t": 156744,
      "e": 154891,
      "ty": 41,
      "x": 2815,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 156793,
      "e": 154940,
      "ty": 2,
      "x": 823,
      "y": 948
    },
    {
      "t": 156893,
      "e": 155040,
      "ty": 2,
      "x": 822,
      "y": 956
    },
    {
      "t": 156994,
      "e": 155141,
      "ty": 41,
      "x": 467,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 157094,
      "e": 155241,
      "ty": 2,
      "x": 823,
      "y": 957
    },
    {
      "t": 157156,
      "e": 155303,
      "ty": 6,
      "x": 827,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157194,
      "e": 155341,
      "ty": 2,
      "x": 827,
      "y": 960
    },
    {
      "t": 157244,
      "e": 155391,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157283,
      "e": 155430,
      "ty": 3,
      "x": 827,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157284,
      "e": 155431,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 157285,
      "e": 155432,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157378,
      "e": 155525,
      "ty": 4,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157378,
      "e": 155525,
      "ty": 5,
      "x": 827,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157378,
      "e": 155525,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 157438,
      "e": 155585,
      "ty": 7,
      "x": 843,
      "y": 983,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157472,
      "e": 155619,
      "ty": 6,
      "x": 858,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157493,
      "e": 155640,
      "ty": 2,
      "x": 859,
      "y": 1014
    },
    {
      "t": 157493,
      "e": 155640,
      "ty": 41,
      "x": 15244,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157593,
      "e": 155740,
      "ty": 2,
      "x": 863,
      "y": 1026
    },
    {
      "t": 157744,
      "e": 155891,
      "ty": 41,
      "x": 17821,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157771,
      "e": 155918,
      "ty": 3,
      "x": 864,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157773,
      "e": 155920,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 157773,
      "e": 155920,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157793,
      "e": 155940,
      "ty": 2,
      "x": 864,
      "y": 1026
    },
    {
      "t": 157850,
      "e": 155997,
      "ty": 4,
      "x": 17821,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157850,
      "e": 155997,
      "ty": 5,
      "x": 864,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157852,
      "e": 155999,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 157853,
      "e": 156000,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 157854,
      "e": 156001,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 157894,
      "e": 156041,
      "ty": 2,
      "x": 866,
      "y": 1027
    },
    {
      "t": 157993,
      "e": 156140,
      "ty": 2,
      "x": 874,
      "y": 1027
    },
    {
      "t": 157993,
      "e": 156140,
      "ty": 41,
      "x": 29823,
      "y": 56449,
      "ta": "html > body"
    },
    {
      "t": 158093,
      "e": 156240,
      "ty": 2,
      "x": 1038,
      "y": 936
    },
    {
      "t": 158193,
      "e": 156340,
      "ty": 2,
      "x": 1189,
      "y": 783
    },
    {
      "t": 158243,
      "e": 156390,
      "ty": 41,
      "x": 41049,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 158294,
      "e": 156441,
      "ty": 2,
      "x": 1202,
      "y": 756
    },
    {
      "t": 158393,
      "e": 156540,
      "ty": 2,
      "x": 1202,
      "y": 754
    },
    {
      "t": 158493,
      "e": 156640,
      "ty": 2,
      "x": 1204,
      "y": 750
    },
    {
      "t": 158493,
      "e": 156640,
      "ty": 41,
      "x": 41187,
      "y": 41104,
      "ta": "html > body"
    },
    {
      "t": 158594,
      "e": 156741,
      "ty": 2,
      "x": 1205,
      "y": 742
    },
    {
      "t": 158694,
      "e": 156841,
      "ty": 2,
      "x": 1177,
      "y": 715
    },
    {
      "t": 158743,
      "e": 156890,
      "ty": 41,
      "x": 39396,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 158793,
      "e": 156940,
      "ty": 2,
      "x": 1120,
      "y": 679
    },
    {
      "t": 158893,
      "e": 157040,
      "ty": 2,
      "x": 1024,
      "y": 633
    },
    {
      "t": 158994,
      "e": 157141,
      "ty": 2,
      "x": 1002,
      "y": 623
    },
    {
      "t": 158994,
      "e": 157141,
      "ty": 41,
      "x": 34231,
      "y": 34069,
      "ta": "html > body"
    },
    {
      "t": 159093,
      "e": 157240,
      "ty": 2,
      "x": 999,
      "y": 621
    },
    {
      "t": 159231,
      "e": 157378,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 159244,
      "e": 157391,
      "ty": 41,
      "x": 34710,
      "y": 54033,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 159694,
      "e": 157841,
      "ty": 2,
      "x": 989,
      "y": 617
    },
    {
      "t": 159743,
      "e": 157890,
      "ty": 41,
      "x": 30233,
      "y": 33358,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 159793,
      "e": 157940,
      "ty": 2,
      "x": 787,
      "y": 455
    },
    {
      "t": 159894,
      "e": 158041,
      "ty": 2,
      "x": 666,
      "y": 242
    },
    {
      "t": 159993,
      "e": 158140,
      "ty": 2,
      "x": 653,
      "y": 256
    },
    {
      "t": 159994,
      "e": 158141,
      "ty": 41,
      "x": 17688,
      "y": 8981,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 160094,
      "e": 158241,
      "ty": 2,
      "x": 671,
      "y": 571
    },
    {
      "t": 160194,
      "e": 158341,
      "ty": 2,
      "x": 772,
      "y": 875
    },
    {
      "t": 160244,
      "e": 158391,
      "ty": 41,
      "x": 25215,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 160293,
      "e": 158440,
      "ty": 2,
      "x": 847,
      "y": 1022
    },
    {
      "t": 160394,
      "e": 158541,
      "ty": 2,
      "x": 916,
      "y": 1121
    },
    {
      "t": 160493,
      "e": 158640,
      "ty": 2,
      "x": 932,
      "y": 1127
    },
    {
      "t": 160494,
      "e": 158641,
      "ty": 41,
      "x": 19894,
      "y": 30088,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 160594,
      "e": 158741,
      "ty": 2,
      "x": 953,
      "y": 1116
    },
    {
      "t": 160641,
      "e": 158788,
      "ty": 6,
      "x": 962,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 160694,
      "e": 158841,
      "ty": 2,
      "x": 970,
      "y": 1094
    },
    {
      "t": 160744,
      "e": 158891,
      "ty": 41,
      "x": 33040,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 161412,
      "e": 159559,
      "ty": 3,
      "x": 970,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 161412,
      "e": 159559,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 161514,
      "e": 159661,
      "ty": 4,
      "x": 33040,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 161514,
      "e": 159661,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 161516,
      "e": 159663,
      "ty": 5,
      "x": 970,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 161516,
      "e": 159663,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 162558,
      "e": 160705,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 163435,
      "e": 161582,
      "ty": 2,
      "x": 973,
      "y": 1078
    },
    {
      "t": 163435,
      "e": 161582,
      "ty": 41,
      "x": 33011,
      "y": 32865,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 163499,
      "e": 161646,
      "ty": 2,
      "x": 974,
      "y": 1077
    },
    {
      "t": 163499,
      "e": 161646,
      "ty": 41,
      "x": 33029,
      "y": 32865,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 164094,
      "e": 162241,
      "ty": 2,
      "x": 974,
      "y": 1071
    },
    {
      "t": 164193,
      "e": 162340,
      "ty": 2,
      "x": 975,
      "y": 1065
    },
    {
      "t": 164243,
      "e": 162390,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 80521, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 80528, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 2841, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 84696, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8913, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"golf\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 94616, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 12071, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 107766, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9347, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 118115, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 47965, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 167431, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-12 PM-11 AM-11 AM-08 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1020,y:1018,t:1527019496357};\\\", \\\"{x:1022,y:1016,t:1527019496363};\\\", \\\"{x:1027,y:1007,t:1527019496377};\\\", \\\"{x:1042,y:991,t:1527019496393};\\\", \\\"{x:1048,y:982,t:1527019496409};\\\", \\\"{x:1052,y:977,t:1527019496426};\\\", \\\"{x:1054,y:977,t:1527019496443};\\\", \\\"{x:1057,y:977,t:1527019496460};\\\", \\\"{x:1058,y:977,t:1527019496476};\\\", \\\"{x:1059,y:977,t:1527019496514};\\\", \\\"{x:1060,y:977,t:1527019496531};\\\", \\\"{x:1061,y:977,t:1527019496547};\\\", \\\"{x:1062,y:977,t:1527019496562};\\\", \\\"{x:1065,y:977,t:1527019496586};\\\", \\\"{x:1065,y:974,t:1527019496595};\\\", \\\"{x:1065,y:973,t:1527019496610};\\\", \\\"{x:1065,y:963,t:1527019496627};\\\", \\\"{x:1064,y:957,t:1527019496642};\\\", \\\"{x:1057,y:950,t:1527019496660};\\\", \\\"{x:1055,y:946,t:1527019496715};\\\", \\\"{x:1055,y:945,t:1527019496726};\\\", \\\"{x:1039,y:926,t:1527019496743};\\\", \\\"{x:1038,y:925,t:1527019496761};\\\", \\\"{x:1033,y:926,t:1527019496776};\\\", \\\"{x:1030,y:926,t:1527019496794};\\\", \\\"{x:1030,y:925,t:1527019496810};\\\", \\\"{x:1030,y:924,t:1527019496836};\\\", \\\"{x:1030,y:922,t:1527019496844};\\\", \\\"{x:1030,y:919,t:1527019496860};\\\", \\\"{x:1026,y:916,t:1527019496877};\\\", \\\"{x:1008,y:888,t:1527019496893};\\\", \\\"{x:973,y:830,t:1527019496911};\\\", \\\"{x:939,y:798,t:1527019496928};\\\", \\\"{x:921,y:781,t:1527019496944};\\\", \\\"{x:912,y:773,t:1527019496961};\\\", \\\"{x:908,y:769,t:1527019496978};\\\", \\\"{x:900,y:754,t:1527019496994};\\\", \\\"{x:883,y:714,t:1527019497011};\\\", \\\"{x:831,y:626,t:1527019497028};\\\", \\\"{x:783,y:581,t:1527019497043};\\\", \\\"{x:730,y:545,t:1527019497062};\\\", \\\"{x:669,y:517,t:1527019497078};\\\", \\\"{x:627,y:503,t:1527019497093};\\\", \\\"{x:576,y:475,t:1527019497110};\\\", \\\"{x:548,y:461,t:1527019497127};\\\", \\\"{x:533,y:451,t:1527019497144};\\\", \\\"{x:492,y:428,t:1527019497160};\\\", \\\"{x:463,y:413,t:1527019497177};\\\", \\\"{x:449,y:408,t:1527019497194};\\\", \\\"{x:448,y:408,t:1527019497251};\\\", \\\"{x:449,y:415,t:1527019497260};\\\", \\\"{x:460,y:427,t:1527019497277};\\\", \\\"{x:467,y:439,t:1527019497294};\\\", \\\"{x:473,y:447,t:1527019497310};\\\", \\\"{x:479,y:451,t:1527019497327};\\\", \\\"{x:484,y:455,t:1527019497344};\\\", \\\"{x:492,y:462,t:1527019497360};\\\", \\\"{x:502,y:473,t:1527019497377};\\\", \\\"{x:510,y:483,t:1527019497394};\\\", \\\"{x:512,y:484,t:1527019497410};\\\", \\\"{x:512,y:485,t:1527019497427};\\\", \\\"{x:514,y:488,t:1527019497515};\\\", \\\"{x:516,y:492,t:1527019497528};\\\", \\\"{x:518,y:500,t:1527019497544};\\\", \\\"{x:520,y:502,t:1527019497560};\\\", \\\"{x:520,y:503,t:1527019497577};\\\", \\\"{x:521,y:504,t:1527019497628};\\\", \\\"{x:523,y:503,t:1527019497835};\\\", \\\"{x:523,y:502,t:1527019497844};\\\", \\\"{x:526,y:498,t:1527019497862};\\\", \\\"{x:527,y:495,t:1527019497877};\\\", \\\"{x:529,y:490,t:1527019497895};\\\", \\\"{x:531,y:487,t:1527019497912};\\\", \\\"{x:531,y:485,t:1527019497927};\\\", \\\"{x:531,y:484,t:1527019498044};\\\", \\\"{x:533,y:483,t:1527019499475};\\\", \\\"{x:543,y:483,t:1527019499482};\\\", \\\"{x:560,y:485,t:1527019499495};\\\", \\\"{x:642,y:513,t:1527019499513};\\\", \\\"{x:755,y:546,t:1527019499530};\\\", \\\"{x:884,y:591,t:1527019499546};\\\", \\\"{x:984,y:623,t:1527019499563};\\\", \\\"{x:1133,y:677,t:1527019499578};\\\", \\\"{x:1200,y:710,t:1527019499595};\\\", \\\"{x:1245,y:732,t:1527019499612};\\\", \\\"{x:1270,y:744,t:1527019499629};\\\", \\\"{x:1278,y:748,t:1527019499645};\\\", \\\"{x:1279,y:749,t:1527019499662};\\\", \\\"{x:1280,y:750,t:1527019499679};\\\", \\\"{x:1280,y:751,t:1527019499715};\\\", \\\"{x:1278,y:754,t:1527019499730};\\\", \\\"{x:1276,y:755,t:1527019499745};\\\", \\\"{x:1272,y:759,t:1527019499762};\\\", \\\"{x:1257,y:766,t:1527019499779};\\\", \\\"{x:1250,y:769,t:1527019499795};\\\", \\\"{x:1246,y:772,t:1527019499813};\\\", \\\"{x:1241,y:778,t:1527019499830};\\\", \\\"{x:1238,y:782,t:1527019499846};\\\", \\\"{x:1235,y:786,t:1527019499863};\\\", \\\"{x:1234,y:791,t:1527019499879};\\\", \\\"{x:1234,y:799,t:1527019499896};\\\", \\\"{x:1232,y:808,t:1527019499913};\\\", \\\"{x:1232,y:818,t:1527019499930};\\\", \\\"{x:1232,y:830,t:1527019499946};\\\", \\\"{x:1232,y:839,t:1527019499963};\\\", \\\"{x:1232,y:848,t:1527019499980};\\\", \\\"{x:1231,y:860,t:1527019499997};\\\", \\\"{x:1230,y:870,t:1527019500012};\\\", \\\"{x:1229,y:886,t:1527019500029};\\\", \\\"{x:1227,y:902,t:1527019500047};\\\", \\\"{x:1227,y:916,t:1527019500063};\\\", \\\"{x:1227,y:929,t:1527019500080};\\\", \\\"{x:1227,y:935,t:1527019500096};\\\", \\\"{x:1227,y:942,t:1527019500113};\\\", \\\"{x:1232,y:948,t:1527019500130};\\\", \\\"{x:1242,y:955,t:1527019500148};\\\", \\\"{x:1246,y:956,t:1527019500163};\\\", \\\"{x:1263,y:960,t:1527019500180};\\\", \\\"{x:1271,y:961,t:1527019500197};\\\", \\\"{x:1278,y:961,t:1527019500212};\\\", \\\"{x:1283,y:961,t:1527019500229};\\\", \\\"{x:1290,y:963,t:1527019500246};\\\", \\\"{x:1295,y:964,t:1527019500263};\\\", \\\"{x:1303,y:965,t:1527019500280};\\\", \\\"{x:1309,y:966,t:1527019500296};\\\", \\\"{x:1314,y:967,t:1527019500314};\\\", \\\"{x:1319,y:968,t:1527019500330};\\\", \\\"{x:1321,y:968,t:1527019500346};\\\", \\\"{x:1322,y:968,t:1527019500363};\\\", \\\"{x:1323,y:968,t:1527019500379};\\\", \\\"{x:1324,y:968,t:1527019500396};\\\", \\\"{x:1326,y:968,t:1527019500451};\\\", \\\"{x:1328,y:968,t:1527019500467};\\\", \\\"{x:1330,y:968,t:1527019500480};\\\", \\\"{x:1332,y:969,t:1527019500497};\\\", \\\"{x:1335,y:971,t:1527019500514};\\\", \\\"{x:1337,y:972,t:1527019500530};\\\", \\\"{x:1338,y:973,t:1527019500588};\\\", \\\"{x:1338,y:974,t:1527019500596};\\\", \\\"{x:1338,y:975,t:1527019500613};\\\", \\\"{x:1337,y:977,t:1527019500630};\\\", \\\"{x:1335,y:979,t:1527019500646};\\\", \\\"{x:1330,y:982,t:1527019500664};\\\", \\\"{x:1329,y:982,t:1527019500680};\\\", \\\"{x:1322,y:987,t:1527019500697};\\\", \\\"{x:1321,y:987,t:1527019500731};\\\", \\\"{x:1319,y:989,t:1527019500746};\\\", \\\"{x:1311,y:989,t:1527019500763};\\\", \\\"{x:1302,y:989,t:1527019500780};\\\", \\\"{x:1295,y:989,t:1527019500796};\\\", \\\"{x:1286,y:987,t:1527019500813};\\\", \\\"{x:1283,y:984,t:1527019500831};\\\", \\\"{x:1282,y:984,t:1527019500846};\\\", \\\"{x:1281,y:983,t:1527019500931};\\\", \\\"{x:1281,y:982,t:1527019501044};\\\", \\\"{x:1281,y:981,t:1527019501052};\\\", \\\"{x:1281,y:980,t:1527019501064};\\\", \\\"{x:1281,y:978,t:1527019501081};\\\", \\\"{x:1281,y:976,t:1527019501097};\\\", \\\"{x:1280,y:975,t:1527019501114};\\\", \\\"{x:1280,y:974,t:1527019501130};\\\", \\\"{x:1280,y:973,t:1527019501148};\\\", \\\"{x:1280,y:972,t:1527019501164};\\\", \\\"{x:1280,y:971,t:1527019501188};\\\", \\\"{x:1280,y:970,t:1527019501203};\\\", \\\"{x:1280,y:969,t:1527019501214};\\\", \\\"{x:1280,y:968,t:1527019501231};\\\", \\\"{x:1280,y:967,t:1527019501248};\\\", \\\"{x:1280,y:966,t:1527019501264};\\\", \\\"{x:1280,y:964,t:1527019501281};\\\", \\\"{x:1280,y:963,t:1527019501298};\\\", \\\"{x:1280,y:961,t:1527019501314};\\\", \\\"{x:1280,y:959,t:1527019501331};\\\", \\\"{x:1280,y:954,t:1527019501347};\\\", \\\"{x:1278,y:949,t:1527019501364};\\\", \\\"{x:1278,y:946,t:1527019501381};\\\", \\\"{x:1278,y:943,t:1527019501398};\\\", \\\"{x:1278,y:940,t:1527019501414};\\\", \\\"{x:1278,y:937,t:1527019501431};\\\", \\\"{x:1278,y:936,t:1527019501448};\\\", \\\"{x:1278,y:934,t:1527019501464};\\\", \\\"{x:1278,y:933,t:1527019501481};\\\", \\\"{x:1278,y:930,t:1527019501498};\\\", \\\"{x:1279,y:925,t:1527019501514};\\\", \\\"{x:1280,y:918,t:1527019501530};\\\", \\\"{x:1281,y:913,t:1527019501548};\\\", \\\"{x:1281,y:907,t:1527019501564};\\\", \\\"{x:1282,y:904,t:1527019501581};\\\", \\\"{x:1282,y:898,t:1527019501598};\\\", \\\"{x:1282,y:892,t:1527019501615};\\\", \\\"{x:1282,y:884,t:1527019501631};\\\", \\\"{x:1282,y:876,t:1527019501648};\\\", \\\"{x:1283,y:869,t:1527019501665};\\\", \\\"{x:1284,y:861,t:1527019501681};\\\", \\\"{x:1284,y:856,t:1527019501698};\\\", \\\"{x:1282,y:852,t:1527019501715};\\\", \\\"{x:1282,y:850,t:1527019501731};\\\", \\\"{x:1282,y:849,t:1527019501747};\\\", \\\"{x:1282,y:847,t:1527019501765};\\\", \\\"{x:1282,y:846,t:1527019501788};\\\", \\\"{x:1282,y:844,t:1527019501852};\\\", \\\"{x:1282,y:842,t:1527019502020};\\\", \\\"{x:1282,y:841,t:1527019502035};\\\", \\\"{x:1282,y:840,t:1527019502076};\\\", \\\"{x:1282,y:839,t:1527019502116};\\\", \\\"{x:1282,y:836,t:1527019503732};\\\", \\\"{x:1281,y:834,t:1527019503739};\\\", \\\"{x:1280,y:831,t:1527019503748};\\\", \\\"{x:1280,y:830,t:1527019503766};\\\", \\\"{x:1279,y:828,t:1527019503783};\\\", \\\"{x:1279,y:827,t:1527019503800};\\\", \\\"{x:1278,y:826,t:1527019503819};\\\", \\\"{x:1278,y:824,t:1527019504035};\\\", \\\"{x:1277,y:824,t:1527019504050};\\\", \\\"{x:1276,y:822,t:1527019504092};\\\", \\\"{x:1276,y:821,t:1527019504115};\\\", \\\"{x:1276,y:820,t:1527019504172};\\\", \\\"{x:1276,y:819,t:1527019504187};\\\", \\\"{x:1276,y:818,t:1527019504205};\\\", \\\"{x:1276,y:817,t:1527019504234};\\\", \\\"{x:1276,y:815,t:1527019504250};\\\", \\\"{x:1276,y:814,t:1527019504275};\\\", \\\"{x:1276,y:813,t:1527019504298};\\\", \\\"{x:1276,y:811,t:1527019504315};\\\", \\\"{x:1276,y:810,t:1527019504330};\\\", \\\"{x:1276,y:809,t:1527019504338};\\\", \\\"{x:1276,y:808,t:1527019504354};\\\", \\\"{x:1276,y:807,t:1527019504395};\\\", \\\"{x:1277,y:805,t:1527019504419};\\\", \\\"{x:1277,y:804,t:1527019504460};\\\", \\\"{x:1277,y:800,t:1527019504475};\\\", \\\"{x:1278,y:800,t:1527019504491};\\\", \\\"{x:1278,y:799,t:1527019504515};\\\", \\\"{x:1279,y:797,t:1527019504556};\\\", \\\"{x:1279,y:795,t:1527019504596};\\\", \\\"{x:1279,y:794,t:1527019504604};\\\", \\\"{x:1280,y:794,t:1527019504628};\\\", \\\"{x:1280,y:793,t:1527019504652};\\\", \\\"{x:1280,y:791,t:1527019504676};\\\", \\\"{x:1280,y:790,t:1527019504692};\\\", \\\"{x:1280,y:788,t:1527019504700};\\\", \\\"{x:1280,y:785,t:1527019504717};\\\", \\\"{x:1281,y:781,t:1527019504733};\\\", \\\"{x:1281,y:778,t:1527019504749};\\\", \\\"{x:1282,y:777,t:1527019504766};\\\", \\\"{x:1283,y:774,t:1527019504786};\\\", \\\"{x:1283,y:773,t:1527019504803};\\\", \\\"{x:1283,y:772,t:1527019504817};\\\", \\\"{x:1283,y:771,t:1527019504834};\\\", \\\"{x:1283,y:769,t:1527019504849};\\\", \\\"{x:1283,y:766,t:1527019504866};\\\", \\\"{x:1283,y:765,t:1527019504884};\\\", \\\"{x:1283,y:764,t:1527019504899};\\\", \\\"{x:1283,y:761,t:1527019504917};\\\", \\\"{x:1283,y:759,t:1527019504933};\\\", \\\"{x:1282,y:756,t:1527019504950};\\\", \\\"{x:1280,y:752,t:1527019504967};\\\", \\\"{x:1279,y:750,t:1527019504984};\\\", \\\"{x:1278,y:748,t:1527019504999};\\\", \\\"{x:1277,y:744,t:1527019505017};\\\", \\\"{x:1276,y:740,t:1527019505034};\\\", \\\"{x:1275,y:737,t:1527019505050};\\\", \\\"{x:1274,y:735,t:1527019505067};\\\", \\\"{x:1274,y:734,t:1527019505084};\\\", \\\"{x:1273,y:732,t:1527019505108};\\\", \\\"{x:1272,y:731,t:1527019505117};\\\", \\\"{x:1272,y:729,t:1527019505139};\\\", \\\"{x:1272,y:728,t:1527019505155};\\\", \\\"{x:1272,y:726,t:1527019505211};\\\", \\\"{x:1272,y:725,t:1527019505243};\\\", \\\"{x:1272,y:723,t:1527019505267};\\\", \\\"{x:1272,y:722,t:1527019505284};\\\", \\\"{x:1272,y:720,t:1527019505300};\\\", \\\"{x:1272,y:719,t:1527019505316};\\\", \\\"{x:1272,y:717,t:1527019505334};\\\", \\\"{x:1272,y:715,t:1527019505351};\\\", \\\"{x:1272,y:714,t:1527019505367};\\\", \\\"{x:1272,y:713,t:1527019505383};\\\", \\\"{x:1272,y:712,t:1527019505400};\\\", \\\"{x:1272,y:711,t:1527019505417};\\\", \\\"{x:1272,y:710,t:1527019505434};\\\", \\\"{x:1272,y:706,t:1527019505451};\\\", \\\"{x:1272,y:705,t:1527019505468};\\\", \\\"{x:1272,y:704,t:1527019505484};\\\", \\\"{x:1272,y:703,t:1527019505501};\\\", \\\"{x:1272,y:701,t:1527019505532};\\\", \\\"{x:1272,y:700,t:1527019505547};\\\", \\\"{x:1269,y:703,t:1527019505795};\\\", \\\"{x:1267,y:708,t:1527019505803};\\\", \\\"{x:1265,y:714,t:1527019505818};\\\", \\\"{x:1262,y:719,t:1527019505834};\\\", \\\"{x:1259,y:732,t:1527019505851};\\\", \\\"{x:1258,y:738,t:1527019505867};\\\", \\\"{x:1258,y:743,t:1527019505884};\\\", \\\"{x:1258,y:745,t:1527019505901};\\\", \\\"{x:1256,y:748,t:1527019505918};\\\", \\\"{x:1256,y:750,t:1527019505934};\\\", \\\"{x:1255,y:756,t:1527019505951};\\\", \\\"{x:1255,y:761,t:1527019505968};\\\", \\\"{x:1255,y:766,t:1527019505986};\\\", \\\"{x:1255,y:769,t:1527019506001};\\\", \\\"{x:1255,y:776,t:1527019506018};\\\", \\\"{x:1255,y:787,t:1527019506035};\\\", \\\"{x:1255,y:794,t:1527019506051};\\\", \\\"{x:1255,y:804,t:1527019506068};\\\", \\\"{x:1255,y:810,t:1527019506085};\\\", \\\"{x:1255,y:819,t:1527019506102};\\\", \\\"{x:1252,y:833,t:1527019506119};\\\", \\\"{x:1252,y:848,t:1527019506135};\\\", \\\"{x:1252,y:862,t:1527019506151};\\\", \\\"{x:1252,y:869,t:1527019506168};\\\", \\\"{x:1252,y:873,t:1527019506186};\\\", \\\"{x:1252,y:875,t:1527019506202};\\\", \\\"{x:1252,y:878,t:1527019506218};\\\", \\\"{x:1255,y:889,t:1527019506236};\\\", \\\"{x:1257,y:898,t:1527019506251};\\\", \\\"{x:1262,y:905,t:1527019506268};\\\", \\\"{x:1266,y:911,t:1527019506285};\\\", \\\"{x:1269,y:916,t:1527019506301};\\\", \\\"{x:1273,y:919,t:1527019506317};\\\", \\\"{x:1275,y:925,t:1527019506335};\\\", \\\"{x:1277,y:929,t:1527019506350};\\\", \\\"{x:1279,y:931,t:1527019506368};\\\", \\\"{x:1279,y:932,t:1527019506385};\\\", \\\"{x:1280,y:934,t:1527019506401};\\\", \\\"{x:1281,y:935,t:1527019506435};\\\", \\\"{x:1281,y:937,t:1527019506482};\\\", \\\"{x:1281,y:938,t:1527019506507};\\\", \\\"{x:1281,y:940,t:1527019506523};\\\", \\\"{x:1281,y:941,t:1527019506588};\\\", \\\"{x:1281,y:943,t:1527019506603};\\\", \\\"{x:1281,y:944,t:1527019506618};\\\", \\\"{x:1281,y:946,t:1527019506740};\\\", \\\"{x:1281,y:947,t:1527019506804};\\\", \\\"{x:1281,y:952,t:1527019510267};\\\", \\\"{x:1281,y:956,t:1527019510275};\\\", \\\"{x:1281,y:962,t:1527019510288};\\\", \\\"{x:1281,y:967,t:1527019510304};\\\", \\\"{x:1281,y:969,t:1527019510322};\\\", \\\"{x:1281,y:970,t:1527019510338};\\\", \\\"{x:1281,y:971,t:1527019516404};\\\", \\\"{x:1280,y:970,t:1527019516724};\\\", \\\"{x:1280,y:968,t:1527019516740};\\\", \\\"{x:1280,y:967,t:1527019516748};\\\", \\\"{x:1280,y:965,t:1527019516760};\\\", \\\"{x:1280,y:963,t:1527019516777};\\\", \\\"{x:1280,y:960,t:1527019516793};\\\", \\\"{x:1280,y:958,t:1527019516809};\\\", \\\"{x:1282,y:953,t:1527019516826};\\\", \\\"{x:1283,y:949,t:1527019516843};\\\", \\\"{x:1283,y:946,t:1527019516859};\\\", \\\"{x:1283,y:943,t:1527019516877};\\\", \\\"{x:1284,y:941,t:1527019516893};\\\", \\\"{x:1284,y:939,t:1527019516910};\\\", \\\"{x:1284,y:938,t:1527019516939};\\\", \\\"{x:1284,y:937,t:1527019516980};\\\", \\\"{x:1284,y:936,t:1527019517012};\\\", \\\"{x:1285,y:935,t:1527019517067};\\\", \\\"{x:1285,y:933,t:1527019517091};\\\", \\\"{x:1286,y:933,t:1527019517099};\\\", \\\"{x:1286,y:932,t:1527019517116};\\\", \\\"{x:1286,y:931,t:1527019517131};\\\", \\\"{x:1286,y:930,t:1527019517144};\\\", \\\"{x:1286,y:929,t:1527019517160};\\\", \\\"{x:1286,y:927,t:1527019517176};\\\", \\\"{x:1286,y:925,t:1527019517193};\\\", \\\"{x:1286,y:924,t:1527019517210};\\\", \\\"{x:1286,y:916,t:1527019517226};\\\", \\\"{x:1287,y:890,t:1527019517244};\\\", \\\"{x:1288,y:875,t:1527019517261};\\\", \\\"{x:1289,y:862,t:1527019517276};\\\", \\\"{x:1292,y:854,t:1527019517293};\\\", \\\"{x:1292,y:852,t:1527019517310};\\\", \\\"{x:1293,y:849,t:1527019517327};\\\", \\\"{x:1293,y:847,t:1527019517344};\\\", \\\"{x:1293,y:846,t:1527019517364};\\\", \\\"{x:1293,y:844,t:1527019517377};\\\", \\\"{x:1293,y:843,t:1527019517394};\\\", \\\"{x:1293,y:842,t:1527019517411};\\\", \\\"{x:1293,y:840,t:1527019517427};\\\", \\\"{x:1294,y:837,t:1527019517444};\\\", \\\"{x:1294,y:836,t:1527019517460};\\\", \\\"{x:1294,y:834,t:1527019517476};\\\", \\\"{x:1294,y:830,t:1527019517494};\\\", \\\"{x:1293,y:827,t:1527019517511};\\\", \\\"{x:1291,y:822,t:1527019517528};\\\", \\\"{x:1288,y:815,t:1527019517544};\\\", \\\"{x:1287,y:810,t:1527019517561};\\\", \\\"{x:1283,y:801,t:1527019517578};\\\", \\\"{x:1280,y:792,t:1527019517594};\\\", \\\"{x:1276,y:788,t:1527019517611};\\\", \\\"{x:1274,y:781,t:1527019517627};\\\", \\\"{x:1271,y:761,t:1527019517644};\\\", \\\"{x:1269,y:750,t:1527019517661};\\\", \\\"{x:1268,y:741,t:1527019517678};\\\", \\\"{x:1266,y:735,t:1527019517694};\\\", \\\"{x:1266,y:729,t:1527019517711};\\\", \\\"{x:1266,y:722,t:1527019517728};\\\", \\\"{x:1264,y:715,t:1527019517744};\\\", \\\"{x:1264,y:706,t:1527019517761};\\\", \\\"{x:1264,y:698,t:1527019517778};\\\", \\\"{x:1264,y:691,t:1527019517794};\\\", \\\"{x:1264,y:688,t:1527019517811};\\\", \\\"{x:1264,y:678,t:1527019517828};\\\", \\\"{x:1264,y:675,t:1527019517843};\\\", \\\"{x:1264,y:671,t:1527019517861};\\\", \\\"{x:1264,y:668,t:1527019517877};\\\", \\\"{x:1264,y:664,t:1527019517894};\\\", \\\"{x:1264,y:660,t:1527019517911};\\\", \\\"{x:1264,y:656,t:1527019517928};\\\", \\\"{x:1264,y:651,t:1527019517944};\\\", \\\"{x:1264,y:648,t:1527019517961};\\\", \\\"{x:1264,y:646,t:1527019517978};\\\", \\\"{x:1264,y:639,t:1527019517995};\\\", \\\"{x:1264,y:637,t:1527019518010};\\\", \\\"{x:1264,y:629,t:1527019518027};\\\", \\\"{x:1264,y:623,t:1527019518045};\\\", \\\"{x:1265,y:617,t:1527019518061};\\\", \\\"{x:1266,y:613,t:1527019518078};\\\", \\\"{x:1268,y:609,t:1527019518095};\\\", \\\"{x:1268,y:608,t:1527019518111};\\\", \\\"{x:1268,y:606,t:1527019518128};\\\", \\\"{x:1269,y:602,t:1527019518145};\\\", \\\"{x:1270,y:600,t:1527019518160};\\\", \\\"{x:1271,y:595,t:1527019518178};\\\", \\\"{x:1272,y:590,t:1527019518196};\\\", \\\"{x:1272,y:589,t:1527019518211};\\\", \\\"{x:1272,y:585,t:1527019518228};\\\", \\\"{x:1273,y:583,t:1527019518245};\\\", \\\"{x:1274,y:581,t:1527019518267};\\\", \\\"{x:1274,y:578,t:1527019518291};\\\", \\\"{x:1274,y:577,t:1527019518299};\\\", \\\"{x:1276,y:576,t:1527019518311};\\\", \\\"{x:1276,y:575,t:1527019518328};\\\", \\\"{x:1276,y:574,t:1527019518346};\\\", \\\"{x:1273,y:576,t:1527019518612};\\\", \\\"{x:1265,y:582,t:1527019518628};\\\", \\\"{x:1258,y:588,t:1527019518645};\\\", \\\"{x:1253,y:593,t:1527019518662};\\\", \\\"{x:1249,y:598,t:1527019518678};\\\", \\\"{x:1248,y:598,t:1527019518731};\\\", \\\"{x:1245,y:600,t:1527019518744};\\\", \\\"{x:1237,y:604,t:1527019518762};\\\", \\\"{x:1228,y:608,t:1527019518778};\\\", \\\"{x:1223,y:613,t:1527019518795};\\\", \\\"{x:1216,y:617,t:1527019518811};\\\", \\\"{x:1216,y:620,t:1527019518829};\\\", \\\"{x:1207,y:625,t:1527019518845};\\\", \\\"{x:1191,y:632,t:1527019518862};\\\", \\\"{x:1178,y:638,t:1527019518879};\\\", \\\"{x:1165,y:643,t:1527019518895};\\\", \\\"{x:1149,y:647,t:1527019518912};\\\", \\\"{x:1135,y:653,t:1527019518929};\\\", \\\"{x:1123,y:657,t:1527019518944};\\\", \\\"{x:1113,y:663,t:1527019518962};\\\", \\\"{x:1100,y:670,t:1527019518979};\\\", \\\"{x:1068,y:677,t:1527019518995};\\\", \\\"{x:1046,y:680,t:1527019519012};\\\", \\\"{x:1024,y:682,t:1527019519029};\\\", \\\"{x:987,y:682,t:1527019519045};\\\", \\\"{x:940,y:682,t:1527019519062};\\\", \\\"{x:876,y:682,t:1527019519079};\\\", \\\"{x:802,y:678,t:1527019519095};\\\", \\\"{x:748,y:668,t:1527019519112};\\\", \\\"{x:694,y:659,t:1527019519129};\\\", \\\"{x:649,y:652,t:1527019519144};\\\", \\\"{x:617,y:645,t:1527019519163};\\\", \\\"{x:604,y:642,t:1527019519178};\\\", \\\"{x:577,y:641,t:1527019519194};\\\", \\\"{x:556,y:642,t:1527019519211};\\\", \\\"{x:538,y:644,t:1527019519228};\\\", \\\"{x:520,y:647,t:1527019519244};\\\", \\\"{x:516,y:647,t:1527019519261};\\\", \\\"{x:516,y:648,t:1527019519330};\\\", \\\"{x:515,y:648,t:1527019519343};\\\", \\\"{x:514,y:650,t:1527019519361};\\\", \\\"{x:512,y:651,t:1527019519379};\\\", \\\"{x:512,y:654,t:1527019519394};\\\", \\\"{x:510,y:657,t:1527019519413};\\\", \\\"{x:508,y:660,t:1527019519429};\\\", \\\"{x:508,y:662,t:1527019519446};\\\", \\\"{x:507,y:664,t:1527019519463};\\\", \\\"{x:506,y:669,t:1527019519480};\\\", \\\"{x:503,y:674,t:1527019519497};\\\", \\\"{x:500,y:679,t:1527019519512};\\\", \\\"{x:500,y:682,t:1527019519529};\\\", \\\"{x:500,y:683,t:1527019519546};\\\", \\\"{x:500,y:685,t:1527019519563};\\\", \\\"{x:500,y:686,t:1527019519580};\\\", \\\"{x:500,y:688,t:1527019519667};\\\", \\\"{x:499,y:688,t:1527019519680};\\\", \\\"{x:498,y:691,t:1527019519697};\\\", \\\"{x:497,y:692,t:1527019519713};\\\", \\\"{x:497,y:693,t:1527019519730};\\\", \\\"{x:497,y:694,t:1527019519747};\\\", \\\"{x:497,y:695,t:1527019519764};\\\", \\\"{x:497,y:696,t:1527019519781};\\\", \\\"{x:497,y:697,t:1527019519797};\\\", \\\"{x:497,y:699,t:1527019519814};\\\", \\\"{x:497,y:701,t:1527019519833};\\\", \\\"{x:497,y:705,t:1527019519847};\\\", \\\"{x:497,y:707,t:1527019519874};\\\", \\\"{x:502,y:711,t:1527019529804};\\\", \\\"{x:529,y:727,t:1527019529820};\\\", \\\"{x:569,y:755,t:1527019529838};\\\", \\\"{x:616,y:786,t:1527019529852};\\\", \\\"{x:676,y:820,t:1527019529870};\\\", \\\"{x:717,y:844,t:1527019529887};\\\", \\\"{x:748,y:868,t:1527019529904};\\\", \\\"{x:764,y:876,t:1527019529920};\\\", \\\"{x:774,y:886,t:1527019529938};\\\", \\\"{x:783,y:893,t:1527019529953};\\\", \\\"{x:785,y:896,t:1527019529970};\\\", \\\"{x:788,y:899,t:1527019529988};\\\", \\\"{x:790,y:908,t:1527019530004};\\\", \\\"{x:792,y:915,t:1527019530020};\\\", \\\"{x:797,y:924,t:1527019530038};\\\", \\\"{x:804,y:938,t:1527019530055};\\\", \\\"{x:819,y:958,t:1527019530070};\\\", \\\"{x:834,y:971,t:1527019530088};\\\", \\\"{x:849,y:982,t:1527019530105};\\\", \\\"{x:868,y:990,t:1527019530120};\\\", \\\"{x:891,y:996,t:1527019530137};\\\", \\\"{x:930,y:1002,t:1527019530155};\\\", \\\"{x:955,y:1002,t:1527019530170};\\\", \\\"{x:970,y:1002,t:1527019530188};\\\", \\\"{x:994,y:1002,t:1527019530205};\\\", \\\"{x:1011,y:1001,t:1527019530221};\\\", \\\"{x:1022,y:1000,t:1527019530238};\\\", \\\"{x:1029,y:999,t:1527019530255};\\\", \\\"{x:1030,y:998,t:1527019530271};\\\", \\\"{x:1031,y:998,t:1527019530291};\\\", \\\"{x:1032,y:997,t:1527019530306};\\\", \\\"{x:1033,y:997,t:1527019530322};\\\", \\\"{x:1036,y:995,t:1527019530338};\\\", \\\"{x:1041,y:991,t:1527019530356};\\\", \\\"{x:1046,y:989,t:1527019530371};\\\", \\\"{x:1048,y:987,t:1527019530388};\\\", \\\"{x:1050,y:986,t:1527019530406};\\\", \\\"{x:1053,y:984,t:1527019530435};\\\", \\\"{x:1053,y:983,t:1527019530443};\\\", \\\"{x:1058,y:981,t:1527019530455};\\\", \\\"{x:1070,y:977,t:1527019530471};\\\", \\\"{x:1081,y:972,t:1527019530488};\\\", \\\"{x:1090,y:967,t:1527019530505};\\\", \\\"{x:1099,y:963,t:1527019530522};\\\", \\\"{x:1112,y:959,t:1527019530538};\\\", \\\"{x:1125,y:952,t:1527019530555};\\\", \\\"{x:1133,y:951,t:1527019530572};\\\", \\\"{x:1138,y:950,t:1527019530588};\\\", \\\"{x:1150,y:946,t:1527019530605};\\\", \\\"{x:1163,y:945,t:1527019530622};\\\", \\\"{x:1170,y:944,t:1527019530639};\\\", \\\"{x:1178,y:942,t:1527019530655};\\\", \\\"{x:1180,y:942,t:1527019530672};\\\", \\\"{x:1181,y:942,t:1527019530688};\\\", \\\"{x:1183,y:941,t:1527019530755};\\\", \\\"{x:1184,y:942,t:1527019530882};\\\", \\\"{x:1185,y:943,t:1527019530890};\\\", \\\"{x:1185,y:944,t:1527019530905};\\\", \\\"{x:1186,y:948,t:1527019530921};\\\", \\\"{x:1186,y:954,t:1527019530938};\\\", \\\"{x:1186,y:959,t:1527019530955};\\\", \\\"{x:1186,y:961,t:1527019530972};\\\", \\\"{x:1188,y:959,t:1527019531811};\\\", \\\"{x:1188,y:955,t:1527019531823};\\\", \\\"{x:1188,y:949,t:1527019531840};\\\", \\\"{x:1187,y:944,t:1527019531856};\\\", \\\"{x:1187,y:940,t:1527019531873};\\\", \\\"{x:1186,y:937,t:1527019531889};\\\", \\\"{x:1186,y:933,t:1527019531906};\\\", \\\"{x:1182,y:922,t:1527019531923};\\\", \\\"{x:1180,y:910,t:1527019531939};\\\", \\\"{x:1178,y:894,t:1527019531957};\\\", \\\"{x:1171,y:876,t:1527019531974};\\\", \\\"{x:1165,y:862,t:1527019531990};\\\", \\\"{x:1163,y:854,t:1527019532006};\\\", \\\"{x:1160,y:850,t:1527019532023};\\\", \\\"{x:1159,y:844,t:1527019532039};\\\", \\\"{x:1157,y:840,t:1527019532056};\\\", \\\"{x:1156,y:833,t:1527019532073};\\\", \\\"{x:1154,y:826,t:1527019532089};\\\", \\\"{x:1154,y:821,t:1527019532106};\\\", \\\"{x:1153,y:816,t:1527019532123};\\\", \\\"{x:1153,y:815,t:1527019532140};\\\", \\\"{x:1153,y:814,t:1527019532156};\\\", \\\"{x:1153,y:816,t:1527019532282};\\\", \\\"{x:1153,y:817,t:1527019532289};\\\", \\\"{x:1153,y:821,t:1527019532305};\\\", \\\"{x:1156,y:829,t:1527019532323};\\\", \\\"{x:1163,y:836,t:1527019532339};\\\", \\\"{x:1170,y:847,t:1527019532355};\\\", \\\"{x:1175,y:855,t:1527019532372};\\\", \\\"{x:1189,y:869,t:1527019532390};\\\", \\\"{x:1208,y:891,t:1527019532406};\\\", \\\"{x:1228,y:914,t:1527019532423};\\\", \\\"{x:1253,y:935,t:1527019532439};\\\", \\\"{x:1271,y:953,t:1527019532455};\\\", \\\"{x:1294,y:965,t:1527019532472};\\\", \\\"{x:1306,y:974,t:1527019532490};\\\", \\\"{x:1308,y:976,t:1527019532506};\\\", \\\"{x:1308,y:969,t:1527019532748};\\\", \\\"{x:1307,y:957,t:1527019532757};\\\", \\\"{x:1301,y:938,t:1527019532773};\\\", \\\"{x:1296,y:917,t:1527019532791};\\\", \\\"{x:1293,y:895,t:1527019532808};\\\", \\\"{x:1290,y:876,t:1527019532823};\\\", \\\"{x:1288,y:858,t:1527019532841};\\\", \\\"{x:1284,y:830,t:1527019532857};\\\", \\\"{x:1279,y:797,t:1527019532874};\\\", \\\"{x:1277,y:773,t:1527019532890};\\\", \\\"{x:1273,y:738,t:1527019532907};\\\", \\\"{x:1273,y:727,t:1527019532923};\\\", \\\"{x:1279,y:702,t:1527019532940};\\\", \\\"{x:1284,y:685,t:1527019532957};\\\", \\\"{x:1286,y:674,t:1527019532974};\\\", \\\"{x:1291,y:664,t:1527019532991};\\\", \\\"{x:1293,y:660,t:1527019533007};\\\", \\\"{x:1294,y:654,t:1527019533023};\\\", \\\"{x:1297,y:648,t:1527019533040};\\\", \\\"{x:1298,y:643,t:1527019533058};\\\", \\\"{x:1299,y:638,t:1527019533075};\\\", \\\"{x:1299,y:634,t:1527019533091};\\\", \\\"{x:1301,y:630,t:1527019533108};\\\", \\\"{x:1301,y:628,t:1527019533125};\\\", \\\"{x:1301,y:627,t:1527019533140};\\\", \\\"{x:1301,y:626,t:1527019533158};\\\", \\\"{x:1301,y:624,t:1527019533174};\\\", \\\"{x:1301,y:623,t:1527019533190};\\\", \\\"{x:1301,y:620,t:1527019533208};\\\", \\\"{x:1301,y:618,t:1527019533225};\\\", \\\"{x:1297,y:618,t:1527019533324};\\\", \\\"{x:1287,y:630,t:1527019533341};\\\", \\\"{x:1267,y:645,t:1527019533357};\\\", \\\"{x:1252,y:658,t:1527019533374};\\\", \\\"{x:1236,y:671,t:1527019533391};\\\", \\\"{x:1222,y:684,t:1527019533407};\\\", \\\"{x:1208,y:698,t:1527019533423};\\\", \\\"{x:1199,y:706,t:1527019533439};\\\", \\\"{x:1178,y:728,t:1527019533457};\\\", \\\"{x:1160,y:740,t:1527019533474};\\\", \\\"{x:1137,y:757,t:1527019533490};\\\", \\\"{x:1123,y:761,t:1527019533507};\\\", \\\"{x:1106,y:770,t:1527019533524};\\\", \\\"{x:1081,y:778,t:1527019533541};\\\", \\\"{x:1061,y:787,t:1527019533557};\\\", \\\"{x:1032,y:795,t:1527019533574};\\\", \\\"{x:1017,y:804,t:1527019533591};\\\", \\\"{x:999,y:809,t:1527019533606};\\\", \\\"{x:965,y:815,t:1527019533624};\\\", \\\"{x:939,y:815,t:1527019533641};\\\", \\\"{x:913,y:815,t:1527019533657};\\\", \\\"{x:896,y:815,t:1527019533674};\\\", \\\"{x:862,y:813,t:1527019533690};\\\", \\\"{x:848,y:809,t:1527019533707};\\\", \\\"{x:833,y:803,t:1527019533724};\\\", \\\"{x:818,y:795,t:1527019533740};\\\", \\\"{x:811,y:789,t:1527019533757};\\\", \\\"{x:794,y:779,t:1527019533774};\\\", \\\"{x:784,y:768,t:1527019533791};\\\", \\\"{x:773,y:755,t:1527019533807};\\\", \\\"{x:759,y:737,t:1527019533824};\\\", \\\"{x:740,y:722,t:1527019533841};\\\", \\\"{x:713,y:703,t:1527019533857};\\\", \\\"{x:681,y:689,t:1527019533874};\\\", \\\"{x:620,y:666,t:1527019533890};\\\", \\\"{x:599,y:657,t:1527019533907};\\\", \\\"{x:583,y:653,t:1527019533924};\\\", \\\"{x:569,y:652,t:1527019533941};\\\", \\\"{x:562,y:652,t:1527019533958};\\\", \\\"{x:552,y:653,t:1527019533974};\\\", \\\"{x:545,y:659,t:1527019533991};\\\", \\\"{x:540,y:664,t:1527019534008};\\\", \\\"{x:537,y:671,t:1527019534024};\\\", \\\"{x:534,y:675,t:1527019534041};\\\", \\\"{x:531,y:677,t:1527019534059};\\\", \\\"{x:528,y:682,t:1527019534074};\\\", \\\"{x:526,y:686,t:1527019534091};\\\", \\\"{x:525,y:689,t:1527019534108};\\\", \\\"{x:523,y:691,t:1527019534124};\\\", \\\"{x:521,y:695,t:1527019534141};\\\", \\\"{x:520,y:697,t:1527019534158};\\\", \\\"{x:519,y:701,t:1527019534175};\\\", \\\"{x:516,y:706,t:1527019534191};\\\", \\\"{x:514,y:710,t:1527019534207};\\\", \\\"{x:513,y:714,t:1527019534224};\\\", \\\"{x:514,y:723,t:1527019535923};\\\", \\\"{x:520,y:743,t:1527019535932};\\\", \\\"{x:530,y:764,t:1527019535943};\\\", \\\"{x:584,y:822,t:1527019535959};\\\", \\\"{x:682,y:895,t:1527019535976};\\\", \\\"{x:800,y:968,t:1527019535991};\\\", \\\"{x:926,y:1047,t:1527019536008};\\\", \\\"{x:1045,y:1122,t:1527019536025};\\\", \\\"{x:1220,y:1215,t:1527019536042};\\\", \\\"{x:1327,y:1215,t:1527019536058};\\\", \\\"{x:1434,y:1215,t:1527019536076};\\\", \\\"{x:1508,y:1215,t:1527019536093};\\\", \\\"{x:1569,y:1215,t:1527019536109};\\\", \\\"{x:1592,y:1215,t:1527019536126};\\\", \\\"{x:1605,y:1215,t:1527019536143};\\\", \\\"{x:1617,y:1215,t:1527019536159};\\\", \\\"{x:1619,y:1215,t:1527019536176};\\\", \\\"{x:1621,y:1215,t:1527019536193};\\\", \\\"{x:1626,y:1208,t:1527019536209};\\\", \\\"{x:1632,y:1194,t:1527019536226};\\\", \\\"{x:1637,y:1172,t:1527019536242};\\\", \\\"{x:1640,y:1155,t:1527019536259};\\\", \\\"{x:1640,y:1144,t:1527019536276};\\\", \\\"{x:1641,y:1130,t:1527019536293};\\\", \\\"{x:1642,y:1118,t:1527019536310};\\\", \\\"{x:1638,y:1105,t:1527019536326};\\\", \\\"{x:1635,y:1095,t:1527019536343};\\\", \\\"{x:1631,y:1089,t:1527019536360};\\\", \\\"{x:1628,y:1083,t:1527019536376};\\\", \\\"{x:1625,y:1073,t:1527019536394};\\\", \\\"{x:1618,y:1060,t:1527019536411};\\\", \\\"{x:1604,y:1050,t:1527019536427};\\\", \\\"{x:1593,y:1045,t:1527019536443};\\\", \\\"{x:1574,y:1039,t:1527019536460};\\\", \\\"{x:1548,y:1036,t:1527019536477};\\\", \\\"{x:1521,y:1034,t:1527019536493};\\\", \\\"{x:1498,y:1031,t:1527019536511};\\\", \\\"{x:1479,y:1030,t:1527019536526};\\\", \\\"{x:1466,y:1029,t:1527019536543};\\\", \\\"{x:1452,y:1029,t:1527019536560};\\\", \\\"{x:1442,y:1029,t:1527019536577};\\\", \\\"{x:1431,y:1029,t:1527019536593};\\\", \\\"{x:1425,y:1029,t:1527019536610};\\\", \\\"{x:1423,y:1029,t:1527019536627};\\\", \\\"{x:1422,y:1029,t:1527019536731};\\\", \\\"{x:1422,y:1028,t:1527019536980};\\\", \\\"{x:1424,y:1026,t:1527019536993};\\\", \\\"{x:1433,y:1021,t:1527019537010};\\\", \\\"{x:1439,y:1018,t:1527019537026};\\\", \\\"{x:1441,y:1017,t:1527019537044};\\\", \\\"{x:1443,y:1016,t:1527019537060};\\\", \\\"{x:1444,y:1015,t:1527019537078};\\\", \\\"{x:1446,y:1015,t:1527019537093};\\\", \\\"{x:1449,y:1014,t:1527019537111};\\\", \\\"{x:1453,y:1011,t:1527019537128};\\\", \\\"{x:1456,y:1008,t:1527019537144};\\\", \\\"{x:1458,y:1008,t:1527019537160};\\\", \\\"{x:1459,y:1008,t:1527019537177};\\\", \\\"{x:1460,y:1007,t:1527019537235};\\\", \\\"{x:1459,y:1007,t:1527019538003};\\\", \\\"{x:1457,y:1007,t:1527019538011};\\\", \\\"{x:1456,y:1007,t:1527019538028};\\\", \\\"{x:1454,y:1007,t:1527019538044};\\\", \\\"{x:1451,y:1007,t:1527019538061};\\\", \\\"{x:1450,y:1008,t:1527019538091};\\\", \\\"{x:1449,y:1009,t:1527019538131};\\\", \\\"{x:1448,y:1010,t:1527019538144};\\\", \\\"{x:1447,y:1011,t:1527019538162};\\\", \\\"{x:1445,y:1011,t:1527019538179};\\\", \\\"{x:1443,y:1012,t:1527019538195};\\\", \\\"{x:1441,y:1013,t:1527019538219};\\\", \\\"{x:1440,y:1014,t:1527019538243};\\\", \\\"{x:1439,y:1015,t:1527019538251};\\\", \\\"{x:1438,y:1015,t:1527019538267};\\\", \\\"{x:1437,y:1016,t:1527019538291};\\\", \\\"{x:1436,y:1016,t:1527019538347};\\\", \\\"{x:1436,y:1017,t:1527019538362};\\\", \\\"{x:1435,y:1017,t:1527019538379};\\\", \\\"{x:1434,y:1018,t:1527019538395};\\\", \\\"{x:1433,y:1018,t:1527019538412};\\\", \\\"{x:1430,y:1018,t:1527019538428};\\\", \\\"{x:1427,y:1018,t:1527019538444};\\\", \\\"{x:1424,y:1018,t:1527019538461};\\\", \\\"{x:1423,y:1018,t:1527019538499};\\\", \\\"{x:1421,y:1018,t:1527019538548};\\\", \\\"{x:1419,y:1018,t:1527019539067};\\\", \\\"{x:1417,y:1018,t:1527019539078};\\\", \\\"{x:1406,y:1018,t:1527019539095};\\\", \\\"{x:1389,y:1014,t:1527019539112};\\\", \\\"{x:1381,y:1010,t:1527019539129};\\\", \\\"{x:1374,y:1003,t:1527019539146};\\\", \\\"{x:1341,y:991,t:1527019539163};\\\", \\\"{x:1317,y:980,t:1527019539179};\\\", \\\"{x:1296,y:966,t:1527019539195};\\\", \\\"{x:1275,y:952,t:1527019539213};\\\", \\\"{x:1260,y:938,t:1527019539229};\\\", \\\"{x:1248,y:926,t:1527019539245};\\\", \\\"{x:1236,y:912,t:1527019539263};\\\", \\\"{x:1227,y:902,t:1527019539280};\\\", \\\"{x:1222,y:894,t:1527019539296};\\\", \\\"{x:1214,y:886,t:1527019539312};\\\", \\\"{x:1206,y:881,t:1527019539330};\\\", \\\"{x:1204,y:878,t:1527019539346};\\\", \\\"{x:1204,y:877,t:1527019539363};\\\", \\\"{x:1204,y:875,t:1527019539379};\\\", \\\"{x:1204,y:873,t:1527019539396};\\\", \\\"{x:1204,y:870,t:1527019539413};\\\", \\\"{x:1204,y:868,t:1527019539429};\\\", \\\"{x:1204,y:866,t:1527019539446};\\\", \\\"{x:1204,y:864,t:1527019539464};\\\", \\\"{x:1204,y:862,t:1527019539483};\\\", \\\"{x:1204,y:861,t:1527019539524};\\\", \\\"{x:1203,y:859,t:1527019539531};\\\", \\\"{x:1202,y:858,t:1527019539546};\\\", \\\"{x:1202,y:857,t:1527019539563};\\\", \\\"{x:1202,y:855,t:1527019539579};\\\", \\\"{x:1202,y:853,t:1527019539597};\\\", \\\"{x:1202,y:852,t:1527019539613};\\\", \\\"{x:1202,y:851,t:1527019539811};\\\", \\\"{x:1202,y:850,t:1527019539830};\\\", \\\"{x:1202,y:849,t:1527019539846};\\\", \\\"{x:1202,y:848,t:1527019539907};\\\", \\\"{x:1202,y:847,t:1527019539947};\\\", \\\"{x:1202,y:846,t:1527019539987};\\\", \\\"{x:1201,y:839,t:1527019541684};\\\", \\\"{x:1165,y:811,t:1527019541697};\\\", \\\"{x:1008,y:712,t:1527019541715};\\\", \\\"{x:896,y:649,t:1527019541731};\\\", \\\"{x:818,y:592,t:1527019541748};\\\", \\\"{x:784,y:570,t:1527019541765};\\\", \\\"{x:770,y:557,t:1527019541780};\\\", \\\"{x:767,y:555,t:1527019541797};\\\", \\\"{x:761,y:553,t:1527019541813};\\\", \\\"{x:757,y:551,t:1527019541830};\\\", \\\"{x:743,y:547,t:1527019541847};\\\", \\\"{x:733,y:544,t:1527019541863};\\\", \\\"{x:724,y:543,t:1527019541882};\\\", \\\"{x:708,y:543,t:1527019541897};\\\", \\\"{x:656,y:542,t:1527019541914};\\\", \\\"{x:630,y:542,t:1527019541931};\\\", \\\"{x:615,y:541,t:1527019541947};\\\", \\\"{x:604,y:541,t:1527019541964};\\\", \\\"{x:592,y:543,t:1527019541981};\\\", \\\"{x:582,y:546,t:1527019541998};\\\", \\\"{x:570,y:555,t:1527019542013};\\\", \\\"{x:558,y:570,t:1527019542031};\\\", \\\"{x:547,y:590,t:1527019542048};\\\", \\\"{x:544,y:601,t:1527019542064};\\\", \\\"{x:540,y:612,t:1527019542081};\\\", \\\"{x:540,y:616,t:1527019542098};\\\", \\\"{x:537,y:626,t:1527019542115};\\\", \\\"{x:535,y:632,t:1527019542131};\\\", \\\"{x:534,y:639,t:1527019542148};\\\", \\\"{x:531,y:648,t:1527019542164};\\\", \\\"{x:529,y:653,t:1527019542182};\\\", \\\"{x:529,y:656,t:1527019542198};\\\", \\\"{x:529,y:659,t:1527019542214};\\\", \\\"{x:529,y:662,t:1527019542231};\\\", \\\"{x:529,y:669,t:1527019542249};\\\", \\\"{x:529,y:679,t:1527019542265};\\\", \\\"{x:525,y:691,t:1527019542281};\\\", \\\"{x:522,y:705,t:1527019542299};\\\", \\\"{x:519,y:707,t:1527019542315};\\\", \\\"{x:518,y:709,t:1527019542331};\\\", \\\"{x:517,y:713,t:1527019542347};\\\", \\\"{x:517,y:715,t:1527019542364};\\\", \\\"{x:516,y:719,t:1527019542381};\\\", \\\"{x:515,y:721,t:1527019542399};\\\", \\\"{x:514,y:721,t:1527019542427};\\\" ] }, { \\\"rt\\\": 76380, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 245068, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-03 PM-05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:631,t:1527019544954};\\\", \\\"{x:493,y:609,t:1527019544969};\\\", \\\"{x:488,y:592,t:1527019544983};\\\", \\\"{x:488,y:577,t:1527019545000};\\\", \\\"{x:490,y:562,t:1527019545016};\\\", \\\"{x:493,y:541,t:1527019545034};\\\", \\\"{x:505,y:522,t:1527019545050};\\\", \\\"{x:513,y:505,t:1527019545066};\\\", \\\"{x:524,y:483,t:1527019545084};\\\", \\\"{x:533,y:467,t:1527019545100};\\\", \\\"{x:540,y:456,t:1527019545116};\\\", \\\"{x:547,y:445,t:1527019545133};\\\", \\\"{x:552,y:439,t:1527019545150};\\\", \\\"{x:554,y:437,t:1527019545166};\\\", \\\"{x:559,y:432,t:1527019545183};\\\", \\\"{x:563,y:428,t:1527019545200};\\\", \\\"{x:567,y:426,t:1527019545216};\\\", \\\"{x:572,y:424,t:1527019545233};\\\", \\\"{x:575,y:421,t:1527019545249};\\\", \\\"{x:584,y:420,t:1527019545266};\\\", \\\"{x:587,y:420,t:1527019545283};\\\", \\\"{x:588,y:420,t:1527019545299};\\\", \\\"{x:590,y:420,t:1527019545316};\\\", \\\"{x:593,y:422,t:1527019545333};\\\", \\\"{x:598,y:427,t:1527019545349};\\\", \\\"{x:607,y:435,t:1527019545366};\\\", \\\"{x:615,y:444,t:1527019545383};\\\", \\\"{x:622,y:451,t:1527019545399};\\\", \\\"{x:627,y:456,t:1527019545416};\\\", \\\"{x:631,y:460,t:1527019545433};\\\", \\\"{x:633,y:461,t:1527019545449};\\\", \\\"{x:634,y:462,t:1527019545466};\\\", \\\"{x:634,y:463,t:1527019545771};\\\", \\\"{x:634,y:464,t:1527019545803};\\\", \\\"{x:634,y:465,t:1527019545923};\\\", \\\"{x:634,y:467,t:1527019548219};\\\", \\\"{x:633,y:467,t:1527019548231};\\\", \\\"{x:632,y:467,t:1527019548248};\\\", \\\"{x:632,y:468,t:1527019548264};\\\", \\\"{x:631,y:468,t:1527019548290};\\\", \\\"{x:630,y:468,t:1527019548523};\\\", \\\"{x:629,y:468,t:1527019548554};\\\", \\\"{x:628,y:469,t:1527019548684};\\\", \\\"{x:627,y:470,t:1527019548696};\\\", \\\"{x:626,y:470,t:1527019549978};\\\", \\\"{x:626,y:471,t:1527019550002};\\\", \\\"{x:625,y:471,t:1527019550042};\\\", \\\"{x:624,y:471,t:1527019554675};\\\", \\\"{x:623,y:471,t:1527019554699};\\\", \\\"{x:622,y:471,t:1527019554707};\\\", \\\"{x:621,y:471,t:1527019554724};\\\", \\\"{x:620,y:471,t:1527019554770};\\\", \\\"{x:618,y:473,t:1527019568094};\\\", \\\"{x:617,y:474,t:1527019568102};\\\", \\\"{x:614,y:475,t:1527019568118};\\\", \\\"{x:612,y:476,t:1527019568133};\\\", \\\"{x:610,y:477,t:1527019568150};\\\", \\\"{x:608,y:477,t:1527019568167};\\\", \\\"{x:607,y:478,t:1527019568183};\\\", \\\"{x:604,y:479,t:1527019568200};\\\", \\\"{x:603,y:480,t:1527019568217};\\\", \\\"{x:601,y:480,t:1527019568233};\\\", \\\"{x:600,y:481,t:1527019568261};\\\", \\\"{x:600,y:482,t:1527019568286};\\\", \\\"{x:600,y:483,t:1527019568343};\\\", \\\"{x:599,y:484,t:1527019568373};\\\", \\\"{x:598,y:485,t:1527019568383};\\\", \\\"{x:596,y:486,t:1527019568400};\\\", \\\"{x:593,y:487,t:1527019568416};\\\", \\\"{x:590,y:487,t:1527019568433};\\\", \\\"{x:587,y:489,t:1527019568450};\\\", \\\"{x:585,y:490,t:1527019568466};\\\", \\\"{x:582,y:491,t:1527019568494};\\\", \\\"{x:581,y:492,t:1527019568510};\\\", \\\"{x:579,y:492,t:1527019568526};\\\", \\\"{x:578,y:493,t:1527019568534};\\\", \\\"{x:577,y:494,t:1527019568549};\\\", \\\"{x:575,y:494,t:1527019568565};\\\", \\\"{x:574,y:494,t:1527019568583};\\\", \\\"{x:572,y:494,t:1527019568600};\\\", \\\"{x:571,y:496,t:1527019568630};\\\", \\\"{x:570,y:496,t:1527019568646};\\\", \\\"{x:569,y:496,t:1527019568686};\\\", \\\"{x:568,y:496,t:1527019568774};\\\", \\\"{x:566,y:496,t:1527019568862};\\\", \\\"{x:564,y:496,t:1527019568885};\\\", \\\"{x:563,y:496,t:1527019568900};\\\", \\\"{x:562,y:496,t:1527019568916};\\\", \\\"{x:561,y:496,t:1527019568933};\\\", \\\"{x:560,y:496,t:1527019568951};\\\", \\\"{x:559,y:496,t:1527019569006};\\\", \\\"{x:557,y:496,t:1527019569030};\\\", \\\"{x:556,y:496,t:1527019569045};\\\", \\\"{x:554,y:496,t:1527019569126};\\\", \\\"{x:553,y:497,t:1527019569152};\\\", \\\"{x:552,y:497,t:1527019569174};\\\", \\\"{x:551,y:497,t:1527019569182};\\\", \\\"{x:550,y:497,t:1527019569230};\\\", \\\"{x:548,y:497,t:1527019569262};\\\", \\\"{x:547,y:497,t:1527019569294};\\\", \\\"{x:545,y:497,t:1527019569342};\\\", \\\"{x:543,y:499,t:1527019569352};\\\", \\\"{x:542,y:499,t:1527019569422};\\\", \\\"{x:541,y:499,t:1527019569445};\\\", \\\"{x:540,y:499,t:1527019569502};\\\", \\\"{x:539,y:499,t:1527019569518};\\\", \\\"{x:538,y:499,t:1527019569532};\\\", \\\"{x:537,y:499,t:1527019569558};\\\", \\\"{x:536,y:499,t:1527019569574};\\\", \\\"{x:535,y:499,t:1527019569582};\\\", \\\"{x:534,y:499,t:1527019569606};\\\", \\\"{x:533,y:499,t:1527019569678};\\\", \\\"{x:532,y:499,t:1527019569686};\\\", \\\"{x:531,y:499,t:1527019569718};\\\", \\\"{x:529,y:499,t:1527019569758};\\\", \\\"{x:528,y:499,t:1527019569814};\\\", \\\"{x:527,y:499,t:1527019569845};\\\", \\\"{x:526,y:499,t:1527019569877};\\\", \\\"{x:525,y:499,t:1527019569973};\\\", \\\"{x:524,y:499,t:1527019570013};\\\", \\\"{x:523,y:499,t:1527019570022};\\\", \\\"{x:522,y:498,t:1527019570032};\\\", \\\"{x:521,y:498,t:1527019570102};\\\", \\\"{x:519,y:497,t:1527019570118};\\\", \\\"{x:518,y:496,t:1527019570222};\\\", \\\"{x:517,y:496,t:1527019570374};\\\", \\\"{x:516,y:496,t:1527019570414};\\\", \\\"{x:515,y:496,t:1527019570446};\\\", \\\"{x:514,y:496,t:1527019570502};\\\", \\\"{x:513,y:496,t:1527019570525};\\\", \\\"{x:512,y:496,t:1527019570553};\\\", \\\"{x:511,y:496,t:1527019570606};\\\", \\\"{x:509,y:495,t:1527019570854};\\\", \\\"{x:508,y:495,t:1527019570864};\\\", \\\"{x:507,y:494,t:1527019571110};\\\", \\\"{x:507,y:493,t:1527019571142};\\\", \\\"{x:507,y:492,t:1527019571294};\\\", \\\"{x:507,y:491,t:1527019571334};\\\", \\\"{x:507,y:490,t:1527019571414};\\\", \\\"{x:507,y:489,t:1527019571438};\\\", \\\"{x:507,y:488,t:1527019571502};\\\", \\\"{x:506,y:488,t:1527019571990};\\\", \\\"{x:505,y:488,t:1527019572414};\\\", \\\"{x:503,y:488,t:1527019572430};\\\", \\\"{x:501,y:488,t:1527019572446};\\\", \\\"{x:499,y:489,t:1527019572464};\\\", \\\"{x:497,y:489,t:1527019572479};\\\", \\\"{x:497,y:490,t:1527019572496};\\\", \\\"{x:496,y:491,t:1527019572622};\\\", \\\"{x:494,y:491,t:1527019573070};\\\", \\\"{x:493,y:492,t:1527019573080};\\\", \\\"{x:493,y:493,t:1527019573095};\\\", \\\"{x:492,y:493,t:1527019573112};\\\", \\\"{x:491,y:494,t:1527019573141};\\\", \\\"{x:490,y:494,t:1527019573222};\\\", \\\"{x:489,y:494,t:1527019573230};\\\", \\\"{x:488,y:495,t:1527019573245};\\\", \\\"{x:487,y:496,t:1527019573277};\\\", \\\"{x:485,y:497,t:1527019573294};\\\", \\\"{x:485,y:498,t:1527019573302};\\\", \\\"{x:484,y:498,t:1527019573312};\\\", \\\"{x:483,y:500,t:1527019573329};\\\", \\\"{x:480,y:502,t:1527019573345};\\\", \\\"{x:477,y:504,t:1527019573363};\\\", \\\"{x:475,y:505,t:1527019573378};\\\", \\\"{x:473,y:506,t:1527019573397};\\\", \\\"{x:473,y:507,t:1527019573414};\\\", \\\"{x:472,y:508,t:1527019573934};\\\", \\\"{x:471,y:509,t:1527019573943};\\\", \\\"{x:471,y:510,t:1527019573960};\\\", \\\"{x:470,y:511,t:1527019573976};\\\", \\\"{x:470,y:512,t:1527019573994};\\\", \\\"{x:469,y:512,t:1527019574014};\\\", \\\"{x:468,y:513,t:1527019574952};\\\", \\\"{x:468,y:514,t:1527019584726};\\\", \\\"{x:468,y:516,t:1527019584765};\\\", \\\"{x:467,y:517,t:1527019584774};\\\", \\\"{x:466,y:517,t:1527019586126};\\\", \\\"{x:467,y:516,t:1527019589670};\\\", \\\"{x:469,y:514,t:1527019589680};\\\", \\\"{x:473,y:511,t:1527019589697};\\\", \\\"{x:476,y:509,t:1527019589714};\\\", \\\"{x:478,y:508,t:1527019589730};\\\", \\\"{x:479,y:507,t:1527019589747};\\\", \\\"{x:482,y:505,t:1527019589767};\\\", \\\"{x:484,y:505,t:1527019589780};\\\", \\\"{x:490,y:503,t:1527019589797};\\\", \\\"{x:502,y:499,t:1527019589806};\\\", \\\"{x:513,y:496,t:1527019589823};\\\", \\\"{x:520,y:494,t:1527019589840};\\\", \\\"{x:525,y:491,t:1527019589856};\\\", \\\"{x:534,y:491,t:1527019589873};\\\", \\\"{x:541,y:490,t:1527019589891};\\\", \\\"{x:555,y:490,t:1527019589907};\\\", \\\"{x:569,y:490,t:1527019589924};\\\", \\\"{x:596,y:490,t:1527019589940};\\\", \\\"{x:603,y:490,t:1527019589957};\\\", \\\"{x:620,y:490,t:1527019589973};\\\", \\\"{x:625,y:490,t:1527019589991};\\\", \\\"{x:630,y:490,t:1527019590007};\\\", \\\"{x:631,y:490,t:1527019590024};\\\", \\\"{x:647,y:490,t:1527019590566};\\\", \\\"{x:713,y:490,t:1527019590573};\\\", \\\"{x:850,y:500,t:1527019590589};\\\", \\\"{x:1043,y:523,t:1527019590608};\\\", \\\"{x:1248,y:555,t:1527019590624};\\\", \\\"{x:1444,y:582,t:1527019590640};\\\", \\\"{x:1622,y:616,t:1527019590657};\\\", \\\"{x:1784,y:649,t:1527019590673};\\\", \\\"{x:1912,y:676,t:1527019590690};\\\", \\\"{x:1919,y:698,t:1527019590707};\\\", \\\"{x:1919,y:711,t:1527019590723};\\\", \\\"{x:1919,y:715,t:1527019590740};\\\", \\\"{x:1919,y:717,t:1527019590756};\\\", \\\"{x:1919,y:718,t:1527019591077};\\\", \\\"{x:1918,y:718,t:1527019591089};\\\", \\\"{x:1914,y:720,t:1527019591106};\\\", \\\"{x:1911,y:721,t:1527019591122};\\\", \\\"{x:1909,y:723,t:1527019591139};\\\", \\\"{x:1908,y:724,t:1527019591156};\\\", \\\"{x:1907,y:724,t:1527019591172};\\\", \\\"{x:1902,y:727,t:1527019591189};\\\", \\\"{x:1899,y:728,t:1527019591205};\\\", \\\"{x:1897,y:728,t:1527019591225};\\\", \\\"{x:1895,y:729,t:1527019591242};\\\", \\\"{x:1894,y:730,t:1527019591258};\\\", \\\"{x:1893,y:730,t:1527019591277};\\\", \\\"{x:1891,y:731,t:1527019591318};\\\", \\\"{x:1890,y:731,t:1527019591374};\\\", \\\"{x:1889,y:731,t:1527019591392};\\\", \\\"{x:1888,y:731,t:1527019591409};\\\", \\\"{x:1887,y:732,t:1527019591425};\\\", \\\"{x:1885,y:732,t:1527019591442};\\\", \\\"{x:1881,y:734,t:1527019591460};\\\", \\\"{x:1879,y:735,t:1527019591475};\\\", \\\"{x:1874,y:735,t:1527019591492};\\\", \\\"{x:1868,y:738,t:1527019591509};\\\", \\\"{x:1862,y:741,t:1527019591525};\\\", \\\"{x:1848,y:744,t:1527019591542};\\\", \\\"{x:1838,y:747,t:1527019591559};\\\", \\\"{x:1826,y:749,t:1527019591576};\\\", \\\"{x:1818,y:752,t:1527019591592};\\\", \\\"{x:1812,y:752,t:1527019591610};\\\", \\\"{x:1808,y:753,t:1527019591626};\\\", \\\"{x:1802,y:753,t:1527019591642};\\\", \\\"{x:1800,y:753,t:1527019591660};\\\", \\\"{x:1796,y:754,t:1527019591675};\\\", \\\"{x:1794,y:755,t:1527019591692};\\\", \\\"{x:1791,y:755,t:1527019591710};\\\", \\\"{x:1790,y:755,t:1527019591725};\\\", \\\"{x:1786,y:755,t:1527019591742};\\\", \\\"{x:1775,y:755,t:1527019591760};\\\", \\\"{x:1762,y:762,t:1527019591777};\\\", \\\"{x:1736,y:768,t:1527019591792};\\\", \\\"{x:1672,y:780,t:1527019591809};\\\", \\\"{x:1649,y:783,t:1527019591827};\\\", \\\"{x:1612,y:792,t:1527019591842};\\\", \\\"{x:1589,y:793,t:1527019591859};\\\", \\\"{x:1586,y:793,t:1527019591876};\\\", \\\"{x:1583,y:797,t:1527019592030};\\\", \\\"{x:1581,y:806,t:1527019592042};\\\", \\\"{x:1566,y:832,t:1527019592059};\\\", \\\"{x:1552,y:851,t:1527019592076};\\\", \\\"{x:1534,y:884,t:1527019592092};\\\", \\\"{x:1520,y:906,t:1527019592109};\\\", \\\"{x:1503,y:934,t:1527019592126};\\\", \\\"{x:1499,y:942,t:1527019592142};\\\", \\\"{x:1495,y:950,t:1527019592159};\\\", \\\"{x:1489,y:961,t:1527019592176};\\\", \\\"{x:1484,y:971,t:1527019592194};\\\", \\\"{x:1478,y:981,t:1527019592209};\\\", \\\"{x:1475,y:990,t:1527019592227};\\\", \\\"{x:1473,y:997,t:1527019592244};\\\", \\\"{x:1473,y:999,t:1527019592259};\\\", \\\"{x:1473,y:1000,t:1527019592276};\\\", \\\"{x:1473,y:1001,t:1527019592293};\\\", \\\"{x:1473,y:1002,t:1527019592309};\\\", \\\"{x:1472,y:1004,t:1527019592325};\\\", \\\"{x:1471,y:1008,t:1527019592343};\\\", \\\"{x:1471,y:1011,t:1527019592360};\\\", \\\"{x:1470,y:1013,t:1527019592377};\\\", \\\"{x:1469,y:1015,t:1527019592393};\\\", \\\"{x:1469,y:1016,t:1527019592409};\\\", \\\"{x:1469,y:1017,t:1527019592438};\\\", \\\"{x:1469,y:1016,t:1527019592806};\\\", \\\"{x:1469,y:1015,t:1527019592814};\\\", \\\"{x:1469,y:1014,t:1527019592826};\\\", \\\"{x:1469,y:1012,t:1527019592844};\\\", \\\"{x:1470,y:1009,t:1527019592860};\\\", \\\"{x:1470,y:1008,t:1527019592876};\\\", \\\"{x:1473,y:1004,t:1527019592894};\\\", \\\"{x:1473,y:1003,t:1527019592910};\\\", \\\"{x:1474,y:1003,t:1527019592926};\\\", \\\"{x:1474,y:1001,t:1527019592943};\\\", \\\"{x:1474,y:1000,t:1527019592960};\\\", \\\"{x:1476,y:999,t:1527019592981};\\\", \\\"{x:1477,y:997,t:1527019592998};\\\", \\\"{x:1478,y:996,t:1527019593021};\\\", \\\"{x:1479,y:995,t:1527019593029};\\\", \\\"{x:1480,y:994,t:1527019593045};\\\", \\\"{x:1481,y:993,t:1527019593060};\\\", \\\"{x:1484,y:991,t:1527019593078};\\\", \\\"{x:1484,y:990,t:1527019593094};\\\", \\\"{x:1486,y:989,t:1527019593110};\\\", \\\"{x:1489,y:987,t:1527019593128};\\\", \\\"{x:1490,y:986,t:1527019593143};\\\", \\\"{x:1492,y:984,t:1527019593161};\\\", \\\"{x:1494,y:984,t:1527019593177};\\\", \\\"{x:1497,y:983,t:1527019593193};\\\", \\\"{x:1500,y:982,t:1527019593210};\\\", \\\"{x:1503,y:979,t:1527019593228};\\\", \\\"{x:1508,y:978,t:1527019593244};\\\", \\\"{x:1510,y:977,t:1527019593260};\\\", \\\"{x:1513,y:975,t:1527019593277};\\\", \\\"{x:1517,y:973,t:1527019593294};\\\", \\\"{x:1520,y:972,t:1527019593310};\\\", \\\"{x:1526,y:972,t:1527019593328};\\\", \\\"{x:1533,y:972,t:1527019593344};\\\", \\\"{x:1543,y:972,t:1527019593360};\\\", \\\"{x:1552,y:970,t:1527019593377};\\\", \\\"{x:1563,y:968,t:1527019593393};\\\", \\\"{x:1572,y:968,t:1527019593411};\\\", \\\"{x:1579,y:967,t:1527019593427};\\\", \\\"{x:1585,y:967,t:1527019593444};\\\", \\\"{x:1593,y:965,t:1527019593460};\\\", \\\"{x:1596,y:965,t:1527019593477};\\\", \\\"{x:1600,y:964,t:1527019593494};\\\", \\\"{x:1601,y:964,t:1527019593510};\\\", \\\"{x:1603,y:964,t:1527019593534};\\\", \\\"{x:1604,y:963,t:1527019593558};\\\", \\\"{x:1605,y:962,t:1527019593574};\\\", \\\"{x:1606,y:961,t:1527019594254};\\\", \\\"{x:1608,y:961,t:1527019594278};\\\", \\\"{x:1610,y:960,t:1527019594294};\\\", \\\"{x:1611,y:959,t:1527019594312};\\\", \\\"{x:1613,y:958,t:1527019594327};\\\", \\\"{x:1615,y:957,t:1527019594345};\\\", \\\"{x:1620,y:954,t:1527019594362};\\\", \\\"{x:1626,y:953,t:1527019594378};\\\", \\\"{x:1629,y:953,t:1527019594394};\\\", \\\"{x:1634,y:953,t:1527019594411};\\\", \\\"{x:1640,y:953,t:1527019594428};\\\", \\\"{x:1644,y:953,t:1527019594444};\\\", \\\"{x:1652,y:953,t:1527019594461};\\\", \\\"{x:1660,y:953,t:1527019594478};\\\", \\\"{x:1667,y:957,t:1527019594495};\\\", \\\"{x:1683,y:962,t:1527019594511};\\\", \\\"{x:1695,y:967,t:1527019594529};\\\", \\\"{x:1705,y:969,t:1527019594544};\\\", \\\"{x:1714,y:971,t:1527019594562};\\\", \\\"{x:1721,y:972,t:1527019594578};\\\", \\\"{x:1726,y:975,t:1527019594594};\\\", \\\"{x:1727,y:976,t:1527019595862};\\\", \\\"{x:1727,y:978,t:1527019595886};\\\", \\\"{x:1726,y:978,t:1527019595895};\\\", \\\"{x:1722,y:980,t:1527019595911};\\\", \\\"{x:1712,y:984,t:1527019595928};\\\", \\\"{x:1703,y:984,t:1527019595944};\\\", \\\"{x:1677,y:984,t:1527019595962};\\\", \\\"{x:1635,y:981,t:1527019595979};\\\", \\\"{x:1566,y:965,t:1527019595995};\\\", \\\"{x:1479,y:936,t:1527019596012};\\\", \\\"{x:1342,y:888,t:1527019596028};\\\", \\\"{x:1235,y:851,t:1527019596045};\\\", \\\"{x:1148,y:818,t:1527019596062};\\\", \\\"{x:1098,y:795,t:1527019596078};\\\", \\\"{x:1047,y:778,t:1527019596095};\\\", \\\"{x:1011,y:762,t:1527019596112};\\\", \\\"{x:985,y:753,t:1527019596129};\\\", \\\"{x:961,y:746,t:1527019596146};\\\", \\\"{x:942,y:736,t:1527019596162};\\\", \\\"{x:932,y:725,t:1527019596179};\\\", \\\"{x:909,y:713,t:1527019596196};\\\", \\\"{x:888,y:701,t:1527019596212};\\\", \\\"{x:870,y:693,t:1527019596229};\\\", \\\"{x:863,y:690,t:1527019596245};\\\", \\\"{x:859,y:688,t:1527019596262};\\\", \\\"{x:858,y:687,t:1527019596279};\\\", \\\"{x:854,y:685,t:1527019596297};\\\", \\\"{x:848,y:681,t:1527019596312};\\\", \\\"{x:839,y:676,t:1527019596329};\\\", \\\"{x:822,y:665,t:1527019596346};\\\", \\\"{x:807,y:654,t:1527019596363};\\\", \\\"{x:787,y:642,t:1527019596379};\\\", \\\"{x:777,y:634,t:1527019596396};\\\", \\\"{x:776,y:633,t:1527019596411};\\\", \\\"{x:774,y:633,t:1527019596444};\\\", \\\"{x:771,y:631,t:1527019596453};\\\", \\\"{x:768,y:627,t:1527019596461};\\\", \\\"{x:757,y:620,t:1527019596478};\\\", \\\"{x:741,y:608,t:1527019596497};\\\", \\\"{x:721,y:593,t:1527019596512};\\\", \\\"{x:637,y:550,t:1527019596530};\\\", \\\"{x:558,y:522,t:1527019596546};\\\", \\\"{x:491,y:501,t:1527019596563};\\\", \\\"{x:454,y:484,t:1527019596579};\\\", \\\"{x:443,y:478,t:1527019596596};\\\", \\\"{x:442,y:478,t:1527019596613};\\\", \\\"{x:441,y:478,t:1527019596629};\\\", \\\"{x:440,y:478,t:1527019596789};\\\", \\\"{x:440,y:482,t:1527019596798};\\\", \\\"{x:440,y:495,t:1527019596814};\\\", \\\"{x:440,y:502,t:1527019596829};\\\", \\\"{x:440,y:511,t:1527019596847};\\\", \\\"{x:440,y:518,t:1527019596863};\\\", \\\"{x:440,y:523,t:1527019596880};\\\", \\\"{x:440,y:528,t:1527019596896};\\\", \\\"{x:437,y:534,t:1527019596913};\\\", \\\"{x:435,y:538,t:1527019596930};\\\", \\\"{x:434,y:543,t:1527019596946};\\\", \\\"{x:431,y:546,t:1527019596963};\\\", \\\"{x:428,y:550,t:1527019596979};\\\", \\\"{x:429,y:550,t:1527019597053};\\\", \\\"{x:431,y:552,t:1527019597493};\\\", \\\"{x:432,y:553,t:1527019597526};\\\", \\\"{x:432,y:554,t:1527019597951};\\\", \\\"{x:432,y:555,t:1527019597973};\\\", \\\"{x:432,y:556,t:1527019597981};\\\", \\\"{x:432,y:557,t:1527019598022};\\\", \\\"{x:432,y:559,t:1527019598045};\\\", \\\"{x:431,y:561,t:1527019598069};\\\", \\\"{x:431,y:562,t:1527019598086};\\\", \\\"{x:430,y:563,t:1527019598102};\\\", \\\"{x:429,y:564,t:1527019598125};\\\", \\\"{x:428,y:565,t:1527019598150};\\\", \\\"{x:428,y:566,t:1527019598181};\\\", \\\"{x:427,y:566,t:1527019598245};\\\", \\\"{x:426,y:567,t:1527019598278};\\\", \\\"{x:426,y:568,t:1527019598302};\\\", \\\"{x:425,y:568,t:1527019598333};\\\", \\\"{x:424,y:568,t:1527019598421};\\\", \\\"{x:423,y:569,t:1527019598438};\\\", \\\"{x:422,y:570,t:1527019598486};\\\", \\\"{x:420,y:570,t:1527019599237};\\\", \\\"{x:419,y:570,t:1527019600766};\\\", \\\"{x:419,y:571,t:1527019600837};\\\", \\\"{x:419,y:572,t:1527019600850};\\\", \\\"{x:418,y:573,t:1527019619584};\\\", \\\"{x:418,y:575,t:1527019619593};\\\", \\\"{x:418,y:577,t:1527019619608};\\\", \\\"{x:418,y:578,t:1527019619624};\\\", \\\"{x:418,y:579,t:1527019619635};\\\", \\\"{x:418,y:581,t:1527019619650};\\\", \\\"{x:418,y:585,t:1527019619668};\\\", \\\"{x:418,y:592,t:1527019619685};\\\", \\\"{x:418,y:599,t:1527019619702};\\\", \\\"{x:418,y:610,t:1527019619718};\\\", \\\"{x:419,y:620,t:1527019619735};\\\", \\\"{x:422,y:637,t:1527019619751};\\\", \\\"{x:426,y:654,t:1527019619768};\\\", \\\"{x:428,y:669,t:1527019619785};\\\", \\\"{x:431,y:676,t:1527019619801};\\\", \\\"{x:431,y:679,t:1527019619818};\\\", \\\"{x:434,y:683,t:1527019619835};\\\", \\\"{x:435,y:684,t:1527019619852};\\\", \\\"{x:436,y:688,t:1527019619868};\\\", \\\"{x:438,y:690,t:1527019619885};\\\", \\\"{x:439,y:692,t:1527019619902};\\\", \\\"{x:441,y:695,t:1527019619918};\\\", \\\"{x:443,y:698,t:1527019619936};\\\", \\\"{x:452,y:712,t:1527019619954};\\\", \\\"{x:457,y:719,t:1527019619968};\\\", \\\"{x:464,y:726,t:1527019619985};\\\", \\\"{x:471,y:731,t:1527019620002};\\\", \\\"{x:484,y:735,t:1527019620019};\\\", \\\"{x:498,y:738,t:1527019620035};\\\", \\\"{x:512,y:742,t:1527019620052};\\\", \\\"{x:521,y:745,t:1527019620068};\\\", \\\"{x:522,y:745,t:1527019620085};\\\", \\\"{x:524,y:745,t:1527019620377};\\\", \\\"{x:525,y:744,t:1527019620385};\\\", \\\"{x:526,y:741,t:1527019620403};\\\", \\\"{x:529,y:737,t:1527019620419};\\\", \\\"{x:531,y:734,t:1527019620436};\\\", \\\"{x:533,y:731,t:1527019620452};\\\", \\\"{x:534,y:730,t:1527019620469};\\\", \\\"{x:537,y:726,t:1527019620486};\\\", \\\"{x:541,y:720,t:1527019620502};\\\", \\\"{x:546,y:715,t:1527019620519};\\\", \\\"{x:548,y:711,t:1527019620536};\\\", \\\"{x:549,y:709,t:1527019621232};\\\", \\\"{x:553,y:707,t:1527019621240};\\\", \\\"{x:558,y:704,t:1527019621253};\\\", \\\"{x:563,y:701,t:1527019621269};\\\", \\\"{x:569,y:698,t:1527019621286};\\\", \\\"{x:572,y:694,t:1527019621304};\\\", \\\"{x:575,y:691,t:1527019621319};\\\", \\\"{x:586,y:683,t:1527019621336};\\\", \\\"{x:593,y:678,t:1527019621353};\\\", \\\"{x:595,y:677,t:1527019621370};\\\", \\\"{x:598,y:675,t:1527019621386};\\\", \\\"{x:598,y:674,t:1527019621403};\\\", \\\"{x:600,y:673,t:1527019621419};\\\" ] }, { \\\"rt\\\": 31503, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 278114, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -10 AM-11 AM-12 PM-12 PM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:602,y:672,t:1527019623161};\\\", \\\"{x:602,y:671,t:1527019623171};\\\", \\\"{x:603,y:668,t:1527019623188};\\\", \\\"{x:605,y:666,t:1527019623204};\\\", \\\"{x:605,y:664,t:1527019623224};\\\", \\\"{x:607,y:663,t:1527019623238};\\\", \\\"{x:607,y:662,t:1527019623255};\\\", \\\"{x:607,y:660,t:1527019623272};\\\", \\\"{x:609,y:656,t:1527019623288};\\\", \\\"{x:610,y:654,t:1527019623305};\\\", \\\"{x:611,y:651,t:1527019623321};\\\", \\\"{x:612,y:647,t:1527019623341};\\\", \\\"{x:612,y:644,t:1527019623355};\\\", \\\"{x:614,y:640,t:1527019623371};\\\", \\\"{x:615,y:635,t:1527019623387};\\\", \\\"{x:617,y:628,t:1527019623403};\\\", \\\"{x:617,y:623,t:1527019623421};\\\", \\\"{x:619,y:618,t:1527019623437};\\\", \\\"{x:623,y:610,t:1527019623454};\\\", \\\"{x:625,y:602,t:1527019623471};\\\", \\\"{x:628,y:593,t:1527019623487};\\\", \\\"{x:628,y:589,t:1527019623505};\\\", \\\"{x:630,y:584,t:1527019623522};\\\", \\\"{x:632,y:579,t:1527019623539};\\\", \\\"{x:633,y:574,t:1527019623555};\\\", \\\"{x:635,y:569,t:1527019623572};\\\", \\\"{x:637,y:563,t:1527019623588};\\\", \\\"{x:637,y:558,t:1527019623605};\\\", \\\"{x:639,y:551,t:1527019623621};\\\", \\\"{x:640,y:547,t:1527019623638};\\\", \\\"{x:642,y:543,t:1527019623656};\\\", \\\"{x:643,y:541,t:1527019623671};\\\", \\\"{x:643,y:539,t:1527019623688};\\\", \\\"{x:644,y:536,t:1527019623707};\\\", \\\"{x:645,y:532,t:1527019623721};\\\", \\\"{x:646,y:530,t:1527019623738};\\\", \\\"{x:646,y:525,t:1527019623755};\\\", \\\"{x:647,y:522,t:1527019623771};\\\", \\\"{x:647,y:519,t:1527019623788};\\\", \\\"{x:647,y:518,t:1527019623805};\\\", \\\"{x:646,y:513,t:1527019623822};\\\", \\\"{x:643,y:511,t:1527019623838};\\\", \\\"{x:640,y:510,t:1527019623855};\\\", \\\"{x:639,y:509,t:1527019623872};\\\", \\\"{x:638,y:508,t:1527019623888};\\\", \\\"{x:637,y:507,t:1527019623905};\\\", \\\"{x:636,y:505,t:1527019623923};\\\", \\\"{x:625,y:500,t:1527019623938};\\\", \\\"{x:607,y:494,t:1527019623955};\\\", \\\"{x:592,y:487,t:1527019623972};\\\", \\\"{x:579,y:480,t:1527019623988};\\\", \\\"{x:565,y:472,t:1527019624005};\\\", \\\"{x:556,y:469,t:1527019624021};\\\", \\\"{x:549,y:463,t:1527019624039};\\\", \\\"{x:544,y:460,t:1527019624055};\\\", \\\"{x:544,y:458,t:1527019624161};\\\", \\\"{x:544,y:457,t:1527019624289};\\\", \\\"{x:544,y:455,t:1527019624344};\\\", \\\"{x:545,y:454,t:1527019624356};\\\", \\\"{x:546,y:454,t:1527019624371};\\\", \\\"{x:547,y:454,t:1527019624389};\\\", \\\"{x:549,y:453,t:1527019624406};\\\", \\\"{x:551,y:453,t:1527019624423};\\\", \\\"{x:552,y:453,t:1527019624440};\\\", \\\"{x:555,y:450,t:1527019624456};\\\", \\\"{x:561,y:450,t:1527019624472};\\\", \\\"{x:573,y:450,t:1527019624489};\\\", \\\"{x:593,y:450,t:1527019624505};\\\", \\\"{x:615,y:452,t:1527019624522};\\\", \\\"{x:638,y:453,t:1527019624539};\\\", \\\"{x:669,y:457,t:1527019624555};\\\", \\\"{x:708,y:464,t:1527019624573};\\\", \\\"{x:738,y:467,t:1527019624588};\\\", \\\"{x:772,y:472,t:1527019624606};\\\", \\\"{x:809,y:479,t:1527019624622};\\\", \\\"{x:834,y:479,t:1527019624639};\\\", \\\"{x:868,y:479,t:1527019624656};\\\", \\\"{x:889,y:483,t:1527019624672};\\\", \\\"{x:930,y:490,t:1527019624688};\\\", \\\"{x:983,y:497,t:1527019624706};\\\", \\\"{x:1023,y:505,t:1527019624723};\\\", \\\"{x:1053,y:510,t:1527019624739};\\\", \\\"{x:1085,y:518,t:1527019624756};\\\", \\\"{x:1106,y:524,t:1527019624773};\\\", \\\"{x:1124,y:528,t:1527019624789};\\\", \\\"{x:1141,y:531,t:1527019624806};\\\", \\\"{x:1154,y:534,t:1527019624823};\\\", \\\"{x:1162,y:535,t:1527019624839};\\\", \\\"{x:1163,y:535,t:1527019624856};\\\", \\\"{x:1174,y:537,t:1527019624872};\\\", \\\"{x:1187,y:539,t:1527019624889};\\\", \\\"{x:1204,y:545,t:1527019624906};\\\", \\\"{x:1217,y:549,t:1527019624923};\\\", \\\"{x:1226,y:550,t:1527019624938};\\\", \\\"{x:1234,y:550,t:1527019624956};\\\", \\\"{x:1248,y:553,t:1527019624972};\\\", \\\"{x:1257,y:553,t:1527019624989};\\\", \\\"{x:1266,y:553,t:1527019625006};\\\", \\\"{x:1275,y:555,t:1527019625022};\\\", \\\"{x:1283,y:557,t:1527019625039};\\\", \\\"{x:1287,y:557,t:1527019625056};\\\", \\\"{x:1290,y:559,t:1527019625073};\\\", \\\"{x:1296,y:562,t:1527019625089};\\\", \\\"{x:1299,y:565,t:1527019625106};\\\", \\\"{x:1304,y:565,t:1527019625123};\\\", \\\"{x:1309,y:566,t:1527019625139};\\\", \\\"{x:1314,y:566,t:1527019625156};\\\", \\\"{x:1322,y:566,t:1527019625173};\\\", \\\"{x:1334,y:570,t:1527019625189};\\\", \\\"{x:1341,y:573,t:1527019625206};\\\", \\\"{x:1350,y:575,t:1527019625223};\\\", \\\"{x:1356,y:578,t:1527019625239};\\\", \\\"{x:1362,y:579,t:1527019625256};\\\", \\\"{x:1370,y:582,t:1527019625272};\\\", \\\"{x:1373,y:582,t:1527019625289};\\\", \\\"{x:1374,y:583,t:1527019625306};\\\", \\\"{x:1377,y:584,t:1527019625323};\\\", \\\"{x:1378,y:585,t:1527019625339};\\\", \\\"{x:1380,y:586,t:1527019625356};\\\", \\\"{x:1386,y:589,t:1527019625373};\\\", \\\"{x:1391,y:592,t:1527019625389};\\\", \\\"{x:1402,y:599,t:1527019625406};\\\", \\\"{x:1409,y:602,t:1527019625423};\\\", \\\"{x:1421,y:608,t:1527019625439};\\\", \\\"{x:1433,y:612,t:1527019625456};\\\", \\\"{x:1445,y:617,t:1527019625472};\\\", \\\"{x:1449,y:620,t:1527019625489};\\\", \\\"{x:1451,y:620,t:1527019625506};\\\", \\\"{x:1453,y:622,t:1527019625523};\\\", \\\"{x:1458,y:624,t:1527019625539};\\\", \\\"{x:1462,y:627,t:1527019625556};\\\", \\\"{x:1466,y:631,t:1527019625573};\\\", \\\"{x:1469,y:634,t:1527019625589};\\\", \\\"{x:1473,y:640,t:1527019625606};\\\", \\\"{x:1475,y:645,t:1527019625623};\\\", \\\"{x:1477,y:654,t:1527019625640};\\\", \\\"{x:1478,y:668,t:1527019625656};\\\", \\\"{x:1484,y:704,t:1527019625672};\\\", \\\"{x:1491,y:734,t:1527019625690};\\\", \\\"{x:1491,y:758,t:1527019625706};\\\", \\\"{x:1491,y:776,t:1527019625723};\\\", \\\"{x:1486,y:790,t:1527019625740};\\\", \\\"{x:1478,y:807,t:1527019625756};\\\", \\\"{x:1473,y:820,t:1527019625773};\\\", \\\"{x:1467,y:829,t:1527019625789};\\\", \\\"{x:1458,y:839,t:1527019625806};\\\", \\\"{x:1440,y:846,t:1527019625823};\\\", \\\"{x:1415,y:851,t:1527019625840};\\\", \\\"{x:1414,y:853,t:1527019625856};\\\", \\\"{x:1402,y:853,t:1527019625872};\\\", \\\"{x:1384,y:851,t:1527019625890};\\\", \\\"{x:1370,y:847,t:1527019625906};\\\", \\\"{x:1350,y:842,t:1527019625923};\\\", \\\"{x:1335,y:841,t:1527019625940};\\\", \\\"{x:1327,y:841,t:1527019625956};\\\", \\\"{x:1319,y:841,t:1527019625973};\\\", \\\"{x:1317,y:841,t:1527019625990};\\\", \\\"{x:1309,y:841,t:1527019626006};\\\", \\\"{x:1304,y:841,t:1527019626023};\\\", \\\"{x:1297,y:838,t:1527019626040};\\\", \\\"{x:1294,y:838,t:1527019626056};\\\", \\\"{x:1275,y:838,t:1527019626073};\\\", \\\"{x:1261,y:838,t:1527019626090};\\\", \\\"{x:1253,y:838,t:1527019626106};\\\", \\\"{x:1241,y:838,t:1527019626123};\\\", \\\"{x:1231,y:838,t:1527019626140};\\\", \\\"{x:1226,y:839,t:1527019626156};\\\", \\\"{x:1225,y:839,t:1527019626172};\\\", \\\"{x:1224,y:839,t:1527019626632};\\\", \\\"{x:1224,y:838,t:1527019626648};\\\", \\\"{x:1224,y:837,t:1527019626664};\\\", \\\"{x:1222,y:836,t:1527019626816};\\\", \\\"{x:1222,y:835,t:1527019626824};\\\", \\\"{x:1221,y:835,t:1527019626840};\\\", \\\"{x:1220,y:835,t:1527019626857};\\\", \\\"{x:1219,y:835,t:1527019626888};\\\", \\\"{x:1219,y:834,t:1527019626897};\\\", \\\"{x:1218,y:834,t:1527019626910};\\\", \\\"{x:1217,y:833,t:1527019627608};\\\", \\\"{x:1217,y:832,t:1527019627624};\\\", \\\"{x:1217,y:831,t:1527019627680};\\\", \\\"{x:1217,y:830,t:1527019627690};\\\", \\\"{x:1217,y:829,t:1527019627913};\\\", \\\"{x:1217,y:827,t:1527019629616};\\\", \\\"{x:1218,y:825,t:1527019629624};\\\", \\\"{x:1227,y:821,t:1527019629642};\\\", \\\"{x:1235,y:821,t:1527019629657};\\\", \\\"{x:1243,y:821,t:1527019629674};\\\", \\\"{x:1257,y:822,t:1527019629691};\\\", \\\"{x:1268,y:823,t:1527019629707};\\\", \\\"{x:1282,y:823,t:1527019629724};\\\", \\\"{x:1290,y:822,t:1527019629741};\\\", \\\"{x:1295,y:822,t:1527019629757};\\\", \\\"{x:1302,y:822,t:1527019629775};\\\", \\\"{x:1304,y:822,t:1527019629793};\\\", \\\"{x:1306,y:822,t:1527019629807};\\\", \\\"{x:1305,y:823,t:1527019629945};\\\", \\\"{x:1303,y:823,t:1527019629957};\\\", \\\"{x:1301,y:823,t:1527019630017};\\\", \\\"{x:1299,y:825,t:1527019630025};\\\", \\\"{x:1296,y:826,t:1527019630040};\\\", \\\"{x:1293,y:827,t:1527019630057};\\\", \\\"{x:1290,y:829,t:1527019630075};\\\", \\\"{x:1287,y:830,t:1527019630091};\\\", \\\"{x:1285,y:832,t:1527019630106};\\\", \\\"{x:1282,y:835,t:1527019630124};\\\", \\\"{x:1281,y:836,t:1527019630140};\\\", \\\"{x:1282,y:836,t:1527019630417};\\\", \\\"{x:1287,y:835,t:1527019630424};\\\", \\\"{x:1293,y:833,t:1527019630440};\\\", \\\"{x:1302,y:830,t:1527019630458};\\\", \\\"{x:1304,y:830,t:1527019630474};\\\", \\\"{x:1307,y:829,t:1527019630492};\\\", \\\"{x:1308,y:829,t:1527019630512};\\\", \\\"{x:1310,y:828,t:1527019630528};\\\", \\\"{x:1312,y:826,t:1527019630552};\\\", \\\"{x:1313,y:826,t:1527019630568};\\\", \\\"{x:1316,y:824,t:1527019630601};\\\", \\\"{x:1317,y:823,t:1527019630617};\\\", \\\"{x:1320,y:823,t:1527019630624};\\\", \\\"{x:1323,y:820,t:1527019630640};\\\", \\\"{x:1324,y:820,t:1527019630664};\\\", \\\"{x:1325,y:820,t:1527019630713};\\\", \\\"{x:1326,y:819,t:1527019630724};\\\", \\\"{x:1331,y:816,t:1527019630741};\\\", \\\"{x:1332,y:816,t:1527019630758};\\\", \\\"{x:1335,y:815,t:1527019630775};\\\", \\\"{x:1337,y:815,t:1527019630855};\\\", \\\"{x:1338,y:815,t:1527019630872};\\\", \\\"{x:1339,y:815,t:1527019630977};\\\", \\\"{x:1340,y:815,t:1527019630991};\\\", \\\"{x:1345,y:818,t:1527019631008};\\\", \\\"{x:1345,y:819,t:1527019631065};\\\", \\\"{x:1345,y:823,t:1527019632121};\\\", \\\"{x:1343,y:829,t:1527019632129};\\\", \\\"{x:1342,y:832,t:1527019632141};\\\", \\\"{x:1333,y:848,t:1527019632159};\\\", \\\"{x:1320,y:870,t:1527019632176};\\\", \\\"{x:1315,y:875,t:1527019632191};\\\", \\\"{x:1310,y:883,t:1527019632208};\\\", \\\"{x:1305,y:890,t:1527019632225};\\\", \\\"{x:1299,y:897,t:1527019632241};\\\", \\\"{x:1292,y:903,t:1527019632258};\\\", \\\"{x:1281,y:911,t:1527019632275};\\\", \\\"{x:1270,y:918,t:1527019632291};\\\", \\\"{x:1267,y:921,t:1527019632308};\\\", \\\"{x:1264,y:924,t:1527019632325};\\\", \\\"{x:1259,y:927,t:1527019632341};\\\", \\\"{x:1258,y:930,t:1527019632358};\\\", \\\"{x:1253,y:936,t:1527019632376};\\\", \\\"{x:1251,y:937,t:1527019632392};\\\", \\\"{x:1244,y:945,t:1527019632408};\\\", \\\"{x:1240,y:948,t:1527019632425};\\\", \\\"{x:1236,y:955,t:1527019632442};\\\", \\\"{x:1235,y:955,t:1527019632472};\\\", \\\"{x:1234,y:956,t:1527019632777};\\\", \\\"{x:1230,y:956,t:1527019632792};\\\", \\\"{x:1215,y:954,t:1527019632809};\\\", \\\"{x:1207,y:951,t:1527019632826};\\\", \\\"{x:1204,y:950,t:1527019632842};\\\", \\\"{x:1203,y:950,t:1527019632858};\\\", \\\"{x:1202,y:948,t:1527019634257};\\\", \\\"{x:1202,y:946,t:1527019634272};\\\", \\\"{x:1203,y:946,t:1527019634280};\\\", \\\"{x:1204,y:944,t:1527019634293};\\\", \\\"{x:1205,y:944,t:1527019634310};\\\", \\\"{x:1206,y:944,t:1527019634593};\\\", \\\"{x:1215,y:948,t:1527019634609};\\\", \\\"{x:1217,y:953,t:1527019634625};\\\", \\\"{x:1220,y:957,t:1527019634642};\\\", \\\"{x:1220,y:958,t:1527019634658};\\\", \\\"{x:1222,y:959,t:1527019634675};\\\", \\\"{x:1222,y:960,t:1527019634807};\\\", \\\"{x:1222,y:961,t:1527019634848};\\\", \\\"{x:1222,y:962,t:1527019634859};\\\", \\\"{x:1222,y:963,t:1527019634880};\\\", \\\"{x:1222,y:964,t:1527019634905};\\\", \\\"{x:1222,y:965,t:1527019634943};\\\", \\\"{x:1222,y:969,t:1527019635377};\\\", \\\"{x:1236,y:977,t:1527019635393};\\\", \\\"{x:1251,y:985,t:1527019635410};\\\", \\\"{x:1263,y:990,t:1527019635427};\\\", \\\"{x:1274,y:996,t:1527019635442};\\\", \\\"{x:1282,y:999,t:1527019635460};\\\", \\\"{x:1286,y:1000,t:1527019635477};\\\", \\\"{x:1289,y:1000,t:1527019635493};\\\", \\\"{x:1291,y:1000,t:1527019635509};\\\", \\\"{x:1292,y:1000,t:1527019635526};\\\", \\\"{x:1294,y:1000,t:1527019635545};\\\", \\\"{x:1296,y:1000,t:1527019635559};\\\", \\\"{x:1298,y:1000,t:1527019635576};\\\", \\\"{x:1299,y:1000,t:1527019635649};\\\", \\\"{x:1300,y:999,t:1527019635729};\\\", \\\"{x:1300,y:997,t:1527019635744};\\\", \\\"{x:1300,y:996,t:1527019635759};\\\", \\\"{x:1299,y:989,t:1527019635777};\\\", \\\"{x:1299,y:988,t:1527019635792};\\\", \\\"{x:1299,y:987,t:1527019635809};\\\", \\\"{x:1299,y:986,t:1527019635826};\\\", \\\"{x:1298,y:983,t:1527019635842};\\\", \\\"{x:1297,y:980,t:1527019635859};\\\", \\\"{x:1295,y:976,t:1527019635876};\\\", \\\"{x:1294,y:974,t:1527019635893};\\\", \\\"{x:1293,y:971,t:1527019635909};\\\", \\\"{x:1292,y:970,t:1527019635926};\\\", \\\"{x:1292,y:968,t:1527019635943};\\\", \\\"{x:1291,y:967,t:1527019635960};\\\", \\\"{x:1290,y:966,t:1527019635976};\\\", \\\"{x:1290,y:965,t:1527019635992};\\\", \\\"{x:1292,y:966,t:1527019636592};\\\", \\\"{x:1302,y:971,t:1527019636609};\\\", \\\"{x:1309,y:975,t:1527019636626};\\\", \\\"{x:1321,y:980,t:1527019636643};\\\", \\\"{x:1330,y:984,t:1527019636660};\\\", \\\"{x:1336,y:986,t:1527019636677};\\\", \\\"{x:1339,y:988,t:1527019636694};\\\", \\\"{x:1340,y:988,t:1527019636709};\\\", \\\"{x:1341,y:988,t:1527019636726};\\\", \\\"{x:1341,y:989,t:1527019636744};\\\", \\\"{x:1342,y:989,t:1527019636793};\\\", \\\"{x:1344,y:989,t:1527019636840};\\\", \\\"{x:1345,y:989,t:1527019637224};\\\", \\\"{x:1345,y:988,t:1527019637240};\\\", \\\"{x:1345,y:986,t:1527019637257};\\\", \\\"{x:1345,y:985,t:1527019637280};\\\", \\\"{x:1345,y:983,t:1527019637297};\\\", \\\"{x:1345,y:982,t:1527019637312};\\\", \\\"{x:1345,y:980,t:1527019637328};\\\", \\\"{x:1345,y:979,t:1527019637352};\\\", \\\"{x:1345,y:977,t:1527019637368};\\\", \\\"{x:1345,y:976,t:1527019637392};\\\", \\\"{x:1345,y:974,t:1527019637409};\\\", \\\"{x:1345,y:973,t:1527019637432};\\\", \\\"{x:1345,y:971,t:1527019637497};\\\", \\\"{x:1345,y:970,t:1527019637536};\\\", \\\"{x:1345,y:968,t:1527019637552};\\\", \\\"{x:1345,y:967,t:1527019637561};\\\", \\\"{x:1344,y:966,t:1527019637576};\\\", \\\"{x:1344,y:965,t:1527019637593};\\\", \\\"{x:1344,y:961,t:1527019637609};\\\", \\\"{x:1343,y:955,t:1527019637627};\\\", \\\"{x:1340,y:949,t:1527019637644};\\\", \\\"{x:1340,y:941,t:1527019637660};\\\", \\\"{x:1338,y:936,t:1527019637676};\\\", \\\"{x:1337,y:932,t:1527019637693};\\\", \\\"{x:1337,y:928,t:1527019637710};\\\", \\\"{x:1337,y:920,t:1527019637727};\\\", \\\"{x:1337,y:913,t:1527019637743};\\\", \\\"{x:1337,y:902,t:1527019637760};\\\", \\\"{x:1338,y:894,t:1527019637777};\\\", \\\"{x:1339,y:882,t:1527019637793};\\\", \\\"{x:1342,y:868,t:1527019637811};\\\", \\\"{x:1344,y:854,t:1527019637826};\\\", \\\"{x:1346,y:843,t:1527019637843};\\\", \\\"{x:1347,y:835,t:1527019637860};\\\", \\\"{x:1348,y:828,t:1527019637876};\\\", \\\"{x:1351,y:819,t:1527019637893};\\\", \\\"{x:1351,y:815,t:1527019637910};\\\", \\\"{x:1352,y:806,t:1527019637926};\\\", \\\"{x:1355,y:796,t:1527019637943};\\\", \\\"{x:1358,y:779,t:1527019637960};\\\", \\\"{x:1360,y:770,t:1527019637976};\\\", \\\"{x:1361,y:760,t:1527019637993};\\\", \\\"{x:1362,y:754,t:1527019638010};\\\", \\\"{x:1363,y:747,t:1527019638026};\\\", \\\"{x:1364,y:738,t:1527019638043};\\\", \\\"{x:1365,y:730,t:1527019638060};\\\", \\\"{x:1365,y:721,t:1527019638076};\\\", \\\"{x:1365,y:712,t:1527019638093};\\\", \\\"{x:1366,y:704,t:1527019638110};\\\", \\\"{x:1367,y:699,t:1527019638125};\\\", \\\"{x:1369,y:692,t:1527019638143};\\\", \\\"{x:1370,y:681,t:1527019638160};\\\", \\\"{x:1370,y:675,t:1527019638176};\\\", \\\"{x:1370,y:667,t:1527019638193};\\\", \\\"{x:1370,y:660,t:1527019638210};\\\", \\\"{x:1371,y:651,t:1527019638227};\\\", \\\"{x:1371,y:645,t:1527019638243};\\\", \\\"{x:1371,y:636,t:1527019638260};\\\", \\\"{x:1371,y:630,t:1527019638276};\\\", \\\"{x:1371,y:623,t:1527019638294};\\\", \\\"{x:1371,y:616,t:1527019638310};\\\", \\\"{x:1371,y:610,t:1527019638326};\\\", \\\"{x:1371,y:606,t:1527019638343};\\\", \\\"{x:1373,y:603,t:1527019638360};\\\", \\\"{x:1373,y:601,t:1527019638376};\\\", \\\"{x:1373,y:599,t:1527019638393};\\\", \\\"{x:1373,y:597,t:1527019638410};\\\", \\\"{x:1373,y:596,t:1527019638431};\\\", \\\"{x:1373,y:595,t:1527019638443};\\\", \\\"{x:1373,y:594,t:1527019638460};\\\", \\\"{x:1373,y:593,t:1527019638476};\\\", \\\"{x:1373,y:592,t:1527019638521};\\\", \\\"{x:1371,y:594,t:1527019638744};\\\", \\\"{x:1368,y:615,t:1527019638760};\\\", \\\"{x:1367,y:636,t:1527019638777};\\\", \\\"{x:1367,y:656,t:1527019638793};\\\", \\\"{x:1367,y:678,t:1527019638811};\\\", \\\"{x:1367,y:693,t:1527019638827};\\\", \\\"{x:1367,y:707,t:1527019638844};\\\", \\\"{x:1367,y:719,t:1527019638860};\\\", \\\"{x:1367,y:730,t:1527019638877};\\\", \\\"{x:1370,y:747,t:1527019638893};\\\", \\\"{x:1375,y:768,t:1527019638910};\\\", \\\"{x:1379,y:785,t:1527019638928};\\\", \\\"{x:1384,y:798,t:1527019638943};\\\", \\\"{x:1387,y:817,t:1527019638960};\\\", \\\"{x:1389,y:826,t:1527019638977};\\\", \\\"{x:1389,y:838,t:1527019638994};\\\", \\\"{x:1389,y:856,t:1527019639010};\\\", \\\"{x:1389,y:875,t:1527019639027};\\\", \\\"{x:1387,y:890,t:1527019639044};\\\", \\\"{x:1383,y:910,t:1527019639060};\\\", \\\"{x:1377,y:928,t:1527019639078};\\\", \\\"{x:1370,y:949,t:1527019639093};\\\", \\\"{x:1368,y:966,t:1527019639110};\\\", \\\"{x:1366,y:980,t:1527019639127};\\\", \\\"{x:1365,y:989,t:1527019639144};\\\", \\\"{x:1364,y:995,t:1527019639160};\\\", \\\"{x:1363,y:997,t:1527019639176};\\\", \\\"{x:1362,y:997,t:1527019639384};\\\", \\\"{x:1362,y:995,t:1527019639393};\\\", \\\"{x:1362,y:989,t:1527019639411};\\\", \\\"{x:1362,y:981,t:1527019639428};\\\", \\\"{x:1362,y:970,t:1527019639443};\\\", \\\"{x:1358,y:960,t:1527019639461};\\\", \\\"{x:1356,y:954,t:1527019639478};\\\", \\\"{x:1355,y:953,t:1527019639493};\\\", \\\"{x:1354,y:952,t:1527019639512};\\\", \\\"{x:1354,y:951,t:1527019639528};\\\", \\\"{x:1354,y:950,t:1527019639543};\\\", \\\"{x:1353,y:943,t:1527019639560};\\\", \\\"{x:1352,y:939,t:1527019639578};\\\", \\\"{x:1352,y:935,t:1527019639593};\\\", \\\"{x:1351,y:931,t:1527019639610};\\\", \\\"{x:1350,y:922,t:1527019639628};\\\", \\\"{x:1349,y:916,t:1527019639643};\\\", \\\"{x:1348,y:914,t:1527019639660};\\\", \\\"{x:1347,y:909,t:1527019639678};\\\", \\\"{x:1346,y:906,t:1527019639694};\\\", \\\"{x:1346,y:901,t:1527019639711};\\\", \\\"{x:1345,y:898,t:1527019639728};\\\", \\\"{x:1344,y:895,t:1527019639743};\\\", \\\"{x:1343,y:890,t:1527019639760};\\\", \\\"{x:1341,y:886,t:1527019639777};\\\", \\\"{x:1339,y:879,t:1527019639794};\\\", \\\"{x:1337,y:874,t:1527019639811};\\\", \\\"{x:1337,y:871,t:1527019639828};\\\", \\\"{x:1336,y:868,t:1527019639843};\\\", \\\"{x:1336,y:864,t:1527019639860};\\\", \\\"{x:1335,y:862,t:1527019639878};\\\", \\\"{x:1335,y:859,t:1527019639893};\\\", \\\"{x:1334,y:857,t:1527019639910};\\\", \\\"{x:1334,y:855,t:1527019639927};\\\", \\\"{x:1333,y:852,t:1527019639943};\\\", \\\"{x:1333,y:846,t:1527019639960};\\\", \\\"{x:1333,y:840,t:1527019639977};\\\", \\\"{x:1333,y:834,t:1527019639993};\\\", \\\"{x:1333,y:826,t:1527019640010};\\\", \\\"{x:1333,y:819,t:1527019640027};\\\", \\\"{x:1335,y:811,t:1527019640043};\\\", \\\"{x:1338,y:802,t:1527019640060};\\\", \\\"{x:1338,y:799,t:1527019640077};\\\", \\\"{x:1339,y:792,t:1527019640094};\\\", \\\"{x:1340,y:787,t:1527019640110};\\\", \\\"{x:1340,y:782,t:1527019640127};\\\", \\\"{x:1342,y:776,t:1527019640144};\\\", \\\"{x:1343,y:775,t:1527019640160};\\\", \\\"{x:1343,y:773,t:1527019640177};\\\", \\\"{x:1343,y:772,t:1527019640195};\\\", \\\"{x:1343,y:770,t:1527019640210};\\\", \\\"{x:1343,y:769,t:1527019640228};\\\", \\\"{x:1343,y:768,t:1527019640245};\\\", \\\"{x:1343,y:767,t:1527019640264};\\\", \\\"{x:1343,y:766,t:1527019640288};\\\", \\\"{x:1343,y:765,t:1527019640296};\\\", \\\"{x:1343,y:763,t:1527019640312};\\\", \\\"{x:1342,y:762,t:1527019640328};\\\", \\\"{x:1342,y:758,t:1527019640343};\\\", \\\"{x:1342,y:755,t:1527019640360};\\\", \\\"{x:1342,y:753,t:1527019640377};\\\", \\\"{x:1342,y:749,t:1527019640394};\\\", \\\"{x:1342,y:746,t:1527019640410};\\\", \\\"{x:1341,y:742,t:1527019640427};\\\", \\\"{x:1341,y:740,t:1527019640444};\\\", \\\"{x:1341,y:739,t:1527019640460};\\\", \\\"{x:1341,y:737,t:1527019640478};\\\", \\\"{x:1341,y:736,t:1527019640494};\\\", \\\"{x:1341,y:734,t:1527019640511};\\\", \\\"{x:1341,y:733,t:1527019640601};\\\", \\\"{x:1341,y:734,t:1527019641360};\\\", \\\"{x:1341,y:743,t:1527019641377};\\\", \\\"{x:1341,y:751,t:1527019641394};\\\", \\\"{x:1341,y:758,t:1527019641412};\\\", \\\"{x:1343,y:765,t:1527019641428};\\\", \\\"{x:1344,y:772,t:1527019641445};\\\", \\\"{x:1347,y:780,t:1527019641462};\\\", \\\"{x:1349,y:788,t:1527019641478};\\\", \\\"{x:1353,y:796,t:1527019641495};\\\", \\\"{x:1356,y:802,t:1527019641512};\\\", \\\"{x:1359,y:811,t:1527019641528};\\\", \\\"{x:1363,y:818,t:1527019641544};\\\", \\\"{x:1364,y:823,t:1527019641562};\\\", \\\"{x:1366,y:826,t:1527019641578};\\\", \\\"{x:1368,y:829,t:1527019641595};\\\", \\\"{x:1369,y:832,t:1527019641611};\\\", \\\"{x:1370,y:833,t:1527019641627};\\\", \\\"{x:1370,y:834,t:1527019641645};\\\", \\\"{x:1370,y:836,t:1527019641661};\\\", \\\"{x:1371,y:836,t:1527019641800};\\\", \\\"{x:1371,y:837,t:1527019641815};\\\", \\\"{x:1370,y:838,t:1527019641831};\\\", \\\"{x:1369,y:838,t:1527019641847};\\\", \\\"{x:1368,y:839,t:1527019641863};\\\", \\\"{x:1365,y:840,t:1527019641951};\\\", \\\"{x:1364,y:841,t:1527019641983};\\\", \\\"{x:1363,y:841,t:1527019642112};\\\", \\\"{x:1361,y:841,t:1527019642128};\\\", \\\"{x:1359,y:841,t:1527019642144};\\\", \\\"{x:1357,y:841,t:1527019642161};\\\", \\\"{x:1355,y:841,t:1527019642178};\\\", \\\"{x:1352,y:841,t:1527019642194};\\\", \\\"{x:1351,y:841,t:1527019642211};\\\", \\\"{x:1350,y:841,t:1527019642232};\\\", \\\"{x:1349,y:841,t:1527019642465};\\\", \\\"{x:1349,y:840,t:1527019642478};\\\", \\\"{x:1347,y:838,t:1527019642494};\\\", \\\"{x:1347,y:837,t:1527019642512};\\\", \\\"{x:1345,y:834,t:1527019642528};\\\", \\\"{x:1344,y:832,t:1527019642545};\\\", \\\"{x:1344,y:831,t:1527019642568};\\\", \\\"{x:1344,y:830,t:1527019642594};\\\", \\\"{x:1343,y:829,t:1527019642612};\\\", \\\"{x:1343,y:828,t:1527019642665};\\\", \\\"{x:1343,y:827,t:1527019642696};\\\", \\\"{x:1343,y:826,t:1527019642737};\\\", \\\"{x:1337,y:813,t:1527019650449};\\\", \\\"{x:1292,y:756,t:1527019650464};\\\", \\\"{x:1249,y:706,t:1527019650481};\\\", \\\"{x:1214,y:674,t:1527019650497};\\\", \\\"{x:1189,y:655,t:1527019650514};\\\", \\\"{x:1172,y:638,t:1527019650531};\\\", \\\"{x:1157,y:628,t:1527019650547};\\\", \\\"{x:1145,y:623,t:1527019650564};\\\", \\\"{x:1138,y:620,t:1527019650581};\\\", \\\"{x:1125,y:619,t:1527019650597};\\\", \\\"{x:1109,y:613,t:1527019650614};\\\", \\\"{x:1089,y:607,t:1527019650631};\\\", \\\"{x:1066,y:598,t:1527019650647};\\\", \\\"{x:1011,y:583,t:1527019650664};\\\", \\\"{x:934,y:574,t:1527019650681};\\\", \\\"{x:849,y:557,t:1527019650697};\\\", \\\"{x:665,y:526,t:1527019650727};\\\", \\\"{x:567,y:509,t:1527019650744};\\\", \\\"{x:438,y:477,t:1527019650761};\\\", \\\"{x:307,y:454,t:1527019650777};\\\", \\\"{x:174,y:435,t:1527019650794};\\\", \\\"{x:68,y:433,t:1527019650810};\\\", \\\"{x:4,y:433,t:1527019650827};\\\", \\\"{x:0,y:437,t:1527019650844};\\\", \\\"{x:0,y:440,t:1527019650860};\\\", \\\"{x:1,y:440,t:1527019650992};\\\", \\\"{x:4,y:442,t:1527019650999};\\\", \\\"{x:6,y:444,t:1527019651011};\\\", \\\"{x:12,y:446,t:1527019651027};\\\", \\\"{x:19,y:455,t:1527019651045};\\\", \\\"{x:28,y:470,t:1527019651061};\\\", \\\"{x:34,y:479,t:1527019651078};\\\", \\\"{x:40,y:481,t:1527019651094};\\\", \\\"{x:43,y:484,t:1527019651111};\\\", \\\"{x:51,y:485,t:1527019651127};\\\", \\\"{x:66,y:487,t:1527019651144};\\\", \\\"{x:82,y:487,t:1527019651161};\\\", \\\"{x:96,y:489,t:1527019651178};\\\", \\\"{x:115,y:489,t:1527019651194};\\\", \\\"{x:140,y:491,t:1527019651212};\\\", \\\"{x:160,y:491,t:1527019651227};\\\", \\\"{x:183,y:492,t:1527019651244};\\\", \\\"{x:193,y:493,t:1527019651261};\\\", \\\"{x:197,y:493,t:1527019651279};\\\", \\\"{x:199,y:493,t:1527019651294};\\\", \\\"{x:208,y:493,t:1527019651311};\\\", \\\"{x:212,y:490,t:1527019651327};\\\", \\\"{x:216,y:490,t:1527019651344};\\\", \\\"{x:227,y:490,t:1527019651362};\\\", \\\"{x:247,y:497,t:1527019651379};\\\", \\\"{x:264,y:506,t:1527019651396};\\\", \\\"{x:274,y:512,t:1527019651412};\\\", \\\"{x:282,y:518,t:1527019651428};\\\", \\\"{x:297,y:524,t:1527019651443};\\\", \\\"{x:327,y:534,t:1527019651461};\\\", \\\"{x:355,y:542,t:1527019651477};\\\", \\\"{x:374,y:548,t:1527019651494};\\\", \\\"{x:386,y:552,t:1527019651512};\\\", \\\"{x:389,y:552,t:1527019651527};\\\", \\\"{x:390,y:552,t:1527019651591};\\\", \\\"{x:391,y:551,t:1527019651599};\\\", \\\"{x:392,y:551,t:1527019651612};\\\", \\\"{x:393,y:550,t:1527019651628};\\\", \\\"{x:394,y:549,t:1527019651753};\\\", \\\"{x:394,y:548,t:1527019651781};\\\", \\\"{x:394,y:545,t:1527019651796};\\\", \\\"{x:392,y:541,t:1527019651812};\\\", \\\"{x:391,y:538,t:1527019651829};\\\", \\\"{x:390,y:537,t:1527019651844};\\\", \\\"{x:390,y:535,t:1527019651861};\\\", \\\"{x:390,y:532,t:1527019651879};\\\", \\\"{x:390,y:531,t:1527019651894};\\\", \\\"{x:390,y:529,t:1527019651911};\\\", \\\"{x:390,y:528,t:1527019651928};\\\", \\\"{x:390,y:523,t:1527019651945};\\\", \\\"{x:390,y:522,t:1527019651962};\\\", \\\"{x:390,y:520,t:1527019651978};\\\", \\\"{x:390,y:519,t:1527019651995};\\\", \\\"{x:389,y:519,t:1527019652415};\\\", \\\"{x:388,y:521,t:1527019652432};\\\", \\\"{x:387,y:524,t:1527019652445};\\\", \\\"{x:385,y:530,t:1527019652462};\\\", \\\"{x:384,y:533,t:1527019652479};\\\", \\\"{x:383,y:537,t:1527019652496};\\\", \\\"{x:383,y:539,t:1527019652512};\\\", \\\"{x:382,y:540,t:1527019652535};\\\", \\\"{x:381,y:541,t:1527019652545};\\\", \\\"{x:379,y:544,t:1527019652564};\\\", \\\"{x:379,y:546,t:1527019652578};\\\", \\\"{x:379,y:547,t:1527019652596};\\\", \\\"{x:379,y:549,t:1527019652612};\\\", \\\"{x:380,y:551,t:1527019653175};\\\", \\\"{x:387,y:556,t:1527019653183};\\\", \\\"{x:391,y:559,t:1527019653195};\\\", \\\"{x:396,y:564,t:1527019653212};\\\", \\\"{x:405,y:572,t:1527019653229};\\\", \\\"{x:415,y:586,t:1527019653246};\\\", \\\"{x:420,y:593,t:1527019653262};\\\", \\\"{x:427,y:615,t:1527019653279};\\\", \\\"{x:428,y:628,t:1527019653296};\\\", \\\"{x:433,y:642,t:1527019653312};\\\", \\\"{x:438,y:652,t:1527019653329};\\\", \\\"{x:449,y:667,t:1527019653347};\\\", \\\"{x:461,y:680,t:1527019653363};\\\", \\\"{x:469,y:693,t:1527019653379};\\\", \\\"{x:474,y:704,t:1527019653396};\\\", \\\"{x:478,y:713,t:1527019653412};\\\", \\\"{x:481,y:718,t:1527019653430};\\\", \\\"{x:482,y:720,t:1527019653447};\\\", \\\"{x:483,y:722,t:1527019653463};\\\", \\\"{x:485,y:722,t:1527019653943};\\\", \\\"{x:488,y:722,t:1527019653959};\\\", \\\"{x:490,y:721,t:1527019653967};\\\", \\\"{x:493,y:720,t:1527019653980};\\\", \\\"{x:508,y:714,t:1527019653997};\\\", \\\"{x:527,y:709,t:1527019654014};\\\", \\\"{x:552,y:697,t:1527019654029};\\\", \\\"{x:602,y:689,t:1527019654046};\\\", \\\"{x:702,y:665,t:1527019654062};\\\", \\\"{x:755,y:657,t:1527019654079};\\\", \\\"{x:805,y:651,t:1527019654096};\\\", \\\"{x:845,y:651,t:1527019654113};\\\", \\\"{x:894,y:653,t:1527019654130};\\\", \\\"{x:936,y:653,t:1527019654147};\\\", \\\"{x:984,y:653,t:1527019654164};\\\", \\\"{x:1017,y:653,t:1527019654179};\\\", \\\"{x:1046,y:653,t:1527019654196};\\\", \\\"{x:1072,y:658,t:1527019654214};\\\", \\\"{x:1094,y:663,t:1527019654229};\\\", \\\"{x:1104,y:666,t:1527019654247};\\\", \\\"{x:1111,y:667,t:1527019654263};\\\", \\\"{x:1106,y:668,t:1527019654568};\\\", \\\"{x:1102,y:668,t:1527019654581};\\\", \\\"{x:1097,y:669,t:1527019654597};\\\", \\\"{x:1089,y:671,t:1527019654614};\\\", \\\"{x:1080,y:672,t:1527019654630};\\\", \\\"{x:1070,y:673,t:1527019654646};\\\", \\\"{x:1045,y:676,t:1527019654664};\\\", \\\"{x:1023,y:678,t:1527019654680};\\\", \\\"{x:1000,y:678,t:1527019654697};\\\", \\\"{x:978,y:675,t:1527019654714};\\\", \\\"{x:939,y:675,t:1527019654731};\\\", \\\"{x:909,y:675,t:1527019654747};\\\", \\\"{x:889,y:674,t:1527019654764};\\\", \\\"{x:861,y:668,t:1527019654785};\\\", \\\"{x:852,y:666,t:1527019654797};\\\", \\\"{x:836,y:664,t:1527019654813};\\\", \\\"{x:812,y:660,t:1527019654830};\\\", \\\"{x:778,y:655,t:1527019654847};\\\", \\\"{x:749,y:651,t:1527019654863};\\\" ] }, { \\\"rt\\\": 84146, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 363493, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-06 PM-05 PM-04 PM-03 PM-C -C -U -04 PM-C -O -O -I -H -H -A -A -F -Z -U -H -J -O -O -O -03 PM-F -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:669,y:636,t:1527019654992};\\\", \\\"{x:668,y:636,t:1527019655352};\\\", \\\"{x:655,y:640,t:1527019655425};\\\", \\\"{x:653,y:640,t:1527019655441};\\\", \\\"{x:651,y:640,t:1527019655447};\\\", \\\"{x:638,y:640,t:1527019655465};\\\", \\\"{x:617,y:631,t:1527019655481};\\\", \\\"{x:597,y:621,t:1527019655497};\\\", \\\"{x:583,y:612,t:1527019655515};\\\", \\\"{x:570,y:603,t:1527019655531};\\\", \\\"{x:557,y:594,t:1527019655548};\\\", \\\"{x:543,y:583,t:1527019655564};\\\", \\\"{x:525,y:567,t:1527019655582};\\\", \\\"{x:509,y:553,t:1527019655598};\\\", \\\"{x:493,y:537,t:1527019655615};\\\", \\\"{x:471,y:517,t:1527019655631};\\\", \\\"{x:464,y:506,t:1527019655647};\\\", \\\"{x:459,y:495,t:1527019655665};\\\", \\\"{x:459,y:490,t:1527019655681};\\\", \\\"{x:459,y:484,t:1527019655697};\\\", \\\"{x:459,y:479,t:1527019655715};\\\", \\\"{x:461,y:477,t:1527019655731};\\\", \\\"{x:463,y:475,t:1527019655752};\\\", \\\"{x:463,y:474,t:1527019655800};\\\", \\\"{x:464,y:474,t:1527019655814};\\\", \\\"{x:466,y:473,t:1527019655832};\\\", \\\"{x:468,y:471,t:1527019655849};\\\", \\\"{x:470,y:470,t:1527019655866};\\\", \\\"{x:476,y:468,t:1527019655881};\\\", \\\"{x:481,y:468,t:1527019655899};\\\", \\\"{x:490,y:467,t:1527019655916};\\\", \\\"{x:498,y:467,t:1527019655932};\\\", \\\"{x:512,y:468,t:1527019655949};\\\", \\\"{x:533,y:473,t:1527019655966};\\\", \\\"{x:560,y:484,t:1527019655983};\\\", \\\"{x:615,y:501,t:1527019656000};\\\", \\\"{x:710,y:530,t:1527019656017};\\\", \\\"{x:768,y:545,t:1527019656033};\\\", \\\"{x:826,y:562,t:1527019656048};\\\", \\\"{x:890,y:581,t:1527019656065};\\\", \\\"{x:957,y:599,t:1527019656082};\\\", \\\"{x:1043,y:624,t:1527019656099};\\\", \\\"{x:1123,y:644,t:1527019656114};\\\", \\\"{x:1200,y:664,t:1527019656132};\\\", \\\"{x:1272,y:682,t:1527019656149};\\\", \\\"{x:1309,y:695,t:1527019656165};\\\", \\\"{x:1341,y:706,t:1527019656182};\\\", \\\"{x:1364,y:715,t:1527019656199};\\\", \\\"{x:1376,y:722,t:1527019656214};\\\", \\\"{x:1404,y:730,t:1527019656231};\\\", \\\"{x:1414,y:738,t:1527019656249};\\\", \\\"{x:1433,y:747,t:1527019656265};\\\", \\\"{x:1441,y:755,t:1527019656282};\\\", \\\"{x:1454,y:764,t:1527019656299};\\\", \\\"{x:1463,y:770,t:1527019656315};\\\", \\\"{x:1475,y:778,t:1527019656332};\\\", \\\"{x:1485,y:788,t:1527019656349};\\\", \\\"{x:1496,y:800,t:1527019656366};\\\", \\\"{x:1509,y:809,t:1527019656382};\\\", \\\"{x:1513,y:815,t:1527019656399};\\\", \\\"{x:1515,y:819,t:1527019656415};\\\", \\\"{x:1519,y:828,t:1527019656431};\\\", \\\"{x:1521,y:835,t:1527019656449};\\\", \\\"{x:1523,y:844,t:1527019656465};\\\", \\\"{x:1524,y:855,t:1527019656482};\\\", \\\"{x:1526,y:862,t:1527019656499};\\\", \\\"{x:1526,y:868,t:1527019656515};\\\", \\\"{x:1526,y:874,t:1527019656532};\\\", \\\"{x:1526,y:879,t:1527019656550};\\\", \\\"{x:1525,y:883,t:1527019656565};\\\", \\\"{x:1525,y:885,t:1527019656617};\\\", \\\"{x:1525,y:890,t:1527019656632};\\\", \\\"{x:1525,y:894,t:1527019656649};\\\", \\\"{x:1521,y:902,t:1527019656665};\\\", \\\"{x:1519,y:909,t:1527019656682};\\\", \\\"{x:1515,y:919,t:1527019656699};\\\", \\\"{x:1512,y:926,t:1527019656715};\\\", \\\"{x:1511,y:931,t:1527019656732};\\\", \\\"{x:1509,y:935,t:1527019656749};\\\", \\\"{x:1508,y:937,t:1527019656766};\\\", \\\"{x:1508,y:938,t:1527019656782};\\\", \\\"{x:1508,y:939,t:1527019656799};\\\", \\\"{x:1508,y:940,t:1527019656864};\\\", \\\"{x:1509,y:940,t:1527019656912};\\\", \\\"{x:1510,y:940,t:1527019656920};\\\", \\\"{x:1511,y:940,t:1527019656932};\\\", \\\"{x:1516,y:940,t:1527019656949};\\\", \\\"{x:1521,y:940,t:1527019656967};\\\", \\\"{x:1528,y:938,t:1527019656982};\\\", \\\"{x:1536,y:935,t:1527019656999};\\\", \\\"{x:1550,y:930,t:1527019657016};\\\", \\\"{x:1562,y:929,t:1527019657032};\\\", \\\"{x:1578,y:926,t:1527019657050};\\\", \\\"{x:1594,y:924,t:1527019657066};\\\", \\\"{x:1606,y:922,t:1527019657083};\\\", \\\"{x:1620,y:922,t:1527019657099};\\\", \\\"{x:1629,y:921,t:1527019657116};\\\", \\\"{x:1635,y:921,t:1527019657132};\\\", \\\"{x:1641,y:921,t:1527019657150};\\\", \\\"{x:1650,y:921,t:1527019657166};\\\", \\\"{x:1656,y:921,t:1527019657182};\\\", \\\"{x:1664,y:922,t:1527019657199};\\\", \\\"{x:1675,y:926,t:1527019657216};\\\", \\\"{x:1687,y:928,t:1527019657232};\\\", \\\"{x:1697,y:932,t:1527019657250};\\\", \\\"{x:1704,y:937,t:1527019657267};\\\", \\\"{x:1714,y:941,t:1527019657283};\\\", \\\"{x:1723,y:946,t:1527019657299};\\\", \\\"{x:1732,y:950,t:1527019657316};\\\", \\\"{x:1742,y:956,t:1527019657332};\\\", \\\"{x:1750,y:964,t:1527019657350};\\\", \\\"{x:1758,y:968,t:1527019657366};\\\", \\\"{x:1765,y:973,t:1527019657382};\\\", \\\"{x:1769,y:976,t:1527019657401};\\\", \\\"{x:1772,y:980,t:1527019657416};\\\", \\\"{x:1773,y:981,t:1527019657432};\\\", \\\"{x:1773,y:982,t:1527019657449};\\\", \\\"{x:1774,y:982,t:1527019657720};\\\", \\\"{x:1774,y:983,t:1527019657792};\\\", \\\"{x:1774,y:984,t:1527019657832};\\\", \\\"{x:1771,y:986,t:1527019657849};\\\", \\\"{x:1755,y:985,t:1527019657866};\\\", \\\"{x:1741,y:984,t:1527019657883};\\\", \\\"{x:1731,y:982,t:1527019657898};\\\", \\\"{x:1714,y:981,t:1527019657917};\\\", \\\"{x:1695,y:981,t:1527019657932};\\\", \\\"{x:1677,y:981,t:1527019657949};\\\", \\\"{x:1664,y:981,t:1527019657966};\\\", \\\"{x:1643,y:981,t:1527019657983};\\\", \\\"{x:1632,y:981,t:1527019657999};\\\", \\\"{x:1627,y:981,t:1527019658016};\\\", \\\"{x:1626,y:981,t:1527019658079};\\\", \\\"{x:1625,y:981,t:1527019658111};\\\", \\\"{x:1620,y:981,t:1527019658120};\\\", \\\"{x:1618,y:981,t:1527019658132};\\\", \\\"{x:1616,y:981,t:1527019658148};\\\", \\\"{x:1611,y:979,t:1527019658166};\\\", \\\"{x:1610,y:979,t:1527019658182};\\\", \\\"{x:1606,y:979,t:1527019658313};\\\", \\\"{x:1601,y:979,t:1527019658320};\\\", \\\"{x:1595,y:979,t:1527019658333};\\\", \\\"{x:1584,y:977,t:1527019658349};\\\", \\\"{x:1558,y:972,t:1527019658366};\\\", \\\"{x:1478,y:949,t:1527019658384};\\\", \\\"{x:1435,y:941,t:1527019658400};\\\", \\\"{x:1409,y:930,t:1527019658416};\\\", \\\"{x:1387,y:925,t:1527019658434};\\\", \\\"{x:1384,y:925,t:1527019658449};\\\", \\\"{x:1374,y:921,t:1527019658466};\\\", \\\"{x:1364,y:915,t:1527019658483};\\\", \\\"{x:1356,y:913,t:1527019658499};\\\", \\\"{x:1348,y:911,t:1527019658516};\\\", \\\"{x:1345,y:911,t:1527019658534};\\\", \\\"{x:1342,y:911,t:1527019658549};\\\", \\\"{x:1341,y:911,t:1527019658566};\\\", \\\"{x:1338,y:911,t:1527019658582};\\\", \\\"{x:1330,y:911,t:1527019658599};\\\", \\\"{x:1308,y:911,t:1527019658616};\\\", \\\"{x:1288,y:911,t:1527019658633};\\\", \\\"{x:1270,y:910,t:1527019658649};\\\", \\\"{x:1251,y:910,t:1527019658667};\\\", \\\"{x:1240,y:911,t:1527019658684};\\\", \\\"{x:1231,y:911,t:1527019658699};\\\", \\\"{x:1228,y:912,t:1527019658716};\\\", \\\"{x:1225,y:914,t:1527019658733};\\\", \\\"{x:1222,y:916,t:1527019658750};\\\", \\\"{x:1221,y:917,t:1527019658767};\\\", \\\"{x:1219,y:919,t:1527019658783};\\\", \\\"{x:1216,y:919,t:1527019658800};\\\", \\\"{x:1215,y:919,t:1527019658816};\\\", \\\"{x:1213,y:919,t:1527019658872};\\\", \\\"{x:1213,y:920,t:1527019658883};\\\", \\\"{x:1216,y:921,t:1527019658936};\\\", \\\"{x:1223,y:923,t:1527019658949};\\\", \\\"{x:1224,y:923,t:1527019658966};\\\", \\\"{x:1229,y:924,t:1527019658983};\\\", \\\"{x:1252,y:924,t:1527019659000};\\\", \\\"{x:1258,y:924,t:1527019659016};\\\", \\\"{x:1265,y:924,t:1527019659033};\\\", \\\"{x:1267,y:923,t:1527019659049};\\\", \\\"{x:1269,y:923,t:1527019659071};\\\", \\\"{x:1269,y:921,t:1527019659241};\\\", \\\"{x:1267,y:919,t:1527019659249};\\\", \\\"{x:1263,y:915,t:1527019659266};\\\", \\\"{x:1254,y:909,t:1527019659283};\\\", \\\"{x:1249,y:899,t:1527019659299};\\\", \\\"{x:1246,y:896,t:1527019659316};\\\", \\\"{x:1243,y:891,t:1527019659334};\\\", \\\"{x:1242,y:886,t:1527019659350};\\\", \\\"{x:1242,y:880,t:1527019659367};\\\", \\\"{x:1247,y:874,t:1527019659384};\\\", \\\"{x:1248,y:869,t:1527019659399};\\\", \\\"{x:1248,y:863,t:1527019659416};\\\", \\\"{x:1248,y:857,t:1527019659433};\\\", \\\"{x:1244,y:855,t:1527019659449};\\\", \\\"{x:1240,y:852,t:1527019659467};\\\", \\\"{x:1239,y:852,t:1527019659483};\\\", \\\"{x:1239,y:851,t:1527019659499};\\\", \\\"{x:1237,y:850,t:1527019659516};\\\", \\\"{x:1236,y:849,t:1527019659534};\\\", \\\"{x:1233,y:848,t:1527019659549};\\\", \\\"{x:1229,y:845,t:1527019659567};\\\", \\\"{x:1225,y:843,t:1527019659583};\\\", \\\"{x:1221,y:841,t:1527019659599};\\\", \\\"{x:1217,y:838,t:1527019659616};\\\", \\\"{x:1214,y:836,t:1527019659633};\\\", \\\"{x:1213,y:833,t:1527019659652};\\\", \\\"{x:1212,y:831,t:1527019659665};\\\", \\\"{x:1212,y:830,t:1527019659683};\\\", \\\"{x:1212,y:829,t:1527019659711};\\\", \\\"{x:1212,y:828,t:1527019659719};\\\", \\\"{x:1212,y:827,t:1527019659732};\\\", \\\"{x:1212,y:826,t:1527019659767};\\\", \\\"{x:1212,y:824,t:1527019659856};\\\", \\\"{x:1214,y:823,t:1527019659976};\\\", \\\"{x:1215,y:823,t:1527019660448};\\\", \\\"{x:1218,y:823,t:1527019660456};\\\", \\\"{x:1221,y:823,t:1527019660467};\\\", \\\"{x:1231,y:823,t:1527019660483};\\\", \\\"{x:1246,y:825,t:1527019660499};\\\", \\\"{x:1263,y:831,t:1527019660516};\\\", \\\"{x:1283,y:836,t:1527019660533};\\\", \\\"{x:1288,y:840,t:1527019660549};\\\", \\\"{x:1305,y:844,t:1527019660566};\\\", \\\"{x:1316,y:847,t:1527019660583};\\\", \\\"{x:1321,y:849,t:1527019660599};\\\", \\\"{x:1328,y:852,t:1527019660615};\\\", \\\"{x:1332,y:853,t:1527019660633};\\\", \\\"{x:1338,y:854,t:1527019660650};\\\", \\\"{x:1343,y:854,t:1527019660666};\\\", \\\"{x:1352,y:856,t:1527019660683};\\\", \\\"{x:1362,y:858,t:1527019660700};\\\", \\\"{x:1374,y:862,t:1527019660717};\\\", \\\"{x:1388,y:866,t:1527019660733};\\\", \\\"{x:1401,y:871,t:1527019660750};\\\", \\\"{x:1413,y:877,t:1527019660766};\\\", \\\"{x:1431,y:885,t:1527019660782};\\\", \\\"{x:1448,y:893,t:1527019660800};\\\", \\\"{x:1460,y:898,t:1527019660816};\\\", \\\"{x:1474,y:902,t:1527019660833};\\\", \\\"{x:1490,y:907,t:1527019660850};\\\", \\\"{x:1501,y:911,t:1527019660866};\\\", \\\"{x:1511,y:914,t:1527019660883};\\\", \\\"{x:1516,y:916,t:1527019660901};\\\", \\\"{x:1518,y:917,t:1527019660917};\\\", \\\"{x:1519,y:917,t:1527019661015};\\\", \\\"{x:1520,y:918,t:1527019661096};\\\", \\\"{x:1520,y:919,t:1527019661103};\\\", \\\"{x:1520,y:920,t:1527019661115};\\\", \\\"{x:1524,y:923,t:1527019661133};\\\", \\\"{x:1529,y:927,t:1527019661150};\\\", \\\"{x:1537,y:933,t:1527019661166};\\\", \\\"{x:1547,y:937,t:1527019661183};\\\", \\\"{x:1567,y:947,t:1527019661200};\\\", \\\"{x:1583,y:952,t:1527019661216};\\\", \\\"{x:1596,y:957,t:1527019661233};\\\", \\\"{x:1608,y:961,t:1527019661250};\\\", \\\"{x:1617,y:963,t:1527019661266};\\\", \\\"{x:1621,y:964,t:1527019661283};\\\", \\\"{x:1623,y:965,t:1527019661300};\\\", \\\"{x:1625,y:966,t:1527019661316};\\\", \\\"{x:1624,y:966,t:1527019661537};\\\", \\\"{x:1621,y:966,t:1527019661550};\\\", \\\"{x:1613,y:963,t:1527019661568};\\\", \\\"{x:1611,y:962,t:1527019661584};\\\", \\\"{x:1610,y:962,t:1527019661600};\\\", \\\"{x:1608,y:962,t:1527019661617};\\\", \\\"{x:1605,y:961,t:1527019661633};\\\", \\\"{x:1603,y:961,t:1527019661651};\\\", \\\"{x:1600,y:961,t:1527019661667};\\\", \\\"{x:1599,y:961,t:1527019661684};\\\", \\\"{x:1598,y:961,t:1527019661737};\\\", \\\"{x:1597,y:960,t:1527019661888};\\\", \\\"{x:1597,y:959,t:1527019661911};\\\", \\\"{x:1597,y:958,t:1527019661927};\\\", \\\"{x:1597,y:957,t:1527019661967};\\\", \\\"{x:1597,y:956,t:1527019662048};\\\", \\\"{x:1597,y:955,t:1527019662072};\\\", \\\"{x:1599,y:955,t:1527019662121};\\\", \\\"{x:1601,y:955,t:1527019662136};\\\", \\\"{x:1604,y:955,t:1527019662152};\\\", \\\"{x:1605,y:956,t:1527019662167};\\\", \\\"{x:1610,y:957,t:1527019662184};\\\", \\\"{x:1613,y:959,t:1527019662200};\\\", \\\"{x:1614,y:960,t:1527019662217};\\\", \\\"{x:1616,y:961,t:1527019662234};\\\", \\\"{x:1621,y:964,t:1527019662251};\\\", \\\"{x:1625,y:967,t:1527019662268};\\\", \\\"{x:1628,y:968,t:1527019662283};\\\", \\\"{x:1629,y:970,t:1527019662304};\\\", \\\"{x:1631,y:970,t:1527019662400};\\\", \\\"{x:1632,y:970,t:1527019662447};\\\", \\\"{x:1634,y:970,t:1527019662784};\\\", \\\"{x:1634,y:969,t:1527019662800};\\\", \\\"{x:1634,y:968,t:1527019662857};\\\", \\\"{x:1633,y:967,t:1527019662929};\\\", \\\"{x:1633,y:966,t:1527019663000};\\\", \\\"{x:1632,y:966,t:1527019663023};\\\", \\\"{x:1631,y:966,t:1527019663264};\\\", \\\"{x:1630,y:965,t:1527019663271};\\\", \\\"{x:1628,y:964,t:1527019663286};\\\", \\\"{x:1627,y:964,t:1527019663300};\\\", \\\"{x:1622,y:964,t:1527019663318};\\\", \\\"{x:1619,y:963,t:1527019663335};\\\", \\\"{x:1615,y:963,t:1527019663351};\\\", \\\"{x:1610,y:961,t:1527019663368};\\\", \\\"{x:1607,y:961,t:1527019663383};\\\", \\\"{x:1602,y:961,t:1527019663401};\\\", \\\"{x:1600,y:960,t:1527019663418};\\\", \\\"{x:1599,y:960,t:1527019663513};\\\", \\\"{x:1598,y:960,t:1527019663616};\\\", \\\"{x:1597,y:959,t:1527019664032};\\\", \\\"{x:1597,y:958,t:1527019664048};\\\", \\\"{x:1598,y:958,t:1527019664152};\\\", \\\"{x:1599,y:958,t:1527019664176};\\\", \\\"{x:1600,y:958,t:1527019664184};\\\", \\\"{x:1603,y:958,t:1527019664200};\\\", \\\"{x:1605,y:958,t:1527019664218};\\\", \\\"{x:1607,y:958,t:1527019664234};\\\", \\\"{x:1608,y:958,t:1527019664272};\\\", \\\"{x:1609,y:958,t:1527019664448};\\\", \\\"{x:1610,y:958,t:1527019664456};\\\", \\\"{x:1611,y:958,t:1527019664496};\\\", \\\"{x:1612,y:958,t:1527019664552};\\\", \\\"{x:1613,y:958,t:1527019664609};\\\", \\\"{x:1614,y:958,t:1527019664768};\\\", \\\"{x:1615,y:958,t:1527019665112};\\\", \\\"{x:1614,y:956,t:1527019665560};\\\", \\\"{x:1602,y:953,t:1527019665568};\\\", \\\"{x:1583,y:948,t:1527019665585};\\\", \\\"{x:1555,y:941,t:1527019665601};\\\", \\\"{x:1485,y:920,t:1527019665618};\\\", \\\"{x:1390,y:886,t:1527019665634};\\\", \\\"{x:1295,y:852,t:1527019665652};\\\", \\\"{x:1216,y:812,t:1527019665667};\\\", \\\"{x:1175,y:786,t:1527019665685};\\\", \\\"{x:1156,y:773,t:1527019665702};\\\", \\\"{x:1148,y:763,t:1527019665717};\\\", \\\"{x:1146,y:761,t:1527019665735};\\\", \\\"{x:1145,y:754,t:1527019665751};\\\", \\\"{x:1145,y:748,t:1527019665767};\\\", \\\"{x:1145,y:740,t:1527019665785};\\\", \\\"{x:1148,y:728,t:1527019665801};\\\", \\\"{x:1149,y:717,t:1527019665817};\\\", \\\"{x:1152,y:707,t:1527019665835};\\\", \\\"{x:1154,y:696,t:1527019665852};\\\", \\\"{x:1157,y:691,t:1527019665867};\\\", \\\"{x:1159,y:687,t:1527019665885};\\\", \\\"{x:1161,y:683,t:1527019665901};\\\", \\\"{x:1163,y:678,t:1527019665918};\\\", \\\"{x:1166,y:671,t:1527019665935};\\\", \\\"{x:1170,y:664,t:1527019665951};\\\", \\\"{x:1174,y:660,t:1527019665968};\\\", \\\"{x:1178,y:655,t:1527019665984};\\\", \\\"{x:1185,y:649,t:1527019666002};\\\", \\\"{x:1190,y:644,t:1527019666018};\\\", \\\"{x:1193,y:639,t:1527019666035};\\\", \\\"{x:1199,y:635,t:1527019666051};\\\", \\\"{x:1201,y:635,t:1527019666068};\\\", \\\"{x:1201,y:634,t:1527019666084};\\\", \\\"{x:1203,y:633,t:1527019666128};\\\", \\\"{x:1205,y:632,t:1527019666136};\\\", \\\"{x:1208,y:631,t:1527019666152};\\\", \\\"{x:1212,y:628,t:1527019666168};\\\", \\\"{x:1215,y:627,t:1527019666185};\\\", \\\"{x:1215,y:626,t:1527019666201};\\\", \\\"{x:1217,y:625,t:1527019666219};\\\", \\\"{x:1218,y:625,t:1527019666256};\\\", \\\"{x:1219,y:625,t:1527019666272};\\\", \\\"{x:1219,y:624,t:1527019666285};\\\", \\\"{x:1220,y:624,t:1527019666301};\\\", \\\"{x:1221,y:624,t:1527019666369};\\\", \\\"{x:1222,y:624,t:1527019666400};\\\", \\\"{x:1223,y:624,t:1527019666504};\\\", \\\"{x:1224,y:624,t:1527019666518};\\\", \\\"{x:1227,y:624,t:1527019666535};\\\", \\\"{x:1228,y:625,t:1527019666551};\\\", \\\"{x:1230,y:627,t:1527019666568};\\\", \\\"{x:1232,y:628,t:1527019666584};\\\", \\\"{x:1234,y:630,t:1527019666602};\\\", \\\"{x:1235,y:632,t:1527019666619};\\\", \\\"{x:1238,y:635,t:1527019666634};\\\", \\\"{x:1240,y:637,t:1527019666651};\\\", \\\"{x:1242,y:638,t:1527019666669};\\\", \\\"{x:1243,y:639,t:1527019666685};\\\", \\\"{x:1244,y:639,t:1527019666702};\\\", \\\"{x:1245,y:640,t:1527019666776};\\\", \\\"{x:1246,y:640,t:1527019666808};\\\", \\\"{x:1248,y:640,t:1527019667568};\\\", \\\"{x:1251,y:641,t:1527019667584};\\\", \\\"{x:1252,y:641,t:1527019667607};\\\", \\\"{x:1253,y:642,t:1527019668265};\\\", \\\"{x:1253,y:641,t:1527019668560};\\\", \\\"{x:1253,y:639,t:1527019668728};\\\", \\\"{x:1250,y:637,t:1527019668736};\\\", \\\"{x:1250,y:636,t:1527019668752};\\\", \\\"{x:1249,y:634,t:1527019668769};\\\", \\\"{x:1248,y:632,t:1527019668787};\\\", \\\"{x:1247,y:630,t:1527019668802};\\\", \\\"{x:1246,y:628,t:1527019668818};\\\", \\\"{x:1245,y:627,t:1527019668836};\\\", \\\"{x:1245,y:626,t:1527019668852};\\\", \\\"{x:1245,y:625,t:1527019668872};\\\", \\\"{x:1244,y:625,t:1527019668984};\\\", \\\"{x:1243,y:625,t:1527019669001};\\\", \\\"{x:1242,y:625,t:1527019669018};\\\", \\\"{x:1240,y:627,t:1527019669035};\\\", \\\"{x:1239,y:633,t:1527019669052};\\\", \\\"{x:1239,y:638,t:1527019669069};\\\", \\\"{x:1239,y:644,t:1527019669085};\\\", \\\"{x:1240,y:649,t:1527019669102};\\\", \\\"{x:1241,y:655,t:1527019669119};\\\", \\\"{x:1244,y:662,t:1527019669136};\\\", \\\"{x:1246,y:663,t:1527019669152};\\\", \\\"{x:1247,y:665,t:1527019669169};\\\", \\\"{x:1247,y:666,t:1527019669200};\\\", \\\"{x:1247,y:667,t:1527019669224};\\\", \\\"{x:1248,y:667,t:1527019669240};\\\", \\\"{x:1248,y:668,t:1527019669256};\\\", \\\"{x:1248,y:669,t:1527019669272};\\\", \\\"{x:1248,y:670,t:1527019669285};\\\", \\\"{x:1249,y:670,t:1527019669303};\\\", \\\"{x:1249,y:669,t:1527019669544};\\\", \\\"{x:1249,y:668,t:1527019669552};\\\", \\\"{x:1249,y:665,t:1527019669568};\\\", \\\"{x:1250,y:664,t:1527019669586};\\\", \\\"{x:1250,y:662,t:1527019669603};\\\", \\\"{x:1250,y:660,t:1527019669619};\\\", \\\"{x:1250,y:659,t:1527019669636};\\\", \\\"{x:1250,y:658,t:1527019669653};\\\", \\\"{x:1250,y:656,t:1527019669669};\\\", \\\"{x:1250,y:653,t:1527019669686};\\\", \\\"{x:1250,y:652,t:1527019669703};\\\", \\\"{x:1250,y:649,t:1527019669719};\\\", \\\"{x:1250,y:646,t:1527019669736};\\\", \\\"{x:1250,y:645,t:1527019669752};\\\", \\\"{x:1250,y:643,t:1527019669769};\\\", \\\"{x:1250,y:641,t:1527019669786};\\\", \\\"{x:1250,y:640,t:1527019669832};\\\", \\\"{x:1251,y:639,t:1527019669840};\\\", \\\"{x:1251,y:638,t:1527019669855};\\\", \\\"{x:1251,y:637,t:1527019669869};\\\", \\\"{x:1251,y:636,t:1527019669911};\\\", \\\"{x:1251,y:635,t:1527019669935};\\\", \\\"{x:1251,y:634,t:1527019669959};\\\", \\\"{x:1250,y:634,t:1527019670256};\\\", \\\"{x:1249,y:634,t:1527019670271};\\\", \\\"{x:1249,y:635,t:1527019670287};\\\", \\\"{x:1249,y:637,t:1527019670303};\\\", \\\"{x:1249,y:639,t:1527019670318};\\\", \\\"{x:1249,y:643,t:1527019670335};\\\", \\\"{x:1249,y:645,t:1527019670353};\\\", \\\"{x:1249,y:649,t:1527019670368};\\\", \\\"{x:1249,y:654,t:1527019670385};\\\", \\\"{x:1249,y:660,t:1527019670402};\\\", \\\"{x:1249,y:665,t:1527019670419};\\\", \\\"{x:1249,y:671,t:1527019670435};\\\", \\\"{x:1249,y:677,t:1527019670452};\\\", \\\"{x:1249,y:684,t:1527019670469};\\\", \\\"{x:1249,y:688,t:1527019670486};\\\", \\\"{x:1249,y:693,t:1527019670503};\\\", \\\"{x:1247,y:700,t:1527019670518};\\\", \\\"{x:1247,y:709,t:1527019670535};\\\", \\\"{x:1247,y:715,t:1527019670553};\\\", \\\"{x:1247,y:720,t:1527019670569};\\\", \\\"{x:1247,y:722,t:1527019670586};\\\", \\\"{x:1248,y:725,t:1527019670603};\\\", \\\"{x:1251,y:728,t:1527019670619};\\\", \\\"{x:1252,y:731,t:1527019670636};\\\", \\\"{x:1253,y:733,t:1527019670653};\\\", \\\"{x:1254,y:734,t:1527019670669};\\\", \\\"{x:1254,y:735,t:1527019670704};\\\", \\\"{x:1255,y:736,t:1527019670719};\\\", \\\"{x:1255,y:737,t:1527019670776};\\\", \\\"{x:1255,y:738,t:1527019670786};\\\", \\\"{x:1255,y:739,t:1527019670803};\\\", \\\"{x:1255,y:740,t:1527019670820};\\\", \\\"{x:1255,y:742,t:1527019670836};\\\", \\\"{x:1255,y:743,t:1527019670856};\\\", \\\"{x:1255,y:744,t:1527019670869};\\\", \\\"{x:1255,y:745,t:1527019670888};\\\", \\\"{x:1255,y:746,t:1527019670911};\\\", \\\"{x:1255,y:747,t:1527019670920};\\\", \\\"{x:1255,y:748,t:1527019670944};\\\", \\\"{x:1254,y:750,t:1527019670984};\\\", \\\"{x:1254,y:751,t:1527019671000};\\\", \\\"{x:1254,y:752,t:1527019671121};\\\", \\\"{x:1254,y:753,t:1527019671184};\\\", \\\"{x:1254,y:754,t:1527019671192};\\\", \\\"{x:1254,y:755,t:1527019671312};\\\", \\\"{x:1254,y:757,t:1527019671376};\\\", \\\"{x:1254,y:758,t:1527019671416};\\\", \\\"{x:1254,y:759,t:1527019671456};\\\", \\\"{x:1254,y:760,t:1527019671560};\\\", \\\"{x:1254,y:761,t:1527019671584};\\\", \\\"{x:1254,y:762,t:1527019671808};\\\", \\\"{x:1252,y:762,t:1527019671928};\\\", \\\"{x:1251,y:762,t:1527019671952};\\\", \\\"{x:1250,y:762,t:1527019671976};\\\", \\\"{x:1249,y:762,t:1527019671986};\\\", \\\"{x:1248,y:762,t:1527019672003};\\\", \\\"{x:1247,y:762,t:1527019672080};\\\", \\\"{x:1246,y:761,t:1527019672161};\\\", \\\"{x:1245,y:761,t:1527019672433};\\\", \\\"{x:1245,y:764,t:1527019672439};\\\", \\\"{x:1245,y:765,t:1527019672453};\\\", \\\"{x:1246,y:772,t:1527019672469};\\\", \\\"{x:1246,y:779,t:1527019672487};\\\", \\\"{x:1249,y:782,t:1527019672503};\\\", \\\"{x:1249,y:790,t:1527019672520};\\\", \\\"{x:1252,y:793,t:1527019672536};\\\", \\\"{x:1253,y:797,t:1527019672553};\\\", \\\"{x:1255,y:799,t:1527019672569};\\\", \\\"{x:1257,y:802,t:1527019672586};\\\", \\\"{x:1259,y:807,t:1527019672602};\\\", \\\"{x:1260,y:812,t:1527019672619};\\\", \\\"{x:1260,y:817,t:1527019672637};\\\", \\\"{x:1260,y:821,t:1527019672653};\\\", \\\"{x:1260,y:823,t:1527019672669};\\\", \\\"{x:1260,y:824,t:1527019672686};\\\", \\\"{x:1261,y:826,t:1527019672702};\\\", \\\"{x:1261,y:828,t:1527019672719};\\\", \\\"{x:1261,y:829,t:1527019672736};\\\", \\\"{x:1261,y:831,t:1527019672752};\\\", \\\"{x:1261,y:833,t:1527019672770};\\\", \\\"{x:1260,y:834,t:1527019672786};\\\", \\\"{x:1259,y:835,t:1527019672803};\\\", \\\"{x:1258,y:836,t:1527019672819};\\\", \\\"{x:1257,y:837,t:1527019672847};\\\", \\\"{x:1256,y:837,t:1527019672871};\\\", \\\"{x:1255,y:839,t:1527019672895};\\\", \\\"{x:1254,y:841,t:1527019672911};\\\", \\\"{x:1253,y:842,t:1527019672927};\\\", \\\"{x:1252,y:843,t:1527019672937};\\\", \\\"{x:1250,y:846,t:1527019672952};\\\", \\\"{x:1248,y:849,t:1527019672970};\\\", \\\"{x:1247,y:854,t:1527019672986};\\\", \\\"{x:1244,y:857,t:1527019673002};\\\", \\\"{x:1243,y:858,t:1527019673020};\\\", \\\"{x:1243,y:863,t:1527019673036};\\\", \\\"{x:1243,y:864,t:1527019673052};\\\", \\\"{x:1243,y:866,t:1527019673071};\\\", \\\"{x:1243,y:867,t:1527019673168};\\\", \\\"{x:1243,y:869,t:1527019673256};\\\", \\\"{x:1243,y:871,t:1527019673272};\\\", \\\"{x:1243,y:873,t:1527019673287};\\\", \\\"{x:1242,y:874,t:1527019673303};\\\", \\\"{x:1241,y:874,t:1527019673369};\\\", \\\"{x:1241,y:876,t:1527019673440};\\\", \\\"{x:1240,y:877,t:1527019673456};\\\", \\\"{x:1240,y:880,t:1527019673471};\\\", \\\"{x:1240,y:881,t:1527019674064};\\\", \\\"{x:1239,y:883,t:1527019674072};\\\", \\\"{x:1242,y:888,t:1527019674087};\\\", \\\"{x:1245,y:900,t:1527019674104};\\\", \\\"{x:1249,y:906,t:1527019674120};\\\", \\\"{x:1249,y:909,t:1527019674137};\\\", \\\"{x:1252,y:913,t:1527019674154};\\\", \\\"{x:1252,y:915,t:1527019674169};\\\", \\\"{x:1252,y:918,t:1527019674187};\\\", \\\"{x:1252,y:922,t:1527019674204};\\\", \\\"{x:1253,y:924,t:1527019674220};\\\", \\\"{x:1254,y:926,t:1527019674237};\\\", \\\"{x:1254,y:927,t:1527019674254};\\\", \\\"{x:1254,y:929,t:1527019674271};\\\", \\\"{x:1254,y:931,t:1527019674287};\\\", \\\"{x:1254,y:932,t:1527019674304};\\\", \\\"{x:1255,y:934,t:1527019674320};\\\", \\\"{x:1256,y:935,t:1527019674337};\\\", \\\"{x:1256,y:937,t:1527019674354};\\\", \\\"{x:1256,y:939,t:1527019674370};\\\", \\\"{x:1256,y:944,t:1527019674387};\\\", \\\"{x:1256,y:947,t:1527019674404};\\\", \\\"{x:1256,y:952,t:1527019674420};\\\", \\\"{x:1256,y:958,t:1527019674437};\\\", \\\"{x:1255,y:962,t:1527019674454};\\\", \\\"{x:1254,y:966,t:1527019674470};\\\", \\\"{x:1253,y:969,t:1527019674489};\\\", \\\"{x:1252,y:969,t:1527019674503};\\\", \\\"{x:1251,y:971,t:1527019674520};\\\", \\\"{x:1250,y:972,t:1527019674537};\\\", \\\"{x:1249,y:973,t:1527019674559};\\\", \\\"{x:1249,y:974,t:1527019674575};\\\", \\\"{x:1249,y:973,t:1527019675123};\\\", \\\"{x:1248,y:971,t:1527019675140};\\\", \\\"{x:1248,y:969,t:1527019675157};\\\", \\\"{x:1248,y:968,t:1527019675179};\\\", \\\"{x:1248,y:966,t:1527019675190};\\\", \\\"{x:1248,y:965,t:1527019675207};\\\", \\\"{x:1248,y:962,t:1527019675223};\\\", \\\"{x:1245,y:960,t:1527019675240};\\\", \\\"{x:1245,y:957,t:1527019675257};\\\", \\\"{x:1245,y:956,t:1527019675273};\\\", \\\"{x:1244,y:954,t:1527019675291};\\\", \\\"{x:1243,y:954,t:1527019675307};\\\", \\\"{x:1243,y:953,t:1527019675347};\\\", \\\"{x:1243,y:952,t:1527019675899};\\\", \\\"{x:1243,y:950,t:1527019675923};\\\", \\\"{x:1242,y:948,t:1527019675947};\\\", \\\"{x:1242,y:947,t:1527019675963};\\\", \\\"{x:1242,y:946,t:1527019675979};\\\", \\\"{x:1242,y:945,t:1527019675995};\\\", \\\"{x:1242,y:944,t:1527019676007};\\\", \\\"{x:1242,y:940,t:1527019676024};\\\", \\\"{x:1243,y:935,t:1527019676040};\\\", \\\"{x:1248,y:925,t:1527019676058};\\\", \\\"{x:1254,y:913,t:1527019676074};\\\", \\\"{x:1260,y:899,t:1527019676090};\\\", \\\"{x:1270,y:876,t:1527019676107};\\\", \\\"{x:1276,y:854,t:1527019676124};\\\", \\\"{x:1280,y:831,t:1527019676141};\\\", \\\"{x:1282,y:816,t:1527019676157};\\\", \\\"{x:1285,y:801,t:1527019676174};\\\", \\\"{x:1290,y:779,t:1527019676191};\\\", \\\"{x:1292,y:761,t:1527019676207};\\\", \\\"{x:1296,y:743,t:1527019676224};\\\", \\\"{x:1297,y:726,t:1527019676241};\\\", \\\"{x:1300,y:707,t:1527019676257};\\\", \\\"{x:1302,y:686,t:1527019676275};\\\", \\\"{x:1305,y:657,t:1527019676291};\\\", \\\"{x:1305,y:637,t:1527019676307};\\\", \\\"{x:1305,y:623,t:1527019676325};\\\", \\\"{x:1305,y:608,t:1527019676340};\\\", \\\"{x:1305,y:593,t:1527019676358};\\\", \\\"{x:1305,y:575,t:1527019676375};\\\", \\\"{x:1305,y:557,t:1527019676390};\\\", \\\"{x:1306,y:542,t:1527019676407};\\\", \\\"{x:1307,y:532,t:1527019676424};\\\", \\\"{x:1307,y:521,t:1527019676441};\\\", \\\"{x:1307,y:517,t:1527019676457};\\\", \\\"{x:1307,y:514,t:1527019676474};\\\", \\\"{x:1308,y:511,t:1527019676490};\\\", \\\"{x:1310,y:507,t:1527019676507};\\\", \\\"{x:1311,y:505,t:1527019676524};\\\", \\\"{x:1313,y:502,t:1527019676541};\\\", \\\"{x:1314,y:498,t:1527019676557};\\\", \\\"{x:1316,y:495,t:1527019676574};\\\", \\\"{x:1318,y:492,t:1527019676591};\\\", \\\"{x:1318,y:491,t:1527019678124};\\\", \\\"{x:1319,y:490,t:1527019680330};\\\", \\\"{x:1321,y:490,t:1527019680341};\\\", \\\"{x:1325,y:497,t:1527019680358};\\\", \\\"{x:1331,y:505,t:1527019680375};\\\", \\\"{x:1342,y:516,t:1527019680391};\\\", \\\"{x:1353,y:520,t:1527019680408};\\\", \\\"{x:1364,y:526,t:1527019680425};\\\", \\\"{x:1373,y:531,t:1527019680441};\\\", \\\"{x:1389,y:536,t:1527019680459};\\\", \\\"{x:1401,y:540,t:1527019680475};\\\", \\\"{x:1406,y:540,t:1527019680492};\\\", \\\"{x:1411,y:543,t:1527019680508};\\\", \\\"{x:1414,y:543,t:1527019680525};\\\", \\\"{x:1416,y:544,t:1527019680603};\\\", \\\"{x:1417,y:545,t:1527019680619};\\\", \\\"{x:1419,y:546,t:1527019680627};\\\", \\\"{x:1421,y:548,t:1527019680643};\\\", \\\"{x:1426,y:552,t:1527019680659};\\\", \\\"{x:1430,y:555,t:1527019680675};\\\", \\\"{x:1434,y:560,t:1527019680691};\\\", \\\"{x:1439,y:562,t:1527019680708};\\\", \\\"{x:1439,y:563,t:1527019680726};\\\", \\\"{x:1440,y:563,t:1527019680742};\\\", \\\"{x:1441,y:564,t:1527019680763};\\\", \\\"{x:1440,y:564,t:1527019681018};\\\", \\\"{x:1439,y:564,t:1527019681027};\\\", \\\"{x:1438,y:564,t:1527019681041};\\\", \\\"{x:1435,y:564,t:1527019681059};\\\", \\\"{x:1433,y:563,t:1527019681075};\\\", \\\"{x:1433,y:562,t:1527019681091};\\\", \\\"{x:1431,y:562,t:1527019681123};\\\", \\\"{x:1428,y:562,t:1527019681130};\\\", \\\"{x:1427,y:562,t:1527019681142};\\\", \\\"{x:1420,y:562,t:1527019681159};\\\", \\\"{x:1416,y:562,t:1527019681176};\\\", \\\"{x:1409,y:562,t:1527019681192};\\\", \\\"{x:1407,y:562,t:1527019681209};\\\", \\\"{x:1406,y:562,t:1527019681226};\\\", \\\"{x:1403,y:563,t:1527019681660};\\\", \\\"{x:1400,y:570,t:1527019681675};\\\", \\\"{x:1397,y:576,t:1527019681691};\\\", \\\"{x:1396,y:582,t:1527019681708};\\\", \\\"{x:1395,y:590,t:1527019681725};\\\", \\\"{x:1395,y:601,t:1527019681743};\\\", \\\"{x:1397,y:612,t:1527019681759};\\\", \\\"{x:1399,y:625,t:1527019681775};\\\", \\\"{x:1402,y:638,t:1527019681793};\\\", \\\"{x:1402,y:648,t:1527019681809};\\\", \\\"{x:1401,y:662,t:1527019681826};\\\", \\\"{x:1397,y:681,t:1527019681843};\\\", \\\"{x:1394,y:691,t:1527019681859};\\\", \\\"{x:1393,y:695,t:1527019681876};\\\", \\\"{x:1392,y:701,t:1527019681893};\\\", \\\"{x:1385,y:705,t:1527019681908};\\\", \\\"{x:1383,y:710,t:1527019681925};\\\", \\\"{x:1377,y:715,t:1527019681943};\\\", \\\"{x:1376,y:716,t:1527019681958};\\\", \\\"{x:1374,y:717,t:1527019681976};\\\", \\\"{x:1373,y:718,t:1527019681993};\\\", \\\"{x:1368,y:720,t:1527019682009};\\\", \\\"{x:1364,y:722,t:1527019682026};\\\", \\\"{x:1361,y:724,t:1527019682043};\\\", \\\"{x:1357,y:727,t:1527019682059};\\\", \\\"{x:1352,y:729,t:1527019682076};\\\", \\\"{x:1347,y:731,t:1527019682092};\\\", \\\"{x:1342,y:736,t:1527019682109};\\\", \\\"{x:1338,y:740,t:1527019682126};\\\", \\\"{x:1333,y:745,t:1527019682142};\\\", \\\"{x:1330,y:746,t:1527019682159};\\\", \\\"{x:1326,y:748,t:1527019682175};\\\", \\\"{x:1324,y:749,t:1527019682192};\\\", \\\"{x:1322,y:750,t:1527019682211};\\\", \\\"{x:1321,y:752,t:1527019682227};\\\", \\\"{x:1320,y:752,t:1527019682251};\\\", \\\"{x:1319,y:752,t:1527019682259};\\\", \\\"{x:1318,y:753,t:1527019682275};\\\", \\\"{x:1318,y:754,t:1527019682380};\\\", \\\"{x:1317,y:756,t:1527019682393};\\\", \\\"{x:1315,y:757,t:1527019682408};\\\", \\\"{x:1315,y:758,t:1527019682426};\\\", \\\"{x:1314,y:759,t:1527019682442};\\\", \\\"{x:1315,y:760,t:1527019683563};\\\", \\\"{x:1318,y:760,t:1527019683576};\\\", \\\"{x:1323,y:762,t:1527019683594};\\\", \\\"{x:1327,y:762,t:1527019683609};\\\", \\\"{x:1331,y:764,t:1527019683625};\\\", \\\"{x:1342,y:768,t:1527019683642};\\\", \\\"{x:1348,y:770,t:1527019683659};\\\", \\\"{x:1356,y:772,t:1527019683675};\\\", \\\"{x:1363,y:773,t:1527019683693};\\\", \\\"{x:1366,y:774,t:1527019683709};\\\", \\\"{x:1367,y:774,t:1527019683725};\\\", \\\"{x:1369,y:774,t:1527019683770};\\\", \\\"{x:1371,y:773,t:1527019683788};\\\", \\\"{x:1372,y:771,t:1527019683795};\\\", \\\"{x:1374,y:770,t:1527019683811};\\\", \\\"{x:1376,y:769,t:1527019683827};\\\", \\\"{x:1377,y:768,t:1527019683843};\\\", \\\"{x:1379,y:766,t:1527019683963};\\\", \\\"{x:1380,y:765,t:1527019683992};\\\", \\\"{x:1380,y:764,t:1527019684010};\\\", \\\"{x:1381,y:761,t:1527019684025};\\\", \\\"{x:1382,y:759,t:1527019684042};\\\", \\\"{x:1383,y:758,t:1527019684059};\\\", \\\"{x:1385,y:755,t:1527019684077};\\\", \\\"{x:1385,y:754,t:1527019684092};\\\", \\\"{x:1386,y:752,t:1527019684110};\\\", \\\"{x:1386,y:751,t:1527019684170};\\\", \\\"{x:1386,y:750,t:1527019684595};\\\", \\\"{x:1388,y:749,t:1527019692835};\\\", \\\"{x:1394,y:744,t:1527019692845};\\\", \\\"{x:1404,y:741,t:1527019692862};\\\", \\\"{x:1407,y:738,t:1527019692878};\\\", \\\"{x:1409,y:737,t:1527019692896};\\\", \\\"{x:1410,y:737,t:1527019694419};\\\", \\\"{x:1410,y:738,t:1527019694467};\\\", \\\"{x:1410,y:739,t:1527019694491};\\\", \\\"{x:1409,y:740,t:1527019694523};\\\", \\\"{x:1409,y:741,t:1527019694539};\\\", \\\"{x:1409,y:742,t:1527019694547};\\\", \\\"{x:1408,y:744,t:1527019694562};\\\", \\\"{x:1407,y:746,t:1527019694580};\\\", \\\"{x:1406,y:748,t:1527019694595};\\\", \\\"{x:1406,y:749,t:1527019694613};\\\", \\\"{x:1404,y:753,t:1527019694629};\\\", \\\"{x:1403,y:755,t:1527019694645};\\\", \\\"{x:1403,y:757,t:1527019694663};\\\", \\\"{x:1400,y:760,t:1527019694680};\\\", \\\"{x:1399,y:764,t:1527019694696};\\\", \\\"{x:1396,y:770,t:1527019694712};\\\", \\\"{x:1394,y:776,t:1527019694729};\\\", \\\"{x:1390,y:785,t:1527019694745};\\\", \\\"{x:1388,y:793,t:1527019694762};\\\", \\\"{x:1386,y:805,t:1527019694779};\\\", \\\"{x:1386,y:811,t:1527019694795};\\\", \\\"{x:1386,y:819,t:1527019694812};\\\", \\\"{x:1386,y:829,t:1527019694829};\\\", \\\"{x:1386,y:840,t:1527019694845};\\\", \\\"{x:1386,y:851,t:1527019694861};\\\", \\\"{x:1386,y:862,t:1527019694879};\\\", \\\"{x:1392,y:874,t:1527019694894};\\\", \\\"{x:1398,y:889,t:1527019694912};\\\", \\\"{x:1402,y:898,t:1527019694928};\\\", \\\"{x:1408,y:910,t:1527019694945};\\\", \\\"{x:1409,y:919,t:1527019694961};\\\", \\\"{x:1415,y:929,t:1527019694979};\\\", \\\"{x:1417,y:934,t:1527019694995};\\\", \\\"{x:1418,y:937,t:1527019695011};\\\", \\\"{x:1421,y:940,t:1527019695029};\\\", \\\"{x:1421,y:943,t:1527019695045};\\\", \\\"{x:1421,y:945,t:1527019695062};\\\", \\\"{x:1421,y:947,t:1527019695079};\\\", \\\"{x:1421,y:949,t:1527019695095};\\\", \\\"{x:1421,y:950,t:1527019695403};\\\", \\\"{x:1421,y:952,t:1527019695452};\\\", \\\"{x:1421,y:953,t:1527019695462};\\\", \\\"{x:1421,y:954,t:1527019695479};\\\", \\\"{x:1420,y:954,t:1527019695986};\\\", \\\"{x:1421,y:952,t:1527019695995};\\\", \\\"{x:1422,y:949,t:1527019696012};\\\", \\\"{x:1424,y:945,t:1527019696028};\\\", \\\"{x:1426,y:939,t:1527019696046};\\\", \\\"{x:1427,y:935,t:1527019696062};\\\", \\\"{x:1428,y:932,t:1527019696079};\\\", \\\"{x:1429,y:929,t:1527019696095};\\\", \\\"{x:1431,y:924,t:1527019696112};\\\", \\\"{x:1435,y:917,t:1527019696128};\\\", \\\"{x:1436,y:911,t:1527019696146};\\\", \\\"{x:1437,y:908,t:1527019696162};\\\", \\\"{x:1437,y:905,t:1527019696179};\\\", \\\"{x:1438,y:902,t:1527019696196};\\\", \\\"{x:1438,y:900,t:1527019696212};\\\", \\\"{x:1439,y:898,t:1527019696228};\\\", \\\"{x:1440,y:896,t:1527019696246};\\\", \\\"{x:1440,y:895,t:1527019696266};\\\", \\\"{x:1439,y:895,t:1527019696610};\\\", \\\"{x:1437,y:898,t:1527019696618};\\\", \\\"{x:1432,y:899,t:1527019696629};\\\", \\\"{x:1428,y:902,t:1527019696646};\\\", \\\"{x:1424,y:903,t:1527019696662};\\\", \\\"{x:1421,y:904,t:1527019696679};\\\", \\\"{x:1420,y:904,t:1527019696696};\\\", \\\"{x:1421,y:904,t:1527019696859};\\\", \\\"{x:1422,y:903,t:1527019696867};\\\", \\\"{x:1423,y:903,t:1527019696891};\\\", \\\"{x:1424,y:903,t:1527019696931};\\\", \\\"{x:1424,y:902,t:1527019696946};\\\", \\\"{x:1426,y:901,t:1527019696962};\\\", \\\"{x:1426,y:900,t:1527019696980};\\\", \\\"{x:1426,y:899,t:1527019696997};\\\", \\\"{x:1426,y:898,t:1527019697012};\\\", \\\"{x:1427,y:897,t:1527019697030};\\\", \\\"{x:1425,y:897,t:1527019697203};\\\", \\\"{x:1422,y:896,t:1527019697227};\\\", \\\"{x:1420,y:896,t:1527019697244};\\\", \\\"{x:1418,y:896,t:1527019697263};\\\", \\\"{x:1417,y:896,t:1527019697279};\\\", \\\"{x:1416,y:895,t:1527019697379};\\\", \\\"{x:1416,y:893,t:1527019697746};\\\", \\\"{x:1417,y:893,t:1527019697819};\\\", \\\"{x:1418,y:893,t:1527019697835};\\\", \\\"{x:1419,y:893,t:1527019698579};\\\", \\\"{x:1426,y:890,t:1527019698597};\\\", \\\"{x:1433,y:888,t:1527019698613};\\\", \\\"{x:1440,y:886,t:1527019698630};\\\", \\\"{x:1442,y:885,t:1527019698646};\\\", \\\"{x:1443,y:885,t:1527019699035};\\\", \\\"{x:1443,y:881,t:1527019699046};\\\", \\\"{x:1435,y:872,t:1527019699064};\\\", \\\"{x:1430,y:869,t:1527019699080};\\\", \\\"{x:1426,y:867,t:1527019699097};\\\", \\\"{x:1422,y:865,t:1527019699114};\\\", \\\"{x:1419,y:864,t:1527019699130};\\\", \\\"{x:1417,y:864,t:1527019699195};\\\", \\\"{x:1416,y:864,t:1527019699214};\\\", \\\"{x:1412,y:866,t:1527019699231};\\\", \\\"{x:1407,y:871,t:1527019699247};\\\", \\\"{x:1403,y:874,t:1527019699264};\\\", \\\"{x:1402,y:876,t:1527019699281};\\\", \\\"{x:1402,y:874,t:1527019699963};\\\", \\\"{x:1404,y:867,t:1527019699981};\\\", \\\"{x:1405,y:864,t:1527019699996};\\\", \\\"{x:1408,y:859,t:1527019700013};\\\", \\\"{x:1408,y:855,t:1527019700031};\\\", \\\"{x:1408,y:852,t:1527019700047};\\\", \\\"{x:1408,y:848,t:1527019700063};\\\", \\\"{x:1408,y:843,t:1527019700081};\\\", \\\"{x:1409,y:839,t:1527019700098};\\\", \\\"{x:1409,y:834,t:1527019700113};\\\", \\\"{x:1411,y:826,t:1527019700131};\\\", \\\"{x:1411,y:821,t:1527019700147};\\\", \\\"{x:1411,y:818,t:1527019700164};\\\", \\\"{x:1411,y:814,t:1527019700181};\\\", \\\"{x:1411,y:812,t:1527019700197};\\\", \\\"{x:1411,y:810,t:1527019700214};\\\", \\\"{x:1412,y:807,t:1527019700230};\\\", \\\"{x:1412,y:803,t:1527019700248};\\\", \\\"{x:1414,y:796,t:1527019700264};\\\", \\\"{x:1415,y:792,t:1527019700280};\\\", \\\"{x:1416,y:785,t:1527019700297};\\\", \\\"{x:1417,y:781,t:1527019700313};\\\", \\\"{x:1417,y:775,t:1527019700331};\\\", \\\"{x:1417,y:764,t:1527019700346};\\\", \\\"{x:1419,y:750,t:1527019700364};\\\", \\\"{x:1419,y:740,t:1527019700380};\\\", \\\"{x:1420,y:728,t:1527019700397};\\\", \\\"{x:1422,y:716,t:1527019700414};\\\", \\\"{x:1422,y:708,t:1527019700430};\\\", \\\"{x:1422,y:704,t:1527019700448};\\\", \\\"{x:1422,y:698,t:1527019700464};\\\", \\\"{x:1422,y:694,t:1527019700481};\\\", \\\"{x:1422,y:689,t:1527019700498};\\\", \\\"{x:1422,y:681,t:1527019700514};\\\", \\\"{x:1422,y:668,t:1527019700531};\\\", \\\"{x:1422,y:662,t:1527019700547};\\\", \\\"{x:1422,y:650,t:1527019700564};\\\", \\\"{x:1422,y:640,t:1527019700580};\\\", \\\"{x:1422,y:631,t:1527019700597};\\\", \\\"{x:1422,y:625,t:1527019700613};\\\", \\\"{x:1421,y:620,t:1527019700631};\\\", \\\"{x:1421,y:615,t:1527019700647};\\\", \\\"{x:1420,y:609,t:1527019700664};\\\", \\\"{x:1418,y:605,t:1527019700681};\\\", \\\"{x:1418,y:601,t:1527019700698};\\\", \\\"{x:1417,y:595,t:1527019700714};\\\", \\\"{x:1416,y:591,t:1527019700730};\\\", \\\"{x:1416,y:590,t:1527019700748};\\\", \\\"{x:1415,y:587,t:1527019700764};\\\", \\\"{x:1415,y:586,t:1527019700780};\\\", \\\"{x:1415,y:584,t:1527019700798};\\\", \\\"{x:1415,y:583,t:1527019700827};\\\", \\\"{x:1413,y:582,t:1527019700835};\\\", \\\"{x:1413,y:580,t:1527019700851};\\\", \\\"{x:1413,y:578,t:1527019700875};\\\", \\\"{x:1412,y:576,t:1527019700891};\\\", \\\"{x:1412,y:575,t:1527019700907};\\\", \\\"{x:1412,y:574,t:1527019700914};\\\", \\\"{x:1412,y:573,t:1527019700931};\\\", \\\"{x:1410,y:570,t:1527019700947};\\\", \\\"{x:1409,y:568,t:1527019700970};\\\", \\\"{x:1409,y:567,t:1527019701011};\\\", \\\"{x:1409,y:566,t:1527019701027};\\\", \\\"{x:1409,y:565,t:1527019701043};\\\", \\\"{x:1409,y:564,t:1527019701074};\\\", \\\"{x:1408,y:562,t:1527019701084};\\\", \\\"{x:1408,y:561,t:1527019701107};\\\", \\\"{x:1408,y:559,t:1527019701131};\\\", \\\"{x:1407,y:558,t:1527019701195};\\\", \\\"{x:1406,y:557,t:1527019701203};\\\", \\\"{x:1406,y:555,t:1527019701563};\\\", \\\"{x:1406,y:547,t:1527019701581};\\\", \\\"{x:1406,y:535,t:1527019701597};\\\", \\\"{x:1409,y:519,t:1527019701614};\\\", \\\"{x:1414,y:504,t:1527019701630};\\\", \\\"{x:1415,y:495,t:1527019701648};\\\", \\\"{x:1417,y:489,t:1527019701665};\\\", \\\"{x:1417,y:486,t:1527019701681};\\\", \\\"{x:1418,y:481,t:1527019701698};\\\", \\\"{x:1418,y:480,t:1527019701739};\\\", \\\"{x:1418,y:479,t:1527019701883};\\\", \\\"{x:1418,y:477,t:1527019701898};\\\", \\\"{x:1418,y:475,t:1527019701914};\\\", \\\"{x:1418,y:472,t:1527019701931};\\\", \\\"{x:1418,y:471,t:1527019701955};\\\", \\\"{x:1418,y:470,t:1527019701965};\\\", \\\"{x:1418,y:469,t:1527019701995};\\\", \\\"{x:1417,y:468,t:1527019702019};\\\", \\\"{x:1417,y:466,t:1527019702123};\\\", \\\"{x:1417,y:465,t:1527019702131};\\\", \\\"{x:1417,y:463,t:1527019702148};\\\", \\\"{x:1417,y:462,t:1527019702165};\\\", \\\"{x:1417,y:459,t:1527019702180};\\\", \\\"{x:1417,y:457,t:1527019702198};\\\", \\\"{x:1417,y:453,t:1527019702215};\\\", \\\"{x:1417,y:452,t:1527019702231};\\\", \\\"{x:1417,y:449,t:1527019702248};\\\", \\\"{x:1418,y:448,t:1527019702267};\\\", \\\"{x:1418,y:447,t:1527019702281};\\\", \\\"{x:1418,y:446,t:1527019702297};\\\", \\\"{x:1419,y:444,t:1527019702314};\\\", \\\"{x:1419,y:443,t:1527019702346};\\\", \\\"{x:1419,y:441,t:1527019702365};\\\", \\\"{x:1419,y:439,t:1527019702381};\\\", \\\"{x:1419,y:436,t:1527019702398};\\\", \\\"{x:1419,y:433,t:1527019702414};\\\", \\\"{x:1419,y:432,t:1527019702447};\\\", \\\"{x:1420,y:430,t:1527019702464};\\\", \\\"{x:1419,y:430,t:1527019704139};\\\", \\\"{x:1419,y:432,t:1527019704147};\\\", \\\"{x:1415,y:441,t:1527019704166};\\\", \\\"{x:1412,y:446,t:1527019704181};\\\", \\\"{x:1409,y:452,t:1527019704198};\\\", \\\"{x:1408,y:455,t:1527019704214};\\\", \\\"{x:1406,y:459,t:1527019704232};\\\", \\\"{x:1403,y:462,t:1527019704248};\\\", \\\"{x:1402,y:466,t:1527019704265};\\\", \\\"{x:1397,y:474,t:1527019704281};\\\", \\\"{x:1394,y:477,t:1527019704298};\\\", \\\"{x:1391,y:482,t:1527019704315};\\\", \\\"{x:1389,y:484,t:1527019704331};\\\", \\\"{x:1386,y:487,t:1527019704348};\\\", \\\"{x:1383,y:491,t:1527019704365};\\\", \\\"{x:1379,y:497,t:1527019704382};\\\", \\\"{x:1371,y:502,t:1527019704397};\\\", \\\"{x:1367,y:505,t:1527019704414};\\\", \\\"{x:1366,y:507,t:1527019704431};\\\", \\\"{x:1365,y:509,t:1527019704448};\\\", \\\"{x:1364,y:510,t:1527019704464};\\\", \\\"{x:1361,y:512,t:1527019704481};\\\", \\\"{x:1358,y:515,t:1527019704498};\\\", \\\"{x:1353,y:517,t:1527019704515};\\\", \\\"{x:1351,y:518,t:1527019704532};\\\", \\\"{x:1350,y:519,t:1527019704548};\\\", \\\"{x:1348,y:519,t:1527019704564};\\\", \\\"{x:1347,y:519,t:1527019704581};\\\", \\\"{x:1343,y:521,t:1527019704598};\\\", \\\"{x:1340,y:521,t:1527019704615};\\\", \\\"{x:1332,y:521,t:1527019704632};\\\", \\\"{x:1326,y:522,t:1527019704648};\\\", \\\"{x:1322,y:522,t:1527019704664};\\\", \\\"{x:1321,y:522,t:1527019704681};\\\", \\\"{x:1320,y:522,t:1527019704954};\\\", \\\"{x:1320,y:521,t:1527019704965};\\\", \\\"{x:1322,y:518,t:1527019704981};\\\", \\\"{x:1322,y:515,t:1527019704998};\\\", \\\"{x:1322,y:514,t:1527019705014};\\\", \\\"{x:1322,y:512,t:1527019705031};\\\", \\\"{x:1323,y:511,t:1527019705048};\\\", \\\"{x:1323,y:509,t:1527019705064};\\\", \\\"{x:1323,y:506,t:1527019705081};\\\", \\\"{x:1323,y:502,t:1527019705099};\\\", \\\"{x:1323,y:501,t:1527019705114};\\\", \\\"{x:1323,y:499,t:1527019705147};\\\", \\\"{x:1323,y:503,t:1527019705475};\\\", \\\"{x:1323,y:507,t:1527019705483};\\\", \\\"{x:1323,y:520,t:1527019705499};\\\", \\\"{x:1323,y:529,t:1527019705515};\\\", \\\"{x:1323,y:536,t:1527019705531};\\\", \\\"{x:1323,y:543,t:1527019705548};\\\", \\\"{x:1320,y:551,t:1527019705565};\\\", \\\"{x:1319,y:556,t:1527019705582};\\\", \\\"{x:1316,y:558,t:1527019705599};\\\", \\\"{x:1313,y:565,t:1527019705615};\\\", \\\"{x:1307,y:575,t:1527019705632};\\\", \\\"{x:1304,y:583,t:1527019705649};\\\", \\\"{x:1301,y:590,t:1527019705665};\\\", \\\"{x:1297,y:597,t:1527019705682};\\\", \\\"{x:1290,y:604,t:1527019705699};\\\", \\\"{x:1288,y:606,t:1527019705715};\\\", \\\"{x:1287,y:607,t:1527019705732};\\\", \\\"{x:1285,y:609,t:1527019705749};\\\", \\\"{x:1283,y:610,t:1527019705765};\\\", \\\"{x:1280,y:612,t:1527019705782};\\\", \\\"{x:1277,y:614,t:1527019705799};\\\", \\\"{x:1275,y:616,t:1527019705815};\\\", \\\"{x:1273,y:618,t:1527019705832};\\\", \\\"{x:1272,y:619,t:1527019705849};\\\", \\\"{x:1271,y:620,t:1527019705865};\\\", \\\"{x:1269,y:621,t:1527019705882};\\\", \\\"{x:1266,y:623,t:1527019705898};\\\", \\\"{x:1265,y:625,t:1527019705915};\\\", \\\"{x:1263,y:626,t:1527019705932};\\\", \\\"{x:1262,y:627,t:1527019705949};\\\", \\\"{x:1259,y:630,t:1527019705965};\\\", \\\"{x:1256,y:630,t:1527019705982};\\\", \\\"{x:1254,y:630,t:1527019705999};\\\", \\\"{x:1253,y:630,t:1527019706016};\\\", \\\"{x:1252,y:630,t:1527019706051};\\\", \\\"{x:1250,y:630,t:1527019706283};\\\", \\\"{x:1247,y:630,t:1527019706298};\\\", \\\"{x:1244,y:630,t:1527019706315};\\\", \\\"{x:1238,y:629,t:1527019706333};\\\", \\\"{x:1235,y:629,t:1527019706348};\\\", \\\"{x:1233,y:629,t:1527019706366};\\\", \\\"{x:1232,y:629,t:1527019706579};\\\", \\\"{x:1232,y:628,t:1527019706788};\\\", \\\"{x:1234,y:627,t:1527019706867};\\\", \\\"{x:1235,y:626,t:1527019706883};\\\", \\\"{x:1236,y:626,t:1527019706906};\\\", \\\"{x:1237,y:626,t:1527019706915};\\\", \\\"{x:1239,y:625,t:1527019706932};\\\", \\\"{x:1242,y:624,t:1527019706949};\\\", \\\"{x:1242,y:623,t:1527019706987};\\\", \\\"{x:1243,y:623,t:1527019707027};\\\", \\\"{x:1244,y:623,t:1527019707042};\\\", \\\"{x:1244,y:622,t:1527019707051};\\\", \\\"{x:1245,y:622,t:1527019707427};\\\", \\\"{x:1245,y:624,t:1527019707443};\\\", \\\"{x:1245,y:625,t:1527019707459};\\\", \\\"{x:1245,y:626,t:1527019707481};\\\", \\\"{x:1246,y:627,t:1527019707499};\\\", \\\"{x:1246,y:629,t:1527019707516};\\\", \\\"{x:1247,y:630,t:1527019707971};\\\", \\\"{x:1247,y:632,t:1527019707982};\\\", \\\"{x:1244,y:639,t:1527019708000};\\\", \\\"{x:1243,y:644,t:1527019708016};\\\", \\\"{x:1242,y:648,t:1527019708033};\\\", \\\"{x:1242,y:653,t:1527019708049};\\\", \\\"{x:1242,y:654,t:1527019708066};\\\", \\\"{x:1242,y:655,t:1527019708083};\\\", \\\"{x:1243,y:655,t:1527019708299};\\\", \\\"{x:1244,y:653,t:1527019708315};\\\", \\\"{x:1245,y:651,t:1527019708333};\\\", \\\"{x:1245,y:650,t:1527019708349};\\\", \\\"{x:1245,y:649,t:1527019708366};\\\", \\\"{x:1245,y:648,t:1527019708394};\\\", \\\"{x:1245,y:647,t:1527019708427};\\\", \\\"{x:1245,y:646,t:1527019708443};\\\", \\\"{x:1245,y:645,t:1527019708459};\\\", \\\"{x:1245,y:644,t:1527019708474};\\\", \\\"{x:1245,y:643,t:1527019708482};\\\", \\\"{x:1245,y:642,t:1527019708523};\\\", \\\"{x:1246,y:641,t:1527019708546};\\\", \\\"{x:1242,y:640,t:1527019711315};\\\", \\\"{x:1228,y:635,t:1527019711323};\\\", \\\"{x:1208,y:628,t:1527019711333};\\\", \\\"{x:1153,y:615,t:1527019711350};\\\", \\\"{x:1106,y:597,t:1527019711367};\\\", \\\"{x:1082,y:588,t:1527019711383};\\\", \\\"{x:1058,y:578,t:1527019711400};\\\", \\\"{x:1024,y:568,t:1527019711417};\\\", \\\"{x:999,y:561,t:1527019711434};\\\", \\\"{x:979,y:559,t:1527019711450};\\\", \\\"{x:950,y:551,t:1527019711468};\\\", \\\"{x:930,y:551,t:1527019711482};\\\", \\\"{x:919,y:549,t:1527019711499};\\\", \\\"{x:902,y:546,t:1527019711515};\\\", \\\"{x:895,y:546,t:1527019711531};\\\", \\\"{x:893,y:546,t:1527019711547};\\\", \\\"{x:892,y:546,t:1527019711626};\\\", \\\"{x:892,y:545,t:1527019711706};\\\", \\\"{x:892,y:544,t:1527019711714};\\\", \\\"{x:884,y:541,t:1527019711732};\\\", \\\"{x:867,y:534,t:1527019711749};\\\", \\\"{x:855,y:530,t:1527019711765};\\\", \\\"{x:845,y:525,t:1527019711781};\\\", \\\"{x:830,y:520,t:1527019711798};\\\", \\\"{x:826,y:516,t:1527019711815};\\\", \\\"{x:826,y:515,t:1527019711874};\\\", \\\"{x:834,y:513,t:1527019712659};\\\", \\\"{x:845,y:509,t:1527019712667};\\\", \\\"{x:874,y:496,t:1527019712684};\\\", \\\"{x:929,y:491,t:1527019712698};\\\", \\\"{x:984,y:489,t:1527019712715};\\\", \\\"{x:1045,y:497,t:1527019712732};\\\", \\\"{x:1101,y:507,t:1527019712749};\\\", \\\"{x:1137,y:513,t:1527019712765};\\\", \\\"{x:1176,y:526,t:1527019712781};\\\", \\\"{x:1203,y:537,t:1527019712798};\\\", \\\"{x:1235,y:550,t:1527019712816};\\\", \\\"{x:1259,y:558,t:1527019712832};\\\", \\\"{x:1283,y:570,t:1527019712848};\\\", \\\"{x:1310,y:581,t:1527019712865};\\\", \\\"{x:1334,y:593,t:1527019712881};\\\", \\\"{x:1354,y:603,t:1527019712899};\\\", \\\"{x:1365,y:608,t:1527019712916};\\\", \\\"{x:1374,y:616,t:1527019712933};\\\", \\\"{x:1382,y:622,t:1527019712949};\\\", \\\"{x:1391,y:631,t:1527019712966};\\\", \\\"{x:1395,y:635,t:1527019712982};\\\", \\\"{x:1398,y:639,t:1527019712999};\\\", \\\"{x:1400,y:642,t:1527019713016};\\\", \\\"{x:1401,y:644,t:1527019713033};\\\", \\\"{x:1402,y:651,t:1527019713049};\\\", \\\"{x:1403,y:656,t:1527019713066};\\\", \\\"{x:1404,y:665,t:1527019713082};\\\", \\\"{x:1404,y:670,t:1527019713099};\\\", \\\"{x:1405,y:681,t:1527019713116};\\\", \\\"{x:1405,y:687,t:1527019713133};\\\", \\\"{x:1403,y:694,t:1527019713150};\\\", \\\"{x:1403,y:698,t:1527019713166};\\\", \\\"{x:1402,y:703,t:1527019713183};\\\", \\\"{x:1400,y:708,t:1527019713199};\\\", \\\"{x:1400,y:710,t:1527019713216};\\\", \\\"{x:1400,y:715,t:1527019713233};\\\", \\\"{x:1400,y:720,t:1527019713249};\\\", \\\"{x:1400,y:726,t:1527019713267};\\\", \\\"{x:1400,y:728,t:1527019713283};\\\", \\\"{x:1401,y:731,t:1527019713300};\\\", \\\"{x:1401,y:734,t:1527019713316};\\\", \\\"{x:1403,y:738,t:1527019713333};\\\", \\\"{x:1404,y:742,t:1527019713349};\\\", \\\"{x:1405,y:746,t:1527019713367};\\\", \\\"{x:1407,y:752,t:1527019713383};\\\", \\\"{x:1408,y:753,t:1527019713399};\\\", \\\"{x:1413,y:759,t:1527019713416};\\\", \\\"{x:1415,y:761,t:1527019713433};\\\", \\\"{x:1421,y:772,t:1527019713449};\\\", \\\"{x:1425,y:779,t:1527019713466};\\\", \\\"{x:1432,y:794,t:1527019713483};\\\", \\\"{x:1435,y:801,t:1527019713499};\\\", \\\"{x:1437,y:804,t:1527019713516};\\\", \\\"{x:1439,y:808,t:1527019713533};\\\", \\\"{x:1440,y:811,t:1527019713549};\\\", \\\"{x:1441,y:815,t:1527019713566};\\\", \\\"{x:1445,y:823,t:1527019713583};\\\", \\\"{x:1446,y:829,t:1527019713600};\\\", \\\"{x:1450,y:842,t:1527019713616};\\\", \\\"{x:1454,y:855,t:1527019713634};\\\", \\\"{x:1459,y:866,t:1527019713650};\\\", \\\"{x:1465,y:878,t:1527019713666};\\\", \\\"{x:1472,y:891,t:1527019713682};\\\", \\\"{x:1483,y:904,t:1527019713701};\\\", \\\"{x:1490,y:917,t:1527019713716};\\\", \\\"{x:1500,y:928,t:1527019713733};\\\", \\\"{x:1514,y:937,t:1527019713750};\\\", \\\"{x:1533,y:951,t:1527019713766};\\\", \\\"{x:1548,y:960,t:1527019713784};\\\", \\\"{x:1557,y:965,t:1527019713800};\\\", \\\"{x:1566,y:969,t:1527019713815};\\\", \\\"{x:1573,y:971,t:1527019713832};\\\", \\\"{x:1575,y:972,t:1527019713849};\\\", \\\"{x:1578,y:972,t:1527019713906};\\\", \\\"{x:1580,y:972,t:1527019713921};\\\", \\\"{x:1582,y:972,t:1527019713932};\\\", \\\"{x:1587,y:971,t:1527019713950};\\\", \\\"{x:1590,y:971,t:1527019713966};\\\", \\\"{x:1592,y:969,t:1527019713983};\\\", \\\"{x:1596,y:968,t:1527019714000};\\\", \\\"{x:1598,y:968,t:1527019714018};\\\", \\\"{x:1599,y:967,t:1527019714032};\\\", \\\"{x:1600,y:967,t:1527019714050};\\\", \\\"{x:1603,y:966,t:1527019714347};\\\", \\\"{x:1603,y:965,t:1527019714507};\\\", \\\"{x:1604,y:965,t:1527019714530};\\\", \\\"{x:1604,y:964,t:1527019714547};\\\", \\\"{x:1606,y:963,t:1527019714563};\\\", \\\"{x:1606,y:962,t:1527019714571};\\\", \\\"{x:1607,y:961,t:1527019714587};\\\", \\\"{x:1608,y:961,t:1527019714659};\\\", \\\"{x:1608,y:960,t:1527019714667};\\\", \\\"{x:1609,y:959,t:1527019714683};\\\", \\\"{x:1609,y:957,t:1527019714700};\\\", \\\"{x:1609,y:952,t:1527019714716};\\\", \\\"{x:1611,y:949,t:1527019714738};\\\", \\\"{x:1611,y:948,t:1527019714749};\\\", \\\"{x:1611,y:947,t:1527019714770};\\\", \\\"{x:1611,y:946,t:1527019714786};\\\", \\\"{x:1611,y:945,t:1527019714810};\\\", \\\"{x:1611,y:944,t:1527019714826};\\\", \\\"{x:1611,y:943,t:1527019714842};\\\", \\\"{x:1611,y:942,t:1527019714866};\\\", \\\"{x:1611,y:941,t:1527019714874};\\\", \\\"{x:1611,y:940,t:1527019714906};\\\", \\\"{x:1611,y:939,t:1527019714930};\\\", \\\"{x:1611,y:938,t:1527019714945};\\\", \\\"{x:1611,y:936,t:1527019714953};\\\", \\\"{x:1612,y:936,t:1527019714966};\\\", \\\"{x:1612,y:934,t:1527019715018};\\\", \\\"{x:1612,y:933,t:1527019715033};\\\", \\\"{x:1612,y:932,t:1527019715050};\\\", \\\"{x:1612,y:929,t:1527019715066};\\\", \\\"{x:1612,y:928,t:1527019715083};\\\", \\\"{x:1612,y:927,t:1527019715100};\\\", \\\"{x:1612,y:926,t:1527019715117};\\\", \\\"{x:1612,y:925,t:1527019715134};\\\", \\\"{x:1611,y:924,t:1527019715154};\\\", \\\"{x:1611,y:923,t:1527019715179};\\\", \\\"{x:1611,y:922,t:1527019715186};\\\", \\\"{x:1611,y:921,t:1527019715203};\\\", \\\"{x:1611,y:919,t:1527019715235};\\\", \\\"{x:1611,y:917,t:1527019715250};\\\", \\\"{x:1611,y:916,t:1527019715267};\\\", \\\"{x:1611,y:914,t:1527019715284};\\\", \\\"{x:1610,y:912,t:1527019715300};\\\", \\\"{x:1610,y:911,t:1527019715317};\\\", \\\"{x:1609,y:911,t:1527019715334};\\\", \\\"{x:1608,y:908,t:1527019715351};\\\", \\\"{x:1608,y:905,t:1527019715368};\\\", \\\"{x:1607,y:904,t:1527019715384};\\\", \\\"{x:1605,y:900,t:1527019715411};\\\", \\\"{x:1605,y:898,t:1527019715434};\\\", \\\"{x:1605,y:897,t:1527019715452};\\\", \\\"{x:1605,y:894,t:1527019715467};\\\", \\\"{x:1605,y:892,t:1527019715484};\\\", \\\"{x:1605,y:891,t:1527019715507};\\\", \\\"{x:1604,y:890,t:1527019715517};\\\", \\\"{x:1603,y:887,t:1527019715534};\\\", \\\"{x:1602,y:885,t:1527019715551};\\\", \\\"{x:1602,y:883,t:1527019715567};\\\", \\\"{x:1601,y:882,t:1527019715584};\\\", \\\"{x:1601,y:881,t:1527019715601};\\\", \\\"{x:1601,y:880,t:1527019715617};\\\", \\\"{x:1601,y:878,t:1527019715634};\\\", \\\"{x:1601,y:877,t:1527019715651};\\\", \\\"{x:1601,y:876,t:1527019715675};\\\", \\\"{x:1601,y:875,t:1527019715699};\\\", \\\"{x:1601,y:874,t:1527019715706};\\\", \\\"{x:1601,y:873,t:1527019715731};\\\", \\\"{x:1601,y:872,t:1527019715739};\\\", \\\"{x:1601,y:871,t:1527019715751};\\\", \\\"{x:1601,y:870,t:1527019715771};\\\", \\\"{x:1601,y:869,t:1527019715795};\\\", \\\"{x:1601,y:868,t:1527019715802};\\\", \\\"{x:1601,y:866,t:1527019715819};\\\", \\\"{x:1601,y:865,t:1527019715835};\\\", \\\"{x:1601,y:863,t:1527019715850};\\\", \\\"{x:1601,y:862,t:1527019715867};\\\", \\\"{x:1601,y:860,t:1527019715891};\\\", \\\"{x:1601,y:859,t:1527019715901};\\\", \\\"{x:1601,y:857,t:1527019715923};\\\", \\\"{x:1601,y:856,t:1527019715938};\\\", \\\"{x:1601,y:852,t:1527019715951};\\\", \\\"{x:1601,y:851,t:1527019715967};\\\", \\\"{x:1599,y:846,t:1527019715985};\\\", \\\"{x:1599,y:842,t:1527019716002};\\\", \\\"{x:1599,y:836,t:1527019716019};\\\", \\\"{x:1599,y:834,t:1527019716034};\\\", \\\"{x:1599,y:832,t:1527019716051};\\\", \\\"{x:1599,y:831,t:1527019716068};\\\", \\\"{x:1598,y:828,t:1527019716091};\\\", \\\"{x:1598,y:826,t:1527019716115};\\\", \\\"{x:1598,y:825,t:1527019716123};\\\", \\\"{x:1598,y:823,t:1527019716139};\\\", \\\"{x:1597,y:822,t:1527019716152};\\\", \\\"{x:1597,y:821,t:1527019716195};\\\", \\\"{x:1597,y:820,t:1527019716202};\\\", \\\"{x:1596,y:819,t:1527019716226};\\\", \\\"{x:1595,y:819,t:1527019717106};\\\", \\\"{x:1591,y:819,t:1527019717118};\\\", \\\"{x:1576,y:824,t:1527019717135};\\\", \\\"{x:1565,y:830,t:1527019717152};\\\", \\\"{x:1555,y:832,t:1527019717169};\\\", \\\"{x:1547,y:835,t:1527019717185};\\\", \\\"{x:1535,y:840,t:1527019717202};\\\", \\\"{x:1530,y:844,t:1527019717219};\\\", \\\"{x:1521,y:848,t:1527019717235};\\\", \\\"{x:1510,y:853,t:1527019717252};\\\", \\\"{x:1501,y:858,t:1527019717268};\\\", \\\"{x:1491,y:863,t:1527019717285};\\\", \\\"{x:1484,y:866,t:1527019717302};\\\", \\\"{x:1478,y:870,t:1527019717318};\\\", \\\"{x:1475,y:870,t:1527019717335};\\\", \\\"{x:1473,y:872,t:1527019717353};\\\", \\\"{x:1471,y:873,t:1527019717371};\\\", \\\"{x:1470,y:873,t:1527019717385};\\\", \\\"{x:1460,y:873,t:1527019717402};\\\", \\\"{x:1448,y:873,t:1527019717419};\\\", \\\"{x:1444,y:873,t:1527019717435};\\\", \\\"{x:1442,y:872,t:1527019717452};\\\", \\\"{x:1440,y:871,t:1527019717483};\\\", \\\"{x:1440,y:870,t:1527019717498};\\\", \\\"{x:1439,y:869,t:1527019717507};\\\", \\\"{x:1436,y:867,t:1527019717518};\\\", \\\"{x:1433,y:862,t:1527019717536};\\\", \\\"{x:1428,y:857,t:1527019717552};\\\", \\\"{x:1422,y:849,t:1527019717569};\\\", \\\"{x:1418,y:845,t:1527019717585};\\\", \\\"{x:1413,y:838,t:1527019717603};\\\", \\\"{x:1409,y:835,t:1527019717618};\\\", \\\"{x:1402,y:827,t:1527019717634};\\\", \\\"{x:1398,y:821,t:1527019717652};\\\", \\\"{x:1397,y:817,t:1527019717668};\\\", \\\"{x:1391,y:807,t:1527019717684};\\\", \\\"{x:1389,y:802,t:1527019717702};\\\", \\\"{x:1387,y:797,t:1527019717718};\\\", \\\"{x:1387,y:794,t:1527019717735};\\\", \\\"{x:1386,y:792,t:1527019717752};\\\", \\\"{x:1384,y:789,t:1527019717769};\\\", \\\"{x:1384,y:784,t:1527019717785};\\\", \\\"{x:1382,y:780,t:1527019717802};\\\", \\\"{x:1382,y:777,t:1527019717818};\\\", \\\"{x:1382,y:774,t:1527019717835};\\\", \\\"{x:1380,y:770,t:1527019717852};\\\", \\\"{x:1379,y:768,t:1527019717869};\\\", \\\"{x:1378,y:765,t:1527019717885};\\\", \\\"{x:1377,y:764,t:1527019717902};\\\", \\\"{x:1377,y:763,t:1527019717919};\\\", \\\"{x:1377,y:762,t:1527019717935};\\\", \\\"{x:1375,y:760,t:1527019717953};\\\", \\\"{x:1375,y:759,t:1527019717970};\\\", \\\"{x:1374,y:758,t:1527019717986};\\\", \\\"{x:1373,y:757,t:1527019718010};\\\", \\\"{x:1372,y:756,t:1527019718323};\\\", \\\"{x:1372,y:755,t:1527019718362};\\\", \\\"{x:1372,y:754,t:1527019718411};\\\", \\\"{x:1372,y:752,t:1527019718531};\\\", \\\"{x:1373,y:751,t:1527019718547};\\\", \\\"{x:1374,y:751,t:1527019718555};\\\", \\\"{x:1375,y:751,t:1527019718570};\\\", \\\"{x:1377,y:751,t:1527019718586};\\\", \\\"{x:1379,y:751,t:1527019718619};\\\", \\\"{x:1381,y:751,t:1527019718636};\\\", \\\"{x:1384,y:751,t:1527019718653};\\\", \\\"{x:1387,y:751,t:1527019718670};\\\", \\\"{x:1390,y:751,t:1527019718687};\\\", \\\"{x:1395,y:752,t:1527019718703};\\\", \\\"{x:1399,y:753,t:1527019718719};\\\", \\\"{x:1402,y:755,t:1527019718736};\\\", \\\"{x:1406,y:755,t:1527019718752};\\\", \\\"{x:1407,y:757,t:1527019720947};\\\", \\\"{x:1406,y:758,t:1527019720955};\\\", \\\"{x:1403,y:759,t:1527019720971};\\\", \\\"{x:1400,y:760,t:1527019720987};\\\", \\\"{x:1398,y:761,t:1527019721005};\\\", \\\"{x:1394,y:763,t:1527019721021};\\\", \\\"{x:1393,y:763,t:1527019721037};\\\", \\\"{x:1392,y:763,t:1527019721054};\\\", \\\"{x:1392,y:764,t:1527019721443};\\\", \\\"{x:1391,y:768,t:1527019721454};\\\", \\\"{x:1391,y:777,t:1527019721476};\\\", \\\"{x:1391,y:781,t:1527019721487};\\\", \\\"{x:1391,y:789,t:1527019721504};\\\", \\\"{x:1391,y:799,t:1527019721520};\\\", \\\"{x:1391,y:809,t:1527019721537};\\\", \\\"{x:1393,y:819,t:1527019721553};\\\", \\\"{x:1395,y:822,t:1527019721571};\\\", \\\"{x:1395,y:824,t:1527019721587};\\\", \\\"{x:1396,y:825,t:1527019721604};\\\", \\\"{x:1396,y:826,t:1527019721621};\\\", \\\"{x:1396,y:827,t:1527019721637};\\\", \\\"{x:1396,y:830,t:1527019721654};\\\", \\\"{x:1396,y:837,t:1527019721671};\\\", \\\"{x:1396,y:848,t:1527019721688};\\\", \\\"{x:1396,y:855,t:1527019721704};\\\", \\\"{x:1396,y:859,t:1527019721721};\\\", \\\"{x:1396,y:862,t:1527019721737};\\\", \\\"{x:1396,y:868,t:1527019721754};\\\", \\\"{x:1396,y:872,t:1527019721771};\\\", \\\"{x:1395,y:875,t:1527019721788};\\\", \\\"{x:1395,y:877,t:1527019721804};\\\", \\\"{x:1395,y:878,t:1527019721821};\\\", \\\"{x:1395,y:879,t:1527019721838};\\\", \\\"{x:1395,y:880,t:1527019721854};\\\", \\\"{x:1395,y:881,t:1527019721891};\\\", \\\"{x:1395,y:883,t:1527019721907};\\\", \\\"{x:1395,y:885,t:1527019721922};\\\", \\\"{x:1392,y:890,t:1527019721939};\\\", \\\"{x:1392,y:891,t:1527019721955};\\\", \\\"{x:1392,y:892,t:1527019721978};\\\", \\\"{x:1392,y:893,t:1527019721995};\\\", \\\"{x:1391,y:894,t:1527019722005};\\\", \\\"{x:1391,y:896,t:1527019722022};\\\", \\\"{x:1390,y:898,t:1527019722038};\\\", \\\"{x:1389,y:899,t:1527019722054};\\\", \\\"{x:1387,y:899,t:1527019722075};\\\", \\\"{x:1387,y:898,t:1527019726882};\\\", \\\"{x:1387,y:895,t:1527019726890};\\\", \\\"{x:1387,y:891,t:1527019726907};\\\", \\\"{x:1387,y:887,t:1527019726924};\\\", \\\"{x:1386,y:884,t:1527019726941};\\\", \\\"{x:1385,y:881,t:1527019726957};\\\", \\\"{x:1385,y:879,t:1527019726975};\\\", \\\"{x:1385,y:878,t:1527019726992};\\\", \\\"{x:1385,y:876,t:1527019727017};\\\", \\\"{x:1385,y:874,t:1527019727034};\\\", \\\"{x:1385,y:871,t:1527019727042};\\\", \\\"{x:1385,y:868,t:1527019727057};\\\", \\\"{x:1385,y:865,t:1527019727074};\\\", \\\"{x:1385,y:857,t:1527019727092};\\\", \\\"{x:1385,y:853,t:1527019727107};\\\", \\\"{x:1383,y:847,t:1527019727124};\\\", \\\"{x:1381,y:840,t:1527019727141};\\\", \\\"{x:1381,y:836,t:1527019727157};\\\", \\\"{x:1379,y:828,t:1527019727174};\\\", \\\"{x:1376,y:823,t:1527019727190};\\\", \\\"{x:1376,y:817,t:1527019727207};\\\", \\\"{x:1375,y:812,t:1527019727224};\\\", \\\"{x:1374,y:805,t:1527019727241};\\\", \\\"{x:1373,y:798,t:1527019727256};\\\", \\\"{x:1373,y:793,t:1527019727274};\\\", \\\"{x:1372,y:788,t:1527019727291};\\\", \\\"{x:1371,y:783,t:1527019727307};\\\", \\\"{x:1370,y:783,t:1527019727324};\\\", \\\"{x:1370,y:782,t:1527019727341};\\\", \\\"{x:1370,y:781,t:1527019727361};\\\", \\\"{x:1370,y:780,t:1527019727374};\\\", \\\"{x:1370,y:779,t:1527019727394};\\\", \\\"{x:1369,y:777,t:1527019727409};\\\", \\\"{x:1369,y:776,t:1527019727426};\\\", \\\"{x:1369,y:774,t:1527019727442};\\\", \\\"{x:1369,y:773,t:1527019727466};\\\", \\\"{x:1369,y:772,t:1527019727482};\\\", \\\"{x:1368,y:771,t:1527019727497};\\\", \\\"{x:1368,y:770,t:1527019727522};\\\", \\\"{x:1368,y:768,t:1527019727546};\\\", \\\"{x:1368,y:767,t:1527019727577};\\\", \\\"{x:1368,y:765,t:1527019727635};\\\", \\\"{x:1368,y:764,t:1527019727642};\\\", \\\"{x:1368,y:763,t:1527019727675};\\\", \\\"{x:1369,y:762,t:1527019727699};\\\", \\\"{x:1370,y:761,t:1527019727731};\\\", \\\"{x:1372,y:760,t:1527019727747};\\\", \\\"{x:1372,y:759,t:1527019727779};\\\", \\\"{x:1373,y:759,t:1527019727791};\\\", \\\"{x:1374,y:759,t:1527019727817};\\\", \\\"{x:1374,y:758,t:1527019727834};\\\", \\\"{x:1375,y:758,t:1527019727866};\\\", \\\"{x:1376,y:757,t:1527019727914};\\\", \\\"{x:1378,y:755,t:1527019728515};\\\", \\\"{x:1378,y:754,t:1527019728530};\\\", \\\"{x:1379,y:754,t:1527019728547};\\\", \\\"{x:1379,y:752,t:1527019728650};\\\", \\\"{x:1380,y:751,t:1527019728666};\\\", \\\"{x:1381,y:750,t:1527019728698};\\\", \\\"{x:1381,y:748,t:1527019728747};\\\", \\\"{x:1382,y:748,t:1527019729162};\\\", \\\"{x:1383,y:748,t:1527019729186};\\\", \\\"{x:1384,y:747,t:1527019729203};\\\", \\\"{x:1385,y:746,t:1527019729259};\\\", \\\"{x:1386,y:745,t:1527019729307};\\\", \\\"{x:1387,y:745,t:1527019729363};\\\", \\\"{x:1387,y:744,t:1527019729435};\\\", \\\"{x:1388,y:743,t:1527019729915};\\\", \\\"{x:1390,y:736,t:1527019729926};\\\", \\\"{x:1391,y:726,t:1527019729943};\\\", \\\"{x:1391,y:725,t:1527019729960};\\\", \\\"{x:1391,y:724,t:1527019729986};\\\", \\\"{x:1394,y:719,t:1527019731099};\\\", \\\"{x:1396,y:715,t:1527019731111};\\\", \\\"{x:1396,y:713,t:1527019731126};\\\", \\\"{x:1394,y:711,t:1527019732323};\\\", \\\"{x:1382,y:705,t:1527019732330};\\\", \\\"{x:1373,y:695,t:1527019732345};\\\", \\\"{x:1357,y:688,t:1527019732361};\\\", \\\"{x:1352,y:688,t:1527019732378};\\\", \\\"{x:1349,y:688,t:1527019732395};\\\", \\\"{x:1347,y:688,t:1527019732603};\\\", \\\"{x:1344,y:688,t:1527019732611};\\\", \\\"{x:1355,y:690,t:1527019732714};\\\", \\\"{x:1361,y:690,t:1527019732728};\\\", \\\"{x:1375,y:688,t:1527019732744};\\\", \\\"{x:1393,y:680,t:1527019732761};\\\", \\\"{x:1425,y:655,t:1527019732778};\\\", \\\"{x:1460,y:631,t:1527019732794};\\\", \\\"{x:1502,y:599,t:1527019732811};\\\", \\\"{x:1569,y:553,t:1527019732827};\\\", \\\"{x:1627,y:502,t:1527019732844};\\\", \\\"{x:1679,y:457,t:1527019732861};\\\", \\\"{x:1702,y:435,t:1527019732878};\\\", \\\"{x:1723,y:415,t:1527019732894};\\\", \\\"{x:1724,y:413,t:1527019732912};\\\", \\\"{x:1725,y:412,t:1527019732927};\\\", \\\"{x:1725,y:407,t:1527019732945};\\\", \\\"{x:1727,y:381,t:1527019732962};\\\", \\\"{x:1730,y:366,t:1527019732977};\\\", \\\"{x:1734,y:326,t:1527019732995};\\\", \\\"{x:1734,y:307,t:1527019733012};\\\", \\\"{x:1727,y:286,t:1527019733027};\\\", \\\"{x:1718,y:272,t:1527019733045};\\\", \\\"{x:1713,y:267,t:1527019733062};\\\", \\\"{x:1709,y:265,t:1527019733077};\\\", \\\"{x:1705,y:265,t:1527019733095};\\\", \\\"{x:1701,y:266,t:1527019733112};\\\", \\\"{x:1680,y:286,t:1527019733128};\\\", \\\"{x:1659,y:304,t:1527019733144};\\\", \\\"{x:1644,y:317,t:1527019733161};\\\", \\\"{x:1627,y:329,t:1527019733178};\\\", \\\"{x:1601,y:345,t:1527019733194};\\\", \\\"{x:1574,y:365,t:1527019733212};\\\", \\\"{x:1535,y:389,t:1527019733228};\\\", \\\"{x:1499,y:412,t:1527019733245};\\\", \\\"{x:1458,y:438,t:1527019733262};\\\", \\\"{x:1413,y:470,t:1527019733279};\\\", \\\"{x:1363,y:499,t:1527019733295};\\\", \\\"{x:1328,y:515,t:1527019733312};\\\", \\\"{x:1312,y:522,t:1527019733329};\\\", \\\"{x:1308,y:524,t:1527019733345};\\\", \\\"{x:1305,y:526,t:1527019733362};\\\", \\\"{x:1304,y:529,t:1527019733379};\\\", \\\"{x:1304,y:531,t:1527019733395};\\\", \\\"{x:1304,y:534,t:1527019733412};\\\", \\\"{x:1306,y:537,t:1527019733429};\\\", \\\"{x:1314,y:539,t:1527019733445};\\\", \\\"{x:1323,y:540,t:1527019733461};\\\", \\\"{x:1326,y:543,t:1527019733479};\\\", \\\"{x:1328,y:543,t:1527019733495};\\\", \\\"{x:1329,y:548,t:1527019733594};\\\", \\\"{x:1332,y:551,t:1527019733612};\\\", \\\"{x:1334,y:554,t:1527019733629};\\\", \\\"{x:1338,y:555,t:1527019733645};\\\", \\\"{x:1343,y:555,t:1527019733662};\\\", \\\"{x:1359,y:555,t:1527019733679};\\\", \\\"{x:1373,y:550,t:1527019733695};\\\", \\\"{x:1384,y:545,t:1527019733712};\\\", \\\"{x:1387,y:544,t:1527019733729};\\\", \\\"{x:1389,y:544,t:1527019733745};\\\", \\\"{x:1391,y:543,t:1527019733762};\\\", \\\"{x:1391,y:542,t:1527019733834};\\\", \\\"{x:1392,y:542,t:1527019733851};\\\", \\\"{x:1393,y:542,t:1527019733862};\\\", \\\"{x:1396,y:542,t:1527019733879};\\\", \\\"{x:1398,y:550,t:1527019733896};\\\", \\\"{x:1400,y:566,t:1527019733912};\\\", \\\"{x:1400,y:585,t:1527019733929};\\\", \\\"{x:1406,y:604,t:1527019733946};\\\", \\\"{x:1407,y:630,t:1527019733962};\\\", \\\"{x:1408,y:671,t:1527019733979};\\\", \\\"{x:1408,y:695,t:1527019733996};\\\", \\\"{x:1407,y:721,t:1527019734012};\\\", \\\"{x:1405,y:747,t:1527019734029};\\\", \\\"{x:1401,y:771,t:1527019734046};\\\", \\\"{x:1400,y:786,t:1527019734062};\\\", \\\"{x:1400,y:801,t:1527019734080};\\\", \\\"{x:1402,y:807,t:1527019734096};\\\", \\\"{x:1402,y:809,t:1527019734112};\\\", \\\"{x:1404,y:811,t:1527019734129};\\\", \\\"{x:1404,y:812,t:1527019734154};\\\", \\\"{x:1404,y:813,t:1527019734162};\\\", \\\"{x:1404,y:817,t:1527019734179};\\\", \\\"{x:1399,y:820,t:1527019734196};\\\", \\\"{x:1395,y:822,t:1527019734212};\\\", \\\"{x:1393,y:823,t:1527019734229};\\\", \\\"{x:1392,y:823,t:1527019734411};\\\", \\\"{x:1391,y:820,t:1527019734419};\\\", \\\"{x:1390,y:815,t:1527019734429};\\\", \\\"{x:1390,y:809,t:1527019734446};\\\", \\\"{x:1390,y:803,t:1527019734463};\\\", \\\"{x:1389,y:799,t:1527019734479};\\\", \\\"{x:1389,y:797,t:1527019734496};\\\", \\\"{x:1388,y:795,t:1527019734512};\\\", \\\"{x:1388,y:794,t:1527019734529};\\\", \\\"{x:1386,y:793,t:1527019734546};\\\", \\\"{x:1386,y:790,t:1527019734562};\\\", \\\"{x:1386,y:788,t:1527019734579};\\\", \\\"{x:1386,y:787,t:1527019734596};\\\", \\\"{x:1384,y:782,t:1527019734613};\\\", \\\"{x:1383,y:778,t:1527019734629};\\\", \\\"{x:1382,y:776,t:1527019734646};\\\", \\\"{x:1381,y:774,t:1527019734663};\\\", \\\"{x:1380,y:771,t:1527019734679};\\\", \\\"{x:1380,y:768,t:1527019734697};\\\", \\\"{x:1379,y:765,t:1527019734713};\\\", \\\"{x:1378,y:768,t:1527019735070};\\\", \\\"{x:1376,y:780,t:1527019735084};\\\", \\\"{x:1373,y:792,t:1527019735099};\\\", \\\"{x:1372,y:806,t:1527019735117};\\\", \\\"{x:1371,y:824,t:1527019735134};\\\", \\\"{x:1371,y:831,t:1527019735150};\\\", \\\"{x:1371,y:836,t:1527019735166};\\\", \\\"{x:1371,y:842,t:1527019735184};\\\", \\\"{x:1371,y:854,t:1527019735200};\\\", \\\"{x:1371,y:863,t:1527019735217};\\\", \\\"{x:1373,y:869,t:1527019735234};\\\", \\\"{x:1373,y:874,t:1527019735249};\\\", \\\"{x:1374,y:879,t:1527019735267};\\\", \\\"{x:1374,y:881,t:1527019735341};\\\", \\\"{x:1375,y:882,t:1527019735349};\\\", \\\"{x:1377,y:884,t:1527019735366};\\\", \\\"{x:1377,y:886,t:1527019735383};\\\", \\\"{x:1379,y:890,t:1527019735399};\\\", \\\"{x:1379,y:893,t:1527019735416};\\\", \\\"{x:1380,y:896,t:1527019735433};\\\", \\\"{x:1381,y:903,t:1527019735449};\\\", \\\"{x:1382,y:905,t:1527019735467};\\\", \\\"{x:1383,y:907,t:1527019735483};\\\", \\\"{x:1384,y:909,t:1527019735499};\\\", \\\"{x:1385,y:909,t:1527019735710};\\\", \\\"{x:1385,y:910,t:1527019735718};\\\", \\\"{x:1385,y:912,t:1527019735734};\\\", \\\"{x:1385,y:914,t:1527019735750};\\\", \\\"{x:1385,y:917,t:1527019735767};\\\", \\\"{x:1385,y:920,t:1527019735784};\\\", \\\"{x:1385,y:923,t:1527019735801};\\\", \\\"{x:1385,y:926,t:1527019735817};\\\", \\\"{x:1386,y:929,t:1527019735834};\\\", \\\"{x:1386,y:931,t:1527019735850};\\\", \\\"{x:1386,y:933,t:1527019735866};\\\", \\\"{x:1386,y:940,t:1527019735883};\\\", \\\"{x:1386,y:948,t:1527019735901};\\\", \\\"{x:1385,y:958,t:1527019735916};\\\", \\\"{x:1381,y:985,t:1527019735934};\\\", \\\"{x:1375,y:1006,t:1527019735950};\\\", \\\"{x:1371,y:1022,t:1527019735967};\\\", \\\"{x:1369,y:1031,t:1527019735984};\\\", \\\"{x:1369,y:1032,t:1527019736001};\\\", \\\"{x:1369,y:1030,t:1527019736182};\\\", \\\"{x:1369,y:1025,t:1527019736190};\\\", \\\"{x:1370,y:1019,t:1527019736201};\\\", \\\"{x:1373,y:1009,t:1527019736216};\\\", \\\"{x:1378,y:998,t:1527019736233};\\\", \\\"{x:1382,y:989,t:1527019736250};\\\", \\\"{x:1384,y:984,t:1527019736268};\\\", \\\"{x:1387,y:980,t:1527019736283};\\\", \\\"{x:1388,y:975,t:1527019736300};\\\", \\\"{x:1391,y:967,t:1527019736318};\\\", \\\"{x:1393,y:965,t:1527019736333};\\\", \\\"{x:1394,y:963,t:1527019736350};\\\", \\\"{x:1394,y:962,t:1527019736368};\\\", \\\"{x:1393,y:962,t:1527019736479};\\\", \\\"{x:1391,y:962,t:1527019736486};\\\", \\\"{x:1389,y:962,t:1527019736500};\\\", \\\"{x:1388,y:963,t:1527019736518};\\\", \\\"{x:1387,y:963,t:1527019736534};\\\", \\\"{x:1386,y:963,t:1527019736558};\\\", \\\"{x:1385,y:963,t:1527019736568};\\\", \\\"{x:1381,y:966,t:1527019736584};\\\", \\\"{x:1380,y:966,t:1527019736601};\\\", \\\"{x:1379,y:966,t:1527019736617};\\\", \\\"{x:1378,y:966,t:1527019736633};\\\", \\\"{x:1379,y:964,t:1527019737246};\\\", \\\"{x:1380,y:960,t:1527019737255};\\\", \\\"{x:1381,y:956,t:1527019737268};\\\", \\\"{x:1382,y:956,t:1527019737285};\\\", \\\"{x:1382,y:955,t:1527019737301};\\\", \\\"{x:1383,y:952,t:1527019737318};\\\", \\\"{x:1383,y:950,t:1527019737334};\\\", \\\"{x:1384,y:949,t:1527019737351};\\\", \\\"{x:1378,y:945,t:1527019737782};\\\", \\\"{x:1349,y:929,t:1527019737789};\\\", \\\"{x:1303,y:907,t:1527019737802};\\\", \\\"{x:1178,y:849,t:1527019737817};\\\", \\\"{x:1051,y:809,t:1527019737834};\\\", \\\"{x:926,y:775,t:1527019737851};\\\", \\\"{x:809,y:750,t:1527019737867};\\\", \\\"{x:700,y:730,t:1527019737885};\\\", \\\"{x:537,y:685,t:1527019737902};\\\", \\\"{x:461,y:659,t:1527019737918};\\\", \\\"{x:413,y:636,t:1527019737936};\\\", \\\"{x:382,y:616,t:1527019737952};\\\", \\\"{x:370,y:602,t:1527019737969};\\\", \\\"{x:362,y:590,t:1527019737989};\\\", \\\"{x:361,y:589,t:1527019738006};\\\", \\\"{x:361,y:588,t:1527019738023};\\\", \\\"{x:360,y:588,t:1527019738039};\\\", \\\"{x:358,y:588,t:1527019738069};\\\", \\\"{x:355,y:589,t:1527019738085};\\\", \\\"{x:353,y:590,t:1527019738093};\\\", \\\"{x:353,y:592,t:1527019738106};\\\", \\\"{x:351,y:595,t:1527019738123};\\\", \\\"{x:352,y:596,t:1527019738206};\\\", \\\"{x:355,y:596,t:1527019738224};\\\", \\\"{x:362,y:596,t:1527019738240};\\\", \\\"{x:368,y:595,t:1527019738256};\\\", \\\"{x:376,y:593,t:1527019738274};\\\", \\\"{x:382,y:591,t:1527019738290};\\\", \\\"{x:390,y:591,t:1527019738306};\\\", \\\"{x:402,y:591,t:1527019738323};\\\", \\\"{x:417,y:591,t:1527019738341};\\\", \\\"{x:437,y:595,t:1527019738357};\\\", \\\"{x:453,y:603,t:1527019738373};\\\", \\\"{x:470,y:614,t:1527019738390};\\\", \\\"{x:492,y:623,t:1527019738407};\\\", \\\"{x:525,y:629,t:1527019738424};\\\", \\\"{x:557,y:630,t:1527019738440};\\\", \\\"{x:584,y:632,t:1527019738457};\\\", \\\"{x:597,y:635,t:1527019738473};\\\", \\\"{x:600,y:636,t:1527019738491};\\\", \\\"{x:604,y:637,t:1527019738508};\\\", \\\"{x:605,y:638,t:1527019738523};\\\", \\\"{x:605,y:640,t:1527019738549};\\\", \\\"{x:606,y:642,t:1527019738558};\\\", \\\"{x:606,y:643,t:1527019738589};\\\", \\\"{x:607,y:643,t:1527019738597};\\\", \\\"{x:607,y:644,t:1527019738608};\\\", \\\"{x:607,y:648,t:1527019738624};\\\", \\\"{x:607,y:654,t:1527019738641};\\\", \\\"{x:605,y:662,t:1527019738657};\\\", \\\"{x:602,y:669,t:1527019738675};\\\", \\\"{x:598,y:675,t:1527019738690};\\\", \\\"{x:596,y:678,t:1527019738707};\\\", \\\"{x:596,y:679,t:1527019738725};\\\", \\\"{x:595,y:679,t:1527019738758};\\\", \\\"{x:592,y:681,t:1527019738773};\\\", \\\"{x:586,y:683,t:1527019738790};\\\", \\\"{x:580,y:687,t:1527019738808};\\\", \\\"{x:572,y:694,t:1527019738824};\\\", \\\"{x:562,y:701,t:1527019738841};\\\", \\\"{x:550,y:711,t:1527019738858};\\\", \\\"{x:542,y:720,t:1527019738874};\\\", \\\"{x:534,y:728,t:1527019738890};\\\", \\\"{x:531,y:731,t:1527019738907};\\\", \\\"{x:530,y:731,t:1527019738924};\\\", \\\"{x:528,y:732,t:1527019738940};\\\", \\\"{x:526,y:732,t:1527019738957};\\\", \\\"{x:525,y:732,t:1527019739454};\\\", \\\"{x:525,y:729,t:1527019739462};\\\", \\\"{x:525,y:725,t:1527019739475};\\\", \\\"{x:528,y:715,t:1527019739491};\\\", \\\"{x:542,y:697,t:1527019739507};\\\", \\\"{x:569,y:671,t:1527019739525};\\\", \\\"{x:625,y:626,t:1527019739542};\\\", \\\"{x:668,y:593,t:1527019739557};\\\", \\\"{x:713,y:563,t:1527019739574};\\\", \\\"{x:744,y:537,t:1527019739591};\\\", \\\"{x:792,y:500,t:1527019739609};\\\", \\\"{x:861,y:443,t:1527019739624};\\\", \\\"{x:923,y:393,t:1527019739642};\\\", \\\"{x:992,y:350,t:1527019739657};\\\", \\\"{x:1047,y:316,t:1527019739674};\\\", \\\"{x:1094,y:287,t:1527019739692};\\\", \\\"{x:1125,y:265,t:1527019739708};\\\", \\\"{x:1144,y:254,t:1527019739725};\\\", \\\"{x:1158,y:240,t:1527019739742};\\\", \\\"{x:1162,y:237,t:1527019739758};\\\", \\\"{x:1163,y:235,t:1527019739775};\\\", \\\"{x:1163,y:234,t:1527019739798};\\\", \\\"{x:1163,y:232,t:1527019739813};\\\", \\\"{x:1163,y:231,t:1527019739824};\\\", \\\"{x:1160,y:226,t:1527019739841};\\\", \\\"{x:1154,y:218,t:1527019739859};\\\", \\\"{x:1146,y:213,t:1527019739875};\\\", \\\"{x:1142,y:209,t:1527019739892};\\\", \\\"{x:1135,y:206,t:1527019739908};\\\", \\\"{x:1126,y:204,t:1527019739924};\\\", \\\"{x:1112,y:198,t:1527019739940};\\\", \\\"{x:1108,y:195,t:1527019739958};\\\", \\\"{x:1100,y:193,t:1527019739975};\\\", \\\"{x:1097,y:192,t:1527019739991};\\\", \\\"{x:1096,y:191,t:1527019740008};\\\", \\\"{x:1095,y:191,t:1527019740025};\\\", \\\"{x:1094,y:191,t:1527019740062};\\\", \\\"{x:1093,y:191,t:1527019740118};\\\", \\\"{x:1091,y:191,t:1527019740142};\\\", \\\"{x:1089,y:191,t:1527019740168};\\\", \\\"{x:1087,y:191,t:1527019740175};\\\", \\\"{x:1083,y:191,t:1527019740201};\\\", \\\"{x:1082,y:191,t:1527019740221};\\\", \\\"{x:1081,y:191,t:1527019740237};\\\", \\\"{x:1080,y:191,t:1527019740253};\\\", \\\"{x:1079,y:191,t:1527019740261};\\\", \\\"{x:1078,y:192,t:1527019740277};\\\", \\\"{x:1076,y:193,t:1527019740291};\\\", \\\"{x:1070,y:193,t:1527019740308};\\\", \\\"{x:1061,y:194,t:1527019740325};\\\", \\\"{x:1053,y:194,t:1527019740342};\\\", \\\"{x:1044,y:197,t:1527019740358};\\\", \\\"{x:1039,y:197,t:1527019740376};\\\", \\\"{x:1033,y:197,t:1527019740392};\\\", \\\"{x:1029,y:197,t:1527019740409};\\\", \\\"{x:1026,y:197,t:1527019740425};\\\", \\\"{x:1025,y:197,t:1527019740442};\\\", \\\"{x:1023,y:197,t:1527019740459};\\\" ] }, { \\\"rt\\\": 75838, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 440869, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 6, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"H\\\", \\\"J\\\", \\\"X\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -A -A -11 AM-A -F -03 PM-03 PM-K -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1004,y:204,t:1527019740675};\\\", \\\"{x:1002,y:205,t:1527019740699};\\\", \\\"{x:1001,y:205,t:1527019740708};\\\", \\\"{x:999,y:207,t:1527019740724};\\\", \\\"{x:998,y:207,t:1527019740742};\\\", \\\"{x:995,y:209,t:1527019740768};\\\", \\\"{x:990,y:211,t:1527019740829};\\\", \\\"{x:989,y:211,t:1527019740845};\\\", \\\"{x:988,y:212,t:1527019740861};\\\", \\\"{x:986,y:212,t:1527019740934};\\\", \\\"{x:985,y:213,t:1527019740949};\\\", \\\"{x:983,y:215,t:1527019740965};\\\", \\\"{x:982,y:215,t:1527019740975};\\\", \\\"{x:978,y:218,t:1527019740993};\\\", \\\"{x:971,y:222,t:1527019741009};\\\", \\\"{x:967,y:226,t:1527019741025};\\\", \\\"{x:960,y:229,t:1527019741042};\\\", \\\"{x:954,y:234,t:1527019741059};\\\", \\\"{x:947,y:238,t:1527019741075};\\\", \\\"{x:942,y:241,t:1527019741092};\\\", \\\"{x:931,y:253,t:1527019741109};\\\", \\\"{x:916,y:262,t:1527019741125};\\\", \\\"{x:897,y:274,t:1527019741143};\\\", \\\"{x:845,y:297,t:1527019741159};\\\", \\\"{x:793,y:318,t:1527019741175};\\\", \\\"{x:716,y:348,t:1527019741192};\\\", \\\"{x:647,y:369,t:1527019741209};\\\", \\\"{x:564,y:390,t:1527019741225};\\\", \\\"{x:501,y:405,t:1527019741242};\\\", \\\"{x:459,y:417,t:1527019741260};\\\", \\\"{x:435,y:426,t:1527019741275};\\\", \\\"{x:402,y:431,t:1527019741292};\\\", \\\"{x:383,y:435,t:1527019741309};\\\", \\\"{x:382,y:435,t:1527019741327};\\\", \\\"{x:381,y:435,t:1527019741486};\\\", \\\"{x:379,y:435,t:1527019741502};\\\", \\\"{x:378,y:435,t:1527019741510};\\\", \\\"{x:376,y:435,t:1527019741526};\\\", \\\"{x:375,y:436,t:1527019741543};\\\", \\\"{x:364,y:447,t:1527019741560};\\\", \\\"{x:343,y:462,t:1527019741576};\\\", \\\"{x:312,y:476,t:1527019741593};\\\", \\\"{x:288,y:488,t:1527019741609};\\\", \\\"{x:270,y:493,t:1527019741626};\\\", \\\"{x:257,y:493,t:1527019741643};\\\", \\\"{x:252,y:491,t:1527019741660};\\\", \\\"{x:247,y:486,t:1527019741677};\\\", \\\"{x:245,y:483,t:1527019741693};\\\", \\\"{x:243,y:480,t:1527019741710};\\\", \\\"{x:243,y:479,t:1527019741726};\\\", \\\"{x:242,y:479,t:1527019741743};\\\", \\\"{x:242,y:477,t:1527019741760};\\\", \\\"{x:242,y:474,t:1527019741776};\\\", \\\"{x:242,y:470,t:1527019741793};\\\", \\\"{x:242,y:469,t:1527019741810};\\\", \\\"{x:242,y:468,t:1527019741827};\\\", \\\"{x:242,y:467,t:1527019741844};\\\", \\\"{x:246,y:463,t:1527019741860};\\\", \\\"{x:255,y:459,t:1527019741877};\\\", \\\"{x:262,y:456,t:1527019741894};\\\", \\\"{x:275,y:454,t:1527019741910};\\\", \\\"{x:285,y:453,t:1527019741927};\\\", \\\"{x:300,y:452,t:1527019741944};\\\", \\\"{x:325,y:452,t:1527019741959};\\\", \\\"{x:345,y:452,t:1527019741976};\\\", \\\"{x:371,y:454,t:1527019741993};\\\", \\\"{x:396,y:458,t:1527019742009};\\\", \\\"{x:422,y:462,t:1527019742026};\\\", \\\"{x:449,y:466,t:1527019742043};\\\", \\\"{x:486,y:473,t:1527019742060};\\\", \\\"{x:523,y:479,t:1527019742077};\\\", \\\"{x:568,y:484,t:1527019742093};\\\", \\\"{x:590,y:485,t:1527019742110};\\\", \\\"{x:597,y:485,t:1527019742126};\\\", \\\"{x:601,y:485,t:1527019742143};\\\", \\\"{x:602,y:485,t:1527019742160};\\\", \\\"{x:603,y:485,t:1527019742342};\\\", \\\"{x:602,y:487,t:1527019742429};\\\", \\\"{x:600,y:488,t:1527019742443};\\\", \\\"{x:598,y:490,t:1527019742461};\\\", \\\"{x:595,y:492,t:1527019742477};\\\", \\\"{x:591,y:494,t:1527019742493};\\\", \\\"{x:588,y:496,t:1527019742510};\\\", \\\"{x:585,y:499,t:1527019742527};\\\", \\\"{x:580,y:501,t:1527019742544};\\\", \\\"{x:573,y:504,t:1527019742560};\\\", \\\"{x:571,y:505,t:1527019742577};\\\", \\\"{x:566,y:507,t:1527019742594};\\\", \\\"{x:563,y:509,t:1527019742611};\\\", \\\"{x:557,y:511,t:1527019742626};\\\", \\\"{x:556,y:511,t:1527019742644};\\\", \\\"{x:554,y:510,t:1527019742870};\\\", \\\"{x:554,y:509,t:1527019742901};\\\", \\\"{x:554,y:507,t:1527019742910};\\\", \\\"{x:554,y:506,t:1527019742958};\\\", \\\"{x:554,y:505,t:1527019742966};\\\", \\\"{x:554,y:504,t:1527019742978};\\\", \\\"{x:554,y:503,t:1527019742998};\\\", \\\"{x:554,y:502,t:1527019743011};\\\", \\\"{x:554,y:501,t:1527019743028};\\\", \\\"{x:554,y:499,t:1527019743044};\\\", \\\"{x:554,y:498,t:1527019743062};\\\", \\\"{x:554,y:496,t:1527019743101};\\\", \\\"{x:553,y:496,t:1527019743111};\\\", \\\"{x:552,y:495,t:1527019743128};\\\", \\\"{x:552,y:493,t:1527019743173};\\\", \\\"{x:552,y:492,t:1527019744669};\\\", \\\"{x:554,y:490,t:1527019744679};\\\", \\\"{x:560,y:486,t:1527019744696};\\\", \\\"{x:566,y:482,t:1527019744711};\\\", \\\"{x:573,y:479,t:1527019744728};\\\", \\\"{x:583,y:474,t:1527019744746};\\\", \\\"{x:592,y:470,t:1527019744762};\\\", \\\"{x:606,y:469,t:1527019744779};\\\", \\\"{x:625,y:466,t:1527019744795};\\\", \\\"{x:659,y:465,t:1527019744812};\\\", \\\"{x:720,y:465,t:1527019744829};\\\", \\\"{x:804,y:465,t:1527019744846};\\\", \\\"{x:866,y:463,t:1527019744862};\\\", \\\"{x:946,y:463,t:1527019744878};\\\", \\\"{x:1041,y:463,t:1527019744896};\\\", \\\"{x:1122,y:466,t:1527019744913};\\\", \\\"{x:1203,y:468,t:1527019744928};\\\", \\\"{x:1285,y:471,t:1527019744946};\\\", \\\"{x:1345,y:474,t:1527019744963};\\\", \\\"{x:1391,y:477,t:1527019744978};\\\", \\\"{x:1431,y:479,t:1527019744996};\\\", \\\"{x:1461,y:481,t:1527019745012};\\\", \\\"{x:1483,y:481,t:1527019745028};\\\", \\\"{x:1507,y:483,t:1527019745046};\\\", \\\"{x:1512,y:484,t:1527019745062};\\\", \\\"{x:1511,y:484,t:1527019745101};\\\", \\\"{x:1509,y:484,t:1527019745112};\\\", \\\"{x:1492,y:486,t:1527019745129};\\\", \\\"{x:1470,y:487,t:1527019745146};\\\", \\\"{x:1458,y:487,t:1527019745163};\\\", \\\"{x:1449,y:486,t:1527019745179};\\\", \\\"{x:1439,y:484,t:1527019745195};\\\", \\\"{x:1427,y:482,t:1527019745213};\\\", \\\"{x:1420,y:480,t:1527019745228};\\\", \\\"{x:1409,y:478,t:1527019745245};\\\", \\\"{x:1405,y:478,t:1527019745263};\\\", \\\"{x:1400,y:478,t:1527019745280};\\\", \\\"{x:1397,y:478,t:1527019745295};\\\", \\\"{x:1396,y:478,t:1527019745313};\\\", \\\"{x:1395,y:478,t:1527019745330};\\\", \\\"{x:1395,y:479,t:1527019745350};\\\", \\\"{x:1393,y:479,t:1527019745365};\\\", \\\"{x:1391,y:481,t:1527019745379};\\\", \\\"{x:1384,y:483,t:1527019745396};\\\", \\\"{x:1380,y:486,t:1527019745414};\\\", \\\"{x:1374,y:489,t:1527019745430};\\\", \\\"{x:1370,y:491,t:1527019745446};\\\", \\\"{x:1366,y:494,t:1527019745464};\\\", \\\"{x:1363,y:497,t:1527019745480};\\\", \\\"{x:1355,y:501,t:1527019745496};\\\", \\\"{x:1350,y:503,t:1527019745513};\\\", \\\"{x:1349,y:504,t:1527019745530};\\\", \\\"{x:1347,y:505,t:1527019745546};\\\", \\\"{x:1345,y:506,t:1527019745563};\\\", \\\"{x:1344,y:506,t:1527019745582};\\\", \\\"{x:1342,y:506,t:1527019745606};\\\", \\\"{x:1341,y:506,t:1527019745614};\\\", \\\"{x:1335,y:506,t:1527019745630};\\\", \\\"{x:1332,y:506,t:1527019745647};\\\", \\\"{x:1323,y:504,t:1527019745663};\\\", \\\"{x:1313,y:503,t:1527019745680};\\\", \\\"{x:1303,y:498,t:1527019745696};\\\", \\\"{x:1296,y:494,t:1527019745713};\\\", \\\"{x:1291,y:493,t:1527019745730};\\\", \\\"{x:1286,y:491,t:1527019745746};\\\", \\\"{x:1284,y:490,t:1527019745763};\\\", \\\"{x:1284,y:489,t:1527019745780};\\\", \\\"{x:1283,y:489,t:1527019745893};\\\", \\\"{x:1282,y:487,t:1527019745901};\\\", \\\"{x:1280,y:485,t:1527019745912};\\\", \\\"{x:1280,y:481,t:1527019745930};\\\", \\\"{x:1280,y:476,t:1527019745947};\\\", \\\"{x:1280,y:474,t:1527019745963};\\\", \\\"{x:1280,y:471,t:1527019745980};\\\", \\\"{x:1281,y:469,t:1527019745997};\\\", \\\"{x:1282,y:468,t:1527019746021};\\\", \\\"{x:1283,y:467,t:1527019746030};\\\", \\\"{x:1286,y:465,t:1527019746046};\\\", \\\"{x:1288,y:465,t:1527019746102};\\\", \\\"{x:1289,y:465,t:1527019746118};\\\", \\\"{x:1291,y:466,t:1527019746130};\\\", \\\"{x:1292,y:468,t:1527019746147};\\\", \\\"{x:1293,y:469,t:1527019746190};\\\", \\\"{x:1293,y:472,t:1527019746198};\\\", \\\"{x:1294,y:474,t:1527019746214};\\\", \\\"{x:1296,y:478,t:1527019746230};\\\", \\\"{x:1297,y:479,t:1527019746261};\\\", \\\"{x:1297,y:480,t:1527019746269};\\\", \\\"{x:1298,y:480,t:1527019746414};\\\", \\\"{x:1298,y:481,t:1527019746471};\\\", \\\"{x:1298,y:483,t:1527019746480};\\\", \\\"{x:1300,y:485,t:1527019746502};\\\", \\\"{x:1300,y:486,t:1527019746514};\\\", \\\"{x:1301,y:487,t:1527019746530};\\\", \\\"{x:1301,y:489,t:1527019746547};\\\", \\\"{x:1301,y:490,t:1527019746565};\\\", \\\"{x:1302,y:491,t:1527019746590};\\\", \\\"{x:1303,y:492,t:1527019746597};\\\", \\\"{x:1304,y:492,t:1527019746942};\\\", \\\"{x:1305,y:492,t:1527019747039};\\\", \\\"{x:1306,y:492,t:1527019747047};\\\", \\\"{x:1307,y:492,t:1527019747064};\\\", \\\"{x:1313,y:492,t:1527019747083};\\\", \\\"{x:1319,y:492,t:1527019747099};\\\", \\\"{x:1321,y:492,t:1527019747114};\\\", \\\"{x:1322,y:492,t:1527019747581};\\\", \\\"{x:1322,y:493,t:1527019747597};\\\", \\\"{x:1323,y:493,t:1527019747621};\\\", \\\"{x:1323,y:495,t:1527019747661};\\\", \\\"{x:1323,y:496,t:1527019748142};\\\", \\\"{x:1322,y:497,t:1527019748183};\\\", \\\"{x:1322,y:498,t:1527019748206};\\\", \\\"{x:1322,y:499,t:1527019748215};\\\", \\\"{x:1322,y:502,t:1527019748232};\\\", \\\"{x:1321,y:505,t:1527019748249};\\\", \\\"{x:1320,y:509,t:1527019748266};\\\", \\\"{x:1319,y:512,t:1527019748282};\\\", \\\"{x:1317,y:518,t:1527019748298};\\\", \\\"{x:1316,y:521,t:1527019748315};\\\", \\\"{x:1315,y:529,t:1527019748332};\\\", \\\"{x:1315,y:536,t:1527019748348};\\\", \\\"{x:1315,y:544,t:1527019748365};\\\", \\\"{x:1315,y:549,t:1527019748382};\\\", \\\"{x:1315,y:551,t:1527019748398};\\\", \\\"{x:1314,y:557,t:1527019748415};\\\", \\\"{x:1314,y:562,t:1527019748432};\\\", \\\"{x:1314,y:567,t:1527019748449};\\\", \\\"{x:1314,y:576,t:1527019748465};\\\", \\\"{x:1315,y:584,t:1527019748483};\\\", \\\"{x:1316,y:590,t:1527019748500};\\\", \\\"{x:1317,y:596,t:1527019748515};\\\", \\\"{x:1318,y:602,t:1527019748532};\\\", \\\"{x:1320,y:608,t:1527019748548};\\\", \\\"{x:1320,y:612,t:1527019748565};\\\", \\\"{x:1320,y:614,t:1527019748582};\\\", \\\"{x:1320,y:618,t:1527019748599};\\\", \\\"{x:1322,y:621,t:1527019748614};\\\", \\\"{x:1323,y:625,t:1527019748631};\\\", \\\"{x:1323,y:631,t:1527019748648};\\\", \\\"{x:1323,y:635,t:1527019748664};\\\", \\\"{x:1323,y:640,t:1527019748682};\\\", \\\"{x:1323,y:643,t:1527019748699};\\\", \\\"{x:1323,y:647,t:1527019748714};\\\", \\\"{x:1323,y:650,t:1527019748732};\\\", \\\"{x:1323,y:658,t:1527019748748};\\\", \\\"{x:1323,y:662,t:1527019748764};\\\", \\\"{x:1323,y:666,t:1527019748782};\\\", \\\"{x:1323,y:671,t:1527019748798};\\\", \\\"{x:1323,y:674,t:1527019748815};\\\", \\\"{x:1323,y:678,t:1527019748832};\\\", \\\"{x:1323,y:681,t:1527019748849};\\\", \\\"{x:1323,y:686,t:1527019748864};\\\", \\\"{x:1323,y:687,t:1527019748881};\\\", \\\"{x:1322,y:692,t:1527019748899};\\\", \\\"{x:1322,y:694,t:1527019748915};\\\", \\\"{x:1322,y:699,t:1527019748931};\\\", \\\"{x:1319,y:713,t:1527019748970};\\\", \\\"{x:1316,y:721,t:1527019748981};\\\", \\\"{x:1311,y:737,t:1527019748999};\\\", \\\"{x:1309,y:747,t:1527019749016};\\\", \\\"{x:1306,y:760,t:1527019749032};\\\", \\\"{x:1306,y:771,t:1527019749048};\\\", \\\"{x:1306,y:779,t:1527019749065};\\\", \\\"{x:1306,y:785,t:1527019749082};\\\", \\\"{x:1306,y:791,t:1527019749099};\\\", \\\"{x:1306,y:794,t:1527019749116};\\\", \\\"{x:1309,y:798,t:1527019749132};\\\", \\\"{x:1309,y:803,t:1527019749148};\\\", \\\"{x:1309,y:805,t:1527019749166};\\\", \\\"{x:1309,y:806,t:1527019749182};\\\", \\\"{x:1309,y:807,t:1527019749213};\\\", \\\"{x:1309,y:808,t:1527019749246};\\\", \\\"{x:1309,y:810,t:1527019749253};\\\", \\\"{x:1309,y:811,t:1527019749265};\\\", \\\"{x:1309,y:818,t:1527019749282};\\\", \\\"{x:1309,y:821,t:1527019749299};\\\", \\\"{x:1309,y:826,t:1527019749316};\\\", \\\"{x:1311,y:828,t:1527019749332};\\\", \\\"{x:1311,y:829,t:1527019749350};\\\", \\\"{x:1312,y:837,t:1527019749366};\\\", \\\"{x:1311,y:844,t:1527019749384};\\\", \\\"{x:1309,y:847,t:1527019749406};\\\", \\\"{x:1309,y:848,t:1527019749416};\\\", \\\"{x:1309,y:849,t:1527019749433};\\\", \\\"{x:1308,y:849,t:1527019749510};\\\", \\\"{x:1308,y:850,t:1527019749661};\\\", \\\"{x:1309,y:851,t:1527019749669};\\\", \\\"{x:1310,y:854,t:1527019749683};\\\", \\\"{x:1310,y:857,t:1527019749699};\\\", \\\"{x:1310,y:858,t:1527019749716};\\\", \\\"{x:1310,y:861,t:1527019749732};\\\", \\\"{x:1308,y:868,t:1527019749749};\\\", \\\"{x:1307,y:875,t:1527019749766};\\\", \\\"{x:1305,y:881,t:1527019749783};\\\", \\\"{x:1303,y:890,t:1527019749799};\\\", \\\"{x:1301,y:901,t:1527019749816};\\\", \\\"{x:1299,y:906,t:1527019749833};\\\", \\\"{x:1299,y:909,t:1527019749849};\\\", \\\"{x:1298,y:912,t:1527019749866};\\\", \\\"{x:1298,y:914,t:1527019749883};\\\", \\\"{x:1296,y:916,t:1527019749900};\\\", \\\"{x:1296,y:917,t:1527019749916};\\\", \\\"{x:1296,y:919,t:1527019749933};\\\", \\\"{x:1296,y:920,t:1527019749950};\\\", \\\"{x:1296,y:922,t:1527019749966};\\\", \\\"{x:1296,y:923,t:1527019749984};\\\", \\\"{x:1296,y:925,t:1527019750000};\\\", \\\"{x:1295,y:927,t:1527019750017};\\\", \\\"{x:1295,y:930,t:1527019750033};\\\", \\\"{x:1295,y:933,t:1527019750050};\\\", \\\"{x:1294,y:935,t:1527019750067};\\\", \\\"{x:1294,y:938,t:1527019750084};\\\", \\\"{x:1293,y:944,t:1527019750101};\\\", \\\"{x:1293,y:948,t:1527019750116};\\\", \\\"{x:1293,y:951,t:1527019750134};\\\", \\\"{x:1293,y:953,t:1527019750166};\\\", \\\"{x:1293,y:954,t:1527019750237};\\\", \\\"{x:1293,y:956,t:1527019750269};\\\", \\\"{x:1293,y:957,t:1527019750326};\\\", \\\"{x:1293,y:958,t:1527019750365};\\\", \\\"{x:1295,y:958,t:1527019750574};\\\", \\\"{x:1297,y:958,t:1527019750583};\\\", \\\"{x:1303,y:956,t:1527019750601};\\\", \\\"{x:1305,y:955,t:1527019750618};\\\", \\\"{x:1306,y:955,t:1527019750634};\\\", \\\"{x:1306,y:954,t:1527019754534};\\\", \\\"{x:1306,y:949,t:1527019754542};\\\", \\\"{x:1309,y:941,t:1527019754554};\\\", \\\"{x:1310,y:931,t:1527019754570};\\\", \\\"{x:1310,y:921,t:1527019754586};\\\", \\\"{x:1310,y:914,t:1527019754604};\\\", \\\"{x:1308,y:906,t:1527019754620};\\\", \\\"{x:1306,y:885,t:1527019754638};\\\", \\\"{x:1306,y:870,t:1527019754654};\\\", \\\"{x:1306,y:854,t:1527019754670};\\\", \\\"{x:1306,y:833,t:1527019754688};\\\", \\\"{x:1306,y:815,t:1527019754703};\\\", \\\"{x:1306,y:796,t:1527019754720};\\\", \\\"{x:1306,y:780,t:1527019754738};\\\", \\\"{x:1306,y:765,t:1527019754754};\\\", \\\"{x:1306,y:750,t:1527019754771};\\\", \\\"{x:1306,y:736,t:1527019754788};\\\", \\\"{x:1306,y:729,t:1527019754804};\\\", \\\"{x:1306,y:717,t:1527019754821};\\\", \\\"{x:1306,y:700,t:1527019754838};\\\", \\\"{x:1304,y:689,t:1527019754854};\\\", \\\"{x:1304,y:670,t:1527019754871};\\\", \\\"{x:1304,y:653,t:1527019754888};\\\", \\\"{x:1304,y:638,t:1527019754904};\\\", \\\"{x:1308,y:621,t:1527019754920};\\\", \\\"{x:1309,y:606,t:1527019754938};\\\", \\\"{x:1310,y:593,t:1527019754953};\\\", \\\"{x:1310,y:578,t:1527019754971};\\\", \\\"{x:1310,y:566,t:1527019754987};\\\", \\\"{x:1311,y:552,t:1527019755003};\\\", \\\"{x:1314,y:539,t:1527019755021};\\\", \\\"{x:1318,y:521,t:1527019755037};\\\", \\\"{x:1321,y:507,t:1527019755054};\\\", \\\"{x:1324,y:497,t:1527019755071};\\\", \\\"{x:1324,y:490,t:1527019755088};\\\", \\\"{x:1325,y:485,t:1527019755105};\\\", \\\"{x:1325,y:482,t:1527019755120};\\\", \\\"{x:1325,y:480,t:1527019755137};\\\", \\\"{x:1327,y:475,t:1527019755154};\\\", \\\"{x:1327,y:472,t:1527019755171};\\\", \\\"{x:1327,y:471,t:1527019755187};\\\", \\\"{x:1327,y:470,t:1527019755204};\\\", \\\"{x:1327,y:469,t:1527019755220};\\\", \\\"{x:1328,y:472,t:1527019755463};\\\", \\\"{x:1328,y:475,t:1527019755471};\\\", \\\"{x:1328,y:480,t:1527019755487};\\\", \\\"{x:1331,y:486,t:1527019755504};\\\", \\\"{x:1331,y:492,t:1527019755521};\\\", \\\"{x:1333,y:498,t:1527019755537};\\\", \\\"{x:1335,y:502,t:1527019755555};\\\", \\\"{x:1337,y:507,t:1527019755572};\\\", \\\"{x:1339,y:512,t:1527019755588};\\\", \\\"{x:1341,y:515,t:1527019755605};\\\", \\\"{x:1344,y:520,t:1527019755622};\\\", \\\"{x:1344,y:521,t:1527019755638};\\\", \\\"{x:1344,y:522,t:1527019755654};\\\", \\\"{x:1344,y:524,t:1527019755671};\\\", \\\"{x:1345,y:525,t:1527019755688};\\\", \\\"{x:1346,y:528,t:1527019755704};\\\", \\\"{x:1347,y:534,t:1527019755722};\\\", \\\"{x:1349,y:536,t:1527019755738};\\\", \\\"{x:1349,y:538,t:1527019755755};\\\", \\\"{x:1350,y:541,t:1527019755771};\\\", \\\"{x:1350,y:542,t:1527019755788};\\\", \\\"{x:1351,y:546,t:1527019755804};\\\", \\\"{x:1351,y:552,t:1527019755822};\\\", \\\"{x:1352,y:554,t:1527019755838};\\\", \\\"{x:1353,y:556,t:1527019755855};\\\", \\\"{x:1353,y:560,t:1527019755872};\\\", \\\"{x:1354,y:566,t:1527019755888};\\\", \\\"{x:1355,y:569,t:1527019755905};\\\", \\\"{x:1355,y:578,t:1527019755922};\\\", \\\"{x:1355,y:583,t:1527019755938};\\\", \\\"{x:1355,y:590,t:1527019755955};\\\", \\\"{x:1355,y:597,t:1527019755971};\\\", \\\"{x:1355,y:602,t:1527019755989};\\\", \\\"{x:1356,y:609,t:1527019756005};\\\", \\\"{x:1356,y:618,t:1527019756022};\\\", \\\"{x:1356,y:620,t:1527019756038};\\\", \\\"{x:1356,y:623,t:1527019756054};\\\", \\\"{x:1353,y:627,t:1527019756071};\\\", \\\"{x:1352,y:629,t:1527019756088};\\\", \\\"{x:1352,y:630,t:1527019756105};\\\", \\\"{x:1352,y:631,t:1527019756122};\\\", \\\"{x:1350,y:632,t:1527019756138};\\\", \\\"{x:1349,y:634,t:1527019756155};\\\", \\\"{x:1348,y:635,t:1527019756172};\\\", \\\"{x:1347,y:636,t:1527019756189};\\\", \\\"{x:1347,y:637,t:1527019756206};\\\", \\\"{x:1347,y:639,t:1527019756221};\\\", \\\"{x:1346,y:641,t:1527019756239};\\\", \\\"{x:1345,y:647,t:1527019756255};\\\", \\\"{x:1343,y:652,t:1527019756272};\\\", \\\"{x:1341,y:658,t:1527019756289};\\\", \\\"{x:1339,y:664,t:1527019756305};\\\", \\\"{x:1339,y:667,t:1527019756322};\\\", \\\"{x:1338,y:671,t:1527019756339};\\\", \\\"{x:1336,y:675,t:1527019756355};\\\", \\\"{x:1335,y:679,t:1527019756372};\\\", \\\"{x:1334,y:686,t:1527019756389};\\\", \\\"{x:1331,y:691,t:1527019756405};\\\", \\\"{x:1331,y:698,t:1527019756422};\\\", \\\"{x:1328,y:702,t:1527019756438};\\\", \\\"{x:1327,y:708,t:1527019756456};\\\", \\\"{x:1323,y:714,t:1527019756472};\\\", \\\"{x:1321,y:724,t:1527019756488};\\\", \\\"{x:1318,y:733,t:1527019756506};\\\", \\\"{x:1315,y:743,t:1527019756521};\\\", \\\"{x:1314,y:749,t:1527019756539};\\\", \\\"{x:1311,y:753,t:1527019756556};\\\", \\\"{x:1311,y:758,t:1527019756572};\\\", \\\"{x:1311,y:761,t:1527019756590};\\\", \\\"{x:1310,y:767,t:1527019756605};\\\", \\\"{x:1310,y:768,t:1527019756623};\\\", \\\"{x:1309,y:770,t:1527019756639};\\\", \\\"{x:1308,y:773,t:1527019756656};\\\", \\\"{x:1308,y:774,t:1527019756671};\\\", \\\"{x:1308,y:776,t:1527019756689};\\\", \\\"{x:1308,y:779,t:1527019756706};\\\", \\\"{x:1308,y:782,t:1527019756722};\\\", \\\"{x:1310,y:785,t:1527019756739};\\\", \\\"{x:1310,y:789,t:1527019756756};\\\", \\\"{x:1311,y:792,t:1527019756772};\\\", \\\"{x:1312,y:794,t:1527019756789};\\\", \\\"{x:1316,y:798,t:1527019756806};\\\", \\\"{x:1318,y:804,t:1527019756821};\\\", \\\"{x:1318,y:809,t:1527019756839};\\\", \\\"{x:1319,y:814,t:1527019756856};\\\", \\\"{x:1320,y:817,t:1527019756873};\\\", \\\"{x:1320,y:820,t:1527019756888};\\\", \\\"{x:1322,y:823,t:1527019756905};\\\", \\\"{x:1322,y:824,t:1527019756922};\\\", \\\"{x:1323,y:828,t:1527019756938};\\\", \\\"{x:1323,y:829,t:1527019756955};\\\", \\\"{x:1323,y:830,t:1527019756973};\\\", \\\"{x:1325,y:831,t:1527019756989};\\\", \\\"{x:1325,y:832,t:1527019757046};\\\", \\\"{x:1325,y:833,t:1527019757055};\\\", \\\"{x:1325,y:836,t:1527019757072};\\\", \\\"{x:1325,y:837,t:1527019757089};\\\", \\\"{x:1325,y:839,t:1527019757106};\\\", \\\"{x:1325,y:840,t:1527019757122};\\\", \\\"{x:1325,y:846,t:1527019757139};\\\", \\\"{x:1325,y:849,t:1527019757155};\\\", \\\"{x:1326,y:854,t:1527019757172};\\\", \\\"{x:1327,y:861,t:1527019757188};\\\", \\\"{x:1328,y:868,t:1527019757206};\\\", \\\"{x:1328,y:873,t:1527019757223};\\\", \\\"{x:1328,y:878,t:1527019757239};\\\", \\\"{x:1330,y:886,t:1527019757255};\\\", \\\"{x:1330,y:890,t:1527019757273};\\\", \\\"{x:1332,y:896,t:1527019757290};\\\", \\\"{x:1332,y:904,t:1527019757305};\\\", \\\"{x:1332,y:910,t:1527019757323};\\\", \\\"{x:1331,y:918,t:1527019757340};\\\", \\\"{x:1328,y:925,t:1527019757356};\\\", \\\"{x:1328,y:933,t:1527019757372};\\\", \\\"{x:1327,y:938,t:1527019757390};\\\", \\\"{x:1327,y:939,t:1527019757406};\\\", \\\"{x:1325,y:941,t:1527019757423};\\\", \\\"{x:1324,y:943,t:1527019757440};\\\", \\\"{x:1321,y:947,t:1527019757456};\\\", \\\"{x:1319,y:950,t:1527019757473};\\\", \\\"{x:1317,y:953,t:1527019757490};\\\", \\\"{x:1316,y:954,t:1527019757506};\\\", \\\"{x:1316,y:955,t:1527019757523};\\\", \\\"{x:1316,y:958,t:1527019757540};\\\", \\\"{x:1316,y:959,t:1527019757573};\\\", \\\"{x:1316,y:960,t:1527019757589};\\\", \\\"{x:1316,y:961,t:1527019757645};\\\", \\\"{x:1316,y:962,t:1527019757717};\\\", \\\"{x:1316,y:963,t:1527019757733};\\\", \\\"{x:1316,y:964,t:1527019757749};\\\", \\\"{x:1316,y:967,t:1527019759470};\\\", \\\"{x:1313,y:968,t:1527019759477};\\\", \\\"{x:1309,y:971,t:1527019759491};\\\", \\\"{x:1299,y:974,t:1527019759508};\\\", \\\"{x:1297,y:974,t:1527019759646};\\\", \\\"{x:1294,y:974,t:1527019759658};\\\", \\\"{x:1282,y:974,t:1527019759675};\\\", \\\"{x:1271,y:969,t:1527019759691};\\\", \\\"{x:1257,y:963,t:1527019759709};\\\", \\\"{x:1248,y:959,t:1527019759725};\\\", \\\"{x:1223,y:953,t:1527019759741};\\\", \\\"{x:1167,y:936,t:1527019759758};\\\", \\\"{x:1122,y:927,t:1527019759774};\\\", \\\"{x:1112,y:926,t:1527019759791};\\\", \\\"{x:1106,y:925,t:1527019759808};\\\", \\\"{x:1103,y:924,t:1527019759825};\\\", \\\"{x:1102,y:923,t:1527019759841};\\\", \\\"{x:1098,y:923,t:1527019760214};\\\", \\\"{x:1096,y:922,t:1527019760225};\\\", \\\"{x:1092,y:921,t:1527019760242};\\\", \\\"{x:1087,y:921,t:1527019760258};\\\", \\\"{x:1084,y:921,t:1527019760274};\\\", \\\"{x:1081,y:920,t:1527019760291};\\\", \\\"{x:1080,y:920,t:1527019760308};\\\", \\\"{x:1079,y:920,t:1527019760325};\\\", \\\"{x:1079,y:919,t:1527019760342};\\\", \\\"{x:1077,y:919,t:1527019760702};\\\", \\\"{x:1074,y:918,t:1527019760709};\\\", \\\"{x:1070,y:916,t:1527019760725};\\\", \\\"{x:1067,y:916,t:1527019760742};\\\", \\\"{x:1066,y:915,t:1527019760759};\\\", \\\"{x:1064,y:915,t:1527019760782};\\\", \\\"{x:1063,y:915,t:1527019760806};\\\", \\\"{x:1061,y:915,t:1527019760830};\\\", \\\"{x:1060,y:915,t:1527019760846};\\\", \\\"{x:1058,y:915,t:1527019760859};\\\", \\\"{x:1056,y:914,t:1527019760876};\\\", \\\"{x:1054,y:914,t:1527019760892};\\\", \\\"{x:1052,y:914,t:1527019760909};\\\", \\\"{x:1047,y:913,t:1527019760926};\\\", \\\"{x:1045,y:913,t:1527019760942};\\\", \\\"{x:1044,y:913,t:1527019760958};\\\", \\\"{x:1041,y:913,t:1527019760975};\\\", \\\"{x:1041,y:912,t:1527019760992};\\\", \\\"{x:1040,y:912,t:1527019761009};\\\", \\\"{x:1039,y:912,t:1527019761025};\\\", \\\"{x:1038,y:912,t:1527019761042};\\\", \\\"{x:1037,y:912,t:1527019761058};\\\", \\\"{x:1035,y:911,t:1527019761076};\\\", \\\"{x:1034,y:911,t:1527019762359};\\\", \\\"{x:1032,y:910,t:1527019762365};\\\", \\\"{x:1031,y:910,t:1527019762377};\\\", \\\"{x:1029,y:909,t:1527019762392};\\\", \\\"{x:1028,y:909,t:1527019762413};\\\", \\\"{x:1027,y:909,t:1527019762426};\\\", \\\"{x:1026,y:909,t:1527019762442};\\\", \\\"{x:1024,y:907,t:1527019762459};\\\", \\\"{x:1022,y:906,t:1527019762533};\\\", \\\"{x:1021,y:906,t:1527019762542};\\\", \\\"{x:1020,y:906,t:1527019762559};\\\", \\\"{x:1019,y:906,t:1527019762576};\\\", \\\"{x:1021,y:904,t:1527019768406};\\\", \\\"{x:1025,y:902,t:1527019768415};\\\", \\\"{x:1036,y:896,t:1527019768431};\\\", \\\"{x:1041,y:893,t:1527019768448};\\\", \\\"{x:1041,y:892,t:1527019768466};\\\", \\\"{x:1045,y:889,t:1527019768481};\\\", \\\"{x:1051,y:877,t:1527019768498};\\\", \\\"{x:1059,y:865,t:1527019768515};\\\", \\\"{x:1064,y:862,t:1527019768531};\\\", \\\"{x:1072,y:848,t:1527019768548};\\\", \\\"{x:1085,y:834,t:1527019768566};\\\", \\\"{x:1107,y:807,t:1527019768581};\\\", \\\"{x:1138,y:774,t:1527019768598};\\\", \\\"{x:1154,y:756,t:1527019768615};\\\", \\\"{x:1159,y:750,t:1527019768632};\\\", \\\"{x:1162,y:746,t:1527019768649};\\\", \\\"{x:1164,y:744,t:1527019768666};\\\", \\\"{x:1164,y:742,t:1527019768681};\\\", \\\"{x:1166,y:740,t:1527019768742};\\\", \\\"{x:1168,y:740,t:1527019768750};\\\", \\\"{x:1170,y:740,t:1527019768765};\\\", \\\"{x:1179,y:736,t:1527019768782};\\\", \\\"{x:1184,y:735,t:1527019768799};\\\", \\\"{x:1193,y:735,t:1527019768816};\\\", \\\"{x:1203,y:739,t:1527019768832};\\\", \\\"{x:1217,y:744,t:1527019768849};\\\", \\\"{x:1226,y:748,t:1527019768865};\\\", \\\"{x:1236,y:748,t:1527019768882};\\\", \\\"{x:1246,y:747,t:1527019768898};\\\", \\\"{x:1255,y:744,t:1527019768915};\\\", \\\"{x:1261,y:740,t:1527019768933};\\\", \\\"{x:1262,y:740,t:1527019768948};\\\", \\\"{x:1263,y:740,t:1527019769174};\\\", \\\"{x:1264,y:742,t:1527019769181};\\\", \\\"{x:1271,y:749,t:1527019769199};\\\", \\\"{x:1274,y:753,t:1527019769215};\\\", \\\"{x:1276,y:754,t:1527019769232};\\\", \\\"{x:1279,y:755,t:1527019769249};\\\", \\\"{x:1280,y:755,t:1527019769269};\\\", \\\"{x:1281,y:755,t:1527019769286};\\\", \\\"{x:1282,y:756,t:1527019769302};\\\", \\\"{x:1283,y:756,t:1527019769358};\\\", \\\"{x:1284,y:756,t:1527019769415};\\\", \\\"{x:1285,y:756,t:1527019769432};\\\", \\\"{x:1294,y:756,t:1527019769449};\\\", \\\"{x:1304,y:754,t:1527019769466};\\\", \\\"{x:1309,y:754,t:1527019769482};\\\", \\\"{x:1311,y:754,t:1527019769499};\\\", \\\"{x:1312,y:754,t:1527019769515};\\\", \\\"{x:1313,y:754,t:1527019769532};\\\", \\\"{x:1315,y:754,t:1527019769598};\\\", \\\"{x:1316,y:754,t:1527019769615};\\\", \\\"{x:1318,y:755,t:1527019769633};\\\", \\\"{x:1319,y:755,t:1527019769654};\\\", \\\"{x:1319,y:756,t:1527019769666};\\\", \\\"{x:1323,y:758,t:1527019769682};\\\", \\\"{x:1332,y:759,t:1527019769699};\\\", \\\"{x:1342,y:760,t:1527019769716};\\\", \\\"{x:1352,y:762,t:1527019769732};\\\", \\\"{x:1366,y:764,t:1527019769750};\\\", \\\"{x:1376,y:764,t:1527019769766};\\\", \\\"{x:1389,y:765,t:1527019769783};\\\", \\\"{x:1396,y:767,t:1527019769798};\\\", \\\"{x:1405,y:769,t:1527019769816};\\\", \\\"{x:1408,y:771,t:1527019769831};\\\", \\\"{x:1410,y:773,t:1527019769849};\\\", \\\"{x:1413,y:776,t:1527019769865};\\\", \\\"{x:1417,y:783,t:1527019769881};\\\", \\\"{x:1417,y:791,t:1527019769899};\\\", \\\"{x:1421,y:797,t:1527019769916};\\\", \\\"{x:1425,y:807,t:1527019769932};\\\", \\\"{x:1432,y:823,t:1527019769949};\\\", \\\"{x:1438,y:839,t:1527019769965};\\\", \\\"{x:1447,y:855,t:1527019769982};\\\", \\\"{x:1456,y:874,t:1527019769999};\\\", \\\"{x:1469,y:890,t:1527019770016};\\\", \\\"{x:1475,y:905,t:1527019770032};\\\", \\\"{x:1482,y:921,t:1527019770049};\\\", \\\"{x:1490,y:941,t:1527019770066};\\\", \\\"{x:1498,y:959,t:1527019770083};\\\", \\\"{x:1509,y:977,t:1527019770099};\\\", \\\"{x:1514,y:988,t:1527019770116};\\\", \\\"{x:1518,y:998,t:1527019770133};\\\", \\\"{x:1520,y:1002,t:1527019770149};\\\", \\\"{x:1521,y:1007,t:1527019770166};\\\", \\\"{x:1522,y:1010,t:1527019770182};\\\", \\\"{x:1522,y:1012,t:1527019770204};\\\", \\\"{x:1523,y:1013,t:1527019770221};\\\", \\\"{x:1524,y:1014,t:1527019770333};\\\", \\\"{x:1527,y:1012,t:1527019770349};\\\", \\\"{x:1528,y:1008,t:1527019770366};\\\", \\\"{x:1529,y:1005,t:1527019770383};\\\", \\\"{x:1529,y:1003,t:1527019770437};\\\", \\\"{x:1530,y:1001,t:1527019770452};\\\", \\\"{x:1530,y:1000,t:1527019770468};\\\", \\\"{x:1530,y:999,t:1527019770483};\\\", \\\"{x:1530,y:992,t:1527019770499};\\\", \\\"{x:1530,y:986,t:1527019770516};\\\", \\\"{x:1530,y:975,t:1527019770532};\\\", \\\"{x:1530,y:970,t:1527019770549};\\\", \\\"{x:1531,y:966,t:1527019770565};\\\", \\\"{x:1531,y:963,t:1527019770583};\\\", \\\"{x:1531,y:962,t:1527019770600};\\\", \\\"{x:1530,y:958,t:1527019770616};\\\", \\\"{x:1530,y:956,t:1527019770633};\\\", \\\"{x:1530,y:952,t:1527019770650};\\\", \\\"{x:1530,y:951,t:1527019770666};\\\", \\\"{x:1530,y:950,t:1527019770683};\\\", \\\"{x:1530,y:948,t:1527019770700};\\\", \\\"{x:1530,y:947,t:1527019770718};\\\", \\\"{x:1530,y:946,t:1527019770766};\\\", \\\"{x:1530,y:944,t:1527019770784};\\\", \\\"{x:1530,y:943,t:1527019770801};\\\", \\\"{x:1530,y:940,t:1527019770816};\\\", \\\"{x:1531,y:938,t:1527019770833};\\\", \\\"{x:1531,y:935,t:1527019770850};\\\", \\\"{x:1531,y:934,t:1527019770866};\\\", \\\"{x:1532,y:930,t:1527019770883};\\\", \\\"{x:1532,y:928,t:1527019770900};\\\", \\\"{x:1534,y:923,t:1527019770916};\\\", \\\"{x:1534,y:918,t:1527019770933};\\\", \\\"{x:1534,y:914,t:1527019770950};\\\", \\\"{x:1534,y:911,t:1527019770967};\\\", \\\"{x:1534,y:910,t:1527019770984};\\\", \\\"{x:1535,y:908,t:1527019771001};\\\", \\\"{x:1535,y:904,t:1527019771017};\\\", \\\"{x:1535,y:901,t:1527019771033};\\\", \\\"{x:1535,y:898,t:1527019771050};\\\", \\\"{x:1535,y:896,t:1527019771067};\\\", \\\"{x:1535,y:895,t:1527019771083};\\\", \\\"{x:1535,y:894,t:1527019771109};\\\", \\\"{x:1535,y:893,t:1527019771117};\\\", \\\"{x:1535,y:891,t:1527019771149};\\\", \\\"{x:1536,y:890,t:1527019771181};\\\", \\\"{x:1538,y:891,t:1527019771374};\\\", \\\"{x:1540,y:897,t:1527019771384};\\\", \\\"{x:1543,y:910,t:1527019771401};\\\", \\\"{x:1546,y:924,t:1527019771417};\\\", \\\"{x:1551,y:936,t:1527019771435};\\\", \\\"{x:1557,y:946,t:1527019771451};\\\", \\\"{x:1561,y:954,t:1527019771468};\\\", \\\"{x:1565,y:962,t:1527019771485};\\\", \\\"{x:1566,y:964,t:1527019771501};\\\", \\\"{x:1567,y:967,t:1527019771517};\\\", \\\"{x:1568,y:968,t:1527019771534};\\\", \\\"{x:1569,y:969,t:1527019771550};\\\", \\\"{x:1568,y:969,t:1527019771790};\\\", \\\"{x:1565,y:967,t:1527019771801};\\\", \\\"{x:1561,y:963,t:1527019771818};\\\", \\\"{x:1553,y:960,t:1527019771835};\\\", \\\"{x:1548,y:958,t:1527019771851};\\\", \\\"{x:1546,y:956,t:1527019771867};\\\", \\\"{x:1545,y:956,t:1527019771884};\\\", \\\"{x:1544,y:956,t:1527019771902};\\\", \\\"{x:1543,y:955,t:1527019771919};\\\", \\\"{x:1543,y:954,t:1527019772174};\\\", \\\"{x:1543,y:952,t:1527019772185};\\\", \\\"{x:1543,y:947,t:1527019772201};\\\", \\\"{x:1543,y:943,t:1527019772217};\\\", \\\"{x:1543,y:939,t:1527019772234};\\\", \\\"{x:1543,y:933,t:1527019772252};\\\", \\\"{x:1543,y:928,t:1527019772268};\\\", \\\"{x:1545,y:918,t:1527019772284};\\\", \\\"{x:1546,y:906,t:1527019772302};\\\", \\\"{x:1546,y:900,t:1527019772317};\\\", \\\"{x:1546,y:892,t:1527019772335};\\\", \\\"{x:1546,y:886,t:1527019772352};\\\", \\\"{x:1546,y:884,t:1527019772370};\\\", \\\"{x:1546,y:883,t:1527019772384};\\\", \\\"{x:1546,y:881,t:1527019772401};\\\", \\\"{x:1546,y:880,t:1527019772422};\\\", \\\"{x:1546,y:879,t:1527019772438};\\\", \\\"{x:1546,y:878,t:1527019772452};\\\", \\\"{x:1546,y:876,t:1527019772470};\\\", \\\"{x:1546,y:875,t:1527019772484};\\\", \\\"{x:1546,y:870,t:1527019772502};\\\", \\\"{x:1546,y:867,t:1527019772518};\\\", \\\"{x:1546,y:863,t:1527019772535};\\\", \\\"{x:1546,y:860,t:1527019772551};\\\", \\\"{x:1546,y:859,t:1527019772569};\\\", \\\"{x:1545,y:857,t:1527019772585};\\\", \\\"{x:1545,y:855,t:1527019772601};\\\", \\\"{x:1545,y:853,t:1527019772618};\\\", \\\"{x:1544,y:850,t:1527019772635};\\\", \\\"{x:1544,y:848,t:1527019772651};\\\", \\\"{x:1544,y:847,t:1527019772668};\\\", \\\"{x:1544,y:845,t:1527019772683};\\\", \\\"{x:1544,y:841,t:1527019772700};\\\", \\\"{x:1544,y:838,t:1527019772717};\\\", \\\"{x:1544,y:836,t:1527019772734};\\\", \\\"{x:1544,y:833,t:1527019772750};\\\", \\\"{x:1544,y:831,t:1527019772767};\\\", \\\"{x:1544,y:830,t:1527019772785};\\\", \\\"{x:1544,y:829,t:1527019772801};\\\", \\\"{x:1544,y:828,t:1527019772818};\\\", \\\"{x:1544,y:825,t:1527019772835};\\\", \\\"{x:1544,y:824,t:1527019772851};\\\", \\\"{x:1544,y:819,t:1527019772868};\\\", \\\"{x:1544,y:815,t:1527019772885};\\\", \\\"{x:1544,y:814,t:1527019772901};\\\", \\\"{x:1544,y:812,t:1527019772919};\\\", \\\"{x:1544,y:810,t:1527019772936};\\\", \\\"{x:1544,y:805,t:1527019772952};\\\", \\\"{x:1544,y:804,t:1527019772969};\\\", \\\"{x:1544,y:796,t:1527019772986};\\\", \\\"{x:1544,y:786,t:1527019773001};\\\", \\\"{x:1546,y:778,t:1527019773018};\\\", \\\"{x:1546,y:774,t:1527019773035};\\\", \\\"{x:1548,y:770,t:1527019773051};\\\", \\\"{x:1548,y:766,t:1527019773068};\\\", \\\"{x:1548,y:758,t:1527019773086};\\\", \\\"{x:1546,y:753,t:1527019773102};\\\", \\\"{x:1545,y:749,t:1527019773118};\\\", \\\"{x:1545,y:745,t:1527019773136};\\\", \\\"{x:1545,y:742,t:1527019773152};\\\", \\\"{x:1543,y:739,t:1527019773169};\\\", \\\"{x:1543,y:736,t:1527019773185};\\\", \\\"{x:1543,y:735,t:1527019773202};\\\", \\\"{x:1542,y:729,t:1527019773219};\\\", \\\"{x:1542,y:724,t:1527019773235};\\\", \\\"{x:1541,y:719,t:1527019773252};\\\", \\\"{x:1541,y:713,t:1527019773269};\\\", \\\"{x:1540,y:705,t:1527019773286};\\\", \\\"{x:1540,y:704,t:1527019773302};\\\", \\\"{x:1540,y:703,t:1527019773318};\\\", \\\"{x:1540,y:702,t:1527019773336};\\\", \\\"{x:1540,y:700,t:1527019773352};\\\", \\\"{x:1540,y:699,t:1527019773369};\\\", \\\"{x:1540,y:696,t:1527019773386};\\\", \\\"{x:1540,y:694,t:1527019773403};\\\", \\\"{x:1540,y:689,t:1527019773419};\\\", \\\"{x:1540,y:684,t:1527019773436};\\\", \\\"{x:1540,y:679,t:1527019773452};\\\", \\\"{x:1540,y:674,t:1527019773468};\\\", \\\"{x:1540,y:662,t:1527019773486};\\\", \\\"{x:1540,y:657,t:1527019773502};\\\", \\\"{x:1540,y:653,t:1527019773519};\\\", \\\"{x:1540,y:650,t:1527019773536};\\\", \\\"{x:1539,y:647,t:1527019773552};\\\", \\\"{x:1539,y:646,t:1527019773582};\\\", \\\"{x:1539,y:645,t:1527019773589};\\\", \\\"{x:1539,y:644,t:1527019773601};\\\", \\\"{x:1539,y:642,t:1527019773618};\\\", \\\"{x:1539,y:640,t:1527019773635};\\\", \\\"{x:1539,y:639,t:1527019773676};\\\", \\\"{x:1539,y:638,t:1527019773693};\\\", \\\"{x:1539,y:637,t:1527019773702};\\\", \\\"{x:1539,y:636,t:1527019773724};\\\", \\\"{x:1539,y:635,t:1527019773734};\\\", \\\"{x:1539,y:632,t:1527019773752};\\\", \\\"{x:1539,y:631,t:1527019773773};\\\", \\\"{x:1539,y:629,t:1527019773789};\\\", \\\"{x:1539,y:628,t:1527019773805};\\\", \\\"{x:1538,y:627,t:1527019773819};\\\", \\\"{x:1538,y:626,t:1527019773835};\\\", \\\"{x:1538,y:625,t:1527019773852};\\\", \\\"{x:1536,y:623,t:1527019773870};\\\", \\\"{x:1536,y:621,t:1527019773885};\\\", \\\"{x:1536,y:617,t:1527019773902};\\\", \\\"{x:1535,y:614,t:1527019773919};\\\", \\\"{x:1535,y:611,t:1527019773935};\\\", \\\"{x:1535,y:607,t:1527019773952};\\\", \\\"{x:1535,y:602,t:1527019773970};\\\", \\\"{x:1535,y:600,t:1527019773986};\\\", \\\"{x:1533,y:596,t:1527019774002};\\\", \\\"{x:1533,y:594,t:1527019774019};\\\", \\\"{x:1532,y:590,t:1527019774036};\\\", \\\"{x:1532,y:584,t:1527019774052};\\\", \\\"{x:1532,y:576,t:1527019774069};\\\", \\\"{x:1531,y:572,t:1527019774086};\\\", \\\"{x:1531,y:568,t:1527019774102};\\\", \\\"{x:1530,y:565,t:1527019774119};\\\", \\\"{x:1529,y:565,t:1527019774136};\\\", \\\"{x:1529,y:564,t:1527019774152};\\\", \\\"{x:1529,y:562,t:1527019774169};\\\", \\\"{x:1529,y:559,t:1527019774186};\\\", \\\"{x:1529,y:558,t:1527019774202};\\\", \\\"{x:1529,y:557,t:1527019774222};\\\", \\\"{x:1529,y:558,t:1527019774734};\\\", \\\"{x:1528,y:564,t:1527019774742};\\\", \\\"{x:1528,y:568,t:1527019774753};\\\", \\\"{x:1528,y:571,t:1527019774770};\\\", \\\"{x:1528,y:573,t:1527019774787};\\\", \\\"{x:1528,y:574,t:1527019774870};\\\", \\\"{x:1528,y:580,t:1527019774886};\\\", \\\"{x:1529,y:585,t:1527019774904};\\\", \\\"{x:1529,y:588,t:1527019774920};\\\", \\\"{x:1529,y:589,t:1527019774942};\\\", \\\"{x:1529,y:590,t:1527019774958};\\\", \\\"{x:1529,y:591,t:1527019774971};\\\", \\\"{x:1529,y:593,t:1527019774989};\\\", \\\"{x:1530,y:594,t:1527019775003};\\\", \\\"{x:1530,y:599,t:1527019775021};\\\", \\\"{x:1532,y:605,t:1527019775037};\\\", \\\"{x:1532,y:610,t:1527019775054};\\\", \\\"{x:1532,y:612,t:1527019775070};\\\", \\\"{x:1532,y:613,t:1527019775086};\\\", \\\"{x:1536,y:621,t:1527019777526};\\\", \\\"{x:1541,y:626,t:1527019777539};\\\", \\\"{x:1545,y:634,t:1527019777555};\\\", \\\"{x:1551,y:647,t:1527019777572};\\\", \\\"{x:1558,y:662,t:1527019777589};\\\", \\\"{x:1564,y:680,t:1527019777606};\\\", \\\"{x:1569,y:690,t:1527019777622};\\\", \\\"{x:1576,y:700,t:1527019777639};\\\", \\\"{x:1581,y:710,t:1527019777656};\\\", \\\"{x:1585,y:723,t:1527019777673};\\\", \\\"{x:1587,y:734,t:1527019777688};\\\", \\\"{x:1591,y:751,t:1527019777705};\\\", \\\"{x:1597,y:771,t:1527019777722};\\\", \\\"{x:1602,y:788,t:1527019777738};\\\", \\\"{x:1608,y:806,t:1527019777755};\\\", \\\"{x:1609,y:816,t:1527019777772};\\\", \\\"{x:1609,y:824,t:1527019777788};\\\", \\\"{x:1611,y:833,t:1527019777804};\\\", \\\"{x:1612,y:843,t:1527019777822};\\\", \\\"{x:1612,y:854,t:1527019777838};\\\", \\\"{x:1611,y:868,t:1527019777855};\\\", \\\"{x:1610,y:882,t:1527019777872};\\\", \\\"{x:1608,y:892,t:1527019777888};\\\", \\\"{x:1607,y:895,t:1527019777905};\\\", \\\"{x:1607,y:898,t:1527019777922};\\\", \\\"{x:1606,y:902,t:1527019777938};\\\", \\\"{x:1605,y:904,t:1527019777955};\\\", \\\"{x:1604,y:905,t:1527019777973};\\\", \\\"{x:1603,y:908,t:1527019777989};\\\", \\\"{x:1601,y:912,t:1527019778005};\\\", \\\"{x:1599,y:915,t:1527019778022};\\\", \\\"{x:1596,y:919,t:1527019778039};\\\", \\\"{x:1592,y:923,t:1527019778056};\\\", \\\"{x:1589,y:925,t:1527019778072};\\\", \\\"{x:1586,y:927,t:1527019778089};\\\", \\\"{x:1585,y:928,t:1527019778106};\\\", \\\"{x:1578,y:932,t:1527019778122};\\\", \\\"{x:1574,y:935,t:1527019778139};\\\", \\\"{x:1572,y:937,t:1527019778155};\\\", \\\"{x:1571,y:937,t:1527019778173};\\\", \\\"{x:1570,y:938,t:1527019778190};\\\", \\\"{x:1569,y:938,t:1527019778237};\\\", \\\"{x:1568,y:938,t:1527019778246};\\\", \\\"{x:1567,y:939,t:1527019778261};\\\", \\\"{x:1565,y:939,t:1527019778309};\\\", \\\"{x:1563,y:940,t:1527019778357};\\\", \\\"{x:1561,y:943,t:1527019778381};\\\", \\\"{x:1560,y:944,t:1527019778389};\\\", \\\"{x:1555,y:945,t:1527019778405};\\\", \\\"{x:1552,y:948,t:1527019778422};\\\", \\\"{x:1549,y:951,t:1527019778439};\\\", \\\"{x:1544,y:954,t:1527019778456};\\\", \\\"{x:1541,y:956,t:1527019778472};\\\", \\\"{x:1540,y:956,t:1527019778489};\\\", \\\"{x:1540,y:957,t:1527019778506};\\\", \\\"{x:1539,y:957,t:1527019778798};\\\", \\\"{x:1539,y:955,t:1527019778807};\\\", \\\"{x:1539,y:952,t:1527019778823};\\\", \\\"{x:1541,y:948,t:1527019778839};\\\", \\\"{x:1542,y:948,t:1527019778857};\\\", \\\"{x:1543,y:946,t:1527019778872};\\\", \\\"{x:1543,y:944,t:1527019778902};\\\", \\\"{x:1544,y:942,t:1527019779102};\\\", \\\"{x:1544,y:939,t:1527019779118};\\\", \\\"{x:1546,y:937,t:1527019779125};\\\", \\\"{x:1546,y:936,t:1527019779140};\\\", \\\"{x:1546,y:932,t:1527019779157};\\\", \\\"{x:1546,y:925,t:1527019779174};\\\", \\\"{x:1546,y:919,t:1527019779190};\\\", \\\"{x:1546,y:913,t:1527019779206};\\\", \\\"{x:1546,y:905,t:1527019779224};\\\", \\\"{x:1546,y:895,t:1527019779239};\\\", \\\"{x:1546,y:885,t:1527019779257};\\\", \\\"{x:1546,y:879,t:1527019779274};\\\", \\\"{x:1546,y:870,t:1527019779290};\\\", \\\"{x:1546,y:862,t:1527019779307};\\\", \\\"{x:1546,y:847,t:1527019779323};\\\", \\\"{x:1546,y:832,t:1527019779340};\\\", \\\"{x:1546,y:818,t:1527019779358};\\\", \\\"{x:1546,y:811,t:1527019779373};\\\", \\\"{x:1546,y:805,t:1527019779391};\\\", \\\"{x:1546,y:797,t:1527019779407};\\\", \\\"{x:1546,y:787,t:1527019779423};\\\", \\\"{x:1546,y:778,t:1527019779440};\\\", \\\"{x:1546,y:771,t:1527019779456};\\\", \\\"{x:1547,y:763,t:1527019779474};\\\", \\\"{x:1548,y:753,t:1527019779491};\\\", \\\"{x:1548,y:748,t:1527019779506};\\\", \\\"{x:1550,y:739,t:1527019779524};\\\", \\\"{x:1550,y:731,t:1527019779540};\\\", \\\"{x:1550,y:728,t:1527019779557};\\\", \\\"{x:1550,y:722,t:1527019779574};\\\", \\\"{x:1550,y:717,t:1527019779590};\\\", \\\"{x:1550,y:712,t:1527019779607};\\\", \\\"{x:1550,y:708,t:1527019779623};\\\", \\\"{x:1550,y:704,t:1527019779641};\\\", \\\"{x:1550,y:701,t:1527019779657};\\\", \\\"{x:1550,y:700,t:1527019779694};\\\", \\\"{x:1550,y:698,t:1527019779707};\\\", \\\"{x:1550,y:694,t:1527019779724};\\\", \\\"{x:1550,y:692,t:1527019779741};\\\", \\\"{x:1550,y:691,t:1527019779757};\\\", \\\"{x:1551,y:688,t:1527019779774};\\\", \\\"{x:1551,y:687,t:1527019779790};\\\", \\\"{x:1551,y:684,t:1527019779807};\\\", \\\"{x:1551,y:681,t:1527019779824};\\\", \\\"{x:1551,y:677,t:1527019779841};\\\", \\\"{x:1552,y:675,t:1527019779858};\\\", \\\"{x:1553,y:673,t:1527019779874};\\\", \\\"{x:1554,y:671,t:1527019779890};\\\", \\\"{x:1554,y:667,t:1527019779907};\\\", \\\"{x:1555,y:664,t:1527019779923};\\\", \\\"{x:1555,y:658,t:1527019779940};\\\", \\\"{x:1555,y:651,t:1527019779956};\\\", \\\"{x:1555,y:642,t:1527019779973};\\\", \\\"{x:1555,y:637,t:1527019779990};\\\", \\\"{x:1555,y:636,t:1527019780012};\\\", \\\"{x:1555,y:635,t:1527019780070};\\\", \\\"{x:1554,y:635,t:1527019780317};\\\", \\\"{x:1552,y:635,t:1527019780324};\\\", \\\"{x:1549,y:635,t:1527019780340};\\\", \\\"{x:1542,y:634,t:1527019780356};\\\", \\\"{x:1536,y:633,t:1527019780374};\\\", \\\"{x:1530,y:633,t:1527019780390};\\\", \\\"{x:1524,y:633,t:1527019780407};\\\", \\\"{x:1519,y:633,t:1527019780424};\\\", \\\"{x:1519,y:634,t:1527019780441};\\\", \\\"{x:1513,y:634,t:1527019794534};\\\", \\\"{x:1486,y:644,t:1527019794554};\\\", \\\"{x:1442,y:651,t:1527019794569};\\\", \\\"{x:1383,y:651,t:1527019794585};\\\", \\\"{x:1300,y:651,t:1527019794602};\\\", \\\"{x:1220,y:651,t:1527019794619};\\\", \\\"{x:1152,y:650,t:1527019794635};\\\", \\\"{x:1096,y:650,t:1527019794651};\\\", \\\"{x:1050,y:649,t:1527019794668};\\\", \\\"{x:1027,y:647,t:1527019794684};\\\", \\\"{x:1011,y:647,t:1527019794702};\\\", \\\"{x:994,y:644,t:1527019794719};\\\", \\\"{x:974,y:640,t:1527019794735};\\\", \\\"{x:952,y:637,t:1527019794752};\\\", \\\"{x:926,y:633,t:1527019794768};\\\", \\\"{x:897,y:628,t:1527019794785};\\\", \\\"{x:875,y:626,t:1527019794802};\\\", \\\"{x:853,y:626,t:1527019794819};\\\", \\\"{x:830,y:626,t:1527019794836};\\\", \\\"{x:803,y:626,t:1527019794853};\\\", \\\"{x:794,y:626,t:1527019794870};\\\", \\\"{x:780,y:629,t:1527019794887};\\\", \\\"{x:768,y:632,t:1527019794904};\\\", \\\"{x:754,y:635,t:1527019794919};\\\", \\\"{x:745,y:637,t:1527019794937};\\\", \\\"{x:736,y:639,t:1527019794954};\\\", \\\"{x:722,y:642,t:1527019794970};\\\", \\\"{x:701,y:647,t:1527019794986};\\\", \\\"{x:682,y:648,t:1527019795007};\\\", \\\"{x:653,y:650,t:1527019795024};\\\", \\\"{x:623,y:647,t:1527019795040};\\\", \\\"{x:580,y:632,t:1527019795058};\\\", \\\"{x:521,y:616,t:1527019795075};\\\", \\\"{x:478,y:601,t:1527019795090};\\\", \\\"{x:415,y:584,t:1527019795108};\\\", \\\"{x:398,y:570,t:1527019795124};\\\", \\\"{x:363,y:560,t:1527019795141};\\\", \\\"{x:342,y:554,t:1527019795158};\\\", \\\"{x:336,y:553,t:1527019795174};\\\", \\\"{x:335,y:553,t:1527019795289};\\\", \\\"{x:336,y:553,t:1527019795296};\\\", \\\"{x:337,y:556,t:1527019795308};\\\", \\\"{x:344,y:567,t:1527019795325};\\\", \\\"{x:350,y:583,t:1527019795341};\\\", \\\"{x:360,y:603,t:1527019795357};\\\", \\\"{x:368,y:626,t:1527019795374};\\\", \\\"{x:378,y:650,t:1527019795391};\\\", \\\"{x:389,y:665,t:1527019795407};\\\", \\\"{x:408,y:679,t:1527019795423};\\\", \\\"{x:417,y:681,t:1527019795440};\\\", \\\"{x:421,y:681,t:1527019795457};\\\", \\\"{x:422,y:681,t:1527019795474};\\\", \\\"{x:424,y:681,t:1527019795503};\\\", \\\"{x:425,y:680,t:1527019795520};\\\", \\\"{x:425,y:678,t:1527019795528};\\\", \\\"{x:425,y:676,t:1527019795541};\\\", \\\"{x:425,y:668,t:1527019795557};\\\", \\\"{x:425,y:661,t:1527019795575};\\\", \\\"{x:424,y:653,t:1527019795591};\\\", \\\"{x:418,y:647,t:1527019795608};\\\", \\\"{x:414,y:636,t:1527019795625};\\\", \\\"{x:411,y:632,t:1527019795642};\\\", \\\"{x:408,y:626,t:1527019795657};\\\", \\\"{x:408,y:624,t:1527019795674};\\\", \\\"{x:407,y:622,t:1527019795692};\\\", \\\"{x:406,y:622,t:1527019795708};\\\", \\\"{x:405,y:622,t:1527019795889};\\\", \\\"{x:404,y:622,t:1527019795903};\\\", \\\"{x:403,y:622,t:1527019795912};\\\", \\\"{x:402,y:622,t:1527019795928};\\\", \\\"{x:401,y:622,t:1527019796032};\\\", \\\"{x:398,y:622,t:1527019796042};\\\", \\\"{x:395,y:623,t:1527019796058};\\\", \\\"{x:397,y:623,t:1527019796385};\\\", \\\"{x:406,y:620,t:1527019796393};\\\", \\\"{x:421,y:609,t:1527019796410};\\\", \\\"{x:446,y:597,t:1527019796424};\\\", \\\"{x:474,y:591,t:1527019796441};\\\", \\\"{x:487,y:591,t:1527019796458};\\\", \\\"{x:488,y:591,t:1527019796475};\\\", \\\"{x:491,y:591,t:1527019796552};\\\", \\\"{x:491,y:590,t:1527019796568};\\\", \\\"{x:493,y:590,t:1527019796576};\\\", \\\"{x:494,y:589,t:1527019796591};\\\", \\\"{x:513,y:581,t:1527019796609};\\\", \\\"{x:528,y:578,t:1527019796625};\\\", \\\"{x:532,y:577,t:1527019796641};\\\", \\\"{x:533,y:577,t:1527019796713};\\\", \\\"{x:535,y:577,t:1527019796724};\\\", \\\"{x:538,y:576,t:1527019796741};\\\", \\\"{x:545,y:572,t:1527019796759};\\\", \\\"{x:559,y:568,t:1527019796775};\\\", \\\"{x:576,y:565,t:1527019796791};\\\", \\\"{x:581,y:565,t:1527019796808};\\\", \\\"{x:582,y:565,t:1527019796849};\\\", \\\"{x:584,y:564,t:1527019796897};\\\", \\\"{x:585,y:563,t:1527019796909};\\\", \\\"{x:586,y:563,t:1527019796924};\\\", \\\"{x:591,y:560,t:1527019796942};\\\", \\\"{x:600,y:559,t:1527019796959};\\\", \\\"{x:623,y:559,t:1527019796975};\\\", \\\"{x:636,y:559,t:1527019796992};\\\", \\\"{x:643,y:560,t:1527019797009};\\\", \\\"{x:644,y:561,t:1527019797024};\\\", \\\"{x:645,y:562,t:1527019797113};\\\", \\\"{x:645,y:563,t:1527019797136};\\\", \\\"{x:645,y:564,t:1527019797145};\\\", \\\"{x:645,y:567,t:1527019797157};\\\", \\\"{x:638,y:569,t:1527019797176};\\\", \\\"{x:633,y:571,t:1527019797191};\\\", \\\"{x:625,y:575,t:1527019797210};\\\", \\\"{x:624,y:576,t:1527019797225};\\\", \\\"{x:622,y:576,t:1527019797616};\\\", \\\"{x:619,y:576,t:1527019797626};\\\", \\\"{x:616,y:576,t:1527019797642};\\\", \\\"{x:609,y:576,t:1527019797659};\\\", \\\"{x:600,y:575,t:1527019797676};\\\", \\\"{x:594,y:574,t:1527019797693};\\\", \\\"{x:587,y:574,t:1527019797709};\\\", \\\"{x:576,y:574,t:1527019797727};\\\", \\\"{x:555,y:575,t:1527019797742};\\\", \\\"{x:537,y:579,t:1527019797759};\\\", \\\"{x:502,y:582,t:1527019797776};\\\", \\\"{x:486,y:581,t:1527019797793};\\\", \\\"{x:481,y:579,t:1527019797810};\\\", \\\"{x:475,y:576,t:1527019797826};\\\", \\\"{x:472,y:574,t:1527019797843};\\\", \\\"{x:468,y:572,t:1527019797859};\\\", \\\"{x:465,y:571,t:1527019797877};\\\", \\\"{x:463,y:571,t:1527019797893};\\\", \\\"{x:462,y:571,t:1527019797909};\\\", \\\"{x:458,y:571,t:1527019797926};\\\", \\\"{x:453,y:571,t:1527019797942};\\\", \\\"{x:444,y:571,t:1527019797960};\\\", \\\"{x:431,y:573,t:1527019797976};\\\", \\\"{x:425,y:574,t:1527019797994};\\\", \\\"{x:422,y:574,t:1527019798009};\\\", \\\"{x:418,y:577,t:1527019798027};\\\", \\\"{x:414,y:577,t:1527019798044};\\\", \\\"{x:408,y:577,t:1527019798060};\\\", \\\"{x:402,y:577,t:1527019798077};\\\", \\\"{x:393,y:577,t:1527019798094};\\\", \\\"{x:386,y:577,t:1527019798109};\\\", \\\"{x:382,y:576,t:1527019798126};\\\", \\\"{x:379,y:576,t:1527019798143};\\\", \\\"{x:378,y:578,t:1527019798568};\\\", \\\"{x:378,y:585,t:1527019798576};\\\", \\\"{x:377,y:594,t:1527019798594};\\\", \\\"{x:377,y:601,t:1527019798611};\\\", \\\"{x:377,y:603,t:1527019798627};\\\", \\\"{x:377,y:604,t:1527019798644};\\\", \\\"{x:377,y:605,t:1527019798660};\\\", \\\"{x:377,y:608,t:1527019798676};\\\", \\\"{x:378,y:608,t:1527019798694};\\\", \\\"{x:379,y:611,t:1527019798710};\\\", \\\"{x:380,y:613,t:1527019798729};\\\", \\\"{x:384,y:614,t:1527019799128};\\\", \\\"{x:401,y:609,t:1527019799144};\\\", \\\"{x:516,y:571,t:1527019799161};\\\", \\\"{x:636,y:548,t:1527019799178};\\\", \\\"{x:762,y:527,t:1527019799196};\\\", \\\"{x:888,y:500,t:1527019799211};\\\", \\\"{x:1015,y:464,t:1527019799227};\\\", \\\"{x:1145,y:423,t:1527019799244};\\\", \\\"{x:1281,y:378,t:1527019799261};\\\", \\\"{x:1429,y:325,t:1527019799277};\\\", \\\"{x:1569,y:265,t:1527019799295};\\\", \\\"{x:1701,y:214,t:1527019799310};\\\", \\\"{x:1824,y:174,t:1527019799328};\\\", \\\"{x:1919,y:126,t:1527019799344};\\\", \\\"{x:1919,y:98,t:1527019799361};\\\", \\\"{x:1919,y:84,t:1527019799378};\\\", \\\"{x:1919,y:79,t:1527019799394};\\\", \\\"{x:1919,y:77,t:1527019799410};\\\", \\\"{x:1919,y:79,t:1527019799537};\\\", \\\"{x:1919,y:83,t:1527019799545};\\\", \\\"{x:1919,y:91,t:1527019799561};\\\", \\\"{x:1916,y:100,t:1527019799577};\\\", \\\"{x:1909,y:110,t:1527019799594};\\\", \\\"{x:1896,y:122,t:1527019799611};\\\", \\\"{x:1885,y:126,t:1527019799627};\\\", \\\"{x:1884,y:130,t:1527019799645};\\\", \\\"{x:1878,y:127,t:1527019800031};\\\", \\\"{x:1876,y:126,t:1527019800044};\\\", \\\"{x:1866,y:117,t:1527019800062};\\\", \\\"{x:1851,y:113,t:1527019800078};\\\", \\\"{x:1837,y:110,t:1527019800094};\\\", \\\"{x:1823,y:110,t:1527019800111};\\\", \\\"{x:1815,y:120,t:1527019800128};\\\", \\\"{x:1799,y:132,t:1527019800145};\\\", \\\"{x:1787,y:143,t:1527019800162};\\\", \\\"{x:1782,y:155,t:1527019800178};\\\", \\\"{x:1786,y:169,t:1527019800195};\\\", \\\"{x:1792,y:175,t:1527019800212};\\\", \\\"{x:1795,y:184,t:1527019800229};\\\", \\\"{x:1793,y:184,t:1527019800521};\\\", \\\"{x:1784,y:186,t:1527019800529};\\\", \\\"{x:1769,y:194,t:1527019800546};\\\", \\\"{x:1753,y:202,t:1527019800563};\\\", \\\"{x:1733,y:217,t:1527019800579};\\\", \\\"{x:1714,y:231,t:1527019800596};\\\", \\\"{x:1701,y:244,t:1527019800613};\\\", \\\"{x:1682,y:262,t:1527019800629};\\\", \\\"{x:1667,y:279,t:1527019800646};\\\", \\\"{x:1652,y:301,t:1527019800663};\\\", \\\"{x:1632,y:320,t:1527019800679};\\\", \\\"{x:1602,y:357,t:1527019800696};\\\", \\\"{x:1548,y:419,t:1527019800713};\\\", \\\"{x:1524,y:446,t:1527019800729};\\\", \\\"{x:1510,y:465,t:1527019800746};\\\", \\\"{x:1502,y:477,t:1527019800763};\\\", \\\"{x:1492,y:494,t:1527019800779};\\\", \\\"{x:1487,y:509,t:1527019800796};\\\", \\\"{x:1483,y:528,t:1527019800813};\\\", \\\"{x:1481,y:546,t:1527019800829};\\\", \\\"{x:1481,y:565,t:1527019800845};\\\", \\\"{x:1482,y:588,t:1527019800862};\\\", \\\"{x:1488,y:612,t:1527019800880};\\\", \\\"{x:1488,y:631,t:1527019800895};\\\", \\\"{x:1488,y:654,t:1527019800912};\\\", \\\"{x:1489,y:663,t:1527019800929};\\\", \\\"{x:1489,y:665,t:1527019800945};\\\", \\\"{x:1487,y:661,t:1527019801057};\\\", \\\"{x:1485,y:658,t:1527019801065};\\\", \\\"{x:1484,y:652,t:1527019801080};\\\", \\\"{x:1484,y:637,t:1527019801096};\\\", \\\"{x:1486,y:621,t:1527019801113};\\\", \\\"{x:1487,y:619,t:1527019801130};\\\", \\\"{x:1488,y:616,t:1527019801146};\\\", \\\"{x:1488,y:612,t:1527019801163};\\\", \\\"{x:1488,y:609,t:1527019801180};\\\", \\\"{x:1490,y:603,t:1527019801197};\\\", \\\"{x:1492,y:597,t:1527019801213};\\\", \\\"{x:1493,y:594,t:1527019801230};\\\", \\\"{x:1494,y:593,t:1527019801247};\\\", \\\"{x:1494,y:591,t:1527019801263};\\\", \\\"{x:1495,y:590,t:1527019801281};\\\", \\\"{x:1496,y:591,t:1527019801498};\\\", \\\"{x:1500,y:597,t:1527019801515};\\\", \\\"{x:1507,y:605,t:1527019801530};\\\", \\\"{x:1516,y:615,t:1527019801546};\\\", \\\"{x:1526,y:625,t:1527019801564};\\\", \\\"{x:1535,y:632,t:1527019801579};\\\", \\\"{x:1539,y:634,t:1527019801596};\\\", \\\"{x:1543,y:635,t:1527019801613};\\\", \\\"{x:1547,y:635,t:1527019801630};\\\", \\\"{x:1550,y:632,t:1527019801646};\\\", \\\"{x:1552,y:632,t:1527019801889};\\\", \\\"{x:1554,y:632,t:1527019801897};\\\", \\\"{x:1556,y:625,t:1527019801914};\\\", \\\"{x:1556,y:622,t:1527019801931};\\\", \\\"{x:1558,y:613,t:1527019801947};\\\", \\\"{x:1558,y:609,t:1527019801964};\\\", \\\"{x:1558,y:606,t:1527019801981};\\\", \\\"{x:1559,y:603,t:1527019801997};\\\", \\\"{x:1559,y:602,t:1527019802015};\\\", \\\"{x:1559,y:600,t:1527019802032};\\\", \\\"{x:1558,y:598,t:1527019802047};\\\", \\\"{x:1555,y:595,t:1527019802064};\\\", \\\"{x:1549,y:591,t:1527019802080};\\\", \\\"{x:1546,y:588,t:1527019802097};\\\", \\\"{x:1543,y:587,t:1527019802114};\\\", \\\"{x:1534,y:584,t:1527019802132};\\\", \\\"{x:1527,y:582,t:1527019802148};\\\", \\\"{x:1510,y:577,t:1527019802164};\\\", \\\"{x:1500,y:571,t:1527019802181};\\\", \\\"{x:1494,y:569,t:1527019802197};\\\", \\\"{x:1489,y:568,t:1527019802213};\\\", \\\"{x:1485,y:567,t:1527019802231};\\\", \\\"{x:1478,y:567,t:1527019802247};\\\", \\\"{x:1474,y:567,t:1527019802264};\\\", \\\"{x:1471,y:567,t:1527019802280};\\\", \\\"{x:1469,y:567,t:1527019802297};\\\", \\\"{x:1465,y:567,t:1527019802314};\\\", \\\"{x:1459,y:567,t:1527019802331};\\\", \\\"{x:1450,y:571,t:1527019802347};\\\", \\\"{x:1447,y:573,t:1527019802364};\\\", \\\"{x:1445,y:573,t:1527019802380};\\\", \\\"{x:1443,y:573,t:1527019802397};\\\", \\\"{x:1440,y:573,t:1527019802414};\\\", \\\"{x:1434,y:573,t:1527019802431};\\\", \\\"{x:1425,y:572,t:1527019802447};\\\", \\\"{x:1423,y:569,t:1527019802464};\\\", \\\"{x:1418,y:569,t:1527019802929};\\\", \\\"{x:1413,y:576,t:1527019802936};\\\", \\\"{x:1407,y:585,t:1527019802948};\\\", \\\"{x:1395,y:606,t:1527019802965};\\\", \\\"{x:1385,y:630,t:1527019802982};\\\", \\\"{x:1374,y:658,t:1527019802999};\\\", \\\"{x:1362,y:685,t:1527019803015};\\\", \\\"{x:1356,y:709,t:1527019803032};\\\", \\\"{x:1347,y:733,t:1527019803048};\\\", \\\"{x:1346,y:762,t:1527019803065};\\\", \\\"{x:1346,y:777,t:1527019803082};\\\", \\\"{x:1346,y:781,t:1527019803099};\\\", \\\"{x:1346,y:782,t:1527019803116};\\\", \\\"{x:1346,y:779,t:1527019803305};\\\", \\\"{x:1346,y:777,t:1527019803315};\\\", \\\"{x:1352,y:765,t:1527019803332};\\\", \\\"{x:1361,y:751,t:1527019803349};\\\", \\\"{x:1369,y:731,t:1527019803366};\\\", \\\"{x:1379,y:710,t:1527019803382};\\\", \\\"{x:1391,y:686,t:1527019803400};\\\", \\\"{x:1403,y:662,t:1527019803416};\\\", \\\"{x:1416,y:630,t:1527019803432};\\\", \\\"{x:1444,y:550,t:1527019803449};\\\", \\\"{x:1458,y:502,t:1527019803466};\\\", \\\"{x:1472,y:455,t:1527019803482};\\\", \\\"{x:1480,y:432,t:1527019803500};\\\", \\\"{x:1483,y:415,t:1527019803516};\\\", \\\"{x:1485,y:399,t:1527019803532};\\\", \\\"{x:1485,y:385,t:1527019803549};\\\", \\\"{x:1486,y:367,t:1527019803566};\\\", \\\"{x:1487,y:346,t:1527019803582};\\\", \\\"{x:1487,y:333,t:1527019803599};\\\", \\\"{x:1488,y:324,t:1527019803616};\\\", \\\"{x:1488,y:317,t:1527019803632};\\\", \\\"{x:1488,y:312,t:1527019803650};\\\", \\\"{x:1488,y:311,t:1527019803667};\\\", \\\"{x:1488,y:316,t:1527019803761};\\\", \\\"{x:1488,y:326,t:1527019803769};\\\", \\\"{x:1485,y:338,t:1527019803783};\\\", \\\"{x:1472,y:364,t:1527019803799};\\\", \\\"{x:1467,y:380,t:1527019803816};\\\", \\\"{x:1461,y:398,t:1527019803833};\\\", \\\"{x:1459,y:402,t:1527019803849};\\\", \\\"{x:1459,y:403,t:1527019803866};\\\", \\\"{x:1459,y:404,t:1527019803888};\\\", \\\"{x:1459,y:405,t:1527019803912};\\\", \\\"{x:1459,y:408,t:1527019803936};\\\", \\\"{x:1459,y:409,t:1527019803949};\\\", \\\"{x:1459,y:413,t:1527019803967};\\\", \\\"{x:1459,y:415,t:1527019803983};\\\", \\\"{x:1457,y:416,t:1527019804000};\\\", \\\"{x:1457,y:418,t:1527019804016};\\\", \\\"{x:1456,y:420,t:1527019804033};\\\", \\\"{x:1454,y:421,t:1527019804050};\\\", \\\"{x:1452,y:422,t:1527019804066};\\\", \\\"{x:1451,y:422,t:1527019804089};\\\", \\\"{x:1449,y:422,t:1527019804105};\\\", \\\"{x:1446,y:422,t:1527019804116};\\\", \\\"{x:1443,y:422,t:1527019804134};\\\", \\\"{x:1439,y:422,t:1527019804151};\\\", \\\"{x:1437,y:422,t:1527019804166};\\\", \\\"{x:1434,y:423,t:1527019804184};\\\", \\\"{x:1434,y:424,t:1527019804201};\\\", \\\"{x:1434,y:425,t:1527019804216};\\\", \\\"{x:1432,y:426,t:1527019804241};\\\", \\\"{x:1430,y:427,t:1527019804265};\\\", \\\"{x:1429,y:428,t:1527019804272};\\\", \\\"{x:1428,y:428,t:1527019804283};\\\", \\\"{x:1426,y:430,t:1527019804300};\\\", \\\"{x:1423,y:433,t:1527019804318};\\\", \\\"{x:1418,y:439,t:1527019804333};\\\", \\\"{x:1412,y:443,t:1527019804350};\\\", \\\"{x:1404,y:446,t:1527019804367};\\\", \\\"{x:1401,y:449,t:1527019804384};\\\", \\\"{x:1398,y:452,t:1527019804401};\\\", \\\"{x:1397,y:453,t:1527019804473};\\\", \\\"{x:1392,y:459,t:1527019805409};\\\", \\\"{x:1378,y:479,t:1527019805418};\\\", \\\"{x:1349,y:509,t:1527019805435};\\\", \\\"{x:1315,y:531,t:1527019805451};\\\", \\\"{x:1299,y:540,t:1527019805468};\\\", \\\"{x:1287,y:548,t:1527019805484};\\\", \\\"{x:1269,y:553,t:1527019805502};\\\", \\\"{x:1252,y:556,t:1527019805519};\\\", \\\"{x:1243,y:558,t:1527019805534};\\\", \\\"{x:1234,y:558,t:1527019805551};\\\", \\\"{x:1201,y:555,t:1527019805568};\\\", \\\"{x:1172,y:547,t:1527019805584};\\\", \\\"{x:1148,y:541,t:1527019805601};\\\", \\\"{x:1108,y:527,t:1527019805619};\\\", \\\"{x:1035,y:517,t:1527019805635};\\\", \\\"{x:944,y:517,t:1527019805651};\\\", \\\"{x:836,y:517,t:1527019805668};\\\", \\\"{x:703,y:500,t:1527019805685};\\\", \\\"{x:660,y:493,t:1527019805701};\\\", \\\"{x:660,y:492,t:1527019805720};\\\", \\\"{x:660,y:496,t:1527019805833};\\\", \\\"{x:660,y:501,t:1527019805840};\\\", \\\"{x:660,y:507,t:1527019805851};\\\", \\\"{x:660,y:515,t:1527019805868};\\\", \\\"{x:658,y:521,t:1527019805886};\\\", \\\"{x:657,y:528,t:1527019805902};\\\", \\\"{x:654,y:532,t:1527019805917};\\\", \\\"{x:653,y:537,t:1527019805932};\\\", \\\"{x:652,y:543,t:1527019805948};\\\", \\\"{x:649,y:553,t:1527019805966};\\\", \\\"{x:648,y:557,t:1527019805982};\\\", \\\"{x:646,y:566,t:1527019806000};\\\", \\\"{x:645,y:572,t:1527019806015};\\\", \\\"{x:642,y:578,t:1527019806032};\\\", \\\"{x:639,y:587,t:1527019806049};\\\", \\\"{x:626,y:603,t:1527019806067};\\\", \\\"{x:598,y:622,t:1527019806083};\\\", \\\"{x:583,y:635,t:1527019806100};\\\", \\\"{x:573,y:649,t:1527019806116};\\\", \\\"{x:574,y:649,t:1527019806184};\\\", \\\"{x:579,y:647,t:1527019806200};\\\", \\\"{x:608,y:614,t:1527019806217};\\\", \\\"{x:667,y:569,t:1527019806233};\\\", \\\"{x:722,y:523,t:1527019806250};\\\", \\\"{x:783,y:482,t:1527019806267};\\\", \\\"{x:809,y:462,t:1527019806283};\\\", \\\"{x:826,y:455,t:1527019806300};\\\", \\\"{x:841,y:445,t:1527019806317};\\\", \\\"{x:852,y:439,t:1527019806333};\\\", \\\"{x:860,y:433,t:1527019806350};\\\", \\\"{x:862,y:431,t:1527019806367};\\\", \\\"{x:863,y:431,t:1527019806433};\\\", \\\"{x:865,y:443,t:1527019806450};\\\", \\\"{x:866,y:449,t:1527019806467};\\\", \\\"{x:866,y:460,t:1527019806483};\\\", \\\"{x:864,y:478,t:1527019806500};\\\", \\\"{x:864,y:491,t:1527019806516};\\\", \\\"{x:863,y:496,t:1527019806533};\\\", \\\"{x:862,y:501,t:1527019806550};\\\", \\\"{x:862,y:503,t:1527019806566};\\\", \\\"{x:862,y:506,t:1527019806583};\\\", \\\"{x:859,y:510,t:1527019806600};\\\", \\\"{x:859,y:512,t:1527019806616};\\\", \\\"{x:859,y:514,t:1527019806633};\\\", \\\"{x:859,y:522,t:1527019806651};\\\", \\\"{x:857,y:527,t:1527019806666};\\\", \\\"{x:852,y:541,t:1527019806684};\\\", \\\"{x:843,y:553,t:1527019806699};\\\", \\\"{x:834,y:563,t:1527019806717};\\\", \\\"{x:829,y:569,t:1527019806734};\\\", \\\"{x:828,y:573,t:1527019806750};\\\", \\\"{x:826,y:576,t:1527019806767};\\\", \\\"{x:822,y:584,t:1527019806783};\\\", \\\"{x:817,y:592,t:1527019806801};\\\", \\\"{x:813,y:601,t:1527019806817};\\\", \\\"{x:810,y:607,t:1527019806834};\\\", \\\"{x:809,y:612,t:1527019806850};\\\", \\\"{x:808,y:612,t:1527019806866};\\\", \\\"{x:806,y:615,t:1527019806976};\\\", \\\"{x:805,y:615,t:1527019806992};\\\", \\\"{x:802,y:615,t:1527019807001};\\\", \\\"{x:797,y:614,t:1527019807017};\\\", \\\"{x:792,y:612,t:1527019807034};\\\", \\\"{x:790,y:611,t:1527019807050};\\\", \\\"{x:789,y:610,t:1527019807088};\\\", \\\"{x:789,y:609,t:1527019807100};\\\", \\\"{x:789,y:604,t:1527019807117};\\\", \\\"{x:789,y:600,t:1527019807134};\\\", \\\"{x:789,y:594,t:1527019807151};\\\", \\\"{x:791,y:588,t:1527019807168};\\\", \\\"{x:791,y:582,t:1527019807183};\\\", \\\"{x:792,y:580,t:1527019807200};\\\", \\\"{x:793,y:577,t:1527019807217};\\\", \\\"{x:793,y:576,t:1527019807234};\\\", \\\"{x:795,y:573,t:1527019807251};\\\", \\\"{x:796,y:571,t:1527019807267};\\\", \\\"{x:799,y:568,t:1527019807283};\\\", \\\"{x:800,y:567,t:1527019807304};\\\", \\\"{x:801,y:567,t:1527019807449};\\\", \\\"{x:802,y:567,t:1527019807497};\\\", \\\"{x:803,y:566,t:1527019807569};\\\", \\\"{x:810,y:557,t:1527019807585};\\\", \\\"{x:814,y:555,t:1527019807601};\\\", \\\"{x:815,y:555,t:1527019807833};\\\", \\\"{x:816,y:556,t:1527019807841};\\\", \\\"{x:818,y:558,t:1527019807851};\\\", \\\"{x:820,y:563,t:1527019807866};\\\", \\\"{x:824,y:569,t:1527019807883};\\\", \\\"{x:826,y:571,t:1527019807901};\\\", \\\"{x:826,y:572,t:1527019807917};\\\", \\\"{x:827,y:572,t:1527019807935};\\\", \\\"{x:828,y:573,t:1527019808048};\\\", \\\"{x:829,y:573,t:1527019808176};\\\", \\\"{x:829,y:573,t:1527019808293};\\\", \\\"{x:828,y:575,t:1527019808448};\\\", \\\"{x:822,y:579,t:1527019808456};\\\", \\\"{x:819,y:579,t:1527019808467};\\\", \\\"{x:808,y:587,t:1527019808485};\\\", \\\"{x:804,y:592,t:1527019808503};\\\", \\\"{x:795,y:598,t:1527019808518};\\\", \\\"{x:785,y:603,t:1527019808534};\\\", \\\"{x:783,y:603,t:1527019808551};\\\", \\\"{x:782,y:606,t:1527019808575};\\\", \\\"{x:780,y:608,t:1527019808585};\\\", \\\"{x:776,y:619,t:1527019808601};\\\", \\\"{x:771,y:626,t:1527019808618};\\\", \\\"{x:765,y:635,t:1527019808635};\\\", \\\"{x:758,y:643,t:1527019808652};\\\", \\\"{x:750,y:648,t:1527019808669};\\\", \\\"{x:742,y:653,t:1527019808684};\\\", \\\"{x:736,y:657,t:1527019808701};\\\", \\\"{x:734,y:657,t:1527019808718};\\\", \\\"{x:724,y:657,t:1527019808735};\\\", \\\"{x:708,y:657,t:1527019808751};\\\", \\\"{x:698,y:657,t:1527019808769};\\\", \\\"{x:684,y:657,t:1527019808785};\\\", \\\"{x:675,y:657,t:1527019808801};\\\", \\\"{x:660,y:657,t:1527019808819};\\\", \\\"{x:649,y:657,t:1527019808835};\\\", \\\"{x:644,y:657,t:1527019808851};\\\", \\\"{x:640,y:657,t:1527019808869};\\\", \\\"{x:637,y:657,t:1527019808885};\\\", \\\"{x:635,y:657,t:1527019808902};\\\", \\\"{x:632,y:657,t:1527019808919};\\\", \\\"{x:630,y:657,t:1527019808934};\\\", \\\"{x:630,y:656,t:1527019809089};\\\", \\\"{x:637,y:647,t:1527019809102};\\\", \\\"{x:666,y:624,t:1527019809121};\\\", \\\"{x:684,y:606,t:1527019809135};\\\", \\\"{x:687,y:603,t:1527019809151};\\\", \\\"{x:687,y:601,t:1527019809264};\\\", \\\"{x:687,y:599,t:1527019809272};\\\", \\\"{x:687,y:597,t:1527019809286};\\\", \\\"{x:688,y:595,t:1527019809303};\\\", \\\"{x:688,y:594,t:1527019809319};\\\", \\\"{x:687,y:593,t:1527019809393};\\\", \\\"{x:684,y:593,t:1527019809402};\\\", \\\"{x:667,y:593,t:1527019809419};\\\", \\\"{x:664,y:594,t:1527019809436};\\\", \\\"{x:664,y:595,t:1527019809456};\\\", \\\"{x:664,y:596,t:1527019809470};\\\", \\\"{x:659,y:596,t:1527019810057};\\\", \\\"{x:650,y:596,t:1527019810070};\\\", \\\"{x:621,y:597,t:1527019810086};\\\", \\\"{x:606,y:597,t:1527019810103};\\\", \\\"{x:599,y:597,t:1527019810120};\\\", \\\"{x:593,y:596,t:1527019810137};\\\", \\\"{x:584,y:596,t:1527019810153};\\\", \\\"{x:564,y:600,t:1527019810171};\\\", \\\"{x:529,y:612,t:1527019810186};\\\", \\\"{x:487,y:623,t:1527019810205};\\\", \\\"{x:453,y:630,t:1527019810220};\\\", \\\"{x:405,y:632,t:1527019810235};\\\", \\\"{x:355,y:632,t:1527019810253};\\\", \\\"{x:340,y:635,t:1527019810270};\\\", \\\"{x:314,y:637,t:1527019810286};\\\", \\\"{x:300,y:638,t:1527019810303};\\\", \\\"{x:284,y:642,t:1527019810320};\\\", \\\"{x:274,y:645,t:1527019810336};\\\", \\\"{x:269,y:645,t:1527019810354};\\\", \\\"{x:265,y:645,t:1527019810370};\\\", \\\"{x:257,y:645,t:1527019810386};\\\", \\\"{x:246,y:645,t:1527019810402};\\\", \\\"{x:230,y:645,t:1527019810419};\\\", \\\"{x:221,y:645,t:1527019810437};\\\", \\\"{x:217,y:645,t:1527019810452};\\\", \\\"{x:216,y:645,t:1527019810470};\\\", \\\"{x:214,y:645,t:1527019810521};\\\", \\\"{x:213,y:645,t:1527019810544};\\\", \\\"{x:210,y:643,t:1527019810561};\\\", \\\"{x:208,y:641,t:1527019810570};\\\", \\\"{x:205,y:637,t:1527019810587};\\\", \\\"{x:197,y:628,t:1527019810604};\\\", \\\"{x:187,y:619,t:1527019810621};\\\", \\\"{x:183,y:613,t:1527019810636};\\\", \\\"{x:178,y:607,t:1527019810652};\\\", \\\"{x:176,y:605,t:1527019810670};\\\", \\\"{x:173,y:602,t:1527019810686};\\\", \\\"{x:168,y:597,t:1527019810703};\\\", \\\"{x:165,y:595,t:1527019810720};\\\", \\\"{x:164,y:595,t:1527019810737};\\\", \\\"{x:163,y:595,t:1527019810768};\\\", \\\"{x:162,y:595,t:1527019810800};\\\", \\\"{x:161,y:595,t:1527019810929};\\\", \\\"{x:160,y:595,t:1527019810937};\\\", \\\"{x:158,y:595,t:1527019810954};\\\", \\\"{x:157,y:595,t:1527019810971};\\\", \\\"{x:156,y:595,t:1527019811009};\\\", \\\"{x:154,y:595,t:1527019811022};\\\", \\\"{x:152,y:599,t:1527019811039};\\\", \\\"{x:148,y:603,t:1527019811055};\\\", \\\"{x:141,y:609,t:1527019811070};\\\", \\\"{x:137,y:616,t:1527019811087};\\\", \\\"{x:134,y:624,t:1527019811103};\\\", \\\"{x:134,y:632,t:1527019811121};\\\", \\\"{x:135,y:634,t:1527019811138};\\\", \\\"{x:135,y:635,t:1527019811154};\\\", \\\"{x:135,y:636,t:1527019811385};\\\", \\\"{x:135,y:634,t:1527019811392};\\\", \\\"{x:135,y:633,t:1527019811405};\\\", \\\"{x:139,y:621,t:1527019811421};\\\", \\\"{x:142,y:613,t:1527019811436};\\\", \\\"{x:146,y:607,t:1527019811453};\\\", \\\"{x:148,y:603,t:1527019811470};\\\", \\\"{x:148,y:600,t:1527019811487};\\\", \\\"{x:150,y:600,t:1527019812122};\\\", \\\"{x:166,y:611,t:1527019812136};\\\", \\\"{x:191,y:622,t:1527019812155};\\\", \\\"{x:227,y:634,t:1527019812171};\\\", \\\"{x:262,y:640,t:1527019812187};\\\", \\\"{x:285,y:645,t:1527019812205};\\\", \\\"{x:307,y:656,t:1527019812221};\\\", \\\"{x:330,y:664,t:1527019812238};\\\", \\\"{x:344,y:670,t:1527019812255};\\\", \\\"{x:357,y:677,t:1527019812271};\\\", \\\"{x:371,y:684,t:1527019812288};\\\", \\\"{x:379,y:685,t:1527019812305};\\\", \\\"{x:384,y:685,t:1527019812322};\\\", \\\"{x:386,y:685,t:1527019812338};\\\", \\\"{x:389,y:685,t:1527019812355};\\\", \\\"{x:390,y:685,t:1527019812465};\\\", \\\"{x:394,y:684,t:1527019812472};\\\", \\\"{x:404,y:681,t:1527019812489};\\\", \\\"{x:409,y:674,t:1527019812505};\\\", \\\"{x:406,y:665,t:1527019812522};\\\", \\\"{x:394,y:656,t:1527019812539};\\\", \\\"{x:379,y:647,t:1527019812555};\\\", \\\"{x:369,y:637,t:1527019812572};\\\", \\\"{x:353,y:627,t:1527019812588};\\\", \\\"{x:338,y:621,t:1527019812605};\\\", \\\"{x:333,y:617,t:1527019812621};\\\", \\\"{x:324,y:616,t:1527019812637};\\\", \\\"{x:311,y:616,t:1527019812654};\\\", \\\"{x:292,y:620,t:1527019812671};\\\", \\\"{x:287,y:623,t:1527019812688};\\\", \\\"{x:279,y:624,t:1527019812705};\\\", \\\"{x:272,y:627,t:1527019812722};\\\", \\\"{x:269,y:627,t:1527019812738};\\\", \\\"{x:266,y:628,t:1527019812754};\\\", \\\"{x:260,y:631,t:1527019812773};\\\", \\\"{x:256,y:635,t:1527019812788};\\\", \\\"{x:250,y:638,t:1527019812805};\\\", \\\"{x:247,y:639,t:1527019812822};\\\", \\\"{x:240,y:640,t:1527019812839};\\\", \\\"{x:229,y:642,t:1527019812855};\\\", \\\"{x:204,y:647,t:1527019812872};\\\", \\\"{x:178,y:647,t:1527019812889};\\\", \\\"{x:164,y:647,t:1527019812906};\\\", \\\"{x:157,y:646,t:1527019812923};\\\", \\\"{x:153,y:644,t:1527019812939};\\\", \\\"{x:153,y:643,t:1527019812955};\\\", \\\"{x:153,y:642,t:1527019812973};\\\", \\\"{x:154,y:642,t:1527019812989};\\\", \\\"{x:155,y:641,t:1527019813005};\\\", \\\"{x:155,y:640,t:1527019813022};\\\", \\\"{x:155,y:637,t:1527019813040};\\\", \\\"{x:156,y:634,t:1527019813056};\\\", \\\"{x:157,y:632,t:1527019813073};\\\", \\\"{x:157,y:629,t:1527019813089};\\\", \\\"{x:160,y:622,t:1527019813105};\\\", \\\"{x:161,y:619,t:1527019813122};\\\", \\\"{x:161,y:615,t:1527019813139};\\\", \\\"{x:161,y:613,t:1527019813156};\\\", \\\"{x:161,y:612,t:1527019813173};\\\", \\\"{x:161,y:611,t:1527019813257};\\\", \\\"{x:163,y:609,t:1527019813527};\\\", \\\"{x:170,y:604,t:1527019813539};\\\", \\\"{x:194,y:590,t:1527019813557};\\\", \\\"{x:207,y:587,t:1527019813573};\\\", \\\"{x:211,y:587,t:1527019813589};\\\", \\\"{x:240,y:593,t:1527019813607};\\\", \\\"{x:268,y:606,t:1527019813623};\\\", \\\"{x:289,y:619,t:1527019813640};\\\", \\\"{x:323,y:654,t:1527019813657};\\\", \\\"{x:337,y:673,t:1527019813673};\\\", \\\"{x:351,y:685,t:1527019813689};\\\", \\\"{x:368,y:696,t:1527019813706};\\\", \\\"{x:370,y:698,t:1527019813722};\\\", \\\"{x:373,y:702,t:1527019813739};\\\", \\\"{x:376,y:705,t:1527019813756};\\\", \\\"{x:380,y:708,t:1527019813774};\\\", \\\"{x:383,y:713,t:1527019813789};\\\", \\\"{x:386,y:718,t:1527019813807};\\\", \\\"{x:388,y:723,t:1527019813823};\\\", \\\"{x:389,y:725,t:1527019813839};\\\", \\\"{x:390,y:726,t:1527019813857};\\\", \\\"{x:391,y:727,t:1527019813873};\\\", \\\"{x:393,y:729,t:1527019813890};\\\", \\\"{x:394,y:730,t:1527019813907};\\\", \\\"{x:395,y:730,t:1527019813923};\\\", \\\"{x:402,y:728,t:1527019813939};\\\", \\\"{x:417,y:719,t:1527019813957};\\\", \\\"{x:427,y:711,t:1527019813973};\\\", \\\"{x:440,y:702,t:1527019813989};\\\", \\\"{x:459,y:695,t:1527019814006};\\\", \\\"{x:463,y:693,t:1527019814024};\\\", \\\"{x:464,y:692,t:1527019814039};\\\", \\\"{x:465,y:693,t:1527019814232};\\\", \\\"{x:467,y:698,t:1527019814241};\\\", \\\"{x:468,y:702,t:1527019814256};\\\", \\\"{x:471,y:710,t:1527019814273};\\\", \\\"{x:475,y:717,t:1527019814292};\\\", \\\"{x:476,y:718,t:1527019814306};\\\", \\\"{x:476,y:719,t:1527019814322};\\\", \\\"{x:476,y:720,t:1527019814340};\\\", \\\"{x:477,y:721,t:1527019814359};\\\" ] }, { \\\"rt\\\": 10197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 452628, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:722,t:1527019818745};\\\", \\\"{x:483,y:692,t:1527019818762};\\\", \\\"{x:485,y:661,t:1527019818778};\\\", \\\"{x:485,y:637,t:1527019818794};\\\", \\\"{x:485,y:616,t:1527019818810};\\\", \\\"{x:485,y:607,t:1527019818827};\\\", \\\"{x:484,y:600,t:1527019818843};\\\", \\\"{x:483,y:596,t:1527019818860};\\\", \\\"{x:482,y:583,t:1527019818878};\\\", \\\"{x:482,y:579,t:1527019818893};\\\", \\\"{x:482,y:572,t:1527019818910};\\\", \\\"{x:482,y:567,t:1527019818927};\\\", \\\"{x:482,y:561,t:1527019818943};\\\", \\\"{x:483,y:555,t:1527019818960};\\\", \\\"{x:484,y:552,t:1527019818977};\\\", \\\"{x:485,y:548,t:1527019818993};\\\", \\\"{x:485,y:545,t:1527019819010};\\\", \\\"{x:487,y:541,t:1527019819027};\\\", \\\"{x:488,y:535,t:1527019819043};\\\", \\\"{x:492,y:524,t:1527019819062};\\\", \\\"{x:495,y:516,t:1527019819078};\\\", \\\"{x:499,y:505,t:1527019819095};\\\", \\\"{x:501,y:501,t:1527019819110};\\\", \\\"{x:504,y:494,t:1527019819127};\\\", \\\"{x:506,y:490,t:1527019819143};\\\", \\\"{x:506,y:487,t:1527019819161};\\\", \\\"{x:509,y:484,t:1527019819179};\\\", \\\"{x:510,y:483,t:1527019819194};\\\", \\\"{x:510,y:482,t:1527019819215};\\\", \\\"{x:511,y:482,t:1527019819272};\\\", \\\"{x:511,y:481,t:1527019819279};\\\", \\\"{x:511,y:480,t:1527019819294};\\\", \\\"{x:511,y:478,t:1527019819312};\\\", \\\"{x:514,y:477,t:1527019819327};\\\", \\\"{x:519,y:475,t:1527019819343};\\\", \\\"{x:525,y:473,t:1527019819360};\\\", \\\"{x:528,y:471,t:1527019819377};\\\", \\\"{x:535,y:466,t:1527019819394};\\\", \\\"{x:540,y:465,t:1527019819410};\\\", \\\"{x:542,y:462,t:1527019819428};\\\", \\\"{x:545,y:462,t:1527019819444};\\\", \\\"{x:546,y:462,t:1527019819461};\\\", \\\"{x:548,y:461,t:1527019819477};\\\", \\\"{x:549,y:461,t:1527019819495};\\\", \\\"{x:550,y:461,t:1527019819785};\\\", \\\"{x:551,y:459,t:1527019819794};\\\", \\\"{x:553,y:459,t:1527019819812};\\\", \\\"{x:556,y:459,t:1527019819828};\\\", \\\"{x:560,y:457,t:1527019819844};\\\", \\\"{x:567,y:455,t:1527019819862};\\\", \\\"{x:574,y:454,t:1527019819879};\\\", \\\"{x:583,y:453,t:1527019819895};\\\", \\\"{x:601,y:451,t:1527019819912};\\\", \\\"{x:618,y:449,t:1527019819929};\\\", \\\"{x:626,y:448,t:1527019819945};\\\", \\\"{x:636,y:448,t:1527019819962};\\\", \\\"{x:646,y:448,t:1527019819979};\\\", \\\"{x:655,y:448,t:1527019819994};\\\", \\\"{x:666,y:450,t:1527019820011};\\\", \\\"{x:673,y:451,t:1527019820028};\\\", \\\"{x:680,y:452,t:1527019820045};\\\", \\\"{x:686,y:454,t:1527019820062};\\\", \\\"{x:692,y:454,t:1527019820078};\\\", \\\"{x:698,y:456,t:1527019820095};\\\", \\\"{x:702,y:457,t:1527019820111};\\\", \\\"{x:726,y:459,t:1527019820129};\\\", \\\"{x:736,y:461,t:1527019820146};\\\", \\\"{x:746,y:461,t:1527019820161};\\\", \\\"{x:759,y:465,t:1527019820178};\\\", \\\"{x:769,y:465,t:1527019820196};\\\", \\\"{x:783,y:466,t:1527019820212};\\\", \\\"{x:791,y:469,t:1527019820228};\\\", \\\"{x:805,y:471,t:1527019820246};\\\", \\\"{x:824,y:475,t:1527019820261};\\\", \\\"{x:834,y:479,t:1527019820278};\\\", \\\"{x:864,y:486,t:1527019820295};\\\", \\\"{x:872,y:488,t:1527019820312};\\\", \\\"{x:899,y:496,t:1527019820328};\\\", \\\"{x:915,y:501,t:1527019820345};\\\", \\\"{x:922,y:501,t:1527019820362};\\\", \\\"{x:933,y:506,t:1527019820378};\\\", \\\"{x:941,y:510,t:1527019820395};\\\", \\\"{x:945,y:511,t:1527019820411};\\\", \\\"{x:948,y:513,t:1527019820428};\\\", \\\"{x:949,y:513,t:1527019820444};\\\", \\\"{x:949,y:514,t:1527019820480};\\\", \\\"{x:949,y:515,t:1527019820545};\\\", \\\"{x:949,y:516,t:1527019820585};\\\", \\\"{x:949,y:517,t:1527019820640};\\\", \\\"{x:947,y:517,t:1527019820688};\\\", \\\"{x:944,y:516,t:1527019820696};\\\", \\\"{x:940,y:514,t:1527019820712};\\\", \\\"{x:932,y:509,t:1527019820729};\\\", \\\"{x:922,y:504,t:1527019820744};\\\", \\\"{x:916,y:499,t:1527019820762};\\\", \\\"{x:908,y:492,t:1527019820779};\\\", \\\"{x:905,y:488,t:1527019820795};\\\", \\\"{x:900,y:484,t:1527019820813};\\\", \\\"{x:897,y:480,t:1527019820829};\\\", \\\"{x:892,y:475,t:1527019820845};\\\", \\\"{x:889,y:472,t:1527019820862};\\\", \\\"{x:888,y:471,t:1527019820878};\\\", \\\"{x:887,y:470,t:1527019820919};\\\", \\\"{x:887,y:466,t:1527019820968};\\\", \\\"{x:886,y:455,t:1527019820978};\\\", \\\"{x:886,y:434,t:1527019820995};\\\", \\\"{x:885,y:432,t:1527019821013};\\\", \\\"{x:885,y:431,t:1527019821712};\\\", \\\"{x:885,y:432,t:1527019821768};\\\", \\\"{x:886,y:437,t:1527019821780};\\\", \\\"{x:892,y:450,t:1527019821797};\\\", \\\"{x:897,y:459,t:1527019821813};\\\", \\\"{x:902,y:468,t:1527019821829};\\\", \\\"{x:906,y:477,t:1527019821847};\\\", \\\"{x:909,y:484,t:1527019821863};\\\", \\\"{x:911,y:495,t:1527019821881};\\\", \\\"{x:918,y:519,t:1527019821895};\\\", \\\"{x:924,y:528,t:1527019821913};\\\", \\\"{x:931,y:546,t:1527019821929};\\\", \\\"{x:937,y:564,t:1527019821947};\\\", \\\"{x:944,y:581,t:1527019821962};\\\", \\\"{x:955,y:600,t:1527019821979};\\\", \\\"{x:966,y:620,t:1527019821997};\\\", \\\"{x:980,y:643,t:1527019822013};\\\", \\\"{x:991,y:664,t:1527019822029};\\\", \\\"{x:1000,y:680,t:1527019822047};\\\", \\\"{x:1005,y:695,t:1527019822063};\\\", \\\"{x:1014,y:717,t:1527019822079};\\\", \\\"{x:1024,y:734,t:1527019822096};\\\", \\\"{x:1034,y:750,t:1527019822112};\\\", \\\"{x:1045,y:767,t:1527019822130};\\\", \\\"{x:1052,y:782,t:1527019822147};\\\", \\\"{x:1058,y:792,t:1527019822163};\\\", \\\"{x:1066,y:802,t:1527019822180};\\\", \\\"{x:1073,y:812,t:1527019822197};\\\", \\\"{x:1078,y:820,t:1527019822214};\\\", \\\"{x:1086,y:828,t:1527019822230};\\\", \\\"{x:1093,y:836,t:1527019822247};\\\", \\\"{x:1100,y:847,t:1527019822264};\\\", \\\"{x:1111,y:863,t:1527019822280};\\\", \\\"{x:1117,y:870,t:1527019822297};\\\", \\\"{x:1123,y:880,t:1527019822315};\\\", \\\"{x:1127,y:885,t:1527019822330};\\\", \\\"{x:1133,y:893,t:1527019822347};\\\", \\\"{x:1139,y:899,t:1527019822364};\\\", \\\"{x:1143,y:903,t:1527019822380};\\\", \\\"{x:1145,y:904,t:1527019822396};\\\", \\\"{x:1146,y:905,t:1527019822417};\\\", \\\"{x:1147,y:905,t:1527019822457};\\\", \\\"{x:1148,y:904,t:1527019822464};\\\", \\\"{x:1149,y:901,t:1527019822480};\\\", \\\"{x:1151,y:895,t:1527019822497};\\\", \\\"{x:1152,y:884,t:1527019822514};\\\", \\\"{x:1152,y:873,t:1527019822530};\\\", \\\"{x:1152,y:857,t:1527019822547};\\\", \\\"{x:1152,y:840,t:1527019822564};\\\", \\\"{x:1152,y:821,t:1527019822581};\\\", \\\"{x:1151,y:802,t:1527019822597};\\\", \\\"{x:1149,y:782,t:1527019822614};\\\", \\\"{x:1146,y:763,t:1527019822631};\\\", \\\"{x:1144,y:748,t:1527019822648};\\\", \\\"{x:1139,y:726,t:1527019822664};\\\", \\\"{x:1135,y:713,t:1527019822681};\\\", \\\"{x:1134,y:703,t:1527019822697};\\\", \\\"{x:1131,y:695,t:1527019822714};\\\", \\\"{x:1129,y:682,t:1527019822730};\\\", \\\"{x:1126,y:664,t:1527019822746};\\\", \\\"{x:1121,y:643,t:1527019822764};\\\", \\\"{x:1115,y:624,t:1527019822780};\\\", \\\"{x:1109,y:604,t:1527019822797};\\\", \\\"{x:1104,y:589,t:1527019822813};\\\", \\\"{x:1099,y:575,t:1527019822830};\\\", \\\"{x:1096,y:567,t:1527019822846};\\\", \\\"{x:1094,y:558,t:1527019822863};\\\", \\\"{x:1093,y:555,t:1527019822880};\\\", \\\"{x:1093,y:554,t:1527019822896};\\\", \\\"{x:1092,y:552,t:1527019822914};\\\", \\\"{x:1092,y:551,t:1527019823057};\\\", \\\"{x:1093,y:550,t:1527019823064};\\\", \\\"{x:1095,y:550,t:1527019823081};\\\", \\\"{x:1096,y:550,t:1527019823098};\\\", \\\"{x:1099,y:549,t:1527019823114};\\\", \\\"{x:1101,y:549,t:1527019823131};\\\", \\\"{x:1106,y:549,t:1527019823148};\\\", \\\"{x:1115,y:549,t:1527019823164};\\\", \\\"{x:1126,y:555,t:1527019823181};\\\", \\\"{x:1135,y:560,t:1527019823198};\\\", \\\"{x:1144,y:568,t:1527019823214};\\\", \\\"{x:1156,y:572,t:1527019823231};\\\", \\\"{x:1174,y:579,t:1527019823247};\\\", \\\"{x:1180,y:579,t:1527019823263};\\\", \\\"{x:1185,y:583,t:1527019823281};\\\", \\\"{x:1192,y:584,t:1527019823298};\\\", \\\"{x:1199,y:586,t:1527019823314};\\\", \\\"{x:1203,y:586,t:1527019823331};\\\", \\\"{x:1206,y:586,t:1527019823348};\\\", \\\"{x:1207,y:586,t:1527019823364};\\\", \\\"{x:1209,y:586,t:1527019823381};\\\", \\\"{x:1211,y:585,t:1527019823397};\\\", \\\"{x:1211,y:584,t:1527019823441};\\\", \\\"{x:1213,y:584,t:1527019823465};\\\", \\\"{x:1214,y:583,t:1527019823481};\\\", \\\"{x:1216,y:583,t:1527019823498};\\\", \\\"{x:1219,y:579,t:1527019823514};\\\", \\\"{x:1225,y:576,t:1527019823531};\\\", \\\"{x:1231,y:572,t:1527019823548};\\\", \\\"{x:1237,y:567,t:1527019823565};\\\", \\\"{x:1244,y:563,t:1527019823581};\\\", \\\"{x:1250,y:560,t:1527019823598};\\\", \\\"{x:1255,y:558,t:1527019823615};\\\", \\\"{x:1256,y:558,t:1527019823631};\\\", \\\"{x:1257,y:557,t:1527019823648};\\\", \\\"{x:1258,y:556,t:1527019823665};\\\", \\\"{x:1263,y:556,t:1527019823680};\\\", \\\"{x:1270,y:556,t:1527019823698};\\\", \\\"{x:1271,y:556,t:1527019823715};\\\", \\\"{x:1265,y:558,t:1527019823769};\\\", \\\"{x:1261,y:560,t:1527019823781};\\\", \\\"{x:1249,y:562,t:1527019823798};\\\", \\\"{x:1230,y:565,t:1527019823815};\\\", \\\"{x:1210,y:567,t:1527019823831};\\\", \\\"{x:1151,y:574,t:1527019823849};\\\", \\\"{x:1090,y:581,t:1527019823864};\\\", \\\"{x:1039,y:586,t:1527019823881};\\\", \\\"{x:980,y:586,t:1527019823898};\\\", \\\"{x:954,y:586,t:1527019823915};\\\", \\\"{x:938,y:587,t:1527019823932};\\\", \\\"{x:917,y:587,t:1527019823947};\\\", \\\"{x:902,y:587,t:1527019823964};\\\", \\\"{x:887,y:588,t:1527019823981};\\\", \\\"{x:874,y:591,t:1527019823997};\\\", \\\"{x:860,y:594,t:1527019824015};\\\", \\\"{x:843,y:599,t:1527019824031};\\\", \\\"{x:825,y:604,t:1527019824048};\\\", \\\"{x:809,y:608,t:1527019824064};\\\", \\\"{x:787,y:614,t:1527019824082};\\\", \\\"{x:776,y:615,t:1527019824098};\\\", \\\"{x:763,y:606,t:1527019824115};\\\", \\\"{x:761,y:594,t:1527019824133};\\\", \\\"{x:761,y:593,t:1527019824530};\\\", \\\"{x:753,y:588,t:1527019824549};\\\", \\\"{x:744,y:581,t:1527019824565};\\\", \\\"{x:739,y:581,t:1527019824582};\\\", \\\"{x:731,y:581,t:1527019824598};\\\", \\\"{x:726,y:581,t:1527019824615};\\\", \\\"{x:711,y:581,t:1527019824634};\\\", \\\"{x:697,y:581,t:1527019824649};\\\", \\\"{x:686,y:581,t:1527019824665};\\\", \\\"{x:665,y:579,t:1527019824681};\\\", \\\"{x:653,y:576,t:1527019824698};\\\", \\\"{x:647,y:574,t:1527019824715};\\\", \\\"{x:638,y:572,t:1527019824732};\\\", \\\"{x:628,y:570,t:1527019824747};\\\", \\\"{x:620,y:569,t:1527019824765};\\\", \\\"{x:609,y:568,t:1527019824781};\\\", \\\"{x:588,y:568,t:1527019824799};\\\", \\\"{x:562,y:568,t:1527019824815};\\\", \\\"{x:552,y:565,t:1527019824832};\\\", \\\"{x:537,y:563,t:1527019824848};\\\", \\\"{x:516,y:563,t:1527019824865};\\\", \\\"{x:490,y:563,t:1527019824883};\\\", \\\"{x:446,y:560,t:1527019824899};\\\", \\\"{x:414,y:560,t:1527019824915};\\\", \\\"{x:377,y:557,t:1527019824931};\\\", \\\"{x:350,y:557,t:1527019824949};\\\", \\\"{x:322,y:557,t:1527019824966};\\\", \\\"{x:307,y:558,t:1527019824982};\\\", \\\"{x:302,y:558,t:1527019824999};\\\", \\\"{x:300,y:558,t:1527019825016};\\\", \\\"{x:302,y:557,t:1527019825056};\\\", \\\"{x:307,y:554,t:1527019825067};\\\", \\\"{x:325,y:544,t:1527019825082};\\\", \\\"{x:343,y:541,t:1527019825098};\\\", \\\"{x:366,y:538,t:1527019825116};\\\", \\\"{x:379,y:538,t:1527019825131};\\\", \\\"{x:399,y:538,t:1527019825149};\\\", \\\"{x:411,y:540,t:1527019825166};\\\", \\\"{x:419,y:542,t:1527019825183};\\\", \\\"{x:429,y:543,t:1527019825198};\\\", \\\"{x:447,y:545,t:1527019825215};\\\", \\\"{x:457,y:548,t:1527019825232};\\\", \\\"{x:460,y:549,t:1527019825248};\\\", \\\"{x:464,y:549,t:1527019825266};\\\", \\\"{x:469,y:549,t:1527019825282};\\\", \\\"{x:478,y:549,t:1527019825299};\\\", \\\"{x:484,y:549,t:1527019825315};\\\", \\\"{x:488,y:549,t:1527019825332};\\\", \\\"{x:493,y:549,t:1527019825348};\\\", \\\"{x:506,y:548,t:1527019825366};\\\", \\\"{x:519,y:543,t:1527019825382};\\\", \\\"{x:528,y:541,t:1527019825398};\\\", \\\"{x:539,y:537,t:1527019825416};\\\", \\\"{x:544,y:536,t:1527019825433};\\\", \\\"{x:553,y:532,t:1527019825448};\\\", \\\"{x:558,y:532,t:1527019825465};\\\", \\\"{x:571,y:530,t:1527019825483};\\\", \\\"{x:585,y:529,t:1527019825498};\\\", \\\"{x:590,y:529,t:1527019825516};\\\", \\\"{x:593,y:528,t:1527019825532};\\\", \\\"{x:595,y:527,t:1527019825549};\\\", \\\"{x:596,y:526,t:1527019825565};\\\", \\\"{x:597,y:525,t:1527019825583};\\\", \\\"{x:598,y:525,t:1527019825609};\\\", \\\"{x:599,y:524,t:1527019825633};\\\", \\\"{x:601,y:522,t:1527019825650};\\\", \\\"{x:604,y:521,t:1527019825666};\\\", \\\"{x:607,y:519,t:1527019825683};\\\", \\\"{x:609,y:518,t:1527019825700};\\\", \\\"{x:611,y:517,t:1527019825717};\\\", \\\"{x:612,y:516,t:1527019825732};\\\", \\\"{x:613,y:515,t:1527019825750};\\\", \\\"{x:614,y:513,t:1527019825792};\\\", \\\"{x:614,y:512,t:1527019825799};\\\", \\\"{x:616,y:508,t:1527019825815};\\\", \\\"{x:617,y:504,t:1527019825833};\\\", \\\"{x:620,y:498,t:1527019825849};\\\", \\\"{x:620,y:497,t:1527019825865};\\\", \\\"{x:621,y:495,t:1527019825883};\\\", \\\"{x:623,y:495,t:1527019826255};\\\", \\\"{x:629,y:495,t:1527019826267};\\\", \\\"{x:648,y:496,t:1527019826284};\\\", \\\"{x:682,y:503,t:1527019826300};\\\", \\\"{x:742,y:523,t:1527019826317};\\\", \\\"{x:804,y:544,t:1527019826333};\\\", \\\"{x:831,y:555,t:1527019826350};\\\", \\\"{x:848,y:560,t:1527019826368};\\\", \\\"{x:863,y:565,t:1527019826384};\\\", \\\"{x:865,y:565,t:1527019826399};\\\", \\\"{x:865,y:566,t:1527019826456};\\\", \\\"{x:863,y:567,t:1527019826472};\\\", \\\"{x:862,y:567,t:1527019826483};\\\", \\\"{x:862,y:568,t:1527019826499};\\\", \\\"{x:860,y:569,t:1527019826517};\\\", \\\"{x:859,y:569,t:1527019826534};\\\", \\\"{x:851,y:569,t:1527019826550};\\\", \\\"{x:846,y:567,t:1527019826567};\\\", \\\"{x:844,y:566,t:1527019826584};\\\", \\\"{x:844,y:565,t:1527019826617};\\\", \\\"{x:844,y:564,t:1527019826634};\\\", \\\"{x:843,y:559,t:1527019826649};\\\", \\\"{x:842,y:557,t:1527019826666};\\\", \\\"{x:841,y:554,t:1527019826684};\\\", \\\"{x:839,y:551,t:1527019826700};\\\", \\\"{x:836,y:550,t:1527019827055};\\\", \\\"{x:828,y:549,t:1527019827067};\\\", \\\"{x:812,y:547,t:1527019827084};\\\", \\\"{x:787,y:546,t:1527019827100};\\\", \\\"{x:765,y:555,t:1527019827116};\\\", \\\"{x:747,y:564,t:1527019827134};\\\", \\\"{x:722,y:588,t:1527019827152};\\\", \\\"{x:699,y:615,t:1527019827168};\\\", \\\"{x:679,y:648,t:1527019827184};\\\", \\\"{x:666,y:682,t:1527019827200};\\\", \\\"{x:656,y:702,t:1527019827217};\\\", \\\"{x:641,y:722,t:1527019827233};\\\", \\\"{x:612,y:756,t:1527019827249};\\\", \\\"{x:600,y:776,t:1527019827266};\\\", \\\"{x:594,y:786,t:1527019827283};\\\", \\\"{x:589,y:791,t:1527019827300};\\\", \\\"{x:587,y:796,t:1527019827317};\\\", \\\"{x:585,y:800,t:1527019827333};\\\", \\\"{x:583,y:801,t:1527019827350};\\\", \\\"{x:583,y:802,t:1527019827367};\\\", \\\"{x:581,y:802,t:1527019827383};\\\", \\\"{x:579,y:802,t:1527019827400};\\\", \\\"{x:577,y:802,t:1527019827417};\\\", \\\"{x:575,y:799,t:1527019827433};\\\", \\\"{x:573,y:798,t:1527019827450};\\\", \\\"{x:573,y:794,t:1527019827466};\\\", \\\"{x:572,y:789,t:1527019827483};\\\", \\\"{x:571,y:779,t:1527019827500};\\\", \\\"{x:569,y:768,t:1527019827516};\\\", \\\"{x:566,y:752,t:1527019827533};\\\", \\\"{x:558,y:736,t:1527019827551};\\\", \\\"{x:552,y:724,t:1527019827566};\\\", \\\"{x:546,y:715,t:1527019827584};\\\", \\\"{x:546,y:717,t:1527019827936};\\\", \\\"{x:546,y:718,t:1527019827968};\\\", \\\"{x:546,y:720,t:1527019828017};\\\", \\\"{x:546,y:724,t:1527019828035};\\\", \\\"{x:546,y:731,t:1527019828052};\\\", \\\"{x:546,y:734,t:1527019828068};\\\", \\\"{x:546,y:738,t:1527019828085};\\\", \\\"{x:546,y:743,t:1527019828101};\\\", \\\"{x:546,y:746,t:1527019828118};\\\", \\\"{x:548,y:746,t:1527019828576};\\\", \\\"{x:557,y:746,t:1527019828584};\\\", \\\"{x:588,y:735,t:1527019828602};\\\", \\\"{x:620,y:726,t:1527019828618};\\\", \\\"{x:649,y:716,t:1527019828635};\\\", \\\"{x:686,y:709,t:1527019828651};\\\", \\\"{x:732,y:694,t:1527019828668};\\\", \\\"{x:763,y:687,t:1527019828685};\\\", \\\"{x:811,y:678,t:1527019828702};\\\", \\\"{x:855,y:674,t:1527019828718};\\\", \\\"{x:877,y:671,t:1527019828734};\\\", \\\"{x:913,y:665,t:1527019828752};\\\", \\\"{x:926,y:660,t:1527019828768};\\\", \\\"{x:930,y:657,t:1527019828785};\\\", \\\"{x:933,y:655,t:1527019828802};\\\", \\\"{x:937,y:650,t:1527019828819};\\\", \\\"{x:937,y:648,t:1527019828847};\\\", \\\"{x:937,y:647,t:1527019828880};\\\" ] }, { \\\"rt\\\": 14502, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 468398, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:932,y:640,t:1527019830481};\\\", \\\"{x:871,y:589,t:1527019830508};\\\", \\\"{x:818,y:544,t:1527019830520};\\\", \\\"{x:754,y:500,t:1527019830538};\\\", \\\"{x:683,y:440,t:1527019830553};\\\", \\\"{x:618,y:394,t:1527019830570};\\\", \\\"{x:568,y:354,t:1527019830587};\\\", \\\"{x:528,y:323,t:1527019830603};\\\", \\\"{x:491,y:296,t:1527019830620};\\\", \\\"{x:471,y:281,t:1527019830637};\\\", \\\"{x:452,y:268,t:1527019830653};\\\", \\\"{x:439,y:265,t:1527019830670};\\\", \\\"{x:436,y:263,t:1527019830687};\\\", \\\"{x:434,y:264,t:1527019830736};\\\", \\\"{x:429,y:271,t:1527019830744};\\\", \\\"{x:428,y:276,t:1527019830754};\\\", \\\"{x:422,y:287,t:1527019830771};\\\", \\\"{x:415,y:303,t:1527019830787};\\\", \\\"{x:407,y:319,t:1527019830803};\\\", \\\"{x:403,y:331,t:1527019830821};\\\", \\\"{x:400,y:339,t:1527019830836};\\\", \\\"{x:400,y:345,t:1527019830854};\\\", \\\"{x:400,y:348,t:1527019830871};\\\", \\\"{x:400,y:353,t:1527019830887};\\\", \\\"{x:401,y:356,t:1527019830904};\\\", \\\"{x:401,y:359,t:1527019830921};\\\", \\\"{x:401,y:363,t:1527019830938};\\\", \\\"{x:401,y:367,t:1527019830954};\\\", \\\"{x:399,y:375,t:1527019830970};\\\", \\\"{x:394,y:384,t:1527019830988};\\\", \\\"{x:392,y:392,t:1527019831003};\\\", \\\"{x:390,y:402,t:1527019831021};\\\", \\\"{x:388,y:415,t:1527019831038};\\\", \\\"{x:385,y:425,t:1527019831055};\\\", \\\"{x:382,y:431,t:1527019831071};\\\", \\\"{x:378,y:439,t:1527019831088};\\\", \\\"{x:378,y:442,t:1527019831105};\\\", \\\"{x:376,y:444,t:1527019831121};\\\", \\\"{x:375,y:445,t:1527019831138};\\\", \\\"{x:373,y:449,t:1527019831155};\\\", \\\"{x:370,y:452,t:1527019831171};\\\", \\\"{x:370,y:453,t:1527019831188};\\\", \\\"{x:366,y:456,t:1527019831205};\\\", \\\"{x:363,y:459,t:1527019831222};\\\", \\\"{x:361,y:461,t:1527019831239};\\\", \\\"{x:361,y:462,t:1527019831255};\\\", \\\"{x:361,y:464,t:1527019831272};\\\", \\\"{x:361,y:466,t:1527019831288};\\\", \\\"{x:360,y:467,t:1527019831305};\\\", \\\"{x:360,y:466,t:1527019831456};\\\", \\\"{x:363,y:463,t:1527019831472};\\\", \\\"{x:369,y:459,t:1527019831489};\\\", \\\"{x:378,y:456,t:1527019831506};\\\", \\\"{x:390,y:452,t:1527019831522};\\\", \\\"{x:397,y:452,t:1527019831539};\\\", \\\"{x:404,y:451,t:1527019831556};\\\", \\\"{x:412,y:451,t:1527019831572};\\\", \\\"{x:418,y:451,t:1527019831589};\\\", \\\"{x:423,y:451,t:1527019831606};\\\", \\\"{x:432,y:452,t:1527019831622};\\\", \\\"{x:440,y:453,t:1527019831639};\\\", \\\"{x:446,y:455,t:1527019831656};\\\", \\\"{x:447,y:455,t:1527019831673};\\\", \\\"{x:449,y:456,t:1527019831690};\\\", \\\"{x:450,y:457,t:1527019831761};\\\", \\\"{x:452,y:458,t:1527019831800};\\\", \\\"{x:453,y:458,t:1527019831992};\\\", \\\"{x:455,y:458,t:1527019832007};\\\", \\\"{x:456,y:458,t:1527019832032};\\\", \\\"{x:457,y:457,t:1527019832040};\\\", \\\"{x:459,y:457,t:1527019832064};\\\", \\\"{x:460,y:456,t:1527019832112};\\\", \\\"{x:460,y:455,t:1527019832177};\\\", \\\"{x:461,y:455,t:1527019832190};\\\", \\\"{x:462,y:454,t:1527019832208};\\\", \\\"{x:465,y:453,t:1527019832224};\\\", \\\"{x:465,y:452,t:1527019832264};\\\", \\\"{x:466,y:452,t:1527019832288};\\\", \\\"{x:468,y:452,t:1527019832296};\\\", \\\"{x:469,y:452,t:1527019832307};\\\", \\\"{x:472,y:452,t:1527019832324};\\\", \\\"{x:475,y:451,t:1527019832341};\\\", \\\"{x:479,y:451,t:1527019832357};\\\", \\\"{x:480,y:451,t:1527019832374};\\\", \\\"{x:481,y:451,t:1527019832392};\\\", \\\"{x:483,y:451,t:1527019832408};\\\", \\\"{x:485,y:451,t:1527019832424};\\\", \\\"{x:486,y:451,t:1527019832442};\\\", \\\"{x:489,y:451,t:1527019832458};\\\", \\\"{x:496,y:452,t:1527019832474};\\\", \\\"{x:500,y:452,t:1527019832491};\\\", \\\"{x:504,y:454,t:1527019832508};\\\", \\\"{x:508,y:455,t:1527019832525};\\\", \\\"{x:513,y:457,t:1527019832541};\\\", \\\"{x:515,y:458,t:1527019832558};\\\", \\\"{x:518,y:458,t:1527019832575};\\\", \\\"{x:522,y:460,t:1527019832591};\\\", \\\"{x:528,y:460,t:1527019832608};\\\", \\\"{x:532,y:461,t:1527019832624};\\\", \\\"{x:536,y:462,t:1527019832641};\\\", \\\"{x:542,y:464,t:1527019832658};\\\", \\\"{x:547,y:464,t:1527019832674};\\\", \\\"{x:549,y:464,t:1527019832692};\\\", \\\"{x:551,y:464,t:1527019832708};\\\", \\\"{x:554,y:464,t:1527019832725};\\\", \\\"{x:556,y:464,t:1527019832741};\\\", \\\"{x:557,y:464,t:1527019832758};\\\", \\\"{x:561,y:464,t:1527019832775};\\\", \\\"{x:565,y:462,t:1527019832792};\\\", \\\"{x:570,y:460,t:1527019832808};\\\", \\\"{x:574,y:459,t:1527019832825};\\\", \\\"{x:578,y:456,t:1527019832842};\\\", \\\"{x:581,y:456,t:1527019832859};\\\", \\\"{x:582,y:455,t:1527019832875};\\\", \\\"{x:584,y:455,t:1527019832911};\\\", \\\"{x:588,y:454,t:1527019832935};\\\", \\\"{x:588,y:453,t:1527019832944};\\\", \\\"{x:589,y:453,t:1527019832959};\\\", \\\"{x:591,y:453,t:1527019832983};\\\", \\\"{x:592,y:453,t:1527019832992};\\\", \\\"{x:595,y:452,t:1527019833009};\\\", \\\"{x:599,y:452,t:1527019833026};\\\", \\\"{x:601,y:452,t:1527019833042};\\\", \\\"{x:605,y:452,t:1527019833059};\\\", \\\"{x:608,y:452,t:1527019833076};\\\", \\\"{x:612,y:452,t:1527019833092};\\\", \\\"{x:617,y:452,t:1527019833109};\\\", \\\"{x:621,y:452,t:1527019833126};\\\", \\\"{x:627,y:454,t:1527019833143};\\\", \\\"{x:633,y:456,t:1527019833159};\\\", \\\"{x:637,y:456,t:1527019833176};\\\", \\\"{x:641,y:458,t:1527019833193};\\\", \\\"{x:643,y:459,t:1527019833210};\\\", \\\"{x:649,y:461,t:1527019833226};\\\", \\\"{x:653,y:462,t:1527019833243};\\\", \\\"{x:657,y:462,t:1527019833259};\\\", \\\"{x:660,y:462,t:1527019833276};\\\", \\\"{x:663,y:462,t:1527019833294};\\\", \\\"{x:667,y:462,t:1527019833310};\\\", \\\"{x:668,y:462,t:1527019833326};\\\", \\\"{x:672,y:462,t:1527019833343};\\\", \\\"{x:675,y:462,t:1527019833360};\\\", \\\"{x:678,y:462,t:1527019833376};\\\", \\\"{x:686,y:462,t:1527019833393};\\\", \\\"{x:687,y:462,t:1527019833410};\\\", \\\"{x:690,y:462,t:1527019833427};\\\", \\\"{x:695,y:464,t:1527019833443};\\\", \\\"{x:696,y:464,t:1527019833460};\\\", \\\"{x:700,y:465,t:1527019833478};\\\", \\\"{x:702,y:465,t:1527019833494};\\\", \\\"{x:704,y:465,t:1527019833510};\\\", \\\"{x:705,y:465,t:1527019833527};\\\", \\\"{x:707,y:465,t:1527019833550};\\\", \\\"{x:708,y:465,t:1527019833567};\\\", \\\"{x:709,y:466,t:1527019833576};\\\", \\\"{x:710,y:466,t:1527019833593};\\\", \\\"{x:711,y:466,t:1527019833609};\\\", \\\"{x:714,y:466,t:1527019833627};\\\", \\\"{x:715,y:468,t:1527019833999};\\\", \\\"{x:715,y:469,t:1527019834010};\\\", \\\"{x:715,y:471,t:1527019834028};\\\", \\\"{x:716,y:474,t:1527019834044};\\\", \\\"{x:718,y:479,t:1527019834060};\\\", \\\"{x:718,y:481,t:1527019834078};\\\", \\\"{x:720,y:485,t:1527019834095};\\\", \\\"{x:720,y:488,t:1527019834110};\\\", \\\"{x:722,y:492,t:1527019834127};\\\", \\\"{x:723,y:492,t:1527019834145};\\\", \\\"{x:724,y:494,t:1527019834159};\\\", \\\"{x:725,y:495,t:1527019834183};\\\", \\\"{x:725,y:496,t:1527019834535};\\\", \\\"{x:725,y:498,t:1527019834543};\\\", \\\"{x:725,y:504,t:1527019834556};\\\", \\\"{x:725,y:519,t:1527019834573};\\\", \\\"{x:727,y:544,t:1527019834590};\\\", \\\"{x:733,y:572,t:1527019834607};\\\", \\\"{x:746,y:600,t:1527019834623};\\\", \\\"{x:774,y:636,t:1527019834640};\\\", \\\"{x:794,y:653,t:1527019834656};\\\", \\\"{x:822,y:674,t:1527019834673};\\\", \\\"{x:882,y:699,t:1527019834690};\\\", \\\"{x:918,y:720,t:1527019834706};\\\", \\\"{x:970,y:749,t:1527019834723};\\\", \\\"{x:999,y:770,t:1527019834740};\\\", \\\"{x:1043,y:799,t:1527019834756};\\\", \\\"{x:1095,y:822,t:1527019834773};\\\", \\\"{x:1132,y:840,t:1527019834790};\\\", \\\"{x:1156,y:852,t:1527019834806};\\\", \\\"{x:1176,y:862,t:1527019834823};\\\", \\\"{x:1190,y:865,t:1527019834839};\\\", \\\"{x:1194,y:868,t:1527019834856};\\\", \\\"{x:1195,y:869,t:1527019834872};\\\", \\\"{x:1196,y:870,t:1527019834890};\\\", \\\"{x:1197,y:871,t:1527019834911};\\\", \\\"{x:1198,y:871,t:1527019835008};\\\", \\\"{x:1201,y:870,t:1527019835023};\\\", \\\"{x:1205,y:862,t:1527019835039};\\\", \\\"{x:1205,y:855,t:1527019835056};\\\", \\\"{x:1205,y:846,t:1527019835073};\\\", \\\"{x:1192,y:828,t:1527019835089};\\\", \\\"{x:1178,y:809,t:1527019835106};\\\", \\\"{x:1164,y:795,t:1527019835123};\\\", \\\"{x:1149,y:784,t:1527019835140};\\\", \\\"{x:1134,y:773,t:1527019835155};\\\", \\\"{x:1119,y:761,t:1527019835173};\\\", \\\"{x:1107,y:746,t:1527019835188};\\\", \\\"{x:1097,y:735,t:1527019835206};\\\", \\\"{x:1082,y:718,t:1527019835223};\\\", \\\"{x:1075,y:712,t:1527019835239};\\\", \\\"{x:1072,y:707,t:1527019835256};\\\", \\\"{x:1072,y:703,t:1527019835273};\\\", \\\"{x:1067,y:693,t:1527019835289};\\\", \\\"{x:1065,y:686,t:1527019835306};\\\", \\\"{x:1063,y:684,t:1527019835323};\\\", \\\"{x:1062,y:682,t:1527019835339};\\\", \\\"{x:1062,y:681,t:1527019835367};\\\", \\\"{x:1062,y:677,t:1527019835392};\\\", \\\"{x:1063,y:674,t:1527019835406};\\\", \\\"{x:1063,y:665,t:1527019835423};\\\", \\\"{x:1063,y:651,t:1527019835439};\\\", \\\"{x:1063,y:635,t:1527019835456};\\\", \\\"{x:1063,y:630,t:1527019835473};\\\", \\\"{x:1063,y:625,t:1527019835489};\\\", \\\"{x:1063,y:623,t:1527019835505};\\\", \\\"{x:1064,y:621,t:1527019835524};\\\", \\\"{x:1065,y:620,t:1527019835591};\\\", \\\"{x:1065,y:618,t:1527019835607};\\\", \\\"{x:1067,y:618,t:1527019835664};\\\", \\\"{x:1069,y:618,t:1527019835720};\\\", \\\"{x:1071,y:619,t:1527019835928};\\\", \\\"{x:1075,y:621,t:1527019835939};\\\", \\\"{x:1079,y:625,t:1527019835955};\\\", \\\"{x:1083,y:628,t:1527019835972};\\\", \\\"{x:1086,y:628,t:1527019835989};\\\", \\\"{x:1088,y:630,t:1527019836005};\\\", \\\"{x:1092,y:633,t:1527019836022};\\\", \\\"{x:1095,y:636,t:1527019836039};\\\", \\\"{x:1096,y:637,t:1527019836055};\\\", \\\"{x:1097,y:637,t:1527019836295};\\\", \\\"{x:1102,y:638,t:1527019836305};\\\", \\\"{x:1109,y:639,t:1527019836322};\\\", \\\"{x:1120,y:643,t:1527019836339};\\\", \\\"{x:1131,y:648,t:1527019836355};\\\", \\\"{x:1152,y:655,t:1527019836372};\\\", \\\"{x:1169,y:664,t:1527019836389};\\\", \\\"{x:1189,y:671,t:1527019836405};\\\", \\\"{x:1210,y:677,t:1527019836422};\\\", \\\"{x:1228,y:680,t:1527019836438};\\\", \\\"{x:1244,y:682,t:1527019836455};\\\", \\\"{x:1249,y:684,t:1527019836472};\\\", \\\"{x:1253,y:685,t:1527019836488};\\\", \\\"{x:1256,y:685,t:1527019836505};\\\", \\\"{x:1257,y:685,t:1527019836522};\\\", \\\"{x:1261,y:685,t:1527019836538};\\\", \\\"{x:1263,y:685,t:1527019836555};\\\", \\\"{x:1265,y:685,t:1527019836572};\\\", \\\"{x:1267,y:684,t:1527019836588};\\\", \\\"{x:1269,y:683,t:1527019836605};\\\", \\\"{x:1272,y:680,t:1527019836622};\\\", \\\"{x:1275,y:677,t:1527019836638};\\\", \\\"{x:1281,y:674,t:1527019836654};\\\", \\\"{x:1287,y:668,t:1527019836672};\\\", \\\"{x:1289,y:664,t:1527019836688};\\\", \\\"{x:1293,y:657,t:1527019836705};\\\", \\\"{x:1297,y:653,t:1527019836722};\\\", \\\"{x:1300,y:647,t:1527019836738};\\\", \\\"{x:1302,y:645,t:1527019836755};\\\", \\\"{x:1305,y:641,t:1527019836771};\\\", \\\"{x:1306,y:639,t:1527019836791};\\\", \\\"{x:1308,y:637,t:1527019836805};\\\", \\\"{x:1309,y:635,t:1527019836824};\\\", \\\"{x:1309,y:634,t:1527019836848};\\\", \\\"{x:1310,y:634,t:1527019836879};\\\", \\\"{x:1311,y:634,t:1527019836888};\\\", \\\"{x:1312,y:634,t:1527019836911};\\\", \\\"{x:1314,y:633,t:1527019836921};\\\", \\\"{x:1315,y:632,t:1527019836938};\\\", \\\"{x:1316,y:632,t:1527019836955};\\\", \\\"{x:1317,y:632,t:1527019836971};\\\", \\\"{x:1318,y:631,t:1527019836988};\\\", \\\"{x:1320,y:631,t:1527019837005};\\\", \\\"{x:1325,y:629,t:1527019837021};\\\", \\\"{x:1330,y:628,t:1527019837038};\\\", \\\"{x:1333,y:627,t:1527019837056};\\\", \\\"{x:1336,y:626,t:1527019837071};\\\", \\\"{x:1341,y:624,t:1527019837088};\\\", \\\"{x:1343,y:624,t:1527019837106};\\\", \\\"{x:1345,y:624,t:1527019837122};\\\", \\\"{x:1348,y:624,t:1527019837139};\\\", \\\"{x:1352,y:624,t:1527019837155};\\\", \\\"{x:1355,y:624,t:1527019837172};\\\", \\\"{x:1359,y:624,t:1527019837188};\\\", \\\"{x:1374,y:628,t:1527019837205};\\\", \\\"{x:1385,y:634,t:1527019837221};\\\", \\\"{x:1398,y:636,t:1527019837239};\\\", \\\"{x:1410,y:639,t:1527019837254};\\\", \\\"{x:1422,y:641,t:1527019837272};\\\", \\\"{x:1434,y:644,t:1527019837288};\\\", \\\"{x:1440,y:645,t:1527019837305};\\\", \\\"{x:1445,y:647,t:1527019837322};\\\", \\\"{x:1449,y:647,t:1527019837339};\\\", \\\"{x:1455,y:648,t:1527019837354};\\\", \\\"{x:1456,y:648,t:1527019837371};\\\", \\\"{x:1458,y:648,t:1527019837392};\\\", \\\"{x:1459,y:648,t:1527019837425};\\\", \\\"{x:1462,y:648,t:1527019837439};\\\", \\\"{x:1464,y:648,t:1527019837472};\\\", \\\"{x:1464,y:650,t:1527019837569};\\\", \\\"{x:1460,y:653,t:1527019837576};\\\", \\\"{x:1458,y:655,t:1527019837587};\\\", \\\"{x:1451,y:662,t:1527019837605};\\\", \\\"{x:1442,y:665,t:1527019837622};\\\", \\\"{x:1431,y:671,t:1527019837638};\\\", \\\"{x:1428,y:674,t:1527019837654};\\\", \\\"{x:1421,y:675,t:1527019837671};\\\", \\\"{x:1419,y:675,t:1527019837688};\\\", \\\"{x:1411,y:678,t:1527019837704};\\\", \\\"{x:1407,y:681,t:1527019837722};\\\", \\\"{x:1405,y:681,t:1527019837744};\\\", \\\"{x:1403,y:680,t:1527019837754};\\\", \\\"{x:1400,y:680,t:1527019837771};\\\", \\\"{x:1398,y:677,t:1527019837787};\\\", \\\"{x:1397,y:677,t:1527019837807};\\\", \\\"{x:1396,y:677,t:1527019837831};\\\", \\\"{x:1395,y:677,t:1527019837847};\\\", \\\"{x:1394,y:677,t:1527019837864};\\\", \\\"{x:1392,y:677,t:1527019837871};\\\", \\\"{x:1391,y:677,t:1527019837887};\\\", \\\"{x:1387,y:677,t:1527019837904};\\\", \\\"{x:1383,y:677,t:1527019837921};\\\", \\\"{x:1380,y:677,t:1527019837937};\\\", \\\"{x:1371,y:679,t:1527019837954};\\\", \\\"{x:1366,y:679,t:1527019837970};\\\", \\\"{x:1354,y:683,t:1527019837988};\\\", \\\"{x:1352,y:683,t:1527019838004};\\\", \\\"{x:1348,y:684,t:1527019838020};\\\", \\\"{x:1344,y:686,t:1527019838037};\\\", \\\"{x:1344,y:687,t:1527019838136};\\\", \\\"{x:1342,y:690,t:1527019838625};\\\", \\\"{x:1342,y:693,t:1527019838640};\\\", \\\"{x:1342,y:695,t:1527019838655};\\\", \\\"{x:1342,y:698,t:1527019838670};\\\", \\\"{x:1341,y:707,t:1527019838689};\\\", \\\"{x:1341,y:717,t:1527019838703};\\\", \\\"{x:1341,y:732,t:1527019838720};\\\", \\\"{x:1341,y:744,t:1527019838737};\\\", \\\"{x:1339,y:755,t:1527019838754};\\\", \\\"{x:1338,y:761,t:1527019838771};\\\", \\\"{x:1336,y:765,t:1527019838787};\\\", \\\"{x:1336,y:766,t:1527019838803};\\\", \\\"{x:1334,y:767,t:1527019839177};\\\", \\\"{x:1330,y:770,t:1527019839187};\\\", \\\"{x:1319,y:776,t:1527019839204};\\\", \\\"{x:1300,y:780,t:1527019839220};\\\", \\\"{x:1270,y:783,t:1527019839237};\\\", \\\"{x:1214,y:775,t:1527019839253};\\\", \\\"{x:1150,y:750,t:1527019839270};\\\", \\\"{x:1050,y:699,t:1527019839287};\\\", \\\"{x:909,y:612,t:1527019839304};\\\", \\\"{x:645,y:483,t:1527019839320};\\\", \\\"{x:339,y:458,t:1527019839344};\\\", \\\"{x:192,y:478,t:1527019839360};\\\", \\\"{x:98,y:508,t:1527019839378};\\\", \\\"{x:74,y:518,t:1527019839394};\\\", \\\"{x:62,y:523,t:1527019839410};\\\", \\\"{x:54,y:529,t:1527019839427};\\\", \\\"{x:49,y:539,t:1527019839444};\\\", \\\"{x:46,y:545,t:1527019839461};\\\", \\\"{x:45,y:550,t:1527019839477};\\\", \\\"{x:44,y:557,t:1527019839494};\\\", \\\"{x:43,y:562,t:1527019839510};\\\", \\\"{x:42,y:565,t:1527019839527};\\\", \\\"{x:42,y:568,t:1527019839544};\\\", \\\"{x:40,y:574,t:1527019839561};\\\", \\\"{x:40,y:589,t:1527019839577};\\\", \\\"{x:44,y:603,t:1527019839594};\\\", \\\"{x:50,y:610,t:1527019839611};\\\", \\\"{x:57,y:612,t:1527019839627};\\\", \\\"{x:61,y:612,t:1527019839644};\\\", \\\"{x:71,y:612,t:1527019839661};\\\", \\\"{x:80,y:608,t:1527019839677};\\\", \\\"{x:87,y:604,t:1527019839694};\\\", \\\"{x:94,y:601,t:1527019839711};\\\", \\\"{x:97,y:596,t:1527019839729};\\\", \\\"{x:102,y:588,t:1527019839745};\\\", \\\"{x:105,y:582,t:1527019839761};\\\", \\\"{x:114,y:573,t:1527019839777};\\\", \\\"{x:118,y:568,t:1527019839794};\\\", \\\"{x:121,y:563,t:1527019839811};\\\", \\\"{x:122,y:561,t:1527019839829};\\\", \\\"{x:124,y:560,t:1527019839845};\\\", \\\"{x:130,y:555,t:1527019839863};\\\", \\\"{x:140,y:550,t:1527019839877};\\\", \\\"{x:151,y:543,t:1527019839894};\\\", \\\"{x:155,y:542,t:1527019839912};\\\", \\\"{x:159,y:540,t:1527019839928};\\\", \\\"{x:161,y:538,t:1527019839944};\\\", \\\"{x:164,y:536,t:1527019839961};\\\", \\\"{x:172,y:536,t:1527019839977};\\\", \\\"{x:181,y:536,t:1527019839994};\\\", \\\"{x:191,y:536,t:1527019840011};\\\", \\\"{x:200,y:536,t:1527019840027};\\\", \\\"{x:212,y:536,t:1527019840044};\\\", \\\"{x:221,y:533,t:1527019840061};\\\", \\\"{x:229,y:531,t:1527019840077};\\\", \\\"{x:230,y:530,t:1527019840094};\\\", \\\"{x:244,y:530,t:1527019840111};\\\", \\\"{x:250,y:531,t:1527019840127};\\\", \\\"{x:256,y:532,t:1527019840145};\\\", \\\"{x:259,y:532,t:1527019840160};\\\", \\\"{x:262,y:532,t:1527019840177};\\\", \\\"{x:268,y:532,t:1527019840194};\\\", \\\"{x:286,y:532,t:1527019840212};\\\", \\\"{x:322,y:532,t:1527019840228};\\\", \\\"{x:358,y:532,t:1527019840244};\\\", \\\"{x:389,y:532,t:1527019840263};\\\", \\\"{x:411,y:532,t:1527019840278};\\\", \\\"{x:433,y:532,t:1527019840294};\\\", \\\"{x:466,y:536,t:1527019840311};\\\", \\\"{x:483,y:537,t:1527019840328};\\\", \\\"{x:492,y:537,t:1527019840344};\\\", \\\"{x:499,y:537,t:1527019840361};\\\", \\\"{x:506,y:536,t:1527019840378};\\\", \\\"{x:518,y:532,t:1527019840394};\\\", \\\"{x:530,y:531,t:1527019840411};\\\", \\\"{x:533,y:530,t:1527019840428};\\\", \\\"{x:534,y:530,t:1527019840444};\\\", \\\"{x:535,y:530,t:1527019840520};\\\", \\\"{x:537,y:530,t:1527019840552};\\\", \\\"{x:540,y:530,t:1527019840561};\\\", \\\"{x:549,y:530,t:1527019840578};\\\", \\\"{x:578,y:530,t:1527019840595};\\\", \\\"{x:615,y:534,t:1527019840614};\\\", \\\"{x:666,y:534,t:1527019840629};\\\", \\\"{x:706,y:534,t:1527019840645};\\\", \\\"{x:727,y:534,t:1527019840662};\\\", \\\"{x:747,y:533,t:1527019840678};\\\", \\\"{x:767,y:528,t:1527019840695};\\\", \\\"{x:776,y:525,t:1527019840711};\\\", \\\"{x:778,y:525,t:1527019840728};\\\", \\\"{x:778,y:524,t:1527019840746};\\\", \\\"{x:779,y:523,t:1527019840783};\\\", \\\"{x:780,y:523,t:1527019840795};\\\", \\\"{x:785,y:521,t:1527019840811};\\\", \\\"{x:788,y:519,t:1527019840828};\\\", \\\"{x:789,y:519,t:1527019840845};\\\", \\\"{x:792,y:516,t:1527019840862};\\\", \\\"{x:792,y:515,t:1527019840878};\\\", \\\"{x:793,y:514,t:1527019840895};\\\", \\\"{x:793,y:513,t:1527019840912};\\\", \\\"{x:796,y:511,t:1527019840929};\\\", \\\"{x:805,y:508,t:1527019840945};\\\", \\\"{x:816,y:503,t:1527019840961};\\\", \\\"{x:824,y:500,t:1527019840978};\\\", \\\"{x:838,y:498,t:1527019840996};\\\", \\\"{x:853,y:495,t:1527019841012};\\\", \\\"{x:860,y:493,t:1527019841028};\\\", \\\"{x:862,y:491,t:1527019841045};\\\", \\\"{x:864,y:490,t:1527019841071};\\\", \\\"{x:864,y:489,t:1527019841209};\\\", \\\"{x:862,y:487,t:1527019841230};\\\", \\\"{x:855,y:485,t:1527019841245};\\\", \\\"{x:852,y:485,t:1527019841262};\\\", \\\"{x:845,y:486,t:1527019841278};\\\", \\\"{x:843,y:488,t:1527019841295};\\\", \\\"{x:844,y:490,t:1527019841457};\\\", \\\"{x:846,y:490,t:1527019841464};\\\", \\\"{x:850,y:493,t:1527019841480};\\\", \\\"{x:852,y:493,t:1527019841495};\\\", \\\"{x:853,y:496,t:1527019841512};\\\", \\\"{x:855,y:499,t:1527019841529};\\\", \\\"{x:855,y:500,t:1527019841545};\\\", \\\"{x:855,y:501,t:1527019841563};\\\", \\\"{x:855,y:504,t:1527019841579};\\\", \\\"{x:855,y:505,t:1527019841600};\\\", \\\"{x:853,y:506,t:1527019841689};\\\", \\\"{x:852,y:506,t:1527019841696};\\\", \\\"{x:850,y:506,t:1527019841712};\\\", \\\"{x:848,y:506,t:1527019841744};\\\", \\\"{x:847,y:504,t:1527019841752};\\\", \\\"{x:845,y:504,t:1527019841763};\\\", \\\"{x:844,y:503,t:1527019841780};\\\", \\\"{x:842,y:501,t:1527019841796};\\\", \\\"{x:842,y:500,t:1527019841943};\\\", \\\"{x:842,y:499,t:1527019841992};\\\", \\\"{x:842,y:499,t:1527019842013};\\\", \\\"{x:839,y:498,t:1527019842111};\\\", \\\"{x:832,y:498,t:1527019842119};\\\", \\\"{x:822,y:500,t:1527019842130};\\\", \\\"{x:797,y:514,t:1527019842146};\\\", \\\"{x:762,y:527,t:1527019842162};\\\", \\\"{x:706,y:544,t:1527019842180};\\\", \\\"{x:631,y:562,t:1527019842197};\\\", \\\"{x:589,y:569,t:1527019842215};\\\", \\\"{x:540,y:571,t:1527019842229};\\\", \\\"{x:495,y:578,t:1527019842247};\\\", \\\"{x:473,y:578,t:1527019842262};\\\", \\\"{x:436,y:579,t:1527019842280};\\\", \\\"{x:417,y:579,t:1527019842297};\\\", \\\"{x:397,y:579,t:1527019842313};\\\", \\\"{x:382,y:579,t:1527019842329};\\\", \\\"{x:363,y:579,t:1527019842347};\\\", \\\"{x:345,y:579,t:1527019842362};\\\", \\\"{x:311,y:574,t:1527019842379};\\\", \\\"{x:281,y:564,t:1527019842396};\\\", \\\"{x:248,y:553,t:1527019842414};\\\", \\\"{x:231,y:547,t:1527019842431};\\\", \\\"{x:226,y:546,t:1527019842446};\\\", \\\"{x:224,y:544,t:1527019842463};\\\", \\\"{x:222,y:541,t:1527019842480};\\\", \\\"{x:221,y:540,t:1527019842496};\\\", \\\"{x:220,y:537,t:1527019842514};\\\", \\\"{x:219,y:537,t:1527019842569};\\\", \\\"{x:217,y:537,t:1527019842584};\\\", \\\"{x:216,y:537,t:1527019842596};\\\", \\\"{x:212,y:537,t:1527019842613};\\\", \\\"{x:204,y:538,t:1527019842630};\\\", \\\"{x:197,y:543,t:1527019842647};\\\", \\\"{x:186,y:546,t:1527019842665};\\\", \\\"{x:184,y:546,t:1527019842680};\\\", \\\"{x:181,y:546,t:1527019842696};\\\", \\\"{x:180,y:546,t:1527019842713};\\\", \\\"{x:175,y:546,t:1527019842730};\\\", \\\"{x:173,y:546,t:1527019842746};\\\", \\\"{x:170,y:547,t:1527019842763};\\\", \\\"{x:167,y:548,t:1527019842780};\\\", \\\"{x:165,y:549,t:1527019842796};\\\", \\\"{x:163,y:549,t:1527019842813};\\\", \\\"{x:162,y:549,t:1527019842831};\\\", \\\"{x:160,y:550,t:1527019843055};\\\", \\\"{x:162,y:553,t:1527019843063};\\\", \\\"{x:178,y:567,t:1527019843081};\\\", \\\"{x:203,y:582,t:1527019843097};\\\", \\\"{x:244,y:598,t:1527019843113};\\\", \\\"{x:268,y:612,t:1527019843131};\\\", \\\"{x:281,y:620,t:1527019843148};\\\", \\\"{x:292,y:629,t:1527019843163};\\\", \\\"{x:303,y:642,t:1527019843181};\\\", \\\"{x:311,y:655,t:1527019843197};\\\", \\\"{x:321,y:672,t:1527019843214};\\\", \\\"{x:324,y:678,t:1527019843230};\\\", \\\"{x:328,y:682,t:1527019843247};\\\", \\\"{x:334,y:688,t:1527019843263};\\\", \\\"{x:345,y:695,t:1527019843280};\\\", \\\"{x:357,y:700,t:1527019843298};\\\", \\\"{x:363,y:704,t:1527019843313};\\\", \\\"{x:364,y:704,t:1527019843352};\\\", \\\"{x:365,y:706,t:1527019843364};\\\", \\\"{x:365,y:708,t:1527019843384};\\\", \\\"{x:367,y:710,t:1527019843400};\\\", \\\"{x:368,y:710,t:1527019843413};\\\", \\\"{x:372,y:711,t:1527019843431};\\\", \\\"{x:379,y:711,t:1527019843447};\\\", \\\"{x:386,y:711,t:1527019843465};\\\", \\\"{x:393,y:712,t:1527019843481};\\\", \\\"{x:397,y:714,t:1527019843498};\\\", \\\"{x:405,y:716,t:1527019843514};\\\", \\\"{x:408,y:718,t:1527019843530};\\\", \\\"{x:412,y:719,t:1527019843547};\\\", \\\"{x:416,y:722,t:1527019843565};\\\", \\\"{x:419,y:723,t:1527019843580};\\\", \\\"{x:424,y:725,t:1527019843598};\\\", \\\"{x:426,y:726,t:1527019843614};\\\", \\\"{x:428,y:726,t:1527019843630};\\\", \\\"{x:428,y:727,t:1527019843648};\\\", \\\"{x:429,y:728,t:1527019843704};\\\", \\\"{x:431,y:728,t:1527019843714};\\\", \\\"{x:434,y:728,t:1527019843730};\\\", \\\"{x:442,y:728,t:1527019843748};\\\", \\\"{x:447,y:728,t:1527019843766};\\\", \\\"{x:451,y:728,t:1527019843780};\\\", \\\"{x:461,y:728,t:1527019843798};\\\", \\\"{x:472,y:728,t:1527019843814};\\\", \\\"{x:479,y:728,t:1527019843831};\\\", \\\"{x:480,y:728,t:1527019843847};\\\", \\\"{x:482,y:728,t:1527019843951};\\\", \\\"{x:483,y:728,t:1527019843965};\\\", \\\"{x:484,y:728,t:1527019843981};\\\", \\\"{x:484,y:728,t:1527019844064};\\\", \\\"{x:487,y:727,t:1527019844280};\\\", \\\"{x:492,y:722,t:1527019844288};\\\", \\\"{x:497,y:717,t:1527019844298};\\\", \\\"{x:507,y:711,t:1527019844314};\\\", \\\"{x:512,y:699,t:1527019844331};\\\", \\\"{x:537,y:681,t:1527019844348};\\\", \\\"{x:562,y:663,t:1527019844364};\\\", \\\"{x:585,y:647,t:1527019844382};\\\", \\\"{x:605,y:632,t:1527019844399};\\\", \\\"{x:631,y:611,t:1527019844414};\\\", \\\"{x:679,y:585,t:1527019844431};\\\", \\\"{x:694,y:574,t:1527019844447};\\\", \\\"{x:701,y:570,t:1527019844464};\\\" ] }, { \\\"rt\\\": 53595, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 523202, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -F -B -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:697,y:567,t:1527019845752};\\\", \\\"{x:673,y:558,t:1527019845767};\\\", \\\"{x:647,y:545,t:1527019845785};\\\", \\\"{x:626,y:529,t:1527019845799};\\\", \\\"{x:604,y:515,t:1527019845815};\\\", \\\"{x:589,y:504,t:1527019845833};\\\", \\\"{x:578,y:495,t:1527019845849};\\\", \\\"{x:567,y:488,t:1527019845865};\\\", \\\"{x:554,y:470,t:1527019845883};\\\", \\\"{x:542,y:456,t:1527019845899};\\\", \\\"{x:527,y:445,t:1527019845915};\\\", \\\"{x:523,y:442,t:1527019845932};\\\", \\\"{x:520,y:442,t:1527019845967};\\\", \\\"{x:519,y:442,t:1527019845983};\\\", \\\"{x:508,y:444,t:1527019845999};\\\", \\\"{x:495,y:450,t:1527019846015};\\\", \\\"{x:483,y:457,t:1527019846032};\\\", \\\"{x:466,y:459,t:1527019846049};\\\", \\\"{x:457,y:461,t:1527019846067};\\\", \\\"{x:448,y:462,t:1527019846082};\\\", \\\"{x:441,y:462,t:1527019846099};\\\", \\\"{x:440,y:461,t:1527019846117};\\\", \\\"{x:437,y:460,t:1527019846132};\\\", \\\"{x:435,y:459,t:1527019846150};\\\", \\\"{x:434,y:459,t:1527019846167};\\\", \\\"{x:433,y:459,t:1527019846182};\\\", \\\"{x:429,y:459,t:1527019846200};\\\", \\\"{x:427,y:459,t:1527019846216};\\\", \\\"{x:428,y:459,t:1527019847623};\\\", \\\"{x:431,y:459,t:1527019847635};\\\", \\\"{x:438,y:459,t:1527019847651};\\\", \\\"{x:443,y:459,t:1527019847667};\\\", \\\"{x:446,y:459,t:1527019847685};\\\", \\\"{x:452,y:459,t:1527019847700};\\\", \\\"{x:458,y:459,t:1527019847718};\\\", \\\"{x:462,y:459,t:1527019847734};\\\", \\\"{x:470,y:458,t:1527019847750};\\\", \\\"{x:475,y:457,t:1527019847767};\\\", \\\"{x:481,y:457,t:1527019847784};\\\", \\\"{x:490,y:452,t:1527019847801};\\\", \\\"{x:501,y:447,t:1527019847818};\\\", \\\"{x:513,y:440,t:1527019847836};\\\", \\\"{x:528,y:431,t:1527019847851};\\\", \\\"{x:543,y:422,t:1527019847867};\\\", \\\"{x:559,y:414,t:1527019847885};\\\", \\\"{x:581,y:405,t:1527019847901};\\\", \\\"{x:597,y:396,t:1527019847918};\\\", \\\"{x:617,y:386,t:1527019847935};\\\", \\\"{x:630,y:380,t:1527019847950};\\\", \\\"{x:664,y:368,t:1527019847967};\\\", \\\"{x:687,y:361,t:1527019847984};\\\", \\\"{x:717,y:355,t:1527019848002};\\\", \\\"{x:755,y:355,t:1527019848017};\\\", \\\"{x:804,y:355,t:1527019848035};\\\", \\\"{x:865,y:355,t:1527019848052};\\\", \\\"{x:920,y:367,t:1527019848067};\\\", \\\"{x:968,y:382,t:1527019848085};\\\", \\\"{x:1008,y:397,t:1527019848102};\\\", \\\"{x:1066,y:413,t:1527019848118};\\\", \\\"{x:1102,y:426,t:1527019848135};\\\", \\\"{x:1142,y:439,t:1527019848152};\\\", \\\"{x:1159,y:443,t:1527019848168};\\\", \\\"{x:1177,y:450,t:1527019848185};\\\", \\\"{x:1186,y:451,t:1527019848202};\\\", \\\"{x:1187,y:451,t:1527019848218};\\\", \\\"{x:1188,y:451,t:1527019848328};\\\", \\\"{x:1188,y:457,t:1527019848335};\\\", \\\"{x:1189,y:466,t:1527019848352};\\\", \\\"{x:1189,y:484,t:1527019848367};\\\", \\\"{x:1189,y:495,t:1527019848385};\\\", \\\"{x:1188,y:504,t:1527019848401};\\\", \\\"{x:1185,y:510,t:1527019848419};\\\", \\\"{x:1179,y:516,t:1527019848435};\\\", \\\"{x:1171,y:520,t:1527019848452};\\\", \\\"{x:1167,y:522,t:1527019848469};\\\", \\\"{x:1164,y:522,t:1527019848485};\\\", \\\"{x:1160,y:522,t:1527019848502};\\\", \\\"{x:1158,y:522,t:1527019848519};\\\", \\\"{x:1156,y:520,t:1527019848535};\\\", \\\"{x:1156,y:519,t:1527019848552};\\\", \\\"{x:1155,y:518,t:1527019848568};\\\", \\\"{x:1154,y:516,t:1527019848585};\\\", \\\"{x:1153,y:516,t:1527019848641};\\\", \\\"{x:1152,y:516,t:1527019848652};\\\", \\\"{x:1151,y:515,t:1527019848913};\\\", \\\"{x:1151,y:514,t:1527019848952};\\\", \\\"{x:1150,y:513,t:1527019848968};\\\", \\\"{x:1149,y:513,t:1527019849080};\\\", \\\"{x:1149,y:518,t:1527019849784};\\\", \\\"{x:1149,y:525,t:1527019849792};\\\", \\\"{x:1149,y:527,t:1527019849803};\\\", \\\"{x:1149,y:533,t:1527019849820};\\\", \\\"{x:1150,y:535,t:1527019849837};\\\", \\\"{x:1152,y:537,t:1527019849853};\\\", \\\"{x:1155,y:538,t:1527019849870};\\\", \\\"{x:1159,y:541,t:1527019849887};\\\", \\\"{x:1162,y:544,t:1527019849903};\\\", \\\"{x:1169,y:547,t:1527019849920};\\\", \\\"{x:1171,y:549,t:1527019849936};\\\", \\\"{x:1176,y:549,t:1527019849954};\\\", \\\"{x:1179,y:551,t:1527019849970};\\\", \\\"{x:1181,y:551,t:1527019849986};\\\", \\\"{x:1182,y:551,t:1527019850003};\\\", \\\"{x:1185,y:552,t:1527019850020};\\\", \\\"{x:1186,y:552,t:1527019850036};\\\", \\\"{x:1189,y:552,t:1527019850053};\\\", \\\"{x:1190,y:550,t:1527019850071};\\\", \\\"{x:1191,y:550,t:1527019850088};\\\", \\\"{x:1192,y:550,t:1527019850103};\\\", \\\"{x:1193,y:549,t:1527019850144};\\\", \\\"{x:1196,y:545,t:1527019850417};\\\", \\\"{x:1197,y:540,t:1527019850424};\\\", \\\"{x:1199,y:538,t:1527019850437};\\\", \\\"{x:1205,y:527,t:1527019850454};\\\", \\\"{x:1210,y:516,t:1527019850471};\\\", \\\"{x:1215,y:509,t:1527019850488};\\\", \\\"{x:1219,y:505,t:1527019850512};\\\", \\\"{x:1221,y:505,t:1527019850520};\\\", \\\"{x:1225,y:505,t:1527019850537};\\\", \\\"{x:1227,y:503,t:1527019850555};\\\", \\\"{x:1231,y:499,t:1527019850570};\\\", \\\"{x:1233,y:496,t:1527019850588};\\\", \\\"{x:1236,y:493,t:1527019850604};\\\", \\\"{x:1239,y:491,t:1527019850620};\\\", \\\"{x:1241,y:489,t:1527019850637};\\\", \\\"{x:1242,y:489,t:1527019850654};\\\", \\\"{x:1244,y:487,t:1527019850671};\\\", \\\"{x:1245,y:487,t:1527019850737};\\\", \\\"{x:1246,y:487,t:1527019851529};\\\", \\\"{x:1247,y:487,t:1527019851538};\\\", \\\"{x:1249,y:494,t:1527019851554};\\\", \\\"{x:1249,y:501,t:1527019851571};\\\", \\\"{x:1247,y:511,t:1527019851588};\\\", \\\"{x:1242,y:524,t:1527019851604};\\\", \\\"{x:1239,y:536,t:1527019851621};\\\", \\\"{x:1237,y:550,t:1527019851638};\\\", \\\"{x:1234,y:560,t:1527019851655};\\\", \\\"{x:1233,y:569,t:1527019851672};\\\", \\\"{x:1232,y:574,t:1527019851688};\\\", \\\"{x:1232,y:575,t:1527019851705};\\\", \\\"{x:1232,y:579,t:1527019853377};\\\", \\\"{x:1239,y:591,t:1527019853390};\\\", \\\"{x:1250,y:614,t:1527019853407};\\\", \\\"{x:1259,y:632,t:1527019853424};\\\", \\\"{x:1271,y:649,t:1527019853439};\\\", \\\"{x:1295,y:669,t:1527019853456};\\\", \\\"{x:1303,y:677,t:1527019853474};\\\", \\\"{x:1309,y:682,t:1527019853490};\\\", \\\"{x:1314,y:686,t:1527019853507};\\\", \\\"{x:1316,y:689,t:1527019853523};\\\", \\\"{x:1318,y:689,t:1527019853539};\\\", \\\"{x:1318,y:690,t:1527019853557};\\\", \\\"{x:1320,y:691,t:1527019853573};\\\", \\\"{x:1320,y:692,t:1527019853589};\\\", \\\"{x:1322,y:697,t:1527019853606};\\\", \\\"{x:1324,y:704,t:1527019853624};\\\", \\\"{x:1326,y:712,t:1527019853640};\\\", \\\"{x:1335,y:733,t:1527019853656};\\\", \\\"{x:1343,y:750,t:1527019853674};\\\", \\\"{x:1352,y:767,t:1527019853693};\\\", \\\"{x:1358,y:782,t:1527019853706};\\\", \\\"{x:1366,y:794,t:1527019853723};\\\", \\\"{x:1373,y:802,t:1527019853740};\\\", \\\"{x:1374,y:804,t:1527019853755};\\\", \\\"{x:1375,y:804,t:1527019853773};\\\", \\\"{x:1376,y:804,t:1527019853848};\\\", \\\"{x:1377,y:804,t:1527019853855};\\\", \\\"{x:1379,y:804,t:1527019853880};\\\", \\\"{x:1379,y:803,t:1527019853920};\\\", \\\"{x:1379,y:802,t:1527019853928};\\\", \\\"{x:1379,y:801,t:1527019853943};\\\", \\\"{x:1381,y:800,t:1527019853956};\\\", \\\"{x:1381,y:799,t:1527019853973};\\\", \\\"{x:1381,y:797,t:1527019853990};\\\", \\\"{x:1382,y:796,t:1527019854006};\\\", \\\"{x:1382,y:795,t:1527019854023};\\\", \\\"{x:1382,y:793,t:1527019854041};\\\", \\\"{x:1382,y:792,t:1527019854056};\\\", \\\"{x:1384,y:789,t:1527019854073};\\\", \\\"{x:1385,y:787,t:1527019854090};\\\", \\\"{x:1386,y:785,t:1527019854106};\\\", \\\"{x:1387,y:785,t:1527019854123};\\\", \\\"{x:1387,y:784,t:1527019854152};\\\", \\\"{x:1387,y:783,t:1527019854529};\\\", \\\"{x:1387,y:782,t:1527019854540};\\\", \\\"{x:1387,y:781,t:1527019854584};\\\", \\\"{x:1387,y:779,t:1527019854769};\\\", \\\"{x:1387,y:778,t:1527019854776};\\\", \\\"{x:1387,y:777,t:1527019854808};\\\", \\\"{x:1386,y:776,t:1527019854913};\\\", \\\"{x:1377,y:773,t:1527019854925};\\\", \\\"{x:1296,y:756,t:1527019854941};\\\", \\\"{x:1169,y:718,t:1527019854957};\\\", \\\"{x:1094,y:682,t:1527019854975};\\\", \\\"{x:1084,y:673,t:1527019854991};\\\", \\\"{x:1083,y:672,t:1527019855011};\\\", \\\"{x:1083,y:670,t:1527019855163};\\\", \\\"{x:1085,y:669,t:1527019855178};\\\", \\\"{x:1097,y:663,t:1527019855195};\\\", \\\"{x:1105,y:660,t:1527019855210};\\\", \\\"{x:1115,y:655,t:1527019855228};\\\", \\\"{x:1125,y:657,t:1527019855244};\\\", \\\"{x:1149,y:673,t:1527019855260};\\\", \\\"{x:1192,y:694,t:1527019855278};\\\", \\\"{x:1226,y:710,t:1527019855294};\\\", \\\"{x:1252,y:720,t:1527019855311};\\\", \\\"{x:1277,y:728,t:1527019855328};\\\", \\\"{x:1296,y:733,t:1527019855344};\\\", \\\"{x:1311,y:739,t:1527019855361};\\\", \\\"{x:1316,y:742,t:1527019855378};\\\", \\\"{x:1318,y:742,t:1527019855395};\\\", \\\"{x:1318,y:743,t:1527019855443};\\\", \\\"{x:1318,y:745,t:1527019855451};\\\", \\\"{x:1318,y:746,t:1527019855462};\\\", \\\"{x:1318,y:747,t:1527019855515};\\\", \\\"{x:1314,y:747,t:1527019855528};\\\", \\\"{x:1313,y:748,t:1527019855545};\\\", \\\"{x:1311,y:749,t:1527019855562};\\\", \\\"{x:1314,y:748,t:1527019855813};\\\", \\\"{x:1323,y:744,t:1527019855828};\\\", \\\"{x:1330,y:739,t:1527019855845};\\\", \\\"{x:1338,y:736,t:1527019855863};\\\", \\\"{x:1346,y:735,t:1527019855879};\\\", \\\"{x:1354,y:734,t:1527019855896};\\\", \\\"{x:1356,y:734,t:1527019855912};\\\", \\\"{x:1358,y:734,t:1527019855929};\\\", \\\"{x:1359,y:734,t:1527019855963};\\\", \\\"{x:1359,y:736,t:1527019856180};\\\", \\\"{x:1360,y:742,t:1527019856196};\\\", \\\"{x:1361,y:746,t:1527019856212};\\\", \\\"{x:1362,y:752,t:1527019856229};\\\", \\\"{x:1364,y:759,t:1527019856246};\\\", \\\"{x:1364,y:765,t:1527019856262};\\\", \\\"{x:1364,y:768,t:1527019856280};\\\", \\\"{x:1363,y:768,t:1527019856596};\\\", \\\"{x:1361,y:767,t:1527019856612};\\\", \\\"{x:1360,y:766,t:1527019856629};\\\", \\\"{x:1359,y:766,t:1527019856646};\\\", \\\"{x:1358,y:765,t:1527019856684};\\\", \\\"{x:1358,y:764,t:1527019856716};\\\", \\\"{x:1356,y:762,t:1527019862732};\\\", \\\"{x:1347,y:751,t:1527019862739};\\\", \\\"{x:1329,y:728,t:1527019862751};\\\", \\\"{x:1293,y:685,t:1527019862767};\\\", \\\"{x:1264,y:652,t:1527019862784};\\\", \\\"{x:1238,y:628,t:1527019862801};\\\", \\\"{x:1226,y:617,t:1527019862818};\\\", \\\"{x:1223,y:615,t:1527019862834};\\\", \\\"{x:1225,y:616,t:1527019863956};\\\", \\\"{x:1228,y:618,t:1527019863969};\\\", \\\"{x:1232,y:622,t:1527019863986};\\\", \\\"{x:1235,y:625,t:1527019864002};\\\", \\\"{x:1236,y:627,t:1527019864020};\\\", \\\"{x:1237,y:627,t:1527019864043};\\\", \\\"{x:1238,y:629,t:1527019864052};\\\", \\\"{x:1240,y:631,t:1527019864070};\\\", \\\"{x:1243,y:634,t:1527019864085};\\\", \\\"{x:1245,y:635,t:1527019864103};\\\", \\\"{x:1246,y:635,t:1527019864119};\\\", \\\"{x:1247,y:636,t:1527019864135};\\\", \\\"{x:1248,y:637,t:1527019864152};\\\", \\\"{x:1249,y:638,t:1527019864170};\\\", \\\"{x:1251,y:639,t:1527019864186};\\\", \\\"{x:1252,y:640,t:1527019864203};\\\", \\\"{x:1255,y:643,t:1527019864219};\\\", \\\"{x:1257,y:645,t:1527019864260};\\\", \\\"{x:1260,y:647,t:1527019864270};\\\", \\\"{x:1267,y:652,t:1527019864286};\\\", \\\"{x:1276,y:657,t:1527019864302};\\\", \\\"{x:1284,y:663,t:1527019864319};\\\", \\\"{x:1288,y:666,t:1527019864336};\\\", \\\"{x:1291,y:668,t:1527019864352};\\\", \\\"{x:1293,y:669,t:1527019864369};\\\", \\\"{x:1295,y:669,t:1527019864386};\\\", \\\"{x:1298,y:671,t:1527019864403};\\\", \\\"{x:1307,y:677,t:1527019864420};\\\", \\\"{x:1313,y:681,t:1527019864436};\\\", \\\"{x:1317,y:684,t:1527019864453};\\\", \\\"{x:1318,y:685,t:1527019864470};\\\", \\\"{x:1321,y:688,t:1527019864486};\\\", \\\"{x:1323,y:689,t:1527019864502};\\\", \\\"{x:1325,y:690,t:1527019864519};\\\", \\\"{x:1327,y:691,t:1527019864537};\\\", \\\"{x:1329,y:692,t:1527019864553};\\\", \\\"{x:1330,y:692,t:1527019864580};\\\", \\\"{x:1331,y:693,t:1527019864628};\\\", \\\"{x:1332,y:694,t:1527019864708};\\\", \\\"{x:1337,y:695,t:1527019864720};\\\", \\\"{x:1345,y:699,t:1527019864737};\\\", \\\"{x:1352,y:702,t:1527019864754};\\\", \\\"{x:1358,y:704,t:1527019864770};\\\", \\\"{x:1361,y:705,t:1527019864787};\\\", \\\"{x:1363,y:706,t:1527019864803};\\\", \\\"{x:1364,y:707,t:1527019864819};\\\", \\\"{x:1365,y:707,t:1527019864837};\\\", \\\"{x:1365,y:709,t:1527019865060};\\\", \\\"{x:1363,y:714,t:1527019865069};\\\", \\\"{x:1361,y:718,t:1527019865087};\\\", \\\"{x:1359,y:722,t:1527019865103};\\\", \\\"{x:1357,y:725,t:1527019865119};\\\", \\\"{x:1356,y:726,t:1527019865135};\\\", \\\"{x:1356,y:728,t:1527019865171};\\\", \\\"{x:1354,y:730,t:1527019865186};\\\", \\\"{x:1353,y:733,t:1527019865202};\\\", \\\"{x:1351,y:737,t:1527019865219};\\\", \\\"{x:1350,y:739,t:1527019865236};\\\", \\\"{x:1349,y:740,t:1527019865253};\\\", \\\"{x:1349,y:743,t:1527019865270};\\\", \\\"{x:1348,y:745,t:1527019865290};\\\", \\\"{x:1348,y:746,t:1527019865314};\\\", \\\"{x:1347,y:748,t:1527019872067};\\\", \\\"{x:1347,y:749,t:1527019872083};\\\", \\\"{x:1346,y:750,t:1527019872099};\\\", \\\"{x:1347,y:749,t:1527019872516};\\\", \\\"{x:1348,y:744,t:1527019872526};\\\", \\\"{x:1349,y:731,t:1527019872543};\\\", \\\"{x:1353,y:720,t:1527019872560};\\\", \\\"{x:1354,y:709,t:1527019872576};\\\", \\\"{x:1357,y:700,t:1527019872593};\\\", \\\"{x:1357,y:692,t:1527019872610};\\\", \\\"{x:1357,y:688,t:1527019872627};\\\", \\\"{x:1357,y:686,t:1527019872643};\\\", \\\"{x:1357,y:683,t:1527019872659};\\\", \\\"{x:1357,y:682,t:1527019872677};\\\", \\\"{x:1357,y:676,t:1527019872693};\\\", \\\"{x:1358,y:671,t:1527019872710};\\\", \\\"{x:1358,y:667,t:1527019872727};\\\", \\\"{x:1358,y:664,t:1527019872743};\\\", \\\"{x:1358,y:662,t:1527019872759};\\\", \\\"{x:1358,y:661,t:1527019872786};\\\", \\\"{x:1358,y:658,t:1527019872819};\\\", \\\"{x:1358,y:657,t:1527019872866};\\\", \\\"{x:1358,y:656,t:1527019873828};\\\", \\\"{x:1355,y:656,t:1527019874420};\\\", \\\"{x:1350,y:656,t:1527019874428};\\\", \\\"{x:1349,y:656,t:1527019874445};\\\", \\\"{x:1349,y:654,t:1527019874484};\\\", \\\"{x:1349,y:650,t:1527019874495};\\\", \\\"{x:1343,y:641,t:1527019874511};\\\", \\\"{x:1338,y:633,t:1527019874528};\\\", \\\"{x:1337,y:631,t:1527019874545};\\\", \\\"{x:1336,y:629,t:1527019874561};\\\", \\\"{x:1335,y:628,t:1527019874578};\\\", \\\"{x:1334,y:626,t:1527019874595};\\\", \\\"{x:1330,y:620,t:1527019874611};\\\", \\\"{x:1328,y:618,t:1527019874628};\\\", \\\"{x:1321,y:608,t:1527019874644};\\\", \\\"{x:1314,y:591,t:1527019874661};\\\", \\\"{x:1306,y:581,t:1527019874678};\\\", \\\"{x:1296,y:567,t:1527019874695};\\\", \\\"{x:1283,y:552,t:1527019874712};\\\", \\\"{x:1282,y:545,t:1527019874728};\\\", \\\"{x:1278,y:539,t:1527019874745};\\\", \\\"{x:1277,y:538,t:1527019874761};\\\", \\\"{x:1276,y:538,t:1527019874778};\\\", \\\"{x:1275,y:539,t:1527019874947};\\\", \\\"{x:1275,y:540,t:1527019874988};\\\", \\\"{x:1275,y:542,t:1527019875060};\\\", \\\"{x:1276,y:545,t:1527019875068};\\\", \\\"{x:1276,y:546,t:1527019875079};\\\", \\\"{x:1277,y:551,t:1527019875094};\\\", \\\"{x:1278,y:555,t:1527019875111};\\\", \\\"{x:1278,y:560,t:1527019875129};\\\", \\\"{x:1279,y:565,t:1527019875145};\\\", \\\"{x:1280,y:565,t:1527019875160};\\\", \\\"{x:1280,y:568,t:1527019875179};\\\", \\\"{x:1281,y:568,t:1527019875218};\\\", \\\"{x:1285,y:554,t:1527019895653};\\\", \\\"{x:1287,y:534,t:1527019895663};\\\", \\\"{x:1293,y:501,t:1527019895679};\\\", \\\"{x:1293,y:480,t:1527019895696};\\\", \\\"{x:1296,y:473,t:1527019895713};\\\", \\\"{x:1296,y:472,t:1527019895730};\\\", \\\"{x:1291,y:481,t:1527019895868};\\\", \\\"{x:1288,y:491,t:1527019895880};\\\", \\\"{x:1275,y:505,t:1527019895897};\\\", \\\"{x:1264,y:519,t:1527019895912};\\\", \\\"{x:1249,y:534,t:1527019895930};\\\", \\\"{x:1232,y:550,t:1527019895947};\\\", \\\"{x:1222,y:558,t:1527019895963};\\\", \\\"{x:1201,y:571,t:1527019895980};\\\", \\\"{x:1176,y:584,t:1527019895997};\\\", \\\"{x:1152,y:590,t:1527019896013};\\\", \\\"{x:1113,y:593,t:1527019896030};\\\", \\\"{x:1095,y:595,t:1527019896047};\\\", \\\"{x:1038,y:584,t:1527019896063};\\\", \\\"{x:993,y:569,t:1527019896081};\\\", \\\"{x:959,y:558,t:1527019896097};\\\", \\\"{x:942,y:557,t:1527019896113};\\\", \\\"{x:939,y:557,t:1527019896129};\\\", \\\"{x:933,y:557,t:1527019896147};\\\", \\\"{x:931,y:558,t:1527019896163};\\\", \\\"{x:929,y:559,t:1527019896179};\\\", \\\"{x:928,y:560,t:1527019896211};\\\", \\\"{x:927,y:560,t:1527019896227};\\\", \\\"{x:926,y:561,t:1527019896251};\\\", \\\"{x:924,y:561,t:1527019896275};\\\", \\\"{x:923,y:562,t:1527019896315};\\\", \\\"{x:922,y:562,t:1527019896331};\\\", \\\"{x:922,y:563,t:1527019896348};\\\", \\\"{x:921,y:563,t:1527019896369};\\\", \\\"{x:919,y:563,t:1527019896450};\\\", \\\"{x:918,y:564,t:1527019896490};\\\", \\\"{x:916,y:566,t:1527019896503};\\\", \\\"{x:910,y:570,t:1527019896520};\\\", \\\"{x:901,y:574,t:1527019896536};\\\", \\\"{x:892,y:579,t:1527019896553};\\\", \\\"{x:880,y:588,t:1527019896571};\\\", \\\"{x:869,y:596,t:1527019896587};\\\", \\\"{x:857,y:600,t:1527019896603};\\\", \\\"{x:831,y:613,t:1527019896630};\\\", \\\"{x:814,y:621,t:1527019896645};\\\", \\\"{x:792,y:632,t:1527019896662};\\\", \\\"{x:771,y:646,t:1527019896679};\\\", \\\"{x:748,y:654,t:1527019896695};\\\", \\\"{x:733,y:666,t:1527019896712};\\\", \\\"{x:717,y:673,t:1527019896728};\\\", \\\"{x:710,y:676,t:1527019896745};\\\", \\\"{x:705,y:679,t:1527019896761};\\\", \\\"{x:698,y:684,t:1527019896778};\\\", \\\"{x:691,y:688,t:1527019896795};\\\", \\\"{x:680,y:697,t:1527019896811};\\\", \\\"{x:667,y:703,t:1527019896828};\\\", \\\"{x:653,y:710,t:1527019896845};\\\", \\\"{x:649,y:713,t:1527019896861};\\\", \\\"{x:646,y:715,t:1527019896878};\\\", \\\"{x:640,y:715,t:1527019896895};\\\", \\\"{x:637,y:715,t:1527019896911};\\\", \\\"{x:632,y:715,t:1527019896928};\\\", \\\"{x:624,y:714,t:1527019896945};\\\", \\\"{x:623,y:714,t:1527019896962};\\\", \\\"{x:623,y:712,t:1527019896987};\\\", \\\"{x:619,y:710,t:1527019896996};\\\", \\\"{x:609,y:704,t:1527019897012};\\\", \\\"{x:592,y:693,t:1527019897028};\\\", \\\"{x:559,y:676,t:1527019897045};\\\", \\\"{x:543,y:666,t:1527019897062};\\\", \\\"{x:519,y:659,t:1527019897078};\\\", \\\"{x:501,y:651,t:1527019897095};\\\", \\\"{x:493,y:649,t:1527019897113};\\\", \\\"{x:488,y:646,t:1527019897129};\\\", \\\"{x:485,y:645,t:1527019897145};\\\", \\\"{x:482,y:643,t:1527019897161};\\\", \\\"{x:480,y:642,t:1527019897179};\\\", \\\"{x:468,y:637,t:1527019897196};\\\", \\\"{x:448,y:631,t:1527019897212};\\\", \\\"{x:436,y:625,t:1527019897229};\\\", \\\"{x:428,y:621,t:1527019897245};\\\", \\\"{x:422,y:616,t:1527019897262};\\\", \\\"{x:412,y:608,t:1527019897278};\\\", \\\"{x:410,y:603,t:1527019897296};\\\", \\\"{x:409,y:599,t:1527019897312};\\\", \\\"{x:409,y:585,t:1527019897329};\\\", \\\"{x:425,y:567,t:1527019897345};\\\", \\\"{x:456,y:545,t:1527019897363};\\\", \\\"{x:475,y:532,t:1527019897378};\\\", \\\"{x:491,y:524,t:1527019897395};\\\", \\\"{x:505,y:519,t:1527019897412};\\\", \\\"{x:520,y:510,t:1527019897430};\\\", \\\"{x:538,y:503,t:1527019897445};\\\", \\\"{x:549,y:495,t:1527019897462};\\\", \\\"{x:565,y:487,t:1527019897479};\\\", \\\"{x:576,y:482,t:1527019897496};\\\", \\\"{x:590,y:474,t:1527019897513};\\\", \\\"{x:592,y:473,t:1527019897529};\\\", \\\"{x:597,y:471,t:1527019897545};\\\", \\\"{x:599,y:469,t:1527019897562};\\\", \\\"{x:601,y:468,t:1527019897580};\\\", \\\"{x:602,y:467,t:1527019897596};\\\", \\\"{x:604,y:467,t:1527019897659};\\\", \\\"{x:607,y:470,t:1527019897667};\\\", \\\"{x:608,y:472,t:1527019897680};\\\", \\\"{x:611,y:479,t:1527019897696};\\\", \\\"{x:613,y:483,t:1527019897713};\\\", \\\"{x:615,y:487,t:1527019897731};\\\", \\\"{x:616,y:491,t:1527019897746};\\\", \\\"{x:618,y:492,t:1527019897762};\\\", \\\"{x:618,y:494,t:1527019897803};\\\", \\\"{x:618,y:495,t:1527019897812};\\\", \\\"{x:618,y:498,t:1527019897829};\\\", \\\"{x:619,y:501,t:1527019897845};\\\", \\\"{x:619,y:502,t:1527019897863};\\\", \\\"{x:619,y:505,t:1527019898186};\\\", \\\"{x:619,y:506,t:1527019898202};\\\", \\\"{x:619,y:508,t:1527019898214};\\\", \\\"{x:614,y:521,t:1527019898230};\\\", \\\"{x:607,y:539,t:1527019898247};\\\", \\\"{x:597,y:562,t:1527019898263};\\\", \\\"{x:588,y:588,t:1527019898280};\\\", \\\"{x:579,y:607,t:1527019898298};\\\", \\\"{x:568,y:620,t:1527019898313};\\\", \\\"{x:558,y:628,t:1527019898329};\\\", \\\"{x:548,y:642,t:1527019898347};\\\", \\\"{x:544,y:646,t:1527019898364};\\\", \\\"{x:540,y:651,t:1527019898379};\\\", \\\"{x:528,y:659,t:1527019898396};\\\", \\\"{x:517,y:667,t:1527019898413};\\\", \\\"{x:502,y:678,t:1527019898429};\\\", \\\"{x:492,y:688,t:1527019898447};\\\", \\\"{x:486,y:696,t:1527019898463};\\\", \\\"{x:481,y:701,t:1527019898479};\\\", \\\"{x:476,y:706,t:1527019898496};\\\", \\\"{x:472,y:712,t:1527019898513};\\\", \\\"{x:469,y:720,t:1527019898531};\\\", \\\"{x:464,y:727,t:1527019898546};\\\", \\\"{x:462,y:731,t:1527019898563};\\\", \\\"{x:459,y:733,t:1527019898580};\\\", \\\"{x:457,y:735,t:1527019898596};\\\", \\\"{x:457,y:737,t:1527019898613};\\\", \\\"{x:457,y:738,t:1527019898630};\\\", \\\"{x:457,y:742,t:1527019898646};\\\", \\\"{x:457,y:744,t:1527019898663};\\\", \\\"{x:457,y:745,t:1527019898827};\\\", \\\"{x:457,y:745,t:1527019898866};\\\", \\\"{x:458,y:745,t:1527019898930};\\\", \\\"{x:459,y:745,t:1527019899050};\\\", \\\"{x:461,y:745,t:1527019899083};\\\", \\\"{x:462,y:745,t:1527019899096};\\\", \\\"{x:465,y:745,t:1527019899114};\\\", \\\"{x:470,y:745,t:1527019899131};\\\", \\\"{x:475,y:745,t:1527019899147};\\\", \\\"{x:479,y:745,t:1527019899163};\\\", \\\"{x:482,y:745,t:1527019899180};\\\", \\\"{x:483,y:745,t:1527019899203};\\\", \\\"{x:484,y:745,t:1527019899243};\\\", \\\"{x:486,y:745,t:1527019899435};\\\", \\\"{x:487,y:745,t:1527019899635};\\\", \\\"{x:488,y:745,t:1527019899659};\\\", \\\"{x:489,y:745,t:1527019899739};\\\" ] }, { \\\"rt\\\": 38650, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 563060, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:745,t:1527019900194};\\\", \\\"{x:491,y:745,t:1527019900547};\\\", \\\"{x:492,y:745,t:1527019900570};\\\", \\\"{x:492,y:744,t:1527019900586};\\\", \\\"{x:492,y:743,t:1527019900611};\\\", \\\"{x:493,y:723,t:1527019900680};\\\", \\\"{x:491,y:719,t:1527019900684};\\\", \\\"{x:486,y:708,t:1527019900698};\\\", \\\"{x:485,y:702,t:1527019900715};\\\", \\\"{x:482,y:690,t:1527019900732};\\\", \\\"{x:479,y:672,t:1527019900748};\\\", \\\"{x:474,y:646,t:1527019900764};\\\", \\\"{x:470,y:604,t:1527019900782};\\\", \\\"{x:466,y:566,t:1527019900799};\\\", \\\"{x:458,y:539,t:1527019900815};\\\", \\\"{x:455,y:518,t:1527019900832};\\\", \\\"{x:453,y:504,t:1527019900849};\\\", \\\"{x:452,y:500,t:1527019900866};\\\", \\\"{x:452,y:497,t:1527019900881};\\\", \\\"{x:451,y:496,t:1527019900898};\\\", \\\"{x:451,y:494,t:1527019900946};\\\", \\\"{x:451,y:492,t:1527019900954};\\\", \\\"{x:451,y:489,t:1527019900966};\\\", \\\"{x:451,y:486,t:1527019900982};\\\", \\\"{x:451,y:484,t:1527019900998};\\\", \\\"{x:451,y:482,t:1527019901016};\\\", \\\"{x:451,y:480,t:1527019901031};\\\", \\\"{x:451,y:478,t:1527019901048};\\\", \\\"{x:451,y:476,t:1527019901066};\\\", \\\"{x:452,y:473,t:1527019901082};\\\", \\\"{x:453,y:467,t:1527019901098};\\\", \\\"{x:457,y:461,t:1527019901115};\\\", \\\"{x:458,y:455,t:1527019901132};\\\", \\\"{x:462,y:448,t:1527019901148};\\\", \\\"{x:465,y:443,t:1527019901166};\\\", \\\"{x:467,y:440,t:1527019901182};\\\", \\\"{x:468,y:439,t:1527019901199};\\\", \\\"{x:469,y:439,t:1527019902556};\\\", \\\"{x:469,y:442,t:1527019902571};\\\", \\\"{x:471,y:445,t:1527019902583};\\\", \\\"{x:471,y:449,t:1527019902600};\\\", \\\"{x:472,y:452,t:1527019902616};\\\", \\\"{x:475,y:452,t:1527019903044};\\\", \\\"{x:477,y:452,t:1527019903051};\\\", \\\"{x:484,y:452,t:1527019903066};\\\", \\\"{x:489,y:452,t:1527019903084};\\\", \\\"{x:491,y:450,t:1527019903100};\\\", \\\"{x:496,y:450,t:1527019903117};\\\", \\\"{x:498,y:450,t:1527019903134};\\\", \\\"{x:503,y:450,t:1527019903150};\\\", \\\"{x:514,y:450,t:1527019903167};\\\", \\\"{x:524,y:450,t:1527019903184};\\\", \\\"{x:538,y:451,t:1527019903200};\\\", \\\"{x:553,y:453,t:1527019903217};\\\", \\\"{x:563,y:454,t:1527019903235};\\\", \\\"{x:570,y:455,t:1527019903251};\\\", \\\"{x:581,y:455,t:1527019903267};\\\", \\\"{x:586,y:456,t:1527019903283};\\\", \\\"{x:592,y:460,t:1527019903300};\\\", \\\"{x:602,y:463,t:1527019903317};\\\", \\\"{x:612,y:465,t:1527019903333};\\\", \\\"{x:620,y:468,t:1527019903350};\\\", \\\"{x:633,y:471,t:1527019903366};\\\", \\\"{x:646,y:473,t:1527019903383};\\\", \\\"{x:658,y:477,t:1527019903401};\\\", \\\"{x:670,y:479,t:1527019903416};\\\", \\\"{x:677,y:482,t:1527019903433};\\\", \\\"{x:702,y:489,t:1527019903451};\\\", \\\"{x:721,y:492,t:1527019903466};\\\", \\\"{x:734,y:493,t:1527019903484};\\\", \\\"{x:753,y:494,t:1527019903500};\\\", \\\"{x:774,y:501,t:1527019903517};\\\", \\\"{x:795,y:501,t:1527019903532};\\\", \\\"{x:814,y:501,t:1527019903549};\\\", \\\"{x:829,y:501,t:1527019903567};\\\", \\\"{x:844,y:501,t:1527019903583};\\\", \\\"{x:863,y:501,t:1527019903601};\\\", \\\"{x:880,y:501,t:1527019903618};\\\", \\\"{x:893,y:501,t:1527019903633};\\\", \\\"{x:932,y:501,t:1527019903651};\\\", \\\"{x:971,y:503,t:1527019903668};\\\", \\\"{x:1002,y:509,t:1527019903684};\\\", \\\"{x:1027,y:521,t:1527019903700};\\\", \\\"{x:1046,y:528,t:1527019903718};\\\", \\\"{x:1074,y:529,t:1527019903733};\\\", \\\"{x:1106,y:538,t:1527019903750};\\\", \\\"{x:1132,y:547,t:1527019903768};\\\", \\\"{x:1154,y:555,t:1527019903784};\\\", \\\"{x:1179,y:564,t:1527019903801};\\\", \\\"{x:1199,y:568,t:1527019903818};\\\", \\\"{x:1209,y:571,t:1527019903834};\\\", \\\"{x:1216,y:573,t:1527019903850};\\\", \\\"{x:1217,y:573,t:1527019903875};\\\", \\\"{x:1218,y:574,t:1527019903996};\\\", \\\"{x:1223,y:576,t:1527019904003};\\\", \\\"{x:1225,y:577,t:1527019904019};\\\", \\\"{x:1234,y:584,t:1527019904035};\\\", \\\"{x:1247,y:588,t:1527019904051};\\\", \\\"{x:1255,y:591,t:1527019904068};\\\", \\\"{x:1263,y:595,t:1527019904084};\\\", \\\"{x:1274,y:599,t:1527019904102};\\\", \\\"{x:1292,y:606,t:1527019904118};\\\", \\\"{x:1317,y:614,t:1527019904135};\\\", \\\"{x:1338,y:624,t:1527019904151};\\\", \\\"{x:1358,y:630,t:1527019904168};\\\", \\\"{x:1378,y:637,t:1527019904185};\\\", \\\"{x:1391,y:642,t:1527019904201};\\\", \\\"{x:1403,y:646,t:1527019904219};\\\", \\\"{x:1414,y:649,t:1527019904234};\\\", \\\"{x:1417,y:651,t:1527019904251};\\\", \\\"{x:1421,y:654,t:1527019904268};\\\", \\\"{x:1427,y:655,t:1527019904284};\\\", \\\"{x:1432,y:658,t:1527019904301};\\\", \\\"{x:1437,y:660,t:1527019904318};\\\", \\\"{x:1441,y:662,t:1527019904335};\\\", \\\"{x:1444,y:665,t:1527019904351};\\\", \\\"{x:1446,y:666,t:1527019904368};\\\", \\\"{x:1447,y:666,t:1527019904385};\\\", \\\"{x:1447,y:667,t:1527019904452};\\\", \\\"{x:1448,y:668,t:1527019904467};\\\", \\\"{x:1449,y:669,t:1527019904499};\\\", \\\"{x:1449,y:671,t:1527019904659};\\\", \\\"{x:1451,y:673,t:1527019905044};\\\", \\\"{x:1453,y:673,t:1527019905067};\\\", \\\"{x:1455,y:673,t:1527019905084};\\\", \\\"{x:1457,y:675,t:1527019905102};\\\", \\\"{x:1458,y:675,t:1527019905117};\\\", \\\"{x:1460,y:675,t:1527019905134};\\\", \\\"{x:1459,y:675,t:1527019905379};\\\", \\\"{x:1456,y:675,t:1527019905387};\\\", \\\"{x:1454,y:675,t:1527019905401};\\\", \\\"{x:1452,y:675,t:1527019905417};\\\", \\\"{x:1450,y:677,t:1527019905563};\\\", \\\"{x:1450,y:679,t:1527019905571};\\\", \\\"{x:1449,y:679,t:1527019905585};\\\", \\\"{x:1446,y:683,t:1527019905601};\\\", \\\"{x:1444,y:686,t:1527019905617};\\\", \\\"{x:1442,y:689,t:1527019905634};\\\", \\\"{x:1441,y:692,t:1527019905651};\\\", \\\"{x:1440,y:694,t:1527019905667};\\\", \\\"{x:1439,y:694,t:1527019905684};\\\", \\\"{x:1438,y:697,t:1527019905701};\\\", \\\"{x:1436,y:701,t:1527019905730};\\\", \\\"{x:1435,y:702,t:1527019905738};\\\", \\\"{x:1435,y:703,t:1527019905762};\\\", \\\"{x:1435,y:704,t:1527019905778};\\\", \\\"{x:1435,y:705,t:1527019906363};\\\", \\\"{x:1434,y:705,t:1527019906371};\\\", \\\"{x:1432,y:704,t:1527019906387};\\\", \\\"{x:1429,y:702,t:1527019906403};\\\", \\\"{x:1428,y:702,t:1527019906417};\\\", \\\"{x:1425,y:698,t:1527019906434};\\\", \\\"{x:1419,y:694,t:1527019906451};\\\", \\\"{x:1406,y:680,t:1527019906467};\\\", \\\"{x:1396,y:666,t:1527019906485};\\\", \\\"{x:1384,y:654,t:1527019906501};\\\", \\\"{x:1370,y:636,t:1527019906517};\\\", \\\"{x:1343,y:613,t:1527019906534};\\\", \\\"{x:1301,y:574,t:1527019906552};\\\", \\\"{x:1262,y:525,t:1527019906567};\\\", \\\"{x:1222,y:472,t:1527019906584};\\\", \\\"{x:1175,y:419,t:1527019906601};\\\", \\\"{x:1092,y:366,t:1527019906618};\\\", \\\"{x:952,y:309,t:1527019906634};\\\", \\\"{x:795,y:247,t:1527019906650};\\\", \\\"{x:557,y:176,t:1527019906667};\\\", \\\"{x:437,y:155,t:1527019906684};\\\", \\\"{x:387,y:147,t:1527019906701};\\\", \\\"{x:361,y:147,t:1527019906717};\\\", \\\"{x:339,y:157,t:1527019906734};\\\", \\\"{x:292,y:179,t:1527019906751};\\\", \\\"{x:270,y:195,t:1527019906767};\\\", \\\"{x:263,y:220,t:1527019906784};\\\", \\\"{x:252,y:243,t:1527019906801};\\\", \\\"{x:251,y:268,t:1527019906818};\\\", \\\"{x:260,y:291,t:1527019906835};\\\", \\\"{x:275,y:319,t:1527019906851};\\\", \\\"{x:280,y:329,t:1527019906867};\\\", \\\"{x:287,y:349,t:1527019906884};\\\", \\\"{x:294,y:364,t:1527019906900};\\\", \\\"{x:301,y:370,t:1527019906917};\\\", \\\"{x:312,y:378,t:1527019906934};\\\", \\\"{x:329,y:386,t:1527019906950};\\\", \\\"{x:346,y:392,t:1527019906967};\\\", \\\"{x:380,y:398,t:1527019906984};\\\", \\\"{x:402,y:403,t:1527019907000};\\\", \\\"{x:419,y:406,t:1527019907017};\\\", \\\"{x:422,y:406,t:1527019907034};\\\", \\\"{x:423,y:406,t:1527019907050};\\\", \\\"{x:426,y:406,t:1527019907067};\\\", \\\"{x:427,y:406,t:1527019907090};\\\", \\\"{x:428,y:406,t:1527019909379};\\\", \\\"{x:432,y:409,t:1527019909435};\\\", \\\"{x:433,y:409,t:1527019909450};\\\", \\\"{x:454,y:418,t:1527019909467};\\\", \\\"{x:460,y:428,t:1527019909483};\\\", \\\"{x:474,y:443,t:1527019909501};\\\", \\\"{x:485,y:459,t:1527019909517};\\\", \\\"{x:497,y:476,t:1527019909534};\\\", \\\"{x:516,y:497,t:1527019909552};\\\", \\\"{x:572,y:536,t:1527019909568};\\\", \\\"{x:661,y:601,t:1527019909583};\\\", \\\"{x:797,y:716,t:1527019909606};\\\", \\\"{x:889,y:799,t:1527019909622};\\\", \\\"{x:975,y:859,t:1527019909639};\\\", \\\"{x:1066,y:918,t:1527019909656};\\\", \\\"{x:1162,y:960,t:1527019909672};\\\", \\\"{x:1235,y:982,t:1527019909689};\\\", \\\"{x:1298,y:987,t:1527019909706};\\\", \\\"{x:1323,y:987,t:1527019909722};\\\", \\\"{x:1357,y:981,t:1527019909739};\\\", \\\"{x:1404,y:961,t:1527019909756};\\\", \\\"{x:1453,y:941,t:1527019909772};\\\", \\\"{x:1508,y:907,t:1527019909790};\\\", \\\"{x:1553,y:873,t:1527019909806};\\\", \\\"{x:1583,y:830,t:1527019909822};\\\", \\\"{x:1597,y:813,t:1527019909840};\\\", \\\"{x:1605,y:803,t:1527019909856};\\\", \\\"{x:1610,y:797,t:1527019909873};\\\", \\\"{x:1612,y:794,t:1527019909889};\\\", \\\"{x:1612,y:792,t:1527019909906};\\\", \\\"{x:1612,y:791,t:1527019909923};\\\", \\\"{x:1608,y:788,t:1527019909939};\\\", \\\"{x:1595,y:787,t:1527019909956};\\\", \\\"{x:1579,y:787,t:1527019909973};\\\", \\\"{x:1565,y:787,t:1527019909989};\\\", \\\"{x:1551,y:790,t:1527019910006};\\\", \\\"{x:1539,y:795,t:1527019910023};\\\", \\\"{x:1523,y:800,t:1527019910039};\\\", \\\"{x:1510,y:804,t:1527019910056};\\\", \\\"{x:1497,y:806,t:1527019910074};\\\", \\\"{x:1482,y:810,t:1527019910089};\\\", \\\"{x:1452,y:811,t:1527019910107};\\\", \\\"{x:1431,y:811,t:1527019910123};\\\", \\\"{x:1419,y:808,t:1527019910139};\\\", \\\"{x:1406,y:802,t:1527019910157};\\\", \\\"{x:1402,y:800,t:1527019910174};\\\", \\\"{x:1392,y:797,t:1527019910189};\\\", \\\"{x:1388,y:795,t:1527019910207};\\\", \\\"{x:1383,y:792,t:1527019910224};\\\", \\\"{x:1379,y:789,t:1527019910240};\\\", \\\"{x:1372,y:784,t:1527019910257};\\\", \\\"{x:1370,y:782,t:1527019910274};\\\", \\\"{x:1369,y:782,t:1527019910290};\\\", \\\"{x:1367,y:782,t:1527019911971};\\\", \\\"{x:1366,y:782,t:1527019911979};\\\", \\\"{x:1365,y:782,t:1527019911991};\\\", \\\"{x:1362,y:783,t:1527019912007};\\\", \\\"{x:1361,y:784,t:1527019912211};\\\", \\\"{x:1360,y:784,t:1527019912260};\\\", \\\"{x:1359,y:784,t:1527019912275};\\\", \\\"{x:1358,y:784,t:1527019912291};\\\", \\\"{x:1357,y:784,t:1527019912323};\\\", \\\"{x:1356,y:784,t:1527019912331};\\\", \\\"{x:1354,y:785,t:1527019912403};\\\", \\\"{x:1350,y:785,t:1527019912411};\\\", \\\"{x:1344,y:785,t:1527019912425};\\\", \\\"{x:1330,y:785,t:1527019912441};\\\", \\\"{x:1312,y:782,t:1527019912458};\\\", \\\"{x:1305,y:781,t:1527019912476};\\\", \\\"{x:1305,y:780,t:1527019912611};\\\", \\\"{x:1306,y:777,t:1527019912626};\\\", \\\"{x:1311,y:774,t:1527019912642};\\\", \\\"{x:1319,y:770,t:1527019912659};\\\", \\\"{x:1322,y:769,t:1527019912675};\\\", \\\"{x:1324,y:767,t:1527019912691};\\\", \\\"{x:1326,y:766,t:1527019912708};\\\", \\\"{x:1329,y:765,t:1527019912725};\\\", \\\"{x:1331,y:764,t:1527019912741};\\\", \\\"{x:1333,y:763,t:1527019912759};\\\", \\\"{x:1335,y:762,t:1527019912779};\\\", \\\"{x:1336,y:762,t:1527019912803};\\\", \\\"{x:1337,y:761,t:1527019912810};\\\", \\\"{x:1338,y:761,t:1527019912825};\\\", \\\"{x:1339,y:760,t:1527019912841};\\\", \\\"{x:1340,y:759,t:1527019912858};\\\", \\\"{x:1342,y:757,t:1527019917718};\\\", \\\"{x:1346,y:756,t:1527019917731};\\\", \\\"{x:1351,y:755,t:1527019917749};\\\", \\\"{x:1353,y:753,t:1527019917766};\\\", \\\"{x:1354,y:753,t:1527019917870};\\\", \\\"{x:1354,y:756,t:1527019933646};\\\", \\\"{x:1354,y:761,t:1527019933662};\\\", \\\"{x:1354,y:762,t:1527019933678};\\\", \\\"{x:1354,y:764,t:1527019934596};\\\", \\\"{x:1352,y:768,t:1527019934612};\\\", \\\"{x:1344,y:778,t:1527019934628};\\\", \\\"{x:1339,y:791,t:1527019934645};\\\", \\\"{x:1331,y:804,t:1527019934661};\\\", \\\"{x:1319,y:816,t:1527019934678};\\\", \\\"{x:1309,y:825,t:1527019934695};\\\", \\\"{x:1298,y:835,t:1527019934711};\\\", \\\"{x:1281,y:845,t:1527019934729};\\\", \\\"{x:1260,y:856,t:1527019934744};\\\", \\\"{x:1240,y:859,t:1527019934762};\\\", \\\"{x:1217,y:860,t:1527019934779};\\\", \\\"{x:1188,y:861,t:1527019934795};\\\", \\\"{x:1149,y:865,t:1527019934812};\\\", \\\"{x:1041,y:855,t:1527019934829};\\\", \\\"{x:945,y:831,t:1527019934845};\\\", \\\"{x:856,y:808,t:1527019934862};\\\", \\\"{x:771,y:785,t:1527019934879};\\\", \\\"{x:695,y:761,t:1527019934894};\\\", \\\"{x:618,y:741,t:1527019934912};\\\", \\\"{x:568,y:727,t:1527019934929};\\\", \\\"{x:536,y:721,t:1527019934945};\\\", \\\"{x:521,y:716,t:1527019934962};\\\", \\\"{x:507,y:713,t:1527019934978};\\\", \\\"{x:497,y:711,t:1527019934995};\\\", \\\"{x:485,y:709,t:1527019935012};\\\", \\\"{x:463,y:705,t:1527019935030};\\\", \\\"{x:441,y:703,t:1527019935045};\\\", \\\"{x:422,y:698,t:1527019935062};\\\", \\\"{x:401,y:694,t:1527019935079};\\\", \\\"{x:383,y:683,t:1527019935095};\\\", \\\"{x:366,y:672,t:1527019935112};\\\", \\\"{x:348,y:662,t:1527019935130};\\\", \\\"{x:341,y:660,t:1527019935146};\\\", \\\"{x:338,y:660,t:1527019935162};\\\", \\\"{x:336,y:658,t:1527019935179};\\\", \\\"{x:336,y:656,t:1527019935253};\\\", \\\"{x:336,y:654,t:1527019935262};\\\", \\\"{x:336,y:647,t:1527019935280};\\\", \\\"{x:340,y:641,t:1527019935297};\\\", \\\"{x:347,y:637,t:1527019935313};\\\", \\\"{x:356,y:632,t:1527019935330};\\\", \\\"{x:364,y:629,t:1527019935347};\\\", \\\"{x:366,y:629,t:1527019935363};\\\", \\\"{x:367,y:628,t:1527019935379};\\\", \\\"{x:367,y:627,t:1527019935462};\\\", \\\"{x:368,y:625,t:1527019935469};\\\", \\\"{x:373,y:622,t:1527019935480};\\\", \\\"{x:380,y:620,t:1527019935497};\\\", \\\"{x:390,y:615,t:1527019935513};\\\", \\\"{x:397,y:613,t:1527019935531};\\\", \\\"{x:420,y:611,t:1527019935548};\\\", \\\"{x:448,y:612,t:1527019935562};\\\", \\\"{x:469,y:618,t:1527019935579};\\\", \\\"{x:479,y:619,t:1527019935597};\\\", \\\"{x:480,y:619,t:1527019935612};\\\", \\\"{x:485,y:619,t:1527019935629};\\\", \\\"{x:499,y:619,t:1527019935648};\\\", \\\"{x:519,y:623,t:1527019935662};\\\", \\\"{x:538,y:624,t:1527019935680};\\\", \\\"{x:543,y:624,t:1527019935696};\\\", \\\"{x:556,y:625,t:1527019935713};\\\", \\\"{x:569,y:625,t:1527019935729};\\\", \\\"{x:576,y:625,t:1527019935746};\\\", \\\"{x:578,y:625,t:1527019935762};\\\", \\\"{x:579,y:625,t:1527019935789};\\\", \\\"{x:579,y:624,t:1527019935796};\\\", \\\"{x:581,y:623,t:1527019935813};\\\", \\\"{x:583,y:621,t:1527019935830};\\\", \\\"{x:586,y:618,t:1527019935846};\\\", \\\"{x:588,y:616,t:1527019935863};\\\", \\\"{x:590,y:614,t:1527019935885};\\\", \\\"{x:592,y:612,t:1527019935897};\\\", \\\"{x:596,y:606,t:1527019935914};\\\", \\\"{x:602,y:598,t:1527019935929};\\\", \\\"{x:608,y:589,t:1527019935947};\\\", \\\"{x:608,y:581,t:1527019935963};\\\", \\\"{x:608,y:569,t:1527019935979};\\\", \\\"{x:588,y:552,t:1527019935997};\\\", \\\"{x:572,y:543,t:1527019936014};\\\", \\\"{x:551,y:530,t:1527019936030};\\\", \\\"{x:519,y:518,t:1527019936047};\\\", \\\"{x:448,y:503,t:1527019936065};\\\", \\\"{x:391,y:498,t:1527019936080};\\\", \\\"{x:366,y:498,t:1527019936097};\\\", \\\"{x:340,y:498,t:1527019936114};\\\", \\\"{x:320,y:498,t:1527019936130};\\\", \\\"{x:304,y:501,t:1527019936146};\\\", \\\"{x:298,y:504,t:1527019936164};\\\", \\\"{x:294,y:507,t:1527019936179};\\\", \\\"{x:287,y:514,t:1527019936197};\\\", \\\"{x:281,y:520,t:1527019936215};\\\", \\\"{x:268,y:529,t:1527019936231};\\\", \\\"{x:253,y:538,t:1527019936247};\\\", \\\"{x:237,y:544,t:1527019936264};\\\", \\\"{x:227,y:545,t:1527019936281};\\\", \\\"{x:222,y:546,t:1527019936297};\\\", \\\"{x:216,y:547,t:1527019936314};\\\", \\\"{x:206,y:548,t:1527019936331};\\\", \\\"{x:184,y:552,t:1527019936346};\\\", \\\"{x:168,y:558,t:1527019936364};\\\", \\\"{x:153,y:567,t:1527019936381};\\\", \\\"{x:143,y:572,t:1527019936397};\\\", \\\"{x:137,y:576,t:1527019936414};\\\", \\\"{x:133,y:580,t:1527019936431};\\\", \\\"{x:128,y:583,t:1527019936447};\\\", \\\"{x:123,y:588,t:1527019936464};\\\", \\\"{x:118,y:593,t:1527019936482};\\\", \\\"{x:115,y:594,t:1527019936497};\\\", \\\"{x:110,y:597,t:1527019936513};\\\", \\\"{x:108,y:599,t:1527019936530};\\\", \\\"{x:107,y:604,t:1527019936548};\\\", \\\"{x:105,y:611,t:1527019936564};\\\", \\\"{x:102,y:617,t:1527019936581};\\\", \\\"{x:99,y:622,t:1527019936598};\\\", \\\"{x:96,y:627,t:1527019936613};\\\", \\\"{x:97,y:628,t:1527019936644};\\\", \\\"{x:100,y:629,t:1527019936652};\\\", \\\"{x:103,y:630,t:1527019936664};\\\", \\\"{x:120,y:635,t:1527019936683};\\\", \\\"{x:143,y:637,t:1527019936697};\\\", \\\"{x:168,y:637,t:1527019936714};\\\", \\\"{x:210,y:634,t:1527019936731};\\\", \\\"{x:238,y:626,t:1527019936747};\\\", \\\"{x:279,y:616,t:1527019936764};\\\", \\\"{x:329,y:602,t:1527019936781};\\\", \\\"{x:350,y:595,t:1527019936798};\\\", \\\"{x:359,y:590,t:1527019936814};\\\", \\\"{x:361,y:590,t:1527019936830};\\\", \\\"{x:362,y:588,t:1527019936848};\\\", \\\"{x:363,y:588,t:1527019936892};\\\", \\\"{x:363,y:584,t:1527019936900};\\\", \\\"{x:368,y:579,t:1527019936914};\\\", \\\"{x:378,y:561,t:1527019936932};\\\", \\\"{x:388,y:539,t:1527019936949};\\\", \\\"{x:395,y:512,t:1527019936965};\\\", \\\"{x:399,y:498,t:1527019936981};\\\", \\\"{x:403,y:488,t:1527019936999};\\\", \\\"{x:405,y:483,t:1527019937015};\\\", \\\"{x:406,y:482,t:1527019937031};\\\", \\\"{x:407,y:480,t:1527019937048};\\\", \\\"{x:407,y:479,t:1527019937278};\\\", \\\"{x:407,y:480,t:1527019937309};\\\", \\\"{x:407,y:481,t:1527019937317};\\\", \\\"{x:407,y:483,t:1527019937333};\\\", \\\"{x:407,y:484,t:1527019937350};\\\", \\\"{x:406,y:488,t:1527019937407};\\\", \\\"{x:403,y:494,t:1527019937417};\\\", \\\"{x:401,y:503,t:1527019937432};\\\", \\\"{x:398,y:510,t:1527019937448};\\\", \\\"{x:397,y:513,t:1527019937465};\\\", \\\"{x:396,y:514,t:1527019937581};\\\", \\\"{x:395,y:514,t:1527019937605};\\\", \\\"{x:395,y:513,t:1527019937622};\\\", \\\"{x:394,y:512,t:1527019937631};\\\", \\\"{x:392,y:506,t:1527019937648};\\\", \\\"{x:390,y:504,t:1527019937665};\\\", \\\"{x:390,y:503,t:1527019937726};\\\", \\\"{x:390,y:502,t:1527019937812};\\\", \\\"{x:390,y:502,t:1527019937873};\\\", \\\"{x:390,y:504,t:1527019938004};\\\", \\\"{x:390,y:508,t:1527019938015};\\\", \\\"{x:390,y:529,t:1527019938032};\\\", \\\"{x:395,y:546,t:1527019938049};\\\", \\\"{x:404,y:566,t:1527019938066};\\\", \\\"{x:420,y:600,t:1527019938083};\\\", \\\"{x:443,y:641,t:1527019938099};\\\", \\\"{x:456,y:664,t:1527019938115};\\\", \\\"{x:465,y:685,t:1527019938132};\\\", \\\"{x:482,y:717,t:1527019938148};\\\", \\\"{x:489,y:727,t:1527019938165};\\\", \\\"{x:496,y:740,t:1527019938181};\\\", \\\"{x:502,y:747,t:1527019938199};\\\", \\\"{x:508,y:756,t:1527019938215};\\\", \\\"{x:511,y:760,t:1527019938231};\\\", \\\"{x:511,y:761,t:1527019938261};\\\", \\\"{x:512,y:761,t:1527019938429};\\\", \\\"{x:513,y:756,t:1527019938436};\\\", \\\"{x:518,y:750,t:1527019938449};\\\", \\\"{x:521,y:747,t:1527019938465};\\\", \\\"{x:523,y:741,t:1527019938482};\\\", \\\"{x:525,y:737,t:1527019938498};\\\", \\\"{x:525,y:736,t:1527019938524};\\\", \\\"{x:526,y:736,t:1527019938573};\\\", \\\"{x:527,y:736,t:1527019938589};\\\", \\\"{x:529,y:736,t:1527019938604};\\\", \\\"{x:531,y:735,t:1527019938620};\\\", \\\"{x:532,y:735,t:1527019938636};\\\", \\\"{x:533,y:734,t:1527019938723};\\\" ] }, { \\\"rt\\\": 49216, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 613475, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -01 PM-02 PM-03 PM-04 PM-B -F -C -E -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:729,t:1527019940581};\\\", \\\"{x:533,y:719,t:1527019940589};\\\", \\\"{x:533,y:709,t:1527019940602};\\\", \\\"{x:533,y:680,t:1527019940617};\\\", \\\"{x:533,y:650,t:1527019940634};\\\", \\\"{x:533,y:625,t:1527019940651};\\\", \\\"{x:533,y:601,t:1527019940667};\\\", \\\"{x:533,y:586,t:1527019940685};\\\", \\\"{x:533,y:573,t:1527019940700};\\\", \\\"{x:533,y:567,t:1527019940717};\\\", \\\"{x:533,y:563,t:1527019940733};\\\", \\\"{x:533,y:555,t:1527019940752};\\\", \\\"{x:533,y:550,t:1527019940767};\\\", \\\"{x:533,y:545,t:1527019940784};\\\", \\\"{x:533,y:542,t:1527019940801};\\\", \\\"{x:533,y:539,t:1527019940817};\\\", \\\"{x:533,y:534,t:1527019940834};\\\", \\\"{x:533,y:527,t:1527019940851};\\\", \\\"{x:533,y:516,t:1527019940868};\\\", \\\"{x:533,y:508,t:1527019940884};\\\", \\\"{x:533,y:486,t:1527019940901};\\\", \\\"{x:533,y:468,t:1527019940918};\\\", \\\"{x:533,y:451,t:1527019940934};\\\", \\\"{x:533,y:433,t:1527019940951};\\\", \\\"{x:536,y:419,t:1527019940968};\\\", \\\"{x:538,y:409,t:1527019940984};\\\", \\\"{x:539,y:405,t:1527019941001};\\\", \\\"{x:539,y:404,t:1527019941017};\\\", \\\"{x:539,y:403,t:1527019941150};\\\", \\\"{x:538,y:403,t:1527019941157};\\\", \\\"{x:535,y:404,t:1527019941168};\\\", \\\"{x:531,y:409,t:1527019941184};\\\", \\\"{x:529,y:413,t:1527019941202};\\\", \\\"{x:528,y:415,t:1527019941218};\\\", \\\"{x:526,y:416,t:1527019941235};\\\", \\\"{x:526,y:417,t:1527019941277};\\\", \\\"{x:525,y:417,t:1527019941325};\\\", \\\"{x:524,y:417,t:1527019941335};\\\", \\\"{x:520,y:417,t:1527019941351};\\\", \\\"{x:516,y:421,t:1527019941368};\\\", \\\"{x:511,y:425,t:1527019941384};\\\", \\\"{x:508,y:431,t:1527019941401};\\\", \\\"{x:504,y:437,t:1527019941418};\\\", \\\"{x:500,y:441,t:1527019941435};\\\", \\\"{x:496,y:445,t:1527019941451};\\\", \\\"{x:493,y:448,t:1527019941469};\\\", \\\"{x:492,y:449,t:1527019941517};\\\", \\\"{x:491,y:449,t:1527019942126};\\\", \\\"{x:490,y:449,t:1527019942137};\\\", \\\"{x:490,y:450,t:1527019942173};\\\", \\\"{x:489,y:450,t:1527019942189};\\\", \\\"{x:488,y:450,t:1527019942213};\\\", \\\"{x:487,y:450,t:1527019942285};\\\", \\\"{x:486,y:450,t:1527019942309};\\\", \\\"{x:485,y:451,t:1527019942318};\\\", \\\"{x:484,y:451,t:1527019942337};\\\", \\\"{x:482,y:452,t:1527019942351};\\\", \\\"{x:478,y:453,t:1527019942368};\\\", \\\"{x:477,y:453,t:1527019942385};\\\", \\\"{x:475,y:454,t:1527019942402};\\\", \\\"{x:473,y:454,t:1527019942418};\\\", \\\"{x:472,y:454,t:1527019942435};\\\", \\\"{x:470,y:454,t:1527019942452};\\\", \\\"{x:469,y:455,t:1527019942469};\\\", \\\"{x:467,y:456,t:1527019942486};\\\", \\\"{x:465,y:457,t:1527019942502};\\\", \\\"{x:464,y:457,t:1527019942519};\\\", \\\"{x:460,y:458,t:1527019942537};\\\", \\\"{x:459,y:459,t:1527019942565};\\\", \\\"{x:458,y:459,t:1527019942573};\\\", \\\"{x:456,y:460,t:1527019942606};\\\", \\\"{x:456,y:461,t:1527019942621};\\\", \\\"{x:455,y:461,t:1527019942662};\\\", \\\"{x:454,y:461,t:1527019942677};\\\", \\\"{x:453,y:461,t:1527019942685};\\\", \\\"{x:452,y:461,t:1527019942701};\\\", \\\"{x:451,y:461,t:1527019942718};\\\", \\\"{x:449,y:463,t:1527019942737};\\\", \\\"{x:446,y:463,t:1527019942870};\\\", \\\"{x:445,y:464,t:1527019943182};\\\", \\\"{x:444,y:464,t:1527019943189};\\\", \\\"{x:443,y:465,t:1527019943221};\\\", \\\"{x:440,y:465,t:1527019945101};\\\", \\\"{x:439,y:466,t:1527019945119};\\\", \\\"{x:438,y:466,t:1527019945141};\\\", \\\"{x:437,y:466,t:1527019945157};\\\", \\\"{x:436,y:466,t:1527019945405};\\\", \\\"{x:435,y:466,t:1527019945420};\\\", \\\"{x:434,y:466,t:1527019945437};\\\", \\\"{x:431,y:466,t:1527019945469};\\\", \\\"{x:430,y:466,t:1527019945493};\\\", \\\"{x:429,y:467,t:1527019945509};\\\", \\\"{x:428,y:467,t:1527019945533};\\\", \\\"{x:427,y:467,t:1527019945621};\\\", \\\"{x:425,y:468,t:1527019945636};\\\", \\\"{x:424,y:468,t:1527019945652};\\\", \\\"{x:420,y:470,t:1527019945670};\\\", \\\"{x:419,y:470,t:1527019945686};\\\", \\\"{x:417,y:470,t:1527019945703};\\\", \\\"{x:414,y:471,t:1527019945719};\\\", \\\"{x:412,y:473,t:1527019945737};\\\", \\\"{x:410,y:473,t:1527019945752};\\\", \\\"{x:406,y:474,t:1527019945770};\\\", \\\"{x:402,y:475,t:1527019945786};\\\", \\\"{x:398,y:476,t:1527019945802};\\\", \\\"{x:395,y:478,t:1527019945820};\\\", \\\"{x:390,y:479,t:1527019945837};\\\", \\\"{x:379,y:483,t:1527019945853};\\\", \\\"{x:372,y:485,t:1527019945869};\\\", \\\"{x:371,y:485,t:1527019945886};\\\", \\\"{x:368,y:486,t:1527019945902};\\\", \\\"{x:367,y:486,t:1527019945973};\\\", \\\"{x:365,y:487,t:1527019945999};\\\", \\\"{x:365,y:488,t:1527019946004};\\\", \\\"{x:364,y:488,t:1527019946084};\\\", \\\"{x:363,y:488,t:1527019946098};\\\", \\\"{x:362,y:488,t:1527019946116};\\\", \\\"{x:361,y:488,t:1527019946165};\\\", \\\"{x:360,y:488,t:1527019946181};\\\", \\\"{x:359,y:488,t:1527019946198};\\\", \\\"{x:357,y:488,t:1527019946229};\\\", \\\"{x:355,y:488,t:1527019946236};\\\", \\\"{x:354,y:489,t:1527019946261};\\\", \\\"{x:353,y:489,t:1527019946269};\\\", \\\"{x:352,y:490,t:1527019946285};\\\", \\\"{x:350,y:490,t:1527019946299};\\\", \\\"{x:349,y:490,t:1527019946317};\\\", \\\"{x:347,y:492,t:1527019946333};\\\", \\\"{x:346,y:492,t:1527019946357};\\\", \\\"{x:344,y:492,t:1527019946381};\\\", \\\"{x:343,y:492,t:1527019946397};\\\", \\\"{x:342,y:492,t:1527019946405};\\\", \\\"{x:341,y:492,t:1527019946416};\\\", \\\"{x:340,y:492,t:1527019946433};\\\", \\\"{x:338,y:492,t:1527019946450};\\\", \\\"{x:337,y:492,t:1527019946465};\\\", \\\"{x:336,y:492,t:1527019946483};\\\", \\\"{x:335,y:493,t:1527019946499};\\\", \\\"{x:333,y:494,t:1527019946516};\\\", \\\"{x:332,y:494,t:1527019946581};\\\", \\\"{x:330,y:494,t:1527019946645};\\\", \\\"{x:330,y:495,t:1527019946653};\\\", \\\"{x:328,y:495,t:1527019946677};\\\", \\\"{x:327,y:495,t:1527019946693};\\\", \\\"{x:326,y:495,t:1527019946717};\\\", \\\"{x:324,y:496,t:1527019946733};\\\", \\\"{x:323,y:496,t:1527019946757};\\\", \\\"{x:321,y:497,t:1527019946781};\\\", \\\"{x:320,y:497,t:1527019946805};\\\", \\\"{x:319,y:497,t:1527019946816};\\\", \\\"{x:318,y:498,t:1527019946833};\\\", \\\"{x:317,y:498,t:1527019946850};\\\", \\\"{x:316,y:499,t:1527019946867};\\\", \\\"{x:315,y:499,t:1527019946883};\\\", \\\"{x:314,y:499,t:1527019946909};\\\", \\\"{x:313,y:499,t:1527019946933};\\\", \\\"{x:312,y:499,t:1527019946950};\\\", \\\"{x:310,y:500,t:1527019946989};\\\", \\\"{x:310,y:501,t:1527019947005};\\\", \\\"{x:309,y:501,t:1527019947021};\\\", \\\"{x:308,y:501,t:1527019947045};\\\", \\\"{x:307,y:501,t:1527019947053};\\\", \\\"{x:306,y:501,t:1527019947067};\\\", \\\"{x:305,y:502,t:1527019947084};\\\", \\\"{x:304,y:502,t:1527019947125};\\\", \\\"{x:303,y:502,t:1527019947141};\\\", \\\"{x:302,y:502,t:1527019947270};\\\", \\\"{x:300,y:503,t:1527019950102};\\\", \\\"{x:299,y:503,t:1527019950109};\\\", \\\"{x:297,y:504,t:1527019950149};\\\", \\\"{x:296,y:505,t:1527019950485};\\\", \\\"{x:294,y:505,t:1527019950517};\\\", \\\"{x:293,y:506,t:1527019950527};\\\", \\\"{x:290,y:509,t:1527019950544};\\\", \\\"{x:287,y:511,t:1527019950560};\\\", \\\"{x:287,y:512,t:1527019950576};\\\", \\\"{x:290,y:509,t:1527019950709};\\\", \\\"{x:296,y:505,t:1527019950716};\\\", \\\"{x:301,y:501,t:1527019950727};\\\", \\\"{x:311,y:491,t:1527019950744};\\\", \\\"{x:324,y:483,t:1527019950762};\\\", \\\"{x:343,y:475,t:1527019950777};\\\", \\\"{x:354,y:473,t:1527019950793};\\\", \\\"{x:373,y:469,t:1527019950810};\\\", \\\"{x:391,y:467,t:1527019950825};\\\", \\\"{x:411,y:465,t:1527019950842};\\\", \\\"{x:419,y:465,t:1527019950859};\\\", \\\"{x:433,y:466,t:1527019950875};\\\", \\\"{x:466,y:478,t:1527019950892};\\\", \\\"{x:522,y:507,t:1527019950910};\\\", \\\"{x:602,y:529,t:1527019950925};\\\", \\\"{x:687,y:550,t:1527019950942};\\\", \\\"{x:774,y:565,t:1527019950960};\\\", \\\"{x:884,y:577,t:1527019950975};\\\", \\\"{x:1007,y:595,t:1527019950992};\\\", \\\"{x:1121,y:614,t:1527019951010};\\\", \\\"{x:1245,y:630,t:1527019951025};\\\", \\\"{x:1363,y:657,t:1527019951043};\\\", \\\"{x:1447,y:686,t:1527019951060};\\\", \\\"{x:1520,y:708,t:1527019951076};\\\", \\\"{x:1613,y:739,t:1527019951092};\\\", \\\"{x:1669,y:755,t:1527019951109};\\\", \\\"{x:1727,y:774,t:1527019951125};\\\", \\\"{x:1772,y:795,t:1527019951142};\\\", \\\"{x:1803,y:811,t:1527019951160};\\\", \\\"{x:1826,y:826,t:1527019951175};\\\", \\\"{x:1844,y:837,t:1527019951193};\\\", \\\"{x:1851,y:843,t:1527019951210};\\\", \\\"{x:1851,y:845,t:1527019951226};\\\", \\\"{x:1852,y:849,t:1527019951243};\\\", \\\"{x:1852,y:853,t:1527019951260};\\\", \\\"{x:1845,y:858,t:1527019951276};\\\", \\\"{x:1814,y:861,t:1527019951293};\\\", \\\"{x:1781,y:861,t:1527019951309};\\\", \\\"{x:1744,y:861,t:1527019951325};\\\", \\\"{x:1711,y:861,t:1527019951343};\\\", \\\"{x:1685,y:861,t:1527019951360};\\\", \\\"{x:1654,y:861,t:1527019951376};\\\", \\\"{x:1625,y:861,t:1527019951392};\\\", \\\"{x:1598,y:861,t:1527019951410};\\\", \\\"{x:1572,y:861,t:1527019951426};\\\", \\\"{x:1554,y:862,t:1527019951443};\\\", \\\"{x:1538,y:862,t:1527019951459};\\\", \\\"{x:1524,y:862,t:1527019951476};\\\", \\\"{x:1507,y:860,t:1527019951493};\\\", \\\"{x:1497,y:856,t:1527019951510};\\\", \\\"{x:1484,y:850,t:1527019951526};\\\", \\\"{x:1471,y:844,t:1527019951543};\\\", \\\"{x:1448,y:834,t:1527019951560};\\\", \\\"{x:1428,y:822,t:1527019951576};\\\", \\\"{x:1400,y:807,t:1527019951593};\\\", \\\"{x:1382,y:802,t:1527019951610};\\\", \\\"{x:1361,y:799,t:1527019951627};\\\", \\\"{x:1339,y:794,t:1527019951643};\\\", \\\"{x:1327,y:791,t:1527019951660};\\\", \\\"{x:1325,y:791,t:1527019951677};\\\", \\\"{x:1324,y:791,t:1527019951693};\\\", \\\"{x:1325,y:787,t:1527019951862};\\\", \\\"{x:1326,y:780,t:1527019951876};\\\", \\\"{x:1335,y:754,t:1527019951893};\\\", \\\"{x:1339,y:744,t:1527019951909};\\\", \\\"{x:1342,y:737,t:1527019951926};\\\", \\\"{x:1344,y:733,t:1527019951943};\\\", \\\"{x:1345,y:731,t:1527019951960};\\\", \\\"{x:1347,y:728,t:1527019951976};\\\", \\\"{x:1349,y:725,t:1527019951993};\\\", \\\"{x:1351,y:720,t:1527019952011};\\\", \\\"{x:1352,y:715,t:1527019952026};\\\", \\\"{x:1355,y:709,t:1527019952043};\\\", \\\"{x:1357,y:703,t:1527019952060};\\\", \\\"{x:1359,y:693,t:1527019952076};\\\", \\\"{x:1360,y:677,t:1527019952093};\\\", \\\"{x:1361,y:664,t:1527019952109};\\\", \\\"{x:1361,y:655,t:1527019952126};\\\", \\\"{x:1363,y:651,t:1527019952143};\\\", \\\"{x:1364,y:648,t:1527019952160};\\\", \\\"{x:1364,y:647,t:1527019952176};\\\", \\\"{x:1364,y:648,t:1527019952269};\\\", \\\"{x:1362,y:652,t:1527019952277};\\\", \\\"{x:1356,y:663,t:1527019952293};\\\", \\\"{x:1349,y:677,t:1527019952309};\\\", \\\"{x:1343,y:690,t:1527019952326};\\\", \\\"{x:1336,y:709,t:1527019952344};\\\", \\\"{x:1327,y:727,t:1527019952360};\\\", \\\"{x:1322,y:748,t:1527019952376};\\\", \\\"{x:1318,y:763,t:1527019952393};\\\", \\\"{x:1313,y:779,t:1527019952410};\\\", \\\"{x:1308,y:793,t:1527019952426};\\\", \\\"{x:1305,y:805,t:1527019952443};\\\", \\\"{x:1302,y:816,t:1527019952460};\\\", \\\"{x:1299,y:825,t:1527019952476};\\\", \\\"{x:1295,y:841,t:1527019952493};\\\", \\\"{x:1295,y:851,t:1527019952510};\\\", \\\"{x:1292,y:862,t:1527019952526};\\\", \\\"{x:1292,y:873,t:1527019952543};\\\", \\\"{x:1292,y:884,t:1527019952560};\\\", \\\"{x:1292,y:898,t:1527019952576};\\\", \\\"{x:1293,y:908,t:1527019952593};\\\", \\\"{x:1293,y:916,t:1527019952610};\\\", \\\"{x:1293,y:924,t:1527019952626};\\\", \\\"{x:1294,y:934,t:1527019952643};\\\", \\\"{x:1298,y:942,t:1527019952660};\\\", \\\"{x:1298,y:945,t:1527019952676};\\\", \\\"{x:1302,y:954,t:1527019952693};\\\", \\\"{x:1307,y:964,t:1527019952710};\\\", \\\"{x:1311,y:973,t:1527019952726};\\\", \\\"{x:1317,y:984,t:1527019952742};\\\", \\\"{x:1318,y:989,t:1527019952760};\\\", \\\"{x:1319,y:993,t:1527019952776};\\\", \\\"{x:1319,y:994,t:1527019952793};\\\", \\\"{x:1321,y:998,t:1527019952810};\\\", \\\"{x:1324,y:1002,t:1527019952826};\\\", \\\"{x:1324,y:1003,t:1527019952842};\\\", \\\"{x:1324,y:1004,t:1527019952860};\\\", \\\"{x:1325,y:1005,t:1527019952885};\\\", \\\"{x:1327,y:1005,t:1527019952901};\\\", \\\"{x:1331,y:1005,t:1527019952909};\\\", \\\"{x:1340,y:1003,t:1527019952926};\\\", \\\"{x:1353,y:998,t:1527019952943};\\\", \\\"{x:1362,y:993,t:1527019952959};\\\", \\\"{x:1367,y:992,t:1527019952975};\\\", \\\"{x:1369,y:990,t:1527019952997};\\\", \\\"{x:1370,y:990,t:1527019953010};\\\", \\\"{x:1373,y:990,t:1527019953026};\\\", \\\"{x:1380,y:989,t:1527019953042};\\\", \\\"{x:1384,y:989,t:1527019953060};\\\", \\\"{x:1390,y:988,t:1527019953075};\\\", \\\"{x:1411,y:984,t:1527019953093};\\\", \\\"{x:1421,y:984,t:1527019953110};\\\", \\\"{x:1443,y:984,t:1527019953127};\\\", \\\"{x:1471,y:984,t:1527019953143};\\\", \\\"{x:1500,y:984,t:1527019953159};\\\", \\\"{x:1525,y:984,t:1527019953175};\\\", \\\"{x:1549,y:983,t:1527019953193};\\\", \\\"{x:1566,y:983,t:1527019953210};\\\", \\\"{x:1582,y:981,t:1527019953226};\\\", \\\"{x:1593,y:980,t:1527019953242};\\\", \\\"{x:1600,y:979,t:1527019953260};\\\", \\\"{x:1609,y:979,t:1527019953275};\\\", \\\"{x:1617,y:979,t:1527019953292};\\\", \\\"{x:1624,y:979,t:1527019953310};\\\", \\\"{x:1627,y:979,t:1527019953325};\\\", \\\"{x:1628,y:979,t:1527019953343};\\\", \\\"{x:1628,y:978,t:1527019953733};\\\", \\\"{x:1627,y:978,t:1527019953742};\\\", \\\"{x:1625,y:977,t:1527019953760};\\\", \\\"{x:1624,y:977,t:1527019953775};\\\", \\\"{x:1623,y:977,t:1527019953836};\\\", \\\"{x:1622,y:976,t:1527019953909};\\\", \\\"{x:1621,y:975,t:1527019953926};\\\", \\\"{x:1621,y:974,t:1527019953981};\\\", \\\"{x:1621,y:973,t:1527019954013};\\\", \\\"{x:1621,y:972,t:1527019954029};\\\", \\\"{x:1620,y:971,t:1527019954043};\\\", \\\"{x:1620,y:969,t:1527019954085};\\\", \\\"{x:1620,y:968,t:1527019954101};\\\", \\\"{x:1620,y:966,t:1527019954117};\\\", \\\"{x:1620,y:962,t:1527019954126};\\\", \\\"{x:1620,y:957,t:1527019954143};\\\", \\\"{x:1620,y:949,t:1527019954159};\\\", \\\"{x:1620,y:939,t:1527019954176};\\\", \\\"{x:1620,y:929,t:1527019954193};\\\", \\\"{x:1620,y:917,t:1527019954210};\\\", \\\"{x:1620,y:902,t:1527019954227};\\\", \\\"{x:1616,y:881,t:1527019954243};\\\", \\\"{x:1613,y:865,t:1527019954260};\\\", \\\"{x:1612,y:850,t:1527019954276};\\\", \\\"{x:1611,y:839,t:1527019954293};\\\", \\\"{x:1611,y:834,t:1527019954310};\\\", \\\"{x:1610,y:830,t:1527019954326};\\\", \\\"{x:1610,y:826,t:1527019954343};\\\", \\\"{x:1606,y:813,t:1527019954361};\\\", \\\"{x:1601,y:795,t:1527019954377};\\\", \\\"{x:1592,y:775,t:1527019954393};\\\", \\\"{x:1591,y:764,t:1527019954410};\\\", \\\"{x:1591,y:759,t:1527019954426};\\\", \\\"{x:1590,y:757,t:1527019954443};\\\", \\\"{x:1590,y:756,t:1527019954460};\\\", \\\"{x:1590,y:753,t:1527019954477};\\\", \\\"{x:1589,y:749,t:1527019954493};\\\", \\\"{x:1589,y:741,t:1527019954511};\\\", \\\"{x:1588,y:729,t:1527019954526};\\\", \\\"{x:1588,y:723,t:1527019954543};\\\", \\\"{x:1587,y:716,t:1527019954560};\\\", \\\"{x:1587,y:715,t:1527019954576};\\\", \\\"{x:1587,y:711,t:1527019954593};\\\", \\\"{x:1587,y:708,t:1527019954610};\\\", \\\"{x:1587,y:705,t:1527019954627};\\\", \\\"{x:1587,y:701,t:1527019954643};\\\", \\\"{x:1588,y:699,t:1527019954660};\\\", \\\"{x:1588,y:696,t:1527019954677};\\\", \\\"{x:1589,y:693,t:1527019954694};\\\", \\\"{x:1589,y:691,t:1527019954709};\\\", \\\"{x:1590,y:691,t:1527019954725};\\\", \\\"{x:1591,y:690,t:1527019954805};\\\", \\\"{x:1591,y:691,t:1527019958813};\\\", \\\"{x:1590,y:693,t:1527019959077};\\\", \\\"{x:1587,y:696,t:1527019959094};\\\", \\\"{x:1583,y:700,t:1527019959110};\\\", \\\"{x:1581,y:708,t:1527019959126};\\\", \\\"{x:1577,y:713,t:1527019959143};\\\", \\\"{x:1573,y:717,t:1527019959160};\\\", \\\"{x:1571,y:719,t:1527019959177};\\\", \\\"{x:1569,y:720,t:1527019959193};\\\", \\\"{x:1567,y:722,t:1527019959211};\\\", \\\"{x:1565,y:723,t:1527019959227};\\\", \\\"{x:1563,y:727,t:1527019959243};\\\", \\\"{x:1561,y:733,t:1527019959261};\\\", \\\"{x:1561,y:736,t:1527019959277};\\\", \\\"{x:1549,y:746,t:1527019959293};\\\", \\\"{x:1537,y:751,t:1527019959310};\\\", \\\"{x:1520,y:757,t:1527019959327};\\\", \\\"{x:1506,y:762,t:1527019959343};\\\", \\\"{x:1494,y:765,t:1527019959360};\\\", \\\"{x:1488,y:767,t:1527019959377};\\\", \\\"{x:1482,y:770,t:1527019959394};\\\", \\\"{x:1470,y:772,t:1527019959411};\\\", \\\"{x:1466,y:775,t:1527019959426};\\\", \\\"{x:1459,y:778,t:1527019959443};\\\", \\\"{x:1456,y:779,t:1527019959459};\\\", \\\"{x:1452,y:780,t:1527019959477};\\\", \\\"{x:1447,y:782,t:1527019959493};\\\", \\\"{x:1445,y:783,t:1527019959511};\\\", \\\"{x:1435,y:789,t:1527019959527};\\\", \\\"{x:1423,y:795,t:1527019959543};\\\", \\\"{x:1418,y:797,t:1527019959560};\\\", \\\"{x:1415,y:797,t:1527019959577};\\\", \\\"{x:1411,y:799,t:1527019959593};\\\", \\\"{x:1408,y:799,t:1527019959610};\\\", \\\"{x:1407,y:801,t:1527019959627};\\\", \\\"{x:1406,y:802,t:1527019959644};\\\", \\\"{x:1405,y:802,t:1527019959694};\\\", \\\"{x:1403,y:802,t:1527019959711};\\\", \\\"{x:1402,y:802,t:1527019959726};\\\", \\\"{x:1398,y:802,t:1527019959743};\\\", \\\"{x:1394,y:802,t:1527019959759};\\\", \\\"{x:1384,y:800,t:1527019959775};\\\", \\\"{x:1378,y:797,t:1527019959792};\\\", \\\"{x:1377,y:797,t:1527019959809};\\\", \\\"{x:1376,y:797,t:1527019959828};\\\", \\\"{x:1374,y:796,t:1527019959843};\\\", \\\"{x:1371,y:794,t:1527019959859};\\\", \\\"{x:1370,y:793,t:1527019959876};\\\", \\\"{x:1368,y:792,t:1527019959972};\\\", \\\"{x:1367,y:791,t:1527019959980};\\\", \\\"{x:1367,y:788,t:1527019959997};\\\", \\\"{x:1365,y:786,t:1527019960012};\\\", \\\"{x:1364,y:783,t:1527019960026};\\\", \\\"{x:1362,y:781,t:1527019960043};\\\", \\\"{x:1361,y:779,t:1527019960061};\\\", \\\"{x:1361,y:778,t:1527019960076};\\\", \\\"{x:1360,y:776,t:1527019960093};\\\", \\\"{x:1359,y:773,t:1527019960110};\\\", \\\"{x:1356,y:769,t:1527019960127};\\\", \\\"{x:1356,y:768,t:1527019960149};\\\", \\\"{x:1354,y:767,t:1527019960160};\\\", \\\"{x:1354,y:766,t:1527019960181};\\\", \\\"{x:1353,y:764,t:1527019960195};\\\", \\\"{x:1353,y:763,t:1527019960252};\\\", \\\"{x:1352,y:763,t:1527019960268};\\\", \\\"{x:1351,y:762,t:1527019960276};\\\", \\\"{x:1351,y:761,t:1527019961573};\\\", \\\"{x:1350,y:764,t:1527019961581};\\\", \\\"{x:1350,y:770,t:1527019961594};\\\", \\\"{x:1350,y:782,t:1527019961610};\\\", \\\"{x:1350,y:788,t:1527019961626};\\\", \\\"{x:1350,y:795,t:1527019961644};\\\", \\\"{x:1350,y:798,t:1527019961660};\\\", \\\"{x:1350,y:803,t:1527019961677};\\\", \\\"{x:1350,y:806,t:1527019961693};\\\", \\\"{x:1353,y:815,t:1527019961711};\\\", \\\"{x:1358,y:822,t:1527019961726};\\\", \\\"{x:1363,y:827,t:1527019961744};\\\", \\\"{x:1365,y:829,t:1527019961760};\\\", \\\"{x:1367,y:830,t:1527019961776};\\\", \\\"{x:1368,y:830,t:1527019961885};\\\", \\\"{x:1370,y:830,t:1527019961893};\\\", \\\"{x:1370,y:828,t:1527019961909};\\\", \\\"{x:1372,y:825,t:1527019961926};\\\", \\\"{x:1372,y:824,t:1527019961943};\\\", \\\"{x:1372,y:816,t:1527019961959};\\\", \\\"{x:1372,y:803,t:1527019961976};\\\", \\\"{x:1372,y:795,t:1527019961993};\\\", \\\"{x:1372,y:785,t:1527019962010};\\\", \\\"{x:1369,y:773,t:1527019962026};\\\", \\\"{x:1365,y:766,t:1527019962043};\\\", \\\"{x:1364,y:761,t:1527019962060};\\\", \\\"{x:1362,y:759,t:1527019962076};\\\", \\\"{x:1361,y:759,t:1527019962093};\\\", \\\"{x:1361,y:758,t:1527019962109};\\\", \\\"{x:1358,y:753,t:1527019962126};\\\", \\\"{x:1357,y:747,t:1527019962143};\\\", \\\"{x:1347,y:735,t:1527019962160};\\\", \\\"{x:1339,y:724,t:1527019962176};\\\", \\\"{x:1329,y:713,t:1527019962193};\\\", \\\"{x:1324,y:706,t:1527019962209};\\\", \\\"{x:1323,y:704,t:1527019962225};\\\", \\\"{x:1323,y:703,t:1527019962260};\\\", \\\"{x:1323,y:701,t:1527019962300};\\\", \\\"{x:1323,y:700,t:1527019962310};\\\", \\\"{x:1323,y:696,t:1527019962327};\\\", \\\"{x:1323,y:693,t:1527019962343};\\\", \\\"{x:1323,y:692,t:1527019962359};\\\", \\\"{x:1323,y:690,t:1527019962376};\\\", \\\"{x:1323,y:689,t:1527019962393};\\\", \\\"{x:1324,y:689,t:1527019962413};\\\", \\\"{x:1325,y:689,t:1527019962426};\\\", \\\"{x:1326,y:689,t:1527019962453};\\\", \\\"{x:1327,y:688,t:1527019962468};\\\", \\\"{x:1328,y:687,t:1527019962477};\\\", \\\"{x:1329,y:687,t:1527019962493};\\\", \\\"{x:1330,y:686,t:1527019962510};\\\", \\\"{x:1331,y:685,t:1527019962527};\\\", \\\"{x:1333,y:685,t:1527019962543};\\\", \\\"{x:1336,y:683,t:1527019962559};\\\", \\\"{x:1343,y:679,t:1527019962576};\\\", \\\"{x:1360,y:673,t:1527019962593};\\\", \\\"{x:1379,y:664,t:1527019962609};\\\", \\\"{x:1387,y:662,t:1527019962627};\\\", \\\"{x:1388,y:660,t:1527019962643};\\\", \\\"{x:1392,y:659,t:1527019962862};\\\", \\\"{x:1394,y:658,t:1527019962876};\\\", \\\"{x:1398,y:656,t:1527019962893};\\\", \\\"{x:1402,y:654,t:1527019962910};\\\", \\\"{x:1406,y:653,t:1527019962927};\\\", \\\"{x:1408,y:651,t:1527019962943};\\\", \\\"{x:1411,y:649,t:1527019962959};\\\", \\\"{x:1416,y:647,t:1527019962976};\\\", \\\"{x:1421,y:644,t:1527019962994};\\\", \\\"{x:1426,y:642,t:1527019963010};\\\", \\\"{x:1429,y:640,t:1527019963026};\\\", \\\"{x:1431,y:640,t:1527019963044};\\\", \\\"{x:1433,y:638,t:1527019963134};\\\", \\\"{x:1434,y:637,t:1527019963157};\\\", \\\"{x:1435,y:637,t:1527019963165};\\\", \\\"{x:1436,y:636,t:1527019963177};\\\", \\\"{x:1437,y:635,t:1527019963194};\\\", \\\"{x:1438,y:635,t:1527019963221};\\\", \\\"{x:1440,y:635,t:1527019963366};\\\", \\\"{x:1441,y:635,t:1527019963429};\\\", \\\"{x:1442,y:635,t:1527019963445};\\\", \\\"{x:1444,y:634,t:1527019963487};\\\", \\\"{x:1443,y:634,t:1527019965678};\\\", \\\"{x:1442,y:634,t:1527019965797};\\\", \\\"{x:1441,y:634,t:1527019965958};\\\", \\\"{x:1440,y:634,t:1527019966117};\\\", \\\"{x:1438,y:635,t:1527019966318};\\\", \\\"{x:1438,y:636,t:1527019966749};\\\", \\\"{x:1437,y:636,t:1527019966760};\\\", \\\"{x:1434,y:637,t:1527019966777};\\\", \\\"{x:1428,y:639,t:1527019966793};\\\", \\\"{x:1423,y:640,t:1527019966810};\\\", \\\"{x:1416,y:641,t:1527019966827};\\\", \\\"{x:1410,y:642,t:1527019966844};\\\", \\\"{x:1402,y:642,t:1527019966859};\\\", \\\"{x:1384,y:642,t:1527019966877};\\\", \\\"{x:1367,y:638,t:1527019966893};\\\", \\\"{x:1352,y:635,t:1527019966910};\\\", \\\"{x:1330,y:632,t:1527019966927};\\\", \\\"{x:1305,y:628,t:1527019966944};\\\", \\\"{x:1282,y:621,t:1527019966960};\\\", \\\"{x:1268,y:616,t:1527019966976};\\\", \\\"{x:1261,y:613,t:1527019966993};\\\", \\\"{x:1259,y:612,t:1527019967009};\\\", \\\"{x:1258,y:612,t:1527019967036};\\\", \\\"{x:1258,y:611,t:1527019967060};\\\", \\\"{x:1258,y:610,t:1527019967076};\\\", \\\"{x:1256,y:606,t:1527019967093};\\\", \\\"{x:1253,y:603,t:1527019967109};\\\", \\\"{x:1252,y:599,t:1527019967126};\\\", \\\"{x:1250,y:597,t:1527019967143};\\\", \\\"{x:1250,y:595,t:1527019967164};\\\", \\\"{x:1249,y:595,t:1527019967176};\\\", \\\"{x:1249,y:594,t:1527019967193};\\\", \\\"{x:1248,y:592,t:1527019967210};\\\", \\\"{x:1248,y:590,t:1527019967226};\\\", \\\"{x:1248,y:589,t:1527019967243};\\\", \\\"{x:1248,y:587,t:1527019967259};\\\", \\\"{x:1248,y:585,t:1527019967277};\\\", \\\"{x:1248,y:584,t:1527019967293};\\\", \\\"{x:1251,y:581,t:1527019967310};\\\", \\\"{x:1252,y:579,t:1527019967326};\\\", \\\"{x:1254,y:578,t:1527019967343};\\\", \\\"{x:1256,y:576,t:1527019967360};\\\", \\\"{x:1257,y:575,t:1527019967377};\\\", \\\"{x:1262,y:572,t:1527019967394};\\\", \\\"{x:1265,y:570,t:1527019967409};\\\", \\\"{x:1266,y:570,t:1527019967426};\\\", \\\"{x:1267,y:569,t:1527019967443};\\\", \\\"{x:1269,y:567,t:1527019967459};\\\", \\\"{x:1269,y:566,t:1527019967477};\\\", \\\"{x:1271,y:566,t:1527019967581};\\\", \\\"{x:1272,y:566,t:1527019967661};\\\", \\\"{x:1272,y:565,t:1527019967677};\\\", \\\"{x:1275,y:564,t:1527019967693};\\\", \\\"{x:1277,y:563,t:1527019967709};\\\", \\\"{x:1278,y:563,t:1527019967726};\\\", \\\"{x:1279,y:563,t:1527019967756};\\\", \\\"{x:1280,y:562,t:1527019967764};\\\", \\\"{x:1281,y:562,t:1527019967775};\\\", \\\"{x:1283,y:561,t:1527019967793};\\\", \\\"{x:1282,y:561,t:1527019972389};\\\", \\\"{x:1281,y:561,t:1527019972494};\\\", \\\"{x:1280,y:561,t:1527019972597};\\\", \\\"{x:1279,y:562,t:1527019972609};\\\", \\\"{x:1278,y:563,t:1527019972653};\\\", \\\"{x:1276,y:563,t:1527019972917};\\\", \\\"{x:1276,y:564,t:1527019972926};\\\", \\\"{x:1275,y:564,t:1527019973023};\\\", \\\"{x:1274,y:564,t:1527019973149};\\\", \\\"{x:1273,y:564,t:1527019973454};\\\", \\\"{x:1272,y:564,t:1527019973493};\\\", \\\"{x:1272,y:565,t:1527019974885};\\\", \\\"{x:1272,y:567,t:1527019974893};\\\", \\\"{x:1272,y:572,t:1527019974910};\\\", \\\"{x:1272,y:578,t:1527019974927};\\\", \\\"{x:1272,y:580,t:1527019974945};\\\", \\\"{x:1272,y:581,t:1527019974960};\\\", \\\"{x:1274,y:583,t:1527019974977};\\\", \\\"{x:1277,y:588,t:1527019974994};\\\", \\\"{x:1280,y:592,t:1527019975011};\\\", \\\"{x:1284,y:596,t:1527019975027};\\\", \\\"{x:1297,y:604,t:1527019975044};\\\", \\\"{x:1305,y:610,t:1527019975060};\\\", \\\"{x:1309,y:613,t:1527019975077};\\\", \\\"{x:1315,y:617,t:1527019975098};\\\", \\\"{x:1319,y:619,t:1527019975114};\\\", \\\"{x:1323,y:623,t:1527019975131};\\\", \\\"{x:1331,y:628,t:1527019975148};\\\", \\\"{x:1340,y:634,t:1527019975164};\\\", \\\"{x:1348,y:641,t:1527019975181};\\\", \\\"{x:1355,y:651,t:1527019975198};\\\", \\\"{x:1358,y:658,t:1527019975214};\\\", \\\"{x:1360,y:661,t:1527019975232};\\\", \\\"{x:1361,y:665,t:1527019975248};\\\", \\\"{x:1363,y:667,t:1527019975264};\\\", \\\"{x:1363,y:669,t:1527019975281};\\\", \\\"{x:1363,y:670,t:1527019975298};\\\", \\\"{x:1363,y:672,t:1527019975314};\\\", \\\"{x:1363,y:675,t:1527019975331};\\\", \\\"{x:1363,y:677,t:1527019975353};\\\", \\\"{x:1363,y:678,t:1527019975569};\\\", \\\"{x:1363,y:680,t:1527019975585};\\\", \\\"{x:1363,y:681,t:1527019975601};\\\", \\\"{x:1363,y:682,t:1527019975762};\\\", \\\"{x:1362,y:683,t:1527019975793};\\\", \\\"{x:1361,y:683,t:1527019975801};\\\", \\\"{x:1361,y:684,t:1527019975814};\\\", \\\"{x:1358,y:685,t:1527019975831};\\\", \\\"{x:1356,y:687,t:1527019975847};\\\", \\\"{x:1355,y:687,t:1527019975864};\\\", \\\"{x:1354,y:688,t:1527019975881};\\\", \\\"{x:1353,y:688,t:1527019975938};\\\", \\\"{x:1351,y:689,t:1527019975994};\\\", \\\"{x:1350,y:690,t:1527019976009};\\\", \\\"{x:1349,y:691,t:1527019976058};\\\", \\\"{x:1347,y:691,t:1527019976081};\\\", \\\"{x:1346,y:691,t:1527019976161};\\\", \\\"{x:1344,y:691,t:1527019976201};\\\", \\\"{x:1342,y:693,t:1527019976249};\\\", \\\"{x:1341,y:693,t:1527019976625};\\\", \\\"{x:1339,y:693,t:1527019982809};\\\", \\\"{x:1338,y:694,t:1527019982833};\\\", \\\"{x:1333,y:697,t:1527019985225};\\\", \\\"{x:1326,y:699,t:1527019985233};\\\", \\\"{x:1316,y:700,t:1527019985248};\\\", \\\"{x:1287,y:704,t:1527019985265};\\\", \\\"{x:1273,y:704,t:1527019985281};\\\", \\\"{x:1263,y:704,t:1527019985297};\\\", \\\"{x:1261,y:705,t:1527019985321};\\\", \\\"{x:1260,y:705,t:1527019985332};\\\", \\\"{x:1258,y:706,t:1527019985347};\\\", \\\"{x:1257,y:707,t:1527019985377};\\\", \\\"{x:1256,y:707,t:1527019985392};\\\", \\\"{x:1254,y:707,t:1527019985408};\\\", \\\"{x:1253,y:708,t:1527019985425};\\\", \\\"{x:1252,y:708,t:1527019985432};\\\", \\\"{x:1250,y:709,t:1527019985447};\\\", \\\"{x:1246,y:710,t:1527019985465};\\\", \\\"{x:1244,y:711,t:1527019985482};\\\", \\\"{x:1239,y:712,t:1527019985498};\\\", \\\"{x:1235,y:712,t:1527019985515};\\\", \\\"{x:1229,y:713,t:1527019985532};\\\", \\\"{x:1224,y:713,t:1527019985547};\\\", \\\"{x:1220,y:713,t:1527019985564};\\\", \\\"{x:1217,y:713,t:1527019985582};\\\", \\\"{x:1216,y:714,t:1527019985609};\\\", \\\"{x:1215,y:714,t:1527019985617};\\\", \\\"{x:1214,y:714,t:1527019985631};\\\", \\\"{x:1213,y:714,t:1527019985647};\\\", \\\"{x:1210,y:714,t:1527019985665};\\\", \\\"{x:1207,y:714,t:1527019985681};\\\", \\\"{x:1204,y:714,t:1527019985698};\\\", \\\"{x:1201,y:714,t:1527019985714};\\\", \\\"{x:1198,y:714,t:1527019985731};\\\", \\\"{x:1194,y:714,t:1527019985748};\\\", \\\"{x:1190,y:714,t:1527019985764};\\\", \\\"{x:1186,y:714,t:1527019985781};\\\", \\\"{x:1179,y:714,t:1527019985796};\\\", \\\"{x:1169,y:714,t:1527019985814};\\\", \\\"{x:1154,y:714,t:1527019985831};\\\", \\\"{x:1146,y:714,t:1527019985847};\\\", \\\"{x:1117,y:718,t:1527019985864};\\\", \\\"{x:1087,y:727,t:1527019985881};\\\", \\\"{x:1063,y:730,t:1527019985897};\\\", \\\"{x:1041,y:736,t:1527019985914};\\\", \\\"{x:1016,y:742,t:1527019985931};\\\", \\\"{x:994,y:747,t:1527019985947};\\\", \\\"{x:967,y:753,t:1527019985964};\\\", \\\"{x:950,y:754,t:1527019985981};\\\", \\\"{x:931,y:760,t:1527019985997};\\\", \\\"{x:884,y:766,t:1527019986014};\\\", \\\"{x:827,y:775,t:1527019986031};\\\", \\\"{x:761,y:782,t:1527019986048};\\\", \\\"{x:680,y:782,t:1527019986065};\\\", \\\"{x:618,y:784,t:1527019986080};\\\", \\\"{x:582,y:784,t:1527019986097};\\\", \\\"{x:563,y:784,t:1527019986115};\\\", \\\"{x:549,y:784,t:1527019986131};\\\", \\\"{x:540,y:784,t:1527019986147};\\\", \\\"{x:537,y:784,t:1527019986164};\\\", \\\"{x:534,y:784,t:1527019986181};\\\", \\\"{x:532,y:784,t:1527019986289};\\\", \\\"{x:529,y:784,t:1527019986297};\\\", \\\"{x:522,y:784,t:1527019986315};\\\", \\\"{x:513,y:782,t:1527019986331};\\\", \\\"{x:501,y:778,t:1527019986348};\\\", \\\"{x:490,y:775,t:1527019986365};\\\", \\\"{x:473,y:772,t:1527019986381};\\\", \\\"{x:436,y:769,t:1527019986397};\\\", \\\"{x:378,y:763,t:1527019986415};\\\", \\\"{x:338,y:754,t:1527019986432};\\\", \\\"{x:338,y:751,t:1527019986777};\\\", \\\"{x:339,y:750,t:1527019986825};\\\", \\\"{x:342,y:746,t:1527019986840};\\\", \\\"{x:347,y:742,t:1527019986848};\\\", \\\"{x:352,y:737,t:1527019986864};\\\", \\\"{x:358,y:731,t:1527019986881};\\\", \\\"{x:364,y:724,t:1527019986897};\\\", \\\"{x:371,y:714,t:1527019986914};\\\", \\\"{x:386,y:699,t:1527019986932};\\\", \\\"{x:405,y:684,t:1527019986948};\\\", \\\"{x:420,y:669,t:1527019986966};\\\", \\\"{x:442,y:657,t:1527019986981};\\\", \\\"{x:458,y:649,t:1527019986997};\\\", \\\"{x:474,y:639,t:1527019987009};\\\", \\\"{x:485,y:632,t:1527019987025};\\\", \\\"{x:496,y:624,t:1527019987042};\\\", \\\"{x:500,y:622,t:1527019987060};\\\", \\\"{x:503,y:620,t:1527019987076};\\\", \\\"{x:513,y:616,t:1527019987093};\\\", \\\"{x:521,y:613,t:1527019987110};\\\", \\\"{x:529,y:609,t:1527019987126};\\\", \\\"{x:538,y:607,t:1527019987142};\\\", \\\"{x:553,y:602,t:1527019987160};\\\", \\\"{x:559,y:599,t:1527019987178};\\\", \\\"{x:564,y:598,t:1527019987193};\\\", \\\"{x:568,y:597,t:1527019987210};\\\", \\\"{x:578,y:596,t:1527019987226};\\\", \\\"{x:591,y:596,t:1527019987243};\\\", \\\"{x:598,y:595,t:1527019987260};\\\", \\\"{x:603,y:594,t:1527019987277};\\\", \\\"{x:606,y:593,t:1527019987294};\\\", \\\"{x:607,y:592,t:1527019987310};\\\", \\\"{x:609,y:592,t:1527019987478};\\\", \\\"{x:612,y:590,t:1527019987493};\\\", \\\"{x:614,y:590,t:1527019987510};\\\", \\\"{x:615,y:590,t:1527019987527};\\\", \\\"{x:617,y:589,t:1527019987544};\\\", \\\"{x:617,y:589,t:1527019987568};\\\", \\\"{x:616,y:590,t:1527019987664};\\\", \\\"{x:613,y:593,t:1527019987676};\\\", \\\"{x:607,y:600,t:1527019987694};\\\", \\\"{x:600,y:611,t:1527019987710};\\\", \\\"{x:594,y:625,t:1527019987727};\\\", \\\"{x:585,y:646,t:1527019987744};\\\", \\\"{x:582,y:659,t:1527019987760};\\\", \\\"{x:577,y:667,t:1527019987777};\\\", \\\"{x:570,y:681,t:1527019987793};\\\", \\\"{x:566,y:689,t:1527019987810};\\\", \\\"{x:561,y:694,t:1527019987827};\\\", \\\"{x:560,y:694,t:1527019987848};\\\", \\\"{x:566,y:691,t:1527019987913};\\\", \\\"{x:572,y:683,t:1527019987926};\\\", \\\"{x:584,y:666,t:1527019987943};\\\", \\\"{x:596,y:641,t:1527019987960};\\\", \\\"{x:598,y:635,t:1527019987976};\\\", \\\"{x:598,y:629,t:1527019987994};\\\", \\\"{x:600,y:623,t:1527019988011};\\\", \\\"{x:601,y:618,t:1527019988027};\\\", \\\"{x:601,y:617,t:1527019988044};\\\", \\\"{x:599,y:615,t:1527019988061};\\\", \\\"{x:599,y:613,t:1527019988087};\\\", \\\"{x:600,y:611,t:1527019988104};\\\", \\\"{x:600,y:610,t:1527019988112};\\\", \\\"{x:600,y:608,t:1527019988151};\\\", \\\"{x:600,y:607,t:1527019988168};\\\", \\\"{x:600,y:602,t:1527019988178};\\\", \\\"{x:601,y:596,t:1527019988196};\\\", \\\"{x:603,y:591,t:1527019988212};\\\", \\\"{x:605,y:585,t:1527019988228};\\\", \\\"{x:607,y:581,t:1527019988244};\\\", \\\"{x:608,y:578,t:1527019988261};\\\", \\\"{x:608,y:577,t:1527019988277};\\\", \\\"{x:609,y:576,t:1527019988294};\\\", \\\"{x:610,y:574,t:1527019988311};\\\", \\\"{x:608,y:581,t:1527019988583};\\\", \\\"{x:605,y:588,t:1527019988594};\\\", \\\"{x:598,y:603,t:1527019988612};\\\", \\\"{x:592,y:618,t:1527019988628};\\\", \\\"{x:585,y:634,t:1527019988644};\\\", \\\"{x:578,y:650,t:1527019988661};\\\", \\\"{x:570,y:664,t:1527019988677};\\\", \\\"{x:564,y:677,t:1527019988694};\\\", \\\"{x:557,y:696,t:1527019988711};\\\", \\\"{x:548,y:718,t:1527019988728};\\\", \\\"{x:537,y:733,t:1527019988745};\\\", \\\"{x:533,y:740,t:1527019988761};\\\", \\\"{x:530,y:745,t:1527019988777};\\\", \\\"{x:534,y:743,t:1527019989576};\\\", \\\"{x:539,y:740,t:1527019989584};\\\", \\\"{x:542,y:740,t:1527019989595};\\\", \\\"{x:548,y:737,t:1527019989612};\\\", \\\"{x:556,y:733,t:1527019989628};\\\", \\\"{x:565,y:729,t:1527019989645};\\\", \\\"{x:571,y:726,t:1527019989662};\\\", \\\"{x:576,y:725,t:1527019989678};\\\", \\\"{x:579,y:723,t:1527019989695};\\\", \\\"{x:582,y:722,t:1527019989712};\\\", \\\"{x:586,y:722,t:1527019989728};\\\", \\\"{x:588,y:721,t:1527019989745};\\\", \\\"{x:590,y:721,t:1527019989762};\\\", \\\"{x:593,y:720,t:1527019989779};\\\", \\\"{x:594,y:720,t:1527019989808};\\\", \\\"{x:594,y:719,t:1527019989824};\\\" ] }, { \\\"rt\\\": 9151, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 623944, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:595,y:719,t:1527019991081};\\\", \\\"{x:594,y:719,t:1527019991136};\\\", \\\"{x:593,y:719,t:1527019991159};\\\", \\\"{x:591,y:719,t:1527019991192};\\\", \\\"{x:590,y:719,t:1527019991215};\\\", \\\"{x:588,y:719,t:1527019991248};\\\", \\\"{x:587,y:719,t:1527019991288};\\\", \\\"{x:585,y:719,t:1527019991337};\\\", \\\"{x:584,y:719,t:1527019994552};\\\", \\\"{x:579,y:719,t:1527019994565};\\\", \\\"{x:571,y:720,t:1527019994582};\\\", \\\"{x:555,y:724,t:1527019994600};\\\", \\\"{x:520,y:726,t:1527019994616};\\\", \\\"{x:508,y:726,t:1527019994632};\\\", \\\"{x:507,y:726,t:1527019994649};\\\", \\\"{x:506,y:726,t:1527019994666};\\\", \\\"{x:505,y:726,t:1527019994682};\\\", \\\"{x:502,y:726,t:1527019994699};\\\", \\\"{x:499,y:726,t:1527019994716};\\\", \\\"{x:495,y:725,t:1527019994733};\\\", \\\"{x:489,y:723,t:1527019994749};\\\", \\\"{x:483,y:719,t:1527019994766};\\\", \\\"{x:478,y:715,t:1527019994783};\\\", \\\"{x:471,y:710,t:1527019994799};\\\", \\\"{x:458,y:700,t:1527019994816};\\\", \\\"{x:451,y:692,t:1527019994832};\\\", \\\"{x:443,y:684,t:1527019994849};\\\", \\\"{x:437,y:678,t:1527019994866};\\\", \\\"{x:435,y:674,t:1527019994882};\\\", \\\"{x:432,y:671,t:1527019994899};\\\", \\\"{x:432,y:670,t:1527019994916};\\\", \\\"{x:430,y:669,t:1527019994933};\\\", \\\"{x:429,y:667,t:1527019994949};\\\", \\\"{x:428,y:661,t:1527019994966};\\\", \\\"{x:426,y:651,t:1527019994982};\\\", \\\"{x:425,y:643,t:1527019994999};\\\", \\\"{x:424,y:626,t:1527019995017};\\\", \\\"{x:424,y:620,t:1527019995033};\\\", \\\"{x:424,y:615,t:1527019995049};\\\", \\\"{x:424,y:610,t:1527019995066};\\\", \\\"{x:426,y:603,t:1527019995083};\\\", \\\"{x:430,y:597,t:1527019995100};\\\", \\\"{x:434,y:591,t:1527019995117};\\\", \\\"{x:439,y:586,t:1527019995133};\\\", \\\"{x:452,y:581,t:1527019995149};\\\", \\\"{x:464,y:575,t:1527019995166};\\\", \\\"{x:483,y:568,t:1527019995183};\\\", \\\"{x:493,y:564,t:1527019995199};\\\", \\\"{x:508,y:561,t:1527019995217};\\\", \\\"{x:511,y:560,t:1527019995233};\\\", \\\"{x:516,y:559,t:1527019995249};\\\", \\\"{x:517,y:559,t:1527019995266};\\\", \\\"{x:519,y:558,t:1527019995283};\\\", \\\"{x:526,y:555,t:1527019995301};\\\", \\\"{x:536,y:552,t:1527019995317};\\\", \\\"{x:558,y:550,t:1527019995334};\\\", \\\"{x:573,y:547,t:1527019995349};\\\", \\\"{x:597,y:545,t:1527019995366};\\\", \\\"{x:618,y:541,t:1527019995383};\\\", \\\"{x:630,y:540,t:1527019995400};\\\", \\\"{x:632,y:540,t:1527019995416};\\\", \\\"{x:633,y:539,t:1527019995504};\\\", \\\"{x:639,y:539,t:1527019995673};\\\", \\\"{x:644,y:539,t:1527019995685};\\\", \\\"{x:673,y:539,t:1527019995700};\\\", \\\"{x:694,y:542,t:1527019995717};\\\", \\\"{x:756,y:542,t:1527019995734};\\\", \\\"{x:801,y:542,t:1527019995750};\\\", \\\"{x:837,y:542,t:1527019995767};\\\", \\\"{x:853,y:540,t:1527019995784};\\\", \\\"{x:862,y:538,t:1527019995800};\\\", \\\"{x:863,y:537,t:1527019995816};\\\", \\\"{x:863,y:535,t:1527019995848};\\\", \\\"{x:863,y:534,t:1527019995856};\\\", \\\"{x:863,y:533,t:1527019995867};\\\", \\\"{x:863,y:530,t:1527019995883};\\\", \\\"{x:861,y:526,t:1527019995900};\\\", \\\"{x:857,y:524,t:1527019995917};\\\", \\\"{x:856,y:523,t:1527019995935};\\\", \\\"{x:856,y:521,t:1527019995952};\\\", \\\"{x:855,y:519,t:1527019995967};\\\", \\\"{x:852,y:517,t:1527019995984};\\\", \\\"{x:847,y:515,t:1527019996001};\\\", \\\"{x:844,y:513,t:1527019996018};\\\", \\\"{x:843,y:513,t:1527019996033};\\\", \\\"{x:840,y:511,t:1527019996050};\\\", \\\"{x:837,y:510,t:1527019996067};\\\", \\\"{x:836,y:508,t:1527019996083};\\\", \\\"{x:835,y:508,t:1527019996100};\\\", \\\"{x:834,y:507,t:1527019996117};\\\", \\\"{x:827,y:507,t:1527019996391};\\\", \\\"{x:819,y:508,t:1527019996401};\\\", \\\"{x:807,y:515,t:1527019996417};\\\", \\\"{x:784,y:521,t:1527019996434};\\\", \\\"{x:755,y:530,t:1527019996450};\\\", \\\"{x:705,y:544,t:1527019996468};\\\", \\\"{x:656,y:553,t:1527019996485};\\\", \\\"{x:608,y:560,t:1527019996501};\\\", \\\"{x:549,y:570,t:1527019996518};\\\", \\\"{x:485,y:578,t:1527019996535};\\\", \\\"{x:405,y:591,t:1527019996551};\\\", \\\"{x:385,y:592,t:1527019996567};\\\", \\\"{x:336,y:592,t:1527019996583};\\\", \\\"{x:312,y:592,t:1527019996600};\\\", \\\"{x:276,y:592,t:1527019996617};\\\", \\\"{x:241,y:592,t:1527019996635};\\\", \\\"{x:185,y:585,t:1527019996651};\\\", \\\"{x:159,y:576,t:1527019996667};\\\", \\\"{x:123,y:571,t:1527019996685};\\\", \\\"{x:95,y:564,t:1527019996701};\\\", \\\"{x:77,y:559,t:1527019996717};\\\", \\\"{x:72,y:557,t:1527019996734};\\\", \\\"{x:71,y:556,t:1527019996751};\\\", \\\"{x:72,y:556,t:1527019996839};\\\", \\\"{x:74,y:555,t:1527019996852};\\\", \\\"{x:76,y:554,t:1527019996867};\\\", \\\"{x:81,y:551,t:1527019996884};\\\", \\\"{x:87,y:548,t:1527019996901};\\\", \\\"{x:94,y:545,t:1527019996917};\\\", \\\"{x:98,y:543,t:1527019996934};\\\", \\\"{x:104,y:540,t:1527019996951};\\\", \\\"{x:108,y:538,t:1527019996968};\\\", \\\"{x:115,y:536,t:1527019996983};\\\", \\\"{x:119,y:533,t:1527019997002};\\\", \\\"{x:120,y:533,t:1527019997017};\\\", \\\"{x:122,y:532,t:1527019997034};\\\", \\\"{x:123,y:532,t:1527019997065};\\\", \\\"{x:125,y:531,t:1527019997096};\\\", \\\"{x:127,y:529,t:1527019997104};\\\", \\\"{x:129,y:529,t:1527019997118};\\\", \\\"{x:135,y:528,t:1527019997135};\\\", \\\"{x:139,y:527,t:1527019997152};\\\", \\\"{x:149,y:525,t:1527019997169};\\\", \\\"{x:152,y:525,t:1527019997184};\\\", \\\"{x:153,y:526,t:1527019997657};\\\", \\\"{x:153,y:527,t:1527019997669};\\\", \\\"{x:157,y:532,t:1527019997687};\\\", \\\"{x:161,y:536,t:1527019997702};\\\", \\\"{x:168,y:545,t:1527019997719};\\\", \\\"{x:176,y:551,t:1527019997736};\\\", \\\"{x:178,y:554,t:1527019997751};\\\", \\\"{x:180,y:557,t:1527019997769};\\\", \\\"{x:181,y:560,t:1527019997785};\\\", \\\"{x:184,y:564,t:1527019997802};\\\", \\\"{x:191,y:573,t:1527019997819};\\\", \\\"{x:202,y:579,t:1527019997835};\\\", \\\"{x:214,y:588,t:1527019997852};\\\", \\\"{x:222,y:595,t:1527019997869};\\\", \\\"{x:227,y:599,t:1527019997885};\\\", \\\"{x:231,y:603,t:1527019997903};\\\", \\\"{x:237,y:608,t:1527019997919};\\\", \\\"{x:238,y:610,t:1527019997935};\\\", \\\"{x:239,y:607,t:1527019997992};\\\", \\\"{x:238,y:602,t:1527019998001};\\\", \\\"{x:233,y:595,t:1527019998019};\\\", \\\"{x:219,y:580,t:1527019998035};\\\", \\\"{x:202,y:568,t:1527019998052};\\\", \\\"{x:191,y:560,t:1527019998068};\\\", \\\"{x:186,y:556,t:1527019998085};\\\", \\\"{x:186,y:555,t:1527019998103};\\\", \\\"{x:185,y:554,t:1527019998118};\\\", \\\"{x:181,y:551,t:1527019998136};\\\", \\\"{x:180,y:549,t:1527019998153};\\\", \\\"{x:175,y:547,t:1527019998168};\\\", \\\"{x:175,y:545,t:1527019998186};\\\", \\\"{x:174,y:545,t:1527019998202};\\\", \\\"{x:173,y:544,t:1527019998224};\\\", \\\"{x:171,y:544,t:1527019998297};\\\", \\\"{x:171,y:543,t:1527019998305};\\\", \\\"{x:169,y:542,t:1527019998321};\\\", \\\"{x:167,y:542,t:1527019998336};\\\", \\\"{x:167,y:541,t:1527019998369};\\\", \\\"{x:167,y:541,t:1527019998458};\\\", \\\"{x:166,y:541,t:1527019998616};\\\", \\\"{x:166,y:542,t:1527019998640};\\\", \\\"{x:166,y:544,t:1527019998657};\\\", \\\"{x:166,y:547,t:1527019998670};\\\", \\\"{x:166,y:555,t:1527019998687};\\\", \\\"{x:166,y:570,t:1527019998703};\\\", \\\"{x:181,y:596,t:1527019998719};\\\", \\\"{x:204,y:612,t:1527019998736};\\\", \\\"{x:221,y:624,t:1527019998752};\\\", \\\"{x:250,y:633,t:1527019998770};\\\", \\\"{x:275,y:645,t:1527019998786};\\\", \\\"{x:304,y:656,t:1527019998802};\\\", \\\"{x:326,y:669,t:1527019998819};\\\", \\\"{x:347,y:679,t:1527019998836};\\\", \\\"{x:368,y:691,t:1527019998852};\\\", \\\"{x:383,y:706,t:1527019998869};\\\", \\\"{x:397,y:717,t:1527019998886};\\\", \\\"{x:408,y:721,t:1527019998902};\\\", \\\"{x:416,y:725,t:1527019998919};\\\", \\\"{x:426,y:729,t:1527019998936};\\\", \\\"{x:439,y:734,t:1527019998952};\\\", \\\"{x:456,y:743,t:1527019998971};\\\", \\\"{x:473,y:751,t:1527019998986};\\\", \\\"{x:481,y:758,t:1527019999003};\\\", \\\"{x:484,y:760,t:1527019999020};\\\", \\\"{x:485,y:760,t:1527019999036};\\\", \\\"{x:486,y:760,t:1527019999145};\\\", \\\"{x:488,y:760,t:1527019999167};\\\", \\\"{x:488,y:760,t:1527019999225};\\\", \\\"{x:489,y:759,t:1527019999297};\\\", \\\"{x:490,y:757,t:1527019999304};\\\", \\\"{x:493,y:754,t:1527019999321};\\\", \\\"{x:496,y:745,t:1527019999337};\\\", \\\"{x:497,y:741,t:1527019999353};\\\", \\\"{x:500,y:738,t:1527019999369};\\\", \\\"{x:500,y:737,t:1527019999387};\\\", \\\"{x:501,y:736,t:1527019999456};\\\", \\\"{x:502,y:736,t:1527019999471};\\\", \\\"{x:503,y:736,t:1527019999486};\\\", \\\"{x:509,y:734,t:1527019999504};\\\", \\\"{x:511,y:733,t:1527019999519};\\\", \\\"{x:512,y:732,t:1527019999551};\\\", \\\"{x:512,y:732,t:1527019999607};\\\" ] }, { \\\"rt\\\": 11267, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 636469, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:730,t:1527020003441};\\\", \\\"{x:493,y:711,t:1527020003455};\\\", \\\"{x:469,y:697,t:1527020003467};\\\", \\\"{x:430,y:671,t:1527020003483};\\\", \\\"{x:352,y:621,t:1527020003512};\\\", \\\"{x:340,y:614,t:1527020003524};\\\", \\\"{x:327,y:609,t:1527020003539};\\\", \\\"{x:324,y:606,t:1527020003556};\\\", \\\"{x:325,y:604,t:1527020006137};\\\", \\\"{x:329,y:601,t:1527020006144};\\\", \\\"{x:337,y:595,t:1527020006161};\\\", \\\"{x:359,y:582,t:1527020006176};\\\", \\\"{x:370,y:577,t:1527020006193};\\\", \\\"{x:382,y:571,t:1527020006209};\\\", \\\"{x:385,y:569,t:1527020006226};\\\", \\\"{x:387,y:568,t:1527020006242};\\\", \\\"{x:389,y:567,t:1527020006272};\\\", \\\"{x:390,y:567,t:1527020006287};\\\", \\\"{x:390,y:566,t:1527020006319};\\\", \\\"{x:390,y:565,t:1527020006328};\\\", \\\"{x:390,y:564,t:1527020006343};\\\", \\\"{x:386,y:560,t:1527020006359};\\\", \\\"{x:368,y:554,t:1527020006376};\\\", \\\"{x:357,y:552,t:1527020006393};\\\", \\\"{x:355,y:551,t:1527020006409};\\\", \\\"{x:354,y:551,t:1527020006616};\\\", \\\"{x:350,y:552,t:1527020006626};\\\", \\\"{x:320,y:559,t:1527020006643};\\\", \\\"{x:293,y:562,t:1527020006659};\\\", \\\"{x:240,y:562,t:1527020006676};\\\", \\\"{x:194,y:559,t:1527020006692};\\\", \\\"{x:146,y:553,t:1527020006710};\\\", \\\"{x:107,y:548,t:1527020006726};\\\", \\\"{x:82,y:541,t:1527020006742};\\\", \\\"{x:70,y:540,t:1527020006758};\\\", \\\"{x:69,y:540,t:1527020006776};\\\", \\\"{x:68,y:539,t:1527020006824};\\\", \\\"{x:68,y:538,t:1527020006839};\\\", \\\"{x:69,y:537,t:1527020006848};\\\", \\\"{x:70,y:535,t:1527020006859};\\\", \\\"{x:74,y:534,t:1527020006876};\\\", \\\"{x:80,y:532,t:1527020006893};\\\", \\\"{x:86,y:529,t:1527020006910};\\\", \\\"{x:92,y:526,t:1527020006926};\\\", \\\"{x:96,y:526,t:1527020006943};\\\", \\\"{x:104,y:526,t:1527020006960};\\\", \\\"{x:108,y:526,t:1527020006976};\\\", \\\"{x:112,y:526,t:1527020006993};\\\", \\\"{x:116,y:527,t:1527020007010};\\\", \\\"{x:120,y:529,t:1527020007026};\\\", \\\"{x:122,y:530,t:1527020007044};\\\", \\\"{x:124,y:532,t:1527020007113};\\\", \\\"{x:125,y:535,t:1527020007127};\\\", \\\"{x:126,y:537,t:1527020007143};\\\", \\\"{x:127,y:541,t:1527020007160};\\\", \\\"{x:131,y:544,t:1527020007177};\\\", \\\"{x:135,y:546,t:1527020007193};\\\", \\\"{x:137,y:547,t:1527020007211};\\\", \\\"{x:139,y:547,t:1527020007240};\\\", \\\"{x:144,y:547,t:1527020007265};\\\", \\\"{x:151,y:548,t:1527020007277};\\\", \\\"{x:164,y:549,t:1527020007293};\\\", \\\"{x:168,y:550,t:1527020007310};\\\", \\\"{x:169,y:550,t:1527020007326};\\\", \\\"{x:171,y:550,t:1527020007425};\\\", \\\"{x:173,y:550,t:1527020007443};\\\", \\\"{x:174,y:550,t:1527020007460};\\\", \\\"{x:176,y:550,t:1527020007477};\\\", \\\"{x:177,y:550,t:1527020007494};\\\", \\\"{x:177,y:550,t:1527020007554};\\\", \\\"{x:175,y:552,t:1527020007633};\\\", \\\"{x:174,y:552,t:1527020007643};\\\", \\\"{x:164,y:552,t:1527020007661};\\\", \\\"{x:151,y:552,t:1527020007677};\\\", \\\"{x:144,y:551,t:1527020007694};\\\", \\\"{x:140,y:549,t:1527020007711};\\\", \\\"{x:139,y:549,t:1527020007727};\\\", \\\"{x:138,y:548,t:1527020007744};\\\", \\\"{x:138,y:547,t:1527020007768};\\\", \\\"{x:137,y:547,t:1527020007777};\\\", \\\"{x:136,y:545,t:1527020007795};\\\", \\\"{x:136,y:544,t:1527020007810};\\\", \\\"{x:136,y:543,t:1527020007827};\\\", \\\"{x:136,y:542,t:1527020007952};\\\", \\\"{x:138,y:541,t:1527020007960};\\\", \\\"{x:140,y:539,t:1527020007977};\\\", \\\"{x:142,y:538,t:1527020007994};\\\", \\\"{x:144,y:538,t:1527020008011};\\\", \\\"{x:145,y:537,t:1527020008027};\\\", \\\"{x:146,y:537,t:1527020008368};\\\", \\\"{x:148,y:538,t:1527020008377};\\\", \\\"{x:151,y:540,t:1527020008395};\\\", \\\"{x:152,y:543,t:1527020008411};\\\", \\\"{x:160,y:550,t:1527020008427};\\\", \\\"{x:165,y:555,t:1527020008444};\\\", \\\"{x:171,y:559,t:1527020008461};\\\", \\\"{x:177,y:565,t:1527020008477};\\\", \\\"{x:185,y:572,t:1527020008494};\\\", \\\"{x:192,y:579,t:1527020008511};\\\", \\\"{x:203,y:594,t:1527020008529};\\\", \\\"{x:212,y:606,t:1527020008544};\\\", \\\"{x:218,y:611,t:1527020008561};\\\", \\\"{x:222,y:613,t:1527020008577};\\\", \\\"{x:230,y:617,t:1527020008594};\\\", \\\"{x:238,y:625,t:1527020008611};\\\", \\\"{x:247,y:631,t:1527020008627};\\\", \\\"{x:256,y:640,t:1527020008644};\\\", \\\"{x:262,y:645,t:1527020008661};\\\", \\\"{x:264,y:650,t:1527020008677};\\\", \\\"{x:266,y:652,t:1527020008694};\\\", \\\"{x:267,y:653,t:1527020008711};\\\", \\\"{x:270,y:656,t:1527020008727};\\\", \\\"{x:290,y:669,t:1527020008744};\\\", \\\"{x:309,y:683,t:1527020008760};\\\", \\\"{x:327,y:693,t:1527020008778};\\\", \\\"{x:341,y:702,t:1527020008794};\\\", \\\"{x:346,y:704,t:1527020008811};\\\", \\\"{x:348,y:706,t:1527020008827};\\\", \\\"{x:349,y:706,t:1527020008844};\\\", \\\"{x:350,y:706,t:1527020008896};\\\", \\\"{x:350,y:699,t:1527020008912};\\\", \\\"{x:346,y:668,t:1527020008929};\\\", \\\"{x:326,y:640,t:1527020008945};\\\", \\\"{x:296,y:617,t:1527020008961};\\\", \\\"{x:274,y:601,t:1527020008978};\\\", \\\"{x:260,y:590,t:1527020008995};\\\", \\\"{x:253,y:586,t:1527020009011};\\\", \\\"{x:251,y:584,t:1527020009027};\\\", \\\"{x:247,y:582,t:1527020009044};\\\", \\\"{x:234,y:574,t:1527020009061};\\\", \\\"{x:219,y:566,t:1527020009078};\\\", \\\"{x:204,y:557,t:1527020009095};\\\", \\\"{x:196,y:552,t:1527020009112};\\\", \\\"{x:187,y:549,t:1527020009128};\\\", \\\"{x:183,y:548,t:1527020009145};\\\", \\\"{x:181,y:547,t:1527020009161};\\\", \\\"{x:175,y:543,t:1527020009178};\\\", \\\"{x:163,y:536,t:1527020009195};\\\", \\\"{x:152,y:530,t:1527020009212};\\\", \\\"{x:147,y:529,t:1527020009229};\\\", \\\"{x:148,y:529,t:1527020009448};\\\", \\\"{x:156,y:529,t:1527020009462};\\\", \\\"{x:171,y:532,t:1527020009478};\\\", \\\"{x:180,y:536,t:1527020009495};\\\", \\\"{x:187,y:538,t:1527020009512};\\\", \\\"{x:194,y:541,t:1527020009529};\\\", \\\"{x:204,y:547,t:1527020009545};\\\", \\\"{x:217,y:556,t:1527020009563};\\\", \\\"{x:231,y:565,t:1527020009578};\\\", \\\"{x:242,y:575,t:1527020009595};\\\", \\\"{x:251,y:584,t:1527020009612};\\\", \\\"{x:259,y:594,t:1527020009628};\\\", \\\"{x:271,y:608,t:1527020009645};\\\", \\\"{x:288,y:628,t:1527020009662};\\\", \\\"{x:298,y:641,t:1527020009679};\\\", \\\"{x:307,y:652,t:1527020009695};\\\", \\\"{x:307,y:653,t:1527020009712};\\\", \\\"{x:308,y:653,t:1527020009729};\\\", \\\"{x:306,y:651,t:1527020009768};\\\", \\\"{x:297,y:644,t:1527020009779};\\\", \\\"{x:266,y:623,t:1527020009796};\\\", \\\"{x:233,y:596,t:1527020009813};\\\", \\\"{x:211,y:575,t:1527020009829};\\\", \\\"{x:200,y:568,t:1527020009845};\\\", \\\"{x:195,y:564,t:1527020009861};\\\", \\\"{x:193,y:563,t:1527020009878};\\\", \\\"{x:190,y:562,t:1527020009896};\\\", \\\"{x:188,y:559,t:1527020009912};\\\", \\\"{x:185,y:557,t:1527020009929};\\\", \\\"{x:182,y:556,t:1527020009945};\\\", \\\"{x:180,y:551,t:1527020010049};\\\", \\\"{x:178,y:548,t:1527020010063};\\\", \\\"{x:173,y:541,t:1527020010079};\\\", \\\"{x:168,y:534,t:1527020010095};\\\", \\\"{x:155,y:524,t:1527020010112};\\\", \\\"{x:153,y:522,t:1527020010129};\\\", \\\"{x:152,y:522,t:1527020010271};\\\", \\\"{x:151,y:521,t:1527020010279};\\\", \\\"{x:150,y:521,t:1527020010319};\\\", \\\"{x:150,y:521,t:1527020010320};\\\", \\\"{x:150,y:522,t:1527020010329};\\\", \\\"{x:150,y:526,t:1527020010347};\\\", \\\"{x:152,y:532,t:1527020010363};\\\", \\\"{x:153,y:536,t:1527020010378};\\\", \\\"{x:153,y:537,t:1527020010396};\\\", \\\"{x:153,y:538,t:1527020010448};\\\", \\\"{x:153,y:539,t:1527020010462};\\\", \\\"{x:153,y:541,t:1527020010480};\\\", \\\"{x:153,y:550,t:1527020010496};\\\", \\\"{x:152,y:552,t:1527020010513};\\\", \\\"{x:151,y:554,t:1527020010543};\\\", \\\"{x:151,y:553,t:1527020010872};\\\", \\\"{x:151,y:551,t:1527020010881};\\\", \\\"{x:151,y:549,t:1527020010896};\\\", \\\"{x:151,y:548,t:1527020010913};\\\", \\\"{x:151,y:547,t:1527020010928};\\\", \\\"{x:151,y:546,t:1527020010951};\\\", \\\"{x:151,y:545,t:1527020010963};\\\", \\\"{x:151,y:544,t:1527020010991};\\\", \\\"{x:151,y:543,t:1527020011016};\\\", \\\"{x:151,y:542,t:1527020011031};\\\", \\\"{x:151,y:541,t:1527020011047};\\\", \\\"{x:151,y:540,t:1527020011063};\\\", \\\"{x:152,y:539,t:1527020011296};\\\", \\\"{x:153,y:539,t:1527020011313};\\\", \\\"{x:155,y:539,t:1527020011360};\\\", \\\"{x:156,y:539,t:1527020011367};\\\", \\\"{x:159,y:539,t:1527020011379};\\\", \\\"{x:164,y:541,t:1527020011396};\\\", \\\"{x:169,y:544,t:1527020011413};\\\", \\\"{x:173,y:545,t:1527020011430};\\\", \\\"{x:178,y:547,t:1527020011446};\\\", \\\"{x:182,y:547,t:1527020011464};\\\", \\\"{x:192,y:550,t:1527020011481};\\\", \\\"{x:202,y:556,t:1527020011497};\\\", \\\"{x:215,y:563,t:1527020011514};\\\", \\\"{x:229,y:574,t:1527020011530};\\\", \\\"{x:240,y:583,t:1527020011547};\\\", \\\"{x:260,y:599,t:1527020011563};\\\", \\\"{x:279,y:616,t:1527020011580};\\\", \\\"{x:307,y:635,t:1527020011596};\\\", \\\"{x:324,y:646,t:1527020011613};\\\", \\\"{x:332,y:651,t:1527020011630};\\\", \\\"{x:340,y:654,t:1527020011647};\\\", \\\"{x:352,y:659,t:1527020011663};\\\", \\\"{x:367,y:665,t:1527020011680};\\\", \\\"{x:380,y:666,t:1527020011697};\\\", \\\"{x:393,y:671,t:1527020011713};\\\", \\\"{x:404,y:675,t:1527020011730};\\\", \\\"{x:407,y:676,t:1527020011747};\\\", \\\"{x:412,y:679,t:1527020011764};\\\", \\\"{x:423,y:685,t:1527020011780};\\\", \\\"{x:439,y:696,t:1527020011797};\\\", \\\"{x:454,y:707,t:1527020011814};\\\", \\\"{x:465,y:715,t:1527020011830};\\\", \\\"{x:470,y:716,t:1527020011847};\\\", \\\"{x:471,y:718,t:1527020011864};\\\", \\\"{x:475,y:720,t:1527020011881};\\\", \\\"{x:481,y:724,t:1527020011897};\\\", \\\"{x:489,y:730,t:1527020011913};\\\", \\\"{x:495,y:737,t:1527020011930};\\\", \\\"{x:499,y:738,t:1527020011947};\\\", \\\"{x:499,y:739,t:1527020011963};\\\", \\\"{x:500,y:740,t:1527020011980};\\\", \\\"{x:502,y:740,t:1527020012039};\\\", \\\"{x:504,y:740,t:1527020012071};\\\", \\\"{x:504,y:740,t:1527020012132};\\\" ] }, { \\\"rt\\\": 36681, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 674360, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:739,t:1527020043419};\\\", \\\"{x:499,y:738,t:1527020043427};\\\", \\\"{x:498,y:737,t:1527020043443};\\\", \\\"{x:497,y:736,t:1527020043474};\\\", \\\"{x:496,y:736,t:1527020043570};\\\", \\\"{x:495,y:736,t:1527020043578};\\\", \\\"{x:492,y:736,t:1527020043593};\\\", \\\"{x:489,y:736,t:1527020043610};\\\", \\\"{x:483,y:732,t:1527020043627};\\\", \\\"{x:479,y:727,t:1527020043643};\\\", \\\"{x:475,y:718,t:1527020043661};\\\", \\\"{x:473,y:707,t:1527020043676};\\\", \\\"{x:465,y:696,t:1527020043692};\\\", \\\"{x:464,y:692,t:1527020043703};\\\", \\\"{x:456,y:686,t:1527020043720};\\\", \\\"{x:450,y:680,t:1527020043737};\\\", \\\"{x:443,y:676,t:1527020043753};\\\", \\\"{x:434,y:672,t:1527020043770};\\\", \\\"{x:428,y:672,t:1527020043787};\\\", \\\"{x:424,y:669,t:1527020043804};\\\", \\\"{x:422,y:669,t:1527020043820};\\\", \\\"{x:419,y:668,t:1527020043842};\\\", \\\"{x:417,y:666,t:1527020043859};\\\", \\\"{x:415,y:666,t:1527020043876};\\\", \\\"{x:414,y:666,t:1527020043963};\\\", \\\"{x:414,y:665,t:1527020044115};\\\", \\\"{x:414,y:664,t:1527020044132};\\\", \\\"{x:414,y:663,t:1527020044146};\\\", \\\"{x:414,y:662,t:1527020044162};\\\", \\\"{x:413,y:661,t:1527020044176};\\\", \\\"{x:413,y:659,t:1527020044211};\\\", \\\"{x:412,y:659,t:1527020046179};\\\", \\\"{x:408,y:659,t:1527020046194};\\\", \\\"{x:407,y:659,t:1527020046218};\\\", \\\"{x:406,y:660,t:1527020046474};\\\", \\\"{x:405,y:660,t:1527020046482};\\\", \\\"{x:404,y:660,t:1527020046496};\\\", \\\"{x:403,y:660,t:1527020046512};\\\", \\\"{x:402,y:660,t:1527020046529};\\\", \\\"{x:409,y:660,t:1527020047467};\\\", \\\"{x:411,y:660,t:1527020047480};\\\", \\\"{x:431,y:656,t:1527020047497};\\\", \\\"{x:447,y:651,t:1527020047513};\\\", \\\"{x:455,y:648,t:1527020047530};\\\", \\\"{x:457,y:647,t:1527020047545};\\\", \\\"{x:458,y:647,t:1527020047562};\\\", \\\"{x:458,y:646,t:1527020047579};\\\", \\\"{x:460,y:645,t:1527020047595};\\\", \\\"{x:461,y:644,t:1527020047612};\\\", \\\"{x:464,y:641,t:1527020047629};\\\", \\\"{x:467,y:633,t:1527020047647};\\\", \\\"{x:470,y:627,t:1527020047663};\\\", \\\"{x:476,y:618,t:1527020047679};\\\", \\\"{x:482,y:612,t:1527020047696};\\\", \\\"{x:487,y:610,t:1527020047712};\\\", \\\"{x:491,y:607,t:1527020047729};\\\", \\\"{x:503,y:603,t:1527020047746};\\\", \\\"{x:515,y:599,t:1527020047763};\\\", \\\"{x:527,y:599,t:1527020047779};\\\", \\\"{x:549,y:594,t:1527020047795};\\\", \\\"{x:563,y:589,t:1527020047813};\\\", \\\"{x:572,y:587,t:1527020047829};\\\", \\\"{x:578,y:584,t:1527020047845};\\\", \\\"{x:583,y:583,t:1527020047863};\\\", \\\"{x:585,y:581,t:1527020047879};\\\", \\\"{x:586,y:580,t:1527020047994};\\\", \\\"{x:586,y:579,t:1527020048018};\\\", \\\"{x:587,y:579,t:1527020048029};\\\", \\\"{x:590,y:578,t:1527020048046};\\\", \\\"{x:596,y:577,t:1527020048063};\\\", \\\"{x:604,y:575,t:1527020048079};\\\", \\\"{x:607,y:574,t:1527020048095};\\\", \\\"{x:611,y:573,t:1527020048112};\\\", \\\"{x:611,y:572,t:1527020048129};\\\", \\\"{x:617,y:572,t:1527020048321};\\\", \\\"{x:622,y:572,t:1527020048330};\\\", \\\"{x:642,y:564,t:1527020048347};\\\", \\\"{x:661,y:559,t:1527020048364};\\\", \\\"{x:687,y:550,t:1527020048380};\\\", \\\"{x:706,y:541,t:1527020048396};\\\", \\\"{x:725,y:531,t:1527020048413};\\\", \\\"{x:743,y:523,t:1527020048431};\\\", \\\"{x:755,y:519,t:1527020048446};\\\", \\\"{x:763,y:513,t:1527020048464};\\\", \\\"{x:781,y:503,t:1527020048480};\\\", \\\"{x:801,y:494,t:1527020048496};\\\", \\\"{x:814,y:487,t:1527020048513};\\\", \\\"{x:822,y:481,t:1527020048531};\\\", \\\"{x:826,y:477,t:1527020048546};\\\", \\\"{x:827,y:477,t:1527020048570};\\\", \\\"{x:829,y:477,t:1527020048618};\\\", \\\"{x:833,y:477,t:1527020048634};\\\", \\\"{x:835,y:477,t:1527020048658};\\\", \\\"{x:836,y:477,t:1527020048714};\\\", \\\"{x:837,y:477,t:1527020048731};\\\", \\\"{x:838,y:478,t:1527020048746};\\\", \\\"{x:839,y:479,t:1527020048763};\\\", \\\"{x:839,y:480,t:1527020048786};\\\", \\\"{x:839,y:482,t:1527020048835};\\\", \\\"{x:839,y:483,t:1527020048866};\\\", \\\"{x:840,y:483,t:1527020048881};\\\", \\\"{x:840,y:484,t:1527020048898};\\\", \\\"{x:840,y:485,t:1527020048914};\\\", \\\"{x:840,y:486,t:1527020048987};\\\", \\\"{x:841,y:486,t:1527020048998};\\\", \\\"{x:841,y:488,t:1527020049015};\\\", \\\"{x:841,y:492,t:1527020049031};\\\", \\\"{x:842,y:495,t:1527020049048};\\\", \\\"{x:843,y:496,t:1527020049063};\\\", \\\"{x:843,y:498,t:1527020049080};\\\", \\\"{x:843,y:499,t:1527020049338};\\\", \\\"{x:843,y:501,t:1527020049348};\\\", \\\"{x:842,y:502,t:1527020049363};\\\", \\\"{x:837,y:506,t:1527020049381};\\\", \\\"{x:826,y:511,t:1527020049397};\\\", \\\"{x:811,y:522,t:1527020049415};\\\", \\\"{x:796,y:535,t:1527020049430};\\\", \\\"{x:780,y:550,t:1527020049447};\\\", \\\"{x:772,y:560,t:1527020049465};\\\", \\\"{x:763,y:574,t:1527020049481};\\\", \\\"{x:746,y:588,t:1527020049497};\\\", \\\"{x:721,y:609,t:1527020049514};\\\", \\\"{x:702,y:624,t:1527020049531};\\\", \\\"{x:669,y:646,t:1527020049548};\\\", \\\"{x:636,y:668,t:1527020049564};\\\", \\\"{x:614,y:683,t:1527020049580};\\\", \\\"{x:604,y:693,t:1527020049598};\\\", \\\"{x:597,y:696,t:1527020049615};\\\", \\\"{x:592,y:701,t:1527020049631};\\\", \\\"{x:585,y:706,t:1527020049648};\\\", \\\"{x:577,y:712,t:1527020049665};\\\", \\\"{x:566,y:722,t:1527020049682};\\\", \\\"{x:559,y:726,t:1527020049698};\\\", \\\"{x:554,y:729,t:1527020049714};\\\", \\\"{x:553,y:731,t:1527020049730};\\\", \\\"{x:546,y:735,t:1527020049747};\\\", \\\"{x:542,y:738,t:1527020049764};\\\", \\\"{x:537,y:742,t:1527020049781};\\\", \\\"{x:534,y:745,t:1527020049798};\\\", \\\"{x:525,y:748,t:1527020049815};\\\", \\\"{x:518,y:751,t:1527020049831};\\\", \\\"{x:515,y:753,t:1527020049847};\\\", \\\"{x:516,y:753,t:1527020050419};\\\", \\\"{x:517,y:753,t:1527020050431};\\\", \\\"{x:518,y:753,t:1527020050514};\\\" ] }, { \\\"rt\\\": 30005, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 705596, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:753,t:1527020054739};\\\", \\\"{x:605,y:753,t:1527020054756};\\\", \\\"{x:709,y:772,t:1527020054770};\\\", \\\"{x:793,y:787,t:1527020054788};\\\", \\\"{x:838,y:794,t:1527020054802};\\\", \\\"{x:876,y:801,t:1527020054818};\\\", \\\"{x:934,y:818,t:1527020054835};\\\", \\\"{x:980,y:833,t:1527020054851};\\\", \\\"{x:1002,y:841,t:1527020054868};\\\", \\\"{x:1012,y:844,t:1527020054885};\\\", \\\"{x:1020,y:847,t:1527020054901};\\\", \\\"{x:1028,y:850,t:1527020054919};\\\", \\\"{x:1038,y:850,t:1527020054936};\\\", \\\"{x:1069,y:852,t:1527020054952};\\\", \\\"{x:1134,y:857,t:1527020054968};\\\", \\\"{x:1246,y:859,t:1527020054985};\\\", \\\"{x:1460,y:868,t:1527020055002};\\\", \\\"{x:1617,y:868,t:1527020055019};\\\", \\\"{x:1753,y:868,t:1527020055036};\\\", \\\"{x:1859,y:869,t:1527020055052};\\\", \\\"{x:1919,y:869,t:1527020055069};\\\", \\\"{x:1919,y:868,t:1527020055086};\\\", \\\"{x:1917,y:869,t:1527020055194};\\\", \\\"{x:1912,y:869,t:1527020055201};\\\", \\\"{x:1902,y:873,t:1527020055219};\\\", \\\"{x:1890,y:877,t:1527020055236};\\\", \\\"{x:1876,y:881,t:1527020055251};\\\", \\\"{x:1852,y:887,t:1527020055268};\\\", \\\"{x:1826,y:893,t:1527020055286};\\\", \\\"{x:1774,y:906,t:1527020055303};\\\", \\\"{x:1719,y:919,t:1527020055318};\\\", \\\"{x:1651,y:936,t:1527020055335};\\\", \\\"{x:1589,y:955,t:1527020055353};\\\", \\\"{x:1542,y:976,t:1527020055369};\\\", \\\"{x:1515,y:986,t:1527020055387};\\\", \\\"{x:1496,y:993,t:1527020055402};\\\", \\\"{x:1490,y:994,t:1527020055419};\\\", \\\"{x:1488,y:996,t:1527020055436};\\\", \\\"{x:1489,y:996,t:1527020055579};\\\", \\\"{x:1496,y:994,t:1527020055587};\\\", \\\"{x:1504,y:991,t:1527020055603};\\\", \\\"{x:1516,y:985,t:1527020055619};\\\", \\\"{x:1519,y:983,t:1527020055636};\\\", \\\"{x:1523,y:981,t:1527020055653};\\\", \\\"{x:1524,y:980,t:1527020055669};\\\", \\\"{x:1525,y:979,t:1527020055747};\\\", \\\"{x:1526,y:978,t:1527020055867};\\\", \\\"{x:1527,y:977,t:1527020055899};\\\", \\\"{x:1529,y:976,t:1527020055915};\\\", \\\"{x:1532,y:976,t:1527020055930};\\\", \\\"{x:1533,y:975,t:1527020055947};\\\", \\\"{x:1535,y:975,t:1527020055962};\\\", \\\"{x:1536,y:975,t:1527020055970};\\\", \\\"{x:1537,y:973,t:1527020055986};\\\", \\\"{x:1538,y:973,t:1527020056003};\\\", \\\"{x:1539,y:973,t:1527020056035};\\\", \\\"{x:1540,y:972,t:1527020056049};\\\", \\\"{x:1541,y:972,t:1527020056058};\\\", \\\"{x:1542,y:972,t:1527020064291};\\\", \\\"{x:1539,y:970,t:1527020064299};\\\", \\\"{x:1529,y:970,t:1527020064312};\\\", \\\"{x:1516,y:969,t:1527020064329};\\\", \\\"{x:1498,y:967,t:1527020064345};\\\", \\\"{x:1474,y:967,t:1527020064362};\\\", \\\"{x:1443,y:967,t:1527020064378};\\\", \\\"{x:1432,y:965,t:1527020064395};\\\", \\\"{x:1428,y:965,t:1527020064412};\\\", \\\"{x:1427,y:965,t:1527020064474};\\\", \\\"{x:1426,y:965,t:1527020065083};\\\", \\\"{x:1425,y:965,t:1527020065195};\\\", \\\"{x:1424,y:965,t:1527020065213};\\\", \\\"{x:1423,y:965,t:1527020065243};\\\", \\\"{x:1422,y:965,t:1527020065283};\\\", \\\"{x:1421,y:965,t:1527020065296};\\\", \\\"{x:1420,y:965,t:1527020065312};\\\", \\\"{x:1419,y:965,t:1527020065330};\\\", \\\"{x:1418,y:965,t:1527020065378};\\\", \\\"{x:1417,y:965,t:1527020065402};\\\", \\\"{x:1416,y:965,t:1527020065427};\\\", \\\"{x:1415,y:965,t:1527020065507};\\\", \\\"{x:1414,y:965,t:1527020065643};\\\", \\\"{x:1413,y:965,t:1527020065723};\\\", \\\"{x:1412,y:965,t:1527020065755};\\\", \\\"{x:1411,y:965,t:1527020065787};\\\", \\\"{x:1410,y:965,t:1527020065874};\\\", \\\"{x:1409,y:965,t:1527020065915};\\\", \\\"{x:1408,y:965,t:1527020065939};\\\", \\\"{x:1406,y:965,t:1527020065979};\\\", \\\"{x:1404,y:965,t:1527020066026};\\\", \\\"{x:1403,y:965,t:1527020066075};\\\", \\\"{x:1402,y:965,t:1527020066106};\\\", \\\"{x:1401,y:965,t:1527020066171};\\\", \\\"{x:1400,y:965,t:1527020066323};\\\", \\\"{x:1399,y:965,t:1527020066346};\\\", \\\"{x:1398,y:965,t:1527020066395};\\\", \\\"{x:1397,y:965,t:1527020066442};\\\", \\\"{x:1396,y:965,t:1527020066475};\\\", \\\"{x:1395,y:965,t:1527020066522};\\\", \\\"{x:1394,y:965,t:1527020066555};\\\", \\\"{x:1393,y:965,t:1527020066635};\\\", \\\"{x:1392,y:965,t:1527020066658};\\\", \\\"{x:1391,y:965,t:1527020066730};\\\", \\\"{x:1390,y:965,t:1527020066762};\\\", \\\"{x:1385,y:962,t:1527020073729};\\\", \\\"{x:1377,y:953,t:1527020073737};\\\", \\\"{x:1355,y:929,t:1527020073753};\\\", \\\"{x:1338,y:915,t:1527020073770};\\\", \\\"{x:1330,y:907,t:1527020073787};\\\", \\\"{x:1327,y:904,t:1527020073803};\\\", \\\"{x:1327,y:901,t:1527020073821};\\\", \\\"{x:1325,y:898,t:1527020073931};\\\", \\\"{x:1325,y:897,t:1527020073939};\\\", \\\"{x:1323,y:888,t:1527020073954};\\\", \\\"{x:1320,y:878,t:1527020073972};\\\", \\\"{x:1318,y:858,t:1527020073989};\\\", \\\"{x:1315,y:839,t:1527020074005};\\\", \\\"{x:1314,y:821,t:1527020074021};\\\", \\\"{x:1312,y:807,t:1527020074039};\\\", \\\"{x:1311,y:802,t:1527020074055};\\\", \\\"{x:1310,y:799,t:1527020074071};\\\", \\\"{x:1310,y:797,t:1527020074107};\\\", \\\"{x:1310,y:796,t:1527020074121};\\\", \\\"{x:1309,y:788,t:1527020074138};\\\", \\\"{x:1309,y:778,t:1527020074155};\\\", \\\"{x:1309,y:766,t:1527020074171};\\\", \\\"{x:1310,y:758,t:1527020074188};\\\", \\\"{x:1311,y:754,t:1527020074205};\\\", \\\"{x:1311,y:751,t:1527020074221};\\\", \\\"{x:1311,y:747,t:1527020074238};\\\", \\\"{x:1312,y:740,t:1527020074255};\\\", \\\"{x:1312,y:730,t:1527020074271};\\\", \\\"{x:1312,y:726,t:1527020074288};\\\", \\\"{x:1312,y:723,t:1527020074305};\\\", \\\"{x:1312,y:722,t:1527020074321};\\\", \\\"{x:1314,y:723,t:1527020074443};\\\", \\\"{x:1315,y:726,t:1527020074456};\\\", \\\"{x:1315,y:735,t:1527020074471};\\\", \\\"{x:1316,y:739,t:1527020074488};\\\", \\\"{x:1316,y:743,t:1527020074505};\\\", \\\"{x:1317,y:751,t:1527020074522};\\\", \\\"{x:1317,y:754,t:1527020074538};\\\", \\\"{x:1318,y:758,t:1527020074554};\\\", \\\"{x:1320,y:763,t:1527020074573};\\\", \\\"{x:1320,y:767,t:1527020074589};\\\", \\\"{x:1320,y:771,t:1527020074605};\\\", \\\"{x:1320,y:775,t:1527020074623};\\\", \\\"{x:1320,y:778,t:1527020074639};\\\", \\\"{x:1320,y:779,t:1527020074655};\\\", \\\"{x:1320,y:781,t:1527020074673};\\\", \\\"{x:1320,y:782,t:1527020074688};\\\", \\\"{x:1320,y:785,t:1527020074705};\\\", \\\"{x:1318,y:789,t:1527020074722};\\\", \\\"{x:1317,y:793,t:1527020074738};\\\", \\\"{x:1316,y:796,t:1527020074755};\\\", \\\"{x:1314,y:798,t:1527020074772};\\\", \\\"{x:1314,y:796,t:1527020075019};\\\", \\\"{x:1314,y:792,t:1527020075026};\\\", \\\"{x:1314,y:787,t:1527020075041};\\\", \\\"{x:1316,y:778,t:1527020075055};\\\", \\\"{x:1319,y:772,t:1527020075073};\\\", \\\"{x:1319,y:769,t:1527020075089};\\\", \\\"{x:1319,y:765,t:1527020075106};\\\", \\\"{x:1319,y:762,t:1527020075163};\\\", \\\"{x:1320,y:762,t:1527020075651};\\\", \\\"{x:1321,y:762,t:1527020075715};\\\", \\\"{x:1322,y:762,t:1527020075723};\\\", \\\"{x:1326,y:761,t:1527020075739};\\\", \\\"{x:1331,y:761,t:1527020075756};\\\", \\\"{x:1334,y:761,t:1527020075774};\\\", \\\"{x:1335,y:761,t:1527020075789};\\\", \\\"{x:1336,y:761,t:1527020075807};\\\", \\\"{x:1336,y:762,t:1527020075823};\\\", \\\"{x:1337,y:762,t:1527020075939};\\\", \\\"{x:1338,y:762,t:1527020075946};\\\", \\\"{x:1339,y:763,t:1527020075956};\\\", \\\"{x:1340,y:765,t:1527020075974};\\\", \\\"{x:1340,y:767,t:1527020075991};\\\", \\\"{x:1340,y:770,t:1527020076006};\\\", \\\"{x:1340,y:771,t:1527020076035};\\\", \\\"{x:1340,y:772,t:1527020076089};\\\", \\\"{x:1340,y:774,t:1527020076106};\\\", \\\"{x:1338,y:779,t:1527020076122};\\\", \\\"{x:1335,y:785,t:1527020076140};\\\", \\\"{x:1331,y:789,t:1527020076156};\\\", \\\"{x:1330,y:792,t:1527020076173};\\\", \\\"{x:1328,y:795,t:1527020076189};\\\", \\\"{x:1323,y:798,t:1527020076206};\\\", \\\"{x:1317,y:805,t:1527020076223};\\\", \\\"{x:1310,y:811,t:1527020076240};\\\", \\\"{x:1300,y:823,t:1527020076256};\\\", \\\"{x:1283,y:834,t:1527020076274};\\\", \\\"{x:1251,y:858,t:1527020076290};\\\", \\\"{x:1235,y:867,t:1527020076306};\\\", \\\"{x:1225,y:875,t:1527020076323};\\\", \\\"{x:1219,y:876,t:1527020076340};\\\", \\\"{x:1218,y:878,t:1527020076356};\\\", \\\"{x:1217,y:878,t:1527020077259};\\\", \\\"{x:1216,y:878,t:1527020077339};\\\", \\\"{x:1214,y:879,t:1527020077387};\\\", \\\"{x:1211,y:880,t:1527020077747};\\\", \\\"{x:1210,y:881,t:1527020077758};\\\", \\\"{x:1206,y:882,t:1527020077775};\\\", \\\"{x:1197,y:886,t:1527020077792};\\\", \\\"{x:1193,y:888,t:1527020077808};\\\", \\\"{x:1185,y:889,t:1527020077825};\\\", \\\"{x:1182,y:891,t:1527020077841};\\\", \\\"{x:1181,y:891,t:1527020077859};\\\", \\\"{x:1180,y:891,t:1527020077931};\\\", \\\"{x:1176,y:891,t:1527020077946};\\\", \\\"{x:1175,y:891,t:1527020077994};\\\", \\\"{x:1175,y:892,t:1527020078008};\\\", \\\"{x:1173,y:893,t:1527020078025};\\\", \\\"{x:1172,y:893,t:1527020078040};\\\", \\\"{x:1171,y:893,t:1527020078057};\\\", \\\"{x:1170,y:893,t:1527020078075};\\\", \\\"{x:1169,y:893,t:1527020078091};\\\", \\\"{x:1168,y:894,t:1527020078108};\\\", \\\"{x:1167,y:894,t:1527020078125};\\\", \\\"{x:1165,y:894,t:1527020078142};\\\", \\\"{x:1162,y:894,t:1527020078162};\\\", \\\"{x:1161,y:894,t:1527020078186};\\\", \\\"{x:1160,y:894,t:1527020078203};\\\", \\\"{x:1159,y:894,t:1527020078211};\\\", \\\"{x:1158,y:894,t:1527020078226};\\\", \\\"{x:1153,y:895,t:1527020078243};\\\", \\\"{x:1150,y:897,t:1527020078259};\\\", \\\"{x:1146,y:897,t:1527020078275};\\\", \\\"{x:1144,y:897,t:1527020078293};\\\", \\\"{x:1141,y:898,t:1527020078307};\\\", \\\"{x:1140,y:898,t:1527020078325};\\\", \\\"{x:1138,y:898,t:1527020078342};\\\", \\\"{x:1135,y:899,t:1527020078358};\\\", \\\"{x:1132,y:899,t:1527020078375};\\\", \\\"{x:1130,y:899,t:1527020078391};\\\", \\\"{x:1128,y:900,t:1527020078407};\\\", \\\"{x:1125,y:900,t:1527020078425};\\\", \\\"{x:1124,y:900,t:1527020078442};\\\", \\\"{x:1122,y:900,t:1527020078459};\\\", \\\"{x:1121,y:900,t:1527020078490};\\\", \\\"{x:1120,y:901,t:1527020078498};\\\", \\\"{x:1119,y:901,t:1527020078578};\\\", \\\"{x:1118,y:901,t:1527020078642};\\\", \\\"{x:1117,y:901,t:1527020078771};\\\", \\\"{x:1116,y:901,t:1527020078795};\\\", \\\"{x:1114,y:901,t:1527020078850};\\\", \\\"{x:1111,y:901,t:1527020078859};\\\", \\\"{x:1108,y:899,t:1527020078876};\\\", \\\"{x:1101,y:895,t:1527020078892};\\\", \\\"{x:1085,y:886,t:1527020078909};\\\", \\\"{x:1066,y:875,t:1527020078926};\\\", \\\"{x:1032,y:859,t:1527020078943};\\\", \\\"{x:1011,y:838,t:1527020078959};\\\", \\\"{x:982,y:816,t:1527020078976};\\\", \\\"{x:934,y:792,t:1527020078993};\\\", \\\"{x:894,y:767,t:1527020079009};\\\", \\\"{x:834,y:740,t:1527020079026};\\\", \\\"{x:804,y:723,t:1527020079042};\\\", \\\"{x:783,y:714,t:1527020079059};\\\", \\\"{x:769,y:708,t:1527020079076};\\\", \\\"{x:752,y:706,t:1527020079092};\\\", \\\"{x:733,y:705,t:1527020079109};\\\", \\\"{x:704,y:705,t:1527020079126};\\\", \\\"{x:672,y:705,t:1527020079142};\\\", \\\"{x:623,y:704,t:1527020079159};\\\", \\\"{x:562,y:697,t:1527020079177};\\\", \\\"{x:506,y:681,t:1527020079193};\\\", \\\"{x:458,y:664,t:1527020079211};\\\", \\\"{x:420,y:649,t:1527020079226};\\\", \\\"{x:405,y:643,t:1527020079243};\\\", \\\"{x:400,y:639,t:1527020079254};\\\", \\\"{x:396,y:637,t:1527020079270};\\\", \\\"{x:394,y:636,t:1527020079288};\\\", \\\"{x:393,y:635,t:1527020079313};\\\", \\\"{x:392,y:634,t:1527020079353};\\\", \\\"{x:387,y:631,t:1527020079386};\\\", \\\"{x:370,y:620,t:1527020079406};\\\", \\\"{x:337,y:610,t:1527020079422};\\\", \\\"{x:318,y:599,t:1527020079440};\\\", \\\"{x:308,y:592,t:1527020079457};\\\", \\\"{x:304,y:591,t:1527020079473};\\\", \\\"{x:303,y:590,t:1527020079531};\\\", \\\"{x:301,y:588,t:1527020079539};\\\", \\\"{x:291,y:583,t:1527020079556};\\\", \\\"{x:285,y:582,t:1527020079573};\\\", \\\"{x:283,y:580,t:1527020079589};\\\", \\\"{x:281,y:579,t:1527020079610};\\\", \\\"{x:278,y:577,t:1527020079622};\\\", \\\"{x:273,y:574,t:1527020079640};\\\", \\\"{x:264,y:570,t:1527020079657};\\\", \\\"{x:262,y:568,t:1527020079673};\\\", \\\"{x:260,y:568,t:1527020079689};\\\", \\\"{x:259,y:568,t:1527020079705};\\\", \\\"{x:255,y:567,t:1527020079723};\\\", \\\"{x:249,y:566,t:1527020079738};\\\", \\\"{x:243,y:563,t:1527020079756};\\\", \\\"{x:241,y:561,t:1527020079774};\\\", \\\"{x:239,y:561,t:1527020079789};\\\", \\\"{x:234,y:560,t:1527020079806};\\\", \\\"{x:226,y:560,t:1527020079823};\\\", \\\"{x:219,y:559,t:1527020079840};\\\", \\\"{x:215,y:559,t:1527020079856};\\\", \\\"{x:212,y:559,t:1527020079873};\\\", \\\"{x:203,y:561,t:1527020079889};\\\", \\\"{x:195,y:562,t:1527020079905};\\\", \\\"{x:190,y:562,t:1527020079922};\\\", \\\"{x:189,y:561,t:1527020079938};\\\", \\\"{x:187,y:559,t:1527020079961};\\\", \\\"{x:187,y:558,t:1527020079978};\\\", \\\"{x:185,y:557,t:1527020079990};\\\", \\\"{x:181,y:557,t:1527020080006};\\\", \\\"{x:176,y:554,t:1527020080024};\\\", \\\"{x:175,y:553,t:1527020080039};\\\", \\\"{x:172,y:551,t:1527020080056};\\\", \\\"{x:165,y:547,t:1527020080073};\\\", \\\"{x:157,y:542,t:1527020080089};\\\", \\\"{x:155,y:540,t:1527020080106};\\\", \\\"{x:153,y:540,t:1527020080123};\\\", \\\"{x:151,y:538,t:1527020080139};\\\", \\\"{x:151,y:537,t:1527020080162};\\\", \\\"{x:151,y:536,t:1527020080218};\\\", \\\"{x:155,y:533,t:1527020080356};\\\", \\\"{x:161,y:530,t:1527020080373};\\\", \\\"{x:167,y:527,t:1527020080390};\\\", \\\"{x:172,y:525,t:1527020080406};\\\", \\\"{x:174,y:524,t:1527020080423};\\\", \\\"{x:176,y:523,t:1527020080440};\\\", \\\"{x:184,y:519,t:1527020080456};\\\", \\\"{x:194,y:515,t:1527020080474};\\\", \\\"{x:207,y:508,t:1527020080489};\\\", \\\"{x:211,y:508,t:1527020080506};\\\", \\\"{x:218,y:507,t:1527020080523};\\\", \\\"{x:219,y:507,t:1527020080540};\\\", \\\"{x:220,y:507,t:1527020080556};\\\", \\\"{x:222,y:507,t:1527020080651};\\\", \\\"{x:225,y:510,t:1527020080658};\\\", \\\"{x:227,y:515,t:1527020080673};\\\", \\\"{x:240,y:530,t:1527020080692};\\\", \\\"{x:263,y:547,t:1527020080707};\\\", \\\"{x:280,y:562,t:1527020080724};\\\", \\\"{x:290,y:575,t:1527020080740};\\\", \\\"{x:302,y:585,t:1527020080757};\\\", \\\"{x:308,y:593,t:1527020080773};\\\", \\\"{x:321,y:600,t:1527020080791};\\\", \\\"{x:336,y:613,t:1527020080807};\\\", \\\"{x:351,y:624,t:1527020080824};\\\", \\\"{x:361,y:632,t:1527020080841};\\\", \\\"{x:370,y:640,t:1527020080857};\\\", \\\"{x:378,y:650,t:1527020080873};\\\", \\\"{x:400,y:660,t:1527020080890};\\\", \\\"{x:420,y:671,t:1527020080907};\\\", \\\"{x:435,y:682,t:1527020080924};\\\", \\\"{x:453,y:694,t:1527020080940};\\\", \\\"{x:459,y:698,t:1527020080957};\\\", \\\"{x:468,y:706,t:1527020080974};\\\", \\\"{x:477,y:716,t:1527020080991};\\\", \\\"{x:482,y:724,t:1527020081007};\\\", \\\"{x:487,y:729,t:1527020081023};\\\", \\\"{x:488,y:729,t:1527020081074};\\\", \\\"{x:489,y:732,t:1527020081098};\\\", \\\"{x:494,y:736,t:1527020081108};\\\", \\\"{x:496,y:740,t:1527020081125};\\\", \\\"{x:498,y:740,t:1527020081170};\\\", \\\"{x:498,y:741,t:1527020081190};\\\", \\\"{x:500,y:742,t:1527020081206};\\\", \\\"{x:500,y:742,t:1527020081259};\\\", \\\"{x:502,y:742,t:1527020081274};\\\", \\\"{x:503,y:741,t:1527020081297};\\\", \\\"{x:503,y:740,t:1527020081322};\\\", \\\"{x:504,y:739,t:1527020081426};\\\", \\\"{x:508,y:738,t:1527020081441};\\\", \\\"{x:510,y:736,t:1527020081457};\\\", \\\"{x:514,y:732,t:1527020081474};\\\", \\\"{x:525,y:726,t:1527020081491};\\\", \\\"{x:531,y:721,t:1527020081507};\\\", \\\"{x:544,y:721,t:1527020081524};\\\", \\\"{x:565,y:721,t:1527020081541};\\\", \\\"{x:597,y:721,t:1527020081557};\\\", \\\"{x:632,y:722,t:1527020081574};\\\", \\\"{x:669,y:733,t:1527020081591};\\\", \\\"{x:748,y:754,t:1527020081608};\\\", \\\"{x:803,y:779,t:1527020081624};\\\", \\\"{x:904,y:837,t:1527020081641};\\\", \\\"{x:1032,y:903,t:1527020081657};\\\", \\\"{x:1081,y:933,t:1527020081674};\\\", \\\"{x:1101,y:948,t:1527020081692};\\\", \\\"{x:1116,y:955,t:1527020081707};\\\", \\\"{x:1128,y:959,t:1527020081724};\\\", \\\"{x:1130,y:960,t:1527020081741};\\\", \\\"{x:1130,y:963,t:1527020081794};\\\", \\\"{x:1130,y:964,t:1527020081808};\\\", \\\"{x:1129,y:968,t:1527020081824};\\\", \\\"{x:1127,y:972,t:1527020081841};\\\", \\\"{x:1123,y:979,t:1527020081858};\\\", \\\"{x:1121,y:983,t:1527020081874};\\\", \\\"{x:1120,y:984,t:1527020081891};\\\", \\\"{x:1120,y:985,t:1527020081908};\\\", \\\"{x:1118,y:986,t:1527020082035};\\\", \\\"{x:1118,y:987,t:1527020082041};\\\", \\\"{x:1115,y:987,t:1527020082058};\\\", \\\"{x:1114,y:987,t:1527020082075};\\\", \\\"{x:1113,y:988,t:1527020082091};\\\", \\\"{x:1112,y:988,t:1527020082108};\\\", \\\"{x:1109,y:989,t:1527020082271};\\\", \\\"{x:1101,y:992,t:1527020082275};\\\", \\\"{x:1093,y:993,t:1527020082292};\\\", \\\"{x:1092,y:994,t:1527020082308};\\\" ] }, { \\\"rt\\\": 55052, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 761919, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-02 PM-X -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1085,y:980,t:1527020085258};\\\", \\\"{x:1069,y:930,t:1527020085266};\\\", \\\"{x:1057,y:875,t:1527020085277};\\\", \\\"{x:1017,y:809,t:1527020085294};\\\", \\\"{x:985,y:766,t:1527020085310};\\\", \\\"{x:963,y:739,t:1527020085328};\\\", \\\"{x:943,y:718,t:1527020085344};\\\", \\\"{x:934,y:698,t:1527020085360};\\\", \\\"{x:921,y:679,t:1527020085378};\\\", \\\"{x:901,y:652,t:1527020085394};\\\", \\\"{x:877,y:633,t:1527020085412};\\\", \\\"{x:847,y:609,t:1527020085428};\\\", \\\"{x:822,y:581,t:1527020085445};\\\", \\\"{x:793,y:553,t:1527020085461};\\\", \\\"{x:756,y:529,t:1527020085478};\\\", \\\"{x:705,y:502,t:1527020085495};\\\", \\\"{x:667,y:484,t:1527020085511};\\\", \\\"{x:636,y:468,t:1527020085527};\\\", \\\"{x:620,y:459,t:1527020085543};\\\", \\\"{x:605,y:448,t:1527020085561};\\\", \\\"{x:597,y:442,t:1527020085576};\\\", \\\"{x:588,y:438,t:1527020085593};\\\", \\\"{x:574,y:438,t:1527020085611};\\\", \\\"{x:558,y:442,t:1527020085627};\\\", \\\"{x:547,y:446,t:1527020085644};\\\", \\\"{x:543,y:448,t:1527020085661};\\\", \\\"{x:541,y:450,t:1527020085677};\\\", \\\"{x:540,y:451,t:1527020085694};\\\", \\\"{x:539,y:451,t:1527020085711};\\\", \\\"{x:540,y:451,t:1527020087539};\\\", \\\"{x:542,y:451,t:1527020087546};\\\", \\\"{x:544,y:451,t:1527020087562};\\\", \\\"{x:551,y:450,t:1527020087579};\\\", \\\"{x:554,y:450,t:1527020087595};\\\", \\\"{x:567,y:450,t:1527020087612};\\\", \\\"{x:586,y:458,t:1527020087628};\\\", \\\"{x:600,y:466,t:1527020087645};\\\", \\\"{x:624,y:469,t:1527020087662};\\\", \\\"{x:643,y:474,t:1527020087678};\\\", \\\"{x:651,y:474,t:1527020087695};\\\", \\\"{x:653,y:476,t:1527020087712};\\\", \\\"{x:654,y:476,t:1527020092786};\\\", \\\"{x:666,y:481,t:1527020092798};\\\", \\\"{x:688,y:493,t:1527020092815};\\\", \\\"{x:733,y:507,t:1527020092832};\\\", \\\"{x:775,y:520,t:1527020092847};\\\", \\\"{x:872,y:546,t:1527020092864};\\\", \\\"{x:1109,y:605,t:1527020092884};\\\", \\\"{x:1312,y:654,t:1527020092901};\\\", \\\"{x:1559,y:694,t:1527020092916};\\\", \\\"{x:1775,y:740,t:1527020092933};\\\", \\\"{x:1919,y:782,t:1527020092950};\\\", \\\"{x:1919,y:809,t:1527020092966};\\\", \\\"{x:1919,y:830,t:1527020092983};\\\", \\\"{x:1919,y:842,t:1527020093000};\\\", \\\"{x:1919,y:849,t:1527020093017};\\\", \\\"{x:1919,y:851,t:1527020093033};\\\", \\\"{x:1918,y:852,t:1527020093130};\\\", \\\"{x:1909,y:858,t:1527020093137};\\\", \\\"{x:1897,y:864,t:1527020093151};\\\", \\\"{x:1869,y:871,t:1527020093167};\\\", \\\"{x:1850,y:876,t:1527020093184};\\\", \\\"{x:1818,y:881,t:1527020093201};\\\", \\\"{x:1760,y:892,t:1527020093218};\\\", \\\"{x:1703,y:904,t:1527020093234};\\\", \\\"{x:1660,y:911,t:1527020093250};\\\", \\\"{x:1629,y:911,t:1527020093268};\\\", \\\"{x:1596,y:911,t:1527020093284};\\\", \\\"{x:1581,y:911,t:1527020093301};\\\", \\\"{x:1573,y:911,t:1527020093318};\\\", \\\"{x:1564,y:911,t:1527020093334};\\\", \\\"{x:1561,y:912,t:1527020093351};\\\", \\\"{x:1559,y:914,t:1527020093368};\\\", \\\"{x:1557,y:916,t:1527020093384};\\\", \\\"{x:1553,y:920,t:1527020093401};\\\", \\\"{x:1541,y:930,t:1527020093418};\\\", \\\"{x:1534,y:934,t:1527020093434};\\\", \\\"{x:1532,y:935,t:1527020093451};\\\", \\\"{x:1529,y:938,t:1527020093468};\\\", \\\"{x:1528,y:939,t:1527020093484};\\\", \\\"{x:1527,y:941,t:1527020093501};\\\", \\\"{x:1525,y:943,t:1527020093518};\\\", \\\"{x:1519,y:949,t:1527020093534};\\\", \\\"{x:1514,y:953,t:1527020093551};\\\", \\\"{x:1508,y:959,t:1527020093568};\\\", \\\"{x:1505,y:961,t:1527020093584};\\\", \\\"{x:1502,y:963,t:1527020093602};\\\", \\\"{x:1497,y:967,t:1527020093618};\\\", \\\"{x:1495,y:968,t:1527020093634};\\\", \\\"{x:1493,y:969,t:1527020093651};\\\", \\\"{x:1492,y:969,t:1527020093668};\\\", \\\"{x:1491,y:969,t:1527020093754};\\\", \\\"{x:1490,y:969,t:1527020093987};\\\", \\\"{x:1490,y:968,t:1527020094003};\\\", \\\"{x:1490,y:967,t:1527020094034};\\\", \\\"{x:1490,y:966,t:1527020094051};\\\", \\\"{x:1490,y:965,t:1527020094068};\\\", \\\"{x:1488,y:962,t:1527020094090};\\\", \\\"{x:1487,y:961,t:1527020094163};\\\", \\\"{x:1486,y:960,t:1527020094178};\\\", \\\"{x:1485,y:958,t:1527020094186};\\\", \\\"{x:1484,y:957,t:1527020094219};\\\", \\\"{x:1484,y:956,t:1527020094250};\\\", \\\"{x:1484,y:955,t:1527020094459};\\\", \\\"{x:1484,y:953,t:1527020094514};\\\", \\\"{x:1483,y:952,t:1527020094546};\\\", \\\"{x:1483,y:951,t:1527020094683};\\\", \\\"{x:1483,y:950,t:1527020094707};\\\", \\\"{x:1482,y:946,t:1527020097302};\\\", \\\"{x:1481,y:940,t:1527020097310};\\\", \\\"{x:1481,y:936,t:1527020097324};\\\", \\\"{x:1480,y:930,t:1527020097341};\\\", \\\"{x:1478,y:920,t:1527020097357};\\\", \\\"{x:1478,y:918,t:1527020097374};\\\", \\\"{x:1478,y:917,t:1527020097391};\\\", \\\"{x:1477,y:915,t:1527020097407};\\\", \\\"{x:1477,y:914,t:1527020097429};\\\", \\\"{x:1477,y:912,t:1527020097441};\\\", \\\"{x:1477,y:911,t:1527020097457};\\\", \\\"{x:1477,y:909,t:1527020097476};\\\", \\\"{x:1477,y:908,t:1527020097491};\\\", \\\"{x:1477,y:906,t:1527020097510};\\\", \\\"{x:1477,y:904,t:1527020097534};\\\", \\\"{x:1477,y:903,t:1527020097550};\\\", \\\"{x:1477,y:902,t:1527020097558};\\\", \\\"{x:1477,y:899,t:1527020097574};\\\", \\\"{x:1477,y:895,t:1527020097591};\\\", \\\"{x:1478,y:891,t:1527020097608};\\\", \\\"{x:1479,y:887,t:1527020097625};\\\", \\\"{x:1480,y:883,t:1527020097642};\\\", \\\"{x:1480,y:880,t:1527020097658};\\\", \\\"{x:1481,y:877,t:1527020097676};\\\", \\\"{x:1481,y:876,t:1527020097692};\\\", \\\"{x:1481,y:874,t:1527020097707};\\\", \\\"{x:1482,y:871,t:1527020097725};\\\", \\\"{x:1482,y:870,t:1527020097781};\\\", \\\"{x:1482,y:869,t:1527020097814};\\\", \\\"{x:1482,y:867,t:1527020097830};\\\", \\\"{x:1482,y:865,t:1527020097845};\\\", \\\"{x:1482,y:864,t:1527020097858};\\\", \\\"{x:1482,y:860,t:1527020097876};\\\", \\\"{x:1484,y:857,t:1527020097892};\\\", \\\"{x:1484,y:852,t:1527020097907};\\\", \\\"{x:1485,y:850,t:1527020097925};\\\", \\\"{x:1485,y:846,t:1527020097941};\\\", \\\"{x:1485,y:844,t:1527020097958};\\\", \\\"{x:1486,y:843,t:1527020097975};\\\", \\\"{x:1486,y:842,t:1527020097991};\\\", \\\"{x:1487,y:841,t:1527020098008};\\\", \\\"{x:1487,y:840,t:1527020098046};\\\", \\\"{x:1488,y:839,t:1527020098118};\\\", \\\"{x:1488,y:837,t:1527020098974};\\\", \\\"{x:1487,y:836,t:1527020098981};\\\", \\\"{x:1485,y:834,t:1527020098995};\\\", \\\"{x:1484,y:833,t:1527020099008};\\\", \\\"{x:1483,y:833,t:1527020099093};\\\", \\\"{x:1481,y:832,t:1527020099148};\\\", \\\"{x:1480,y:831,t:1527020099165};\\\", \\\"{x:1479,y:830,t:1527020099181};\\\", \\\"{x:1478,y:830,t:1527020099205};\\\", \\\"{x:1477,y:830,t:1527020100341};\\\", \\\"{x:1476,y:830,t:1527020100430};\\\", \\\"{x:1473,y:830,t:1527020105479};\\\", \\\"{x:1470,y:834,t:1527020105496};\\\", \\\"{x:1468,y:839,t:1527020105513};\\\", \\\"{x:1467,y:842,t:1527020105530};\\\", \\\"{x:1467,y:845,t:1527020105547};\\\", \\\"{x:1467,y:849,t:1527020105563};\\\", \\\"{x:1467,y:856,t:1527020105581};\\\", \\\"{x:1467,y:865,t:1527020105597};\\\", \\\"{x:1467,y:875,t:1527020105613};\\\", \\\"{x:1467,y:882,t:1527020105631};\\\", \\\"{x:1467,y:885,t:1527020105647};\\\", \\\"{x:1467,y:889,t:1527020105664};\\\", \\\"{x:1467,y:894,t:1527020105680};\\\", \\\"{x:1467,y:900,t:1527020105697};\\\", \\\"{x:1467,y:909,t:1527020105714};\\\", \\\"{x:1470,y:915,t:1527020105730};\\\", \\\"{x:1473,y:922,t:1527020105747};\\\", \\\"{x:1478,y:931,t:1527020105764};\\\", \\\"{x:1483,y:939,t:1527020105781};\\\", \\\"{x:1488,y:949,t:1527020105798};\\\", \\\"{x:1489,y:951,t:1527020105814};\\\", \\\"{x:1490,y:952,t:1527020105831};\\\", \\\"{x:1490,y:954,t:1527020105848};\\\", \\\"{x:1492,y:956,t:1527020105864};\\\", \\\"{x:1494,y:959,t:1527020105881};\\\", \\\"{x:1496,y:961,t:1527020105898};\\\", \\\"{x:1496,y:962,t:1527020105913};\\\", \\\"{x:1496,y:964,t:1527020106062};\\\", \\\"{x:1496,y:962,t:1527020106558};\\\", \\\"{x:1496,y:961,t:1527020106733};\\\", \\\"{x:1496,y:959,t:1527020106806};\\\", \\\"{x:1496,y:958,t:1527020106966};\\\", \\\"{x:1496,y:956,t:1527020107094};\\\", \\\"{x:1496,y:955,t:1527020107198};\\\", \\\"{x:1496,y:953,t:1527020107380};\\\", \\\"{x:1496,y:952,t:1527020107421};\\\", \\\"{x:1496,y:950,t:1527020107542};\\\", \\\"{x:1496,y:949,t:1527020107574};\\\", \\\"{x:1496,y:947,t:1527020113366};\\\", \\\"{x:1495,y:947,t:1527020116981};\\\", \\\"{x:1493,y:947,t:1527020119621};\\\", \\\"{x:1492,y:947,t:1527020119686};\\\", \\\"{x:1490,y:947,t:1527020119709};\\\", \\\"{x:1488,y:947,t:1527020119726};\\\", \\\"{x:1487,y:947,t:1527020119743};\\\", \\\"{x:1486,y:947,t:1527020119758};\\\", \\\"{x:1485,y:947,t:1527020119776};\\\", \\\"{x:1484,y:947,t:1527020119830};\\\", \\\"{x:1483,y:947,t:1527020119862};\\\", \\\"{x:1481,y:947,t:1527020119925};\\\", \\\"{x:1480,y:946,t:1527020119942};\\\", \\\"{x:1479,y:946,t:1527020119973};\\\", \\\"{x:1478,y:946,t:1527020120054};\\\", \\\"{x:1477,y:946,t:1527020120142};\\\", \\\"{x:1476,y:945,t:1527020120160};\\\", \\\"{x:1475,y:945,t:1527020121077};\\\", \\\"{x:1473,y:945,t:1527020121093};\\\", \\\"{x:1471,y:945,t:1527020121110};\\\", \\\"{x:1470,y:945,t:1527020121127};\\\", \\\"{x:1468,y:945,t:1527020121144};\\\", \\\"{x:1467,y:945,t:1527020121160};\\\", \\\"{x:1466,y:945,t:1527020121176};\\\", \\\"{x:1465,y:945,t:1527020121246};\\\", \\\"{x:1464,y:945,t:1527020121277};\\\", \\\"{x:1463,y:944,t:1527020121293};\\\", \\\"{x:1462,y:944,t:1527020121317};\\\", \\\"{x:1461,y:944,t:1527020121389};\\\", \\\"{x:1459,y:944,t:1527020121453};\\\", \\\"{x:1458,y:944,t:1527020121485};\\\", \\\"{x:1457,y:943,t:1527020121493};\\\", \\\"{x:1455,y:943,t:1527020121525};\\\", \\\"{x:1454,y:942,t:1527020121549};\\\", \\\"{x:1453,y:942,t:1527020121581};\\\", \\\"{x:1452,y:942,t:1527020121614};\\\", \\\"{x:1451,y:942,t:1527020123060};\\\", \\\"{x:1450,y:942,t:1527020123109};\\\", \\\"{x:1449,y:942,t:1527020123116};\\\", \\\"{x:1447,y:941,t:1527020123132};\\\", \\\"{x:1442,y:936,t:1527020134838};\\\", \\\"{x:1368,y:888,t:1527020134854};\\\", \\\"{x:1315,y:853,t:1527020134872};\\\", \\\"{x:1245,y:816,t:1527020134887};\\\", \\\"{x:1181,y:786,t:1527020134904};\\\", \\\"{x:1139,y:774,t:1527020134921};\\\", \\\"{x:1102,y:762,t:1527020134936};\\\", \\\"{x:1094,y:758,t:1527020134953};\\\", \\\"{x:1073,y:758,t:1527020134971};\\\", \\\"{x:1057,y:758,t:1527020134987};\\\", \\\"{x:1031,y:758,t:1527020135004};\\\", \\\"{x:1002,y:753,t:1527020135020};\\\", \\\"{x:993,y:751,t:1527020135037};\\\", \\\"{x:977,y:747,t:1527020135054};\\\", \\\"{x:962,y:743,t:1527020135070};\\\", \\\"{x:939,y:737,t:1527020135087};\\\", \\\"{x:916,y:731,t:1527020135103};\\\", \\\"{x:895,y:723,t:1527020135120};\\\", \\\"{x:868,y:709,t:1527020135138};\\\", \\\"{x:852,y:694,t:1527020135154};\\\", \\\"{x:805,y:660,t:1527020135170};\\\", \\\"{x:746,y:615,t:1527020135188};\\\", \\\"{x:687,y:579,t:1527020135204};\\\", \\\"{x:656,y:546,t:1527020135221};\\\", \\\"{x:648,y:531,t:1527020135238};\\\", \\\"{x:644,y:518,t:1527020135256};\\\", \\\"{x:643,y:513,t:1527020135271};\\\", \\\"{x:643,y:512,t:1527020135372};\\\", \\\"{x:642,y:509,t:1527020135389};\\\", \\\"{x:636,y:506,t:1527020135405};\\\", \\\"{x:634,y:505,t:1527020135422};\\\", \\\"{x:633,y:505,t:1527020135444};\\\", \\\"{x:632,y:505,t:1527020135509};\\\", \\\"{x:630,y:505,t:1527020135525};\\\", \\\"{x:629,y:505,t:1527020135539};\\\", \\\"{x:627,y:505,t:1527020135556};\\\", \\\"{x:625,y:505,t:1527020135572};\\\", \\\"{x:624,y:505,t:1527020135605};\\\", \\\"{x:622,y:505,t:1527020135613};\\\", \\\"{x:620,y:505,t:1527020135622};\\\", \\\"{x:617,y:505,t:1527020135639};\\\", \\\"{x:613,y:506,t:1527020135655};\\\", \\\"{x:612,y:507,t:1527020135672};\\\", \\\"{x:611,y:507,t:1527020135884};\\\", \\\"{x:614,y:507,t:1527020135892};\\\", \\\"{x:621,y:507,t:1527020135905};\\\", \\\"{x:632,y:507,t:1527020135923};\\\", \\\"{x:637,y:507,t:1527020135939};\\\", \\\"{x:643,y:507,t:1527020135956};\\\", \\\"{x:660,y:507,t:1527020135972};\\\", \\\"{x:685,y:507,t:1527020135988};\\\", \\\"{x:707,y:507,t:1527020136006};\\\", \\\"{x:726,y:507,t:1527020136024};\\\", \\\"{x:747,y:511,t:1527020136038};\\\", \\\"{x:766,y:512,t:1527020136055};\\\", \\\"{x:795,y:514,t:1527020136072};\\\", \\\"{x:821,y:518,t:1527020136088};\\\", \\\"{x:839,y:520,t:1527020136106};\\\", \\\"{x:845,y:522,t:1527020136122};\\\", \\\"{x:846,y:523,t:1527020136138};\\\", \\\"{x:844,y:523,t:1527020136333};\\\", \\\"{x:843,y:523,t:1527020136340};\\\", \\\"{x:842,y:523,t:1527020136356};\\\", \\\"{x:838,y:523,t:1527020136580};\\\", \\\"{x:835,y:525,t:1527020136589};\\\", \\\"{x:830,y:533,t:1527020136606};\\\", \\\"{x:822,y:541,t:1527020136623};\\\", \\\"{x:811,y:550,t:1527020136639};\\\", \\\"{x:806,y:554,t:1527020136657};\\\", \\\"{x:796,y:563,t:1527020136673};\\\", \\\"{x:789,y:570,t:1527020136690};\\\", \\\"{x:780,y:580,t:1527020136707};\\\", \\\"{x:773,y:589,t:1527020136723};\\\", \\\"{x:765,y:601,t:1527020136739};\\\", \\\"{x:752,y:616,t:1527020136757};\\\", \\\"{x:742,y:626,t:1527020136773};\\\", \\\"{x:736,y:632,t:1527020136789};\\\", \\\"{x:729,y:637,t:1527020136807};\\\", \\\"{x:722,y:641,t:1527020136824};\\\", \\\"{x:712,y:646,t:1527020136840};\\\", \\\"{x:701,y:648,t:1527020136857};\\\", \\\"{x:687,y:655,t:1527020136872};\\\", \\\"{x:670,y:663,t:1527020136889};\\\", \\\"{x:654,y:673,t:1527020136907};\\\", \\\"{x:637,y:679,t:1527020136924};\\\", \\\"{x:613,y:689,t:1527020136940};\\\", \\\"{x:587,y:702,t:1527020136956};\\\", \\\"{x:574,y:707,t:1527020136973};\\\", \\\"{x:562,y:711,t:1527020136990};\\\", \\\"{x:557,y:712,t:1527020137007};\\\", \\\"{x:551,y:714,t:1527020137023};\\\", \\\"{x:548,y:716,t:1527020137039};\\\", \\\"{x:544,y:718,t:1527020137057};\\\", \\\"{x:540,y:719,t:1527020137075};\\\", \\\"{x:535,y:721,t:1527020137090};\\\", \\\"{x:532,y:723,t:1527020137107};\\\", \\\"{x:531,y:724,t:1527020137124};\\\", \\\"{x:530,y:725,t:1527020137212};\\\", \\\"{x:529,y:726,t:1527020137224};\\\", \\\"{x:524,y:729,t:1527020137241};\\\", \\\"{x:518,y:733,t:1527020137257};\\\", \\\"{x:516,y:734,t:1527020137268};\\\", \\\"{x:516,y:734,t:1527020137274};\\\", \\\"{x:516,y:736,t:1527020137290};\\\", \\\"{x:516,y:737,t:1527020137349};\\\", \\\"{x:516,y:739,t:1527020137356};\\\", \\\"{x:515,y:742,t:1527020137374};\\\", \\\"{x:515,y:747,t:1527020137389};\\\", \\\"{x:516,y:747,t:1527020137901};\\\", \\\"{x:519,y:747,t:1527020137909};\\\", \\\"{x:523,y:747,t:1527020137924};\\\", \\\"{x:531,y:742,t:1527020137940};\\\", \\\"{x:535,y:740,t:1527020137958};\\\", \\\"{x:540,y:737,t:1527020137973};\\\", \\\"{x:544,y:735,t:1527020137991};\\\", \\\"{x:548,y:731,t:1527020138008};\\\", \\\"{x:554,y:731,t:1527020138023};\\\", \\\"{x:560,y:726,t:1527020138040};\\\", \\\"{x:566,y:723,t:1527020138058};\\\", \\\"{x:573,y:720,t:1527020138074};\\\", \\\"{x:578,y:718,t:1527020138091};\\\", \\\"{x:586,y:715,t:1527020138108};\\\", \\\"{x:595,y:714,t:1527020138124};\\\", \\\"{x:603,y:709,t:1527020138140};\\\", \\\"{x:608,y:709,t:1527020138157};\\\", \\\"{x:613,y:709,t:1527020138173};\\\", \\\"{x:616,y:707,t:1527020138191};\\\", \\\"{x:618,y:706,t:1527020138207};\\\", \\\"{x:619,y:706,t:1527020138269};\\\", \\\"{x:621,y:706,t:1527020138445};\\\", \\\"{x:622,y:706,t:1527020138458};\\\", \\\"{x:625,y:706,t:1527020138474};\\\", \\\"{x:627,y:706,t:1527020138491};\\\", \\\"{x:628,y:706,t:1527020138508};\\\" ] }, { \\\"rt\\\": 139339, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 902533, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You find 12pm on the x-axis and then you see if there are any points that are directly above the 12pm increment to see if any shifts start then. To find out when a break is taking place at 12pm you test one's shift by dividing their duration by 2 and adding that to when they started their shift. If the answer is 12 pm then thats when their break is.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8480, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 912019, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7749, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 920788, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 2291, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 924451, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ZKB08\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"ZKB08\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 277, dom: 1215, initialDom: 1392",
  "javascriptErrors": []
}