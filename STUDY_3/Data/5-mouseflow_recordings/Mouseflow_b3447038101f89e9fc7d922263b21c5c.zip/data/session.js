var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b3447038101f89e9fc7d922263b21c5c",
  "created": "2018-06-04T13:19:55.6953858-07:00",
  "lastActivity": "2018-06-04T13:20:37.2433858-07:00",
  "pageViews": [
    {
      "id": "06045554958a5568097b0516181950642b8c7ef0",
      "startTime": "2018-06-04T13:19:55.6953858-07:00",
      "endTime": "2018-06-04T13:20:37.2433858-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 41548,
      "engagementTime": 41497,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 41548,
  "engagementTime": 41497,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=K0CNH",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "91bc802b547a94d6f35d9a7690f62bd2",
  "gdpr": false
}