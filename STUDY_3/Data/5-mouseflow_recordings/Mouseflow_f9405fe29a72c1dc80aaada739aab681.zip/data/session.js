var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f9405fe29a72c1dc80aaada739aab681",
  "created": "2018-05-21T10:10:59.3081305-07:00",
  "lastActivity": "2018-05-21T10:11:53.7626446-07:00",
  "pageViews": [
    {
      "id": "05215951aed9fedfcc226fd86fd65660feb52c88",
      "startTime": "2018-05-21T10:10:59.6441063-07:00",
      "endTime": "2018-05-21T10:11:53.7626446-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 54197,
      "engagementTime": 28646,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 54197,
  "engagementTime": 28646,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YE3VQ",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c25c259f7f1dcb110e434619b251f252",
  "gdpr": false
}