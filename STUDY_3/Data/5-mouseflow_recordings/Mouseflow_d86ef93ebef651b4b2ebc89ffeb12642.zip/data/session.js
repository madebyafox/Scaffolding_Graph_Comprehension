var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d86ef93ebef651b4b2ebc89ffeb12642",
  "created": "2018-06-01T11:11:35.8590801-07:00",
  "lastActivity": "2018-06-01T11:12:05.5773262-07:00",
  "pageViews": [
    {
      "id": "0601362034336adcebd98e8b5c322ddcb7adcfba",
      "startTime": "2018-06-01T11:11:35.9133262-07:00",
      "endTime": "2018-06-01T11:12:05.5773262-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 29664,
      "engagementTime": 29664,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29664,
  "engagementTime": 29664,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=AG2V3",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d8c98bf01c14d6c53d58d4b47564c2da",
  "gdpr": false
}