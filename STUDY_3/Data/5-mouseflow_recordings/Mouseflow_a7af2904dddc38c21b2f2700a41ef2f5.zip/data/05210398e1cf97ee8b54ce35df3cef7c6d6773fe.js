var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05210398e1cf97ee8b54ce35df3cef7c6d6773fe"] = {
  "startTime": "2018-05-21T17:18:03.6152361Z",
  "websitePageUrl": "/16",
  "visitTime": 127509,
  "engagementTime": 126126,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a7af2904dddc38c21b2f2700a41ef2f5",
    "created": "2018-05-21T17:18:03.6152361+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DOQRP",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bb26aacbc194f7fd1cd9fadd3e1bd457",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a7af2904dddc38c21b2f2700a41ef2f5/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 101,
      "e": 101,
      "ty": 2,
      "x": 522,
      "y": 760
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 522,
      "y": 761
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 17700,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 512,
      "e": 512,
      "ty": 2,
      "x": 520,
      "y": 762
    },
    {
      "t": 514,
      "e": 514,
      "ty": 41,
      "x": 47538,
      "y": 41769,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 668,
      "e": 668,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 672,
      "e": 672,
      "ty": 2,
      "x": 519,
      "y": 762
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 519,
      "y": 763
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 47426,
      "y": 41824,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 518,
      "y": 764
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 47314,
      "y": 41880,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 517,
      "y": 733
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 47651,
      "y": 38057,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 526,
      "y": 674
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 514,
      "y": 628
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 503,
      "y": 604
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 45627,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 6,
      "x": 502,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 490,
      "y": 586
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 484,
      "y": 576
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 43267,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 480,
      "y": 562
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 479,
      "y": 561
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 42930,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 3,
      "x": 479,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2392,
      "e": 2392,
      "ty": 4,
      "x": 42930,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2392,
      "e": 2392,
      "ty": 5,
      "x": 479,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8517,
      "e": 7392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9016,
      "e": 7891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9049,
      "e": 7924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9082,
      "e": 7957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9115,
      "e": 7990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9148,
      "e": 8023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9181,
      "e": 8056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9214,
      "e": 8089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9246,
      "e": 8121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9279,
      "e": 8154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9313,
      "e": 8188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9346,
      "e": 8221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9379,
      "e": 8254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9411,
      "e": 8286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9445,
      "e": 8320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9477,
      "e": 8352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9511,
      "e": 8386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9544,
      "e": 8419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9577,
      "e": 8452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9609,
      "e": 8484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9642,
      "e": 8517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9675,
      "e": 8550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9709,
      "e": 8584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9741,
      "e": 8616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9774,
      "e": 8649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9808,
      "e": 8683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9841,
      "e": 8716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9874,
      "e": 8749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9907,
      "e": 8782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9940,
      "e": 8815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 9973,
      "e": 8848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10001,
      "e": 8876,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10005,
      "e": 8880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10038,
      "e": 8913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10071,
      "e": 8946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10104,
      "e": 8979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10137,
      "e": 9012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10171,
      "e": 9046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10203,
      "e": 9078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10236,
      "e": 9111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10270,
      "e": 9145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10302,
      "e": 9177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10336,
      "e": 9211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10368,
      "e": 9243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10402,
      "e": 9277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10435,
      "e": 9310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10468,
      "e": 9343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10501,
      "e": 9376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10534,
      "e": 9409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10566,
      "e": 9441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10600,
      "e": 9475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10632,
      "e": 9507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10666,
      "e": 9541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10698,
      "e": 9573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10732,
      "e": 9607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10764,
      "e": 9639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10798,
      "e": 9673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10831,
      "e": 9706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10863,
      "e": 9738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10897,
      "e": 9772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10929,
      "e": 9804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10963,
      "e": 9838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 10996,
      "e": 9871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11029,
      "e": 9904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11062,
      "e": 9937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11095,
      "e": 9970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11128,
      "e": 10003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11161,
      "e": 10036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11194,
      "e": 10069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11227,
      "e": 10102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 11227,
      "e": 10102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11384,
      "e": 10259,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13128,
      "e": 12003,
      "ty": 3,
      "x": 479,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13128,
      "e": 12003,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13311,
      "e": 12186,
      "ty": 4,
      "x": 42930,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13312,
      "e": 12187,
      "ty": 5,
      "x": 479,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14092,
      "e": 12967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14308,
      "e": 13183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14308,
      "e": 13183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14380,
      "e": 13255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 14395,
      "e": 13270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 14563,
      "e": 13438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14563,
      "e": 13438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14652,
      "e": 13527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 14875,
      "e": 13750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14875,
      "e": 13750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14915,
      "e": 13790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 15572,
      "e": 14447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15700,
      "e": 14575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 15812,
      "e": 14687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15899,
      "e": 14774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16003,
      "e": 14878,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16675,
      "e": 15550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16675,
      "e": 15550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16788,
      "e": 15663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 16996,
      "e": 15871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 17124,
      "e": 15999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 17348,
      "e": 16223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17348,
      "e": 16223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17452,
      "e": 16327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F N"
    },
    {
      "t": 17580,
      "e": 16455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17580,
      "e": 16455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17660,
      "e": 16535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17660,
      "e": 16535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17715,
      "e": 16590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ND "
    },
    {
      "t": 17780,
      "e": 16655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17891,
      "e": 16766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17988,
      "e": 16863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 17988,
      "e": 16863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18083,
      "e": 16958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 18099,
      "e": 16974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18260,
      "e": 17135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18260,
      "e": 17135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18363,
      "e": 17238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18771,
      "e": 17646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18803,
      "e": 17678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ND b"
    },
    {
      "t": 18923,
      "e": 17798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18995,
      "e": 17870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ND "
    },
    {
      "t": 19100,
      "e": 17975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19187,
      "e": 18062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F ND"
    },
    {
      "t": 19300,
      "e": 18175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19371,
      "e": 18246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F N"
    },
    {
      "t": 19491,
      "e": 18366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19571,
      "e": 18446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 20000,
      "e": 18875,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20491,
      "e": 19366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20491,
      "e": 19366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20602,
      "e": 19477,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F A"
    },
    {
      "t": 20611,
      "e": 19486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F A"
    },
    {
      "t": 21084,
      "e": 19959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21203,
      "e": 20078,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 21212,
      "e": 20087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 21236,
      "e": 20111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 21355,
      "e": 20230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F "
    },
    {
      "t": 21427,
      "e": 20302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21427,
      "e": 20302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21555,
      "e": 20430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F a"
    },
    {
      "t": 21587,
      "e": 20462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21587,
      "e": 20462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21747,
      "e": 20622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F an"
    },
    {
      "t": 22259,
      "e": 21134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22259,
      "e": 21134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22371,
      "e": 21246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22372,
      "e": 21247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22395,
      "e": 21270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 22492,
      "e": 21367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22564,
      "e": 21439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 22684,
      "e": 21559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 22684,
      "e": 21559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22748,
      "e": 21623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 22764,
      "e": 21639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22907,
      "e": 21782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22907,
      "e": 21782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22988,
      "e": 21863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23228,
      "e": 22103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23228,
      "e": 22103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23373,
      "e": 22248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23787,
      "e": 22662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23788,
      "e": 22663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23876,
      "e": 22751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23980,
      "e": 22855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23981,
      "e": 22856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24075,
      "e": 22950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24484,
      "e": 23359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24587,
      "e": 23462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B at"
    },
    {
      "t": 24691,
      "e": 23566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24763,
      "e": 23638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B a"
    },
    {
      "t": 24875,
      "e": 23750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24939,
      "e": 23814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B "
    },
    {
      "t": 25315,
      "e": 24190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25315,
      "e": 24190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25427,
      "e": 24302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25507,
      "e": 24382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25507,
      "e": 24382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25595,
      "e": 24470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25683,
      "e": 24558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25683,
      "e": 24558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25764,
      "e": 24639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25764,
      "e": 24639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25812,
      "e": 24687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 25836,
      "e": 24711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25964,
      "e": 24839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25964,
      "e": 24839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26059,
      "e": 24934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26283,
      "e": 25158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26283,
      "e": 25158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26388,
      "e": 25263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26500,
      "e": 25375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26501,
      "e": 25376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26579,
      "e": 25454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26579,
      "e": 25454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26612,
      "e": 25487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rh"
    },
    {
      "t": 26667,
      "e": 25542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26884,
      "e": 25759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 26885,
      "e": 25760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26963,
      "e": 25838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 27467,
      "e": 26342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27555,
      "e": 26430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start rh"
    },
    {
      "t": 27731,
      "e": 26606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27835,
      "e": 26710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start r"
    },
    {
      "t": 28155,
      "e": 27030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28275,
      "e": 27150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start "
    },
    {
      "t": 28387,
      "e": 27262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28388,
      "e": 27263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28475,
      "e": 27350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28563,
      "e": 27438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28563,
      "e": 27438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28659,
      "e": 27534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28731,
      "e": 27606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28731,
      "e": 27606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28819,
      "e": 27694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28955,
      "e": 27830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28955,
      "e": 27830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29019,
      "e": 27894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29147,
      "e": 28022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29147,
      "e": 28022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29243,
      "e": 28118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30001,
      "e": 28876,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30044,
      "e": 28919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30203,
      "e": 29078,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B start ther"
    },
    {
      "t": 30543,
      "e": 29418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30576,
      "e": 29451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30609,
      "e": 29484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30642,
      "e": 29517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30675,
      "e": 29550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30708,
      "e": 29583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30741,
      "e": 29616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30774,
      "e": 29649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30807,
      "e": 29682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30827,
      "e": 29702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B s"
    },
    {
      "t": 31002,
      "e": 29877,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B s"
    },
    {
      "t": 31203,
      "e": 30078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31331,
      "e": 30206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B "
    },
    {
      "t": 31723,
      "e": 30598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 31723,
      "e": 30598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31819,
      "e": 30694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 31819,
      "e": 30694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31820,
      "e": 30695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31899,
      "e": 30774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32002,
      "e": 30877,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B be"
    },
    {
      "t": 32171,
      "e": 31046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32171,
      "e": 31046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32267,
      "e": 31142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 32660,
      "e": 31535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32661,
      "e": 31536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32763,
      "e": 31638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32835,
      "e": 31710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32836,
      "e": 31711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32980,
      "e": 31855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33124,
      "e": 31999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33125,
      "e": 32000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33187,
      "e": 32062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33188,
      "e": 32063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33211,
      "e": 32086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 33275,
      "e": 32150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33379,
      "e": 32254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33379,
      "e": 32254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33467,
      "e": 32342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33507,
      "e": 32382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33507,
      "e": 32382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33611,
      "e": 32486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33766,
      "e": 32641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33766,
      "e": 32641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33843,
      "e": 32718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 33979,
      "e": 32854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33980,
      "e": 32855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34051,
      "e": 32926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34051,
      "e": 32926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34075,
      "e": 32950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 34147,
      "e": 33022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34412,
      "e": 33287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34412,
      "e": 33287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34546,
      "e": 33421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34555,
      "e": 33430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34555,
      "e": 33430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34628,
      "e": 33503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34811,
      "e": 33686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34811,
      "e": 33686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34916,
      "e": 33791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34955,
      "e": 33830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34955,
      "e": 33830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35035,
      "e": 33910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 35147,
      "e": 34022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35147,
      "e": 34022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35251,
      "e": 34126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35963,
      "e": 34838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 35963,
      "e": 34838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36027,
      "e": 34902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 36864,
      "e": 35739,
      "ty": 7,
      "x": 455,
      "y": 634,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36897,
      "e": 35772,
      "ty": 6,
      "x": 448,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 36900,
      "e": 35775,
      "ty": 2,
      "x": 448,
      "y": 667
    },
    {
      "t": 36930,
      "e": 35805,
      "ty": 7,
      "x": 447,
      "y": 689,
      "ta": "#strategyButton"
    },
    {
      "t": 37000,
      "e": 35875,
      "ty": 2,
      "x": 444,
      "y": 702
    },
    {
      "t": 37001,
      "e": 35876,
      "ty": 41,
      "x": 58703,
      "y": 52602,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 37101,
      "e": 35976,
      "ty": 2,
      "x": 421,
      "y": 715
    },
    {
      "t": 37200,
      "e": 36075,
      "ty": 2,
      "x": 412,
      "y": 701
    },
    {
      "t": 37248,
      "e": 36123,
      "ty": 6,
      "x": 412,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 37251,
      "e": 36126,
      "ty": 41,
      "x": 40088,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 37301,
      "e": 36176,
      "ty": 2,
      "x": 417,
      "y": 668
    },
    {
      "t": 37401,
      "e": 36276,
      "ty": 2,
      "x": 419,
      "y": 665
    },
    {
      "t": 37433,
      "e": 36308,
      "ty": 3,
      "x": 419,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 37434,
      "e": 36309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F and B begin there shift."
    },
    {
      "t": 37434,
      "e": 36309,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37435,
      "e": 36310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 37501,
      "e": 36376,
      "ty": 2,
      "x": 420,
      "y": 663
    },
    {
      "t": 37501,
      "e": 36376,
      "ty": 41,
      "x": 44457,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 37567,
      "e": 36442,
      "ty": 4,
      "x": 44457,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 37581,
      "e": 36456,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 37582,
      "e": 36457,
      "ty": 5,
      "x": 420,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 37586,
      "e": 36461,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 38584,
      "e": 37459,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 38601,
      "e": 37476,
      "ty": 2,
      "x": 432,
      "y": 655
    },
    {
      "t": 38701,
      "e": 37576,
      "ty": 2,
      "x": 434,
      "y": 653
    },
    {
      "t": 38751,
      "e": 37626,
      "ty": 41,
      "x": 14567,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 38800,
      "e": 37675,
      "ty": 2,
      "x": 423,
      "y": 683
    },
    {
      "t": 39001,
      "e": 37876,
      "ty": 41,
      "x": 14291,
      "y": 37393,
      "ta": "html > body"
    },
    {
      "t": 39101,
      "e": 37976,
      "ty": 2,
      "x": 513,
      "y": 696
    },
    {
      "t": 39201,
      "e": 38076,
      "ty": 2,
      "x": 757,
      "y": 697
    },
    {
      "t": 39251,
      "e": 38126,
      "ty": 41,
      "x": 27653,
      "y": 37503,
      "ta": "html > body"
    },
    {
      "t": 39301,
      "e": 38176,
      "ty": 2,
      "x": 815,
      "y": 677
    },
    {
      "t": 39333,
      "e": 38208,
      "ty": 6,
      "x": 817,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39382,
      "e": 38257,
      "ty": 7,
      "x": 830,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39401,
      "e": 38276,
      "ty": 2,
      "x": 838,
      "y": 635
    },
    {
      "t": 39501,
      "e": 38376,
      "ty": 2,
      "x": 870,
      "y": 599
    },
    {
      "t": 39501,
      "e": 38376,
      "ty": 41,
      "x": 13409,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39600,
      "e": 38475,
      "ty": 2,
      "x": 878,
      "y": 585
    },
    {
      "t": 39700,
      "e": 38575,
      "ty": 2,
      "x": 883,
      "y": 575
    },
    {
      "t": 39716,
      "e": 38591,
      "ty": 6,
      "x": 884,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39751,
      "e": 38626,
      "ty": 41,
      "x": 16437,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39801,
      "e": 38627,
      "ty": 2,
      "x": 884,
      "y": 572
    },
    {
      "t": 39848,
      "e": 38674,
      "ty": 3,
      "x": 884,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39848,
      "e": 38674,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39901,
      "e": 38727,
      "ty": 2,
      "x": 884,
      "y": 571
    },
    {
      "t": 39990,
      "e": 38816,
      "ty": 4,
      "x": 16437,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39991,
      "e": 38817,
      "ty": 5,
      "x": 884,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40001,
      "e": 38827,
      "ty": 41,
      "x": 16437,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40252,
      "e": 39078,
      "ty": 41,
      "x": 16437,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40300,
      "e": 39126,
      "ty": 7,
      "x": 877,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40300,
      "e": 39126,
      "ty": 2,
      "x": 877,
      "y": 553
    },
    {
      "t": 40401,
      "e": 39227,
      "ty": 2,
      "x": 860,
      "y": 521
    },
    {
      "t": 40501,
      "e": 39327,
      "ty": 41,
      "x": 11246,
      "y": 30426,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 40601,
      "e": 39427,
      "ty": 2,
      "x": 858,
      "y": 524
    },
    {
      "t": 40701,
      "e": 39527,
      "ty": 2,
      "x": 857,
      "y": 526
    },
    {
      "t": 40723,
      "e": 39549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 40723,
      "e": 39549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40751,
      "e": 39577,
      "ty": 41,
      "x": 9949,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 40801,
      "e": 39627,
      "ty": 2,
      "x": 854,
      "y": 528
    },
    {
      "t": 40834,
      "e": 39660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 40901,
      "e": 39727,
      "ty": 2,
      "x": 851,
      "y": 533
    },
    {
      "t": 40907,
      "e": 39733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 40907,
      "e": 39733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41001,
      "e": 39827,
      "ty": 41,
      "x": 9300,
      "y": 58513,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 41043,
      "e": 39869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 41101,
      "e": 39927,
      "ty": 2,
      "x": 848,
      "y": 536
    },
    {
      "t": 41243,
      "e": 40069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 41244,
      "e": 40070,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 41244,
      "e": 40070,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41244,
      "e": 40070,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41251,
      "e": 40077,
      "ty": 41,
      "x": 8651,
      "y": 32415,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41387,
      "e": 40213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 41400,
      "e": 40226,
      "ty": 6,
      "x": 846,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41401,
      "e": 40227,
      "ty": 2,
      "x": 846,
      "y": 554
    },
    {
      "t": 41433,
      "e": 40259,
      "ty": 7,
      "x": 861,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41501,
      "e": 40327,
      "ty": 2,
      "x": 874,
      "y": 605
    },
    {
      "t": 41501,
      "e": 40327,
      "ty": 41,
      "x": 14274,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 41601,
      "e": 40427,
      "ty": 2,
      "x": 880,
      "y": 621
    },
    {
      "t": 41752,
      "e": 40578,
      "ty": 41,
      "x": 15572,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 41900,
      "e": 40726,
      "ty": 2,
      "x": 878,
      "y": 625
    },
    {
      "t": 41951,
      "e": 40777,
      "ty": 6,
      "x": 863,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42000,
      "e": 40826,
      "ty": 2,
      "x": 847,
      "y": 663
    },
    {
      "t": 42001,
      "e": 40827,
      "ty": 41,
      "x": 8435,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42018,
      "e": 40844,
      "ty": 7,
      "x": 840,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42100,
      "e": 40926,
      "ty": 2,
      "x": 831,
      "y": 689
    },
    {
      "t": 42200,
      "e": 41026,
      "ty": 2,
      "x": 831,
      "y": 701
    },
    {
      "t": 42252,
      "e": 41078,
      "ty": 41,
      "x": 28342,
      "y": 38556,
      "ta": "html > body"
    },
    {
      "t": 42300,
      "e": 41126,
      "ty": 2,
      "x": 831,
      "y": 704
    },
    {
      "t": 43395,
      "e": 42221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 43395,
      "e": 42221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43483,
      "e": 42309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 43867,
      "e": 42693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 43868,
      "e": 42694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43955,
      "e": 42781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u."
    },
    {
      "t": 44011,
      "e": 42837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 44163,
      "e": 42989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 44163,
      "e": 42989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44299,
      "e": 43125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u.S"
    },
    {
      "t": 44314,
      "e": 43140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u.S"
    },
    {
      "t": 44362,
      "e": 43188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 44362,
      "e": 43188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44443,
      "e": 43269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u.S."
    },
    {
      "t": 45187,
      "e": 44013,
      "ty": 6,
      "x": 899,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45200,
      "e": 44026,
      "ty": 2,
      "x": 899,
      "y": 699
    },
    {
      "t": 45250,
      "e": 44076,
      "ty": 41,
      "x": 9317,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45300,
      "e": 44126,
      "ty": 2,
      "x": 930,
      "y": 691
    },
    {
      "t": 45399,
      "e": 44225,
      "ty": 3,
      "x": 950,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45399,
      "e": 44225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u.S."
    },
    {
      "t": 45399,
      "e": 44225,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45399,
      "e": 44225,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45400,
      "e": 44226,
      "ty": 2,
      "x": 950,
      "y": 689
    },
    {
      "t": 45501,
      "e": 44327,
      "ty": 41,
      "x": 27871,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45519,
      "e": 44345,
      "ty": 4,
      "x": 27871,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45519,
      "e": 44345,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45519,
      "e": 44345,
      "ty": 5,
      "x": 950,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45519,
      "e": 44345,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 45800,
      "e": 44626,
      "ty": 2,
      "x": 947,
      "y": 689
    },
    {
      "t": 45900,
      "e": 44726,
      "ty": 2,
      "x": 888,
      "y": 667
    },
    {
      "t": 46000,
      "e": 44826,
      "ty": 2,
      "x": 809,
      "y": 612
    },
    {
      "t": 46000,
      "e": 44826,
      "ty": 41,
      "x": 27584,
      "y": 33459,
      "ta": "html > body"
    },
    {
      "t": 46100,
      "e": 44926,
      "ty": 2,
      "x": 773,
      "y": 590
    },
    {
      "t": 46200,
      "e": 45026,
      "ty": 2,
      "x": 770,
      "y": 574
    },
    {
      "t": 46251,
      "e": 45077,
      "ty": 41,
      "x": 26930,
      "y": 29637,
      "ta": "html > body"
    },
    {
      "t": 46300,
      "e": 45126,
      "ty": 2,
      "x": 814,
      "y": 512
    },
    {
      "t": 46400,
      "e": 45226,
      "ty": 2,
      "x": 829,
      "y": 499
    },
    {
      "t": 46500,
      "e": 45326,
      "ty": 41,
      "x": 28273,
      "y": 27200,
      "ta": "html > body"
    },
    {
      "t": 46542,
      "e": 45368,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46566,
      "e": 45392,
      "ty": 6,
      "x": 829,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46607,
      "e": 45433,
      "ty": 7,
      "x": 825,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46700,
      "e": 45526,
      "ty": 2,
      "x": 757,
      "y": 492
    },
    {
      "t": 46751,
      "e": 45577,
      "ty": 41,
      "x": 25552,
      "y": 26812,
      "ta": "html > body"
    },
    {
      "t": 46800,
      "e": 45626,
      "ty": 2,
      "x": 748,
      "y": 492
    },
    {
      "t": 47000,
      "e": 45826,
      "ty": 2,
      "x": 749,
      "y": 492
    },
    {
      "t": 47001,
      "e": 45827,
      "ty": 41,
      "x": 25518,
      "y": 26812,
      "ta": "html > body"
    },
    {
      "t": 47100,
      "e": 45926,
      "ty": 2,
      "x": 877,
      "y": 454
    },
    {
      "t": 47200,
      "e": 46026,
      "ty": 2,
      "x": 927,
      "y": 417
    },
    {
      "t": 47250,
      "e": 46076,
      "ty": 41,
      "x": 25056,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 47300,
      "e": 46126,
      "ty": 2,
      "x": 926,
      "y": 417
    },
    {
      "t": 47400,
      "e": 46226,
      "ty": 2,
      "x": 927,
      "y": 417
    },
    {
      "t": 47500,
      "e": 46326,
      "ty": 2,
      "x": 909,
      "y": 328
    },
    {
      "t": 47500,
      "e": 46326,
      "ty": 41,
      "x": 20784,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 47600,
      "e": 46426,
      "ty": 2,
      "x": 870,
      "y": 267
    },
    {
      "t": 47701,
      "e": 46527,
      "ty": 2,
      "x": 865,
      "y": 262
    },
    {
      "t": 47752,
      "e": 46528,
      "ty": 41,
      "x": 33189,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 47800,
      "e": 46576,
      "ty": 2,
      "x": 860,
      "y": 258
    },
    {
      "t": 47900,
      "e": 46676,
      "ty": 2,
      "x": 842,
      "y": 257
    },
    {
      "t": 47939,
      "e": 46715,
      "ty": 6,
      "x": 829,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 48000,
      "e": 46776,
      "ty": 2,
      "x": 829,
      "y": 261
    },
    {
      "t": 48000,
      "e": 46776,
      "ty": 41,
      "x": 12996,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 48055,
      "e": 46831,
      "ty": 7,
      "x": 827,
      "y": 258,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 48100,
      "e": 46876,
      "ty": 2,
      "x": 826,
      "y": 254
    },
    {
      "t": 48200,
      "e": 46976,
      "ty": 2,
      "x": 826,
      "y": 248
    },
    {
      "t": 48250,
      "e": 47026,
      "ty": 41,
      "x": 3748,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48300,
      "e": 47076,
      "ty": 2,
      "x": 826,
      "y": 246
    },
    {
      "t": 48323,
      "e": 47099,
      "ty": 6,
      "x": 827,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48400,
      "e": 47176,
      "ty": 2,
      "x": 828,
      "y": 243
    },
    {
      "t": 48500,
      "e": 47276,
      "ty": 2,
      "x": 828,
      "y": 238
    },
    {
      "t": 48501,
      "e": 47277,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48559,
      "e": 47335,
      "ty": 3,
      "x": 828,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48560,
      "e": 47336,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48647,
      "e": 47423,
      "ty": 4,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48648,
      "e": 47424,
      "ty": 5,
      "x": 828,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48648,
      "e": 47424,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 48751,
      "e": 47527,
      "ty": 41,
      "x": 0,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48755,
      "e": 47531,
      "ty": 7,
      "x": 825,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48800,
      "e": 47576,
      "ty": 2,
      "x": 818,
      "y": 255
    },
    {
      "t": 48900,
      "e": 47676,
      "ty": 2,
      "x": 811,
      "y": 288
    },
    {
      "t": 49000,
      "e": 47776,
      "ty": 2,
      "x": 828,
      "y": 334
    },
    {
      "t": 49000,
      "e": 47776,
      "ty": 41,
      "x": 1561,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 49101,
      "e": 47877,
      "ty": 2,
      "x": 837,
      "y": 365
    },
    {
      "t": 49200,
      "e": 47976,
      "ty": 2,
      "x": 840,
      "y": 383
    },
    {
      "t": 49251,
      "e": 48027,
      "ty": 41,
      "x": 3934,
      "y": 11103,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 49290,
      "e": 48066,
      "ty": 6,
      "x": 838,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49300,
      "e": 48076,
      "ty": 2,
      "x": 838,
      "y": 408
    },
    {
      "t": 49357,
      "e": 48133,
      "ty": 7,
      "x": 838,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49401,
      "e": 48177,
      "ty": 2,
      "x": 838,
      "y": 435
    },
    {
      "t": 49407,
      "e": 48183,
      "ty": 6,
      "x": 838,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 49500,
      "e": 48276,
      "ty": 2,
      "x": 839,
      "y": 448
    },
    {
      "t": 49500,
      "e": 48276,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 49512,
      "e": 48288,
      "ty": 7,
      "x": 839,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 49590,
      "e": 48366,
      "ty": 6,
      "x": 835,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 49600,
      "e": 48376,
      "ty": 2,
      "x": 835,
      "y": 464
    },
    {
      "t": 49674,
      "e": 48450,
      "ty": 7,
      "x": 831,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 49700,
      "e": 48476,
      "ty": 2,
      "x": 829,
      "y": 483
    },
    {
      "t": 49741,
      "e": 48517,
      "ty": 6,
      "x": 828,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 49750,
      "e": 48526,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 49800,
      "e": 48576,
      "ty": 2,
      "x": 827,
      "y": 503
    },
    {
      "t": 49806,
      "e": 48582,
      "ty": 7,
      "x": 826,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 49900,
      "e": 48676,
      "ty": 2,
      "x": 826,
      "y": 510
    },
    {
      "t": 50000,
      "e": 48776,
      "ty": 41,
      "x": 1086,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 50100,
      "e": 48876,
      "ty": 2,
      "x": 825,
      "y": 510
    },
    {
      "t": 50200,
      "e": 48976,
      "ty": 2,
      "x": 822,
      "y": 500
    },
    {
      "t": 50250,
      "e": 49026,
      "ty": 41,
      "x": 27963,
      "y": 27089,
      "ta": "html > body"
    },
    {
      "t": 50300,
      "e": 49076,
      "ty": 2,
      "x": 819,
      "y": 496
    },
    {
      "t": 50400,
      "e": 49176,
      "ty": 2,
      "x": 821,
      "y": 496
    },
    {
      "t": 50441,
      "e": 49217,
      "ty": 6,
      "x": 829,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50501,
      "e": 49218,
      "ty": 2,
      "x": 832,
      "y": 498
    },
    {
      "t": 50502,
      "e": 49219,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50600,
      "e": 49317,
      "ty": 2,
      "x": 836,
      "y": 499
    },
    {
      "t": 50679,
      "e": 49396,
      "ty": 3,
      "x": 836,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50679,
      "e": 49396,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50679,
      "e": 49396,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50750,
      "e": 49467,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50799,
      "e": 49516,
      "ty": 4,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50799,
      "e": 49516,
      "ty": 5,
      "x": 836,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 50799,
      "e": 49516,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 51001,
      "e": 49718,
      "ty": 2,
      "x": 836,
      "y": 502
    },
    {
      "t": 51001,
      "e": 49718,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 51042,
      "e": 49759,
      "ty": 7,
      "x": 836,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 51100,
      "e": 49817,
      "ty": 2,
      "x": 834,
      "y": 517
    },
    {
      "t": 51108,
      "e": 49825,
      "ty": 6,
      "x": 833,
      "y": 524,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51125,
      "e": 49842,
      "ty": 7,
      "x": 833,
      "y": 535,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51200,
      "e": 49917,
      "ty": 2,
      "x": 833,
      "y": 542
    },
    {
      "t": 51250,
      "e": 49967,
      "ty": 41,
      "x": 2747,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 51358,
      "e": 50075,
      "ty": 6,
      "x": 833,
      "y": 552,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 51391,
      "e": 50108,
      "ty": 7,
      "x": 835,
      "y": 564,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 51401,
      "e": 50118,
      "ty": 2,
      "x": 835,
      "y": 564
    },
    {
      "t": 51500,
      "e": 50217,
      "ty": 2,
      "x": 837,
      "y": 569
    },
    {
      "t": 51500,
      "e": 50217,
      "ty": 41,
      "x": 3697,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 51575,
      "e": 50292,
      "ty": 6,
      "x": 837,
      "y": 577,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 51600,
      "e": 50317,
      "ty": 2,
      "x": 837,
      "y": 580
    },
    {
      "t": 51625,
      "e": 50342,
      "ty": 7,
      "x": 839,
      "y": 590,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 51701,
      "e": 50418,
      "ty": 2,
      "x": 840,
      "y": 624
    },
    {
      "t": 51750,
      "e": 50467,
      "ty": 41,
      "x": 4409,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 51800,
      "e": 50517,
      "ty": 2,
      "x": 844,
      "y": 674
    },
    {
      "t": 51900,
      "e": 50617,
      "ty": 2,
      "x": 845,
      "y": 706
    },
    {
      "t": 52001,
      "e": 50718,
      "ty": 2,
      "x": 840,
      "y": 739
    },
    {
      "t": 52001,
      "e": 50718,
      "ty": 41,
      "x": 4662,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 52042,
      "e": 50759,
      "ty": 6,
      "x": 839,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 52100,
      "e": 50817,
      "ty": 2,
      "x": 835,
      "y": 764
    },
    {
      "t": 52109,
      "e": 50826,
      "ty": 7,
      "x": 832,
      "y": 770,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 52176,
      "e": 50893,
      "ty": 6,
      "x": 832,
      "y": 783,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 52201,
      "e": 50918,
      "ty": 2,
      "x": 832,
      "y": 786
    },
    {
      "t": 52250,
      "e": 50967,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 52259,
      "e": 50976,
      "ty": 7,
      "x": 833,
      "y": 795,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 52300,
      "e": 51017,
      "ty": 2,
      "x": 835,
      "y": 800
    },
    {
      "t": 52400,
      "e": 51117,
      "ty": 2,
      "x": 843,
      "y": 816
    },
    {
      "t": 52501,
      "e": 51218,
      "ty": 2,
      "x": 846,
      "y": 826
    },
    {
      "t": 52501,
      "e": 51218,
      "ty": 41,
      "x": 5832,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 52601,
      "e": 51318,
      "ty": 2,
      "x": 847,
      "y": 828
    },
    {
      "t": 52750,
      "e": 51467,
      "ty": 41,
      "x": 6070,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 52800,
      "e": 51517,
      "ty": 2,
      "x": 847,
      "y": 823
    },
    {
      "t": 52900,
      "e": 51617,
      "ty": 2,
      "x": 846,
      "y": 813
    },
    {
      "t": 53000,
      "e": 51717,
      "ty": 2,
      "x": 845,
      "y": 812
    },
    {
      "t": 53001,
      "e": 51718,
      "ty": 41,
      "x": 13916,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53100,
      "e": 51817,
      "ty": 2,
      "x": 840,
      "y": 795
    },
    {
      "t": 53127,
      "e": 51844,
      "ty": 6,
      "x": 838,
      "y": 788,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53200,
      "e": 51917,
      "ty": 2,
      "x": 835,
      "y": 782
    },
    {
      "t": 53251,
      "e": 51968,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53300,
      "e": 52017,
      "ty": 2,
      "x": 835,
      "y": 781
    },
    {
      "t": 53400,
      "e": 52117,
      "ty": 2,
      "x": 835,
      "y": 780
    },
    {
      "t": 53500,
      "e": 52217,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53560,
      "e": 52277,
      "ty": 7,
      "x": 835,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 53600,
      "e": 52317,
      "ty": 2,
      "x": 835,
      "y": 775
    },
    {
      "t": 53700,
      "e": 52417,
      "ty": 2,
      "x": 833,
      "y": 767
    },
    {
      "t": 53750,
      "e": 52467,
      "ty": 41,
      "x": 4413,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 53801,
      "e": 52518,
      "ty": 2,
      "x": 832,
      "y": 765
    },
    {
      "t": 54000,
      "e": 52717,
      "ty": 41,
      "x": 4413,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54079,
      "e": 52796,
      "ty": 6,
      "x": 832,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54100,
      "e": 52817,
      "ty": 2,
      "x": 832,
      "y": 762
    },
    {
      "t": 54201,
      "e": 52918,
      "ty": 2,
      "x": 834,
      "y": 757
    },
    {
      "t": 54251,
      "e": 52968,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54301,
      "e": 53018,
      "ty": 2,
      "x": 835,
      "y": 756
    },
    {
      "t": 54360,
      "e": 53077,
      "ty": 7,
      "x": 840,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54400,
      "e": 53117,
      "ty": 2,
      "x": 843,
      "y": 762
    },
    {
      "t": 54500,
      "e": 53217,
      "ty": 2,
      "x": 843,
      "y": 763
    },
    {
      "t": 54501,
      "e": 53218,
      "ty": 41,
      "x": 9003,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54600,
      "e": 53317,
      "ty": 2,
      "x": 839,
      "y": 751
    },
    {
      "t": 54701,
      "e": 53418,
      "ty": 2,
      "x": 834,
      "y": 737
    },
    {
      "t": 54711,
      "e": 53428,
      "ty": 6,
      "x": 834,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54751,
      "e": 53468,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54800,
      "e": 53517,
      "ty": 2,
      "x": 836,
      "y": 725
    },
    {
      "t": 54811,
      "e": 53528,
      "ty": 7,
      "x": 838,
      "y": 722,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 54900,
      "e": 53617,
      "ty": 2,
      "x": 842,
      "y": 709
    },
    {
      "t": 55001,
      "e": 53718,
      "ty": 2,
      "x": 843,
      "y": 701
    },
    {
      "t": 55001,
      "e": 53718,
      "ty": 41,
      "x": 5437,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55101,
      "e": 53818,
      "ty": 2,
      "x": 843,
      "y": 694
    },
    {
      "t": 55200,
      "e": 53917,
      "ty": 2,
      "x": 843,
      "y": 693
    },
    {
      "t": 55251,
      "e": 53968,
      "ty": 41,
      "x": 5437,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55359,
      "e": 54076,
      "ty": 3,
      "x": 843,
      "y": 693,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55360,
      "e": 54077,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 55534,
      "e": 54251,
      "ty": 4,
      "x": 5437,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55534,
      "e": 54251,
      "ty": 5,
      "x": 843,
      "y": 693,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55535,
      "e": 54252,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55535,
      "e": 54252,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 55711,
      "e": 54428,
      "ty": 2,
      "x": 843,
      "y": 699
    },
    {
      "t": 55761,
      "e": 54478,
      "ty": 41,
      "x": 5437,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 55811,
      "e": 54528,
      "ty": 2,
      "x": 843,
      "y": 703
    },
    {
      "t": 55911,
      "e": 54628,
      "ty": 2,
      "x": 842,
      "y": 716
    },
    {
      "t": 56011,
      "e": 54728,
      "ty": 2,
      "x": 848,
      "y": 740
    },
    {
      "t": 56011,
      "e": 54728,
      "ty": 41,
      "x": 6670,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 56111,
      "e": 54828,
      "ty": 2,
      "x": 842,
      "y": 760
    },
    {
      "t": 56211,
      "e": 54928,
      "ty": 2,
      "x": 840,
      "y": 777
    },
    {
      "t": 56239,
      "e": 54956,
      "ty": 6,
      "x": 839,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 56261,
      "e": 54978,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 56289,
      "e": 55006,
      "ty": 7,
      "x": 838,
      "y": 796,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 56310,
      "e": 55027,
      "ty": 2,
      "x": 836,
      "y": 802
    },
    {
      "t": 56323,
      "e": 55040,
      "ty": 6,
      "x": 835,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 56356,
      "e": 55073,
      "ty": 7,
      "x": 835,
      "y": 826,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 56407,
      "e": 55124,
      "ty": 6,
      "x": 835,
      "y": 837,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 56411,
      "e": 55128,
      "ty": 2,
      "x": 835,
      "y": 837
    },
    {
      "t": 56489,
      "e": 55206,
      "ty": 7,
      "x": 835,
      "y": 851,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 56511,
      "e": 55228,
      "ty": 2,
      "x": 835,
      "y": 856
    },
    {
      "t": 56512,
      "e": 55229,
      "ty": 41,
      "x": 3222,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 56611,
      "e": 55328,
      "ty": 2,
      "x": 835,
      "y": 877
    },
    {
      "t": 56711,
      "e": 55428,
      "ty": 2,
      "x": 837,
      "y": 904
    },
    {
      "t": 56761,
      "e": 55478,
      "ty": 41,
      "x": 4171,
      "y": 19156,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 56811,
      "e": 55528,
      "ty": 2,
      "x": 840,
      "y": 920
    },
    {
      "t": 56911,
      "e": 55628,
      "ty": 2,
      "x": 840,
      "y": 936
    },
    {
      "t": 57011,
      "e": 55728,
      "ty": 2,
      "x": 840,
      "y": 937
    },
    {
      "t": 57011,
      "e": 55728,
      "ty": 41,
      "x": 20291,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 57673,
      "e": 56390,
      "ty": 3,
      "x": 840,
      "y": 937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 57673,
      "e": 56390,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57825,
      "e": 56542,
      "ty": 4,
      "x": 20291,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 57825,
      "e": 56542,
      "ty": 5,
      "x": 840,
      "y": 937,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 57826,
      "e": 56543,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 57826,
      "e": 56543,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 58111,
      "e": 56828,
      "ty": 2,
      "x": 845,
      "y": 949
    },
    {
      "t": 58211,
      "e": 56928,
      "ty": 2,
      "x": 850,
      "y": 965
    },
    {
      "t": 58261,
      "e": 56978,
      "ty": 41,
      "x": 7731,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 58311,
      "e": 57028,
      "ty": 2,
      "x": 855,
      "y": 978
    },
    {
      "t": 58411,
      "e": 57128,
      "ty": 2,
      "x": 862,
      "y": 994
    },
    {
      "t": 58475,
      "e": 57192,
      "ty": 6,
      "x": 867,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58511,
      "e": 57228,
      "ty": 2,
      "x": 869,
      "y": 1014
    },
    {
      "t": 58511,
      "e": 57228,
      "ty": 41,
      "x": 20398,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58611,
      "e": 57328,
      "ty": 2,
      "x": 872,
      "y": 1016
    },
    {
      "t": 58658,
      "e": 57375,
      "ty": 3,
      "x": 872,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58658,
      "e": 57375,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 58658,
      "e": 57375,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58761,
      "e": 57478,
      "ty": 41,
      "x": 21944,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58801,
      "e": 57518,
      "ty": 4,
      "x": 21944,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58801,
      "e": 57518,
      "ty": 5,
      "x": 872,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58803,
      "e": 57520,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 58804,
      "e": 57521,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58805,
      "e": 57522,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 59211,
      "e": 57928,
      "ty": 2,
      "x": 874,
      "y": 1012
    },
    {
      "t": 59261,
      "e": 57978,
      "ty": 41,
      "x": 29823,
      "y": 55341,
      "ta": "html > body"
    },
    {
      "t": 59311,
      "e": 58028,
      "ty": 2,
      "x": 875,
      "y": 1004
    },
    {
      "t": 59411,
      "e": 58128,
      "ty": 2,
      "x": 877,
      "y": 996
    },
    {
      "t": 59512,
      "e": 58229,
      "ty": 2,
      "x": 877,
      "y": 993
    },
    {
      "t": 59512,
      "e": 58229,
      "ty": 41,
      "x": 29926,
      "y": 54566,
      "ta": "html > body"
    },
    {
      "t": 59611,
      "e": 58328,
      "ty": 2,
      "x": 880,
      "y": 984
    },
    {
      "t": 59711,
      "e": 58428,
      "ty": 2,
      "x": 880,
      "y": 978
    },
    {
      "t": 59762,
      "e": 58479,
      "ty": 41,
      "x": 30064,
      "y": 53624,
      "ta": "html > body"
    },
    {
      "t": 59811,
      "e": 58528,
      "ty": 2,
      "x": 884,
      "y": 972
    },
    {
      "t": 59883,
      "e": 58600,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 59911,
      "e": 58628,
      "ty": 2,
      "x": 891,
      "y": 967
    },
    {
      "t": 60011,
      "e": 58728,
      "ty": 2,
      "x": 894,
      "y": 965
    },
    {
      "t": 60011,
      "e": 58728,
      "ty": 41,
      "x": 29545,
      "y": 58077,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60111,
      "e": 58828,
      "ty": 2,
      "x": 896,
      "y": 964
    },
    {
      "t": 60211,
      "e": 58928,
      "ty": 2,
      "x": 898,
      "y": 963
    },
    {
      "t": 60261,
      "e": 58978,
      "ty": 41,
      "x": 29938,
      "y": 57870,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60311,
      "e": 59028,
      "ty": 2,
      "x": 911,
      "y": 958
    },
    {
      "t": 60411,
      "e": 59128,
      "ty": 2,
      "x": 934,
      "y": 951
    },
    {
      "t": 60511,
      "e": 59228,
      "ty": 2,
      "x": 935,
      "y": 951
    },
    {
      "t": 60511,
      "e": 59228,
      "ty": 41,
      "x": 31562,
      "y": 57108,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60611,
      "e": 59328,
      "ty": 2,
      "x": 932,
      "y": 976
    },
    {
      "t": 60711,
      "e": 59428,
      "ty": 2,
      "x": 931,
      "y": 994
    },
    {
      "t": 60761,
      "e": 59478,
      "ty": 41,
      "x": 31365,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60811,
      "e": 59528,
      "ty": 2,
      "x": 930,
      "y": 1015
    },
    {
      "t": 60911,
      "e": 59628,
      "ty": 2,
      "x": 930,
      "y": 1032
    },
    {
      "t": 61011,
      "e": 59728,
      "ty": 2,
      "x": 937,
      "y": 1050
    },
    {
      "t": 61012,
      "e": 59729,
      "ty": 41,
      "x": 31660,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61112,
      "e": 59829,
      "ty": 2,
      "x": 939,
      "y": 1055
    },
    {
      "t": 61194,
      "e": 59911,
      "ty": 6,
      "x": 946,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 61211,
      "e": 59928,
      "ty": 2,
      "x": 947,
      "y": 1075
    },
    {
      "t": 61262,
      "e": 59979,
      "ty": 41,
      "x": 21025,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 61312,
      "e": 60029,
      "ty": 2,
      "x": 948,
      "y": 1077
    },
    {
      "t": 61411,
      "e": 60128,
      "ty": 2,
      "x": 948,
      "y": 1078
    },
    {
      "t": 61511,
      "e": 60228,
      "ty": 41,
      "x": 21025,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 64761,
      "e": 63478,
      "ty": 41,
      "x": 21571,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 64796,
      "e": 63513,
      "ty": 7,
      "x": 950,
      "y": 1069,
      "ta": "#start"
    },
    {
      "t": 64811,
      "e": 63528,
      "ty": 2,
      "x": 950,
      "y": 1069
    },
    {
      "t": 64911,
      "e": 63628,
      "ty": 2,
      "x": 928,
      "y": 1005
    },
    {
      "t": 65011,
      "e": 63728,
      "ty": 2,
      "x": 888,
      "y": 894
    },
    {
      "t": 65011,
      "e": 63728,
      "ty": 41,
      "x": 29249,
      "y": 50358,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 65111,
      "e": 63828,
      "ty": 2,
      "x": 836,
      "y": 745
    },
    {
      "t": 65212,
      "e": 63929,
      "ty": 2,
      "x": 771,
      "y": 626
    },
    {
      "t": 65261,
      "e": 63978,
      "ty": 41,
      "x": 22067,
      "y": 36869,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65311,
      "e": 64028,
      "ty": 2,
      "x": 728,
      "y": 562
    },
    {
      "t": 65412,
      "e": 64129,
      "ty": 2,
      "x": 712,
      "y": 554
    },
    {
      "t": 65511,
      "e": 64228,
      "ty": 2,
      "x": 722,
      "y": 545
    },
    {
      "t": 65511,
      "e": 64228,
      "ty": 41,
      "x": 21083,
      "y": 24386,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65611,
      "e": 64328,
      "ty": 2,
      "x": 738,
      "y": 502
    },
    {
      "t": 65711,
      "e": 64428,
      "ty": 2,
      "x": 742,
      "y": 488
    },
    {
      "t": 65762,
      "e": 64429,
      "ty": 41,
      "x": 22067,
      "y": 2151,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65811,
      "e": 64478,
      "ty": 2,
      "x": 743,
      "y": 487
    },
    {
      "t": 65911,
      "e": 64578,
      "ty": 2,
      "x": 745,
      "y": 486
    },
    {
      "t": 66012,
      "e": 64679,
      "ty": 2,
      "x": 751,
      "y": 482
    },
    {
      "t": 66012,
      "e": 64679,
      "ty": 41,
      "x": 22509,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 66111,
      "e": 64778,
      "ty": 2,
      "x": 809,
      "y": 454
    },
    {
      "t": 66211,
      "e": 64878,
      "ty": 2,
      "x": 936,
      "y": 442
    },
    {
      "t": 66262,
      "e": 64929,
      "ty": 41,
      "x": 34120,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 66311,
      "e": 64978,
      "ty": 2,
      "x": 1020,
      "y": 430
    },
    {
      "t": 66411,
      "e": 65078,
      "ty": 2,
      "x": 1036,
      "y": 428
    },
    {
      "t": 66511,
      "e": 65178,
      "ty": 2,
      "x": 1037,
      "y": 428
    },
    {
      "t": 66512,
      "e": 65179,
      "ty": 41,
      "x": 36580,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67711,
      "e": 66378,
      "ty": 2,
      "x": 1028,
      "y": 428
    },
    {
      "t": 67761,
      "e": 66428,
      "ty": 41,
      "x": 34956,
      "y": 37850,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67811,
      "e": 66478,
      "ty": 2,
      "x": 968,
      "y": 431
    },
    {
      "t": 67911,
      "e": 66578,
      "ty": 2,
      "x": 847,
      "y": 437
    },
    {
      "t": 68011,
      "e": 66678,
      "ty": 2,
      "x": 760,
      "y": 436
    },
    {
      "t": 68011,
      "e": 66678,
      "ty": 41,
      "x": 22952,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68112,
      "e": 66779,
      "ty": 2,
      "x": 672,
      "y": 434
    },
    {
      "t": 68211,
      "e": 66878,
      "ty": 2,
      "x": 569,
      "y": 425
    },
    {
      "t": 68262,
      "e": 66929,
      "ty": 41,
      "x": 10997,
      "y": 32389,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68311,
      "e": 66978,
      "ty": 2,
      "x": 483,
      "y": 420
    },
    {
      "t": 68411,
      "e": 67078,
      "ty": 2,
      "x": 433,
      "y": 418
    },
    {
      "t": 68511,
      "e": 67178,
      "ty": 2,
      "x": 424,
      "y": 418
    },
    {
      "t": 68512,
      "e": 67179,
      "ty": 41,
      "x": 6422,
      "y": 29268,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68711,
      "e": 67378,
      "ty": 2,
      "x": 465,
      "y": 423
    },
    {
      "t": 68762,
      "e": 67429,
      "ty": 41,
      "x": 10456,
      "y": 38631,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68812,
      "e": 67479,
      "ty": 2,
      "x": 526,
      "y": 431
    },
    {
      "t": 68912,
      "e": 67579,
      "ty": 2,
      "x": 555,
      "y": 431
    },
    {
      "t": 69011,
      "e": 67678,
      "ty": 2,
      "x": 594,
      "y": 427
    },
    {
      "t": 69011,
      "e": 67678,
      "ty": 41,
      "x": 14786,
      "y": 36290,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69111,
      "e": 67778,
      "ty": 2,
      "x": 605,
      "y": 423
    },
    {
      "t": 69211,
      "e": 67878,
      "ty": 2,
      "x": 627,
      "y": 420
    },
    {
      "t": 69262,
      "e": 67929,
      "ty": 41,
      "x": 17245,
      "y": 28488,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69311,
      "e": 67978,
      "ty": 2,
      "x": 655,
      "y": 416
    },
    {
      "t": 69411,
      "e": 68078,
      "ty": 2,
      "x": 681,
      "y": 411
    },
    {
      "t": 69512,
      "e": 68179,
      "ty": 2,
      "x": 717,
      "y": 408
    },
    {
      "t": 69512,
      "e": 68179,
      "ty": 41,
      "x": 20837,
      "y": 21467,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69611,
      "e": 68278,
      "ty": 2,
      "x": 760,
      "y": 407
    },
    {
      "t": 69711,
      "e": 68378,
      "ty": 2,
      "x": 793,
      "y": 407
    },
    {
      "t": 69762,
      "e": 68429,
      "ty": 41,
      "x": 24920,
      "y": 20686,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69812,
      "e": 68479,
      "ty": 2,
      "x": 800,
      "y": 407
    },
    {
      "t": 70011,
      "e": 68678,
      "ty": 2,
      "x": 801,
      "y": 407
    },
    {
      "t": 70011,
      "e": 68678,
      "ty": 41,
      "x": 24969,
      "y": 20686,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70111,
      "e": 68778,
      "ty": 2,
      "x": 849,
      "y": 410
    },
    {
      "t": 70211,
      "e": 68878,
      "ty": 2,
      "x": 857,
      "y": 411
    },
    {
      "t": 70262,
      "e": 68929,
      "ty": 41,
      "x": 28069,
      "y": 23807,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70312,
      "e": 68979,
      "ty": 2,
      "x": 881,
      "y": 411
    },
    {
      "t": 70412,
      "e": 69079,
      "ty": 2,
      "x": 909,
      "y": 411
    },
    {
      "t": 70511,
      "e": 69178,
      "ty": 2,
      "x": 935,
      "y": 411
    },
    {
      "t": 70511,
      "e": 69178,
      "ty": 41,
      "x": 31562,
      "y": 23807,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70611,
      "e": 69278,
      "ty": 2,
      "x": 971,
      "y": 411
    },
    {
      "t": 70712,
      "e": 69379,
      "ty": 2,
      "x": 994,
      "y": 413
    },
    {
      "t": 70761,
      "e": 69428,
      "ty": 41,
      "x": 34759,
      "y": 25367,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 70811,
      "e": 69478,
      "ty": 2,
      "x": 1006,
      "y": 413
    },
    {
      "t": 70911,
      "e": 69578,
      "ty": 2,
      "x": 1025,
      "y": 416
    },
    {
      "t": 71012,
      "e": 69679,
      "ty": 2,
      "x": 1051,
      "y": 420
    },
    {
      "t": 71012,
      "e": 69679,
      "ty": 41,
      "x": 37269,
      "y": 30829,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71112,
      "e": 69779,
      "ty": 2,
      "x": 1072,
      "y": 426
    },
    {
      "t": 71212,
      "e": 69879,
      "ty": 2,
      "x": 1103,
      "y": 430
    },
    {
      "t": 71261,
      "e": 69928,
      "ty": 41,
      "x": 40220,
      "y": 39411,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71312,
      "e": 69979,
      "ty": 2,
      "x": 1118,
      "y": 431
    },
    {
      "t": 71411,
      "e": 70078,
      "ty": 2,
      "x": 1132,
      "y": 429
    },
    {
      "t": 71511,
      "e": 70178,
      "ty": 2,
      "x": 1160,
      "y": 429
    },
    {
      "t": 71512,
      "e": 70179,
      "ty": 41,
      "x": 42631,
      "y": 37850,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71611,
      "e": 70278,
      "ty": 2,
      "x": 1184,
      "y": 433
    },
    {
      "t": 71712,
      "e": 70379,
      "ty": 2,
      "x": 1206,
      "y": 437
    },
    {
      "t": 71762,
      "e": 70429,
      "ty": 41,
      "x": 45288,
      "y": 44092,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71812,
      "e": 70479,
      "ty": 2,
      "x": 1227,
      "y": 437
    },
    {
      "t": 71912,
      "e": 70579,
      "ty": 2,
      "x": 1249,
      "y": 434
    },
    {
      "t": 72011,
      "e": 70678,
      "ty": 2,
      "x": 1269,
      "y": 428
    },
    {
      "t": 72011,
      "e": 70678,
      "ty": 41,
      "x": 47993,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 72111,
      "e": 70778,
      "ty": 2,
      "x": 1290,
      "y": 421
    },
    {
      "t": 72211,
      "e": 70878,
      "ty": 2,
      "x": 1295,
      "y": 421
    },
    {
      "t": 72261,
      "e": 70928,
      "ty": 41,
      "x": 49273,
      "y": 31609,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 72411,
      "e": 71078,
      "ty": 2,
      "x": 1260,
      "y": 425
    },
    {
      "t": 72512,
      "e": 71179,
      "ty": 2,
      "x": 1189,
      "y": 425
    },
    {
      "t": 72512,
      "e": 71179,
      "ty": 41,
      "x": 44058,
      "y": 34730,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 72611,
      "e": 71278,
      "ty": 2,
      "x": 1155,
      "y": 429
    },
    {
      "t": 72712,
      "e": 71379,
      "ty": 2,
      "x": 1060,
      "y": 428
    },
    {
      "t": 72761,
      "e": 71428,
      "ty": 41,
      "x": 33431,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 72812,
      "e": 71479,
      "ty": 2,
      "x": 913,
      "y": 428
    },
    {
      "t": 72911,
      "e": 71578,
      "ty": 2,
      "x": 834,
      "y": 427
    },
    {
      "t": 73011,
      "e": 71678,
      "ty": 2,
      "x": 732,
      "y": 432
    },
    {
      "t": 73012,
      "e": 71679,
      "ty": 41,
      "x": 21575,
      "y": 40191,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 73112,
      "e": 71779,
      "ty": 2,
      "x": 628,
      "y": 423
    },
    {
      "t": 73212,
      "e": 71879,
      "ty": 2,
      "x": 563,
      "y": 425
    },
    {
      "t": 73261,
      "e": 71928,
      "ty": 41,
      "x": 11637,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 73310,
      "e": 71977,
      "ty": 2,
      "x": 495,
      "y": 429
    },
    {
      "t": 73412,
      "e": 72079,
      "ty": 2,
      "x": 439,
      "y": 437
    },
    {
      "t": 73511,
      "e": 72178,
      "ty": 2,
      "x": 395,
      "y": 442
    },
    {
      "t": 73511,
      "e": 72178,
      "ty": 41,
      "x": 4995,
      "y": 47993,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 73610,
      "e": 72277,
      "ty": 2,
      "x": 394,
      "y": 443
    },
    {
      "t": 73761,
      "e": 72428,
      "ty": 41,
      "x": 4946,
      "y": 48773,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 73912,
      "e": 72579,
      "ty": 2,
      "x": 416,
      "y": 443
    },
    {
      "t": 74012,
      "e": 72679,
      "ty": 2,
      "x": 423,
      "y": 443
    },
    {
      "t": 74012,
      "e": 72679,
      "ty": 41,
      "x": 6373,
      "y": 48773,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 74111,
      "e": 72778,
      "ty": 2,
      "x": 439,
      "y": 443
    },
    {
      "t": 74212,
      "e": 72879,
      "ty": 2,
      "x": 467,
      "y": 446
    },
    {
      "t": 74261,
      "e": 72928,
      "ty": 41,
      "x": 9423,
      "y": 51113,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 74311,
      "e": 72978,
      "ty": 2,
      "x": 504,
      "y": 446
    },
    {
      "t": 74411,
      "e": 73078,
      "ty": 2,
      "x": 565,
      "y": 453
    },
    {
      "t": 74511,
      "e": 73178,
      "ty": 2,
      "x": 588,
      "y": 453
    },
    {
      "t": 74511,
      "e": 73178,
      "ty": 41,
      "x": 14490,
      "y": 56575,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 74611,
      "e": 73278,
      "ty": 2,
      "x": 592,
      "y": 453
    },
    {
      "t": 74761,
      "e": 73428,
      "ty": 41,
      "x": 14638,
      "y": 57355,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 74810,
      "e": 73477,
      "ty": 2,
      "x": 587,
      "y": 456
    },
    {
      "t": 74911,
      "e": 73578,
      "ty": 2,
      "x": 581,
      "y": 461
    },
    {
      "t": 75011,
      "e": 73678,
      "ty": 2,
      "x": 581,
      "y": 467
    },
    {
      "t": 75011,
      "e": 73678,
      "ty": 41,
      "x": 14146,
      "y": 15343,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 75112,
      "e": 73779,
      "ty": 2,
      "x": 602,
      "y": 476
    },
    {
      "t": 75211,
      "e": 73878,
      "ty": 2,
      "x": 644,
      "y": 480
    },
    {
      "t": 75261,
      "e": 73928,
      "ty": 41,
      "x": 18328,
      "y": 981,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75310,
      "e": 73977,
      "ty": 2,
      "x": 684,
      "y": 487
    },
    {
      "t": 75411,
      "e": 74078,
      "ty": 2,
      "x": 699,
      "y": 486
    },
    {
      "t": 75511,
      "e": 74178,
      "ty": 2,
      "x": 727,
      "y": 486
    },
    {
      "t": 75511,
      "e": 74178,
      "ty": 41,
      "x": 21329,
      "y": 1371,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75610,
      "e": 74277,
      "ty": 2,
      "x": 746,
      "y": 486
    },
    {
      "t": 75711,
      "e": 74378,
      "ty": 2,
      "x": 781,
      "y": 483
    },
    {
      "t": 75762,
      "e": 74429,
      "ty": 41,
      "x": 24920,
      "y": 1371,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75811,
      "e": 74478,
      "ty": 2,
      "x": 816,
      "y": 488
    },
    {
      "t": 75910,
      "e": 74577,
      "ty": 2,
      "x": 841,
      "y": 488
    },
    {
      "t": 76011,
      "e": 74678,
      "ty": 2,
      "x": 869,
      "y": 488
    },
    {
      "t": 76011,
      "e": 74678,
      "ty": 41,
      "x": 28315,
      "y": 2151,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76111,
      "e": 74778,
      "ty": 2,
      "x": 905,
      "y": 488
    },
    {
      "t": 76211,
      "e": 74878,
      "ty": 2,
      "x": 929,
      "y": 492
    },
    {
      "t": 76261,
      "e": 74928,
      "ty": 41,
      "x": 31808,
      "y": 4492,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76311,
      "e": 74978,
      "ty": 2,
      "x": 954,
      "y": 497
    },
    {
      "t": 76411,
      "e": 75078,
      "ty": 2,
      "x": 979,
      "y": 500
    },
    {
      "t": 76510,
      "e": 75177,
      "ty": 2,
      "x": 1007,
      "y": 504
    },
    {
      "t": 76510,
      "e": 75177,
      "ty": 41,
      "x": 35104,
      "y": 8393,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76611,
      "e": 75278,
      "ty": 2,
      "x": 1018,
      "y": 505
    },
    {
      "t": 76710,
      "e": 75377,
      "ty": 2,
      "x": 1029,
      "y": 505
    },
    {
      "t": 76761,
      "e": 75428,
      "ty": 41,
      "x": 36580,
      "y": 8783,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 76810,
      "e": 75477,
      "ty": 2,
      "x": 1045,
      "y": 504
    },
    {
      "t": 76910,
      "e": 75577,
      "ty": 2,
      "x": 1066,
      "y": 502
    },
    {
      "t": 77010,
      "e": 75677,
      "ty": 2,
      "x": 1088,
      "y": 502
    },
    {
      "t": 77010,
      "e": 75677,
      "ty": 41,
      "x": 39089,
      "y": 7612,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 77111,
      "e": 75778,
      "ty": 2,
      "x": 1109,
      "y": 502
    },
    {
      "t": 77211,
      "e": 75878,
      "ty": 2,
      "x": 1130,
      "y": 499
    },
    {
      "t": 77261,
      "e": 75928,
      "ty": 41,
      "x": 41303,
      "y": 6442,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 77310,
      "e": 75977,
      "ty": 2,
      "x": 1151,
      "y": 498
    },
    {
      "t": 77411,
      "e": 76078,
      "ty": 2,
      "x": 1184,
      "y": 497
    },
    {
      "t": 77511,
      "e": 76178,
      "ty": 2,
      "x": 1202,
      "y": 495
    },
    {
      "t": 77511,
      "e": 76178,
      "ty": 41,
      "x": 44697,
      "y": 4882,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 77610,
      "e": 76277,
      "ty": 2,
      "x": 1225,
      "y": 493
    },
    {
      "t": 77711,
      "e": 76378,
      "ty": 2,
      "x": 1243,
      "y": 491
    },
    {
      "t": 77761,
      "e": 76428,
      "ty": 41,
      "x": 47305,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 77811,
      "e": 76478,
      "ty": 2,
      "x": 1269,
      "y": 491
    },
    {
      "t": 77911,
      "e": 76578,
      "ty": 2,
      "x": 1282,
      "y": 492
    },
    {
      "t": 78010,
      "e": 76677,
      "ty": 2,
      "x": 1287,
      "y": 492
    },
    {
      "t": 78011,
      "e": 76678,
      "ty": 41,
      "x": 48879,
      "y": 3711,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78111,
      "e": 76778,
      "ty": 2,
      "x": 1292,
      "y": 492
    },
    {
      "t": 78211,
      "e": 76878,
      "ty": 2,
      "x": 1295,
      "y": 492
    },
    {
      "t": 78261,
      "e": 76928,
      "ty": 41,
      "x": 49371,
      "y": 3711,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78311,
      "e": 76978,
      "ty": 2,
      "x": 1298,
      "y": 492
    },
    {
      "t": 78411,
      "e": 77078,
      "ty": 2,
      "x": 1305,
      "y": 492
    },
    {
      "t": 78510,
      "e": 77177,
      "ty": 2,
      "x": 1314,
      "y": 491
    },
    {
      "t": 78511,
      "e": 77178,
      "ty": 41,
      "x": 50207,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78611,
      "e": 77278,
      "ty": 2,
      "x": 1327,
      "y": 492
    },
    {
      "t": 78711,
      "e": 77378,
      "ty": 2,
      "x": 1334,
      "y": 491
    },
    {
      "t": 78761,
      "e": 77378,
      "ty": 41,
      "x": 51585,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78811,
      "e": 77428,
      "ty": 2,
      "x": 1349,
      "y": 491
    },
    {
      "t": 78910,
      "e": 77527,
      "ty": 2,
      "x": 1364,
      "y": 493
    },
    {
      "t": 79011,
      "e": 77628,
      "ty": 2,
      "x": 1370,
      "y": 496
    },
    {
      "t": 79011,
      "e": 77628,
      "ty": 41,
      "x": 52962,
      "y": 5272,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 79111,
      "e": 77728,
      "ty": 2,
      "x": 1381,
      "y": 498
    },
    {
      "t": 79211,
      "e": 77828,
      "ty": 2,
      "x": 1382,
      "y": 498
    },
    {
      "t": 79261,
      "e": 77878,
      "ty": 41,
      "x": 53553,
      "y": 6052,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 79311,
      "e": 77928,
      "ty": 2,
      "x": 1370,
      "y": 500
    },
    {
      "t": 79410,
      "e": 78027,
      "ty": 2,
      "x": 1253,
      "y": 512
    },
    {
      "t": 79510,
      "e": 78127,
      "ty": 2,
      "x": 1021,
      "y": 518
    },
    {
      "t": 79510,
      "e": 78127,
      "ty": 41,
      "x": 35793,
      "y": 13854,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 79610,
      "e": 78227,
      "ty": 2,
      "x": 618,
      "y": 524
    },
    {
      "t": 79711,
      "e": 78328,
      "ty": 2,
      "x": 394,
      "y": 516
    },
    {
      "t": 79761,
      "e": 78378,
      "ty": 41,
      "x": 1896,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 79811,
      "e": 78428,
      "ty": 2,
      "x": 285,
      "y": 523
    },
    {
      "t": 79910,
      "e": 78527,
      "ty": 2,
      "x": 247,
      "y": 534
    },
    {
      "t": 80011,
      "e": 78628,
      "ty": 2,
      "x": 246,
      "y": 535
    },
    {
      "t": 80011,
      "e": 78628,
      "ty": 41,
      "x": 8196,
      "y": 29194,
      "ta": "> div.masterdiv"
    },
    {
      "t": 80110,
      "e": 78727,
      "ty": 2,
      "x": 323,
      "y": 535
    },
    {
      "t": 80210,
      "e": 78827,
      "ty": 2,
      "x": 378,
      "y": 531
    },
    {
      "t": 80261,
      "e": 78878,
      "ty": 41,
      "x": 5143,
      "y": 16194,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80311,
      "e": 78928,
      "ty": 2,
      "x": 429,
      "y": 524
    },
    {
      "t": 80410,
      "e": 79027,
      "ty": 2,
      "x": 463,
      "y": 525
    },
    {
      "t": 80510,
      "e": 79127,
      "ty": 2,
      "x": 473,
      "y": 525
    },
    {
      "t": 80511,
      "e": 79128,
      "ty": 41,
      "x": 8833,
      "y": 16584,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80611,
      "e": 79228,
      "ty": 2,
      "x": 516,
      "y": 525
    },
    {
      "t": 80710,
      "e": 79327,
      "ty": 2,
      "x": 564,
      "y": 523
    },
    {
      "t": 80760,
      "e": 79377,
      "ty": 41,
      "x": 13900,
      "y": 15024,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80810,
      "e": 79427,
      "ty": 2,
      "x": 588,
      "y": 520
    },
    {
      "t": 80911,
      "e": 79528,
      "ty": 2,
      "x": 610,
      "y": 520
    },
    {
      "t": 81011,
      "e": 79628,
      "ty": 2,
      "x": 642,
      "y": 519
    },
    {
      "t": 81011,
      "e": 79628,
      "ty": 41,
      "x": 17147,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81111,
      "e": 79728,
      "ty": 2,
      "x": 685,
      "y": 519
    },
    {
      "t": 81211,
      "e": 79828,
      "ty": 2,
      "x": 709,
      "y": 516
    },
    {
      "t": 81261,
      "e": 79878,
      "ty": 41,
      "x": 20984,
      "y": 11903,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81310,
      "e": 79927,
      "ty": 2,
      "x": 734,
      "y": 513
    },
    {
      "t": 81411,
      "e": 80028,
      "ty": 2,
      "x": 772,
      "y": 516
    },
    {
      "t": 81511,
      "e": 80128,
      "ty": 2,
      "x": 810,
      "y": 521
    },
    {
      "t": 81511,
      "e": 80128,
      "ty": 41,
      "x": 25412,
      "y": 15024,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81610,
      "e": 80227,
      "ty": 2,
      "x": 832,
      "y": 522
    },
    {
      "t": 81711,
      "e": 80328,
      "ty": 2,
      "x": 860,
      "y": 523
    },
    {
      "t": 81761,
      "e": 80378,
      "ty": 41,
      "x": 28118,
      "y": 15804,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81811,
      "e": 80428,
      "ty": 2,
      "x": 879,
      "y": 526
    },
    {
      "t": 81911,
      "e": 80528,
      "ty": 2,
      "x": 892,
      "y": 526
    },
    {
      "t": 82011,
      "e": 80628,
      "ty": 2,
      "x": 895,
      "y": 526
    },
    {
      "t": 82011,
      "e": 80628,
      "ty": 41,
      "x": 29594,
      "y": 16974,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82110,
      "e": 80727,
      "ty": 2,
      "x": 898,
      "y": 526
    },
    {
      "t": 82210,
      "e": 80827,
      "ty": 2,
      "x": 915,
      "y": 526
    },
    {
      "t": 82261,
      "e": 80878,
      "ty": 41,
      "x": 30873,
      "y": 16974,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82310,
      "e": 80927,
      "ty": 2,
      "x": 940,
      "y": 525
    },
    {
      "t": 82411,
      "e": 81028,
      "ty": 2,
      "x": 944,
      "y": 525
    },
    {
      "t": 82510,
      "e": 81127,
      "ty": 2,
      "x": 950,
      "y": 525
    },
    {
      "t": 82511,
      "e": 81128,
      "ty": 41,
      "x": 32300,
      "y": 16584,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 82611,
      "e": 81228,
      "ty": 2,
      "x": 974,
      "y": 525
    },
    {
      "t": 82710,
      "e": 81327,
      "ty": 2,
      "x": 980,
      "y": 525
    },
    {
      "t": 82761,
      "e": 81378,
      "ty": 41,
      "x": 33776,
      "y": 16584,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83010,
      "e": 81627,
      "ty": 2,
      "x": 982,
      "y": 525
    },
    {
      "t": 83011,
      "e": 81628,
      "ty": 41,
      "x": 33874,
      "y": 16584,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83111,
      "e": 81728,
      "ty": 2,
      "x": 1013,
      "y": 525
    },
    {
      "t": 83211,
      "e": 81828,
      "ty": 2,
      "x": 1038,
      "y": 526
    },
    {
      "t": 83261,
      "e": 81878,
      "ty": 41,
      "x": 36924,
      "y": 16974,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83311,
      "e": 81928,
      "ty": 2,
      "x": 1055,
      "y": 527
    },
    {
      "t": 83411,
      "e": 82028,
      "ty": 2,
      "x": 1072,
      "y": 529
    },
    {
      "t": 83511,
      "e": 82128,
      "ty": 2,
      "x": 1126,
      "y": 534
    },
    {
      "t": 83511,
      "e": 82128,
      "ty": 41,
      "x": 40958,
      "y": 20095,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83611,
      "e": 82228,
      "ty": 2,
      "x": 1145,
      "y": 535
    },
    {
      "t": 83711,
      "e": 82328,
      "ty": 2,
      "x": 1166,
      "y": 535
    },
    {
      "t": 83761,
      "e": 82378,
      "ty": 41,
      "x": 43320,
      "y": 20485,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 83811,
      "e": 82428,
      "ty": 2,
      "x": 1186,
      "y": 533
    },
    {
      "t": 83911,
      "e": 82528,
      "ty": 2,
      "x": 1212,
      "y": 527
    },
    {
      "t": 84010,
      "e": 82627,
      "ty": 2,
      "x": 1219,
      "y": 525
    },
    {
      "t": 84011,
      "e": 82628,
      "ty": 41,
      "x": 45534,
      "y": 16584,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84111,
      "e": 82728,
      "ty": 2,
      "x": 1235,
      "y": 523
    },
    {
      "t": 84211,
      "e": 82828,
      "ty": 2,
      "x": 1274,
      "y": 519
    },
    {
      "t": 84261,
      "e": 82878,
      "ty": 41,
      "x": 49469,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84311,
      "e": 82928,
      "ty": 2,
      "x": 1319,
      "y": 519
    },
    {
      "t": 84411,
      "e": 83028,
      "ty": 2,
      "x": 1380,
      "y": 519
    },
    {
      "t": 84510,
      "e": 83127,
      "ty": 2,
      "x": 1415,
      "y": 520
    },
    {
      "t": 84510,
      "e": 83127,
      "ty": 41,
      "x": 55176,
      "y": 14634,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84611,
      "e": 83228,
      "ty": 2,
      "x": 1426,
      "y": 520
    },
    {
      "t": 84711,
      "e": 83328,
      "ty": 2,
      "x": 1436,
      "y": 520
    },
    {
      "t": 84761,
      "e": 83378,
      "ty": 41,
      "x": 56800,
      "y": 14634,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 84811,
      "e": 83428,
      "ty": 2,
      "x": 1458,
      "y": 522
    },
    {
      "t": 84911,
      "e": 83528,
      "ty": 2,
      "x": 1481,
      "y": 523
    },
    {
      "t": 85011,
      "e": 83628,
      "ty": 2,
      "x": 1500,
      "y": 522
    },
    {
      "t": 85011,
      "e": 83628,
      "ty": 41,
      "x": 59358,
      "y": 15414,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85111,
      "e": 83728,
      "ty": 2,
      "x": 1483,
      "y": 521
    },
    {
      "t": 85211,
      "e": 83828,
      "ty": 2,
      "x": 1142,
      "y": 531
    },
    {
      "t": 85261,
      "e": 83878,
      "ty": 41,
      "x": 30086,
      "y": 17755,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85310,
      "e": 83927,
      "ty": 2,
      "x": 753,
      "y": 527
    },
    {
      "t": 85411,
      "e": 84028,
      "ty": 2,
      "x": 554,
      "y": 536
    },
    {
      "t": 85511,
      "e": 84128,
      "ty": 2,
      "x": 479,
      "y": 551
    },
    {
      "t": 85511,
      "e": 84128,
      "ty": 41,
      "x": 9128,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85611,
      "e": 84228,
      "ty": 2,
      "x": 431,
      "y": 558
    },
    {
      "t": 85711,
      "e": 84328,
      "ty": 2,
      "x": 390,
      "y": 557
    },
    {
      "t": 85761,
      "e": 84378,
      "ty": 41,
      "x": 3913,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 85810,
      "e": 84427,
      "ty": 2,
      "x": 368,
      "y": 554
    },
    {
      "t": 86011,
      "e": 84628,
      "ty": 41,
      "x": 3667,
      "y": 27897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86111,
      "e": 84728,
      "ty": 2,
      "x": 369,
      "y": 554
    },
    {
      "t": 86211,
      "e": 84828,
      "ty": 2,
      "x": 428,
      "y": 553
    },
    {
      "t": 86261,
      "e": 84878,
      "ty": 41,
      "x": 7603,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86311,
      "e": 84928,
      "ty": 2,
      "x": 463,
      "y": 551
    },
    {
      "t": 86411,
      "e": 85028,
      "ty": 2,
      "x": 482,
      "y": 549
    },
    {
      "t": 86511,
      "e": 85128,
      "ty": 2,
      "x": 484,
      "y": 549
    },
    {
      "t": 86511,
      "e": 85128,
      "ty": 41,
      "x": 9374,
      "y": 25947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86611,
      "e": 85228,
      "ty": 2,
      "x": 507,
      "y": 549
    },
    {
      "t": 86711,
      "e": 85328,
      "ty": 2,
      "x": 517,
      "y": 549
    },
    {
      "t": 86761,
      "e": 85378,
      "ty": 41,
      "x": 11391,
      "y": 26337,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 86811,
      "e": 85428,
      "ty": 2,
      "x": 536,
      "y": 550
    },
    {
      "t": 86911,
      "e": 85528,
      "ty": 2,
      "x": 576,
      "y": 550
    },
    {
      "t": 87011,
      "e": 85628,
      "ty": 2,
      "x": 615,
      "y": 547
    },
    {
      "t": 87011,
      "e": 85628,
      "ty": 41,
      "x": 15819,
      "y": 25166,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 87111,
      "e": 85728,
      "ty": 2,
      "x": 627,
      "y": 544
    },
    {
      "t": 87211,
      "e": 85828,
      "ty": 2,
      "x": 632,
      "y": 543
    },
    {
      "t": 87261,
      "e": 85878,
      "ty": 41,
      "x": 16655,
      "y": 23606,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 87611,
      "e": 86228,
      "ty": 2,
      "x": 653,
      "y": 545
    },
    {
      "t": 87711,
      "e": 86328,
      "ty": 2,
      "x": 676,
      "y": 548
    },
    {
      "t": 87761,
      "e": 86378,
      "ty": 41,
      "x": 19115,
      "y": 25947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 87814,
      "e": 86431,
      "ty": 2,
      "x": 698,
      "y": 550
    },
    {
      "t": 87911,
      "e": 86528,
      "ty": 2,
      "x": 735,
      "y": 552
    },
    {
      "t": 88011,
      "e": 86628,
      "ty": 2,
      "x": 747,
      "y": 552
    },
    {
      "t": 88011,
      "e": 86628,
      "ty": 41,
      "x": 22313,
      "y": 27117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 88111,
      "e": 86728,
      "ty": 2,
      "x": 762,
      "y": 552
    },
    {
      "t": 88211,
      "e": 86828,
      "ty": 2,
      "x": 788,
      "y": 552
    },
    {
      "t": 88262,
      "e": 86879,
      "ty": 41,
      "x": 24527,
      "y": 26727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 88311,
      "e": 86928,
      "ty": 2,
      "x": 799,
      "y": 550
    },
    {
      "t": 88411,
      "e": 87028,
      "ty": 2,
      "x": 822,
      "y": 549
    },
    {
      "t": 88511,
      "e": 87128,
      "ty": 2,
      "x": 862,
      "y": 549
    },
    {
      "t": 88512,
      "e": 87129,
      "ty": 41,
      "x": 27970,
      "y": 25947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 88611,
      "e": 87228,
      "ty": 2,
      "x": 874,
      "y": 548
    },
    {
      "t": 88711,
      "e": 87328,
      "ty": 2,
      "x": 907,
      "y": 550
    },
    {
      "t": 88761,
      "e": 87378,
      "ty": 41,
      "x": 31021,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 88811,
      "e": 87428,
      "ty": 2,
      "x": 934,
      "y": 554
    },
    {
      "t": 88911,
      "e": 87528,
      "ty": 2,
      "x": 994,
      "y": 564
    },
    {
      "t": 89011,
      "e": 87628,
      "ty": 2,
      "x": 1011,
      "y": 567
    },
    {
      "t": 89011,
      "e": 87628,
      "ty": 41,
      "x": 35301,
      "y": 32968,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89111,
      "e": 87728,
      "ty": 2,
      "x": 1015,
      "y": 567
    },
    {
      "t": 89211,
      "e": 87828,
      "ty": 2,
      "x": 1029,
      "y": 566
    },
    {
      "t": 89261,
      "e": 87878,
      "ty": 41,
      "x": 36678,
      "y": 31408,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89312,
      "e": 87929,
      "ty": 2,
      "x": 1047,
      "y": 562
    },
    {
      "t": 89411,
      "e": 88028,
      "ty": 2,
      "x": 1062,
      "y": 556
    },
    {
      "t": 89511,
      "e": 88128,
      "ty": 2,
      "x": 1072,
      "y": 555
    },
    {
      "t": 89512,
      "e": 88129,
      "ty": 41,
      "x": 38302,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89611,
      "e": 88228,
      "ty": 2,
      "x": 1084,
      "y": 555
    },
    {
      "t": 89711,
      "e": 88328,
      "ty": 2,
      "x": 1101,
      "y": 556
    },
    {
      "t": 89761,
      "e": 88378,
      "ty": 41,
      "x": 39876,
      "y": 28677,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 89811,
      "e": 88428,
      "ty": 2,
      "x": 1111,
      "y": 556
    },
    {
      "t": 89911,
      "e": 88528,
      "ty": 2,
      "x": 1141,
      "y": 557
    },
    {
      "t": 90011,
      "e": 88628,
      "ty": 2,
      "x": 1169,
      "y": 557
    },
    {
      "t": 90012,
      "e": 88629,
      "ty": 41,
      "x": 43074,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90012,
      "e": 88629,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90111,
      "e": 88728,
      "ty": 2,
      "x": 1185,
      "y": 557
    },
    {
      "t": 90211,
      "e": 88828,
      "ty": 2,
      "x": 1197,
      "y": 553
    },
    {
      "t": 90262,
      "e": 88879,
      "ty": 41,
      "x": 44451,
      "y": 27507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90311,
      "e": 88928,
      "ty": 2,
      "x": 1160,
      "y": 556
    },
    {
      "t": 90411,
      "e": 89028,
      "ty": 2,
      "x": 1007,
      "y": 573
    },
    {
      "t": 90511,
      "e": 89128,
      "ty": 2,
      "x": 878,
      "y": 576
    },
    {
      "t": 90511,
      "e": 89128,
      "ty": 41,
      "x": 28757,
      "y": 36479,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90611,
      "e": 89228,
      "ty": 2,
      "x": 763,
      "y": 580
    },
    {
      "t": 90712,
      "e": 89329,
      "ty": 2,
      "x": 716,
      "y": 580
    },
    {
      "t": 90762,
      "e": 89379,
      "ty": 41,
      "x": 20296,
      "y": 38819,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 90812,
      "e": 89429,
      "ty": 2,
      "x": 699,
      "y": 585
    },
    {
      "t": 90912,
      "e": 89529,
      "ty": 2,
      "x": 663,
      "y": 593
    },
    {
      "t": 91011,
      "e": 89628,
      "ty": 2,
      "x": 609,
      "y": 606
    },
    {
      "t": 91012,
      "e": 89629,
      "ty": 41,
      "x": 15523,
      "y": 48182,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91111,
      "e": 89728,
      "ty": 2,
      "x": 552,
      "y": 616
    },
    {
      "t": 91211,
      "e": 89828,
      "ty": 2,
      "x": 478,
      "y": 616
    },
    {
      "t": 91262,
      "e": 89879,
      "ty": 41,
      "x": 6668,
      "y": 50522,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91311,
      "e": 89928,
      "ty": 2,
      "x": 398,
      "y": 608
    },
    {
      "t": 91411,
      "e": 90028,
      "ty": 2,
      "x": 368,
      "y": 608
    },
    {
      "t": 91511,
      "e": 90128,
      "ty": 2,
      "x": 352,
      "y": 610
    },
    {
      "t": 91512,
      "e": 90129,
      "ty": 41,
      "x": 2880,
      "y": 49742,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91612,
      "e": 90229,
      "ty": 2,
      "x": 345,
      "y": 602
    },
    {
      "t": 91711,
      "e": 90328,
      "ty": 2,
      "x": 342,
      "y": 596
    },
    {
      "t": 91762,
      "e": 90379,
      "ty": 41,
      "x": 2486,
      "y": 42330,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 91811,
      "e": 90428,
      "ty": 2,
      "x": 380,
      "y": 584
    },
    {
      "t": 91911,
      "e": 90528,
      "ty": 2,
      "x": 472,
      "y": 577
    },
    {
      "t": 92011,
      "e": 90628,
      "ty": 2,
      "x": 505,
      "y": 578
    },
    {
      "t": 92011,
      "e": 90628,
      "ty": 41,
      "x": 10407,
      "y": 37259,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92111,
      "e": 90728,
      "ty": 2,
      "x": 527,
      "y": 580
    },
    {
      "t": 92211,
      "e": 90828,
      "ty": 2,
      "x": 540,
      "y": 581
    },
    {
      "t": 92261,
      "e": 90878,
      "ty": 41,
      "x": 12375,
      "y": 38429,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92311,
      "e": 90928,
      "ty": 2,
      "x": 556,
      "y": 580
    },
    {
      "t": 92411,
      "e": 91028,
      "ty": 2,
      "x": 589,
      "y": 577
    },
    {
      "t": 92511,
      "e": 91128,
      "ty": 2,
      "x": 628,
      "y": 580
    },
    {
      "t": 92511,
      "e": 91128,
      "ty": 41,
      "x": 16458,
      "y": 38039,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92611,
      "e": 91228,
      "ty": 2,
      "x": 672,
      "y": 578
    },
    {
      "t": 92712,
      "e": 91329,
      "ty": 2,
      "x": 703,
      "y": 576
    },
    {
      "t": 92761,
      "e": 91378,
      "ty": 41,
      "x": 21083,
      "y": 35699,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 92811,
      "e": 91428,
      "ty": 2,
      "x": 730,
      "y": 573
    },
    {
      "t": 92912,
      "e": 91529,
      "ty": 2,
      "x": 754,
      "y": 573
    },
    {
      "t": 93011,
      "e": 91628,
      "ty": 2,
      "x": 780,
      "y": 573
    },
    {
      "t": 93012,
      "e": 91629,
      "ty": 41,
      "x": 23936,
      "y": 35309,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 93111,
      "e": 91728,
      "ty": 2,
      "x": 793,
      "y": 573
    },
    {
      "t": 93211,
      "e": 91828,
      "ty": 2,
      "x": 807,
      "y": 574
    },
    {
      "t": 93261,
      "e": 91878,
      "ty": 41,
      "x": 25510,
      "y": 35699,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 93311,
      "e": 91928,
      "ty": 2,
      "x": 813,
      "y": 574
    },
    {
      "t": 93511,
      "e": 92128,
      "ty": 2,
      "x": 778,
      "y": 582
    },
    {
      "t": 93511,
      "e": 92128,
      "ty": 41,
      "x": 23838,
      "y": 38819,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 93611,
      "e": 92228,
      "ty": 2,
      "x": 710,
      "y": 586
    },
    {
      "t": 93711,
      "e": 92328,
      "ty": 2,
      "x": 655,
      "y": 595
    },
    {
      "t": 93761,
      "e": 92378,
      "ty": 41,
      "x": 16753,
      "y": 45061,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 93811,
      "e": 92428,
      "ty": 2,
      "x": 618,
      "y": 600
    },
    {
      "t": 93912,
      "e": 92529,
      "ty": 2,
      "x": 595,
      "y": 602
    },
    {
      "t": 94011,
      "e": 92628,
      "ty": 2,
      "x": 568,
      "y": 608
    },
    {
      "t": 94011,
      "e": 92628,
      "ty": 41,
      "x": 13506,
      "y": 48962,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 94111,
      "e": 92728,
      "ty": 2,
      "x": 525,
      "y": 613
    },
    {
      "t": 94211,
      "e": 92828,
      "ty": 2,
      "x": 479,
      "y": 613
    },
    {
      "t": 94262,
      "e": 92879,
      "ty": 41,
      "x": 8636,
      "y": 50912,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 94311,
      "e": 92928,
      "ty": 2,
      "x": 450,
      "y": 613
    },
    {
      "t": 94411,
      "e": 93028,
      "ty": 2,
      "x": 419,
      "y": 613
    },
    {
      "t": 94511,
      "e": 93128,
      "ty": 2,
      "x": 394,
      "y": 613
    },
    {
      "t": 94511,
      "e": 93128,
      "ty": 41,
      "x": 4946,
      "y": 50912,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 94611,
      "e": 93228,
      "ty": 2,
      "x": 364,
      "y": 614
    },
    {
      "t": 94711,
      "e": 93328,
      "ty": 2,
      "x": 334,
      "y": 619
    },
    {
      "t": 94761,
      "e": 93378,
      "ty": 41,
      "x": 1896,
      "y": 53253,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 94811,
      "e": 93428,
      "ty": 2,
      "x": 332,
      "y": 619
    },
    {
      "t": 94911,
      "e": 93528,
      "ty": 2,
      "x": 333,
      "y": 619
    },
    {
      "t": 95011,
      "e": 93628,
      "ty": 2,
      "x": 363,
      "y": 615
    },
    {
      "t": 95011,
      "e": 93628,
      "ty": 41,
      "x": 3421,
      "y": 51692,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95111,
      "e": 93728,
      "ty": 2,
      "x": 387,
      "y": 613
    },
    {
      "t": 95211,
      "e": 93828,
      "ty": 2,
      "x": 394,
      "y": 613
    },
    {
      "t": 95261,
      "e": 93878,
      "ty": 41,
      "x": 4995,
      "y": 50912,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95311,
      "e": 93928,
      "ty": 2,
      "x": 395,
      "y": 613
    },
    {
      "t": 95511,
      "e": 94128,
      "ty": 2,
      "x": 406,
      "y": 613
    },
    {
      "t": 95511,
      "e": 94128,
      "ty": 41,
      "x": 5536,
      "y": 50912,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95611,
      "e": 94228,
      "ty": 2,
      "x": 421,
      "y": 611
    },
    {
      "t": 95711,
      "e": 94328,
      "ty": 2,
      "x": 448,
      "y": 607
    },
    {
      "t": 95761,
      "e": 94378,
      "ty": 41,
      "x": 8488,
      "y": 47792,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95811,
      "e": 94428,
      "ty": 2,
      "x": 480,
      "y": 603
    },
    {
      "t": 95911,
      "e": 94528,
      "ty": 2,
      "x": 510,
      "y": 600
    },
    {
      "t": 96011,
      "e": 94628,
      "ty": 2,
      "x": 538,
      "y": 603
    },
    {
      "t": 96012,
      "e": 94629,
      "ty": 41,
      "x": 12030,
      "y": 47011,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96112,
      "e": 94729,
      "ty": 2,
      "x": 576,
      "y": 606
    },
    {
      "t": 96211,
      "e": 94828,
      "ty": 2,
      "x": 597,
      "y": 607
    },
    {
      "t": 96262,
      "e": 94879,
      "ty": 41,
      "x": 15622,
      "y": 48572,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96312,
      "e": 94929,
      "ty": 2,
      "x": 623,
      "y": 608
    },
    {
      "t": 96412,
      "e": 95029,
      "ty": 2,
      "x": 634,
      "y": 609
    },
    {
      "t": 96511,
      "e": 95128,
      "ty": 2,
      "x": 663,
      "y": 613
    },
    {
      "t": 96512,
      "e": 95129,
      "ty": 41,
      "x": 18180,
      "y": 50912,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96612,
      "e": 95229,
      "ty": 2,
      "x": 687,
      "y": 613
    },
    {
      "t": 96711,
      "e": 95328,
      "ty": 2,
      "x": 708,
      "y": 615
    },
    {
      "t": 96762,
      "e": 95379,
      "ty": 41,
      "x": 20443,
      "y": 51692,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 96811,
      "e": 95428,
      "ty": 2,
      "x": 712,
      "y": 615
    },
    {
      "t": 96911,
      "e": 95528,
      "ty": 2,
      "x": 723,
      "y": 615
    },
    {
      "t": 97011,
      "e": 95628,
      "ty": 2,
      "x": 739,
      "y": 615
    },
    {
      "t": 97012,
      "e": 95629,
      "ty": 41,
      "x": 21919,
      "y": 51692,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97311,
      "e": 95928,
      "ty": 2,
      "x": 748,
      "y": 614
    },
    {
      "t": 97411,
      "e": 96028,
      "ty": 2,
      "x": 758,
      "y": 612
    },
    {
      "t": 97512,
      "e": 96129,
      "ty": 41,
      "x": 22854,
      "y": 50522,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97612,
      "e": 96229,
      "ty": 2,
      "x": 692,
      "y": 616
    },
    {
      "t": 97711,
      "e": 96328,
      "ty": 2,
      "x": 605,
      "y": 624
    },
    {
      "t": 97761,
      "e": 96378,
      "ty": 41,
      "x": 14048,
      "y": 57544,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 97811,
      "e": 96428,
      "ty": 2,
      "x": 546,
      "y": 631
    },
    {
      "t": 97911,
      "e": 96528,
      "ty": 2,
      "x": 489,
      "y": 635
    },
    {
      "t": 98011,
      "e": 96628,
      "ty": 2,
      "x": 454,
      "y": 635
    },
    {
      "t": 98011,
      "e": 96628,
      "ty": 41,
      "x": 7898,
      "y": 59494,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98112,
      "e": 96729,
      "ty": 2,
      "x": 406,
      "y": 637
    },
    {
      "t": 98212,
      "e": 96829,
      "ty": 2,
      "x": 404,
      "y": 639
    },
    {
      "t": 98262,
      "e": 96879,
      "ty": 41,
      "x": 5438,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98412,
      "e": 97029,
      "ty": 2,
      "x": 411,
      "y": 639
    },
    {
      "t": 98511,
      "e": 97128,
      "ty": 2,
      "x": 467,
      "y": 639
    },
    {
      "t": 98511,
      "e": 97128,
      "ty": 41,
      "x": 8537,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98611,
      "e": 97228,
      "ty": 2,
      "x": 480,
      "y": 637
    },
    {
      "t": 98711,
      "e": 97328,
      "ty": 2,
      "x": 501,
      "y": 632
    },
    {
      "t": 98761,
      "e": 97378,
      "ty": 41,
      "x": 11243,
      "y": 57154,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98812,
      "e": 97429,
      "ty": 2,
      "x": 536,
      "y": 627
    },
    {
      "t": 98912,
      "e": 97529,
      "ty": 2,
      "x": 565,
      "y": 624
    },
    {
      "t": 99011,
      "e": 97628,
      "ty": 2,
      "x": 575,
      "y": 624
    },
    {
      "t": 99012,
      "e": 97629,
      "ty": 41,
      "x": 13851,
      "y": 55203,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99112,
      "e": 97729,
      "ty": 2,
      "x": 592,
      "y": 625
    },
    {
      "t": 99211,
      "e": 97828,
      "ty": 2,
      "x": 610,
      "y": 628
    },
    {
      "t": 99262,
      "e": 97879,
      "ty": 41,
      "x": 15819,
      "y": 56764,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99311,
      "e": 97928,
      "ty": 2,
      "x": 617,
      "y": 629
    },
    {
      "t": 99411,
      "e": 98028,
      "ty": 2,
      "x": 624,
      "y": 631
    },
    {
      "t": 99512,
      "e": 98129,
      "ty": 2,
      "x": 632,
      "y": 631
    },
    {
      "t": 99512,
      "e": 98129,
      "ty": 41,
      "x": 16655,
      "y": 57934,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99612,
      "e": 98229,
      "ty": 2,
      "x": 638,
      "y": 629
    },
    {
      "t": 99712,
      "e": 98329,
      "ty": 2,
      "x": 641,
      "y": 628
    },
    {
      "t": 99761,
      "e": 98378,
      "ty": 41,
      "x": 17245,
      "y": 55983,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99811,
      "e": 98428,
      "ty": 2,
      "x": 648,
      "y": 624
    },
    {
      "t": 99912,
      "e": 98529,
      "ty": 2,
      "x": 658,
      "y": 623
    },
    {
      "t": 100012,
      "e": 98629,
      "ty": 2,
      "x": 666,
      "y": 622
    },
    {
      "t": 100012,
      "e": 98629,
      "ty": 41,
      "x": 18328,
      "y": 54423,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100012,
      "e": 98629,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100111,
      "e": 98728,
      "ty": 2,
      "x": 670,
      "y": 621
    },
    {
      "t": 100211,
      "e": 98828,
      "ty": 2,
      "x": 674,
      "y": 620
    },
    {
      "t": 100261,
      "e": 98878,
      "ty": 41,
      "x": 18869,
      "y": 53643,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100311,
      "e": 98928,
      "ty": 2,
      "x": 679,
      "y": 620
    },
    {
      "t": 100412,
      "e": 99029,
      "ty": 2,
      "x": 702,
      "y": 620
    },
    {
      "t": 100511,
      "e": 99128,
      "ty": 2,
      "x": 707,
      "y": 621
    },
    {
      "t": 100511,
      "e": 99128,
      "ty": 41,
      "x": 20345,
      "y": 54033,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101112,
      "e": 99729,
      "ty": 2,
      "x": 690,
      "y": 623
    },
    {
      "t": 101211,
      "e": 99828,
      "ty": 2,
      "x": 639,
      "y": 630
    },
    {
      "t": 101261,
      "e": 99878,
      "ty": 41,
      "x": 15720,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101312,
      "e": 99929,
      "ty": 2,
      "x": 581,
      "y": 647
    },
    {
      "t": 101411,
      "e": 100028,
      "ty": 2,
      "x": 542,
      "y": 661
    },
    {
      "t": 101511,
      "e": 100128,
      "ty": 2,
      "x": 507,
      "y": 664
    },
    {
      "t": 101511,
      "e": 100128,
      "ty": 41,
      "x": 10505,
      "y": 38153,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 101611,
      "e": 100228,
      "ty": 2,
      "x": 473,
      "y": 656
    },
    {
      "t": 101711,
      "e": 100328,
      "ty": 2,
      "x": 452,
      "y": 656
    },
    {
      "t": 101762,
      "e": 100379,
      "ty": 41,
      "x": 7012,
      "y": 38037,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 101812,
      "e": 100429,
      "ty": 2,
      "x": 413,
      "y": 663
    },
    {
      "t": 101912,
      "e": 100529,
      "ty": 2,
      "x": 395,
      "y": 662
    },
    {
      "t": 102012,
      "e": 100629,
      "ty": 2,
      "x": 384,
      "y": 662
    },
    {
      "t": 102014,
      "e": 100631,
      "ty": 41,
      "x": 4454,
      "y": 37921,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 102111,
      "e": 100728,
      "ty": 2,
      "x": 381,
      "y": 663
    },
    {
      "t": 102212,
      "e": 100829,
      "ty": 2,
      "x": 378,
      "y": 664
    },
    {
      "t": 102262,
      "e": 100879,
      "ty": 41,
      "x": 4011,
      "y": 38384,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 102311,
      "e": 100928,
      "ty": 2,
      "x": 372,
      "y": 675
    },
    {
      "t": 102411,
      "e": 101028,
      "ty": 2,
      "x": 372,
      "y": 687
    },
    {
      "t": 102511,
      "e": 101128,
      "ty": 2,
      "x": 379,
      "y": 689
    },
    {
      "t": 102512,
      "e": 101129,
      "ty": 41,
      "x": 24063,
      "y": 54117,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 102611,
      "e": 101228,
      "ty": 2,
      "x": 387,
      "y": 687
    },
    {
      "t": 102712,
      "e": 101329,
      "ty": 2,
      "x": 388,
      "y": 686
    },
    {
      "t": 102762,
      "e": 101379,
      "ty": 41,
      "x": 26594,
      "y": 44287,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 102911,
      "e": 101528,
      "ty": 2,
      "x": 391,
      "y": 685
    },
    {
      "t": 103012,
      "e": 101629,
      "ty": 2,
      "x": 403,
      "y": 679
    },
    {
      "t": 103012,
      "e": 101629,
      "ty": 41,
      "x": 30813,
      "y": 21350,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 103111,
      "e": 101728,
      "ty": 2,
      "x": 410,
      "y": 676
    },
    {
      "t": 103212,
      "e": 101829,
      "ty": 2,
      "x": 429,
      "y": 673
    },
    {
      "t": 103261,
      "e": 101878,
      "ty": 41,
      "x": 6816,
      "y": 1471,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103311,
      "e": 101928,
      "ty": 2,
      "x": 435,
      "y": 670
    },
    {
      "t": 103411,
      "e": 102028,
      "ty": 2,
      "x": 448,
      "y": 670
    },
    {
      "t": 103511,
      "e": 102128,
      "ty": 2,
      "x": 491,
      "y": 676
    },
    {
      "t": 103511,
      "e": 102128,
      "ty": 41,
      "x": 55566,
      "y": 11519,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 103610,
      "e": 102227,
      "ty": 2,
      "x": 509,
      "y": 678
    },
    {
      "t": 103711,
      "e": 102328,
      "ty": 2,
      "x": 531,
      "y": 678
    },
    {
      "t": 103761,
      "e": 102378,
      "ty": 41,
      "x": 12326,
      "y": 5567,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103810,
      "e": 102427,
      "ty": 2,
      "x": 551,
      "y": 678
    },
    {
      "t": 103911,
      "e": 102528,
      "ty": 2,
      "x": 565,
      "y": 678
    },
    {
      "t": 104011,
      "e": 102628,
      "ty": 2,
      "x": 573,
      "y": 678
    },
    {
      "t": 104011,
      "e": 102628,
      "ty": 41,
      "x": 13752,
      "y": 5567,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 104112,
      "e": 102729,
      "ty": 2,
      "x": 585,
      "y": 678
    },
    {
      "t": 104211,
      "e": 102828,
      "ty": 2,
      "x": 592,
      "y": 680
    },
    {
      "t": 104262,
      "e": 102879,
      "ty": 41,
      "x": 14786,
      "y": 6738,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 104311,
      "e": 102928,
      "ty": 2,
      "x": 597,
      "y": 680
    },
    {
      "t": 104411,
      "e": 103028,
      "ty": 2,
      "x": 614,
      "y": 683
    },
    {
      "t": 104512,
      "e": 103129,
      "ty": 2,
      "x": 617,
      "y": 683
    },
    {
      "t": 104512,
      "e": 103129,
      "ty": 41,
      "x": 15917,
      "y": 8493,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 104611,
      "e": 103228,
      "ty": 2,
      "x": 618,
      "y": 684
    },
    {
      "t": 104712,
      "e": 103329,
      "ty": 2,
      "x": 620,
      "y": 684
    },
    {
      "t": 104761,
      "e": 103378,
      "ty": 41,
      "x": 16261,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 104810,
      "e": 103427,
      "ty": 2,
      "x": 624,
      "y": 684
    },
    {
      "t": 105012,
      "e": 103629,
      "ty": 2,
      "x": 626,
      "y": 684
    },
    {
      "t": 105012,
      "e": 103629,
      "ty": 41,
      "x": 16360,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 105110,
      "e": 103727,
      "ty": 2,
      "x": 627,
      "y": 684
    },
    {
      "t": 105260,
      "e": 103877,
      "ty": 41,
      "x": 16409,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 105510,
      "e": 104127,
      "ty": 2,
      "x": 629,
      "y": 683
    },
    {
      "t": 105510,
      "e": 104127,
      "ty": 41,
      "x": 16507,
      "y": 8493,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 107110,
      "e": 105727,
      "ty": 2,
      "x": 627,
      "y": 683
    },
    {
      "t": 107211,
      "e": 105828,
      "ty": 2,
      "x": 627,
      "y": 684
    },
    {
      "t": 107261,
      "e": 105878,
      "ty": 41,
      "x": 16409,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 107510,
      "e": 106127,
      "ty": 2,
      "x": 626,
      "y": 684
    },
    {
      "t": 107510,
      "e": 106127,
      "ty": 41,
      "x": 16360,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108211,
      "e": 106828,
      "ty": 2,
      "x": 625,
      "y": 684
    },
    {
      "t": 108261,
      "e": 106878,
      "ty": 41,
      "x": 15966,
      "y": 9078,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108311,
      "e": 106928,
      "ty": 2,
      "x": 611,
      "y": 684
    },
    {
      "t": 108410,
      "e": 107027,
      "ty": 2,
      "x": 591,
      "y": 690
    },
    {
      "t": 108511,
      "e": 107128,
      "ty": 2,
      "x": 553,
      "y": 703
    },
    {
      "t": 108511,
      "e": 107128,
      "ty": 41,
      "x": 12768,
      "y": 20196,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108611,
      "e": 107228,
      "ty": 2,
      "x": 496,
      "y": 717
    },
    {
      "t": 108711,
      "e": 107328,
      "ty": 2,
      "x": 468,
      "y": 721
    },
    {
      "t": 108761,
      "e": 107378,
      "ty": 41,
      "x": 8488,
      "y": 31313,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108811,
      "e": 107428,
      "ty": 2,
      "x": 465,
      "y": 723
    },
    {
      "t": 108911,
      "e": 107528,
      "ty": 2,
      "x": 469,
      "y": 723
    },
    {
      "t": 109011,
      "e": 107628,
      "ty": 2,
      "x": 497,
      "y": 709
    },
    {
      "t": 109012,
      "e": 107629,
      "ty": 41,
      "x": 10013,
      "y": 23707,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 109111,
      "e": 107728,
      "ty": 2,
      "x": 521,
      "y": 700
    },
    {
      "t": 109210,
      "e": 107827,
      "ty": 2,
      "x": 547,
      "y": 697
    },
    {
      "t": 109261,
      "e": 107878,
      "ty": 41,
      "x": 13949,
      "y": 18440,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 109311,
      "e": 107928,
      "ty": 2,
      "x": 586,
      "y": 702
    },
    {
      "t": 109410,
      "e": 108027,
      "ty": 2,
      "x": 621,
      "y": 703
    },
    {
      "t": 109511,
      "e": 108128,
      "ty": 2,
      "x": 647,
      "y": 707
    },
    {
      "t": 109511,
      "e": 108128,
      "ty": 41,
      "x": 17393,
      "y": 22536,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 109611,
      "e": 108228,
      "ty": 2,
      "x": 669,
      "y": 707
    },
    {
      "t": 109711,
      "e": 108328,
      "ty": 2,
      "x": 691,
      "y": 705
    },
    {
      "t": 109761,
      "e": 108378,
      "ty": 41,
      "x": 19804,
      "y": 21366,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 109811,
      "e": 108428,
      "ty": 2,
      "x": 696,
      "y": 705
    },
    {
      "t": 110010,
      "e": 108627,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110110,
      "e": 108727,
      "ty": 2,
      "x": 701,
      "y": 705
    },
    {
      "t": 110210,
      "e": 108827,
      "ty": 2,
      "x": 703,
      "y": 673
    },
    {
      "t": 110261,
      "e": 108878,
      "ty": 41,
      "x": 20148,
      "y": 2642,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 110610,
      "e": 109227,
      "ty": 2,
      "x": 704,
      "y": 669
    },
    {
      "t": 110761,
      "e": 109378,
      "ty": 41,
      "x": 20197,
      "y": 301,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 110910,
      "e": 109527,
      "ty": 2,
      "x": 704,
      "y": 668
    },
    {
      "t": 111010,
      "e": 109627,
      "ty": 2,
      "x": 703,
      "y": 669
    },
    {
      "t": 111010,
      "e": 109627,
      "ty": 41,
      "x": 20148,
      "y": 301,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111410,
      "e": 110027,
      "ty": 2,
      "x": 700,
      "y": 671
    },
    {
      "t": 111511,
      "e": 110128,
      "ty": 2,
      "x": 699,
      "y": 673
    },
    {
      "t": 111511,
      "e": 110128,
      "ty": 41,
      "x": 19951,
      "y": 2642,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111610,
      "e": 110227,
      "ty": 2,
      "x": 698,
      "y": 675
    },
    {
      "t": 111761,
      "e": 110378,
      "ty": 41,
      "x": 19902,
      "y": 4397,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111811,
      "e": 110428,
      "ty": 2,
      "x": 697,
      "y": 678
    },
    {
      "t": 112011,
      "e": 110628,
      "ty": 2,
      "x": 696,
      "y": 679
    },
    {
      "t": 112011,
      "e": 110628,
      "ty": 41,
      "x": 19804,
      "y": 6153,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112511,
      "e": 111128,
      "ty": 2,
      "x": 693,
      "y": 682
    },
    {
      "t": 112511,
      "e": 111128,
      "ty": 41,
      "x": 19656,
      "y": 7908,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112611,
      "e": 111228,
      "ty": 2,
      "x": 689,
      "y": 689
    },
    {
      "t": 112711,
      "e": 111328,
      "ty": 2,
      "x": 688,
      "y": 691
    },
    {
      "t": 112761,
      "e": 111378,
      "ty": 41,
      "x": 19410,
      "y": 13174,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112911,
      "e": 111528,
      "ty": 2,
      "x": 686,
      "y": 692
    },
    {
      "t": 113011,
      "e": 111628,
      "ty": 41,
      "x": 19312,
      "y": 13759,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 113111,
      "e": 111728,
      "ty": 2,
      "x": 685,
      "y": 694
    },
    {
      "t": 113211,
      "e": 111828,
      "ty": 2,
      "x": 683,
      "y": 697
    },
    {
      "t": 113261,
      "e": 111878,
      "ty": 41,
      "x": 19164,
      "y": 16685,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 113811,
      "e": 112428,
      "ty": 2,
      "x": 682,
      "y": 697
    },
    {
      "t": 113911,
      "e": 112528,
      "ty": 2,
      "x": 674,
      "y": 701
    },
    {
      "t": 114011,
      "e": 112628,
      "ty": 2,
      "x": 663,
      "y": 710
    },
    {
      "t": 114011,
      "e": 112628,
      "ty": 41,
      "x": 18180,
      "y": 24292,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114110,
      "e": 112727,
      "ty": 2,
      "x": 652,
      "y": 717
    },
    {
      "t": 114211,
      "e": 112828,
      "ty": 2,
      "x": 627,
      "y": 725
    },
    {
      "t": 114261,
      "e": 112878,
      "ty": 41,
      "x": 15720,
      "y": 36580,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114311,
      "e": 112928,
      "ty": 2,
      "x": 604,
      "y": 735
    },
    {
      "t": 114411,
      "e": 113028,
      "ty": 2,
      "x": 591,
      "y": 743
    },
    {
      "t": 114511,
      "e": 113128,
      "ty": 2,
      "x": 583,
      "y": 748
    },
    {
      "t": 114511,
      "e": 113128,
      "ty": 41,
      "x": 14244,
      "y": 46527,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114611,
      "e": 113228,
      "ty": 2,
      "x": 577,
      "y": 751
    },
    {
      "t": 114711,
      "e": 113328,
      "ty": 2,
      "x": 572,
      "y": 753
    },
    {
      "t": 114761,
      "e": 113378,
      "ty": 41,
      "x": 13359,
      "y": 50038,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 114810,
      "e": 113427,
      "ty": 2,
      "x": 555,
      "y": 754
    },
    {
      "t": 114911,
      "e": 113528,
      "ty": 2,
      "x": 538,
      "y": 754
    },
    {
      "t": 115011,
      "e": 113628,
      "ty": 2,
      "x": 490,
      "y": 747
    },
    {
      "t": 115011,
      "e": 113628,
      "ty": 41,
      "x": 9669,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115111,
      "e": 113728,
      "ty": 2,
      "x": 449,
      "y": 739
    },
    {
      "t": 115211,
      "e": 113828,
      "ty": 2,
      "x": 441,
      "y": 737
    },
    {
      "t": 115261,
      "e": 113878,
      "ty": 41,
      "x": 7258,
      "y": 40090,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115410,
      "e": 114027,
      "ty": 2,
      "x": 452,
      "y": 734
    },
    {
      "t": 115511,
      "e": 114128,
      "ty": 2,
      "x": 474,
      "y": 734
    },
    {
      "t": 115511,
      "e": 114128,
      "ty": 41,
      "x": 8882,
      "y": 38335,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115611,
      "e": 114228,
      "ty": 2,
      "x": 483,
      "y": 734
    },
    {
      "t": 115721,
      "e": 114338,
      "ty": 2,
      "x": 528,
      "y": 732
    },
    {
      "t": 115771,
      "e": 114388,
      "ty": 41,
      "x": 12375,
      "y": 37165,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 115821,
      "e": 114438,
      "ty": 2,
      "x": 554,
      "y": 731
    },
    {
      "t": 115922,
      "e": 114539,
      "ty": 2,
      "x": 577,
      "y": 730
    },
    {
      "t": 116021,
      "e": 114638,
      "ty": 2,
      "x": 614,
      "y": 729
    },
    {
      "t": 116021,
      "e": 114638,
      "ty": 41,
      "x": 15769,
      "y": 35409,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 116121,
      "e": 114738,
      "ty": 2,
      "x": 637,
      "y": 728
    },
    {
      "t": 116221,
      "e": 114838,
      "ty": 2,
      "x": 684,
      "y": 724
    },
    {
      "t": 116272,
      "e": 114889,
      "ty": 41,
      "x": 20148,
      "y": 32484,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 116321,
      "e": 114938,
      "ty": 2,
      "x": 722,
      "y": 724
    },
    {
      "t": 116421,
      "e": 115038,
      "ty": 2,
      "x": 740,
      "y": 722
    },
    {
      "t": 116521,
      "e": 115138,
      "ty": 2,
      "x": 766,
      "y": 721
    },
    {
      "t": 116521,
      "e": 115138,
      "ty": 41,
      "x": 23247,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 116621,
      "e": 115238,
      "ty": 2,
      "x": 781,
      "y": 721
    },
    {
      "t": 116721,
      "e": 115338,
      "ty": 2,
      "x": 802,
      "y": 721
    },
    {
      "t": 116771,
      "e": 115388,
      "ty": 41,
      "x": 25461,
      "y": 29558,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 116821,
      "e": 115438,
      "ty": 2,
      "x": 818,
      "y": 719
    },
    {
      "t": 116921,
      "e": 115538,
      "ty": 2,
      "x": 829,
      "y": 719
    },
    {
      "t": 117021,
      "e": 115638,
      "ty": 2,
      "x": 842,
      "y": 717
    },
    {
      "t": 117021,
      "e": 115638,
      "ty": 41,
      "x": 26986,
      "y": 28388,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 117122,
      "e": 115739,
      "ty": 2,
      "x": 849,
      "y": 717
    },
    {
      "t": 117224,
      "e": 115841,
      "ty": 2,
      "x": 857,
      "y": 718
    },
    {
      "t": 117272,
      "e": 115889,
      "ty": 41,
      "x": 27921,
      "y": 28973,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 117321,
      "e": 115938,
      "ty": 2,
      "x": 861,
      "y": 718
    },
    {
      "t": 117621,
      "e": 116238,
      "ty": 2,
      "x": 844,
      "y": 727
    },
    {
      "t": 117721,
      "e": 116338,
      "ty": 2,
      "x": 755,
      "y": 746
    },
    {
      "t": 117771,
      "e": 116388,
      "ty": 41,
      "x": 20935,
      "y": 47697,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 117821,
      "e": 116438,
      "ty": 2,
      "x": 696,
      "y": 752
    },
    {
      "t": 117921,
      "e": 116538,
      "ty": 2,
      "x": 637,
      "y": 769
    },
    {
      "t": 118021,
      "e": 116638,
      "ty": 2,
      "x": 586,
      "y": 774
    },
    {
      "t": 118021,
      "e": 116638,
      "ty": 41,
      "x": 14392,
      "y": 61740,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 118121,
      "e": 116738,
      "ty": 2,
      "x": 554,
      "y": 771
    },
    {
      "t": 118221,
      "e": 116838,
      "ty": 2,
      "x": 529,
      "y": 785
    },
    {
      "t": 118271,
      "e": 116888,
      "ty": 41,
      "x": 10063,
      "y": 603,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 118321,
      "e": 116938,
      "ty": 2,
      "x": 476,
      "y": 807
    },
    {
      "t": 118421,
      "e": 117038,
      "ty": 2,
      "x": 454,
      "y": 809
    },
    {
      "t": 118521,
      "e": 117138,
      "ty": 2,
      "x": 420,
      "y": 812
    },
    {
      "t": 118521,
      "e": 117138,
      "ty": 41,
      "x": 6225,
      "y": 15816,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 118621,
      "e": 117238,
      "ty": 2,
      "x": 407,
      "y": 812
    },
    {
      "t": 118772,
      "e": 117389,
      "ty": 41,
      "x": 5586,
      "y": 15816,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 118921,
      "e": 117538,
      "ty": 2,
      "x": 409,
      "y": 814
    },
    {
      "t": 119022,
      "e": 117639,
      "ty": 2,
      "x": 447,
      "y": 814
    },
    {
      "t": 119022,
      "e": 117639,
      "ty": 41,
      "x": 7554,
      "y": 18157,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 119121,
      "e": 117738,
      "ty": 2,
      "x": 501,
      "y": 812
    },
    {
      "t": 119221,
      "e": 117838,
      "ty": 2,
      "x": 555,
      "y": 805
    },
    {
      "t": 119272,
      "e": 117889,
      "ty": 41,
      "x": 14392,
      "y": 5284,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 119321,
      "e": 117938,
      "ty": 2,
      "x": 610,
      "y": 801
    },
    {
      "t": 119421,
      "e": 118038,
      "ty": 2,
      "x": 663,
      "y": 797
    },
    {
      "t": 119522,
      "e": 118139,
      "ty": 2,
      "x": 726,
      "y": 801
    },
    {
      "t": 119522,
      "e": 118139,
      "ty": 41,
      "x": 21280,
      "y": 2943,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 119621,
      "e": 118238,
      "ty": 2,
      "x": 758,
      "y": 800
    },
    {
      "t": 119721,
      "e": 118338,
      "ty": 2,
      "x": 780,
      "y": 800
    },
    {
      "t": 119772,
      "e": 118389,
      "ty": 41,
      "x": 24674,
      "y": 1773,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 119822,
      "e": 118439,
      "ty": 2,
      "x": 806,
      "y": 800
    },
    {
      "t": 119921,
      "e": 118538,
      "ty": 2,
      "x": 827,
      "y": 800
    },
    {
      "t": 120021,
      "e": 118638,
      "ty": 2,
      "x": 847,
      "y": 802
    },
    {
      "t": 120022,
      "e": 118639,
      "ty": 41,
      "x": 27232,
      "y": 4114,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120023,
      "e": 118640,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120121,
      "e": 118738,
      "ty": 2,
      "x": 857,
      "y": 802
    },
    {
      "t": 120221,
      "e": 118838,
      "ty": 2,
      "x": 881,
      "y": 805
    },
    {
      "t": 120271,
      "e": 118888,
      "ty": 41,
      "x": 29249,
      "y": 7625,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120321,
      "e": 118938,
      "ty": 2,
      "x": 894,
      "y": 805
    },
    {
      "t": 120422,
      "e": 119039,
      "ty": 2,
      "x": 901,
      "y": 806
    },
    {
      "t": 120522,
      "e": 119139,
      "ty": 2,
      "x": 910,
      "y": 808
    },
    {
      "t": 120522,
      "e": 119139,
      "ty": 41,
      "x": 30332,
      "y": 11135,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120621,
      "e": 119238,
      "ty": 2,
      "x": 920,
      "y": 809
    },
    {
      "t": 120722,
      "e": 119339,
      "ty": 2,
      "x": 930,
      "y": 809
    },
    {
      "t": 120772,
      "e": 119389,
      "ty": 41,
      "x": 31611,
      "y": 12306,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120821,
      "e": 119438,
      "ty": 2,
      "x": 945,
      "y": 809
    },
    {
      "t": 120921,
      "e": 119538,
      "ty": 2,
      "x": 969,
      "y": 809
    },
    {
      "t": 121021,
      "e": 119638,
      "ty": 41,
      "x": 33234,
      "y": 12306,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 121121,
      "e": 119738,
      "ty": 2,
      "x": 971,
      "y": 809
    },
    {
      "t": 121221,
      "e": 119838,
      "ty": 2,
      "x": 971,
      "y": 808
    },
    {
      "t": 121272,
      "e": 119889,
      "ty": 41,
      "x": 33382,
      "y": 11135,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 121321,
      "e": 119938,
      "ty": 2,
      "x": 972,
      "y": 808
    },
    {
      "t": 121721,
      "e": 120338,
      "ty": 2,
      "x": 936,
      "y": 811
    },
    {
      "t": 121771,
      "e": 120388,
      "ty": 41,
      "x": 28610,
      "y": 12306,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 121821,
      "e": 120438,
      "ty": 2,
      "x": 798,
      "y": 799
    },
    {
      "t": 121921,
      "e": 120538,
      "ty": 2,
      "x": 693,
      "y": 794
    },
    {
      "t": 122021,
      "e": 120638,
      "ty": 2,
      "x": 603,
      "y": 794
    },
    {
      "t": 122022,
      "e": 120639,
      "ty": 41,
      "x": 15228,
      "y": 53205,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 122121,
      "e": 120738,
      "ty": 2,
      "x": 583,
      "y": 802
    },
    {
      "t": 122221,
      "e": 120838,
      "ty": 2,
      "x": 578,
      "y": 810
    },
    {
      "t": 122271,
      "e": 120888,
      "ty": 41,
      "x": 13998,
      "y": 18157,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 122321,
      "e": 120938,
      "ty": 2,
      "x": 578,
      "y": 817
    },
    {
      "t": 122421,
      "e": 121038,
      "ty": 2,
      "x": 600,
      "y": 836
    },
    {
      "t": 122521,
      "e": 121138,
      "ty": 2,
      "x": 627,
      "y": 848
    },
    {
      "t": 122521,
      "e": 121138,
      "ty": 41,
      "x": 16409,
      "y": 57946,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 122622,
      "e": 121239,
      "ty": 2,
      "x": 721,
      "y": 886
    },
    {
      "t": 122721,
      "e": 121338,
      "ty": 2,
      "x": 804,
      "y": 932
    },
    {
      "t": 122771,
      "e": 121388,
      "ty": 41,
      "x": 27429,
      "y": 58077,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122821,
      "e": 121438,
      "ty": 2,
      "x": 892,
      "y": 988
    },
    {
      "t": 122921,
      "e": 121538,
      "ty": 2,
      "x": 959,
      "y": 1032
    },
    {
      "t": 123021,
      "e": 121638,
      "ty": 2,
      "x": 976,
      "y": 1047
    },
    {
      "t": 123021,
      "e": 121638,
      "ty": 41,
      "x": 33579,
      "y": 63756,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 123121,
      "e": 121738,
      "ty": 2,
      "x": 982,
      "y": 1058
    },
    {
      "t": 123187,
      "e": 121804,
      "ty": 6,
      "x": 984,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 123222,
      "e": 121839,
      "ty": 2,
      "x": 984,
      "y": 1081
    },
    {
      "t": 123271,
      "e": 121888,
      "ty": 41,
      "x": 40686,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 123321,
      "e": 121938,
      "ty": 2,
      "x": 983,
      "y": 1090
    },
    {
      "t": 123422,
      "e": 122039,
      "ty": 2,
      "x": 983,
      "y": 1092
    },
    {
      "t": 123521,
      "e": 122138,
      "ty": 41,
      "x": 40140,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 123622,
      "e": 122239,
      "ty": 2,
      "x": 982,
      "y": 1094
    },
    {
      "t": 123771,
      "e": 122388,
      "ty": 41,
      "x": 39594,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 123821,
      "e": 122438,
      "ty": 2,
      "x": 980,
      "y": 1096
    },
    {
      "t": 123921,
      "e": 122538,
      "ty": 2,
      "x": 980,
      "y": 1097
    },
    {
      "t": 124021,
      "e": 122638,
      "ty": 41,
      "x": 38501,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 124421,
      "e": 123038,
      "ty": 2,
      "x": 979,
      "y": 1094
    },
    {
      "t": 124521,
      "e": 123138,
      "ty": 2,
      "x": 977,
      "y": 1091
    },
    {
      "t": 124521,
      "e": 123138,
      "ty": 41,
      "x": 36863,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 124684,
      "e": 123301,
      "ty": 3,
      "x": 977,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 124685,
      "e": 123302,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124834,
      "e": 123451,
      "ty": 4,
      "x": 36863,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 124834,
      "e": 123451,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 124835,
      "e": 123452,
      "ty": 5,
      "x": 977,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 124835,
      "e": 123452,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 125222,
      "e": 123839,
      "ty": 2,
      "x": 977,
      "y": 1090
    },
    {
      "t": 125271,
      "e": 123888,
      "ty": 41,
      "x": 33335,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 125322,
      "e": 123939,
      "ty": 2,
      "x": 974,
      "y": 1088
    },
    {
      "t": 125422,
      "e": 124039,
      "ty": 2,
      "x": 963,
      "y": 1082
    },
    {
      "t": 125521,
      "e": 124138,
      "ty": 2,
      "x": 929,
      "y": 1066
    },
    {
      "t": 125522,
      "e": 124139,
      "ty": 41,
      "x": 31717,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 125622,
      "e": 124239,
      "ty": 2,
      "x": 804,
      "y": 1007
    },
    {
      "t": 125721,
      "e": 124338,
      "ty": 2,
      "x": 686,
      "y": 951
    },
    {
      "t": 125771,
      "e": 124388,
      "ty": 41,
      "x": 21592,
      "y": 50799,
      "ta": "html > body"
    },
    {
      "t": 125822,
      "e": 124439,
      "ty": 2,
      "x": 589,
      "y": 893
    },
    {
      "t": 125866,
      "e": 124483,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 126643,
      "e": 125260,
      "ty": 2,
      "x": 457,
      "y": 614
    },
    {
      "t": 126643,
      "e": 125260,
      "ty": 41,
      "x": 3578,
      "y": 32770,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 126921,
      "e": 125538,
      "ty": 2,
      "x": 738,
      "y": 624
    },
    {
      "t": 127021,
      "e": 125638,
      "ty": 2,
      "x": 1171,
      "y": 632
    },
    {
      "t": 127021,
      "e": 125638,
      "ty": 41,
      "x": 45053,
      "y": 32775,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 127121,
      "e": 125738,
      "ty": 2,
      "x": 1243,
      "y": 625
    },
    {
      "t": 127221,
      "e": 125838,
      "ty": 2,
      "x": 1251,
      "y": 623
    },
    {
      "t": 127271,
      "e": 125888,
      "ty": 41,
      "x": 49991,
      "y": 32772,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 127321,
      "e": 125938,
      "ty": 2,
      "x": 1256,
      "y": 622
    },
    {
      "t": 127509,
      "e": 126126,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 3387, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 3390, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 6589, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 11098, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8363, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"bravo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 20465, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 14729, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 36281, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 15690, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 52973, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 17150, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 71349, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:989,y:1034,t:1526922625445};\\\", \\\"{x:987,y:1034,t:1526922625453};\\\", \\\"{x:982,y:1032,t:1526922625470};\\\", \\\"{x:979,y:1030,t:1526922625488};\\\", \\\"{x:975,y:1028,t:1526922625503};\\\", \\\"{x:971,y:1026,t:1526922625520};\\\", \\\"{x:966,y:1024,t:1526922625538};\\\", \\\"{x:959,y:1023,t:1526922625553};\\\", \\\"{x:949,y:1019,t:1526922625570};\\\", \\\"{x:938,y:1016,t:1526922625588};\\\", \\\"{x:926,y:1010,t:1526922625604};\\\", \\\"{x:916,y:1004,t:1526922625620};\\\", \\\"{x:899,y:997,t:1526922625637};\\\", \\\"{x:882,y:989,t:1526922625654};\\\", \\\"{x:866,y:982,t:1526922625670};\\\", \\\"{x:856,y:978,t:1526922625688};\\\", \\\"{x:843,y:970,t:1526922625704};\\\", \\\"{x:838,y:966,t:1526922625720};\\\", \\\"{x:827,y:959,t:1526922625738};\\\", \\\"{x:812,y:954,t:1526922625753};\\\", \\\"{x:802,y:950,t:1526922625771};\\\", \\\"{x:796,y:948,t:1526922625787};\\\", \\\"{x:786,y:943,t:1526922625804};\\\", \\\"{x:774,y:939,t:1526922625821};\\\", \\\"{x:759,y:934,t:1526922625837};\\\", \\\"{x:752,y:931,t:1526922625855};\\\", \\\"{x:749,y:930,t:1526922625870};\\\", \\\"{x:746,y:929,t:1526922625887};\\\", \\\"{x:745,y:929,t:1526922625905};\\\", \\\"{x:743,y:928,t:1526922625921};\\\", \\\"{x:741,y:928,t:1526922625937};\\\", \\\"{x:740,y:927,t:1526922625955};\\\", \\\"{x:736,y:927,t:1526922625970};\\\", \\\"{x:733,y:927,t:1526922625987};\\\", \\\"{x:730,y:925,t:1526922626004};\\\", \\\"{x:729,y:925,t:1526922626021};\\\", \\\"{x:728,y:925,t:1526922626037};\\\", \\\"{x:726,y:924,t:1526922626054};\\\", \\\"{x:725,y:924,t:1526922626101};\\\", \\\"{x:724,y:924,t:1526922626141};\\\", \\\"{x:723,y:924,t:1526922626164};\\\", \\\"{x:722,y:924,t:1526922626229};\\\", \\\"{x:721,y:924,t:1526922626237};\\\", \\\"{x:720,y:923,t:1526922626318};\\\", \\\"{x:718,y:923,t:1526922626462};\\\", \\\"{x:717,y:923,t:1526922626471};\\\", \\\"{x:716,y:923,t:1526922628518};\\\", \\\"{x:716,y:922,t:1526922628550};\\\", \\\"{x:718,y:922,t:1526922628558};\\\", \\\"{x:723,y:924,t:1526922628573};\\\", \\\"{x:746,y:931,t:1526922628590};\\\", \\\"{x:763,y:934,t:1526922628606};\\\", \\\"{x:783,y:942,t:1526922628622};\\\", \\\"{x:803,y:948,t:1526922628640};\\\", \\\"{x:820,y:955,t:1526922628656};\\\", \\\"{x:839,y:960,t:1526922628673};\\\", \\\"{x:850,y:963,t:1526922628690};\\\", \\\"{x:859,y:966,t:1526922628707};\\\", \\\"{x:872,y:970,t:1526922628723};\\\", \\\"{x:892,y:977,t:1526922628740};\\\", \\\"{x:914,y:981,t:1526922628757};\\\", \\\"{x:938,y:988,t:1526922628773};\\\", \\\"{x:972,y:998,t:1526922628790};\\\", \\\"{x:997,y:1004,t:1526922628807};\\\", \\\"{x:1023,y:1011,t:1526922628823};\\\", \\\"{x:1061,y:1017,t:1526922628839};\\\", \\\"{x:1088,y:1022,t:1526922628857};\\\", \\\"{x:1110,y:1025,t:1526922628872};\\\", \\\"{x:1127,y:1025,t:1526922628889};\\\", \\\"{x:1148,y:1025,t:1526922628906};\\\", \\\"{x:1162,y:1025,t:1526922628923};\\\", \\\"{x:1173,y:1025,t:1526922628939};\\\", \\\"{x:1188,y:1019,t:1526922628956};\\\", \\\"{x:1191,y:1017,t:1526922628972};\\\", \\\"{x:1199,y:1015,t:1526922628989};\\\", \\\"{x:1205,y:1013,t:1526922629006};\\\", \\\"{x:1213,y:1010,t:1526922629022};\\\", \\\"{x:1218,y:1009,t:1526922629040};\\\", \\\"{x:1222,y:1007,t:1526922629057};\\\", \\\"{x:1224,y:1006,t:1526922629073};\\\", \\\"{x:1225,y:1004,t:1526922629090};\\\", \\\"{x:1226,y:1004,t:1526922629107};\\\", \\\"{x:1229,y:1004,t:1526922629123};\\\", \\\"{x:1235,y:1000,t:1526922629139};\\\", \\\"{x:1241,y:998,t:1526922629156};\\\", \\\"{x:1250,y:993,t:1526922629173};\\\", \\\"{x:1253,y:992,t:1526922629190};\\\", \\\"{x:1259,y:989,t:1526922629206};\\\", \\\"{x:1260,y:989,t:1526922629223};\\\", \\\"{x:1261,y:989,t:1526922629429};\\\", \\\"{x:1262,y:989,t:1526922629439};\\\", \\\"{x:1263,y:988,t:1526922629460};\\\", \\\"{x:1264,y:988,t:1526922629476};\\\", \\\"{x:1266,y:988,t:1526922629493};\\\", \\\"{x:1267,y:987,t:1526922629509};\\\", \\\"{x:1268,y:987,t:1526922629541};\\\", \\\"{x:1269,y:987,t:1526922629556};\\\", \\\"{x:1270,y:987,t:1526922629573};\\\", \\\"{x:1270,y:986,t:1526922629612};\\\", \\\"{x:1271,y:986,t:1526922629693};\\\", \\\"{x:1272,y:986,t:1526922629706};\\\", \\\"{x:1275,y:986,t:1526922629723};\\\", \\\"{x:1277,y:986,t:1526922629748};\\\", \\\"{x:1278,y:986,t:1526922629757};\\\", \\\"{x:1280,y:986,t:1526922629789};\\\", \\\"{x:1281,y:986,t:1526922630037};\\\", \\\"{x:1281,y:985,t:1526922630053};\\\", \\\"{x:1281,y:984,t:1526922630069};\\\", \\\"{x:1281,y:983,t:1526922630077};\\\", \\\"{x:1281,y:982,t:1526922630101};\\\", \\\"{x:1283,y:981,t:1526922630125};\\\", \\\"{x:1283,y:980,t:1526922630141};\\\", \\\"{x:1283,y:979,t:1526922630173};\\\", \\\"{x:1283,y:978,t:1526922630191};\\\", \\\"{x:1284,y:977,t:1526922630207};\\\", \\\"{x:1284,y:976,t:1526922630224};\\\", \\\"{x:1284,y:974,t:1526922630241};\\\", \\\"{x:1284,y:973,t:1526922630258};\\\", \\\"{x:1284,y:970,t:1526922630274};\\\", \\\"{x:1284,y:968,t:1526922630292};\\\", \\\"{x:1284,y:967,t:1526922630325};\\\", \\\"{x:1283,y:967,t:1526922631333};\\\", \\\"{x:1282,y:967,t:1526922631389};\\\", \\\"{x:1281,y:967,t:1526922631421};\\\", \\\"{x:1280,y:967,t:1526922631461};\\\", \\\"{x:1279,y:967,t:1526922632142};\\\", \\\"{x:1277,y:963,t:1526922632158};\\\", \\\"{x:1273,y:956,t:1526922632175};\\\", \\\"{x:1271,y:951,t:1526922632191};\\\", \\\"{x:1268,y:942,t:1526922632208};\\\", \\\"{x:1262,y:934,t:1526922632226};\\\", \\\"{x:1257,y:929,t:1526922632242};\\\", \\\"{x:1248,y:920,t:1526922632258};\\\", \\\"{x:1237,y:915,t:1526922632275};\\\", \\\"{x:1212,y:902,t:1526922632291};\\\", \\\"{x:1183,y:892,t:1526922632309};\\\", \\\"{x:1109,y:867,t:1526922632325};\\\", \\\"{x:1037,y:847,t:1526922632341};\\\", \\\"{x:974,y:832,t:1526922632359};\\\", \\\"{x:916,y:817,t:1526922632376};\\\", \\\"{x:856,y:795,t:1526922632391};\\\", \\\"{x:805,y:777,t:1526922632409};\\\", \\\"{x:774,y:766,t:1526922632425};\\\", \\\"{x:747,y:751,t:1526922632441};\\\", \\\"{x:723,y:740,t:1526922632459};\\\", \\\"{x:697,y:727,t:1526922632476};\\\", \\\"{x:671,y:715,t:1526922632492};\\\", \\\"{x:659,y:708,t:1526922632508};\\\", \\\"{x:635,y:700,t:1526922632525};\\\", \\\"{x:620,y:694,t:1526922632542};\\\", \\\"{x:614,y:694,t:1526922632558};\\\", \\\"{x:601,y:692,t:1526922632575};\\\", \\\"{x:593,y:690,t:1526922632592};\\\", \\\"{x:586,y:688,t:1526922632608};\\\", \\\"{x:584,y:687,t:1526922632625};\\\", \\\"{x:582,y:687,t:1526922632653};\\\", \\\"{x:582,y:685,t:1526922632685};\\\", \\\"{x:582,y:684,t:1526922632693};\\\", \\\"{x:582,y:681,t:1526922632708};\\\", \\\"{x:585,y:676,t:1526922632725};\\\", \\\"{x:592,y:672,t:1526922632743};\\\", \\\"{x:603,y:666,t:1526922632758};\\\", \\\"{x:622,y:658,t:1526922632775};\\\", \\\"{x:642,y:652,t:1526922632793};\\\", \\\"{x:671,y:647,t:1526922632809};\\\", \\\"{x:690,y:641,t:1526922632826};\\\", \\\"{x:718,y:635,t:1526922632843};\\\", \\\"{x:745,y:628,t:1526922632858};\\\", \\\"{x:768,y:623,t:1526922632876};\\\", \\\"{x:786,y:620,t:1526922632893};\\\", \\\"{x:798,y:615,t:1526922632910};\\\", \\\"{x:799,y:614,t:1526922632926};\\\", \\\"{x:802,y:611,t:1526922632944};\\\", \\\"{x:804,y:609,t:1526922632959};\\\", \\\"{x:805,y:608,t:1526922632976};\\\", \\\"{x:805,y:604,t:1526922632994};\\\", \\\"{x:807,y:600,t:1526922633009};\\\", \\\"{x:807,y:595,t:1526922633026};\\\", \\\"{x:809,y:590,t:1526922633044};\\\", \\\"{x:809,y:586,t:1526922633060};\\\", \\\"{x:809,y:582,t:1526922633076};\\\", \\\"{x:810,y:577,t:1526922633093};\\\", \\\"{x:811,y:571,t:1526922633111};\\\", \\\"{x:812,y:566,t:1526922633126};\\\", \\\"{x:813,y:562,t:1526922633143};\\\", \\\"{x:816,y:557,t:1526922633161};\\\", \\\"{x:818,y:552,t:1526922633177};\\\", \\\"{x:823,y:547,t:1526922633194};\\\", \\\"{x:825,y:546,t:1526922633211};\\\", \\\"{x:828,y:544,t:1526922633229};\\\", \\\"{x:829,y:544,t:1526922633661};\\\", \\\"{x:832,y:544,t:1526922633677};\\\", \\\"{x:833,y:542,t:1526922633694};\\\", \\\"{x:835,y:541,t:1526922633711};\\\", \\\"{x:836,y:540,t:1526922633733};\\\", \\\"{x:836,y:537,t:1526922633958};\\\", \\\"{x:837,y:537,t:1526922633966};\\\", \\\"{x:837,y:536,t:1526922634005};\\\", \\\"{x:837,y:535,t:1526922634028};\\\", \\\"{x:837,y:534,t:1526922634044};\\\", \\\"{x:837,y:533,t:1526922634060};\\\", \\\"{x:837,y:532,t:1526922634076};\\\", \\\"{x:837,y:531,t:1526922634094};\\\", \\\"{x:836,y:530,t:1526922634110};\\\", \\\"{x:835,y:528,t:1526922634127};\\\", \\\"{x:835,y:527,t:1526922634149};\\\", \\\"{x:835,y:526,t:1526922634160};\\\", \\\"{x:835,y:525,t:1526922634180};\\\", \\\"{x:835,y:524,t:1526922634205};\\\", \\\"{x:835,y:523,t:1526922634228};\\\", \\\"{x:836,y:523,t:1526922634982};\\\", \\\"{x:841,y:530,t:1526922634995};\\\", \\\"{x:854,y:546,t:1526922635013};\\\", \\\"{x:868,y:563,t:1526922635028};\\\", \\\"{x:881,y:581,t:1526922635045};\\\", \\\"{x:917,y:612,t:1526922635062};\\\", \\\"{x:938,y:638,t:1526922635080};\\\", \\\"{x:965,y:671,t:1526922635095};\\\", \\\"{x:980,y:692,t:1526922635112};\\\", \\\"{x:997,y:714,t:1526922635127};\\\", \\\"{x:1011,y:732,t:1526922635145};\\\", \\\"{x:1027,y:748,t:1526922635163};\\\", \\\"{x:1045,y:762,t:1526922635177};\\\", \\\"{x:1068,y:779,t:1526922635195};\\\", \\\"{x:1090,y:794,t:1526922635212};\\\", \\\"{x:1110,y:806,t:1526922635228};\\\", \\\"{x:1126,y:816,t:1526922635244};\\\", \\\"{x:1142,y:828,t:1526922635261};\\\", \\\"{x:1152,y:836,t:1526922635278};\\\", \\\"{x:1162,y:841,t:1526922635295};\\\", \\\"{x:1173,y:848,t:1526922635311};\\\", \\\"{x:1178,y:853,t:1526922635328};\\\", \\\"{x:1188,y:858,t:1526922635345};\\\", \\\"{x:1199,y:864,t:1526922635362};\\\", \\\"{x:1204,y:869,t:1526922635378};\\\", \\\"{x:1211,y:871,t:1526922635394};\\\", \\\"{x:1216,y:872,t:1526922635412};\\\", \\\"{x:1226,y:878,t:1526922635428};\\\", \\\"{x:1234,y:885,t:1526922635445};\\\", \\\"{x:1244,y:891,t:1526922635462};\\\", \\\"{x:1249,y:894,t:1526922635478};\\\", \\\"{x:1254,y:897,t:1526922635495};\\\", \\\"{x:1258,y:899,t:1526922635512};\\\", \\\"{x:1261,y:902,t:1526922635528};\\\", \\\"{x:1263,y:903,t:1526922635545};\\\", \\\"{x:1264,y:903,t:1526922635565};\\\", \\\"{x:1264,y:904,t:1526922635578};\\\", \\\"{x:1264,y:905,t:1526922635597};\\\", \\\"{x:1264,y:906,t:1526922635611};\\\", \\\"{x:1267,y:908,t:1526922635628};\\\", \\\"{x:1267,y:911,t:1526922635645};\\\", \\\"{x:1269,y:914,t:1526922635660};\\\", \\\"{x:1271,y:916,t:1526922635678};\\\", \\\"{x:1273,y:918,t:1526922635695};\\\", \\\"{x:1273,y:920,t:1526922635724};\\\", \\\"{x:1274,y:921,t:1526922635733};\\\", \\\"{x:1275,y:923,t:1526922635757};\\\", \\\"{x:1276,y:923,t:1526922635773};\\\", \\\"{x:1276,y:925,t:1526922635780};\\\", \\\"{x:1277,y:925,t:1526922635795};\\\", \\\"{x:1278,y:927,t:1526922635810};\\\", \\\"{x:1278,y:930,t:1526922635828};\\\", \\\"{x:1278,y:931,t:1526922635844};\\\", \\\"{x:1280,y:935,t:1526922635861};\\\", \\\"{x:1280,y:937,t:1526922635877};\\\", \\\"{x:1280,y:938,t:1526922635895};\\\", \\\"{x:1280,y:940,t:1526922635910};\\\", \\\"{x:1280,y:941,t:1526922635928};\\\", \\\"{x:1280,y:943,t:1526922635945};\\\", \\\"{x:1280,y:944,t:1526922635960};\\\", \\\"{x:1280,y:946,t:1526922635977};\\\", \\\"{x:1280,y:947,t:1526922635994};\\\", \\\"{x:1279,y:949,t:1526922636011};\\\", \\\"{x:1279,y:948,t:1526922636205};\\\", \\\"{x:1280,y:945,t:1526922636212};\\\", \\\"{x:1281,y:943,t:1526922636227};\\\", \\\"{x:1282,y:937,t:1526922636244};\\\", \\\"{x:1284,y:926,t:1526922636261};\\\", \\\"{x:1284,y:920,t:1526922636277};\\\", \\\"{x:1281,y:907,t:1526922636294};\\\", \\\"{x:1278,y:892,t:1526922636311};\\\", \\\"{x:1275,y:875,t:1526922636327};\\\", \\\"{x:1268,y:852,t:1526922636343};\\\", \\\"{x:1259,y:830,t:1526922636361};\\\", \\\"{x:1249,y:801,t:1526922636378};\\\", \\\"{x:1240,y:767,t:1526922636393};\\\", \\\"{x:1237,y:745,t:1526922636411};\\\", \\\"{x:1235,y:730,t:1526922636428};\\\", \\\"{x:1234,y:715,t:1526922636443};\\\", \\\"{x:1232,y:696,t:1526922636461};\\\", \\\"{x:1231,y:686,t:1526922636477};\\\", \\\"{x:1231,y:678,t:1526922636494};\\\", \\\"{x:1231,y:677,t:1526922636511};\\\", \\\"{x:1231,y:675,t:1526922636527};\\\", \\\"{x:1232,y:673,t:1526922636573};\\\", \\\"{x:1233,y:671,t:1526922636590};\\\", \\\"{x:1234,y:669,t:1526922636598};\\\", \\\"{x:1234,y:668,t:1526922636611};\\\", \\\"{x:1235,y:666,t:1526922636627};\\\", \\\"{x:1235,y:665,t:1526922636645};\\\", \\\"{x:1236,y:663,t:1526922636661};\\\", \\\"{x:1237,y:662,t:1526922636677};\\\", \\\"{x:1238,y:661,t:1526922636694};\\\", \\\"{x:1239,y:658,t:1526922636711};\\\", \\\"{x:1239,y:656,t:1526922636727};\\\", \\\"{x:1239,y:654,t:1526922636744};\\\", \\\"{x:1241,y:652,t:1526922636761};\\\", \\\"{x:1241,y:649,t:1526922636777};\\\", \\\"{x:1243,y:645,t:1526922636793};\\\", \\\"{x:1244,y:644,t:1526922636810};\\\", \\\"{x:1245,y:637,t:1526922636827};\\\", \\\"{x:1246,y:634,t:1526922636844};\\\", \\\"{x:1246,y:630,t:1526922636861};\\\", \\\"{x:1246,y:627,t:1526922636877};\\\", \\\"{x:1246,y:625,t:1526922636893};\\\", \\\"{x:1246,y:624,t:1526922636911};\\\", \\\"{x:1245,y:624,t:1526922636989};\\\", \\\"{x:1241,y:625,t:1526922636997};\\\", \\\"{x:1238,y:626,t:1526922637010};\\\", \\\"{x:1224,y:637,t:1526922637026};\\\", \\\"{x:1200,y:647,t:1526922637044};\\\", \\\"{x:1173,y:658,t:1526922637060};\\\", \\\"{x:1109,y:675,t:1526922637077};\\\", \\\"{x:1075,y:686,t:1526922637093};\\\", \\\"{x:1040,y:691,t:1526922637110};\\\", \\\"{x:1013,y:695,t:1526922637127};\\\", \\\"{x:988,y:700,t:1526922637144};\\\", \\\"{x:970,y:704,t:1526922637160};\\\", \\\"{x:954,y:709,t:1526922637177};\\\", \\\"{x:938,y:715,t:1526922637194};\\\", \\\"{x:920,y:719,t:1526922637210};\\\", \\\"{x:896,y:719,t:1526922637227};\\\", \\\"{x:877,y:719,t:1526922637243};\\\", \\\"{x:864,y:721,t:1526922637260};\\\", \\\"{x:844,y:723,t:1526922637276};\\\", \\\"{x:833,y:723,t:1526922637294};\\\", \\\"{x:825,y:723,t:1526922637309};\\\", \\\"{x:807,y:724,t:1526922637326};\\\", \\\"{x:789,y:723,t:1526922637343};\\\", \\\"{x:770,y:723,t:1526922637359};\\\", \\\"{x:747,y:723,t:1526922637376};\\\", \\\"{x:726,y:723,t:1526922637393};\\\", \\\"{x:707,y:723,t:1526922637410};\\\", \\\"{x:681,y:722,t:1526922637426};\\\", \\\"{x:658,y:719,t:1526922637443};\\\", \\\"{x:635,y:716,t:1526922637459};\\\", \\\"{x:610,y:715,t:1526922637476};\\\", \\\"{x:593,y:715,t:1526922637493};\\\", \\\"{x:586,y:715,t:1526922637509};\\\", \\\"{x:577,y:715,t:1526922637527};\\\", \\\"{x:570,y:715,t:1526922637542};\\\", \\\"{x:566,y:715,t:1526922637559};\\\", \\\"{x:561,y:713,t:1526922637577};\\\", \\\"{x:558,y:713,t:1526922637593};\\\", \\\"{x:555,y:713,t:1526922637610};\\\", \\\"{x:549,y:713,t:1526922637631};\\\", \\\"{x:547,y:713,t:1526922637646};\\\", \\\"{x:544,y:713,t:1526922637663};\\\", \\\"{x:542,y:712,t:1526922637681};\\\", \\\"{x:541,y:712,t:1526922637698};\\\", \\\"{x:539,y:712,t:1526922637797};\\\", \\\"{x:538,y:712,t:1526922637820};\\\" ] }, { \\\"rt\\\": 19151, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 91741, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:713,t:1526922644582};\\\", \\\"{x:553,y:725,t:1526922644598};\\\", \\\"{x:591,y:746,t:1526922644616};\\\", \\\"{x:626,y:771,t:1526922644631};\\\", \\\"{x:668,y:796,t:1526922644648};\\\", \\\"{x:814,y:852,t:1526922644668};\\\", \\\"{x:916,y:895,t:1526922644686};\\\", \\\"{x:994,y:919,t:1526922644703};\\\", \\\"{x:1065,y:947,t:1526922644719};\\\", \\\"{x:1135,y:970,t:1526922644736};\\\", \\\"{x:1195,y:1002,t:1526922644753};\\\", \\\"{x:1254,y:1020,t:1526922644770};\\\", \\\"{x:1301,y:1042,t:1526922644786};\\\", \\\"{x:1339,y:1058,t:1526922644803};\\\", \\\"{x:1387,y:1074,t:1526922644820};\\\", \\\"{x:1425,y:1086,t:1526922644836};\\\", \\\"{x:1462,y:1099,t:1526922644852};\\\", \\\"{x:1477,y:1106,t:1526922644870};\\\", \\\"{x:1502,y:1111,t:1526922644885};\\\", \\\"{x:1514,y:1115,t:1526922644903};\\\", \\\"{x:1525,y:1119,t:1526922644920};\\\", \\\"{x:1530,y:1120,t:1526922644936};\\\", \\\"{x:1535,y:1122,t:1526922644952};\\\", \\\"{x:1540,y:1122,t:1526922644970};\\\", \\\"{x:1542,y:1119,t:1526922644988};\\\", \\\"{x:1542,y:1118,t:1526922645002};\\\", \\\"{x:1544,y:1115,t:1526922645020};\\\", \\\"{x:1548,y:1112,t:1526922645035};\\\", \\\"{x:1561,y:1102,t:1526922645052};\\\", \\\"{x:1570,y:1097,t:1526922645070};\\\", \\\"{x:1577,y:1091,t:1526922645085};\\\", \\\"{x:1585,y:1086,t:1526922645102};\\\", \\\"{x:1594,y:1079,t:1526922645120};\\\", \\\"{x:1601,y:1072,t:1526922645136};\\\", \\\"{x:1605,y:1069,t:1526922645153};\\\", \\\"{x:1609,y:1066,t:1526922645170};\\\", \\\"{x:1613,y:1061,t:1526922645187};\\\", \\\"{x:1616,y:1058,t:1526922645202};\\\", \\\"{x:1624,y:1050,t:1526922645220};\\\", \\\"{x:1633,y:1044,t:1526922645236};\\\", \\\"{x:1639,y:1038,t:1526922645253};\\\", \\\"{x:1643,y:1031,t:1526922645269};\\\", \\\"{x:1646,y:1025,t:1526922645287};\\\", \\\"{x:1648,y:1021,t:1526922645302};\\\", \\\"{x:1648,y:1017,t:1526922645319};\\\", \\\"{x:1650,y:1013,t:1526922645337};\\\", \\\"{x:1652,y:1011,t:1526922645353};\\\", \\\"{x:1655,y:1007,t:1526922645370};\\\", \\\"{x:1657,y:1002,t:1526922645387};\\\", \\\"{x:1660,y:998,t:1526922645403};\\\", \\\"{x:1662,y:993,t:1526922645419};\\\", \\\"{x:1663,y:989,t:1526922645437};\\\", \\\"{x:1665,y:986,t:1526922645453};\\\", \\\"{x:1665,y:985,t:1526922645470};\\\", \\\"{x:1666,y:984,t:1526922645487};\\\", \\\"{x:1667,y:981,t:1526922645504};\\\", \\\"{x:1667,y:980,t:1526922645548};\\\", \\\"{x:1667,y:979,t:1526922645564};\\\", \\\"{x:1667,y:978,t:1526922645596};\\\", \\\"{x:1667,y:977,t:1526922645612};\\\", \\\"{x:1667,y:976,t:1526922645620};\\\", \\\"{x:1667,y:975,t:1526922645636};\\\", \\\"{x:1667,y:974,t:1526922645654};\\\", \\\"{x:1665,y:972,t:1526922645670};\\\", \\\"{x:1665,y:970,t:1526922645686};\\\", \\\"{x:1664,y:969,t:1526922645704};\\\", \\\"{x:1663,y:968,t:1526922645720};\\\", \\\"{x:1662,y:968,t:1526922645737};\\\", \\\"{x:1660,y:968,t:1526922645964};\\\", \\\"{x:1658,y:968,t:1526922646533};\\\", \\\"{x:1657,y:969,t:1526922646556};\\\", \\\"{x:1656,y:970,t:1526922646669};\\\", \\\"{x:1655,y:970,t:1526922646717};\\\", \\\"{x:1655,y:971,t:1526922646781};\\\", \\\"{x:1654,y:972,t:1526922647365};\\\", \\\"{x:1653,y:972,t:1526922647373};\\\", \\\"{x:1653,y:971,t:1526922647453};\\\", \\\"{x:1652,y:971,t:1526922647461};\\\", \\\"{x:1652,y:970,t:1526922647508};\\\", \\\"{x:1652,y:969,t:1526922647548};\\\", \\\"{x:1652,y:968,t:1526922647572};\\\", \\\"{x:1651,y:967,t:1526922647732};\\\", \\\"{x:1651,y:966,t:1526922648077};\\\", \\\"{x:1651,y:965,t:1526922648093};\\\", \\\"{x:1651,y:963,t:1526922648116};\\\", \\\"{x:1651,y:962,t:1526922648132};\\\", \\\"{x:1651,y:960,t:1526922648148};\\\", \\\"{x:1651,y:959,t:1526922648164};\\\", \\\"{x:1651,y:957,t:1526922648172};\\\", \\\"{x:1651,y:956,t:1526922648196};\\\", \\\"{x:1651,y:955,t:1526922648213};\\\", \\\"{x:1651,y:954,t:1526922648223};\\\", \\\"{x:1651,y:953,t:1526922648252};\\\", \\\"{x:1651,y:951,t:1526922648261};\\\", \\\"{x:1651,y:950,t:1526922648277};\\\", \\\"{x:1651,y:948,t:1526922648289};\\\", \\\"{x:1651,y:947,t:1526922648306};\\\", \\\"{x:1651,y:944,t:1526922648323};\\\", \\\"{x:1651,y:943,t:1526922648339};\\\", \\\"{x:1651,y:940,t:1526922648356};\\\", \\\"{x:1650,y:936,t:1526922648373};\\\", \\\"{x:1649,y:933,t:1526922648389};\\\", \\\"{x:1649,y:931,t:1526922648406};\\\", \\\"{x:1648,y:930,t:1526922648423};\\\", \\\"{x:1648,y:927,t:1526922648439};\\\", \\\"{x:1647,y:925,t:1526922648456};\\\", \\\"{x:1647,y:923,t:1526922648477};\\\", \\\"{x:1646,y:920,t:1526922648494};\\\", \\\"{x:1646,y:919,t:1526922648506};\\\", \\\"{x:1646,y:917,t:1526922648523};\\\", \\\"{x:1646,y:915,t:1526922648540};\\\", \\\"{x:1646,y:914,t:1526922648556};\\\", \\\"{x:1645,y:911,t:1526922648573};\\\", \\\"{x:1645,y:909,t:1526922648590};\\\", \\\"{x:1645,y:908,t:1526922648606};\\\", \\\"{x:1644,y:904,t:1526922648623};\\\", \\\"{x:1643,y:902,t:1526922648645};\\\", \\\"{x:1643,y:901,t:1526922648655};\\\", \\\"{x:1643,y:899,t:1526922648673};\\\", \\\"{x:1642,y:897,t:1526922648690};\\\", \\\"{x:1642,y:895,t:1526922648706};\\\", \\\"{x:1642,y:894,t:1526922648722};\\\", \\\"{x:1642,y:891,t:1526922648740};\\\", \\\"{x:1642,y:890,t:1526922648756};\\\", \\\"{x:1642,y:888,t:1526922648772};\\\", \\\"{x:1642,y:887,t:1526922648790};\\\", \\\"{x:1642,y:885,t:1526922648806};\\\", \\\"{x:1640,y:883,t:1526922648823};\\\", \\\"{x:1640,y:882,t:1526922648840};\\\", \\\"{x:1640,y:880,t:1526922648857};\\\", \\\"{x:1640,y:877,t:1526922648872};\\\", \\\"{x:1640,y:876,t:1526922648890};\\\", \\\"{x:1639,y:873,t:1526922648909};\\\", \\\"{x:1639,y:872,t:1526922648932};\\\", \\\"{x:1639,y:871,t:1526922648940};\\\", \\\"{x:1639,y:870,t:1526922648956};\\\", \\\"{x:1639,y:868,t:1526922648973};\\\", \\\"{x:1639,y:867,t:1526922648990};\\\", \\\"{x:1639,y:866,t:1526922649007};\\\", \\\"{x:1639,y:863,t:1526922649023};\\\", \\\"{x:1639,y:857,t:1526922649040};\\\", \\\"{x:1639,y:854,t:1526922649057};\\\", \\\"{x:1639,y:853,t:1526922649073};\\\", \\\"{x:1639,y:851,t:1526922649090};\\\", \\\"{x:1638,y:850,t:1526922649107};\\\", \\\"{x:1638,y:849,t:1526922649123};\\\", \\\"{x:1637,y:847,t:1526922649140};\\\", \\\"{x:1636,y:847,t:1526922649254};\\\", \\\"{x:1635,y:848,t:1526922649261};\\\", \\\"{x:1632,y:850,t:1526922649274};\\\", \\\"{x:1631,y:855,t:1526922649291};\\\", \\\"{x:1628,y:864,t:1526922649307};\\\", \\\"{x:1623,y:875,t:1526922649323};\\\", \\\"{x:1619,y:887,t:1526922649340};\\\", \\\"{x:1617,y:901,t:1526922649356};\\\", \\\"{x:1615,y:908,t:1526922649374};\\\", \\\"{x:1615,y:912,t:1526922649390};\\\", \\\"{x:1614,y:913,t:1526922649407};\\\", \\\"{x:1612,y:915,t:1526922649424};\\\", \\\"{x:1612,y:916,t:1526922649440};\\\", \\\"{x:1611,y:918,t:1526922649457};\\\", \\\"{x:1611,y:922,t:1526922649474};\\\", \\\"{x:1611,y:925,t:1526922649490};\\\", \\\"{x:1611,y:928,t:1526922649506};\\\", \\\"{x:1610,y:931,t:1526922649524};\\\", \\\"{x:1610,y:934,t:1526922649540};\\\", \\\"{x:1609,y:936,t:1526922649557};\\\", \\\"{x:1609,y:939,t:1526922649574};\\\", \\\"{x:1609,y:941,t:1526922649591};\\\", \\\"{x:1608,y:941,t:1526922649607};\\\", \\\"{x:1608,y:942,t:1526922649629};\\\", \\\"{x:1608,y:943,t:1526922649644};\\\", \\\"{x:1608,y:944,t:1526922649657};\\\", \\\"{x:1608,y:945,t:1526922649708};\\\", \\\"{x:1608,y:947,t:1526922649724};\\\", \\\"{x:1608,y:948,t:1526922649740};\\\", \\\"{x:1608,y:950,t:1526922649757};\\\", \\\"{x:1608,y:951,t:1526922649774};\\\", \\\"{x:1608,y:952,t:1526922649797};\\\", \\\"{x:1608,y:953,t:1526922649837};\\\", \\\"{x:1608,y:954,t:1526922649845};\\\", \\\"{x:1608,y:955,t:1526922649877};\\\", \\\"{x:1608,y:956,t:1526922649893};\\\", \\\"{x:1608,y:957,t:1526922649908};\\\", \\\"{x:1608,y:958,t:1526922649933};\\\", \\\"{x:1608,y:959,t:1526922649941};\\\", \\\"{x:1608,y:960,t:1526922649965};\\\", \\\"{x:1608,y:961,t:1526922649974};\\\", \\\"{x:1608,y:963,t:1526922649991};\\\", \\\"{x:1608,y:964,t:1526922650013};\\\", \\\"{x:1608,y:966,t:1526922650029};\\\", \\\"{x:1608,y:967,t:1526922650150};\\\", \\\"{x:1608,y:968,t:1526922650205};\\\", \\\"{x:1608,y:969,t:1526922650236};\\\", \\\"{x:1608,y:970,t:1526922650277};\\\", \\\"{x:1608,y:972,t:1526922650325};\\\", \\\"{x:1609,y:973,t:1526922650365};\\\", \\\"{x:1609,y:975,t:1526922650405};\\\", \\\"{x:1610,y:975,t:1526922650413};\\\", \\\"{x:1610,y:976,t:1526922650428};\\\", \\\"{x:1610,y:977,t:1526922650441};\\\", \\\"{x:1611,y:980,t:1526922650458};\\\", \\\"{x:1611,y:981,t:1526922650476};\\\", \\\"{x:1612,y:982,t:1526922650845};\\\", \\\"{x:1613,y:982,t:1526922650918};\\\", \\\"{x:1614,y:982,t:1526922650925};\\\", \\\"{x:1615,y:982,t:1526922650949};\\\", \\\"{x:1615,y:980,t:1526922651277};\\\", \\\"{x:1617,y:979,t:1526922652372};\\\", \\\"{x:1617,y:978,t:1526922652396};\\\", \\\"{x:1617,y:977,t:1526922652410};\\\", \\\"{x:1618,y:975,t:1526922652426};\\\", \\\"{x:1621,y:972,t:1526922652443};\\\", \\\"{x:1621,y:970,t:1526922652460};\\\", \\\"{x:1621,y:966,t:1526922652476};\\\", \\\"{x:1620,y:959,t:1526922652493};\\\", \\\"{x:1620,y:954,t:1526922652510};\\\", \\\"{x:1620,y:951,t:1526922652526};\\\", \\\"{x:1620,y:944,t:1526922652543};\\\", \\\"{x:1618,y:940,t:1526922652560};\\\", \\\"{x:1617,y:934,t:1526922652576};\\\", \\\"{x:1617,y:932,t:1526922652593};\\\", \\\"{x:1617,y:929,t:1526922652610};\\\", \\\"{x:1617,y:925,t:1526922652626};\\\", \\\"{x:1617,y:922,t:1526922652643};\\\", \\\"{x:1617,y:913,t:1526922652660};\\\", \\\"{x:1617,y:910,t:1526922652677};\\\", \\\"{x:1617,y:906,t:1526922652693};\\\", \\\"{x:1617,y:903,t:1526922652710};\\\", \\\"{x:1617,y:901,t:1526922652728};\\\", \\\"{x:1617,y:900,t:1526922652744};\\\", \\\"{x:1617,y:897,t:1526922652760};\\\", \\\"{x:1617,y:894,t:1526922652777};\\\", \\\"{x:1617,y:893,t:1526922652793};\\\", \\\"{x:1617,y:890,t:1526922652811};\\\", \\\"{x:1617,y:888,t:1526922652828};\\\", \\\"{x:1617,y:887,t:1526922652845};\\\", \\\"{x:1617,y:884,t:1526922652860};\\\", \\\"{x:1617,y:883,t:1526922652918};\\\", \\\"{x:1617,y:882,t:1526922652941};\\\", \\\"{x:1617,y:880,t:1526922652957};\\\", \\\"{x:1617,y:878,t:1526922652974};\\\", \\\"{x:1617,y:877,t:1526922652998};\\\", \\\"{x:1617,y:876,t:1526922653010};\\\", \\\"{x:1616,y:873,t:1526922653028};\\\", \\\"{x:1615,y:871,t:1526922653044};\\\", \\\"{x:1615,y:870,t:1526922653061};\\\", \\\"{x:1614,y:868,t:1526922653077};\\\", \\\"{x:1614,y:866,t:1526922653095};\\\", \\\"{x:1614,y:864,t:1526922653111};\\\", \\\"{x:1614,y:862,t:1526922653128};\\\", \\\"{x:1614,y:860,t:1526922653145};\\\", \\\"{x:1614,y:858,t:1526922653161};\\\", \\\"{x:1614,y:857,t:1526922653178};\\\", \\\"{x:1614,y:855,t:1526922653195};\\\", \\\"{x:1614,y:853,t:1526922653210};\\\", \\\"{x:1614,y:852,t:1526922653227};\\\", \\\"{x:1613,y:849,t:1526922653244};\\\", \\\"{x:1613,y:846,t:1526922653261};\\\", \\\"{x:1613,y:843,t:1526922653278};\\\", \\\"{x:1613,y:842,t:1526922653295};\\\", \\\"{x:1613,y:840,t:1526922653310};\\\", \\\"{x:1613,y:839,t:1526922653327};\\\", \\\"{x:1612,y:839,t:1526922653345};\\\", \\\"{x:1612,y:838,t:1526922653365};\\\", \\\"{x:1611,y:837,t:1526922653397};\\\", \\\"{x:1611,y:836,t:1526922653444};\\\", \\\"{x:1611,y:835,t:1526922653468};\\\", \\\"{x:1611,y:834,t:1526922653477};\\\", \\\"{x:1611,y:833,t:1526922653494};\\\", \\\"{x:1611,y:832,t:1526922653512};\\\", \\\"{x:1611,y:831,t:1526922653527};\\\", \\\"{x:1611,y:830,t:1526922653557};\\\", \\\"{x:1611,y:829,t:1526922653588};\\\", \\\"{x:1611,y:828,t:1526922653604};\\\", \\\"{x:1611,y:827,t:1526922653613};\\\", \\\"{x:1611,y:826,t:1526922653636};\\\", \\\"{x:1611,y:825,t:1526922653685};\\\", \\\"{x:1611,y:824,t:1526922653717};\\\", \\\"{x:1611,y:822,t:1526922654134};\\\", \\\"{x:1611,y:821,t:1526922654145};\\\", \\\"{x:1611,y:819,t:1526922654162};\\\", \\\"{x:1610,y:816,t:1526922654178};\\\", \\\"{x:1610,y:815,t:1526922654195};\\\", \\\"{x:1610,y:814,t:1526922654211};\\\", \\\"{x:1610,y:812,t:1526922654228};\\\", \\\"{x:1610,y:811,t:1526922654260};\\\", \\\"{x:1610,y:810,t:1526922654276};\\\", \\\"{x:1610,y:809,t:1526922654325};\\\", \\\"{x:1610,y:808,t:1526922654357};\\\", \\\"{x:1610,y:807,t:1526922654380};\\\", \\\"{x:1610,y:806,t:1526922654412};\\\", \\\"{x:1610,y:805,t:1526922654445};\\\", \\\"{x:1610,y:804,t:1526922654692};\\\", \\\"{x:1610,y:803,t:1526922654708};\\\", \\\"{x:1608,y:804,t:1526922656468};\\\", \\\"{x:1608,y:809,t:1526922656480};\\\", \\\"{x:1607,y:816,t:1526922656497};\\\", \\\"{x:1607,y:820,t:1526922656513};\\\", \\\"{x:1607,y:826,t:1526922656530};\\\", \\\"{x:1606,y:828,t:1526922656547};\\\", \\\"{x:1604,y:832,t:1526922656563};\\\", \\\"{x:1601,y:835,t:1526922656580};\\\", \\\"{x:1600,y:840,t:1526922656598};\\\", \\\"{x:1600,y:846,t:1526922656613};\\\", \\\"{x:1600,y:854,t:1526922656630};\\\", \\\"{x:1600,y:862,t:1526922656647};\\\", \\\"{x:1600,y:869,t:1526922656663};\\\", \\\"{x:1600,y:874,t:1526922656681};\\\", \\\"{x:1601,y:879,t:1526922656697};\\\", \\\"{x:1602,y:884,t:1526922656713};\\\", \\\"{x:1602,y:888,t:1526922656730};\\\", \\\"{x:1604,y:893,t:1526922656747};\\\", \\\"{x:1605,y:898,t:1526922656764};\\\", \\\"{x:1609,y:904,t:1526922656781};\\\", \\\"{x:1610,y:908,t:1526922656797};\\\", \\\"{x:1612,y:911,t:1526922656814};\\\", \\\"{x:1614,y:914,t:1526922656831};\\\", \\\"{x:1616,y:917,t:1526922656848};\\\", \\\"{x:1616,y:918,t:1526922656864};\\\", \\\"{x:1618,y:921,t:1526922656880};\\\", \\\"{x:1619,y:923,t:1526922656898};\\\", \\\"{x:1621,y:924,t:1526922656917};\\\", \\\"{x:1623,y:925,t:1526922656940};\\\", \\\"{x:1625,y:926,t:1526922656981};\\\", \\\"{x:1625,y:928,t:1526922657037};\\\", \\\"{x:1625,y:930,t:1526922657060};\\\", \\\"{x:1625,y:931,t:1526922657077};\\\", \\\"{x:1625,y:932,t:1526922657085};\\\", \\\"{x:1625,y:933,t:1526922657097};\\\", \\\"{x:1624,y:937,t:1526922657115};\\\", \\\"{x:1624,y:938,t:1526922657132};\\\", \\\"{x:1622,y:939,t:1526922657148};\\\", \\\"{x:1622,y:943,t:1526922657164};\\\", \\\"{x:1621,y:946,t:1526922657180};\\\", \\\"{x:1618,y:951,t:1526922657197};\\\", \\\"{x:1618,y:955,t:1526922657215};\\\", \\\"{x:1617,y:958,t:1526922657231};\\\", \\\"{x:1617,y:960,t:1526922657248};\\\", \\\"{x:1617,y:963,t:1526922657265};\\\", \\\"{x:1617,y:964,t:1526922657282};\\\", \\\"{x:1617,y:965,t:1526922657334};\\\", \\\"{x:1617,y:963,t:1526922657446};\\\", \\\"{x:1618,y:960,t:1526922657454};\\\", \\\"{x:1621,y:955,t:1526922657463};\\\", \\\"{x:1624,y:947,t:1526922657481};\\\", \\\"{x:1627,y:939,t:1526922657497};\\\", \\\"{x:1629,y:932,t:1526922657514};\\\", \\\"{x:1632,y:924,t:1526922657531};\\\", \\\"{x:1632,y:918,t:1526922657547};\\\", \\\"{x:1634,y:912,t:1526922657564};\\\", \\\"{x:1634,y:910,t:1526922657581};\\\", \\\"{x:1634,y:907,t:1526922657599};\\\", \\\"{x:1634,y:901,t:1526922657614};\\\", \\\"{x:1634,y:897,t:1526922657632};\\\", \\\"{x:1634,y:892,t:1526922657648};\\\", \\\"{x:1631,y:885,t:1526922657664};\\\", \\\"{x:1630,y:876,t:1526922657681};\\\", \\\"{x:1628,y:869,t:1526922657699};\\\", \\\"{x:1626,y:861,t:1526922657714};\\\", \\\"{x:1622,y:854,t:1526922657731};\\\", \\\"{x:1621,y:846,t:1526922657748};\\\", \\\"{x:1618,y:839,t:1526922657764};\\\", \\\"{x:1616,y:831,t:1526922657781};\\\", \\\"{x:1616,y:827,t:1526922657798};\\\", \\\"{x:1614,y:822,t:1526922657815};\\\", \\\"{x:1613,y:820,t:1526922657831};\\\", \\\"{x:1611,y:817,t:1526922657848};\\\", \\\"{x:1611,y:816,t:1526922657865};\\\", \\\"{x:1610,y:814,t:1526922657882};\\\", \\\"{x:1609,y:814,t:1526922657933};\\\", \\\"{x:1604,y:814,t:1526922657948};\\\", \\\"{x:1586,y:823,t:1526922657966};\\\", \\\"{x:1558,y:835,t:1526922657981};\\\", \\\"{x:1494,y:854,t:1526922657999};\\\", \\\"{x:1427,y:865,t:1526922658015};\\\", \\\"{x:1356,y:879,t:1526922658032};\\\", \\\"{x:1271,y:888,t:1526922658048};\\\", \\\"{x:1188,y:897,t:1526922658065};\\\", \\\"{x:1111,y:903,t:1526922658081};\\\", \\\"{x:1085,y:907,t:1526922658098};\\\", \\\"{x:1043,y:907,t:1526922658115};\\\", \\\"{x:1015,y:907,t:1526922658131};\\\", \\\"{x:978,y:909,t:1526922658148};\\\", \\\"{x:956,y:909,t:1526922658166};\\\", \\\"{x:941,y:909,t:1526922658181};\\\", \\\"{x:926,y:909,t:1526922658198};\\\", \\\"{x:916,y:909,t:1526922658215};\\\", \\\"{x:903,y:909,t:1526922658232};\\\", \\\"{x:891,y:909,t:1526922658248};\\\", \\\"{x:876,y:907,t:1526922658265};\\\", \\\"{x:860,y:901,t:1526922658282};\\\", \\\"{x:850,y:895,t:1526922658298};\\\", \\\"{x:832,y:885,t:1526922658315};\\\", \\\"{x:806,y:872,t:1526922658332};\\\", \\\"{x:791,y:865,t:1526922658348};\\\", \\\"{x:781,y:857,t:1526922658365};\\\", \\\"{x:770,y:850,t:1526922658382};\\\", \\\"{x:767,y:845,t:1526922658398};\\\", \\\"{x:764,y:842,t:1526922658415};\\\", \\\"{x:757,y:836,t:1526922658432};\\\", \\\"{x:746,y:829,t:1526922658448};\\\", \\\"{x:730,y:822,t:1526922658465};\\\", \\\"{x:714,y:816,t:1526922658482};\\\", \\\"{x:695,y:807,t:1526922658498};\\\", \\\"{x:678,y:799,t:1526922658515};\\\", \\\"{x:653,y:789,t:1526922658532};\\\", \\\"{x:642,y:784,t:1526922658548};\\\", \\\"{x:629,y:776,t:1526922658564};\\\", \\\"{x:612,y:770,t:1526922658582};\\\", \\\"{x:601,y:764,t:1526922658598};\\\", \\\"{x:587,y:757,t:1526922658615};\\\", \\\"{x:579,y:752,t:1526922658632};\\\", \\\"{x:574,y:749,t:1526922658648};\\\", \\\"{x:567,y:745,t:1526922658665};\\\", \\\"{x:563,y:743,t:1526922658682};\\\", \\\"{x:561,y:740,t:1526922658699};\\\", \\\"{x:560,y:740,t:1526922658715};\\\", \\\"{x:558,y:739,t:1526922658796};\\\", \\\"{x:555,y:737,t:1526922658813};\\\", \\\"{x:555,y:736,t:1526922658844};\\\", \\\"{x:554,y:736,t:1526922658852};\\\", \\\"{x:554,y:735,t:1526922658909};\\\", \\\"{x:552,y:733,t:1526922658929};\\\", \\\"{x:551,y:731,t:1526922658946};\\\", \\\"{x:551,y:729,t:1526922658961};\\\", \\\"{x:550,y:727,t:1526922658977};\\\", \\\"{x:548,y:725,t:1526922658994};\\\", \\\"{x:548,y:724,t:1526922659010};\\\", \\\"{x:548,y:723,t:1526922659027};\\\", \\\"{x:547,y:721,t:1526922659044};\\\", \\\"{x:547,y:720,t:1526922659061};\\\", \\\"{x:546,y:720,t:1526922659078};\\\", \\\"{x:546,y:717,t:1526922659094};\\\", \\\"{x:546,y:716,t:1526922659110};\\\", \\\"{x:546,y:715,t:1526922659128};\\\", \\\"{x:546,y:714,t:1526922659144};\\\", \\\"{x:545,y:713,t:1526922659163};\\\" ] }, { \\\"rt\\\": 11837, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 104792, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:716,t:1526922665316};\\\", \\\"{x:551,y:719,t:1526922665324};\\\", \\\"{x:555,y:723,t:1526922665336};\\\", \\\"{x:562,y:726,t:1526922665352};\\\", \\\"{x:573,y:732,t:1526922665370};\\\", \\\"{x:585,y:737,t:1526922665386};\\\", \\\"{x:599,y:743,t:1526922665402};\\\", \\\"{x:615,y:749,t:1526922665416};\\\", \\\"{x:629,y:752,t:1526922665434};\\\", \\\"{x:643,y:757,t:1526922665449};\\\", \\\"{x:657,y:764,t:1526922665466};\\\", \\\"{x:669,y:770,t:1526922665483};\\\", \\\"{x:687,y:779,t:1526922665499};\\\", \\\"{x:695,y:783,t:1526922665516};\\\", \\\"{x:710,y:788,t:1526922665533};\\\", \\\"{x:728,y:794,t:1526922665550};\\\", \\\"{x:743,y:798,t:1526922665566};\\\", \\\"{x:764,y:805,t:1526922665583};\\\", \\\"{x:780,y:810,t:1526922665600};\\\", \\\"{x:795,y:816,t:1526922665616};\\\", \\\"{x:814,y:821,t:1526922665634};\\\", \\\"{x:837,y:828,t:1526922665650};\\\", \\\"{x:858,y:834,t:1526922665666};\\\", \\\"{x:881,y:838,t:1526922665683};\\\", \\\"{x:910,y:846,t:1526922665699};\\\", \\\"{x:924,y:852,t:1526922665716};\\\", \\\"{x:942,y:856,t:1526922665733};\\\", \\\"{x:961,y:859,t:1526922665750};\\\", \\\"{x:978,y:869,t:1526922665766};\\\", \\\"{x:1000,y:875,t:1526922665783};\\\", \\\"{x:1026,y:885,t:1526922665800};\\\", \\\"{x:1049,y:892,t:1526922665816};\\\", \\\"{x:1075,y:900,t:1526922665833};\\\", \\\"{x:1093,y:908,t:1526922665851};\\\", \\\"{x:1116,y:912,t:1526922665867};\\\", \\\"{x:1139,y:915,t:1526922665883};\\\", \\\"{x:1161,y:919,t:1526922665899};\\\", \\\"{x:1183,y:924,t:1526922665917};\\\", \\\"{x:1205,y:925,t:1526922665933};\\\", \\\"{x:1225,y:928,t:1526922665951};\\\", \\\"{x:1239,y:931,t:1526922665967};\\\", \\\"{x:1250,y:931,t:1526922665984};\\\", \\\"{x:1266,y:934,t:1526922666000};\\\", \\\"{x:1278,y:936,t:1526922666018};\\\", \\\"{x:1298,y:939,t:1526922666034};\\\", \\\"{x:1313,y:940,t:1526922666050};\\\", \\\"{x:1330,y:944,t:1526922666067};\\\", \\\"{x:1345,y:945,t:1526922666084};\\\", \\\"{x:1363,y:945,t:1526922666100};\\\", \\\"{x:1368,y:945,t:1526922666117};\\\", \\\"{x:1374,y:943,t:1526922666135};\\\", \\\"{x:1379,y:941,t:1526922666150};\\\", \\\"{x:1381,y:940,t:1526922666167};\\\", \\\"{x:1384,y:939,t:1526922666184};\\\", \\\"{x:1385,y:937,t:1526922666201};\\\", \\\"{x:1387,y:937,t:1526922666217};\\\", \\\"{x:1389,y:936,t:1526922666234};\\\", \\\"{x:1389,y:934,t:1526922666250};\\\", \\\"{x:1391,y:930,t:1526922666267};\\\", \\\"{x:1393,y:926,t:1526922666284};\\\", \\\"{x:1393,y:923,t:1526922666301};\\\", \\\"{x:1393,y:920,t:1526922666317};\\\", \\\"{x:1393,y:918,t:1526922666334};\\\", \\\"{x:1393,y:915,t:1526922666351};\\\", \\\"{x:1393,y:911,t:1526922666367};\\\", \\\"{x:1388,y:908,t:1526922666384};\\\", \\\"{x:1383,y:905,t:1526922666401};\\\", \\\"{x:1379,y:904,t:1526922666417};\\\", \\\"{x:1366,y:901,t:1526922666434};\\\", \\\"{x:1355,y:900,t:1526922666452};\\\", \\\"{x:1342,y:899,t:1526922666467};\\\", \\\"{x:1322,y:897,t:1526922666484};\\\", \\\"{x:1307,y:895,t:1526922666501};\\\", \\\"{x:1296,y:895,t:1526922666518};\\\", \\\"{x:1283,y:891,t:1526922666534};\\\", \\\"{x:1273,y:889,t:1526922666551};\\\", \\\"{x:1257,y:886,t:1526922666568};\\\", \\\"{x:1245,y:885,t:1526922666584};\\\", \\\"{x:1229,y:882,t:1526922666602};\\\", \\\"{x:1220,y:880,t:1526922666618};\\\", \\\"{x:1210,y:876,t:1526922666634};\\\", \\\"{x:1201,y:872,t:1526922666652};\\\", \\\"{x:1191,y:866,t:1526922666667};\\\", \\\"{x:1188,y:863,t:1526922666685};\\\", \\\"{x:1186,y:862,t:1526922666701};\\\", \\\"{x:1185,y:861,t:1526922666740};\\\", \\\"{x:1185,y:860,t:1526922666764};\\\", \\\"{x:1185,y:859,t:1526922666788};\\\", \\\"{x:1185,y:858,t:1526922666801};\\\", \\\"{x:1185,y:857,t:1526922666819};\\\", \\\"{x:1185,y:855,t:1526922666834};\\\", \\\"{x:1185,y:853,t:1526922666851};\\\", \\\"{x:1187,y:853,t:1526922666867};\\\", \\\"{x:1189,y:851,t:1526922666884};\\\", \\\"{x:1192,y:850,t:1526922666901};\\\", \\\"{x:1193,y:849,t:1526922666918};\\\", \\\"{x:1194,y:849,t:1526922666934};\\\", \\\"{x:1196,y:848,t:1526922667068};\\\", \\\"{x:1196,y:847,t:1526922667085};\\\", \\\"{x:1196,y:846,t:1526922667101};\\\", \\\"{x:1196,y:845,t:1526922667118};\\\", \\\"{x:1196,y:843,t:1526922667135};\\\", \\\"{x:1198,y:840,t:1526922667152};\\\", \\\"{x:1198,y:839,t:1526922667169};\\\", \\\"{x:1198,y:838,t:1526922667185};\\\", \\\"{x:1199,y:838,t:1526922667202};\\\", \\\"{x:1199,y:837,t:1526922667685};\\\", \\\"{x:1200,y:836,t:1526922667703};\\\", \\\"{x:1201,y:836,t:1526922667797};\\\", \\\"{x:1201,y:835,t:1526922667917};\\\", \\\"{x:1202,y:833,t:1526922668021};\\\", \\\"{x:1203,y:832,t:1526922668187};\\\", \\\"{x:1204,y:832,t:1526922668220};\\\", \\\"{x:1205,y:832,t:1526922668268};\\\", \\\"{x:1206,y:832,t:1526922668276};\\\", \\\"{x:1207,y:832,t:1526922668287};\\\", \\\"{x:1210,y:832,t:1526922668304};\\\", \\\"{x:1212,y:832,t:1526922668320};\\\", \\\"{x:1213,y:832,t:1526922668336};\\\", \\\"{x:1214,y:832,t:1526922668353};\\\", \\\"{x:1216,y:832,t:1526922668388};\\\", \\\"{x:1216,y:831,t:1526922668419};\\\", \\\"{x:1217,y:831,t:1526922668924};\\\", \\\"{x:1217,y:832,t:1526922668940};\\\", \\\"{x:1217,y:833,t:1526922668964};\\\", \\\"{x:1217,y:834,t:1526922668972};\\\", \\\"{x:1217,y:835,t:1526922668995};\\\", \\\"{x:1217,y:836,t:1526922669020};\\\", \\\"{x:1218,y:837,t:1526922669037};\\\", \\\"{x:1218,y:838,t:1526922669055};\\\", \\\"{x:1219,y:840,t:1526922669076};\\\", \\\"{x:1220,y:841,t:1526922669087};\\\", \\\"{x:1221,y:842,t:1526922669108};\\\", \\\"{x:1221,y:844,t:1526922669124};\\\", \\\"{x:1221,y:845,t:1526922669139};\\\", \\\"{x:1221,y:847,t:1526922669156};\\\", \\\"{x:1223,y:848,t:1526922669171};\\\", \\\"{x:1223,y:850,t:1526922669187};\\\", \\\"{x:1223,y:855,t:1526922669204};\\\", \\\"{x:1224,y:858,t:1526922669221};\\\", \\\"{x:1224,y:862,t:1526922669237};\\\", \\\"{x:1224,y:865,t:1526922669254};\\\", \\\"{x:1224,y:869,t:1526922669272};\\\", \\\"{x:1224,y:872,t:1526922669287};\\\", \\\"{x:1225,y:877,t:1526922669304};\\\", \\\"{x:1225,y:880,t:1526922669321};\\\", \\\"{x:1226,y:886,t:1526922669337};\\\", \\\"{x:1226,y:889,t:1526922669354};\\\", \\\"{x:1227,y:894,t:1526922669371};\\\", \\\"{x:1228,y:896,t:1526922669387};\\\", \\\"{x:1228,y:900,t:1526922669404};\\\", \\\"{x:1228,y:905,t:1526922669421};\\\", \\\"{x:1232,y:910,t:1526922669437};\\\", \\\"{x:1234,y:913,t:1526922669454};\\\", \\\"{x:1235,y:917,t:1526922669471};\\\", \\\"{x:1235,y:920,t:1526922669488};\\\", \\\"{x:1235,y:926,t:1526922669504};\\\", \\\"{x:1235,y:930,t:1526922669521};\\\", \\\"{x:1236,y:935,t:1526922669539};\\\", \\\"{x:1238,y:939,t:1526922669554};\\\", \\\"{x:1239,y:947,t:1526922669571};\\\", \\\"{x:1239,y:954,t:1526922669588};\\\", \\\"{x:1239,y:956,t:1526922669605};\\\", \\\"{x:1239,y:958,t:1526922669622};\\\", \\\"{x:1239,y:961,t:1526922669638};\\\", \\\"{x:1239,y:963,t:1526922669654};\\\", \\\"{x:1239,y:966,t:1526922669672};\\\", \\\"{x:1239,y:967,t:1526922669688};\\\", \\\"{x:1239,y:970,t:1526922669705};\\\", \\\"{x:1239,y:971,t:1526922669721};\\\", \\\"{x:1239,y:973,t:1526922669738};\\\", \\\"{x:1240,y:975,t:1526922669756};\\\", \\\"{x:1241,y:977,t:1526922669771};\\\", \\\"{x:1242,y:979,t:1526922669789};\\\", \\\"{x:1242,y:980,t:1526922669805};\\\", \\\"{x:1243,y:981,t:1526922669827};\\\", \\\"{x:1243,y:982,t:1526922669839};\\\", \\\"{x:1244,y:983,t:1526922669876};\\\", \\\"{x:1246,y:983,t:1526922669964};\\\", \\\"{x:1247,y:982,t:1526922669971};\\\", \\\"{x:1251,y:982,t:1526922669989};\\\", \\\"{x:1253,y:981,t:1526922670005};\\\", \\\"{x:1259,y:978,t:1526922670022};\\\", \\\"{x:1262,y:976,t:1526922670039};\\\", \\\"{x:1264,y:976,t:1526922670056};\\\", \\\"{x:1266,y:974,t:1526922670073};\\\", \\\"{x:1268,y:972,t:1526922670088};\\\", \\\"{x:1270,y:971,t:1526922670105};\\\", \\\"{x:1272,y:965,t:1526922670123};\\\", \\\"{x:1276,y:960,t:1526922670139};\\\", \\\"{x:1279,y:951,t:1526922670156};\\\", \\\"{x:1284,y:931,t:1526922670172};\\\", \\\"{x:1284,y:917,t:1526922670188};\\\", \\\"{x:1284,y:900,t:1526922670206};\\\", \\\"{x:1284,y:882,t:1526922670223};\\\", \\\"{x:1284,y:858,t:1526922670239};\\\", \\\"{x:1280,y:829,t:1526922670255};\\\", \\\"{x:1274,y:803,t:1526922670273};\\\", \\\"{x:1265,y:772,t:1526922670289};\\\", \\\"{x:1256,y:749,t:1526922670306};\\\", \\\"{x:1246,y:728,t:1526922670322};\\\", \\\"{x:1236,y:710,t:1526922670340};\\\", \\\"{x:1224,y:691,t:1526922670355};\\\", \\\"{x:1216,y:684,t:1526922670372};\\\", \\\"{x:1208,y:677,t:1526922670389};\\\", \\\"{x:1199,y:676,t:1526922670406};\\\", \\\"{x:1184,y:674,t:1526922670422};\\\", \\\"{x:1155,y:674,t:1526922670439};\\\", \\\"{x:1125,y:674,t:1526922670455};\\\", \\\"{x:1078,y:667,t:1526922670473};\\\", \\\"{x:1039,y:663,t:1526922670489};\\\", \\\"{x:1012,y:658,t:1526922670505};\\\", \\\"{x:997,y:649,t:1526922670522};\\\", \\\"{x:984,y:643,t:1526922670540};\\\", \\\"{x:982,y:640,t:1526922670556};\\\", \\\"{x:982,y:638,t:1526922670572};\\\", \\\"{x:981,y:637,t:1526922670589};\\\", \\\"{x:980,y:635,t:1526922670606};\\\", \\\"{x:980,y:633,t:1526922670622};\\\", \\\"{x:980,y:631,t:1526922670640};\\\", \\\"{x:979,y:630,t:1526922670657};\\\", \\\"{x:977,y:626,t:1526922670673};\\\", \\\"{x:971,y:622,t:1526922670689};\\\", \\\"{x:966,y:617,t:1526922670706};\\\", \\\"{x:957,y:611,t:1526922670723};\\\", \\\"{x:948,y:605,t:1526922670740};\\\", \\\"{x:938,y:599,t:1526922670756};\\\", \\\"{x:931,y:595,t:1526922670772};\\\", \\\"{x:926,y:591,t:1526922670787};\\\", \\\"{x:919,y:588,t:1526922670804};\\\", \\\"{x:916,y:585,t:1526922670820};\\\", \\\"{x:911,y:582,t:1526922670837};\\\", \\\"{x:903,y:578,t:1526922670853};\\\", \\\"{x:900,y:576,t:1526922670871};\\\", \\\"{x:893,y:573,t:1526922670888};\\\", \\\"{x:881,y:567,t:1526922670905};\\\", \\\"{x:870,y:562,t:1526922670921};\\\", \\\"{x:865,y:558,t:1526922670937};\\\", \\\"{x:859,y:554,t:1526922670954};\\\", \\\"{x:858,y:553,t:1526922670970};\\\", \\\"{x:857,y:551,t:1526922670988};\\\", \\\"{x:855,y:547,t:1526922671004};\\\", \\\"{x:855,y:545,t:1526922671020};\\\", \\\"{x:855,y:543,t:1526922671038};\\\", \\\"{x:855,y:541,t:1526922671054};\\\", \\\"{x:855,y:539,t:1526922671071};\\\", \\\"{x:854,y:538,t:1526922671087};\\\", \\\"{x:854,y:535,t:1526922671105};\\\", \\\"{x:854,y:534,t:1526922671120};\\\", \\\"{x:853,y:531,t:1526922671138};\\\", \\\"{x:851,y:529,t:1526922671155};\\\", \\\"{x:850,y:524,t:1526922671171};\\\", \\\"{x:848,y:521,t:1526922671188};\\\", \\\"{x:846,y:517,t:1526922671203};\\\", \\\"{x:844,y:515,t:1526922671221};\\\", \\\"{x:843,y:513,t:1526922671237};\\\", \\\"{x:842,y:510,t:1526922671255};\\\", \\\"{x:841,y:508,t:1526922671271};\\\", \\\"{x:840,y:507,t:1526922671287};\\\", \\\"{x:840,y:506,t:1526922671307};\\\", \\\"{x:838,y:506,t:1526922671323};\\\", \\\"{x:836,y:506,t:1526922671419};\\\", \\\"{x:835,y:507,t:1526922671451};\\\", \\\"{x:834,y:509,t:1526922671467};\\\", \\\"{x:833,y:512,t:1526922671484};\\\", \\\"{x:833,y:513,t:1526922671499};\\\", \\\"{x:833,y:514,t:1526922671508};\\\", \\\"{x:833,y:515,t:1526922671532};\\\", \\\"{x:833,y:517,t:1526922671547};\\\", \\\"{x:833,y:518,t:1526922671579};\\\", \\\"{x:833,y:520,t:1526922671620};\\\", \\\"{x:833,y:521,t:1526922671923};\\\", \\\"{x:833,y:522,t:1526922671938};\\\", \\\"{x:833,y:526,t:1526922671955};\\\", \\\"{x:829,y:535,t:1526922671972};\\\", \\\"{x:824,y:539,t:1526922671988};\\\", \\\"{x:819,y:545,t:1526922672005};\\\", \\\"{x:809,y:552,t:1526922672021};\\\", \\\"{x:803,y:556,t:1526922672038};\\\", \\\"{x:791,y:565,t:1526922672055};\\\", \\\"{x:780,y:575,t:1526922672072};\\\", \\\"{x:767,y:586,t:1526922672089};\\\", \\\"{x:753,y:597,t:1526922672105};\\\", \\\"{x:744,y:607,t:1526922672121};\\\", \\\"{x:734,y:617,t:1526922672139};\\\", \\\"{x:724,y:631,t:1526922672156};\\\", \\\"{x:718,y:638,t:1526922672172};\\\", \\\"{x:710,y:644,t:1526922672187};\\\", \\\"{x:705,y:648,t:1526922672204};\\\", \\\"{x:698,y:651,t:1526922672222};\\\", \\\"{x:693,y:654,t:1526922672237};\\\", \\\"{x:689,y:656,t:1526922672255};\\\", \\\"{x:684,y:660,t:1526922672271};\\\", \\\"{x:679,y:663,t:1526922672288};\\\", \\\"{x:675,y:664,t:1526922672304};\\\", \\\"{x:670,y:666,t:1526922672321};\\\", \\\"{x:666,y:668,t:1526922672339};\\\", \\\"{x:661,y:669,t:1526922672354};\\\", \\\"{x:655,y:673,t:1526922672372};\\\", \\\"{x:648,y:677,t:1526922672388};\\\", \\\"{x:640,y:680,t:1526922672405};\\\", \\\"{x:630,y:684,t:1526922672421};\\\", \\\"{x:621,y:687,t:1526922672439};\\\", \\\"{x:609,y:692,t:1526922672454};\\\", \\\"{x:601,y:696,t:1526922672471};\\\", \\\"{x:599,y:697,t:1526922672488};\\\", \\\"{x:594,y:698,t:1526922672504};\\\", \\\"{x:589,y:702,t:1526922672521};\\\", \\\"{x:584,y:704,t:1526922672538};\\\", \\\"{x:580,y:705,t:1526922672555};\\\", \\\"{x:574,y:706,t:1526922672572};\\\", \\\"{x:571,y:709,t:1526922672588};\\\", \\\"{x:567,y:711,t:1526922672605};\\\", \\\"{x:565,y:712,t:1526922672621};\\\", \\\"{x:563,y:713,t:1526922672638};\\\", \\\"{x:561,y:715,t:1526922672654};\\\", \\\"{x:559,y:716,t:1526922672676};\\\", \\\"{x:558,y:716,t:1526922672688};\\\", \\\"{x:557,y:717,t:1526922672708};\\\", \\\"{x:556,y:718,t:1526922672739};\\\", \\\"{x:555,y:719,t:1526922672763};\\\", \\\"{x:554,y:719,t:1526922672779};\\\", \\\"{x:553,y:719,t:1526922672795};\\\", \\\"{x:552,y:720,t:1526922672805};\\\", \\\"{x:551,y:721,t:1526922672822};\\\", \\\"{x:550,y:722,t:1526922672839};\\\", \\\"{x:548,y:723,t:1526922672855};\\\", \\\"{x:547,y:724,t:1526922672875};\\\", \\\"{x:547,y:725,t:1526922672988};\\\", \\\"{x:546,y:725,t:1526922673044};\\\", \\\"{x:545,y:725,t:1526922673076};\\\", \\\"{x:544,y:725,t:1526922673107};\\\", \\\"{x:543,y:725,t:1526922673123};\\\", \\\"{x:543,y:726,t:1526922673140};\\\", \\\"{x:542,y:727,t:1526922673171};\\\", \\\"{x:542,y:728,t:1526922673203};\\\", \\\"{x:540,y:728,t:1526922673211};\\\", \\\"{x:540,y:729,t:1526922673223};\\\", \\\"{x:540,y:730,t:1526922673251};\\\", \\\"{x:540,y:729,t:1526922673452};\\\", \\\"{x:540,y:728,t:1526922673468};\\\", \\\"{x:540,y:726,t:1526922673476};\\\", \\\"{x:540,y:724,t:1526922673491};\\\", \\\"{x:541,y:723,t:1526922673506};\\\", \\\"{x:541,y:722,t:1526922673522};\\\", \\\"{x:543,y:721,t:1526922673540};\\\" ] }, { \\\"rt\\\": 15550, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 121570, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:721,t:1526922679253};\\\", \\\"{x:542,y:722,t:1526922679276};\\\", \\\"{x:540,y:724,t:1526922679286};\\\", \\\"{x:539,y:728,t:1526922679302};\\\", \\\"{x:539,y:736,t:1526922679320};\\\", \\\"{x:540,y:749,t:1526922679337};\\\", \\\"{x:552,y:765,t:1526922679353};\\\", \\\"{x:580,y:790,t:1526922679377};\\\", \\\"{x:615,y:819,t:1526922679395};\\\", \\\"{x:657,y:847,t:1526922679410};\\\", \\\"{x:698,y:866,t:1526922679427};\\\", \\\"{x:766,y:889,t:1526922679445};\\\", \\\"{x:826,y:911,t:1526922679460};\\\", \\\"{x:894,y:936,t:1526922679478};\\\", \\\"{x:950,y:953,t:1526922679494};\\\", \\\"{x:1003,y:969,t:1526922679512};\\\", \\\"{x:1057,y:982,t:1526922679527};\\\", \\\"{x:1113,y:991,t:1526922679545};\\\", \\\"{x:1166,y:998,t:1526922679562};\\\", \\\"{x:1197,y:1002,t:1526922679578};\\\", \\\"{x:1233,y:1007,t:1526922679595};\\\", \\\"{x:1262,y:1012,t:1526922679612};\\\", \\\"{x:1274,y:1014,t:1526922679628};\\\", \\\"{x:1290,y:1015,t:1526922679644};\\\", \\\"{x:1300,y:1017,t:1526922679661};\\\", \\\"{x:1316,y:1018,t:1526922679678};\\\", \\\"{x:1332,y:1018,t:1526922679695};\\\", \\\"{x:1350,y:1018,t:1526922679712};\\\", \\\"{x:1366,y:1023,t:1526922679729};\\\", \\\"{x:1382,y:1024,t:1526922679744};\\\", \\\"{x:1397,y:1024,t:1526922679762};\\\", \\\"{x:1411,y:1024,t:1526922679778};\\\", \\\"{x:1426,y:1024,t:1526922679795};\\\", \\\"{x:1458,y:1024,t:1526922679812};\\\", \\\"{x:1474,y:1024,t:1526922679829};\\\", \\\"{x:1491,y:1023,t:1526922679845};\\\", \\\"{x:1505,y:1021,t:1526922679862};\\\", \\\"{x:1520,y:1020,t:1526922679879};\\\", \\\"{x:1530,y:1018,t:1526922679896};\\\", \\\"{x:1542,y:1016,t:1526922679912};\\\", \\\"{x:1549,y:1014,t:1526922679929};\\\", \\\"{x:1557,y:1010,t:1526922679946};\\\", \\\"{x:1563,y:1009,t:1526922679962};\\\", \\\"{x:1572,y:1005,t:1526922679979};\\\", \\\"{x:1588,y:1000,t:1526922679995};\\\", \\\"{x:1601,y:995,t:1526922680012};\\\", \\\"{x:1611,y:991,t:1526922680029};\\\", \\\"{x:1616,y:987,t:1526922680046};\\\", \\\"{x:1619,y:984,t:1526922680062};\\\", \\\"{x:1622,y:982,t:1526922680078};\\\", \\\"{x:1623,y:982,t:1526922680115};\\\", \\\"{x:1623,y:980,t:1526922680129};\\\", \\\"{x:1624,y:978,t:1526922680164};\\\", \\\"{x:1624,y:977,t:1526922680179};\\\", \\\"{x:1625,y:976,t:1526922680196};\\\", \\\"{x:1625,y:974,t:1526922680213};\\\", \\\"{x:1625,y:973,t:1526922680230};\\\", \\\"{x:1624,y:973,t:1526922680540};\\\", \\\"{x:1623,y:973,t:1526922680555};\\\", \\\"{x:1621,y:973,t:1526922680564};\\\", \\\"{x:1619,y:973,t:1526922680611};\\\", \\\"{x:1618,y:973,t:1526922680636};\\\", \\\"{x:1616,y:973,t:1526922680675};\\\", \\\"{x:1615,y:973,t:1526922680748};\\\", \\\"{x:1614,y:972,t:1526922681301};\\\", \\\"{x:1614,y:971,t:1526922681332};\\\", \\\"{x:1614,y:970,t:1526922681379};\\\", \\\"{x:1614,y:969,t:1526922681411};\\\", \\\"{x:1614,y:968,t:1526922681420};\\\", \\\"{x:1614,y:967,t:1526922681435};\\\", \\\"{x:1614,y:966,t:1526922681475};\\\", \\\"{x:1614,y:965,t:1526922681484};\\\", \\\"{x:1614,y:964,t:1526922681499};\\\", \\\"{x:1614,y:963,t:1526922681540};\\\", \\\"{x:1614,y:962,t:1526922681549};\\\", \\\"{x:1614,y:961,t:1526922681565};\\\", \\\"{x:1614,y:960,t:1526922681587};\\\", \\\"{x:1614,y:959,t:1526922681599};\\\", \\\"{x:1614,y:958,t:1526922681627};\\\", \\\"{x:1614,y:957,t:1526922681643};\\\", \\\"{x:1614,y:956,t:1526922681652};\\\", \\\"{x:1614,y:955,t:1526922681666};\\\", \\\"{x:1614,y:952,t:1526922681682};\\\", \\\"{x:1614,y:951,t:1526922681699};\\\", \\\"{x:1614,y:949,t:1526922681715};\\\", \\\"{x:1614,y:946,t:1526922681732};\\\", \\\"{x:1614,y:945,t:1526922681748};\\\", \\\"{x:1614,y:944,t:1526922681766};\\\", \\\"{x:1614,y:942,t:1526922681782};\\\", \\\"{x:1615,y:938,t:1526922681799};\\\", \\\"{x:1615,y:937,t:1526922681819};\\\", \\\"{x:1615,y:936,t:1526922681833};\\\", \\\"{x:1616,y:935,t:1526922681849};\\\", \\\"{x:1616,y:933,t:1526922681875};\\\", \\\"{x:1616,y:932,t:1526922681907};\\\", \\\"{x:1616,y:930,t:1526922681915};\\\", \\\"{x:1616,y:929,t:1526922681933};\\\", \\\"{x:1616,y:928,t:1526922681948};\\\", \\\"{x:1616,y:927,t:1526922681966};\\\", \\\"{x:1616,y:926,t:1526922681982};\\\", \\\"{x:1616,y:923,t:1526922682000};\\\", \\\"{x:1616,y:922,t:1526922682019};\\\", \\\"{x:1616,y:920,t:1526922682035};\\\", \\\"{x:1616,y:919,t:1526922682068};\\\", \\\"{x:1616,y:918,t:1526922682084};\\\", \\\"{x:1616,y:916,t:1526922682108};\\\", \\\"{x:1616,y:915,t:1526922682148};\\\", \\\"{x:1616,y:914,t:1526922682156};\\\", \\\"{x:1616,y:913,t:1526922682167};\\\", \\\"{x:1616,y:911,t:1526922682204};\\\", \\\"{x:1617,y:910,t:1526922682236};\\\", \\\"{x:1617,y:908,t:1526922682284};\\\", \\\"{x:1617,y:907,t:1526922682307};\\\", \\\"{x:1617,y:905,t:1526922682347};\\\", \\\"{x:1617,y:901,t:1526922682379};\\\", \\\"{x:1617,y:900,t:1526922682428};\\\", \\\"{x:1617,y:898,t:1526922682492};\\\", \\\"{x:1617,y:897,t:1526922682532};\\\", \\\"{x:1617,y:895,t:1526922682627};\\\", \\\"{x:1617,y:894,t:1526922682676};\\\", \\\"{x:1617,y:892,t:1526922682748};\\\", \\\"{x:1617,y:891,t:1526922682772};\\\", \\\"{x:1617,y:889,t:1526922682828};\\\", \\\"{x:1617,y:888,t:1526922682908};\\\", \\\"{x:1617,y:886,t:1526922682980};\\\", \\\"{x:1617,y:885,t:1526922683044};\\\", \\\"{x:1617,y:884,t:1526922683100};\\\", \\\"{x:1616,y:883,t:1526922683115};\\\", \\\"{x:1616,y:882,t:1526922683156};\\\", \\\"{x:1616,y:880,t:1526922683195};\\\", \\\"{x:1616,y:879,t:1526922683235};\\\", \\\"{x:1615,y:878,t:1526922683308};\\\", \\\"{x:1615,y:877,t:1526922683331};\\\", \\\"{x:1615,y:875,t:1526922683339};\\\", \\\"{x:1615,y:874,t:1526922683355};\\\", \\\"{x:1615,y:873,t:1526922683379};\\\", \\\"{x:1615,y:871,t:1526922683395};\\\", \\\"{x:1615,y:870,t:1526922683403};\\\", \\\"{x:1615,y:868,t:1526922683419};\\\", \\\"{x:1615,y:866,t:1526922683435};\\\", \\\"{x:1615,y:863,t:1526922683451};\\\", \\\"{x:1615,y:861,t:1526922683469};\\\", \\\"{x:1615,y:860,t:1526922683486};\\\", \\\"{x:1615,y:858,t:1526922683502};\\\", \\\"{x:1615,y:857,t:1526922683518};\\\", \\\"{x:1615,y:856,t:1526922683536};\\\", \\\"{x:1615,y:855,t:1526922683553};\\\", \\\"{x:1615,y:854,t:1526922683569};\\\", \\\"{x:1616,y:852,t:1526922683585};\\\", \\\"{x:1616,y:851,t:1526922683627};\\\", \\\"{x:1616,y:850,t:1526922683668};\\\", \\\"{x:1616,y:849,t:1526922683684};\\\", \\\"{x:1616,y:848,t:1526922683748};\\\", \\\"{x:1616,y:847,t:1526922683763};\\\", \\\"{x:1616,y:846,t:1526922683796};\\\", \\\"{x:1616,y:845,t:1526922683844};\\\", \\\"{x:1616,y:844,t:1526922683917};\\\", \\\"{x:1616,y:843,t:1526922683940};\\\", \\\"{x:1616,y:842,t:1526922683980};\\\", \\\"{x:1616,y:843,t:1526922685411};\\\", \\\"{x:1616,y:845,t:1526922685422};\\\", \\\"{x:1613,y:848,t:1526922685439};\\\", \\\"{x:1610,y:854,t:1526922685456};\\\", \\\"{x:1607,y:860,t:1526922685473};\\\", \\\"{x:1603,y:866,t:1526922685490};\\\", \\\"{x:1597,y:876,t:1526922685506};\\\", \\\"{x:1594,y:883,t:1526922685522};\\\", \\\"{x:1591,y:888,t:1526922685540};\\\", \\\"{x:1587,y:895,t:1526922685555};\\\", \\\"{x:1586,y:899,t:1526922685573};\\\", \\\"{x:1584,y:903,t:1526922685590};\\\", \\\"{x:1581,y:907,t:1526922685606};\\\", \\\"{x:1580,y:910,t:1526922685623};\\\", \\\"{x:1577,y:915,t:1526922685640};\\\", \\\"{x:1575,y:919,t:1526922685657};\\\", \\\"{x:1574,y:922,t:1526922685673};\\\", \\\"{x:1572,y:924,t:1526922685690};\\\", \\\"{x:1572,y:925,t:1526922685707};\\\", \\\"{x:1571,y:927,t:1526922685723};\\\", \\\"{x:1571,y:928,t:1526922685740};\\\", \\\"{x:1571,y:930,t:1526922685757};\\\", \\\"{x:1568,y:932,t:1526922685773};\\\", \\\"{x:1567,y:935,t:1526922685790};\\\", \\\"{x:1567,y:938,t:1526922685807};\\\", \\\"{x:1565,y:939,t:1526922685824};\\\", \\\"{x:1563,y:942,t:1526922685840};\\\", \\\"{x:1562,y:942,t:1526922685857};\\\", \\\"{x:1562,y:944,t:1526922685874};\\\", \\\"{x:1561,y:947,t:1526922685890};\\\", \\\"{x:1559,y:949,t:1526922685907};\\\", \\\"{x:1555,y:951,t:1526922685924};\\\", \\\"{x:1553,y:954,t:1526922685940};\\\", \\\"{x:1551,y:956,t:1526922685957};\\\", \\\"{x:1548,y:957,t:1526922685974};\\\", \\\"{x:1548,y:958,t:1526922685990};\\\", \\\"{x:1547,y:958,t:1526922686007};\\\", \\\"{x:1546,y:958,t:1526922686115};\\\", \\\"{x:1545,y:958,t:1526922686268};\\\", \\\"{x:1544,y:957,t:1526922686299};\\\", \\\"{x:1544,y:956,t:1526922686307};\\\", \\\"{x:1544,y:952,t:1526922686325};\\\", \\\"{x:1544,y:950,t:1526922686341};\\\", \\\"{x:1544,y:948,t:1526922686358};\\\", \\\"{x:1544,y:945,t:1526922686375};\\\", \\\"{x:1542,y:940,t:1526922686391};\\\", \\\"{x:1542,y:937,t:1526922686408};\\\", \\\"{x:1542,y:932,t:1526922686425};\\\", \\\"{x:1542,y:925,t:1526922686441};\\\", \\\"{x:1542,y:921,t:1526922686457};\\\", \\\"{x:1541,y:916,t:1526922686475};\\\", \\\"{x:1541,y:911,t:1526922686490};\\\", \\\"{x:1540,y:906,t:1526922686508};\\\", \\\"{x:1540,y:903,t:1526922686525};\\\", \\\"{x:1540,y:900,t:1526922686542};\\\", \\\"{x:1540,y:896,t:1526922686558};\\\", \\\"{x:1540,y:893,t:1526922686575};\\\", \\\"{x:1540,y:891,t:1526922686592};\\\", \\\"{x:1540,y:886,t:1526922686608};\\\", \\\"{x:1540,y:882,t:1526922686625};\\\", \\\"{x:1540,y:879,t:1526922686643};\\\", \\\"{x:1540,y:876,t:1526922686658};\\\", \\\"{x:1540,y:870,t:1526922686675};\\\", \\\"{x:1540,y:865,t:1526922686692};\\\", \\\"{x:1540,y:861,t:1526922686709};\\\", \\\"{x:1540,y:854,t:1526922686725};\\\", \\\"{x:1540,y:849,t:1526922686742};\\\", \\\"{x:1540,y:844,t:1526922686759};\\\", \\\"{x:1540,y:838,t:1526922686775};\\\", \\\"{x:1538,y:831,t:1526922686792};\\\", \\\"{x:1537,y:824,t:1526922686809};\\\", \\\"{x:1535,y:820,t:1526922686825};\\\", \\\"{x:1535,y:817,t:1526922686842};\\\", \\\"{x:1533,y:813,t:1526922686859};\\\", \\\"{x:1530,y:804,t:1526922686875};\\\", \\\"{x:1529,y:799,t:1526922686892};\\\", \\\"{x:1529,y:796,t:1526922686909};\\\", \\\"{x:1528,y:791,t:1526922686926};\\\", \\\"{x:1527,y:787,t:1526922686942};\\\", \\\"{x:1526,y:784,t:1526922686959};\\\", \\\"{x:1526,y:781,t:1526922686976};\\\", \\\"{x:1525,y:777,t:1526922686992};\\\", \\\"{x:1525,y:775,t:1526922687012};\\\", \\\"{x:1525,y:774,t:1526922687026};\\\", \\\"{x:1525,y:767,t:1526922687042};\\\", \\\"{x:1525,y:764,t:1526922687059};\\\", \\\"{x:1525,y:760,t:1526922687075};\\\", \\\"{x:1525,y:756,t:1526922687093};\\\", \\\"{x:1526,y:754,t:1526922687109};\\\", \\\"{x:1527,y:748,t:1526922687126};\\\", \\\"{x:1529,y:745,t:1526922687143};\\\", \\\"{x:1530,y:740,t:1526922687159};\\\", \\\"{x:1532,y:735,t:1526922687176};\\\", \\\"{x:1532,y:732,t:1526922687193};\\\", \\\"{x:1535,y:726,t:1526922687209};\\\", \\\"{x:1536,y:723,t:1526922687227};\\\", \\\"{x:1537,y:722,t:1526922687292};\\\", \\\"{x:1537,y:719,t:1526922687300};\\\", \\\"{x:1537,y:718,t:1526922687310};\\\", \\\"{x:1537,y:716,t:1526922687326};\\\", \\\"{x:1537,y:715,t:1526922687347};\\\", \\\"{x:1537,y:714,t:1526922687360};\\\", \\\"{x:1537,y:711,t:1526922687376};\\\", \\\"{x:1537,y:709,t:1526922687393};\\\", \\\"{x:1537,y:705,t:1526922687410};\\\", \\\"{x:1537,y:700,t:1526922687427};\\\", \\\"{x:1537,y:698,t:1526922687443};\\\", \\\"{x:1537,y:688,t:1526922687460};\\\", \\\"{x:1537,y:683,t:1526922687477};\\\", \\\"{x:1537,y:680,t:1526922687493};\\\", \\\"{x:1537,y:677,t:1526922687510};\\\", \\\"{x:1537,y:676,t:1526922687528};\\\", \\\"{x:1537,y:675,t:1526922687543};\\\", \\\"{x:1536,y:675,t:1526922687579};\\\", \\\"{x:1535,y:675,t:1526922687594};\\\", \\\"{x:1525,y:683,t:1526922687610};\\\", \\\"{x:1514,y:693,t:1526922687627};\\\", \\\"{x:1494,y:707,t:1526922687643};\\\", \\\"{x:1476,y:715,t:1526922687660};\\\", \\\"{x:1455,y:725,t:1526922687677};\\\", \\\"{x:1436,y:730,t:1526922687694};\\\", \\\"{x:1416,y:741,t:1526922687710};\\\", \\\"{x:1390,y:746,t:1526922687727};\\\", \\\"{x:1357,y:750,t:1526922687744};\\\", \\\"{x:1311,y:753,t:1526922687760};\\\", \\\"{x:1231,y:753,t:1526922687778};\\\", \\\"{x:1142,y:753,t:1526922687794};\\\", \\\"{x:1042,y:753,t:1526922687811};\\\", \\\"{x:953,y:753,t:1526922687827};\\\", \\\"{x:784,y:753,t:1526922687844};\\\", \\\"{x:695,y:752,t:1526922687861};\\\", \\\"{x:603,y:741,t:1526922687877};\\\", \\\"{x:516,y:735,t:1526922687894};\\\", \\\"{x:415,y:731,t:1526922687912};\\\", \\\"{x:333,y:726,t:1526922687928};\\\", \\\"{x:290,y:723,t:1526922687950};\\\", \\\"{x:269,y:718,t:1526922687968};\\\", \\\"{x:257,y:712,t:1526922687983};\\\", \\\"{x:254,y:710,t:1526922688001};\\\", \\\"{x:253,y:709,t:1526922688018};\\\", \\\"{x:253,y:705,t:1526922688034};\\\", \\\"{x:253,y:704,t:1526922688051};\\\", \\\"{x:253,y:703,t:1526922688083};\\\", \\\"{x:253,y:701,t:1526922688091};\\\", \\\"{x:253,y:695,t:1526922688101};\\\", \\\"{x:258,y:687,t:1526922688118};\\\", \\\"{x:265,y:682,t:1526922688134};\\\", \\\"{x:271,y:677,t:1526922688151};\\\", \\\"{x:277,y:673,t:1526922688168};\\\", \\\"{x:286,y:667,t:1526922688184};\\\", \\\"{x:296,y:660,t:1526922688201};\\\", \\\"{x:304,y:654,t:1526922688218};\\\", \\\"{x:313,y:648,t:1526922688234};\\\", \\\"{x:317,y:644,t:1526922688251};\\\", \\\"{x:317,y:643,t:1526922688268};\\\", \\\"{x:320,y:642,t:1526922688285};\\\", \\\"{x:323,y:639,t:1526922688302};\\\", \\\"{x:327,y:638,t:1526922688318};\\\", \\\"{x:329,y:636,t:1526922688335};\\\", \\\"{x:333,y:634,t:1526922688352};\\\", \\\"{x:337,y:631,t:1526922688369};\\\", \\\"{x:341,y:629,t:1526922688384};\\\", \\\"{x:344,y:627,t:1526922688402};\\\", \\\"{x:349,y:623,t:1526922688419};\\\", \\\"{x:354,y:620,t:1526922688434};\\\", \\\"{x:358,y:618,t:1526922688453};\\\", \\\"{x:360,y:617,t:1526922688469};\\\", \\\"{x:361,y:616,t:1526922688485};\\\", \\\"{x:362,y:616,t:1526922688531};\\\", \\\"{x:364,y:615,t:1526922688539};\\\", \\\"{x:365,y:614,t:1526922688551};\\\", \\\"{x:371,y:611,t:1526922688569};\\\", \\\"{x:376,y:609,t:1526922688585};\\\", \\\"{x:379,y:608,t:1526922688601};\\\", \\\"{x:381,y:606,t:1526922688618};\\\", \\\"{x:383,y:606,t:1526922688634};\\\", \\\"{x:385,y:605,t:1526922688659};\\\", \\\"{x:386,y:604,t:1526922688668};\\\", \\\"{x:389,y:603,t:1526922688685};\\\", \\\"{x:393,y:602,t:1526922688702};\\\", \\\"{x:396,y:601,t:1526922688718};\\\", \\\"{x:399,y:600,t:1526922688735};\\\", \\\"{x:400,y:600,t:1526922688752};\\\", \\\"{x:403,y:599,t:1526922688767};\\\", \\\"{x:404,y:598,t:1526922688785};\\\", \\\"{x:405,y:597,t:1526922688802};\\\", \\\"{x:405,y:599,t:1526922689595};\\\", \\\"{x:406,y:602,t:1526922689603};\\\", \\\"{x:409,y:607,t:1526922689619};\\\", \\\"{x:412,y:613,t:1526922689636};\\\", \\\"{x:416,y:618,t:1526922689652};\\\", \\\"{x:419,y:621,t:1526922689670};\\\", \\\"{x:423,y:625,t:1526922689686};\\\", \\\"{x:427,y:629,t:1526922689702};\\\", \\\"{x:431,y:633,t:1526922689719};\\\", \\\"{x:440,y:646,t:1526922689736};\\\", \\\"{x:452,y:655,t:1526922689753};\\\", \\\"{x:467,y:668,t:1526922689769};\\\", \\\"{x:474,y:673,t:1526922689786};\\\", \\\"{x:486,y:679,t:1526922689802};\\\", \\\"{x:496,y:684,t:1526922689819};\\\", \\\"{x:498,y:685,t:1526922689836};\\\", \\\"{x:499,y:685,t:1526922689853};\\\", \\\"{x:501,y:686,t:1526922690019};\\\", \\\"{x:501,y:687,t:1526922690036};\\\", \\\"{x:501,y:688,t:1526922690053};\\\", \\\"{x:501,y:691,t:1526922690069};\\\", \\\"{x:504,y:697,t:1526922690086};\\\", \\\"{x:506,y:700,t:1526922690103};\\\", \\\"{x:507,y:703,t:1526922690119};\\\", \\\"{x:509,y:705,t:1526922690136};\\\", \\\"{x:509,y:707,t:1526922690153};\\\", \\\"{x:510,y:707,t:1526922690170};\\\", \\\"{x:511,y:708,t:1526922690187};\\\", \\\"{x:511,y:709,t:1526922690212};\\\", \\\"{x:511,y:711,t:1526922690219};\\\", \\\"{x:512,y:711,t:1526922690236};\\\", \\\"{x:512,y:712,t:1526922690253};\\\", \\\"{x:512,y:713,t:1526922690275};\\\", \\\"{x:512,y:714,t:1526922690307};\\\", \\\"{x:513,y:714,t:1526922690355};\\\" ] }, { \\\"rt\\\": 15543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 138353, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -A -6\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:714,t:1526922692339};\\\", \\\"{x:511,y:715,t:1526922692354};\\\", \\\"{x:505,y:717,t:1526922692371};\\\", \\\"{x:496,y:721,t:1526922692388};\\\", \\\"{x:489,y:722,t:1526922692405};\\\", \\\"{x:482,y:723,t:1526922692421};\\\", \\\"{x:475,y:725,t:1526922692438};\\\", \\\"{x:473,y:726,t:1526922692455};\\\", \\\"{x:471,y:726,t:1526922692471};\\\", \\\"{x:468,y:726,t:1526922692488};\\\", \\\"{x:460,y:726,t:1526922692505};\\\", \\\"{x:455,y:726,t:1526922692521};\\\", \\\"{x:442,y:726,t:1526922692539};\\\", \\\"{x:423,y:725,t:1526922692555};\\\", \\\"{x:411,y:724,t:1526922692571};\\\", \\\"{x:400,y:724,t:1526922692588};\\\", \\\"{x:385,y:724,t:1526922692604};\\\", \\\"{x:373,y:724,t:1526922692621};\\\", \\\"{x:363,y:724,t:1526922692638};\\\", \\\"{x:345,y:724,t:1526922692655};\\\", \\\"{x:333,y:727,t:1526922692671};\\\", \\\"{x:326,y:728,t:1526922692688};\\\", \\\"{x:313,y:728,t:1526922692705};\\\", \\\"{x:307,y:729,t:1526922692721};\\\", \\\"{x:301,y:730,t:1526922692739};\\\", \\\"{x:294,y:731,t:1526922692755};\\\", \\\"{x:293,y:731,t:1526922692771};\\\", \\\"{x:292,y:732,t:1526922692788};\\\", \\\"{x:291,y:732,t:1526922692805};\\\", \\\"{x:289,y:732,t:1526922692820};\\\", \\\"{x:289,y:733,t:1526922692838};\\\", \\\"{x:287,y:734,t:1526922692859};\\\", \\\"{x:286,y:734,t:1526922692899};\\\", \\\"{x:284,y:734,t:1526922692915};\\\", \\\"{x:284,y:735,t:1526922693179};\\\", \\\"{x:283,y:735,t:1526922693195};\\\", \\\"{x:283,y:736,t:1526922693211};\\\", \\\"{x:282,y:736,t:1526922693668};\\\", \\\"{x:281,y:737,t:1526922694468};\\\", \\\"{x:281,y:738,t:1526922694515};\\\", \\\"{x:280,y:738,t:1526922694547};\\\", \\\"{x:280,y:739,t:1526922695228};\\\", \\\"{x:279,y:739,t:1526922696083};\\\", \\\"{x:278,y:740,t:1526922696172};\\\", \\\"{x:277,y:740,t:1526922696219};\\\", \\\"{x:277,y:741,t:1526922696243};\\\", \\\"{x:276,y:742,t:1526922696259};\\\", \\\"{x:275,y:743,t:1526922696708};\\\", \\\"{x:282,y:743,t:1526922698571};\\\", \\\"{x:297,y:743,t:1526922698578};\\\", \\\"{x:321,y:740,t:1526922698591};\\\", \\\"{x:371,y:732,t:1526922698609};\\\", \\\"{x:407,y:724,t:1526922698626};\\\", \\\"{x:476,y:718,t:1526922698642};\\\", \\\"{x:551,y:708,t:1526922698659};\\\", \\\"{x:605,y:693,t:1526922698675};\\\", \\\"{x:654,y:674,t:1526922698694};\\\", \\\"{x:697,y:664,t:1526922698710};\\\", \\\"{x:731,y:652,t:1526922698727};\\\", \\\"{x:760,y:641,t:1526922698743};\\\", \\\"{x:780,y:635,t:1526922698759};\\\", \\\"{x:798,y:629,t:1526922698776};\\\", \\\"{x:811,y:625,t:1526922698794};\\\", \\\"{x:818,y:621,t:1526922698810};\\\", \\\"{x:818,y:620,t:1526922698826};\\\", \\\"{x:819,y:618,t:1526922698843};\\\", \\\"{x:818,y:617,t:1526922698860};\\\", \\\"{x:818,y:615,t:1526922698877};\\\", \\\"{x:824,y:610,t:1526922698893};\\\", \\\"{x:838,y:604,t:1526922698910};\\\", \\\"{x:859,y:600,t:1526922698928};\\\", \\\"{x:877,y:597,t:1526922698944};\\\", \\\"{x:903,y:597,t:1526922698961};\\\", \\\"{x:918,y:594,t:1526922698977};\\\", \\\"{x:940,y:594,t:1526922698993};\\\", \\\"{x:978,y:594,t:1526922699011};\\\", \\\"{x:1020,y:592,t:1526922699027};\\\", \\\"{x:1084,y:595,t:1526922699043};\\\", \\\"{x:1123,y:595,t:1526922699061};\\\", \\\"{x:1150,y:595,t:1526922699077};\\\", \\\"{x:1171,y:596,t:1526922699094};\\\", \\\"{x:1186,y:596,t:1526922699110};\\\", \\\"{x:1195,y:598,t:1526922699126};\\\", \\\"{x:1196,y:599,t:1526922699143};\\\", \\\"{x:1202,y:599,t:1526922699160};\\\", \\\"{x:1211,y:599,t:1526922699176};\\\", \\\"{x:1221,y:599,t:1526922699193};\\\", \\\"{x:1237,y:598,t:1526922699210};\\\", \\\"{x:1259,y:596,t:1526922699226};\\\", \\\"{x:1280,y:591,t:1526922699243};\\\", \\\"{x:1293,y:589,t:1526922699261};\\\", \\\"{x:1299,y:588,t:1526922699277};\\\", \\\"{x:1301,y:586,t:1526922699293};\\\", \\\"{x:1302,y:586,t:1526922699339};\\\", \\\"{x:1304,y:585,t:1526922699347};\\\", \\\"{x:1306,y:583,t:1526922699361};\\\", \\\"{x:1312,y:580,t:1526922699378};\\\", \\\"{x:1317,y:578,t:1526922699393};\\\", \\\"{x:1318,y:576,t:1526922699410};\\\", \\\"{x:1320,y:575,t:1526922699427};\\\", \\\"{x:1320,y:574,t:1526922699444};\\\", \\\"{x:1321,y:574,t:1526922699460};\\\", \\\"{x:1321,y:573,t:1526922699483};\\\", \\\"{x:1322,y:571,t:1526922699507};\\\", \\\"{x:1322,y:570,t:1526922699515};\\\", \\\"{x:1322,y:569,t:1526922699540};\\\", \\\"{x:1322,y:567,t:1526922699547};\\\", \\\"{x:1323,y:566,t:1526922699651};\\\", \\\"{x:1323,y:565,t:1526922699667};\\\", \\\"{x:1323,y:563,t:1526922699683};\\\", \\\"{x:1323,y:562,t:1526922699694};\\\", \\\"{x:1323,y:561,t:1526922699711};\\\", \\\"{x:1323,y:559,t:1526922699728};\\\", \\\"{x:1322,y:557,t:1526922699745};\\\", \\\"{x:1321,y:555,t:1526922699761};\\\", \\\"{x:1320,y:553,t:1526922699777};\\\", \\\"{x:1319,y:551,t:1526922699795};\\\", \\\"{x:1318,y:548,t:1526922699811};\\\", \\\"{x:1317,y:542,t:1526922699827};\\\", \\\"{x:1317,y:539,t:1526922699844};\\\", \\\"{x:1316,y:537,t:1526922699860};\\\", \\\"{x:1316,y:535,t:1526922699878};\\\", \\\"{x:1314,y:533,t:1526922699895};\\\", \\\"{x:1312,y:530,t:1526922699911};\\\", \\\"{x:1312,y:528,t:1526922699927};\\\", \\\"{x:1311,y:527,t:1526922699944};\\\", \\\"{x:1310,y:523,t:1526922699961};\\\", \\\"{x:1309,y:522,t:1526922699977};\\\", \\\"{x:1308,y:522,t:1526922699994};\\\", \\\"{x:1308,y:521,t:1526922700010};\\\", \\\"{x:1308,y:517,t:1526922700027};\\\", \\\"{x:1308,y:515,t:1526922700044};\\\", \\\"{x:1308,y:514,t:1526922700060};\\\", \\\"{x:1308,y:511,t:1526922700077};\\\", \\\"{x:1308,y:514,t:1526922700147};\\\", \\\"{x:1308,y:517,t:1526922700160};\\\", \\\"{x:1305,y:522,t:1526922700178};\\\", \\\"{x:1305,y:529,t:1526922700194};\\\", \\\"{x:1301,y:538,t:1526922700211};\\\", \\\"{x:1301,y:550,t:1526922700228};\\\", \\\"{x:1300,y:560,t:1526922700245};\\\", \\\"{x:1298,y:566,t:1526922700261};\\\", \\\"{x:1297,y:577,t:1526922700277};\\\", \\\"{x:1295,y:590,t:1526922700295};\\\", \\\"{x:1295,y:605,t:1526922700312};\\\", \\\"{x:1297,y:623,t:1526922700327};\\\", \\\"{x:1299,y:641,t:1526922700344};\\\", \\\"{x:1300,y:658,t:1526922700361};\\\", \\\"{x:1300,y:669,t:1526922700378};\\\", \\\"{x:1300,y:682,t:1526922700394};\\\", \\\"{x:1300,y:704,t:1526922700410};\\\", \\\"{x:1304,y:714,t:1526922700427};\\\", \\\"{x:1307,y:723,t:1526922700444};\\\", \\\"{x:1314,y:734,t:1526922700461};\\\", \\\"{x:1316,y:742,t:1526922700477};\\\", \\\"{x:1318,y:747,t:1526922700494};\\\", \\\"{x:1318,y:749,t:1526922700511};\\\", \\\"{x:1318,y:750,t:1526922700539};\\\", \\\"{x:1318,y:751,t:1526922700555};\\\", \\\"{x:1318,y:752,t:1526922700595};\\\", \\\"{x:1318,y:753,t:1526922700611};\\\", \\\"{x:1317,y:755,t:1526922700629};\\\", \\\"{x:1317,y:756,t:1526922700651};\\\", \\\"{x:1317,y:757,t:1526922700661};\\\", \\\"{x:1316,y:759,t:1526922700684};\\\", \\\"{x:1315,y:759,t:1526922700694};\\\", \\\"{x:1314,y:761,t:1526922700715};\\\", \\\"{x:1313,y:762,t:1526922700756};\\\", \\\"{x:1312,y:763,t:1526922700779};\\\", \\\"{x:1311,y:764,t:1526922700811};\\\", \\\"{x:1311,y:762,t:1526922701867};\\\", \\\"{x:1311,y:761,t:1526922701878};\\\", \\\"{x:1311,y:757,t:1526922701896};\\\", \\\"{x:1311,y:751,t:1526922701913};\\\", \\\"{x:1310,y:744,t:1526922701930};\\\", \\\"{x:1309,y:734,t:1526922701946};\\\", \\\"{x:1305,y:718,t:1526922701963};\\\", \\\"{x:1299,y:679,t:1526922701979};\\\", \\\"{x:1298,y:653,t:1526922701995};\\\", \\\"{x:1297,y:633,t:1526922702012};\\\", \\\"{x:1297,y:613,t:1526922702030};\\\", \\\"{x:1297,y:593,t:1526922702045};\\\", \\\"{x:1295,y:576,t:1526922702062};\\\", \\\"{x:1295,y:564,t:1526922702079};\\\", \\\"{x:1294,y:555,t:1526922702095};\\\", \\\"{x:1293,y:550,t:1526922702112};\\\", \\\"{x:1292,y:546,t:1526922702130};\\\", \\\"{x:1292,y:544,t:1526922702145};\\\", \\\"{x:1291,y:542,t:1526922702162};\\\", \\\"{x:1290,y:543,t:1526922702235};\\\", \\\"{x:1289,y:551,t:1526922702245};\\\", \\\"{x:1288,y:569,t:1526922702262};\\\", \\\"{x:1285,y:584,t:1526922702279};\\\", \\\"{x:1283,y:602,t:1526922702296};\\\", \\\"{x:1275,y:628,t:1526922702312};\\\", \\\"{x:1269,y:653,t:1526922702330};\\\", \\\"{x:1263,y:674,t:1526922702346};\\\", \\\"{x:1252,y:690,t:1526922702363};\\\", \\\"{x:1223,y:719,t:1526922702379};\\\", \\\"{x:1199,y:731,t:1526922702397};\\\", \\\"{x:1161,y:739,t:1526922702413};\\\", \\\"{x:1085,y:752,t:1526922702430};\\\", \\\"{x:1005,y:761,t:1526922702447};\\\", \\\"{x:874,y:765,t:1526922702462};\\\", \\\"{x:722,y:765,t:1526922702479};\\\", \\\"{x:581,y:747,t:1526922702496};\\\", \\\"{x:456,y:730,t:1526922702513};\\\", \\\"{x:363,y:709,t:1526922702529};\\\", \\\"{x:327,y:701,t:1526922702546};\\\", \\\"{x:308,y:693,t:1526922702559};\\\", \\\"{x:306,y:691,t:1526922702576};\\\", \\\"{x:306,y:685,t:1526922702593};\\\", \\\"{x:307,y:679,t:1526922702610};\\\", \\\"{x:307,y:676,t:1526922702626};\\\", \\\"{x:308,y:671,t:1526922702643};\\\", \\\"{x:296,y:655,t:1526922702659};\\\", \\\"{x:282,y:644,t:1526922702676};\\\", \\\"{x:268,y:636,t:1526922702696};\\\", \\\"{x:260,y:628,t:1526922702713};\\\", \\\"{x:253,y:623,t:1526922702729};\\\", \\\"{x:251,y:619,t:1526922702746};\\\", \\\"{x:243,y:610,t:1526922702762};\\\", \\\"{x:241,y:606,t:1526922702779};\\\", \\\"{x:237,y:600,t:1526922702796};\\\", \\\"{x:236,y:598,t:1526922702813};\\\", \\\"{x:235,y:597,t:1526922702829};\\\", \\\"{x:235,y:596,t:1526922702846};\\\", \\\"{x:235,y:594,t:1526922702864};\\\", \\\"{x:235,y:593,t:1526922702879};\\\", \\\"{x:238,y:589,t:1526922702896};\\\", \\\"{x:244,y:585,t:1526922702913};\\\", \\\"{x:253,y:579,t:1526922702929};\\\", \\\"{x:264,y:574,t:1526922702947};\\\", \\\"{x:281,y:569,t:1526922702963};\\\", \\\"{x:288,y:568,t:1526922702979};\\\", \\\"{x:293,y:568,t:1526922702996};\\\", \\\"{x:300,y:567,t:1526922703014};\\\", \\\"{x:307,y:567,t:1526922703029};\\\", \\\"{x:321,y:566,t:1526922703046};\\\", \\\"{x:329,y:562,t:1526922703064};\\\", \\\"{x:337,y:562,t:1526922703079};\\\", \\\"{x:347,y:561,t:1526922703096};\\\", \\\"{x:354,y:561,t:1526922703113};\\\", \\\"{x:355,y:561,t:1526922703130};\\\", \\\"{x:358,y:559,t:1526922703146};\\\", \\\"{x:361,y:558,t:1526922703163};\\\", \\\"{x:361,y:557,t:1526922703259};\\\", \\\"{x:362,y:556,t:1526922703266};\\\", \\\"{x:362,y:555,t:1526922703279};\\\", \\\"{x:364,y:552,t:1526922703296};\\\", \\\"{x:366,y:549,t:1526922703314};\\\", \\\"{x:369,y:545,t:1526922703329};\\\", \\\"{x:373,y:542,t:1526922703346};\\\", \\\"{x:379,y:539,t:1526922703364};\\\", \\\"{x:383,y:537,t:1526922703381};\\\", \\\"{x:384,y:537,t:1526922703396};\\\", \\\"{x:387,y:535,t:1526922703414};\\\", \\\"{x:388,y:535,t:1526922703430};\\\", \\\"{x:389,y:533,t:1526922703448};\\\", \\\"{x:392,y:533,t:1526922703463};\\\", \\\"{x:393,y:534,t:1526922703947};\\\", \\\"{x:393,y:538,t:1526922703963};\\\", \\\"{x:394,y:545,t:1526922703981};\\\", \\\"{x:398,y:555,t:1526922703998};\\\", \\\"{x:399,y:563,t:1526922704014};\\\", \\\"{x:403,y:575,t:1526922704030};\\\", \\\"{x:406,y:584,t:1526922704048};\\\", \\\"{x:411,y:590,t:1526922704064};\\\", \\\"{x:420,y:600,t:1526922704080};\\\", \\\"{x:429,y:610,t:1526922704097};\\\", \\\"{x:438,y:616,t:1526922704114};\\\", \\\"{x:441,y:622,t:1526922704131};\\\", \\\"{x:468,y:637,t:1526922704148};\\\", \\\"{x:487,y:648,t:1526922704164};\\\", \\\"{x:519,y:661,t:1526922704181};\\\", \\\"{x:556,y:675,t:1526922704198};\\\", \\\"{x:608,y:685,t:1526922704215};\\\", \\\"{x:658,y:692,t:1526922704231};\\\", \\\"{x:722,y:698,t:1526922704247};\\\", \\\"{x:769,y:698,t:1526922704264};\\\", \\\"{x:822,y:698,t:1526922704281};\\\", \\\"{x:868,y:692,t:1526922704297};\\\", \\\"{x:914,y:675,t:1526922704314};\\\", \\\"{x:954,y:659,t:1526922704331};\\\", \\\"{x:992,y:632,t:1526922704348};\\\", \\\"{x:1011,y:618,t:1526922704364};\\\", \\\"{x:1025,y:607,t:1526922704381};\\\", \\\"{x:1031,y:603,t:1526922704397};\\\", \\\"{x:1036,y:599,t:1526922704414};\\\", \\\"{x:1041,y:594,t:1526922704432};\\\", \\\"{x:1045,y:588,t:1526922704447};\\\", \\\"{x:1051,y:578,t:1526922704465};\\\", \\\"{x:1059,y:569,t:1526922704481};\\\", \\\"{x:1068,y:563,t:1526922704498};\\\", \\\"{x:1080,y:555,t:1526922704514};\\\", \\\"{x:1104,y:548,t:1526922704531};\\\", \\\"{x:1122,y:545,t:1526922704548};\\\", \\\"{x:1146,y:541,t:1526922704564};\\\", \\\"{x:1174,y:534,t:1526922704581};\\\", \\\"{x:1205,y:530,t:1526922704597};\\\", \\\"{x:1234,y:530,t:1526922704615};\\\", \\\"{x:1261,y:530,t:1526922704631};\\\", \\\"{x:1276,y:530,t:1526922704648};\\\", \\\"{x:1279,y:530,t:1526922704665};\\\", \\\"{x:1277,y:533,t:1526922704723};\\\", \\\"{x:1273,y:534,t:1526922704731};\\\", \\\"{x:1269,y:539,t:1526922704748};\\\", \\\"{x:1261,y:547,t:1526922704764};\\\", \\\"{x:1250,y:560,t:1526922704782};\\\", \\\"{x:1234,y:575,t:1526922704799};\\\", \\\"{x:1211,y:592,t:1526922704815};\\\", \\\"{x:1179,y:608,t:1526922704832};\\\", \\\"{x:1136,y:635,t:1526922704848};\\\", \\\"{x:1095,y:659,t:1526922704865};\\\", \\\"{x:1075,y:676,t:1526922704881};\\\", \\\"{x:1060,y:683,t:1526922704898};\\\", \\\"{x:1050,y:690,t:1526922704915};\\\", \\\"{x:1046,y:694,t:1526922704932};\\\", \\\"{x:1045,y:695,t:1526922704955};\\\", \\\"{x:1045,y:696,t:1526922704964};\\\", \\\"{x:1043,y:701,t:1526922704981};\\\", \\\"{x:1041,y:711,t:1526922704999};\\\", \\\"{x:1034,y:724,t:1526922705014};\\\", \\\"{x:1026,y:738,t:1526922705032};\\\", \\\"{x:1018,y:743,t:1526922705049};\\\", \\\"{x:1008,y:752,t:1526922705064};\\\", \\\"{x:992,y:760,t:1526922705082};\\\", \\\"{x:968,y:770,t:1526922705099};\\\", \\\"{x:927,y:781,t:1526922705115};\\\", \\\"{x:903,y:787,t:1526922705131};\\\", \\\"{x:869,y:792,t:1526922705149};\\\", \\\"{x:847,y:796,t:1526922705165};\\\", \\\"{x:831,y:802,t:1526922705182};\\\", \\\"{x:815,y:804,t:1526922705198};\\\", \\\"{x:806,y:805,t:1526922705215};\\\", \\\"{x:801,y:806,t:1526922705232};\\\", \\\"{x:798,y:807,t:1526922705249};\\\", \\\"{x:792,y:810,t:1526922705266};\\\", \\\"{x:788,y:813,t:1526922705282};\\\", \\\"{x:782,y:815,t:1526922705299};\\\", \\\"{x:764,y:821,t:1526922705315};\\\", \\\"{x:753,y:824,t:1526922705331};\\\", \\\"{x:738,y:829,t:1526922705348};\\\", \\\"{x:725,y:831,t:1526922705365};\\\", \\\"{x:707,y:835,t:1526922705381};\\\", \\\"{x:692,y:837,t:1526922705399};\\\", \\\"{x:678,y:839,t:1526922705415};\\\", \\\"{x:663,y:839,t:1526922705433};\\\", \\\"{x:646,y:838,t:1526922705448};\\\", \\\"{x:636,y:837,t:1526922705466};\\\", \\\"{x:628,y:836,t:1526922705483};\\\", \\\"{x:626,y:836,t:1526922705498};\\\", \\\"{x:625,y:836,t:1526922705515};\\\", \\\"{x:624,y:836,t:1526922705533};\\\", \\\"{x:624,y:835,t:1526922705548};\\\", \\\"{x:623,y:835,t:1526922705565};\\\", \\\"{x:620,y:833,t:1526922705583};\\\", \\\"{x:618,y:830,t:1526922705598};\\\", \\\"{x:614,y:825,t:1526922705615};\\\", \\\"{x:610,y:819,t:1526922705633};\\\", \\\"{x:605,y:811,t:1526922705648};\\\", \\\"{x:599,y:806,t:1526922705666};\\\", \\\"{x:594,y:801,t:1526922705682};\\\", \\\"{x:590,y:796,t:1526922705699};\\\", \\\"{x:587,y:793,t:1526922705716};\\\", \\\"{x:585,y:790,t:1526922705732};\\\", \\\"{x:583,y:789,t:1526922705748};\\\", \\\"{x:583,y:788,t:1526922705766};\\\", \\\"{x:583,y:787,t:1526922705783};\\\", \\\"{x:583,y:785,t:1526922705799};\\\", \\\"{x:580,y:783,t:1526922705859};\\\", \\\"{x:579,y:782,t:1526922705867};\\\", \\\"{x:577,y:779,t:1526922705883};\\\", \\\"{x:570,y:771,t:1526922705899};\\\", \\\"{x:565,y:764,t:1526922705915};\\\", \\\"{x:558,y:759,t:1526922705932};\\\", \\\"{x:552,y:755,t:1526922705949};\\\", \\\"{x:544,y:750,t:1526922705965};\\\", \\\"{x:537,y:748,t:1526922705983};\\\", \\\"{x:529,y:743,t:1526922705999};\\\", \\\"{x:524,y:740,t:1526922706015};\\\", \\\"{x:516,y:737,t:1526922706031};\\\", \\\"{x:506,y:736,t:1526922706047};\\\", \\\"{x:502,y:736,t:1526922706063};\\\", \\\"{x:499,y:736,t:1526922706080};\\\", \\\"{x:496,y:735,t:1526922706097};\\\", \\\"{x:493,y:734,t:1526922706113};\\\", \\\"{x:492,y:732,t:1526922706130};\\\", \\\"{x:491,y:732,t:1526922706154};\\\", \\\"{x:490,y:731,t:1526922706164};\\\" ] }, { \\\"rt\\\": 16292, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 155857, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:731,t:1526922708883};\\\", \\\"{x:487,y:731,t:1526922712796};\\\", \\\"{x:489,y:730,t:1526922715547};\\\", \\\"{x:494,y:729,t:1526922715555};\\\", \\\"{x:504,y:729,t:1526922715565};\\\", \\\"{x:528,y:729,t:1526922715582};\\\", \\\"{x:566,y:729,t:1526922715598};\\\", \\\"{x:616,y:729,t:1526922715615};\\\", \\\"{x:677,y:729,t:1526922715632};\\\", \\\"{x:703,y:727,t:1526922715640};\\\", \\\"{x:738,y:728,t:1526922715657};\\\", \\\"{x:766,y:729,t:1526922715673};\\\", \\\"{x:819,y:729,t:1526922715690};\\\", \\\"{x:867,y:729,t:1526922715707};\\\", \\\"{x:887,y:729,t:1526922715724};\\\", \\\"{x:904,y:726,t:1526922715740};\\\", \\\"{x:912,y:725,t:1526922715757};\\\", \\\"{x:919,y:724,t:1526922715774};\\\", \\\"{x:926,y:723,t:1526922715790};\\\", \\\"{x:934,y:721,t:1526922715807};\\\", \\\"{x:949,y:719,t:1526922715823};\\\", \\\"{x:965,y:716,t:1526922715840};\\\", \\\"{x:979,y:712,t:1526922715857};\\\", \\\"{x:982,y:709,t:1526922715874};\\\", \\\"{x:1010,y:704,t:1526922715891};\\\", \\\"{x:1034,y:698,t:1526922715907};\\\", \\\"{x:1055,y:695,t:1526922715924};\\\", \\\"{x:1073,y:689,t:1526922715941};\\\", \\\"{x:1088,y:684,t:1526922715957};\\\", \\\"{x:1102,y:680,t:1526922715974};\\\", \\\"{x:1112,y:677,t:1526922715991};\\\", \\\"{x:1120,y:676,t:1526922716008};\\\", \\\"{x:1128,y:674,t:1526922716025};\\\", \\\"{x:1135,y:673,t:1526922716042};\\\", \\\"{x:1142,y:671,t:1526922716057};\\\", \\\"{x:1147,y:671,t:1526922716074};\\\", \\\"{x:1152,y:671,t:1526922716091};\\\", \\\"{x:1154,y:671,t:1526922716363};\\\", \\\"{x:1154,y:670,t:1526922716373};\\\", \\\"{x:1155,y:669,t:1526922716390};\\\", \\\"{x:1158,y:668,t:1526922716408};\\\", \\\"{x:1161,y:667,t:1526922716424};\\\", \\\"{x:1166,y:665,t:1526922716441};\\\", \\\"{x:1170,y:663,t:1526922716458};\\\", \\\"{x:1172,y:661,t:1526922716475};\\\", \\\"{x:1175,y:659,t:1526922716490};\\\", \\\"{x:1179,y:657,t:1526922716508};\\\", \\\"{x:1180,y:656,t:1526922716525};\\\", \\\"{x:1181,y:656,t:1526922716541};\\\", \\\"{x:1182,y:655,t:1526922716558};\\\", \\\"{x:1184,y:653,t:1526922716575};\\\", \\\"{x:1185,y:652,t:1526922716591};\\\", \\\"{x:1189,y:650,t:1526922716608};\\\", \\\"{x:1193,y:648,t:1526922716625};\\\", \\\"{x:1195,y:646,t:1526922716641};\\\", \\\"{x:1198,y:644,t:1526922716658};\\\", \\\"{x:1201,y:642,t:1526922716675};\\\", \\\"{x:1203,y:640,t:1526922716691};\\\", \\\"{x:1205,y:639,t:1526922716708};\\\", \\\"{x:1206,y:639,t:1526922716725};\\\", \\\"{x:1209,y:636,t:1526922716742};\\\", \\\"{x:1210,y:635,t:1526922716758};\\\", \\\"{x:1214,y:633,t:1526922716775};\\\", \\\"{x:1215,y:632,t:1526922716792};\\\", \\\"{x:1216,y:632,t:1526922716808};\\\", \\\"{x:1217,y:631,t:1526922716825};\\\", \\\"{x:1219,y:631,t:1526922716842};\\\", \\\"{x:1220,y:630,t:1526922716858};\\\", \\\"{x:1223,y:629,t:1526922716876};\\\", \\\"{x:1224,y:627,t:1526922716892};\\\", \\\"{x:1225,y:626,t:1526922716908};\\\", \\\"{x:1226,y:625,t:1526922716925};\\\", \\\"{x:1228,y:624,t:1526922716942};\\\", \\\"{x:1229,y:624,t:1526922716958};\\\", \\\"{x:1231,y:623,t:1526922717084};\\\", \\\"{x:1232,y:622,t:1526922717108};\\\", \\\"{x:1233,y:622,t:1526922717148};\\\", \\\"{x:1234,y:620,t:1526922717172};\\\", \\\"{x:1235,y:620,t:1526922717195};\\\", \\\"{x:1236,y:619,t:1526922717209};\\\", \\\"{x:1237,y:617,t:1526922717236};\\\", \\\"{x:1239,y:616,t:1526922717251};\\\", \\\"{x:1240,y:615,t:1526922717259};\\\", \\\"{x:1240,y:614,t:1526922717276};\\\", \\\"{x:1242,y:612,t:1526922717292};\\\", \\\"{x:1243,y:610,t:1526922717310};\\\", \\\"{x:1245,y:608,t:1526922717326};\\\", \\\"{x:1246,y:606,t:1526922717343};\\\", \\\"{x:1246,y:602,t:1526922717360};\\\", \\\"{x:1248,y:598,t:1526922717377};\\\", \\\"{x:1249,y:595,t:1526922717393};\\\", \\\"{x:1250,y:589,t:1526922717410};\\\", \\\"{x:1250,y:586,t:1526922717426};\\\", \\\"{x:1252,y:582,t:1526922717443};\\\", \\\"{x:1254,y:578,t:1526922717460};\\\", \\\"{x:1256,y:574,t:1526922717477};\\\", \\\"{x:1258,y:571,t:1526922717492};\\\", \\\"{x:1260,y:568,t:1526922717510};\\\", \\\"{x:1260,y:567,t:1526922717527};\\\", \\\"{x:1262,y:565,t:1526922717543};\\\", \\\"{x:1256,y:565,t:1526922718595};\\\", \\\"{x:1241,y:567,t:1526922718610};\\\", \\\"{x:1174,y:577,t:1526922718626};\\\", \\\"{x:1120,y:582,t:1526922718644};\\\", \\\"{x:1056,y:590,t:1526922718660};\\\", \\\"{x:1004,y:593,t:1526922718677};\\\", \\\"{x:956,y:593,t:1526922718694};\\\", \\\"{x:903,y:593,t:1526922718711};\\\", \\\"{x:886,y:593,t:1526922718726};\\\", \\\"{x:866,y:593,t:1526922718743};\\\", \\\"{x:839,y:595,t:1526922718759};\\\", \\\"{x:817,y:596,t:1526922718776};\\\", \\\"{x:802,y:596,t:1526922718793};\\\", \\\"{x:795,y:597,t:1526922718873};\\\", \\\"{x:790,y:597,t:1526922718890};\\\", \\\"{x:789,y:597,t:1526922718907};\\\", \\\"{x:786,y:597,t:1526922718986};\\\", \\\"{x:785,y:597,t:1526922718995};\\\", \\\"{x:782,y:597,t:1526922719007};\\\", \\\"{x:769,y:599,t:1526922719023};\\\", \\\"{x:756,y:602,t:1526922719041};\\\", \\\"{x:743,y:602,t:1526922719057};\\\", \\\"{x:726,y:606,t:1526922719073};\\\", \\\"{x:705,y:606,t:1526922719091};\\\", \\\"{x:670,y:606,t:1526922719107};\\\", \\\"{x:647,y:605,t:1526922719123};\\\", \\\"{x:635,y:603,t:1526922719140};\\\", \\\"{x:624,y:600,t:1526922719158};\\\", \\\"{x:616,y:599,t:1526922719174};\\\", \\\"{x:613,y:597,t:1526922719190};\\\", \\\"{x:612,y:595,t:1526922719207};\\\", \\\"{x:609,y:592,t:1526922719225};\\\", \\\"{x:609,y:586,t:1526922719241};\\\", \\\"{x:608,y:582,t:1526922719257};\\\", \\\"{x:605,y:576,t:1526922719274};\\\", \\\"{x:605,y:570,t:1526922719290};\\\", \\\"{x:601,y:557,t:1526922719308};\\\", \\\"{x:600,y:553,t:1526922719326};\\\", \\\"{x:595,y:545,t:1526922719340};\\\", \\\"{x:594,y:538,t:1526922719357};\\\", \\\"{x:593,y:533,t:1526922719373};\\\", \\\"{x:593,y:528,t:1526922719390};\\\", \\\"{x:593,y:525,t:1526922719407};\\\", \\\"{x:594,y:521,t:1526922719424};\\\", \\\"{x:595,y:519,t:1526922719440};\\\", \\\"{x:597,y:517,t:1526922719457};\\\", \\\"{x:597,y:514,t:1526922719474};\\\", \\\"{x:598,y:514,t:1526922719490};\\\", \\\"{x:599,y:513,t:1526922719507};\\\", \\\"{x:601,y:510,t:1526922719525};\\\", \\\"{x:604,y:509,t:1526922719540};\\\", \\\"{x:606,y:507,t:1526922719557};\\\", \\\"{x:607,y:506,t:1526922719574};\\\", \\\"{x:608,y:505,t:1526922719590};\\\", \\\"{x:608,y:504,t:1526922719607};\\\", \\\"{x:609,y:504,t:1526922719659};\\\", \\\"{x:608,y:505,t:1526922719923};\\\", \\\"{x:602,y:511,t:1526922719931};\\\", \\\"{x:599,y:512,t:1526922719941};\\\", \\\"{x:585,y:521,t:1526922719957};\\\", \\\"{x:568,y:529,t:1526922719975};\\\", \\\"{x:552,y:535,t:1526922719991};\\\", \\\"{x:533,y:542,t:1526922720007};\\\", \\\"{x:519,y:549,t:1526922720024};\\\", \\\"{x:511,y:553,t:1526922720041};\\\", \\\"{x:506,y:555,t:1526922720058};\\\", \\\"{x:504,y:556,t:1526922720074};\\\", \\\"{x:500,y:557,t:1526922720090};\\\", \\\"{x:498,y:557,t:1526922720108};\\\", \\\"{x:497,y:558,t:1526922720124};\\\", \\\"{x:490,y:558,t:1526922720141};\\\", \\\"{x:478,y:559,t:1526922720158};\\\", \\\"{x:458,y:559,t:1526922720174};\\\", \\\"{x:446,y:560,t:1526922720192};\\\", \\\"{x:425,y:560,t:1526922720208};\\\", \\\"{x:412,y:560,t:1526922720224};\\\", \\\"{x:406,y:560,t:1526922720241};\\\", \\\"{x:402,y:560,t:1526922720259};\\\", \\\"{x:403,y:560,t:1526922720394};\\\", \\\"{x:407,y:560,t:1526922720408};\\\", \\\"{x:424,y:560,t:1526922720425};\\\", \\\"{x:442,y:560,t:1526922720441};\\\", \\\"{x:466,y:560,t:1526922720458};\\\", \\\"{x:489,y:560,t:1526922720474};\\\", \\\"{x:498,y:560,t:1526922720491};\\\", \\\"{x:507,y:560,t:1526922720508};\\\", \\\"{x:514,y:561,t:1526922720525};\\\", \\\"{x:523,y:562,t:1526922720541};\\\", \\\"{x:532,y:564,t:1526922720559};\\\", \\\"{x:547,y:564,t:1526922720575};\\\", \\\"{x:557,y:564,t:1526922720591};\\\", \\\"{x:569,y:564,t:1526922720608};\\\", \\\"{x:575,y:564,t:1526922720625};\\\", \\\"{x:577,y:564,t:1526922720641};\\\", \\\"{x:572,y:564,t:1526922720683};\\\", \\\"{x:564,y:566,t:1526922720691};\\\", \\\"{x:536,y:570,t:1526922720708};\\\", \\\"{x:491,y:577,t:1526922720726};\\\", \\\"{x:430,y:586,t:1526922720741};\\\", \\\"{x:379,y:595,t:1526922720758};\\\", \\\"{x:326,y:602,t:1526922720776};\\\", \\\"{x:303,y:602,t:1526922720791};\\\", \\\"{x:289,y:602,t:1526922720808};\\\", \\\"{x:280,y:602,t:1526922720825};\\\", \\\"{x:276,y:602,t:1526922720841};\\\", \\\"{x:274,y:602,t:1526922720858};\\\", \\\"{x:273,y:602,t:1526922720899};\\\", \\\"{x:272,y:604,t:1526922720909};\\\", \\\"{x:269,y:605,t:1526922720925};\\\", \\\"{x:268,y:606,t:1526922720941};\\\", \\\"{x:266,y:608,t:1526922720958};\\\", \\\"{x:263,y:608,t:1526922720975};\\\", \\\"{x:261,y:608,t:1526922720991};\\\", \\\"{x:251,y:608,t:1526922721008};\\\", \\\"{x:238,y:608,t:1526922721025};\\\", \\\"{x:220,y:605,t:1526922721041};\\\", \\\"{x:205,y:603,t:1526922721058};\\\", \\\"{x:181,y:602,t:1526922721074};\\\", \\\"{x:175,y:601,t:1526922721091};\\\", \\\"{x:171,y:601,t:1526922721108};\\\", \\\"{x:170,y:601,t:1526922721179};\\\", \\\"{x:170,y:602,t:1526922721191};\\\", \\\"{x:171,y:606,t:1526922721208};\\\", \\\"{x:175,y:610,t:1526922721225};\\\", \\\"{x:185,y:617,t:1526922721242};\\\", \\\"{x:198,y:622,t:1526922721259};\\\", \\\"{x:224,y:635,t:1526922721276};\\\", \\\"{x:241,y:640,t:1526922721293};\\\", \\\"{x:258,y:643,t:1526922721308};\\\", \\\"{x:270,y:643,t:1526922721325};\\\", \\\"{x:289,y:643,t:1526922721343};\\\", \\\"{x:306,y:643,t:1526922721359};\\\", \\\"{x:318,y:643,t:1526922721375};\\\", \\\"{x:325,y:642,t:1526922721392};\\\", \\\"{x:334,y:638,t:1526922721409};\\\", \\\"{x:341,y:632,t:1526922721425};\\\", \\\"{x:347,y:628,t:1526922721443};\\\", \\\"{x:355,y:623,t:1526922721458};\\\", \\\"{x:360,y:620,t:1526922721475};\\\", \\\"{x:366,y:615,t:1526922721492};\\\", \\\"{x:371,y:612,t:1526922721510};\\\", \\\"{x:379,y:608,t:1526922721526};\\\", \\\"{x:387,y:603,t:1526922721542};\\\", \\\"{x:395,y:598,t:1526922721560};\\\", \\\"{x:401,y:596,t:1526922721575};\\\", \\\"{x:410,y:593,t:1526922721593};\\\", \\\"{x:413,y:593,t:1526922721609};\\\", \\\"{x:424,y:592,t:1526922721626};\\\", \\\"{x:427,y:592,t:1526922721642};\\\", \\\"{x:437,y:592,t:1526922721659};\\\", \\\"{x:440,y:592,t:1526922721676};\\\", \\\"{x:445,y:592,t:1526922721693};\\\", \\\"{x:447,y:592,t:1526922721709};\\\", \\\"{x:448,y:592,t:1526922721771};\\\", \\\"{x:448,y:593,t:1526922721778};\\\", \\\"{x:448,y:594,t:1526922721796};\\\", \\\"{x:451,y:594,t:1526922721987};\\\", \\\"{x:457,y:593,t:1526922721996};\\\", \\\"{x:461,y:592,t:1526922722009};\\\", \\\"{x:469,y:592,t:1526922722026};\\\", \\\"{x:485,y:586,t:1526922722042};\\\", \\\"{x:511,y:580,t:1526922722060};\\\", \\\"{x:531,y:577,t:1526922722076};\\\", \\\"{x:549,y:574,t:1526922722092};\\\", \\\"{x:564,y:571,t:1526922722109};\\\", \\\"{x:571,y:571,t:1526922722126};\\\", \\\"{x:581,y:571,t:1526922722143};\\\", \\\"{x:588,y:570,t:1526922722159};\\\", \\\"{x:591,y:568,t:1526922722176};\\\", \\\"{x:592,y:568,t:1526922722193};\\\", \\\"{x:593,y:568,t:1526922722218};\\\", \\\"{x:594,y:568,t:1526922722234};\\\", \\\"{x:595,y:566,t:1526922722242};\\\", \\\"{x:601,y:563,t:1526922722260};\\\", \\\"{x:607,y:562,t:1526922722277};\\\", \\\"{x:619,y:557,t:1526922722294};\\\", \\\"{x:633,y:555,t:1526922722310};\\\", \\\"{x:648,y:553,t:1526922722326};\\\", \\\"{x:668,y:552,t:1526922722343};\\\", \\\"{x:684,y:550,t:1526922722359};\\\", \\\"{x:692,y:550,t:1526922722376};\\\", \\\"{x:694,y:550,t:1526922722393};\\\", \\\"{x:695,y:550,t:1526922722409};\\\", \\\"{x:695,y:552,t:1526922722426};\\\", \\\"{x:680,y:563,t:1526922722444};\\\", \\\"{x:657,y:576,t:1526922722459};\\\", \\\"{x:625,y:588,t:1526922722476};\\\", \\\"{x:577,y:601,t:1526922722493};\\\", \\\"{x:534,y:609,t:1526922722508};\\\", \\\"{x:506,y:613,t:1526922722526};\\\", \\\"{x:487,y:615,t:1526922722543};\\\", \\\"{x:486,y:616,t:1526922722559};\\\", \\\"{x:486,y:615,t:1526922722635};\\\", \\\"{x:492,y:615,t:1526922722643};\\\", \\\"{x:518,y:611,t:1526922722660};\\\", \\\"{x:545,y:605,t:1526922722676};\\\", \\\"{x:585,y:601,t:1526922722693};\\\", \\\"{x:607,y:596,t:1526922722710};\\\", \\\"{x:634,y:592,t:1526922722727};\\\", \\\"{x:652,y:590,t:1526922722743};\\\", \\\"{x:665,y:588,t:1526922722760};\\\", \\\"{x:676,y:583,t:1526922722777};\\\", \\\"{x:684,y:580,t:1526922722794};\\\", \\\"{x:692,y:577,t:1526922722810};\\\", \\\"{x:703,y:572,t:1526922722826};\\\", \\\"{x:710,y:567,t:1526922722842};\\\", \\\"{x:719,y:564,t:1526922722860};\\\", \\\"{x:728,y:561,t:1526922722877};\\\", \\\"{x:736,y:559,t:1526922722894};\\\", \\\"{x:742,y:558,t:1526922722910};\\\", \\\"{x:754,y:556,t:1526922722926};\\\", \\\"{x:773,y:556,t:1526922722943};\\\", \\\"{x:807,y:553,t:1526922722960};\\\", \\\"{x:863,y:553,t:1526922722976};\\\", \\\"{x:922,y:553,t:1526922722993};\\\", \\\"{x:967,y:553,t:1526922723011};\\\", \\\"{x:983,y:553,t:1526922723027};\\\", \\\"{x:990,y:553,t:1526922723043};\\\", \\\"{x:990,y:555,t:1526922723099};\\\", \\\"{x:989,y:557,t:1526922723110};\\\", \\\"{x:975,y:557,t:1526922723127};\\\", \\\"{x:954,y:557,t:1526922723143};\\\", \\\"{x:932,y:557,t:1526922723160};\\\", \\\"{x:911,y:557,t:1526922723178};\\\", \\\"{x:896,y:557,t:1526922723194};\\\", \\\"{x:887,y:557,t:1526922723210};\\\", \\\"{x:877,y:557,t:1526922723227};\\\", \\\"{x:875,y:557,t:1526922723244};\\\", \\\"{x:874,y:557,t:1526922723261};\\\", \\\"{x:873,y:557,t:1526922723278};\\\", \\\"{x:872,y:556,t:1526922723293};\\\", \\\"{x:871,y:556,t:1526922723348};\\\", \\\"{x:870,y:556,t:1526922723360};\\\", \\\"{x:867,y:556,t:1526922723378};\\\", \\\"{x:864,y:555,t:1526922723395};\\\", \\\"{x:862,y:554,t:1526922723410};\\\", \\\"{x:859,y:553,t:1526922723426};\\\", \\\"{x:858,y:551,t:1526922723443};\\\", \\\"{x:856,y:551,t:1526922723460};\\\", \\\"{x:851,y:550,t:1526922723478};\\\", \\\"{x:846,y:548,t:1526922723495};\\\", \\\"{x:837,y:547,t:1526922723511};\\\", \\\"{x:832,y:547,t:1526922723527};\\\", \\\"{x:830,y:545,t:1526922723543};\\\", \\\"{x:828,y:544,t:1526922723560};\\\", \\\"{x:827,y:543,t:1526922723578};\\\", \\\"{x:826,y:543,t:1526922723594};\\\", \\\"{x:825,y:542,t:1526922723610};\\\", \\\"{x:823,y:542,t:1526922723899};\\\", \\\"{x:822,y:542,t:1526922723910};\\\", \\\"{x:814,y:546,t:1526922723927};\\\", \\\"{x:803,y:553,t:1526922723945};\\\", \\\"{x:788,y:559,t:1526922723960};\\\", \\\"{x:771,y:565,t:1526922723978};\\\", \\\"{x:747,y:574,t:1526922723995};\\\", \\\"{x:731,y:584,t:1526922724011};\\\", \\\"{x:693,y:602,t:1526922724027};\\\", \\\"{x:655,y:611,t:1526922724044};\\\", \\\"{x:631,y:619,t:1526922724061};\\\", \\\"{x:612,y:628,t:1526922724078};\\\", \\\"{x:604,y:633,t:1526922724094};\\\", \\\"{x:598,y:637,t:1526922724112};\\\", \\\"{x:590,y:644,t:1526922724127};\\\", \\\"{x:584,y:650,t:1526922724145};\\\", \\\"{x:579,y:656,t:1526922724161};\\\", \\\"{x:572,y:665,t:1526922724178};\\\", \\\"{x:562,y:675,t:1526922724195};\\\", \\\"{x:558,y:680,t:1526922724212};\\\", \\\"{x:552,y:685,t:1526922724229};\\\", \\\"{x:541,y:690,t:1526922724244};\\\", \\\"{x:536,y:694,t:1526922724262};\\\", \\\"{x:530,y:698,t:1526922724279};\\\", \\\"{x:527,y:701,t:1526922724294};\\\", \\\"{x:524,y:704,t:1526922724312};\\\", \\\"{x:514,y:710,t:1526922724328};\\\", \\\"{x:510,y:714,t:1526922724345};\\\", \\\"{x:506,y:717,t:1526922724361};\\\", \\\"{x:504,y:720,t:1526922724379};\\\", \\\"{x:503,y:721,t:1526922724395};\\\", \\\"{x:502,y:722,t:1526922724411};\\\", \\\"{x:499,y:725,t:1526922724458};\\\", \\\"{x:499,y:726,t:1526922724490};\\\", \\\"{x:499,y:727,t:1526922724506};\\\", \\\"{x:499,y:728,t:1526922724522};\\\", \\\"{x:499,y:729,t:1526922724611};\\\", \\\"{x:499,y:730,t:1526922724643};\\\", \\\"{x:500,y:730,t:1526922724690};\\\", \\\"{x:500,y:730,t:1526922724810};\\\" ] }, { \\\"rt\\\": 41774, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 198840, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -X -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:731,t:1526922726907};\\\", \\\"{x:499,y:731,t:1526922733722};\\\", \\\"{x:498,y:732,t:1526922733730};\\\", \\\"{x:499,y:732,t:1526922738123};\\\", \\\"{x:506,y:732,t:1526922738130};\\\", \\\"{x:517,y:732,t:1526922738145};\\\", \\\"{x:552,y:723,t:1526922738162};\\\", \\\"{x:605,y:718,t:1526922738178};\\\", \\\"{x:677,y:706,t:1526922738194};\\\", \\\"{x:702,y:700,t:1526922738206};\\\", \\\"{x:738,y:700,t:1526922738222};\\\", \\\"{x:772,y:700,t:1526922738239};\\\", \\\"{x:795,y:699,t:1526922738256};\\\", \\\"{x:817,y:698,t:1526922738273};\\\", \\\"{x:832,y:698,t:1526922738288};\\\", \\\"{x:856,y:699,t:1526922738306};\\\", \\\"{x:892,y:699,t:1526922738322};\\\", \\\"{x:922,y:699,t:1526922738338};\\\", \\\"{x:946,y:699,t:1526922738356};\\\", \\\"{x:967,y:699,t:1526922738373};\\\", \\\"{x:976,y:699,t:1526922738388};\\\", \\\"{x:980,y:696,t:1526922738405};\\\", \\\"{x:984,y:696,t:1526922738422};\\\", \\\"{x:991,y:692,t:1526922738439};\\\", \\\"{x:996,y:691,t:1526922738456};\\\", \\\"{x:1001,y:688,t:1526922738473};\\\", \\\"{x:1012,y:684,t:1526922738489};\\\", \\\"{x:1023,y:682,t:1526922738506};\\\", \\\"{x:1036,y:676,t:1526922738523};\\\", \\\"{x:1040,y:673,t:1526922738539};\\\", \\\"{x:1047,y:671,t:1526922738556};\\\", \\\"{x:1054,y:666,t:1526922738573};\\\", \\\"{x:1062,y:662,t:1526922738590};\\\", \\\"{x:1073,y:657,t:1526922738606};\\\", \\\"{x:1081,y:653,t:1526922738623};\\\", \\\"{x:1084,y:651,t:1526922738640};\\\", \\\"{x:1085,y:650,t:1526922738666};\\\", \\\"{x:1086,y:649,t:1526922738674};\\\", \\\"{x:1086,y:648,t:1526922738698};\\\", \\\"{x:1086,y:647,t:1526922738714};\\\", \\\"{x:1086,y:646,t:1526922738722};\\\", \\\"{x:1086,y:645,t:1526922738740};\\\", \\\"{x:1087,y:643,t:1526922738756};\\\", \\\"{x:1087,y:641,t:1526922738773};\\\", \\\"{x:1087,y:639,t:1526922738790};\\\", \\\"{x:1087,y:637,t:1526922738806};\\\", \\\"{x:1087,y:636,t:1526922738826};\\\", \\\"{x:1087,y:635,t:1526922738842};\\\", \\\"{x:1087,y:634,t:1526922738866};\\\", \\\"{x:1087,y:633,t:1526922739108};\\\", \\\"{x:1087,y:631,t:1526922739146};\\\", \\\"{x:1087,y:630,t:1526922739178};\\\", \\\"{x:1087,y:628,t:1526922739226};\\\", \\\"{x:1086,y:631,t:1526922741250};\\\", \\\"{x:1086,y:633,t:1526922741266};\\\", \\\"{x:1086,y:634,t:1526922741274};\\\", \\\"{x:1086,y:637,t:1526922741292};\\\", \\\"{x:1086,y:638,t:1526922741308};\\\", \\\"{x:1084,y:641,t:1526922741325};\\\", \\\"{x:1084,y:643,t:1526922741342};\\\", \\\"{x:1084,y:646,t:1526922741357};\\\", \\\"{x:1084,y:650,t:1526922741374};\\\", \\\"{x:1083,y:653,t:1526922741392};\\\", \\\"{x:1082,y:655,t:1526922741408};\\\", \\\"{x:1082,y:657,t:1526922741425};\\\", \\\"{x:1081,y:661,t:1526922741442};\\\", \\\"{x:1081,y:663,t:1526922741458};\\\", \\\"{x:1080,y:666,t:1526922741475};\\\", \\\"{x:1080,y:668,t:1526922741492};\\\", \\\"{x:1080,y:670,t:1526922741508};\\\", \\\"{x:1080,y:672,t:1526922741524};\\\", \\\"{x:1079,y:674,t:1526922741542};\\\", \\\"{x:1079,y:675,t:1526922741562};\\\", \\\"{x:1079,y:676,t:1526922741578};\\\", \\\"{x:1079,y:677,t:1526922741602};\\\", \\\"{x:1079,y:678,t:1526922741859};\\\", \\\"{x:1079,y:679,t:1526922741875};\\\", \\\"{x:1079,y:680,t:1526922741891};\\\", \\\"{x:1079,y:681,t:1526922741909};\\\", \\\"{x:1079,y:682,t:1526922741925};\\\", \\\"{x:1079,y:683,t:1526922741942};\\\", \\\"{x:1079,y:684,t:1526922741962};\\\", \\\"{x:1079,y:685,t:1526922741978};\\\", \\\"{x:1080,y:686,t:1526922741992};\\\", \\\"{x:1082,y:687,t:1526922742009};\\\", \\\"{x:1083,y:688,t:1526922742025};\\\", \\\"{x:1083,y:689,t:1526922742066};\\\", \\\"{x:1084,y:689,t:1526922742075};\\\", \\\"{x:1084,y:691,t:1526922743611};\\\", \\\"{x:1084,y:692,t:1526922743634};\\\", \\\"{x:1084,y:694,t:1526922743650};\\\", \\\"{x:1084,y:695,t:1526922743659};\\\", \\\"{x:1085,y:698,t:1526922743677};\\\", \\\"{x:1087,y:705,t:1526922743692};\\\", \\\"{x:1089,y:710,t:1526922743710};\\\", \\\"{x:1090,y:714,t:1526922743727};\\\", \\\"{x:1093,y:719,t:1526922743743};\\\", \\\"{x:1095,y:726,t:1526922743760};\\\", \\\"{x:1099,y:730,t:1526922743777};\\\", \\\"{x:1102,y:740,t:1526922743794};\\\", \\\"{x:1108,y:750,t:1526922743810};\\\", \\\"{x:1113,y:759,t:1526922743827};\\\", \\\"{x:1116,y:768,t:1526922743843};\\\", \\\"{x:1121,y:773,t:1526922743860};\\\", \\\"{x:1124,y:779,t:1526922743877};\\\", \\\"{x:1127,y:786,t:1526922743894};\\\", \\\"{x:1129,y:790,t:1526922743910};\\\", \\\"{x:1130,y:793,t:1526922743928};\\\", \\\"{x:1130,y:795,t:1526922743947};\\\", \\\"{x:1130,y:796,t:1526922743962};\\\", \\\"{x:1130,y:797,t:1526922743987};\\\", \\\"{x:1130,y:799,t:1526922744083};\\\", \\\"{x:1130,y:801,t:1526922744098};\\\", \\\"{x:1130,y:803,t:1526922744110};\\\", \\\"{x:1133,y:805,t:1526922744127};\\\", \\\"{x:1134,y:807,t:1526922744145};\\\", \\\"{x:1138,y:811,t:1526922744161};\\\", \\\"{x:1142,y:814,t:1526922744178};\\\", \\\"{x:1151,y:819,t:1526922744195};\\\", \\\"{x:1155,y:822,t:1526922744211};\\\", \\\"{x:1160,y:826,t:1526922744227};\\\", \\\"{x:1164,y:829,t:1526922744244};\\\", \\\"{x:1167,y:832,t:1526922744261};\\\", \\\"{x:1171,y:836,t:1526922744277};\\\", \\\"{x:1175,y:838,t:1526922744294};\\\", \\\"{x:1179,y:841,t:1526922744311};\\\", \\\"{x:1180,y:843,t:1526922744327};\\\", \\\"{x:1182,y:844,t:1526922744346};\\\", \\\"{x:1184,y:844,t:1526922744379};\\\", \\\"{x:1185,y:844,t:1526922744491};\\\", \\\"{x:1187,y:844,t:1526922744507};\\\", \\\"{x:1188,y:844,t:1526922744515};\\\", \\\"{x:1189,y:843,t:1526922744527};\\\", \\\"{x:1190,y:842,t:1526922744544};\\\", \\\"{x:1190,y:841,t:1526922744561};\\\", \\\"{x:1191,y:841,t:1526922744578};\\\", \\\"{x:1192,y:840,t:1526922744595};\\\", \\\"{x:1192,y:839,t:1526922744610};\\\", \\\"{x:1193,y:838,t:1526922744627};\\\", \\\"{x:1194,y:838,t:1526922744716};\\\", \\\"{x:1195,y:837,t:1526922744728};\\\", \\\"{x:1196,y:836,t:1526922744745};\\\", \\\"{x:1197,y:835,t:1526922744763};\\\", \\\"{x:1198,y:834,t:1526922744795};\\\", \\\"{x:1198,y:833,t:1526922744819};\\\", \\\"{x:1198,y:832,t:1526922744828};\\\", \\\"{x:1200,y:830,t:1526922744844};\\\", \\\"{x:1200,y:829,t:1526922744861};\\\", \\\"{x:1200,y:828,t:1526922744878};\\\", \\\"{x:1203,y:826,t:1526922744894};\\\", \\\"{x:1204,y:824,t:1526922744911};\\\", \\\"{x:1205,y:822,t:1526922744928};\\\", \\\"{x:1207,y:820,t:1526922744944};\\\", \\\"{x:1207,y:818,t:1526922744961};\\\", \\\"{x:1209,y:817,t:1526922744978};\\\", \\\"{x:1212,y:815,t:1526922744994};\\\", \\\"{x:1213,y:813,t:1526922745011};\\\", \\\"{x:1214,y:811,t:1526922745027};\\\", \\\"{x:1216,y:810,t:1526922745044};\\\", \\\"{x:1216,y:808,t:1526922745061};\\\", \\\"{x:1218,y:806,t:1526922745078};\\\", \\\"{x:1218,y:805,t:1526922745095};\\\", \\\"{x:1221,y:802,t:1526922745111};\\\", \\\"{x:1223,y:798,t:1526922745128};\\\", \\\"{x:1225,y:795,t:1526922745145};\\\", \\\"{x:1228,y:792,t:1526922745160};\\\", \\\"{x:1230,y:788,t:1526922745178};\\\", \\\"{x:1232,y:785,t:1526922745195};\\\", \\\"{x:1235,y:782,t:1526922745211};\\\", \\\"{x:1237,y:778,t:1526922745228};\\\", \\\"{x:1241,y:773,t:1526922745245};\\\", \\\"{x:1245,y:769,t:1526922745261};\\\", \\\"{x:1247,y:767,t:1526922745279};\\\", \\\"{x:1253,y:762,t:1526922745295};\\\", \\\"{x:1264,y:755,t:1526922745311};\\\", \\\"{x:1270,y:751,t:1526922745328};\\\", \\\"{x:1275,y:748,t:1526922745345};\\\", \\\"{x:1279,y:747,t:1526922745361};\\\", \\\"{x:1283,y:744,t:1526922745377};\\\", \\\"{x:1284,y:743,t:1526922745395};\\\", \\\"{x:1287,y:742,t:1526922745411};\\\", \\\"{x:1289,y:741,t:1526922745428};\\\", \\\"{x:1293,y:741,t:1526922745445};\\\", \\\"{x:1301,y:737,t:1526922745462};\\\", \\\"{x:1302,y:736,t:1526922745482};\\\", \\\"{x:1303,y:735,t:1526922745495};\\\", \\\"{x:1306,y:733,t:1526922745512};\\\", \\\"{x:1309,y:732,t:1526922745528};\\\", \\\"{x:1311,y:730,t:1526922745544};\\\", \\\"{x:1319,y:726,t:1526922745561};\\\", \\\"{x:1322,y:724,t:1526922745577};\\\", \\\"{x:1326,y:722,t:1526922745595};\\\", \\\"{x:1331,y:719,t:1526922745612};\\\", \\\"{x:1334,y:716,t:1526922745628};\\\", \\\"{x:1337,y:714,t:1526922745644};\\\", \\\"{x:1344,y:712,t:1526922745661};\\\", \\\"{x:1349,y:709,t:1526922745678};\\\", \\\"{x:1354,y:706,t:1526922745695};\\\", \\\"{x:1359,y:703,t:1526922745711};\\\", \\\"{x:1364,y:700,t:1526922745728};\\\", \\\"{x:1368,y:699,t:1526922745745};\\\", \\\"{x:1370,y:697,t:1526922745769};\\\", \\\"{x:1371,y:697,t:1526922745827};\\\", \\\"{x:1370,y:700,t:1526922745954};\\\", \\\"{x:1368,y:701,t:1526922745961};\\\", \\\"{x:1367,y:704,t:1526922745979};\\\", \\\"{x:1365,y:708,t:1526922745995};\\\", \\\"{x:1364,y:709,t:1526922746012};\\\", \\\"{x:1363,y:711,t:1526922746029};\\\", \\\"{x:1363,y:712,t:1526922746045};\\\", \\\"{x:1362,y:712,t:1526922746363};\\\", \\\"{x:1361,y:712,t:1526922746379};\\\", \\\"{x:1360,y:712,t:1526922746434};\\\", \\\"{x:1357,y:711,t:1526922746458};\\\", \\\"{x:1357,y:709,t:1526922746490};\\\", \\\"{x:1356,y:709,t:1526922746497};\\\", \\\"{x:1355,y:709,t:1526922746514};\\\", \\\"{x:1355,y:707,t:1526922746528};\\\", \\\"{x:1354,y:707,t:1526922746546};\\\", \\\"{x:1354,y:706,t:1526922746561};\\\", \\\"{x:1354,y:705,t:1526922746610};\\\", \\\"{x:1354,y:704,t:1526922746618};\\\", \\\"{x:1353,y:704,t:1526922746650};\\\", \\\"{x:1352,y:703,t:1526922746662};\\\", \\\"{x:1351,y:703,t:1526922746778};\\\", \\\"{x:1348,y:704,t:1526922746786};\\\", \\\"{x:1347,y:705,t:1526922746802};\\\", \\\"{x:1347,y:707,t:1526922746812};\\\", \\\"{x:1345,y:710,t:1526922746829};\\\", \\\"{x:1341,y:714,t:1526922746846};\\\", \\\"{x:1340,y:720,t:1526922746862};\\\", \\\"{x:1338,y:724,t:1526922746879};\\\", \\\"{x:1337,y:728,t:1526922746897};\\\", \\\"{x:1337,y:733,t:1526922746914};\\\", \\\"{x:1337,y:739,t:1526922746930};\\\", \\\"{x:1337,y:743,t:1526922746946};\\\", \\\"{x:1337,y:745,t:1526922746962};\\\", \\\"{x:1337,y:748,t:1526922746979};\\\", \\\"{x:1338,y:751,t:1526922746996};\\\", \\\"{x:1339,y:752,t:1526922747014};\\\", \\\"{x:1340,y:754,t:1526922747029};\\\", \\\"{x:1342,y:755,t:1526922747046};\\\", \\\"{x:1344,y:758,t:1526922747063};\\\", \\\"{x:1345,y:761,t:1526922747080};\\\", \\\"{x:1346,y:762,t:1526922747096};\\\", \\\"{x:1348,y:764,t:1526922747113};\\\", \\\"{x:1348,y:766,t:1526922747129};\\\", \\\"{x:1349,y:767,t:1526922747146};\\\", \\\"{x:1349,y:764,t:1526922747283};\\\", \\\"{x:1349,y:763,t:1526922747296};\\\", \\\"{x:1350,y:760,t:1526922747313};\\\", \\\"{x:1351,y:752,t:1526922747332};\\\", \\\"{x:1352,y:748,t:1526922747347};\\\", \\\"{x:1352,y:743,t:1526922747364};\\\", \\\"{x:1352,y:739,t:1526922747380};\\\", \\\"{x:1353,y:736,t:1526922747396};\\\", \\\"{x:1353,y:732,t:1526922747413};\\\", \\\"{x:1355,y:729,t:1526922747430};\\\", \\\"{x:1355,y:728,t:1526922747446};\\\", \\\"{x:1355,y:726,t:1526922747463};\\\", \\\"{x:1355,y:723,t:1526922747480};\\\", \\\"{x:1355,y:722,t:1526922747506};\\\", \\\"{x:1355,y:723,t:1526922747674};\\\", \\\"{x:1355,y:724,t:1526922747682};\\\", \\\"{x:1355,y:726,t:1526922747696};\\\", \\\"{x:1355,y:730,t:1526922747713};\\\", \\\"{x:1356,y:736,t:1526922747730};\\\", \\\"{x:1357,y:737,t:1526922747746};\\\", \\\"{x:1357,y:739,t:1526922747764};\\\", \\\"{x:1357,y:742,t:1526922747780};\\\", \\\"{x:1357,y:743,t:1526922747797};\\\", \\\"{x:1358,y:745,t:1526922747813};\\\", \\\"{x:1358,y:746,t:1526922747830};\\\", \\\"{x:1359,y:749,t:1526922747847};\\\", \\\"{x:1359,y:751,t:1526922747864};\\\", \\\"{x:1359,y:752,t:1526922747880};\\\", \\\"{x:1361,y:754,t:1526922747897};\\\", \\\"{x:1361,y:755,t:1526922747914};\\\", \\\"{x:1361,y:756,t:1526922747930};\\\", \\\"{x:1361,y:757,t:1526922747947};\\\", \\\"{x:1362,y:759,t:1526922747963};\\\", \\\"{x:1362,y:760,t:1526922747986};\\\", \\\"{x:1362,y:761,t:1526922747997};\\\", \\\"{x:1362,y:762,t:1526922748013};\\\", \\\"{x:1362,y:763,t:1526922748130};\\\", \\\"{x:1362,y:762,t:1526922748194};\\\", \\\"{x:1362,y:761,t:1526922748202};\\\", \\\"{x:1362,y:758,t:1526922748215};\\\", \\\"{x:1362,y:755,t:1526922748230};\\\", \\\"{x:1362,y:752,t:1526922748247};\\\", \\\"{x:1362,y:748,t:1526922748264};\\\", \\\"{x:1362,y:744,t:1526922748280};\\\", \\\"{x:1361,y:738,t:1526922748297};\\\", \\\"{x:1357,y:728,t:1526922748314};\\\", \\\"{x:1357,y:724,t:1526922748330};\\\", \\\"{x:1356,y:720,t:1526922748347};\\\", \\\"{x:1355,y:716,t:1526922748364};\\\", \\\"{x:1353,y:713,t:1526922748380};\\\", \\\"{x:1353,y:710,t:1526922748397};\\\", \\\"{x:1352,y:710,t:1526922748414};\\\", \\\"{x:1351,y:709,t:1526922748489};\\\", \\\"{x:1350,y:709,t:1526922748498};\\\", \\\"{x:1347,y:711,t:1526922748514};\\\", \\\"{x:1343,y:716,t:1526922748531};\\\", \\\"{x:1341,y:721,t:1526922748547};\\\", \\\"{x:1339,y:726,t:1526922748564};\\\", \\\"{x:1337,y:734,t:1526922748581};\\\", \\\"{x:1334,y:743,t:1526922748597};\\\", \\\"{x:1333,y:751,t:1526922748614};\\\", \\\"{x:1332,y:757,t:1526922748631};\\\", \\\"{x:1330,y:762,t:1526922748647};\\\", \\\"{x:1329,y:766,t:1526922748664};\\\", \\\"{x:1328,y:767,t:1526922748681};\\\", \\\"{x:1326,y:770,t:1526922748697};\\\", \\\"{x:1320,y:774,t:1526922748714};\\\", \\\"{x:1311,y:776,t:1526922748731};\\\", \\\"{x:1296,y:778,t:1526922748747};\\\", \\\"{x:1286,y:779,t:1526922748764};\\\", \\\"{x:1268,y:779,t:1526922748781};\\\", \\\"{x:1249,y:779,t:1526922748798};\\\", \\\"{x:1224,y:777,t:1526922748814};\\\", \\\"{x:1198,y:770,t:1526922748831};\\\", \\\"{x:1147,y:752,t:1526922748847};\\\", \\\"{x:1059,y:735,t:1526922748864};\\\", \\\"{x:1007,y:720,t:1526922748881};\\\", \\\"{x:971,y:716,t:1526922748897};\\\", \\\"{x:926,y:706,t:1526922748914};\\\", \\\"{x:903,y:698,t:1526922748931};\\\", \\\"{x:881,y:690,t:1526922748947};\\\", \\\"{x:862,y:682,t:1526922748964};\\\", \\\"{x:839,y:674,t:1526922748981};\\\", \\\"{x:820,y:667,t:1526922748998};\\\", \\\"{x:801,y:659,t:1526922749014};\\\", \\\"{x:790,y:657,t:1526922749030};\\\", \\\"{x:774,y:654,t:1526922749048};\\\", \\\"{x:768,y:652,t:1526922749063};\\\", \\\"{x:753,y:650,t:1526922749081};\\\", \\\"{x:748,y:648,t:1526922749098};\\\", \\\"{x:743,y:645,t:1526922749114};\\\", \\\"{x:739,y:645,t:1526922749131};\\\", \\\"{x:733,y:643,t:1526922749148};\\\", \\\"{x:725,y:639,t:1526922749164};\\\", \\\"{x:718,y:633,t:1526922749181};\\\", \\\"{x:713,y:629,t:1526922749199};\\\", \\\"{x:704,y:620,t:1526922749215};\\\", \\\"{x:694,y:613,t:1526922749231};\\\", \\\"{x:679,y:603,t:1526922749248};\\\", \\\"{x:667,y:596,t:1526922749264};\\\", \\\"{x:650,y:586,t:1526922749281};\\\", \\\"{x:629,y:571,t:1526922749298};\\\", \\\"{x:617,y:565,t:1526922749314};\\\", \\\"{x:607,y:559,t:1526922749331};\\\", \\\"{x:592,y:554,t:1526922749348};\\\", \\\"{x:572,y:550,t:1526922749365};\\\", \\\"{x:559,y:549,t:1526922749380};\\\", \\\"{x:551,y:546,t:1526922749398};\\\", \\\"{x:550,y:546,t:1526922749415};\\\", \\\"{x:549,y:545,t:1526922749442};\\\", \\\"{x:549,y:544,t:1526922749482};\\\", \\\"{x:549,y:542,t:1526922749506};\\\", \\\"{x:551,y:541,t:1526922749515};\\\", \\\"{x:565,y:539,t:1526922749531};\\\", \\\"{x:586,y:537,t:1526922749548};\\\", \\\"{x:610,y:533,t:1526922749565};\\\", \\\"{x:640,y:528,t:1526922749582};\\\", \\\"{x:680,y:526,t:1526922749598};\\\", \\\"{x:705,y:524,t:1526922749614};\\\", \\\"{x:727,y:520,t:1526922749631};\\\", \\\"{x:749,y:518,t:1526922749648};\\\", \\\"{x:763,y:515,t:1526922749665};\\\", \\\"{x:768,y:513,t:1526922749682};\\\", \\\"{x:768,y:512,t:1526922749738};\\\", \\\"{x:768,y:511,t:1526922749770};\\\", \\\"{x:768,y:510,t:1526922749859};\\\", \\\"{x:768,y:509,t:1526922749866};\\\", \\\"{x:769,y:506,t:1526922749882};\\\", \\\"{x:775,y:505,t:1526922749898};\\\", \\\"{x:783,y:503,t:1526922749915};\\\", \\\"{x:796,y:501,t:1526922749932};\\\", \\\"{x:805,y:501,t:1526922749949};\\\", \\\"{x:814,y:501,t:1526922749966};\\\", \\\"{x:820,y:501,t:1526922749983};\\\", \\\"{x:824,y:501,t:1526922749999};\\\", \\\"{x:825,y:501,t:1526922750015};\\\", \\\"{x:826,y:501,t:1526922750132};\\\", \\\"{x:827,y:501,t:1526922750194};\\\", \\\"{x:827,y:502,t:1526922750401};\\\", \\\"{x:827,y:504,t:1526922750415};\\\", \\\"{x:815,y:509,t:1526922750432};\\\", \\\"{x:796,y:514,t:1526922750449};\\\", \\\"{x:771,y:517,t:1526922750465};\\\", \\\"{x:731,y:525,t:1526922750483};\\\", \\\"{x:707,y:532,t:1526922750499};\\\", \\\"{x:688,y:537,t:1526922750516};\\\", \\\"{x:667,y:544,t:1526922750532};\\\", \\\"{x:651,y:551,t:1526922750549};\\\", \\\"{x:633,y:556,t:1526922750567};\\\", \\\"{x:616,y:561,t:1526922750582};\\\", \\\"{x:599,y:566,t:1526922750600};\\\", \\\"{x:594,y:571,t:1526922750617};\\\", \\\"{x:590,y:574,t:1526922750632};\\\", \\\"{x:583,y:578,t:1526922750649};\\\", \\\"{x:579,y:580,t:1526922750665};\\\", \\\"{x:574,y:582,t:1526922750682};\\\", \\\"{x:570,y:584,t:1526922750699};\\\", \\\"{x:567,y:586,t:1526922750716};\\\", \\\"{x:563,y:587,t:1526922750732};\\\", \\\"{x:558,y:591,t:1526922750749};\\\", \\\"{x:552,y:594,t:1526922750766};\\\", \\\"{x:542,y:598,t:1526922750782};\\\", \\\"{x:534,y:601,t:1526922750800};\\\", \\\"{x:525,y:606,t:1526922750817};\\\", \\\"{x:515,y:608,t:1526922750832};\\\", \\\"{x:509,y:610,t:1526922750849};\\\", \\\"{x:503,y:611,t:1526922750866};\\\", \\\"{x:498,y:613,t:1526922750883};\\\", \\\"{x:496,y:613,t:1526922750899};\\\", \\\"{x:494,y:615,t:1526922750978};\\\", \\\"{x:493,y:615,t:1526922750986};\\\", \\\"{x:492,y:617,t:1526922750999};\\\", \\\"{x:487,y:617,t:1526922751016};\\\", \\\"{x:485,y:617,t:1526922751032};\\\", \\\"{x:484,y:618,t:1526922751049};\\\", \\\"{x:483,y:619,t:1526922751067};\\\", \\\"{x:481,y:619,t:1526922751122};\\\", \\\"{x:479,y:621,t:1526922751133};\\\", \\\"{x:472,y:622,t:1526922751149};\\\", \\\"{x:464,y:623,t:1526922751166};\\\", \\\"{x:460,y:624,t:1526922751183};\\\", \\\"{x:455,y:625,t:1526922751199};\\\", \\\"{x:453,y:627,t:1526922751216};\\\", \\\"{x:448,y:628,t:1526922751233};\\\", \\\"{x:447,y:628,t:1526922751249};\\\", \\\"{x:445,y:628,t:1526922751386};\\\", \\\"{x:442,y:628,t:1526922751410};\\\", \\\"{x:441,y:628,t:1526922751499};\\\", \\\"{x:439,y:628,t:1526922751538};\\\", \\\"{x:438,y:628,t:1526922751562};\\\", \\\"{x:436,y:627,t:1526922751570};\\\", \\\"{x:435,y:626,t:1526922751583};\\\", \\\"{x:431,y:622,t:1526922751600};\\\", \\\"{x:429,y:619,t:1526922751616};\\\", \\\"{x:427,y:617,t:1526922751634};\\\", \\\"{x:423,y:614,t:1526922751649};\\\", \\\"{x:415,y:609,t:1526922751666};\\\", \\\"{x:412,y:606,t:1526922751683};\\\", \\\"{x:408,y:603,t:1526922751699};\\\", \\\"{x:403,y:597,t:1526922751716};\\\", \\\"{x:400,y:596,t:1526922751734};\\\", \\\"{x:398,y:593,t:1526922751751};\\\", \\\"{x:396,y:591,t:1526922751766};\\\", \\\"{x:393,y:591,t:1526922751783};\\\", \\\"{x:388,y:588,t:1526922751800};\\\", \\\"{x:386,y:588,t:1526922751816};\\\", \\\"{x:384,y:585,t:1526922751833};\\\", \\\"{x:379,y:579,t:1526922751850};\\\", \\\"{x:373,y:576,t:1526922751868};\\\", \\\"{x:369,y:572,t:1526922751883};\\\", \\\"{x:365,y:570,t:1526922751900};\\\", \\\"{x:356,y:568,t:1526922751916};\\\", \\\"{x:341,y:567,t:1526922751933};\\\", \\\"{x:323,y:566,t:1526922751950};\\\", \\\"{x:304,y:566,t:1526922751966};\\\", \\\"{x:280,y:565,t:1526922751983};\\\", \\\"{x:263,y:565,t:1526922752001};\\\", \\\"{x:255,y:565,t:1526922752017};\\\", \\\"{x:249,y:564,t:1526922752033};\\\", \\\"{x:248,y:564,t:1526922752050};\\\", \\\"{x:247,y:563,t:1526922752114};\\\", \\\"{x:247,y:561,t:1526922752154};\\\", \\\"{x:246,y:560,t:1526922752194};\\\", \\\"{x:243,y:559,t:1526922752202};\\\", \\\"{x:238,y:559,t:1526922752217};\\\", \\\"{x:226,y:559,t:1526922752233};\\\", \\\"{x:209,y:558,t:1526922752250};\\\", \\\"{x:198,y:558,t:1526922752267};\\\", \\\"{x:195,y:558,t:1526922752285};\\\", \\\"{x:193,y:558,t:1526922752300};\\\", \\\"{x:191,y:558,t:1526922752338};\\\", \\\"{x:190,y:558,t:1526922752354};\\\", \\\"{x:188,y:558,t:1526922752378};\\\", \\\"{x:187,y:557,t:1526922752459};\\\", \\\"{x:185,y:557,t:1526922752468};\\\", \\\"{x:180,y:556,t:1526922752485};\\\", \\\"{x:179,y:555,t:1526922752502};\\\", \\\"{x:177,y:554,t:1526922752517};\\\", \\\"{x:176,y:554,t:1526922752533};\\\", \\\"{x:175,y:554,t:1526922752550};\\\", \\\"{x:174,y:554,t:1526922752567};\\\", \\\"{x:171,y:552,t:1526922752583};\\\", \\\"{x:168,y:551,t:1526922752600};\\\", \\\"{x:167,y:551,t:1526922752617};\\\", \\\"{x:164,y:550,t:1526922752634};\\\", \\\"{x:161,y:548,t:1526922752650};\\\", \\\"{x:159,y:547,t:1526922752667};\\\", \\\"{x:156,y:546,t:1526922752684};\\\", \\\"{x:151,y:544,t:1526922752701};\\\", \\\"{x:149,y:543,t:1526922752718};\\\", \\\"{x:147,y:543,t:1526922752735};\\\", \\\"{x:145,y:541,t:1526922752750};\\\", \\\"{x:143,y:540,t:1526922752767};\\\", \\\"{x:143,y:539,t:1526922752784};\\\", \\\"{x:143,y:542,t:1526922758794};\\\", \\\"{x:150,y:550,t:1526922758809};\\\", \\\"{x:184,y:573,t:1526922758824};\\\", \\\"{x:225,y:599,t:1526922758841};\\\", \\\"{x:371,y:658,t:1526922758872};\\\", \\\"{x:457,y:682,t:1526922758887};\\\", \\\"{x:508,y:704,t:1526922758905};\\\", \\\"{x:565,y:726,t:1526922758922};\\\", \\\"{x:617,y:746,t:1526922758939};\\\", \\\"{x:655,y:767,t:1526922758955};\\\", \\\"{x:679,y:778,t:1526922758972};\\\", \\\"{x:708,y:790,t:1526922758989};\\\", \\\"{x:725,y:799,t:1526922759005};\\\", \\\"{x:756,y:814,t:1526922759022};\\\", \\\"{x:784,y:824,t:1526922759039};\\\", \\\"{x:821,y:838,t:1526922759056};\\\", \\\"{x:851,y:849,t:1526922759073};\\\", \\\"{x:895,y:861,t:1526922759089};\\\", \\\"{x:939,y:865,t:1526922759105};\\\", \\\"{x:994,y:872,t:1526922759122};\\\", \\\"{x:1016,y:875,t:1526922759139};\\\", \\\"{x:1034,y:875,t:1526922759155};\\\", \\\"{x:1054,y:875,t:1526922759172};\\\", \\\"{x:1069,y:874,t:1526922759189};\\\", \\\"{x:1085,y:872,t:1526922759205};\\\", \\\"{x:1095,y:869,t:1526922759222};\\\", \\\"{x:1108,y:865,t:1526922759239};\\\", \\\"{x:1116,y:863,t:1526922759256};\\\", \\\"{x:1122,y:860,t:1526922759272};\\\", \\\"{x:1139,y:859,t:1526922759290};\\\", \\\"{x:1156,y:856,t:1526922759306};\\\", \\\"{x:1186,y:854,t:1526922759323};\\\", \\\"{x:1205,y:854,t:1526922759340};\\\", \\\"{x:1223,y:855,t:1526922759356};\\\", \\\"{x:1242,y:855,t:1526922759373};\\\", \\\"{x:1264,y:856,t:1526922759390};\\\", \\\"{x:1294,y:856,t:1526922759407};\\\", \\\"{x:1323,y:859,t:1526922759423};\\\", \\\"{x:1340,y:862,t:1526922759440};\\\", \\\"{x:1359,y:865,t:1526922759457};\\\", \\\"{x:1375,y:869,t:1526922759473};\\\", \\\"{x:1393,y:872,t:1526922759490};\\\", \\\"{x:1398,y:873,t:1526922759506};\\\", \\\"{x:1411,y:876,t:1526922759522};\\\", \\\"{x:1423,y:877,t:1526922759539};\\\", \\\"{x:1434,y:879,t:1526922759556};\\\", \\\"{x:1443,y:881,t:1526922759572};\\\", \\\"{x:1454,y:884,t:1526922759589};\\\", \\\"{x:1462,y:885,t:1526922759607};\\\", \\\"{x:1470,y:886,t:1526922759622};\\\", \\\"{x:1474,y:886,t:1526922759639};\\\", \\\"{x:1475,y:886,t:1526922759656};\\\", \\\"{x:1476,y:886,t:1526922759697};\\\", \\\"{x:1478,y:883,t:1526922759706};\\\", \\\"{x:1478,y:877,t:1526922759722};\\\", \\\"{x:1478,y:865,t:1526922759739};\\\", \\\"{x:1479,y:849,t:1526922759756};\\\", \\\"{x:1479,y:837,t:1526922759772};\\\", \\\"{x:1479,y:823,t:1526922759790};\\\", \\\"{x:1477,y:810,t:1526922759806};\\\", \\\"{x:1474,y:803,t:1526922759823};\\\", \\\"{x:1472,y:800,t:1526922759839};\\\", \\\"{x:1470,y:797,t:1526922759856};\\\", \\\"{x:1468,y:796,t:1526922759872};\\\", \\\"{x:1466,y:796,t:1526922759978};\\\", \\\"{x:1464,y:796,t:1526922759990};\\\", \\\"{x:1460,y:798,t:1526922760007};\\\", \\\"{x:1459,y:802,t:1526922760022};\\\", \\\"{x:1457,y:806,t:1526922760039};\\\", \\\"{x:1456,y:807,t:1526922760057};\\\", \\\"{x:1456,y:809,t:1526922760072};\\\", \\\"{x:1456,y:810,t:1526922760089};\\\", \\\"{x:1456,y:809,t:1526922760178};\\\", \\\"{x:1456,y:805,t:1526922760190};\\\", \\\"{x:1456,y:795,t:1526922760206};\\\", \\\"{x:1456,y:786,t:1526922760224};\\\", \\\"{x:1456,y:779,t:1526922760240};\\\", \\\"{x:1457,y:769,t:1526922760257};\\\", \\\"{x:1457,y:756,t:1526922760274};\\\", \\\"{x:1457,y:752,t:1526922760290};\\\", \\\"{x:1457,y:747,t:1526922760307};\\\", \\\"{x:1457,y:742,t:1526922760324};\\\", \\\"{x:1457,y:739,t:1526922760339};\\\", \\\"{x:1457,y:738,t:1526922760356};\\\", \\\"{x:1456,y:742,t:1526922760442};\\\", \\\"{x:1453,y:743,t:1526922760457};\\\", \\\"{x:1449,y:752,t:1526922760474};\\\", \\\"{x:1447,y:756,t:1526922760490};\\\", \\\"{x:1447,y:757,t:1526922760530};\\\", \\\"{x:1446,y:757,t:1526922760562};\\\", \\\"{x:1445,y:753,t:1526922760573};\\\", \\\"{x:1444,y:744,t:1526922760590};\\\", \\\"{x:1441,y:725,t:1526922760606};\\\", \\\"{x:1439,y:708,t:1526922760624};\\\", \\\"{x:1435,y:692,t:1526922760640};\\\", \\\"{x:1430,y:682,t:1526922760656};\\\", \\\"{x:1425,y:670,t:1526922760674};\\\", \\\"{x:1423,y:667,t:1526922760690};\\\", \\\"{x:1423,y:666,t:1526922760722};\\\", \\\"{x:1423,y:665,t:1526922760738};\\\", \\\"{x:1423,y:664,t:1526922760794};\\\", \\\"{x:1423,y:663,t:1526922760825};\\\", \\\"{x:1423,y:661,t:1526922760850};\\\", \\\"{x:1425,y:659,t:1526922760865};\\\", \\\"{x:1427,y:657,t:1526922760882};\\\", \\\"{x:1428,y:656,t:1526922760890};\\\", \\\"{x:1430,y:652,t:1526922760906};\\\", \\\"{x:1434,y:648,t:1526922760924};\\\", \\\"{x:1439,y:643,t:1526922760941};\\\", \\\"{x:1441,y:640,t:1526922760956};\\\", \\\"{x:1442,y:639,t:1526922760978};\\\", \\\"{x:1442,y:638,t:1526922760991};\\\", \\\"{x:1442,y:637,t:1526922761007};\\\", \\\"{x:1444,y:637,t:1526922761024};\\\", \\\"{x:1444,y:635,t:1526922761330};\\\", \\\"{x:1445,y:634,t:1526922761346};\\\", \\\"{x:1447,y:631,t:1526922761373};\\\", \\\"{x:1447,y:632,t:1526922761586};\\\", \\\"{x:1447,y:633,t:1526922761602};\\\", \\\"{x:1447,y:634,t:1526922761610};\\\", \\\"{x:1446,y:637,t:1526922761624};\\\", \\\"{x:1446,y:640,t:1526922761640};\\\", \\\"{x:1445,y:647,t:1526922761658};\\\", \\\"{x:1444,y:653,t:1526922761674};\\\", \\\"{x:1444,y:657,t:1526922761691};\\\", \\\"{x:1444,y:663,t:1526922761708};\\\", \\\"{x:1444,y:667,t:1526922761723};\\\", \\\"{x:1444,y:672,t:1526922761741};\\\", \\\"{x:1444,y:677,t:1526922761757};\\\", \\\"{x:1444,y:682,t:1526922761773};\\\", \\\"{x:1444,y:684,t:1526922761791};\\\", \\\"{x:1444,y:690,t:1526922761808};\\\", \\\"{x:1444,y:697,t:1526922761824};\\\", \\\"{x:1444,y:705,t:1526922761841};\\\", \\\"{x:1445,y:717,t:1526922761858};\\\", \\\"{x:1447,y:727,t:1526922761874};\\\", \\\"{x:1448,y:736,t:1526922761891};\\\", \\\"{x:1448,y:744,t:1526922761908};\\\", \\\"{x:1448,y:751,t:1526922761923};\\\", \\\"{x:1448,y:760,t:1526922761941};\\\", \\\"{x:1448,y:764,t:1526922761958};\\\", \\\"{x:1448,y:768,t:1526922761974};\\\", \\\"{x:1448,y:770,t:1526922761991};\\\", \\\"{x:1448,y:774,t:1526922762008};\\\", \\\"{x:1448,y:779,t:1526922762023};\\\", \\\"{x:1448,y:783,t:1526922762041};\\\", \\\"{x:1448,y:791,t:1526922762058};\\\", \\\"{x:1448,y:796,t:1526922762074};\\\", \\\"{x:1448,y:800,t:1526922762091};\\\", \\\"{x:1448,y:802,t:1526922762107};\\\", \\\"{x:1448,y:803,t:1526922762124};\\\", \\\"{x:1449,y:807,t:1526922762141};\\\", \\\"{x:1449,y:811,t:1526922762158};\\\", \\\"{x:1449,y:814,t:1526922762175};\\\", \\\"{x:1449,y:816,t:1526922762190};\\\", \\\"{x:1451,y:818,t:1526922762207};\\\", \\\"{x:1451,y:820,t:1526922762224};\\\", \\\"{x:1451,y:822,t:1526922762240};\\\", \\\"{x:1452,y:824,t:1526922762257};\\\", \\\"{x:1452,y:826,t:1526922762273};\\\", \\\"{x:1452,y:829,t:1526922762290};\\\", \\\"{x:1452,y:833,t:1526922762307};\\\", \\\"{x:1453,y:835,t:1526922762324};\\\", \\\"{x:1453,y:836,t:1526922762340};\\\", \\\"{x:1453,y:837,t:1526922762357};\\\", \\\"{x:1453,y:839,t:1526922762375};\\\", \\\"{x:1454,y:840,t:1526922762391};\\\", \\\"{x:1454,y:842,t:1526922762407};\\\", \\\"{x:1455,y:843,t:1526922762424};\\\", \\\"{x:1455,y:845,t:1526922762442};\\\", \\\"{x:1455,y:846,t:1526922762458};\\\", \\\"{x:1455,y:847,t:1526922762474};\\\", \\\"{x:1455,y:848,t:1526922762522};\\\", \\\"{x:1455,y:850,t:1526922762538};\\\", \\\"{x:1455,y:852,t:1526922762562};\\\", \\\"{x:1455,y:853,t:1526922762586};\\\", \\\"{x:1455,y:855,t:1526922762610};\\\", \\\"{x:1456,y:856,t:1526922762642};\\\", \\\"{x:1456,y:857,t:1526922763490};\\\", \\\"{x:1452,y:859,t:1526922763497};\\\", \\\"{x:1450,y:859,t:1526922763508};\\\", \\\"{x:1443,y:861,t:1526922763524};\\\", \\\"{x:1433,y:865,t:1526922763541};\\\", \\\"{x:1419,y:869,t:1526922763558};\\\", \\\"{x:1400,y:871,t:1526922763574};\\\", \\\"{x:1377,y:874,t:1526922763592};\\\", \\\"{x:1330,y:877,t:1526922763608};\\\", \\\"{x:1295,y:881,t:1526922763624};\\\", \\\"{x:1156,y:881,t:1526922763642};\\\", \\\"{x:1067,y:881,t:1526922763659};\\\", \\\"{x:959,y:866,t:1526922763675};\\\", \\\"{x:859,y:848,t:1526922763691};\\\", \\\"{x:766,y:833,t:1526922763709};\\\", \\\"{x:702,y:821,t:1526922763725};\\\", \\\"{x:662,y:809,t:1526922763742};\\\", \\\"{x:641,y:805,t:1526922763758};\\\", \\\"{x:624,y:799,t:1526922763775};\\\", \\\"{x:615,y:796,t:1526922763792};\\\", \\\"{x:611,y:795,t:1526922763809};\\\", \\\"{x:610,y:795,t:1526922763825};\\\", \\\"{x:601,y:794,t:1526922763841};\\\", \\\"{x:594,y:793,t:1526922763858};\\\", \\\"{x:584,y:793,t:1526922763875};\\\", \\\"{x:569,y:793,t:1526922763892};\\\", \\\"{x:551,y:787,t:1526922763909};\\\", \\\"{x:531,y:783,t:1526922763925};\\\", \\\"{x:525,y:779,t:1526922763942};\\\", \\\"{x:518,y:776,t:1526922763959};\\\", \\\"{x:511,y:773,t:1526922763976};\\\", \\\"{x:509,y:770,t:1526922763991};\\\", \\\"{x:508,y:769,t:1526922764009};\\\", \\\"{x:507,y:762,t:1526922764025};\\\", \\\"{x:507,y:760,t:1526922764042};\\\", \\\"{x:507,y:759,t:1526922764058};\\\", \\\"{x:507,y:756,t:1526922764076};\\\", \\\"{x:507,y:754,t:1526922764098};\\\", \\\"{x:507,y:751,t:1526922764114};\\\", \\\"{x:508,y:750,t:1526922764161};\\\", \\\"{x:509,y:749,t:1526922764722};\\\", \\\"{x:509,y:748,t:1526922764729};\\\", \\\"{x:509,y:746,t:1526922764743};\\\", \\\"{x:509,y:745,t:1526922764760};\\\", \\\"{x:502,y:732,t:1526922764777};\\\", \\\"{x:488,y:720,t:1526922764793};\\\", \\\"{x:467,y:704,t:1526922764810};\\\", \\\"{x:426,y:686,t:1526922764829};\\\", \\\"{x:369,y:658,t:1526922764844};\\\", \\\"{x:306,y:631,t:1526922764861};\\\", \\\"{x:253,y:611,t:1526922764879};\\\", \\\"{x:221,y:594,t:1526922764894};\\\", \\\"{x:212,y:586,t:1526922764910};\\\", \\\"{x:207,y:579,t:1526922764927};\\\", \\\"{x:204,y:571,t:1526922764943};\\\", \\\"{x:202,y:564,t:1526922764960};\\\", \\\"{x:199,y:559,t:1526922764977};\\\", \\\"{x:197,y:553,t:1526922764993};\\\", \\\"{x:195,y:549,t:1526922765011};\\\", \\\"{x:195,y:548,t:1526922765050};\\\", \\\"{x:193,y:548,t:1526922765137};\\\", \\\"{x:190,y:548,t:1526922765146};\\\", \\\"{x:185,y:549,t:1526922765161};\\\", \\\"{x:181,y:549,t:1526922765178};\\\", \\\"{x:178,y:549,t:1526922765194};\\\", \\\"{x:177,y:548,t:1526922765210};\\\", \\\"{x:174,y:548,t:1526922765227};\\\", \\\"{x:170,y:546,t:1526922765245};\\\", \\\"{x:168,y:546,t:1526922765262};\\\", \\\"{x:167,y:546,t:1526922765277};\\\", \\\"{x:166,y:546,t:1526922765297};\\\", \\\"{x:166,y:545,t:1526922765311};\\\", \\\"{x:166,y:546,t:1526922765610};\\\", \\\"{x:167,y:548,t:1526922765627};\\\", \\\"{x:172,y:554,t:1526922765644};\\\", \\\"{x:181,y:562,t:1526922765661};\\\", \\\"{x:197,y:571,t:1526922765678};\\\", \\\"{x:209,y:581,t:1526922765695};\\\", \\\"{x:228,y:594,t:1526922765712};\\\", \\\"{x:254,y:609,t:1526922765728};\\\", \\\"{x:284,y:627,t:1526922765745};\\\", \\\"{x:302,y:639,t:1526922765761};\\\", \\\"{x:333,y:657,t:1526922765777};\\\", \\\"{x:346,y:669,t:1526922765794};\\\", \\\"{x:366,y:681,t:1526922765813};\\\", \\\"{x:380,y:693,t:1526922765828};\\\", \\\"{x:396,y:703,t:1526922765844};\\\", \\\"{x:411,y:712,t:1526922765861};\\\", \\\"{x:426,y:719,t:1526922765878};\\\", \\\"{x:443,y:725,t:1526922765894};\\\", \\\"{x:459,y:731,t:1526922765911};\\\", \\\"{x:473,y:735,t:1526922765929};\\\", \\\"{x:480,y:740,t:1526922765944};\\\", \\\"{x:495,y:744,t:1526922765961};\\\", \\\"{x:506,y:747,t:1526922765977};\\\", \\\"{x:511,y:749,t:1526922765995};\\\", \\\"{x:514,y:750,t:1526922766011};\\\", \\\"{x:519,y:751,t:1526922766028};\\\", \\\"{x:521,y:752,t:1526922766044};\\\", \\\"{x:525,y:754,t:1526922766062};\\\", \\\"{x:530,y:754,t:1526922766078};\\\", \\\"{x:532,y:756,t:1526922766095};\\\", \\\"{x:535,y:756,t:1526922766111};\\\", \\\"{x:537,y:756,t:1526922766127};\\\", \\\"{x:538,y:756,t:1526922766145};\\\", \\\"{x:539,y:756,t:1526922766177};\\\", \\\"{x:540,y:756,t:1526922766210};\\\", \\\"{x:542,y:756,t:1526922766249};\\\", \\\"{x:542,y:755,t:1526922766262};\\\", \\\"{x:544,y:752,t:1526922766279};\\\", \\\"{x:545,y:751,t:1526922766295};\\\", \\\"{x:545,y:750,t:1526922766378};\\\", \\\"{x:545,y:749,t:1526922766410};\\\", \\\"{x:545,y:748,t:1526922766482};\\\", \\\"{x:544,y:746,t:1526922767346};\\\", \\\"{x:541,y:744,t:1526922767362};\\\", \\\"{x:541,y:742,t:1526922767378};\\\", \\\"{x:540,y:739,t:1526922767396};\\\", \\\"{x:539,y:738,t:1526922767412};\\\", \\\"{x:538,y:737,t:1526922767428};\\\", \\\"{x:538,y:736,t:1526922767445};\\\", \\\"{x:537,y:735,t:1526922767462};\\\", \\\"{x:535,y:735,t:1526922767478};\\\", \\\"{x:534,y:735,t:1526922767495};\\\", \\\"{x:532,y:735,t:1526922768441};\\\", \\\"{x:531,y:735,t:1526922768449};\\\", \\\"{x:529,y:735,t:1526922768465};\\\", \\\"{x:527,y:735,t:1526922768479};\\\", \\\"{x:526,y:735,t:1526922768498};\\\" ] }, { \\\"rt\\\": 58193, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 258549, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -F -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:735,t:1526922769993};\\\", \\\"{x:521,y:735,t:1526922770001};\\\", \\\"{x:510,y:735,t:1526922770015};\\\", \\\"{x:486,y:740,t:1526922770031};\\\", \\\"{x:473,y:745,t:1526922770049};\\\", \\\"{x:465,y:745,t:1526922770065};\\\", \\\"{x:460,y:748,t:1526922770081};\\\", \\\"{x:450,y:749,t:1526922770099};\\\", \\\"{x:444,y:749,t:1526922770116};\\\", \\\"{x:441,y:752,t:1526922770132};\\\", \\\"{x:435,y:753,t:1526922770148};\\\", \\\"{x:430,y:756,t:1526922770165};\\\", \\\"{x:425,y:757,t:1526922770181};\\\", \\\"{x:422,y:759,t:1526922770197};\\\", \\\"{x:420,y:763,t:1526922770215};\\\", \\\"{x:412,y:764,t:1526922770231};\\\", \\\"{x:405,y:766,t:1526922770248};\\\", \\\"{x:402,y:767,t:1526922770264};\\\", \\\"{x:397,y:769,t:1526922770281};\\\", \\\"{x:394,y:770,t:1526922770297};\\\", \\\"{x:393,y:770,t:1526922770322};\\\", \\\"{x:392,y:771,t:1526922770332};\\\", \\\"{x:391,y:771,t:1526922770514};\\\", \\\"{x:389,y:771,t:1526922770593};\\\", \\\"{x:392,y:771,t:1526922771225};\\\", \\\"{x:402,y:769,t:1526922771233};\\\", \\\"{x:419,y:763,t:1526922771248};\\\", \\\"{x:487,y:743,t:1526922771266};\\\", \\\"{x:567,y:734,t:1526922771282};\\\", \\\"{x:679,y:724,t:1526922771299};\\\", \\\"{x:799,y:720,t:1526922771316};\\\", \\\"{x:955,y:724,t:1526922771332};\\\", \\\"{x:1118,y:726,t:1526922771348};\\\", \\\"{x:1254,y:726,t:1526922771366};\\\", \\\"{x:1386,y:714,t:1526922771382};\\\", \\\"{x:1499,y:698,t:1526922771399};\\\", \\\"{x:1596,y:684,t:1526922771415};\\\", \\\"{x:1671,y:666,t:1526922771433};\\\", \\\"{x:1723,y:647,t:1526922771448};\\\", \\\"{x:1752,y:631,t:1526922771465};\\\", \\\"{x:1754,y:619,t:1526922771483};\\\", \\\"{x:1755,y:608,t:1526922771499};\\\", \\\"{x:1754,y:597,t:1526922771516};\\\", \\\"{x:1744,y:582,t:1526922771533};\\\", \\\"{x:1737,y:572,t:1526922771549};\\\", \\\"{x:1718,y:553,t:1526922771566};\\\", \\\"{x:1696,y:534,t:1526922771582};\\\", \\\"{x:1679,y:520,t:1526922771599};\\\", \\\"{x:1661,y:508,t:1526922771616};\\\", \\\"{x:1645,y:499,t:1526922771632};\\\", \\\"{x:1624,y:488,t:1526922771648};\\\", \\\"{x:1591,y:476,t:1526922771665};\\\", \\\"{x:1574,y:475,t:1526922771682};\\\", \\\"{x:1564,y:475,t:1526922771699};\\\", \\\"{x:1553,y:475,t:1526922771715};\\\", \\\"{x:1548,y:475,t:1526922771733};\\\", \\\"{x:1545,y:475,t:1526922771749};\\\", \\\"{x:1543,y:475,t:1526922771769};\\\", \\\"{x:1542,y:477,t:1526922771785};\\\", \\\"{x:1541,y:477,t:1526922771801};\\\", \\\"{x:1540,y:479,t:1526922771815};\\\", \\\"{x:1538,y:482,t:1526922771833};\\\", \\\"{x:1536,y:483,t:1526922771849};\\\", \\\"{x:1535,y:484,t:1526922771866};\\\", \\\"{x:1532,y:485,t:1526922771889};\\\", \\\"{x:1530,y:488,t:1526922771905};\\\", \\\"{x:1528,y:488,t:1526922771916};\\\", \\\"{x:1520,y:492,t:1526922771933};\\\", \\\"{x:1512,y:494,t:1526922771949};\\\", \\\"{x:1504,y:498,t:1526922771966};\\\", \\\"{x:1495,y:500,t:1526922771982};\\\", \\\"{x:1489,y:500,t:1526922772000};\\\", \\\"{x:1486,y:501,t:1526922772016};\\\", \\\"{x:1485,y:501,t:1526922772082};\\\", \\\"{x:1480,y:505,t:1526922779370};\\\", \\\"{x:1479,y:509,t:1526922779378};\\\", \\\"{x:1472,y:515,t:1526922779394};\\\", \\\"{x:1469,y:519,t:1526922779411};\\\", \\\"{x:1461,y:527,t:1526922779427};\\\", \\\"{x:1458,y:530,t:1526922779445};\\\", \\\"{x:1456,y:537,t:1526922779461};\\\", \\\"{x:1455,y:543,t:1526922779478};\\\", \\\"{x:1455,y:557,t:1526922779494};\\\", \\\"{x:1458,y:570,t:1526922779512};\\\", \\\"{x:1462,y:583,t:1526922779529};\\\", \\\"{x:1466,y:595,t:1526922779545};\\\", \\\"{x:1468,y:613,t:1526922779562};\\\", \\\"{x:1468,y:624,t:1526922779578};\\\", \\\"{x:1468,y:633,t:1526922779595};\\\", \\\"{x:1463,y:645,t:1526922779611};\\\", \\\"{x:1459,y:658,t:1526922779629};\\\", \\\"{x:1450,y:674,t:1526922779644};\\\", \\\"{x:1441,y:688,t:1526922779661};\\\", \\\"{x:1434,y:700,t:1526922779679};\\\", \\\"{x:1426,y:711,t:1526922779695};\\\", \\\"{x:1419,y:718,t:1526922779712};\\\", \\\"{x:1415,y:721,t:1526922779729};\\\", \\\"{x:1411,y:725,t:1526922779744};\\\", \\\"{x:1394,y:735,t:1526922779762};\\\", \\\"{x:1377,y:739,t:1526922779778};\\\", \\\"{x:1365,y:745,t:1526922779794};\\\", \\\"{x:1352,y:748,t:1526922779812};\\\", \\\"{x:1342,y:752,t:1526922779829};\\\", \\\"{x:1339,y:752,t:1526922779845};\\\", \\\"{x:1338,y:753,t:1526922779882};\\\", \\\"{x:1337,y:754,t:1526922779906};\\\", \\\"{x:1335,y:755,t:1526922779914};\\\", \\\"{x:1334,y:757,t:1526922779928};\\\", \\\"{x:1331,y:759,t:1526922779944};\\\", \\\"{x:1330,y:760,t:1526922779961};\\\", \\\"{x:1329,y:761,t:1526922780114};\\\", \\\"{x:1329,y:762,t:1526922780138};\\\", \\\"{x:1329,y:763,t:1526922780218};\\\", \\\"{x:1330,y:763,t:1526922780698};\\\", \\\"{x:1331,y:763,t:1526922780713};\\\", \\\"{x:1332,y:763,t:1526922780801};\\\", \\\"{x:1334,y:763,t:1526922780914};\\\", \\\"{x:1335,y:763,t:1526922781346};\\\", \\\"{x:1336,y:763,t:1526922781362};\\\", \\\"{x:1337,y:763,t:1526922781380};\\\", \\\"{x:1338,y:763,t:1526922781402};\\\", \\\"{x:1340,y:763,t:1526922781449};\\\", \\\"{x:1341,y:763,t:1526922781482};\\\", \\\"{x:1343,y:763,t:1526922781596};\\\", \\\"{x:1342,y:763,t:1526922790209};\\\", \\\"{x:1341,y:763,t:1526922790363};\\\", \\\"{x:1341,y:764,t:1526922792090};\\\", \\\"{x:1340,y:764,t:1526922792104};\\\", \\\"{x:1338,y:765,t:1526922792946};\\\", \\\"{x:1337,y:765,t:1526922792986};\\\", \\\"{x:1336,y:766,t:1526922793129};\\\", \\\"{x:1335,y:766,t:1526922793145};\\\", \\\"{x:1334,y:767,t:1526922793201};\\\", \\\"{x:1333,y:767,t:1526922793225};\\\", \\\"{x:1332,y:767,t:1526922793238};\\\", \\\"{x:1331,y:768,t:1526922793255};\\\", \\\"{x:1330,y:768,t:1526922793272};\\\", \\\"{x:1329,y:770,t:1526922793288};\\\", \\\"{x:1326,y:770,t:1526922793305};\\\", \\\"{x:1325,y:771,t:1526922793322};\\\", \\\"{x:1323,y:772,t:1526922793338};\\\", \\\"{x:1321,y:773,t:1526922793355};\\\", \\\"{x:1320,y:774,t:1526922793372};\\\", \\\"{x:1319,y:775,t:1526922793388};\\\", \\\"{x:1318,y:775,t:1526922793405};\\\", \\\"{x:1315,y:777,t:1526922793422};\\\", \\\"{x:1314,y:777,t:1526922793438};\\\", \\\"{x:1313,y:778,t:1526922793455};\\\", \\\"{x:1311,y:778,t:1526922793472};\\\", \\\"{x:1310,y:778,t:1526922793497};\\\", \\\"{x:1309,y:778,t:1526922793505};\\\", \\\"{x:1306,y:779,t:1526922793538};\\\", \\\"{x:1305,y:779,t:1526922793562};\\\", \\\"{x:1304,y:779,t:1526922793573};\\\", \\\"{x:1303,y:780,t:1526922793588};\\\", \\\"{x:1302,y:780,t:1526922793605};\\\", \\\"{x:1302,y:781,t:1526922793634};\\\", \\\"{x:1302,y:780,t:1526922793906};\\\", \\\"{x:1302,y:778,t:1526922793922};\\\", \\\"{x:1302,y:776,t:1526922793945};\\\", \\\"{x:1302,y:775,t:1526922793955};\\\", \\\"{x:1302,y:773,t:1526922793972};\\\", \\\"{x:1303,y:772,t:1526922793993};\\\", \\\"{x:1304,y:771,t:1526922794005};\\\", \\\"{x:1306,y:770,t:1526922794022};\\\", \\\"{x:1307,y:769,t:1526922794039};\\\", \\\"{x:1309,y:767,t:1526922794055};\\\", \\\"{x:1310,y:767,t:1526922794072};\\\", \\\"{x:1311,y:767,t:1526922794089};\\\", \\\"{x:1313,y:765,t:1526922794105};\\\", \\\"{x:1315,y:764,t:1526922794130};\\\", \\\"{x:1317,y:764,t:1526922794146};\\\", \\\"{x:1320,y:762,t:1526922794155};\\\", \\\"{x:1322,y:760,t:1526922794172};\\\", \\\"{x:1323,y:759,t:1526922794189};\\\", \\\"{x:1324,y:759,t:1526922794206};\\\", \\\"{x:1325,y:758,t:1526922794222};\\\", \\\"{x:1326,y:757,t:1526922794240};\\\", \\\"{x:1327,y:757,t:1526922794274};\\\", \\\"{x:1328,y:757,t:1526922794290};\\\", \\\"{x:1330,y:755,t:1526922794306};\\\", \\\"{x:1332,y:755,t:1526922794322};\\\", \\\"{x:1333,y:755,t:1526922794345};\\\", \\\"{x:1334,y:754,t:1526922794361};\\\", \\\"{x:1335,y:754,t:1526922794385};\\\", \\\"{x:1336,y:754,t:1526922794426};\\\", \\\"{x:1337,y:753,t:1526922794481};\\\", \\\"{x:1338,y:753,t:1526922794529};\\\", \\\"{x:1339,y:753,t:1526922794794};\\\", \\\"{x:1340,y:754,t:1526922794806};\\\", \\\"{x:1341,y:755,t:1526922794921};\\\", \\\"{x:1341,y:756,t:1526922795065};\\\", \\\"{x:1341,y:757,t:1526922795097};\\\", \\\"{x:1341,y:756,t:1526922795361};\\\", \\\"{x:1341,y:755,t:1526922795373};\\\", \\\"{x:1341,y:754,t:1526922795390};\\\", \\\"{x:1341,y:752,t:1526922795406};\\\", \\\"{x:1341,y:750,t:1526922795423};\\\", \\\"{x:1341,y:749,t:1526922795440};\\\", \\\"{x:1340,y:748,t:1526922795456};\\\", \\\"{x:1340,y:747,t:1526922795473};\\\", \\\"{x:1340,y:746,t:1526922795490};\\\", \\\"{x:1340,y:744,t:1526922795506};\\\", \\\"{x:1340,y:743,t:1526922795523};\\\", \\\"{x:1340,y:742,t:1526922795540};\\\", \\\"{x:1340,y:741,t:1526922795557};\\\", \\\"{x:1340,y:740,t:1526922795573};\\\", \\\"{x:1340,y:738,t:1526922795591};\\\", \\\"{x:1340,y:736,t:1526922795606};\\\", \\\"{x:1340,y:734,t:1526922795626};\\\", \\\"{x:1340,y:733,t:1526922795640};\\\", \\\"{x:1340,y:731,t:1526922795657};\\\", \\\"{x:1340,y:729,t:1526922795673};\\\", \\\"{x:1341,y:727,t:1526922795690};\\\", \\\"{x:1342,y:725,t:1526922795707};\\\", \\\"{x:1342,y:723,t:1526922795723};\\\", \\\"{x:1343,y:720,t:1526922795740};\\\", \\\"{x:1343,y:718,t:1526922795770};\\\", \\\"{x:1343,y:717,t:1526922795785};\\\", \\\"{x:1345,y:715,t:1526922795809};\\\", \\\"{x:1345,y:713,t:1526922795823};\\\", \\\"{x:1345,y:711,t:1526922795840};\\\", \\\"{x:1346,y:707,t:1526922795857};\\\", \\\"{x:1346,y:704,t:1526922795873};\\\", \\\"{x:1347,y:703,t:1526922795890};\\\", \\\"{x:1348,y:700,t:1526922795907};\\\", \\\"{x:1348,y:698,t:1526922795923};\\\", \\\"{x:1348,y:697,t:1526922795940};\\\", \\\"{x:1349,y:695,t:1526922795957};\\\", \\\"{x:1349,y:694,t:1526922795973};\\\", \\\"{x:1349,y:692,t:1526922795993};\\\", \\\"{x:1349,y:691,t:1526922796321};\\\", \\\"{x:1349,y:690,t:1526922796337};\\\", \\\"{x:1348,y:689,t:1526922796354};\\\", \\\"{x:1347,y:688,t:1526922796362};\\\", \\\"{x:1345,y:687,t:1526922796374};\\\", \\\"{x:1344,y:685,t:1526922796390};\\\", \\\"{x:1344,y:684,t:1526922796407};\\\", \\\"{x:1341,y:681,t:1526922796424};\\\", \\\"{x:1341,y:679,t:1526922796440};\\\", \\\"{x:1339,y:675,t:1526922796457};\\\", \\\"{x:1337,y:674,t:1526922796481};\\\", \\\"{x:1336,y:672,t:1526922796491};\\\", \\\"{x:1334,y:669,t:1526922796507};\\\", \\\"{x:1331,y:665,t:1526922796525};\\\", \\\"{x:1330,y:662,t:1526922796541};\\\", \\\"{x:1327,y:658,t:1526922796557};\\\", \\\"{x:1324,y:654,t:1526922796575};\\\", \\\"{x:1322,y:649,t:1526922796591};\\\", \\\"{x:1319,y:644,t:1526922796607};\\\", \\\"{x:1317,y:640,t:1526922796624};\\\", \\\"{x:1315,y:633,t:1526922796642};\\\", \\\"{x:1312,y:627,t:1526922796657};\\\", \\\"{x:1308,y:623,t:1526922796674};\\\", \\\"{x:1307,y:619,t:1526922796691};\\\", \\\"{x:1305,y:615,t:1526922796707};\\\", \\\"{x:1303,y:611,t:1526922796724};\\\", \\\"{x:1301,y:607,t:1526922796741};\\\", \\\"{x:1301,y:604,t:1526922796757};\\\", \\\"{x:1300,y:600,t:1526922796774};\\\", \\\"{x:1299,y:600,t:1526922796792};\\\", \\\"{x:1298,y:599,t:1526922796807};\\\", \\\"{x:1297,y:597,t:1526922796824};\\\", \\\"{x:1295,y:594,t:1526922796841};\\\", \\\"{x:1294,y:594,t:1526922796857};\\\", \\\"{x:1292,y:590,t:1526922796874};\\\", \\\"{x:1292,y:589,t:1526922796891};\\\", \\\"{x:1290,y:585,t:1526922796907};\\\", \\\"{x:1289,y:583,t:1526922796925};\\\", \\\"{x:1287,y:580,t:1526922796941};\\\", \\\"{x:1286,y:578,t:1526922796957};\\\", \\\"{x:1284,y:576,t:1526922796974};\\\", \\\"{x:1284,y:573,t:1526922796991};\\\", \\\"{x:1284,y:571,t:1526922797008};\\\", \\\"{x:1282,y:570,t:1526922797024};\\\", \\\"{x:1280,y:565,t:1526922797041};\\\", \\\"{x:1280,y:564,t:1526922797057};\\\", \\\"{x:1278,y:561,t:1526922797074};\\\", \\\"{x:1277,y:560,t:1526922797091};\\\", \\\"{x:1276,y:559,t:1526922797108};\\\", \\\"{x:1274,y:557,t:1526922797124};\\\", \\\"{x:1273,y:557,t:1526922797153};\\\", \\\"{x:1273,y:556,t:1526922797161};\\\", \\\"{x:1272,y:555,t:1526922797174};\\\", \\\"{x:1272,y:554,t:1526922797191};\\\", \\\"{x:1271,y:553,t:1526922797209};\\\", \\\"{x:1270,y:552,t:1526922797241};\\\", \\\"{x:1272,y:552,t:1526922802418};\\\", \\\"{x:1273,y:552,t:1526922802546};\\\", \\\"{x:1274,y:552,t:1526922802561};\\\", \\\"{x:1275,y:552,t:1526922802674};\\\", \\\"{x:1276,y:553,t:1526922804010};\\\", \\\"{x:1276,y:554,t:1526922804066};\\\", \\\"{x:1277,y:555,t:1526922804145};\\\", \\\"{x:1277,y:556,t:1526922804170};\\\", \\\"{x:1278,y:557,t:1526922804218};\\\", \\\"{x:1278,y:558,t:1526922804259};\\\", \\\"{x:1279,y:558,t:1526922804346};\\\", \\\"{x:1279,y:559,t:1526922804394};\\\", \\\"{x:1281,y:560,t:1526922804481};\\\", \\\"{x:1281,y:561,t:1526922804634};\\\", \\\"{x:1282,y:561,t:1526922804722};\\\", \\\"{x:1283,y:561,t:1526922815361};\\\", \\\"{x:1283,y:562,t:1526922824569};\\\", \\\"{x:1281,y:565,t:1526922824578};\\\", \\\"{x:1277,y:571,t:1526922824595};\\\", \\\"{x:1269,y:580,t:1526922824612};\\\", \\\"{x:1257,y:592,t:1526922824628};\\\", \\\"{x:1245,y:608,t:1526922824645};\\\", \\\"{x:1199,y:630,t:1526922824661};\\\", \\\"{x:1137,y:650,t:1526922824678};\\\", \\\"{x:1053,y:676,t:1526922824695};\\\", \\\"{x:984,y:692,t:1526922824711};\\\", \\\"{x:918,y:701,t:1526922824728};\\\", \\\"{x:854,y:709,t:1526922824745};\\\", \\\"{x:832,y:711,t:1526922824761};\\\", \\\"{x:809,y:711,t:1526922824778};\\\", \\\"{x:715,y:704,t:1526922824795};\\\", \\\"{x:589,y:683,t:1526922824812};\\\", \\\"{x:486,y:665,t:1526922824828};\\\", \\\"{x:375,y:651,t:1526922824846};\\\", \\\"{x:288,y:645,t:1526922824862};\\\", \\\"{x:253,y:635,t:1526922824876};\\\", \\\"{x:228,y:626,t:1526922824892};\\\", \\\"{x:218,y:622,t:1526922824915};\\\", \\\"{x:216,y:621,t:1526922824931};\\\", \\\"{x:216,y:617,t:1526922824949};\\\", \\\"{x:222,y:609,t:1526922824965};\\\", \\\"{x:226,y:602,t:1526922824982};\\\", \\\"{x:233,y:593,t:1526922825000};\\\", \\\"{x:242,y:583,t:1526922825015};\\\", \\\"{x:254,y:573,t:1526922825032};\\\", \\\"{x:268,y:566,t:1526922825048};\\\", \\\"{x:286,y:555,t:1526922825065};\\\", \\\"{x:296,y:550,t:1526922825082};\\\", \\\"{x:309,y:545,t:1526922825098};\\\", \\\"{x:315,y:545,t:1526922825116};\\\", \\\"{x:328,y:543,t:1526922825132};\\\", \\\"{x:346,y:543,t:1526922825149};\\\", \\\"{x:363,y:543,t:1526922825166};\\\", \\\"{x:378,y:543,t:1526922825183};\\\", \\\"{x:402,y:543,t:1526922825199};\\\", \\\"{x:424,y:543,t:1526922825215};\\\", \\\"{x:447,y:543,t:1526922825232};\\\", \\\"{x:473,y:543,t:1526922825248};\\\", \\\"{x:483,y:539,t:1526922825266};\\\", \\\"{x:500,y:539,t:1526922825282};\\\", \\\"{x:518,y:539,t:1526922825299};\\\", \\\"{x:534,y:539,t:1526922825315};\\\", \\\"{x:550,y:535,t:1526922825332};\\\", \\\"{x:562,y:530,t:1526922825348};\\\", \\\"{x:568,y:527,t:1526922825365};\\\", \\\"{x:576,y:525,t:1526922825382};\\\", \\\"{x:578,y:523,t:1526922825399};\\\", \\\"{x:581,y:521,t:1526922825415};\\\", \\\"{x:582,y:521,t:1526922825432};\\\", \\\"{x:584,y:519,t:1526922825449};\\\", \\\"{x:586,y:517,t:1526922825467};\\\", \\\"{x:591,y:515,t:1526922825482};\\\", \\\"{x:592,y:514,t:1526922825499};\\\", \\\"{x:595,y:513,t:1526922825515};\\\", \\\"{x:596,y:513,t:1526922825532};\\\", \\\"{x:598,y:512,t:1526922825549};\\\", \\\"{x:599,y:511,t:1526922825566};\\\", \\\"{x:601,y:511,t:1526922825582};\\\", \\\"{x:605,y:510,t:1526922825598};\\\", \\\"{x:609,y:510,t:1526922825616};\\\", \\\"{x:615,y:510,t:1526922825632};\\\", \\\"{x:616,y:509,t:1526922825801};\\\", \\\"{x:615,y:510,t:1526922826032};\\\", \\\"{x:614,y:513,t:1526922826064};\\\", \\\"{x:612,y:516,t:1526922826073};\\\", \\\"{x:611,y:521,t:1526922826083};\\\", \\\"{x:609,y:528,t:1526922826099};\\\", \\\"{x:605,y:535,t:1526922826116};\\\", \\\"{x:604,y:541,t:1526922826133};\\\", \\\"{x:599,y:546,t:1526922826151};\\\", \\\"{x:597,y:550,t:1526922826166};\\\", \\\"{x:594,y:555,t:1526922826183};\\\", \\\"{x:594,y:560,t:1526922826200};\\\", \\\"{x:594,y:564,t:1526922826217};\\\", \\\"{x:594,y:565,t:1526922826232};\\\", \\\"{x:591,y:568,t:1526922826265};\\\", \\\"{x:590,y:570,t:1526922826272};\\\", \\\"{x:588,y:572,t:1526922826289};\\\", \\\"{x:587,y:572,t:1526922826304};\\\", \\\"{x:587,y:573,t:1526922826337};\\\", \\\"{x:585,y:575,t:1526922826350};\\\", \\\"{x:579,y:577,t:1526922826367};\\\", \\\"{x:578,y:579,t:1526922826383};\\\", \\\"{x:576,y:581,t:1526922826400};\\\", \\\"{x:572,y:584,t:1526922826416};\\\", \\\"{x:568,y:590,t:1526922826433};\\\", \\\"{x:564,y:596,t:1526922826450};\\\", \\\"{x:562,y:599,t:1526922826467};\\\", \\\"{x:557,y:611,t:1526922826483};\\\", \\\"{x:555,y:613,t:1526922826500};\\\", \\\"{x:555,y:623,t:1526922826516};\\\", \\\"{x:551,y:629,t:1526922826533};\\\", \\\"{x:551,y:632,t:1526922826551};\\\", \\\"{x:550,y:636,t:1526922826566};\\\", \\\"{x:549,y:640,t:1526922826583};\\\", \\\"{x:547,y:644,t:1526922826600};\\\", \\\"{x:546,y:647,t:1526922826617};\\\", \\\"{x:545,y:650,t:1526922826634};\\\", \\\"{x:545,y:653,t:1526922826650};\\\", \\\"{x:544,y:656,t:1526922826667};\\\", \\\"{x:544,y:660,t:1526922826684};\\\", \\\"{x:540,y:663,t:1526922826700};\\\", \\\"{x:538,y:667,t:1526922826717};\\\", \\\"{x:536,y:669,t:1526922826734};\\\", \\\"{x:531,y:679,t:1526922826751};\\\", \\\"{x:525,y:687,t:1526922826768};\\\", \\\"{x:518,y:698,t:1526922826784};\\\", \\\"{x:506,y:720,t:1526922826800};\\\", \\\"{x:499,y:734,t:1526922826817};\\\", \\\"{x:492,y:747,t:1526922826833};\\\", \\\"{x:487,y:762,t:1526922826850};\\\", \\\"{x:484,y:771,t:1526922826867};\\\", \\\"{x:482,y:775,t:1526922826883};\\\", \\\"{x:479,y:782,t:1526922826900};\\\", \\\"{x:478,y:787,t:1526922826917};\\\", \\\"{x:478,y:790,t:1526922826933};\\\", \\\"{x:477,y:791,t:1526922826950};\\\", \\\"{x:477,y:790,t:1526922827073};\\\", \\\"{x:478,y:787,t:1526922827084};\\\", \\\"{x:483,y:778,t:1526922827100};\\\", \\\"{x:487,y:772,t:1526922827117};\\\", \\\"{x:490,y:765,t:1526922827133};\\\", \\\"{x:498,y:756,t:1526922827150};\\\", \\\"{x:501,y:748,t:1526922827167};\\\", \\\"{x:502,y:743,t:1526922827184};\\\", \\\"{x:503,y:743,t:1526922827200};\\\", \\\"{x:503,y:742,t:1526922827217};\\\", \\\"{x:503,y:740,t:1526922827234};\\\", \\\"{x:503,y:739,t:1526922827250};\\\", \\\"{x:500,y:739,t:1526922827576};\\\", \\\"{x:499,y:739,t:1526922827584};\\\", \\\"{x:493,y:739,t:1526922827601};\\\", \\\"{x:487,y:739,t:1526922827617};\\\", \\\"{x:480,y:739,t:1526922827634};\\\", \\\"{x:478,y:738,t:1526922827651};\\\", \\\"{x:477,y:738,t:1526922827667};\\\", \\\"{x:477,y:736,t:1526922827705};\\\", \\\"{x:477,y:734,t:1526922827717};\\\", \\\"{x:478,y:734,t:1526922827734};\\\", \\\"{x:480,y:732,t:1526922827751};\\\", \\\"{x:481,y:731,t:1526922827767};\\\", \\\"{x:482,y:730,t:1526922827784};\\\" ] }, { \\\"rt\\\": 13456, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 273259, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -J -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:729,t:1526922829072};\\\", \\\"{x:487,y:727,t:1526922829086};\\\", \\\"{x:490,y:721,t:1526922829102};\\\", \\\"{x:493,y:717,t:1526922829119};\\\", \\\"{x:496,y:713,t:1526922829136};\\\", \\\"{x:499,y:709,t:1526922829153};\\\", \\\"{x:500,y:705,t:1526922829168};\\\", \\\"{x:504,y:697,t:1526922829185};\\\", \\\"{x:507,y:690,t:1526922829202};\\\", \\\"{x:509,y:683,t:1526922829218};\\\", \\\"{x:512,y:674,t:1526922829235};\\\", \\\"{x:521,y:608,t:1526922829324};\\\", \\\"{x:522,y:595,t:1526922829337};\\\", \\\"{x:522,y:590,t:1526922829352};\\\", \\\"{x:522,y:571,t:1526922829369};\\\", \\\"{x:519,y:557,t:1526922829386};\\\", \\\"{x:518,y:545,t:1526922829403};\\\", \\\"{x:515,y:535,t:1526922829419};\\\", \\\"{x:512,y:523,t:1526922829435};\\\", \\\"{x:511,y:518,t:1526922829452};\\\", \\\"{x:510,y:514,t:1526922829469};\\\", \\\"{x:509,y:511,t:1526922829485};\\\", \\\"{x:508,y:508,t:1526922829502};\\\", \\\"{x:508,y:507,t:1526922829519};\\\", \\\"{x:508,y:506,t:1526922829535};\\\", \\\"{x:508,y:504,t:1526922829552};\\\", \\\"{x:508,y:503,t:1526922829576};\\\", \\\"{x:510,y:503,t:1526922829592};\\\", \\\"{x:512,y:501,t:1526922829961};\\\", \\\"{x:513,y:501,t:1526922829969};\\\", \\\"{x:515,y:500,t:1526922829987};\\\", \\\"{x:517,y:497,t:1526922830003};\\\", \\\"{x:519,y:495,t:1526922830020};\\\", \\\"{x:522,y:492,t:1526922830036};\\\", \\\"{x:523,y:488,t:1526922830053};\\\", \\\"{x:525,y:485,t:1526922830070};\\\", \\\"{x:525,y:484,t:1526922830086};\\\", \\\"{x:526,y:482,t:1526922830102};\\\", \\\"{x:526,y:481,t:1526922830119};\\\", \\\"{x:526,y:479,t:1526922830136};\\\", \\\"{x:526,y:478,t:1526922830177};\\\", \\\"{x:528,y:477,t:1526922830201};\\\", \\\"{x:528,y:475,t:1526922830224};\\\", \\\"{x:528,y:474,t:1526922830257};\\\", \\\"{x:529,y:474,t:1526922830269};\\\", \\\"{x:529,y:473,t:1526922830297};\\\", \\\"{x:528,y:473,t:1526922831362};\\\", \\\"{x:524,y:473,t:1526922831371};\\\", \\\"{x:517,y:473,t:1526922831387};\\\", \\\"{x:510,y:475,t:1526922831404};\\\", \\\"{x:504,y:475,t:1526922831421};\\\", \\\"{x:503,y:475,t:1526922831437};\\\", \\\"{x:501,y:475,t:1526922831453};\\\", \\\"{x:499,y:475,t:1526922831472};\\\", \\\"{x:496,y:475,t:1526922831486};\\\", \\\"{x:494,y:475,t:1526922831504};\\\", \\\"{x:493,y:475,t:1526922831521};\\\", \\\"{x:491,y:475,t:1526922831537};\\\", \\\"{x:490,y:475,t:1526922831553};\\\", \\\"{x:489,y:475,t:1526922831586};\\\", \\\"{x:491,y:476,t:1526922832346};\\\", \\\"{x:502,y:480,t:1526922832355};\\\", \\\"{x:526,y:489,t:1526922832371};\\\", \\\"{x:548,y:497,t:1526922832387};\\\", \\\"{x:593,y:508,t:1526922832404};\\\", \\\"{x:612,y:508,t:1526922832421};\\\", \\\"{x:656,y:521,t:1526922832439};\\\", \\\"{x:687,y:531,t:1526922832455};\\\", \\\"{x:730,y:541,t:1526922832472};\\\", \\\"{x:781,y:561,t:1526922832489};\\\", \\\"{x:813,y:576,t:1526922832505};\\\", \\\"{x:842,y:585,t:1526922832522};\\\", \\\"{x:867,y:596,t:1526922832538};\\\", \\\"{x:896,y:604,t:1526922832555};\\\", \\\"{x:917,y:611,t:1526922832572};\\\", \\\"{x:947,y:616,t:1526922832589};\\\", \\\"{x:971,y:625,t:1526922832606};\\\", \\\"{x:992,y:632,t:1526922832622};\\\", \\\"{x:1017,y:642,t:1526922832638};\\\", \\\"{x:1038,y:650,t:1526922832654};\\\", \\\"{x:1056,y:658,t:1526922832671};\\\", \\\"{x:1090,y:672,t:1526922832688};\\\", \\\"{x:1109,y:678,t:1526922832705};\\\", \\\"{x:1128,y:686,t:1526922832721};\\\", \\\"{x:1148,y:698,t:1526922832738};\\\", \\\"{x:1158,y:705,t:1526922832755};\\\", \\\"{x:1163,y:709,t:1526922832771};\\\", \\\"{x:1163,y:710,t:1526922832788};\\\", \\\"{x:1163,y:711,t:1526922832804};\\\", \\\"{x:1163,y:715,t:1526922832821};\\\", \\\"{x:1165,y:722,t:1526922832839};\\\", \\\"{x:1168,y:728,t:1526922832855};\\\", \\\"{x:1168,y:730,t:1526922832871};\\\", \\\"{x:1170,y:734,t:1526922832888};\\\", \\\"{x:1173,y:739,t:1526922832905};\\\", \\\"{x:1174,y:743,t:1526922832921};\\\", \\\"{x:1177,y:748,t:1526922832938};\\\", \\\"{x:1181,y:753,t:1526922832955};\\\", \\\"{x:1185,y:759,t:1526922832972};\\\", \\\"{x:1186,y:763,t:1526922832988};\\\", \\\"{x:1190,y:767,t:1526922833005};\\\", \\\"{x:1191,y:769,t:1526922833021};\\\", \\\"{x:1194,y:775,t:1526922833038};\\\", \\\"{x:1195,y:779,t:1526922833054};\\\", \\\"{x:1196,y:783,t:1526922833071};\\\", \\\"{x:1198,y:787,t:1526922833088};\\\", \\\"{x:1198,y:792,t:1526922833104};\\\", \\\"{x:1198,y:797,t:1526922833122};\\\", \\\"{x:1199,y:801,t:1526922833138};\\\", \\\"{x:1200,y:804,t:1526922833154};\\\", \\\"{x:1200,y:807,t:1526922833171};\\\", \\\"{x:1200,y:809,t:1526922833188};\\\", \\\"{x:1200,y:812,t:1526922833204};\\\", \\\"{x:1201,y:815,t:1526922833221};\\\", \\\"{x:1202,y:817,t:1526922833240};\\\", \\\"{x:1202,y:818,t:1526922833254};\\\", \\\"{x:1203,y:820,t:1526922833272};\\\", \\\"{x:1203,y:821,t:1526922833288};\\\", \\\"{x:1204,y:823,t:1526922833304};\\\", \\\"{x:1204,y:824,t:1526922833337};\\\", \\\"{x:1205,y:825,t:1526922833369};\\\", \\\"{x:1205,y:826,t:1526922833377};\\\", \\\"{x:1207,y:828,t:1526922833400};\\\", \\\"{x:1209,y:828,t:1526922833425};\\\", \\\"{x:1211,y:829,t:1526922833437};\\\", \\\"{x:1212,y:830,t:1526922833454};\\\", \\\"{x:1213,y:830,t:1526922833473};\\\", \\\"{x:1214,y:831,t:1526922833488};\\\", \\\"{x:1215,y:831,t:1526922833513};\\\", \\\"{x:1214,y:831,t:1526922834113};\\\", \\\"{x:1210,y:830,t:1526922834121};\\\", \\\"{x:1202,y:825,t:1526922834139};\\\", \\\"{x:1193,y:818,t:1526922834155};\\\", \\\"{x:1185,y:812,t:1526922834170};\\\", \\\"{x:1180,y:807,t:1526922834187};\\\", \\\"{x:1177,y:803,t:1526922834205};\\\", \\\"{x:1175,y:799,t:1526922834221};\\\", \\\"{x:1172,y:796,t:1526922834238};\\\", \\\"{x:1170,y:792,t:1526922834254};\\\", \\\"{x:1170,y:790,t:1526922834270};\\\", \\\"{x:1169,y:788,t:1526922834288};\\\", \\\"{x:1167,y:783,t:1526922834304};\\\", \\\"{x:1166,y:781,t:1526922834321};\\\", \\\"{x:1165,y:778,t:1526922834338};\\\", \\\"{x:1165,y:775,t:1526922834354};\\\", \\\"{x:1163,y:772,t:1526922834370};\\\", \\\"{x:1163,y:770,t:1526922834387};\\\", \\\"{x:1163,y:767,t:1526922834404};\\\", \\\"{x:1163,y:765,t:1526922834421};\\\", \\\"{x:1162,y:762,t:1526922834437};\\\", \\\"{x:1162,y:761,t:1526922834456};\\\", \\\"{x:1162,y:760,t:1526922834481};\\\", \\\"{x:1162,y:759,t:1526922834489};\\\", \\\"{x:1161,y:757,t:1526922834505};\\\", \\\"{x:1161,y:755,t:1526922834537};\\\", \\\"{x:1160,y:754,t:1526922834569};\\\", \\\"{x:1160,y:753,t:1526922834753};\\\", \\\"{x:1159,y:752,t:1526922836352};\\\", \\\"{x:1157,y:752,t:1526922836433};\\\", \\\"{x:1160,y:753,t:1526922836848};\\\", \\\"{x:1162,y:753,t:1526922836864};\\\", \\\"{x:1163,y:753,t:1526922836872};\\\", \\\"{x:1163,y:754,t:1526922836886};\\\", \\\"{x:1164,y:754,t:1526922836903};\\\", \\\"{x:1165,y:754,t:1526922836919};\\\", \\\"{x:1166,y:754,t:1526922836952};\\\", \\\"{x:1167,y:754,t:1526922836960};\\\", \\\"{x:1168,y:754,t:1526922836969};\\\", \\\"{x:1169,y:754,t:1526922836987};\\\", \\\"{x:1170,y:754,t:1526922837004};\\\", \\\"{x:1172,y:754,t:1526922837020};\\\", \\\"{x:1174,y:754,t:1526922837037};\\\", \\\"{x:1175,y:754,t:1526922837053};\\\", \\\"{x:1176,y:754,t:1526922837080};\\\", \\\"{x:1177,y:754,t:1526922837088};\\\", \\\"{x:1178,y:754,t:1526922837104};\\\", \\\"{x:1179,y:754,t:1526922837153};\\\", \\\"{x:1180,y:754,t:1526922837457};\\\", \\\"{x:1181,y:754,t:1526922837704};\\\", \\\"{x:1181,y:755,t:1526922837752};\\\", \\\"{x:1181,y:756,t:1526922837792};\\\", \\\"{x:1181,y:757,t:1526922837803};\\\", \\\"{x:1181,y:758,t:1526922837837};\\\", \\\"{x:1182,y:758,t:1526922837856};\\\", \\\"{x:1180,y:761,t:1526922839287};\\\", \\\"{x:1172,y:762,t:1526922839295};\\\", \\\"{x:1162,y:762,t:1526922839308};\\\", \\\"{x:1137,y:767,t:1526922839324};\\\", \\\"{x:1117,y:767,t:1526922839340};\\\", \\\"{x:1096,y:767,t:1526922839358};\\\", \\\"{x:1074,y:767,t:1526922839374};\\\", \\\"{x:1066,y:767,t:1526922839391};\\\", \\\"{x:1054,y:767,t:1526922839407};\\\", \\\"{x:1042,y:767,t:1526922839425};\\\", \\\"{x:1022,y:767,t:1526922839441};\\\", \\\"{x:985,y:760,t:1526922839458};\\\", \\\"{x:916,y:742,t:1526922839475};\\\", \\\"{x:860,y:724,t:1526922839491};\\\", \\\"{x:798,y:705,t:1526922839508};\\\", \\\"{x:751,y:693,t:1526922839525};\\\", \\\"{x:712,y:684,t:1526922839541};\\\", \\\"{x:675,y:670,t:1526922839558};\\\", \\\"{x:638,y:658,t:1526922839574};\\\", \\\"{x:617,y:649,t:1526922839590};\\\", \\\"{x:597,y:643,t:1526922839608};\\\", \\\"{x:578,y:638,t:1526922839625};\\\", \\\"{x:567,y:631,t:1526922839642};\\\", \\\"{x:552,y:626,t:1526922839658};\\\", \\\"{x:535,y:622,t:1526922839675};\\\", \\\"{x:510,y:616,t:1526922839692};\\\", \\\"{x:485,y:609,t:1526922839709};\\\", \\\"{x:462,y:601,t:1526922839725};\\\", \\\"{x:431,y:595,t:1526922839750};\\\", \\\"{x:415,y:588,t:1526922839766};\\\", \\\"{x:410,y:587,t:1526922839782};\\\", \\\"{x:401,y:587,t:1526922839799};\\\", \\\"{x:391,y:587,t:1526922839816};\\\", \\\"{x:385,y:587,t:1526922839833};\\\", \\\"{x:378,y:588,t:1526922839850};\\\", \\\"{x:374,y:588,t:1526922839866};\\\", \\\"{x:372,y:588,t:1526922839883};\\\", \\\"{x:369,y:588,t:1526922839900};\\\", \\\"{x:367,y:588,t:1526922839916};\\\", \\\"{x:354,y:584,t:1526922839933};\\\", \\\"{x:341,y:580,t:1526922839950};\\\", \\\"{x:319,y:571,t:1526922839966};\\\", \\\"{x:296,y:565,t:1526922839983};\\\", \\\"{x:274,y:559,t:1526922840000};\\\", \\\"{x:251,y:552,t:1526922840018};\\\", \\\"{x:241,y:549,t:1526922840032};\\\", \\\"{x:224,y:543,t:1526922840050};\\\", \\\"{x:215,y:540,t:1526922840066};\\\", \\\"{x:213,y:539,t:1526922840083};\\\", \\\"{x:212,y:539,t:1526922840231};\\\", \\\"{x:209,y:537,t:1526922840247};\\\", \\\"{x:208,y:535,t:1526922840262};\\\", \\\"{x:206,y:535,t:1526922840270};\\\", \\\"{x:206,y:533,t:1526922840283};\\\", \\\"{x:204,y:531,t:1526922840300};\\\", \\\"{x:201,y:529,t:1526922840317};\\\", \\\"{x:201,y:528,t:1526922840333};\\\", \\\"{x:199,y:528,t:1526922840349};\\\", \\\"{x:197,y:527,t:1526922840366};\\\", \\\"{x:195,y:525,t:1526922840384};\\\", \\\"{x:192,y:524,t:1526922840400};\\\", \\\"{x:190,y:522,t:1526922840417};\\\", \\\"{x:186,y:520,t:1526922840433};\\\", \\\"{x:184,y:518,t:1526922840450};\\\", \\\"{x:181,y:516,t:1526922840467};\\\", \\\"{x:179,y:514,t:1526922840483};\\\", \\\"{x:175,y:511,t:1526922840500};\\\", \\\"{x:174,y:510,t:1526922840517};\\\", \\\"{x:171,y:509,t:1526922840534};\\\", \\\"{x:168,y:507,t:1526922840550};\\\", \\\"{x:165,y:505,t:1526922840566};\\\", \\\"{x:163,y:504,t:1526922840584};\\\", \\\"{x:161,y:503,t:1526922840600};\\\", \\\"{x:161,y:502,t:1526922840617};\\\", \\\"{x:162,y:502,t:1526922841030};\\\", \\\"{x:167,y:507,t:1526922841038};\\\", \\\"{x:173,y:512,t:1526922841051};\\\", \\\"{x:188,y:524,t:1526922841067};\\\", \\\"{x:208,y:540,t:1526922841084};\\\", \\\"{x:232,y:556,t:1526922841101};\\\", \\\"{x:257,y:573,t:1526922841117};\\\", \\\"{x:275,y:584,t:1526922841134};\\\", \\\"{x:291,y:600,t:1526922841151};\\\", \\\"{x:294,y:603,t:1526922841167};\\\", \\\"{x:299,y:607,t:1526922841184};\\\", \\\"{x:300,y:608,t:1526922841201};\\\", \\\"{x:302,y:611,t:1526922841217};\\\", \\\"{x:303,y:613,t:1526922841234};\\\", \\\"{x:307,y:617,t:1526922841251};\\\", \\\"{x:309,y:619,t:1526922841266};\\\", \\\"{x:312,y:623,t:1526922841284};\\\", \\\"{x:315,y:626,t:1526922841301};\\\", \\\"{x:319,y:630,t:1526922841317};\\\", \\\"{x:322,y:632,t:1526922841334};\\\", \\\"{x:324,y:634,t:1526922841351};\\\", \\\"{x:325,y:635,t:1526922841368};\\\", \\\"{x:327,y:637,t:1526922841384};\\\", \\\"{x:329,y:638,t:1526922841401};\\\", \\\"{x:331,y:641,t:1526922841418};\\\", \\\"{x:335,y:643,t:1526922841435};\\\", \\\"{x:337,y:645,t:1526922841450};\\\", \\\"{x:341,y:648,t:1526922841468};\\\", \\\"{x:345,y:650,t:1526922841484};\\\", \\\"{x:347,y:652,t:1526922841501};\\\", \\\"{x:352,y:656,t:1526922841518};\\\", \\\"{x:356,y:659,t:1526922841534};\\\", \\\"{x:367,y:667,t:1526922841551};\\\", \\\"{x:377,y:672,t:1526922841569};\\\", \\\"{x:390,y:680,t:1526922841584};\\\", \\\"{x:406,y:687,t:1526922841601};\\\", \\\"{x:413,y:691,t:1526922841618};\\\", \\\"{x:419,y:693,t:1526922841634};\\\", \\\"{x:423,y:695,t:1526922841651};\\\", \\\"{x:425,y:696,t:1526922841668};\\\", \\\"{x:426,y:696,t:1526922841685};\\\", \\\"{x:427,y:697,t:1526922841701};\\\", \\\"{x:429,y:698,t:1526922841718};\\\", \\\"{x:435,y:699,t:1526922841734};\\\", \\\"{x:437,y:700,t:1526922841751};\\\", \\\"{x:441,y:701,t:1526922841768};\\\", \\\"{x:447,y:704,t:1526922841785};\\\", \\\"{x:451,y:706,t:1526922841801};\\\", \\\"{x:455,y:708,t:1526922841818};\\\", \\\"{x:462,y:712,t:1526922841835};\\\", \\\"{x:467,y:715,t:1526922841851};\\\", \\\"{x:472,y:720,t:1526922841868};\\\", \\\"{x:478,y:724,t:1526922841885};\\\", \\\"{x:481,y:727,t:1526922841901};\\\", \\\"{x:484,y:731,t:1526922841918};\\\", \\\"{x:487,y:734,t:1526922841935};\\\", \\\"{x:489,y:735,t:1526922841951};\\\", \\\"{x:490,y:736,t:1526922841968};\\\" ] }, { \\\"rt\\\": 67124, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 341574, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -M -B -B -F -F -E -F -F -F -F -O -X -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:737,t:1526922843519};\\\", \\\"{x:488,y:737,t:1526922843558};\\\", \\\"{x:486,y:737,t:1526922843758};\\\", \\\"{x:486,y:736,t:1526922843769};\\\", \\\"{x:485,y:736,t:1526922843786};\\\", \\\"{x:477,y:732,t:1526922843850};\\\", \\\"{x:475,y:731,t:1526922843865};\\\", \\\"{x:470,y:729,t:1526922843882};\\\", \\\"{x:469,y:728,t:1526922843894};\\\", \\\"{x:468,y:727,t:1526922843902};\\\", \\\"{x:464,y:725,t:1526922843918};\\\", \\\"{x:462,y:724,t:1526922843935};\\\", \\\"{x:458,y:721,t:1526922843952};\\\", \\\"{x:456,y:719,t:1526922843969};\\\", \\\"{x:452,y:717,t:1526922843985};\\\", \\\"{x:451,y:716,t:1526922844003};\\\", \\\"{x:450,y:715,t:1526922844020};\\\", \\\"{x:448,y:712,t:1526922844038};\\\", \\\"{x:448,y:711,t:1526922844062};\\\", \\\"{x:447,y:710,t:1526922844087};\\\", \\\"{x:447,y:708,t:1526922844103};\\\", \\\"{x:446,y:708,t:1526922844120};\\\", \\\"{x:445,y:707,t:1526922844137};\\\", \\\"{x:445,y:705,t:1526922844167};\\\", \\\"{x:445,y:704,t:1526922844199};\\\", \\\"{x:445,y:703,t:1526922844207};\\\", \\\"{x:445,y:702,t:1526922844222};\\\", \\\"{x:445,y:701,t:1526922844247};\\\", \\\"{x:445,y:700,t:1526922844279};\\\", \\\"{x:445,y:699,t:1526922844303};\\\", \\\"{x:445,y:697,t:1526922844327};\\\", \\\"{x:445,y:696,t:1526922844367};\\\", \\\"{x:445,y:695,t:1526922844406};\\\", \\\"{x:445,y:694,t:1526922844527};\\\", \\\"{x:444,y:694,t:1526922844582};\\\", \\\"{x:444,y:693,t:1526922844639};\\\", \\\"{x:444,y:692,t:1526922844654};\\\", \\\"{x:444,y:691,t:1526922844671};\\\", \\\"{x:443,y:691,t:1526922844687};\\\", \\\"{x:443,y:690,t:1526922844704};\\\", \\\"{x:443,y:689,t:1526922847294};\\\", \\\"{x:446,y:689,t:1526922847307};\\\", \\\"{x:455,y:689,t:1526922847323};\\\", \\\"{x:466,y:688,t:1526922847340};\\\", \\\"{x:477,y:687,t:1526922847356};\\\", \\\"{x:487,y:687,t:1526922847373};\\\", \\\"{x:504,y:687,t:1526922847390};\\\", \\\"{x:527,y:687,t:1526922847406};\\\", \\\"{x:569,y:698,t:1526922847423};\\\", \\\"{x:606,y:704,t:1526922847440};\\\", \\\"{x:643,y:711,t:1526922847456};\\\", \\\"{x:678,y:718,t:1526922847473};\\\", \\\"{x:710,y:723,t:1526922847491};\\\", \\\"{x:743,y:729,t:1526922847506};\\\", \\\"{x:773,y:735,t:1526922847524};\\\", \\\"{x:820,y:740,t:1526922847541};\\\", \\\"{x:846,y:741,t:1526922847556};\\\", \\\"{x:881,y:748,t:1526922847573};\\\", \\\"{x:906,y:752,t:1526922847590};\\\", \\\"{x:930,y:754,t:1526922847607};\\\", \\\"{x:970,y:763,t:1526922847623};\\\", \\\"{x:996,y:766,t:1526922847641};\\\", \\\"{x:1017,y:769,t:1526922847656};\\\", \\\"{x:1047,y:773,t:1526922847674};\\\", \\\"{x:1069,y:777,t:1526922847690};\\\", \\\"{x:1090,y:782,t:1526922847707};\\\", \\\"{x:1110,y:788,t:1526922847723};\\\", \\\"{x:1126,y:792,t:1526922847741};\\\", \\\"{x:1143,y:797,t:1526922847757};\\\", \\\"{x:1151,y:801,t:1526922847773};\\\", \\\"{x:1165,y:807,t:1526922847790};\\\", \\\"{x:1194,y:823,t:1526922847807};\\\", \\\"{x:1213,y:829,t:1526922847824};\\\", \\\"{x:1238,y:837,t:1526922847841};\\\", \\\"{x:1259,y:849,t:1526922847857};\\\", \\\"{x:1277,y:860,t:1526922847873};\\\", \\\"{x:1292,y:868,t:1526922847890};\\\", \\\"{x:1306,y:873,t:1526922847907};\\\", \\\"{x:1311,y:876,t:1526922847923};\\\", \\\"{x:1313,y:877,t:1526922847943};\\\", \\\"{x:1315,y:877,t:1526922847983};\\\", \\\"{x:1317,y:878,t:1526922847991};\\\", \\\"{x:1321,y:878,t:1526922848007};\\\", \\\"{x:1326,y:878,t:1526922848024};\\\", \\\"{x:1333,y:878,t:1526922848040};\\\", \\\"{x:1339,y:880,t:1526922848057};\\\", \\\"{x:1344,y:880,t:1526922848075};\\\", \\\"{x:1349,y:880,t:1526922848090};\\\", \\\"{x:1356,y:881,t:1526922848107};\\\", \\\"{x:1366,y:882,t:1526922848124};\\\", \\\"{x:1376,y:885,t:1526922848141};\\\", \\\"{x:1383,y:885,t:1526922848157};\\\", \\\"{x:1397,y:885,t:1526922848175};\\\", \\\"{x:1408,y:885,t:1526922848190};\\\", \\\"{x:1422,y:885,t:1526922848208};\\\", \\\"{x:1428,y:881,t:1526922848224};\\\", \\\"{x:1434,y:877,t:1526922848241};\\\", \\\"{x:1436,y:875,t:1526922848257};\\\", \\\"{x:1441,y:873,t:1526922848274};\\\", \\\"{x:1445,y:869,t:1526922848290};\\\", \\\"{x:1451,y:865,t:1526922848307};\\\", \\\"{x:1459,y:860,t:1526922848324};\\\", \\\"{x:1466,y:856,t:1526922848341};\\\", \\\"{x:1472,y:852,t:1526922848358};\\\", \\\"{x:1476,y:848,t:1526922848375};\\\", \\\"{x:1481,y:844,t:1526922848391};\\\", \\\"{x:1483,y:841,t:1526922848407};\\\", \\\"{x:1486,y:836,t:1526922848424};\\\", \\\"{x:1489,y:832,t:1526922848441};\\\", \\\"{x:1491,y:830,t:1526922848457};\\\", \\\"{x:1493,y:823,t:1526922848475};\\\", \\\"{x:1493,y:818,t:1526922848492};\\\", \\\"{x:1494,y:811,t:1526922848508};\\\", \\\"{x:1495,y:807,t:1526922848525};\\\", \\\"{x:1497,y:802,t:1526922848541};\\\", \\\"{x:1498,y:796,t:1526922848558};\\\", \\\"{x:1498,y:790,t:1526922848574};\\\", \\\"{x:1498,y:778,t:1526922848591};\\\", \\\"{x:1498,y:772,t:1526922848607};\\\", \\\"{x:1498,y:764,t:1526922848625};\\\", \\\"{x:1500,y:755,t:1526922848641};\\\", \\\"{x:1500,y:750,t:1526922848657};\\\", \\\"{x:1500,y:742,t:1526922848675};\\\", \\\"{x:1500,y:737,t:1526922848691};\\\", \\\"{x:1501,y:732,t:1526922848708};\\\", \\\"{x:1502,y:726,t:1526922848724};\\\", \\\"{x:1504,y:721,t:1526922848741};\\\", \\\"{x:1504,y:714,t:1526922848759};\\\", \\\"{x:1505,y:709,t:1526922848775};\\\", \\\"{x:1508,y:700,t:1526922848792};\\\", \\\"{x:1511,y:691,t:1526922848809};\\\", \\\"{x:1515,y:683,t:1526922848824};\\\", \\\"{x:1515,y:679,t:1526922848842};\\\", \\\"{x:1515,y:676,t:1526922848859};\\\", \\\"{x:1515,y:678,t:1526922848959};\\\", \\\"{x:1509,y:685,t:1526922848975};\\\", \\\"{x:1499,y:692,t:1526922848992};\\\", \\\"{x:1483,y:703,t:1526922849009};\\\", \\\"{x:1472,y:710,t:1526922849024};\\\", \\\"{x:1458,y:717,t:1526922849041};\\\", \\\"{x:1449,y:723,t:1526922849059};\\\", \\\"{x:1443,y:726,t:1526922849076};\\\", \\\"{x:1437,y:729,t:1526922849091};\\\", \\\"{x:1434,y:732,t:1526922849108};\\\", \\\"{x:1431,y:735,t:1526922849126};\\\", \\\"{x:1428,y:737,t:1526922849141};\\\", \\\"{x:1424,y:740,t:1526922849158};\\\", \\\"{x:1421,y:742,t:1526922849175};\\\", \\\"{x:1419,y:745,t:1526922849191};\\\", \\\"{x:1417,y:745,t:1526922849208};\\\", \\\"{x:1416,y:747,t:1526922849225};\\\", \\\"{x:1408,y:750,t:1526922849241};\\\", \\\"{x:1404,y:751,t:1526922849258};\\\", \\\"{x:1395,y:755,t:1526922849276};\\\", \\\"{x:1387,y:757,t:1526922849291};\\\", \\\"{x:1380,y:762,t:1526922849308};\\\", \\\"{x:1375,y:762,t:1526922849326};\\\", \\\"{x:1371,y:763,t:1526922849342};\\\", \\\"{x:1368,y:763,t:1526922849358};\\\", \\\"{x:1366,y:764,t:1526922849375};\\\", \\\"{x:1364,y:764,t:1526922849391};\\\", \\\"{x:1362,y:764,t:1526922849408};\\\", \\\"{x:1359,y:765,t:1526922849425};\\\", \\\"{x:1357,y:765,t:1526922849442};\\\", \\\"{x:1354,y:765,t:1526922849459};\\\", \\\"{x:1352,y:765,t:1526922849475};\\\", \\\"{x:1345,y:759,t:1526922849493};\\\", \\\"{x:1344,y:756,t:1526922849509};\\\", \\\"{x:1342,y:751,t:1526922849526};\\\", \\\"{x:1341,y:745,t:1526922849542};\\\", \\\"{x:1340,y:742,t:1526922849558};\\\", \\\"{x:1340,y:738,t:1526922849575};\\\", \\\"{x:1338,y:735,t:1526922849593};\\\", \\\"{x:1337,y:733,t:1526922849608};\\\", \\\"{x:1337,y:731,t:1526922849625};\\\", \\\"{x:1337,y:728,t:1526922849642};\\\", \\\"{x:1337,y:726,t:1526922849659};\\\", \\\"{x:1337,y:723,t:1526922849675};\\\", \\\"{x:1337,y:721,t:1526922849692};\\\", \\\"{x:1339,y:717,t:1526922849709};\\\", \\\"{x:1339,y:715,t:1526922849725};\\\", \\\"{x:1341,y:713,t:1526922849742};\\\", \\\"{x:1341,y:711,t:1526922849758};\\\", \\\"{x:1341,y:710,t:1526922849776};\\\", \\\"{x:1341,y:709,t:1526922849798};\\\", \\\"{x:1341,y:708,t:1526922849815};\\\", \\\"{x:1341,y:707,t:1526922849831};\\\", \\\"{x:1341,y:705,t:1526922849854};\\\", \\\"{x:1341,y:704,t:1526922849935};\\\", \\\"{x:1342,y:703,t:1526922849951};\\\", \\\"{x:1342,y:702,t:1526922849982};\\\", \\\"{x:1342,y:701,t:1526922850006};\\\", \\\"{x:1343,y:700,t:1526922850023};\\\", \\\"{x:1344,y:700,t:1526922850046};\\\", \\\"{x:1344,y:699,t:1526922850167};\\\", \\\"{x:1344,y:698,t:1526922850176};\\\", \\\"{x:1345,y:697,t:1526922851398};\\\", \\\"{x:1347,y:695,t:1526922851463};\\\", \\\"{x:1348,y:694,t:1526922885678};\\\", \\\"{x:1348,y:692,t:1526922885701};\\\", \\\"{x:1347,y:690,t:1526922885711};\\\", \\\"{x:1344,y:687,t:1526922885727};\\\", \\\"{x:1342,y:686,t:1526922885745};\\\", \\\"{x:1339,y:684,t:1526922885761};\\\", \\\"{x:1337,y:683,t:1526922885778};\\\", \\\"{x:1336,y:682,t:1526922885794};\\\", \\\"{x:1335,y:682,t:1526922885810};\\\", \\\"{x:1334,y:681,t:1526922885829};\\\", \\\"{x:1333,y:681,t:1526922885845};\\\", \\\"{x:1332,y:680,t:1526922885862};\\\", \\\"{x:1331,y:679,t:1526922885878};\\\", \\\"{x:1331,y:678,t:1526922885894};\\\", \\\"{x:1330,y:678,t:1526922885910};\\\", \\\"{x:1328,y:678,t:1526922885942};\\\", \\\"{x:1327,y:677,t:1526922885949};\\\", \\\"{x:1326,y:676,t:1526922885966};\\\", \\\"{x:1324,y:675,t:1526922885990};\\\", \\\"{x:1323,y:673,t:1526922886014};\\\", \\\"{x:1323,y:672,t:1526922886028};\\\", \\\"{x:1321,y:671,t:1526922886044};\\\", \\\"{x:1320,y:670,t:1526922886062};\\\", \\\"{x:1319,y:670,t:1526922886077};\\\", \\\"{x:1317,y:668,t:1526922886094};\\\", \\\"{x:1314,y:667,t:1526922886112};\\\", \\\"{x:1312,y:665,t:1526922886128};\\\", \\\"{x:1310,y:665,t:1526922886144};\\\", \\\"{x:1309,y:664,t:1526922886161};\\\", \\\"{x:1306,y:662,t:1526922886178};\\\", \\\"{x:1304,y:660,t:1526922886195};\\\", \\\"{x:1302,y:658,t:1526922886211};\\\", \\\"{x:1300,y:658,t:1526922886228};\\\", \\\"{x:1299,y:657,t:1526922886245};\\\", \\\"{x:1297,y:654,t:1526922886261};\\\", \\\"{x:1295,y:652,t:1526922886277};\\\", \\\"{x:1291,y:648,t:1526922886294};\\\", \\\"{x:1289,y:646,t:1526922886311};\\\", \\\"{x:1286,y:642,t:1526922886328};\\\", \\\"{x:1282,y:637,t:1526922886344};\\\", \\\"{x:1279,y:634,t:1526922886362};\\\", \\\"{x:1278,y:633,t:1526922886377};\\\", \\\"{x:1277,y:631,t:1526922886395};\\\", \\\"{x:1276,y:629,t:1526922886411};\\\", \\\"{x:1275,y:627,t:1526922886428};\\\", \\\"{x:1275,y:624,t:1526922886445};\\\", \\\"{x:1275,y:619,t:1526922886462};\\\", \\\"{x:1275,y:618,t:1526922886477};\\\", \\\"{x:1275,y:616,t:1526922886495};\\\", \\\"{x:1275,y:614,t:1526922886511};\\\", \\\"{x:1275,y:612,t:1526922886529};\\\", \\\"{x:1275,y:611,t:1526922886545};\\\", \\\"{x:1275,y:609,t:1526922886562};\\\", \\\"{x:1275,y:608,t:1526922886599};\\\", \\\"{x:1275,y:606,t:1526922886612};\\\", \\\"{x:1275,y:604,t:1526922886638};\\\", \\\"{x:1275,y:603,t:1526922886645};\\\", \\\"{x:1275,y:602,t:1526922886670};\\\", \\\"{x:1275,y:601,t:1526922886678};\\\", \\\"{x:1275,y:596,t:1526922886694};\\\", \\\"{x:1274,y:596,t:1526922886712};\\\", \\\"{x:1274,y:593,t:1526922886729};\\\", \\\"{x:1274,y:590,t:1526922886746};\\\", \\\"{x:1273,y:588,t:1526922886762};\\\", \\\"{x:1272,y:587,t:1526922886778};\\\", \\\"{x:1272,y:586,t:1526922886795};\\\", \\\"{x:1272,y:585,t:1526922886813};\\\", \\\"{x:1272,y:584,t:1526922886829};\\\", \\\"{x:1272,y:583,t:1526922886846};\\\", \\\"{x:1272,y:582,t:1526922886862};\\\", \\\"{x:1272,y:581,t:1526922886879};\\\", \\\"{x:1272,y:580,t:1526922886934};\\\", \\\"{x:1272,y:579,t:1526922886982};\\\", \\\"{x:1272,y:577,t:1526922887038};\\\", \\\"{x:1272,y:576,t:1526922887045};\\\", \\\"{x:1273,y:574,t:1526922887110};\\\", \\\"{x:1273,y:573,t:1526922887150};\\\", \\\"{x:1274,y:571,t:1526922887174};\\\", \\\"{x:1275,y:568,t:1526922887206};\\\", \\\"{x:1276,y:567,t:1526922887222};\\\", \\\"{x:1276,y:566,t:1526922887237};\\\", \\\"{x:1276,y:565,t:1526922887246};\\\", \\\"{x:1277,y:563,t:1526922887262};\\\", \\\"{x:1277,y:561,t:1526922887302};\\\", \\\"{x:1277,y:560,t:1526922887333};\\\", \\\"{x:1277,y:561,t:1526922888494};\\\", \\\"{x:1277,y:562,t:1526922888701};\\\", \\\"{x:1277,y:563,t:1526922888714};\\\", \\\"{x:1277,y:566,t:1526922890742};\\\", \\\"{x:1277,y:569,t:1526922890750};\\\", \\\"{x:1277,y:573,t:1526922890765};\\\", \\\"{x:1277,y:579,t:1526922890782};\\\", \\\"{x:1277,y:582,t:1526922890799};\\\", \\\"{x:1280,y:587,t:1526922890816};\\\", \\\"{x:1282,y:589,t:1526922890832};\\\", \\\"{x:1284,y:592,t:1526922890848};\\\", \\\"{x:1287,y:595,t:1526922890865};\\\", \\\"{x:1288,y:598,t:1526922890883};\\\", \\\"{x:1291,y:602,t:1526922890899};\\\", \\\"{x:1296,y:606,t:1526922890915};\\\", \\\"{x:1302,y:612,t:1526922890933};\\\", \\\"{x:1310,y:621,t:1526922890949};\\\", \\\"{x:1314,y:625,t:1526922890966};\\\", \\\"{x:1317,y:630,t:1526922890983};\\\", \\\"{x:1323,y:635,t:1526922890999};\\\", \\\"{x:1331,y:644,t:1526922891016};\\\", \\\"{x:1332,y:646,t:1526922891033};\\\", \\\"{x:1337,y:655,t:1526922891050};\\\", \\\"{x:1341,y:660,t:1526922891066};\\\", \\\"{x:1345,y:666,t:1526922891083};\\\", \\\"{x:1347,y:670,t:1526922891100};\\\", \\\"{x:1349,y:675,t:1526922891115};\\\", \\\"{x:1353,y:682,t:1526922891132};\\\", \\\"{x:1354,y:685,t:1526922891150};\\\", \\\"{x:1355,y:688,t:1526922891165};\\\", \\\"{x:1357,y:691,t:1526922891183};\\\", \\\"{x:1357,y:693,t:1526922891200};\\\", \\\"{x:1357,y:694,t:1526922891216};\\\", \\\"{x:1357,y:695,t:1526922891233};\\\", \\\"{x:1357,y:696,t:1526922891250};\\\", \\\"{x:1356,y:696,t:1526922892246};\\\", \\\"{x:1355,y:696,t:1526922892446};\\\", \\\"{x:1354,y:696,t:1526922893237};\\\", \\\"{x:1353,y:696,t:1526922893251};\\\", \\\"{x:1350,y:694,t:1526922893268};\\\", \\\"{x:1347,y:690,t:1526922893285};\\\", \\\"{x:1344,y:687,t:1526922893301};\\\", \\\"{x:1344,y:686,t:1526922893317};\\\", \\\"{x:1343,y:685,t:1526922893349};\\\", \\\"{x:1342,y:685,t:1526922896590};\\\", \\\"{x:1342,y:686,t:1526922896621};\\\", \\\"{x:1343,y:687,t:1526922896638};\\\", \\\"{x:1343,y:689,t:1526922896654};\\\", \\\"{x:1345,y:692,t:1526922896672};\\\", \\\"{x:1346,y:693,t:1526922896688};\\\", \\\"{x:1348,y:695,t:1526922896705};\\\", \\\"{x:1350,y:697,t:1526922896722};\\\", \\\"{x:1353,y:699,t:1526922896738};\\\", \\\"{x:1356,y:702,t:1526922896755};\\\", \\\"{x:1358,y:703,t:1526922896772};\\\", \\\"{x:1360,y:704,t:1526922896788};\\\", \\\"{x:1364,y:706,t:1526922896805};\\\", \\\"{x:1368,y:708,t:1526922896822};\\\", \\\"{x:1371,y:709,t:1526922896838};\\\", \\\"{x:1375,y:712,t:1526922896855};\\\", \\\"{x:1380,y:714,t:1526922896872};\\\", \\\"{x:1385,y:716,t:1526922896888};\\\", \\\"{x:1391,y:720,t:1526922896905};\\\", \\\"{x:1397,y:721,t:1526922896922};\\\", \\\"{x:1400,y:722,t:1526922896938};\\\", \\\"{x:1405,y:725,t:1526922896955};\\\", \\\"{x:1410,y:727,t:1526922896972};\\\", \\\"{x:1414,y:728,t:1526922896988};\\\", \\\"{x:1420,y:729,t:1526922897005};\\\", \\\"{x:1429,y:733,t:1526922897022};\\\", \\\"{x:1438,y:737,t:1526922897039};\\\", \\\"{x:1447,y:740,t:1526922897055};\\\", \\\"{x:1456,y:742,t:1526922897072};\\\", \\\"{x:1462,y:746,t:1526922897089};\\\", \\\"{x:1467,y:746,t:1526922897104};\\\", \\\"{x:1469,y:747,t:1526922897122};\\\", \\\"{x:1470,y:747,t:1526922897139};\\\", \\\"{x:1471,y:748,t:1526922897155};\\\", \\\"{x:1474,y:749,t:1526922897172};\\\", \\\"{x:1474,y:750,t:1526922897189};\\\", \\\"{x:1477,y:750,t:1526922897205};\\\", \\\"{x:1484,y:753,t:1526922897222};\\\", \\\"{x:1488,y:754,t:1526922897239};\\\", \\\"{x:1492,y:756,t:1526922897255};\\\", \\\"{x:1495,y:757,t:1526922897272};\\\", \\\"{x:1499,y:757,t:1526922897289};\\\", \\\"{x:1499,y:758,t:1526922897306};\\\", \\\"{x:1501,y:760,t:1526922897322};\\\", \\\"{x:1502,y:760,t:1526922897339};\\\", \\\"{x:1503,y:760,t:1526922897356};\\\", \\\"{x:1505,y:760,t:1526922897382};\\\", \\\"{x:1506,y:761,t:1526922897413};\\\", \\\"{x:1508,y:761,t:1526922897453};\\\", \\\"{x:1509,y:762,t:1526922897469};\\\", \\\"{x:1511,y:762,t:1526922897489};\\\", \\\"{x:1511,y:763,t:1526922897506};\\\", \\\"{x:1512,y:763,t:1526922897525};\\\", \\\"{x:1513,y:763,t:1526922897539};\\\", \\\"{x:1514,y:763,t:1526922897558};\\\", \\\"{x:1515,y:764,t:1526922898142};\\\", \\\"{x:1515,y:765,t:1526922898156};\\\", \\\"{x:1514,y:771,t:1526922898173};\\\", \\\"{x:1510,y:779,t:1526922898189};\\\", \\\"{x:1506,y:785,t:1526922898206};\\\", \\\"{x:1505,y:789,t:1526922898223};\\\", \\\"{x:1503,y:792,t:1526922898240};\\\", \\\"{x:1502,y:796,t:1526922898256};\\\", \\\"{x:1501,y:798,t:1526922898273};\\\", \\\"{x:1500,y:800,t:1526922898290};\\\", \\\"{x:1500,y:802,t:1526922898306};\\\", \\\"{x:1500,y:803,t:1526922898323};\\\", \\\"{x:1500,y:804,t:1526922898340};\\\", \\\"{x:1500,y:806,t:1526922898356};\\\", \\\"{x:1500,y:808,t:1526922898382};\\\", \\\"{x:1500,y:810,t:1526922898389};\\\", \\\"{x:1499,y:810,t:1526922898406};\\\", \\\"{x:1499,y:812,t:1526922898423};\\\", \\\"{x:1498,y:813,t:1526922898902};\\\", \\\"{x:1497,y:813,t:1526922898917};\\\", \\\"{x:1496,y:814,t:1526922898925};\\\", \\\"{x:1495,y:816,t:1526922898941};\\\", \\\"{x:1494,y:816,t:1526922898957};\\\", \\\"{x:1493,y:816,t:1526922898973};\\\", \\\"{x:1492,y:817,t:1526922898990};\\\", \\\"{x:1491,y:819,t:1526922899007};\\\", \\\"{x:1490,y:819,t:1526922899024};\\\", \\\"{x:1490,y:820,t:1526922899040};\\\", \\\"{x:1489,y:821,t:1526922899062};\\\", \\\"{x:1489,y:822,t:1526922899110};\\\", \\\"{x:1488,y:822,t:1526922899212};\\\", \\\"{x:1488,y:823,t:1526922899220};\\\", \\\"{x:1487,y:824,t:1526922899244};\\\", \\\"{x:1486,y:825,t:1526922899292};\\\", \\\"{x:1485,y:826,t:1526922899388};\\\", \\\"{x:1484,y:827,t:1526922899844};\\\", \\\"{x:1484,y:828,t:1526922899892};\\\", \\\"{x:1482,y:828,t:1526922899980};\\\", \\\"{x:1482,y:829,t:1526922899998};\\\", \\\"{x:1481,y:829,t:1526922900028};\\\", \\\"{x:1478,y:832,t:1526922900461};\\\", \\\"{x:1474,y:833,t:1526922900470};\\\", \\\"{x:1466,y:837,t:1526922900481};\\\", \\\"{x:1444,y:844,t:1526922900498};\\\", \\\"{x:1406,y:846,t:1526922900515};\\\", \\\"{x:1355,y:847,t:1526922900531};\\\", \\\"{x:1336,y:849,t:1526922900547};\\\", \\\"{x:1272,y:844,t:1526922900565};\\\", \\\"{x:1242,y:837,t:1526922900582};\\\", \\\"{x:1223,y:832,t:1526922900597};\\\", \\\"{x:1203,y:828,t:1526922900614};\\\", \\\"{x:1179,y:821,t:1526922900631};\\\", \\\"{x:1151,y:816,t:1526922900648};\\\", \\\"{x:1113,y:808,t:1526922900664};\\\", \\\"{x:1062,y:798,t:1526922900682};\\\", \\\"{x:959,y:768,t:1526922900697};\\\", \\\"{x:876,y:743,t:1526922900715};\\\", \\\"{x:836,y:723,t:1526922900731};\\\", \\\"{x:804,y:713,t:1526922900748};\\\", \\\"{x:774,y:701,t:1526922900765};\\\", \\\"{x:771,y:698,t:1526922900782};\\\", \\\"{x:770,y:696,t:1526922900797};\\\", \\\"{x:769,y:694,t:1526922900815};\\\", \\\"{x:767,y:690,t:1526922900831};\\\", \\\"{x:763,y:684,t:1526922900848};\\\", \\\"{x:752,y:679,t:1526922900864};\\\", \\\"{x:732,y:670,t:1526922900881};\\\", \\\"{x:714,y:664,t:1526922900897};\\\", \\\"{x:699,y:658,t:1526922900914};\\\", \\\"{x:690,y:653,t:1526922900932};\\\", \\\"{x:684,y:650,t:1526922900948};\\\", \\\"{x:683,y:649,t:1526922900965};\\\", \\\"{x:681,y:647,t:1526922900983};\\\", \\\"{x:681,y:646,t:1526922900999};\\\", \\\"{x:679,y:646,t:1526922901015};\\\", \\\"{x:675,y:644,t:1526922901032};\\\", \\\"{x:672,y:642,t:1526922901049};\\\", \\\"{x:671,y:640,t:1526922901064};\\\", \\\"{x:669,y:639,t:1526922901081};\\\", \\\"{x:666,y:636,t:1526922901099};\\\", \\\"{x:661,y:632,t:1526922901115};\\\", \\\"{x:658,y:630,t:1526922901133};\\\", \\\"{x:652,y:624,t:1526922901148};\\\", \\\"{x:647,y:615,t:1526922901166};\\\", \\\"{x:644,y:610,t:1526922901181};\\\", \\\"{x:641,y:604,t:1526922901206};\\\", \\\"{x:637,y:600,t:1526922901222};\\\", \\\"{x:634,y:597,t:1526922901239};\\\", \\\"{x:632,y:594,t:1526922901256};\\\", \\\"{x:630,y:591,t:1526922901272};\\\", \\\"{x:630,y:589,t:1526922901288};\\\", \\\"{x:629,y:589,t:1526922901305};\\\", \\\"{x:628,y:587,t:1526922901322};\\\", \\\"{x:627,y:587,t:1526922901339};\\\", \\\"{x:626,y:586,t:1526922901355};\\\", \\\"{x:625,y:586,t:1526922901460};\\\", \\\"{x:624,y:586,t:1526922901565};\\\", \\\"{x:623,y:585,t:1526922901572};\\\", \\\"{x:624,y:584,t:1526922901924};\\\", \\\"{x:630,y:585,t:1526922901938};\\\", \\\"{x:658,y:601,t:1526922901956};\\\", \\\"{x:688,y:615,t:1526922901972};\\\", \\\"{x:736,y:641,t:1526922901989};\\\", \\\"{x:810,y:669,t:1526922902005};\\\", \\\"{x:884,y:700,t:1526922902023};\\\", \\\"{x:974,y:729,t:1526922902040};\\\", \\\"{x:1060,y:754,t:1526922902055};\\\", \\\"{x:1141,y:780,t:1526922902073};\\\", \\\"{x:1200,y:797,t:1526922902089};\\\", \\\"{x:1248,y:806,t:1526922902105};\\\", \\\"{x:1273,y:812,t:1526922902123};\\\", \\\"{x:1300,y:817,t:1526922902140};\\\", \\\"{x:1308,y:822,t:1526922902156};\\\", \\\"{x:1315,y:825,t:1526922902173};\\\", \\\"{x:1327,y:830,t:1526922902189};\\\", \\\"{x:1350,y:834,t:1526922902206};\\\", \\\"{x:1369,y:836,t:1526922902223};\\\", \\\"{x:1389,y:836,t:1526922902240};\\\", \\\"{x:1407,y:840,t:1526922902255};\\\", \\\"{x:1422,y:841,t:1526922902273};\\\", \\\"{x:1429,y:841,t:1526922902289};\\\", \\\"{x:1431,y:841,t:1526922902305};\\\", \\\"{x:1432,y:841,t:1526922902322};\\\", \\\"{x:1433,y:841,t:1526922902411};\\\", \\\"{x:1435,y:841,t:1526922902428};\\\", \\\"{x:1437,y:841,t:1526922902460};\\\", \\\"{x:1439,y:840,t:1526922902476};\\\", \\\"{x:1441,y:840,t:1526922902491};\\\", \\\"{x:1443,y:839,t:1526922902507};\\\", \\\"{x:1446,y:838,t:1526922902522};\\\", \\\"{x:1455,y:838,t:1526922902540};\\\", \\\"{x:1461,y:838,t:1526922902556};\\\", \\\"{x:1463,y:838,t:1526922902573};\\\", \\\"{x:1466,y:837,t:1526922902590};\\\", \\\"{x:1468,y:837,t:1526922902607};\\\", \\\"{x:1470,y:837,t:1526922902622};\\\", \\\"{x:1471,y:837,t:1526922902643};\\\", \\\"{x:1472,y:837,t:1526922902660};\\\", \\\"{x:1474,y:837,t:1526922902673};\\\", \\\"{x:1476,y:838,t:1526922902690};\\\", \\\"{x:1480,y:840,t:1526922902706};\\\", \\\"{x:1483,y:840,t:1526922902722};\\\", \\\"{x:1484,y:840,t:1526922902739};\\\", \\\"{x:1487,y:840,t:1526922902756};\\\", \\\"{x:1488,y:840,t:1526922902812};\\\", \\\"{x:1489,y:840,t:1526922902822};\\\", \\\"{x:1490,y:840,t:1526922902840};\\\", \\\"{x:1491,y:840,t:1526922902860};\\\", \\\"{x:1492,y:840,t:1526922902884};\\\", \\\"{x:1493,y:841,t:1526922902891};\\\", \\\"{x:1495,y:841,t:1526922902906};\\\", \\\"{x:1500,y:842,t:1526922902924};\\\", \\\"{x:1500,y:843,t:1526922903052};\\\", \\\"{x:1498,y:843,t:1526922903284};\\\", \\\"{x:1497,y:843,t:1526922903292};\\\", \\\"{x:1496,y:843,t:1526922903308};\\\", \\\"{x:1494,y:842,t:1526922903324};\\\", \\\"{x:1493,y:841,t:1526922903340};\\\", \\\"{x:1492,y:840,t:1526922903357};\\\", \\\"{x:1491,y:840,t:1526922903373};\\\", \\\"{x:1490,y:839,t:1526922903404};\\\", \\\"{x:1490,y:838,t:1526922903412};\\\", \\\"{x:1492,y:838,t:1526922903652};\\\", \\\"{x:1492,y:840,t:1526922903667};\\\", \\\"{x:1494,y:841,t:1526922903676};\\\", \\\"{x:1495,y:841,t:1526922903691};\\\", \\\"{x:1498,y:843,t:1526922903707};\\\", \\\"{x:1503,y:845,t:1526922903723};\\\", \\\"{x:1505,y:845,t:1526922903740};\\\", \\\"{x:1507,y:846,t:1526922903756};\\\", \\\"{x:1509,y:848,t:1526922903773};\\\", \\\"{x:1512,y:848,t:1526922903791};\\\", \\\"{x:1516,y:849,t:1526922903807};\\\", \\\"{x:1521,y:849,t:1526922903824};\\\", \\\"{x:1526,y:851,t:1526922903841};\\\", \\\"{x:1533,y:852,t:1526922903856};\\\", \\\"{x:1542,y:852,t:1526922903874};\\\", \\\"{x:1550,y:852,t:1526922903890};\\\", \\\"{x:1552,y:852,t:1526922903907};\\\", \\\"{x:1557,y:852,t:1526922903924};\\\", \\\"{x:1560,y:852,t:1526922903940};\\\", \\\"{x:1561,y:852,t:1526922903958};\\\", \\\"{x:1564,y:852,t:1526922903974};\\\", \\\"{x:1567,y:852,t:1526922903991};\\\", \\\"{x:1571,y:852,t:1526922904008};\\\", \\\"{x:1575,y:852,t:1526922904024};\\\", \\\"{x:1577,y:851,t:1526922904041};\\\", \\\"{x:1582,y:851,t:1526922904057};\\\", \\\"{x:1589,y:850,t:1526922904073};\\\", \\\"{x:1595,y:848,t:1526922904091};\\\", \\\"{x:1598,y:848,t:1526922904108};\\\", \\\"{x:1602,y:847,t:1526922904124};\\\", \\\"{x:1609,y:846,t:1526922904140};\\\", \\\"{x:1612,y:846,t:1526922904158};\\\", \\\"{x:1615,y:846,t:1526922904174};\\\", \\\"{x:1616,y:846,t:1526922904191};\\\", \\\"{x:1617,y:846,t:1526922904208};\\\", \\\"{x:1620,y:846,t:1526922904261};\\\", \\\"{x:1621,y:846,t:1526922904285};\\\", \\\"{x:1622,y:846,t:1526922904301};\\\", \\\"{x:1622,y:844,t:1526922904308};\\\", \\\"{x:1623,y:842,t:1526922904325};\\\", \\\"{x:1623,y:841,t:1526922904341};\\\", \\\"{x:1624,y:841,t:1526922904381};\\\", \\\"{x:1625,y:842,t:1526922904429};\\\", \\\"{x:1626,y:845,t:1526922904441};\\\", \\\"{x:1630,y:853,t:1526922904458};\\\", \\\"{x:1631,y:862,t:1526922904474};\\\", \\\"{x:1631,y:870,t:1526922904491};\\\", \\\"{x:1633,y:886,t:1526922904507};\\\", \\\"{x:1633,y:896,t:1526922904524};\\\", \\\"{x:1633,y:907,t:1526922904541};\\\", \\\"{x:1631,y:918,t:1526922904557};\\\", \\\"{x:1631,y:928,t:1526922904575};\\\", \\\"{x:1629,y:940,t:1526922904590};\\\", \\\"{x:1629,y:945,t:1526922904608};\\\", \\\"{x:1629,y:950,t:1526922904625};\\\", \\\"{x:1629,y:952,t:1526922904641};\\\", \\\"{x:1629,y:955,t:1526922904658};\\\", \\\"{x:1629,y:956,t:1526922904674};\\\", \\\"{x:1629,y:957,t:1526922904691};\\\", \\\"{x:1629,y:960,t:1526922904708};\\\", \\\"{x:1628,y:961,t:1526922904901};\\\", \\\"{x:1627,y:962,t:1526922905045};\\\", \\\"{x:1625,y:961,t:1526922905061};\\\", \\\"{x:1625,y:959,t:1526922905075};\\\", \\\"{x:1625,y:950,t:1526922905092};\\\", \\\"{x:1624,y:943,t:1526922905109};\\\", \\\"{x:1623,y:932,t:1526922905126};\\\", \\\"{x:1622,y:927,t:1526922905143};\\\", \\\"{x:1622,y:925,t:1526922905158};\\\", \\\"{x:1622,y:922,t:1526922905176};\\\", \\\"{x:1618,y:916,t:1526922905192};\\\", \\\"{x:1618,y:912,t:1526922905209};\\\", \\\"{x:1618,y:910,t:1526922905225};\\\", \\\"{x:1618,y:907,t:1526922905242};\\\", \\\"{x:1618,y:903,t:1526922905258};\\\", \\\"{x:1618,y:899,t:1526922905275};\\\", \\\"{x:1618,y:895,t:1526922905292};\\\", \\\"{x:1618,y:889,t:1526922905308};\\\", \\\"{x:1618,y:886,t:1526922905325};\\\", \\\"{x:1618,y:883,t:1526922905341};\\\", \\\"{x:1618,y:881,t:1526922905359};\\\", \\\"{x:1618,y:878,t:1526922905375};\\\", \\\"{x:1618,y:875,t:1526922905392};\\\", \\\"{x:1618,y:873,t:1526922905408};\\\", \\\"{x:1618,y:869,t:1526922905425};\\\", \\\"{x:1618,y:867,t:1526922905442};\\\", \\\"{x:1618,y:865,t:1526922905459};\\\", \\\"{x:1618,y:864,t:1526922905475};\\\", \\\"{x:1618,y:860,t:1526922905492};\\\", \\\"{x:1618,y:857,t:1526922905509};\\\", \\\"{x:1618,y:855,t:1526922905525};\\\", \\\"{x:1618,y:853,t:1526922905542};\\\", \\\"{x:1618,y:851,t:1526922905559};\\\", \\\"{x:1618,y:849,t:1526922905575};\\\", \\\"{x:1618,y:848,t:1526922905592};\\\", \\\"{x:1618,y:846,t:1526922905609};\\\", \\\"{x:1618,y:845,t:1526922905625};\\\", \\\"{x:1616,y:844,t:1526922905642};\\\", \\\"{x:1615,y:842,t:1526922905659};\\\", \\\"{x:1614,y:841,t:1526922905675};\\\", \\\"{x:1613,y:839,t:1526922905692};\\\", \\\"{x:1612,y:836,t:1526922905709};\\\", \\\"{x:1611,y:835,t:1526922905725};\\\", \\\"{x:1610,y:833,t:1526922905741};\\\", \\\"{x:1610,y:832,t:1526922905759};\\\", \\\"{x:1610,y:831,t:1526922905776};\\\", \\\"{x:1610,y:830,t:1526922905819};\\\", \\\"{x:1610,y:829,t:1526922906276};\\\", \\\"{x:1610,y:828,t:1526922906316};\\\", \\\"{x:1609,y:828,t:1526922907604};\\\", \\\"{x:1607,y:828,t:1526922908115};\\\", \\\"{x:1605,y:828,t:1526922908126};\\\", \\\"{x:1595,y:832,t:1526922908144};\\\", \\\"{x:1582,y:836,t:1526922908160};\\\", \\\"{x:1562,y:843,t:1526922908177};\\\", \\\"{x:1544,y:848,t:1526922908194};\\\", \\\"{x:1525,y:857,t:1526922908211};\\\", \\\"{x:1509,y:863,t:1526922908227};\\\", \\\"{x:1477,y:870,t:1526922908243};\\\", \\\"{x:1450,y:877,t:1526922908260};\\\", \\\"{x:1429,y:883,t:1526922908277};\\\", \\\"{x:1408,y:888,t:1526922908293};\\\", \\\"{x:1392,y:896,t:1526922908311};\\\", \\\"{x:1378,y:900,t:1526922908327};\\\", \\\"{x:1369,y:902,t:1526922908344};\\\", \\\"{x:1358,y:909,t:1526922908360};\\\", \\\"{x:1349,y:915,t:1526922908377};\\\", \\\"{x:1342,y:921,t:1526922908393};\\\", \\\"{x:1339,y:928,t:1526922908410};\\\", \\\"{x:1335,y:934,t:1526922908427};\\\", \\\"{x:1332,y:941,t:1526922908443};\\\", \\\"{x:1332,y:943,t:1526922908468};\\\", \\\"{x:1332,y:944,t:1526922908508};\\\", \\\"{x:1333,y:946,t:1526922908532};\\\", \\\"{x:1335,y:948,t:1526922908544};\\\", \\\"{x:1335,y:949,t:1526922908564};\\\", \\\"{x:1336,y:949,t:1526922908587};\\\", \\\"{x:1336,y:950,t:1526922908603};\\\", \\\"{x:1337,y:950,t:1526922908627};\\\", \\\"{x:1339,y:949,t:1526922908684};\\\", \\\"{x:1340,y:947,t:1526922908694};\\\", \\\"{x:1343,y:939,t:1526922908711};\\\", \\\"{x:1346,y:930,t:1526922908728};\\\", \\\"{x:1349,y:917,t:1526922908744};\\\", \\\"{x:1351,y:902,t:1526922908761};\\\", \\\"{x:1351,y:883,t:1526922908778};\\\", \\\"{x:1351,y:865,t:1526922908794};\\\", \\\"{x:1350,y:850,t:1526922908811};\\\", \\\"{x:1346,y:830,t:1526922908828};\\\", \\\"{x:1343,y:817,t:1526922908844};\\\", \\\"{x:1340,y:807,t:1526922908861};\\\", \\\"{x:1336,y:799,t:1526922908878};\\\", \\\"{x:1335,y:796,t:1526922908894};\\\", \\\"{x:1334,y:795,t:1526922908910};\\\", \\\"{x:1334,y:794,t:1526922908928};\\\", \\\"{x:1333,y:794,t:1526922908956};\\\", \\\"{x:1332,y:794,t:1526922909005};\\\", \\\"{x:1332,y:795,t:1526922909012};\\\", \\\"{x:1331,y:799,t:1526922909028};\\\", \\\"{x:1330,y:802,t:1526922909044};\\\", \\\"{x:1328,y:807,t:1526922909061};\\\", \\\"{x:1326,y:816,t:1526922909078};\\\", \\\"{x:1324,y:821,t:1526922909094};\\\", \\\"{x:1321,y:830,t:1526922909111};\\\", \\\"{x:1318,y:841,t:1526922909128};\\\", \\\"{x:1316,y:848,t:1526922909145};\\\", \\\"{x:1309,y:859,t:1526922909161};\\\", \\\"{x:1304,y:869,t:1526922909179};\\\", \\\"{x:1297,y:880,t:1526922909196};\\\", \\\"{x:1295,y:886,t:1526922909212};\\\", \\\"{x:1290,y:896,t:1526922909229};\\\", \\\"{x:1289,y:902,t:1526922909245};\\\", \\\"{x:1286,y:910,t:1526922909261};\\\", \\\"{x:1283,y:917,t:1526922909278};\\\", \\\"{x:1280,y:920,t:1526922909296};\\\", \\\"{x:1278,y:922,t:1526922909312};\\\", \\\"{x:1278,y:924,t:1526922909333};\\\", \\\"{x:1277,y:924,t:1526922909345};\\\", \\\"{x:1276,y:924,t:1526922909362};\\\", \\\"{x:1272,y:926,t:1526922909378};\\\", \\\"{x:1266,y:927,t:1526922909395};\\\", \\\"{x:1260,y:928,t:1526922909412};\\\", \\\"{x:1250,y:928,t:1526922909429};\\\", \\\"{x:1241,y:928,t:1526922909445};\\\", \\\"{x:1232,y:927,t:1526922909460};\\\", \\\"{x:1222,y:924,t:1526922909478};\\\", \\\"{x:1211,y:919,t:1526922909494};\\\", \\\"{x:1198,y:913,t:1526922909511};\\\", \\\"{x:1161,y:899,t:1526922909528};\\\", \\\"{x:1125,y:884,t:1526922909545};\\\", \\\"{x:1090,y:877,t:1526922909562};\\\", \\\"{x:1049,y:866,t:1526922909578};\\\", \\\"{x:1003,y:850,t:1526922909595};\\\", \\\"{x:950,y:829,t:1526922909611};\\\", \\\"{x:921,y:820,t:1526922909627};\\\", \\\"{x:905,y:813,t:1526922909645};\\\", \\\"{x:888,y:809,t:1526922909661};\\\", \\\"{x:876,y:807,t:1526922909678};\\\", \\\"{x:862,y:807,t:1526922909694};\\\", \\\"{x:849,y:807,t:1526922909711};\\\", \\\"{x:834,y:806,t:1526922909727};\\\", \\\"{x:818,y:806,t:1526922909744};\\\", \\\"{x:800,y:803,t:1526922909761};\\\", \\\"{x:783,y:802,t:1526922909778};\\\", \\\"{x:761,y:801,t:1526922909794};\\\", \\\"{x:731,y:797,t:1526922909811};\\\", \\\"{x:707,y:794,t:1526922909828};\\\", \\\"{x:688,y:794,t:1526922909844};\\\", \\\"{x:665,y:794,t:1526922909861};\\\", \\\"{x:646,y:794,t:1526922909878};\\\", \\\"{x:623,y:789,t:1526922909895};\\\", \\\"{x:601,y:786,t:1526922909911};\\\", \\\"{x:580,y:784,t:1526922909928};\\\", \\\"{x:560,y:781,t:1526922909945};\\\", \\\"{x:545,y:780,t:1526922909961};\\\", \\\"{x:529,y:774,t:1526922909979};\\\", \\\"{x:515,y:769,t:1526922909995};\\\", \\\"{x:497,y:762,t:1526922910012};\\\", \\\"{x:482,y:755,t:1526922910029};\\\", \\\"{x:477,y:750,t:1526922910045};\\\", \\\"{x:473,y:747,t:1526922910061};\\\", \\\"{x:471,y:745,t:1526922910079};\\\", \\\"{x:470,y:744,t:1526922910095};\\\", \\\"{x:468,y:744,t:1526922910111};\\\", \\\"{x:468,y:743,t:1526922910129};\\\" ] }, { \\\"rt\\\": 12563, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 355657, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:741,t:1526922913284};\\\", \\\"{x:468,y:740,t:1526922914036};\\\", \\\"{x:470,y:740,t:1526922914045};\\\", \\\"{x:476,y:740,t:1526922914062};\\\", \\\"{x:493,y:742,t:1526922914079};\\\", \\\"{x:512,y:748,t:1526922914096};\\\", \\\"{x:539,y:751,t:1526922914111};\\\", \\\"{x:560,y:759,t:1526922914129};\\\", \\\"{x:609,y:774,t:1526922914145};\\\", \\\"{x:650,y:786,t:1526922914162};\\\", \\\"{x:733,y:807,t:1526922914182};\\\", \\\"{x:802,y:824,t:1526922914198};\\\", \\\"{x:874,y:840,t:1526922914215};\\\", \\\"{x:927,y:857,t:1526922914232};\\\", \\\"{x:988,y:867,t:1526922914248};\\\", \\\"{x:1051,y:878,t:1526922914265};\\\", \\\"{x:1118,y:891,t:1526922914282};\\\", \\\"{x:1175,y:900,t:1526922914298};\\\", \\\"{x:1235,y:914,t:1526922914315};\\\", \\\"{x:1288,y:926,t:1526922914332};\\\", \\\"{x:1312,y:937,t:1526922914348};\\\", \\\"{x:1341,y:942,t:1526922914365};\\\", \\\"{x:1371,y:951,t:1526922914382};\\\", \\\"{x:1388,y:956,t:1526922914398};\\\", \\\"{x:1408,y:963,t:1526922914415};\\\", \\\"{x:1419,y:968,t:1526922914432};\\\", \\\"{x:1423,y:970,t:1526922914448};\\\", \\\"{x:1424,y:971,t:1526922914465};\\\", \\\"{x:1425,y:972,t:1526922914628};\\\", \\\"{x:1425,y:973,t:1526922914636};\\\", \\\"{x:1425,y:974,t:1526922914648};\\\", \\\"{x:1421,y:975,t:1526922914665};\\\", \\\"{x:1418,y:975,t:1526922914682};\\\", \\\"{x:1414,y:975,t:1526922914698};\\\", \\\"{x:1412,y:975,t:1526922914715};\\\", \\\"{x:1411,y:975,t:1526922914732};\\\", \\\"{x:1408,y:975,t:1526922914748};\\\", \\\"{x:1406,y:975,t:1526922914765};\\\", \\\"{x:1404,y:974,t:1526922914782};\\\", \\\"{x:1403,y:974,t:1526922914798};\\\", \\\"{x:1402,y:974,t:1526922914844};\\\", \\\"{x:1401,y:973,t:1526922914859};\\\", \\\"{x:1399,y:973,t:1526922914868};\\\", \\\"{x:1398,y:973,t:1526922914884};\\\", \\\"{x:1395,y:972,t:1526922914899};\\\", \\\"{x:1393,y:970,t:1526922914915};\\\", \\\"{x:1385,y:965,t:1526922914932};\\\", \\\"{x:1377,y:962,t:1526922914949};\\\", \\\"{x:1371,y:960,t:1526922914965};\\\", \\\"{x:1368,y:958,t:1526922914983};\\\", \\\"{x:1367,y:957,t:1526922914999};\\\", \\\"{x:1366,y:957,t:1526922915015};\\\", \\\"{x:1362,y:957,t:1526922915307};\\\", \\\"{x:1360,y:957,t:1526922915323};\\\", \\\"{x:1358,y:957,t:1526922915332};\\\", \\\"{x:1355,y:958,t:1526922915349};\\\", \\\"{x:1353,y:958,t:1526922915365};\\\", \\\"{x:1352,y:959,t:1526922915387};\\\", \\\"{x:1351,y:959,t:1526922915399};\\\", \\\"{x:1350,y:960,t:1526922915989};\\\", \\\"{x:1349,y:961,t:1526922916013};\\\", \\\"{x:1349,y:962,t:1526922916045};\\\", \\\"{x:1348,y:962,t:1526922916109};\\\", \\\"{x:1347,y:962,t:1526922916245};\\\", \\\"{x:1346,y:962,t:1526922916957};\\\", \\\"{x:1345,y:961,t:1526922916972};\\\", \\\"{x:1344,y:958,t:1526922916988};\\\", \\\"{x:1343,y:957,t:1526922917000};\\\", \\\"{x:1343,y:955,t:1526922917017};\\\", \\\"{x:1343,y:954,t:1526922917033};\\\", \\\"{x:1343,y:951,t:1526922917050};\\\", \\\"{x:1342,y:946,t:1526922917067};\\\", \\\"{x:1341,y:945,t:1526922917083};\\\", \\\"{x:1341,y:944,t:1526922917100};\\\", \\\"{x:1341,y:941,t:1526922917116};\\\", \\\"{x:1341,y:940,t:1526922917134};\\\", \\\"{x:1341,y:938,t:1526922917149};\\\", \\\"{x:1341,y:936,t:1526922917167};\\\", \\\"{x:1341,y:934,t:1526922917184};\\\", \\\"{x:1341,y:930,t:1526922917199};\\\", \\\"{x:1343,y:927,t:1526922917216};\\\", \\\"{x:1343,y:922,t:1526922917233};\\\", \\\"{x:1344,y:916,t:1526922917249};\\\", \\\"{x:1346,y:911,t:1526922917266};\\\", \\\"{x:1346,y:909,t:1526922917284};\\\", \\\"{x:1346,y:906,t:1526922917299};\\\", \\\"{x:1346,y:904,t:1526922917316};\\\", \\\"{x:1346,y:902,t:1526922917333};\\\", \\\"{x:1346,y:896,t:1526922917350};\\\", \\\"{x:1346,y:895,t:1526922917366};\\\", \\\"{x:1346,y:892,t:1526922917383};\\\", \\\"{x:1347,y:887,t:1526922917400};\\\", \\\"{x:1347,y:884,t:1526922917416};\\\", \\\"{x:1348,y:877,t:1526922917433};\\\", \\\"{x:1348,y:873,t:1526922917450};\\\", \\\"{x:1348,y:867,t:1526922917466};\\\", \\\"{x:1348,y:862,t:1526922917484};\\\", \\\"{x:1348,y:848,t:1526922917500};\\\", \\\"{x:1348,y:835,t:1526922917517};\\\", \\\"{x:1348,y:827,t:1526922917533};\\\", \\\"{x:1348,y:812,t:1526922917550};\\\", \\\"{x:1348,y:799,t:1526922917566};\\\", \\\"{x:1347,y:785,t:1526922917583};\\\", \\\"{x:1347,y:771,t:1526922917601};\\\", \\\"{x:1348,y:756,t:1526922917616};\\\", \\\"{x:1352,y:742,t:1526922917634};\\\", \\\"{x:1353,y:734,t:1526922917650};\\\", \\\"{x:1354,y:731,t:1526922917666};\\\", \\\"{x:1354,y:729,t:1526922917684};\\\", \\\"{x:1351,y:729,t:1526922917740};\\\", \\\"{x:1349,y:730,t:1526922917750};\\\", \\\"{x:1337,y:734,t:1526922917767};\\\", \\\"{x:1322,y:743,t:1526922917783};\\\", \\\"{x:1298,y:747,t:1526922917800};\\\", \\\"{x:1276,y:752,t:1526922917816};\\\", \\\"{x:1256,y:756,t:1526922917833};\\\", \\\"{x:1235,y:756,t:1526922917850};\\\", \\\"{x:1215,y:757,t:1526922917867};\\\", \\\"{x:1188,y:757,t:1526922917883};\\\", \\\"{x:1140,y:757,t:1526922917900};\\\", \\\"{x:1107,y:751,t:1526922917916};\\\", \\\"{x:1079,y:745,t:1526922917933};\\\", \\\"{x:1056,y:738,t:1526922917950};\\\", \\\"{x:1022,y:731,t:1526922917966};\\\", \\\"{x:995,y:724,t:1526922917983};\\\", \\\"{x:963,y:718,t:1526922918000};\\\", \\\"{x:937,y:713,t:1526922918016};\\\", \\\"{x:916,y:711,t:1526922918033};\\\", \\\"{x:894,y:708,t:1526922918050};\\\", \\\"{x:870,y:706,t:1526922918066};\\\", \\\"{x:841,y:702,t:1526922918083};\\\", \\\"{x:805,y:695,t:1526922918100};\\\", \\\"{x:790,y:691,t:1526922918116};\\\", \\\"{x:767,y:685,t:1526922918133};\\\", \\\"{x:745,y:678,t:1526922918150};\\\", \\\"{x:725,y:674,t:1526922918167};\\\", \\\"{x:707,y:669,t:1526922918183};\\\", \\\"{x:690,y:664,t:1526922918200};\\\", \\\"{x:669,y:661,t:1526922918217};\\\", \\\"{x:647,y:657,t:1526922918233};\\\", \\\"{x:627,y:655,t:1526922918250};\\\", \\\"{x:609,y:650,t:1526922918267};\\\", \\\"{x:596,y:645,t:1526922918283};\\\", \\\"{x:573,y:637,t:1526922918300};\\\", \\\"{x:559,y:630,t:1526922918317};\\\", \\\"{x:556,y:627,t:1526922918333};\\\", \\\"{x:552,y:624,t:1526922918350};\\\", \\\"{x:547,y:618,t:1526922918369};\\\", \\\"{x:539,y:609,t:1526922918386};\\\", \\\"{x:529,y:603,t:1526922918402};\\\", \\\"{x:513,y:595,t:1526922918420};\\\", \\\"{x:485,y:583,t:1526922918435};\\\", \\\"{x:463,y:572,t:1526922918452};\\\", \\\"{x:447,y:570,t:1526922918469};\\\", \\\"{x:427,y:565,t:1526922918486};\\\", \\\"{x:408,y:557,t:1526922918502};\\\", \\\"{x:394,y:552,t:1526922918519};\\\", \\\"{x:381,y:549,t:1526922918535};\\\", \\\"{x:373,y:545,t:1526922918551};\\\", \\\"{x:371,y:545,t:1526922918570};\\\", \\\"{x:370,y:544,t:1526922918683};\\\", \\\"{x:370,y:543,t:1526922918691};\\\", \\\"{x:371,y:542,t:1526922918715};\\\", \\\"{x:372,y:542,t:1526922918732};\\\", \\\"{x:374,y:540,t:1526922918739};\\\", \\\"{x:378,y:538,t:1526922918752};\\\", \\\"{x:382,y:534,t:1526922918769};\\\", \\\"{x:410,y:529,t:1526922918786};\\\", \\\"{x:433,y:524,t:1526922918803};\\\", \\\"{x:474,y:518,t:1526922918819};\\\", \\\"{x:494,y:518,t:1526922918836};\\\", \\\"{x:523,y:518,t:1526922918853};\\\", \\\"{x:539,y:518,t:1526922918869};\\\", \\\"{x:554,y:518,t:1526922918886};\\\", \\\"{x:564,y:518,t:1526922918903};\\\", \\\"{x:569,y:518,t:1526922918919};\\\", \\\"{x:570,y:518,t:1526922918936};\\\", \\\"{x:570,y:517,t:1526922918954};\\\", \\\"{x:571,y:517,t:1526922918972};\\\", \\\"{x:573,y:516,t:1526922918987};\\\", \\\"{x:577,y:515,t:1526922919003};\\\", \\\"{x:584,y:514,t:1526922919019};\\\", \\\"{x:587,y:514,t:1526922919036};\\\", \\\"{x:589,y:512,t:1526922919053};\\\", \\\"{x:594,y:512,t:1526922919069};\\\", \\\"{x:599,y:511,t:1526922919086};\\\", \\\"{x:607,y:511,t:1526922919104};\\\", \\\"{x:613,y:510,t:1526922919119};\\\", \\\"{x:623,y:510,t:1526922919136};\\\", \\\"{x:641,y:510,t:1526922919153};\\\", \\\"{x:665,y:512,t:1526922919170};\\\", \\\"{x:686,y:512,t:1526922919186};\\\", \\\"{x:707,y:513,t:1526922919203};\\\", \\\"{x:741,y:514,t:1526922919220};\\\", \\\"{x:757,y:514,t:1526922919236};\\\", \\\"{x:766,y:518,t:1526922919253};\\\", \\\"{x:775,y:518,t:1526922919270};\\\", \\\"{x:780,y:518,t:1526922919286};\\\", \\\"{x:781,y:518,t:1526922919316};\\\", \\\"{x:784,y:518,t:1526922919323};\\\", \\\"{x:786,y:518,t:1526922919336};\\\", \\\"{x:793,y:518,t:1526922919354};\\\", \\\"{x:800,y:518,t:1526922919370};\\\", \\\"{x:807,y:518,t:1526922919386};\\\", \\\"{x:812,y:518,t:1526922919403};\\\", \\\"{x:813,y:518,t:1526922919468};\\\", \\\"{x:815,y:518,t:1526922919475};\\\", \\\"{x:816,y:518,t:1526922919499};\\\", \\\"{x:818,y:518,t:1526922919507};\\\", \\\"{x:821,y:518,t:1526922919524};\\\", \\\"{x:822,y:518,t:1526922919536};\\\", \\\"{x:823,y:517,t:1526922919553};\\\", \\\"{x:824,y:517,t:1526922919570};\\\", \\\"{x:825,y:517,t:1526922919586};\\\", \\\"{x:827,y:516,t:1526922919603};\\\", \\\"{x:827,y:515,t:1526922919620};\\\", \\\"{x:829,y:514,t:1526922919637};\\\", \\\"{x:831,y:513,t:1526922919653};\\\", \\\"{x:834,y:512,t:1526922919670};\\\", \\\"{x:835,y:511,t:1526922919687};\\\", \\\"{x:836,y:511,t:1526922919703};\\\", \\\"{x:836,y:510,t:1526922919731};\\\", \\\"{x:836,y:513,t:1526922919955};\\\", \\\"{x:825,y:516,t:1526922919971};\\\", \\\"{x:768,y:526,t:1526922919988};\\\", \\\"{x:709,y:527,t:1526922920003};\\\", \\\"{x:636,y:531,t:1526922920021};\\\", \\\"{x:583,y:531,t:1526922920038};\\\", \\\"{x:547,y:535,t:1526922920053};\\\", \\\"{x:520,y:535,t:1526922920070};\\\", \\\"{x:496,y:535,t:1526922920087};\\\", \\\"{x:478,y:535,t:1526922920104};\\\", \\\"{x:465,y:535,t:1526922920120};\\\", \\\"{x:461,y:535,t:1526922920137};\\\", \\\"{x:450,y:537,t:1526922920154};\\\", \\\"{x:441,y:539,t:1526922920170};\\\", \\\"{x:422,y:542,t:1526922920187};\\\", \\\"{x:421,y:542,t:1526922920204};\\\", \\\"{x:416,y:543,t:1526922920221};\\\", \\\"{x:409,y:547,t:1526922920237};\\\", \\\"{x:401,y:548,t:1526922920253};\\\", \\\"{x:383,y:551,t:1526922920270};\\\", \\\"{x:372,y:551,t:1526922920288};\\\", \\\"{x:358,y:551,t:1526922920303};\\\", \\\"{x:343,y:551,t:1526922920320};\\\", \\\"{x:322,y:551,t:1526922920362};\\\", \\\"{x:316,y:551,t:1526922920370};\\\", \\\"{x:301,y:547,t:1526922920387};\\\", \\\"{x:274,y:544,t:1526922920403};\\\", \\\"{x:258,y:540,t:1526922920421};\\\", \\\"{x:237,y:536,t:1526922920437};\\\", \\\"{x:219,y:533,t:1526922920454};\\\", \\\"{x:215,y:533,t:1526922920470};\\\", \\\"{x:214,y:532,t:1526922920487};\\\", \\\"{x:213,y:532,t:1526922920571};\\\", \\\"{x:210,y:532,t:1526922920587};\\\", \\\"{x:209,y:532,t:1526922920604};\\\", \\\"{x:207,y:532,t:1526922920621};\\\", \\\"{x:206,y:532,t:1526922920637};\\\", \\\"{x:203,y:533,t:1526922920654};\\\", \\\"{x:196,y:536,t:1526922920671};\\\", \\\"{x:190,y:539,t:1526922920687};\\\", \\\"{x:181,y:541,t:1526922920704};\\\", \\\"{x:170,y:544,t:1526922920721};\\\", \\\"{x:164,y:544,t:1526922920737};\\\", \\\"{x:161,y:545,t:1526922920754};\\\", \\\"{x:160,y:546,t:1526922921339};\\\", \\\"{x:161,y:549,t:1526922921355};\\\", \\\"{x:161,y:552,t:1526922921371};\\\", \\\"{x:162,y:557,t:1526922921389};\\\", \\\"{x:167,y:565,t:1526922921406};\\\", \\\"{x:170,y:569,t:1526922921421};\\\", \\\"{x:176,y:575,t:1526922921438};\\\", \\\"{x:183,y:581,t:1526922921455};\\\", \\\"{x:194,y:592,t:1526922921471};\\\", \\\"{x:208,y:604,t:1526922921489};\\\", \\\"{x:221,y:619,t:1526922921504};\\\", \\\"{x:234,y:631,t:1526922921521};\\\", \\\"{x:259,y:649,t:1526922921539};\\\", \\\"{x:280,y:663,t:1526922921555};\\\", \\\"{x:313,y:685,t:1526922921572};\\\", \\\"{x:331,y:693,t:1526922921588};\\\", \\\"{x:356,y:703,t:1526922921605};\\\", \\\"{x:389,y:716,t:1526922921621};\\\", \\\"{x:412,y:723,t:1526922921638};\\\", \\\"{x:428,y:729,t:1526922921656};\\\", \\\"{x:432,y:732,t:1526922921671};\\\", \\\"{x:434,y:732,t:1526922921688};\\\", \\\"{x:435,y:732,t:1526922921860};\\\", \\\"{x:438,y:732,t:1526922921871};\\\", \\\"{x:448,y:732,t:1526922921889};\\\", \\\"{x:463,y:732,t:1526922921904};\\\", \\\"{x:472,y:732,t:1526922921921};\\\", \\\"{x:487,y:737,t:1526922921937};\\\", \\\"{x:503,y:741,t:1526922921954};\\\", \\\"{x:513,y:743,t:1526922921971};\\\", \\\"{x:514,y:743,t:1526922921987};\\\", \\\"{x:514,y:744,t:1526922922004};\\\", \\\"{x:515,y:744,t:1526922922076};\\\", \\\"{x:516,y:744,t:1526922922268};\\\", \\\"{x:518,y:744,t:1526922922275};\\\", \\\"{x:519,y:744,t:1526922922287};\\\", \\\"{x:521,y:742,t:1526922922304};\\\", \\\"{x:522,y:741,t:1526922922320};\\\", \\\"{x:523,y:740,t:1526922922340};\\\", \\\"{x:524,y:740,t:1526922924124};\\\", \\\"{x:525,y:739,t:1526922924277};\\\" ] }, { \\\"rt\\\": 15449, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 372503, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:738,t:1526922926916};\\\", \\\"{x:523,y:738,t:1526922927091};\\\", \\\"{x:522,y:738,t:1526922927131};\\\", \\\"{x:521,y:738,t:1526922927147};\\\", \\\"{x:520,y:738,t:1526922927315};\\\", \\\"{x:519,y:738,t:1526922927329};\\\", \\\"{x:518,y:738,t:1526922927345};\\\", \\\"{x:517,y:738,t:1526922927404};\\\", \\\"{x:515,y:738,t:1526922927427};\\\", \\\"{x:514,y:738,t:1526922927956};\\\", \\\"{x:510,y:735,t:1526922933291};\\\", \\\"{x:510,y:733,t:1526922933299};\\\", \\\"{x:505,y:728,t:1526922933312};\\\", \\\"{x:501,y:721,t:1526922933329};\\\", \\\"{x:495,y:712,t:1526922933345};\\\", \\\"{x:488,y:704,t:1526922933361};\\\", \\\"{x:483,y:695,t:1526922933379};\\\", \\\"{x:479,y:689,t:1526922933395};\\\", \\\"{x:476,y:686,t:1526922933413};\\\", \\\"{x:475,y:683,t:1526922933430};\\\", \\\"{x:475,y:675,t:1526922933445};\\\", \\\"{x:474,y:669,t:1526922933463};\\\", \\\"{x:472,y:666,t:1526922933479};\\\", \\\"{x:467,y:655,t:1526922933497};\\\", \\\"{x:461,y:645,t:1526922933514};\\\", \\\"{x:453,y:638,t:1526922933531};\\\", \\\"{x:447,y:630,t:1526922933548};\\\", \\\"{x:443,y:623,t:1526922933564};\\\", \\\"{x:438,y:614,t:1526922933581};\\\", \\\"{x:432,y:607,t:1526922933598};\\\", \\\"{x:427,y:602,t:1526922933615};\\\", \\\"{x:424,y:598,t:1526922933632};\\\", \\\"{x:421,y:592,t:1526922933648};\\\", \\\"{x:417,y:587,t:1526922933665};\\\", \\\"{x:415,y:584,t:1526922933681};\\\", \\\"{x:413,y:584,t:1526922933723};\\\", \\\"{x:413,y:583,t:1526922933787};\\\", \\\"{x:413,y:582,t:1526922933803};\\\", \\\"{x:412,y:581,t:1526922934395};\\\", \\\"{x:408,y:578,t:1526922934403};\\\", \\\"{x:407,y:577,t:1526922934416};\\\", \\\"{x:403,y:573,t:1526922934432};\\\", \\\"{x:400,y:570,t:1526922934448};\\\", \\\"{x:395,y:569,t:1526922934465};\\\", \\\"{x:393,y:567,t:1526922934482};\\\", \\\"{x:391,y:566,t:1526922934498};\\\", \\\"{x:390,y:566,t:1526922934515};\\\", \\\"{x:387,y:565,t:1526922934532};\\\", \\\"{x:384,y:565,t:1526922934548};\\\", \\\"{x:381,y:563,t:1526922934566};\\\", \\\"{x:376,y:562,t:1526922934583};\\\", \\\"{x:368,y:558,t:1526922934599};\\\", \\\"{x:363,y:558,t:1526922934616};\\\", \\\"{x:358,y:558,t:1526922934632};\\\", \\\"{x:350,y:558,t:1526922934649};\\\", \\\"{x:345,y:558,t:1526922934666};\\\", \\\"{x:337,y:557,t:1526922934682};\\\", \\\"{x:332,y:555,t:1526922934699};\\\", \\\"{x:324,y:555,t:1526922934716};\\\", \\\"{x:311,y:555,t:1526922934732};\\\", \\\"{x:301,y:555,t:1526922934749};\\\", \\\"{x:285,y:554,t:1526922934766};\\\", \\\"{x:273,y:552,t:1526922934783};\\\", \\\"{x:262,y:550,t:1526922934799};\\\", \\\"{x:252,y:549,t:1526922934816};\\\", \\\"{x:247,y:548,t:1526922934833};\\\", \\\"{x:240,y:547,t:1526922934849};\\\", \\\"{x:237,y:546,t:1526922934865};\\\", \\\"{x:231,y:546,t:1526922934883};\\\", \\\"{x:223,y:546,t:1526922934898};\\\", \\\"{x:211,y:546,t:1526922934916};\\\", \\\"{x:198,y:544,t:1526922934932};\\\", \\\"{x:187,y:544,t:1526922934949};\\\", \\\"{x:179,y:544,t:1526922934965};\\\", \\\"{x:173,y:544,t:1526922934982};\\\", \\\"{x:169,y:544,t:1526922934998};\\\", \\\"{x:166,y:544,t:1526922935015};\\\", \\\"{x:165,y:542,t:1526922935033};\\\", \\\"{x:164,y:542,t:1526922935067};\\\", \\\"{x:163,y:542,t:1526922935082};\\\", \\\"{x:161,y:542,t:1526922935107};\\\", \\\"{x:160,y:542,t:1526922935139};\\\", \\\"{x:159,y:542,t:1526922936091};\\\", \\\"{x:160,y:542,t:1526922936100};\\\", \\\"{x:168,y:546,t:1526922936117};\\\", \\\"{x:174,y:550,t:1526922936134};\\\", \\\"{x:185,y:557,t:1526922936150};\\\", \\\"{x:199,y:566,t:1526922936167};\\\", \\\"{x:216,y:572,t:1526922936183};\\\", \\\"{x:236,y:581,t:1526922936199};\\\", \\\"{x:255,y:592,t:1526922936217};\\\", \\\"{x:284,y:600,t:1526922936234};\\\", \\\"{x:300,y:610,t:1526922936251};\\\", \\\"{x:321,y:617,t:1526922936266};\\\", \\\"{x:351,y:631,t:1526922936283};\\\", \\\"{x:375,y:640,t:1526922936300};\\\", \\\"{x:397,y:650,t:1526922936317};\\\", \\\"{x:417,y:659,t:1526922936334};\\\", \\\"{x:439,y:666,t:1526922936350};\\\", \\\"{x:461,y:673,t:1526922936368};\\\", \\\"{x:480,y:684,t:1526922936384};\\\", \\\"{x:496,y:692,t:1526922936400};\\\", \\\"{x:525,y:707,t:1526922936417};\\\", \\\"{x:544,y:717,t:1526922936434};\\\", \\\"{x:573,y:727,t:1526922936450};\\\", \\\"{x:596,y:736,t:1526922936466};\\\", \\\"{x:631,y:752,t:1526922936483};\\\", \\\"{x:653,y:763,t:1526922936500};\\\", \\\"{x:669,y:768,t:1526922936517};\\\", \\\"{x:694,y:780,t:1526922936533};\\\", \\\"{x:722,y:793,t:1526922936550};\\\", \\\"{x:741,y:803,t:1526922936567};\\\", \\\"{x:759,y:814,t:1526922936584};\\\", \\\"{x:780,y:823,t:1526922936599};\\\", \\\"{x:799,y:833,t:1526922936617};\\\", \\\"{x:820,y:843,t:1526922936634};\\\", \\\"{x:844,y:854,t:1526922936651};\\\", \\\"{x:860,y:861,t:1526922936667};\\\", \\\"{x:884,y:874,t:1526922936683};\\\", \\\"{x:900,y:880,t:1526922936701};\\\", \\\"{x:916,y:887,t:1526922936717};\\\", \\\"{x:929,y:892,t:1526922936734};\\\", \\\"{x:947,y:897,t:1526922936751};\\\", \\\"{x:967,y:903,t:1526922936767};\\\", \\\"{x:985,y:906,t:1526922936784};\\\", \\\"{x:1007,y:908,t:1526922936801};\\\", \\\"{x:1032,y:913,t:1526922936817};\\\", \\\"{x:1055,y:915,t:1526922936834};\\\", \\\"{x:1077,y:920,t:1526922936852};\\\", \\\"{x:1100,y:924,t:1526922936867};\\\", \\\"{x:1128,y:926,t:1526922936884};\\\", \\\"{x:1151,y:929,t:1526922936902};\\\", \\\"{x:1173,y:931,t:1526922936917};\\\", \\\"{x:1193,y:935,t:1526922936935};\\\", \\\"{x:1214,y:935,t:1526922936951};\\\", \\\"{x:1230,y:935,t:1526922936968};\\\", \\\"{x:1243,y:934,t:1526922936984};\\\", \\\"{x:1252,y:933,t:1526922937001};\\\", \\\"{x:1254,y:932,t:1526922937017};\\\", \\\"{x:1256,y:932,t:1526922937108};\\\", \\\"{x:1257,y:932,t:1526922937117};\\\", \\\"{x:1261,y:932,t:1526922937135};\\\", \\\"{x:1269,y:936,t:1526922937151};\\\", \\\"{x:1275,y:936,t:1526922937167};\\\", \\\"{x:1282,y:939,t:1526922937185};\\\", \\\"{x:1297,y:943,t:1526922937201};\\\", \\\"{x:1309,y:945,t:1526922937218};\\\", \\\"{x:1319,y:947,t:1526922937234};\\\", \\\"{x:1323,y:948,t:1526922937251};\\\", \\\"{x:1324,y:948,t:1526922937267};\\\", \\\"{x:1329,y:951,t:1526922937284};\\\", \\\"{x:1332,y:951,t:1526922937301};\\\", \\\"{x:1333,y:952,t:1526922937317};\\\", \\\"{x:1334,y:952,t:1526922937334};\\\", \\\"{x:1336,y:953,t:1526922937350};\\\", \\\"{x:1338,y:955,t:1526922937367};\\\", \\\"{x:1339,y:955,t:1526922937384};\\\", \\\"{x:1341,y:956,t:1526922937400};\\\", \\\"{x:1342,y:956,t:1526922937417};\\\", \\\"{x:1343,y:957,t:1526922937434};\\\", \\\"{x:1346,y:961,t:1526922937450};\\\", \\\"{x:1347,y:961,t:1526922937467};\\\", \\\"{x:1348,y:963,t:1526922937484};\\\", \\\"{x:1349,y:963,t:1526922937739};\\\", \\\"{x:1349,y:961,t:1526922937751};\\\", \\\"{x:1349,y:958,t:1526922937768};\\\", \\\"{x:1348,y:956,t:1526922937784};\\\", \\\"{x:1347,y:955,t:1526922937801};\\\", \\\"{x:1345,y:952,t:1526922937818};\\\", \\\"{x:1344,y:949,t:1526922937833};\\\", \\\"{x:1341,y:944,t:1526922937851};\\\", \\\"{x:1339,y:941,t:1526922937866};\\\", \\\"{x:1337,y:936,t:1526922937884};\\\", \\\"{x:1335,y:932,t:1526922937900};\\\", \\\"{x:1333,y:927,t:1526922937918};\\\", \\\"{x:1331,y:924,t:1526922937934};\\\", \\\"{x:1329,y:922,t:1526922937951};\\\", \\\"{x:1329,y:918,t:1526922937968};\\\", \\\"{x:1327,y:910,t:1526922937984};\\\", \\\"{x:1326,y:906,t:1526922938001};\\\", \\\"{x:1323,y:902,t:1526922938017};\\\", \\\"{x:1323,y:896,t:1526922938034};\\\", \\\"{x:1322,y:891,t:1526922938051};\\\", \\\"{x:1320,y:886,t:1526922938067};\\\", \\\"{x:1320,y:882,t:1526922938084};\\\", \\\"{x:1320,y:880,t:1526922938101};\\\", \\\"{x:1320,y:877,t:1526922938117};\\\", \\\"{x:1320,y:874,t:1526922938134};\\\", \\\"{x:1320,y:872,t:1526922938150};\\\", \\\"{x:1320,y:869,t:1526922938168};\\\", \\\"{x:1320,y:865,t:1526922938184};\\\", \\\"{x:1321,y:861,t:1526922938201};\\\", \\\"{x:1323,y:857,t:1526922938217};\\\", \\\"{x:1325,y:854,t:1526922938234};\\\", \\\"{x:1327,y:850,t:1526922938251};\\\", \\\"{x:1330,y:848,t:1526922938267};\\\", \\\"{x:1330,y:846,t:1526922938283};\\\", \\\"{x:1333,y:842,t:1526922938300};\\\", \\\"{x:1335,y:838,t:1526922938318};\\\", \\\"{x:1338,y:833,t:1526922938334};\\\", \\\"{x:1340,y:829,t:1526922938351};\\\", \\\"{x:1342,y:825,t:1526922938368};\\\", \\\"{x:1345,y:822,t:1526922938384};\\\", \\\"{x:1346,y:818,t:1526922938400};\\\", \\\"{x:1346,y:815,t:1526922938417};\\\", \\\"{x:1347,y:812,t:1526922938435};\\\", \\\"{x:1349,y:809,t:1526922938450};\\\", \\\"{x:1349,y:808,t:1526922938468};\\\", \\\"{x:1349,y:806,t:1526922938484};\\\", \\\"{x:1349,y:804,t:1526922938501};\\\", \\\"{x:1349,y:803,t:1526922938522};\\\", \\\"{x:1349,y:802,t:1526922938535};\\\", \\\"{x:1349,y:801,t:1526922938551};\\\", \\\"{x:1349,y:800,t:1526922938568};\\\", \\\"{x:1349,y:798,t:1526922938584};\\\", \\\"{x:1349,y:797,t:1526922938601};\\\", \\\"{x:1349,y:794,t:1526922938618};\\\", \\\"{x:1349,y:792,t:1526922938635};\\\", \\\"{x:1349,y:789,t:1526922938651};\\\", \\\"{x:1349,y:785,t:1526922938667};\\\", \\\"{x:1349,y:782,t:1526922938685};\\\", \\\"{x:1348,y:780,t:1526922938700};\\\", \\\"{x:1348,y:778,t:1526922938717};\\\", \\\"{x:1347,y:774,t:1526922938735};\\\", \\\"{x:1347,y:773,t:1526922938750};\\\", \\\"{x:1346,y:770,t:1526922938768};\\\", \\\"{x:1346,y:768,t:1526922938788};\\\", \\\"{x:1345,y:766,t:1526922938818};\\\", \\\"{x:1345,y:765,t:1526922938835};\\\", \\\"{x:1344,y:764,t:1526922938851};\\\", \\\"{x:1344,y:762,t:1526922938868};\\\", \\\"{x:1344,y:761,t:1526922938885};\\\", \\\"{x:1344,y:759,t:1526922938901};\\\", \\\"{x:1344,y:758,t:1526922938918};\\\", \\\"{x:1344,y:755,t:1526922938935};\\\", \\\"{x:1344,y:753,t:1526922938951};\\\", \\\"{x:1344,y:749,t:1526922938968};\\\", \\\"{x:1344,y:748,t:1526922938984};\\\", \\\"{x:1342,y:746,t:1526922939001};\\\", \\\"{x:1342,y:745,t:1526922939018};\\\", \\\"{x:1342,y:740,t:1526922939034};\\\", \\\"{x:1342,y:738,t:1526922939051};\\\", \\\"{x:1342,y:736,t:1526922939068};\\\", \\\"{x:1341,y:733,t:1526922939085};\\\", \\\"{x:1340,y:731,t:1526922939101};\\\", \\\"{x:1339,y:730,t:1526922939117};\\\", \\\"{x:1339,y:728,t:1526922939135};\\\", \\\"{x:1339,y:727,t:1526922939150};\\\", \\\"{x:1339,y:725,t:1526922939168};\\\", \\\"{x:1338,y:723,t:1526922939185};\\\", \\\"{x:1338,y:721,t:1526922939200};\\\", \\\"{x:1338,y:719,t:1526922939218};\\\", \\\"{x:1337,y:716,t:1526922939235};\\\", \\\"{x:1337,y:714,t:1526922939251};\\\", \\\"{x:1337,y:711,t:1526922939268};\\\", \\\"{x:1337,y:709,t:1526922939285};\\\", \\\"{x:1336,y:707,t:1526922939300};\\\", \\\"{x:1336,y:704,t:1526922939318};\\\", \\\"{x:1335,y:702,t:1526922939334};\\\", \\\"{x:1335,y:701,t:1526922939350};\\\", \\\"{x:1335,y:700,t:1526922939368};\\\", \\\"{x:1335,y:698,t:1526922939385};\\\", \\\"{x:1334,y:697,t:1526922939403};\\\", \\\"{x:1332,y:694,t:1526922939517};\\\", \\\"{x:1332,y:693,t:1526922939524};\\\", \\\"{x:1332,y:691,t:1526922939536};\\\", \\\"{x:1332,y:688,t:1526922939553};\\\", \\\"{x:1332,y:682,t:1526922939569};\\\", \\\"{x:1331,y:676,t:1526922939585};\\\", \\\"{x:1330,y:673,t:1526922939602};\\\", \\\"{x:1329,y:670,t:1526922939619};\\\", \\\"{x:1329,y:668,t:1526922939636};\\\", \\\"{x:1328,y:666,t:1526922939651};\\\", \\\"{x:1328,y:664,t:1526922939668};\\\", \\\"{x:1328,y:663,t:1526922939686};\\\", \\\"{x:1328,y:661,t:1526922939703};\\\", \\\"{x:1328,y:660,t:1526922939718};\\\", \\\"{x:1328,y:659,t:1526922939747};\\\", \\\"{x:1328,y:658,t:1526922939756};\\\", \\\"{x:1328,y:657,t:1526922939771};\\\", \\\"{x:1328,y:656,t:1526922939796};\\\", \\\"{x:1328,y:655,t:1526922939812};\\\", \\\"{x:1327,y:654,t:1526922939820};\\\", \\\"{x:1327,y:653,t:1526922939869};\\\", \\\"{x:1326,y:653,t:1526922939892};\\\", \\\"{x:1325,y:654,t:1526922940021};\\\", \\\"{x:1321,y:660,t:1526922940035};\\\", \\\"{x:1317,y:666,t:1526922940051};\\\", \\\"{x:1311,y:675,t:1526922940068};\\\", \\\"{x:1302,y:688,t:1526922940085};\\\", \\\"{x:1299,y:695,t:1526922940101};\\\", \\\"{x:1292,y:704,t:1526922940118};\\\", \\\"{x:1285,y:714,t:1526922940135};\\\", \\\"{x:1277,y:724,t:1526922940152};\\\", \\\"{x:1267,y:736,t:1526922940168};\\\", \\\"{x:1254,y:752,t:1526922940185};\\\", \\\"{x:1235,y:768,t:1526922940202};\\\", \\\"{x:1217,y:782,t:1526922940218};\\\", \\\"{x:1185,y:798,t:1526922940235};\\\", \\\"{x:1165,y:807,t:1526922940251};\\\", \\\"{x:1139,y:814,t:1526922940268};\\\", \\\"{x:1115,y:822,t:1526922940285};\\\", \\\"{x:1085,y:826,t:1526922940302};\\\", \\\"{x:1061,y:831,t:1526922940318};\\\", \\\"{x:1047,y:835,t:1526922940335};\\\", \\\"{x:1026,y:835,t:1526922940352};\\\", \\\"{x:1005,y:835,t:1526922940367};\\\", \\\"{x:988,y:835,t:1526922940385};\\\", \\\"{x:969,y:835,t:1526922940402};\\\", \\\"{x:955,y:835,t:1526922940419};\\\", \\\"{x:941,y:831,t:1526922940434};\\\", \\\"{x:930,y:830,t:1526922940452};\\\", \\\"{x:913,y:826,t:1526922940469};\\\", \\\"{x:893,y:823,t:1526922940485};\\\", \\\"{x:872,y:820,t:1526922940501};\\\", \\\"{x:847,y:815,t:1526922940519};\\\", \\\"{x:826,y:813,t:1526922940535};\\\", \\\"{x:802,y:810,t:1526922940552};\\\", \\\"{x:776,y:806,t:1526922940569};\\\", \\\"{x:755,y:802,t:1526922940585};\\\", \\\"{x:735,y:798,t:1526922940602};\\\", \\\"{x:710,y:792,t:1526922940619};\\\", \\\"{x:693,y:790,t:1526922940635};\\\", \\\"{x:680,y:788,t:1526922940652};\\\", \\\"{x:673,y:787,t:1526922940669};\\\", \\\"{x:661,y:786,t:1526922940685};\\\", \\\"{x:648,y:782,t:1526922940702};\\\", \\\"{x:633,y:781,t:1526922940719};\\\", \\\"{x:620,y:776,t:1526922940735};\\\", \\\"{x:604,y:772,t:1526922940753};\\\", \\\"{x:591,y:768,t:1526922940769};\\\", \\\"{x:577,y:763,t:1526922940785};\\\", \\\"{x:566,y:760,t:1526922940803};\\\", \\\"{x:554,y:757,t:1526922940820};\\\", \\\"{x:549,y:754,t:1526922940837};\\\", \\\"{x:545,y:753,t:1526922940852};\\\", \\\"{x:541,y:751,t:1526922940868};\\\", \\\"{x:539,y:750,t:1526922940887};\\\", \\\"{x:537,y:749,t:1526922940903};\\\", \\\"{x:535,y:747,t:1526922940920};\\\", \\\"{x:534,y:746,t:1526922940936};\\\", \\\"{x:532,y:746,t:1526922940954};\\\", \\\"{x:528,y:746,t:1526922940971};\\\", \\\"{x:526,y:744,t:1526922940987};\\\", \\\"{x:523,y:744,t:1526922941003};\\\", \\\"{x:521,y:743,t:1526922941021};\\\" ] }, { \\\"rt\\\": 23933, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 397753, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:743,t:1526922942947};\\\", \\\"{x:518,y:744,t:1526922944555};\\\", \\\"{x:516,y:745,t:1526922944572};\\\", \\\"{x:515,y:745,t:1526922944938};\\\", \\\"{x:515,y:747,t:1526922945027};\\\", \\\"{x:515,y:748,t:1526922945067};\\\", \\\"{x:515,y:749,t:1526922945107};\\\", \\\"{x:514,y:750,t:1526922945122};\\\", \\\"{x:514,y:752,t:1526922945564};\\\", \\\"{x:514,y:753,t:1526922945572};\\\", \\\"{x:525,y:758,t:1526922945589};\\\", \\\"{x:540,y:761,t:1526922945606};\\\", \\\"{x:558,y:765,t:1526922945622};\\\", \\\"{x:581,y:766,t:1526922945640};\\\", \\\"{x:610,y:768,t:1526922945657};\\\", \\\"{x:635,y:770,t:1526922945674};\\\", \\\"{x:666,y:776,t:1526922945690};\\\", \\\"{x:710,y:783,t:1526922945707};\\\", \\\"{x:751,y:787,t:1526922945724};\\\", \\\"{x:799,y:789,t:1526922945740};\\\", \\\"{x:839,y:790,t:1526922945757};\\\", \\\"{x:876,y:795,t:1526922945774};\\\", \\\"{x:909,y:801,t:1526922945789};\\\", \\\"{x:937,y:803,t:1526922945807};\\\", \\\"{x:966,y:807,t:1526922945824};\\\", \\\"{x:990,y:813,t:1526922945840};\\\", \\\"{x:1014,y:816,t:1526922945857};\\\", \\\"{x:1026,y:819,t:1526922945874};\\\", \\\"{x:1039,y:820,t:1526922945890};\\\", \\\"{x:1064,y:823,t:1526922945907};\\\", \\\"{x:1078,y:824,t:1526922945924};\\\", \\\"{x:1094,y:829,t:1526922945940};\\\", \\\"{x:1110,y:832,t:1526922945957};\\\", \\\"{x:1128,y:838,t:1526922945973};\\\", \\\"{x:1147,y:841,t:1526922945990};\\\", \\\"{x:1163,y:844,t:1526922946007};\\\", \\\"{x:1180,y:848,t:1526922946024};\\\", \\\"{x:1191,y:849,t:1526922946040};\\\", \\\"{x:1205,y:850,t:1526922946057};\\\", \\\"{x:1214,y:851,t:1526922946074};\\\", \\\"{x:1227,y:854,t:1526922946091};\\\", \\\"{x:1241,y:856,t:1526922946107};\\\", \\\"{x:1255,y:861,t:1526922946124};\\\", \\\"{x:1264,y:864,t:1526922946141};\\\", \\\"{x:1282,y:868,t:1526922946157};\\\", \\\"{x:1300,y:874,t:1526922946174};\\\", \\\"{x:1315,y:879,t:1526922946191};\\\", \\\"{x:1325,y:884,t:1526922946207};\\\", \\\"{x:1339,y:885,t:1526922946224};\\\", \\\"{x:1355,y:889,t:1526922946241};\\\", \\\"{x:1363,y:890,t:1526922946257};\\\", \\\"{x:1376,y:893,t:1526922946274};\\\", \\\"{x:1395,y:895,t:1526922946290};\\\", \\\"{x:1408,y:896,t:1526922946307};\\\", \\\"{x:1416,y:899,t:1526922946324};\\\", \\\"{x:1424,y:899,t:1526922946341};\\\", \\\"{x:1437,y:902,t:1526922946357};\\\", \\\"{x:1448,y:904,t:1526922946374};\\\", \\\"{x:1462,y:907,t:1526922946391};\\\", \\\"{x:1473,y:910,t:1526922946407};\\\", \\\"{x:1488,y:914,t:1526922946424};\\\", \\\"{x:1503,y:915,t:1526922946441};\\\", \\\"{x:1518,y:918,t:1526922946457};\\\", \\\"{x:1529,y:919,t:1526922946474};\\\", \\\"{x:1551,y:924,t:1526922946491};\\\", \\\"{x:1562,y:925,t:1526922946507};\\\", \\\"{x:1574,y:926,t:1526922946524};\\\", \\\"{x:1581,y:927,t:1526922946541};\\\", \\\"{x:1586,y:928,t:1526922946557};\\\", \\\"{x:1588,y:928,t:1526922946574};\\\", \\\"{x:1592,y:929,t:1526922946591};\\\", \\\"{x:1593,y:930,t:1526922946611};\\\", \\\"{x:1594,y:931,t:1526922946624};\\\", \\\"{x:1596,y:932,t:1526922946641};\\\", \\\"{x:1598,y:932,t:1526922946657};\\\", \\\"{x:1598,y:933,t:1526922946674};\\\", \\\"{x:1601,y:935,t:1526922946691};\\\", \\\"{x:1602,y:936,t:1526922946715};\\\", \\\"{x:1602,y:937,t:1526922946738};\\\", \\\"{x:1602,y:938,t:1526922946755};\\\", \\\"{x:1602,y:939,t:1526922946763};\\\", \\\"{x:1604,y:941,t:1526922946775};\\\", \\\"{x:1604,y:945,t:1526922946791};\\\", \\\"{x:1604,y:949,t:1526922946808};\\\", \\\"{x:1604,y:952,t:1526922946824};\\\", \\\"{x:1601,y:956,t:1526922946841};\\\", \\\"{x:1596,y:959,t:1526922946859};\\\", \\\"{x:1594,y:960,t:1526922946875};\\\", \\\"{x:1592,y:962,t:1526922946891};\\\", \\\"{x:1591,y:963,t:1526922946908};\\\", \\\"{x:1590,y:964,t:1526922946924};\\\", \\\"{x:1586,y:965,t:1526922946941};\\\", \\\"{x:1584,y:966,t:1526922946958};\\\", \\\"{x:1576,y:966,t:1526922946973};\\\", \\\"{x:1568,y:966,t:1526922946991};\\\", \\\"{x:1558,y:966,t:1526922947008};\\\", \\\"{x:1543,y:966,t:1526922947024};\\\", \\\"{x:1530,y:966,t:1526922947041};\\\", \\\"{x:1504,y:966,t:1526922947059};\\\", \\\"{x:1495,y:966,t:1526922947074};\\\", \\\"{x:1476,y:965,t:1526922947091};\\\", \\\"{x:1456,y:961,t:1526922947108};\\\", \\\"{x:1440,y:958,t:1526922947124};\\\", \\\"{x:1426,y:954,t:1526922947141};\\\", \\\"{x:1410,y:952,t:1526922947158};\\\", \\\"{x:1391,y:948,t:1526922947174};\\\", \\\"{x:1371,y:945,t:1526922947191};\\\", \\\"{x:1351,y:942,t:1526922947209};\\\", \\\"{x:1333,y:936,t:1526922947224};\\\", \\\"{x:1312,y:932,t:1526922947241};\\\", \\\"{x:1278,y:925,t:1526922947259};\\\", \\\"{x:1267,y:921,t:1526922947274};\\\", \\\"{x:1255,y:920,t:1526922947291};\\\", \\\"{x:1247,y:918,t:1526922947308};\\\", \\\"{x:1242,y:916,t:1526922947324};\\\", \\\"{x:1239,y:916,t:1526922947342};\\\", \\\"{x:1238,y:916,t:1526922947358};\\\", \\\"{x:1237,y:915,t:1526922947379};\\\", \\\"{x:1236,y:915,t:1526922947391};\\\", \\\"{x:1234,y:914,t:1526922947408};\\\", \\\"{x:1233,y:914,t:1526922947451};\\\", \\\"{x:1232,y:913,t:1526922947564};\\\", \\\"{x:1233,y:911,t:1526922947588};\\\", \\\"{x:1235,y:911,t:1526922947596};\\\", \\\"{x:1236,y:910,t:1526922947612};\\\", \\\"{x:1239,y:909,t:1526922947626};\\\", \\\"{x:1242,y:908,t:1526922947642};\\\", \\\"{x:1255,y:908,t:1526922947660};\\\", \\\"{x:1270,y:908,t:1526922947675};\\\", \\\"{x:1287,y:909,t:1526922947692};\\\", \\\"{x:1306,y:912,t:1526922947708};\\\", \\\"{x:1325,y:914,t:1526922947725};\\\", \\\"{x:1344,y:919,t:1526922947741};\\\", \\\"{x:1359,y:920,t:1526922947759};\\\", \\\"{x:1376,y:921,t:1526922947776};\\\", \\\"{x:1386,y:925,t:1526922947792};\\\", \\\"{x:1396,y:928,t:1526922947808};\\\", \\\"{x:1407,y:929,t:1526922947826};\\\", \\\"{x:1414,y:929,t:1526922947842};\\\", \\\"{x:1425,y:932,t:1526922947860};\\\", \\\"{x:1430,y:932,t:1526922947876};\\\", \\\"{x:1435,y:932,t:1526922947892};\\\", \\\"{x:1440,y:933,t:1526922947908};\\\", \\\"{x:1447,y:934,t:1526922947926};\\\", \\\"{x:1454,y:935,t:1526922947942};\\\", \\\"{x:1461,y:936,t:1526922947959};\\\", \\\"{x:1471,y:938,t:1526922947975};\\\", \\\"{x:1479,y:941,t:1526922947992};\\\", \\\"{x:1483,y:941,t:1526922948008};\\\", \\\"{x:1486,y:942,t:1526922948026};\\\", \\\"{x:1487,y:942,t:1526922948041};\\\", \\\"{x:1489,y:944,t:1526922948059};\\\", \\\"{x:1491,y:944,t:1526922948076};\\\", \\\"{x:1492,y:944,t:1526922948100};\\\", \\\"{x:1496,y:944,t:1526922949268};\\\", \\\"{x:1500,y:944,t:1526922949276};\\\", \\\"{x:1507,y:936,t:1526922949293};\\\", \\\"{x:1519,y:921,t:1526922949309};\\\", \\\"{x:1535,y:910,t:1526922949326};\\\", \\\"{x:1550,y:899,t:1526922949342};\\\", \\\"{x:1568,y:891,t:1526922949359};\\\", \\\"{x:1584,y:882,t:1526922949376};\\\", \\\"{x:1596,y:876,t:1526922949392};\\\", \\\"{x:1603,y:871,t:1526922949409};\\\", \\\"{x:1607,y:866,t:1526922949426};\\\", \\\"{x:1613,y:858,t:1526922949442};\\\", \\\"{x:1619,y:843,t:1526922949459};\\\", \\\"{x:1621,y:837,t:1526922949476};\\\", \\\"{x:1624,y:830,t:1526922949492};\\\", \\\"{x:1626,y:826,t:1526922949509};\\\", \\\"{x:1627,y:824,t:1526922949526};\\\", \\\"{x:1629,y:819,t:1526922949542};\\\", \\\"{x:1630,y:816,t:1526922949559};\\\", \\\"{x:1630,y:813,t:1526922949576};\\\", \\\"{x:1631,y:809,t:1526922949592};\\\", \\\"{x:1632,y:807,t:1526922949609};\\\", \\\"{x:1632,y:806,t:1526922949626};\\\", \\\"{x:1632,y:804,t:1526922949642};\\\", \\\"{x:1632,y:800,t:1526922949659};\\\", \\\"{x:1632,y:795,t:1526922949676};\\\", \\\"{x:1632,y:789,t:1526922949692};\\\", \\\"{x:1632,y:784,t:1526922949709};\\\", \\\"{x:1632,y:780,t:1526922949726};\\\", \\\"{x:1631,y:773,t:1526922949742};\\\", \\\"{x:1629,y:771,t:1526922949759};\\\", \\\"{x:1628,y:769,t:1526922949776};\\\", \\\"{x:1627,y:766,t:1526922949793};\\\", \\\"{x:1626,y:764,t:1526922949809};\\\", \\\"{x:1625,y:761,t:1526922949826};\\\", \\\"{x:1623,y:759,t:1526922949842};\\\", \\\"{x:1621,y:753,t:1526922949859};\\\", \\\"{x:1620,y:751,t:1526922949876};\\\", \\\"{x:1617,y:748,t:1526922949893};\\\", \\\"{x:1616,y:746,t:1526922949909};\\\", \\\"{x:1614,y:743,t:1526922949926};\\\", \\\"{x:1613,y:743,t:1526922949943};\\\", \\\"{x:1612,y:741,t:1526922949959};\\\", \\\"{x:1612,y:740,t:1526922949976};\\\", \\\"{x:1611,y:740,t:1526922950107};\\\", \\\"{x:1610,y:740,t:1526922950115};\\\", \\\"{x:1610,y:741,t:1526922950126};\\\", \\\"{x:1610,y:745,t:1526922950143};\\\", \\\"{x:1610,y:747,t:1526922950159};\\\", \\\"{x:1610,y:748,t:1526922950176};\\\", \\\"{x:1610,y:746,t:1526922950298};\\\", \\\"{x:1610,y:745,t:1526922950309};\\\", \\\"{x:1610,y:743,t:1526922950326};\\\", \\\"{x:1610,y:739,t:1526922950344};\\\", \\\"{x:1610,y:734,t:1526922950359};\\\", \\\"{x:1610,y:728,t:1526922950376};\\\", \\\"{x:1613,y:719,t:1526922950393};\\\", \\\"{x:1613,y:713,t:1526922950409};\\\", \\\"{x:1614,y:710,t:1526922950426};\\\", \\\"{x:1616,y:704,t:1526922950443};\\\", \\\"{x:1617,y:700,t:1526922950460};\\\", \\\"{x:1618,y:698,t:1526922950476};\\\", \\\"{x:1618,y:697,t:1526922950493};\\\", \\\"{x:1619,y:696,t:1526922950510};\\\", \\\"{x:1620,y:696,t:1526922950546};\\\", \\\"{x:1620,y:695,t:1526922950579};\\\", \\\"{x:1620,y:693,t:1526922950684};\\\", \\\"{x:1620,y:691,t:1526922950708};\\\", \\\"{x:1620,y:690,t:1526922950739};\\\", \\\"{x:1620,y:688,t:1526922950803};\\\", \\\"{x:1619,y:689,t:1526922950915};\\\", \\\"{x:1619,y:690,t:1526922950939};\\\", \\\"{x:1618,y:691,t:1526922950987};\\\", \\\"{x:1618,y:693,t:1526922954163};\\\", \\\"{x:1616,y:702,t:1526922954194};\\\", \\\"{x:1616,y:708,t:1526922954212};\\\", \\\"{x:1614,y:714,t:1526922954228};\\\", \\\"{x:1612,y:723,t:1526922954245};\\\", \\\"{x:1612,y:730,t:1526922954262};\\\", \\\"{x:1610,y:739,t:1526922954279};\\\", \\\"{x:1610,y:747,t:1526922954296};\\\", \\\"{x:1608,y:759,t:1526922954312};\\\", \\\"{x:1607,y:772,t:1526922954329};\\\", \\\"{x:1606,y:786,t:1526922954346};\\\", \\\"{x:1603,y:803,t:1526922954363};\\\", \\\"{x:1603,y:818,t:1526922954378};\\\", \\\"{x:1603,y:844,t:1526922954395};\\\", \\\"{x:1602,y:858,t:1526922954412};\\\", \\\"{x:1601,y:874,t:1526922954429};\\\", \\\"{x:1598,y:884,t:1526922954446};\\\", \\\"{x:1596,y:890,t:1526922954462};\\\", \\\"{x:1593,y:895,t:1526922954479};\\\", \\\"{x:1589,y:901,t:1526922954496};\\\", \\\"{x:1584,y:907,t:1526922954513};\\\", \\\"{x:1576,y:914,t:1526922954529};\\\", \\\"{x:1573,y:916,t:1526922954545};\\\", \\\"{x:1570,y:919,t:1526922954562};\\\", \\\"{x:1568,y:920,t:1526922954579};\\\", \\\"{x:1566,y:921,t:1526922954595};\\\", \\\"{x:1565,y:921,t:1526922954613};\\\", \\\"{x:1564,y:921,t:1526922954651};\\\", \\\"{x:1563,y:921,t:1526922954683};\\\", \\\"{x:1562,y:921,t:1526922954696};\\\", \\\"{x:1561,y:921,t:1526922954713};\\\", \\\"{x:1560,y:921,t:1526922954729};\\\", \\\"{x:1558,y:922,t:1526922954778};\\\", \\\"{x:1555,y:929,t:1526922954795};\\\", \\\"{x:1554,y:934,t:1526922954812};\\\", \\\"{x:1554,y:937,t:1526922954829};\\\", \\\"{x:1554,y:940,t:1526922954845};\\\", \\\"{x:1554,y:942,t:1526922954862};\\\", \\\"{x:1554,y:940,t:1526922954995};\\\", \\\"{x:1554,y:939,t:1526922955003};\\\", \\\"{x:1553,y:937,t:1526922955018};\\\", \\\"{x:1553,y:936,t:1526922955043};\\\", \\\"{x:1552,y:935,t:1526922955051};\\\", \\\"{x:1552,y:934,t:1526922955067};\\\", \\\"{x:1551,y:933,t:1526922955083};\\\", \\\"{x:1550,y:931,t:1526922955115};\\\", \\\"{x:1550,y:930,t:1526922955131};\\\", \\\"{x:1550,y:929,t:1526922955145};\\\", \\\"{x:1549,y:927,t:1526922955163};\\\", \\\"{x:1549,y:926,t:1526922955180};\\\", \\\"{x:1548,y:924,t:1526922955204};\\\", \\\"{x:1547,y:921,t:1526922955219};\\\", \\\"{x:1546,y:919,t:1526922955236};\\\", \\\"{x:1545,y:917,t:1526922955246};\\\", \\\"{x:1542,y:911,t:1526922955263};\\\", \\\"{x:1537,y:904,t:1526922955280};\\\", \\\"{x:1533,y:898,t:1526922955296};\\\", \\\"{x:1526,y:892,t:1526922955312};\\\", \\\"{x:1519,y:887,t:1526922955330};\\\", \\\"{x:1513,y:882,t:1526922955346};\\\", \\\"{x:1507,y:876,t:1526922955363};\\\", \\\"{x:1501,y:871,t:1526922955380};\\\", \\\"{x:1497,y:867,t:1526922955395};\\\", \\\"{x:1495,y:865,t:1526922955413};\\\", \\\"{x:1493,y:862,t:1526922955430};\\\", \\\"{x:1492,y:859,t:1526922955446};\\\", \\\"{x:1490,y:857,t:1526922955463};\\\", \\\"{x:1490,y:856,t:1526922955480};\\\", \\\"{x:1489,y:854,t:1526922955496};\\\", \\\"{x:1489,y:853,t:1526922955513};\\\", \\\"{x:1487,y:850,t:1526922955530};\\\", \\\"{x:1487,y:849,t:1526922955546};\\\", \\\"{x:1486,y:847,t:1526922955563};\\\", \\\"{x:1485,y:845,t:1526922955580};\\\", \\\"{x:1484,y:842,t:1526922955597};\\\", \\\"{x:1482,y:838,t:1526922955613};\\\", \\\"{x:1482,y:836,t:1526922955630};\\\", \\\"{x:1480,y:831,t:1526922955647};\\\", \\\"{x:1479,y:827,t:1526922955663};\\\", \\\"{x:1478,y:825,t:1526922955680};\\\", \\\"{x:1478,y:824,t:1526922955697};\\\", \\\"{x:1477,y:823,t:1526922955713};\\\", \\\"{x:1477,y:822,t:1526922955729};\\\", \\\"{x:1476,y:822,t:1526922956547};\\\", \\\"{x:1474,y:823,t:1526922956564};\\\", \\\"{x:1473,y:823,t:1526922956580};\\\", \\\"{x:1473,y:824,t:1526922956597};\\\", \\\"{x:1472,y:824,t:1526922956614};\\\", \\\"{x:1471,y:825,t:1526922956644};\\\", \\\"{x:1471,y:826,t:1526922958116};\\\", \\\"{x:1471,y:827,t:1526922958131};\\\", \\\"{x:1472,y:827,t:1526922958155};\\\", \\\"{x:1473,y:827,t:1526922958187};\\\", \\\"{x:1475,y:828,t:1526922958243};\\\", \\\"{x:1476,y:828,t:1526922958291};\\\", \\\"{x:1477,y:828,t:1526922958322};\\\", \\\"{x:1477,y:829,t:1526922958330};\\\", \\\"{x:1478,y:829,t:1526922958347};\\\", \\\"{x:1479,y:829,t:1526922958365};\\\", \\\"{x:1480,y:830,t:1526922958380};\\\", \\\"{x:1481,y:831,t:1526922958427};\\\", \\\"{x:1482,y:831,t:1526922958434};\\\", \\\"{x:1483,y:831,t:1526922958447};\\\", \\\"{x:1484,y:831,t:1526922958465};\\\", \\\"{x:1485,y:832,t:1526922958480};\\\", \\\"{x:1484,y:832,t:1526922959288};\\\", \\\"{x:1483,y:831,t:1526922959302};\\\", \\\"{x:1482,y:830,t:1526922959319};\\\", \\\"{x:1476,y:826,t:1526922959336};\\\", \\\"{x:1472,y:824,t:1526922959353};\\\", \\\"{x:1467,y:823,t:1526922959370};\\\", \\\"{x:1465,y:819,t:1526922959386};\\\", \\\"{x:1460,y:818,t:1526922959402};\\\", \\\"{x:1455,y:814,t:1526922959420};\\\", \\\"{x:1446,y:809,t:1526922959436};\\\", \\\"{x:1439,y:805,t:1526922959453};\\\", \\\"{x:1429,y:797,t:1526922959469};\\\", \\\"{x:1422,y:790,t:1526922959486};\\\", \\\"{x:1400,y:771,t:1526922959503};\\\", \\\"{x:1376,y:754,t:1526922959519};\\\", \\\"{x:1361,y:744,t:1526922959535};\\\", \\\"{x:1344,y:731,t:1526922959553};\\\", \\\"{x:1311,y:718,t:1526922959570};\\\", \\\"{x:1279,y:712,t:1526922959586};\\\", \\\"{x:1234,y:710,t:1526922959603};\\\", \\\"{x:1167,y:710,t:1526922959620};\\\", \\\"{x:1086,y:710,t:1526922959635};\\\", \\\"{x:992,y:710,t:1526922959653};\\\", \\\"{x:901,y:710,t:1526922959670};\\\", \\\"{x:803,y:710,t:1526922959686};\\\", \\\"{x:730,y:705,t:1526922959703};\\\", \\\"{x:645,y:695,t:1526922959720};\\\", \\\"{x:611,y:689,t:1526922959736};\\\", \\\"{x:592,y:689,t:1526922959753};\\\", \\\"{x:579,y:688,t:1526922959769};\\\", \\\"{x:568,y:688,t:1526922959785};\\\", \\\"{x:563,y:688,t:1526922959803};\\\", \\\"{x:559,y:688,t:1526922959820};\\\", \\\"{x:554,y:688,t:1526922959836};\\\", \\\"{x:549,y:688,t:1526922959853};\\\", \\\"{x:542,y:687,t:1526922959869};\\\", \\\"{x:537,y:685,t:1526922959886};\\\", \\\"{x:536,y:684,t:1526922959903};\\\", \\\"{x:534,y:682,t:1526922959919};\\\", \\\"{x:534,y:678,t:1526922959935};\\\", \\\"{x:534,y:673,t:1526922959953};\\\", \\\"{x:534,y:671,t:1526922959969};\\\", \\\"{x:537,y:668,t:1526922959987};\\\", \\\"{x:541,y:659,t:1526922960003};\\\", \\\"{x:555,y:648,t:1526922960020};\\\", \\\"{x:565,y:640,t:1526922960037};\\\", \\\"{x:576,y:631,t:1526922960053};\\\", \\\"{x:580,y:626,t:1526922960069};\\\", \\\"{x:582,y:622,t:1526922960087};\\\", \\\"{x:582,y:618,t:1526922960107};\\\", \\\"{x:583,y:616,t:1526922960123};\\\", \\\"{x:584,y:614,t:1526922960139};\\\", \\\"{x:585,y:612,t:1526922960157};\\\", \\\"{x:585,y:611,t:1526922960173};\\\", \\\"{x:587,y:608,t:1526922960191};\\\", \\\"{x:588,y:606,t:1526922960206};\\\", \\\"{x:589,y:602,t:1526922960223};\\\", \\\"{x:590,y:600,t:1526922960241};\\\", \\\"{x:592,y:596,t:1526922960257};\\\", \\\"{x:592,y:595,t:1526922960274};\\\", \\\"{x:594,y:592,t:1526922960291};\\\", \\\"{x:596,y:590,t:1526922960308};\\\", \\\"{x:597,y:588,t:1526922960323};\\\", \\\"{x:599,y:586,t:1526922960340};\\\", \\\"{x:601,y:585,t:1526922960358};\\\", \\\"{x:604,y:584,t:1526922960373};\\\", \\\"{x:606,y:582,t:1526922960391};\\\", \\\"{x:610,y:580,t:1526922960407};\\\", \\\"{x:614,y:577,t:1526922960423};\\\", \\\"{x:615,y:577,t:1526922960440};\\\", \\\"{x:615,y:576,t:1526922960824};\\\", \\\"{x:613,y:577,t:1526922960840};\\\", \\\"{x:597,y:583,t:1526922960858};\\\", \\\"{x:577,y:592,t:1526922960875};\\\", \\\"{x:558,y:599,t:1526922960891};\\\", \\\"{x:536,y:603,t:1526922960908};\\\", \\\"{x:509,y:608,t:1526922960925};\\\", \\\"{x:479,y:610,t:1526922960941};\\\", \\\"{x:440,y:610,t:1526922960958};\\\", \\\"{x:413,y:610,t:1526922960975};\\\", \\\"{x:388,y:608,t:1526922960991};\\\", \\\"{x:350,y:600,t:1526922961008};\\\", \\\"{x:327,y:593,t:1526922961025};\\\", \\\"{x:311,y:591,t:1526922961041};\\\", \\\"{x:301,y:588,t:1526922961057};\\\", \\\"{x:292,y:587,t:1526922961075};\\\", \\\"{x:289,y:586,t:1526922961091};\\\", \\\"{x:285,y:586,t:1526922961107};\\\", \\\"{x:282,y:585,t:1526922961125};\\\", \\\"{x:279,y:584,t:1526922961140};\\\", \\\"{x:274,y:583,t:1526922961157};\\\", \\\"{x:272,y:581,t:1526922961176};\\\", \\\"{x:267,y:580,t:1526922961191};\\\", \\\"{x:260,y:577,t:1526922961208};\\\", \\\"{x:255,y:576,t:1526922961224};\\\", \\\"{x:249,y:573,t:1526922961242};\\\", \\\"{x:245,y:573,t:1526922961257};\\\", \\\"{x:241,y:573,t:1526922961275};\\\", \\\"{x:233,y:572,t:1526922961292};\\\", \\\"{x:228,y:571,t:1526922961307};\\\", \\\"{x:220,y:569,t:1526922961324};\\\", \\\"{x:219,y:569,t:1526922961431};\\\", \\\"{x:219,y:568,t:1526922961441};\\\", \\\"{x:224,y:566,t:1526922961457};\\\", \\\"{x:233,y:565,t:1526922961475};\\\", \\\"{x:250,y:563,t:1526922961491};\\\", \\\"{x:274,y:563,t:1526922961508};\\\", \\\"{x:292,y:560,t:1526922961525};\\\", \\\"{x:309,y:560,t:1526922961542};\\\", \\\"{x:325,y:560,t:1526922961557};\\\", \\\"{x:338,y:560,t:1526922961575};\\\", \\\"{x:362,y:560,t:1526922961591};\\\", \\\"{x:380,y:558,t:1526922961607};\\\", \\\"{x:396,y:555,t:1526922961626};\\\", \\\"{x:415,y:552,t:1526922961642};\\\", \\\"{x:426,y:548,t:1526922961658};\\\", \\\"{x:438,y:544,t:1526922961675};\\\", \\\"{x:454,y:540,t:1526922961691};\\\", \\\"{x:471,y:538,t:1526922961708};\\\", \\\"{x:482,y:535,t:1526922961725};\\\", \\\"{x:491,y:535,t:1526922961741};\\\", \\\"{x:500,y:533,t:1526922961758};\\\", \\\"{x:506,y:533,t:1526922961775};\\\", \\\"{x:511,y:532,t:1526922961791};\\\", \\\"{x:519,y:531,t:1526922961808};\\\", \\\"{x:528,y:530,t:1526922961825};\\\", \\\"{x:540,y:530,t:1526922961842};\\\", \\\"{x:549,y:530,t:1526922961858};\\\", \\\"{x:558,y:530,t:1526922961874};\\\", \\\"{x:567,y:529,t:1526922961892};\\\", \\\"{x:574,y:529,t:1526922961908};\\\", \\\"{x:578,y:529,t:1526922961925};\\\", \\\"{x:582,y:529,t:1526922961942};\\\", \\\"{x:585,y:530,t:1526922961959};\\\", \\\"{x:591,y:531,t:1526922961975};\\\", \\\"{x:595,y:532,t:1526922961991};\\\", \\\"{x:598,y:532,t:1526922962008};\\\", \\\"{x:603,y:533,t:1526922962026};\\\", \\\"{x:607,y:534,t:1526922962042};\\\", \\\"{x:609,y:536,t:1526922962058};\\\", \\\"{x:612,y:538,t:1526922962075};\\\", \\\"{x:615,y:539,t:1526922962092};\\\", \\\"{x:619,y:542,t:1526922962109};\\\", \\\"{x:623,y:545,t:1526922962126};\\\", \\\"{x:625,y:546,t:1526922962142};\\\", \\\"{x:627,y:548,t:1526922962159};\\\", \\\"{x:630,y:551,t:1526922962176};\\\", \\\"{x:633,y:555,t:1526922962191};\\\", \\\"{x:633,y:558,t:1526922962209};\\\", \\\"{x:633,y:562,t:1526922962225};\\\", \\\"{x:628,y:568,t:1526922962242};\\\", \\\"{x:614,y:576,t:1526922962258};\\\", \\\"{x:593,y:582,t:1526922962276};\\\", \\\"{x:564,y:590,t:1526922962292};\\\", \\\"{x:532,y:602,t:1526922962309};\\\", \\\"{x:505,y:606,t:1526922962326};\\\", \\\"{x:469,y:613,t:1526922962343};\\\", \\\"{x:445,y:615,t:1526922962359};\\\", \\\"{x:411,y:618,t:1526922962375};\\\", \\\"{x:396,y:620,t:1526922962392};\\\", \\\"{x:385,y:622,t:1526922962409};\\\", \\\"{x:381,y:624,t:1526922962426};\\\", \\\"{x:377,y:627,t:1526922962443};\\\", \\\"{x:377,y:628,t:1526922962459};\\\", \\\"{x:375,y:630,t:1526922962475};\\\", \\\"{x:375,y:632,t:1526922962493};\\\", \\\"{x:373,y:634,t:1526922962509};\\\", \\\"{x:372,y:635,t:1526922962525};\\\", \\\"{x:371,y:636,t:1526922962542};\\\", \\\"{x:370,y:637,t:1526922962560};\\\", \\\"{x:371,y:637,t:1526922962648};\\\", \\\"{x:372,y:636,t:1526922962659};\\\", \\\"{x:376,y:631,t:1526922962676};\\\", \\\"{x:380,y:623,t:1526922962694};\\\", \\\"{x:384,y:618,t:1526922962710};\\\", \\\"{x:385,y:611,t:1526922962726};\\\", \\\"{x:385,y:605,t:1526922962743};\\\", \\\"{x:385,y:597,t:1526922962761};\\\", \\\"{x:385,y:592,t:1526922962777};\\\", \\\"{x:385,y:590,t:1526922962793};\\\", \\\"{x:385,y:589,t:1526922962810};\\\", \\\"{x:385,y:587,t:1526922962826};\\\", \\\"{x:385,y:586,t:1526922962848};\\\", \\\"{x:385,y:584,t:1526922962905};\\\", \\\"{x:385,y:581,t:1526922962920};\\\", \\\"{x:385,y:580,t:1526922962929};\\\", \\\"{x:385,y:577,t:1526922962943};\\\", \\\"{x:385,y:567,t:1526922962961};\\\", \\\"{x:385,y:560,t:1526922962978};\\\", \\\"{x:389,y:551,t:1526922962993};\\\", \\\"{x:401,y:540,t:1526922963010};\\\", \\\"{x:416,y:533,t:1526922963026};\\\", \\\"{x:425,y:524,t:1526922963043};\\\", \\\"{x:449,y:519,t:1526922963060};\\\", \\\"{x:467,y:515,t:1526922963076};\\\", \\\"{x:481,y:514,t:1526922963093};\\\", \\\"{x:491,y:514,t:1526922963109};\\\", \\\"{x:506,y:514,t:1526922963126};\\\", \\\"{x:512,y:514,t:1526922963143};\\\", \\\"{x:528,y:513,t:1526922963160};\\\", \\\"{x:536,y:512,t:1526922963176};\\\", \\\"{x:542,y:511,t:1526922963193};\\\", \\\"{x:549,y:510,t:1526922963210};\\\", \\\"{x:556,y:510,t:1526922963226};\\\", \\\"{x:566,y:510,t:1526922963243};\\\", \\\"{x:590,y:510,t:1526922963260};\\\", \\\"{x:617,y:510,t:1526922963278};\\\", \\\"{x:647,y:510,t:1526922963292};\\\", \\\"{x:676,y:510,t:1526922963310};\\\", \\\"{x:698,y:509,t:1526922963326};\\\", \\\"{x:711,y:508,t:1526922963343};\\\", \\\"{x:718,y:508,t:1526922963360};\\\", \\\"{x:719,y:508,t:1526922963407};\\\", \\\"{x:722,y:506,t:1526922963415};\\\", \\\"{x:727,y:506,t:1526922963427};\\\", \\\"{x:739,y:505,t:1526922963443};\\\", \\\"{x:750,y:505,t:1526922963459};\\\", \\\"{x:758,y:504,t:1526922963477};\\\", \\\"{x:762,y:504,t:1526922963493};\\\", \\\"{x:765,y:504,t:1526922963510};\\\", \\\"{x:766,y:504,t:1526922963527};\\\", \\\"{x:769,y:504,t:1526922963585};\\\", \\\"{x:771,y:504,t:1526922963600};\\\", \\\"{x:772,y:504,t:1526922963610};\\\", \\\"{x:774,y:504,t:1526922963627};\\\", \\\"{x:776,y:504,t:1526922963643};\\\", \\\"{x:778,y:504,t:1526922963660};\\\", \\\"{x:780,y:504,t:1526922963677};\\\", \\\"{x:784,y:504,t:1526922963694};\\\", \\\"{x:787,y:504,t:1526922963710};\\\", \\\"{x:789,y:504,t:1526922963727};\\\", \\\"{x:791,y:504,t:1526922963743};\\\", \\\"{x:792,y:504,t:1526922963760};\\\", \\\"{x:795,y:504,t:1526922963777};\\\", \\\"{x:798,y:504,t:1526922963793};\\\", \\\"{x:801,y:504,t:1526922963810};\\\", \\\"{x:804,y:504,t:1526922963827};\\\", \\\"{x:808,y:504,t:1526922963844};\\\", \\\"{x:811,y:504,t:1526922963861};\\\", \\\"{x:815,y:504,t:1526922963877};\\\", \\\"{x:816,y:504,t:1526922963894};\\\", \\\"{x:818,y:504,t:1526922963910};\\\", \\\"{x:819,y:504,t:1526922963927};\\\", \\\"{x:822,y:504,t:1526922963944};\\\", \\\"{x:824,y:504,t:1526922963961};\\\", \\\"{x:825,y:504,t:1526922963984};\\\", \\\"{x:827,y:504,t:1526922964050};\\\", \\\"{x:828,y:504,t:1526922964184};\\\", \\\"{x:828,y:505,t:1526922964311};\\\", \\\"{x:828,y:505,t:1526922964327};\\\", \\\"{x:828,y:509,t:1526922964344};\\\", \\\"{x:828,y:512,t:1526922964361};\\\", \\\"{x:826,y:516,t:1526922964377};\\\", \\\"{x:820,y:519,t:1526922964394};\\\", \\\"{x:805,y:527,t:1526922964411};\\\", \\\"{x:781,y:537,t:1526922964427};\\\", \\\"{x:756,y:546,t:1526922964444};\\\", \\\"{x:727,y:556,t:1526922964461};\\\", \\\"{x:706,y:565,t:1526922964478};\\\", \\\"{x:683,y:573,t:1526922964494};\\\", \\\"{x:667,y:581,t:1526922964511};\\\", \\\"{x:640,y:597,t:1526922964528};\\\", \\\"{x:627,y:605,t:1526922964544};\\\", \\\"{x:617,y:613,t:1526922964561};\\\", \\\"{x:613,y:618,t:1526922964577};\\\", \\\"{x:609,y:623,t:1526922964594};\\\", \\\"{x:606,y:629,t:1526922964611};\\\", \\\"{x:602,y:633,t:1526922964628};\\\", \\\"{x:598,y:640,t:1526922964644};\\\", \\\"{x:596,y:643,t:1526922964661};\\\", \\\"{x:593,y:647,t:1526922964677};\\\", \\\"{x:590,y:650,t:1526922964694};\\\", \\\"{x:589,y:652,t:1526922964711};\\\", \\\"{x:586,y:656,t:1526922964728};\\\", \\\"{x:583,y:658,t:1526922964743};\\\", \\\"{x:582,y:659,t:1526922964761};\\\", \\\"{x:581,y:660,t:1526922964778};\\\", \\\"{x:579,y:660,t:1526922964809};\\\", \\\"{x:578,y:660,t:1526922964823};\\\", \\\"{x:577,y:660,t:1526922964832};\\\", \\\"{x:576,y:660,t:1526922964856};\\\", \\\"{x:575,y:660,t:1526922964871};\\\", \\\"{x:573,y:661,t:1526922964896};\\\", \\\"{x:572,y:661,t:1526922964910};\\\", \\\"{x:571,y:662,t:1526922964927};\\\", \\\"{x:570,y:663,t:1526922964944};\\\", \\\"{x:568,y:663,t:1526922964968};\\\", \\\"{x:565,y:663,t:1526922965288};\\\", \\\"{x:564,y:664,t:1526922965296};\\\", \\\"{x:564,y:665,t:1526922965311};\\\", \\\"{x:560,y:668,t:1526922965328};\\\", \\\"{x:559,y:670,t:1526922965344};\\\", \\\"{x:557,y:671,t:1526922965362};\\\", \\\"{x:556,y:673,t:1526922965378};\\\", \\\"{x:556,y:674,t:1526922965395};\\\", \\\"{x:553,y:677,t:1526922965411};\\\", \\\"{x:551,y:678,t:1526922965429};\\\", \\\"{x:548,y:680,t:1526922965445};\\\", \\\"{x:547,y:682,t:1526922965462};\\\", \\\"{x:546,y:682,t:1526922965478};\\\", \\\"{x:545,y:683,t:1526922965495};\\\", \\\"{x:543,y:685,t:1526922965511};\\\", \\\"{x:542,y:686,t:1526922965528};\\\", \\\"{x:541,y:687,t:1526922965546};\\\", \\\"{x:540,y:688,t:1526922965575};\\\", \\\"{x:539,y:689,t:1526922965704};\\\", \\\"{x:537,y:690,t:1526922965720};\\\", \\\"{x:537,y:691,t:1526922965744};\\\", \\\"{x:537,y:692,t:1526922965751};\\\", \\\"{x:536,y:694,t:1526922965768};\\\", \\\"{x:535,y:694,t:1526922965778};\\\", \\\"{x:534,y:695,t:1526922965799};\\\", \\\"{x:532,y:697,t:1526922965832};\\\", \\\"{x:530,y:698,t:1526922965855};\\\", \\\"{x:530,y:699,t:1526922965864};\\\", \\\"{x:529,y:699,t:1526922965878};\\\", \\\"{x:528,y:701,t:1526922965895};\\\", \\\"{x:524,y:704,t:1526922965912};\\\", \\\"{x:523,y:704,t:1526922965929};\\\", \\\"{x:522,y:704,t:1526922965945};\\\", \\\"{x:519,y:706,t:1526922965962};\\\", \\\"{x:519,y:707,t:1526922965979};\\\", \\\"{x:518,y:707,t:1526922965995};\\\", \\\"{x:516,y:708,t:1526922966012};\\\", \\\"{x:515,y:708,t:1526922966029};\\\", \\\"{x:514,y:708,t:1526922966045};\\\", \\\"{x:511,y:711,t:1526922966062};\\\", \\\"{x:509,y:711,t:1526922966079};\\\", \\\"{x:508,y:712,t:1526922966095};\\\", \\\"{x:506,y:714,t:1526922966112};\\\", \\\"{x:505,y:714,t:1526922966129};\\\", \\\"{x:504,y:714,t:1526922966145};\\\", \\\"{x:504,y:715,t:1526922966162};\\\", \\\"{x:503,y:715,t:1526922966179};\\\", \\\"{x:503,y:716,t:1526922966195};\\\", \\\"{x:502,y:717,t:1526922966211};\\\", \\\"{x:502,y:719,t:1526922966229};\\\", \\\"{x:502,y:721,t:1526922966245};\\\", \\\"{x:502,y:723,t:1526922966262};\\\", \\\"{x:502,y:725,t:1526922966279};\\\", \\\"{x:502,y:726,t:1526922966295};\\\", \\\"{x:503,y:728,t:1526922966311};\\\", \\\"{x:503,y:729,t:1526922966335};\\\", \\\"{x:503,y:730,t:1526922966346};\\\", \\\"{x:503,y:731,t:1526922966362};\\\", \\\"{x:503,y:732,t:1526922966392};\\\", \\\"{x:503,y:733,t:1526922966408};\\\" ] }, { \\\"rt\\\": 54559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 453599, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-03 PM-03 PM-M -E -E -I -I -I -I -I -I -I -I -J -J -M -M -Z -N -D -N -N -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:733,t:1526922967984};\\\", \\\"{x:500,y:733,t:1526922969088};\\\", \\\"{x:499,y:735,t:1526922969512};\\\", \\\"{x:498,y:735,t:1526922969520};\\\", \\\"{x:498,y:736,t:1526922969534};\\\", \\\"{x:498,y:739,t:1526922969550};\\\", \\\"{x:501,y:744,t:1526922969567};\\\", \\\"{x:510,y:753,t:1526922969584};\\\", \\\"{x:536,y:764,t:1526922969601};\\\", \\\"{x:564,y:780,t:1526922969618};\\\", \\\"{x:596,y:790,t:1526922969634};\\\", \\\"{x:657,y:807,t:1526922969647};\\\", \\\"{x:723,y:824,t:1526922969664};\\\", \\\"{x:806,y:847,t:1526922969681};\\\", \\\"{x:886,y:867,t:1526922969698};\\\", \\\"{x:969,y:890,t:1526922969715};\\\", \\\"{x:1064,y:919,t:1526922969731};\\\", \\\"{x:1145,y:944,t:1526922969748};\\\", \\\"{x:1209,y:954,t:1526922969765};\\\", \\\"{x:1292,y:966,t:1526922969781};\\\", \\\"{x:1355,y:980,t:1526922969798};\\\", \\\"{x:1427,y:1000,t:1526922969815};\\\", \\\"{x:1475,y:1007,t:1526922969831};\\\", \\\"{x:1553,y:1023,t:1526922969848};\\\", \\\"{x:1591,y:1030,t:1526922969865};\\\", \\\"{x:1641,y:1036,t:1526922969881};\\\", \\\"{x:1709,y:1043,t:1526922969898};\\\", \\\"{x:1769,y:1053,t:1526922969915};\\\", \\\"{x:1805,y:1058,t:1526922969931};\\\", \\\"{x:1828,y:1058,t:1526922969947};\\\", \\\"{x:1848,y:1059,t:1526922969965};\\\", \\\"{x:1854,y:1059,t:1526922969981};\\\", \\\"{x:1855,y:1059,t:1526922970040};\\\", \\\"{x:1853,y:1055,t:1526922970048};\\\", \\\"{x:1843,y:1048,t:1526922970065};\\\", \\\"{x:1828,y:1038,t:1526922970081};\\\", \\\"{x:1811,y:1033,t:1526922970098};\\\", \\\"{x:1790,y:1028,t:1526922970115};\\\", \\\"{x:1766,y:1021,t:1526922970131};\\\", \\\"{x:1744,y:1015,t:1526922970148};\\\", \\\"{x:1718,y:1012,t:1526922970165};\\\", \\\"{x:1693,y:1010,t:1526922970182};\\\", \\\"{x:1671,y:1005,t:1526922970198};\\\", \\\"{x:1656,y:1005,t:1526922970215};\\\", \\\"{x:1646,y:1005,t:1526922970231};\\\", \\\"{x:1629,y:1006,t:1526922970248};\\\", \\\"{x:1621,y:1007,t:1526922970265};\\\", \\\"{x:1617,y:1007,t:1526922970281};\\\", \\\"{x:1614,y:1007,t:1526922970298};\\\", \\\"{x:1607,y:1007,t:1526922970315};\\\", \\\"{x:1605,y:1007,t:1526922970331};\\\", \\\"{x:1602,y:1007,t:1526922970348};\\\", \\\"{x:1600,y:1007,t:1526922970375};\\\", \\\"{x:1598,y:1007,t:1526922970391};\\\", \\\"{x:1597,y:1007,t:1526922970399};\\\", \\\"{x:1596,y:1007,t:1526922970415};\\\", \\\"{x:1594,y:1007,t:1526922970432};\\\", \\\"{x:1593,y:1007,t:1526922970448};\\\", \\\"{x:1592,y:1007,t:1526922970480};\\\", \\\"{x:1591,y:1007,t:1526922970488};\\\", \\\"{x:1589,y:1007,t:1526922970498};\\\", \\\"{x:1584,y:1007,t:1526922970515};\\\", \\\"{x:1580,y:1007,t:1526922970532};\\\", \\\"{x:1574,y:1004,t:1526922970548};\\\", \\\"{x:1568,y:1002,t:1526922970565};\\\", \\\"{x:1562,y:998,t:1526922970582};\\\", \\\"{x:1552,y:993,t:1526922970598};\\\", \\\"{x:1549,y:990,t:1526922970615};\\\", \\\"{x:1546,y:988,t:1526922970631};\\\", \\\"{x:1542,y:984,t:1526922970648};\\\", \\\"{x:1539,y:981,t:1526922970666};\\\", \\\"{x:1537,y:979,t:1526922970682};\\\", \\\"{x:1535,y:977,t:1526922970698};\\\", \\\"{x:1534,y:975,t:1526922970715};\\\", \\\"{x:1532,y:974,t:1526922970732};\\\", \\\"{x:1531,y:973,t:1526922970748};\\\", \\\"{x:1530,y:971,t:1526922970765};\\\", \\\"{x:1529,y:970,t:1526922970783};\\\", \\\"{x:1528,y:969,t:1526922970798};\\\", \\\"{x:1528,y:968,t:1526922971344};\\\", \\\"{x:1530,y:968,t:1526922971663};\\\", \\\"{x:1531,y:968,t:1526922971688};\\\", \\\"{x:1532,y:968,t:1526922971728};\\\", \\\"{x:1533,y:968,t:1526922971735};\\\", \\\"{x:1534,y:969,t:1526922971807};\\\", \\\"{x:1535,y:969,t:1526922971896};\\\", \\\"{x:1535,y:970,t:1526922971903};\\\", \\\"{x:1536,y:970,t:1526922972007};\\\", \\\"{x:1537,y:970,t:1526922972015};\\\", \\\"{x:1539,y:970,t:1526922972032};\\\", \\\"{x:1540,y:970,t:1526922972050};\\\", \\\"{x:1542,y:970,t:1526922972095};\\\", \\\"{x:1543,y:970,t:1526922972127};\\\", \\\"{x:1544,y:969,t:1526922972160};\\\", \\\"{x:1545,y:969,t:1526922972168};\\\", \\\"{x:1546,y:968,t:1526922972216};\\\", \\\"{x:1547,y:968,t:1526922972239};\\\", \\\"{x:1548,y:967,t:1526922972249};\\\", \\\"{x:1549,y:967,t:1526922972272};\\\", \\\"{x:1550,y:966,t:1526922972336};\\\", \\\"{x:1551,y:966,t:1526922972368};\\\", \\\"{x:1552,y:965,t:1526922972519};\\\", \\\"{x:1552,y:964,t:1526922972544};\\\", \\\"{x:1552,y:963,t:1526922972552};\\\", \\\"{x:1552,y:962,t:1526922972567};\\\", \\\"{x:1552,y:960,t:1526922972583};\\\", \\\"{x:1551,y:959,t:1526922972599};\\\", \\\"{x:1549,y:957,t:1526922972624};\\\", \\\"{x:1549,y:956,t:1526922972648};\\\", \\\"{x:1548,y:955,t:1526922972671};\\\", \\\"{x:1548,y:954,t:1526922972683};\\\", \\\"{x:1548,y:953,t:1526922972699};\\\", \\\"{x:1547,y:952,t:1526922972716};\\\", \\\"{x:1546,y:952,t:1526922972733};\\\", \\\"{x:1546,y:951,t:1526922972759};\\\", \\\"{x:1545,y:951,t:1526922972776};\\\", \\\"{x:1544,y:951,t:1526922972864};\\\", \\\"{x:1544,y:950,t:1526922972871};\\\", \\\"{x:1543,y:950,t:1526922972943};\\\", \\\"{x:1542,y:950,t:1526922972975};\\\", \\\"{x:1540,y:950,t:1526922973007};\\\", \\\"{x:1538,y:950,t:1526922973079};\\\", \\\"{x:1536,y:950,t:1526922973096};\\\", \\\"{x:1534,y:950,t:1526922973111};\\\", \\\"{x:1533,y:950,t:1526922973120};\\\", \\\"{x:1530,y:950,t:1526922973133};\\\", \\\"{x:1527,y:949,t:1526922973150};\\\", \\\"{x:1522,y:945,t:1526922973166};\\\", \\\"{x:1516,y:943,t:1526922973183};\\\", \\\"{x:1513,y:942,t:1526922973200};\\\", \\\"{x:1509,y:941,t:1526922973216};\\\", \\\"{x:1507,y:939,t:1526922973234};\\\", \\\"{x:1504,y:938,t:1526922973250};\\\", \\\"{x:1500,y:937,t:1526922973267};\\\", \\\"{x:1496,y:935,t:1526922973283};\\\", \\\"{x:1489,y:935,t:1526922973300};\\\", \\\"{x:1480,y:931,t:1526922973317};\\\", \\\"{x:1476,y:930,t:1526922973333};\\\", \\\"{x:1470,y:928,t:1526922973350};\\\", \\\"{x:1467,y:927,t:1526922973366};\\\", \\\"{x:1465,y:926,t:1526922973383};\\\", \\\"{x:1462,y:926,t:1526922973400};\\\", \\\"{x:1458,y:925,t:1526922973416};\\\", \\\"{x:1457,y:924,t:1526922973433};\\\", \\\"{x:1453,y:923,t:1526922973450};\\\", \\\"{x:1447,y:921,t:1526922973467};\\\", \\\"{x:1443,y:919,t:1526922973483};\\\", \\\"{x:1441,y:918,t:1526922973501};\\\", \\\"{x:1436,y:917,t:1526922973518};\\\", \\\"{x:1435,y:916,t:1526922973534};\\\", \\\"{x:1434,y:915,t:1526922973550};\\\", \\\"{x:1430,y:913,t:1526922973567};\\\", \\\"{x:1427,y:913,t:1526922973583};\\\", \\\"{x:1422,y:911,t:1526922973600};\\\", \\\"{x:1417,y:909,t:1526922973617};\\\", \\\"{x:1413,y:909,t:1526922973633};\\\", \\\"{x:1411,y:907,t:1526922973650};\\\", \\\"{x:1409,y:906,t:1526922973667};\\\", \\\"{x:1407,y:906,t:1526922973683};\\\", \\\"{x:1405,y:905,t:1526922973700};\\\", \\\"{x:1404,y:905,t:1526922973720};\\\", \\\"{x:1402,y:904,t:1526922973733};\\\", \\\"{x:1399,y:902,t:1526922973750};\\\", \\\"{x:1395,y:900,t:1526922973768};\\\", \\\"{x:1393,y:899,t:1526922973783};\\\", \\\"{x:1392,y:898,t:1526922973800};\\\", \\\"{x:1391,y:898,t:1526922973817};\\\", \\\"{x:1389,y:898,t:1526922973834};\\\", \\\"{x:1389,y:897,t:1526922973851};\\\", \\\"{x:1387,y:895,t:1526922973867};\\\", \\\"{x:1385,y:894,t:1526922973889};\\\", \\\"{x:1385,y:893,t:1526922973917};\\\", \\\"{x:1383,y:892,t:1526922973933};\\\", \\\"{x:1382,y:892,t:1526922974079};\\\", \\\"{x:1382,y:893,t:1526922974087};\\\", \\\"{x:1382,y:894,t:1526922974103};\\\", \\\"{x:1382,y:895,t:1526922974117};\\\", \\\"{x:1382,y:897,t:1526922974134};\\\", \\\"{x:1384,y:900,t:1526922974150};\\\", \\\"{x:1387,y:904,t:1526922974168};\\\", \\\"{x:1389,y:908,t:1526922974183};\\\", \\\"{x:1391,y:910,t:1526922974201};\\\", \\\"{x:1391,y:911,t:1526922974217};\\\", \\\"{x:1392,y:912,t:1526922974233};\\\", \\\"{x:1394,y:915,t:1526922974250};\\\", \\\"{x:1397,y:920,t:1526922974267};\\\", \\\"{x:1398,y:922,t:1526922974284};\\\", \\\"{x:1401,y:927,t:1526922974300};\\\", \\\"{x:1403,y:931,t:1526922974317};\\\", \\\"{x:1406,y:934,t:1526922974334};\\\", \\\"{x:1407,y:937,t:1526922974350};\\\", \\\"{x:1409,y:940,t:1526922974367};\\\", \\\"{x:1411,y:943,t:1526922974383};\\\", \\\"{x:1412,y:945,t:1526922974400};\\\", \\\"{x:1412,y:946,t:1526922974417};\\\", \\\"{x:1413,y:947,t:1526922974434};\\\", \\\"{x:1413,y:948,t:1526922974495};\\\", \\\"{x:1413,y:949,t:1526922974807};\\\", \\\"{x:1413,y:950,t:1526922974823};\\\", \\\"{x:1414,y:951,t:1526922974839};\\\", \\\"{x:1415,y:952,t:1526922975112};\\\", \\\"{x:1417,y:951,t:1526922975128};\\\", \\\"{x:1418,y:950,t:1526922975136};\\\", \\\"{x:1420,y:947,t:1526922975151};\\\", \\\"{x:1421,y:946,t:1526922975167};\\\", \\\"{x:1422,y:944,t:1526922975184};\\\", \\\"{x:1422,y:943,t:1526922975216};\\\", \\\"{x:1422,y:942,t:1526922975232};\\\", \\\"{x:1423,y:942,t:1526922975281};\\\", \\\"{x:1421,y:942,t:1526922975432};\\\", \\\"{x:1421,y:943,t:1526922975448};\\\", \\\"{x:1420,y:944,t:1526922975457};\\\", \\\"{x:1419,y:945,t:1526922975468};\\\", \\\"{x:1418,y:946,t:1526922975497};\\\", \\\"{x:1417,y:947,t:1526922975529};\\\", \\\"{x:1416,y:948,t:1526922975552};\\\", \\\"{x:1415,y:948,t:1526922975569};\\\", \\\"{x:1414,y:950,t:1526922975585};\\\", \\\"{x:1414,y:951,t:1526922975602};\\\", \\\"{x:1414,y:953,t:1526922975619};\\\", \\\"{x:1414,y:954,t:1526922975648};\\\", \\\"{x:1414,y:955,t:1526922975656};\\\", \\\"{x:1414,y:956,t:1526922975705};\\\", \\\"{x:1413,y:956,t:1526922975744};\\\", \\\"{x:1413,y:957,t:1526922975993};\\\", \\\"{x:1413,y:956,t:1526922976521};\\\", \\\"{x:1413,y:953,t:1526922976536};\\\", \\\"{x:1413,y:950,t:1526922976552};\\\", \\\"{x:1413,y:949,t:1526922976568};\\\", \\\"{x:1414,y:946,t:1526922976586};\\\", \\\"{x:1414,y:943,t:1526922976602};\\\", \\\"{x:1415,y:940,t:1526922976619};\\\", \\\"{x:1415,y:938,t:1526922976636};\\\", \\\"{x:1416,y:933,t:1526922976652};\\\", \\\"{x:1416,y:930,t:1526922976669};\\\", \\\"{x:1417,y:926,t:1526922976685};\\\", \\\"{x:1418,y:924,t:1526922976703};\\\", \\\"{x:1419,y:922,t:1526922976719};\\\", \\\"{x:1419,y:919,t:1526922976736};\\\", \\\"{x:1419,y:917,t:1526922976752};\\\", \\\"{x:1419,y:915,t:1526922976769};\\\", \\\"{x:1419,y:913,t:1526922976786};\\\", \\\"{x:1419,y:911,t:1526922976803};\\\", \\\"{x:1420,y:909,t:1526922976819};\\\", \\\"{x:1420,y:906,t:1526922976836};\\\", \\\"{x:1420,y:903,t:1526922976853};\\\", \\\"{x:1420,y:900,t:1526922976869};\\\", \\\"{x:1420,y:897,t:1526922976886};\\\", \\\"{x:1420,y:896,t:1526922976903};\\\", \\\"{x:1420,y:892,t:1526922976920};\\\", \\\"{x:1420,y:888,t:1526922976936};\\\", \\\"{x:1420,y:886,t:1526922976953};\\\", \\\"{x:1420,y:883,t:1526922976969};\\\", \\\"{x:1420,y:882,t:1526922976986};\\\", \\\"{x:1420,y:878,t:1526922977003};\\\", \\\"{x:1419,y:873,t:1526922977019};\\\", \\\"{x:1418,y:869,t:1526922977035};\\\", \\\"{x:1417,y:865,t:1526922977052};\\\", \\\"{x:1415,y:862,t:1526922977068};\\\", \\\"{x:1414,y:858,t:1526922977086};\\\", \\\"{x:1414,y:853,t:1526922977102};\\\", \\\"{x:1414,y:849,t:1526922977119};\\\", \\\"{x:1413,y:844,t:1526922977135};\\\", \\\"{x:1413,y:842,t:1526922977152};\\\", \\\"{x:1412,y:840,t:1526922977169};\\\", \\\"{x:1411,y:839,t:1526922977185};\\\", \\\"{x:1411,y:838,t:1526922979823};\\\", \\\"{x:1409,y:839,t:1526922979839};\\\", \\\"{x:1405,y:839,t:1526922979854};\\\", \\\"{x:1398,y:839,t:1526922979870};\\\", \\\"{x:1386,y:839,t:1526922979887};\\\", \\\"{x:1373,y:841,t:1526922979903};\\\", \\\"{x:1357,y:844,t:1526922979920};\\\", \\\"{x:1345,y:845,t:1526922979938};\\\", \\\"{x:1332,y:845,t:1526922979953};\\\", \\\"{x:1312,y:845,t:1526922979971};\\\", \\\"{x:1294,y:845,t:1526922979987};\\\", \\\"{x:1283,y:845,t:1526922980003};\\\", \\\"{x:1276,y:846,t:1526922980020};\\\", \\\"{x:1270,y:847,t:1526922980038};\\\", \\\"{x:1267,y:847,t:1526922980053};\\\", \\\"{x:1266,y:847,t:1526922980070};\\\", \\\"{x:1261,y:847,t:1526922980087};\\\", \\\"{x:1253,y:847,t:1526922980103};\\\", \\\"{x:1244,y:847,t:1526922980120};\\\", \\\"{x:1238,y:847,t:1526922980137};\\\", \\\"{x:1234,y:847,t:1526922980154};\\\", \\\"{x:1232,y:847,t:1526922980171};\\\", \\\"{x:1231,y:847,t:1526922980187};\\\", \\\"{x:1230,y:847,t:1526922980204};\\\", \\\"{x:1229,y:846,t:1526922980220};\\\", \\\"{x:1229,y:844,t:1526922980237};\\\", \\\"{x:1229,y:839,t:1526922980254};\\\", \\\"{x:1234,y:829,t:1526922980271};\\\", \\\"{x:1242,y:813,t:1526922980288};\\\", \\\"{x:1250,y:797,t:1526922980303};\\\", \\\"{x:1260,y:773,t:1526922980320};\\\", \\\"{x:1270,y:752,t:1526922980337};\\\", \\\"{x:1282,y:737,t:1526922980353};\\\", \\\"{x:1287,y:727,t:1526922980371};\\\", \\\"{x:1289,y:718,t:1526922980388};\\\", \\\"{x:1293,y:710,t:1526922980404};\\\", \\\"{x:1294,y:709,t:1526922980420};\\\", \\\"{x:1296,y:703,t:1526922980437};\\\", \\\"{x:1296,y:702,t:1526922980453};\\\", \\\"{x:1296,y:699,t:1526922980471};\\\", \\\"{x:1296,y:691,t:1526922980487};\\\", \\\"{x:1295,y:685,t:1526922980504};\\\", \\\"{x:1293,y:679,t:1526922980521};\\\", \\\"{x:1291,y:671,t:1526922980537};\\\", \\\"{x:1289,y:665,t:1526922980554};\\\", \\\"{x:1285,y:656,t:1526922980570};\\\", \\\"{x:1282,y:647,t:1526922980588};\\\", \\\"{x:1280,y:641,t:1526922980605};\\\", \\\"{x:1278,y:633,t:1526922980621};\\\", \\\"{x:1278,y:626,t:1526922980638};\\\", \\\"{x:1280,y:618,t:1526922980655};\\\", \\\"{x:1282,y:611,t:1526922980670};\\\", \\\"{x:1284,y:604,t:1526922980688};\\\", \\\"{x:1284,y:601,t:1526922980705};\\\", \\\"{x:1285,y:598,t:1526922980721};\\\", \\\"{x:1285,y:597,t:1526922980738};\\\", \\\"{x:1285,y:596,t:1526922980755};\\\", \\\"{x:1285,y:595,t:1526922980771};\\\", \\\"{x:1285,y:594,t:1526922980880};\\\", \\\"{x:1285,y:592,t:1526922980960};\\\", \\\"{x:1285,y:591,t:1526922980970};\\\", \\\"{x:1285,y:589,t:1526922980988};\\\", \\\"{x:1285,y:588,t:1526922981004};\\\", \\\"{x:1285,y:586,t:1526922981031};\\\", \\\"{x:1285,y:585,t:1526922981055};\\\", \\\"{x:1283,y:582,t:1526922981071};\\\", \\\"{x:1283,y:579,t:1526922981087};\\\", \\\"{x:1282,y:577,t:1526922981105};\\\", \\\"{x:1282,y:575,t:1526922981120};\\\", \\\"{x:1282,y:573,t:1526922981137};\\\", \\\"{x:1281,y:571,t:1526922981155};\\\", \\\"{x:1281,y:570,t:1526922981176};\\\", \\\"{x:1281,y:569,t:1526922981191};\\\", \\\"{x:1281,y:567,t:1526922981204};\\\", \\\"{x:1281,y:566,t:1526922981221};\\\", \\\"{x:1281,y:564,t:1526922981237};\\\", \\\"{x:1281,y:563,t:1526922981255};\\\", \\\"{x:1281,y:561,t:1526922981271};\\\", \\\"{x:1281,y:560,t:1526922981287};\\\", \\\"{x:1284,y:560,t:1526922982007};\\\", \\\"{x:1285,y:560,t:1526922982021};\\\", \\\"{x:1293,y:560,t:1526922982039};\\\", \\\"{x:1303,y:560,t:1526922982054};\\\", \\\"{x:1317,y:560,t:1526922982071};\\\", \\\"{x:1321,y:560,t:1526922982088};\\\", \\\"{x:1323,y:560,t:1526922982104};\\\", \\\"{x:1322,y:560,t:1526922982247};\\\", \\\"{x:1321,y:560,t:1526922982255};\\\", \\\"{x:1320,y:560,t:1526922982271};\\\", \\\"{x:1315,y:560,t:1526922982288};\\\", \\\"{x:1309,y:560,t:1526922982306};\\\", \\\"{x:1305,y:560,t:1526922982321};\\\", \\\"{x:1298,y:560,t:1526922982339};\\\", \\\"{x:1297,y:560,t:1526922982355};\\\", \\\"{x:1296,y:560,t:1526922982371};\\\", \\\"{x:1295,y:560,t:1526922982399};\\\", \\\"{x:1294,y:560,t:1526922982408};\\\", \\\"{x:1292,y:560,t:1526922982422};\\\", \\\"{x:1288,y:562,t:1526922982438};\\\", \\\"{x:1279,y:564,t:1526922982456};\\\", \\\"{x:1275,y:565,t:1526922982472};\\\", \\\"{x:1273,y:565,t:1526922982528};\\\", \\\"{x:1273,y:564,t:1526922982551};\\\", \\\"{x:1272,y:563,t:1526922982560};\\\", \\\"{x:1271,y:563,t:1526922982572};\\\", \\\"{x:1270,y:562,t:1526922982589};\\\", \\\"{x:1270,y:560,t:1526922982606};\\\", \\\"{x:1270,y:559,t:1526922982622};\\\", \\\"{x:1270,y:558,t:1526922982639};\\\", \\\"{x:1270,y:556,t:1526922982656};\\\", \\\"{x:1269,y:555,t:1526922982671};\\\", \\\"{x:1268,y:554,t:1526922982752};\\\", \\\"{x:1267,y:554,t:1526922982759};\\\", \\\"{x:1265,y:554,t:1526922982772};\\\", \\\"{x:1260,y:560,t:1526922982789};\\\", \\\"{x:1252,y:569,t:1526922982805};\\\", \\\"{x:1239,y:583,t:1526922982822};\\\", \\\"{x:1225,y:597,t:1526922982839};\\\", \\\"{x:1212,y:615,t:1526922982855};\\\", \\\"{x:1209,y:628,t:1526922982872};\\\", \\\"{x:1207,y:641,t:1526922982889};\\\", \\\"{x:1207,y:651,t:1526922982905};\\\", \\\"{x:1207,y:664,t:1526922982921};\\\", \\\"{x:1207,y:673,t:1526922982938};\\\", \\\"{x:1207,y:681,t:1526922982955};\\\", \\\"{x:1206,y:689,t:1526922982972};\\\", \\\"{x:1205,y:695,t:1526922982988};\\\", \\\"{x:1205,y:700,t:1526922983005};\\\", \\\"{x:1203,y:706,t:1526922983022};\\\", \\\"{x:1203,y:713,t:1526922983038};\\\", \\\"{x:1202,y:719,t:1526922983055};\\\", \\\"{x:1201,y:721,t:1526922983073};\\\", \\\"{x:1199,y:725,t:1526922983088};\\\", \\\"{x:1198,y:728,t:1526922983106};\\\", \\\"{x:1196,y:731,t:1526922983123};\\\", \\\"{x:1193,y:735,t:1526922983138};\\\", \\\"{x:1189,y:738,t:1526922983156};\\\", \\\"{x:1185,y:740,t:1526922983173};\\\", \\\"{x:1184,y:742,t:1526922983189};\\\", \\\"{x:1182,y:743,t:1526922983206};\\\", \\\"{x:1181,y:744,t:1526922983223};\\\", \\\"{x:1180,y:745,t:1526922983238};\\\", \\\"{x:1178,y:749,t:1526922983256};\\\", \\\"{x:1176,y:752,t:1526922983273};\\\", \\\"{x:1175,y:756,t:1526922983289};\\\", \\\"{x:1174,y:756,t:1526922983305};\\\", \\\"{x:1174,y:758,t:1526922983376};\\\", \\\"{x:1174,y:759,t:1526922983416};\\\", \\\"{x:1174,y:761,t:1526922983496};\\\", \\\"{x:1174,y:762,t:1526922983727};\\\", \\\"{x:1175,y:762,t:1526922984769};\\\", \\\"{x:1176,y:761,t:1526922984785};\\\", \\\"{x:1177,y:758,t:1526922984807};\\\", \\\"{x:1178,y:757,t:1526922984823};\\\", \\\"{x:1178,y:755,t:1526922984839};\\\", \\\"{x:1179,y:754,t:1526922985136};\\\", \\\"{x:1180,y:755,t:1526922985185};\\\", \\\"{x:1180,y:756,t:1526922985200};\\\", \\\"{x:1180,y:758,t:1526922985225};\\\", \\\"{x:1181,y:758,t:1526922985239};\\\", \\\"{x:1181,y:759,t:1526922985257};\\\", \\\"{x:1181,y:761,t:1526922985274};\\\", \\\"{x:1181,y:762,t:1526922985290};\\\", \\\"{x:1181,y:765,t:1526922985309};\\\", \\\"{x:1181,y:766,t:1526922985324};\\\", \\\"{x:1181,y:768,t:1526922985340};\\\", \\\"{x:1181,y:770,t:1526922985358};\\\", \\\"{x:1181,y:772,t:1526922985374};\\\", \\\"{x:1181,y:773,t:1526922985390};\\\", \\\"{x:1181,y:774,t:1526922985408};\\\", \\\"{x:1181,y:775,t:1526922985432};\\\", \\\"{x:1181,y:777,t:1526922985440};\\\", \\\"{x:1181,y:778,t:1526922985457};\\\", \\\"{x:1181,y:781,t:1526922985474};\\\", \\\"{x:1180,y:783,t:1526922985491};\\\", \\\"{x:1179,y:785,t:1526922985508};\\\", \\\"{x:1179,y:787,t:1526922985525};\\\", \\\"{x:1179,y:790,t:1526922985540};\\\", \\\"{x:1179,y:792,t:1526922985557};\\\", \\\"{x:1178,y:796,t:1526922985574};\\\", \\\"{x:1177,y:800,t:1526922985591};\\\", \\\"{x:1177,y:803,t:1526922985607};\\\", \\\"{x:1177,y:809,t:1526922985624};\\\", \\\"{x:1177,y:815,t:1526922985641};\\\", \\\"{x:1178,y:820,t:1526922985657};\\\", \\\"{x:1178,y:823,t:1526922985674};\\\", \\\"{x:1178,y:826,t:1526922985691};\\\", \\\"{x:1177,y:829,t:1526922985709};\\\", \\\"{x:1177,y:833,t:1526922985724};\\\", \\\"{x:1175,y:835,t:1526922985741};\\\", \\\"{x:1174,y:837,t:1526922985760};\\\", \\\"{x:1174,y:839,t:1526922985777};\\\", \\\"{x:1174,y:840,t:1526922985791};\\\", \\\"{x:1174,y:841,t:1526922985808};\\\", \\\"{x:1174,y:843,t:1526922985824};\\\", \\\"{x:1174,y:844,t:1526922985840};\\\", \\\"{x:1174,y:847,t:1526922985858};\\\", \\\"{x:1173,y:849,t:1526922985896};\\\", \\\"{x:1173,y:851,t:1526922985909};\\\", \\\"{x:1173,y:853,t:1526922985925};\\\", \\\"{x:1173,y:856,t:1526922985941};\\\", \\\"{x:1173,y:858,t:1526922985957};\\\", \\\"{x:1173,y:860,t:1526922985974};\\\", \\\"{x:1173,y:864,t:1526922985991};\\\", \\\"{x:1173,y:866,t:1526922986007};\\\", \\\"{x:1173,y:873,t:1526922986024};\\\", \\\"{x:1173,y:875,t:1526922986041};\\\", \\\"{x:1173,y:877,t:1526922986058};\\\", \\\"{x:1171,y:882,t:1526922986074};\\\", \\\"{x:1171,y:883,t:1526922986091};\\\", \\\"{x:1170,y:887,t:1526922986107};\\\", \\\"{x:1170,y:890,t:1526922986123};\\\", \\\"{x:1170,y:894,t:1526922986140};\\\", \\\"{x:1170,y:898,t:1526922986156};\\\", \\\"{x:1170,y:901,t:1526922986174};\\\", \\\"{x:1167,y:906,t:1526922986190};\\\", \\\"{x:1167,y:917,t:1526922986207};\\\", \\\"{x:1167,y:921,t:1526922986224};\\\", \\\"{x:1167,y:922,t:1526922986240};\\\", \\\"{x:1168,y:928,t:1526922986258};\\\", \\\"{x:1169,y:928,t:1526922986273};\\\", \\\"{x:1171,y:933,t:1526922986290};\\\", \\\"{x:1173,y:940,t:1526922986307};\\\", \\\"{x:1174,y:945,t:1526922986324};\\\", \\\"{x:1174,y:947,t:1526922986340};\\\", \\\"{x:1175,y:949,t:1526922986357};\\\", \\\"{x:1176,y:951,t:1526922986374};\\\", \\\"{x:1177,y:953,t:1526922986391};\\\", \\\"{x:1178,y:956,t:1526922986407};\\\", \\\"{x:1179,y:956,t:1526922986423};\\\", \\\"{x:1179,y:957,t:1526922986752};\\\", \\\"{x:1181,y:957,t:1526922986759};\\\", \\\"{x:1182,y:954,t:1526922986774};\\\", \\\"{x:1183,y:949,t:1526922986791};\\\", \\\"{x:1185,y:942,t:1526922986807};\\\", \\\"{x:1185,y:939,t:1526922986824};\\\", \\\"{x:1186,y:935,t:1526922986841};\\\", \\\"{x:1186,y:931,t:1526922986858};\\\", \\\"{x:1186,y:927,t:1526922986874};\\\", \\\"{x:1187,y:924,t:1526922986891};\\\", \\\"{x:1187,y:918,t:1526922986908};\\\", \\\"{x:1189,y:912,t:1526922986925};\\\", \\\"{x:1190,y:905,t:1526922986941};\\\", \\\"{x:1190,y:898,t:1526922986958};\\\", \\\"{x:1190,y:892,t:1526922986975};\\\", \\\"{x:1190,y:886,t:1526922986991};\\\", \\\"{x:1191,y:879,t:1526922987007};\\\", \\\"{x:1192,y:870,t:1526922987025};\\\", \\\"{x:1192,y:865,t:1526922987041};\\\", \\\"{x:1193,y:856,t:1526922987058};\\\", \\\"{x:1194,y:847,t:1526922987074};\\\", \\\"{x:1194,y:838,t:1526922987090};\\\", \\\"{x:1194,y:827,t:1526922987108};\\\", \\\"{x:1194,y:821,t:1526922987124};\\\", \\\"{x:1194,y:812,t:1526922987141};\\\", \\\"{x:1193,y:802,t:1526922987158};\\\", \\\"{x:1192,y:796,t:1526922987175};\\\", \\\"{x:1191,y:790,t:1526922987191};\\\", \\\"{x:1191,y:785,t:1526922987208};\\\", \\\"{x:1189,y:778,t:1526922987224};\\\", \\\"{x:1188,y:776,t:1526922987241};\\\", \\\"{x:1188,y:774,t:1526922987258};\\\", \\\"{x:1185,y:770,t:1526922987274};\\\", \\\"{x:1184,y:768,t:1526922987290};\\\", \\\"{x:1184,y:765,t:1526922987308};\\\", \\\"{x:1182,y:761,t:1526922987324};\\\", \\\"{x:1182,y:760,t:1526922987340};\\\", \\\"{x:1181,y:758,t:1526922987357};\\\", \\\"{x:1180,y:756,t:1526922987375};\\\", \\\"{x:1178,y:754,t:1526922987390};\\\", \\\"{x:1177,y:753,t:1526922987407};\\\", \\\"{x:1175,y:751,t:1526922987424};\\\", \\\"{x:1176,y:752,t:1526922987639};\\\", \\\"{x:1176,y:753,t:1526922987647};\\\", \\\"{x:1179,y:756,t:1526922987657};\\\", \\\"{x:1183,y:761,t:1526922987676};\\\", \\\"{x:1188,y:768,t:1526922987693};\\\", \\\"{x:1192,y:775,t:1526922987708};\\\", \\\"{x:1195,y:780,t:1526922987725};\\\", \\\"{x:1197,y:783,t:1526922987741};\\\", \\\"{x:1197,y:786,t:1526922987757};\\\", \\\"{x:1199,y:790,t:1526922987775};\\\", \\\"{x:1200,y:793,t:1526922987791};\\\", \\\"{x:1200,y:797,t:1526922987808};\\\", \\\"{x:1201,y:800,t:1526922987825};\\\", \\\"{x:1201,y:806,t:1526922987842};\\\", \\\"{x:1204,y:810,t:1526922987858};\\\", \\\"{x:1205,y:816,t:1526922987875};\\\", \\\"{x:1207,y:821,t:1526922987892};\\\", \\\"{x:1207,y:827,t:1526922987907};\\\", \\\"{x:1207,y:828,t:1526922987924};\\\", \\\"{x:1208,y:830,t:1526922987942};\\\", \\\"{x:1209,y:832,t:1526922987959};\\\", \\\"{x:1209,y:833,t:1526922987975};\\\", \\\"{x:1209,y:834,t:1526922987991};\\\", \\\"{x:1211,y:834,t:1526922988103};\\\", \\\"{x:1215,y:834,t:1526922988124};\\\", \\\"{x:1222,y:835,t:1526922988142};\\\", \\\"{x:1237,y:837,t:1526922988158};\\\", \\\"{x:1251,y:839,t:1526922988174};\\\", \\\"{x:1267,y:841,t:1526922988191};\\\", \\\"{x:1278,y:843,t:1526922988208};\\\", \\\"{x:1286,y:844,t:1526922988225};\\\", \\\"{x:1291,y:845,t:1526922988242};\\\", \\\"{x:1293,y:846,t:1526922988258};\\\", \\\"{x:1295,y:847,t:1526922988274};\\\", \\\"{x:1299,y:849,t:1526922988292};\\\", \\\"{x:1306,y:852,t:1526922988309};\\\", \\\"{x:1313,y:854,t:1526922988324};\\\", \\\"{x:1319,y:856,t:1526922988341};\\\", \\\"{x:1327,y:860,t:1526922988358};\\\", \\\"{x:1329,y:861,t:1526922988374};\\\", \\\"{x:1336,y:865,t:1526922988392};\\\", \\\"{x:1340,y:868,t:1526922988408};\\\", \\\"{x:1342,y:868,t:1526922988425};\\\", \\\"{x:1344,y:870,t:1526922988442};\\\", \\\"{x:1345,y:870,t:1526922988463};\\\", \\\"{x:1347,y:870,t:1526922988487};\\\", \\\"{x:1348,y:870,t:1526922988511};\\\", \\\"{x:1351,y:870,t:1526922988525};\\\", \\\"{x:1354,y:870,t:1526922988541};\\\", \\\"{x:1356,y:871,t:1526922988559};\\\", \\\"{x:1359,y:872,t:1526922988575};\\\", \\\"{x:1361,y:872,t:1526922988592};\\\", \\\"{x:1362,y:872,t:1526922988623};\\\", \\\"{x:1364,y:872,t:1526922988711};\\\", \\\"{x:1365,y:872,t:1526922988743};\\\", \\\"{x:1367,y:873,t:1526922988759};\\\", \\\"{x:1369,y:875,t:1526922988775};\\\", \\\"{x:1369,y:876,t:1526922988792};\\\", \\\"{x:1370,y:877,t:1526922988809};\\\", \\\"{x:1372,y:879,t:1526922988826};\\\", \\\"{x:1373,y:880,t:1526922988842};\\\", \\\"{x:1375,y:882,t:1526922988859};\\\", \\\"{x:1375,y:883,t:1526922988919};\\\", \\\"{x:1376,y:885,t:1526922988927};\\\", \\\"{x:1376,y:886,t:1526922988941};\\\", \\\"{x:1377,y:886,t:1526922988959};\\\", \\\"{x:1378,y:889,t:1526922988975};\\\", \\\"{x:1380,y:891,t:1526922988991};\\\", \\\"{x:1380,y:892,t:1526922989023};\\\", \\\"{x:1380,y:893,t:1526922990023};\\\", \\\"{x:1381,y:893,t:1526922990031};\\\", \\\"{x:1383,y:893,t:1526922990043};\\\", \\\"{x:1394,y:895,t:1526922990060};\\\", \\\"{x:1406,y:897,t:1526922990076};\\\", \\\"{x:1416,y:900,t:1526922990092};\\\", \\\"{x:1420,y:900,t:1526922990110};\\\", \\\"{x:1424,y:901,t:1526922990126};\\\", \\\"{x:1427,y:901,t:1526922990142};\\\", \\\"{x:1428,y:901,t:1526922990159};\\\", \\\"{x:1431,y:901,t:1526922990176};\\\", \\\"{x:1433,y:901,t:1526922990193};\\\", \\\"{x:1434,y:901,t:1526922990215};\\\", \\\"{x:1436,y:901,t:1526922990230};\\\", \\\"{x:1438,y:901,t:1526922990243};\\\", \\\"{x:1444,y:902,t:1526922990259};\\\", \\\"{x:1448,y:903,t:1526922990276};\\\", \\\"{x:1451,y:903,t:1526922990292};\\\", \\\"{x:1452,y:903,t:1526922990311};\\\", \\\"{x:1452,y:904,t:1526922990326};\\\", \\\"{x:1454,y:904,t:1526922990407};\\\", \\\"{x:1455,y:904,t:1526922990431};\\\", \\\"{x:1456,y:904,t:1526922990591};\\\", \\\"{x:1456,y:903,t:1526922990623};\\\", \\\"{x:1456,y:901,t:1526922990631};\\\", \\\"{x:1456,y:900,t:1526922990670};\\\", \\\"{x:1456,y:898,t:1526922990686};\\\", \\\"{x:1456,y:896,t:1526922990711};\\\", \\\"{x:1455,y:895,t:1526922990727};\\\", \\\"{x:1454,y:894,t:1526922990751};\\\", \\\"{x:1454,y:892,t:1526922990800};\\\", \\\"{x:1453,y:891,t:1526922990816};\\\", \\\"{x:1452,y:890,t:1526922990827};\\\", \\\"{x:1451,y:889,t:1526922990919};\\\", \\\"{x:1450,y:888,t:1526922990943};\\\", \\\"{x:1449,y:888,t:1526922990959};\\\", \\\"{x:1448,y:888,t:1526922993223};\\\", \\\"{x:1450,y:888,t:1526922993311};\\\", \\\"{x:1454,y:888,t:1526922993328};\\\", \\\"{x:1457,y:889,t:1526922993345};\\\", \\\"{x:1459,y:889,t:1526922993361};\\\", \\\"{x:1461,y:889,t:1526922993378};\\\", \\\"{x:1466,y:890,t:1526922993394};\\\", \\\"{x:1471,y:892,t:1526922993411};\\\", \\\"{x:1482,y:895,t:1526922993428};\\\", \\\"{x:1497,y:898,t:1526922993445};\\\", \\\"{x:1513,y:903,t:1526922993461};\\\", \\\"{x:1531,y:907,t:1526922993478};\\\", \\\"{x:1562,y:912,t:1526922993495};\\\", \\\"{x:1578,y:914,t:1526922993511};\\\", \\\"{x:1597,y:918,t:1526922993527};\\\", \\\"{x:1606,y:920,t:1526922993545};\\\", \\\"{x:1625,y:924,t:1526922993560};\\\", \\\"{x:1635,y:926,t:1526922993578};\\\", \\\"{x:1649,y:928,t:1526922993594};\\\", \\\"{x:1656,y:928,t:1526922993611};\\\", \\\"{x:1662,y:928,t:1526922993627};\\\", \\\"{x:1667,y:928,t:1526922993644};\\\", \\\"{x:1670,y:928,t:1526922993660};\\\", \\\"{x:1672,y:928,t:1526922993679};\\\", \\\"{x:1671,y:928,t:1526922993799};\\\", \\\"{x:1670,y:928,t:1526922993811};\\\", \\\"{x:1661,y:928,t:1526922993828};\\\", \\\"{x:1651,y:929,t:1526922993845};\\\", \\\"{x:1636,y:929,t:1526922993862};\\\", \\\"{x:1617,y:930,t:1526922993877};\\\", \\\"{x:1601,y:930,t:1526922993895};\\\", \\\"{x:1597,y:930,t:1526922993912};\\\", \\\"{x:1596,y:930,t:1526922993928};\\\", \\\"{x:1595,y:932,t:1526922993951};\\\", \\\"{x:1594,y:932,t:1526922993982};\\\", \\\"{x:1592,y:932,t:1526922993995};\\\", \\\"{x:1591,y:933,t:1526922994012};\\\", \\\"{x:1588,y:933,t:1526922994028};\\\", \\\"{x:1588,y:934,t:1526922994045};\\\", \\\"{x:1587,y:934,t:1526922994062};\\\", \\\"{x:1585,y:934,t:1526922994078};\\\", \\\"{x:1584,y:934,t:1526922994095};\\\", \\\"{x:1582,y:934,t:1526922994111};\\\", \\\"{x:1581,y:934,t:1526922994152};\\\", \\\"{x:1579,y:935,t:1526922994162};\\\", \\\"{x:1578,y:936,t:1526922994216};\\\", \\\"{x:1577,y:936,t:1526922994232};\\\", \\\"{x:1576,y:936,t:1526922994246};\\\", \\\"{x:1575,y:936,t:1526922994263};\\\", \\\"{x:1574,y:936,t:1526922994278};\\\", \\\"{x:1572,y:937,t:1526922994592};\\\", \\\"{x:1569,y:937,t:1526922994600};\\\", \\\"{x:1566,y:937,t:1526922994613};\\\", \\\"{x:1563,y:937,t:1526922994630};\\\", \\\"{x:1559,y:937,t:1526922994645};\\\", \\\"{x:1554,y:937,t:1526922994663};\\\", \\\"{x:1551,y:937,t:1526922994680};\\\", \\\"{x:1549,y:937,t:1526922994696};\\\", \\\"{x:1548,y:937,t:1526922994712};\\\", \\\"{x:1547,y:937,t:1526922994758};\\\", \\\"{x:1544,y:939,t:1526922994767};\\\", \\\"{x:1541,y:939,t:1526922994783};\\\", \\\"{x:1538,y:939,t:1526922994794};\\\", \\\"{x:1534,y:939,t:1526922994812};\\\", \\\"{x:1530,y:939,t:1526922994829};\\\", \\\"{x:1525,y:939,t:1526922994845};\\\", \\\"{x:1524,y:939,t:1526922994862};\\\", \\\"{x:1523,y:939,t:1526922994879};\\\", \\\"{x:1521,y:939,t:1526922994911};\\\", \\\"{x:1520,y:939,t:1526922994918};\\\", \\\"{x:1519,y:939,t:1526922994929};\\\", \\\"{x:1516,y:939,t:1526922994944};\\\", \\\"{x:1514,y:939,t:1526922994962};\\\", \\\"{x:1513,y:939,t:1526922994979};\\\", \\\"{x:1513,y:937,t:1526922995152};\\\", \\\"{x:1513,y:936,t:1526922995162};\\\", \\\"{x:1514,y:933,t:1526922995180};\\\", \\\"{x:1515,y:932,t:1526922995196};\\\", \\\"{x:1517,y:931,t:1526922995212};\\\", \\\"{x:1517,y:929,t:1526922995229};\\\", \\\"{x:1520,y:927,t:1526922995246};\\\", \\\"{x:1521,y:926,t:1526922995262};\\\", \\\"{x:1522,y:925,t:1526922995279};\\\", \\\"{x:1523,y:924,t:1526922995296};\\\", \\\"{x:1523,y:923,t:1526922995312};\\\", \\\"{x:1524,y:923,t:1526922995329};\\\", \\\"{x:1525,y:921,t:1526922995346};\\\", \\\"{x:1526,y:919,t:1526922995362};\\\", \\\"{x:1527,y:919,t:1526922995379};\\\", \\\"{x:1528,y:919,t:1526922995815};\\\", \\\"{x:1528,y:920,t:1526922995829};\\\", \\\"{x:1529,y:920,t:1526922995846};\\\", \\\"{x:1530,y:924,t:1526922995863};\\\", \\\"{x:1532,y:928,t:1526922995879};\\\", \\\"{x:1535,y:932,t:1526922995896};\\\", \\\"{x:1538,y:934,t:1526922995912};\\\", \\\"{x:1540,y:937,t:1526922995929};\\\", \\\"{x:1542,y:940,t:1526922995946};\\\", \\\"{x:1544,y:942,t:1526922995962};\\\", \\\"{x:1545,y:944,t:1526922995979};\\\", \\\"{x:1545,y:946,t:1526922995996};\\\", \\\"{x:1547,y:948,t:1526922996013};\\\", \\\"{x:1548,y:949,t:1526922996029};\\\", \\\"{x:1549,y:952,t:1526922996159};\\\", \\\"{x:1549,y:954,t:1526922996215};\\\", \\\"{x:1549,y:955,t:1526922996280};\\\", \\\"{x:1549,y:957,t:1526922996310};\\\", \\\"{x:1549,y:958,t:1526922996319};\\\", \\\"{x:1549,y:959,t:1526922996343};\\\", \\\"{x:1549,y:960,t:1526922996366};\\\", \\\"{x:1549,y:962,t:1526922996391};\\\", \\\"{x:1548,y:962,t:1526922996423};\\\", \\\"{x:1547,y:963,t:1526922998231};\\\", \\\"{x:1546,y:963,t:1526922998270};\\\", \\\"{x:1544,y:963,t:1526922998303};\\\", \\\"{x:1543,y:963,t:1526922999215};\\\", \\\"{x:1542,y:963,t:1526922999255};\\\", \\\"{x:1541,y:963,t:1526922999279};\\\", \\\"{x:1536,y:963,t:1526922999503};\\\", \\\"{x:1532,y:963,t:1526922999514};\\\", \\\"{x:1519,y:963,t:1526922999531};\\\", \\\"{x:1508,y:963,t:1526922999548};\\\", \\\"{x:1495,y:961,t:1526922999565};\\\", \\\"{x:1484,y:959,t:1526922999581};\\\", \\\"{x:1478,y:956,t:1526922999598};\\\", \\\"{x:1460,y:955,t:1526922999615};\\\", \\\"{x:1449,y:954,t:1526922999631};\\\", \\\"{x:1440,y:953,t:1526922999648};\\\", \\\"{x:1433,y:953,t:1526922999665};\\\", \\\"{x:1429,y:953,t:1526922999681};\\\", \\\"{x:1428,y:953,t:1526922999698};\\\", \\\"{x:1427,y:953,t:1526922999715};\\\", \\\"{x:1426,y:953,t:1526922999735};\\\", \\\"{x:1425,y:953,t:1526922999748};\\\", \\\"{x:1424,y:952,t:1526922999764};\\\", \\\"{x:1422,y:952,t:1526922999781};\\\", \\\"{x:1420,y:951,t:1526922999798};\\\", \\\"{x:1409,y:951,t:1526922999815};\\\", \\\"{x:1403,y:951,t:1526922999831};\\\", \\\"{x:1397,y:950,t:1526922999848};\\\", \\\"{x:1392,y:950,t:1526922999865};\\\", \\\"{x:1389,y:950,t:1526922999881};\\\", \\\"{x:1383,y:948,t:1526922999898};\\\", \\\"{x:1380,y:948,t:1526922999915};\\\", \\\"{x:1370,y:947,t:1526922999931};\\\", \\\"{x:1362,y:946,t:1526922999948};\\\", \\\"{x:1360,y:946,t:1526922999965};\\\", \\\"{x:1359,y:946,t:1526923000367};\\\", \\\"{x:1356,y:946,t:1526923000382};\\\", \\\"{x:1355,y:946,t:1526923000406};\\\", \\\"{x:1354,y:946,t:1526923000414};\\\", \\\"{x:1353,y:946,t:1526923001079};\\\", \\\"{x:1353,y:947,t:1526923001095};\\\", \\\"{x:1353,y:948,t:1526923001118};\\\", \\\"{x:1353,y:949,t:1526923001134};\\\", \\\"{x:1353,y:950,t:1526923001151};\\\", \\\"{x:1353,y:951,t:1526923001262};\\\", \\\"{x:1352,y:952,t:1526923001455};\\\", \\\"{x:1352,y:953,t:1526923001466};\\\", \\\"{x:1352,y:954,t:1526923001482};\\\", \\\"{x:1352,y:955,t:1526923001499};\\\", \\\"{x:1352,y:956,t:1526923001515};\\\", \\\"{x:1350,y:958,t:1526923001532};\\\", \\\"{x:1350,y:959,t:1526923001549};\\\", \\\"{x:1349,y:960,t:1526923001566};\\\", \\\"{x:1349,y:961,t:1526923001591};\\\", \\\"{x:1348,y:962,t:1526923001606};\\\", \\\"{x:1347,y:963,t:1526923001623};\\\", \\\"{x:1346,y:963,t:1526923001910};\\\", \\\"{x:1345,y:958,t:1526923001927};\\\", \\\"{x:1345,y:955,t:1526923001935};\\\", \\\"{x:1344,y:953,t:1526923001949};\\\", \\\"{x:1344,y:948,t:1526923001966};\\\", \\\"{x:1339,y:941,t:1526923001983};\\\", \\\"{x:1338,y:935,t:1526923001999};\\\", \\\"{x:1337,y:932,t:1526923002016};\\\", \\\"{x:1337,y:927,t:1526923002033};\\\", \\\"{x:1337,y:924,t:1526923002049};\\\", \\\"{x:1337,y:921,t:1526923002066};\\\", \\\"{x:1337,y:919,t:1526923002083};\\\", \\\"{x:1337,y:917,t:1526923002099};\\\", \\\"{x:1337,y:914,t:1526923002116};\\\", \\\"{x:1337,y:911,t:1526923002132};\\\", \\\"{x:1337,y:908,t:1526923002149};\\\", \\\"{x:1337,y:902,t:1526923002166};\\\", \\\"{x:1337,y:893,t:1526923002183};\\\", \\\"{x:1337,y:883,t:1526923002199};\\\", \\\"{x:1339,y:873,t:1526923002216};\\\", \\\"{x:1341,y:858,t:1526923002233};\\\", \\\"{x:1344,y:841,t:1526923002249};\\\", \\\"{x:1345,y:830,t:1526923002267};\\\", \\\"{x:1345,y:816,t:1526923002283};\\\", \\\"{x:1345,y:802,t:1526923002299};\\\", \\\"{x:1345,y:791,t:1526923002316};\\\", \\\"{x:1345,y:783,t:1526923002333};\\\", \\\"{x:1344,y:778,t:1526923002349};\\\", \\\"{x:1342,y:775,t:1526923002366};\\\", \\\"{x:1340,y:771,t:1526923002383};\\\", \\\"{x:1340,y:770,t:1526923002399};\\\", \\\"{x:1340,y:768,t:1526923002423};\\\", \\\"{x:1340,y:766,t:1526923002560};\\\", \\\"{x:1340,y:765,t:1526923002567};\\\", \\\"{x:1339,y:763,t:1526923002583};\\\", \\\"{x:1338,y:762,t:1526923002599};\\\", \\\"{x:1338,y:760,t:1526923002616};\\\", \\\"{x:1338,y:758,t:1526923002633};\\\", \\\"{x:1338,y:757,t:1526923002650};\\\", \\\"{x:1338,y:756,t:1526923002694};\\\", \\\"{x:1338,y:755,t:1526923002734};\\\", \\\"{x:1335,y:755,t:1526923002750};\\\", \\\"{x:1327,y:760,t:1526923002766};\\\", \\\"{x:1299,y:777,t:1526923002783};\\\", \\\"{x:1277,y:782,t:1526923002800};\\\", \\\"{x:1252,y:792,t:1526923002816};\\\", \\\"{x:1228,y:797,t:1526923002833};\\\", \\\"{x:1213,y:800,t:1526923002850};\\\", \\\"{x:1191,y:803,t:1526923002866};\\\", \\\"{x:1130,y:803,t:1526923002883};\\\", \\\"{x:1058,y:795,t:1526923002900};\\\", \\\"{x:977,y:782,t:1526923002915};\\\", \\\"{x:905,y:762,t:1526923002933};\\\", \\\"{x:836,y:746,t:1526923002950};\\\", \\\"{x:797,y:735,t:1526923002966};\\\", \\\"{x:752,y:723,t:1526923002983};\\\", \\\"{x:738,y:717,t:1526923003000};\\\", \\\"{x:724,y:712,t:1526923003016};\\\", \\\"{x:714,y:707,t:1526923003033};\\\", \\\"{x:699,y:701,t:1526923003050};\\\", \\\"{x:685,y:696,t:1526923003066};\\\", \\\"{x:669,y:688,t:1526923003083};\\\", \\\"{x:660,y:681,t:1526923003100};\\\", \\\"{x:640,y:669,t:1526923003116};\\\", \\\"{x:617,y:659,t:1526923003133};\\\", \\\"{x:593,y:646,t:1526923003150};\\\", \\\"{x:550,y:632,t:1526923003166};\\\", \\\"{x:485,y:603,t:1526923003183};\\\", \\\"{x:448,y:592,t:1526923003201};\\\", \\\"{x:408,y:579,t:1526923003217};\\\", \\\"{x:359,y:561,t:1526923003241};\\\", \\\"{x:335,y:551,t:1526923003258};\\\", \\\"{x:320,y:545,t:1526923003275};\\\", \\\"{x:312,y:539,t:1526923003292};\\\", \\\"{x:305,y:534,t:1526923003308};\\\", \\\"{x:304,y:533,t:1526923003325};\\\", \\\"{x:303,y:532,t:1526923003342};\\\", \\\"{x:303,y:531,t:1526923003382};\\\", \\\"{x:303,y:530,t:1526923003406};\\\", \\\"{x:304,y:530,t:1526923003414};\\\", \\\"{x:304,y:529,t:1526923003438};\\\", \\\"{x:307,y:529,t:1526923003454};\\\", \\\"{x:310,y:529,t:1526923003462};\\\", \\\"{x:314,y:529,t:1526923003475};\\\", \\\"{x:320,y:529,t:1526923003491};\\\", \\\"{x:330,y:530,t:1526923003508};\\\", \\\"{x:335,y:531,t:1526923003525};\\\", \\\"{x:338,y:531,t:1526923003541};\\\", \\\"{x:338,y:532,t:1526923003559};\\\", \\\"{x:338,y:533,t:1526923003575};\\\", \\\"{x:335,y:536,t:1526923003591};\\\", \\\"{x:331,y:539,t:1526923003608};\\\", \\\"{x:323,y:544,t:1526923003625};\\\", \\\"{x:313,y:547,t:1526923003641};\\\", \\\"{x:303,y:552,t:1526923003658};\\\", \\\"{x:294,y:555,t:1526923003676};\\\", \\\"{x:282,y:558,t:1526923003691};\\\", \\\"{x:273,y:559,t:1526923003708};\\\", \\\"{x:270,y:560,t:1526923003725};\\\", \\\"{x:268,y:560,t:1526923003742};\\\", \\\"{x:267,y:560,t:1526923003759};\\\", \\\"{x:266,y:560,t:1526923003783};\\\", \\\"{x:265,y:560,t:1526923003807};\\\", \\\"{x:263,y:560,t:1526923003823};\\\", \\\"{x:262,y:560,t:1526923003839};\\\", \\\"{x:260,y:560,t:1526923003846};\\\", \\\"{x:259,y:560,t:1526923003859};\\\", \\\"{x:252,y:558,t:1526923003876};\\\", \\\"{x:246,y:557,t:1526923003892};\\\", \\\"{x:238,y:557,t:1526923003909};\\\", \\\"{x:230,y:555,t:1526923003927};\\\", \\\"{x:223,y:554,t:1526923003942};\\\", \\\"{x:218,y:553,t:1526923003959};\\\", \\\"{x:215,y:552,t:1526923003976};\\\", \\\"{x:212,y:551,t:1526923003992};\\\", \\\"{x:210,y:551,t:1526923004014};\\\", \\\"{x:209,y:551,t:1526923004026};\\\", \\\"{x:206,y:551,t:1526923004042};\\\", \\\"{x:200,y:551,t:1526923004059};\\\", \\\"{x:197,y:550,t:1526923004076};\\\", \\\"{x:194,y:548,t:1526923004093};\\\", \\\"{x:190,y:546,t:1526923004110};\\\", \\\"{x:188,y:544,t:1526923004126};\\\", \\\"{x:186,y:543,t:1526923004142};\\\", \\\"{x:184,y:542,t:1526923004158};\\\", \\\"{x:184,y:541,t:1526923004183};\\\", \\\"{x:183,y:540,t:1526923004192};\\\", \\\"{x:180,y:540,t:1526923004279};\\\", \\\"{x:176,y:540,t:1526923004292};\\\", \\\"{x:170,y:540,t:1526923004309};\\\", \\\"{x:165,y:540,t:1526923004326};\\\", \\\"{x:161,y:540,t:1526923004343};\\\", \\\"{x:158,y:541,t:1526923004359};\\\", \\\"{x:159,y:543,t:1526923004727};\\\", \\\"{x:161,y:544,t:1526923004742};\\\", \\\"{x:168,y:549,t:1526923004760};\\\", \\\"{x:179,y:558,t:1526923004777};\\\", \\\"{x:193,y:564,t:1526923004794};\\\", \\\"{x:207,y:570,t:1526923004810};\\\", \\\"{x:222,y:578,t:1526923004825};\\\", \\\"{x:244,y:581,t:1526923004843};\\\", \\\"{x:267,y:587,t:1526923004860};\\\", \\\"{x:298,y:593,t:1526923004876};\\\", \\\"{x:338,y:599,t:1526923004894};\\\", \\\"{x:416,y:609,t:1526923004910};\\\", \\\"{x:557,y:635,t:1526923004927};\\\", \\\"{x:666,y:655,t:1526923004943};\\\", \\\"{x:786,y:676,t:1526923004960};\\\", \\\"{x:886,y:703,t:1526923004977};\\\", \\\"{x:1003,y:728,t:1526923004994};\\\", \\\"{x:1109,y:744,t:1526923005011};\\\", \\\"{x:1206,y:760,t:1526923005027};\\\", \\\"{x:1299,y:775,t:1526923005043};\\\", \\\"{x:1363,y:785,t:1526923005061};\\\", \\\"{x:1403,y:792,t:1526923005077};\\\", \\\"{x:1430,y:796,t:1526923005094};\\\", \\\"{x:1453,y:796,t:1526923005110};\\\", \\\"{x:1487,y:796,t:1526923005127};\\\", \\\"{x:1500,y:796,t:1526923005145};\\\", \\\"{x:1506,y:796,t:1526923005161};\\\", \\\"{x:1510,y:795,t:1526923005177};\\\", \\\"{x:1514,y:794,t:1526923005194};\\\", \\\"{x:1516,y:791,t:1526923005210};\\\", \\\"{x:1520,y:789,t:1526923005227};\\\", \\\"{x:1521,y:788,t:1526923005244};\\\", \\\"{x:1523,y:785,t:1526923005261};\\\", \\\"{x:1523,y:779,t:1526923005277};\\\", \\\"{x:1523,y:777,t:1526923005294};\\\", \\\"{x:1519,y:777,t:1526923005311};\\\", \\\"{x:1516,y:777,t:1526923005327};\\\", \\\"{x:1512,y:777,t:1526923005344};\\\", \\\"{x:1505,y:777,t:1526923005362};\\\", \\\"{x:1500,y:780,t:1526923005379};\\\", \\\"{x:1489,y:780,t:1526923005394};\\\", \\\"{x:1478,y:781,t:1526923005411};\\\", \\\"{x:1465,y:783,t:1526923005428};\\\", \\\"{x:1453,y:783,t:1526923005444};\\\", \\\"{x:1446,y:784,t:1526923005461};\\\", \\\"{x:1442,y:784,t:1526923005478};\\\", \\\"{x:1438,y:784,t:1526923005494};\\\", \\\"{x:1437,y:784,t:1526923005512};\\\", \\\"{x:1436,y:784,t:1526923005535};\\\", \\\"{x:1436,y:783,t:1526923005574};\\\", \\\"{x:1436,y:781,t:1526923005599};\\\", \\\"{x:1436,y:780,t:1526923005615};\\\", \\\"{x:1435,y:780,t:1526923005628};\\\", \\\"{x:1435,y:779,t:1526923005645};\\\", \\\"{x:1435,y:778,t:1526923005662};\\\", \\\"{x:1435,y:777,t:1526923005679};\\\", \\\"{x:1435,y:776,t:1526923005703};\\\", \\\"{x:1435,y:774,t:1526923005712};\\\", \\\"{x:1435,y:772,t:1526923005728};\\\", \\\"{x:1436,y:770,t:1526923005745};\\\", \\\"{x:1437,y:768,t:1526923005762};\\\", \\\"{x:1439,y:767,t:1526923005783};\\\", \\\"{x:1439,y:766,t:1526923005795};\\\", \\\"{x:1442,y:764,t:1526923005812};\\\", \\\"{x:1447,y:761,t:1526923005829};\\\", \\\"{x:1450,y:760,t:1526923005846};\\\", \\\"{x:1453,y:759,t:1526923005862};\\\", \\\"{x:1461,y:756,t:1526923005878};\\\", \\\"{x:1463,y:756,t:1526923005895};\\\", \\\"{x:1464,y:756,t:1526923005912};\\\", \\\"{x:1466,y:754,t:1526923005929};\\\", \\\"{x:1468,y:754,t:1526923005947};\\\", \\\"{x:1470,y:754,t:1526923005962};\\\", \\\"{x:1474,y:754,t:1526923005979};\\\", \\\"{x:1477,y:754,t:1526923005996};\\\", \\\"{x:1485,y:754,t:1526923006012};\\\", \\\"{x:1491,y:754,t:1526923006029};\\\", \\\"{x:1499,y:753,t:1526923006046};\\\", \\\"{x:1505,y:753,t:1526923006063};\\\", \\\"{x:1520,y:750,t:1526923006079};\\\", \\\"{x:1524,y:749,t:1526923006096};\\\", \\\"{x:1527,y:749,t:1526923006113};\\\", \\\"{x:1529,y:748,t:1526923006130};\\\", \\\"{x:1530,y:748,t:1526923006146};\\\", \\\"{x:1533,y:746,t:1526923006399};\\\", \\\"{x:1534,y:746,t:1526923006413};\\\", \\\"{x:1540,y:743,t:1526923006431};\\\", \\\"{x:1544,y:743,t:1526923006446};\\\", \\\"{x:1547,y:741,t:1526923006463};\\\", \\\"{x:1550,y:739,t:1526923006480};\\\", \\\"{x:1553,y:737,t:1526923006498};\\\", \\\"{x:1555,y:734,t:1526923006514};\\\", \\\"{x:1560,y:730,t:1526923006530};\\\", \\\"{x:1563,y:729,t:1526923006548};\\\", \\\"{x:1568,y:725,t:1526923006564};\\\", \\\"{x:1572,y:721,t:1526923006580};\\\", \\\"{x:1575,y:719,t:1526923006598};\\\", \\\"{x:1578,y:717,t:1526923006614};\\\", \\\"{x:1580,y:715,t:1526923006630};\\\", \\\"{x:1585,y:712,t:1526923006647};\\\", \\\"{x:1587,y:711,t:1526923006671};\\\", \\\"{x:1591,y:709,t:1526923006687};\\\", \\\"{x:1592,y:708,t:1526923006703};\\\", \\\"{x:1593,y:708,t:1526923006714};\\\", \\\"{x:1597,y:706,t:1526923006732};\\\", \\\"{x:1599,y:705,t:1526923006747};\\\", \\\"{x:1603,y:703,t:1526923006764};\\\", \\\"{x:1604,y:702,t:1526923006783};\\\", \\\"{x:1605,y:702,t:1526923006910};\\\", \\\"{x:1607,y:701,t:1526923006935};\\\", \\\"{x:1609,y:700,t:1526923006951};\\\", \\\"{x:1610,y:699,t:1526923006965};\\\", \\\"{x:1610,y:698,t:1526923006980};\\\", \\\"{x:1613,y:697,t:1526923006998};\\\", \\\"{x:1615,y:695,t:1526923007014};\\\", \\\"{x:1616,y:694,t:1526923007031};\\\", \\\"{x:1617,y:694,t:1526923007087};\\\", \\\"{x:1618,y:694,t:1526923007190};\\\", \\\"{x:1618,y:695,t:1526923007230};\\\", \\\"{x:1618,y:697,t:1526923007254};\\\", \\\"{x:1618,y:700,t:1526923007265};\\\", \\\"{x:1618,y:702,t:1526923007283};\\\", \\\"{x:1618,y:706,t:1526923007299};\\\", \\\"{x:1618,y:711,t:1526923007316};\\\", \\\"{x:1620,y:714,t:1526923007332};\\\", \\\"{x:1623,y:721,t:1526923007349};\\\", \\\"{x:1627,y:729,t:1526923007366};\\\", \\\"{x:1631,y:735,t:1526923007382};\\\", \\\"{x:1633,y:748,t:1526923007399};\\\", \\\"{x:1640,y:754,t:1526923007417};\\\", \\\"{x:1644,y:761,t:1526923007433};\\\", \\\"{x:1648,y:766,t:1526923007449};\\\", \\\"{x:1655,y:776,t:1526923007466};\\\", \\\"{x:1659,y:783,t:1526923007484};\\\", \\\"{x:1664,y:790,t:1526923007499};\\\", \\\"{x:1668,y:795,t:1526923007516};\\\", \\\"{x:1672,y:803,t:1526923007534};\\\", \\\"{x:1676,y:806,t:1526923007549};\\\", \\\"{x:1682,y:811,t:1526923007566};\\\", \\\"{x:1685,y:815,t:1526923007583};\\\", \\\"{x:1686,y:817,t:1526923007599};\\\", \\\"{x:1688,y:818,t:1526923007616};\\\", \\\"{x:1691,y:820,t:1526923007633};\\\", \\\"{x:1695,y:824,t:1526923007651};\\\", \\\"{x:1698,y:825,t:1526923007667};\\\", \\\"{x:1701,y:827,t:1526923007683};\\\", \\\"{x:1702,y:829,t:1526923007700};\\\", \\\"{x:1704,y:830,t:1526923007717};\\\", \\\"{x:1706,y:831,t:1526923007733};\\\", \\\"{x:1707,y:831,t:1526923007751};\\\", \\\"{x:1711,y:832,t:1526923007766};\\\", \\\"{x:1715,y:833,t:1526923007784};\\\", \\\"{x:1722,y:833,t:1526923007801};\\\", \\\"{x:1727,y:833,t:1526923007817};\\\", \\\"{x:1732,y:833,t:1526923007833};\\\", \\\"{x:1737,y:833,t:1526923007851};\\\", \\\"{x:1740,y:833,t:1526923007868};\\\", \\\"{x:1741,y:833,t:1526923007883};\\\", \\\"{x:1743,y:833,t:1526923007900};\\\", \\\"{x:1746,y:833,t:1526923007934};\\\", \\\"{x:1747,y:833,t:1526923007950};\\\", \\\"{x:1746,y:833,t:1526923008094};\\\", \\\"{x:1739,y:834,t:1526923008102};\\\", \\\"{x:1729,y:834,t:1526923008117};\\\", \\\"{x:1710,y:835,t:1526923008135};\\\", \\\"{x:1687,y:835,t:1526923008151};\\\", \\\"{x:1675,y:836,t:1526923008168};\\\", \\\"{x:1663,y:836,t:1526923008184};\\\", \\\"{x:1659,y:836,t:1526923008201};\\\", \\\"{x:1660,y:836,t:1526923008350};\\\", \\\"{x:1661,y:836,t:1526923008359};\\\", \\\"{x:1662,y:836,t:1526923008527};\\\", \\\"{x:1663,y:835,t:1526923008535};\\\", \\\"{x:1664,y:834,t:1526923008552};\\\", \\\"{x:1667,y:834,t:1526923008568};\\\", \\\"{x:1670,y:832,t:1526923008585};\\\", \\\"{x:1672,y:831,t:1526923008602};\\\", \\\"{x:1676,y:829,t:1526923008619};\\\", \\\"{x:1679,y:828,t:1526923008635};\\\", \\\"{x:1683,y:827,t:1526923008653};\\\", \\\"{x:1689,y:826,t:1526923008669};\\\", \\\"{x:1693,y:824,t:1526923008685};\\\", \\\"{x:1696,y:824,t:1526923008702};\\\", \\\"{x:1694,y:824,t:1526923009175};\\\", \\\"{x:1693,y:825,t:1526923009223};\\\", \\\"{x:1692,y:825,t:1526923009237};\\\", \\\"{x:1691,y:826,t:1526923009253};\\\", \\\"{x:1690,y:826,t:1526923009279};\\\", \\\"{x:1689,y:827,t:1526923009287};\\\", \\\"{x:1688,y:827,t:1526923009304};\\\", \\\"{x:1687,y:827,t:1526923009350};\\\", \\\"{x:1686,y:827,t:1526923009383};\\\", \\\"{x:1684,y:828,t:1526923009404};\\\", \\\"{x:1682,y:829,t:1526923009421};\\\", \\\"{x:1681,y:829,t:1526923009437};\\\", \\\"{x:1680,y:830,t:1526923009511};\\\", \\\"{x:1679,y:830,t:1526923009526};\\\", \\\"{x:1678,y:830,t:1526923009538};\\\", \\\"{x:1677,y:830,t:1526923009554};\\\", \\\"{x:1676,y:830,t:1526923009572};\\\", \\\"{x:1675,y:830,t:1526923009623};\\\", \\\"{x:1673,y:830,t:1526923009694};\\\", \\\"{x:1672,y:830,t:1526923009705};\\\", \\\"{x:1670,y:830,t:1526923009721};\\\", \\\"{x:1668,y:830,t:1526923009751};\\\", \\\"{x:1667,y:830,t:1526923009758};\\\", \\\"{x:1665,y:830,t:1526923009774};\\\", \\\"{x:1662,y:831,t:1526923009789};\\\", \\\"{x:1659,y:831,t:1526923009805};\\\", \\\"{x:1657,y:831,t:1526923009822};\\\", \\\"{x:1654,y:831,t:1526923009838};\\\", \\\"{x:1653,y:831,t:1526923009855};\\\", \\\"{x:1651,y:831,t:1526923009872};\\\", \\\"{x:1650,y:832,t:1526923009888};\\\", \\\"{x:1649,y:832,t:1526923009906};\\\", \\\"{x:1646,y:832,t:1526923009922};\\\", \\\"{x:1644,y:832,t:1526923009938};\\\", \\\"{x:1641,y:832,t:1526923009956};\\\", \\\"{x:1639,y:832,t:1526923009972};\\\", \\\"{x:1637,y:832,t:1526923009988};\\\", \\\"{x:1636,y:832,t:1526923010005};\\\", \\\"{x:1635,y:832,t:1526923010022};\\\", \\\"{x:1634,y:833,t:1526923010040};\\\", \\\"{x:1634,y:834,t:1526923010056};\\\", \\\"{x:1632,y:834,t:1526923010078};\\\", \\\"{x:1629,y:834,t:1526923010089};\\\", \\\"{x:1623,y:833,t:1526923010106};\\\", \\\"{x:1618,y:831,t:1526923010122};\\\", \\\"{x:1615,y:829,t:1526923010139};\\\", \\\"{x:1611,y:828,t:1526923010156};\\\", \\\"{x:1609,y:827,t:1526923010172};\\\", \\\"{x:1607,y:825,t:1526923010189};\\\", \\\"{x:1606,y:825,t:1526923010207};\\\", \\\"{x:1605,y:825,t:1526923010222};\\\", \\\"{x:1604,y:825,t:1526923010326};\\\", \\\"{x:1603,y:825,t:1526923010342};\\\", \\\"{x:1602,y:825,t:1526923010357};\\\", \\\"{x:1593,y:825,t:1526923010373};\\\", \\\"{x:1585,y:825,t:1526923010389};\\\", \\\"{x:1564,y:825,t:1526923010406};\\\", \\\"{x:1547,y:825,t:1526923010424};\\\", \\\"{x:1530,y:825,t:1526923010441};\\\", \\\"{x:1520,y:825,t:1526923010457};\\\", \\\"{x:1505,y:825,t:1526923010473};\\\", \\\"{x:1492,y:827,t:1526923010490};\\\", \\\"{x:1484,y:828,t:1526923010507};\\\", \\\"{x:1477,y:829,t:1526923010523};\\\", \\\"{x:1472,y:830,t:1526923010540};\\\", \\\"{x:1470,y:830,t:1526923010556};\\\", \\\"{x:1469,y:830,t:1526923010574};\\\", \\\"{x:1467,y:830,t:1526923010590};\\\", \\\"{x:1465,y:830,t:1526923010607};\\\", \\\"{x:1462,y:830,t:1526923010624};\\\", \\\"{x:1460,y:831,t:1526923010641};\\\", \\\"{x:1457,y:831,t:1526923010657};\\\", \\\"{x:1454,y:832,t:1526923010674};\\\", \\\"{x:1453,y:832,t:1526923010690};\\\", \\\"{x:1451,y:832,t:1526923010708};\\\", \\\"{x:1449,y:833,t:1526923010724};\\\", \\\"{x:1446,y:833,t:1526923010740};\\\", \\\"{x:1444,y:833,t:1526923010758};\\\", \\\"{x:1441,y:835,t:1526923010775};\\\", \\\"{x:1439,y:835,t:1526923010791};\\\", \\\"{x:1438,y:835,t:1526923010808};\\\", \\\"{x:1437,y:835,t:1526923010831};\\\", \\\"{x:1436,y:835,t:1526923010847};\\\", \\\"{x:1435,y:835,t:1526923010862};\\\", \\\"{x:1434,y:835,t:1526923010895};\\\", \\\"{x:1432,y:835,t:1526923010911};\\\", \\\"{x:1431,y:835,t:1526923010974};\\\", \\\"{x:1429,y:835,t:1526923010991};\\\", \\\"{x:1428,y:836,t:1526923011008};\\\", \\\"{x:1426,y:837,t:1526923012542};\\\", \\\"{x:1425,y:837,t:1526923012791};\\\", \\\"{x:1424,y:838,t:1526923012799};\\\", \\\"{x:1423,y:838,t:1526923012822};\\\", \\\"{x:1423,y:839,t:1526923012838};\\\", \\\"{x:1422,y:839,t:1526923012918};\\\", \\\"{x:1420,y:839,t:1526923012934};\\\", \\\"{x:1419,y:839,t:1526923012966};\\\", \\\"{x:1417,y:840,t:1526923013095};\\\", \\\"{x:1416,y:840,t:1526923013182};\\\", \\\"{x:1415,y:840,t:1526923013206};\\\", \\\"{x:1414,y:841,t:1526923013942};\\\", \\\"{x:1413,y:842,t:1526923014350};\\\", \\\"{x:1413,y:843,t:1526923014366};\\\", \\\"{x:1411,y:844,t:1526923014390};\\\", \\\"{x:1410,y:844,t:1526923014470};\\\", \\\"{x:1408,y:845,t:1526923014711};\\\", \\\"{x:1407,y:846,t:1526923014727};\\\", \\\"{x:1406,y:846,t:1526923014791};\\\", \\\"{x:1405,y:846,t:1526923014911};\\\", \\\"{x:1404,y:846,t:1526923014934};\\\", \\\"{x:1404,y:847,t:1526923014968};\\\", \\\"{x:1402,y:848,t:1526923017527};\\\", \\\"{x:1401,y:848,t:1526923017540};\\\", \\\"{x:1401,y:849,t:1526923017557};\\\", \\\"{x:1398,y:849,t:1526923017573};\\\", \\\"{x:1397,y:849,t:1526923017591};\\\", \\\"{x:1394,y:849,t:1526923018198};\\\", \\\"{x:1392,y:849,t:1526923018209};\\\", \\\"{x:1389,y:850,t:1526923018225};\\\", \\\"{x:1389,y:851,t:1526923018278};\\\", \\\"{x:1388,y:851,t:1526923018292};\\\", \\\"{x:1387,y:851,t:1526923018471};\\\", \\\"{x:1386,y:851,t:1526923020924};\\\", \\\"{x:1381,y:851,t:1526923020937};\\\", \\\"{x:1371,y:851,t:1526923020954};\\\", \\\"{x:1356,y:851,t:1526923020971};\\\", \\\"{x:1339,y:855,t:1526923020988};\\\", \\\"{x:1323,y:856,t:1526923021004};\\\", \\\"{x:1295,y:860,t:1526923021020};\\\", \\\"{x:1263,y:860,t:1526923021038};\\\", \\\"{x:1238,y:861,t:1526923021054};\\\", \\\"{x:1209,y:861,t:1526923021071};\\\", \\\"{x:1157,y:857,t:1526923021087};\\\", \\\"{x:1116,y:848,t:1526923021104};\\\", \\\"{x:1099,y:843,t:1526923021121};\\\", \\\"{x:1077,y:840,t:1526923021138};\\\", \\\"{x:1070,y:838,t:1526923021155};\\\", \\\"{x:1061,y:838,t:1526923021171};\\\", \\\"{x:1050,y:838,t:1526923021187};\\\", \\\"{x:1037,y:838,t:1526923021204};\\\", \\\"{x:1022,y:838,t:1526923021221};\\\", \\\"{x:995,y:838,t:1526923021238};\\\", \\\"{x:971,y:838,t:1526923021254};\\\", \\\"{x:938,y:835,t:1526923021272};\\\", \\\"{x:896,y:829,t:1526923021288};\\\", \\\"{x:854,y:822,t:1526923021305};\\\", \\\"{x:830,y:819,t:1526923021322};\\\", \\\"{x:787,y:817,t:1526923021338};\\\", \\\"{x:746,y:811,t:1526923021354};\\\", \\\"{x:687,y:804,t:1526923021371};\\\", \\\"{x:614,y:790,t:1526923021388};\\\", \\\"{x:585,y:789,t:1526923021405};\\\", \\\"{x:558,y:789,t:1526923021421};\\\", \\\"{x:543,y:785,t:1526923021439};\\\", \\\"{x:526,y:781,t:1526923021455};\\\", \\\"{x:506,y:779,t:1526923021471};\\\", \\\"{x:488,y:776,t:1526923021489};\\\", \\\"{x:470,y:774,t:1526923021505};\\\", \\\"{x:458,y:774,t:1526923021522};\\\", \\\"{x:443,y:771,t:1526923021539};\\\", \\\"{x:436,y:771,t:1526923021556};\\\", \\\"{x:431,y:769,t:1526923021572};\\\", \\\"{x:424,y:767,t:1526923021589};\\\", \\\"{x:423,y:766,t:1526923021606};\\\", \\\"{x:421,y:765,t:1526923021660};\\\", \\\"{x:420,y:764,t:1526923021673};\\\", \\\"{x:419,y:762,t:1526923021689};\\\", \\\"{x:419,y:758,t:1526923021706};\\\", \\\"{x:420,y:755,t:1526923021722};\\\", \\\"{x:422,y:750,t:1526923021738};\\\", \\\"{x:426,y:747,t:1526923021756};\\\", \\\"{x:433,y:743,t:1526923021772};\\\", \\\"{x:438,y:741,t:1526923021790};\\\", \\\"{x:443,y:740,t:1526923021806};\\\", \\\"{x:445,y:737,t:1526923021823};\\\", \\\"{x:450,y:736,t:1526923021840};\\\", \\\"{x:451,y:736,t:1526923021856};\\\", \\\"{x:452,y:736,t:1526923021875};\\\", \\\"{x:454,y:736,t:1526923021892};\\\", \\\"{x:459,y:736,t:1526923021908};\\\", \\\"{x:461,y:736,t:1526923021925};\\\", \\\"{x:465,y:737,t:1526923021941};\\\", \\\"{x:467,y:738,t:1526923021959};\\\", \\\"{x:469,y:738,t:1526923021976};\\\", \\\"{x:469,y:739,t:1526923021997};\\\", \\\"{x:471,y:739,t:1526923022020};\\\", \\\"{x:471,y:740,t:1526923022028};\\\", \\\"{x:472,y:741,t:1526923022044};\\\", \\\"{x:474,y:741,t:1526923022068};\\\", \\\"{x:476,y:741,t:1526923022117};\\\", \\\"{x:476,y:742,t:1526923022197};\\\" ] }, { \\\"rt\\\": 59052, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 513845, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X -M -M -B -B -B -F -F -F -F -F -F -X -E -11 AM-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:743,t:1526923029996};\\\", \\\"{x:476,y:744,t:1526923030020};\\\", \\\"{x:476,y:745,t:1526923030180};\\\", \\\"{x:476,y:746,t:1526923030324};\\\", \\\"{x:476,y:747,t:1526923030338};\\\", \\\"{x:475,y:747,t:1526923030356};\\\", \\\"{x:474,y:748,t:1526923030540};\\\", \\\"{x:473,y:748,t:1526923030556};\\\", \\\"{x:472,y:749,t:1526923031020};\\\", \\\"{x:472,y:750,t:1526923031989};\\\", \\\"{x:471,y:751,t:1526923032003};\\\", \\\"{x:470,y:753,t:1526923032020};\\\", \\\"{x:470,y:757,t:1526923032037};\\\", \\\"{x:471,y:759,t:1526923032052};\\\", \\\"{x:475,y:760,t:1526923032069};\\\", \\\"{x:483,y:765,t:1526923032087};\\\", \\\"{x:500,y:771,t:1526923032103};\\\", \\\"{x:522,y:777,t:1526923032119};\\\", \\\"{x:546,y:783,t:1526923032137};\\\", \\\"{x:566,y:788,t:1526923032154};\\\", \\\"{x:605,y:799,t:1526923032171};\\\", \\\"{x:647,y:810,t:1526923032187};\\\", \\\"{x:720,y:832,t:1526923032204};\\\", \\\"{x:745,y:842,t:1526923032221};\\\", \\\"{x:777,y:849,t:1526923032237};\\\", \\\"{x:823,y:866,t:1526923032254};\\\", \\\"{x:860,y:877,t:1526923032271};\\\", \\\"{x:886,y:885,t:1526923032287};\\\", \\\"{x:918,y:898,t:1526923032304};\\\", \\\"{x:931,y:902,t:1526923032321};\\\", \\\"{x:955,y:912,t:1526923032337};\\\", \\\"{x:986,y:921,t:1526923032354};\\\", \\\"{x:1021,y:929,t:1526923032371};\\\", \\\"{x:1055,y:938,t:1526923032387};\\\", \\\"{x:1095,y:951,t:1526923032404};\\\", \\\"{x:1143,y:967,t:1526923032421};\\\", \\\"{x:1176,y:974,t:1526923032437};\\\", \\\"{x:1206,y:985,t:1526923032454};\\\", \\\"{x:1229,y:991,t:1526923032471};\\\", \\\"{x:1243,y:997,t:1526923032488};\\\", \\\"{x:1260,y:1002,t:1526923032504};\\\", \\\"{x:1275,y:1002,t:1526923032521};\\\", \\\"{x:1283,y:1002,t:1526923032538};\\\", \\\"{x:1301,y:1009,t:1526923032554};\\\", \\\"{x:1309,y:1010,t:1526923032572};\\\", \\\"{x:1323,y:1011,t:1526923032588};\\\", \\\"{x:1333,y:1012,t:1526923032604};\\\", \\\"{x:1341,y:1015,t:1526923032621};\\\", \\\"{x:1351,y:1014,t:1526923032638};\\\", \\\"{x:1354,y:1014,t:1526923032655};\\\", \\\"{x:1358,y:1013,t:1526923032672};\\\", \\\"{x:1360,y:1013,t:1526923032689};\\\", \\\"{x:1361,y:1013,t:1526923032704};\\\", \\\"{x:1361,y:1012,t:1526923032721};\\\", \\\"{x:1364,y:1011,t:1526923032739};\\\", \\\"{x:1365,y:1010,t:1526923032754};\\\", \\\"{x:1367,y:1009,t:1526923032772};\\\", \\\"{x:1368,y:1008,t:1526923032788};\\\", \\\"{x:1369,y:1007,t:1526923032805};\\\", \\\"{x:1370,y:1007,t:1526923032821};\\\", \\\"{x:1372,y:1005,t:1526923032838};\\\", \\\"{x:1374,y:1004,t:1526923032855};\\\", \\\"{x:1375,y:1002,t:1526923032871};\\\", \\\"{x:1378,y:1000,t:1526923032888};\\\", \\\"{x:1382,y:997,t:1526923032905};\\\", \\\"{x:1386,y:995,t:1526923032921};\\\", \\\"{x:1391,y:994,t:1526923032938};\\\", \\\"{x:1395,y:993,t:1526923032955};\\\", \\\"{x:1401,y:991,t:1526923032971};\\\", \\\"{x:1409,y:989,t:1526923032988};\\\", \\\"{x:1414,y:987,t:1526923033005};\\\", \\\"{x:1419,y:987,t:1526923033021};\\\", \\\"{x:1427,y:987,t:1526923033038};\\\", \\\"{x:1434,y:986,t:1526923033056};\\\", \\\"{x:1441,y:986,t:1526923033071};\\\", \\\"{x:1443,y:986,t:1526923033089};\\\", \\\"{x:1447,y:986,t:1526923033105};\\\", \\\"{x:1450,y:986,t:1526923033121};\\\", \\\"{x:1455,y:986,t:1526923033138};\\\", \\\"{x:1460,y:985,t:1526923033155};\\\", \\\"{x:1464,y:983,t:1526923033171};\\\", \\\"{x:1471,y:983,t:1526923033188};\\\", \\\"{x:1474,y:982,t:1526923033205};\\\", \\\"{x:1475,y:981,t:1526923033223};\\\", \\\"{x:1477,y:980,t:1526923033238};\\\", \\\"{x:1477,y:979,t:1526923033268};\\\", \\\"{x:1479,y:978,t:1526923033284};\\\", \\\"{x:1480,y:977,t:1526923033308};\\\", \\\"{x:1481,y:976,t:1526923033322};\\\", \\\"{x:1482,y:975,t:1526923033389};\\\", \\\"{x:1482,y:974,t:1526923033428};\\\", \\\"{x:1483,y:973,t:1526923033444};\\\", \\\"{x:1483,y:969,t:1526923033468};\\\", \\\"{x:1484,y:969,t:1526923033484};\\\", \\\"{x:1484,y:968,t:1526923033492};\\\", \\\"{x:1484,y:967,t:1526923033505};\\\", \\\"{x:1484,y:966,t:1526923033522};\\\", \\\"{x:1484,y:964,t:1526923033538};\\\", \\\"{x:1485,y:963,t:1526923033564};\\\", \\\"{x:1485,y:961,t:1526923035036};\\\", \\\"{x:1485,y:960,t:1526923035052};\\\", \\\"{x:1485,y:958,t:1526923035076};\\\", \\\"{x:1485,y:957,t:1526923035092};\\\", \\\"{x:1485,y:955,t:1526923035148};\\\", \\\"{x:1486,y:954,t:1526923035180};\\\", \\\"{x:1486,y:953,t:1526923035196};\\\", \\\"{x:1487,y:951,t:1526923035208};\\\", \\\"{x:1488,y:949,t:1526923035299};\\\", \\\"{x:1488,y:948,t:1526923035388};\\\", \\\"{x:1488,y:947,t:1526923035420};\\\", \\\"{x:1488,y:946,t:1526923035436};\\\", \\\"{x:1488,y:945,t:1526923035460};\\\", \\\"{x:1488,y:944,t:1526923035517};\\\", \\\"{x:1488,y:943,t:1526923035533};\\\", \\\"{x:1488,y:941,t:1526923035557};\\\", \\\"{x:1487,y:939,t:1526923035575};\\\", \\\"{x:1487,y:936,t:1526923035591};\\\", \\\"{x:1487,y:934,t:1526923035608};\\\", \\\"{x:1487,y:933,t:1526923035625};\\\", \\\"{x:1487,y:932,t:1526923035641};\\\", \\\"{x:1486,y:929,t:1526923035657};\\\", \\\"{x:1485,y:924,t:1526923035675};\\\", \\\"{x:1484,y:922,t:1526923035691};\\\", \\\"{x:1483,y:919,t:1526923035708};\\\", \\\"{x:1483,y:915,t:1526923035725};\\\", \\\"{x:1483,y:912,t:1526923035742};\\\", \\\"{x:1481,y:907,t:1526923035758};\\\", \\\"{x:1481,y:904,t:1526923035775};\\\", \\\"{x:1480,y:903,t:1526923035792};\\\", \\\"{x:1479,y:899,t:1526923035809};\\\", \\\"{x:1478,y:897,t:1526923035825};\\\", \\\"{x:1478,y:893,t:1526923035842};\\\", \\\"{x:1477,y:890,t:1526923035858};\\\", \\\"{x:1477,y:887,t:1526923035875};\\\", \\\"{x:1477,y:883,t:1526923035892};\\\", \\\"{x:1477,y:881,t:1526923035908};\\\", \\\"{x:1477,y:876,t:1526923035925};\\\", \\\"{x:1477,y:873,t:1526923035941};\\\", \\\"{x:1477,y:870,t:1526923035958};\\\", \\\"{x:1477,y:866,t:1526923035975};\\\", \\\"{x:1477,y:859,t:1526923035992};\\\", \\\"{x:1478,y:854,t:1526923036008};\\\", \\\"{x:1479,y:850,t:1526923036025};\\\", \\\"{x:1481,y:846,t:1526923036042};\\\", \\\"{x:1481,y:845,t:1526923036059};\\\", \\\"{x:1482,y:843,t:1526923036077};\\\", \\\"{x:1483,y:843,t:1526923036092};\\\", \\\"{x:1483,y:842,t:1526923036109};\\\", \\\"{x:1483,y:841,t:1526923036125};\\\", \\\"{x:1484,y:839,t:1526923036142};\\\", \\\"{x:1485,y:838,t:1526923036159};\\\", \\\"{x:1485,y:836,t:1526923036182};\\\", \\\"{x:1486,y:834,t:1526923036197};\\\", \\\"{x:1486,y:832,t:1526923036215};\\\", \\\"{x:1487,y:830,t:1526923036241};\\\", \\\"{x:1487,y:829,t:1526923036258};\\\", \\\"{x:1487,y:828,t:1526923036274};\\\", \\\"{x:1487,y:827,t:1526923036292};\\\", \\\"{x:1487,y:826,t:1526923036308};\\\", \\\"{x:1487,y:825,t:1526923036324};\\\", \\\"{x:1488,y:824,t:1526923036348};\\\", \\\"{x:1488,y:823,t:1526923036373};\\\", \\\"{x:1488,y:822,t:1526923036405};\\\", \\\"{x:1488,y:821,t:1526923036429};\\\", \\\"{x:1488,y:820,t:1526923036453};\\\", \\\"{x:1488,y:819,t:1526923036461};\\\", \\\"{x:1488,y:818,t:1526923036484};\\\", \\\"{x:1488,y:817,t:1526923036493};\\\", \\\"{x:1488,y:816,t:1526923036508};\\\", \\\"{x:1488,y:815,t:1526923036557};\\\", \\\"{x:1488,y:814,t:1526923036574};\\\", \\\"{x:1488,y:813,t:1526923036597};\\\", \\\"{x:1487,y:814,t:1526923036837};\\\", \\\"{x:1487,y:816,t:1526923036845};\\\", \\\"{x:1486,y:817,t:1526923036858};\\\", \\\"{x:1485,y:818,t:1526923036875};\\\", \\\"{x:1484,y:820,t:1526923036892};\\\", \\\"{x:1482,y:820,t:1526923036908};\\\", \\\"{x:1482,y:821,t:1526923036925};\\\", \\\"{x:1481,y:822,t:1526923036943};\\\", \\\"{x:1480,y:822,t:1526923036989};\\\", \\\"{x:1479,y:823,t:1526923039476};\\\", \\\"{x:1478,y:823,t:1526923039491};\\\", \\\"{x:1476,y:824,t:1526923039516};\\\", \\\"{x:1475,y:825,t:1526923039527};\\\", \\\"{x:1474,y:826,t:1526923039544};\\\", \\\"{x:1473,y:828,t:1526923039561};\\\", \\\"{x:1472,y:828,t:1526923039578};\\\", \\\"{x:1471,y:829,t:1526923039594};\\\", \\\"{x:1470,y:830,t:1526923039612};\\\", \\\"{x:1468,y:830,t:1526923039628};\\\", \\\"{x:1466,y:832,t:1526923039644};\\\", \\\"{x:1465,y:833,t:1526923039662};\\\", \\\"{x:1462,y:834,t:1526923039679};\\\", \\\"{x:1461,y:835,t:1526923039695};\\\", \\\"{x:1459,y:838,t:1526923039712};\\\", \\\"{x:1455,y:840,t:1526923039728};\\\", \\\"{x:1452,y:842,t:1526923039745};\\\", \\\"{x:1451,y:842,t:1526923039761};\\\", \\\"{x:1448,y:845,t:1526923039778};\\\", \\\"{x:1448,y:846,t:1526923039794};\\\", \\\"{x:1446,y:850,t:1526923039811};\\\", \\\"{x:1445,y:850,t:1526923039828};\\\", \\\"{x:1438,y:853,t:1526923039844};\\\", \\\"{x:1429,y:858,t:1526923039861};\\\", \\\"{x:1423,y:861,t:1526923039878};\\\", \\\"{x:1419,y:863,t:1526923039895};\\\", \\\"{x:1416,y:865,t:1526923039912};\\\", \\\"{x:1414,y:865,t:1526923039928};\\\", \\\"{x:1410,y:867,t:1526923039946};\\\", \\\"{x:1408,y:869,t:1526923039961};\\\", \\\"{x:1405,y:871,t:1526923039978};\\\", \\\"{x:1399,y:874,t:1526923039996};\\\", \\\"{x:1395,y:877,t:1526923040012};\\\", \\\"{x:1390,y:880,t:1526923040028};\\\", \\\"{x:1387,y:881,t:1526923040045};\\\", \\\"{x:1386,y:882,t:1526923040061};\\\", \\\"{x:1384,y:883,t:1526923040084};\\\", \\\"{x:1384,y:884,t:1526923040096};\\\", \\\"{x:1381,y:885,t:1526923040111};\\\", \\\"{x:1379,y:888,t:1526923040128};\\\", \\\"{x:1377,y:890,t:1526923040145};\\\", \\\"{x:1373,y:894,t:1526923040161};\\\", \\\"{x:1371,y:895,t:1526923040179};\\\", \\\"{x:1370,y:896,t:1526923040220};\\\", \\\"{x:1370,y:897,t:1526923040260};\\\", \\\"{x:1369,y:897,t:1526923040292};\\\", \\\"{x:1369,y:898,t:1526923040524};\\\", \\\"{x:1371,y:898,t:1526923040532};\\\", \\\"{x:1374,y:898,t:1526923040546};\\\", \\\"{x:1377,y:900,t:1526923040563};\\\", \\\"{x:1382,y:900,t:1526923040578};\\\", \\\"{x:1383,y:900,t:1526923040595};\\\", \\\"{x:1384,y:900,t:1526923040613};\\\", \\\"{x:1385,y:900,t:1526923040630};\\\", \\\"{x:1387,y:900,t:1526923040685};\\\", \\\"{x:1388,y:900,t:1526923040695};\\\", \\\"{x:1390,y:900,t:1526923040713};\\\", \\\"{x:1392,y:900,t:1526923040730};\\\", \\\"{x:1393,y:900,t:1526923040746};\\\", \\\"{x:1395,y:900,t:1526923040762};\\\", \\\"{x:1397,y:899,t:1526923040779};\\\", \\\"{x:1398,y:899,t:1526923040796};\\\", \\\"{x:1401,y:899,t:1526923040812};\\\", \\\"{x:1403,y:899,t:1526923040830};\\\", \\\"{x:1404,y:897,t:1526923040846};\\\", \\\"{x:1405,y:897,t:1526923040863};\\\", \\\"{x:1407,y:897,t:1526923040880};\\\", \\\"{x:1408,y:897,t:1526923040896};\\\", \\\"{x:1409,y:897,t:1526923040913};\\\", \\\"{x:1410,y:897,t:1526923040930};\\\", \\\"{x:1410,y:895,t:1526923041764};\\\", \\\"{x:1408,y:891,t:1526923041780};\\\", \\\"{x:1406,y:888,t:1526923041797};\\\", \\\"{x:1405,y:886,t:1526923041814};\\\", \\\"{x:1402,y:883,t:1526923041831};\\\", \\\"{x:1401,y:881,t:1526923041846};\\\", \\\"{x:1401,y:880,t:1526923041864};\\\", \\\"{x:1399,y:877,t:1526923041881};\\\", \\\"{x:1399,y:876,t:1526923041897};\\\", \\\"{x:1398,y:873,t:1526923041914};\\\", \\\"{x:1396,y:871,t:1526923041930};\\\", \\\"{x:1395,y:868,t:1526923041947};\\\", \\\"{x:1393,y:868,t:1526923041964};\\\", \\\"{x:1390,y:865,t:1526923041980};\\\", \\\"{x:1388,y:864,t:1526923041997};\\\", \\\"{x:1385,y:863,t:1526923042014};\\\", \\\"{x:1382,y:862,t:1526923042031};\\\", \\\"{x:1379,y:861,t:1526923042047};\\\", \\\"{x:1368,y:858,t:1526923042063};\\\", \\\"{x:1355,y:857,t:1526923042080};\\\", \\\"{x:1349,y:856,t:1526923042097};\\\", \\\"{x:1343,y:856,t:1526923042114};\\\", \\\"{x:1336,y:855,t:1526923042130};\\\", \\\"{x:1331,y:854,t:1526923042147};\\\", \\\"{x:1327,y:854,t:1526923042163};\\\", \\\"{x:1319,y:852,t:1526923042181};\\\", \\\"{x:1313,y:852,t:1526923042198};\\\", \\\"{x:1309,y:851,t:1526923042213};\\\", \\\"{x:1294,y:846,t:1526923042230};\\\", \\\"{x:1284,y:844,t:1526923042248};\\\", \\\"{x:1276,y:841,t:1526923042263};\\\", \\\"{x:1269,y:840,t:1526923042281};\\\", \\\"{x:1265,y:838,t:1526923042297};\\\", \\\"{x:1263,y:837,t:1526923042313};\\\", \\\"{x:1260,y:836,t:1526923042331};\\\", \\\"{x:1259,y:836,t:1526923042347};\\\", \\\"{x:1257,y:836,t:1526923042363};\\\", \\\"{x:1254,y:836,t:1526923042381};\\\", \\\"{x:1253,y:835,t:1526923042398};\\\", \\\"{x:1252,y:835,t:1526923042414};\\\", \\\"{x:1248,y:835,t:1526923042431};\\\", \\\"{x:1244,y:834,t:1526923042447};\\\", \\\"{x:1241,y:834,t:1526923042464};\\\", \\\"{x:1237,y:833,t:1526923042481};\\\", \\\"{x:1233,y:832,t:1526923042498};\\\", \\\"{x:1230,y:830,t:1526923042515};\\\", \\\"{x:1232,y:829,t:1526923042613};\\\", \\\"{x:1234,y:827,t:1526923042621};\\\", \\\"{x:1237,y:825,t:1526923042630};\\\", \\\"{x:1245,y:825,t:1526923042647};\\\", \\\"{x:1260,y:822,t:1526923042664};\\\", \\\"{x:1284,y:821,t:1526923042680};\\\", \\\"{x:1309,y:820,t:1526923042698};\\\", \\\"{x:1335,y:820,t:1526923042715};\\\", \\\"{x:1354,y:820,t:1526923042731};\\\", \\\"{x:1380,y:820,t:1526923042747};\\\", \\\"{x:1391,y:821,t:1526923042765};\\\", \\\"{x:1393,y:822,t:1526923042782};\\\", \\\"{x:1394,y:822,t:1526923042916};\\\", \\\"{x:1394,y:820,t:1526923042932};\\\", \\\"{x:1394,y:817,t:1526923042947};\\\", \\\"{x:1393,y:814,t:1526923042965};\\\", \\\"{x:1393,y:811,t:1526923042982};\\\", \\\"{x:1393,y:810,t:1526923042998};\\\", \\\"{x:1390,y:806,t:1526923043015};\\\", \\\"{x:1388,y:803,t:1526923043031};\\\", \\\"{x:1386,y:801,t:1526923043048};\\\", \\\"{x:1385,y:799,t:1526923043065};\\\", \\\"{x:1383,y:797,t:1526923043081};\\\", \\\"{x:1382,y:796,t:1526923043097};\\\", \\\"{x:1380,y:794,t:1526923043115};\\\", \\\"{x:1379,y:791,t:1526923043131};\\\", \\\"{x:1375,y:784,t:1526923043148};\\\", \\\"{x:1371,y:780,t:1526923043165};\\\", \\\"{x:1368,y:777,t:1526923043181};\\\", \\\"{x:1367,y:775,t:1526923043198};\\\", \\\"{x:1365,y:773,t:1526923043215};\\\", \\\"{x:1364,y:772,t:1526923043231};\\\", \\\"{x:1362,y:769,t:1526923043248};\\\", \\\"{x:1362,y:768,t:1526923043264};\\\", \\\"{x:1361,y:767,t:1526923043281};\\\", \\\"{x:1360,y:766,t:1526923043299};\\\", \\\"{x:1358,y:763,t:1526923043315};\\\", \\\"{x:1358,y:762,t:1526923043372};\\\", \\\"{x:1357,y:761,t:1526923043388};\\\", \\\"{x:1357,y:760,t:1526923043452};\\\", \\\"{x:1357,y:759,t:1526923043476};\\\", \\\"{x:1359,y:758,t:1526923044083};\\\", \\\"{x:1359,y:757,t:1526923044164};\\\", \\\"{x:1358,y:757,t:1526923044212};\\\", \\\"{x:1357,y:756,t:1526923044363};\\\", \\\"{x:1356,y:756,t:1526923044380};\\\", \\\"{x:1355,y:756,t:1526923044444};\\\", \\\"{x:1353,y:756,t:1526923044508};\\\", \\\"{x:1352,y:756,t:1526923044741};\\\", \\\"{x:1349,y:756,t:1526923045348};\\\", \\\"{x:1348,y:757,t:1526923045564};\\\", \\\"{x:1347,y:757,t:1526923045595};\\\", \\\"{x:1346,y:758,t:1526923045620};\\\", \\\"{x:1345,y:758,t:1526923047309};\\\", \\\"{x:1345,y:759,t:1526923047319};\\\", \\\"{x:1345,y:760,t:1526923047533};\\\", \\\"{x:1345,y:761,t:1526923047573};\\\", \\\"{x:1345,y:759,t:1526923048061};\\\", \\\"{x:1345,y:758,t:1526923048070};\\\", \\\"{x:1345,y:757,t:1526923048088};\\\", \\\"{x:1345,y:753,t:1526923048103};\\\", \\\"{x:1345,y:752,t:1526923048120};\\\", \\\"{x:1345,y:750,t:1526923048137};\\\", \\\"{x:1345,y:748,t:1526923048153};\\\", \\\"{x:1346,y:743,t:1526923048170};\\\", \\\"{x:1346,y:741,t:1526923048187};\\\", \\\"{x:1346,y:739,t:1526923048203};\\\", \\\"{x:1346,y:736,t:1526923048220};\\\", \\\"{x:1347,y:733,t:1526923048244};\\\", \\\"{x:1347,y:732,t:1526923048261};\\\", \\\"{x:1347,y:731,t:1526923048270};\\\", \\\"{x:1348,y:729,t:1526923048287};\\\", \\\"{x:1348,y:727,t:1526923048303};\\\", \\\"{x:1348,y:726,t:1526923048321};\\\", \\\"{x:1348,y:724,t:1526923048337};\\\", \\\"{x:1348,y:721,t:1526923048353};\\\", \\\"{x:1349,y:720,t:1526923048371};\\\", \\\"{x:1349,y:717,t:1526923048389};\\\", \\\"{x:1349,y:716,t:1526923048413};\\\", \\\"{x:1349,y:714,t:1526923048436};\\\", \\\"{x:1349,y:713,t:1526923048485};\\\", \\\"{x:1349,y:712,t:1526923048508};\\\", \\\"{x:1349,y:711,t:1526923048580};\\\", \\\"{x:1349,y:710,t:1526923049764};\\\", \\\"{x:1349,y:709,t:1526923049795};\\\", \\\"{x:1349,y:708,t:1526923049804};\\\", \\\"{x:1349,y:707,t:1526923049821};\\\", \\\"{x:1349,y:706,t:1526923049844};\\\", \\\"{x:1349,y:705,t:1526923049855};\\\", \\\"{x:1350,y:703,t:1526923049871};\\\", \\\"{x:1351,y:702,t:1526923049888};\\\", \\\"{x:1351,y:701,t:1526923049906};\\\", \\\"{x:1352,y:700,t:1526923049937};\\\", \\\"{x:1353,y:698,t:1526923049954};\\\", \\\"{x:1354,y:697,t:1526923050046};\\\", \\\"{x:1354,y:696,t:1526923050141};\\\", \\\"{x:1355,y:695,t:1526923051140};\\\", \\\"{x:1356,y:695,t:1526923051236};\\\", \\\"{x:1351,y:695,t:1526923051396};\\\", \\\"{x:1346,y:695,t:1526923051406};\\\", \\\"{x:1331,y:695,t:1526923051423};\\\", \\\"{x:1310,y:695,t:1526923051440};\\\", \\\"{x:1291,y:695,t:1526923051456};\\\", \\\"{x:1272,y:695,t:1526923051472};\\\", \\\"{x:1257,y:695,t:1526923051490};\\\", \\\"{x:1251,y:695,t:1526923051507};\\\", \\\"{x:1248,y:694,t:1526923051523};\\\", \\\"{x:1227,y:691,t:1526923051540};\\\", \\\"{x:1208,y:690,t:1526923051557};\\\", \\\"{x:1193,y:690,t:1526923051573};\\\", \\\"{x:1180,y:689,t:1526923051590};\\\", \\\"{x:1168,y:685,t:1526923051607};\\\", \\\"{x:1140,y:679,t:1526923051623};\\\", \\\"{x:1123,y:676,t:1526923051640};\\\", \\\"{x:1110,y:675,t:1526923051657};\\\", \\\"{x:1089,y:673,t:1526923051673};\\\", \\\"{x:1072,y:673,t:1526923051690};\\\", \\\"{x:1056,y:673,t:1526923051707};\\\", \\\"{x:1037,y:673,t:1526923051723};\\\", \\\"{x:1000,y:668,t:1526923051740};\\\", \\\"{x:984,y:667,t:1526923051757};\\\", \\\"{x:965,y:667,t:1526923051773};\\\", \\\"{x:944,y:664,t:1526923051789};\\\", \\\"{x:917,y:664,t:1526923051807};\\\", \\\"{x:887,y:657,t:1526923051823};\\\", \\\"{x:840,y:650,t:1526923051840};\\\", \\\"{x:789,y:643,t:1526923051857};\\\", \\\"{x:746,y:632,t:1526923051873};\\\", \\\"{x:701,y:629,t:1526923051886};\\\", \\\"{x:638,y:622,t:1526923051903};\\\", \\\"{x:590,y:614,t:1526923051921};\\\", \\\"{x:538,y:609,t:1526923051937};\\\", \\\"{x:493,y:602,t:1526923051953};\\\", \\\"{x:434,y:594,t:1526923051970};\\\", \\\"{x:370,y:585,t:1526923051987};\\\", \\\"{x:288,y:582,t:1526923052004};\\\", \\\"{x:228,y:577,t:1526923052020};\\\", \\\"{x:176,y:572,t:1526923052037};\\\", \\\"{x:152,y:567,t:1526923052054};\\\", \\\"{x:139,y:563,t:1526923052070};\\\", \\\"{x:136,y:561,t:1526923052087};\\\", \\\"{x:138,y:561,t:1526923052196};\\\", \\\"{x:146,y:561,t:1526923052203};\\\", \\\"{x:162,y:559,t:1526923052220};\\\", \\\"{x:180,y:556,t:1526923052237};\\\", \\\"{x:208,y:556,t:1526923052255};\\\", \\\"{x:237,y:556,t:1526923052270};\\\", \\\"{x:282,y:555,t:1526923052287};\\\", \\\"{x:323,y:552,t:1526923052304};\\\", \\\"{x:376,y:551,t:1526923052320};\\\", \\\"{x:426,y:545,t:1526923052337};\\\", \\\"{x:472,y:538,t:1526923052354};\\\", \\\"{x:501,y:535,t:1526923052369};\\\", \\\"{x:526,y:535,t:1526923052386};\\\", \\\"{x:546,y:534,t:1526923052403};\\\", \\\"{x:554,y:533,t:1526923052421};\\\", \\\"{x:560,y:531,t:1526923052437};\\\", \\\"{x:565,y:530,t:1526923052454};\\\", \\\"{x:572,y:527,t:1526923052470};\\\", \\\"{x:584,y:524,t:1526923052487};\\\", \\\"{x:596,y:521,t:1526923052504};\\\", \\\"{x:601,y:519,t:1526923052522};\\\", \\\"{x:604,y:517,t:1526923052537};\\\", \\\"{x:607,y:515,t:1526923052554};\\\", \\\"{x:608,y:514,t:1526923052580};\\\", \\\"{x:611,y:513,t:1526923052587};\\\", \\\"{x:616,y:511,t:1526923052603};\\\", \\\"{x:628,y:510,t:1526923052621};\\\", \\\"{x:647,y:508,t:1526923052638};\\\", \\\"{x:675,y:503,t:1526923052653};\\\", \\\"{x:698,y:499,t:1526923052671};\\\", \\\"{x:742,y:492,t:1526923052687};\\\", \\\"{x:774,y:489,t:1526923052704};\\\", \\\"{x:799,y:489,t:1526923052721};\\\", \\\"{x:819,y:489,t:1526923052737};\\\", \\\"{x:833,y:489,t:1526923052755};\\\", \\\"{x:836,y:489,t:1526923052771};\\\", \\\"{x:838,y:489,t:1526923052787};\\\", \\\"{x:838,y:488,t:1526923052805};\\\", \\\"{x:840,y:488,t:1526923052861};\\\", \\\"{x:843,y:489,t:1526923052877};\\\", \\\"{x:845,y:490,t:1526923052887};\\\", \\\"{x:849,y:493,t:1526923052904};\\\", \\\"{x:854,y:497,t:1526923052921};\\\", \\\"{x:859,y:499,t:1526923052938};\\\", \\\"{x:860,y:500,t:1526923052955};\\\", \\\"{x:860,y:501,t:1526923052973};\\\", \\\"{x:860,y:502,t:1526923053004};\\\", \\\"{x:860,y:504,t:1526923053022};\\\", \\\"{x:859,y:505,t:1526923053038};\\\", \\\"{x:858,y:506,t:1526923053054};\\\", \\\"{x:856,y:507,t:1526923053071};\\\", \\\"{x:854,y:507,t:1526923053088};\\\", \\\"{x:853,y:507,t:1526923053148};\\\", \\\"{x:853,y:508,t:1526923053188};\\\", \\\"{x:852,y:509,t:1526923053203};\\\", \\\"{x:851,y:509,t:1526923053316};\\\", \\\"{x:850,y:510,t:1526923053499};\\\", \\\"{x:849,y:511,t:1526923053507};\\\", \\\"{x:848,y:512,t:1526923053520};\\\", \\\"{x:847,y:512,t:1526923053547};\\\", \\\"{x:846,y:513,t:1526923053580};\\\", \\\"{x:844,y:513,t:1526923053595};\\\", \\\"{x:843,y:513,t:1526923053612};\\\", \\\"{x:843,y:514,t:1526923053716};\\\", \\\"{x:843,y:515,t:1526923054179};\\\", \\\"{x:845,y:517,t:1526923054188};\\\", \\\"{x:851,y:520,t:1526923054205};\\\", \\\"{x:858,y:523,t:1526923054222};\\\", \\\"{x:865,y:524,t:1526923054238};\\\", \\\"{x:877,y:529,t:1526923054256};\\\", \\\"{x:888,y:533,t:1526923054272};\\\", \\\"{x:900,y:539,t:1526923054290};\\\", \\\"{x:906,y:543,t:1526923054305};\\\", \\\"{x:912,y:544,t:1526923054321};\\\", \\\"{x:917,y:547,t:1526923054339};\\\", \\\"{x:920,y:550,t:1526923054355};\\\", \\\"{x:924,y:552,t:1526923054372};\\\", \\\"{x:926,y:554,t:1526923054389};\\\", \\\"{x:928,y:556,t:1526923054405};\\\", \\\"{x:933,y:558,t:1526923054422};\\\", \\\"{x:941,y:562,t:1526923054439};\\\", \\\"{x:949,y:562,t:1526923054455};\\\", \\\"{x:954,y:566,t:1526923054472};\\\", \\\"{x:963,y:567,t:1526923054489};\\\", \\\"{x:973,y:571,t:1526923054505};\\\", \\\"{x:983,y:573,t:1526923054522};\\\", \\\"{x:991,y:578,t:1526923054539};\\\", \\\"{x:1010,y:581,t:1526923054556};\\\", \\\"{x:1028,y:585,t:1526923054573};\\\", \\\"{x:1046,y:589,t:1526923054589};\\\", \\\"{x:1058,y:592,t:1526923054606};\\\", \\\"{x:1072,y:595,t:1526923054622};\\\", \\\"{x:1093,y:597,t:1526923054639};\\\", \\\"{x:1107,y:600,t:1526923054656};\\\", \\\"{x:1121,y:605,t:1526923054673};\\\", \\\"{x:1137,y:606,t:1526923054689};\\\", \\\"{x:1157,y:610,t:1526923054706};\\\", \\\"{x:1180,y:615,t:1526923054723};\\\", \\\"{x:1194,y:618,t:1526923054739};\\\", \\\"{x:1217,y:626,t:1526923054756};\\\", \\\"{x:1232,y:629,t:1526923054773};\\\", \\\"{x:1241,y:633,t:1526923054790};\\\", \\\"{x:1251,y:636,t:1526923054806};\\\", \\\"{x:1254,y:640,t:1526923054823};\\\", \\\"{x:1259,y:642,t:1526923054840};\\\", \\\"{x:1262,y:644,t:1526923054856};\\\", \\\"{x:1265,y:645,t:1526923054872};\\\", \\\"{x:1269,y:647,t:1526923054890};\\\", \\\"{x:1275,y:651,t:1526923054906};\\\", \\\"{x:1279,y:653,t:1526923054922};\\\", \\\"{x:1285,y:656,t:1526923054940};\\\", \\\"{x:1288,y:658,t:1526923054957};\\\", \\\"{x:1292,y:660,t:1526923054973};\\\", \\\"{x:1296,y:663,t:1526923054990};\\\", \\\"{x:1300,y:665,t:1526923055007};\\\", \\\"{x:1304,y:668,t:1526923055023};\\\", \\\"{x:1308,y:671,t:1526923055040};\\\", \\\"{x:1311,y:674,t:1526923055057};\\\", \\\"{x:1313,y:675,t:1526923055074};\\\", \\\"{x:1315,y:677,t:1526923055090};\\\", \\\"{x:1317,y:680,t:1526923055107};\\\", \\\"{x:1321,y:684,t:1526923055124};\\\", \\\"{x:1327,y:686,t:1526923055140};\\\", \\\"{x:1330,y:689,t:1526923055156};\\\", \\\"{x:1335,y:692,t:1526923055174};\\\", \\\"{x:1337,y:694,t:1526923055190};\\\", \\\"{x:1341,y:696,t:1526923055208};\\\", \\\"{x:1344,y:699,t:1526923055224};\\\", \\\"{x:1347,y:699,t:1526923055241};\\\", \\\"{x:1347,y:700,t:1526923055257};\\\", \\\"{x:1349,y:703,t:1526923055274};\\\", \\\"{x:1352,y:706,t:1526923055291};\\\", \\\"{x:1353,y:707,t:1526923055307};\\\", \\\"{x:1356,y:712,t:1526923055324};\\\", \\\"{x:1358,y:713,t:1526923055341};\\\", \\\"{x:1359,y:717,t:1526923055358};\\\", \\\"{x:1361,y:719,t:1526923055374};\\\", \\\"{x:1362,y:722,t:1526923055391};\\\", \\\"{x:1362,y:724,t:1526923055408};\\\", \\\"{x:1364,y:727,t:1526923055424};\\\", \\\"{x:1364,y:725,t:1526923055629};\\\", \\\"{x:1364,y:724,t:1526923055641};\\\", \\\"{x:1364,y:720,t:1526923055659};\\\", \\\"{x:1362,y:718,t:1526923055675};\\\", \\\"{x:1361,y:715,t:1526923055692};\\\", \\\"{x:1360,y:714,t:1526923055709};\\\", \\\"{x:1360,y:713,t:1526923055726};\\\", \\\"{x:1360,y:712,t:1526923055742};\\\", \\\"{x:1360,y:711,t:1526923055758};\\\", \\\"{x:1359,y:710,t:1526923055776};\\\", \\\"{x:1358,y:708,t:1526923055792};\\\", \\\"{x:1358,y:706,t:1526923055809};\\\", \\\"{x:1357,y:705,t:1526923055825};\\\", \\\"{x:1357,y:702,t:1526923055842};\\\", \\\"{x:1356,y:701,t:1526923055859};\\\", \\\"{x:1355,y:697,t:1526923055875};\\\", \\\"{x:1353,y:695,t:1526923055892};\\\", \\\"{x:1350,y:692,t:1526923055909};\\\", \\\"{x:1349,y:692,t:1526923055939};\\\", \\\"{x:1348,y:691,t:1526923056166};\\\", \\\"{x:1348,y:692,t:1526923057564};\\\", \\\"{x:1348,y:694,t:1526923057578};\\\", \\\"{x:1348,y:695,t:1526923057596};\\\", \\\"{x:1348,y:697,t:1526923057619};\\\", \\\"{x:1348,y:698,t:1526923057643};\\\", \\\"{x:1349,y:699,t:1526923057660};\\\", \\\"{x:1349,y:700,t:1526923057684};\\\", \\\"{x:1350,y:701,t:1526923057699};\\\", \\\"{x:1351,y:702,t:1526923057724};\\\", \\\"{x:1352,y:704,t:1526923057732};\\\", \\\"{x:1353,y:705,t:1526923057746};\\\", \\\"{x:1354,y:707,t:1526923057763};\\\", \\\"{x:1358,y:711,t:1526923057779};\\\", \\\"{x:1359,y:713,t:1526923057796};\\\", \\\"{x:1361,y:715,t:1526923057813};\\\", \\\"{x:1363,y:719,t:1526923057830};\\\", \\\"{x:1367,y:722,t:1526923057845};\\\", \\\"{x:1372,y:727,t:1526923057863};\\\", \\\"{x:1386,y:737,t:1526923057880};\\\", \\\"{x:1399,y:745,t:1526923057897};\\\", \\\"{x:1415,y:752,t:1526923057913};\\\", \\\"{x:1425,y:758,t:1526923057930};\\\", \\\"{x:1431,y:764,t:1526923057947};\\\", \\\"{x:1438,y:768,t:1526923057963};\\\", \\\"{x:1451,y:779,t:1526923057980};\\\", \\\"{x:1456,y:783,t:1526923057997};\\\", \\\"{x:1460,y:786,t:1526923058014};\\\", \\\"{x:1462,y:789,t:1526923058030};\\\", \\\"{x:1464,y:791,t:1526923058047};\\\", \\\"{x:1467,y:793,t:1526923058065};\\\", \\\"{x:1468,y:794,t:1526923058080};\\\", \\\"{x:1470,y:796,t:1526923058097};\\\", \\\"{x:1472,y:800,t:1526923058114};\\\", \\\"{x:1473,y:802,t:1526923058130};\\\", \\\"{x:1476,y:806,t:1526923058147};\\\", \\\"{x:1477,y:808,t:1526923058163};\\\", \\\"{x:1477,y:810,t:1526923058181};\\\", \\\"{x:1477,y:811,t:1526923058197};\\\", \\\"{x:1477,y:813,t:1526923058214};\\\", \\\"{x:1478,y:814,t:1526923058231};\\\", \\\"{x:1478,y:816,t:1526923058252};\\\", \\\"{x:1478,y:817,t:1526923058275};\\\", \\\"{x:1478,y:818,t:1526923058308};\\\", \\\"{x:1479,y:819,t:1526923058324};\\\", \\\"{x:1479,y:820,t:1526923058331};\\\", \\\"{x:1479,y:819,t:1526923058771};\\\", \\\"{x:1479,y:816,t:1526923058781};\\\", \\\"{x:1469,y:808,t:1526923058799};\\\", \\\"{x:1455,y:799,t:1526923058815};\\\", \\\"{x:1441,y:789,t:1526923058832};\\\", \\\"{x:1425,y:780,t:1526923058849};\\\", \\\"{x:1409,y:770,t:1526923058865};\\\", \\\"{x:1394,y:760,t:1526923058882};\\\", \\\"{x:1380,y:750,t:1526923058899};\\\", \\\"{x:1369,y:741,t:1526923058915};\\\", \\\"{x:1362,y:734,t:1526923058932};\\\", \\\"{x:1355,y:726,t:1526923058949};\\\", \\\"{x:1350,y:715,t:1526923058966};\\\", \\\"{x:1346,y:709,t:1526923058982};\\\", \\\"{x:1343,y:706,t:1526923058999};\\\", \\\"{x:1339,y:700,t:1526923059016};\\\", \\\"{x:1336,y:695,t:1526923059033};\\\", \\\"{x:1334,y:692,t:1526923059049};\\\", \\\"{x:1332,y:691,t:1526923059066};\\\", \\\"{x:1331,y:689,t:1526923059084};\\\", \\\"{x:1331,y:688,t:1526923059099};\\\", \\\"{x:1331,y:686,t:1526923059116};\\\", \\\"{x:1331,y:685,t:1526923059133};\\\", \\\"{x:1331,y:684,t:1526923059171};\\\", \\\"{x:1331,y:683,t:1526923059183};\\\", \\\"{x:1331,y:682,t:1526923059211};\\\", \\\"{x:1331,y:680,t:1526923059243};\\\", \\\"{x:1330,y:679,t:1526923059604};\\\", \\\"{x:1330,y:678,t:1526923059618};\\\", \\\"{x:1328,y:675,t:1526923059634};\\\", \\\"{x:1325,y:671,t:1526923059651};\\\", \\\"{x:1325,y:669,t:1526923059668};\\\", \\\"{x:1322,y:663,t:1526923059683};\\\", \\\"{x:1320,y:658,t:1526923059702};\\\", \\\"{x:1316,y:654,t:1526923059718};\\\", \\\"{x:1316,y:647,t:1526923059735};\\\", \\\"{x:1313,y:644,t:1526923059752};\\\", \\\"{x:1312,y:640,t:1526923059767};\\\", \\\"{x:1309,y:637,t:1526923059785};\\\", \\\"{x:1304,y:631,t:1526923059801};\\\", \\\"{x:1301,y:627,t:1526923059818};\\\", \\\"{x:1298,y:622,t:1526923059835};\\\", \\\"{x:1296,y:619,t:1526923059851};\\\", \\\"{x:1294,y:613,t:1526923059867};\\\", \\\"{x:1293,y:609,t:1526923059884};\\\", \\\"{x:1290,y:605,t:1526923059902};\\\", \\\"{x:1287,y:599,t:1526923059918};\\\", \\\"{x:1287,y:596,t:1526923059935};\\\", \\\"{x:1282,y:590,t:1526923059952};\\\", \\\"{x:1279,y:585,t:1526923059968};\\\", \\\"{x:1278,y:581,t:1526923059985};\\\", \\\"{x:1277,y:577,t:1526923060001};\\\", \\\"{x:1276,y:575,t:1526923060018};\\\", \\\"{x:1274,y:573,t:1526923060035};\\\", \\\"{x:1274,y:572,t:1526923060051};\\\", \\\"{x:1272,y:566,t:1526923060068};\\\", \\\"{x:1272,y:564,t:1526923060085};\\\", \\\"{x:1271,y:562,t:1526923060102};\\\", \\\"{x:1271,y:560,t:1526923060118};\\\", \\\"{x:1271,y:559,t:1526923060135};\\\", \\\"{x:1271,y:558,t:1526923060152};\\\", \\\"{x:1271,y:557,t:1526923060169};\\\", \\\"{x:1271,y:556,t:1526923060186};\\\", \\\"{x:1271,y:555,t:1526923060220};\\\", \\\"{x:1271,y:554,t:1526923060268};\\\", \\\"{x:1271,y:555,t:1526923060404};\\\", \\\"{x:1271,y:556,t:1526923060428};\\\", \\\"{x:1272,y:557,t:1526923060444};\\\", \\\"{x:1272,y:558,t:1526923060452};\\\", \\\"{x:1273,y:561,t:1526923060476};\\\", \\\"{x:1273,y:562,t:1526923060540};\\\", \\\"{x:1273,y:563,t:1526923060620};\\\", \\\"{x:1273,y:564,t:1526923060756};\\\", \\\"{x:1274,y:565,t:1526923060963};\\\", \\\"{x:1275,y:565,t:1526923061076};\\\", \\\"{x:1277,y:566,t:1526923061092};\\\", \\\"{x:1278,y:567,t:1526923061103};\\\", \\\"{x:1279,y:567,t:1526923061219};\\\", \\\"{x:1280,y:567,t:1526923061276};\\\", \\\"{x:1281,y:567,t:1526923061339};\\\", \\\"{x:1280,y:567,t:1526923071387};\\\", \\\"{x:1273,y:567,t:1526923071395};\\\", \\\"{x:1265,y:570,t:1526923071411};\\\", \\\"{x:1239,y:575,t:1526923071427};\\\", \\\"{x:1221,y:580,t:1526923071444};\\\", \\\"{x:1201,y:584,t:1526923071461};\\\", \\\"{x:1173,y:587,t:1526923071478};\\\", \\\"{x:1155,y:594,t:1526923071495};\\\", \\\"{x:1092,y:604,t:1526923071512};\\\", \\\"{x:1036,y:612,t:1526923071527};\\\", \\\"{x:980,y:619,t:1526923071545};\\\", \\\"{x:942,y:622,t:1526923071562};\\\", \\\"{x:917,y:625,t:1526923071579};\\\", \\\"{x:903,y:627,t:1526923071594};\\\", \\\"{x:886,y:629,t:1526923071619};\\\", \\\"{x:877,y:631,t:1526923071635};\\\", \\\"{x:860,y:631,t:1526923071653};\\\", \\\"{x:838,y:626,t:1526923071669};\\\", \\\"{x:821,y:622,t:1526923071685};\\\", \\\"{x:801,y:618,t:1526923071702};\\\", \\\"{x:779,y:615,t:1526923071720};\\\", \\\"{x:760,y:610,t:1526923071735};\\\", \\\"{x:748,y:605,t:1526923071753};\\\", \\\"{x:740,y:602,t:1526923071769};\\\", \\\"{x:737,y:601,t:1526923071785};\\\", \\\"{x:735,y:599,t:1526923071802};\\\", \\\"{x:728,y:591,t:1526923071819};\\\", \\\"{x:724,y:587,t:1526923071835};\\\", \\\"{x:714,y:579,t:1526923071853};\\\", \\\"{x:708,y:575,t:1526923071870};\\\", \\\"{x:701,y:570,t:1526923071886};\\\", \\\"{x:692,y:562,t:1526923071902};\\\", \\\"{x:683,y:554,t:1526923071919};\\\", \\\"{x:672,y:547,t:1526923071936};\\\", \\\"{x:655,y:540,t:1526923071952};\\\", \\\"{x:640,y:535,t:1526923071969};\\\", \\\"{x:630,y:532,t:1526923071987};\\\", \\\"{x:616,y:527,t:1526923072003};\\\", \\\"{x:609,y:523,t:1526923072019};\\\", \\\"{x:607,y:523,t:1526923072036};\\\", \\\"{x:605,y:522,t:1526923072067};\\\", \\\"{x:604,y:521,t:1526923072083};\\\", \\\"{x:604,y:522,t:1526923072716};\\\", \\\"{x:605,y:524,t:1526923072724};\\\", \\\"{x:606,y:526,t:1526923072737};\\\", \\\"{x:610,y:532,t:1526923072755};\\\", \\\"{x:617,y:541,t:1526923072771};\\\", \\\"{x:625,y:552,t:1526923072787};\\\", \\\"{x:648,y:574,t:1526923072804};\\\", \\\"{x:668,y:587,t:1526923072821};\\\", \\\"{x:694,y:605,t:1526923072836};\\\", \\\"{x:713,y:626,t:1526923072854};\\\", \\\"{x:738,y:641,t:1526923072870};\\\", \\\"{x:769,y:665,t:1526923072887};\\\", \\\"{x:800,y:689,t:1526923072903};\\\", \\\"{x:827,y:708,t:1526923072920};\\\", \\\"{x:849,y:728,t:1526923072936};\\\", \\\"{x:861,y:743,t:1526923072953};\\\", \\\"{x:879,y:763,t:1526923072971};\\\", \\\"{x:898,y:782,t:1526923072986};\\\", \\\"{x:927,y:809,t:1526923073003};\\\", \\\"{x:943,y:825,t:1526923073021};\\\", \\\"{x:962,y:835,t:1526923073037};\\\", \\\"{x:987,y:849,t:1526923073054};\\\", \\\"{x:1017,y:865,t:1526923073071};\\\", \\\"{x:1048,y:879,t:1526923073087};\\\", \\\"{x:1071,y:886,t:1526923073104};\\\", \\\"{x:1101,y:897,t:1526923073121};\\\", \\\"{x:1126,y:906,t:1526923073137};\\\", \\\"{x:1158,y:914,t:1526923073154};\\\", \\\"{x:1186,y:917,t:1526923073171};\\\", \\\"{x:1209,y:919,t:1526923073187};\\\", \\\"{x:1217,y:920,t:1526923073204};\\\", \\\"{x:1221,y:920,t:1526923073221};\\\", \\\"{x:1223,y:920,t:1526923073260};\\\", \\\"{x:1226,y:920,t:1526923073397};\\\", \\\"{x:1227,y:920,t:1526923073404};\\\", \\\"{x:1229,y:923,t:1526923073421};\\\", \\\"{x:1232,y:925,t:1526923073438};\\\", \\\"{x:1234,y:927,t:1526923073454};\\\", \\\"{x:1235,y:928,t:1526923073471};\\\", \\\"{x:1236,y:930,t:1526923073488};\\\", \\\"{x:1238,y:931,t:1526923073508};\\\", \\\"{x:1239,y:933,t:1526923073522};\\\", \\\"{x:1241,y:935,t:1526923073538};\\\", \\\"{x:1243,y:938,t:1526923073555};\\\", \\\"{x:1248,y:943,t:1526923073571};\\\", \\\"{x:1255,y:950,t:1526923073587};\\\", \\\"{x:1259,y:953,t:1526923073604};\\\", \\\"{x:1261,y:954,t:1526923073620};\\\", \\\"{x:1265,y:957,t:1526923073637};\\\", \\\"{x:1265,y:958,t:1526923073655};\\\", \\\"{x:1267,y:960,t:1526923073671};\\\", \\\"{x:1268,y:962,t:1526923073688};\\\", \\\"{x:1270,y:964,t:1526923073705};\\\", \\\"{x:1272,y:965,t:1526923073721};\\\", \\\"{x:1275,y:967,t:1526923073738};\\\", \\\"{x:1275,y:968,t:1526923073797};\\\", \\\"{x:1276,y:967,t:1526923073916};\\\", \\\"{x:1279,y:966,t:1526923073924};\\\", \\\"{x:1279,y:964,t:1526923073938};\\\", \\\"{x:1282,y:960,t:1526923073956};\\\", \\\"{x:1284,y:957,t:1526923073971};\\\", \\\"{x:1288,y:949,t:1526923073988};\\\", \\\"{x:1290,y:943,t:1526923074005};\\\", \\\"{x:1290,y:936,t:1526923074022};\\\", \\\"{x:1290,y:932,t:1526923074039};\\\", \\\"{x:1291,y:926,t:1526923074055};\\\", \\\"{x:1291,y:921,t:1526923074073};\\\", \\\"{x:1291,y:916,t:1526923074092};\\\", \\\"{x:1289,y:911,t:1526923074106};\\\", \\\"{x:1286,y:900,t:1526923074122};\\\", \\\"{x:1281,y:889,t:1526923074138};\\\", \\\"{x:1275,y:879,t:1526923074155};\\\", \\\"{x:1269,y:869,t:1526923074172};\\\", \\\"{x:1263,y:860,t:1526923074188};\\\", \\\"{x:1259,y:852,t:1526923074206};\\\", \\\"{x:1257,y:847,t:1526923074222};\\\", \\\"{x:1257,y:844,t:1526923074238};\\\", \\\"{x:1256,y:838,t:1526923074255};\\\", \\\"{x:1254,y:834,t:1526923074272};\\\", \\\"{x:1254,y:831,t:1526923074288};\\\", \\\"{x:1253,y:828,t:1526923074305};\\\", \\\"{x:1253,y:826,t:1526923074323};\\\", \\\"{x:1253,y:825,t:1526923074338};\\\", \\\"{x:1253,y:831,t:1526923074420};\\\", \\\"{x:1253,y:837,t:1526923074428};\\\", \\\"{x:1253,y:842,t:1526923074438};\\\", \\\"{x:1253,y:851,t:1526923074455};\\\", \\\"{x:1253,y:862,t:1526923074473};\\\", \\\"{x:1255,y:873,t:1526923074489};\\\", \\\"{x:1258,y:881,t:1526923074504};\\\", \\\"{x:1262,y:891,t:1526923074521};\\\", \\\"{x:1263,y:896,t:1526923074539};\\\", \\\"{x:1265,y:903,t:1526923074554};\\\", \\\"{x:1267,y:908,t:1526923074572};\\\", \\\"{x:1268,y:910,t:1526923074589};\\\", \\\"{x:1269,y:914,t:1526923074605};\\\", \\\"{x:1271,y:921,t:1526923074622};\\\", \\\"{x:1273,y:927,t:1526923074638};\\\", \\\"{x:1273,y:934,t:1526923074655};\\\", \\\"{x:1273,y:939,t:1526923074671};\\\", \\\"{x:1275,y:942,t:1526923074688};\\\", \\\"{x:1275,y:945,t:1526923074705};\\\", \\\"{x:1276,y:949,t:1526923074721};\\\", \\\"{x:1277,y:950,t:1526923074738};\\\", \\\"{x:1277,y:952,t:1526923074755};\\\", \\\"{x:1278,y:952,t:1526923074771};\\\", \\\"{x:1278,y:953,t:1526923074788};\\\", \\\"{x:1279,y:953,t:1526923074811};\\\", \\\"{x:1279,y:955,t:1526923074852};\\\", \\\"{x:1279,y:956,t:1526923074868};\\\", \\\"{x:1279,y:958,t:1526923074899};\\\", \\\"{x:1279,y:959,t:1526923074907};\\\", \\\"{x:1280,y:960,t:1526923074924};\\\", \\\"{x:1281,y:961,t:1526923075004};\\\", \\\"{x:1282,y:962,t:1526923075012};\\\", \\\"{x:1282,y:963,t:1526923075028};\\\", \\\"{x:1282,y:964,t:1526923075039};\\\", \\\"{x:1282,y:965,t:1526923075059};\\\", \\\"{x:1282,y:966,t:1526923075244};\\\", \\\"{x:1283,y:967,t:1526923075257};\\\", \\\"{x:1283,y:968,t:1526923075272};\\\", \\\"{x:1283,y:970,t:1526923075290};\\\", \\\"{x:1283,y:971,t:1526923075307};\\\", \\\"{x:1284,y:971,t:1526923075427};\\\", \\\"{x:1284,y:968,t:1526923076403};\\\", \\\"{x:1284,y:967,t:1526923076411};\\\", \\\"{x:1284,y:966,t:1526923076422};\\\", \\\"{x:1283,y:962,t:1526923076440};\\\", \\\"{x:1281,y:958,t:1526923076456};\\\", \\\"{x:1280,y:953,t:1526923076473};\\\", \\\"{x:1278,y:947,t:1526923076490};\\\", \\\"{x:1277,y:940,t:1526923076507};\\\", \\\"{x:1276,y:928,t:1526923076523};\\\", \\\"{x:1275,y:910,t:1526923076540};\\\", \\\"{x:1273,y:895,t:1526923076557};\\\", \\\"{x:1271,y:881,t:1526923076573};\\\", \\\"{x:1268,y:867,t:1526923076590};\\\", \\\"{x:1266,y:848,t:1526923076607};\\\", \\\"{x:1265,y:830,t:1526923076623};\\\", \\\"{x:1265,y:808,t:1526923076640};\\\", \\\"{x:1265,y:792,t:1526923076657};\\\", \\\"{x:1265,y:776,t:1526923076674};\\\", \\\"{x:1265,y:761,t:1526923076690};\\\", \\\"{x:1265,y:746,t:1526923076707};\\\", \\\"{x:1265,y:721,t:1526923076724};\\\", \\\"{x:1268,y:706,t:1526923076740};\\\", \\\"{x:1269,y:693,t:1526923076757};\\\", \\\"{x:1271,y:680,t:1526923076774};\\\", \\\"{x:1273,y:673,t:1526923076790};\\\", \\\"{x:1273,y:666,t:1526923076807};\\\", \\\"{x:1274,y:657,t:1526923076824};\\\", \\\"{x:1274,y:646,t:1526923076839};\\\", \\\"{x:1277,y:638,t:1526923076857};\\\", \\\"{x:1277,y:628,t:1526923076874};\\\", \\\"{x:1277,y:621,t:1526923076890};\\\", \\\"{x:1277,y:614,t:1526923076907};\\\", \\\"{x:1277,y:611,t:1526923076924};\\\", \\\"{x:1277,y:610,t:1526923076940};\\\", \\\"{x:1277,y:607,t:1526923076957};\\\", \\\"{x:1277,y:603,t:1526923076974};\\\", \\\"{x:1277,y:600,t:1526923076991};\\\", \\\"{x:1277,y:598,t:1526923077007};\\\", \\\"{x:1277,y:597,t:1526923077035};\\\", \\\"{x:1277,y:596,t:1526923077052};\\\", \\\"{x:1277,y:595,t:1526923077060};\\\", \\\"{x:1277,y:594,t:1526923077075};\\\", \\\"{x:1277,y:592,t:1526923077092};\\\", \\\"{x:1277,y:591,t:1526923077107};\\\", \\\"{x:1278,y:589,t:1526923077124};\\\", \\\"{x:1278,y:588,t:1526923077141};\\\", \\\"{x:1278,y:587,t:1526923077158};\\\", \\\"{x:1278,y:586,t:1526923077174};\\\", \\\"{x:1278,y:584,t:1526923077191};\\\", \\\"{x:1278,y:583,t:1526923077212};\\\", \\\"{x:1278,y:582,t:1526923077224};\\\", \\\"{x:1278,y:581,t:1526923077242};\\\", \\\"{x:1278,y:579,t:1526923077257};\\\", \\\"{x:1278,y:576,t:1526923077275};\\\", \\\"{x:1278,y:574,t:1526923077291};\\\", \\\"{x:1279,y:571,t:1526923077307};\\\", \\\"{x:1280,y:569,t:1526923077324};\\\", \\\"{x:1280,y:567,t:1526923077341};\\\", \\\"{x:1280,y:566,t:1526923077357};\\\", \\\"{x:1281,y:566,t:1526923077374};\\\", \\\"{x:1281,y:565,t:1526923077390};\\\", \\\"{x:1282,y:563,t:1526923081593};\\\", \\\"{x:1284,y:563,t:1526923081601};\\\", \\\"{x:1287,y:562,t:1526923081615};\\\", \\\"{x:1291,y:560,t:1526923081631};\\\", \\\"{x:1295,y:560,t:1526923081647};\\\", \\\"{x:1302,y:560,t:1526923081664};\\\", \\\"{x:1314,y:560,t:1526923081680};\\\", \\\"{x:1321,y:560,t:1526923081697};\\\", \\\"{x:1326,y:560,t:1526923081714};\\\", \\\"{x:1328,y:560,t:1526923081731};\\\", \\\"{x:1331,y:563,t:1526923081747};\\\", \\\"{x:1331,y:567,t:1526923081764};\\\", \\\"{x:1326,y:577,t:1526923081781};\\\", \\\"{x:1309,y:591,t:1526923081797};\\\", \\\"{x:1267,y:601,t:1526923081814};\\\", \\\"{x:1150,y:620,t:1526923081832};\\\", \\\"{x:1053,y:636,t:1526923081847};\\\", \\\"{x:978,y:647,t:1526923081864};\\\", \\\"{x:900,y:657,t:1526923081881};\\\", \\\"{x:873,y:663,t:1526923081898};\\\", \\\"{x:832,y:669,t:1526923081914};\\\", \\\"{x:819,y:673,t:1526923081931};\\\", \\\"{x:808,y:677,t:1526923081948};\\\", \\\"{x:797,y:683,t:1526923081964};\\\", \\\"{x:788,y:689,t:1526923081981};\\\", \\\"{x:772,y:696,t:1526923081998};\\\", \\\"{x:758,y:702,t:1526923082014};\\\", \\\"{x:733,y:709,t:1526923082031};\\\", \\\"{x:718,y:710,t:1526923082048};\\\", \\\"{x:693,y:712,t:1526923082064};\\\", \\\"{x:671,y:712,t:1526923082081};\\\", \\\"{x:653,y:712,t:1526923082098};\\\", \\\"{x:632,y:712,t:1526923082114};\\\", \\\"{x:619,y:712,t:1526923082131};\\\", \\\"{x:611,y:712,t:1526923082147};\\\", \\\"{x:609,y:712,t:1526923082163};\\\", \\\"{x:607,y:713,t:1526923082181};\\\", \\\"{x:603,y:715,t:1526923082198};\\\", \\\"{x:601,y:717,t:1526923082214};\\\", \\\"{x:593,y:721,t:1526923082231};\\\", \\\"{x:582,y:726,t:1526923082248};\\\", \\\"{x:570,y:728,t:1526923082264};\\\", \\\"{x:559,y:731,t:1526923082281};\\\", \\\"{x:553,y:734,t:1526923082299};\\\", \\\"{x:549,y:735,t:1526923082315};\\\", \\\"{x:545,y:738,t:1526923082330};\\\", \\\"{x:540,y:740,t:1526923082348};\\\", \\\"{x:534,y:743,t:1526923082364};\\\", \\\"{x:528,y:748,t:1526923082381};\\\", \\\"{x:524,y:751,t:1526923082398};\\\", \\\"{x:521,y:753,t:1526923082415};\\\", \\\"{x:521,y:754,t:1526923082495};\\\", \\\"{x:521,y:755,t:1526923082543};\\\", \\\"{x:521,y:756,t:1526923083007};\\\", \\\"{x:521,y:757,t:1526923083087};\\\", \\\"{x:522,y:757,t:1526923083160};\\\", \\\"{x:523,y:758,t:1526923083288};\\\", \\\"{x:523,y:759,t:1526923083455};\\\", \\\"{x:522,y:760,t:1526923083855};\\\", \\\"{x:522,y:761,t:1526923083919};\\\", \\\"{x:521,y:761,t:1526923084128};\\\" ] }, { \\\"rt\\\": 37057, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 552439, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"F and B begin there shift.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6935, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"u.S.\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 560376, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 12263, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 573661, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 64953, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 639692, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DOQRP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DOQRP\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 398, dom: 1238, initialDom: 2754",
  "javascriptErrors": []
}