var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a7af2904dddc38c21b2f2700a41ef2f5",
  "created": "2018-05-21T10:18:03.6152361-07:00",
  "lastActivity": "2018-05-21T10:20:11.1242361-07:00",
  "pageViews": [
    {
      "id": "05210398e1cf97ee8b54ce35df3cef7c6d6773fe",
      "startTime": "2018-05-21T10:18:03.6152361-07:00",
      "endTime": "2018-05-21T10:20:11.1242361-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 127509,
      "engagementTime": 126126,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 127509,
  "engagementTime": 126126,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=DOQRP",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bb26aacbc194f7fd1cd9fadd3e1bd457",
  "gdpr": false
}