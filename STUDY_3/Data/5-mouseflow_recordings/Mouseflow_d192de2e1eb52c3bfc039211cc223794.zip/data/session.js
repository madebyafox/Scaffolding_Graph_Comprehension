var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d192de2e1eb52c3bfc039211cc223794",
  "created": "2018-06-04T12:17:46.3109381-07:00",
  "lastActivity": "2018-06-04T12:19:26.3209381-07:00",
  "pageViews": [
    {
      "id": "060446968f82a4dfdc10211a6798cd5c10576e1c",
      "startTime": "2018-06-04T12:17:46.3109381-07:00",
      "endTime": "2018-06-04T12:19:26.3209381-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 100010,
      "engagementTime": 98907,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 100010,
  "engagementTime": 98907,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c7d36b97d1f75636031312299a34c22c",
  "gdpr": false
}