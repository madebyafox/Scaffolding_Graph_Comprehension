var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060420462ae72ea05243f7f52d690b1e204dc179"] = {
  "startTime": "2018-06-04T20:25:20.2285153Z",
  "websitePageUrl": "/16",
  "visitTime": 311480,
  "engagementTime": 279183,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "87560a712103a4cb4851475b30e61739",
    "created": "2018-06-04T20:25:20.2285153+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=AV66J",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "eb0c2d0879c42a235c36ab4c85fd5783",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/87560a712103a4cb4851475b30e61739/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 219,
      "e": 219,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 8501,
      "e": 5219,
      "ty": 2,
      "x": 539,
      "y": 752
    },
    {
      "t": 8502,
      "e": 5220,
      "ty": 41,
      "x": 49674,
      "y": 41215,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8601,
      "e": 5319,
      "ty": 2,
      "x": 683,
      "y": 729
    },
    {
      "t": 8751,
      "e": 5469,
      "ty": 41,
      "x": 166,
      "y": 41962,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 9001,
      "e": 5719,
      "ty": 2,
      "x": 649,
      "y": 718
    },
    {
      "t": 9002,
      "e": 5720,
      "ty": 41,
      "x": 62039,
      "y": 39332,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 9037,
      "e": 5755,
      "ty": 6,
      "x": 363,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9101,
      "e": 5819,
      "ty": 2,
      "x": 260,
      "y": 543
    },
    {
      "t": 9251,
      "e": 5969,
      "ty": 41,
      "x": 18312,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9401,
      "e": 6119,
      "ty": 2,
      "x": 295,
      "y": 563
    },
    {
      "t": 9501,
      "e": 6219,
      "ty": 2,
      "x": 317,
      "y": 573
    },
    {
      "t": 9501,
      "e": 6219,
      "ty": 41,
      "x": 24719,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9601,
      "e": 6319,
      "ty": 2,
      "x": 323,
      "y": 576
    },
    {
      "t": 9752,
      "e": 6470,
      "ty": 41,
      "x": 25394,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9801,
      "e": 6519,
      "ty": 2,
      "x": 310,
      "y": 594
    },
    {
      "t": 9804,
      "e": 6522,
      "ty": 7,
      "x": 285,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9901,
      "e": 6619,
      "ty": 2,
      "x": 271,
      "y": 632
    },
    {
      "t": 10002,
      "e": 6720,
      "ty": 41,
      "x": 19548,
      "y": 34567,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10002,
      "e": 6720,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10201,
      "e": 6919,
      "ty": 2,
      "x": 271,
      "y": 633
    },
    {
      "t": 10251,
      "e": 6969,
      "ty": 41,
      "x": 0,
      "y": 11315,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 10301,
      "e": 7019,
      "ty": 2,
      "x": 350,
      "y": 632
    },
    {
      "t": 10401,
      "e": 7119,
      "ty": 2,
      "x": 389,
      "y": 607
    },
    {
      "t": 10405,
      "e": 7123,
      "ty": 6,
      "x": 392,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10501,
      "e": 7219,
      "ty": 2,
      "x": 398,
      "y": 592
    },
    {
      "t": 10501,
      "e": 7219,
      "ty": 41,
      "x": 33824,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10601,
      "e": 7319,
      "ty": 2,
      "x": 400,
      "y": 587
    },
    {
      "t": 10701,
      "e": 7419,
      "ty": 2,
      "x": 403,
      "y": 581
    },
    {
      "t": 10751,
      "e": 7469,
      "ty": 41,
      "x": 34386,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10782,
      "e": 7500,
      "ty": 3,
      "x": 403,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10784,
      "e": 7502,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10860,
      "e": 7578,
      "ty": 4,
      "x": 34386,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10860,
      "e": 7578,
      "ty": 5,
      "x": 403,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13201,
      "e": 9919,
      "ty": 2,
      "x": 459,
      "y": 561
    },
    {
      "t": 13251,
      "e": 9969,
      "ty": 41,
      "x": 41468,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13301,
      "e": 10019,
      "ty": 2,
      "x": 467,
      "y": 557
    },
    {
      "t": 13501,
      "e": 10219,
      "ty": 2,
      "x": 470,
      "y": 561
    },
    {
      "t": 13501,
      "e": 10219,
      "ty": 41,
      "x": 41918,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13601,
      "e": 10319,
      "ty": 2,
      "x": 471,
      "y": 562
    },
    {
      "t": 13751,
      "e": 10469,
      "ty": 41,
      "x": 42030,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13902,
      "e": 10620,
      "ty": 2,
      "x": 471,
      "y": 563
    },
    {
      "t": 14001,
      "e": 10719,
      "ty": 2,
      "x": 479,
      "y": 552
    },
    {
      "t": 14001,
      "e": 10719,
      "ty": 41,
      "x": 42930,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14101,
      "e": 10819,
      "ty": 2,
      "x": 480,
      "y": 551
    },
    {
      "t": 14201,
      "e": 10919,
      "ty": 2,
      "x": 476,
      "y": 556
    },
    {
      "t": 14251,
      "e": 10969,
      "ty": 41,
      "x": 42143,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14301,
      "e": 11019,
      "ty": 2,
      "x": 471,
      "y": 563
    },
    {
      "t": 14401,
      "e": 11119,
      "ty": 2,
      "x": 470,
      "y": 564
    },
    {
      "t": 14501,
      "e": 11219,
      "ty": 41,
      "x": 41918,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14567,
      "e": 11285,
      "ty": 3,
      "x": 470,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14601,
      "e": 11319,
      "ty": 2,
      "x": 471,
      "y": 565
    },
    {
      "t": 14669,
      "e": 11387,
      "ty": 4,
      "x": 42030,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14669,
      "e": 11387,
      "ty": 5,
      "x": 471,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14752,
      "e": 11470,
      "ty": 41,
      "x": 42030,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15001,
      "e": 11719,
      "ty": 2,
      "x": 471,
      "y": 566
    },
    {
      "t": 15001,
      "e": 11719,
      "ty": 41,
      "x": 42030,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15493,
      "e": 12211,
      "ty": 7,
      "x": 610,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15502,
      "e": 12220,
      "ty": 2,
      "x": 610,
      "y": 604
    },
    {
      "t": 15502,
      "e": 12220,
      "ty": 41,
      "x": 57655,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 15544,
      "e": 12262,
      "ty": 6,
      "x": 650,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15601,
      "e": 12319,
      "ty": 2,
      "x": 650,
      "y": 600
    },
    {
      "t": 15701,
      "e": 12419,
      "ty": 2,
      "x": 650,
      "y": 597
    },
    {
      "t": 15751,
      "e": 12469,
      "ty": 41,
      "x": 61365,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15801,
      "e": 12519,
      "ty": 2,
      "x": 631,
      "y": 587
    },
    {
      "t": 15902,
      "e": 12620,
      "ty": 2,
      "x": 598,
      "y": 581
    },
    {
      "t": 16001,
      "e": 12719,
      "ty": 41,
      "x": 56306,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16005,
      "e": 12723,
      "ty": 3,
      "x": 598,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16133,
      "e": 12851,
      "ty": 4,
      "x": 56306,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16133,
      "e": 12851,
      "ty": 5,
      "x": 598,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19998,
      "e": 16716,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21699,
      "e": 17851,
      "ty": 2,
      "x": 537,
      "y": 592
    },
    {
      "t": 21748,
      "e": 17900,
      "ty": 41,
      "x": 48438,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21798,
      "e": 17950,
      "ty": 2,
      "x": 524,
      "y": 592
    },
    {
      "t": 21898,
      "e": 18050,
      "ty": 2,
      "x": 523,
      "y": 592
    },
    {
      "t": 21999,
      "e": 18151,
      "ty": 41,
      "x": 47876,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22299,
      "e": 18451,
      "ty": 2,
      "x": 530,
      "y": 579
    },
    {
      "t": 22399,
      "e": 18551,
      "ty": 2,
      "x": 557,
      "y": 561
    },
    {
      "t": 22498,
      "e": 18650,
      "ty": 2,
      "x": 558,
      "y": 561
    },
    {
      "t": 22499,
      "e": 18651,
      "ty": 41,
      "x": 51810,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22588,
      "e": 18740,
      "ty": 3,
      "x": 558,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22722,
      "e": 18874,
      "ty": 4,
      "x": 51810,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22722,
      "e": 18874,
      "ty": 5,
      "x": 558,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29999,
      "e": 23874,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30258,
      "e": 23874,
      "ty": 3,
      "x": 558,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30378,
      "e": 23994,
      "ty": 4,
      "x": 51810,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30378,
      "e": 23994,
      "ty": 5,
      "x": 558,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30620,
      "e": 24236,
      "ty": 7,
      "x": 634,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30699,
      "e": 24315,
      "ty": 2,
      "x": 676,
      "y": 514
    },
    {
      "t": 30749,
      "e": 24365,
      "ty": 41,
      "x": 65074,
      "y": 45091,
      "ta": "#.strategy > p"
    },
    {
      "t": 31099,
      "e": 24715,
      "ty": 2,
      "x": 671,
      "y": 516
    },
    {
      "t": 31153,
      "e": 24769,
      "ty": 6,
      "x": 641,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31199,
      "e": 24815,
      "ty": 2,
      "x": 591,
      "y": 547
    },
    {
      "t": 31249,
      "e": 24865,
      "ty": 41,
      "x": 51023,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31299,
      "e": 24915,
      "ty": 2,
      "x": 551,
      "y": 555
    },
    {
      "t": 31399,
      "e": 25015,
      "ty": 2,
      "x": 552,
      "y": 568
    },
    {
      "t": 31499,
      "e": 25115,
      "ty": 2,
      "x": 551,
      "y": 568
    },
    {
      "t": 31499,
      "e": 25115,
      "ty": 41,
      "x": 51023,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31925,
      "e": 25541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 32206,
      "e": 25822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32207,
      "e": 25823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32310,
      "e": 25926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 32310,
      "e": 25926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 32325,
      "e": 25941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32325,
      "e": 25941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32398,
      "e": 26014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32398,
      "e": 26014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32421,
      "e": 26037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 32517,
      "e": 26133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 32637,
      "e": 26253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32638,
      "e": 26254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32669,
      "e": 26285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To f"
    },
    {
      "t": 32800,
      "e": 26416,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To f"
    },
    {
      "t": 33405,
      "e": 27021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33405,
      "e": 27021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33493,
      "e": 27109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33494,
      "e": 27110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33534,
      "e": 27150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 33613,
      "e": 27229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33749,
      "e": 27365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33749,
      "e": 27365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33821,
      "e": 27437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33821,
      "e": 27437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33894,
      "e": 27510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 33957,
      "e": 27573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34198,
      "e": 27814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34199,
      "e": 27815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34341,
      "e": 27957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34462,
      "e": 28078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34463,
      "e": 28079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34590,
      "e": 28206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34670,
      "e": 28286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34671,
      "e": 28287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34742,
      "e": 28358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34743,
      "e": 28359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34790,
      "e": 28406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 34861,
      "e": 28477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35486,
      "e": 29102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 35486,
      "e": 29102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35597,
      "e": 29213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 35613,
      "e": 29229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35613,
      "e": 29229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35718,
      "e": 29334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35718,
      "e": 29334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35781,
      "e": 29397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 35821,
      "e": 29437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35917,
      "e": 29533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 35918,
      "e": 29534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36030,
      "e": 29646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 36062,
      "e": 29678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36062,
      "e": 29678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36149,
      "e": 29765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36150,
      "e": 29766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36165,
      "e": 29781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h "
    },
    {
      "t": 36278,
      "e": 29894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36558,
      "e": 30174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36559,
      "e": 30175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36637,
      "e": 30253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36677,
      "e": 30293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36677,
      "e": 30293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36802,
      "e": 30418,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which sh"
    },
    {
      "t": 36806,
      "e": 30422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36806,
      "e": 30422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36877,
      "e": 30493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 36925,
      "e": 30541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37021,
      "e": 30637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37022,
      "e": 30638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37110,
      "e": 30726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 37150,
      "e": 30766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37151,
      "e": 30767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37253,
      "e": 30869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37830,
      "e": 31446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 37831,
      "e": 31447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37925,
      "e": 31541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39998,
      "e": 33614,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 45079,
      "e": 36541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45079,
      "e": 36541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45200,
      "e": 36662,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts "
    },
    {
      "t": 45213,
      "e": 36675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45374,
      "e": 36836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45375,
      "e": 36837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45477,
      "e": 36939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 45517,
      "e": 36979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45517,
      "e": 36979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45598,
      "e": 37060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45702,
      "e": 37164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45702,
      "e": 37164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45765,
      "e": 37227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45765,
      "e": 37227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45821,
      "e": 37283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 45829,
      "e": 37291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45829,
      "e": 37291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45860,
      "e": 37322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45941,
      "e": 37403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46110,
      "e": 37572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46111,
      "e": 37573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46253,
      "e": 37715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46638,
      "e": 38100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46638,
      "e": 38100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46757,
      "e": 38219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46990,
      "e": 38452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46990,
      "e": 38452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47093,
      "e": 38555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47958,
      "e": 39420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47958,
      "e": 39420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48045,
      "e": 39507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48414,
      "e": 39876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 48415,
      "e": 39877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48517,
      "e": 39979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 49238,
      "e": 40700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 49238,
      "e": 40700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49341,
      "e": 40803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 50526,
      "e": 41988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50605,
      "e": 42067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 1"
    },
    {
      "t": 50710,
      "e": 42172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50773,
      "e": 42235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at "
    },
    {
      "t": 51262,
      "e": 42724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 51263,
      "e": 42725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51326,
      "e": 42788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 53109,
      "e": 44571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53229,
      "e": 44691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 53229,
      "e": 44691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53245,
      "e": 44707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 1"
    },
    {
      "t": 53277,
      "e": 44739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 53278,
      "e": 44740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53342,
      "e": 44804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 53389,
      "e": 44851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53837,
      "e": 45299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53837,
      "e": 45299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53948,
      "e": 45410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53949,
      "e": 45411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53949,
      "e": 45411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54166,
      "e": 45628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 54182,
      "e": 45644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54182,
      "e": 45644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54293,
      "e": 45755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 59998,
      "e": 50755,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74462,
      "e": 50755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74462,
      "e": 50755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74600,
      "e": 50893,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm "
    },
    {
      "t": 74612,
      "e": 50905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74924,
      "e": 51217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 74924,
      "e": 51217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75020,
      "e": 51313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 75052,
      "e": 51345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75053,
      "e": 51346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75117,
      "e": 51410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 75117,
      "e": 51410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75172,
      "e": 51465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 75229,
      "e": 51522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76717,
      "e": 53010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76717,
      "e": 53010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76812,
      "e": 53105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77125,
      "e": 53418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77125,
      "e": 53418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77244,
      "e": 53537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 77374,
      "e": 53667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77374,
      "e": 53667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77469,
      "e": 53762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 77549,
      "e": 53842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77549,
      "e": 53842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77660,
      "e": 53953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 77669,
      "e": 53962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 77669,
      "e": 53962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77756,
      "e": 54049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77757,
      "e": 54050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77796,
      "e": 54089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 77885,
      "e": 54178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79611,
      "e": 55904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79674,
      "e": 55967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you star"
    },
    {
      "t": 79799,
      "e": 56092,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you star"
    },
    {
      "t": 79827,
      "e": 56120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79851,
      "e": 56144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you sta"
    },
    {
      "t": 79995,
      "e": 56288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79996,
      "e": 56289,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80058,
      "e": 56351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you st"
    },
    {
      "t": 80339,
      "e": 56632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80419,
      "e": 56712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you s"
    },
    {
      "t": 80787,
      "e": 57080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 80890,
      "e": 57183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you "
    },
    {
      "t": 81291,
      "e": 57584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 81291,
      "e": 57584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81398,
      "e": 57691,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you g"
    },
    {
      "t": 81442,
      "e": 57735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 82050,
      "e": 58343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82155,
      "e": 58448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you "
    },
    {
      "t": 82291,
      "e": 58584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82291,
      "e": 58584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82398,
      "e": 58691,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you  "
    },
    {
      "t": 82434,
      "e": 58727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82682,
      "e": 58975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82787,
      "e": 59080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you "
    },
    {
      "t": 83795,
      "e": 60088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 83796,
      "e": 60089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83842,
      "e": 60135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 83978,
      "e": 60271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 83979,
      "e": 60272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84019,
      "e": 60312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 84130,
      "e": 60423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 84132,
      "e": 60425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84194,
      "e": 60487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 84194,
      "e": 60487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84210,
      "e": 60503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 84282,
      "e": 60575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84435,
      "e": 60728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84436,
      "e": 60729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84570,
      "e": 60863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 84715,
      "e": 61008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84717,
      "e": 61010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84866,
      "e": 61159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 84930,
      "e": 61223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 84930,
      "e": 61223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85026,
      "e": 61319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85027,
      "e": 61320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85042,
      "e": 61335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 85163,
      "e": 61456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 85203,
      "e": 61496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85204,
      "e": 61497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85299,
      "e": 61592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 85314,
      "e": 61607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85315,
      "e": 61608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85419,
      "e": 61712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 85435,
      "e": 61728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 85436,
      "e": 61729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85514,
      "e": 61807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85514,
      "e": 61807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85530,
      "e": 61823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 85634,
      "e": 61927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86259,
      "e": 62552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 86259,
      "e": 62552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86378,
      "e": 62671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86379,
      "e": 62672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86394,
      "e": 62687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x "
    },
    {
      "t": 86507,
      "e": 62800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87235,
      "e": 63528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 87236,
      "e": 63529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87354,
      "e": 63647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 87410,
      "e": 63703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 87410,
      "e": 63703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87474,
      "e": 63767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 87523,
      "e": 63816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87523,
      "e": 63816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87635,
      "e": 63928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 87667,
      "e": 63960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 87668,
      "e": 63961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87738,
      "e": 64031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87738,
      "e": 64031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87770,
      "e": 64063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 87973,
      "e": 64266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88186,
      "e": 64479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 88188,
      "e": 64481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88315,
      "e": 64608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88316,
      "e": 64609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88330,
      "e": 64623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 88419,
      "e": 64712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88971,
      "e": 65264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88971,
      "e": 65264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89090,
      "e": 65383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89235,
      "e": 65528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89238,
      "e": 65531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89322,
      "e": 65615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 89330,
      "e": 65623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89330,
      "e": 65623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89418,
      "e": 65711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 89467,
      "e": 65760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 89468,
      "e": 65761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89545,
      "e": 65838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89546,
      "e": 65839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89570,
      "e": 65839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 89634,
      "e": 65903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89754,
      "e": 66023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 89755,
      "e": 66024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89898,
      "e": 66167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 91283,
      "e": 67552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 91283,
      "e": 67552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91398,
      "e": 67667,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the po"
    },
    {
      "t": 91418,
      "e": 67687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 91506,
      "e": 67775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91507,
      "e": 67776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91578,
      "e": 67847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 91723,
      "e": 67992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 91723,
      "e": 67992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91794,
      "e": 68063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 91867,
      "e": 68136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 91867,
      "e": 68136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91971,
      "e": 68240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91972,
      "e": 68241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92002,
      "e": 68271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 92122,
      "e": 68391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93218,
      "e": 69487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93298,
      "e": 69567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point"
    },
    {
      "t": 94892,
      "e": 71161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94892,
      "e": 71161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94998,
      "e": 71267,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point "
    },
    {
      "t": 95018,
      "e": 71287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95155,
      "e": 71424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95156,
      "e": 71425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95250,
      "e": 71519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95250,
      "e": 71519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 95250,
      "e": 71519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95338,
      "e": 71607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 95362,
      "e": 71631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 95362,
      "e": 71631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95483,
      "e": 71752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95483,
      "e": 71752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95546,
      "e": 71815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 95562,
      "e": 71831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95564,
      "e": 71833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95594,
      "e": 71863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95634,
      "e": 71903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95882,
      "e": 72151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 95883,
      "e": 72152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95971,
      "e": 72240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 96051,
      "e": 72320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 96052,
      "e": 72321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96138,
      "e": 72407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 96539,
      "e": 72808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 96540,
      "e": 72809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96649,
      "e": 72918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 97522,
      "e": 73791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 97523,
      "e": 73792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97610,
      "e": 73879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 97666,
      "e": 73935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97666,
      "e": 73935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97799,
      "e": 74068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corre"
    },
    {
      "t": 97803,
      "e": 74072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 97811,
      "e": 74080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 97811,
      "e": 74080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97922,
      "e": 74191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 98155,
      "e": 74424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 98155,
      "e": 74424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98266,
      "e": 74535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 98403,
      "e": 74672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 98403,
      "e": 74672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98530,
      "e": 74799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 98530,
      "e": 74799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98562,
      "e": 74831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 98666,
      "e": 74935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98827,
      "e": 75096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 98827,
      "e": 75096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98922,
      "e": 75191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 98922,
      "e": 75191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98977,
      "e": 75246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 99010,
      "e": 75279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99010,
      "e": 75279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99058,
      "e": 75327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99163,
      "e": 75432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99996,
      "e": 76265,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100009,
      "e": 76279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 100010,
      "e": 76280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100105,
      "e": 76375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 100137,
      "e": 76407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 100138,
      "e": 76408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100282,
      "e": 76552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 102723,
      "e": 78993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102723,
      "e": 78993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102835,
      "e": 79105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103282,
      "e": 79552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 103283,
      "e": 79553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103385,
      "e": 79655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 103386,
      "e": 79656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103426,
      "e": 79696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 103514,
      "e": 79784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 104002,
      "e": 80272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 104003,
      "e": 80273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104081,
      "e": 80351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 104082,
      "e": 80352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104129,
      "e": 80399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 104210,
      "e": 80480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105050,
      "e": 81320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105050,
      "e": 81320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105161,
      "e": 81431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 105378,
      "e": 81648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 105379,
      "e": 81649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105482,
      "e": 81752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 105498,
      "e": 81768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 105499,
      "e": 81769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105587,
      "e": 81857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 105642,
      "e": 81912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 105643,
      "e": 81913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105737,
      "e": 82007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 106531,
      "e": 82801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 106531,
      "e": 82801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106674,
      "e": 82944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 106955,
      "e": 83225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 106955,
      "e": 83225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107082,
      "e": 83352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 107739,
      "e": 84009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 107739,
      "e": 84009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107833,
      "e": 84103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 107841,
      "e": 84111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 107841,
      "e": 84111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107913,
      "e": 84183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 108011,
      "e": 84281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 108011,
      "e": 84281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108090,
      "e": 84360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 108161,
      "e": 84431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 108162,
      "e": 84432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108243,
      "e": 84513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 108339,
      "e": 84609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 108339,
      "e": 84609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108434,
      "e": 84704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 108473,
      "e": 84743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 108474,
      "e": 84744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108562,
      "e": 84832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 108939,
      "e": 85209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 108939,
      "e": 85209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109050,
      "e": 85320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 109299,
      "e": 85569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 109377,
      "e": 85647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow"
    },
    {
      "t": 109539,
      "e": 85809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109539,
      "e": 85809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109682,
      "e": 85952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 109882,
      "e": 86152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 109883,
      "e": 86153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109986,
      "e": 86256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 109996,
      "e": 86266,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110194,
      "e": 86464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 110194,
      "e": 86464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110314,
      "e": 86584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 111067,
      "e": 87337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 111067,
      "e": 87337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111194,
      "e": 87464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 111410,
      "e": 87680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111411,
      "e": 87681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111562,
      "e": 87832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115787,
      "e": 92057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 115787,
      "e": 92057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115866,
      "e": 92136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 117002,
      "e": 93272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 117004,
      "e": 93274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117130,
      "e": 93400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 117242,
      "e": 93512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 117242,
      "e": 93512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117338,
      "e": 93608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 117619,
      "e": 93889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 117619,
      "e": 93889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117738,
      "e": 94008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 118850,
      "e": 95120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 118921,
      "e": 95191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the dig"
    },
    {
      "t": 119418,
      "e": 95688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119514,
      "e": 95784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the di"
    },
    {
      "t": 119667,
      "e": 95937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 119667,
      "e": 95937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119777,
      "e": 96047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 119995,
      "e": 96265,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120025,
      "e": 96295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 120026,
      "e": 96296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120114,
      "e": 96384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 120754,
      "e": 97024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 120754,
      "e": 97024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120850,
      "e": 97120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 120851,
      "e": 97121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120858,
      "e": 97128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 120961,
      "e": 97231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 121009,
      "e": 97279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 121010,
      "e": 97280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121082,
      "e": 97352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 121082,
      "e": 97352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121105,
      "e": 97375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 121186,
      "e": 97456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 122099,
      "e": 98369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122099,
      "e": 98369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122234,
      "e": 98504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 123930,
      "e": 100200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 123931,
      "e": 100201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124017,
      "e": 100287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 124121,
      "e": 100391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 124122,
      "e": 100392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124226,
      "e": 100496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 124314,
      "e": 100584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 124314,
      "e": 100584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124401,
      "e": 100671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 124402,
      "e": 100672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124425,
      "e": 100695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 124515,
      "e": 100785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 124609,
      "e": 100879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 124610,
      "e": 100880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124778,
      "e": 101048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 125097,
      "e": 101367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125098,
      "e": 101368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125199,
      "e": 101469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal light "
    },
    {
      "t": 125250,
      "e": 101520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 125899,
      "e": 102169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 125953,
      "e": 102223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal light"
    },
    {
      "t": 126073,
      "e": 102343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 126130,
      "e": 102400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal ligh"
    },
    {
      "t": 126225,
      "e": 102495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 126289,
      "e": 102559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal lig"
    },
    {
      "t": 126398,
      "e": 102668,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal lig"
    },
    {
      "t": 126410,
      "e": 102680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 126441,
      "e": 102680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal li"
    },
    {
      "t": 126598,
      "e": 102837,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal li"
    },
    {
      "t": 126890,
      "e": 103129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 126891,
      "e": 103130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126961,
      "e": 103200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 127202,
      "e": 103441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 127266,
      "e": 103505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal li"
    },
    {
      "t": 127399,
      "e": 103638,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal li"
    },
    {
      "t": 127409,
      "e": 103648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 127411,
      "e": 103650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127514,
      "e": 103753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 127546,
      "e": 103785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 127548,
      "e": 103787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127690,
      "e": 103929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 129209,
      "e": 105448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 129211,
      "e": 105450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129298,
      "e": 105537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 129399,
      "e": 105638,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line "
    },
    {
      "t": 129714,
      "e": 105953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 129714,
      "e": 105953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129809,
      "e": 106048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 129986,
      "e": 106225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 129987,
      "e": 106226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130089,
      "e": 106328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 130169,
      "e": 106408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130170,
      "e": 106409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130289,
      "e": 106528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130513,
      "e": 106752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 130514,
      "e": 106753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130634,
      "e": 106873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 130650,
      "e": 106889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 130651,
      "e": 106890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130785,
      "e": 107024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 130809,
      "e": 107048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 130809,
      "e": 107048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130898,
      "e": 107137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130898,
      "e": 107137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130945,
      "e": 107184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 131049,
      "e": 107288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131234,
      "e": 107473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 131236,
      "e": 107475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131321,
      "e": 107560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 131345,
      "e": 107584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 131345,
      "e": 107584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131441,
      "e": 107680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131442,
      "e": 107681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131465,
      "e": 107704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 131586,
      "e": 107825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 131643,
      "e": 107826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 131644,
      "e": 107827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131730,
      "e": 107913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 131746,
      "e": 107929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 131746,
      "e": 107929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131866,
      "e": 108049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 131867,
      "e": 108050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131873,
      "e": 108056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 131922,
      "e": 108105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131922,
      "e": 108105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131985,
      "e": 108168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132114,
      "e": 108297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 132121,
      "e": 108304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 132122,
      "e": 108305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132218,
      "e": 108401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 132250,
      "e": 108433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 132250,
      "e": 108433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132398,
      "e": 108581,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the ri"
    },
    {
      "t": 132418,
      "e": 108601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 132426,
      "e": 108609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 132426,
      "e": 108609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132545,
      "e": 108728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 132554,
      "e": 108737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 132554,
      "e": 108737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132641,
      "e": 108824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 132649,
      "e": 108832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 132649,
      "e": 108832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132737,
      "e": 108920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 134834,
      "e": 111017,
      "ty": 7,
      "x": 753,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134897,
      "e": 111080,
      "ty": 2,
      "x": 874,
      "y": 621
    },
    {
      "t": 134996,
      "e": 111179,
      "ty": 2,
      "x": 887,
      "y": 623
    },
    {
      "t": 134996,
      "e": 111179,
      "ty": 41,
      "x": 65534,
      "y": 37641,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > path"
    },
    {
      "t": 135096,
      "e": 111279,
      "ty": 2,
      "x": 887,
      "y": 624
    },
    {
      "t": 135196,
      "e": 111379,
      "ty": 2,
      "x": 905,
      "y": 657
    },
    {
      "t": 135247,
      "e": 111430,
      "ty": 41,
      "x": 8457,
      "y": 37960,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 135297,
      "e": 111480,
      "ty": 2,
      "x": 899,
      "y": 683
    },
    {
      "t": 135396,
      "e": 111579,
      "ty": 2,
      "x": 897,
      "y": 707
    },
    {
      "t": 135497,
      "e": 111680,
      "ty": 2,
      "x": 901,
      "y": 721
    },
    {
      "t": 135497,
      "e": 111680,
      "ty": 41,
      "x": 8104,
      "y": 41756,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 136096,
      "e": 112279,
      "ty": 2,
      "x": 911,
      "y": 401
    },
    {
      "t": 136197,
      "e": 112380,
      "ty": 2,
      "x": 905,
      "y": 308
    },
    {
      "t": 136248,
      "e": 112431,
      "ty": 41,
      "x": 8386,
      "y": 12175,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 136296,
      "e": 112479,
      "ty": 2,
      "x": 899,
      "y": 302
    },
    {
      "t": 136397,
      "e": 112580,
      "ty": 2,
      "x": 93,
      "y": 366
    },
    {
      "t": 136442,
      "e": 112625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 136443,
      "e": 112626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136496,
      "e": 112679,
      "ty": 2,
      "x": 68,
      "y": 435
    },
    {
      "t": 136496,
      "e": 112679,
      "ty": 41,
      "x": 2066,
      "y": 23654,
      "ta": "> div.stimulus"
    },
    {
      "t": 136545,
      "e": 112728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 136596,
      "e": 112779,
      "ty": 2,
      "x": 227,
      "y": 510
    },
    {
      "t": 136601,
      "e": 112784,
      "ty": 6,
      "x": 254,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136697,
      "e": 112880,
      "ty": 2,
      "x": 360,
      "y": 585
    },
    {
      "t": 136746,
      "e": 112929,
      "ty": 41,
      "x": 29553,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136797,
      "e": 112980,
      "ty": 2,
      "x": 374,
      "y": 586
    },
    {
      "t": 136897,
      "e": 113080,
      "ty": 2,
      "x": 461,
      "y": 559
    },
    {
      "t": 136935,
      "e": 113118,
      "ty": 7,
      "x": 516,
      "y": 505,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136996,
      "e": 113179,
      "ty": 2,
      "x": 529,
      "y": 463
    },
    {
      "t": 136997,
      "e": 113180,
      "ty": 41,
      "x": 48550,
      "y": 25205,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 137096,
      "e": 113279,
      "ty": 2,
      "x": 549,
      "y": 460
    },
    {
      "t": 137197,
      "e": 113380,
      "ty": 2,
      "x": 657,
      "y": 498
    },
    {
      "t": 137247,
      "e": 113430,
      "ty": 41,
      "x": 912,
      "y": 26696,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 137296,
      "e": 113479,
      "ty": 2,
      "x": 702,
      "y": 516
    },
    {
      "t": 137397,
      "e": 113580,
      "ty": 2,
      "x": 797,
      "y": 482
    },
    {
      "t": 137497,
      "e": 113680,
      "ty": 2,
      "x": 928,
      "y": 428
    },
    {
      "t": 137497,
      "e": 113680,
      "ty": 41,
      "x": 10007,
      "y": 20770,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 137597,
      "e": 113780,
      "ty": 2,
      "x": 734,
      "y": 443
    },
    {
      "t": 137696,
      "e": 113879,
      "ty": 2,
      "x": 276,
      "y": 355
    },
    {
      "t": 137747,
      "e": 113930,
      "ty": 41,
      "x": 19661,
      "y": 16729,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 137796,
      "e": 113979,
      "ty": 2,
      "x": 272,
      "y": 309
    },
    {
      "t": 137897,
      "e": 114080,
      "ty": 2,
      "x": 301,
      "y": 427
    },
    {
      "t": 137996,
      "e": 114179,
      "ty": 2,
      "x": 331,
      "y": 488
    },
    {
      "t": 137997,
      "e": 114180,
      "ty": 41,
      "x": 26293,
      "y": 4875,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 138096,
      "e": 114279,
      "ty": 2,
      "x": 336,
      "y": 489
    },
    {
      "t": 138197,
      "e": 114380,
      "ty": 2,
      "x": 350,
      "y": 512
    },
    {
      "t": 138221,
      "e": 114404,
      "ty": 6,
      "x": 355,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138247,
      "e": 114430,
      "ty": 41,
      "x": 29216,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138296,
      "e": 114479,
      "ty": 2,
      "x": 358,
      "y": 529
    },
    {
      "t": 138396,
      "e": 114579,
      "ty": 2,
      "x": 364,
      "y": 529
    },
    {
      "t": 138497,
      "e": 114680,
      "ty": 2,
      "x": 380,
      "y": 526
    },
    {
      "t": 138497,
      "e": 114680,
      "ty": 41,
      "x": 31801,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138694,
      "e": 114877,
      "ty": 2,
      "x": 385,
      "y": 526
    },
    {
      "t": 138744,
      "e": 114927,
      "ty": 41,
      "x": 33262,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138795,
      "e": 114978,
      "ty": 2,
      "x": 434,
      "y": 536
    },
    {
      "t": 138894,
      "e": 115077,
      "ty": 2,
      "x": 664,
      "y": 601
    },
    {
      "t": 138902,
      "e": 115085,
      "ty": 7,
      "x": 694,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138994,
      "e": 115177,
      "ty": 2,
      "x": 850,
      "y": 666
    },
    {
      "t": 138995,
      "e": 115178,
      "ty": 41,
      "x": 4511,
      "y": 37816,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 139094,
      "e": 115277,
      "ty": 2,
      "x": 1026,
      "y": 770
    },
    {
      "t": 139195,
      "e": 115378,
      "ty": 2,
      "x": 1404,
      "y": 994
    },
    {
      "t": 139245,
      "e": 115428,
      "ty": 41,
      "x": 50382,
      "y": 58444,
      "ta": "> div.stimulus"
    },
    {
      "t": 139294,
      "e": 115477,
      "ty": 2,
      "x": 1472,
      "y": 1107
    },
    {
      "t": 139394,
      "e": 115577,
      "ty": 2,
      "x": 1443,
      "y": 1175
    },
    {
      "t": 139494,
      "e": 115677,
      "ty": 2,
      "x": 1434,
      "y": 1169
    },
    {
      "t": 139495,
      "e": 115678,
      "ty": 41,
      "x": 49108,
      "y": 64316,
      "ta": "> div.stimulus"
    },
    {
      "t": 139594,
      "e": 115777,
      "ty": 2,
      "x": 1421,
      "y": 1155
    },
    {
      "t": 139695,
      "e": 115878,
      "ty": 2,
      "x": 1333,
      "y": 1052
    },
    {
      "t": 139745,
      "e": 115928,
      "ty": 41,
      "x": 29033,
      "y": 51496,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 139794,
      "e": 115977,
      "ty": 2,
      "x": 1160,
      "y": 712
    },
    {
      "t": 139895,
      "e": 116078,
      "ty": 2,
      "x": 1173,
      "y": 655
    },
    {
      "t": 139994,
      "e": 116177,
      "ty": 2,
      "x": 1178,
      "y": 709
    },
    {
      "t": 139995,
      "e": 116178,
      "ty": 41,
      "x": 27624,
      "y": 40896,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 139995,
      "e": 116178,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140094,
      "e": 116277,
      "ty": 2,
      "x": 1176,
      "y": 838
    },
    {
      "t": 140195,
      "e": 116378,
      "ty": 2,
      "x": 1157,
      "y": 905
    },
    {
      "t": 140245,
      "e": 116428,
      "ty": 41,
      "x": 25369,
      "y": 57083,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 140295,
      "e": 116478,
      "ty": 2,
      "x": 1137,
      "y": 952
    },
    {
      "t": 140394,
      "e": 116577,
      "ty": 2,
      "x": 1131,
      "y": 971
    },
    {
      "t": 140495,
      "e": 116678,
      "ty": 2,
      "x": 1131,
      "y": 976
    },
    {
      "t": 140495,
      "e": 116678,
      "ty": 41,
      "x": 24312,
      "y": 60020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 140594,
      "e": 116777,
      "ty": 2,
      "x": 1135,
      "y": 978
    },
    {
      "t": 140745,
      "e": 116928,
      "ty": 41,
      "x": 3349,
      "y": 37119,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 140794,
      "e": 116977,
      "ty": 2,
      "x": 1139,
      "y": 974
    },
    {
      "t": 140894,
      "e": 117077,
      "ty": 2,
      "x": 1170,
      "y": 913
    },
    {
      "t": 140994,
      "e": 117177,
      "ty": 2,
      "x": 1206,
      "y": 831
    },
    {
      "t": 140994,
      "e": 117177,
      "ty": 41,
      "x": 29597,
      "y": 49634,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 141094,
      "e": 117277,
      "ty": 2,
      "x": 1219,
      "y": 805
    },
    {
      "t": 141194,
      "e": 117377,
      "ty": 2,
      "x": 1236,
      "y": 764
    },
    {
      "t": 141244,
      "e": 117427,
      "ty": 41,
      "x": 32557,
      "y": 43331,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 141294,
      "e": 117477,
      "ty": 2,
      "x": 1253,
      "y": 731
    },
    {
      "t": 141394,
      "e": 117577,
      "ty": 2,
      "x": 1273,
      "y": 698
    },
    {
      "t": 141495,
      "e": 117678,
      "ty": 2,
      "x": 1305,
      "y": 635
    },
    {
      "t": 141495,
      "e": 117678,
      "ty": 41,
      "x": 36573,
      "y": 35596,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 141594,
      "e": 117777,
      "ty": 2,
      "x": 1330,
      "y": 566
    },
    {
      "t": 141695,
      "e": 117878,
      "ty": 2,
      "x": 1350,
      "y": 525
    },
    {
      "t": 141745,
      "e": 117928,
      "ty": 41,
      "x": 40379,
      "y": 25999,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 141794,
      "e": 117977,
      "ty": 2,
      "x": 1369,
      "y": 478
    },
    {
      "t": 141895,
      "e": 118078,
      "ty": 2,
      "x": 1387,
      "y": 432
    },
    {
      "t": 141995,
      "e": 118178,
      "ty": 2,
      "x": 1410,
      "y": 374
    },
    {
      "t": 141995,
      "e": 118178,
      "ty": 41,
      "x": 43972,
      "y": 16903,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 142094,
      "e": 118277,
      "ty": 2,
      "x": 1417,
      "y": 360
    },
    {
      "t": 142195,
      "e": 118378,
      "ty": 2,
      "x": 1418,
      "y": 360
    },
    {
      "t": 142245,
      "e": 118428,
      "ty": 41,
      "x": 44395,
      "y": 16974,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 142294,
      "e": 118477,
      "ty": 2,
      "x": 1369,
      "y": 507
    },
    {
      "t": 142394,
      "e": 118577,
      "ty": 2,
      "x": 1166,
      "y": 1022
    },
    {
      "t": 142495,
      "e": 118678,
      "ty": 2,
      "x": 1118,
      "y": 1190
    },
    {
      "t": 142594,
      "e": 118777,
      "ty": 2,
      "x": 1139,
      "y": 1159
    },
    {
      "t": 142695,
      "e": 118878,
      "ty": 2,
      "x": 1219,
      "y": 973
    },
    {
      "t": 142795,
      "e": 118978,
      "ty": 2,
      "x": 1251,
      "y": 817
    },
    {
      "t": 142895,
      "e": 119078,
      "ty": 2,
      "x": 1251,
      "y": 801
    },
    {
      "t": 142994,
      "e": 119177,
      "ty": 2,
      "x": 1228,
      "y": 813
    },
    {
      "t": 142995,
      "e": 119178,
      "ty": 41,
      "x": 18517,
      "y": 47103,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 143095,
      "e": 119278,
      "ty": 2,
      "x": 1165,
      "y": 898
    },
    {
      "t": 143194,
      "e": 119377,
      "ty": 2,
      "x": 1157,
      "y": 911
    },
    {
      "t": 143245,
      "e": 119428,
      "ty": 41,
      "x": 25510,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 143294,
      "e": 119477,
      "ty": 2,
      "x": 1144,
      "y": 984
    },
    {
      "t": 143395,
      "e": 119578,
      "ty": 2,
      "x": 1141,
      "y": 997
    },
    {
      "t": 143495,
      "e": 119678,
      "ty": 2,
      "x": 1194,
      "y": 833
    },
    {
      "t": 143496,
      "e": 119679,
      "ty": 41,
      "x": 28751,
      "y": 49777,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 143595,
      "e": 119778,
      "ty": 2,
      "x": 1229,
      "y": 645
    },
    {
      "t": 143694,
      "e": 119877,
      "ty": 2,
      "x": 1219,
      "y": 609
    },
    {
      "t": 143745,
      "e": 119928,
      "ty": 41,
      "x": 25369,
      "y": 31585,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 143794,
      "e": 119977,
      "ty": 2,
      "x": 928,
      "y": 560
    },
    {
      "t": 143894,
      "e": 120077,
      "ty": 2,
      "x": 725,
      "y": 581
    },
    {
      "t": 143994,
      "e": 120177,
      "ty": 2,
      "x": 711,
      "y": 591
    },
    {
      "t": 143995,
      "e": 120178,
      "ty": 41,
      "x": 1773,
      "y": 32163,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 144073,
      "e": 120256,
      "ty": 6,
      "x": 670,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144094,
      "e": 120277,
      "ty": 2,
      "x": 632,
      "y": 574
    },
    {
      "t": 144194,
      "e": 120377,
      "ty": 2,
      "x": 545,
      "y": 566
    },
    {
      "t": 144245,
      "e": 120428,
      "ty": 41,
      "x": 51023,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144294,
      "e": 120477,
      "ty": 2,
      "x": 553,
      "y": 574
    },
    {
      "t": 144494,
      "e": 120677,
      "ty": 2,
      "x": 534,
      "y": 583
    },
    {
      "t": 144495,
      "e": 120678,
      "ty": 41,
      "x": 49112,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144595,
      "e": 120778,
      "ty": 2,
      "x": 477,
      "y": 556
    },
    {
      "t": 144695,
      "e": 120878,
      "ty": 2,
      "x": 380,
      "y": 545
    },
    {
      "t": 144745,
      "e": 120928,
      "ty": 41,
      "x": 30340,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144790,
      "e": 120973,
      "ty": 7,
      "x": 363,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144794,
      "e": 120977,
      "ty": 2,
      "x": 363,
      "y": 518
    },
    {
      "t": 144894,
      "e": 121077,
      "ty": 2,
      "x": 368,
      "y": 504
    },
    {
      "t": 144995,
      "e": 121178,
      "ty": 2,
      "x": 429,
      "y": 486
    },
    {
      "t": 144995,
      "e": 121178,
      "ty": 41,
      "x": 37309,
      "y": 3968,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 145095,
      "e": 121278,
      "ty": 2,
      "x": 456,
      "y": 496
    },
    {
      "t": 145123,
      "e": 121306,
      "ty": 6,
      "x": 531,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145156,
      "e": 121339,
      "ty": 7,
      "x": 703,
      "y": 619,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145194,
      "e": 121377,
      "ty": 2,
      "x": 801,
      "y": 655
    },
    {
      "t": 145245,
      "e": 121428,
      "ty": 41,
      "x": 45925,
      "y": 53758,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 145295,
      "e": 121478,
      "ty": 2,
      "x": 825,
      "y": 663
    },
    {
      "t": 145395,
      "e": 121578,
      "ty": 2,
      "x": 728,
      "y": 606
    },
    {
      "t": 145494,
      "e": 121677,
      "ty": 2,
      "x": 710,
      "y": 593
    },
    {
      "t": 145495,
      "e": 121678,
      "ty": 41,
      "x": 1716,
      "y": 32305,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 145594,
      "e": 121777,
      "ty": 2,
      "x": 765,
      "y": 557
    },
    {
      "t": 145694,
      "e": 121877,
      "ty": 2,
      "x": 767,
      "y": 554
    },
    {
      "t": 145745,
      "e": 121928,
      "ty": 41,
      "x": 4988,
      "y": 29536,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 147264,
      "e": 123447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 147264,
      "e": 123447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147366,
      "e": 123549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 147503,
      "e": 123686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 147639,
      "e": 123822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 147640,
      "e": 123823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147766,
      "e": 123949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 147774,
      "e": 123957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 147807,
      "e": 123990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 147807,
      "e": 123990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 147911,
      "e": 124094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 147912,
      "e": 124095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 147913,
      "e": 124096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148039,
      "e": 124222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 148102,
      "e": 124285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 148103,
      "e": 124286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148207,
      "e": 124390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 148215,
      "e": 124398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 148215,
      "e": 124398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148295,
      "e": 124478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 148295,
      "e": 124478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148335,
      "e": 124518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 148415,
      "e": 124598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 148543,
      "e": 124726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 148544,
      "e": 124727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 148655,
      "e": 124838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 149559,
      "e": 125742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 149560,
      "e": 125743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149671,
      "e": 125854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 149823,
      "e": 126006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 149824,
      "e": 126007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149934,
      "e": 126117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 149935,
      "e": 126118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 149942,
      "e": 126125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 149994,
      "e": 126177,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150086,
      "e": 126269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 150087,
      "e": 126270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150110,
      "e": 126293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 150231,
      "e": 126414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 150231,
      "e": 126414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150302,
      "e": 126485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 150359,
      "e": 126542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 150359,
      "e": 126542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150383,
      "e": 126566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 150470,
      "e": 126653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 150575,
      "e": 126758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 150576,
      "e": 126759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150718,
      "e": 126901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 151479,
      "e": 127662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 151480,
      "e": 127663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151527,
      "e": 127710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 151527,
      "e": 127710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151559,
      "e": 127742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 151662,
      "e": 127845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 151847,
      "e": 128030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 151848,
      "e": 128031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 151950,
      "e": 128133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 151966,
      "e": 128149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 151966,
      "e": 128149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152022,
      "e": 128205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 152023,
      "e": 128206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152046,
      "e": 128229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 152127,
      "e": 128310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 152200,
      "e": 128383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 152200,
      "e": 128383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152294,
      "e": 128477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 152319,
      "e": 128502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 152319,
      "e": 128502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152359,
      "e": 128542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 152359,
      "e": 128542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152414,
      "e": 128597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 152503,
      "e": 128686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 152543,
      "e": 128726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 152544,
      "e": 128727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152679,
      "e": 128862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 152752,
      "e": 128935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 152752,
      "e": 128935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 152894,
      "e": 129077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 152951,
      "e": 129134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 152952,
      "e": 129135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153103,
      "e": 129286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 156594,
      "e": 132777,
      "ty": 2,
      "x": 737,
      "y": 589
    },
    {
      "t": 156694,
      "e": 132877,
      "ty": 2,
      "x": 631,
      "y": 655
    },
    {
      "t": 156744,
      "e": 132927,
      "ty": 41,
      "x": 55519,
      "y": 36229,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 156794,
      "e": 132977,
      "ty": 2,
      "x": 571,
      "y": 662
    },
    {
      "t": 156894,
      "e": 133077,
      "ty": 2,
      "x": 570,
      "y": 638
    },
    {
      "t": 156994,
      "e": 133177,
      "ty": 2,
      "x": 582,
      "y": 606
    },
    {
      "t": 156994,
      "e": 133177,
      "ty": 41,
      "x": 54508,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 157094,
      "e": 133277,
      "ty": 2,
      "x": 592,
      "y": 605
    },
    {
      "t": 157194,
      "e": 133377,
      "ty": 2,
      "x": 600,
      "y": 619
    },
    {
      "t": 157244,
      "e": 133427,
      "ty": 41,
      "x": 56306,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 157294,
      "e": 133477,
      "ty": 2,
      "x": 596,
      "y": 638
    },
    {
      "t": 157495,
      "e": 133678,
      "ty": 41,
      "x": 56082,
      "y": 34900,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 157595,
      "e": 133778,
      "ty": 2,
      "x": 609,
      "y": 634
    },
    {
      "t": 157745,
      "e": 133928,
      "ty": 41,
      "x": 57543,
      "y": 34678,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 157894,
      "e": 134077,
      "ty": 2,
      "x": 608,
      "y": 632
    },
    {
      "t": 157994,
      "e": 134177,
      "ty": 2,
      "x": 578,
      "y": 611
    },
    {
      "t": 157995,
      "e": 134178,
      "ty": 41,
      "x": 54058,
      "y": 65123,
      "ta": "#.strategy"
    },
    {
      "t": 158094,
      "e": 134277,
      "ty": 2,
      "x": 579,
      "y": 623
    },
    {
      "t": 158194,
      "e": 134377,
      "ty": 2,
      "x": 566,
      "y": 656
    },
    {
      "t": 158245,
      "e": 134428,
      "ty": 41,
      "x": 48550,
      "y": 35897,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 158284,
      "e": 134467,
      "ty": 6,
      "x": 350,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158294,
      "e": 134477,
      "ty": 2,
      "x": 350,
      "y": 588
    },
    {
      "t": 158394,
      "e": 134577,
      "ty": 2,
      "x": 244,
      "y": 536
    },
    {
      "t": 158494,
      "e": 134677,
      "ty": 2,
      "x": 243,
      "y": 536
    },
    {
      "t": 158495,
      "e": 134678,
      "ty": 41,
      "x": 16401,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158594,
      "e": 134777,
      "ty": 2,
      "x": 245,
      "y": 539
    },
    {
      "t": 158695,
      "e": 134878,
      "ty": 2,
      "x": 265,
      "y": 548
    },
    {
      "t": 158745,
      "e": 134928,
      "ty": 41,
      "x": 18874,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 158794,
      "e": 134977,
      "ty": 2,
      "x": 269,
      "y": 550
    },
    {
      "t": 158894,
      "e": 135077,
      "ty": 2,
      "x": 295,
      "y": 567
    },
    {
      "t": 158994,
      "e": 135177,
      "ty": 2,
      "x": 297,
      "y": 572
    },
    {
      "t": 158995,
      "e": 135178,
      "ty": 41,
      "x": 22471,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159101,
      "e": 135284,
      "ty": 3,
      "x": 297,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159178,
      "e": 135361,
      "ty": 4,
      "x": 22471,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159178,
      "e": 135361,
      "ty": 5,
      "x": 297,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159585,
      "e": 135768,
      "ty": 7,
      "x": 297,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 159594,
      "e": 135777,
      "ty": 2,
      "x": 297,
      "y": 606
    },
    {
      "t": 159695,
      "e": 135878,
      "ty": 2,
      "x": 299,
      "y": 618
    },
    {
      "t": 159745,
      "e": 135928,
      "ty": 41,
      "x": 22696,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 159894,
      "e": 136077,
      "ty": 2,
      "x": 299,
      "y": 623
    },
    {
      "t": 159995,
      "e": 136178,
      "ty": 41,
      "x": 22696,
      "y": 34069,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 159995,
      "e": 136178,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160594,
      "e": 136777,
      "ty": 2,
      "x": 291,
      "y": 630
    },
    {
      "t": 160745,
      "e": 136928,
      "ty": 41,
      "x": 21796,
      "y": 34457,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 162151,
      "e": 138334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 162151,
      "e": 138334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162198,
      "e": 138381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 162222,
      "e": 138405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 162222,
      "e": 138405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162319,
      "e": 138502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 162551,
      "e": 138734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 162551,
      "e": 138734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 162671,
      "e": 138854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 163159,
      "e": 139342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 163223,
      "e": 139406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be mm"
    },
    {
      "t": 163326,
      "e": 139509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 163383,
      "e": 139566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be m"
    },
    {
      "t": 163479,
      "e": 139662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 163542,
      "e": 139725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be "
    },
    {
      "t": 163775,
      "e": 139958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 164063,
      "e": 140246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 164064,
      "e": 140247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 164110,
      "e": 140293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 164126,
      "e": 140309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 164279,
      "e": 140462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 164281,
      "e": 140464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 164326,
      "e": 140509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 164326,
      "e": 140509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 164407,
      "e": 140590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 164470,
      "e": 140653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 164471,
      "e": 140654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 164486,
      "e": 140669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 164567,
      "e": 140750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 164591,
      "e": 140774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 164592,
      "e": 140775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 164719,
      "e": 140902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 165070,
      "e": 141253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 165070,
      "e": 141253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 165196,
      "e": 141379,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and "
    },
    {
      "t": 165207,
      "e": 141390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 165400,
      "e": 141391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 165758,
      "e": 141749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 165760,
      "e": 141751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 165838,
      "e": 141829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 165927,
      "e": 141918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 166823,
      "e": 142814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 166823,
      "e": 142814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 166886,
      "e": 142877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 166997,
      "e": 142988,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L."
    },
    {
      "t": 167006,
      "e": 142997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 167007,
      "e": 142998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 167134,
      "e": 143125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 167534,
      "e": 143525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 167863,
      "e": 143854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 167864,
      "e": 143855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 167943,
      "e": 143934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 167975,
      "e": 143966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 168038,
      "e": 144029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 168039,
      "e": 144030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168129,
      "e": 144120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 168166,
      "e": 144157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 168166,
      "e": 144157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168302,
      "e": 144293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 168470,
      "e": 144461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 168471,
      "e": 144462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168582,
      "e": 144573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 168583,
      "e": 144574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 168583,
      "e": 144574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168679,
      "e": 144670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 168783,
      "e": 144774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 168784,
      "e": 144775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168927,
      "e": 144918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 168927,
      "e": 144918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 168943,
      "e": 144934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 169086,
      "e": 145077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 169160,
      "e": 145151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 169160,
      "e": 145151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 169262,
      "e": 145253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 169302,
      "e": 145293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 169303,
      "e": 145294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 169447,
      "e": 145438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 169448,
      "e": 145439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 169455,
      "e": 145446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 169543,
      "e": 145534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 170022,
      "e": 146013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 170142,
      "e": 146133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. To see wh"
    },
    {
      "t": 171382,
      "e": 147373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 171382,
      "e": 147373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 171510,
      "e": 147501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 171839,
      "e": 147830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 171839,
      "e": 147830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 171918,
      "e": 147909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 171990,
      "e": 147981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 171991,
      "e": 147982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 172110,
      "e": 148101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 176894,
      "e": 152885,
      "ty": 2,
      "x": 290,
      "y": 630
    },
    {
      "t": 176994,
      "e": 152985,
      "ty": 41,
      "x": 21684,
      "y": 34457,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 178951,
      "e": 154942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 178952,
      "e": 154943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 179102,
      "e": 155093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 179383,
      "e": 155374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 179385,
      "e": 155376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 179518,
      "e": 155509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 179559,
      "e": 155550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 179559,
      "e": 155550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 179613,
      "e": 155604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 179614,
      "e": 155605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 179686,
      "e": 155677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 179742,
      "e": 155733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 179994,
      "e": 155985,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180006,
      "e": 155997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 180006,
      "e": 155997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 180094,
      "e": 156085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 180196,
      "e": 156187,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. To see which shif"
    },
    {
      "t": 180254,
      "e": 156245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 180254,
      "e": 156245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 180359,
      "e": 156350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 181007,
      "e": 156998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 181007,
      "e": 156998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181118,
      "e": 157109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 181119,
      "e": 157110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181149,
      "e": 157140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 181246,
      "e": 157237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 181342,
      "e": 157333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 181343,
      "e": 157334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181438,
      "e": 157429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 181591,
      "e": 157582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 181591,
      "e": 157582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181782,
      "e": 157773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 181790,
      "e": 157781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 181791,
      "e": 157782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181838,
      "e": 157829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 181839,
      "e": 157830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 181910,
      "e": 157901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 181974,
      "e": 157965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 182014,
      "e": 158005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 182014,
      "e": 158005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 182126,
      "e": 158117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 182319,
      "e": 158310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 182319,
      "e": 158310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 182406,
      "e": 158397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 182406,
      "e": 158397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 182438,
      "e": 158429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 182542,
      "e": 158533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 184045,
      "e": 160036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 184046,
      "e": 160037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 184150,
      "e": 160141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 184150,
      "e": 160141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 184190,
      "e": 160181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 184270,
      "e": 160261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 186091,
      "e": 162082,
      "ty": 6,
      "x": 342,
      "y": 563,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186094,
      "e": 162085,
      "ty": 2,
      "x": 342,
      "y": 563
    },
    {
      "t": 186106,
      "e": 162097,
      "ty": 7,
      "x": 387,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186194,
      "e": 162185,
      "ty": 2,
      "x": 442,
      "y": 476
    },
    {
      "t": 186244,
      "e": 162235,
      "ty": 41,
      "x": 38883,
      "y": 25925,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 186294,
      "e": 162285,
      "ty": 2,
      "x": 443,
      "y": 476
    },
    {
      "t": 186594,
      "e": 162585,
      "ty": 2,
      "x": 450,
      "y": 471
    },
    {
      "t": 186741,
      "e": 162732,
      "ty": 6,
      "x": 373,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186745,
      "e": 162736,
      "ty": 41,
      "x": 31014,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186794,
      "e": 162785,
      "ty": 2,
      "x": 277,
      "y": 603
    },
    {
      "t": 186806,
      "e": 162797,
      "ty": 7,
      "x": 272,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186894,
      "e": 162885,
      "ty": 2,
      "x": 271,
      "y": 608
    },
    {
      "t": 186990,
      "e": 162981,
      "ty": 6,
      "x": 290,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 186994,
      "e": 162985,
      "ty": 2,
      "x": 290,
      "y": 602
    },
    {
      "t": 186994,
      "e": 162985,
      "ty": 41,
      "x": 21684,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 187094,
      "e": 163085,
      "ty": 2,
      "x": 301,
      "y": 588
    },
    {
      "t": 187194,
      "e": 163185,
      "ty": 2,
      "x": 325,
      "y": 569
    },
    {
      "t": 187244,
      "e": 163235,
      "ty": 41,
      "x": 26068,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 187294,
      "e": 163285,
      "ty": 2,
      "x": 331,
      "y": 569
    },
    {
      "t": 187394,
      "e": 163385,
      "ty": 2,
      "x": 334,
      "y": 571
    },
    {
      "t": 187494,
      "e": 163485,
      "ty": 41,
      "x": 26630,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 187683,
      "e": 163674,
      "ty": 3,
      "x": 334,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 187794,
      "e": 163785,
      "ty": 4,
      "x": 26630,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 187794,
      "e": 163785,
      "ty": 5,
      "x": 334,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 188655,
      "e": 164646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 188796,
      "e": 164787,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. o see which shifts end at 12"
    },
    {
      "t": 188798,
      "e": 164787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. o see which shifts end at 12"
    },
    {
      "t": 188983,
      "e": 164972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 189134,
      "e": 165123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 189135,
      "e": 165124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 189150,
      "e": 165139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Co see which shifts end at 12"
    },
    {
      "t": 189222,
      "e": 165211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 189294,
      "e": 165283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 189294,
      "e": 165283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 189366,
      "e": 165355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 189366,
      "e": 165355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 189398,
      "e": 165387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Cono see which shifts end at 12"
    },
    {
      "t": 189470,
      "e": 165459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 190118,
      "e": 166107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 190118,
      "e": 166107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 190198,
      "e": 166187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Convo see which shifts end at 12"
    },
    {
      "t": 190277,
      "e": 166266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 190279,
      "e": 166268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 190325,
      "e": 166314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 190327,
      "e": 166316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 190382,
      "e": 166317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Convero see which shifts end at 12"
    },
    {
      "t": 190437,
      "e": 166372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 190582,
      "e": 166517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 190582,
      "e": 166517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 190759,
      "e": 166694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 190760,
      "e": 166695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 190766,
      "e": 166701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Converseo see which shifts end at 12"
    },
    {
      "t": 190861,
      "e": 166796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 190934,
      "e": 166869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 190935,
      "e": 166870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 191071,
      "e": 167006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Converselo see which shifts end at 12"
    },
    {
      "t": 191222,
      "e": 167157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 191223,
      "e": 167158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 191310,
      "e": 167245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Converselyo see which shifts end at 12"
    },
    {
      "t": 191558,
      "e": 167493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 191560,
      "e": 167495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 191646,
      "e": 167495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely,o see which shifts end at 12"
    },
    {
      "t": 191734,
      "e": 167583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 191734,
      "e": 167583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 191846,
      "e": 167695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, o see which shifts end at 12"
    },
    {
      "t": 192894,
      "e": 168743,
      "ty": 2,
      "x": 476,
      "y": 571
    },
    {
      "t": 192994,
      "e": 168843,
      "ty": 2,
      "x": 493,
      "y": 571
    },
    {
      "t": 192994,
      "e": 168843,
      "ty": 41,
      "x": 44503,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193194,
      "e": 169043,
      "ty": 2,
      "x": 513,
      "y": 592
    },
    {
      "t": 193196,
      "e": 169045,
      "ty": 7,
      "x": 559,
      "y": 632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193245,
      "e": 169094,
      "ty": 41,
      "x": 52484,
      "y": 34789,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 193294,
      "e": 169143,
      "ty": 2,
      "x": 577,
      "y": 644
    },
    {
      "t": 193333,
      "e": 169182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 193333,
      "e": 169182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193395,
      "e": 169244,
      "ty": 2,
      "x": 684,
      "y": 618
    },
    {
      "t": 193429,
      "e": 169278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12"
    },
    {
      "t": 193494,
      "e": 169343,
      "ty": 2,
      "x": 731,
      "y": 599
    },
    {
      "t": 193494,
      "e": 169343,
      "ty": 41,
      "x": 2921,
      "y": 32731,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 193595,
      "e": 169444,
      "ty": 2,
      "x": 682,
      "y": 575
    },
    {
      "t": 193595,
      "e": 169444,
      "ty": 6,
      "x": 658,
      "y": 571,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193695,
      "e": 169544,
      "ty": 2,
      "x": 646,
      "y": 569
    },
    {
      "t": 193744,
      "e": 169593,
      "ty": 41,
      "x": 61702,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193794,
      "e": 169643,
      "ty": 2,
      "x": 646,
      "y": 562
    },
    {
      "t": 193894,
      "e": 169743,
      "ty": 2,
      "x": 649,
      "y": 562
    },
    {
      "t": 193923,
      "e": 169772,
      "ty": 3,
      "x": 649,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 193995,
      "e": 169844,
      "ty": 41,
      "x": 62039,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 194042,
      "e": 169891,
      "ty": 4,
      "x": 62039,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 194042,
      "e": 169891,
      "ty": 5,
      "x": 649,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 194654,
      "e": 170503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 194655,
      "e": 170504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 194790,
      "e": 170639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 194926,
      "e": 170775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 194927,
      "e": 170776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195029,
      "e": 170878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 195038,
      "e": 170887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 195038,
      "e": 170887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195133,
      "e": 170982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 195135,
      "e": 170984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195158,
      "e": 171007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 195214,
      "e": 171063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 195271,
      "e": 171120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 195271,
      "e": 171120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195358,
      "e": 171207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 195622,
      "e": 171471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 195623,
      "e": 171472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195725,
      "e": 171574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 195726,
      "e": 171575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195741,
      "e": 171590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wo"
    },
    {
      "t": 195822,
      "e": 171671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 195823,
      "e": 171672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 195879,
      "e": 171673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 195934,
      "e": 171728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 196015,
      "e": 171809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 196015,
      "e": 171809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196118,
      "e": 171912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 196135,
      "e": 171929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 196135,
      "e": 171929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196197,
      "e": 171991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 196197,
      "e": 171991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196245,
      "e": 172039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 196326,
      "e": 172120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 196606,
      "e": 172400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 196606,
      "e": 172400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196718,
      "e": 172512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 196718,
      "e": 172512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196733,
      "e": 172527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 196838,
      "e": 172632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 196894,
      "e": 172688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 196894,
      "e": 172688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 196996,
      "e": 172790,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go "
    },
    {
      "t": 197005,
      "e": 172799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 198438,
      "e": 174232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 198439,
      "e": 174233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 198565,
      "e": 174359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 198604,
      "e": 174398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 198605,
      "e": 174399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 198756,
      "e": 174550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 198781,
      "e": 174575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 198781,
      "e": 174575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 198908,
      "e": 174702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 199021,
      "e": 174815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 199021,
      "e": 174815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 199116,
      "e": 174910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 200413,
      "e": 176207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 200414,
      "e": 176208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 200524,
      "e": 176318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 200556,
      "e": 176350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 200557,
      "e": 176351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 200660,
      "e": 176454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 200756,
      "e": 176550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 200757,
      "e": 176551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 200853,
      "e": 176647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 200877,
      "e": 176671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 200877,
      "e": 176671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 200949,
      "e": 176743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 201053,
      "e": 176847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 201053,
      "e": 176847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201133,
      "e": 176927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 201205,
      "e": 176999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 201206,
      "e": 177000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201292,
      "e": 177086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 201292,
      "e": 177086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201348,
      "e": 177142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 201452,
      "e": 177246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 201541,
      "e": 177335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 201541,
      "e": 177335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201620,
      "e": 177414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 201620,
      "e": 177414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 201620,
      "e": 177414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201740,
      "e": 177534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 201821,
      "e": 177615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 201821,
      "e": 177615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 201933,
      "e": 177727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 202004,
      "e": 177798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 202005,
      "e": 177799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 202132,
      "e": 177926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 202172,
      "e": 177966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 202174,
      "e": 177968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 202268,
      "e": 178062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 202509,
      "e": 178303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 202509,
      "e": 178303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 202588,
      "e": 178382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 202588,
      "e": 178382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 202620,
      "e": 178414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 202725,
      "e": 178519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 202805,
      "e": 178599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 202805,
      "e": 178599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 202884,
      "e": 178678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 202908,
      "e": 178702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 202908,
      "e": 178702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203020,
      "e": 178814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 203028,
      "e": 178822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 203030,
      "e": 178824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203148,
      "e": 178942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 203180,
      "e": 178974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 203180,
      "e": 178974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203269,
      "e": 179063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 203277,
      "e": 179071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 203277,
      "e": 179071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203389,
      "e": 179183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 203412,
      "e": 179206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 203414,
      "e": 179208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203469,
      "e": 179263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 203470,
      "e": 179264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203499,
      "e": 179293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 203580,
      "e": 179374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 203636,
      "e": 179430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 203636,
      "e": 179430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203756,
      "e": 179550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 203766,
      "e": 179552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 203768,
      "e": 179554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203859,
      "e": 179645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 203860,
      "e": 179646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 203876,
      "e": 179662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ef"
    },
    {
      "t": 203964,
      "e": 179750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 204109,
      "e": 179895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 204109,
      "e": 179895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 204212,
      "e": 179998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 205742,
      "e": 181528,
      "ty": 41,
      "x": 58892,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 205792,
      "e": 181578,
      "ty": 2,
      "x": 618,
      "y": 552
    },
    {
      "t": 205892,
      "e": 181678,
      "ty": 2,
      "x": 577,
      "y": 603
    },
    {
      "t": 205904,
      "e": 181690,
      "ty": 7,
      "x": 578,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 205992,
      "e": 181778,
      "ty": 2,
      "x": 564,
      "y": 615
    },
    {
      "t": 205992,
      "e": 181778,
      "ty": 41,
      "x": 52484,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 206093,
      "e": 181879,
      "ty": 2,
      "x": 530,
      "y": 605
    },
    {
      "t": 206104,
      "e": 181890,
      "ty": 6,
      "x": 483,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 206193,
      "e": 181979,
      "ty": 2,
      "x": 380,
      "y": 590
    },
    {
      "t": 206242,
      "e": 182028,
      "ty": 41,
      "x": 33937,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 206292,
      "e": 182078,
      "ty": 2,
      "x": 433,
      "y": 586
    },
    {
      "t": 206392,
      "e": 182178,
      "ty": 2,
      "x": 456,
      "y": 574
    },
    {
      "t": 206492,
      "e": 182278,
      "ty": 41,
      "x": 40344,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 207379,
      "e": 183165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 207379,
      "e": 183165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 207492,
      "e": 183278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 209300,
      "e": 185086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 209300,
      "e": 185086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 209404,
      "e": 185190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 209708,
      "e": 185494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 209860,
      "e": 185646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 209860,
      "e": 185646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 209980,
      "e": 185766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 209992,
      "e": 185778,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 210011,
      "e": 185797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 210316,
      "e": 186102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 210316,
      "e": 186102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 210428,
      "e": 186214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 210452,
      "e": 186238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 210452,
      "e": 186238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 210556,
      "e": 186342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 210636,
      "e": 186422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 210636,
      "e": 186422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 210692,
      "e": 186478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 210723,
      "e": 186509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 210723,
      "e": 186509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 210843,
      "e": 186629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 210843,
      "e": 186629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 210859,
      "e": 186645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 210948,
      "e": 186734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 210963,
      "e": 186749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 210963,
      "e": 186749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211036,
      "e": 186822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 211036,
      "e": 186822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211116,
      "e": 186902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 211148,
      "e": 186934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 211268,
      "e": 187054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 211268,
      "e": 187054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211348,
      "e": 187134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 211363,
      "e": 187149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 211364,
      "e": 187150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211444,
      "e": 187230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 211476,
      "e": 187262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 211476,
      "e": 187262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211594,
      "e": 187380,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this cas"
    },
    {
      "t": 211619,
      "e": 187405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 211619,
      "e": 187405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 211659,
      "e": 187445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 211732,
      "e": 187518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 213116,
      "e": 188902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 213116,
      "e": 188902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 213236,
      "e": 189022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 215420,
      "e": 191206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 215420,
      "e": 191206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 215516,
      "e": 191302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 215564,
      "e": 191350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 215564,
      "e": 191350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 215675,
      "e": 191461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 215676,
      "e": 191462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 215676,
      "e": 191462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 215740,
      "e": 191526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 215740,
      "e": 191526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 215795,
      "e": 191581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 215899,
      "e": 191685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 215900,
      "e": 191686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 215900,
      "e": 191686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 216012,
      "e": 191798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 216396,
      "e": 192182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 216398,
      "e": 192184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 216531,
      "e": 192317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 216660,
      "e": 192446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 216660,
      "e": 192446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 216795,
      "e": 192447,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there a"
    },
    {
      "t": 216796,
      "e": 192448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 216796,
      "e": 192448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 216820,
      "e": 192472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 216940,
      "e": 192592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 216940,
      "e": 192592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 216955,
      "e": 192607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 216955,
      "e": 192607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 216956,
      "e": 192608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 217068,
      "e": 192720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 217075,
      "e": 192727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 217139,
      "e": 192791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 217140,
      "e": 192792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 217220,
      "e": 192872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 217220,
      "e": 192872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 217244,
      "e": 192896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||no"
    },
    {
      "t": 217332,
      "e": 192984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 217340,
      "e": 192992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 217340,
      "e": 192992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 217443,
      "e": 193095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 217500,
      "e": 193152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 217500,
      "e": 193152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 217587,
      "e": 193239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 218435,
      "e": 194087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 218435,
      "e": 194087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 218499,
      "e": 194151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 218660,
      "e": 194312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 218660,
      "e": 194312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 218788,
      "e": 194440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 219251,
      "e": 194903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 219420,
      "e": 195072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 219420,
      "e": 195072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 219492,
      "e": 195144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 219524,
      "e": 195176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 219628,
      "e": 195280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 219630,
      "e": 195282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 219715,
      "e": 195367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 219827,
      "e": 195479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 219827,
      "e": 195479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 219964,
      "e": 195616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 220669,
      "e": 196321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 220670,
      "e": 196322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 220772,
      "e": 196424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 220820,
      "e": 196472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 220820,
      "e": 196472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 220899,
      "e": 196551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 220995,
      "e": 196647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 220995,
      "e": 196647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 221156,
      "e": 196808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 221452,
      "e": 197104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 221452,
      "e": 197104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 221579,
      "e": 197231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 222452,
      "e": 198104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 222452,
      "e": 198104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 222555,
      "e": 198207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 222604,
      "e": 198256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 222604,
      "e": 198256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 222764,
      "e": 198416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 223132,
      "e": 198784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 223133,
      "e": 198785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 223276,
      "e": 198928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 223364,
      "e": 199016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 223365,
      "e": 199017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 223459,
      "e": 199111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 223460,
      "e": 199112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 223476,
      "e": 199128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 223572,
      "e": 199224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 223580,
      "e": 199232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 223581,
      "e": 199233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 223675,
      "e": 199327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 223812,
      "e": 199464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 223812,
      "e": 199464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 223900,
      "e": 199552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 223981,
      "e": 199633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 223982,
      "e": 199634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 224003,
      "e": 199655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 224732,
      "e": 200384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 224733,
      "e": 200385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 224820,
      "e": 200472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 224900,
      "e": 200552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 224900,
      "e": 200552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225004,
      "e": 200656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 225060,
      "e": 200712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 225061,
      "e": 200713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225148,
      "e": 200800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 225212,
      "e": 200864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 225212,
      "e": 200864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225324,
      "e": 200976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 225452,
      "e": 201104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 225453,
      "e": 201105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225491,
      "e": 201143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 225595,
      "e": 201143,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift h"
    },
    {
      "t": 225692,
      "e": 201240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 225693,
      "e": 201241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225795,
      "e": 201343,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift ha"
    },
    {
      "t": 225803,
      "e": 201351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 225828,
      "e": 201376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 225828,
      "e": 201376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 225900,
      "e": 201448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 225956,
      "e": 201504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 225957,
      "e": 201505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 226044,
      "e": 201592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 226044,
      "e": 201592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 226124,
      "e": 201672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 226188,
      "e": 201736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 226188,
      "e": 201736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 226356,
      "e": 201904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 226396,
      "e": 201944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 226437,
      "e": 201985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 226437,
      "e": 201985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 226596,
      "e": 201986,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a "
    },
    {
      "t": 226667,
      "e": 202057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 228580,
      "e": 203970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 228581,
      "e": 203971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 228684,
      "e": 204074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 228788,
      "e": 204178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 228788,
      "e": 204178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 228836,
      "e": 204226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 228836,
      "e": 204226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 228891,
      "e": 204281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 228955,
      "e": 204345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 229068,
      "e": 204458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 229069,
      "e": 204459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 229156,
      "e": 204546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 229181,
      "e": 204571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 229181,
      "e": 204571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 229260,
      "e": 204650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 229340,
      "e": 204730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 229341,
      "e": 204731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 229476,
      "e": 204866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 229644,
      "e": 205034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 229645,
      "e": 205035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 229794,
      "e": 205184,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break a"
    },
    {
      "t": 229804,
      "e": 205194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 229852,
      "e": 205242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 229852,
      "e": 205242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 229971,
      "e": 205361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 229995,
      "e": 205385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 229996,
      "e": 205386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 230108,
      "e": 205498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 231525,
      "e": 206915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 231526,
      "e": 206916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 231595,
      "e": 206985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 231596,
      "e": 206986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 231627,
      "e": 207017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 231732,
      "e": 207122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 232020,
      "e": 207410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 232021,
      "e": 207411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 232139,
      "e": 207529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 232476,
      "e": 207866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 232477,
      "e": 207867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 232564,
      "e": 207954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 232611,
      "e": 208001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 232612,
      "e": 208002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 232732,
      "e": 208122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 232735,
      "e": 208124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 232747,
      "e": 208136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 232851,
      "e": 208240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 232892,
      "e": 208281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 232892,
      "e": 208281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 232980,
      "e": 208369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 232980,
      "e": 208369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 233019,
      "e": 208408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| j"
    },
    {
      "t": 233043,
      "e": 208432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 233132,
      "e": 208521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 233132,
      "e": 208521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 233244,
      "e": 208633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 233284,
      "e": 208673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 233284,
      "e": 208673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 233394,
      "e": 208783,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you jus"
    },
    {
      "t": 233412,
      "e": 208801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 233412,
      "e": 208801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 233419,
      "e": 208808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 233541,
      "e": 208930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 233541,
      "e": 208930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 233571,
      "e": 208960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 233643,
      "e": 209032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 234996,
      "e": 210385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 234997,
      "e": 210386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 235083,
      "e": 210472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 235116,
      "e": 210505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 235116,
      "e": 210505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 235211,
      "e": 210600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 235387,
      "e": 210776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 235387,
      "e": 210776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 235500,
      "e": 210889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 236396,
      "e": 211785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 236397,
      "e": 211786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 236500,
      "e": 211889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 236820,
      "e": 212209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 236821,
      "e": 212210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 236891,
      "e": 212280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 236891,
      "e": 212280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 236923,
      "e": 212312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tr"
    },
    {
      "t": 236988,
      "e": 212377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 237148,
      "e": 212537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 237149,
      "e": 212538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 237259,
      "e": 212648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 237356,
      "e": 212745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 237357,
      "e": 212746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 237451,
      "e": 212840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 237467,
      "e": 212856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 237468,
      "e": 212857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 237547,
      "e": 212936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 238012,
      "e": 213401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 238067,
      "e": 213401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go strig"
    },
    {
      "t": 238164,
      "e": 213498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 238228,
      "e": 213562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go stri"
    },
    {
      "t": 238332,
      "e": 213666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 238405,
      "e": 213668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go str"
    },
    {
      "t": 238523,
      "e": 213786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 238620,
      "e": 213883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go st"
    },
    {
      "t": 240028,
      "e": 215291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 240091,
      "e": 215291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go s"
    },
    {
      "t": 240194,
      "e": 215394,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go s"
    },
    {
      "t": 240227,
      "e": 215427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 240308,
      "e": 215428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go "
    },
    {
      "t": 240923,
      "e": 216043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 240924,
      "e": 216044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241028,
      "e": 216148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 241188,
      "e": 216308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 241188,
      "e": 216308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241299,
      "e": 216419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 241300,
      "e": 216420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241339,
      "e": 216459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 241411,
      "e": 216531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 241541,
      "e": 216661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 241542,
      "e": 216662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241572,
      "e": 216692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 241644,
      "e": 216764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 241645,
      "e": 216765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241763,
      "e": 216883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 241860,
      "e": 216980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 241861,
      "e": 216981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241915,
      "e": 217035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 241916,
      "e": 217036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 241979,
      "e": 217099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 242044,
      "e": 217164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 242044,
      "e": 217164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 242051,
      "e": 217171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 242107,
      "e": 217227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 242187,
      "e": 217307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 242188,
      "e": 217308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 242292,
      "e": 217412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 242315,
      "e": 217435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 242316,
      "e": 217436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 242364,
      "e": 217484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 242364,
      "e": 217484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 242403,
      "e": 217523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 242476,
      "e": 217596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 242884,
      "e": 218004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 242884,
      "e": 218004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 242971,
      "e": 218091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 242995,
      "e": 218115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 242995,
      "e": 218115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243068,
      "e": 218188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 243123,
      "e": 218243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 243124,
      "e": 218244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243260,
      "e": 218380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 243516,
      "e": 218636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 243517,
      "e": 218637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243603,
      "e": 218723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 243603,
      "e": 218723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243651,
      "e": 218771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fr"
    },
    {
      "t": 243691,
      "e": 218811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 243692,
      "e": 218812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 243692,
      "e": 218812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243755,
      "e": 218875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 243756,
      "e": 218876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 243819,
      "e": 218939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 243891,
      "e": 219011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 243948,
      "e": 219068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 243948,
      "e": 219068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 244075,
      "e": 219195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 244763,
      "e": 219883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 244764,
      "e": 219884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 244867,
      "e": 219987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 244869,
      "e": 219989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 244947,
      "e": 220067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 245011,
      "e": 220131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 246940,
      "e": 222060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 246941,
      "e": 222061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 246971,
      "e": 222091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 247476,
      "e": 222596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 247477,
      "e": 222597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 247523,
      "e": 222643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 247891,
      "e": 223011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 247893,
      "e": 223013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 247987,
      "e": 223107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 248981,
      "e": 224101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 248982,
      "e": 224102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 249067,
      "e": 224187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 249164,
      "e": 224284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 249164,
      "e": 224284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 249259,
      "e": 224379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 249372,
      "e": 224492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 249372,
      "e": 224492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 249435,
      "e": 224555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 249716,
      "e": 224836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 249773,
      "e": 224838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go vertically up from 12 pm. "
    },
    {
      "t": 249859,
      "e": 224924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 250051,
      "e": 225116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 250052,
      "e": 225117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 250123,
      "e": 225188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 250155,
      "e": 225220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 250436,
      "e": 225501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 250437,
      "e": 225502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 250547,
      "e": 225612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 250586,
      "e": 225651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 250586,
      "e": 225651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 250706,
      "e": 225771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 250820,
      "e": 225885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 250820,
      "e": 225885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 250923,
      "e": 225988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 250924,
      "e": 225989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 250931,
      "e": 225996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 251010,
      "e": 226075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 251011,
      "e": 226076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251059,
      "e": 226124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 251123,
      "e": 226188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 251163,
      "e": 226228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 251164,
      "e": 226229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251267,
      "e": 226332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 251268,
      "e": 226333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251291,
      "e": 226356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 251379,
      "e": 226444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 251677,
      "e": 226742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 251678,
      "e": 226743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251763,
      "e": 226828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 251795,
      "e": 226860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 251795,
      "e": 226860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251924,
      "e": 226989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 251925,
      "e": 226990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 251963,
      "e": 227028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||as"
    },
    {
      "t": 252067,
      "e": 227132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 252067,
      "e": 227132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 252123,
      "e": 227188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 252204,
      "e": 227269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 258929,
      "e": 232269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 258930,
      "e": 232270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 259040,
      "e": 232380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 259177,
      "e": 232517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 259337,
      "e": 232677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 259338,
      "e": 232678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 259431,
      "e": 232771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 259496,
      "e": 232836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 259911,
      "e": 233251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 259912,
      "e": 233252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 259990,
      "e": 233330,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 260040,
      "e": 233380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 260144,
      "e": 233484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 260144,
      "e": 233484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 260256,
      "e": 233596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 260281,
      "e": 233621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 260281,
      "e": 233621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 260360,
      "e": 233700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 260521,
      "e": 233861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 260521,
      "e": 233861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 260608,
      "e": 233948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 260608,
      "e": 233948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 260640,
      "e": 233980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 260728,
      "e": 234068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 260856,
      "e": 234196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 261233,
      "e": 234573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 261233,
      "e": 234573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 261305,
      "e": 234645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 261352,
      "e": 234692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 262189,
      "e": 235529,
      "ty": 2,
      "x": 527,
      "y": 541
    },
    {
      "t": 262240,
      "e": 235580,
      "ty": 41,
      "x": 48887,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 262289,
      "e": 235629,
      "ty": 2,
      "x": 514,
      "y": 559
    },
    {
      "t": 262330,
      "e": 235670,
      "ty": 7,
      "x": 426,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 262390,
      "e": 235730,
      "ty": 2,
      "x": 358,
      "y": 622
    },
    {
      "t": 262490,
      "e": 235830,
      "ty": 2,
      "x": 262,
      "y": 617
    },
    {
      "t": 262490,
      "e": 235830,
      "ty": 41,
      "x": 18537,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 262590,
      "e": 235930,
      "ty": 2,
      "x": 225,
      "y": 610
    },
    {
      "t": 262690,
      "e": 236030,
      "ty": 2,
      "x": 308,
      "y": 650
    },
    {
      "t": 262740,
      "e": 236080,
      "ty": 41,
      "x": 2530,
      "y": 29664,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 262790,
      "e": 236130,
      "ty": 2,
      "x": 335,
      "y": 684
    },
    {
      "t": 262889,
      "e": 236229,
      "ty": 2,
      "x": 380,
      "y": 695
    },
    {
      "t": 262898,
      "e": 236238,
      "ty": 6,
      "x": 394,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 262930,
      "e": 236270,
      "ty": 7,
      "x": 424,
      "y": 651,
      "ta": "#strategyButton"
    },
    {
      "t": 262990,
      "e": 236330,
      "ty": 2,
      "x": 432,
      "y": 613
    },
    {
      "t": 262990,
      "e": 236330,
      "ty": 41,
      "x": 37646,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 263013,
      "e": 236353,
      "ty": 6,
      "x": 427,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 263090,
      "e": 236430,
      "ty": 2,
      "x": 420,
      "y": 597
    },
    {
      "t": 263189,
      "e": 236529,
      "ty": 2,
      "x": 417,
      "y": 600
    },
    {
      "t": 263197,
      "e": 236537,
      "ty": 7,
      "x": 405,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 263239,
      "e": 236579,
      "ty": 41,
      "x": 29680,
      "y": 6727,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 263289,
      "e": 236629,
      "ty": 2,
      "x": 348,
      "y": 640
    },
    {
      "t": 263330,
      "e": 236670,
      "ty": 6,
      "x": 244,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 263390,
      "e": 236730,
      "ty": 2,
      "x": 190,
      "y": 557
    },
    {
      "t": 263489,
      "e": 236829,
      "ty": 2,
      "x": 192,
      "y": 553
    },
    {
      "t": 263489,
      "e": 236829,
      "ty": 41,
      "x": 10668,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 263590,
      "e": 236930,
      "ty": 2,
      "x": 215,
      "y": 561
    },
    {
      "t": 263630,
      "e": 236970,
      "ty": 7,
      "x": 270,
      "y": 613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 263690,
      "e": 237030,
      "ty": 2,
      "x": 304,
      "y": 642
    },
    {
      "t": 263740,
      "e": 237080,
      "ty": 41,
      "x": 3466,
      "y": 26388,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 263748,
      "e": 237088,
      "ty": 6,
      "x": 339,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 263790,
      "e": 237130,
      "ty": 2,
      "x": 347,
      "y": 680
    },
    {
      "t": 263990,
      "e": 237330,
      "ty": 41,
      "x": 4590,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 263993,
      "e": 237333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 263994,
      "e": 237334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 264088,
      "e": 237428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 264189,
      "e": 237529,
      "ty": 2,
      "x": 352,
      "y": 679
    },
    {
      "t": 264192,
      "e": 237532,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go vertically up from 12 pm. In this case B and F."
    },
    {
      "t": 264231,
      "e": 237571,
      "ty": 7,
      "x": 396,
      "y": 650,
      "ta": "#strategyButton"
    },
    {
      "t": 264240,
      "e": 237580,
      "ty": 41,
      "x": 36234,
      "y": 18523,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 264290,
      "e": 237630,
      "ty": 2,
      "x": 417,
      "y": 637
    },
    {
      "t": 264490,
      "e": 237830,
      "ty": 41,
      "x": 46064,
      "y": 10004,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 265182,
      "e": 238522,
      "ty": 6,
      "x": 448,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 265189,
      "e": 238529,
      "ty": 2,
      "x": 448,
      "y": 573
    },
    {
      "t": 265240,
      "e": 238580,
      "ty": 41,
      "x": 41805,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 265289,
      "e": 238629,
      "ty": 2,
      "x": 469,
      "y": 565
    },
    {
      "t": 265389,
      "e": 238729,
      "ty": 2,
      "x": 484,
      "y": 596
    },
    {
      "t": 265398,
      "e": 238738,
      "ty": 7,
      "x": 487,
      "y": 610,
      "ta": "#strategyAnswer"
    },
    {
      "t": 265490,
      "e": 238830,
      "ty": 2,
      "x": 487,
      "y": 615
    },
    {
      "t": 265490,
      "e": 238830,
      "ty": 41,
      "x": 43829,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 265590,
      "e": 238930,
      "ty": 2,
      "x": 500,
      "y": 633
    },
    {
      "t": 265741,
      "e": 239081,
      "ty": 41,
      "x": 45290,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 265783,
      "e": 239123,
      "ty": 6,
      "x": 546,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 265789,
      "e": 239129,
      "ty": 2,
      "x": 546,
      "y": 596
    },
    {
      "t": 265889,
      "e": 239229,
      "ty": 2,
      "x": 547,
      "y": 594
    },
    {
      "t": 265966,
      "e": 239306,
      "ty": 7,
      "x": 521,
      "y": 624,
      "ta": "#strategyAnswer"
    },
    {
      "t": 265990,
      "e": 239330,
      "ty": 2,
      "x": 506,
      "y": 644
    },
    {
      "t": 265990,
      "e": 239330,
      "ty": 41,
      "x": 45965,
      "y": 35232,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 266089,
      "e": 239429,
      "ty": 2,
      "x": 482,
      "y": 685
    },
    {
      "t": 266190,
      "e": 239530,
      "ty": 2,
      "x": 466,
      "y": 712
    },
    {
      "t": 266233,
      "e": 239573,
      "ty": 6,
      "x": 402,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 266240,
      "e": 239580,
      "ty": 41,
      "x": 34627,
      "y": 60264,
      "ta": "#strategyButton"
    },
    {
      "t": 266290,
      "e": 239630,
      "ty": 2,
      "x": 373,
      "y": 663
    },
    {
      "t": 266390,
      "e": 239730,
      "ty": 2,
      "x": 377,
      "y": 657
    },
    {
      "t": 266490,
      "e": 239830,
      "ty": 2,
      "x": 385,
      "y": 660
    },
    {
      "t": 266490,
      "e": 239830,
      "ty": 41,
      "x": 25343,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 266590,
      "e": 239930,
      "ty": 2,
      "x": 389,
      "y": 663
    },
    {
      "t": 266693,
      "e": 240033,
      "ty": 3,
      "x": 389,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 266696,
      "e": 240035,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go vertically up from 12 pm. In this case B and F."
    },
    {
      "t": 266697,
      "e": 240036,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 266698,
      "e": 240037,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 266740,
      "e": 240079,
      "ty": 41,
      "x": 27528,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 266780,
      "e": 240119,
      "ty": 4,
      "x": 27528,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 266789,
      "e": 240128,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 266791,
      "e": 240130,
      "ty": 5,
      "x": 389,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 266800,
      "e": 240139,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 267189,
      "e": 240528,
      "ty": 2,
      "x": 398,
      "y": 670
    },
    {
      "t": 267240,
      "e": 240579,
      "ty": 41,
      "x": 13430,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 267290,
      "e": 240629,
      "ty": 2,
      "x": 398,
      "y": 671
    },
    {
      "t": 267797,
      "e": 241136,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 267889,
      "e": 241228,
      "ty": 2,
      "x": 394,
      "y": 674
    },
    {
      "t": 267990,
      "e": 241329,
      "ty": 41,
      "x": 13292,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 268090,
      "e": 241429,
      "ty": 2,
      "x": 393,
      "y": 674
    },
    {
      "t": 268190,
      "e": 241529,
      "ty": 2,
      "x": 393,
      "y": 678
    },
    {
      "t": 268240,
      "e": 241579,
      "ty": 41,
      "x": 13327,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 268290,
      "e": 241629,
      "ty": 2,
      "x": 427,
      "y": 687
    },
    {
      "t": 268390,
      "e": 241729,
      "ty": 2,
      "x": 624,
      "y": 687
    },
    {
      "t": 268490,
      "e": 241829,
      "ty": 2,
      "x": 1039,
      "y": 577
    },
    {
      "t": 268490,
      "e": 241829,
      "ty": 41,
      "x": 49962,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 268502,
      "e": 241841,
      "ty": 6,
      "x": 1048,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 268590,
      "e": 241929,
      "ty": 2,
      "x": 1051,
      "y": 572
    },
    {
      "t": 268740,
      "e": 242079,
      "ty": 41,
      "x": 52557,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 268830,
      "e": 242169,
      "ty": 3,
      "x": 1051,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 268830,
      "e": 242169,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 268916,
      "e": 242255,
      "ty": 4,
      "x": 52557,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 268916,
      "e": 242255,
      "ty": 5,
      "x": 1051,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 269761,
      "e": 243100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 269761,
      "e": 243100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 269856,
      "e": 243195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 269888,
      "e": 243227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 269888,
      "e": 243227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 269976,
      "e": 243315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 270725,
      "e": 244064,
      "ty": 7,
      "x": 1028,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 270740,
      "e": 244079,
      "ty": 41,
      "x": 40229,
      "y": 16383,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 270789,
      "e": 244128,
      "ty": 2,
      "x": 968,
      "y": 635
    },
    {
      "t": 270803,
      "e": 244142,
      "ty": 6,
      "x": 955,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 270889,
      "e": 244228,
      "ty": 2,
      "x": 950,
      "y": 667
    },
    {
      "t": 270904,
      "e": 244243,
      "ty": 7,
      "x": 947,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 270990,
      "e": 244329,
      "ty": 2,
      "x": 947,
      "y": 671
    },
    {
      "t": 270990,
      "e": 244329,
      "ty": 41,
      "x": 30063,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 271053,
      "e": 244392,
      "ty": 3,
      "x": 947,
      "y": 671,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 271053,
      "e": 244392,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 271053,
      "e": 244392,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 271140,
      "e": 244479,
      "ty": 4,
      "x": 30063,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 271140,
      "e": 244479,
      "ty": 5,
      "x": 947,
      "y": 671,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 271788,
      "e": 245127,
      "ty": 6,
      "x": 951,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 271789,
      "e": 245128,
      "ty": 2,
      "x": 951,
      "y": 667
    },
    {
      "t": 271862,
      "e": 245201,
      "ty": 3,
      "x": 953,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 271863,
      "e": 245202,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 271890,
      "e": 245229,
      "ty": 2,
      "x": 953,
      "y": 666
    },
    {
      "t": 271971,
      "e": 245310,
      "ty": 4,
      "x": 31361,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 271972,
      "e": 245311,
      "ty": 5,
      "x": 953,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 271990,
      "e": 245329,
      "ty": 41,
      "x": 31361,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 272376,
      "e": 245715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 272876,
      "e": 246215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 272909,
      "e": 246248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 272942,
      "e": 246281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 272975,
      "e": 246314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 273008,
      "e": 246347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 273041,
      "e": 246380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 273074,
      "e": 246413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 273096,
      "e": 246435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 273097,
      "e": 246436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273192,
      "e": 246531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 273201,
      "e": 246540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 273329,
      "e": 246541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 273331,
      "e": 246543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273440,
      "e": 246652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 273440,
      "e": 246652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273464,
      "e": 246676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 273536,
      "e": 246748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 273624,
      "e": 246836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 273625,
      "e": 246837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273713,
      "e": 246925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 273825,
      "e": 247037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 273825,
      "e": 247037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273919,
      "e": 247131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 273919,
      "e": 247131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 273959,
      "e": 247171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ed"
    },
    {
      "t": 274017,
      "e": 247229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 274017,
      "e": 247229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 274064,
      "e": 247276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 274161,
      "e": 247373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 274241,
      "e": 247453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 274704,
      "e": 247916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 274705,
      "e": 247917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 274807,
      "e": 248019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 274816,
      "e": 248028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 274855,
      "e": 248067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 274856,
      "e": 248068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 274936,
      "e": 248148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 274944,
      "e": 248156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 274945,
      "e": 248157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 275040,
      "e": 248252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 275041,
      "e": 248253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 275071,
      "e": 248283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 275112,
      "e": 248324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 275200,
      "e": 248412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 275200,
      "e": 248412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 275328,
      "e": 248540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 275329,
      "e": 248541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 275384,
      "e": 248596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 275440,
      "e": 248652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 275892,
      "e": 249104,
      "ty": 7,
      "x": 951,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 275990,
      "e": 249202,
      "ty": 2,
      "x": 953,
      "y": 668
    },
    {
      "t": 275991,
      "e": 249203,
      "ty": 41,
      "x": 31361,
      "y": 59897,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 276074,
      "e": 249286,
      "ty": 6,
      "x": 934,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 276090,
      "e": 249302,
      "ty": 2,
      "x": 934,
      "y": 685
    },
    {
      "t": 276190,
      "e": 249402,
      "ty": 2,
      "x": 945,
      "y": 704
    },
    {
      "t": 276241,
      "e": 249453,
      "ty": 41,
      "x": 25294,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 277390,
      "e": 250602,
      "ty": 2,
      "x": 954,
      "y": 703
    },
    {
      "t": 277491,
      "e": 250703,
      "ty": 41,
      "x": 29932,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278037,
      "e": 251249,
      "ty": 3,
      "x": 954,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278037,
      "e": 251249,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 278039,
      "e": 251251,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 278041,
      "e": 251253,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278140,
      "e": 251352,
      "ty": 4,
      "x": 29932,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278141,
      "e": 251353,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278141,
      "e": 251353,
      "ty": 5,
      "x": 954,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 278141,
      "e": 251353,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 279164,
      "e": 252376,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 279890,
      "e": 253102,
      "ty": 2,
      "x": 873,
      "y": 221
    },
    {
      "t": 279990,
      "e": 253202,
      "ty": 2,
      "x": 833,
      "y": 0
    },
    {
      "t": 279990,
      "e": 253202,
      "ty": 41,
      "x": 28686,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 279991,
      "e": 253203,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 280090,
      "e": 253302,
      "ty": 2,
      "x": 833,
      "y": 22
    },
    {
      "t": 280190,
      "e": 253402,
      "ty": 2,
      "x": 826,
      "y": 166
    },
    {
      "t": 280240,
      "e": 253452,
      "ty": 41,
      "x": 1086,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 280290,
      "e": 253502,
      "ty": 2,
      "x": 827,
      "y": 204
    },
    {
      "t": 280390,
      "e": 253602,
      "ty": 2,
      "x": 823,
      "y": 228
    },
    {
      "t": 280490,
      "e": 253702,
      "ty": 2,
      "x": 819,
      "y": 242
    },
    {
      "t": 280490,
      "e": 253702,
      "ty": 41,
      "x": 27928,
      "y": 12962,
      "ta": "html > body"
    },
    {
      "t": 280690,
      "e": 253902,
      "ty": 2,
      "x": 824,
      "y": 241
    },
    {
      "t": 280741,
      "e": 253953,
      "ty": 41,
      "x": 2930,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 280790,
      "e": 254002,
      "ty": 2,
      "x": 825,
      "y": 240
    },
    {
      "t": 280812,
      "e": 254024,
      "ty": 3,
      "x": 825,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 280916,
      "e": 254128,
      "ty": 4,
      "x": 2930,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 280917,
      "e": 254129,
      "ty": 5,
      "x": 825,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 280918,
      "e": 254130,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 280920,
      "e": 254132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 281181,
      "e": 254393,
      "ty": 6,
      "x": 828,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 281191,
      "e": 254403,
      "ty": 2,
      "x": 828,
      "y": 240
    },
    {
      "t": 281196,
      "e": 254408,
      "ty": 7,
      "x": 831,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 281212,
      "e": 254424,
      "ty": 6,
      "x": 836,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 281228,
      "e": 254440,
      "ty": 7,
      "x": 840,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 281240,
      "e": 254452,
      "ty": 41,
      "x": 14149,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 281290,
      "e": 254502,
      "ty": 2,
      "x": 852,
      "y": 322
    },
    {
      "t": 281390,
      "e": 254602,
      "ty": 2,
      "x": 869,
      "y": 380
    },
    {
      "t": 281491,
      "e": 254703,
      "ty": 2,
      "x": 877,
      "y": 424
    },
    {
      "t": 281491,
      "e": 254703,
      "ty": 41,
      "x": 65059,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 281590,
      "e": 254802,
      "ty": 2,
      "x": 878,
      "y": 438
    },
    {
      "t": 281690,
      "e": 254902,
      "ty": 2,
      "x": 879,
      "y": 439
    },
    {
      "t": 281741,
      "e": 254953,
      "ty": 41,
      "x": 45990,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 281890,
      "e": 255102,
      "ty": 2,
      "x": 876,
      "y": 439
    },
    {
      "t": 281990,
      "e": 255202,
      "ty": 2,
      "x": 849,
      "y": 429
    },
    {
      "t": 281991,
      "e": 255203,
      "ty": 41,
      "x": 6544,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 282090,
      "e": 255302,
      "ty": 2,
      "x": 848,
      "y": 426
    },
    {
      "t": 282191,
      "e": 255403,
      "ty": 2,
      "x": 856,
      "y": 421
    },
    {
      "t": 282241,
      "e": 255453,
      "ty": 41,
      "x": 55694,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 282291,
      "e": 255503,
      "ty": 2,
      "x": 872,
      "y": 424
    },
    {
      "t": 282390,
      "e": 255602,
      "ty": 2,
      "x": 877,
      "y": 443
    },
    {
      "t": 282490,
      "e": 255702,
      "ty": 2,
      "x": 862,
      "y": 451
    },
    {
      "t": 282490,
      "e": 255702,
      "ty": 41,
      "x": 32411,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 282590,
      "e": 255802,
      "ty": 2,
      "x": 836,
      "y": 431
    },
    {
      "t": 282690,
      "e": 255902,
      "ty": 2,
      "x": 832,
      "y": 421
    },
    {
      "t": 282696,
      "e": 255908,
      "ty": 6,
      "x": 832,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 282740,
      "e": 255952,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 282790,
      "e": 256002,
      "ty": 2,
      "x": 831,
      "y": 418
    },
    {
      "t": 283750,
      "e": 256962,
      "ty": 3,
      "x": 831,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 283750,
      "e": 256962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 283750,
      "e": 256962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 283867,
      "e": 257079,
      "ty": 4,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 283867,
      "e": 257079,
      "ty": 5,
      "x": 831,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 283868,
      "e": 257080,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 284069,
      "e": 257281,
      "ty": 7,
      "x": 833,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 284091,
      "e": 257303,
      "ty": 2,
      "x": 841,
      "y": 451
    },
    {
      "t": 284191,
      "e": 257304,
      "ty": 2,
      "x": 891,
      "y": 551
    },
    {
      "t": 284241,
      "e": 257354,
      "ty": 41,
      "x": 47474,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 284290,
      "e": 257403,
      "ty": 2,
      "x": 891,
      "y": 568
    },
    {
      "t": 284391,
      "e": 257504,
      "ty": 2,
      "x": 891,
      "y": 606
    },
    {
      "t": 284490,
      "e": 257603,
      "ty": 2,
      "x": 891,
      "y": 666
    },
    {
      "t": 284491,
      "e": 257604,
      "ty": 41,
      "x": 18681,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 284590,
      "e": 257703,
      "ty": 2,
      "x": 890,
      "y": 715
    },
    {
      "t": 284691,
      "e": 257804,
      "ty": 2,
      "x": 886,
      "y": 744
    },
    {
      "t": 284740,
      "e": 257853,
      "ty": 41,
      "x": 26528,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 284790,
      "e": 257903,
      "ty": 2,
      "x": 883,
      "y": 763
    },
    {
      "t": 284890,
      "e": 258003,
      "ty": 2,
      "x": 878,
      "y": 789
    },
    {
      "t": 284990,
      "e": 258103,
      "ty": 2,
      "x": 870,
      "y": 811
    },
    {
      "t": 284990,
      "e": 258103,
      "ty": 41,
      "x": 28672,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 285090,
      "e": 258203,
      "ty": 2,
      "x": 858,
      "y": 831
    },
    {
      "t": 285191,
      "e": 258304,
      "ty": 2,
      "x": 847,
      "y": 849
    },
    {
      "t": 285240,
      "e": 258353,
      "ty": 41,
      "x": 5358,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 285291,
      "e": 258404,
      "ty": 2,
      "x": 843,
      "y": 859
    },
    {
      "t": 285490,
      "e": 258603,
      "ty": 2,
      "x": 843,
      "y": 814
    },
    {
      "t": 285490,
      "e": 258603,
      "ty": 41,
      "x": 12736,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 285590,
      "e": 258703,
      "ty": 2,
      "x": 843,
      "y": 772
    },
    {
      "t": 285690,
      "e": 258803,
      "ty": 2,
      "x": 844,
      "y": 758
    },
    {
      "t": 285741,
      "e": 258854,
      "ty": 41,
      "x": 9420,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 285791,
      "e": 258904,
      "ty": 2,
      "x": 845,
      "y": 749
    },
    {
      "t": 285890,
      "e": 259003,
      "ty": 2,
      "x": 848,
      "y": 745
    },
    {
      "t": 285991,
      "e": 259104,
      "ty": 2,
      "x": 848,
      "y": 739
    },
    {
      "t": 285991,
      "e": 259104,
      "ty": 41,
      "x": 6670,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 286048,
      "e": 259161,
      "ty": 6,
      "x": 839,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 286090,
      "e": 259203,
      "ty": 2,
      "x": 836,
      "y": 729
    },
    {
      "t": 286191,
      "e": 259304,
      "ty": 2,
      "x": 832,
      "y": 729
    },
    {
      "t": 286241,
      "e": 259354,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 286291,
      "e": 259404,
      "ty": 2,
      "x": 830,
      "y": 730
    },
    {
      "t": 286491,
      "e": 259604,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 286532,
      "e": 259645,
      "ty": 7,
      "x": 828,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 286590,
      "e": 259703,
      "ty": 2,
      "x": 828,
      "y": 747
    },
    {
      "t": 286631,
      "e": 259744,
      "ty": 6,
      "x": 828,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 286690,
      "e": 259803,
      "ty": 2,
      "x": 828,
      "y": 755
    },
    {
      "t": 286740,
      "e": 259853,
      "ty": 41,
      "x": 7955,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 286749,
      "e": 259862,
      "ty": 7,
      "x": 827,
      "y": 768,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 286791,
      "e": 259904,
      "ty": 2,
      "x": 827,
      "y": 775
    },
    {
      "t": 286816,
      "e": 259929,
      "ty": 6,
      "x": 827,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 286889,
      "e": 260002,
      "ty": 2,
      "x": 827,
      "y": 786
    },
    {
      "t": 286990,
      "e": 260103,
      "ty": 2,
      "x": 827,
      "y": 787
    },
    {
      "t": 286991,
      "e": 260104,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 287053,
      "e": 260166,
      "ty": 7,
      "x": 827,
      "y": 777,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 287089,
      "e": 260202,
      "ty": 2,
      "x": 827,
      "y": 766
    },
    {
      "t": 287099,
      "e": 260203,
      "ty": 6,
      "x": 827,
      "y": 758,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287132,
      "e": 260236,
      "ty": 7,
      "x": 827,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287190,
      "e": 260294,
      "ty": 2,
      "x": 826,
      "y": 749
    },
    {
      "t": 287241,
      "e": 260345,
      "ty": 41,
      "x": 1910,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 287350,
      "e": 260454,
      "ty": 6,
      "x": 830,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287390,
      "e": 260494,
      "ty": 2,
      "x": 830,
      "y": 756
    },
    {
      "t": 287489,
      "e": 260593,
      "ty": 2,
      "x": 830,
      "y": 757
    },
    {
      "t": 287489,
      "e": 260593,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287509,
      "e": 260613,
      "ty": 3,
      "x": 830,
      "y": 757,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287510,
      "e": 260614,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 287511,
      "e": 260615,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287629,
      "e": 260733,
      "ty": 4,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287629,
      "e": 260733,
      "ty": 5,
      "x": 830,
      "y": 757,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 287630,
      "e": 260734,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 288368,
      "e": 261472,
      "ty": 7,
      "x": 836,
      "y": 746,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 288389,
      "e": 261493,
      "ty": 2,
      "x": 838,
      "y": 742
    },
    {
      "t": 288489,
      "e": 261593,
      "ty": 2,
      "x": 842,
      "y": 738
    },
    {
      "t": 288490,
      "e": 261594,
      "ty": 41,
      "x": 5164,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 288590,
      "e": 261694,
      "ty": 2,
      "x": 852,
      "y": 735
    },
    {
      "t": 288689,
      "e": 261793,
      "ty": 2,
      "x": 920,
      "y": 718
    },
    {
      "t": 288740,
      "e": 261844,
      "ty": 41,
      "x": 29008,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 288789,
      "e": 261893,
      "ty": 2,
      "x": 945,
      "y": 726
    },
    {
      "t": 288890,
      "e": 261994,
      "ty": 2,
      "x": 968,
      "y": 823
    },
    {
      "t": 288989,
      "e": 262093,
      "ty": 2,
      "x": 947,
      "y": 855
    },
    {
      "t": 288989,
      "e": 262093,
      "ty": 41,
      "x": 29802,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 289089,
      "e": 262193,
      "ty": 2,
      "x": 939,
      "y": 861
    },
    {
      "t": 289239,
      "e": 262343,
      "ty": 41,
      "x": 27904,
      "y": 52308,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 289889,
      "e": 262993,
      "ty": 2,
      "x": 772,
      "y": 937
    },
    {
      "t": 289990,
      "e": 263094,
      "ty": 2,
      "x": 750,
      "y": 941
    },
    {
      "t": 289990,
      "e": 263094,
      "ty": 41,
      "x": 25552,
      "y": 51685,
      "ta": "html > body"
    },
    {
      "t": 290090,
      "e": 263194,
      "ty": 2,
      "x": 761,
      "y": 945
    },
    {
      "t": 290189,
      "e": 263293,
      "ty": 2,
      "x": 834,
      "y": 948
    },
    {
      "t": 290239,
      "e": 263343,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 290289,
      "e": 263393,
      "ty": 2,
      "x": 841,
      "y": 948
    },
    {
      "t": 290389,
      "e": 263493,
      "ty": 2,
      "x": 841,
      "y": 947
    },
    {
      "t": 290453,
      "e": 263557,
      "ty": 6,
      "x": 838,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290490,
      "e": 263594,
      "ty": 2,
      "x": 835,
      "y": 936
    },
    {
      "t": 290490,
      "e": 263594,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290590,
      "e": 263694,
      "ty": 2,
      "x": 833,
      "y": 933
    },
    {
      "t": 290628,
      "e": 263732,
      "ty": 3,
      "x": 833,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290629,
      "e": 263733,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 290629,
      "e": 263733,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290691,
      "e": 263795,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290691,
      "e": 263795,
      "ty": 5,
      "x": 833,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290692,
      "e": 263796,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 290739,
      "e": 263843,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290836,
      "e": 263940,
      "ty": 7,
      "x": 835,
      "y": 947,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 290887,
      "e": 263991,
      "ty": 6,
      "x": 861,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 290890,
      "e": 263994,
      "ty": 2,
      "x": 861,
      "y": 1014
    },
    {
      "t": 290936,
      "e": 264040,
      "ty": 7,
      "x": 873,
      "y": 1042,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 290989,
      "e": 264093,
      "ty": 2,
      "x": 874,
      "y": 1062
    },
    {
      "t": 290990,
      "e": 264094,
      "ty": 41,
      "x": 29823,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 291090,
      "e": 264194,
      "ty": 2,
      "x": 874,
      "y": 1066
    },
    {
      "t": 291186,
      "e": 264290,
      "ty": 6,
      "x": 883,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291190,
      "e": 264294,
      "ty": 2,
      "x": 883,
      "y": 1037
    },
    {
      "t": 291239,
      "e": 264343,
      "ty": 41,
      "x": 29675,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291290,
      "e": 264394,
      "ty": 2,
      "x": 887,
      "y": 1019
    },
    {
      "t": 291390,
      "e": 264494,
      "ty": 2,
      "x": 889,
      "y": 1017
    },
    {
      "t": 291453,
      "e": 264557,
      "ty": 3,
      "x": 889,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291454,
      "e": 264558,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 291455,
      "e": 264559,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291489,
      "e": 264593,
      "ty": 41,
      "x": 30705,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291539,
      "e": 264643,
      "ty": 4,
      "x": 30705,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291539,
      "e": 264643,
      "ty": 5,
      "x": 889,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291542,
      "e": 264646,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 291542,
      "e": 264646,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 291543,
      "e": 264647,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 292870,
      "e": 265974,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 293390,
      "e": 266494,
      "ty": 2,
      "x": 840,
      "y": 926
    },
    {
      "t": 293489,
      "e": 266593,
      "ty": 2,
      "x": 732,
      "y": 810
    },
    {
      "t": 293490,
      "e": 266594,
      "ty": 41,
      "x": 21575,
      "y": 13476,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 293590,
      "e": 266694,
      "ty": 2,
      "x": 733,
      "y": 794
    },
    {
      "t": 293689,
      "e": 266793,
      "ty": 2,
      "x": 837,
      "y": 718
    },
    {
      "t": 293740,
      "e": 266844,
      "ty": 41,
      "x": 28511,
      "y": 16685,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 293789,
      "e": 266893,
      "ty": 2,
      "x": 879,
      "y": 692
    },
    {
      "t": 293890,
      "e": 266994,
      "ty": 2,
      "x": 859,
      "y": 658
    },
    {
      "t": 293990,
      "e": 267094,
      "ty": 2,
      "x": 608,
      "y": 535
    },
    {
      "t": 293990,
      "e": 267094,
      "ty": 41,
      "x": 15474,
      "y": 20485,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 294090,
      "e": 267194,
      "ty": 2,
      "x": 295,
      "y": 387
    },
    {
      "t": 294189,
      "e": 267293,
      "ty": 2,
      "x": 284,
      "y": 381
    },
    {
      "t": 294240,
      "e": 267344,
      "ty": 41,
      "x": 9642,
      "y": 20496,
      "ta": "> div.masterdiv"
    },
    {
      "t": 294289,
      "e": 267393,
      "ty": 2,
      "x": 334,
      "y": 391
    },
    {
      "t": 294390,
      "e": 267494,
      "ty": 2,
      "x": 676,
      "y": 477
    },
    {
      "t": 294490,
      "e": 267594,
      "ty": 2,
      "x": 738,
      "y": 488
    },
    {
      "t": 294490,
      "e": 267594,
      "ty": 41,
      "x": 21870,
      "y": 2151,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 299990,
      "e": 272594,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 304891,
      "e": 272594,
      "ty": 2,
      "x": 1405,
      "y": 403
    },
    {
      "t": 304990,
      "e": 272693,
      "ty": 2,
      "x": 1477,
      "y": 429
    },
    {
      "t": 304990,
      "e": 272693,
      "ty": 41,
      "x": 58226,
      "y": 37850,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 305090,
      "e": 272793,
      "ty": 2,
      "x": 1401,
      "y": 625
    },
    {
      "t": 305190,
      "e": 272893,
      "ty": 2,
      "x": 1147,
      "y": 939
    },
    {
      "t": 305240,
      "e": 272943,
      "ty": 41,
      "x": 40614,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 305290,
      "e": 272993,
      "ty": 2,
      "x": 1082,
      "y": 1134
    },
    {
      "t": 305390,
      "e": 273093,
      "ty": 2,
      "x": 1044,
      "y": 1160
    },
    {
      "t": 305431,
      "e": 273134,
      "ty": 6,
      "x": 1006,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 305464,
      "e": 273167,
      "ty": 7,
      "x": 989,
      "y": 1069,
      "ta": "#start"
    },
    {
      "t": 305490,
      "e": 273193,
      "ty": 2,
      "x": 988,
      "y": 1069
    },
    {
      "t": 305490,
      "e": 273193,
      "ty": 41,
      "x": 34169,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 305604,
      "e": 273307,
      "ty": 6,
      "x": 983,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 305690,
      "e": 273393,
      "ty": 2,
      "x": 975,
      "y": 1083
    },
    {
      "t": 305740,
      "e": 273443,
      "ty": 41,
      "x": 34132,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 305790,
      "e": 273493,
      "ty": 2,
      "x": 971,
      "y": 1088
    },
    {
      "t": 305890,
      "e": 273593,
      "ty": 2,
      "x": 970,
      "y": 1088
    },
    {
      "t": 305990,
      "e": 273693,
      "ty": 41,
      "x": 33040,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 309021,
      "e": 276724,
      "ty": 3,
      "x": 970,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 309022,
      "e": 276725,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 309123,
      "e": 276826,
      "ty": 4,
      "x": 33040,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 309123,
      "e": 276826,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 309124,
      "e": 276827,
      "ty": 5,
      "x": 970,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 309125,
      "e": 276828,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 309691,
      "e": 277394,
      "ty": 2,
      "x": 1123,
      "y": 1199
    },
    {
      "t": 309790,
      "e": 277493,
      "ty": 2,
      "x": 1592,
      "y": 1199
    },
    {
      "t": 309990,
      "e": 277693,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 310148,
      "e": 277851,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 310746,
      "e": 278449,
      "ty": 2,
      "x": 1418,
      "y": 1199
    },
    {
      "t": 311090,
      "e": 278793,
      "ty": 2,
      "x": 1410,
      "y": 1185
    },
    {
      "t": 311190,
      "e": 278893,
      "ty": 2,
      "x": 1403,
      "y": 1160
    },
    {
      "t": 311240,
      "e": 278943,
      "ty": 41,
      "x": 39782,
      "y": 32924,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 311290,
      "e": 278993,
      "ty": 2,
      "x": 1394,
      "y": 1135
    },
    {
      "t": 311390,
      "e": 279093,
      "ty": 2,
      "x": 1386,
      "y": 1108
    },
    {
      "t": 311480,
      "e": 279183,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 405362, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 405366, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11722, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 418424, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 10297, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"zulu\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 429725, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11096, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 441911, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 14822, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 457737, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 85951, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 545089, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -01 PM-01 PM-01 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:947,y:994,t:1528143514664};\\\", \\\"{x:976,y:976,t:1528143514678};\\\", \\\"{x:1115,y:938,t:1528143514695};\\\", \\\"{x:1165,y:922,t:1528143514712};\\\", \\\"{x:1173,y:918,t:1528143514729};\\\", \\\"{x:1173,y:917,t:1528143514745};\\\", \\\"{x:1176,y:914,t:1528143514761};\\\", \\\"{x:1185,y:911,t:1528143514779};\\\", \\\"{x:1203,y:907,t:1528143514796};\\\", \\\"{x:1249,y:902,t:1528143514812};\\\", \\\"{x:1302,y:894,t:1528143514829};\\\", \\\"{x:1361,y:886,t:1528143514846};\\\", \\\"{x:1436,y:886,t:1528143514862};\\\", \\\"{x:1529,y:876,t:1528143514879};\\\", \\\"{x:1557,y:870,t:1528143514895};\\\", \\\"{x:1577,y:862,t:1528143514911};\\\", \\\"{x:1604,y:855,t:1528143514928};\\\", \\\"{x:1660,y:840,t:1528143514945};\\\", \\\"{x:1724,y:821,t:1528143514961};\\\", \\\"{x:1755,y:810,t:1528143514979};\\\", \\\"{x:1756,y:809,t:1528143514996};\\\", \\\"{x:1764,y:803,t:1528143515011};\\\", \\\"{x:1776,y:787,t:1528143515028};\\\", \\\"{x:1783,y:768,t:1528143515046};\\\", \\\"{x:1783,y:746,t:1528143515063};\\\", \\\"{x:1780,y:732,t:1528143515079};\\\", \\\"{x:1774,y:724,t:1528143515096};\\\", \\\"{x:1769,y:720,t:1528143515113};\\\", \\\"{x:1763,y:718,t:1528143515129};\\\", \\\"{x:1752,y:715,t:1528143515145};\\\", \\\"{x:1738,y:709,t:1528143515163};\\\", \\\"{x:1728,y:707,t:1528143515179};\\\", \\\"{x:1703,y:712,t:1528143515195};\\\", \\\"{x:1652,y:766,t:1528143515212};\\\", \\\"{x:1601,y:821,t:1528143515229};\\\", \\\"{x:1537,y:886,t:1528143515245};\\\", \\\"{x:1472,y:943,t:1528143515262};\\\", \\\"{x:1434,y:974,t:1528143515278};\\\", \\\"{x:1398,y:1005,t:1528143515295};\\\", \\\"{x:1355,y:1039,t:1528143515312};\\\", \\\"{x:1316,y:1073,t:1528143515328};\\\", \\\"{x:1294,y:1087,t:1528143515345};\\\", \\\"{x:1293,y:1088,t:1528143515362};\\\", \\\"{x:1291,y:1089,t:1528143515378};\\\", \\\"{x:1290,y:1089,t:1528143515422};\\\", \\\"{x:1291,y:1088,t:1528143515463};\\\", \\\"{x:1302,y:1073,t:1528143515479};\\\", \\\"{x:1315,y:1058,t:1528143515495};\\\", \\\"{x:1327,y:1042,t:1528143515512};\\\", \\\"{x:1340,y:1024,t:1528143515530};\\\", \\\"{x:1354,y:1009,t:1528143515545};\\\", \\\"{x:1365,y:996,t:1528143515562};\\\", \\\"{x:1373,y:988,t:1528143515579};\\\", \\\"{x:1380,y:978,t:1528143515595};\\\", \\\"{x:1389,y:967,t:1528143515613};\\\", \\\"{x:1391,y:963,t:1528143515630};\\\", \\\"{x:1393,y:958,t:1528143515645};\\\", \\\"{x:1395,y:953,t:1528143515662};\\\", \\\"{x:1396,y:952,t:1528143515680};\\\", \\\"{x:1396,y:951,t:1528143515719};\\\", \\\"{x:1397,y:951,t:1528143515944};\\\", \\\"{x:1397,y:952,t:1528143515951};\\\", \\\"{x:1397,y:957,t:1528143515962};\\\", \\\"{x:1397,y:958,t:1528143515980};\\\", \\\"{x:1397,y:959,t:1528143515997};\\\", \\\"{x:1396,y:962,t:1528143516013};\\\", \\\"{x:1394,y:966,t:1528143516029};\\\", \\\"{x:1389,y:973,t:1528143516047};\\\", \\\"{x:1386,y:976,t:1528143516062};\\\", \\\"{x:1384,y:977,t:1528143516080};\\\", \\\"{x:1382,y:979,t:1528143516096};\\\", \\\"{x:1381,y:979,t:1528143516118};\\\", \\\"{x:1381,y:980,t:1528143516130};\\\", \\\"{x:1377,y:982,t:1528143516147};\\\", \\\"{x:1375,y:983,t:1528143516163};\\\", \\\"{x:1371,y:986,t:1528143516180};\\\", \\\"{x:1370,y:986,t:1528143516197};\\\", \\\"{x:1367,y:988,t:1528143516213};\\\", \\\"{x:1366,y:989,t:1528143516230};\\\", \\\"{x:1365,y:989,t:1528143516376};\\\", \\\"{x:1365,y:988,t:1528143516383};\\\", \\\"{x:1367,y:987,t:1528143516397};\\\", \\\"{x:1378,y:982,t:1528143516412};\\\", \\\"{x:1396,y:975,t:1528143516430};\\\", \\\"{x:1430,y:960,t:1528143516447};\\\", \\\"{x:1448,y:953,t:1528143516462};\\\", \\\"{x:1454,y:950,t:1528143516479};\\\", \\\"{x:1456,y:949,t:1528143516496};\\\", \\\"{x:1456,y:948,t:1528143516616};\\\", \\\"{x:1455,y:948,t:1528143516630};\\\", \\\"{x:1449,y:946,t:1528143516647};\\\", \\\"{x:1438,y:946,t:1528143516663};\\\", \\\"{x:1428,y:951,t:1528143516680};\\\", \\\"{x:1423,y:955,t:1528143516696};\\\", \\\"{x:1419,y:958,t:1528143516714};\\\", \\\"{x:1417,y:959,t:1528143516729};\\\", \\\"{x:1416,y:959,t:1528143516747};\\\", \\\"{x:1416,y:960,t:1528143516766};\\\", \\\"{x:1416,y:961,t:1528143516903};\\\", \\\"{x:1416,y:962,t:1528143516918};\\\", \\\"{x:1416,y:963,t:1528143516935};\\\", \\\"{x:1417,y:964,t:1528143516950};\\\", \\\"{x:1417,y:965,t:1528143516991};\\\", \\\"{x:1417,y:966,t:1528143517006};\\\", \\\"{x:1417,y:967,t:1528143517046};\\\", \\\"{x:1417,y:968,t:1528143517064};\\\", \\\"{x:1418,y:969,t:1528143517134};\\\", \\\"{x:1420,y:970,t:1528143517146};\\\", \\\"{x:1424,y:971,t:1528143517163};\\\", \\\"{x:1426,y:972,t:1528143517180};\\\", \\\"{x:1429,y:972,t:1528143517196};\\\", \\\"{x:1430,y:973,t:1528143517213};\\\", \\\"{x:1440,y:968,t:1528143517230};\\\", \\\"{x:1452,y:963,t:1528143517246};\\\", \\\"{x:1464,y:957,t:1528143517264};\\\", \\\"{x:1471,y:954,t:1528143517281};\\\", \\\"{x:1475,y:953,t:1528143517296};\\\", \\\"{x:1479,y:952,t:1528143517314};\\\", \\\"{x:1482,y:952,t:1528143517330};\\\", \\\"{x:1483,y:952,t:1528143517347};\\\", \\\"{x:1485,y:952,t:1528143517363};\\\", \\\"{x:1491,y:955,t:1528143517381};\\\", \\\"{x:1499,y:957,t:1528143517398};\\\", \\\"{x:1506,y:961,t:1528143517414};\\\", \\\"{x:1510,y:963,t:1528143517431};\\\", \\\"{x:1508,y:963,t:1528143517560};\\\", \\\"{x:1507,y:963,t:1528143517567};\\\", \\\"{x:1506,y:963,t:1528143517590};\\\", \\\"{x:1504,y:963,t:1528143517598};\\\", \\\"{x:1505,y:963,t:1528143517685};\\\", \\\"{x:1507,y:963,t:1528143517697};\\\", \\\"{x:1512,y:964,t:1528143517713};\\\", \\\"{x:1519,y:965,t:1528143517730};\\\", \\\"{x:1522,y:967,t:1528143517747};\\\", \\\"{x:1523,y:967,t:1528143517763};\\\", \\\"{x:1524,y:967,t:1528143517780};\\\", \\\"{x:1525,y:968,t:1528143517797};\\\", \\\"{x:1528,y:968,t:1528143517813};\\\", \\\"{x:1538,y:972,t:1528143517830};\\\", \\\"{x:1548,y:977,t:1528143517847};\\\", \\\"{x:1557,y:981,t:1528143517864};\\\", \\\"{x:1562,y:983,t:1528143517880};\\\", \\\"{x:1567,y:986,t:1528143517897};\\\", \\\"{x:1568,y:986,t:1528143517914};\\\", \\\"{x:1569,y:986,t:1528143517930};\\\", \\\"{x:1570,y:986,t:1528143517974};\\\", \\\"{x:1572,y:984,t:1528143517983};\\\", \\\"{x:1576,y:974,t:1528143517997};\\\", \\\"{x:1581,y:955,t:1528143518015};\\\", \\\"{x:1581,y:940,t:1528143518031};\\\", \\\"{x:1581,y:918,t:1528143518048};\\\", \\\"{x:1575,y:892,t:1528143518064};\\\", \\\"{x:1563,y:857,t:1528143518081};\\\", \\\"{x:1556,y:832,t:1528143518098};\\\", \\\"{x:1549,y:804,t:1528143518114};\\\", \\\"{x:1534,y:756,t:1528143518130};\\\", \\\"{x:1500,y:691,t:1528143518148};\\\", \\\"{x:1448,y:616,t:1528143518164};\\\", \\\"{x:1384,y:542,t:1528143518180};\\\", \\\"{x:1322,y:486,t:1528143518197};\\\", \\\"{x:1247,y:443,t:1528143518214};\\\", \\\"{x:1215,y:441,t:1528143518231};\\\", \\\"{x:1197,y:448,t:1528143518248};\\\", \\\"{x:1186,y:456,t:1528143518265};\\\", \\\"{x:1173,y:465,t:1528143518281};\\\", \\\"{x:1165,y:473,t:1528143518298};\\\", \\\"{x:1159,y:481,t:1528143518314};\\\", \\\"{x:1156,y:488,t:1528143518331};\\\", \\\"{x:1157,y:500,t:1528143518348};\\\", \\\"{x:1180,y:514,t:1528143518365};\\\", \\\"{x:1203,y:524,t:1528143518381};\\\", \\\"{x:1205,y:525,t:1528143518398};\\\", \\\"{x:1206,y:525,t:1528143518455};\\\", \\\"{x:1206,y:531,t:1528143518527};\\\", \\\"{x:1206,y:539,t:1528143518535};\\\", \\\"{x:1204,y:549,t:1528143518547};\\\", \\\"{x:1195,y:566,t:1528143518565};\\\", \\\"{x:1181,y:587,t:1528143518581};\\\", \\\"{x:1150,y:606,t:1528143518596};\\\", \\\"{x:1076,y:631,t:1528143518613};\\\", \\\"{x:1002,y:647,t:1528143518629};\\\", \\\"{x:918,y:660,t:1528143518646};\\\", \\\"{x:819,y:672,t:1528143518663};\\\", \\\"{x:748,y:679,t:1528143518680};\\\", \\\"{x:702,y:688,t:1528143518695};\\\", \\\"{x:676,y:692,t:1528143518713};\\\", \\\"{x:660,y:693,t:1528143518730};\\\", \\\"{x:652,y:693,t:1528143518746};\\\", \\\"{x:648,y:693,t:1528143518763};\\\", \\\"{x:643,y:692,t:1528143518780};\\\", \\\"{x:641,y:692,t:1528143518796};\\\", \\\"{x:640,y:692,t:1528143518837};\\\", \\\"{x:639,y:692,t:1528143518846};\\\", \\\"{x:637,y:692,t:1528143518863};\\\", \\\"{x:636,y:692,t:1528143518879};\\\", \\\"{x:631,y:692,t:1528143518896};\\\", \\\"{x:618,y:687,t:1528143518913};\\\", \\\"{x:593,y:673,t:1528143518930};\\\", \\\"{x:546,y:631,t:1528143518948};\\\", \\\"{x:495,y:582,t:1528143518964};\\\", \\\"{x:432,y:488,t:1528143518996};\\\", \\\"{x:421,y:469,t:1528143519014};\\\", \\\"{x:418,y:464,t:1528143519031};\\\", \\\"{x:418,y:463,t:1528143519048};\\\", \\\"{x:418,y:462,t:1528143519064};\\\", \\\"{x:418,y:461,t:1528143519157};\\\", \\\"{x:420,y:461,t:1528143519165};\\\", \\\"{x:430,y:465,t:1528143519181};\\\", \\\"{x:447,y:481,t:1528143519199};\\\", \\\"{x:471,y:505,t:1528143519215};\\\", \\\"{x:502,y:525,t:1528143519232};\\\", \\\"{x:518,y:531,t:1528143519248};\\\", \\\"{x:524,y:535,t:1528143519268};\\\", \\\"{x:527,y:535,t:1528143519284};\\\", \\\"{x:529,y:535,t:1528143519302};\\\", \\\"{x:526,y:535,t:1528143519405};\\\", \\\"{x:522,y:535,t:1528143519419};\\\", \\\"{x:508,y:535,t:1528143519435};\\\", \\\"{x:501,y:538,t:1528143519453};\\\", \\\"{x:500,y:539,t:1528143519468};\\\", \\\"{x:504,y:541,t:1528143519484};\\\", \\\"{x:515,y:546,t:1528143519502};\\\", \\\"{x:533,y:546,t:1528143519518};\\\", \\\"{x:550,y:547,t:1528143519534};\\\", \\\"{x:566,y:554,t:1528143519551};\\\", \\\"{x:567,y:558,t:1528143519568};\\\", \\\"{x:558,y:565,t:1528143519585};\\\", \\\"{x:537,y:572,t:1528143519601};\\\", \\\"{x:509,y:575,t:1528143519619};\\\", \\\"{x:491,y:579,t:1528143519635};\\\", \\\"{x:472,y:582,t:1528143519652};\\\", \\\"{x:445,y:586,t:1528143519667};\\\", \\\"{x:431,y:588,t:1528143519684};\\\", \\\"{x:427,y:588,t:1528143519702};\\\", \\\"{x:424,y:588,t:1528143519719};\\\", \\\"{x:422,y:588,t:1528143519734};\\\", \\\"{x:421,y:588,t:1528143519797};\\\", \\\"{x:419,y:587,t:1528143519805};\\\", \\\"{x:416,y:587,t:1528143519821};\\\", \\\"{x:412,y:585,t:1528143519844};\\\", \\\"{x:409,y:582,t:1528143519852};\\\", \\\"{x:395,y:575,t:1528143519868};\\\", \\\"{x:376,y:561,t:1528143519886};\\\", \\\"{x:370,y:558,t:1528143519901};\\\", \\\"{x:370,y:557,t:1528143519918};\\\", \\\"{x:371,y:558,t:1528143520068};\\\", \\\"{x:374,y:559,t:1528143520085};\\\", \\\"{x:376,y:560,t:1528143520102};\\\", \\\"{x:377,y:560,t:1528143520119};\\\", \\\"{x:378,y:561,t:1528143520412};\\\", \\\"{x:382,y:561,t:1528143520420};\\\", \\\"{x:390,y:564,t:1528143520436};\\\", \\\"{x:420,y:578,t:1528143520453};\\\", \\\"{x:440,y:587,t:1528143520468};\\\", \\\"{x:466,y:589,t:1528143520485};\\\", \\\"{x:512,y:595,t:1528143520503};\\\", \\\"{x:575,y:611,t:1528143520519};\\\", \\\"{x:645,y:623,t:1528143520536};\\\", \\\"{x:686,y:631,t:1528143520552};\\\", \\\"{x:708,y:639,t:1528143520570};\\\", \\\"{x:714,y:642,t:1528143520585};\\\", \\\"{x:715,y:642,t:1528143520602};\\\", \\\"{x:716,y:643,t:1528143520619};\\\", \\\"{x:717,y:644,t:1528143520635};\\\", \\\"{x:717,y:645,t:1528143520652};\\\", \\\"{x:717,y:649,t:1528143520669};\\\", \\\"{x:717,y:660,t:1528143520686};\\\", \\\"{x:715,y:679,t:1528143520702};\\\", \\\"{x:713,y:697,t:1528143520719};\\\", \\\"{x:710,y:713,t:1528143520735};\\\", \\\"{x:709,y:727,t:1528143520753};\\\", \\\"{x:706,y:743,t:1528143520769};\\\", \\\"{x:703,y:754,t:1528143520785};\\\", \\\"{x:700,y:762,t:1528143520802};\\\", \\\"{x:700,y:763,t:1528143520820};\\\", \\\"{x:700,y:766,t:1528143520836};\\\", \\\"{x:699,y:773,t:1528143520852};\\\", \\\"{x:699,y:779,t:1528143520868};\\\", \\\"{x:699,y:781,t:1528143520886};\\\", \\\"{x:695,y:781,t:1528143521069};\\\", \\\"{x:692,y:765,t:1528143521085};\\\", \\\"{x:690,y:751,t:1528143521102};\\\", \\\"{x:688,y:739,t:1528143521118};\\\", \\\"{x:686,y:727,t:1528143521136};\\\", \\\"{x:686,y:712,t:1528143521153};\\\", \\\"{x:686,y:700,t:1528143521168};\\\", \\\"{x:686,y:694,t:1528143521186};\\\", \\\"{x:686,y:690,t:1528143521202};\\\", \\\"{x:686,y:689,t:1528143521219};\\\", \\\"{x:689,y:688,t:1528143522677};\\\", \\\"{x:701,y:692,t:1528143522685};\\\", \\\"{x:735,y:698,t:1528143522702};\\\", \\\"{x:775,y:698,t:1528143522719};\\\", \\\"{x:833,y:698,t:1528143522736};\\\", \\\"{x:911,y:690,t:1528143522752};\\\", \\\"{x:1007,y:680,t:1528143522769};\\\", \\\"{x:1091,y:677,t:1528143522786};\\\", \\\"{x:1161,y:675,t:1528143522802};\\\", \\\"{x:1223,y:665,t:1528143522818};\\\", \\\"{x:1271,y:657,t:1528143522835};\\\", \\\"{x:1296,y:653,t:1528143522851};\\\", \\\"{x:1306,y:649,t:1528143522868};\\\", \\\"{x:1307,y:649,t:1528143522885};\\\", \\\"{x:1309,y:649,t:1528143522916};\\\", \\\"{x:1310,y:649,t:1528143522924};\\\", \\\"{x:1314,y:649,t:1528143522935};\\\", \\\"{x:1319,y:650,t:1528143522952};\\\", \\\"{x:1322,y:652,t:1528143522968};\\\", \\\"{x:1324,y:654,t:1528143522985};\\\", \\\"{x:1329,y:658,t:1528143523002};\\\", \\\"{x:1337,y:688,t:1528143523018};\\\", \\\"{x:1341,y:713,t:1528143523035};\\\", \\\"{x:1346,y:728,t:1528143523052};\\\", \\\"{x:1352,y:743,t:1528143523068};\\\", \\\"{x:1354,y:746,t:1528143523086};\\\", \\\"{x:1355,y:748,t:1528143523102};\\\", \\\"{x:1356,y:749,t:1528143523165};\\\", \\\"{x:1358,y:751,t:1528143523173};\\\", \\\"{x:1359,y:751,t:1528143523187};\\\", \\\"{x:1362,y:752,t:1528143523202};\\\", \\\"{x:1356,y:751,t:1528143523285};\\\", \\\"{x:1341,y:742,t:1528143523303};\\\", \\\"{x:1305,y:742,t:1528143523319};\\\", \\\"{x:1217,y:740,t:1528143523336};\\\", \\\"{x:1034,y:734,t:1528143523352};\\\", \\\"{x:867,y:727,t:1528143523369};\\\", \\\"{x:786,y:724,t:1528143523387};\\\", \\\"{x:770,y:718,t:1528143523402};\\\", \\\"{x:767,y:716,t:1528143523419};\\\", \\\"{x:766,y:716,t:1528143523436};\\\", \\\"{x:767,y:716,t:1528143523469};\\\", \\\"{x:771,y:716,t:1528143523486};\\\", \\\"{x:776,y:716,t:1528143523502};\\\", \\\"{x:778,y:716,t:1528143523519};\\\", \\\"{x:779,y:716,t:1528143523536};\\\", \\\"{x:778,y:717,t:1528143523580};\\\", \\\"{x:771,y:723,t:1528143523589};\\\", \\\"{x:761,y:730,t:1528143523602};\\\", \\\"{x:744,y:741,t:1528143523618};\\\", \\\"{x:725,y:743,t:1528143523636};\\\", \\\"{x:700,y:739,t:1528143523652};\\\", \\\"{x:672,y:727,t:1528143523669};\\\", \\\"{x:666,y:724,t:1528143523686};\\\", \\\"{x:662,y:722,t:1528143523702};\\\", \\\"{x:659,y:720,t:1528143523719};\\\", \\\"{x:655,y:718,t:1528143523735};\\\", \\\"{x:652,y:717,t:1528143523752};\\\", \\\"{x:650,y:715,t:1528143523769};\\\", \\\"{x:648,y:715,t:1528143523788};\\\", \\\"{x:647,y:715,t:1528143523802};\\\", \\\"{x:641,y:713,t:1528143523819};\\\", \\\"{x:634,y:711,t:1528143523836};\\\", \\\"{x:619,y:718,t:1528143523852};\\\", \\\"{x:609,y:726,t:1528143523869};\\\", \\\"{x:597,y:733,t:1528143523886};\\\", \\\"{x:576,y:736,t:1528143523902};\\\", \\\"{x:558,y:736,t:1528143523919};\\\", \\\"{x:548,y:732,t:1528143523936};\\\", \\\"{x:539,y:728,t:1528143523951};\\\", \\\"{x:529,y:723,t:1528143523969};\\\", \\\"{x:523,y:720,t:1528143523987};\\\", \\\"{x:522,y:719,t:1528143524004};\\\", \\\"{x:518,y:717,t:1528143525409};\\\", \\\"{x:515,y:715,t:1528143525422};\\\", \\\"{x:511,y:714,t:1528143525439};\\\", \\\"{x:507,y:708,t:1528143525455};\\\", \\\"{x:503,y:698,t:1528143525473};\\\", \\\"{x:501,y:696,t:1528143525490};\\\", \\\"{x:500,y:695,t:1528143525507};\\\" ] }, { \\\"rt\\\": 13377, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 560035, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:694,t:1528143525900};\\\", \\\"{x:499,y:693,t:1528143525909};\\\", \\\"{x:498,y:693,t:1528143525923};\\\", \\\"{x:496,y:692,t:1528143525939};\\\", \\\"{x:493,y:691,t:1528143525957};\\\", \\\"{x:466,y:688,t:1528143526088};\\\", \\\"{x:465,y:688,t:1528143526106};\\\", \\\"{x:465,y:687,t:1528143526171};\\\", \\\"{x:465,y:686,t:1528143526203};\\\", \\\"{x:465,y:684,t:1528143526212};\\\", \\\"{x:465,y:683,t:1528143526223};\\\", \\\"{x:466,y:682,t:1528143526239};\\\", \\\"{x:466,y:681,t:1528143526256};\\\", \\\"{x:467,y:678,t:1528143526273};\\\", \\\"{x:468,y:672,t:1528143526290};\\\", \\\"{x:469,y:670,t:1528143526306};\\\", \\\"{x:469,y:662,t:1528143526323};\\\", \\\"{x:470,y:650,t:1528143526341};\\\", \\\"{x:470,y:634,t:1528143526356};\\\", \\\"{x:470,y:620,t:1528143526374};\\\", \\\"{x:471,y:605,t:1528143526391};\\\", \\\"{x:474,y:589,t:1528143526407};\\\", \\\"{x:475,y:574,t:1528143526424};\\\", \\\"{x:475,y:558,t:1528143526440};\\\", \\\"{x:475,y:541,t:1528143526456};\\\", \\\"{x:477,y:527,t:1528143526473};\\\", \\\"{x:482,y:513,t:1528143526491};\\\", \\\"{x:489,y:500,t:1528143526507};\\\", \\\"{x:499,y:486,t:1528143526524};\\\", \\\"{x:505,y:477,t:1528143526539};\\\", \\\"{x:513,y:469,t:1528143526556};\\\", \\\"{x:522,y:459,t:1528143526574};\\\", \\\"{x:534,y:453,t:1528143526590};\\\", \\\"{x:547,y:446,t:1528143526607};\\\", \\\"{x:564,y:440,t:1528143526623};\\\", \\\"{x:578,y:435,t:1528143526641};\\\", \\\"{x:588,y:432,t:1528143526657};\\\", \\\"{x:593,y:431,t:1528143526673};\\\", \\\"{x:597,y:429,t:1528143526691};\\\", \\\"{x:600,y:429,t:1528143526708};\\\", \\\"{x:601,y:429,t:1528143526723};\\\", \\\"{x:602,y:428,t:1528143526740};\\\", \\\"{x:603,y:428,t:1528143526861};\\\", \\\"{x:604,y:428,t:1528143526874};\\\", \\\"{x:608,y:426,t:1528143526891};\\\", \\\"{x:611,y:426,t:1528143526907};\\\", \\\"{x:619,y:425,t:1528143526924};\\\", \\\"{x:649,y:424,t:1528143526940};\\\", \\\"{x:676,y:424,t:1528143526958};\\\", \\\"{x:703,y:425,t:1528143526974};\\\", \\\"{x:741,y:429,t:1528143526990};\\\", \\\"{x:791,y:437,t:1528143527008};\\\", \\\"{x:834,y:444,t:1528143527023};\\\", \\\"{x:876,y:449,t:1528143527040};\\\", \\\"{x:901,y:449,t:1528143527058};\\\", \\\"{x:913,y:449,t:1528143527073};\\\", \\\"{x:918,y:449,t:1528143527091};\\\", \\\"{x:927,y:448,t:1528143527107};\\\", \\\"{x:946,y:436,t:1528143527124};\\\", \\\"{x:957,y:426,t:1528143527141};\\\", \\\"{x:963,y:417,t:1528143527158};\\\", \\\"{x:969,y:404,t:1528143527174};\\\", \\\"{x:973,y:387,t:1528143527190};\\\", \\\"{x:974,y:367,t:1528143527208};\\\", \\\"{x:974,y:355,t:1528143527225};\\\", \\\"{x:974,y:341,t:1528143527241};\\\", \\\"{x:971,y:327,t:1528143527258};\\\", \\\"{x:965,y:315,t:1528143527275};\\\", \\\"{x:956,y:301,t:1528143527291};\\\", \\\"{x:956,y:297,t:1528143527308};\\\", \\\"{x:955,y:294,t:1528143527324};\\\", \\\"{x:953,y:290,t:1528143527341};\\\", \\\"{x:950,y:287,t:1528143527358};\\\", \\\"{x:946,y:282,t:1528143527374};\\\", \\\"{x:945,y:281,t:1528143527390};\\\", \\\"{x:950,y:281,t:1528143535820};\\\", \\\"{x:989,y:265,t:1528143535831};\\\", \\\"{x:1090,y:226,t:1528143535848};\\\", \\\"{x:1123,y:204,t:1528143535864};\\\", \\\"{x:1130,y:152,t:1528143535881};\\\", \\\"{x:1137,y:78,t:1528143535898};\\\", \\\"{x:1143,y:58,t:1528143535915};\\\", \\\"{x:1143,y:57,t:1528143535931};\\\", \\\"{x:1143,y:56,t:1528143535956};\\\", \\\"{x:1137,y:51,t:1528143535964};\\\", \\\"{x:1065,y:22,t:1528143535981};\\\", \\\"{x:950,y:0,t:1528143535998};\\\", \\\"{x:859,y:0,t:1528143536015};\\\", \\\"{x:784,y:0,t:1528143536031};\\\", \\\"{x:676,y:0,t:1528143536048};\\\", \\\"{x:547,y:11,t:1528143536065};\\\", \\\"{x:435,y:32,t:1528143536082};\\\", \\\"{x:378,y:54,t:1528143536098};\\\", \\\"{x:345,y:67,t:1528143536115};\\\", \\\"{x:323,y:80,t:1528143536131};\\\", \\\"{x:268,y:112,t:1528143536148};\\\", \\\"{x:235,y:140,t:1528143536165};\\\", \\\"{x:216,y:155,t:1528143536181};\\\", \\\"{x:204,y:168,t:1528143536198};\\\", \\\"{x:192,y:181,t:1528143536215};\\\", \\\"{x:188,y:198,t:1528143536231};\\\", \\\"{x:187,y:215,t:1528143536248};\\\", \\\"{x:186,y:238,t:1528143536265};\\\", \\\"{x:190,y:278,t:1528143536281};\\\", \\\"{x:203,y:307,t:1528143536298};\\\", \\\"{x:223,y:349,t:1528143536316};\\\", \\\"{x:236,y:374,t:1528143536332};\\\", \\\"{x:242,y:384,t:1528143536348};\\\", \\\"{x:244,y:384,t:1528143536365};\\\", \\\"{x:246,y:384,t:1528143536383};\\\", \\\"{x:245,y:386,t:1528143536412};\\\", \\\"{x:245,y:388,t:1528143536420};\\\", \\\"{x:245,y:389,t:1528143536432};\\\", \\\"{x:245,y:394,t:1528143536448};\\\", \\\"{x:247,y:396,t:1528143536465};\\\", \\\"{x:247,y:397,t:1528143536492};\\\", \\\"{x:247,y:399,t:1528143536501};\\\", \\\"{x:247,y:402,t:1528143536515};\\\", \\\"{x:252,y:412,t:1528143536532};\\\", \\\"{x:260,y:433,t:1528143536548};\\\", \\\"{x:272,y:458,t:1528143536565};\\\", \\\"{x:287,y:481,t:1528143536584};\\\", \\\"{x:299,y:507,t:1528143536600};\\\", \\\"{x:329,y:547,t:1528143536615};\\\", \\\"{x:372,y:608,t:1528143536632};\\\", \\\"{x:389,y:634,t:1528143536646};\\\", \\\"{x:392,y:639,t:1528143536663};\\\", \\\"{x:392,y:640,t:1528143536682};\\\", \\\"{x:392,y:642,t:1528143536697};\\\", \\\"{x:392,y:639,t:1528143536893};\\\", \\\"{x:392,y:633,t:1528143536900};\\\", \\\"{x:392,y:626,t:1528143536915};\\\", \\\"{x:392,y:612,t:1528143536933};\\\", \\\"{x:392,y:609,t:1528143536948};\\\", \\\"{x:392,y:608,t:1528143537013};\\\", \\\"{x:392,y:607,t:1528143537036};\\\", \\\"{x:390,y:605,t:1528143537049};\\\", \\\"{x:389,y:604,t:1528143537065};\\\", \\\"{x:387,y:604,t:1528143537083};\\\", \\\"{x:386,y:604,t:1528143537099};\\\", \\\"{x:385,y:603,t:1528143537116};\\\", \\\"{x:384,y:602,t:1528143537156};\\\", \\\"{x:385,y:602,t:1528143537372};\\\", \\\"{x:392,y:603,t:1528143537382};\\\", \\\"{x:400,y:607,t:1528143537399};\\\", \\\"{x:411,y:618,t:1528143537416};\\\", \\\"{x:427,y:636,t:1528143537432};\\\", \\\"{x:448,y:650,t:1528143537449};\\\", \\\"{x:473,y:663,t:1528143537466};\\\", \\\"{x:504,y:677,t:1528143537483};\\\", \\\"{x:512,y:680,t:1528143537499};\\\", \\\"{x:514,y:681,t:1528143537516};\\\", \\\"{x:514,y:682,t:1528143537540};\\\", \\\"{x:514,y:686,t:1528143537556};\\\", \\\"{x:514,y:688,t:1528143537566};\\\", \\\"{x:514,y:692,t:1528143537583};\\\", \\\"{x:514,y:695,t:1528143537599};\\\", \\\"{x:514,y:701,t:1528143537617};\\\", \\\"{x:512,y:707,t:1528143537632};\\\", \\\"{x:510,y:713,t:1528143537649};\\\", \\\"{x:509,y:716,t:1528143537665};\\\", \\\"{x:508,y:718,t:1528143537683};\\\", \\\"{x:508,y:720,t:1528143537699};\\\", \\\"{x:508,y:721,t:1528143537716};\\\" ] }, { \\\"rt\\\": 21243, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 582554, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:721,t:1528143558612};\\\", \\\"{x:377,y:642,t:1528143558631};\\\", \\\"{x:282,y:570,t:1528143558645};\\\", \\\"{x:249,y:534,t:1528143558663};\\\", \\\"{x:200,y:429,t:1528143558699};\\\", \\\"{x:196,y:406,t:1528143558715};\\\", \\\"{x:196,y:393,t:1528143558732};\\\", \\\"{x:201,y:388,t:1528143558749};\\\", \\\"{x:215,y:388,t:1528143558766};\\\", \\\"{x:215,y:389,t:1528143558782};\\\", \\\"{x:216,y:389,t:1528143558908};\\\", \\\"{x:216,y:391,t:1528143558923};\\\", \\\"{x:213,y:402,t:1528143558932};\\\", \\\"{x:192,y:442,t:1528143558949};\\\", \\\"{x:185,y:471,t:1528143558965};\\\", \\\"{x:188,y:502,t:1528143558982};\\\", \\\"{x:199,y:541,t:1528143558999};\\\", \\\"{x:207,y:566,t:1528143559018};\\\", \\\"{x:215,y:587,t:1528143559034};\\\", \\\"{x:223,y:611,t:1528143559049};\\\", \\\"{x:226,y:630,t:1528143559068};\\\", \\\"{x:230,y:641,t:1528143559082};\\\", \\\"{x:246,y:653,t:1528143559100};\\\", \\\"{x:263,y:660,t:1528143559116};\\\", \\\"{x:282,y:666,t:1528143559132};\\\", \\\"{x:300,y:666,t:1528143559150};\\\", \\\"{x:315,y:664,t:1528143559166};\\\", \\\"{x:325,y:660,t:1528143559182};\\\", \\\"{x:330,y:658,t:1528143559200};\\\", \\\"{x:331,y:657,t:1528143559217};\\\", \\\"{x:334,y:649,t:1528143559234};\\\", \\\"{x:336,y:629,t:1528143559249};\\\", \\\"{x:338,y:614,t:1528143559267};\\\", \\\"{x:339,y:612,t:1528143559284};\\\", \\\"{x:340,y:611,t:1528143559299};\\\", \\\"{x:342,y:611,t:1528143559317};\\\", \\\"{x:344,y:610,t:1528143559333};\\\", \\\"{x:346,y:609,t:1528143559363};\\\", \\\"{x:347,y:606,t:1528143559371};\\\", \\\"{x:350,y:603,t:1528143559383};\\\", \\\"{x:358,y:595,t:1528143559400};\\\", \\\"{x:364,y:591,t:1528143559416};\\\", \\\"{x:368,y:589,t:1528143559433};\\\", \\\"{x:374,y:586,t:1528143559450};\\\", \\\"{x:379,y:583,t:1528143559467};\\\", \\\"{x:382,y:581,t:1528143559483};\\\", \\\"{x:383,y:580,t:1528143559499};\\\", \\\"{x:384,y:579,t:1528143559516};\\\", \\\"{x:386,y:577,t:1528143559534};\\\", \\\"{x:386,y:576,t:1528143559550};\\\", \\\"{x:387,y:575,t:1528143559567};\\\", \\\"{x:387,y:574,t:1528143559585};\\\", \\\"{x:388,y:573,t:1528143559600};\\\", \\\"{x:389,y:572,t:1528143559617};\\\", \\\"{x:389,y:571,t:1528143559634};\\\", \\\"{x:389,y:570,t:1528143559877};\\\", \\\"{x:390,y:570,t:1528143559883};\\\", \\\"{x:394,y:581,t:1528143560747};\\\", \\\"{x:396,y:592,t:1528143560755};\\\", \\\"{x:398,y:598,t:1528143560767};\\\", \\\"{x:400,y:602,t:1528143560785};\\\", \\\"{x:403,y:607,t:1528143560800};\\\", \\\"{x:410,y:622,t:1528143560818};\\\", \\\"{x:421,y:637,t:1528143560834};\\\", \\\"{x:435,y:652,t:1528143560851};\\\", \\\"{x:449,y:666,t:1528143560868};\\\", \\\"{x:452,y:668,t:1528143560885};\\\", \\\"{x:453,y:670,t:1528143560901};\\\", \\\"{x:456,y:677,t:1528143560917};\\\", \\\"{x:456,y:682,t:1528143560935};\\\", \\\"{x:456,y:684,t:1528143560950};\\\", \\\"{x:456,y:685,t:1528143560971};\\\", \\\"{x:456,y:686,t:1528143560984};\\\", \\\"{x:456,y:693,t:1528143561001};\\\", \\\"{x:458,y:709,t:1528143561018};\\\", \\\"{x:463,y:725,t:1528143561034};\\\", \\\"{x:472,y:741,t:1528143561052};\\\", \\\"{x:473,y:741,t:1528143561068};\\\", \\\"{x:475,y:741,t:1528143561084};\\\", \\\"{x:476,y:740,t:1528143561101};\\\", \\\"{x:477,y:739,t:1528143561396};\\\", \\\"{x:478,y:738,t:1528143561404};\\\", \\\"{x:479,y:736,t:1528143561419};\\\", \\\"{x:480,y:732,t:1528143561437};\\\", \\\"{x:481,y:730,t:1528143561451};\\\", \\\"{x:482,y:727,t:1528143561469};\\\" ] }, { \\\"rt\\\": 16164, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 599938, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:703,t:1528143576979};\\\", \\\"{x:507,y:626,t:1528143576990};\\\", \\\"{x:555,y:553,t:1528143577015};\\\", \\\"{x:583,y:515,t:1528143577031};\\\", \\\"{x:610,y:478,t:1528143577047};\\\", \\\"{x:622,y:461,t:1528143577064};\\\", \\\"{x:625,y:457,t:1528143577080};\\\", \\\"{x:626,y:455,t:1528143577097};\\\", \\\"{x:627,y:455,t:1528143577267};\\\", \\\"{x:628,y:463,t:1528143577281};\\\", \\\"{x:618,y:517,t:1528143577298};\\\", \\\"{x:612,y:536,t:1528143577315};\\\", \\\"{x:607,y:572,t:1528143577332};\\\", \\\"{x:604,y:594,t:1528143577348};\\\", \\\"{x:603,y:599,t:1528143577364};\\\", \\\"{x:602,y:600,t:1528143577381};\\\", \\\"{x:600,y:601,t:1528143577399};\\\", \\\"{x:602,y:602,t:1528143577491};\\\", \\\"{x:603,y:602,t:1528143577555};\\\", \\\"{x:605,y:602,t:1528143577579};\\\", \\\"{x:606,y:602,t:1528143577587};\\\", \\\"{x:607,y:600,t:1528143577598};\\\", \\\"{x:609,y:596,t:1528143577615};\\\", \\\"{x:611,y:591,t:1528143577633};\\\", \\\"{x:614,y:586,t:1528143577650};\\\", \\\"{x:614,y:584,t:1528143577667};\\\", \\\"{x:614,y:583,t:1528143577682};\\\", \\\"{x:614,y:582,t:1528143577697};\\\", \\\"{x:614,y:579,t:1528143577714};\\\", \\\"{x:614,y:576,t:1528143577730};\\\", \\\"{x:614,y:574,t:1528143577748};\\\", \\\"{x:614,y:573,t:1528143577764};\\\", \\\"{x:614,y:572,t:1528143577826};\\\", \\\"{x:614,y:571,t:1528143577891};\\\", \\\"{x:614,y:570,t:1528143577908};\\\", \\\"{x:614,y:569,t:1528143578275};\\\", \\\"{x:614,y:575,t:1528143578429};\\\", \\\"{x:605,y:636,t:1528143578448};\\\", \\\"{x:592,y:664,t:1528143578465};\\\", \\\"{x:568,y:719,t:1528143578482};\\\", \\\"{x:541,y:786,t:1528143578499};\\\", \\\"{x:534,y:802,t:1528143578516};\\\", \\\"{x:532,y:809,t:1528143578532};\\\", \\\"{x:531,y:810,t:1528143578549};\\\", \\\"{x:530,y:811,t:1528143578565};\\\", \\\"{x:529,y:812,t:1528143578582};\\\", \\\"{x:528,y:812,t:1528143578657};\\\", \\\"{x:527,y:812,t:1528143578665};\\\", \\\"{x:527,y:811,t:1528143578681};\\\", \\\"{x:525,y:805,t:1528143578697};\\\", \\\"{x:524,y:790,t:1528143578714};\\\", \\\"{x:524,y:783,t:1528143578730};\\\", \\\"{x:523,y:775,t:1528143578747};\\\", \\\"{x:522,y:766,t:1528143578764};\\\", \\\"{x:519,y:759,t:1528143578781};\\\", \\\"{x:519,y:753,t:1528143578797};\\\", \\\"{x:519,y:749,t:1528143578814};\\\", \\\"{x:519,y:743,t:1528143578831};\\\", \\\"{x:520,y:739,t:1528143578846};\\\", \\\"{x:520,y:737,t:1528143578864};\\\", \\\"{x:520,y:733,t:1528143578882};\\\", \\\"{x:520,y:732,t:1528143578898};\\\", \\\"{x:520,y:726,t:1528143578914};\\\", \\\"{x:519,y:724,t:1528143578930};\\\", \\\"{x:518,y:722,t:1528143578946};\\\" ] }, { \\\"rt\\\": 68914, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 670077, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-K -K -12 PM-01 PM-I -I -I -O -O -O -O -I -I -I -I -08 AM-03 PM-03 PM-I -O -O -O -O -O -09 AM-O -02 PM-01 PM-F -02 PM-12 PM-O -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:722,t:1528143580448};\\\", \\\"{x:520,y:720,t:1528143580464};\\\", \\\"{x:527,y:705,t:1528143580481};\\\", \\\"{x:530,y:682,t:1528143580498};\\\", \\\"{x:530,y:672,t:1528143580514};\\\", \\\"{x:529,y:665,t:1528143580531};\\\", \\\"{x:528,y:662,t:1528143580548};\\\", \\\"{x:528,y:661,t:1528143580565};\\\", \\\"{x:529,y:661,t:1528143580873};\\\", \\\"{x:535,y:662,t:1528143580881};\\\", \\\"{x:815,y:804,t:1528143580955};\\\", \\\"{x:842,y:820,t:1528143580967};\\\", \\\"{x:886,y:838,t:1528143580981};\\\", \\\"{x:901,y:842,t:1528143580998};\\\", \\\"{x:898,y:842,t:1528143581120};\\\", \\\"{x:886,y:841,t:1528143581133};\\\", \\\"{x:857,y:828,t:1528143581148};\\\", \\\"{x:828,y:816,t:1528143581165};\\\", \\\"{x:789,y:799,t:1528143581183};\\\", \\\"{x:733,y:774,t:1528143581199};\\\", \\\"{x:686,y:760,t:1528143581215};\\\", \\\"{x:658,y:754,t:1528143581232};\\\", \\\"{x:649,y:749,t:1528143581248};\\\", \\\"{x:644,y:743,t:1528143581266};\\\", \\\"{x:636,y:732,t:1528143581283};\\\", \\\"{x:635,y:732,t:1528143581300};\\\", \\\"{x:635,y:730,t:1528143581316};\\\", \\\"{x:635,y:729,t:1528143581337};\\\", \\\"{x:635,y:727,t:1528143581353};\\\", \\\"{x:635,y:726,t:1528143581365};\\\", \\\"{x:635,y:724,t:1528143581382};\\\", \\\"{x:635,y:723,t:1528143581490};\\\", \\\"{x:628,y:719,t:1528143581500};\\\", \\\"{x:605,y:704,t:1528143581516};\\\", \\\"{x:577,y:677,t:1528143581533};\\\", \\\"{x:549,y:650,t:1528143581551};\\\", \\\"{x:521,y:625,t:1528143581567};\\\", \\\"{x:503,y:608,t:1528143581582};\\\", \\\"{x:490,y:600,t:1528143581599};\\\", \\\"{x:486,y:597,t:1528143581615};\\\", \\\"{x:485,y:596,t:1528143581632};\\\", \\\"{x:483,y:592,t:1528143581649};\\\", \\\"{x:481,y:590,t:1528143581665};\\\", \\\"{x:479,y:588,t:1528143581683};\\\", \\\"{x:479,y:586,t:1528143581712};\\\", \\\"{x:479,y:585,t:1528143581720};\\\", \\\"{x:479,y:584,t:1528143581793};\\\", \\\"{x:478,y:585,t:1528143582209};\\\", \\\"{x:475,y:587,t:1528143582217};\\\", \\\"{x:473,y:600,t:1528143582234};\\\", \\\"{x:471,y:605,t:1528143582250};\\\", \\\"{x:471,y:609,t:1528143582266};\\\", \\\"{x:471,y:612,t:1528143582283};\\\", \\\"{x:471,y:618,t:1528143582299};\\\", \\\"{x:471,y:624,t:1528143582317};\\\", \\\"{x:471,y:627,t:1528143582334};\\\", \\\"{x:471,y:630,t:1528143582349};\\\", \\\"{x:471,y:632,t:1528143582367};\\\", \\\"{x:471,y:633,t:1528143582383};\\\", \\\"{x:471,y:636,t:1528143582400};\\\", \\\"{x:471,y:638,t:1528143582417};\\\", \\\"{x:471,y:639,t:1528143582434};\\\", \\\"{x:471,y:640,t:1528143582522};\\\", \\\"{x:470,y:643,t:1528143582553};\\\", \\\"{x:465,y:648,t:1528143582567};\\\", \\\"{x:454,y:659,t:1528143582584};\\\", \\\"{x:445,y:668,t:1528143582601};\\\", \\\"{x:441,y:672,t:1528143582616};\\\", \\\"{x:440,y:669,t:1528143582857};\\\", \\\"{x:439,y:659,t:1528143582868};\\\", \\\"{x:439,y:649,t:1528143582884};\\\", \\\"{x:439,y:645,t:1528143582900};\\\", \\\"{x:440,y:640,t:1528143582916};\\\", \\\"{x:441,y:638,t:1528143582933};\\\", \\\"{x:442,y:638,t:1528143582961};\\\", \\\"{x:443,y:638,t:1528143582968};\\\", \\\"{x:444,y:638,t:1528143582983};\\\", \\\"{x:454,y:640,t:1528143583000};\\\", \\\"{x:457,y:641,t:1528143583016};\\\", \\\"{x:459,y:641,t:1528143583033};\\\", \\\"{x:462,y:642,t:1528143583186};\\\", \\\"{x:465,y:643,t:1528143583201};\\\", \\\"{x:466,y:644,t:1528143585329};\\\", \\\"{x:470,y:643,t:1528143591769};\\\", \\\"{x:515,y:618,t:1528143591778};\\\", \\\"{x:618,y:578,t:1528143591792};\\\", \\\"{x:985,y:518,t:1528143591825};\\\", \\\"{x:1018,y:511,t:1528143591839};\\\", \\\"{x:1054,y:496,t:1528143591855};\\\", \\\"{x:1096,y:485,t:1528143591872};\\\", \\\"{x:1206,y:467,t:1528143591888};\\\", \\\"{x:1252,y:469,t:1528143591904};\\\", \\\"{x:1280,y:475,t:1528143591922};\\\", \\\"{x:1286,y:476,t:1528143591939};\\\", \\\"{x:1286,y:478,t:1528143591955};\\\", \\\"{x:1291,y:488,t:1528143591972};\\\", \\\"{x:1293,y:502,t:1528143591988};\\\", \\\"{x:1294,y:517,t:1528143592006};\\\", \\\"{x:1300,y:547,t:1528143592022};\\\", \\\"{x:1311,y:587,t:1528143592039};\\\", \\\"{x:1318,y:610,t:1528143592056};\\\", \\\"{x:1322,y:627,t:1528143592072};\\\", \\\"{x:1323,y:642,t:1528143592088};\\\", \\\"{x:1323,y:654,t:1528143592106};\\\", \\\"{x:1323,y:665,t:1528143592122};\\\", \\\"{x:1323,y:678,t:1528143592139};\\\", \\\"{x:1323,y:694,t:1528143592156};\\\", \\\"{x:1327,y:709,t:1528143592172};\\\", \\\"{x:1332,y:724,t:1528143592189};\\\", \\\"{x:1337,y:745,t:1528143592206};\\\", \\\"{x:1346,y:778,t:1528143592222};\\\", \\\"{x:1350,y:810,t:1528143592240};\\\", \\\"{x:1350,y:839,t:1528143592256};\\\", \\\"{x:1350,y:870,t:1528143592272};\\\", \\\"{x:1350,y:912,t:1528143592289};\\\", \\\"{x:1351,y:940,t:1528143592307};\\\", \\\"{x:1358,y:983,t:1528143592322};\\\", \\\"{x:1365,y:1018,t:1528143592340};\\\", \\\"{x:1374,y:1049,t:1528143592356};\\\", \\\"{x:1386,y:1089,t:1528143592372};\\\", \\\"{x:1401,y:1144,t:1528143592389};\\\", \\\"{x:1414,y:1189,t:1528143592406};\\\", \\\"{x:1421,y:1199,t:1528143592422};\\\", \\\"{x:1423,y:1199,t:1528143592441};\\\", \\\"{x:1424,y:1199,t:1528143592554};\\\", \\\"{x:1426,y:1193,t:1528143592602};\\\", \\\"{x:1429,y:1182,t:1528143592609};\\\", \\\"{x:1433,y:1156,t:1528143592624};\\\", \\\"{x:1438,y:1115,t:1528143592640};\\\", \\\"{x:1438,y:1068,t:1528143592658};\\\", \\\"{x:1438,y:1038,t:1528143592675};\\\", \\\"{x:1439,y:1002,t:1528143592691};\\\", \\\"{x:1445,y:957,t:1528143592707};\\\", \\\"{x:1454,y:877,t:1528143592725};\\\", \\\"{x:1460,y:803,t:1528143592742};\\\", \\\"{x:1460,y:750,t:1528143592758};\\\", \\\"{x:1458,y:725,t:1528143592775};\\\", \\\"{x:1455,y:704,t:1528143592792};\\\", \\\"{x:1455,y:691,t:1528143592808};\\\", \\\"{x:1452,y:663,t:1528143592825};\\\", \\\"{x:1450,y:658,t:1528143592842};\\\", \\\"{x:1450,y:657,t:1528143592865};\\\", \\\"{x:1450,y:654,t:1528143592875};\\\", \\\"{x:1451,y:652,t:1528143592892};\\\", \\\"{x:1455,y:648,t:1528143592908};\\\", \\\"{x:1458,y:646,t:1528143592926};\\\", \\\"{x:1459,y:644,t:1528143592942};\\\", \\\"{x:1462,y:643,t:1528143592959};\\\", \\\"{x:1464,y:642,t:1528143592976};\\\", \\\"{x:1468,y:640,t:1528143592993};\\\", \\\"{x:1470,y:639,t:1528143593058};\\\", \\\"{x:1471,y:639,t:1528143593418};\\\", \\\"{x:1473,y:639,t:1528143593426};\\\", \\\"{x:1478,y:636,t:1528143593443};\\\", \\\"{x:1480,y:636,t:1528143593460};\\\", \\\"{x:1482,y:635,t:1528143593476};\\\", \\\"{x:1484,y:633,t:1528143593492};\\\", \\\"{x:1488,y:632,t:1528143593510};\\\", \\\"{x:1491,y:632,t:1528143593525};\\\", \\\"{x:1493,y:630,t:1528143593543};\\\", \\\"{x:1493,y:629,t:1528143593560};\\\", \\\"{x:1495,y:629,t:1528143593594};\\\", \\\"{x:1497,y:628,t:1528143593609};\\\", \\\"{x:1499,y:626,t:1528143593626};\\\", \\\"{x:1500,y:625,t:1528143593642};\\\", \\\"{x:1501,y:625,t:1528143593664};\\\", \\\"{x:1501,y:624,t:1528143593705};\\\", \\\"{x:1502,y:624,t:1528143593713};\\\", \\\"{x:1502,y:622,t:1528143593817};\\\", \\\"{x:1504,y:622,t:1528143593866};\\\", \\\"{x:1506,y:622,t:1528143593876};\\\", \\\"{x:1510,y:627,t:1528143593895};\\\", \\\"{x:1512,y:631,t:1528143593909};\\\", \\\"{x:1513,y:634,t:1528143593926};\\\", \\\"{x:1513,y:638,t:1528143593942};\\\", \\\"{x:1514,y:643,t:1528143593959};\\\", \\\"{x:1514,y:646,t:1528143593976};\\\", \\\"{x:1514,y:648,t:1528143593992};\\\", \\\"{x:1514,y:654,t:1528143594009};\\\", \\\"{x:1514,y:659,t:1528143594025};\\\", \\\"{x:1514,y:664,t:1528143594042};\\\", \\\"{x:1514,y:667,t:1528143594059};\\\", \\\"{x:1514,y:669,t:1528143594076};\\\", \\\"{x:1514,y:670,t:1528143594104};\\\", \\\"{x:1514,y:671,t:1528143594113};\\\", \\\"{x:1514,y:672,t:1528143594144};\\\", \\\"{x:1514,y:671,t:1528143594361};\\\", \\\"{x:1514,y:665,t:1528143594377};\\\", \\\"{x:1514,y:656,t:1528143594393};\\\", \\\"{x:1514,y:649,t:1528143594410};\\\", \\\"{x:1514,y:645,t:1528143594425};\\\", \\\"{x:1514,y:639,t:1528143594443};\\\", \\\"{x:1514,y:638,t:1528143594458};\\\", \\\"{x:1516,y:636,t:1528143594481};\\\", \\\"{x:1516,y:635,t:1528143594569};\\\", \\\"{x:1517,y:634,t:1528143594634};\\\", \\\"{x:1518,y:634,t:1528143594649};\\\", \\\"{x:1519,y:633,t:1528143594661};\\\", \\\"{x:1519,y:634,t:1528143594947};\\\", \\\"{x:1519,y:640,t:1528143594961};\\\", \\\"{x:1518,y:647,t:1528143594977};\\\", \\\"{x:1518,y:651,t:1528143594994};\\\", \\\"{x:1518,y:652,t:1528143595011};\\\", \\\"{x:1518,y:653,t:1528143595242};\\\", \\\"{x:1518,y:654,t:1528143595312};\\\", \\\"{x:1518,y:655,t:1528143595327};\\\", \\\"{x:1517,y:655,t:1528143595342};\\\", \\\"{x:1520,y:655,t:1528143595392};\\\", \\\"{x:1524,y:652,t:1528143595411};\\\", \\\"{x:1527,y:648,t:1528143595427};\\\", \\\"{x:1528,y:641,t:1528143595443};\\\", \\\"{x:1530,y:635,t:1528143595461};\\\", \\\"{x:1530,y:628,t:1528143595477};\\\", \\\"{x:1531,y:621,t:1528143595493};\\\", \\\"{x:1531,y:616,t:1528143595510};\\\", \\\"{x:1531,y:614,t:1528143595527};\\\", \\\"{x:1531,y:612,t:1528143595544};\\\", \\\"{x:1531,y:611,t:1528143595560};\\\", \\\"{x:1531,y:610,t:1528143595577};\\\", \\\"{x:1531,y:609,t:1528143595721};\\\", \\\"{x:1530,y:608,t:1528143596274};\\\", \\\"{x:1529,y:608,t:1528143596281};\\\", \\\"{x:1528,y:606,t:1528143596297};\\\", \\\"{x:1527,y:601,t:1528143596311};\\\", \\\"{x:1523,y:587,t:1528143596328};\\\", \\\"{x:1517,y:564,t:1528143596344};\\\", \\\"{x:1502,y:514,t:1528143596361};\\\", \\\"{x:1494,y:458,t:1528143596379};\\\", \\\"{x:1488,y:414,t:1528143596395};\\\", \\\"{x:1487,y:393,t:1528143596412};\\\", \\\"{x:1487,y:388,t:1528143596429};\\\", \\\"{x:1486,y:388,t:1528143596546};\\\", \\\"{x:1485,y:392,t:1528143596561};\\\", \\\"{x:1483,y:401,t:1528143596579};\\\", \\\"{x:1483,y:407,t:1528143596595};\\\", \\\"{x:1480,y:414,t:1528143596612};\\\", \\\"{x:1475,y:423,t:1528143596629};\\\", \\\"{x:1471,y:430,t:1528143596644};\\\", \\\"{x:1470,y:435,t:1528143596661};\\\", \\\"{x:1462,y:451,t:1528143596678};\\\", \\\"{x:1455,y:462,t:1528143596695};\\\", \\\"{x:1447,y:477,t:1528143596711};\\\", \\\"{x:1441,y:496,t:1528143596728};\\\", \\\"{x:1438,y:515,t:1528143596744};\\\", \\\"{x:1436,y:548,t:1528143596762};\\\", \\\"{x:1436,y:569,t:1528143596778};\\\", \\\"{x:1438,y:593,t:1528143596795};\\\", \\\"{x:1438,y:618,t:1528143596811};\\\", \\\"{x:1438,y:634,t:1528143596829};\\\", \\\"{x:1438,y:650,t:1528143596846};\\\", \\\"{x:1438,y:670,t:1528143596862};\\\", \\\"{x:1438,y:691,t:1528143596879};\\\", \\\"{x:1438,y:709,t:1528143596895};\\\", \\\"{x:1438,y:730,t:1528143596911};\\\", \\\"{x:1438,y:750,t:1528143596928};\\\", \\\"{x:1438,y:779,t:1528143596945};\\\", \\\"{x:1438,y:798,t:1528143596960};\\\", \\\"{x:1438,y:816,t:1528143596978};\\\", \\\"{x:1435,y:838,t:1528143596995};\\\", \\\"{x:1429,y:859,t:1528143597011};\\\", \\\"{x:1427,y:873,t:1528143597028};\\\", \\\"{x:1421,y:884,t:1528143597045};\\\", \\\"{x:1418,y:890,t:1528143597061};\\\", \\\"{x:1411,y:901,t:1528143597079};\\\", \\\"{x:1402,y:917,t:1528143597095};\\\", \\\"{x:1392,y:936,t:1528143597112};\\\", \\\"{x:1376,y:966,t:1528143597129};\\\", \\\"{x:1365,y:980,t:1528143597144};\\\", \\\"{x:1360,y:987,t:1528143597162};\\\", \\\"{x:1358,y:989,t:1528143597178};\\\", \\\"{x:1357,y:989,t:1528143597197};\\\", \\\"{x:1355,y:989,t:1528143597213};\\\", \\\"{x:1358,y:989,t:1528143597361};\\\", \\\"{x:1365,y:987,t:1528143597369};\\\", \\\"{x:1378,y:981,t:1528143597378};\\\", \\\"{x:1407,y:981,t:1528143597395};\\\", \\\"{x:1441,y:1002,t:1528143597413};\\\", \\\"{x:1475,y:1027,t:1528143597428};\\\", \\\"{x:1502,y:1060,t:1528143597446};\\\", \\\"{x:1514,y:1083,t:1528143597462};\\\", \\\"{x:1526,y:1099,t:1528143597478};\\\", \\\"{x:1532,y:1106,t:1528143597495};\\\", \\\"{x:1535,y:1108,t:1528143597512};\\\", \\\"{x:1536,y:1109,t:1528143597529};\\\", \\\"{x:1536,y:1102,t:1528143597625};\\\", \\\"{x:1532,y:1084,t:1528143597633};\\\", \\\"{x:1524,y:1056,t:1528143597646};\\\", \\\"{x:1501,y:1000,t:1528143597663};\\\", \\\"{x:1473,y:952,t:1528143597679};\\\", \\\"{x:1456,y:913,t:1528143597696};\\\", \\\"{x:1447,y:879,t:1528143597713};\\\", \\\"{x:1447,y:848,t:1528143597730};\\\", \\\"{x:1446,y:829,t:1528143597745};\\\", \\\"{x:1444,y:822,t:1528143597763};\\\", \\\"{x:1443,y:822,t:1528143597780};\\\", \\\"{x:1437,y:820,t:1528143597796};\\\", \\\"{x:1427,y:820,t:1528143597813};\\\", \\\"{x:1417,y:820,t:1528143597829};\\\", \\\"{x:1409,y:818,t:1528143597846};\\\", \\\"{x:1401,y:817,t:1528143597863};\\\", \\\"{x:1396,y:815,t:1528143597880};\\\", \\\"{x:1393,y:813,t:1528143597895};\\\", \\\"{x:1384,y:808,t:1528143597913};\\\", \\\"{x:1364,y:792,t:1528143597929};\\\", \\\"{x:1344,y:762,t:1528143597946};\\\", \\\"{x:1335,y:738,t:1528143597963};\\\", \\\"{x:1330,y:712,t:1528143597980};\\\", \\\"{x:1329,y:688,t:1528143597995};\\\", \\\"{x:1329,y:671,t:1528143598012};\\\", \\\"{x:1329,y:656,t:1528143598030};\\\", \\\"{x:1329,y:642,t:1528143598045};\\\", \\\"{x:1333,y:627,t:1528143598062};\\\", \\\"{x:1336,y:614,t:1528143598079};\\\", \\\"{x:1336,y:603,t:1528143598096};\\\", \\\"{x:1336,y:596,t:1528143598113};\\\", \\\"{x:1336,y:583,t:1528143598129};\\\", \\\"{x:1336,y:575,t:1528143598147};\\\", \\\"{x:1336,y:568,t:1528143598162};\\\", \\\"{x:1336,y:557,t:1528143598179};\\\", \\\"{x:1335,y:547,t:1528143598198};\\\", \\\"{x:1334,y:536,t:1528143598213};\\\", \\\"{x:1332,y:522,t:1528143598230};\\\", \\\"{x:1331,y:512,t:1528143598246};\\\", \\\"{x:1330,y:501,t:1528143598263};\\\", \\\"{x:1327,y:490,t:1528143598280};\\\", \\\"{x:1327,y:483,t:1528143598296};\\\", \\\"{x:1326,y:478,t:1528143598313};\\\", \\\"{x:1322,y:474,t:1528143598329};\\\", \\\"{x:1322,y:473,t:1528143598347};\\\", \\\"{x:1320,y:472,t:1528143598363};\\\", \\\"{x:1319,y:471,t:1528143598379};\\\", \\\"{x:1317,y:471,t:1528143598409};\\\", \\\"{x:1317,y:470,t:1528143598417};\\\", \\\"{x:1316,y:470,t:1528143598433};\\\", \\\"{x:1313,y:471,t:1528143598537};\\\", \\\"{x:1307,y:478,t:1528143598547};\\\", \\\"{x:1300,y:486,t:1528143598564};\\\", \\\"{x:1296,y:492,t:1528143598580};\\\", \\\"{x:1294,y:495,t:1528143598598};\\\", \\\"{x:1294,y:496,t:1528143598818};\\\", \\\"{x:1295,y:497,t:1528143598830};\\\", \\\"{x:1298,y:498,t:1528143598846};\\\", \\\"{x:1299,y:498,t:1528143598864};\\\", \\\"{x:1301,y:498,t:1528143598880};\\\", \\\"{x:1302,y:498,t:1528143598905};\\\", \\\"{x:1303,y:498,t:1528143598913};\\\", \\\"{x:1304,y:498,t:1528143599114};\\\", \\\"{x:1306,y:498,t:1528143599131};\\\", \\\"{x:1307,y:498,t:1528143599147};\\\", \\\"{x:1307,y:497,t:1528143599164};\\\", \\\"{x:1308,y:495,t:1528143599394};\\\", \\\"{x:1309,y:494,t:1528143599402};\\\", \\\"{x:1310,y:493,t:1528143599414};\\\", \\\"{x:1311,y:491,t:1528143599430};\\\", \\\"{x:1311,y:490,t:1528143599536};\\\", \\\"{x:1311,y:489,t:1528143599552};\\\", \\\"{x:1311,y:488,t:1528143599650};\\\", \\\"{x:1312,y:488,t:1528143599778};\\\", \\\"{x:1313,y:487,t:1528143599786};\\\", \\\"{x:1315,y:487,t:1528143599798};\\\", \\\"{x:1317,y:487,t:1528143599814};\\\", \\\"{x:1321,y:487,t:1528143599830};\\\", \\\"{x:1323,y:487,t:1528143599847};\\\", \\\"{x:1325,y:488,t:1528143599865};\\\", \\\"{x:1326,y:488,t:1528143599897};\\\", \\\"{x:1326,y:489,t:1528143599937};\\\", \\\"{x:1326,y:490,t:1528143599948};\\\", \\\"{x:1326,y:493,t:1528143599964};\\\", \\\"{x:1325,y:494,t:1528143600730};\\\", \\\"{x:1324,y:494,t:1528143600745};\\\", \\\"{x:1323,y:494,t:1528143600769};\\\", \\\"{x:1321,y:494,t:1528143600865};\\\", \\\"{x:1320,y:494,t:1528143600881};\\\", \\\"{x:1318,y:494,t:1528143600922};\\\", \\\"{x:1317,y:494,t:1528143600932};\\\", \\\"{x:1314,y:495,t:1528143600948};\\\", \\\"{x:1313,y:495,t:1528143600965};\\\", \\\"{x:1311,y:496,t:1528143600981};\\\", \\\"{x:1310,y:496,t:1528143601001};\\\", \\\"{x:1310,y:497,t:1528143601017};\\\", \\\"{x:1310,y:498,t:1528143601050};\\\", \\\"{x:1310,y:500,t:1528143601065};\\\", \\\"{x:1310,y:501,t:1528143601083};\\\", \\\"{x:1310,y:504,t:1528143601099};\\\", \\\"{x:1310,y:505,t:1528143601115};\\\", \\\"{x:1310,y:507,t:1528143601132};\\\", \\\"{x:1310,y:509,t:1528143601148};\\\", \\\"{x:1312,y:513,t:1528143601165};\\\", \\\"{x:1315,y:520,t:1528143601181};\\\", \\\"{x:1315,y:525,t:1528143601199};\\\", \\\"{x:1315,y:529,t:1528143601215};\\\", \\\"{x:1315,y:532,t:1528143601231};\\\", \\\"{x:1315,y:535,t:1528143601248};\\\", \\\"{x:1315,y:538,t:1528143601265};\\\", \\\"{x:1313,y:541,t:1528143601282};\\\", \\\"{x:1312,y:543,t:1528143601298};\\\", \\\"{x:1312,y:545,t:1528143601316};\\\", \\\"{x:1312,y:546,t:1528143601332};\\\", \\\"{x:1312,y:548,t:1528143601348};\\\", \\\"{x:1311,y:551,t:1528143601366};\\\", \\\"{x:1311,y:553,t:1528143601381};\\\", \\\"{x:1311,y:558,t:1528143601399};\\\", \\\"{x:1308,y:562,t:1528143601416};\\\", \\\"{x:1308,y:566,t:1528143601431};\\\", \\\"{x:1305,y:573,t:1528143601449};\\\", \\\"{x:1305,y:577,t:1528143601465};\\\", \\\"{x:1305,y:580,t:1528143601482};\\\", \\\"{x:1305,y:582,t:1528143601498};\\\", \\\"{x:1304,y:587,t:1528143601515};\\\", \\\"{x:1304,y:593,t:1528143601532};\\\", \\\"{x:1304,y:601,t:1528143601549};\\\", \\\"{x:1304,y:606,t:1528143601566};\\\", \\\"{x:1304,y:608,t:1528143601582};\\\", \\\"{x:1304,y:610,t:1528143601617};\\\", \\\"{x:1304,y:611,t:1528143601714};\\\", \\\"{x:1304,y:612,t:1528143601721};\\\", \\\"{x:1304,y:613,t:1528143601733};\\\", \\\"{x:1304,y:614,t:1528143601748};\\\", \\\"{x:1304,y:616,t:1528143601766};\\\", \\\"{x:1305,y:619,t:1528143601782};\\\", \\\"{x:1306,y:622,t:1528143601799};\\\", \\\"{x:1310,y:627,t:1528143601815};\\\", \\\"{x:1311,y:631,t:1528143601832};\\\", \\\"{x:1312,y:632,t:1528143601847};\\\", \\\"{x:1312,y:633,t:1528143601872};\\\", \\\"{x:1312,y:634,t:1528143601888};\\\", \\\"{x:1314,y:631,t:1528143606681};\\\", \\\"{x:1317,y:618,t:1528143606690};\\\", \\\"{x:1318,y:614,t:1528143606703};\\\", \\\"{x:1319,y:612,t:1528143606721};\\\", \\\"{x:1320,y:609,t:1528143606736};\\\", \\\"{x:1320,y:608,t:1528143606977};\\\", \\\"{x:1319,y:614,t:1528143607001};\\\", \\\"{x:1317,y:617,t:1528143607009};\\\", \\\"{x:1317,y:619,t:1528143607020};\\\", \\\"{x:1317,y:623,t:1528143607037};\\\", \\\"{x:1317,y:627,t:1528143607053};\\\", \\\"{x:1316,y:631,t:1528143607070};\\\", \\\"{x:1316,y:633,t:1528143607087};\\\", \\\"{x:1316,y:635,t:1528143607102};\\\", \\\"{x:1316,y:638,t:1528143607121};\\\", \\\"{x:1316,y:641,t:1528143607137};\\\", \\\"{x:1316,y:643,t:1528143607153};\\\", \\\"{x:1316,y:645,t:1528143607170};\\\", \\\"{x:1316,y:647,t:1528143607186};\\\", \\\"{x:1316,y:650,t:1528143607203};\\\", \\\"{x:1316,y:653,t:1528143607220};\\\", \\\"{x:1317,y:656,t:1528143607237};\\\", \\\"{x:1317,y:657,t:1528143607253};\\\", \\\"{x:1318,y:663,t:1528143607270};\\\", \\\"{x:1318,y:667,t:1528143607287};\\\", \\\"{x:1318,y:672,t:1528143607304};\\\", \\\"{x:1318,y:681,t:1528143607320};\\\", \\\"{x:1321,y:694,t:1528143607337};\\\", \\\"{x:1321,y:703,t:1528143607353};\\\", \\\"{x:1321,y:712,t:1528143607370};\\\", \\\"{x:1321,y:719,t:1528143607387};\\\", \\\"{x:1321,y:727,t:1528143607404};\\\", \\\"{x:1322,y:735,t:1528143607420};\\\", \\\"{x:1322,y:742,t:1528143607437};\\\", \\\"{x:1322,y:751,t:1528143607454};\\\", \\\"{x:1322,y:761,t:1528143607470};\\\", \\\"{x:1322,y:775,t:1528143607487};\\\", \\\"{x:1321,y:792,t:1528143607504};\\\", \\\"{x:1319,y:811,t:1528143607520};\\\", \\\"{x:1318,y:836,t:1528143607537};\\\", \\\"{x:1316,y:851,t:1528143607554};\\\", \\\"{x:1314,y:867,t:1528143607570};\\\", \\\"{x:1313,y:879,t:1528143607587};\\\", \\\"{x:1307,y:895,t:1528143607604};\\\", \\\"{x:1304,y:911,t:1528143607620};\\\", \\\"{x:1304,y:926,t:1528143607637};\\\", \\\"{x:1304,y:945,t:1528143607654};\\\", \\\"{x:1308,y:962,t:1528143607671};\\\", \\\"{x:1314,y:982,t:1528143607687};\\\", \\\"{x:1322,y:999,t:1528143607704};\\\", \\\"{x:1325,y:1014,t:1528143607721};\\\", \\\"{x:1326,y:1016,t:1528143607737};\\\", \\\"{x:1326,y:1017,t:1528143607753};\\\", \\\"{x:1327,y:1018,t:1528143607771};\\\", \\\"{x:1327,y:1011,t:1528143607946};\\\", \\\"{x:1327,y:1004,t:1528143607954};\\\", \\\"{x:1327,y:1000,t:1528143607970};\\\", \\\"{x:1326,y:996,t:1528143607987};\\\", \\\"{x:1326,y:995,t:1528143608003};\\\", \\\"{x:1326,y:994,t:1528143608033};\\\", \\\"{x:1325,y:994,t:1528143608178};\\\", \\\"{x:1323,y:987,t:1528143608193};\\\", \\\"{x:1320,y:971,t:1528143608204};\\\", \\\"{x:1317,y:942,t:1528143608220};\\\", \\\"{x:1307,y:883,t:1528143608237};\\\", \\\"{x:1295,y:794,t:1528143608253};\\\", \\\"{x:1284,y:706,t:1528143608271};\\\", \\\"{x:1271,y:622,t:1528143608288};\\\", \\\"{x:1261,y:563,t:1528143608304};\\\", \\\"{x:1261,y:479,t:1528143608320};\\\", \\\"{x:1261,y:451,t:1528143608338};\\\", \\\"{x:1265,y:426,t:1528143608353};\\\", \\\"{x:1268,y:405,t:1528143608371};\\\", \\\"{x:1272,y:393,t:1528143608388};\\\", \\\"{x:1273,y:388,t:1528143608404};\\\", \\\"{x:1274,y:385,t:1528143608421};\\\", \\\"{x:1278,y:381,t:1528143608438};\\\", \\\"{x:1284,y:378,t:1528143608454};\\\", \\\"{x:1292,y:375,t:1528143608471};\\\", \\\"{x:1299,y:370,t:1528143608488};\\\", \\\"{x:1304,y:368,t:1528143608503};\\\", \\\"{x:1309,y:366,t:1528143608521};\\\", \\\"{x:1311,y:366,t:1528143608545};\\\", \\\"{x:1317,y:366,t:1528143608555};\\\", \\\"{x:1323,y:373,t:1528143608571};\\\", \\\"{x:1326,y:386,t:1528143608588};\\\", \\\"{x:1327,y:404,t:1528143608605};\\\", \\\"{x:1327,y:416,t:1528143608620};\\\", \\\"{x:1327,y:432,t:1528143608638};\\\", \\\"{x:1327,y:440,t:1528143608655};\\\", \\\"{x:1327,y:453,t:1528143608671};\\\", \\\"{x:1327,y:458,t:1528143608688};\\\", \\\"{x:1324,y:460,t:1528143608704};\\\", \\\"{x:1323,y:460,t:1528143608721};\\\", \\\"{x:1321,y:460,t:1528143608738};\\\", \\\"{x:1320,y:460,t:1528143608809};\\\", \\\"{x:1319,y:460,t:1528143608825};\\\", \\\"{x:1319,y:459,t:1528143608838};\\\", \\\"{x:1316,y:459,t:1528143608855};\\\", \\\"{x:1315,y:458,t:1528143608961};\\\", \\\"{x:1310,y:463,t:1528143608985};\\\", \\\"{x:1307,y:473,t:1528143608992};\\\", \\\"{x:1304,y:478,t:1528143609005};\\\", \\\"{x:1302,y:489,t:1528143609020};\\\", \\\"{x:1300,y:497,t:1528143609037};\\\", \\\"{x:1300,y:502,t:1528143609055};\\\", \\\"{x:1301,y:502,t:1528143609128};\\\", \\\"{x:1304,y:502,t:1528143609138};\\\", \\\"{x:1309,y:499,t:1528143609155};\\\", \\\"{x:1311,y:494,t:1528143609171};\\\", \\\"{x:1312,y:487,t:1528143609188};\\\", \\\"{x:1312,y:484,t:1528143609205};\\\", \\\"{x:1313,y:481,t:1528143609222};\\\", \\\"{x:1313,y:480,t:1528143609238};\\\", \\\"{x:1313,y:484,t:1528143609666};\\\", \\\"{x:1313,y:487,t:1528143609673};\\\", \\\"{x:1312,y:488,t:1528143609689};\\\", \\\"{x:1312,y:490,t:1528143609705};\\\", \\\"{x:1312,y:491,t:1528143610113};\\\", \\\"{x:1311,y:491,t:1528143610169};\\\", \\\"{x:1311,y:492,t:1528143610194};\\\", \\\"{x:1311,y:493,t:1528143610205};\\\", \\\"{x:1308,y:496,t:1528143610222};\\\", \\\"{x:1308,y:497,t:1528143610240};\\\", \\\"{x:1307,y:498,t:1528143610280};\\\", \\\"{x:1307,y:499,t:1528143610457};\\\", \\\"{x:1305,y:499,t:1528143610489};\\\", \\\"{x:1299,y:500,t:1528143610506};\\\", \\\"{x:1291,y:505,t:1528143610523};\\\", \\\"{x:1285,y:524,t:1528143610538};\\\", \\\"{x:1278,y:545,t:1528143610556};\\\", \\\"{x:1269,y:567,t:1528143610572};\\\", \\\"{x:1262,y:584,t:1528143610589};\\\", \\\"{x:1256,y:605,t:1528143610606};\\\", \\\"{x:1250,y:627,t:1528143610623};\\\", \\\"{x:1242,y:647,t:1528143610639};\\\", \\\"{x:1232,y:663,t:1528143610656};\\\", \\\"{x:1219,y:693,t:1528143610672};\\\", \\\"{x:1210,y:713,t:1528143610689};\\\", \\\"{x:1199,y:731,t:1528143610706};\\\", \\\"{x:1189,y:748,t:1528143610723};\\\", \\\"{x:1179,y:765,t:1528143610739};\\\", \\\"{x:1168,y:782,t:1528143610756};\\\", \\\"{x:1160,y:798,t:1528143610773};\\\", \\\"{x:1154,y:811,t:1528143610790};\\\", \\\"{x:1146,y:822,t:1528143610806};\\\", \\\"{x:1139,y:835,t:1528143610823};\\\", \\\"{x:1125,y:857,t:1528143610840};\\\", \\\"{x:1117,y:872,t:1528143610856};\\\", \\\"{x:1114,y:876,t:1528143610872};\\\", \\\"{x:1111,y:877,t:1528143610890};\\\", \\\"{x:1107,y:877,t:1528143610906};\\\", \\\"{x:1103,y:879,t:1528143610923};\\\", \\\"{x:1100,y:890,t:1528143610941};\\\", \\\"{x:1098,y:914,t:1528143610956};\\\", \\\"{x:1090,y:939,t:1528143610973};\\\", \\\"{x:1085,y:958,t:1528143610990};\\\", \\\"{x:1079,y:971,t:1528143611006};\\\", \\\"{x:1073,y:983,t:1528143611023};\\\", \\\"{x:1069,y:997,t:1528143611040};\\\", \\\"{x:1065,y:1012,t:1528143611056};\\\", \\\"{x:1060,y:1032,t:1528143611073};\\\", \\\"{x:1056,y:1048,t:1528143611090};\\\", \\\"{x:1052,y:1062,t:1528143611106};\\\", \\\"{x:1049,y:1071,t:1528143611122};\\\", \\\"{x:1047,y:1077,t:1528143611140};\\\", \\\"{x:1047,y:1079,t:1528143611156};\\\", \\\"{x:1047,y:1080,t:1528143611173};\\\", \\\"{x:1047,y:1078,t:1528143611297};\\\", \\\"{x:1052,y:1064,t:1528143611307};\\\", \\\"{x:1074,y:1032,t:1528143611323};\\\", \\\"{x:1083,y:1017,t:1528143611340};\\\", \\\"{x:1087,y:1011,t:1528143611357};\\\", \\\"{x:1091,y:1005,t:1528143611373};\\\", \\\"{x:1095,y:1000,t:1528143611390};\\\", \\\"{x:1103,y:987,t:1528143611407};\\\", \\\"{x:1117,y:962,t:1528143611423};\\\", \\\"{x:1131,y:924,t:1528143611440};\\\", \\\"{x:1145,y:866,t:1528143611456};\\\", \\\"{x:1150,y:839,t:1528143611473};\\\", \\\"{x:1157,y:795,t:1528143611489};\\\", \\\"{x:1163,y:750,t:1528143611506};\\\", \\\"{x:1171,y:694,t:1528143611522};\\\", \\\"{x:1177,y:651,t:1528143611540};\\\", \\\"{x:1181,y:625,t:1528143611557};\\\", \\\"{x:1184,y:603,t:1528143611573};\\\", \\\"{x:1188,y:589,t:1528143611590};\\\", \\\"{x:1189,y:579,t:1528143611607};\\\", \\\"{x:1191,y:567,t:1528143611623};\\\", \\\"{x:1194,y:556,t:1528143611639};\\\", \\\"{x:1199,y:535,t:1528143611656};\\\", \\\"{x:1205,y:522,t:1528143611674};\\\", \\\"{x:1212,y:512,t:1528143611690};\\\", \\\"{x:1223,y:503,t:1528143611707};\\\", \\\"{x:1238,y:496,t:1528143611724};\\\", \\\"{x:1256,y:486,t:1528143611740};\\\", \\\"{x:1274,y:476,t:1528143611757};\\\", \\\"{x:1293,y:466,t:1528143611774};\\\", \\\"{x:1307,y:459,t:1528143611790};\\\", \\\"{x:1314,y:457,t:1528143611807};\\\", \\\"{x:1316,y:456,t:1528143611824};\\\", \\\"{x:1317,y:456,t:1528143611840};\\\", \\\"{x:1324,y:455,t:1528143611857};\\\", \\\"{x:1334,y:455,t:1528143611874};\\\", \\\"{x:1339,y:455,t:1528143611890};\\\", \\\"{x:1340,y:455,t:1528143611913};\\\", \\\"{x:1341,y:455,t:1528143611929};\\\", \\\"{x:1342,y:456,t:1528143611944};\\\", \\\"{x:1343,y:457,t:1528143611960};\\\", \\\"{x:1344,y:460,t:1528143611975};\\\", \\\"{x:1344,y:474,t:1528143611990};\\\", \\\"{x:1344,y:486,t:1528143612007};\\\", \\\"{x:1341,y:497,t:1528143612024};\\\", \\\"{x:1338,y:502,t:1528143612041};\\\", \\\"{x:1336,y:504,t:1528143612057};\\\", \\\"{x:1334,y:504,t:1528143612074};\\\", \\\"{x:1333,y:504,t:1528143612091};\\\", \\\"{x:1332,y:504,t:1528143612128};\\\", \\\"{x:1331,y:504,t:1528143612168};\\\", \\\"{x:1329,y:504,t:1528143612177};\\\", \\\"{x:1328,y:506,t:1528143612191};\\\", \\\"{x:1328,y:513,t:1528143612207};\\\", \\\"{x:1328,y:525,t:1528143612224};\\\", \\\"{x:1330,y:554,t:1528143612241};\\\", \\\"{x:1337,y:576,t:1528143612257};\\\", \\\"{x:1341,y:596,t:1528143612275};\\\", \\\"{x:1347,y:617,t:1528143612291};\\\", \\\"{x:1353,y:634,t:1528143612308};\\\", \\\"{x:1355,y:644,t:1528143612324};\\\", \\\"{x:1361,y:658,t:1528143612341};\\\", \\\"{x:1368,y:671,t:1528143612357};\\\", \\\"{x:1373,y:683,t:1528143612374};\\\", \\\"{x:1377,y:689,t:1528143612391};\\\", \\\"{x:1378,y:693,t:1528143612408};\\\", \\\"{x:1380,y:701,t:1528143612425};\\\", \\\"{x:1386,y:715,t:1528143612441};\\\", \\\"{x:1386,y:722,t:1528143612458};\\\", \\\"{x:1386,y:727,t:1528143612475};\\\", \\\"{x:1385,y:732,t:1528143612491};\\\", \\\"{x:1385,y:738,t:1528143612508};\\\", \\\"{x:1388,y:748,t:1528143612525};\\\", \\\"{x:1391,y:757,t:1528143612541};\\\", \\\"{x:1394,y:766,t:1528143612558};\\\", \\\"{x:1401,y:783,t:1528143612574};\\\", \\\"{x:1414,y:803,t:1528143612591};\\\", \\\"{x:1423,y:822,t:1528143612608};\\\", \\\"{x:1436,y:848,t:1528143612625};\\\", \\\"{x:1447,y:866,t:1528143612641};\\\", \\\"{x:1460,y:886,t:1528143612658};\\\", \\\"{x:1475,y:905,t:1528143612674};\\\", \\\"{x:1489,y:924,t:1528143612691};\\\", \\\"{x:1495,y:931,t:1528143612708};\\\", \\\"{x:1500,y:938,t:1528143612725};\\\", \\\"{x:1504,y:943,t:1528143612742};\\\", \\\"{x:1508,y:951,t:1528143612758};\\\", \\\"{x:1516,y:964,t:1528143612774};\\\", \\\"{x:1520,y:971,t:1528143612791};\\\", \\\"{x:1524,y:979,t:1528143612808};\\\", \\\"{x:1526,y:981,t:1528143612824};\\\", \\\"{x:1526,y:984,t:1528143612872};\\\", \\\"{x:1526,y:985,t:1528143612880};\\\", \\\"{x:1528,y:987,t:1528143612891};\\\", \\\"{x:1528,y:992,t:1528143612907};\\\", \\\"{x:1530,y:994,t:1528143612924};\\\", \\\"{x:1530,y:993,t:1528143613121};\\\", \\\"{x:1531,y:990,t:1528143613129};\\\", \\\"{x:1532,y:988,t:1528143613141};\\\", \\\"{x:1533,y:984,t:1528143613158};\\\", \\\"{x:1533,y:981,t:1528143613176};\\\", \\\"{x:1536,y:976,t:1528143613191};\\\", \\\"{x:1536,y:969,t:1528143613208};\\\", \\\"{x:1536,y:965,t:1528143613225};\\\", \\\"{x:1536,y:963,t:1528143613241};\\\", \\\"{x:1537,y:962,t:1528143613258};\\\", \\\"{x:1538,y:962,t:1528143613522};\\\", \\\"{x:1540,y:963,t:1528143613529};\\\", \\\"{x:1542,y:963,t:1528143613542};\\\", \\\"{x:1542,y:964,t:1528143613558};\\\", \\\"{x:1543,y:964,t:1528143613575};\\\", \\\"{x:1544,y:966,t:1528143614049};\\\", \\\"{x:1545,y:966,t:1528143614060};\\\", \\\"{x:1545,y:967,t:1528143614075};\\\", \\\"{x:1545,y:968,t:1528143614136};\\\", \\\"{x:1545,y:969,t:1528143614185};\\\", \\\"{x:1544,y:969,t:1528143614281};\\\", \\\"{x:1543,y:969,t:1528143614296};\\\", \\\"{x:1544,y:969,t:1528143614713};\\\", \\\"{x:1545,y:952,t:1528143616410};\\\", \\\"{x:1525,y:856,t:1528143616427};\\\", \\\"{x:1510,y:820,t:1528143616445};\\\", \\\"{x:1505,y:804,t:1528143616461};\\\", \\\"{x:1502,y:797,t:1528143616478};\\\", \\\"{x:1502,y:796,t:1528143616494};\\\", \\\"{x:1502,y:795,t:1528143616511};\\\", \\\"{x:1501,y:793,t:1528143616528};\\\", \\\"{x:1500,y:788,t:1528143616545};\\\", \\\"{x:1498,y:784,t:1528143616561};\\\", \\\"{x:1496,y:774,t:1528143616577};\\\", \\\"{x:1494,y:763,t:1528143616595};\\\", \\\"{x:1491,y:746,t:1528143616611};\\\", \\\"{x:1484,y:718,t:1528143616627};\\\", \\\"{x:1476,y:680,t:1528143616645};\\\", \\\"{x:1473,y:640,t:1528143616661};\\\", \\\"{x:1470,y:580,t:1528143616677};\\\", \\\"{x:1470,y:474,t:1528143616694};\\\", \\\"{x:1481,y:356,t:1528143616712};\\\", \\\"{x:1504,y:239,t:1528143616727};\\\", \\\"{x:1539,y:90,t:1528143616744};\\\", \\\"{x:1544,y:41,t:1528143616760};\\\", \\\"{x:1546,y:27,t:1528143616777};\\\", \\\"{x:1546,y:24,t:1528143616794};\\\", \\\"{x:1543,y:24,t:1528143616897};\\\", \\\"{x:1538,y:27,t:1528143616911};\\\", \\\"{x:1524,y:47,t:1528143616928};\\\", \\\"{x:1520,y:55,t:1528143616945};\\\", \\\"{x:1509,y:86,t:1528143616961};\\\", \\\"{x:1499,y:104,t:1528143616978};\\\", \\\"{x:1489,y:120,t:1528143616994};\\\", \\\"{x:1478,y:136,t:1528143617011};\\\", \\\"{x:1467,y:152,t:1528143617029};\\\", \\\"{x:1453,y:168,t:1528143617045};\\\", \\\"{x:1431,y:197,t:1528143617062};\\\", \\\"{x:1400,y:230,t:1528143617078};\\\", \\\"{x:1363,y:266,t:1528143617094};\\\", \\\"{x:1326,y:302,t:1528143617112};\\\", \\\"{x:1274,y:346,t:1528143617129};\\\", \\\"{x:1259,y:363,t:1528143617145};\\\", \\\"{x:1245,y:383,t:1528143617162};\\\", \\\"{x:1237,y:400,t:1528143617179};\\\", \\\"{x:1228,y:416,t:1528143617194};\\\", \\\"{x:1221,y:428,t:1528143617211};\\\", \\\"{x:1214,y:438,t:1528143617228};\\\", \\\"{x:1211,y:443,t:1528143617244};\\\", \\\"{x:1209,y:444,t:1528143617261};\\\", \\\"{x:1209,y:445,t:1528143617377};\\\", \\\"{x:1210,y:449,t:1528143617401};\\\", \\\"{x:1211,y:452,t:1528143617412};\\\", \\\"{x:1220,y:467,t:1528143617428};\\\", \\\"{x:1228,y:479,t:1528143617446};\\\", \\\"{x:1239,y:492,t:1528143617461};\\\", \\\"{x:1252,y:510,t:1528143617477};\\\", \\\"{x:1269,y:531,t:1528143617495};\\\", \\\"{x:1285,y:547,t:1528143617510};\\\", \\\"{x:1303,y:570,t:1528143617527};\\\", \\\"{x:1320,y:584,t:1528143617544};\\\", \\\"{x:1332,y:589,t:1528143617561};\\\", \\\"{x:1333,y:589,t:1528143617577};\\\", \\\"{x:1334,y:584,t:1528143617665};\\\", \\\"{x:1334,y:553,t:1528143617678};\\\", \\\"{x:1323,y:506,t:1528143617696};\\\", \\\"{x:1305,y:476,t:1528143617712};\\\", \\\"{x:1301,y:469,t:1528143617729};\\\", \\\"{x:1295,y:459,t:1528143617745};\\\", \\\"{x:1295,y:456,t:1528143617762};\\\", \\\"{x:1295,y:455,t:1528143617779};\\\", \\\"{x:1294,y:455,t:1528143617796};\\\", \\\"{x:1294,y:457,t:1528143617921};\\\", \\\"{x:1296,y:458,t:1528143617937};\\\", \\\"{x:1298,y:459,t:1528143617945};\\\", \\\"{x:1303,y:462,t:1528143617962};\\\", \\\"{x:1308,y:465,t:1528143617978};\\\", \\\"{x:1311,y:466,t:1528143617995};\\\", \\\"{x:1312,y:467,t:1528143618012};\\\", \\\"{x:1314,y:475,t:1528143624705};\\\", \\\"{x:1314,y:489,t:1528143624718};\\\", \\\"{x:1314,y:508,t:1528143624735};\\\", \\\"{x:1316,y:513,t:1528143624751};\\\", \\\"{x:1316,y:515,t:1528143624768};\\\", \\\"{x:1317,y:516,t:1528143625081};\\\", \\\"{x:1319,y:515,t:1528143625089};\\\", \\\"{x:1322,y:508,t:1528143625101};\\\", \\\"{x:1324,y:500,t:1528143625117};\\\", \\\"{x:1325,y:494,t:1528143625134};\\\", \\\"{x:1327,y:489,t:1528143625152};\\\", \\\"{x:1328,y:486,t:1528143625168};\\\", \\\"{x:1324,y:486,t:1528143625416};\\\", \\\"{x:1322,y:490,t:1528143625424};\\\", \\\"{x:1319,y:492,t:1528143625434};\\\", \\\"{x:1315,y:497,t:1528143625451};\\\", \\\"{x:1313,y:500,t:1528143625467};\\\", \\\"{x:1311,y:502,t:1528143625485};\\\", \\\"{x:1312,y:504,t:1528143625921};\\\", \\\"{x:1316,y:506,t:1528143625935};\\\", \\\"{x:1326,y:513,t:1528143625952};\\\", \\\"{x:1332,y:522,t:1528143625969};\\\", \\\"{x:1334,y:526,t:1528143625985};\\\", \\\"{x:1335,y:531,t:1528143626002};\\\", \\\"{x:1336,y:538,t:1528143626019};\\\", \\\"{x:1336,y:544,t:1528143626035};\\\", \\\"{x:1336,y:554,t:1528143626051};\\\", \\\"{x:1336,y:560,t:1528143626068};\\\", \\\"{x:1336,y:567,t:1528143626085};\\\", \\\"{x:1336,y:571,t:1528143626101};\\\", \\\"{x:1334,y:579,t:1528143626118};\\\", \\\"{x:1329,y:593,t:1528143626135};\\\", \\\"{x:1324,y:611,t:1528143626151};\\\", \\\"{x:1308,y:660,t:1528143626168};\\\", \\\"{x:1297,y:697,t:1528143626184};\\\", \\\"{x:1292,y:719,t:1528143626201};\\\", \\\"{x:1288,y:739,t:1528143626218};\\\", \\\"{x:1288,y:754,t:1528143626235};\\\", \\\"{x:1288,y:773,t:1528143626251};\\\", \\\"{x:1288,y:797,t:1528143626268};\\\", \\\"{x:1288,y:819,t:1528143626285};\\\", \\\"{x:1288,y:838,t:1528143626301};\\\", \\\"{x:1288,y:856,t:1528143626318};\\\", \\\"{x:1288,y:869,t:1528143626335};\\\", \\\"{x:1290,y:880,t:1528143626351};\\\", \\\"{x:1291,y:884,t:1528143626368};\\\", \\\"{x:1291,y:885,t:1528143626385};\\\", \\\"{x:1292,y:885,t:1528143626401};\\\", \\\"{x:1292,y:887,t:1528143626465};\\\", \\\"{x:1292,y:888,t:1528143626472};\\\", \\\"{x:1293,y:890,t:1528143626486};\\\", \\\"{x:1293,y:892,t:1528143626502};\\\", \\\"{x:1294,y:893,t:1528143626519};\\\", \\\"{x:1296,y:884,t:1528143626633};\\\", \\\"{x:1300,y:874,t:1528143626641};\\\", \\\"{x:1304,y:866,t:1528143626653};\\\", \\\"{x:1309,y:852,t:1528143626669};\\\", \\\"{x:1315,y:837,t:1528143626686};\\\", \\\"{x:1321,y:823,t:1528143626702};\\\", \\\"{x:1325,y:814,t:1528143626719};\\\", \\\"{x:1329,y:806,t:1528143626736};\\\", \\\"{x:1331,y:797,t:1528143626752};\\\", \\\"{x:1333,y:793,t:1528143626768};\\\", \\\"{x:1335,y:789,t:1528143626785};\\\", \\\"{x:1335,y:776,t:1528143626802};\\\", \\\"{x:1335,y:764,t:1528143626819};\\\", \\\"{x:1335,y:750,t:1528143626835};\\\", \\\"{x:1330,y:737,t:1528143626852};\\\", \\\"{x:1326,y:730,t:1528143626869};\\\", \\\"{x:1323,y:721,t:1528143626885};\\\", \\\"{x:1321,y:713,t:1528143626903};\\\", \\\"{x:1321,y:711,t:1528143626919};\\\", \\\"{x:1321,y:706,t:1528143626936};\\\", \\\"{x:1321,y:700,t:1528143626953};\\\", \\\"{x:1321,y:696,t:1528143626970};\\\", \\\"{x:1318,y:695,t:1528143626986};\\\", \\\"{x:1309,y:691,t:1528143627003};\\\", \\\"{x:1298,y:689,t:1528143627019};\\\", \\\"{x:1286,y:686,t:1528143627036};\\\", \\\"{x:1280,y:686,t:1528143627052};\\\", \\\"{x:1269,y:688,t:1528143627070};\\\", \\\"{x:1230,y:694,t:1528143627086};\\\", \\\"{x:1181,y:704,t:1528143627102};\\\", \\\"{x:1115,y:709,t:1528143627119};\\\", \\\"{x:1016,y:698,t:1528143627136};\\\", \\\"{x:864,y:658,t:1528143627152};\\\", \\\"{x:800,y:650,t:1528143627169};\\\", \\\"{x:747,y:642,t:1528143627186};\\\", \\\"{x:686,y:627,t:1528143627202};\\\", \\\"{x:631,y:612,t:1528143627221};\\\", \\\"{x:603,y:603,t:1528143627236};\\\", \\\"{x:599,y:602,t:1528143627251};\\\", \\\"{x:597,y:602,t:1528143627312};\\\", \\\"{x:592,y:602,t:1528143627320};\\\", \\\"{x:577,y:601,t:1528143627335};\\\", \\\"{x:561,y:603,t:1528143627352};\\\", \\\"{x:555,y:607,t:1528143627369};\\\", \\\"{x:555,y:608,t:1528143627386};\\\", \\\"{x:557,y:609,t:1528143627456};\\\", \\\"{x:567,y:606,t:1528143627469};\\\", \\\"{x:594,y:592,t:1528143627487};\\\", \\\"{x:637,y:570,t:1528143627503};\\\", \\\"{x:672,y:551,t:1528143627519};\\\", \\\"{x:704,y:533,t:1528143627537};\\\", \\\"{x:719,y:522,t:1528143627552};\\\", \\\"{x:733,y:512,t:1528143627570};\\\", \\\"{x:749,y:506,t:1528143627586};\\\", \\\"{x:775,y:494,t:1528143627602};\\\", \\\"{x:795,y:488,t:1528143627619};\\\", \\\"{x:808,y:485,t:1528143627636};\\\", \\\"{x:814,y:482,t:1528143627653};\\\", \\\"{x:818,y:481,t:1528143627669};\\\", \\\"{x:824,y:479,t:1528143627687};\\\", \\\"{x:839,y:472,t:1528143627703};\\\", \\\"{x:852,y:467,t:1528143627719};\\\", \\\"{x:855,y:466,t:1528143627737};\\\", \\\"{x:854,y:467,t:1528143627808};\\\", \\\"{x:850,y:469,t:1528143627820};\\\", \\\"{x:838,y:491,t:1528143627836};\\\", \\\"{x:830,y:517,t:1528143627854};\\\", \\\"{x:822,y:533,t:1528143627872};\\\", \\\"{x:818,y:542,t:1528143627887};\\\", \\\"{x:816,y:546,t:1528143627903};\\\", \\\"{x:814,y:547,t:1528143627919};\\\", \\\"{x:814,y:548,t:1528143627936};\\\", \\\"{x:814,y:549,t:1528143627960};\\\", \\\"{x:814,y:551,t:1528143627970};\\\", \\\"{x:814,y:553,t:1528143627991};\\\", \\\"{x:815,y:553,t:1528143628003};\\\", \\\"{x:819,y:553,t:1528143628019};\\\", \\\"{x:822,y:553,t:1528143628036};\\\", \\\"{x:826,y:552,t:1528143628053};\\\", \\\"{x:831,y:550,t:1528143628069};\\\", \\\"{x:833,y:549,t:1528143628086};\\\", \\\"{x:835,y:549,t:1528143628103};\\\", \\\"{x:835,y:548,t:1528143628297};\\\", \\\"{x:834,y:548,t:1528143628656};\\\", \\\"{x:835,y:548,t:1528143628737};\\\", \\\"{x:840,y:547,t:1528143628753};\\\", \\\"{x:887,y:547,t:1528143628770};\\\", \\\"{x:1009,y:547,t:1528143628789};\\\", \\\"{x:1100,y:555,t:1528143628804};\\\", \\\"{x:1184,y:568,t:1528143628820};\\\", \\\"{x:1276,y:582,t:1528143628837};\\\", \\\"{x:1351,y:593,t:1528143628853};\\\", \\\"{x:1392,y:602,t:1528143628870};\\\", \\\"{x:1417,y:610,t:1528143628887};\\\", \\\"{x:1432,y:620,t:1528143628903};\\\", \\\"{x:1439,y:624,t:1528143628920};\\\", \\\"{x:1439,y:626,t:1528143628937};\\\", \\\"{x:1439,y:629,t:1528143628953};\\\", \\\"{x:1439,y:634,t:1528143628970};\\\", \\\"{x:1439,y:640,t:1528143628988};\\\", \\\"{x:1438,y:645,t:1528143629003};\\\", \\\"{x:1436,y:650,t:1528143629021};\\\", \\\"{x:1433,y:656,t:1528143629037};\\\", \\\"{x:1428,y:658,t:1528143629053};\\\", \\\"{x:1423,y:662,t:1528143629070};\\\", \\\"{x:1420,y:662,t:1528143629087};\\\", \\\"{x:1419,y:662,t:1528143629105};\\\", \\\"{x:1418,y:662,t:1528143629128};\\\", \\\"{x:1416,y:662,t:1528143629138};\\\", \\\"{x:1409,y:662,t:1528143629155};\\\", \\\"{x:1397,y:659,t:1528143629171};\\\", \\\"{x:1381,y:652,t:1528143629188};\\\", \\\"{x:1366,y:646,t:1528143629205};\\\", \\\"{x:1357,y:643,t:1528143629221};\\\", \\\"{x:1355,y:642,t:1528143629238};\\\", \\\"{x:1358,y:645,t:1528143629337};\\\", \\\"{x:1362,y:646,t:1528143629355};\\\", \\\"{x:1364,y:646,t:1528143629370};\\\", \\\"{x:1364,y:647,t:1528143629388};\\\", \\\"{x:1364,y:646,t:1528143629464};\\\", \\\"{x:1362,y:644,t:1528143629472};\\\", \\\"{x:1356,y:642,t:1528143629488};\\\", \\\"{x:1343,y:637,t:1528143629504};\\\", \\\"{x:1342,y:635,t:1528143629521};\\\", \\\"{x:1340,y:635,t:1528143629537};\\\", \\\"{x:1339,y:635,t:1528143629560};\\\", \\\"{x:1337,y:635,t:1528143629896};\\\", \\\"{x:1337,y:634,t:1528143629904};\\\", \\\"{x:1336,y:634,t:1528143629921};\\\", \\\"{x:1334,y:634,t:1528143629984};\\\", \\\"{x:1333,y:634,t:1528143630016};\\\", \\\"{x:1333,y:633,t:1528143630032};\\\", \\\"{x:1331,y:633,t:1528143630039};\\\", \\\"{x:1330,y:633,t:1528143630056};\\\", \\\"{x:1328,y:633,t:1528143630072};\\\", \\\"{x:1327,y:633,t:1528143630096};\\\", \\\"{x:1325,y:633,t:1528143630104};\\\", \\\"{x:1324,y:633,t:1528143630128};\\\", \\\"{x:1323,y:633,t:1528143630139};\\\", \\\"{x:1322,y:633,t:1528143630155};\\\", \\\"{x:1320,y:633,t:1528143630351};\\\", \\\"{x:1320,y:632,t:1528143630360};\\\", \\\"{x:1319,y:631,t:1528143630376};\\\", \\\"{x:1318,y:630,t:1528143630404};\\\", \\\"{x:1317,y:630,t:1528143630421};\\\", \\\"{x:1317,y:629,t:1528143630438};\\\", \\\"{x:1316,y:628,t:1528143630472};\\\", \\\"{x:1315,y:626,t:1528143630520};\\\", \\\"{x:1314,y:624,t:1528143630539};\\\", \\\"{x:1312,y:623,t:1528143630712};\\\", \\\"{x:1311,y:624,t:1528143630722};\\\", \\\"{x:1308,y:629,t:1528143630739};\\\", \\\"{x:1306,y:633,t:1528143630756};\\\", \\\"{x:1304,y:637,t:1528143630772};\\\", \\\"{x:1303,y:640,t:1528143630789};\\\", \\\"{x:1301,y:645,t:1528143630806};\\\", \\\"{x:1300,y:648,t:1528143630821};\\\", \\\"{x:1300,y:652,t:1528143630838};\\\", \\\"{x:1300,y:655,t:1528143630855};\\\", \\\"{x:1300,y:657,t:1528143630872};\\\", \\\"{x:1299,y:663,t:1528143630888};\\\", \\\"{x:1299,y:671,t:1528143630906};\\\", \\\"{x:1299,y:678,t:1528143630922};\\\", \\\"{x:1299,y:684,t:1528143630939};\\\", \\\"{x:1299,y:688,t:1528143630956};\\\", \\\"{x:1299,y:690,t:1528143630973};\\\", \\\"{x:1299,y:691,t:1528143630988};\\\", \\\"{x:1299,y:692,t:1528143631008};\\\", \\\"{x:1300,y:694,t:1528143631023};\\\", \\\"{x:1301,y:697,t:1528143631039};\\\", \\\"{x:1302,y:701,t:1528143631056};\\\", \\\"{x:1304,y:708,t:1528143631073};\\\", \\\"{x:1304,y:712,t:1528143631089};\\\", \\\"{x:1305,y:717,t:1528143631106};\\\", \\\"{x:1306,y:719,t:1528143631123};\\\", \\\"{x:1307,y:721,t:1528143631139};\\\", \\\"{x:1308,y:725,t:1528143631156};\\\", \\\"{x:1309,y:728,t:1528143631172};\\\", \\\"{x:1309,y:730,t:1528143631189};\\\", \\\"{x:1309,y:732,t:1528143631206};\\\", \\\"{x:1310,y:733,t:1528143631223};\\\", \\\"{x:1311,y:734,t:1528143631239};\\\", \\\"{x:1311,y:735,t:1528143631256};\\\", \\\"{x:1311,y:736,t:1528143631272};\\\", \\\"{x:1311,y:737,t:1528143631289};\\\", \\\"{x:1311,y:742,t:1528143631305};\\\", \\\"{x:1311,y:747,t:1528143631322};\\\", \\\"{x:1311,y:753,t:1528143631339};\\\", \\\"{x:1311,y:758,t:1528143631356};\\\", \\\"{x:1311,y:760,t:1528143631373};\\\", \\\"{x:1311,y:763,t:1528143631389};\\\", \\\"{x:1311,y:767,t:1528143631406};\\\", \\\"{x:1311,y:771,t:1528143631423};\\\", \\\"{x:1311,y:776,t:1528143631439};\\\", \\\"{x:1311,y:782,t:1528143631456};\\\", \\\"{x:1311,y:791,t:1528143631472};\\\", \\\"{x:1311,y:798,t:1528143631490};\\\", \\\"{x:1311,y:803,t:1528143631506};\\\", \\\"{x:1311,y:806,t:1528143631523};\\\", \\\"{x:1311,y:813,t:1528143631540};\\\", \\\"{x:1311,y:820,t:1528143631556};\\\", \\\"{x:1311,y:825,t:1528143631573};\\\", \\\"{x:1311,y:832,t:1528143631590};\\\", \\\"{x:1311,y:837,t:1528143631606};\\\", \\\"{x:1311,y:843,t:1528143631622};\\\", \\\"{x:1311,y:848,t:1528143631640};\\\", \\\"{x:1311,y:854,t:1528143631656};\\\", \\\"{x:1311,y:864,t:1528143631673};\\\", \\\"{x:1311,y:870,t:1528143631690};\\\", \\\"{x:1311,y:875,t:1528143631705};\\\", \\\"{x:1311,y:885,t:1528143631723};\\\", \\\"{x:1311,y:893,t:1528143631740};\\\", \\\"{x:1311,y:900,t:1528143631756};\\\", \\\"{x:1311,y:907,t:1528143631773};\\\", \\\"{x:1312,y:914,t:1528143631790};\\\", \\\"{x:1312,y:925,t:1528143631806};\\\", \\\"{x:1312,y:939,t:1528143631823};\\\", \\\"{x:1312,y:953,t:1528143631840};\\\", \\\"{x:1312,y:960,t:1528143631856};\\\", \\\"{x:1312,y:967,t:1528143631872};\\\", \\\"{x:1311,y:973,t:1528143631890};\\\", \\\"{x:1311,y:976,t:1528143631906};\\\", \\\"{x:1310,y:980,t:1528143631923};\\\", \\\"{x:1310,y:982,t:1528143631940};\\\", \\\"{x:1309,y:984,t:1528143631957};\\\", \\\"{x:1309,y:985,t:1528143631972};\\\", \\\"{x:1309,y:987,t:1528143631990};\\\", \\\"{x:1309,y:988,t:1528143632007};\\\", \\\"{x:1309,y:990,t:1528143632023};\\\", \\\"{x:1308,y:989,t:1528143632281};\\\", \\\"{x:1308,y:984,t:1528143632290};\\\", \\\"{x:1308,y:982,t:1528143632307};\\\", \\\"{x:1308,y:980,t:1528143632323};\\\", \\\"{x:1308,y:975,t:1528143632340};\\\", \\\"{x:1306,y:971,t:1528143632357};\\\", \\\"{x:1306,y:968,t:1528143632373};\\\", \\\"{x:1305,y:967,t:1528143632416};\\\", \\\"{x:1305,y:965,t:1528143633569};\\\", \\\"{x:1301,y:943,t:1528143633577};\\\", \\\"{x:1295,y:920,t:1528143633591};\\\", \\\"{x:1290,y:884,t:1528143633608};\\\", \\\"{x:1290,y:853,t:1528143633624};\\\", \\\"{x:1288,y:825,t:1528143633641};\\\", \\\"{x:1288,y:812,t:1528143633658};\\\", \\\"{x:1287,y:794,t:1528143633674};\\\", \\\"{x:1287,y:780,t:1528143633691};\\\", \\\"{x:1287,y:769,t:1528143633708};\\\", \\\"{x:1291,y:758,t:1528143633724};\\\", \\\"{x:1294,y:746,t:1528143633741};\\\", \\\"{x:1299,y:739,t:1528143633758};\\\", \\\"{x:1303,y:735,t:1528143633774};\\\", \\\"{x:1307,y:732,t:1528143633791};\\\", \\\"{x:1312,y:728,t:1528143633807};\\\", \\\"{x:1320,y:720,t:1528143633825};\\\", \\\"{x:1324,y:717,t:1528143633842};\\\", \\\"{x:1327,y:712,t:1528143633858};\\\", \\\"{x:1329,y:705,t:1528143633875};\\\", \\\"{x:1331,y:692,t:1528143633891};\\\", \\\"{x:1331,y:682,t:1528143633908};\\\", \\\"{x:1331,y:669,t:1528143633925};\\\", \\\"{x:1331,y:649,t:1528143633941};\\\", \\\"{x:1329,y:633,t:1528143633958};\\\", \\\"{x:1329,y:619,t:1528143633975};\\\", \\\"{x:1329,y:612,t:1528143633991};\\\", \\\"{x:1331,y:606,t:1528143634008};\\\", \\\"{x:1333,y:602,t:1528143634024};\\\", \\\"{x:1333,y:600,t:1528143634041};\\\", \\\"{x:1334,y:600,t:1528143634257};\\\", \\\"{x:1334,y:601,t:1528143634321};\\\", \\\"{x:1334,y:602,t:1528143634329};\\\", \\\"{x:1334,y:604,t:1528143634341};\\\", \\\"{x:1329,y:609,t:1528143634358};\\\", \\\"{x:1327,y:612,t:1528143634375};\\\", \\\"{x:1323,y:616,t:1528143634392};\\\", \\\"{x:1322,y:619,t:1528143634407};\\\", \\\"{x:1321,y:619,t:1528143634424};\\\", \\\"{x:1320,y:620,t:1528143634448};\\\", \\\"{x:1319,y:621,t:1528143634472};\\\", \\\"{x:1318,y:622,t:1528143634496};\\\", \\\"{x:1317,y:622,t:1528143634511};\\\", \\\"{x:1317,y:623,t:1528143634961};\\\", \\\"{x:1317,y:624,t:1528143634984};\\\", \\\"{x:1317,y:625,t:1528143635001};\\\", \\\"{x:1316,y:626,t:1528143635008};\\\", \\\"{x:1315,y:628,t:1528143635025};\\\", \\\"{x:1314,y:630,t:1528143635041};\\\", \\\"{x:1313,y:630,t:1528143635058};\\\", \\\"{x:1312,y:632,t:1528143635074};\\\", \\\"{x:1310,y:636,t:1528143635473};\\\", \\\"{x:1307,y:645,t:1528143635480};\\\", \\\"{x:1307,y:649,t:1528143635492};\\\", \\\"{x:1302,y:665,t:1528143635508};\\\", \\\"{x:1296,y:687,t:1528143635525};\\\", \\\"{x:1289,y:709,t:1528143635542};\\\", \\\"{x:1282,y:730,t:1528143635558};\\\", \\\"{x:1271,y:754,t:1528143635576};\\\", \\\"{x:1264,y:771,t:1528143635593};\\\", \\\"{x:1255,y:791,t:1528143635608};\\\", \\\"{x:1243,y:807,t:1528143635626};\\\", \\\"{x:1233,y:821,t:1528143635642};\\\", \\\"{x:1227,y:830,t:1528143635659};\\\", \\\"{x:1222,y:838,t:1528143635676};\\\", \\\"{x:1219,y:842,t:1528143635693};\\\", \\\"{x:1216,y:846,t:1528143635709};\\\", \\\"{x:1215,y:849,t:1528143635726};\\\", \\\"{x:1213,y:851,t:1528143635743};\\\", \\\"{x:1213,y:852,t:1528143635759};\\\", \\\"{x:1212,y:853,t:1528143635784};\\\", \\\"{x:1213,y:847,t:1528143636049};\\\", \\\"{x:1215,y:843,t:1528143636059};\\\", \\\"{x:1219,y:834,t:1528143636076};\\\", \\\"{x:1228,y:819,t:1528143636093};\\\", \\\"{x:1235,y:807,t:1528143636110};\\\", \\\"{x:1240,y:797,t:1528143636126};\\\", \\\"{x:1246,y:785,t:1528143636143};\\\", \\\"{x:1254,y:768,t:1528143636159};\\\", \\\"{x:1261,y:752,t:1528143636175};\\\", \\\"{x:1269,y:735,t:1528143636192};\\\", \\\"{x:1275,y:725,t:1528143636210};\\\", \\\"{x:1281,y:712,t:1528143636225};\\\", \\\"{x:1290,y:698,t:1528143636242};\\\", \\\"{x:1298,y:684,t:1528143636259};\\\", \\\"{x:1306,y:672,t:1528143636275};\\\", \\\"{x:1310,y:664,t:1528143636292};\\\", \\\"{x:1314,y:658,t:1528143636309};\\\", \\\"{x:1316,y:655,t:1528143636325};\\\", \\\"{x:1320,y:650,t:1528143636343};\\\", \\\"{x:1328,y:640,t:1528143636360};\\\", \\\"{x:1330,y:637,t:1528143636376};\\\", \\\"{x:1331,y:636,t:1528143636393};\\\", \\\"{x:1331,y:635,t:1528143636409};\\\", \\\"{x:1331,y:633,t:1528143636426};\\\", \\\"{x:1331,y:631,t:1528143636443};\\\", \\\"{x:1331,y:629,t:1528143636488};\\\", \\\"{x:1329,y:628,t:1528143636497};\\\", \\\"{x:1325,y:626,t:1528143636511};\\\", \\\"{x:1312,y:623,t:1528143636526};\\\", \\\"{x:1297,y:622,t:1528143636543};\\\", \\\"{x:1277,y:639,t:1528143636560};\\\", \\\"{x:1267,y:650,t:1528143636576};\\\", \\\"{x:1258,y:663,t:1528143636593};\\\", \\\"{x:1250,y:671,t:1528143636610};\\\", \\\"{x:1242,y:685,t:1528143636627};\\\", \\\"{x:1233,y:705,t:1528143636643};\\\", \\\"{x:1225,y:722,t:1528143636660};\\\", \\\"{x:1216,y:737,t:1528143636676};\\\", \\\"{x:1206,y:755,t:1528143636693};\\\", \\\"{x:1198,y:769,t:1528143636710};\\\", \\\"{x:1190,y:787,t:1528143636727};\\\", \\\"{x:1183,y:805,t:1528143636743};\\\", \\\"{x:1171,y:838,t:1528143636760};\\\", \\\"{x:1164,y:855,t:1528143636776};\\\", \\\"{x:1157,y:870,t:1528143636793};\\\", \\\"{x:1153,y:878,t:1528143636809};\\\", \\\"{x:1149,y:883,t:1528143636827};\\\", \\\"{x:1144,y:890,t:1528143636843};\\\", \\\"{x:1141,y:896,t:1528143636860};\\\", \\\"{x:1139,y:900,t:1528143636877};\\\", \\\"{x:1139,y:905,t:1528143636893};\\\", \\\"{x:1135,y:916,t:1528143636910};\\\", \\\"{x:1132,y:936,t:1528143636927};\\\", \\\"{x:1131,y:948,t:1528143636943};\\\", \\\"{x:1130,y:970,t:1528143636960};\\\", \\\"{x:1130,y:987,t:1528143636977};\\\", \\\"{x:1130,y:1005,t:1528143636993};\\\", \\\"{x:1130,y:1026,t:1528143637010};\\\", \\\"{x:1126,y:1045,t:1528143637027};\\\", \\\"{x:1125,y:1051,t:1528143637043};\\\", \\\"{x:1128,y:1041,t:1528143637145};\\\", \\\"{x:1149,y:992,t:1528143637160};\\\", \\\"{x:1170,y:930,t:1528143637176};\\\", \\\"{x:1187,y:864,t:1528143637194};\\\", \\\"{x:1211,y:788,t:1528143637210};\\\", \\\"{x:1239,y:727,t:1528143637227};\\\", \\\"{x:1267,y:671,t:1528143637244};\\\", \\\"{x:1288,y:633,t:1528143637260};\\\", \\\"{x:1308,y:601,t:1528143637278};\\\", \\\"{x:1319,y:579,t:1528143637294};\\\", \\\"{x:1328,y:558,t:1528143637310};\\\", \\\"{x:1339,y:539,t:1528143637327};\\\", \\\"{x:1347,y:522,t:1528143637344};\\\", \\\"{x:1349,y:520,t:1528143637361};\\\", \\\"{x:1350,y:519,t:1528143637376};\\\", \\\"{x:1351,y:518,t:1528143637400};\\\", \\\"{x:1352,y:518,t:1528143637440};\\\", \\\"{x:1352,y:519,t:1528143637575};\\\", \\\"{x:1352,y:530,t:1528143637584};\\\", \\\"{x:1349,y:553,t:1528143637593};\\\", \\\"{x:1342,y:596,t:1528143637611};\\\", \\\"{x:1340,y:615,t:1528143637627};\\\", \\\"{x:1337,y:632,t:1528143637643};\\\", \\\"{x:1335,y:647,t:1528143637660};\\\", \\\"{x:1331,y:657,t:1528143637676};\\\", \\\"{x:1329,y:663,t:1528143637693};\\\", \\\"{x:1328,y:664,t:1528143637760};\\\", \\\"{x:1326,y:664,t:1528143637784};\\\", \\\"{x:1325,y:664,t:1528143637794};\\\", \\\"{x:1321,y:659,t:1528143637811};\\\", \\\"{x:1316,y:645,t:1528143637827};\\\", \\\"{x:1313,y:634,t:1528143637844};\\\", \\\"{x:1311,y:632,t:1528143637861};\\\", \\\"{x:1312,y:632,t:1528143637953};\\\", \\\"{x:1313,y:632,t:1528143637968};\\\", \\\"{x:1315,y:632,t:1528143637977};\\\", \\\"{x:1317,y:633,t:1528143637994};\\\", \\\"{x:1325,y:637,t:1528143638012};\\\", \\\"{x:1332,y:641,t:1528143638027};\\\", \\\"{x:1341,y:648,t:1528143638044};\\\", \\\"{x:1345,y:669,t:1528143638061};\\\", \\\"{x:1348,y:680,t:1528143638078};\\\", \\\"{x:1350,y:689,t:1528143638094};\\\", \\\"{x:1352,y:699,t:1528143638111};\\\", \\\"{x:1356,y:729,t:1528143638128};\\\", \\\"{x:1357,y:744,t:1528143638144};\\\", \\\"{x:1358,y:753,t:1528143638161};\\\", \\\"{x:1360,y:761,t:1528143638178};\\\", \\\"{x:1361,y:771,t:1528143638194};\\\", \\\"{x:1365,y:784,t:1528143638211};\\\", \\\"{x:1368,y:799,t:1528143638228};\\\", \\\"{x:1372,y:812,t:1528143638244};\\\", \\\"{x:1376,y:823,t:1528143638262};\\\", \\\"{x:1378,y:835,t:1528143638278};\\\", \\\"{x:1380,y:841,t:1528143638294};\\\", \\\"{x:1382,y:850,t:1528143638311};\\\", \\\"{x:1386,y:869,t:1528143638328};\\\", \\\"{x:1387,y:882,t:1528143638345};\\\", \\\"{x:1391,y:893,t:1528143638361};\\\", \\\"{x:1395,y:904,t:1528143638379};\\\", \\\"{x:1398,y:911,t:1528143638394};\\\", \\\"{x:1400,y:914,t:1528143638411};\\\", \\\"{x:1403,y:916,t:1528143638428};\\\", \\\"{x:1406,y:919,t:1528143638445};\\\", \\\"{x:1414,y:922,t:1528143638461};\\\", \\\"{x:1420,y:924,t:1528143638479};\\\", \\\"{x:1425,y:927,t:1528143638494};\\\", \\\"{x:1430,y:928,t:1528143638512};\\\", \\\"{x:1437,y:932,t:1528143638528};\\\", \\\"{x:1444,y:938,t:1528143638545};\\\", \\\"{x:1447,y:942,t:1528143638561};\\\", \\\"{x:1451,y:948,t:1528143638578};\\\", \\\"{x:1456,y:955,t:1528143638595};\\\", \\\"{x:1465,y:967,t:1528143638609};\\\", \\\"{x:1471,y:979,t:1528143638627};\\\", \\\"{x:1477,y:990,t:1528143638643};\\\", \\\"{x:1483,y:1001,t:1528143638659};\\\", \\\"{x:1485,y:1004,t:1528143638676};\\\", \\\"{x:1485,y:1006,t:1528143638692};\\\", \\\"{x:1488,y:1010,t:1528143638708};\\\", \\\"{x:1490,y:1017,t:1528143638725};\\\", \\\"{x:1491,y:1022,t:1528143638742};\\\", \\\"{x:1492,y:1026,t:1528143638759};\\\", \\\"{x:1493,y:1030,t:1528143638775};\\\", \\\"{x:1493,y:1032,t:1528143638792};\\\", \\\"{x:1493,y:1036,t:1528143638808};\\\", \\\"{x:1494,y:1039,t:1528143638825};\\\", \\\"{x:1495,y:1045,t:1528143638842};\\\", \\\"{x:1496,y:1054,t:1528143638858};\\\", \\\"{x:1497,y:1063,t:1528143638876};\\\", \\\"{x:1498,y:1070,t:1528143638892};\\\", \\\"{x:1499,y:1075,t:1528143638908};\\\", \\\"{x:1500,y:1081,t:1528143638925};\\\", \\\"{x:1500,y:1085,t:1528143638943};\\\", \\\"{x:1501,y:1092,t:1528143638959};\\\", \\\"{x:1502,y:1100,t:1528143638976};\\\", \\\"{x:1502,y:1107,t:1528143638993};\\\", \\\"{x:1503,y:1109,t:1528143639008};\\\", \\\"{x:1503,y:1111,t:1528143639026};\\\", \\\"{x:1499,y:1111,t:1528143639126};\\\", \\\"{x:1475,y:1091,t:1528143639143};\\\", \\\"{x:1441,y:1036,t:1528143639160};\\\", \\\"{x:1401,y:975,t:1528143639176};\\\", \\\"{x:1375,y:934,t:1528143639194};\\\", \\\"{x:1367,y:916,t:1528143639209};\\\", \\\"{x:1365,y:907,t:1528143639225};\\\", \\\"{x:1364,y:899,t:1528143639242};\\\", \\\"{x:1364,y:882,t:1528143639260};\\\", \\\"{x:1364,y:863,t:1528143639275};\\\", \\\"{x:1364,y:847,t:1528143639292};\\\", \\\"{x:1367,y:820,t:1528143639309};\\\", \\\"{x:1367,y:800,t:1528143639326};\\\", \\\"{x:1367,y:779,t:1528143639342};\\\", \\\"{x:1367,y:764,t:1528143639360};\\\", \\\"{x:1367,y:747,t:1528143639376};\\\", \\\"{x:1362,y:717,t:1528143639393};\\\", \\\"{x:1356,y:688,t:1528143639411};\\\", \\\"{x:1349,y:661,t:1528143639426};\\\", \\\"{x:1341,y:641,t:1528143639443};\\\", \\\"{x:1333,y:626,t:1528143639459};\\\", \\\"{x:1323,y:610,t:1528143639476};\\\", \\\"{x:1315,y:598,t:1528143639493};\\\", \\\"{x:1314,y:594,t:1528143639510};\\\", \\\"{x:1315,y:596,t:1528143639990};\\\", \\\"{x:1318,y:598,t:1528143639998};\\\", \\\"{x:1323,y:602,t:1528143640010};\\\", \\\"{x:1325,y:608,t:1528143640027};\\\", \\\"{x:1327,y:616,t:1528143640044};\\\", \\\"{x:1330,y:624,t:1528143640060};\\\", \\\"{x:1335,y:636,t:1528143640077};\\\", \\\"{x:1342,y:652,t:1528143640094};\\\", \\\"{x:1345,y:660,t:1528143640110};\\\", \\\"{x:1348,y:671,t:1528143640127};\\\", \\\"{x:1351,y:681,t:1528143640144};\\\", \\\"{x:1353,y:692,t:1528143640160};\\\", \\\"{x:1356,y:703,t:1528143640177};\\\", \\\"{x:1363,y:720,t:1528143640197};\\\", \\\"{x:1372,y:744,t:1528143640210};\\\", \\\"{x:1382,y:764,t:1528143640227};\\\", \\\"{x:1387,y:778,t:1528143640243};\\\", \\\"{x:1395,y:796,t:1528143640259};\\\", \\\"{x:1400,y:817,t:1528143640276};\\\", \\\"{x:1405,y:843,t:1528143640294};\\\", \\\"{x:1411,y:860,t:1528143640309};\\\", \\\"{x:1420,y:888,t:1528143640327};\\\", \\\"{x:1438,y:927,t:1528143640344};\\\", \\\"{x:1453,y:960,t:1528143640360};\\\", \\\"{x:1462,y:975,t:1528143640377};\\\", \\\"{x:1468,y:989,t:1528143640394};\\\", \\\"{x:1473,y:1000,t:1528143640410};\\\", \\\"{x:1477,y:1010,t:1528143640427};\\\", \\\"{x:1479,y:1015,t:1528143640444};\\\", \\\"{x:1483,y:1022,t:1528143640460};\\\", \\\"{x:1485,y:1026,t:1528143640476};\\\", \\\"{x:1487,y:1030,t:1528143640494};\\\", \\\"{x:1487,y:1031,t:1528143640510};\\\", \\\"{x:1489,y:1033,t:1528143640534};\\\", \\\"{x:1489,y:1035,t:1528143640549};\\\", \\\"{x:1490,y:1035,t:1528143640560};\\\", \\\"{x:1490,y:1036,t:1528143640577};\\\", \\\"{x:1490,y:1037,t:1528143640595};\\\", \\\"{x:1487,y:1037,t:1528143644430};\\\", \\\"{x:1428,y:1012,t:1528143644448};\\\", \\\"{x:1406,y:993,t:1528143644463};\\\", \\\"{x:1394,y:946,t:1528143644481};\\\", \\\"{x:1374,y:890,t:1528143644497};\\\", \\\"{x:1350,y:829,t:1528143644513};\\\", \\\"{x:1333,y:783,t:1528143644530};\\\", \\\"{x:1327,y:762,t:1528143644546};\\\", \\\"{x:1317,y:736,t:1528143644562};\\\", \\\"{x:1288,y:682,t:1528143644580};\\\", \\\"{x:1260,y:645,t:1528143644597};\\\", \\\"{x:1254,y:636,t:1528143644613};\\\", \\\"{x:1254,y:635,t:1528143644629};\\\", \\\"{x:1253,y:635,t:1528143644669};\\\", \\\"{x:1252,y:634,t:1528143644686};\\\", \\\"{x:1253,y:634,t:1528143644767};\\\", \\\"{x:1257,y:634,t:1528143644780};\\\", \\\"{x:1272,y:641,t:1528143644798};\\\", \\\"{x:1284,y:644,t:1528143644814};\\\", \\\"{x:1289,y:644,t:1528143644830};\\\", \\\"{x:1291,y:644,t:1528143644847};\\\", \\\"{x:1292,y:644,t:1528143644865};\\\", \\\"{x:1296,y:649,t:1528143644982};\\\", \\\"{x:1296,y:662,t:1528143644997};\\\", \\\"{x:1300,y:702,t:1528143645014};\\\", \\\"{x:1304,y:724,t:1528143645029};\\\", \\\"{x:1306,y:745,t:1528143645047};\\\", \\\"{x:1306,y:770,t:1528143645064};\\\", \\\"{x:1306,y:795,t:1528143645080};\\\", \\\"{x:1308,y:815,t:1528143645097};\\\", \\\"{x:1309,y:836,t:1528143645114};\\\", \\\"{x:1311,y:854,t:1528143645130};\\\", \\\"{x:1312,y:871,t:1528143645147};\\\", \\\"{x:1313,y:896,t:1528143645164};\\\", \\\"{x:1313,y:928,t:1528143645180};\\\", \\\"{x:1313,y:950,t:1528143645197};\\\", \\\"{x:1313,y:972,t:1528143645214};\\\", \\\"{x:1313,y:981,t:1528143645231};\\\", \\\"{x:1313,y:990,t:1528143645247};\\\", \\\"{x:1313,y:995,t:1528143645264};\\\", \\\"{x:1313,y:1001,t:1528143645281};\\\", \\\"{x:1313,y:1005,t:1528143645297};\\\", \\\"{x:1313,y:1010,t:1528143645314};\\\", \\\"{x:1313,y:1017,t:1528143645331};\\\", \\\"{x:1313,y:1021,t:1528143645347};\\\", \\\"{x:1313,y:1022,t:1528143645364};\\\", \\\"{x:1313,y:1023,t:1528143645381};\\\", \\\"{x:1314,y:1023,t:1528143645470};\\\", \\\"{x:1316,y:1020,t:1528143645481};\\\", \\\"{x:1321,y:999,t:1528143645498};\\\", \\\"{x:1328,y:975,t:1528143645514};\\\", \\\"{x:1332,y:959,t:1528143645532};\\\", \\\"{x:1334,y:943,t:1528143645548};\\\", \\\"{x:1338,y:917,t:1528143645564};\\\", \\\"{x:1338,y:886,t:1528143645582};\\\", \\\"{x:1338,y:844,t:1528143645598};\\\", \\\"{x:1338,y:774,t:1528143645614};\\\", \\\"{x:1329,y:726,t:1528143645631};\\\", \\\"{x:1323,y:673,t:1528143645648};\\\", \\\"{x:1315,y:620,t:1528143645663};\\\", \\\"{x:1314,y:582,t:1528143645681};\\\", \\\"{x:1314,y:554,t:1528143645698};\\\", \\\"{x:1314,y:523,t:1528143645713};\\\", \\\"{x:1313,y:503,t:1528143645730};\\\", \\\"{x:1312,y:493,t:1528143645748};\\\", \\\"{x:1312,y:487,t:1528143645764};\\\", \\\"{x:1312,y:484,t:1528143645780};\\\", \\\"{x:1313,y:481,t:1528143645797};\\\", \\\"{x:1313,y:480,t:1528143645821};\\\", \\\"{x:1314,y:478,t:1528143645831};\\\", \\\"{x:1314,y:476,t:1528143645848};\\\", \\\"{x:1315,y:476,t:1528143645864};\\\", \\\"{x:1315,y:474,t:1528143645881};\\\", \\\"{x:1315,y:473,t:1528143645897};\\\", \\\"{x:1315,y:474,t:1528143645966};\\\", \\\"{x:1315,y:484,t:1528143645981};\\\", \\\"{x:1313,y:508,t:1528143645997};\\\", \\\"{x:1311,y:516,t:1528143646014};\\\", \\\"{x:1311,y:521,t:1528143646032};\\\", \\\"{x:1310,y:524,t:1528143646048};\\\", \\\"{x:1310,y:528,t:1528143646065};\\\", \\\"{x:1310,y:531,t:1528143646081};\\\", \\\"{x:1308,y:535,t:1528143646098};\\\", \\\"{x:1305,y:543,t:1528143646115};\\\", \\\"{x:1302,y:549,t:1528143646131};\\\", \\\"{x:1298,y:555,t:1528143646148};\\\", \\\"{x:1289,y:565,t:1528143646165};\\\", \\\"{x:1276,y:578,t:1528143646181};\\\", \\\"{x:1248,y:598,t:1528143646198};\\\", \\\"{x:1229,y:607,t:1528143646215};\\\", \\\"{x:1205,y:616,t:1528143646230};\\\", \\\"{x:1179,y:622,t:1528143646248};\\\", \\\"{x:1160,y:625,t:1528143646265};\\\", \\\"{x:1150,y:625,t:1528143646281};\\\", \\\"{x:1148,y:625,t:1528143646299};\\\", \\\"{x:1146,y:625,t:1528143646316};\\\", \\\"{x:1139,y:624,t:1528143646331};\\\", \\\"{x:1132,y:622,t:1528143646348};\\\", \\\"{x:1119,y:619,t:1528143646366};\\\", \\\"{x:1109,y:619,t:1528143646381};\\\", \\\"{x:1075,y:619,t:1528143646399};\\\", \\\"{x:1047,y:627,t:1528143646415};\\\", \\\"{x:1017,y:633,t:1528143646431};\\\", \\\"{x:983,y:636,t:1528143646448};\\\", \\\"{x:924,y:636,t:1528143646465};\\\", \\\"{x:827,y:623,t:1528143646482};\\\", \\\"{x:714,y:613,t:1528143646498};\\\", \\\"{x:650,y:611,t:1528143646514};\\\", \\\"{x:628,y:613,t:1528143646532};\\\", \\\"{x:607,y:621,t:1528143646548};\\\", \\\"{x:575,y:635,t:1528143646566};\\\", \\\"{x:558,y:639,t:1528143646582};\\\", \\\"{x:550,y:640,t:1528143646598};\\\", \\\"{x:540,y:640,t:1528143646616};\\\", \\\"{x:530,y:640,t:1528143646631};\\\", \\\"{x:521,y:637,t:1528143646649};\\\", \\\"{x:514,y:635,t:1528143646666};\\\", \\\"{x:509,y:635,t:1528143646681};\\\", \\\"{x:503,y:635,t:1528143646698};\\\", \\\"{x:496,y:636,t:1528143646716};\\\", \\\"{x:486,y:644,t:1528143646732};\\\", \\\"{x:480,y:649,t:1528143646749};\\\", \\\"{x:480,y:651,t:1528143646773};\\\", \\\"{x:480,y:652,t:1528143646797};\\\", \\\"{x:480,y:653,t:1528143646805};\\\", \\\"{x:483,y:655,t:1528143646816};\\\", \\\"{x:487,y:656,t:1528143646833};\\\", \\\"{x:492,y:657,t:1528143646850};\\\", \\\"{x:495,y:658,t:1528143646867};\\\", \\\"{x:500,y:658,t:1528143646884};\\\", \\\"{x:509,y:658,t:1528143646899};\\\", \\\"{x:519,y:658,t:1528143646916};\\\", \\\"{x:534,y:657,t:1528143646932};\\\", \\\"{x:588,y:645,t:1528143646949};\\\", \\\"{x:644,y:635,t:1528143646965};\\\", \\\"{x:723,y:618,t:1528143646984};\\\", \\\"{x:816,y:601,t:1528143647001};\\\", \\\"{x:929,y:587,t:1528143647016};\\\", \\\"{x:1041,y:581,t:1528143647033};\\\", \\\"{x:1141,y:581,t:1528143647050};\\\", \\\"{x:1227,y:581,t:1528143647066};\\\", \\\"{x:1288,y:581,t:1528143647082};\\\", \\\"{x:1328,y:581,t:1528143647100};\\\", \\\"{x:1350,y:581,t:1528143647116};\\\", \\\"{x:1364,y:581,t:1528143647133};\\\", \\\"{x:1375,y:581,t:1528143647150};\\\", \\\"{x:1378,y:582,t:1528143647167};\\\", \\\"{x:1376,y:582,t:1528143647295};\\\", \\\"{x:1374,y:590,t:1528143647301};\\\", \\\"{x:1373,y:602,t:1528143647317};\\\", \\\"{x:1367,y:619,t:1528143647333};\\\", \\\"{x:1357,y:640,t:1528143647350};\\\", \\\"{x:1351,y:651,t:1528143647367};\\\", \\\"{x:1344,y:658,t:1528143647383};\\\", \\\"{x:1335,y:662,t:1528143647401};\\\", \\\"{x:1318,y:663,t:1528143647417};\\\", \\\"{x:1282,y:660,t:1528143647433};\\\", \\\"{x:1207,y:642,t:1528143647450};\\\", \\\"{x:1110,y:627,t:1528143647468};\\\", \\\"{x:1029,y:616,t:1528143647483};\\\", \\\"{x:963,y:607,t:1528143647501};\\\", \\\"{x:892,y:595,t:1528143647517};\\\", \\\"{x:783,y:581,t:1528143647535};\\\", \\\"{x:743,y:574,t:1528143647550};\\\", \\\"{x:727,y:572,t:1528143647567};\\\", \\\"{x:713,y:570,t:1528143647584};\\\", \\\"{x:699,y:569,t:1528143647600};\\\", \\\"{x:689,y:568,t:1528143647616};\\\", \\\"{x:684,y:568,t:1528143647632};\\\", \\\"{x:672,y:571,t:1528143647650};\\\", \\\"{x:657,y:580,t:1528143647667};\\\", \\\"{x:644,y:597,t:1528143647683};\\\", \\\"{x:639,y:614,t:1528143647700};\\\", \\\"{x:639,y:622,t:1528143647716};\\\", \\\"{x:643,y:626,t:1528143647732};\\\", \\\"{x:654,y:627,t:1528143647750};\\\", \\\"{x:682,y:617,t:1528143647767};\\\", \\\"{x:712,y:604,t:1528143647784};\\\", \\\"{x:745,y:591,t:1528143647800};\\\", \\\"{x:766,y:581,t:1528143647817};\\\", \\\"{x:777,y:576,t:1528143647833};\\\", \\\"{x:780,y:575,t:1528143647850};\\\", \\\"{x:783,y:573,t:1528143647867};\\\", \\\"{x:785,y:572,t:1528143647883};\\\", \\\"{x:786,y:572,t:1528143647901};\\\", \\\"{x:788,y:571,t:1528143647916};\\\", \\\"{x:796,y:567,t:1528143647934};\\\", \\\"{x:799,y:566,t:1528143647951};\\\", \\\"{x:800,y:565,t:1528143647982};\\\", \\\"{x:801,y:565,t:1528143647989};\\\", \\\"{x:802,y:565,t:1528143648001};\\\", \\\"{x:810,y:560,t:1528143648017};\\\", \\\"{x:816,y:557,t:1528143648035};\\\", \\\"{x:818,y:556,t:1528143648051};\\\", \\\"{x:819,y:554,t:1528143648067};\\\", \\\"{x:819,y:552,t:1528143648083};\\\", \\\"{x:819,y:551,t:1528143648100};\\\", \\\"{x:819,y:550,t:1528143648117};\\\", \\\"{x:819,y:548,t:1528143648133};\\\", \\\"{x:819,y:547,t:1528143648157};\\\", \\\"{x:820,y:547,t:1528143648173};\\\", \\\"{x:821,y:545,t:1528143648184};\\\", \\\"{x:822,y:545,t:1528143648214};\\\", \\\"{x:823,y:544,t:1528143648237};\\\", \\\"{x:824,y:544,t:1528143648255};\\\", \\\"{x:825,y:544,t:1528143648267};\\\", \\\"{x:828,y:543,t:1528143648284};\\\", \\\"{x:830,y:542,t:1528143648301};\\\", \\\"{x:830,y:541,t:1528143648469};\\\", \\\"{x:826,y:540,t:1528143648484};\\\", \\\"{x:818,y:538,t:1528143648501};\\\", \\\"{x:811,y:537,t:1528143648516};\\\", \\\"{x:779,y:560,t:1528143648534};\\\", \\\"{x:756,y:580,t:1528143648551};\\\", \\\"{x:731,y:594,t:1528143648568};\\\", \\\"{x:715,y:603,t:1528143648585};\\\", \\\"{x:710,y:605,t:1528143648600};\\\", \\\"{x:706,y:609,t:1528143648618};\\\", \\\"{x:700,y:615,t:1528143648634};\\\", \\\"{x:690,y:625,t:1528143648651};\\\", \\\"{x:683,y:630,t:1528143648668};\\\", \\\"{x:677,y:635,t:1528143648684};\\\", \\\"{x:667,y:643,t:1528143648701};\\\", \\\"{x:658,y:651,t:1528143648717};\\\", \\\"{x:646,y:659,t:1528143648734};\\\", \\\"{x:640,y:662,t:1528143648750};\\\", \\\"{x:628,y:667,t:1528143648767};\\\", \\\"{x:617,y:673,t:1528143648784};\\\", \\\"{x:609,y:677,t:1528143648801};\\\", \\\"{x:603,y:682,t:1528143648817};\\\", \\\"{x:594,y:691,t:1528143648834};\\\", \\\"{x:585,y:702,t:1528143648851};\\\", \\\"{x:571,y:716,t:1528143648867};\\\", \\\"{x:562,y:723,t:1528143648885};\\\", \\\"{x:556,y:727,t:1528143648900};\\\", \\\"{x:551,y:731,t:1528143648918};\\\", \\\"{x:551,y:732,t:1528143648934};\\\", \\\"{x:550,y:732,t:1528143648951};\\\", \\\"{x:549,y:734,t:1528143648974};\\\", \\\"{x:548,y:734,t:1528143648998};\\\", \\\"{x:547,y:735,t:1528143649005};\\\", \\\"{x:546,y:735,t:1528143649030};\\\", \\\"{x:545,y:736,t:1528143649037};\\\", \\\"{x:544,y:736,t:1528143649990};\\\", \\\"{x:545,y:732,t:1528143650134};\\\", \\\"{x:547,y:726,t:1528143650152};\\\", \\\"{x:548,y:724,t:1528143650169};\\\", \\\"{x:549,y:723,t:1528143650206};\\\", \\\"{x:549,y:722,t:1528143650218};\\\", \\\"{x:552,y:716,t:1528143650235};\\\", \\\"{x:554,y:710,t:1528143650251};\\\", \\\"{x:561,y:691,t:1528143650269};\\\", \\\"{x:568,y:668,t:1528143650285};\\\", \\\"{x:574,y:648,t:1528143650302};\\\", \\\"{x:579,y:633,t:1528143650327};\\\", \\\"{x:580,y:630,t:1528143650339};\\\", \\\"{x:582,y:627,t:1528143650352};\\\", \\\"{x:584,y:623,t:1528143650369};\\\", \\\"{x:585,y:619,t:1528143650385};\\\", \\\"{x:586,y:617,t:1528143650402};\\\", \\\"{x:586,y:616,t:1528143650419};\\\", \\\"{x:587,y:613,t:1528143650436};\\\", \\\"{x:587,y:612,t:1528143650453};\\\", \\\"{x:587,y:611,t:1528143650485};\\\", \\\"{x:587,y:610,t:1528143650502};\\\", \\\"{x:588,y:609,t:1528143650518};\\\", \\\"{x:588,y:608,t:1528143650606};\\\" ] }, { \\\"rt\\\": 12217, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 683857, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:588,y:607,t:1528143650870};\\\", \\\"{x:589,y:607,t:1528143652621};\\\", \\\"{x:635,y:592,t:1528143652638};\\\", \\\"{x:667,y:581,t:1528143652653};\\\", \\\"{x:704,y:581,t:1528143652671};\\\", \\\"{x:799,y:582,t:1528143652687};\\\", \\\"{x:871,y:582,t:1528143652703};\\\", \\\"{x:952,y:582,t:1528143652722};\\\", \\\"{x:1057,y:582,t:1528143652737};\\\", \\\"{x:1132,y:582,t:1528143652753};\\\", \\\"{x:1193,y:582,t:1528143652771};\\\", \\\"{x:1257,y:582,t:1528143652787};\\\", \\\"{x:1312,y:578,t:1528143652804};\\\", \\\"{x:1374,y:567,t:1528143652821};\\\", \\\"{x:1388,y:562,t:1528143652837};\\\", \\\"{x:1390,y:561,t:1528143652855};\\\", \\\"{x:1390,y:560,t:1528143652871};\\\", \\\"{x:1388,y:557,t:1528143652934};\\\", \\\"{x:1378,y:554,t:1528143652942};\\\", \\\"{x:1369,y:546,t:1528143652954};\\\", \\\"{x:1340,y:534,t:1528143652971};\\\", \\\"{x:1319,y:525,t:1528143652989};\\\", \\\"{x:1298,y:516,t:1528143653004};\\\", \\\"{x:1261,y:504,t:1528143653022};\\\", \\\"{x:1234,y:509,t:1528143653038};\\\", \\\"{x:1210,y:517,t:1528143653055};\\\", \\\"{x:1185,y:522,t:1528143653071};\\\", \\\"{x:1164,y:527,t:1528143653088};\\\", \\\"{x:1157,y:530,t:1528143653106};\\\", \\\"{x:1152,y:537,t:1528143653122};\\\", \\\"{x:1143,y:557,t:1528143653139};\\\", \\\"{x:1138,y:576,t:1528143653156};\\\", \\\"{x:1134,y:589,t:1528143653171};\\\", \\\"{x:1131,y:596,t:1528143653188};\\\", \\\"{x:1128,y:600,t:1528143653205};\\\", \\\"{x:1127,y:600,t:1528143653221};\\\", \\\"{x:1127,y:601,t:1528143653239};\\\", \\\"{x:1127,y:600,t:1528143653526};\\\", \\\"{x:1130,y:597,t:1528143653539};\\\", \\\"{x:1144,y:592,t:1528143653556};\\\", \\\"{x:1167,y:586,t:1528143653573};\\\", \\\"{x:1190,y:583,t:1528143653588};\\\", \\\"{x:1238,y:578,t:1528143653606};\\\", \\\"{x:1264,y:574,t:1528143653622};\\\", \\\"{x:1282,y:571,t:1528143653640};\\\", \\\"{x:1294,y:569,t:1528143653656};\\\", \\\"{x:1295,y:568,t:1528143653672};\\\", \\\"{x:1296,y:568,t:1528143653773};\\\", \\\"{x:1297,y:568,t:1528143653789};\\\", \\\"{x:1299,y:567,t:1528143653805};\\\", \\\"{x:1302,y:566,t:1528143653822};\\\", \\\"{x:1314,y:565,t:1528143653838};\\\", \\\"{x:1330,y:562,t:1528143653854};\\\", \\\"{x:1347,y:560,t:1528143653872};\\\", \\\"{x:1364,y:557,t:1528143653889};\\\", \\\"{x:1382,y:555,t:1528143653906};\\\", \\\"{x:1395,y:554,t:1528143653922};\\\", \\\"{x:1408,y:551,t:1528143653939};\\\", \\\"{x:1426,y:549,t:1528143653956};\\\", \\\"{x:1445,y:545,t:1528143653972};\\\", \\\"{x:1458,y:544,t:1528143653989};\\\", \\\"{x:1458,y:543,t:1528143654021};\\\", \\\"{x:1449,y:537,t:1528143654039};\\\", \\\"{x:1428,y:528,t:1528143654056};\\\", \\\"{x:1409,y:521,t:1528143654071};\\\", \\\"{x:1391,y:526,t:1528143654089};\\\", \\\"{x:1287,y:544,t:1528143654106};\\\", \\\"{x:1132,y:551,t:1528143654122};\\\", \\\"{x:1007,y:550,t:1528143654139};\\\", \\\"{x:926,y:550,t:1528143654157};\\\", \\\"{x:882,y:540,t:1528143654173};\\\", \\\"{x:880,y:540,t:1528143654213};\\\", \\\"{x:876,y:540,t:1528143654222};\\\", \\\"{x:875,y:541,t:1528143654238};\\\", \\\"{x:872,y:542,t:1528143654255};\\\", \\\"{x:866,y:542,t:1528143654273};\\\", \\\"{x:856,y:541,t:1528143654289};\\\", \\\"{x:853,y:540,t:1528143654305};\\\", \\\"{x:852,y:539,t:1528143654325};\\\", \\\"{x:850,y:536,t:1528143654397};\\\", \\\"{x:848,y:535,t:1528143654405};\\\", \\\"{x:837,y:528,t:1528143654422};\\\", \\\"{x:818,y:520,t:1528143654440};\\\", \\\"{x:807,y:516,t:1528143654455};\\\", \\\"{x:804,y:516,t:1528143654471};\\\", \\\"{x:802,y:516,t:1528143654501};\\\", \\\"{x:800,y:516,t:1528143654509};\\\", \\\"{x:793,y:516,t:1528143654521};\\\", \\\"{x:785,y:516,t:1528143654539};\\\", \\\"{x:779,y:515,t:1528143654555};\\\", \\\"{x:769,y:512,t:1528143654572};\\\", \\\"{x:750,y:507,t:1528143654589};\\\", \\\"{x:730,y:504,t:1528143654604};\\\", \\\"{x:710,y:500,t:1528143654622};\\\", \\\"{x:691,y:500,t:1528143654639};\\\", \\\"{x:672,y:500,t:1528143654655};\\\", \\\"{x:659,y:500,t:1528143654672};\\\", \\\"{x:654,y:500,t:1528143654689};\\\", \\\"{x:651,y:500,t:1528143654706};\\\", \\\"{x:649,y:501,t:1528143654722};\\\", \\\"{x:645,y:501,t:1528143654739};\\\", \\\"{x:639,y:501,t:1528143654756};\\\", \\\"{x:633,y:501,t:1528143654772};\\\", \\\"{x:630,y:502,t:1528143654789};\\\", \\\"{x:630,y:503,t:1528143654805};\\\", \\\"{x:629,y:503,t:1528143654822};\\\", \\\"{x:627,y:503,t:1528143654853};\\\", \\\"{x:623,y:505,t:1528143654861};\\\", \\\"{x:618,y:506,t:1528143654872};\\\", \\\"{x:615,y:507,t:1528143654888};\\\", \\\"{x:610,y:508,t:1528143654906};\\\", \\\"{x:607,y:508,t:1528143654921};\\\", \\\"{x:605,y:508,t:1528143654939};\\\", \\\"{x:603,y:508,t:1528143654956};\\\", \\\"{x:602,y:508,t:1528143654972};\\\", \\\"{x:597,y:506,t:1528143654989};\\\", \\\"{x:596,y:505,t:1528143655006};\\\", \\\"{x:595,y:505,t:1528143655022};\\\", \\\"{x:596,y:505,t:1528143655182};\\\", \\\"{x:601,y:507,t:1528143655190};\\\", \\\"{x:616,y:515,t:1528143655206};\\\", \\\"{x:632,y:522,t:1528143655223};\\\", \\\"{x:645,y:527,t:1528143655239};\\\", \\\"{x:656,y:532,t:1528143655256};\\\", \\\"{x:667,y:536,t:1528143655273};\\\", \\\"{x:673,y:538,t:1528143655289};\\\", \\\"{x:682,y:541,t:1528143655305};\\\", \\\"{x:691,y:542,t:1528143655322};\\\", \\\"{x:698,y:542,t:1528143655339};\\\", \\\"{x:704,y:542,t:1528143655356};\\\", \\\"{x:710,y:542,t:1528143655373};\\\", \\\"{x:713,y:542,t:1528143655389};\\\", \\\"{x:715,y:542,t:1528143655406};\\\", \\\"{x:716,y:542,t:1528143655423};\\\", \\\"{x:717,y:542,t:1528143655440};\\\", \\\"{x:717,y:541,t:1528143655456};\\\", \\\"{x:711,y:530,t:1528143655474};\\\", \\\"{x:693,y:520,t:1528143655491};\\\", \\\"{x:673,y:507,t:1528143655506};\\\", \\\"{x:650,y:493,t:1528143655522};\\\", \\\"{x:628,y:484,t:1528143655539};\\\", \\\"{x:620,y:481,t:1528143655556};\\\", \\\"{x:620,y:480,t:1528143655573};\\\", \\\"{x:619,y:481,t:1528143655669};\\\", \\\"{x:618,y:485,t:1528143655677};\\\", \\\"{x:617,y:489,t:1528143655691};\\\", \\\"{x:616,y:491,t:1528143655708};\\\", \\\"{x:616,y:492,t:1528143655749};\\\", \\\"{x:615,y:493,t:1528143655774};\\\", \\\"{x:615,y:494,t:1528143655789};\\\", \\\"{x:614,y:495,t:1528143655806};\\\", \\\"{x:620,y:499,t:1528143655990};\\\", \\\"{x:636,y:505,t:1528143656006};\\\", \\\"{x:658,y:515,t:1528143656023};\\\", \\\"{x:695,y:529,t:1528143656041};\\\", \\\"{x:744,y:540,t:1528143656058};\\\", \\\"{x:767,y:546,t:1528143656073};\\\", \\\"{x:775,y:548,t:1528143656089};\\\", \\\"{x:780,y:548,t:1528143656107};\\\", \\\"{x:783,y:548,t:1528143656123};\\\", \\\"{x:786,y:548,t:1528143656140};\\\", \\\"{x:788,y:548,t:1528143656156};\\\", \\\"{x:789,y:548,t:1528143656309};\\\", \\\"{x:791,y:547,t:1528143656323};\\\", \\\"{x:800,y:543,t:1528143656339};\\\", \\\"{x:807,y:540,t:1528143656357};\\\", \\\"{x:809,y:539,t:1528143656373};\\\", \\\"{x:815,y:537,t:1528143656390};\\\", \\\"{x:821,y:534,t:1528143656407};\\\", \\\"{x:827,y:531,t:1528143656423};\\\", \\\"{x:834,y:529,t:1528143656440};\\\", \\\"{x:838,y:527,t:1528143656458};\\\", \\\"{x:840,y:526,t:1528143656474};\\\", \\\"{x:839,y:526,t:1528143656694};\\\", \\\"{x:838,y:528,t:1528143656991};\\\", \\\"{x:835,y:530,t:1528143657007};\\\", \\\"{x:834,y:531,t:1528143658551};\\\", \\\"{x:834,y:532,t:1528143659998};\\\", \\\"{x:830,y:536,t:1528143660009};\\\", \\\"{x:824,y:541,t:1528143660027};\\\", \\\"{x:817,y:550,t:1528143660045};\\\", \\\"{x:810,y:560,t:1528143660061};\\\", \\\"{x:806,y:566,t:1528143660077};\\\", \\\"{x:798,y:576,t:1528143660093};\\\", \\\"{x:785,y:587,t:1528143660109};\\\", \\\"{x:768,y:598,t:1528143660127};\\\", \\\"{x:743,y:610,t:1528143660142};\\\", \\\"{x:722,y:619,t:1528143660161};\\\", \\\"{x:705,y:627,t:1528143660177};\\\", \\\"{x:693,y:634,t:1528143660194};\\\", \\\"{x:679,y:640,t:1528143660210};\\\", \\\"{x:666,y:646,t:1528143660226};\\\", \\\"{x:649,y:653,t:1528143660243};\\\", \\\"{x:637,y:660,t:1528143660260};\\\", \\\"{x:627,y:668,t:1528143660276};\\\", \\\"{x:605,y:685,t:1528143660293};\\\", \\\"{x:598,y:690,t:1528143660311};\\\", \\\"{x:596,y:693,t:1528143660327};\\\", \\\"{x:593,y:695,t:1528143660343};\\\", \\\"{x:590,y:698,t:1528143660360};\\\", \\\"{x:583,y:705,t:1528143660377};\\\", \\\"{x:577,y:710,t:1528143660393};\\\", \\\"{x:572,y:713,t:1528143660411};\\\", \\\"{x:569,y:715,t:1528143660427};\\\", \\\"{x:566,y:716,t:1528143660443};\\\", \\\"{x:560,y:716,t:1528143660460};\\\", \\\"{x:558,y:716,t:1528143660477};\\\", \\\"{x:557,y:716,t:1528143660493};\\\", \\\"{x:557,y:717,t:1528143660517};\\\", \\\"{x:556,y:717,t:1528143660550};\\\", \\\"{x:554,y:718,t:1528143660566};\\\", \\\"{x:554,y:719,t:1528143660578};\\\", \\\"{x:553,y:719,t:1528143660593};\\\", \\\"{x:550,y:720,t:1528143660612};\\\", \\\"{x:550,y:722,t:1528143660627};\\\", \\\"{x:549,y:722,t:1528143660643};\\\", \\\"{x:549,y:724,t:1528143660660};\\\", \\\"{x:547,y:725,t:1528143660677};\\\", \\\"{x:546,y:725,t:1528143660694};\\\", \\\"{x:545,y:726,t:1528143660711};\\\", \\\"{x:545,y:727,t:1528143661518};\\\", \\\"{x:544,y:728,t:1528143661614};\\\", \\\"{x:543,y:729,t:1528143661646};\\\", \\\"{x:542,y:729,t:1528143661661};\\\", \\\"{x:541,y:729,t:1528143661678};\\\", \\\"{x:539,y:730,t:1528143661695};\\\", \\\"{x:538,y:730,t:1528143661711};\\\", \\\"{x:538,y:731,t:1528143661729};\\\", \\\"{x:537,y:731,t:1528143661749};\\\", \\\"{x:536,y:731,t:1528143661782};\\\", \\\"{x:535,y:731,t:1528143662694};\\\", \\\"{x:535,y:732,t:1528143662766};\\\", \\\"{x:534,y:733,t:1528143662780};\\\", \\\"{x:533,y:733,t:1528143662796};\\\", \\\"{x:533,y:734,t:1528143662821};\\\", \\\"{x:532,y:734,t:1528143662830};\\\", \\\"{x:531,y:734,t:1528143662870};\\\" ] }, { \\\"rt\\\": 52845, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 737943, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-06 PM-F -C -O -X -12 PM-X -01 PM-12 PM-11 AM-10 AM-09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:734,t:1528143679998};\\\", \\\"{x:594,y:734,t:1528143680010};\\\", \\\"{x:676,y:740,t:1528143680024};\\\", \\\"{x:765,y:753,t:1528143680041};\\\", \\\"{x:862,y:765,t:1528143680059};\\\", \\\"{x:975,y:789,t:1528143680075};\\\", \\\"{x:1157,y:822,t:1528143680092};\\\", \\\"{x:1287,y:859,t:1528143680108};\\\", \\\"{x:1428,y:900,t:1528143680125};\\\", \\\"{x:1550,y:933,t:1528143680143};\\\", \\\"{x:1654,y:960,t:1528143680159};\\\", \\\"{x:1721,y:977,t:1528143680176};\\\", \\\"{x:1746,y:983,t:1528143680193};\\\", \\\"{x:1759,y:984,t:1528143680209};\\\", \\\"{x:1762,y:985,t:1528143680227};\\\", \\\"{x:1766,y:985,t:1528143680243};\\\", \\\"{x:1766,y:986,t:1528143680260};\\\", \\\"{x:1767,y:981,t:1528143680326};\\\", \\\"{x:1753,y:950,t:1528143680344};\\\", \\\"{x:1715,y:906,t:1528143680360};\\\", \\\"{x:1648,y:855,t:1528143680376};\\\", \\\"{x:1587,y:818,t:1528143680393};\\\", \\\"{x:1517,y:781,t:1528143680410};\\\", \\\"{x:1456,y:755,t:1528143680427};\\\", \\\"{x:1398,y:731,t:1528143680443};\\\", \\\"{x:1340,y:705,t:1528143680460};\\\", \\\"{x:1273,y:684,t:1528143680476};\\\", \\\"{x:1157,y:653,t:1528143680494};\\\", \\\"{x:1087,y:642,t:1528143680511};\\\", \\\"{x:1009,y:631,t:1528143680527};\\\", \\\"{x:912,y:616,t:1528143680546};\\\", \\\"{x:823,y:603,t:1528143680560};\\\", \\\"{x:762,y:596,t:1528143680576};\\\", \\\"{x:708,y:592,t:1528143680594};\\\", \\\"{x:673,y:592,t:1528143680610};\\\", \\\"{x:650,y:592,t:1528143680626};\\\", \\\"{x:635,y:592,t:1528143680643};\\\", \\\"{x:622,y:594,t:1528143680660};\\\", \\\"{x:618,y:596,t:1528143680676};\\\", \\\"{x:617,y:596,t:1528143680693};\\\", \\\"{x:616,y:597,t:1528143680710};\\\", \\\"{x:615,y:597,t:1528143680726};\\\", \\\"{x:614,y:597,t:1528143680918};\\\", \\\"{x:615,y:598,t:1528143681094};\\\", \\\"{x:635,y:599,t:1528143681110};\\\", \\\"{x:666,y:604,t:1528143681129};\\\", \\\"{x:722,y:611,t:1528143681143};\\\", \\\"{x:808,y:611,t:1528143681160};\\\", \\\"{x:888,y:611,t:1528143681176};\\\", \\\"{x:974,y:611,t:1528143681193};\\\", \\\"{x:1082,y:624,t:1528143681209};\\\", \\\"{x:1203,y:636,t:1528143681227};\\\", \\\"{x:1317,y:654,t:1528143681244};\\\", \\\"{x:1414,y:666,t:1528143681260};\\\", \\\"{x:1529,y:682,t:1528143681276};\\\", \\\"{x:1577,y:690,t:1528143681294};\\\", \\\"{x:1599,y:691,t:1528143681310};\\\", \\\"{x:1602,y:691,t:1528143681327};\\\", \\\"{x:1599,y:691,t:1528143681389};\\\", \\\"{x:1589,y:691,t:1528143681397};\\\", \\\"{x:1578,y:690,t:1528143681410};\\\", \\\"{x:1548,y:690,t:1528143681428};\\\", \\\"{x:1509,y:690,t:1528143681444};\\\", \\\"{x:1464,y:690,t:1528143681460};\\\", \\\"{x:1394,y:690,t:1528143681477};\\\", \\\"{x:1338,y:690,t:1528143681494};\\\", \\\"{x:1285,y:690,t:1528143681511};\\\", \\\"{x:1221,y:690,t:1528143681527};\\\", \\\"{x:1168,y:690,t:1528143681545};\\\", \\\"{x:1099,y:690,t:1528143681560};\\\", \\\"{x:1035,y:697,t:1528143681578};\\\", \\\"{x:991,y:701,t:1528143681594};\\\", \\\"{x:958,y:708,t:1528143681610};\\\", \\\"{x:944,y:712,t:1528143681627};\\\", \\\"{x:938,y:714,t:1528143681645};\\\", \\\"{x:936,y:716,t:1528143681660};\\\", \\\"{x:935,y:717,t:1528143681677};\\\", \\\"{x:936,y:717,t:1528143681726};\\\", \\\"{x:943,y:717,t:1528143681733};\\\", \\\"{x:953,y:716,t:1528143681744};\\\", \\\"{x:987,y:715,t:1528143681762};\\\", \\\"{x:1034,y:715,t:1528143681778};\\\", \\\"{x:1090,y:715,t:1528143681795};\\\", \\\"{x:1153,y:712,t:1528143681811};\\\", \\\"{x:1214,y:712,t:1528143681827};\\\", \\\"{x:1278,y:712,t:1528143681844};\\\", \\\"{x:1343,y:712,t:1528143681861};\\\", \\\"{x:1379,y:712,t:1528143681877};\\\", \\\"{x:1417,y:714,t:1528143681895};\\\", \\\"{x:1457,y:726,t:1528143681911};\\\", \\\"{x:1479,y:732,t:1528143681927};\\\", \\\"{x:1488,y:736,t:1528143681944};\\\", \\\"{x:1492,y:736,t:1528143681961};\\\", \\\"{x:1493,y:737,t:1528143681998};\\\", \\\"{x:1492,y:737,t:1528143682011};\\\", \\\"{x:1489,y:737,t:1528143682029};\\\", \\\"{x:1483,y:736,t:1528143682045};\\\", \\\"{x:1471,y:732,t:1528143682061};\\\", \\\"{x:1453,y:730,t:1528143682079};\\\", \\\"{x:1427,y:726,t:1528143682094};\\\", \\\"{x:1406,y:721,t:1528143682112};\\\", \\\"{x:1386,y:714,t:1528143682128};\\\", \\\"{x:1361,y:708,t:1528143682144};\\\", \\\"{x:1335,y:700,t:1528143682161};\\\", \\\"{x:1318,y:696,t:1528143682178};\\\", \\\"{x:1310,y:692,t:1528143682195};\\\", \\\"{x:1308,y:691,t:1528143682212};\\\", \\\"{x:1309,y:690,t:1528143682702};\\\", \\\"{x:1311,y:688,t:1528143682712};\\\", \\\"{x:1315,y:687,t:1528143682729};\\\", \\\"{x:1317,y:685,t:1528143682745};\\\", \\\"{x:1320,y:684,t:1528143682762};\\\", \\\"{x:1323,y:682,t:1528143682778};\\\", \\\"{x:1325,y:681,t:1528143682795};\\\", \\\"{x:1327,y:681,t:1528143682811};\\\", \\\"{x:1329,y:679,t:1528143682829};\\\", \\\"{x:1331,y:678,t:1528143682845};\\\", \\\"{x:1332,y:677,t:1528143682869};\\\", \\\"{x:1333,y:677,t:1528143682950};\\\", \\\"{x:1334,y:677,t:1528143682965};\\\", \\\"{x:1335,y:677,t:1528143682982};\\\", \\\"{x:1336,y:677,t:1528143682995};\\\", \\\"{x:1337,y:677,t:1528143683013};\\\", \\\"{x:1338,y:678,t:1528143683029};\\\", \\\"{x:1339,y:684,t:1528143683045};\\\", \\\"{x:1339,y:687,t:1528143683063};\\\", \\\"{x:1339,y:688,t:1528143683079};\\\", \\\"{x:1339,y:689,t:1528143683095};\\\", \\\"{x:1339,y:691,t:1528143683113};\\\", \\\"{x:1339,y:692,t:1528143683128};\\\", \\\"{x:1339,y:690,t:1528143683630};\\\", \\\"{x:1340,y:688,t:1528143683646};\\\", \\\"{x:1341,y:687,t:1528143683669};\\\", \\\"{x:1341,y:686,t:1528143683709};\\\", \\\"{x:1343,y:684,t:1528143684325};\\\", \\\"{x:1347,y:682,t:1528143684332};\\\", \\\"{x:1349,y:681,t:1528143684348};\\\", \\\"{x:1351,y:680,t:1528143684363};\\\", \\\"{x:1354,y:679,t:1528143684379};\\\", \\\"{x:1355,y:678,t:1528143684396};\\\", \\\"{x:1356,y:677,t:1528143684413};\\\", \\\"{x:1357,y:677,t:1528143684470};\\\", \\\"{x:1350,y:673,t:1528143686623};\\\", \\\"{x:1339,y:667,t:1528143686632};\\\", \\\"{x:1322,y:660,t:1528143686648};\\\", \\\"{x:1318,y:657,t:1528143686666};\\\", \\\"{x:1316,y:656,t:1528143686682};\\\", \\\"{x:1315,y:656,t:1528143686698};\\\", \\\"{x:1315,y:655,t:1528143686869};\\\", \\\"{x:1321,y:654,t:1528143686882};\\\", \\\"{x:1333,y:650,t:1528143686899};\\\", \\\"{x:1340,y:649,t:1528143686916};\\\", \\\"{x:1350,y:648,t:1528143686932};\\\", \\\"{x:1363,y:647,t:1528143686949};\\\", \\\"{x:1380,y:642,t:1528143686965};\\\", \\\"{x:1401,y:639,t:1528143686983};\\\", \\\"{x:1420,y:635,t:1528143686999};\\\", \\\"{x:1429,y:634,t:1528143687016};\\\", \\\"{x:1430,y:633,t:1528143687032};\\\", \\\"{x:1431,y:633,t:1528143687049};\\\", \\\"{x:1432,y:632,t:1528143687065};\\\", \\\"{x:1433,y:632,t:1528143687083};\\\", \\\"{x:1435,y:631,t:1528143687453};\\\", \\\"{x:1436,y:631,t:1528143687465};\\\", \\\"{x:1439,y:631,t:1528143687483};\\\", \\\"{x:1441,y:631,t:1528143687500};\\\", \\\"{x:1442,y:631,t:1528143687519};\\\", \\\"{x:1443,y:630,t:1528143687532};\\\", \\\"{x:1444,y:630,t:1528143692469};\\\", \\\"{x:1430,y:654,t:1528143692488};\\\", \\\"{x:1423,y:671,t:1528143692504};\\\", \\\"{x:1418,y:687,t:1528143692520};\\\", \\\"{x:1410,y:703,t:1528143692537};\\\", \\\"{x:1404,y:716,t:1528143692554};\\\", \\\"{x:1402,y:722,t:1528143692571};\\\", \\\"{x:1401,y:727,t:1528143692588};\\\", \\\"{x:1400,y:733,t:1528143692604};\\\", \\\"{x:1398,y:749,t:1528143692620};\\\", \\\"{x:1398,y:762,t:1528143692636};\\\", \\\"{x:1398,y:774,t:1528143692653};\\\", \\\"{x:1398,y:784,t:1528143692670};\\\", \\\"{x:1401,y:797,t:1528143692686};\\\", \\\"{x:1409,y:813,t:1528143692703};\\\", \\\"{x:1419,y:831,t:1528143692720};\\\", \\\"{x:1445,y:852,t:1528143692736};\\\", \\\"{x:1559,y:883,t:1528143692753};\\\", \\\"{x:1672,y:916,t:1528143692770};\\\", \\\"{x:1720,y:929,t:1528143692787};\\\", \\\"{x:1739,y:930,t:1528143692803};\\\", \\\"{x:1769,y:928,t:1528143692820};\\\", \\\"{x:1780,y:925,t:1528143692836};\\\", \\\"{x:1791,y:917,t:1528143692854};\\\", \\\"{x:1791,y:915,t:1528143692871};\\\", \\\"{x:1793,y:912,t:1528143692886};\\\", \\\"{x:1793,y:910,t:1528143692904};\\\", \\\"{x:1793,y:907,t:1528143692920};\\\", \\\"{x:1789,y:902,t:1528143692937};\\\", \\\"{x:1778,y:895,t:1528143692954};\\\", \\\"{x:1762,y:886,t:1528143692970};\\\", \\\"{x:1735,y:878,t:1528143692988};\\\", \\\"{x:1708,y:876,t:1528143693003};\\\", \\\"{x:1632,y:876,t:1528143693020};\\\", \\\"{x:1590,y:876,t:1528143693037};\\\", \\\"{x:1575,y:875,t:1528143693053};\\\", \\\"{x:1566,y:873,t:1528143693071};\\\", \\\"{x:1563,y:873,t:1528143693087};\\\", \\\"{x:1562,y:872,t:1528143693141};\\\", \\\"{x:1562,y:865,t:1528143693230};\\\", \\\"{x:1562,y:857,t:1528143693237};\\\", \\\"{x:1562,y:852,t:1528143693254};\\\", \\\"{x:1559,y:847,t:1528143693271};\\\", \\\"{x:1558,y:841,t:1528143693288};\\\", \\\"{x:1551,y:834,t:1528143693304};\\\", \\\"{x:1542,y:825,t:1528143693321};\\\", \\\"{x:1535,y:819,t:1528143693338};\\\", \\\"{x:1529,y:815,t:1528143693354};\\\", \\\"{x:1528,y:815,t:1528143693371};\\\", \\\"{x:1526,y:813,t:1528143693388};\\\", \\\"{x:1524,y:811,t:1528143693405};\\\", \\\"{x:1524,y:810,t:1528143693421};\\\", \\\"{x:1524,y:809,t:1528143693445};\\\", \\\"{x:1524,y:808,t:1528143693455};\\\", \\\"{x:1524,y:807,t:1528143693471};\\\", \\\"{x:1524,y:806,t:1528143693488};\\\", \\\"{x:1524,y:805,t:1528143693519};\\\", \\\"{x:1524,y:804,t:1528143693549};\\\", \\\"{x:1524,y:802,t:1528143693565};\\\", \\\"{x:1524,y:801,t:1528143693573};\\\", \\\"{x:1524,y:800,t:1528143693588};\\\", \\\"{x:1524,y:798,t:1528143693605};\\\", \\\"{x:1524,y:797,t:1528143693621};\\\", \\\"{x:1525,y:794,t:1528143693638};\\\", \\\"{x:1525,y:792,t:1528143693655};\\\", \\\"{x:1525,y:790,t:1528143693670};\\\", \\\"{x:1526,y:788,t:1528143693688};\\\", \\\"{x:1526,y:787,t:1528143693719};\\\", \\\"{x:1526,y:785,t:1528143693726};\\\", \\\"{x:1526,y:784,t:1528143693741};\\\", \\\"{x:1526,y:783,t:1528143693754};\\\", \\\"{x:1526,y:782,t:1528143693771};\\\", \\\"{x:1527,y:782,t:1528143693789};\\\", \\\"{x:1527,y:781,t:1528143693805};\\\", \\\"{x:1527,y:780,t:1528143693821};\\\", \\\"{x:1527,y:779,t:1528143693894};\\\", \\\"{x:1527,y:777,t:1528143693925};\\\", \\\"{x:1527,y:775,t:1528143693938};\\\", \\\"{x:1527,y:773,t:1528143693955};\\\", \\\"{x:1527,y:772,t:1528143693972};\\\", \\\"{x:1527,y:770,t:1528143693988};\\\", \\\"{x:1527,y:769,t:1528143694046};\\\", \\\"{x:1526,y:769,t:1528143694055};\\\", \\\"{x:1526,y:768,t:1528143694072};\\\", \\\"{x:1525,y:767,t:1528143694088};\\\", \\\"{x:1523,y:765,t:1528143694105};\\\", \\\"{x:1519,y:763,t:1528143694122};\\\", \\\"{x:1513,y:759,t:1528143694137};\\\", \\\"{x:1511,y:759,t:1528143694155};\\\", \\\"{x:1511,y:758,t:1528143694172};\\\", \\\"{x:1510,y:758,t:1528143694269};\\\", \\\"{x:1508,y:760,t:1528143694277};\\\", \\\"{x:1507,y:760,t:1528143694289};\\\", \\\"{x:1506,y:763,t:1528143694305};\\\", \\\"{x:1504,y:767,t:1528143694322};\\\", \\\"{x:1502,y:772,t:1528143694338};\\\", \\\"{x:1500,y:777,t:1528143694355};\\\", \\\"{x:1495,y:786,t:1528143694371};\\\", \\\"{x:1484,y:815,t:1528143694388};\\\", \\\"{x:1473,y:839,t:1528143694405};\\\", \\\"{x:1456,y:864,t:1528143694422};\\\", \\\"{x:1442,y:882,t:1528143694438};\\\", \\\"{x:1431,y:894,t:1528143694454};\\\", \\\"{x:1428,y:897,t:1528143694471};\\\", \\\"{x:1428,y:898,t:1528143694488};\\\", \\\"{x:1427,y:899,t:1528143694504};\\\", \\\"{x:1428,y:897,t:1528143694628};\\\", \\\"{x:1433,y:888,t:1528143694638};\\\", \\\"{x:1446,y:871,t:1528143694655};\\\", \\\"{x:1459,y:854,t:1528143694671};\\\", \\\"{x:1472,y:835,t:1528143694689};\\\", \\\"{x:1486,y:818,t:1528143694705};\\\", \\\"{x:1493,y:808,t:1528143694721};\\\", \\\"{x:1502,y:798,t:1528143694739};\\\", \\\"{x:1511,y:788,t:1528143694755};\\\", \\\"{x:1517,y:780,t:1528143694771};\\\", \\\"{x:1525,y:768,t:1528143694789};\\\", \\\"{x:1526,y:764,t:1528143694805};\\\", \\\"{x:1528,y:762,t:1528143694822};\\\", \\\"{x:1528,y:761,t:1528143694845};\\\", \\\"{x:1528,y:760,t:1528143694902};\\\", \\\"{x:1527,y:759,t:1528143695102};\\\", \\\"{x:1521,y:765,t:1528143695109};\\\", \\\"{x:1513,y:772,t:1528143695123};\\\", \\\"{x:1498,y:785,t:1528143695139};\\\", \\\"{x:1480,y:800,t:1528143695156};\\\", \\\"{x:1450,y:824,t:1528143695173};\\\", \\\"{x:1426,y:846,t:1528143695189};\\\", \\\"{x:1396,y:882,t:1528143695206};\\\", \\\"{x:1352,y:929,t:1528143695223};\\\", \\\"{x:1302,y:985,t:1528143695239};\\\", \\\"{x:1263,y:1023,t:1528143695256};\\\", \\\"{x:1235,y:1046,t:1528143695272};\\\", \\\"{x:1222,y:1058,t:1528143695289};\\\", \\\"{x:1214,y:1065,t:1528143695306};\\\", \\\"{x:1208,y:1070,t:1528143695323};\\\", \\\"{x:1205,y:1072,t:1528143695338};\\\", \\\"{x:1207,y:1071,t:1528143695429};\\\", \\\"{x:1209,y:1069,t:1528143695439};\\\", \\\"{x:1223,y:1054,t:1528143695456};\\\", \\\"{x:1246,y:1034,t:1528143695474};\\\", \\\"{x:1288,y:1005,t:1528143695490};\\\", \\\"{x:1331,y:973,t:1528143695506};\\\", \\\"{x:1385,y:933,t:1528143695524};\\\", \\\"{x:1434,y:892,t:1528143695540};\\\", \\\"{x:1495,y:839,t:1528143695557};\\\", \\\"{x:1560,y:782,t:1528143695573};\\\", \\\"{x:1575,y:765,t:1528143695590};\\\", \\\"{x:1588,y:751,t:1528143695606};\\\", \\\"{x:1597,y:740,t:1528143695623};\\\", \\\"{x:1602,y:735,t:1528143695640};\\\", \\\"{x:1603,y:734,t:1528143695656};\\\", \\\"{x:1603,y:733,t:1528143695677};\\\", \\\"{x:1594,y:743,t:1528143695829};\\\", \\\"{x:1588,y:753,t:1528143695840};\\\", \\\"{x:1576,y:771,t:1528143695857};\\\", \\\"{x:1564,y:787,t:1528143695873};\\\", \\\"{x:1552,y:804,t:1528143695890};\\\", \\\"{x:1538,y:823,t:1528143695907};\\\", \\\"{x:1526,y:843,t:1528143695923};\\\", \\\"{x:1515,y:867,t:1528143695940};\\\", \\\"{x:1493,y:915,t:1528143695957};\\\", \\\"{x:1481,y:936,t:1528143695973};\\\", \\\"{x:1469,y:955,t:1528143695990};\\\", \\\"{x:1460,y:969,t:1528143696007};\\\", \\\"{x:1456,y:974,t:1528143696023};\\\", \\\"{x:1454,y:974,t:1528143696040};\\\", \\\"{x:1454,y:969,t:1528143696381};\\\", \\\"{x:1450,y:955,t:1528143696390};\\\", \\\"{x:1450,y:936,t:1528143696407};\\\", \\\"{x:1450,y:910,t:1528143696424};\\\", \\\"{x:1450,y:888,t:1528143696440};\\\", \\\"{x:1450,y:878,t:1528143696457};\\\", \\\"{x:1458,y:865,t:1528143696474};\\\", \\\"{x:1471,y:854,t:1528143696490};\\\", \\\"{x:1483,y:844,t:1528143696507};\\\", \\\"{x:1493,y:838,t:1528143696524};\\\", \\\"{x:1503,y:831,t:1528143696540};\\\", \\\"{x:1509,y:828,t:1528143696557};\\\", \\\"{x:1512,y:825,t:1528143696574};\\\", \\\"{x:1514,y:823,t:1528143696590};\\\", \\\"{x:1516,y:822,t:1528143696607};\\\", \\\"{x:1519,y:821,t:1528143696624};\\\", \\\"{x:1521,y:820,t:1528143696642};\\\", \\\"{x:1523,y:818,t:1528143696657};\\\", \\\"{x:1523,y:817,t:1528143696674};\\\", \\\"{x:1524,y:816,t:1528143696691};\\\", \\\"{x:1527,y:812,t:1528143696708};\\\", \\\"{x:1528,y:809,t:1528143696724};\\\", \\\"{x:1530,y:804,t:1528143696741};\\\", \\\"{x:1531,y:801,t:1528143696757};\\\", \\\"{x:1532,y:796,t:1528143696774};\\\", \\\"{x:1533,y:795,t:1528143696791};\\\", \\\"{x:1533,y:790,t:1528143696806};\\\", \\\"{x:1533,y:788,t:1528143696824};\\\", \\\"{x:1533,y:786,t:1528143696841};\\\", \\\"{x:1533,y:785,t:1528143696857};\\\", \\\"{x:1533,y:784,t:1528143696874};\\\", \\\"{x:1533,y:783,t:1528143696891};\\\", \\\"{x:1533,y:782,t:1528143696924};\\\", \\\"{x:1530,y:785,t:1528143697021};\\\", \\\"{x:1528,y:790,t:1528143697029};\\\", \\\"{x:1524,y:795,t:1528143697041};\\\", \\\"{x:1516,y:804,t:1528143697057};\\\", \\\"{x:1507,y:812,t:1528143697074};\\\", \\\"{x:1496,y:822,t:1528143697091};\\\", \\\"{x:1482,y:832,t:1528143697108};\\\", \\\"{x:1475,y:838,t:1528143697124};\\\", \\\"{x:1468,y:845,t:1528143697141};\\\", \\\"{x:1464,y:848,t:1528143697158};\\\", \\\"{x:1463,y:849,t:1528143697174};\\\", \\\"{x:1459,y:853,t:1528143697191};\\\", \\\"{x:1456,y:859,t:1528143697208};\\\", \\\"{x:1452,y:865,t:1528143697224};\\\", \\\"{x:1448,y:870,t:1528143697241};\\\", \\\"{x:1447,y:872,t:1528143697258};\\\", \\\"{x:1445,y:876,t:1528143697274};\\\", \\\"{x:1442,y:884,t:1528143697291};\\\", \\\"{x:1439,y:892,t:1528143697309};\\\", \\\"{x:1435,y:904,t:1528143697324};\\\", \\\"{x:1430,y:921,t:1528143697341};\\\", \\\"{x:1426,y:933,t:1528143697358};\\\", \\\"{x:1421,y:942,t:1528143697374};\\\", \\\"{x:1417,y:949,t:1528143697392};\\\", \\\"{x:1416,y:951,t:1528143697408};\\\", \\\"{x:1421,y:944,t:1528143697606};\\\", \\\"{x:1430,y:927,t:1528143697613};\\\", \\\"{x:1443,y:905,t:1528143697625};\\\", \\\"{x:1456,y:887,t:1528143697641};\\\", \\\"{x:1465,y:875,t:1528143697658};\\\", \\\"{x:1471,y:865,t:1528143697674};\\\", \\\"{x:1474,y:862,t:1528143697690};\\\", \\\"{x:1476,y:858,t:1528143697708};\\\", \\\"{x:1478,y:855,t:1528143697725};\\\", \\\"{x:1478,y:854,t:1528143697741};\\\", \\\"{x:1478,y:853,t:1528143697758};\\\", \\\"{x:1478,y:854,t:1528143697853};\\\", \\\"{x:1475,y:864,t:1528143697862};\\\", \\\"{x:1469,y:876,t:1528143697875};\\\", \\\"{x:1459,y:892,t:1528143697893};\\\", \\\"{x:1449,y:908,t:1528143697908};\\\", \\\"{x:1436,y:927,t:1528143697925};\\\", \\\"{x:1424,y:941,t:1528143697941};\\\", \\\"{x:1413,y:952,t:1528143697958};\\\", \\\"{x:1404,y:961,t:1528143697975};\\\", \\\"{x:1395,y:967,t:1528143697993};\\\", \\\"{x:1388,y:973,t:1528143698008};\\\", \\\"{x:1386,y:975,t:1528143698025};\\\", \\\"{x:1385,y:976,t:1528143698042};\\\", \\\"{x:1384,y:977,t:1528143698061};\\\", \\\"{x:1383,y:977,t:1528143698149};\\\", \\\"{x:1383,y:978,t:1528143698158};\\\", \\\"{x:1382,y:979,t:1528143698175};\\\", \\\"{x:1382,y:980,t:1528143698192};\\\", \\\"{x:1381,y:980,t:1528143698208};\\\", \\\"{x:1384,y:980,t:1528143698357};\\\", \\\"{x:1386,y:977,t:1528143698365};\\\", \\\"{x:1389,y:971,t:1528143698376};\\\", \\\"{x:1397,y:963,t:1528143698392};\\\", \\\"{x:1411,y:950,t:1528143698410};\\\", \\\"{x:1430,y:936,t:1528143698425};\\\", \\\"{x:1449,y:921,t:1528143698442};\\\", \\\"{x:1464,y:910,t:1528143698459};\\\", \\\"{x:1479,y:899,t:1528143698475};\\\", \\\"{x:1495,y:883,t:1528143698492};\\\", \\\"{x:1511,y:866,t:1528143698509};\\\", \\\"{x:1517,y:855,t:1528143698525};\\\", \\\"{x:1522,y:844,t:1528143698542};\\\", \\\"{x:1525,y:837,t:1528143698559};\\\", \\\"{x:1525,y:836,t:1528143698575};\\\", \\\"{x:1523,y:836,t:1528143698627};\\\", \\\"{x:1517,y:836,t:1528143698640};\\\", \\\"{x:1499,y:847,t:1528143698657};\\\", \\\"{x:1475,y:876,t:1528143698674};\\\", \\\"{x:1454,y:905,t:1528143698690};\\\", \\\"{x:1429,y:942,t:1528143698707};\\\", \\\"{x:1412,y:961,t:1528143698724};\\\", \\\"{x:1397,y:977,t:1528143698740};\\\", \\\"{x:1389,y:982,t:1528143698757};\\\", \\\"{x:1380,y:989,t:1528143698774};\\\", \\\"{x:1374,y:991,t:1528143698790};\\\", \\\"{x:1365,y:994,t:1528143698807};\\\", \\\"{x:1361,y:994,t:1528143698823};\\\", \\\"{x:1358,y:994,t:1528143698840};\\\", \\\"{x:1348,y:989,t:1528143698856};\\\", \\\"{x:1335,y:979,t:1528143698874};\\\", \\\"{x:1328,y:974,t:1528143698890};\\\", \\\"{x:1322,y:970,t:1528143698907};\\\", \\\"{x:1321,y:969,t:1528143698924};\\\", \\\"{x:1320,y:969,t:1528143698940};\\\", \\\"{x:1314,y:969,t:1528143698957};\\\", \\\"{x:1299,y:969,t:1528143698974};\\\", \\\"{x:1279,y:970,t:1528143698989};\\\", \\\"{x:1255,y:973,t:1528143699007};\\\", \\\"{x:1225,y:974,t:1528143699024};\\\", \\\"{x:1199,y:974,t:1528143699040};\\\", \\\"{x:1176,y:974,t:1528143699058};\\\", \\\"{x:1161,y:974,t:1528143699074};\\\", \\\"{x:1146,y:974,t:1528143699090};\\\", \\\"{x:1140,y:974,t:1528143699107};\\\", \\\"{x:1143,y:968,t:1528143699186};\\\", \\\"{x:1150,y:958,t:1528143699194};\\\", \\\"{x:1156,y:949,t:1528143699206};\\\", \\\"{x:1175,y:929,t:1528143699223};\\\", \\\"{x:1198,y:902,t:1528143699240};\\\", \\\"{x:1220,y:876,t:1528143699256};\\\", \\\"{x:1239,y:854,t:1528143699273};\\\", \\\"{x:1263,y:827,t:1528143699290};\\\", \\\"{x:1276,y:812,t:1528143699307};\\\", \\\"{x:1290,y:797,t:1528143699323};\\\", \\\"{x:1301,y:784,t:1528143699341};\\\", \\\"{x:1306,y:778,t:1528143699357};\\\", \\\"{x:1306,y:777,t:1528143699373};\\\", \\\"{x:1304,y:776,t:1528143699451};\\\", \\\"{x:1296,y:781,t:1528143699459};\\\", \\\"{x:1282,y:791,t:1528143699474};\\\", \\\"{x:1241,y:839,t:1528143699491};\\\", \\\"{x:1216,y:869,t:1528143699508};\\\", \\\"{x:1196,y:889,t:1528143699524};\\\", \\\"{x:1174,y:907,t:1528143699540};\\\", \\\"{x:1155,y:918,t:1528143699557};\\\", \\\"{x:1147,y:922,t:1528143699573};\\\", \\\"{x:1144,y:922,t:1528143699590};\\\", \\\"{x:1143,y:922,t:1528143699650};\\\", \\\"{x:1143,y:915,t:1528143699698};\\\", \\\"{x:1145,y:904,t:1528143699708};\\\", \\\"{x:1155,y:886,t:1528143699723};\\\", \\\"{x:1161,y:874,t:1528143699740};\\\", \\\"{x:1173,y:856,t:1528143699758};\\\", \\\"{x:1184,y:841,t:1528143699774};\\\", \\\"{x:1191,y:830,t:1528143699791};\\\", \\\"{x:1199,y:817,t:1528143699808};\\\", \\\"{x:1211,y:798,t:1528143699824};\\\", \\\"{x:1226,y:776,t:1528143699840};\\\", \\\"{x:1237,y:758,t:1528143699858};\\\", \\\"{x:1248,y:740,t:1528143699875};\\\", \\\"{x:1254,y:735,t:1528143699890};\\\", \\\"{x:1255,y:732,t:1528143699908};\\\", \\\"{x:1256,y:731,t:1528143699925};\\\", \\\"{x:1256,y:729,t:1528143699954};\\\", \\\"{x:1252,y:727,t:1528143699962};\\\", \\\"{x:1248,y:725,t:1528143699975};\\\", \\\"{x:1237,y:721,t:1528143699990};\\\", \\\"{x:1222,y:713,t:1528143700008};\\\", \\\"{x:1206,y:706,t:1528143700025};\\\", \\\"{x:1198,y:703,t:1528143700041};\\\", \\\"{x:1196,y:701,t:1528143700058};\\\", \\\"{x:1194,y:701,t:1528143700074};\\\", \\\"{x:1192,y:699,t:1528143700091};\\\", \\\"{x:1189,y:696,t:1528143700109};\\\", \\\"{x:1185,y:689,t:1528143700126};\\\", \\\"{x:1185,y:686,t:1528143700141};\\\", \\\"{x:1183,y:682,t:1528143700158};\\\", \\\"{x:1182,y:679,t:1528143700175};\\\", \\\"{x:1182,y:677,t:1528143700191};\\\", \\\"{x:1182,y:675,t:1528143700208};\\\", \\\"{x:1182,y:674,t:1528143700225};\\\", \\\"{x:1182,y:673,t:1528143700241};\\\", \\\"{x:1182,y:671,t:1528143700258};\\\", \\\"{x:1190,y:661,t:1528143700275};\\\", \\\"{x:1198,y:656,t:1528143700292};\\\", \\\"{x:1202,y:653,t:1528143700308};\\\", \\\"{x:1210,y:648,t:1528143700324};\\\", \\\"{x:1218,y:643,t:1528143700341};\\\", \\\"{x:1229,y:638,t:1528143700358};\\\", \\\"{x:1242,y:633,t:1528143700374};\\\", \\\"{x:1260,y:630,t:1528143700391};\\\", \\\"{x:1276,y:625,t:1528143700407};\\\", \\\"{x:1290,y:621,t:1528143700424};\\\", \\\"{x:1307,y:617,t:1528143700441};\\\", \\\"{x:1320,y:613,t:1528143700457};\\\", \\\"{x:1335,y:611,t:1528143700475};\\\", \\\"{x:1342,y:610,t:1528143700491};\\\", \\\"{x:1351,y:608,t:1528143700507};\\\", \\\"{x:1361,y:608,t:1528143700524};\\\", \\\"{x:1371,y:608,t:1528143700541};\\\", \\\"{x:1380,y:608,t:1528143700558};\\\", \\\"{x:1387,y:608,t:1528143700574};\\\", \\\"{x:1392,y:608,t:1528143700592};\\\", \\\"{x:1399,y:608,t:1528143700608};\\\", \\\"{x:1402,y:608,t:1528143700625};\\\", \\\"{x:1405,y:608,t:1528143700642};\\\", \\\"{x:1410,y:608,t:1528143700658};\\\", \\\"{x:1416,y:608,t:1528143700675};\\\", \\\"{x:1426,y:608,t:1528143700691};\\\", \\\"{x:1439,y:608,t:1528143700708};\\\", \\\"{x:1454,y:608,t:1528143700724};\\\", \\\"{x:1465,y:608,t:1528143700741};\\\", \\\"{x:1477,y:608,t:1528143700758};\\\", \\\"{x:1482,y:608,t:1528143700775};\\\", \\\"{x:1488,y:608,t:1528143700791};\\\", \\\"{x:1492,y:608,t:1528143700809};\\\", \\\"{x:1494,y:608,t:1528143700824};\\\", \\\"{x:1495,y:608,t:1528143700841};\\\", \\\"{x:1496,y:608,t:1528143700947};\\\", \\\"{x:1497,y:608,t:1528143700963};\\\", \\\"{x:1498,y:608,t:1528143700975};\\\", \\\"{x:1503,y:608,t:1528143700992};\\\", \\\"{x:1509,y:609,t:1528143701009};\\\", \\\"{x:1519,y:610,t:1528143701025};\\\", \\\"{x:1531,y:613,t:1528143701042};\\\", \\\"{x:1538,y:613,t:1528143701059};\\\", \\\"{x:1540,y:613,t:1528143701075};\\\", \\\"{x:1541,y:613,t:1528143701092};\\\", \\\"{x:1543,y:613,t:1528143701323};\\\", \\\"{x:1544,y:614,t:1528143701346};\\\", \\\"{x:1548,y:614,t:1528143701363};\\\", \\\"{x:1550,y:614,t:1528143701376};\\\", \\\"{x:1553,y:616,t:1528143701392};\\\", \\\"{x:1558,y:616,t:1528143701409};\\\", \\\"{x:1567,y:617,t:1528143701426};\\\", \\\"{x:1575,y:618,t:1528143701443};\\\", \\\"{x:1589,y:621,t:1528143701459};\\\", \\\"{x:1597,y:622,t:1528143701476};\\\", \\\"{x:1601,y:623,t:1528143701492};\\\", \\\"{x:1605,y:623,t:1528143701508};\\\", \\\"{x:1608,y:623,t:1528143701526};\\\", \\\"{x:1609,y:624,t:1528143701542};\\\", \\\"{x:1611,y:624,t:1528143701559};\\\", \\\"{x:1613,y:624,t:1528143701576};\\\", \\\"{x:1614,y:624,t:1528143701593};\\\", \\\"{x:1615,y:624,t:1528143701611};\\\", \\\"{x:1616,y:624,t:1528143701626};\\\", \\\"{x:1617,y:625,t:1528143701643};\\\", \\\"{x:1619,y:625,t:1528143701659};\\\", \\\"{x:1621,y:626,t:1528143701676};\\\", \\\"{x:1625,y:628,t:1528143701693};\\\", \\\"{x:1628,y:629,t:1528143701709};\\\", \\\"{x:1633,y:631,t:1528143701726};\\\", \\\"{x:1637,y:632,t:1528143701743};\\\", \\\"{x:1639,y:632,t:1528143701759};\\\", \\\"{x:1642,y:633,t:1528143701776};\\\", \\\"{x:1645,y:634,t:1528143701793};\\\", \\\"{x:1646,y:634,t:1528143701808};\\\", \\\"{x:1648,y:635,t:1528143701826};\\\", \\\"{x:1650,y:635,t:1528143701843};\\\", \\\"{x:1652,y:635,t:1528143701859};\\\", \\\"{x:1654,y:636,t:1528143701907};\\\", \\\"{x:1655,y:636,t:1528143701922};\\\", \\\"{x:1658,y:636,t:1528143701931};\\\", \\\"{x:1659,y:636,t:1528143701943};\\\", \\\"{x:1661,y:636,t:1528143701960};\\\", \\\"{x:1662,y:638,t:1528143701976};\\\", \\\"{x:1665,y:638,t:1528143701993};\\\", \\\"{x:1668,y:639,t:1528143702010};\\\", \\\"{x:1675,y:641,t:1528143702026};\\\", \\\"{x:1681,y:643,t:1528143702042};\\\", \\\"{x:1683,y:644,t:1528143702060};\\\", \\\"{x:1688,y:645,t:1528143702076};\\\", \\\"{x:1695,y:647,t:1528143702093};\\\", \\\"{x:1703,y:649,t:1528143702110};\\\", \\\"{x:1712,y:652,t:1528143702126};\\\", \\\"{x:1717,y:654,t:1528143702143};\\\", \\\"{x:1721,y:656,t:1528143702160};\\\", \\\"{x:1729,y:662,t:1528143702176};\\\", \\\"{x:1738,y:670,t:1528143702193};\\\", \\\"{x:1745,y:677,t:1528143702210};\\\", \\\"{x:1753,y:685,t:1528143702226};\\\", \\\"{x:1754,y:694,t:1528143702243};\\\", \\\"{x:1754,y:711,t:1528143702260};\\\", \\\"{x:1750,y:732,t:1528143702276};\\\", \\\"{x:1733,y:762,t:1528143702293};\\\", \\\"{x:1698,y:812,t:1528143702310};\\\", \\\"{x:1651,y:861,t:1528143702327};\\\", \\\"{x:1604,y:892,t:1528143702343};\\\", \\\"{x:1550,y:901,t:1528143702360};\\\", \\\"{x:1477,y:904,t:1528143702377};\\\", \\\"{x:1368,y:901,t:1528143702393};\\\", \\\"{x:1230,y:867,t:1528143702410};\\\", \\\"{x:988,y:805,t:1528143702426};\\\", \\\"{x:864,y:775,t:1528143702443};\\\", \\\"{x:771,y:754,t:1528143702460};\\\", \\\"{x:750,y:744,t:1528143702477};\\\", \\\"{x:744,y:742,t:1528143702492};\\\", \\\"{x:741,y:741,t:1528143702510};\\\", \\\"{x:739,y:739,t:1528143702563};\\\", \\\"{x:738,y:739,t:1528143702577};\\\", \\\"{x:724,y:727,t:1528143702593};\\\", \\\"{x:700,y:713,t:1528143702610};\\\", \\\"{x:690,y:707,t:1528143702627};\\\", \\\"{x:686,y:703,t:1528143702643};\\\", \\\"{x:672,y:694,t:1528143702659};\\\", \\\"{x:650,y:685,t:1528143702678};\\\", \\\"{x:633,y:678,t:1528143702694};\\\", \\\"{x:624,y:676,t:1528143702710};\\\", \\\"{x:615,y:673,t:1528143702726};\\\", \\\"{x:612,y:672,t:1528143702744};\\\", \\\"{x:609,y:670,t:1528143702760};\\\", \\\"{x:608,y:670,t:1528143702777};\\\", \\\"{x:606,y:669,t:1528143702793};\\\", \\\"{x:603,y:667,t:1528143702810};\\\", \\\"{x:597,y:659,t:1528143702826};\\\", \\\"{x:597,y:655,t:1528143702844};\\\", \\\"{x:597,y:653,t:1528143702860};\\\", \\\"{x:598,y:648,t:1528143702876};\\\", \\\"{x:603,y:640,t:1528143702894};\\\", \\\"{x:608,y:633,t:1528143702910};\\\", \\\"{x:616,y:626,t:1528143702928};\\\", \\\"{x:623,y:620,t:1528143702944};\\\", \\\"{x:637,y:610,t:1528143702959};\\\", \\\"{x:646,y:601,t:1528143702973};\\\", \\\"{x:656,y:592,t:1528143702990};\\\", \\\"{x:661,y:587,t:1528143703007};\\\", \\\"{x:665,y:581,t:1528143703025};\\\", \\\"{x:666,y:579,t:1528143703042};\\\", \\\"{x:667,y:577,t:1528143703058};\\\", \\\"{x:667,y:573,t:1528143703075};\\\", \\\"{x:660,y:568,t:1528143703092};\\\", \\\"{x:648,y:563,t:1528143703108};\\\", \\\"{x:634,y:559,t:1528143703126};\\\", \\\"{x:627,y:557,t:1528143703143};\\\", \\\"{x:621,y:555,t:1528143703159};\\\", \\\"{x:616,y:555,t:1528143703175};\\\", \\\"{x:612,y:555,t:1528143703193};\\\", \\\"{x:611,y:557,t:1528143703213};\\\", \\\"{x:611,y:558,t:1528143703234};\\\", \\\"{x:611,y:560,t:1528143703241};\\\", \\\"{x:611,y:561,t:1528143703259};\\\", \\\"{x:613,y:565,t:1528143703276};\\\", \\\"{x:615,y:565,t:1528143703292};\\\", \\\"{x:616,y:566,t:1528143703308};\\\", \\\"{x:616,y:567,t:1528143703338};\\\", \\\"{x:616,y:568,t:1528143703378};\\\", \\\"{x:616,y:570,t:1528143703426};\\\", \\\"{x:615,y:570,t:1528143703442};\\\", \\\"{x:615,y:571,t:1528143703459};\\\", \\\"{x:620,y:572,t:1528143703610};\\\", \\\"{x:642,y:572,t:1528143703626};\\\", \\\"{x:669,y:572,t:1528143703642};\\\", \\\"{x:694,y:568,t:1528143703659};\\\", \\\"{x:710,y:562,t:1528143703676};\\\", \\\"{x:719,y:560,t:1528143703692};\\\", \\\"{x:729,y:556,t:1528143703709};\\\", \\\"{x:740,y:551,t:1528143703726};\\\", \\\"{x:748,y:547,t:1528143703742};\\\", \\\"{x:756,y:544,t:1528143703759};\\\", \\\"{x:761,y:542,t:1528143703775};\\\", \\\"{x:765,y:540,t:1528143703793};\\\", \\\"{x:766,y:540,t:1528143703810};\\\", \\\"{x:768,y:539,t:1528143703825};\\\", \\\"{x:770,y:539,t:1528143703842};\\\", \\\"{x:775,y:539,t:1528143703860};\\\", \\\"{x:778,y:540,t:1528143703876};\\\", \\\"{x:779,y:541,t:1528143703893};\\\", \\\"{x:780,y:542,t:1528143703909};\\\", \\\"{x:783,y:544,t:1528143703939};\\\", \\\"{x:784,y:544,t:1528143703963};\\\", \\\"{x:785,y:545,t:1528143703978};\\\", \\\"{x:786,y:546,t:1528143703994};\\\", \\\"{x:788,y:547,t:1528143704010};\\\", \\\"{x:789,y:547,t:1528143704027};\\\", \\\"{x:791,y:548,t:1528143704043};\\\", \\\"{x:794,y:550,t:1528143704059};\\\", \\\"{x:795,y:550,t:1528143704077};\\\", \\\"{x:797,y:551,t:1528143704093};\\\", \\\"{x:798,y:551,t:1528143704110};\\\", \\\"{x:802,y:554,t:1528143704127};\\\", \\\"{x:807,y:555,t:1528143704143};\\\", \\\"{x:812,y:559,t:1528143704161};\\\", \\\"{x:816,y:561,t:1528143704176};\\\", \\\"{x:818,y:562,t:1528143704192};\\\", \\\"{x:818,y:563,t:1528143704210};\\\", \\\"{x:819,y:563,t:1528143704226};\\\", \\\"{x:821,y:563,t:1528143704242};\\\", \\\"{x:823,y:565,t:1528143704259};\\\", \\\"{x:825,y:566,t:1528143704282};\\\", \\\"{x:826,y:567,t:1528143704306};\\\", \\\"{x:827,y:568,t:1528143704330};\\\", \\\"{x:828,y:569,t:1528143704343};\\\", \\\"{x:830,y:570,t:1528143704360};\\\", \\\"{x:830,y:571,t:1528143704377};\\\", \\\"{x:832,y:572,t:1528143704394};\\\", \\\"{x:832,y:573,t:1528143704409};\\\", \\\"{x:832,y:574,t:1528143704427};\\\", \\\"{x:832,y:575,t:1528143704873};\\\", \\\"{x:831,y:577,t:1528143705067};\\\", \\\"{x:828,y:582,t:1528143705076};\\\", \\\"{x:826,y:585,t:1528143705093};\\\", \\\"{x:824,y:588,t:1528143705111};\\\", \\\"{x:824,y:589,t:1528143705127};\\\", \\\"{x:823,y:590,t:1528143705144};\\\", \\\"{x:820,y:594,t:1528143705677};\\\", \\\"{x:810,y:606,t:1528143705695};\\\", \\\"{x:806,y:609,t:1528143705710};\\\", \\\"{x:800,y:617,t:1528143705727};\\\", \\\"{x:795,y:623,t:1528143705745};\\\", \\\"{x:787,y:631,t:1528143705761};\\\", \\\"{x:776,y:646,t:1528143705778};\\\", \\\"{x:766,y:656,t:1528143705794};\\\", \\\"{x:752,y:669,t:1528143705810};\\\", \\\"{x:734,y:682,t:1528143705828};\\\", \\\"{x:718,y:691,t:1528143705845};\\\", \\\"{x:710,y:696,t:1528143705860};\\\", \\\"{x:707,y:699,t:1528143705878};\\\", \\\"{x:702,y:703,t:1528143705894};\\\", \\\"{x:701,y:705,t:1528143705911};\\\", \\\"{x:700,y:706,t:1528143705928};\\\", \\\"{x:702,y:706,t:1528143706034};\\\", \\\"{x:706,y:706,t:1528143706045};\\\", \\\"{x:718,y:708,t:1528143706061};\\\", \\\"{x:738,y:710,t:1528143706078};\\\", \\\"{x:764,y:714,t:1528143706095};\\\", \\\"{x:791,y:714,t:1528143706111};\\\", \\\"{x:816,y:714,t:1528143706128};\\\", \\\"{x:832,y:714,t:1528143706145};\\\", \\\"{x:850,y:713,t:1528143706162};\\\", \\\"{x:851,y:713,t:1528143706178};\\\", \\\"{x:851,y:711,t:1528143715043};\\\", \\\"{x:844,y:708,t:1528143715051};\\\", \\\"{x:829,y:701,t:1528143715068};\\\", \\\"{x:816,y:696,t:1528143715084};\\\", \\\"{x:810,y:693,t:1528143715102};\\\", \\\"{x:807,y:692,t:1528143715118};\\\", \\\"{x:799,y:691,t:1528143715135};\\\", \\\"{x:790,y:689,t:1528143715152};\\\", \\\"{x:786,y:687,t:1528143715168};\\\", \\\"{x:784,y:687,t:1528143715185};\\\", \\\"{x:783,y:687,t:1528143715316};\\\", \\\"{x:781,y:687,t:1528143715322};\\\", \\\"{x:779,y:687,t:1528143715335};\\\", \\\"{x:774,y:687,t:1528143715351};\\\", \\\"{x:769,y:687,t:1528143715368};\\\", \\\"{x:763,y:689,t:1528143715385};\\\", \\\"{x:759,y:691,t:1528143715401};\\\", \\\"{x:750,y:694,t:1528143715418};\\\", \\\"{x:748,y:695,t:1528143715435};\\\", \\\"{x:746,y:696,t:1528143715451};\\\", \\\"{x:745,y:696,t:1528143715497};\\\", \\\"{x:744,y:696,t:1528143715538};\\\", \\\"{x:743,y:696,t:1528143715619};\\\", \\\"{x:742,y:696,t:1528143715642};\\\", \\\"{x:740,y:696,t:1528143715652};\\\", \\\"{x:734,y:701,t:1528143715669};\\\", \\\"{x:729,y:706,t:1528143715686};\\\", \\\"{x:722,y:713,t:1528143715702};\\\", \\\"{x:716,y:717,t:1528143715719};\\\", \\\"{x:709,y:722,t:1528143715735};\\\", \\\"{x:705,y:726,t:1528143715752};\\\", \\\"{x:700,y:730,t:1528143715768};\\\", \\\"{x:696,y:734,t:1528143715785};\\\", \\\"{x:688,y:743,t:1528143715802};\\\", \\\"{x:685,y:748,t:1528143715818};\\\", \\\"{x:684,y:753,t:1528143715835};\\\", \\\"{x:683,y:756,t:1528143715852};\\\", \\\"{x:683,y:757,t:1528143715868};\\\", \\\"{x:682,y:759,t:1528143715885};\\\", \\\"{x:681,y:763,t:1528143715902};\\\", \\\"{x:679,y:768,t:1528143715918};\\\", \\\"{x:679,y:770,t:1528143715935};\\\", \\\"{x:679,y:772,t:1528143715952};\\\", \\\"{x:678,y:773,t:1528143715968};\\\", \\\"{x:677,y:775,t:1528143715986};\\\", \\\"{x:676,y:776,t:1528143716002};\\\", \\\"{x:673,y:779,t:1528143716018};\\\", \\\"{x:671,y:781,t:1528143716035};\\\", \\\"{x:667,y:784,t:1528143716052};\\\", \\\"{x:663,y:786,t:1528143716069};\\\", \\\"{x:661,y:789,t:1528143716085};\\\", \\\"{x:656,y:789,t:1528143716102};\\\", \\\"{x:653,y:789,t:1528143716119};\\\", \\\"{x:652,y:789,t:1528143716134};\\\", \\\"{x:649,y:789,t:1528143716151};\\\", \\\"{x:645,y:789,t:1528143716169};\\\", \\\"{x:639,y:786,t:1528143716185};\\\", \\\"{x:630,y:782,t:1528143716202};\\\", \\\"{x:623,y:779,t:1528143716219};\\\", \\\"{x:618,y:778,t:1528143716235};\\\", \\\"{x:610,y:774,t:1528143716252};\\\", \\\"{x:600,y:769,t:1528143716269};\\\", \\\"{x:590,y:765,t:1528143716285};\\\", \\\"{x:586,y:763,t:1528143716302};\\\", \\\"{x:584,y:763,t:1528143716319};\\\", \\\"{x:582,y:763,t:1528143716443};\\\", \\\"{x:579,y:762,t:1528143716453};\\\", \\\"{x:579,y:761,t:1528143716470};\\\", \\\"{x:577,y:760,t:1528143716486};\\\", \\\"{x:572,y:759,t:1528143716503};\\\", \\\"{x:569,y:757,t:1528143716519};\\\", \\\"{x:565,y:756,t:1528143716537};\\\", \\\"{x:561,y:755,t:1528143716553};\\\", \\\"{x:555,y:753,t:1528143716570};\\\", \\\"{x:544,y:750,t:1528143716585};\\\", \\\"{x:538,y:748,t:1528143716601};\\\", \\\"{x:536,y:747,t:1528143716619};\\\", \\\"{x:534,y:746,t:1528143716636};\\\", \\\"{x:533,y:746,t:1528143716665};\\\", \\\"{x:533,y:745,t:1528143716673};\\\", \\\"{x:532,y:745,t:1528143716874};\\\", \\\"{x:531,y:745,t:1528143717794};\\\" ] }, { \\\"rt\\\": 82536, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 821755, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:744,t:1528143718665};\\\", \\\"{x:531,y:743,t:1528143718770};\\\", \\\"{x:531,y:734,t:1528143718793};\\\", \\\"{x:531,y:721,t:1528143718805};\\\", \\\"{x:531,y:708,t:1528143718823};\\\", \\\"{x:530,y:698,t:1528143718838};\\\", \\\"{x:529,y:684,t:1528143718855};\\\", \\\"{x:529,y:673,t:1528143718871};\\\", \\\"{x:529,y:664,t:1528143718888};\\\", \\\"{x:529,y:657,t:1528143718905};\\\", \\\"{x:529,y:647,t:1528143718921};\\\", \\\"{x:533,y:627,t:1528143718939};\\\", \\\"{x:569,y:528,t:1528143719039};\\\", \\\"{x:575,y:516,t:1528143719055};\\\", \\\"{x:581,y:501,t:1528143719071};\\\", \\\"{x:589,y:490,t:1528143719088};\\\", \\\"{x:596,y:481,t:1528143719105};\\\", \\\"{x:604,y:472,t:1528143719120};\\\", \\\"{x:615,y:461,t:1528143719138};\\\", \\\"{x:621,y:456,t:1528143719155};\\\", \\\"{x:626,y:452,t:1528143719171};\\\", \\\"{x:634,y:447,t:1528143719188};\\\", \\\"{x:639,y:444,t:1528143719205};\\\", \\\"{x:644,y:440,t:1528143719221};\\\", \\\"{x:647,y:438,t:1528143719238};\\\", \\\"{x:650,y:437,t:1528143719255};\\\", \\\"{x:654,y:434,t:1528143719272};\\\", \\\"{x:656,y:433,t:1528143719288};\\\", \\\"{x:664,y:429,t:1528143719305};\\\", \\\"{x:671,y:426,t:1528143719321};\\\", \\\"{x:678,y:424,t:1528143719338};\\\", \\\"{x:682,y:422,t:1528143719355};\\\", \\\"{x:686,y:421,t:1528143719372};\\\", \\\"{x:688,y:419,t:1528143719388};\\\", \\\"{x:689,y:419,t:1528143719405};\\\", \\\"{x:689,y:418,t:1528143719421};\\\", \\\"{x:691,y:418,t:1528143719491};\\\", \\\"{x:692,y:416,t:1528143719505};\\\", \\\"{x:696,y:415,t:1528143719522};\\\", \\\"{x:699,y:414,t:1528143719538};\\\", \\\"{x:700,y:413,t:1528143719554};\\\", \\\"{x:702,y:412,t:1528143719572};\\\", \\\"{x:704,y:412,t:1528143719588};\\\", \\\"{x:706,y:411,t:1528143719604};\\\", \\\"{x:708,y:409,t:1528143719621};\\\", \\\"{x:710,y:408,t:1528143719638};\\\", \\\"{x:712,y:408,t:1528143719654};\\\", \\\"{x:711,y:407,t:1528143719818};\\\", \\\"{x:711,y:406,t:1528143719899};\\\", \\\"{x:711,y:405,t:1528143719906};\\\", \\\"{x:713,y:404,t:1528143719921};\\\", \\\"{x:713,y:403,t:1528143719939};\\\", \\\"{x:715,y:403,t:1528143720067};\\\", \\\"{x:710,y:403,t:1528143785535};\\\", \\\"{x:679,y:420,t:1528143785543};\\\", \\\"{x:596,y:458,t:1528143785560};\\\", \\\"{x:533,y:483,t:1528143785577};\\\", \\\"{x:472,y:511,t:1528143785594};\\\", \\\"{x:394,y:545,t:1528143785610};\\\", \\\"{x:311,y:567,t:1528143785626};\\\", \\\"{x:218,y:597,t:1528143785656};\\\", \\\"{x:207,y:603,t:1528143785673};\\\", \\\"{x:206,y:603,t:1528143786022};\\\", \\\"{x:205,y:602,t:1528143786038};\\\", \\\"{x:205,y:596,t:1528143786047};\\\", \\\"{x:205,y:589,t:1528143786057};\\\", \\\"{x:205,y:577,t:1528143786073};\\\", \\\"{x:205,y:564,t:1528143786089};\\\", \\\"{x:205,y:553,t:1528143786106};\\\", \\\"{x:205,y:545,t:1528143786123};\\\", \\\"{x:204,y:537,t:1528143786139};\\\", \\\"{x:199,y:531,t:1528143786155};\\\", \\\"{x:199,y:529,t:1528143786173};\\\", \\\"{x:198,y:529,t:1528143786198};\\\", \\\"{x:197,y:529,t:1528143786206};\\\", \\\"{x:183,y:529,t:1528143786223};\\\", \\\"{x:175,y:529,t:1528143786239};\\\", \\\"{x:177,y:529,t:1528143786278};\\\", \\\"{x:186,y:533,t:1528143786289};\\\", \\\"{x:206,y:541,t:1528143786307};\\\", \\\"{x:235,y:547,t:1528143786323};\\\", \\\"{x:280,y:547,t:1528143786341};\\\", \\\"{x:339,y:547,t:1528143786355};\\\", \\\"{x:392,y:547,t:1528143786374};\\\", \\\"{x:453,y:547,t:1528143786390};\\\", \\\"{x:472,y:547,t:1528143786406};\\\", \\\"{x:477,y:547,t:1528143786422};\\\", \\\"{x:478,y:547,t:1528143786454};\\\", \\\"{x:478,y:550,t:1528143786511};\\\", \\\"{x:477,y:559,t:1528143786524};\\\", \\\"{x:475,y:575,t:1528143786540};\\\", \\\"{x:475,y:584,t:1528143786557};\\\", \\\"{x:473,y:588,t:1528143786573};\\\", \\\"{x:458,y:590,t:1528143786590};\\\", \\\"{x:436,y:590,t:1528143786607};\\\", \\\"{x:414,y:590,t:1528143786624};\\\", \\\"{x:392,y:588,t:1528143786639};\\\", \\\"{x:370,y:579,t:1528143786657};\\\", \\\"{x:346,y:572,t:1528143786672};\\\", \\\"{x:330,y:568,t:1528143786690};\\\", \\\"{x:316,y:566,t:1528143786706};\\\", \\\"{x:306,y:564,t:1528143786722};\\\", \\\"{x:299,y:563,t:1528143786740};\\\", \\\"{x:297,y:563,t:1528143786756};\\\", \\\"{x:295,y:562,t:1528143786774};\\\", \\\"{x:295,y:563,t:1528143786847};\\\", \\\"{x:296,y:564,t:1528143786857};\\\", \\\"{x:297,y:569,t:1528143786873};\\\", \\\"{x:309,y:580,t:1528143786890};\\\", \\\"{x:336,y:592,t:1528143786907};\\\", \\\"{x:376,y:605,t:1528143786924};\\\", \\\"{x:421,y:611,t:1528143786940};\\\", \\\"{x:471,y:612,t:1528143786956};\\\", \\\"{x:530,y:612,t:1528143786974};\\\", \\\"{x:570,y:612,t:1528143786990};\\\", \\\"{x:641,y:608,t:1528143787007};\\\", \\\"{x:721,y:597,t:1528143787025};\\\", \\\"{x:768,y:586,t:1528143787040};\\\", \\\"{x:792,y:577,t:1528143787056};\\\", \\\"{x:798,y:573,t:1528143787072};\\\", \\\"{x:799,y:572,t:1528143787090};\\\", \\\"{x:799,y:570,t:1528143787106};\\\", \\\"{x:800,y:570,t:1528143787133};\\\", \\\"{x:801,y:570,t:1528143787149};\\\", \\\"{x:802,y:569,t:1528143787165};\\\", \\\"{x:805,y:568,t:1528143787174};\\\", \\\"{x:810,y:565,t:1528143787189};\\\", \\\"{x:821,y:562,t:1528143787207};\\\", \\\"{x:831,y:557,t:1528143787224};\\\", \\\"{x:838,y:554,t:1528143787240};\\\", \\\"{x:839,y:554,t:1528143787256};\\\", \\\"{x:840,y:553,t:1528143787327};\\\", \\\"{x:841,y:553,t:1528143787374};\\\", \\\"{x:842,y:553,t:1528143787390};\\\", \\\"{x:842,y:552,t:1528143787406};\\\", \\\"{x:843,y:551,t:1528143787438};\\\", \\\"{x:843,y:550,t:1528143787445};\\\", \\\"{x:842,y:549,t:1528143787457};\\\", \\\"{x:838,y:549,t:1528143787474};\\\", \\\"{x:836,y:547,t:1528143787489};\\\", \\\"{x:835,y:547,t:1528143787507};\\\", \\\"{x:829,y:545,t:1528143787524};\\\", \\\"{x:825,y:543,t:1528143787540};\\\", \\\"{x:822,y:541,t:1528143787557};\\\", \\\"{x:822,y:540,t:1528143788118};\\\", \\\"{x:828,y:540,t:1528143788135};\\\", \\\"{x:878,y:538,t:1528143788142};\\\", \\\"{x:985,y:540,t:1528143788157};\\\", \\\"{x:1212,y:526,t:1528143788174};\\\", \\\"{x:1295,y:490,t:1528143788190};\\\", \\\"{x:1322,y:468,t:1528143788207};\\\", \\\"{x:1332,y:455,t:1528143788223};\\\", \\\"{x:1334,y:452,t:1528143788241};\\\", \\\"{x:1337,y:447,t:1528143788257};\\\", \\\"{x:1340,y:448,t:1528143788438};\\\", \\\"{x:1362,y:486,t:1528143788445};\\\", \\\"{x:1387,y:524,t:1528143788456};\\\", \\\"{x:1444,y:608,t:1528143788474};\\\", \\\"{x:1494,y:670,t:1528143788491};\\\", \\\"{x:1509,y:686,t:1528143788507};\\\", \\\"{x:1521,y:693,t:1528143788523};\\\", \\\"{x:1540,y:705,t:1528143788541};\\\", \\\"{x:1557,y:714,t:1528143788556};\\\", \\\"{x:1559,y:714,t:1528143788574};\\\", \\\"{x:1547,y:710,t:1528143788591};\\\", \\\"{x:1533,y:701,t:1528143788607};\\\", \\\"{x:1528,y:697,t:1528143788624};\\\", \\\"{x:1527,y:696,t:1528143788641};\\\", \\\"{x:1526,y:691,t:1528143788658};\\\", \\\"{x:1512,y:664,t:1528143788674};\\\", \\\"{x:1475,y:627,t:1528143788691};\\\", \\\"{x:1452,y:606,t:1528143788707};\\\", \\\"{x:1443,y:598,t:1528143788725};\\\", \\\"{x:1439,y:595,t:1528143788742};\\\", \\\"{x:1431,y:585,t:1528143788757};\\\", \\\"{x:1428,y:576,t:1528143788774};\\\", \\\"{x:1428,y:574,t:1528143788792};\\\", \\\"{x:1429,y:574,t:1528143788822};\\\", \\\"{x:1430,y:574,t:1528143788863};\\\", \\\"{x:1433,y:574,t:1528143788875};\\\", \\\"{x:1437,y:574,t:1528143788891};\\\", \\\"{x:1441,y:574,t:1528143788908};\\\", \\\"{x:1443,y:575,t:1528143788924};\\\", \\\"{x:1441,y:575,t:1528143788975};\\\", \\\"{x:1429,y:570,t:1528143788992};\\\", \\\"{x:1414,y:563,t:1528143789011};\\\", \\\"{x:1407,y:560,t:1528143789026};\\\", \\\"{x:1404,y:558,t:1528143789041};\\\", \\\"{x:1401,y:556,t:1528143789058};\\\", \\\"{x:1397,y:554,t:1528143789074};\\\", \\\"{x:1395,y:553,t:1528143789093};\\\", \\\"{x:1395,y:552,t:1528143789175};\\\", \\\"{x:1400,y:552,t:1528143789191};\\\", \\\"{x:1407,y:554,t:1528143789208};\\\", \\\"{x:1415,y:556,t:1528143789224};\\\", \\\"{x:1420,y:559,t:1528143789242};\\\", \\\"{x:1424,y:561,t:1528143789258};\\\", \\\"{x:1423,y:561,t:1528143789494};\\\", \\\"{x:1422,y:560,t:1528143789508};\\\", \\\"{x:1422,y:559,t:1528143792911};\\\", \\\"{x:1421,y:559,t:1528143794998};\\\", \\\"{x:1416,y:560,t:1528143795046};\\\", \\\"{x:1411,y:562,t:1528143795059};\\\", \\\"{x:1410,y:562,t:1528143795076};\\\", \\\"{x:1403,y:566,t:1528143795094};\\\", \\\"{x:1398,y:568,t:1528143795110};\\\", \\\"{x:1388,y:571,t:1528143795126};\\\", \\\"{x:1370,y:578,t:1528143795143};\\\", \\\"{x:1336,y:579,t:1528143795159};\\\", \\\"{x:1309,y:582,t:1528143795177};\\\", \\\"{x:1280,y:593,t:1528143795193};\\\", \\\"{x:1240,y:594,t:1528143795209};\\\", \\\"{x:1168,y:594,t:1528143795226};\\\", \\\"{x:1097,y:606,t:1528143795244};\\\", \\\"{x:1057,y:620,t:1528143795259};\\\", \\\"{x:1021,y:637,t:1528143795277};\\\", \\\"{x:950,y:675,t:1528143795294};\\\", \\\"{x:886,y:706,t:1528143795310};\\\", \\\"{x:821,y:733,t:1528143795326};\\\", \\\"{x:761,y:755,t:1528143795343};\\\", \\\"{x:689,y:773,t:1528143795359};\\\", \\\"{x:609,y:784,t:1528143795376};\\\", \\\"{x:555,y:792,t:1528143795393};\\\", \\\"{x:538,y:796,t:1528143795409};\\\", \\\"{x:525,y:801,t:1528143795426};\\\", \\\"{x:498,y:807,t:1528143795443};\\\", \\\"{x:442,y:823,t:1528143795459};\\\", \\\"{x:399,y:837,t:1528143795476};\\\", \\\"{x:377,y:848,t:1528143795493};\\\", \\\"{x:373,y:849,t:1528143795508};\\\", \\\"{x:377,y:849,t:1528143795566};\\\", \\\"{x:382,y:840,t:1528143795576};\\\", \\\"{x:400,y:822,t:1528143795593};\\\", \\\"{x:431,y:792,t:1528143795609};\\\", \\\"{x:459,y:762,t:1528143795627};\\\", \\\"{x:477,y:739,t:1528143795644};\\\", \\\"{x:488,y:722,t:1528143795660};\\\", \\\"{x:497,y:710,t:1528143795676};\\\", \\\"{x:503,y:703,t:1528143795694};\\\", \\\"{x:508,y:700,t:1528143795709};\\\", \\\"{x:515,y:699,t:1528143795727};\\\", \\\"{x:521,y:698,t:1528143795744};\\\", \\\"{x:526,y:697,t:1528143795760};\\\", \\\"{x:531,y:697,t:1528143795777};\\\", \\\"{x:534,y:697,t:1528143795793};\\\", \\\"{x:535,y:697,t:1528143795810};\\\", \\\"{x:537,y:697,t:1528143795845};\\\", \\\"{x:537,y:699,t:1528143795934};\\\", \\\"{x:535,y:700,t:1528143795943};\\\", \\\"{x:534,y:702,t:1528143795961};\\\", \\\"{x:533,y:702,t:1528143795977};\\\", \\\"{x:532,y:702,t:1528143795993};\\\", \\\"{x:530,y:704,t:1528143796010};\\\", \\\"{x:527,y:709,t:1528143796026};\\\", \\\"{x:526,y:713,t:1528143796043};\\\", \\\"{x:524,y:715,t:1528143796060};\\\", \\\"{x:524,y:716,t:1528143796076};\\\", \\\"{x:524,y:720,t:1528143796094};\\\", \\\"{x:523,y:722,t:1528143796110};\\\", \\\"{x:523,y:723,t:1528143796130};\\\", \\\"{x:523,y:725,t:1528143796147};\\\", \\\"{x:523,y:726,t:1528143796164};\\\", \\\"{x:523,y:727,t:1528143796181};\\\", \\\"{x:524,y:727,t:1528143796390};\\\", \\\"{x:524,y:723,t:1528143796397};\\\", \\\"{x:527,y:698,t:1528143796415};\\\", \\\"{x:537,y:682,t:1528143796432};\\\", \\\"{x:554,y:662,t:1528143796447};\\\", \\\"{x:587,y:636,t:1528143796464};\\\", \\\"{x:622,y:607,t:1528143796483};\\\", \\\"{x:658,y:577,t:1528143796498};\\\", \\\"{x:692,y:553,t:1528143796515};\\\", \\\"{x:723,y:533,t:1528143796531};\\\", \\\"{x:744,y:522,t:1528143796547};\\\", \\\"{x:759,y:516,t:1528143796564};\\\", \\\"{x:771,y:512,t:1528143796581};\\\", \\\"{x:776,y:511,t:1528143796596};\\\", \\\"{x:783,y:511,t:1528143796614};\\\", \\\"{x:791,y:511,t:1528143796631};\\\", \\\"{x:800,y:511,t:1528143796647};\\\", \\\"{x:803,y:511,t:1528143796664};\\\", \\\"{x:809,y:511,t:1528143796681};\\\", \\\"{x:813,y:511,t:1528143796698};\\\", \\\"{x:816,y:510,t:1528143796714};\\\", \\\"{x:817,y:510,t:1528143796731};\\\", \\\"{x:820,y:515,t:1528143796830};\\\", \\\"{x:820,y:526,t:1528143796839};\\\", \\\"{x:820,y:535,t:1528143796848};\\\", \\\"{x:820,y:541,t:1528143796864};\\\", \\\"{x:822,y:545,t:1528143796880};\\\", \\\"{x:825,y:547,t:1528143796897};\\\", \\\"{x:830,y:550,t:1528143796913};\\\", \\\"{x:830,y:551,t:1528143796932};\\\", \\\"{x:831,y:552,t:1528143796948};\\\", \\\"{x:832,y:553,t:1528143796965};\\\", \\\"{x:833,y:553,t:1528143797021};\\\", \\\"{x:834,y:553,t:1528143797143};\\\", \\\"{x:834,y:552,t:1528143797174};\\\", \\\"{x:834,y:551,t:1528143797239};\\\", \\\"{x:834,y:550,t:1528143797248};\\\", \\\"{x:833,y:549,t:1528143797277};\\\", \\\"{x:832,y:549,t:1528143797285};\\\", \\\"{x:831,y:548,t:1528143797298};\\\", \\\"{x:828,y:547,t:1528143797315};\\\", \\\"{x:827,y:546,t:1528143797331};\\\", \\\"{x:824,y:546,t:1528143798222};\\\", \\\"{x:812,y:555,t:1528143798233};\\\", \\\"{x:775,y:596,t:1528143798249};\\\", \\\"{x:722,y:646,t:1528143798265};\\\", \\\"{x:657,y:696,t:1528143798282};\\\", \\\"{x:590,y:743,t:1528143798299};\\\", \\\"{x:544,y:770,t:1528143798315};\\\", \\\"{x:528,y:778,t:1528143798332};\\\", \\\"{x:508,y:793,t:1528143798348};\\\", \\\"{x:505,y:795,t:1528143798365};\\\", \\\"{x:506,y:795,t:1528143798485};\\\", \\\"{x:510,y:793,t:1528143798499};\\\", \\\"{x:512,y:787,t:1528143798516};\\\", \\\"{x:517,y:782,t:1528143798533};\\\", \\\"{x:520,y:776,t:1528143798550};\\\", \\\"{x:522,y:774,t:1528143798566};\\\", \\\"{x:522,y:772,t:1528143798623};\\\", \\\"{x:522,y:768,t:1528143798633};\\\", \\\"{x:522,y:764,t:1528143798649};\\\", \\\"{x:523,y:760,t:1528143798667};\\\", \\\"{x:523,y:754,t:1528143798683};\\\", \\\"{x:523,y:749,t:1528143798699};\\\", \\\"{x:523,y:746,t:1528143798716};\\\", \\\"{x:524,y:742,t:1528143798732};\\\", \\\"{x:525,y:739,t:1528143798749};\\\", \\\"{x:526,y:737,t:1528143798766};\\\", \\\"{x:529,y:734,t:1528143798784};\\\", \\\"{x:529,y:732,t:1528143798799};\\\", \\\"{x:529,y:730,t:1528143798830};\\\" ] }, { \\\"rt\\\": 42860, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 866157, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B -B -10 AM-10 AM-I -I -J -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:727,t:1528143803847};\\\", \\\"{x:529,y:714,t:1528143803858};\\\", \\\"{x:528,y:699,t:1528143803872};\\\", \\\"{x:528,y:696,t:1528143803886};\\\", \\\"{x:528,y:694,t:1528143803904};\\\", \\\"{x:543,y:688,t:1528143829580};\\\", \\\"{x:591,y:666,t:1528143829587};\\\", \\\"{x:690,y:622,t:1528143829605};\\\", \\\"{x:727,y:599,t:1528143829620};\\\", \\\"{x:738,y:586,t:1528143829637};\\\", \\\"{x:755,y:568,t:1528143829655};\\\", \\\"{x:772,y:556,t:1528143829672};\\\", \\\"{x:788,y:549,t:1528143829689};\\\", \\\"{x:802,y:545,t:1528143829705};\\\", \\\"{x:806,y:545,t:1528143829722};\\\", \\\"{x:808,y:545,t:1528143829738};\\\", \\\"{x:813,y:547,t:1528143829755};\\\", \\\"{x:826,y:556,t:1528143829772};\\\", \\\"{x:842,y:575,t:1528143829789};\\\", \\\"{x:883,y:627,t:1528143829806};\\\", \\\"{x:971,y:734,t:1528143829822};\\\", \\\"{x:1088,y:871,t:1528143829839};\\\", \\\"{x:1198,y:993,t:1528143829855};\\\", \\\"{x:1267,y:1050,t:1528143829872};\\\", \\\"{x:1316,y:1080,t:1528143829889};\\\", \\\"{x:1356,y:1101,t:1528143829905};\\\", \\\"{x:1389,y:1111,t:1528143829922};\\\", \\\"{x:1402,y:1114,t:1528143829939};\\\", \\\"{x:1403,y:1114,t:1528143829955};\\\", \\\"{x:1404,y:1114,t:1528143830067};\\\", \\\"{x:1402,y:1111,t:1528143830075};\\\", \\\"{x:1393,y:1107,t:1528143830090};\\\", \\\"{x:1377,y:1097,t:1528143830105};\\\", \\\"{x:1316,y:1066,t:1528143830122};\\\", \\\"{x:1187,y:971,t:1528143830140};\\\", \\\"{x:1133,y:906,t:1528143830155};\\\", \\\"{x:1117,y:879,t:1528143830173};\\\", \\\"{x:1117,y:877,t:1528143830190};\\\", \\\"{x:1119,y:874,t:1528143830205};\\\", \\\"{x:1128,y:868,t:1528143830223};\\\", \\\"{x:1143,y:857,t:1528143830240};\\\", \\\"{x:1162,y:845,t:1528143830255};\\\", \\\"{x:1186,y:835,t:1528143830272};\\\", \\\"{x:1212,y:823,t:1528143830290};\\\", \\\"{x:1236,y:813,t:1528143830307};\\\", \\\"{x:1242,y:811,t:1528143830322};\\\", \\\"{x:1242,y:810,t:1528143830339};\\\", \\\"{x:1247,y:809,t:1528143830356};\\\", \\\"{x:1250,y:808,t:1528143830372};\\\", \\\"{x:1256,y:807,t:1528143830389};\\\", \\\"{x:1257,y:807,t:1528143830407};\\\", \\\"{x:1258,y:807,t:1528143830422};\\\", \\\"{x:1258,y:806,t:1528143830439};\\\", \\\"{x:1260,y:806,t:1528143830523};\\\", \\\"{x:1267,y:806,t:1528143830539};\\\", \\\"{x:1276,y:809,t:1528143830557};\\\", \\\"{x:1282,y:813,t:1528143830573};\\\", \\\"{x:1289,y:816,t:1528143830590};\\\", \\\"{x:1297,y:822,t:1528143830607};\\\", \\\"{x:1305,y:827,t:1528143830623};\\\", \\\"{x:1311,y:830,t:1528143830640};\\\", \\\"{x:1315,y:832,t:1528143830657};\\\", \\\"{x:1316,y:832,t:1528143830675};\\\", \\\"{x:1317,y:832,t:1528143830811};\\\", \\\"{x:1320,y:822,t:1528143830823};\\\", \\\"{x:1322,y:801,t:1528143830839};\\\", \\\"{x:1324,y:796,t:1528143830857};\\\", \\\"{x:1328,y:788,t:1528143830873};\\\", \\\"{x:1331,y:782,t:1528143830889};\\\", \\\"{x:1336,y:775,t:1528143830906};\\\", \\\"{x:1340,y:773,t:1528143830923};\\\", \\\"{x:1341,y:772,t:1528143830940};\\\", \\\"{x:1344,y:771,t:1528143830956};\\\", \\\"{x:1348,y:768,t:1528143830975};\\\", \\\"{x:1350,y:768,t:1528143830989};\\\", \\\"{x:1352,y:767,t:1528143831006};\\\", \\\"{x:1354,y:765,t:1528143831024};\\\", \\\"{x:1356,y:764,t:1528143831039};\\\", \\\"{x:1357,y:763,t:1528143831056};\\\", \\\"{x:1357,y:762,t:1528143831073};\\\", \\\"{x:1357,y:761,t:1528143831140};\\\", \\\"{x:1357,y:760,t:1528143831187};\\\", \\\"{x:1357,y:759,t:1528143831195};\\\", \\\"{x:1356,y:758,t:1528143831235};\\\", \\\"{x:1355,y:758,t:1528143831244};\\\", \\\"{x:1353,y:757,t:1528143831256};\\\", \\\"{x:1351,y:756,t:1528143831273};\\\", \\\"{x:1349,y:755,t:1528143831314};\\\", \\\"{x:1348,y:755,t:1528143831571};\\\", \\\"{x:1347,y:755,t:1528143831626};\\\", \\\"{x:1342,y:762,t:1528143831641};\\\", \\\"{x:1336,y:771,t:1528143831658};\\\", \\\"{x:1331,y:780,t:1528143831673};\\\", \\\"{x:1325,y:787,t:1528143831690};\\\", \\\"{x:1325,y:789,t:1528143831706};\\\", \\\"{x:1324,y:790,t:1528143831723};\\\", \\\"{x:1324,y:791,t:1528143831740};\\\", \\\"{x:1323,y:791,t:1528143831757};\\\", \\\"{x:1321,y:796,t:1528143831774};\\\", \\\"{x:1318,y:800,t:1528143831790};\\\", \\\"{x:1318,y:805,t:1528143831807};\\\", \\\"{x:1316,y:807,t:1528143831823};\\\", \\\"{x:1314,y:810,t:1528143831840};\\\", \\\"{x:1311,y:814,t:1528143831857};\\\", \\\"{x:1307,y:819,t:1528143831873};\\\", \\\"{x:1302,y:825,t:1528143831891};\\\", \\\"{x:1299,y:830,t:1528143831907};\\\", \\\"{x:1297,y:834,t:1528143831924};\\\", \\\"{x:1295,y:837,t:1528143831941};\\\", \\\"{x:1292,y:840,t:1528143831957};\\\", \\\"{x:1288,y:845,t:1528143831973};\\\", \\\"{x:1286,y:851,t:1528143831990};\\\", \\\"{x:1283,y:856,t:1528143832008};\\\", \\\"{x:1279,y:862,t:1528143832023};\\\", \\\"{x:1276,y:868,t:1528143832040};\\\", \\\"{x:1275,y:873,t:1528143832058};\\\", \\\"{x:1272,y:878,t:1528143832074};\\\", \\\"{x:1266,y:892,t:1528143832091};\\\", \\\"{x:1260,y:905,t:1528143832107};\\\", \\\"{x:1250,y:920,t:1528143832123};\\\", \\\"{x:1243,y:931,t:1528143832140};\\\", \\\"{x:1237,y:940,t:1528143832158};\\\", \\\"{x:1231,y:948,t:1528143832175};\\\", \\\"{x:1225,y:959,t:1528143832191};\\\", \\\"{x:1218,y:970,t:1528143832208};\\\", \\\"{x:1214,y:979,t:1528143832224};\\\", \\\"{x:1211,y:988,t:1528143832243};\\\", \\\"{x:1208,y:994,t:1528143832257};\\\", \\\"{x:1208,y:997,t:1528143832274};\\\", \\\"{x:1207,y:998,t:1528143832290};\\\", \\\"{x:1207,y:999,t:1528143832307};\\\", \\\"{x:1206,y:1000,t:1528143832325};\\\", \\\"{x:1205,y:1001,t:1528143832340};\\\", \\\"{x:1204,y:1002,t:1528143832357};\\\", \\\"{x:1204,y:1003,t:1528143832596};\\\", \\\"{x:1204,y:1001,t:1528143832643};\\\", \\\"{x:1204,y:998,t:1528143832658};\\\", \\\"{x:1204,y:988,t:1528143832675};\\\", \\\"{x:1204,y:980,t:1528143832691};\\\", \\\"{x:1204,y:962,t:1528143832709};\\\", \\\"{x:1204,y:947,t:1528143832724};\\\", \\\"{x:1204,y:937,t:1528143832742};\\\", \\\"{x:1207,y:920,t:1528143832758};\\\", \\\"{x:1209,y:901,t:1528143832775};\\\", \\\"{x:1209,y:879,t:1528143832792};\\\", \\\"{x:1209,y:860,t:1528143832808};\\\", \\\"{x:1206,y:841,t:1528143832825};\\\", \\\"{x:1202,y:818,t:1528143832842};\\\", \\\"{x:1195,y:799,t:1528143832858};\\\", \\\"{x:1184,y:770,t:1528143832875};\\\", \\\"{x:1181,y:760,t:1528143832892};\\\", \\\"{x:1179,y:757,t:1528143832908};\\\", \\\"{x:1178,y:753,t:1528143832924};\\\", \\\"{x:1177,y:749,t:1528143832941};\\\", \\\"{x:1175,y:743,t:1528143832958};\\\", \\\"{x:1174,y:740,t:1528143832975};\\\", \\\"{x:1174,y:738,t:1528143832991};\\\", \\\"{x:1174,y:737,t:1528143833008};\\\", \\\"{x:1175,y:737,t:1528143833092};\\\", \\\"{x:1187,y:744,t:1528143833109};\\\", \\\"{x:1198,y:752,t:1528143833124};\\\", \\\"{x:1201,y:769,t:1528143833142};\\\", \\\"{x:1203,y:785,t:1528143833159};\\\", \\\"{x:1207,y:809,t:1528143833175};\\\", \\\"{x:1212,y:834,t:1528143833192};\\\", \\\"{x:1219,y:864,t:1528143833209};\\\", \\\"{x:1224,y:890,t:1528143833225};\\\", \\\"{x:1229,y:914,t:1528143833242};\\\", \\\"{x:1232,y:930,t:1528143833259};\\\", \\\"{x:1234,y:937,t:1528143833274};\\\", \\\"{x:1234,y:942,t:1528143833292};\\\", \\\"{x:1240,y:961,t:1528143833309};\\\", \\\"{x:1245,y:979,t:1528143833325};\\\", \\\"{x:1252,y:996,t:1528143833342};\\\", \\\"{x:1258,y:1007,t:1528143833358};\\\", \\\"{x:1260,y:1010,t:1528143833375};\\\", \\\"{x:1261,y:1010,t:1528143833676};\\\", \\\"{x:1263,y:1002,t:1528143833692};\\\", \\\"{x:1264,y:993,t:1528143833708};\\\", \\\"{x:1265,y:988,t:1528143833726};\\\", \\\"{x:1267,y:984,t:1528143833742};\\\", \\\"{x:1268,y:981,t:1528143833759};\\\", \\\"{x:1268,y:979,t:1528143833776};\\\", \\\"{x:1270,y:977,t:1528143833791};\\\", \\\"{x:1270,y:975,t:1528143833809};\\\", \\\"{x:1271,y:975,t:1528143833825};\\\", \\\"{x:1271,y:974,t:1528143833842};\\\", \\\"{x:1271,y:972,t:1528143833859};\\\", \\\"{x:1272,y:971,t:1528143833876};\\\", \\\"{x:1273,y:969,t:1528143833899};\\\", \\\"{x:1273,y:968,t:1528143833909};\\\", \\\"{x:1273,y:966,t:1528143833926};\\\", \\\"{x:1273,y:963,t:1528143833942};\\\", \\\"{x:1273,y:959,t:1528143833959};\\\", \\\"{x:1273,y:958,t:1528143833975};\\\", \\\"{x:1273,y:952,t:1528143833992};\\\", \\\"{x:1273,y:946,t:1528143834009};\\\", \\\"{x:1273,y:939,t:1528143834026};\\\", \\\"{x:1272,y:926,t:1528143834042};\\\", \\\"{x:1272,y:912,t:1528143834058};\\\", \\\"{x:1272,y:904,t:1528143834075};\\\", \\\"{x:1274,y:896,t:1528143834092};\\\", \\\"{x:1276,y:889,t:1528143834108};\\\", \\\"{x:1278,y:882,t:1528143834125};\\\", \\\"{x:1280,y:875,t:1528143834142};\\\", \\\"{x:1282,y:871,t:1528143834158};\\\", \\\"{x:1282,y:870,t:1528143834175};\\\", \\\"{x:1283,y:868,t:1528143834192};\\\", \\\"{x:1284,y:864,t:1528143834208};\\\", \\\"{x:1286,y:857,t:1528143834226};\\\", \\\"{x:1289,y:850,t:1528143834242};\\\", \\\"{x:1290,y:847,t:1528143834258};\\\", \\\"{x:1291,y:844,t:1528143834276};\\\", \\\"{x:1291,y:840,t:1528143834293};\\\", \\\"{x:1291,y:837,t:1528143834309};\\\", \\\"{x:1291,y:833,t:1528143834326};\\\", \\\"{x:1291,y:831,t:1528143834343};\\\", \\\"{x:1291,y:829,t:1528143834358};\\\", \\\"{x:1291,y:828,t:1528143834375};\\\", \\\"{x:1291,y:830,t:1528143834531};\\\", \\\"{x:1286,y:845,t:1528143834543};\\\", \\\"{x:1274,y:868,t:1528143834560};\\\", \\\"{x:1260,y:893,t:1528143834576};\\\", \\\"{x:1253,y:904,t:1528143834593};\\\", \\\"{x:1253,y:906,t:1528143834610};\\\", \\\"{x:1252,y:908,t:1528143834626};\\\", \\\"{x:1251,y:911,t:1528143834643};\\\", \\\"{x:1250,y:915,t:1528143834659};\\\", \\\"{x:1249,y:920,t:1528143834676};\\\", \\\"{x:1249,y:923,t:1528143834693};\\\", \\\"{x:1248,y:925,t:1528143834710};\\\", \\\"{x:1247,y:928,t:1528143834726};\\\", \\\"{x:1246,y:930,t:1528143834742};\\\", \\\"{x:1245,y:932,t:1528143834760};\\\", \\\"{x:1243,y:933,t:1528143834860};\\\", \\\"{x:1228,y:926,t:1528143834876};\\\", \\\"{x:1203,y:903,t:1528143834893};\\\", \\\"{x:1169,y:826,t:1528143834910};\\\", \\\"{x:1147,y:778,t:1528143834926};\\\", \\\"{x:1135,y:741,t:1528143834942};\\\", \\\"{x:1125,y:705,t:1528143834959};\\\", \\\"{x:1114,y:678,t:1528143834976};\\\", \\\"{x:1102,y:649,t:1528143834992};\\\", \\\"{x:1091,y:626,t:1528143835009};\\\", \\\"{x:1080,y:608,t:1528143835026};\\\", \\\"{x:1072,y:603,t:1528143835042};\\\", \\\"{x:1057,y:596,t:1528143835059};\\\", \\\"{x:1036,y:587,t:1528143835076};\\\", \\\"{x:1027,y:582,t:1528143835092};\\\", \\\"{x:1025,y:581,t:1528143835109};\\\", \\\"{x:1019,y:580,t:1528143835127};\\\", \\\"{x:1003,y:573,t:1528143835143};\\\", \\\"{x:953,y:557,t:1528143835159};\\\", \\\"{x:853,y:544,t:1528143835178};\\\", \\\"{x:704,y:531,t:1528143835193};\\\", \\\"{x:538,y:531,t:1528143835209};\\\", \\\"{x:237,y:526,t:1528143835227};\\\", \\\"{x:85,y:526,t:1528143835243};\\\", \\\"{x:0,y:531,t:1528143835260};\\\", \\\"{x:0,y:539,t:1528143835276};\\\", \\\"{x:0,y:541,t:1528143835294};\\\", \\\"{x:5,y:539,t:1528143835395};\\\", \\\"{x:19,y:532,t:1528143835410};\\\", \\\"{x:34,y:531,t:1528143835426};\\\", \\\"{x:59,y:533,t:1528143835444};\\\", \\\"{x:85,y:538,t:1528143835460};\\\", \\\"{x:114,y:543,t:1528143835476};\\\", \\\"{x:154,y:544,t:1528143835493};\\\", \\\"{x:207,y:550,t:1528143835510};\\\", \\\"{x:264,y:554,t:1528143835526};\\\", \\\"{x:323,y:563,t:1528143835545};\\\", \\\"{x:376,y:571,t:1528143835560};\\\", \\\"{x:424,y:578,t:1528143835576};\\\", \\\"{x:430,y:578,t:1528143835593};\\\", \\\"{x:424,y:578,t:1528143835803};\\\", \\\"{x:401,y:568,t:1528143835812};\\\", \\\"{x:389,y:562,t:1528143835827};\\\", \\\"{x:386,y:561,t:1528143835843};\\\", \\\"{x:386,y:560,t:1528143835890};\\\", \\\"{x:387,y:560,t:1528143836042};\\\", \\\"{x:397,y:560,t:1528143836060};\\\", \\\"{x:411,y:558,t:1528143836077};\\\", \\\"{x:435,y:551,t:1528143836096};\\\", \\\"{x:460,y:545,t:1528143836111};\\\", \\\"{x:487,y:540,t:1528143836127};\\\", \\\"{x:511,y:536,t:1528143836144};\\\", \\\"{x:531,y:533,t:1528143836160};\\\", \\\"{x:558,y:530,t:1528143836177};\\\", \\\"{x:591,y:526,t:1528143836193};\\\", \\\"{x:633,y:524,t:1528143836210};\\\", \\\"{x:655,y:520,t:1528143836227};\\\", \\\"{x:667,y:518,t:1528143836243};\\\", \\\"{x:670,y:518,t:1528143836261};\\\", \\\"{x:669,y:518,t:1528143836411};\\\", \\\"{x:665,y:519,t:1528143836428};\\\", \\\"{x:662,y:521,t:1528143836445};\\\", \\\"{x:661,y:521,t:1528143836467};\\\", \\\"{x:659,y:521,t:1528143836587};\\\", \\\"{x:658,y:521,t:1528143836651};\\\", \\\"{x:658,y:522,t:1528143836661};\\\", \\\"{x:653,y:522,t:1528143836678};\\\", \\\"{x:651,y:523,t:1528143836695};\\\", \\\"{x:648,y:523,t:1528143836712};\\\", \\\"{x:646,y:523,t:1528143836747};\\\", \\\"{x:654,y:516,t:1528143838085};\\\", \\\"{x:666,y:507,t:1528143838095};\\\", \\\"{x:680,y:498,t:1528143838113};\\\", \\\"{x:687,y:494,t:1528143838129};\\\", \\\"{x:697,y:492,t:1528143838146};\\\", \\\"{x:702,y:491,t:1528143838163};\\\", \\\"{x:702,y:490,t:1528143838194};\\\", \\\"{x:705,y:489,t:1528143840707};\\\", \\\"{x:712,y:486,t:1528143840716};\\\", \\\"{x:731,y:486,t:1528143840730};\\\", \\\"{x:744,y:488,t:1528143840748};\\\", \\\"{x:755,y:488,t:1528143840764};\\\", \\\"{x:764,y:488,t:1528143840780};\\\", \\\"{x:773,y:488,t:1528143840797};\\\", \\\"{x:785,y:490,t:1528143840814};\\\", \\\"{x:799,y:492,t:1528143840831};\\\", \\\"{x:814,y:495,t:1528143840847};\\\", \\\"{x:839,y:498,t:1528143840865};\\\", \\\"{x:864,y:499,t:1528143840880};\\\", \\\"{x:878,y:501,t:1528143840898};\\\", \\\"{x:893,y:501,t:1528143840913};\\\", \\\"{x:897,y:501,t:1528143840930};\\\", \\\"{x:901,y:501,t:1528143840947};\\\", \\\"{x:914,y:507,t:1528143840965};\\\", \\\"{x:936,y:515,t:1528143840980};\\\", \\\"{x:963,y:532,t:1528143840999};\\\", \\\"{x:982,y:546,t:1528143841015};\\\", \\\"{x:1007,y:562,t:1528143841031};\\\", \\\"{x:1036,y:581,t:1528143841047};\\\", \\\"{x:1063,y:600,t:1528143841064};\\\", \\\"{x:1079,y:612,t:1528143841080};\\\", \\\"{x:1083,y:617,t:1528143841098};\\\", \\\"{x:1084,y:620,t:1528143841114};\\\", \\\"{x:1085,y:622,t:1528143841132};\\\", \\\"{x:1081,y:624,t:1528143841148};\\\", \\\"{x:1049,y:615,t:1528143841166};\\\", \\\"{x:994,y:592,t:1528143841182};\\\", \\\"{x:961,y:577,t:1528143841198};\\\", \\\"{x:942,y:567,t:1528143841216};\\\", \\\"{x:918,y:557,t:1528143841232};\\\", \\\"{x:878,y:540,t:1528143841248};\\\", \\\"{x:821,y:516,t:1528143841265};\\\", \\\"{x:778,y:494,t:1528143841281};\\\", \\\"{x:764,y:488,t:1528143841297};\\\", \\\"{x:763,y:488,t:1528143841321};\\\", \\\"{x:758,y:490,t:1528143841410};\\\", \\\"{x:752,y:499,t:1528143841419};\\\", \\\"{x:744,y:507,t:1528143841432};\\\", \\\"{x:726,y:521,t:1528143841448};\\\", \\\"{x:688,y:538,t:1528143841466};\\\", \\\"{x:635,y:552,t:1528143841482};\\\", \\\"{x:581,y:572,t:1528143841498};\\\", \\\"{x:557,y:580,t:1528143841514};\\\", \\\"{x:529,y:585,t:1528143841531};\\\", \\\"{x:501,y:589,t:1528143841548};\\\", \\\"{x:478,y:589,t:1528143841565};\\\", \\\"{x:470,y:590,t:1528143841581};\\\", \\\"{x:468,y:590,t:1528143841598};\\\", \\\"{x:464,y:590,t:1528143841614};\\\", \\\"{x:456,y:590,t:1528143841632};\\\", \\\"{x:446,y:588,t:1528143841649};\\\", \\\"{x:437,y:587,t:1528143841664};\\\", \\\"{x:433,y:587,t:1528143841682};\\\", \\\"{x:431,y:586,t:1528143841697};\\\", \\\"{x:425,y:586,t:1528143841715};\\\", \\\"{x:416,y:584,t:1528143841733};\\\", \\\"{x:403,y:580,t:1528143841748};\\\", \\\"{x:396,y:579,t:1528143841765};\\\", \\\"{x:392,y:577,t:1528143841782};\\\", \\\"{x:391,y:577,t:1528143841938};\\\", \\\"{x:390,y:577,t:1528143841949};\\\", \\\"{x:385,y:577,t:1528143841965};\\\", \\\"{x:382,y:578,t:1528143841981};\\\", \\\"{x:377,y:582,t:1528143841999};\\\", \\\"{x:372,y:586,t:1528143842017};\\\", \\\"{x:365,y:592,t:1528143842031};\\\", \\\"{x:360,y:596,t:1528143842049};\\\", \\\"{x:356,y:598,t:1528143842065};\\\", \\\"{x:354,y:600,t:1528143842081};\\\", \\\"{x:354,y:608,t:1528143842099};\\\", \\\"{x:355,y:614,t:1528143842115};\\\", \\\"{x:358,y:621,t:1528143842131};\\\", \\\"{x:362,y:628,t:1528143842149};\\\", \\\"{x:366,y:630,t:1528143842166};\\\", \\\"{x:372,y:633,t:1528143842182};\\\", \\\"{x:382,y:638,t:1528143842199};\\\", \\\"{x:397,y:644,t:1528143842216};\\\", \\\"{x:417,y:653,t:1528143842231};\\\", \\\"{x:430,y:655,t:1528143842249};\\\", \\\"{x:441,y:657,t:1528143842266};\\\", \\\"{x:445,y:655,t:1528143842282};\\\", \\\"{x:462,y:645,t:1528143842299};\\\", \\\"{x:474,y:636,t:1528143842316};\\\", \\\"{x:491,y:622,t:1528143842332};\\\", \\\"{x:507,y:608,t:1528143842349};\\\", \\\"{x:523,y:596,t:1528143842366};\\\", \\\"{x:543,y:585,t:1528143842383};\\\", \\\"{x:570,y:568,t:1528143842399};\\\", \\\"{x:590,y:555,t:1528143842416};\\\", \\\"{x:608,y:541,t:1528143842433};\\\", \\\"{x:623,y:531,t:1528143842449};\\\", \\\"{x:634,y:521,t:1528143842465};\\\", \\\"{x:640,y:516,t:1528143842482};\\\", \\\"{x:641,y:515,t:1528143842498};\\\", \\\"{x:642,y:514,t:1528143842555};\\\", \\\"{x:644,y:513,t:1528143842566};\\\", \\\"{x:653,y:512,t:1528143842582};\\\", \\\"{x:665,y:510,t:1528143842599};\\\", \\\"{x:671,y:510,t:1528143842616};\\\", \\\"{x:675,y:510,t:1528143842633};\\\", \\\"{x:677,y:510,t:1528143842658};\\\", \\\"{x:680,y:514,t:1528143842665};\\\", \\\"{x:685,y:533,t:1528143842682};\\\", \\\"{x:690,y:550,t:1528143842698};\\\", \\\"{x:695,y:564,t:1528143842716};\\\", \\\"{x:695,y:577,t:1528143842732};\\\", \\\"{x:695,y:585,t:1528143842748};\\\", \\\"{x:689,y:597,t:1528143842765};\\\", \\\"{x:685,y:604,t:1528143842783};\\\", \\\"{x:677,y:608,t:1528143842799};\\\", \\\"{x:664,y:613,t:1528143842815};\\\", \\\"{x:643,y:618,t:1528143842833};\\\", \\\"{x:628,y:620,t:1528143842850};\\\", \\\"{x:619,y:622,t:1528143842865};\\\", \\\"{x:598,y:623,t:1528143842882};\\\", \\\"{x:577,y:619,t:1528143842900};\\\", \\\"{x:549,y:610,t:1528143842915};\\\", \\\"{x:530,y:602,t:1528143842932};\\\", \\\"{x:517,y:596,t:1528143842951};\\\", \\\"{x:506,y:592,t:1528143842966};\\\", \\\"{x:493,y:583,t:1528143842983};\\\", \\\"{x:482,y:576,t:1528143842999};\\\", \\\"{x:473,y:572,t:1528143843016};\\\", \\\"{x:470,y:569,t:1528143843033};\\\", \\\"{x:469,y:568,t:1528143843050};\\\", \\\"{x:468,y:567,t:1528143843066};\\\", \\\"{x:468,y:566,t:1528143843083};\\\", \\\"{x:467,y:564,t:1528143843100};\\\", \\\"{x:461,y:555,t:1528143843118};\\\", \\\"{x:452,y:540,t:1528143843133};\\\", \\\"{x:436,y:521,t:1528143843150};\\\", \\\"{x:427,y:511,t:1528143843167};\\\", \\\"{x:425,y:507,t:1528143843182};\\\", \\\"{x:424,y:507,t:1528143843210};\\\", \\\"{x:424,y:506,t:1528143843217};\\\", \\\"{x:422,y:506,t:1528143843234};\\\", \\\"{x:421,y:506,t:1528143843250};\\\", \\\"{x:419,y:506,t:1528143843265};\\\", \\\"{x:418,y:506,t:1528143843298};\\\", \\\"{x:413,y:510,t:1528143843306};\\\", \\\"{x:409,y:515,t:1528143843316};\\\", \\\"{x:393,y:525,t:1528143843333};\\\", \\\"{x:377,y:533,t:1528143843350};\\\", \\\"{x:361,y:538,t:1528143843367};\\\", \\\"{x:345,y:543,t:1528143843382};\\\", \\\"{x:331,y:544,t:1528143843399};\\\", \\\"{x:322,y:544,t:1528143843416};\\\", \\\"{x:316,y:544,t:1528143843433};\\\", \\\"{x:311,y:544,t:1528143843450};\\\", \\\"{x:304,y:541,t:1528143843465};\\\", \\\"{x:293,y:535,t:1528143843482};\\\", \\\"{x:282,y:529,t:1528143843500};\\\", \\\"{x:274,y:526,t:1528143843516};\\\", \\\"{x:270,y:525,t:1528143843534};\\\", \\\"{x:266,y:523,t:1528143843549};\\\", \\\"{x:258,y:520,t:1528143843567};\\\", \\\"{x:239,y:516,t:1528143843583};\\\", \\\"{x:217,y:512,t:1528143843600};\\\", \\\"{x:203,y:511,t:1528143843616};\\\", \\\"{x:195,y:511,t:1528143843634};\\\", \\\"{x:189,y:510,t:1528143843649};\\\", \\\"{x:182,y:508,t:1528143843667};\\\", \\\"{x:180,y:508,t:1528143843684};\\\", \\\"{x:178,y:508,t:1528143843700};\\\", \\\"{x:174,y:506,t:1528143843716};\\\", \\\"{x:173,y:506,t:1528143843780};\\\", \\\"{x:172,y:506,t:1528143843819};\\\", \\\"{x:171,y:506,t:1528143843834};\\\", \\\"{x:170,y:506,t:1528143843850};\\\", \\\"{x:171,y:506,t:1528143844074};\\\", \\\"{x:172,y:508,t:1528143844084};\\\", \\\"{x:178,y:509,t:1528143844099};\\\", \\\"{x:184,y:514,t:1528143844117};\\\", \\\"{x:196,y:519,t:1528143844134};\\\", \\\"{x:210,y:526,t:1528143844149};\\\", \\\"{x:227,y:532,t:1528143844167};\\\", \\\"{x:250,y:543,t:1528143844184};\\\", \\\"{x:276,y:554,t:1528143844201};\\\", \\\"{x:313,y:571,t:1528143844218};\\\", \\\"{x:342,y:584,t:1528143844233};\\\", \\\"{x:365,y:594,t:1528143844250};\\\", \\\"{x:372,y:598,t:1528143844266};\\\", \\\"{x:373,y:599,t:1528143844283};\\\", \\\"{x:377,y:604,t:1528143844301};\\\", \\\"{x:384,y:630,t:1528143844317};\\\", \\\"{x:397,y:673,t:1528143844334};\\\", \\\"{x:411,y:710,t:1528143844351};\\\", \\\"{x:421,y:729,t:1528143844366};\\\", \\\"{x:424,y:735,t:1528143844383};\\\", \\\"{x:425,y:738,t:1528143844400};\\\", \\\"{x:426,y:749,t:1528143844416};\\\", \\\"{x:427,y:763,t:1528143844433};\\\", \\\"{x:429,y:773,t:1528143844450};\\\", \\\"{x:429,y:774,t:1528143844468};\\\", \\\"{x:430,y:775,t:1528143844483};\\\", \\\"{x:432,y:778,t:1528143844500};\\\", \\\"{x:437,y:779,t:1528143844518};\\\", \\\"{x:441,y:782,t:1528143844534};\\\", \\\"{x:446,y:782,t:1528143844551};\\\", \\\"{x:458,y:779,t:1528143844567};\\\", \\\"{x:474,y:770,t:1528143844583};\\\", \\\"{x:495,y:763,t:1528143844600};\\\", \\\"{x:520,y:751,t:1528143844618};\\\", \\\"{x:532,y:745,t:1528143844634};\\\", \\\"{x:540,y:742,t:1528143844650};\\\", \\\"{x:540,y:741,t:1528143844723};\\\", \\\"{x:541,y:740,t:1528143844754};\\\", \\\"{x:541,y:739,t:1528143844875};\\\", \\\"{x:541,y:738,t:1528143844962};\\\", \\\"{x:540,y:738,t:1528143845043};\\\", \\\"{x:539,y:738,t:1528143845059};\\\", \\\"{x:538,y:738,t:1528143845763};\\\" ] }, { \\\"rt\\\": 7452, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 874867, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:737,t:1528143846930};\\\", \\\"{x:536,y:735,t:1528143846938};\\\", \\\"{x:536,y:733,t:1528143846953};\\\", \\\"{x:535,y:726,t:1528143846970};\\\", \\\"{x:535,y:724,t:1528143846986};\\\", \\\"{x:535,y:719,t:1528143847003};\\\", \\\"{x:535,y:717,t:1528143847026};\\\", \\\"{x:535,y:715,t:1528143847051};\\\", \\\"{x:535,y:714,t:1528143847059};\\\", \\\"{x:535,y:713,t:1528143847070};\\\", \\\"{x:532,y:706,t:1528143847086};\\\", \\\"{x:530,y:693,t:1528143847103};\\\", \\\"{x:522,y:672,t:1528143847120};\\\", \\\"{x:515,y:652,t:1528143847136};\\\", \\\"{x:589,y:466,t:1528143847212};\\\", \\\"{x:602,y:448,t:1528143847219};\\\", \\\"{x:631,y:411,t:1528143847236};\\\", \\\"{x:652,y:397,t:1528143847252};\\\", \\\"{x:670,y:385,t:1528143847270};\\\", \\\"{x:695,y:372,t:1528143847285};\\\", \\\"{x:740,y:359,t:1528143847302};\\\", \\\"{x:820,y:350,t:1528143847320};\\\", \\\"{x:925,y:350,t:1528143847336};\\\", \\\"{x:1033,y:350,t:1528143847353};\\\", \\\"{x:1218,y:360,t:1528143847370};\\\", \\\"{x:1356,y:377,t:1528143847386};\\\", \\\"{x:1469,y:391,t:1528143847403};\\\", \\\"{x:1525,y:391,t:1528143847419};\\\", \\\"{x:1544,y:387,t:1528143847436};\\\", \\\"{x:1554,y:381,t:1528143847453};\\\", \\\"{x:1558,y:379,t:1528143847470};\\\", \\\"{x:1560,y:377,t:1528143847486};\\\", \\\"{x:1560,y:373,t:1528143847692};\\\", \\\"{x:1558,y:364,t:1528143847704};\\\", \\\"{x:1553,y:352,t:1528143847721};\\\", \\\"{x:1551,y:345,t:1528143847736};\\\", \\\"{x:1551,y:339,t:1528143847753};\\\", \\\"{x:1551,y:338,t:1528143847770};\\\", \\\"{x:1551,y:337,t:1528143847787};\\\", \\\"{x:1552,y:336,t:1528143848011};\\\", \\\"{x:1556,y:335,t:1528143848020};\\\", \\\"{x:1602,y:339,t:1528143848037};\\\", \\\"{x:1611,y:342,t:1528143848054};\\\", \\\"{x:1613,y:341,t:1528143848147};\\\", \\\"{x:1617,y:337,t:1528143848155};\\\", \\\"{x:1620,y:333,t:1528143848170};\\\", \\\"{x:1623,y:331,t:1528143848186};\\\", \\\"{x:1624,y:331,t:1528143848227};\\\", \\\"{x:1625,y:332,t:1528143848372};\\\", \\\"{x:1625,y:360,t:1528143848386};\\\", \\\"{x:1625,y:390,t:1528143848403};\\\", \\\"{x:1625,y:420,t:1528143848421};\\\", \\\"{x:1622,y:446,t:1528143848438};\\\", \\\"{x:1618,y:470,t:1528143848454};\\\", \\\"{x:1615,y:492,t:1528143848471};\\\", \\\"{x:1613,y:511,t:1528143848487};\\\", \\\"{x:1612,y:523,t:1528143848504};\\\", \\\"{x:1610,y:530,t:1528143848521};\\\", \\\"{x:1608,y:537,t:1528143848538};\\\", \\\"{x:1607,y:542,t:1528143848555};\\\", \\\"{x:1607,y:546,t:1528143848570};\\\", \\\"{x:1606,y:549,t:1528143848587};\\\", \\\"{x:1606,y:550,t:1528143848605};\\\", \\\"{x:1605,y:552,t:1528143848621};\\\", \\\"{x:1605,y:555,t:1528143848637};\\\", \\\"{x:1605,y:558,t:1528143848655};\\\", \\\"{x:1605,y:559,t:1528143848670};\\\", \\\"{x:1605,y:561,t:1528143848763};\\\", \\\"{x:1605,y:563,t:1528143848779};\\\", \\\"{x:1605,y:564,t:1528143848787};\\\", \\\"{x:1605,y:565,t:1528143848804};\\\", \\\"{x:1605,y:567,t:1528143848820};\\\", \\\"{x:1606,y:568,t:1528143848849};\\\", \\\"{x:1607,y:568,t:1528143848898};\\\", \\\"{x:1607,y:570,t:1528143848914};\\\", \\\"{x:1607,y:575,t:1528143848922};\\\", \\\"{x:1603,y:587,t:1528143848937};\\\", \\\"{x:1601,y:634,t:1528143848954};\\\", \\\"{x:1601,y:671,t:1528143848970};\\\", \\\"{x:1601,y:716,t:1528143848987};\\\", \\\"{x:1601,y:766,t:1528143849004};\\\", \\\"{x:1601,y:811,t:1528143849020};\\\", \\\"{x:1595,y:855,t:1528143849037};\\\", \\\"{x:1582,y:900,t:1528143849054};\\\", \\\"{x:1571,y:928,t:1528143849071};\\\", \\\"{x:1562,y:949,t:1528143849087};\\\", \\\"{x:1555,y:964,t:1528143849105};\\\", \\\"{x:1551,y:969,t:1528143849121};\\\", \\\"{x:1550,y:971,t:1528143849137};\\\", \\\"{x:1549,y:972,t:1528143849155};\\\", \\\"{x:1547,y:972,t:1528143849227};\\\", \\\"{x:1545,y:972,t:1528143849237};\\\", \\\"{x:1543,y:972,t:1528143849255};\\\", \\\"{x:1536,y:970,t:1528143849271};\\\", \\\"{x:1518,y:960,t:1528143849288};\\\", \\\"{x:1501,y:942,t:1528143849304};\\\", \\\"{x:1488,y:905,t:1528143849322};\\\", \\\"{x:1483,y:892,t:1528143849338};\\\", \\\"{x:1476,y:868,t:1528143849355};\\\", \\\"{x:1471,y:844,t:1528143849370};\\\", \\\"{x:1461,y:818,t:1528143849387};\\\", \\\"{x:1451,y:792,t:1528143849404};\\\", \\\"{x:1439,y:771,t:1528143849421};\\\", \\\"{x:1428,y:749,t:1528143849437};\\\", \\\"{x:1423,y:732,t:1528143849453};\\\", \\\"{x:1421,y:722,t:1528143849471};\\\", \\\"{x:1417,y:706,t:1528143849487};\\\", \\\"{x:1414,y:698,t:1528143849504};\\\", \\\"{x:1413,y:697,t:1528143849554};\\\", \\\"{x:1411,y:697,t:1528143849570};\\\", \\\"{x:1409,y:695,t:1528143849588};\\\", \\\"{x:1407,y:695,t:1528143849604};\\\", \\\"{x:1406,y:695,t:1528143849642};\\\", \\\"{x:1404,y:695,t:1528143849654};\\\", \\\"{x:1398,y:714,t:1528143849672};\\\", \\\"{x:1393,y:741,t:1528143849688};\\\", \\\"{x:1386,y:763,t:1528143849704};\\\", \\\"{x:1385,y:769,t:1528143849722};\\\", \\\"{x:1385,y:770,t:1528143849738};\\\", \\\"{x:1383,y:772,t:1528143849755};\\\", \\\"{x:1382,y:776,t:1528143849770};\\\", \\\"{x:1382,y:777,t:1528143849788};\\\", \\\"{x:1382,y:782,t:1528143849805};\\\", \\\"{x:1382,y:790,t:1528143849821};\\\", \\\"{x:1392,y:804,t:1528143849838};\\\", \\\"{x:1409,y:823,t:1528143849854};\\\", \\\"{x:1423,y:842,t:1528143849871};\\\", \\\"{x:1431,y:852,t:1528143849888};\\\", \\\"{x:1439,y:863,t:1528143849904};\\\", \\\"{x:1451,y:880,t:1528143849921};\\\", \\\"{x:1463,y:897,t:1528143849938};\\\", \\\"{x:1473,y:912,t:1528143849954};\\\", \\\"{x:1475,y:917,t:1528143849970};\\\", \\\"{x:1478,y:925,t:1528143849987};\\\", \\\"{x:1481,y:941,t:1528143850004};\\\", \\\"{x:1487,y:956,t:1528143850021};\\\", \\\"{x:1489,y:962,t:1528143850037};\\\", \\\"{x:1489,y:963,t:1528143850054};\\\", \\\"{x:1489,y:964,t:1528143850071};\\\", \\\"{x:1490,y:968,t:1528143850088};\\\", \\\"{x:1491,y:976,t:1528143850105};\\\", \\\"{x:1491,y:979,t:1528143850121};\\\", \\\"{x:1492,y:982,t:1528143850138};\\\", \\\"{x:1492,y:983,t:1528143850170};\\\", \\\"{x:1492,y:987,t:1528143850189};\\\", \\\"{x:1493,y:992,t:1528143850205};\\\", \\\"{x:1494,y:995,t:1528143850221};\\\", \\\"{x:1494,y:998,t:1528143850238};\\\", \\\"{x:1494,y:1000,t:1528143850255};\\\", \\\"{x:1494,y:1005,t:1528143850272};\\\", \\\"{x:1494,y:1008,t:1528143850288};\\\", \\\"{x:1494,y:1013,t:1528143850306};\\\", \\\"{x:1496,y:1016,t:1528143850321};\\\", \\\"{x:1497,y:1019,t:1528143850339};\\\", \\\"{x:1498,y:1019,t:1528143850460};\\\", \\\"{x:1497,y:1018,t:1528143850569};\\\", \\\"{x:1496,y:1016,t:1528143850578};\\\", \\\"{x:1495,y:1013,t:1528143850587};\\\", \\\"{x:1489,y:1002,t:1528143850605};\\\", \\\"{x:1482,y:989,t:1528143850621};\\\", \\\"{x:1468,y:962,t:1528143850638};\\\", \\\"{x:1447,y:929,t:1528143850655};\\\", \\\"{x:1429,y:907,t:1528143850671};\\\", \\\"{x:1419,y:887,t:1528143850688};\\\", \\\"{x:1414,y:871,t:1528143850705};\\\", \\\"{x:1407,y:846,t:1528143850722};\\\", \\\"{x:1380,y:757,t:1528143850738};\\\", \\\"{x:1356,y:699,t:1528143850754};\\\", \\\"{x:1347,y:679,t:1528143850772};\\\", \\\"{x:1346,y:674,t:1528143850789};\\\", \\\"{x:1346,y:670,t:1528143850805};\\\", \\\"{x:1346,y:667,t:1528143850823};\\\", \\\"{x:1346,y:665,t:1528143850838};\\\", \\\"{x:1346,y:663,t:1528143850856};\\\", \\\"{x:1346,y:659,t:1528143850873};\\\", \\\"{x:1345,y:646,t:1528143850888};\\\", \\\"{x:1340,y:632,t:1528143850905};\\\", \\\"{x:1331,y:619,t:1528143850922};\\\", \\\"{x:1331,y:617,t:1528143850939};\\\", \\\"{x:1330,y:615,t:1528143850955};\\\", \\\"{x:1329,y:611,t:1528143850973};\\\", \\\"{x:1324,y:605,t:1528143850989};\\\", \\\"{x:1319,y:599,t:1528143851005};\\\", \\\"{x:1309,y:588,t:1528143851022};\\\", \\\"{x:1303,y:580,t:1528143851038};\\\", \\\"{x:1298,y:574,t:1528143851055};\\\", \\\"{x:1296,y:572,t:1528143851072};\\\", \\\"{x:1295,y:571,t:1528143851091};\\\", \\\"{x:1294,y:569,t:1528143851106};\\\", \\\"{x:1294,y:566,t:1528143851139};\\\", \\\"{x:1294,y:563,t:1528143851156};\\\", \\\"{x:1294,y:562,t:1528143851187};\\\", \\\"{x:1296,y:562,t:1528143851275};\\\", \\\"{x:1301,y:565,t:1528143851288};\\\", \\\"{x:1317,y:575,t:1528143851305};\\\", \\\"{x:1336,y:587,t:1528143851323};\\\", \\\"{x:1349,y:605,t:1528143851339};\\\", \\\"{x:1363,y:631,t:1528143851356};\\\", \\\"{x:1376,y:650,t:1528143851372};\\\", \\\"{x:1386,y:670,t:1528143851390};\\\", \\\"{x:1397,y:688,t:1528143851405};\\\", \\\"{x:1408,y:707,t:1528143851423};\\\", \\\"{x:1420,y:727,t:1528143851439};\\\", \\\"{x:1429,y:748,t:1528143851456};\\\", \\\"{x:1439,y:770,t:1528143851473};\\\", \\\"{x:1447,y:788,t:1528143851489};\\\", \\\"{x:1457,y:808,t:1528143851506};\\\", \\\"{x:1472,y:844,t:1528143851522};\\\", \\\"{x:1478,y:863,t:1528143851538};\\\", \\\"{x:1486,y:883,t:1528143851555};\\\", \\\"{x:1490,y:898,t:1528143851573};\\\", \\\"{x:1494,y:915,t:1528143851589};\\\", \\\"{x:1503,y:941,t:1528143851606};\\\", \\\"{x:1508,y:966,t:1528143851623};\\\", \\\"{x:1512,y:988,t:1528143851640};\\\", \\\"{x:1515,y:1009,t:1528143851655};\\\", \\\"{x:1519,y:1029,t:1528143851673};\\\", \\\"{x:1525,y:1053,t:1528143851690};\\\", \\\"{x:1529,y:1073,t:1528143851706};\\\", \\\"{x:1531,y:1089,t:1528143851722};\\\", \\\"{x:1532,y:1092,t:1528143851739};\\\", \\\"{x:1526,y:1090,t:1528143851835};\\\", \\\"{x:1522,y:1086,t:1528143851843};\\\", \\\"{x:1518,y:1078,t:1528143851856};\\\", \\\"{x:1505,y:1053,t:1528143851872};\\\", \\\"{x:1485,y:1018,t:1528143851890};\\\", \\\"{x:1449,y:949,t:1528143851906};\\\", \\\"{x:1420,y:877,t:1528143851923};\\\", \\\"{x:1383,y:789,t:1528143851939};\\\", \\\"{x:1340,y:687,t:1528143851957};\\\", \\\"{x:1286,y:581,t:1528143851973};\\\", \\\"{x:1229,y:485,t:1528143851989};\\\", \\\"{x:1192,y:430,t:1528143852007};\\\", \\\"{x:1172,y:401,t:1528143852022};\\\", \\\"{x:1156,y:377,t:1528143852039};\\\", \\\"{x:1150,y:367,t:1528143852056};\\\", \\\"{x:1147,y:359,t:1528143852073};\\\", \\\"{x:1147,y:357,t:1528143852090};\\\", \\\"{x:1147,y:355,t:1528143852106};\\\", \\\"{x:1146,y:355,t:1528143852179};\\\", \\\"{x:1145,y:355,t:1528143852189};\\\", \\\"{x:1124,y:368,t:1528143852206};\\\", \\\"{x:1024,y:437,t:1528143852222};\\\", \\\"{x:958,y:475,t:1528143852239};\\\", \\\"{x:918,y:496,t:1528143852257};\\\", \\\"{x:900,y:501,t:1528143852273};\\\", \\\"{x:889,y:506,t:1528143852289};\\\", \\\"{x:885,y:510,t:1528143852307};\\\", \\\"{x:883,y:521,t:1528143852323};\\\", \\\"{x:876,y:536,t:1528143852340};\\\", \\\"{x:866,y:551,t:1528143852356};\\\", \\\"{x:852,y:563,t:1528143852373};\\\", \\\"{x:835,y:572,t:1528143852390};\\\", \\\"{x:811,y:579,t:1528143852407};\\\", \\\"{x:794,y:580,t:1528143852424};\\\", \\\"{x:775,y:580,t:1528143852440};\\\", \\\"{x:745,y:580,t:1528143852457};\\\", \\\"{x:711,y:570,t:1528143852473};\\\", \\\"{x:648,y:542,t:1528143852490};\\\", \\\"{x:613,y:521,t:1528143852508};\\\", \\\"{x:578,y:501,t:1528143852524};\\\", \\\"{x:559,y:490,t:1528143852539};\\\", \\\"{x:549,y:482,t:1528143852558};\\\", \\\"{x:548,y:481,t:1528143852585};\\\", \\\"{x:548,y:480,t:1528143852593};\\\", \\\"{x:548,y:479,t:1528143852606};\\\", \\\"{x:548,y:477,t:1528143852623};\\\", \\\"{x:548,y:476,t:1528143852639};\\\", \\\"{x:548,y:475,t:1528143852656};\\\", \\\"{x:551,y:475,t:1528143852674};\\\", \\\"{x:556,y:475,t:1528143852690};\\\", \\\"{x:564,y:475,t:1528143852707};\\\", \\\"{x:578,y:479,t:1528143852725};\\\", \\\"{x:591,y:484,t:1528143852740};\\\", \\\"{x:602,y:490,t:1528143852758};\\\", \\\"{x:607,y:493,t:1528143852775};\\\", \\\"{x:611,y:495,t:1528143852790};\\\", \\\"{x:612,y:496,t:1528143852807};\\\", \\\"{x:611,y:496,t:1528143852986};\\\", \\\"{x:610,y:497,t:1528143853018};\\\", \\\"{x:609,y:497,t:1528143853026};\\\", \\\"{x:609,y:498,t:1528143853250};\\\", \\\"{x:610,y:499,t:1528143853257};\\\", \\\"{x:612,y:501,t:1528143853274};\\\", \\\"{x:617,y:532,t:1528143853292};\\\", \\\"{x:624,y:559,t:1528143853308};\\\", \\\"{x:629,y:582,t:1528143853324};\\\", \\\"{x:634,y:606,t:1528143853342};\\\", \\\"{x:642,y:625,t:1528143853358};\\\", \\\"{x:645,y:634,t:1528143853374};\\\", \\\"{x:645,y:635,t:1528143853391};\\\", \\\"{x:645,y:636,t:1528143853408};\\\", \\\"{x:645,y:637,t:1528143853424};\\\", \\\"{x:645,y:639,t:1528143853441};\\\", \\\"{x:644,y:644,t:1528143853457};\\\", \\\"{x:641,y:648,t:1528143853475};\\\", \\\"{x:635,y:654,t:1528143853491};\\\", \\\"{x:629,y:661,t:1528143853508};\\\", \\\"{x:624,y:669,t:1528143853525};\\\", \\\"{x:614,y:675,t:1528143853541};\\\", \\\"{x:609,y:678,t:1528143853558};\\\", \\\"{x:607,y:678,t:1528143853575};\\\", \\\"{x:603,y:678,t:1528143853592};\\\", \\\"{x:594,y:678,t:1528143853608};\\\", \\\"{x:571,y:678,t:1528143853625};\\\", \\\"{x:550,y:679,t:1528143853642};\\\", \\\"{x:543,y:682,t:1528143853658};\\\", \\\"{x:538,y:685,t:1528143853675};\\\", \\\"{x:535,y:686,t:1528143853692};\\\", \\\"{x:531,y:689,t:1528143853709};\\\", \\\"{x:527,y:693,t:1528143853726};\\\", \\\"{x:525,y:701,t:1528143853742};\\\", \\\"{x:523,y:706,t:1528143853759};\\\", \\\"{x:523,y:709,t:1528143853776};\\\", \\\"{x:520,y:712,t:1528143853793};\\\", \\\"{x:517,y:716,t:1528143853810};\\\", \\\"{x:513,y:723,t:1528143853828};\\\", \\\"{x:511,y:724,t:1528143853842};\\\", \\\"{x:509,y:727,t:1528143853857};\\\", \\\"{x:508,y:727,t:1528143853873};\\\", \\\"{x:507,y:729,t:1528143853890};\\\", \\\"{x:505,y:731,t:1528143853906};\\\", \\\"{x:505,y:733,t:1528143853924};\\\", \\\"{x:503,y:734,t:1528143853945};\\\", \\\"{x:508,y:732,t:1528143854435};\\\", \\\"{x:519,y:727,t:1528143854441};\\\", \\\"{x:547,y:715,t:1528143854458};\\\", \\\"{x:600,y:688,t:1528143854475};\\\", \\\"{x:618,y:685,t:1528143854493};\\\" ] }, { \\\"rt\\\": 11208, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 887376, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -12 PM-M -L -05 PM-01 PM-11 AM-10 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:621,y:683,t:1528143855873};\\\", \\\"{x:621,y:680,t:1528143855954};\\\", \\\"{x:620,y:678,t:1528143855961};\\\", \\\"{x:619,y:676,t:1528143855976};\\\", \\\"{x:615,y:666,t:1528143855993};\\\", \\\"{x:614,y:662,t:1528143856009};\\\", \\\"{x:610,y:651,t:1528143856026};\\\", \\\"{x:607,y:636,t:1528143856043};\\\", \\\"{x:605,y:621,t:1528143856061};\\\", \\\"{x:602,y:607,t:1528143856076};\\\", \\\"{x:601,y:597,t:1528143856093};\\\", \\\"{x:600,y:583,t:1528143856111};\\\", \\\"{x:599,y:572,t:1528143856126};\\\", \\\"{x:599,y:562,t:1528143856143};\\\", \\\"{x:599,y:551,t:1528143856161};\\\", \\\"{x:603,y:534,t:1528143856176};\\\", \\\"{x:608,y:519,t:1528143856193};\\\", \\\"{x:612,y:509,t:1528143856210};\\\", \\\"{x:615,y:504,t:1528143856226};\\\", \\\"{x:616,y:503,t:1528143856242};\\\", \\\"{x:617,y:503,t:1528143856260};\\\", \\\"{x:617,y:502,t:1528143856276};\\\", \\\"{x:618,y:502,t:1528143856293};\\\", \\\"{x:619,y:502,t:1528143856779};\\\", \\\"{x:621,y:502,t:1528143856795};\\\", \\\"{x:622,y:502,t:1528143856843};\\\", \\\"{x:625,y:502,t:1528143856850};\\\", \\\"{x:626,y:502,t:1528143856866};\\\", \\\"{x:627,y:502,t:1528143856890};\\\", \\\"{x:628,y:502,t:1528143856930};\\\", \\\"{x:629,y:502,t:1528143857018};\\\", \\\"{x:630,y:502,t:1528143857028};\\\", \\\"{x:633,y:499,t:1528143857045};\\\", \\\"{x:634,y:498,t:1528143857061};\\\", \\\"{x:635,y:496,t:1528143857078};\\\", \\\"{x:636,y:496,t:1528143857095};\\\", \\\"{x:637,y:495,t:1528143857111};\\\", \\\"{x:637,y:494,t:1528143857129};\\\", \\\"{x:638,y:494,t:1528143857618};\\\", \\\"{x:640,y:494,t:1528143857643};\\\", \\\"{x:647,y:489,t:1528143857651};\\\", \\\"{x:652,y:487,t:1528143857660};\\\", \\\"{x:665,y:479,t:1528143857678};\\\", \\\"{x:675,y:474,t:1528143857695};\\\", \\\"{x:687,y:467,t:1528143857711};\\\", \\\"{x:714,y:460,t:1528143857727};\\\", \\\"{x:750,y:449,t:1528143857744};\\\", \\\"{x:809,y:441,t:1528143857761};\\\", \\\"{x:897,y:432,t:1528143857777};\\\", \\\"{x:990,y:428,t:1528143857794};\\\", \\\"{x:1039,y:425,t:1528143857811};\\\", \\\"{x:1084,y:425,t:1528143857828};\\\", \\\"{x:1135,y:426,t:1528143857844};\\\", \\\"{x:1180,y:433,t:1528143857861};\\\", \\\"{x:1208,y:438,t:1528143857877};\\\", \\\"{x:1217,y:440,t:1528143857894};\\\", \\\"{x:1219,y:440,t:1528143857954};\\\", \\\"{x:1221,y:445,t:1528143857963};\\\", \\\"{x:1224,y:452,t:1528143857978};\\\", \\\"{x:1234,y:475,t:1528143857995};\\\", \\\"{x:1249,y:500,t:1528143858011};\\\", \\\"{x:1264,y:522,t:1528143858029};\\\", \\\"{x:1272,y:537,t:1528143858045};\\\", \\\"{x:1275,y:544,t:1528143858061};\\\", \\\"{x:1284,y:559,t:1528143858080};\\\", \\\"{x:1300,y:588,t:1528143858096};\\\", \\\"{x:1316,y:629,t:1528143858111};\\\", \\\"{x:1326,y:655,t:1528143858128};\\\", \\\"{x:1331,y:672,t:1528143858145};\\\", \\\"{x:1337,y:689,t:1528143858161};\\\", \\\"{x:1341,y:712,t:1528143858178};\\\", \\\"{x:1342,y:728,t:1528143858194};\\\", \\\"{x:1342,y:755,t:1528143858211};\\\", \\\"{x:1342,y:791,t:1528143858228};\\\", \\\"{x:1342,y:817,t:1528143858245};\\\", \\\"{x:1344,y:837,t:1528143858261};\\\", \\\"{x:1347,y:854,t:1528143858279};\\\", \\\"{x:1347,y:873,t:1528143858295};\\\", \\\"{x:1347,y:891,t:1528143858311};\\\", \\\"{x:1347,y:909,t:1528143858329};\\\", \\\"{x:1347,y:930,t:1528143858345};\\\", \\\"{x:1348,y:946,t:1528143858362};\\\", \\\"{x:1348,y:956,t:1528143858379};\\\", \\\"{x:1348,y:958,t:1528143858395};\\\", \\\"{x:1349,y:963,t:1528143858412};\\\", \\\"{x:1349,y:972,t:1528143858429};\\\", \\\"{x:1352,y:979,t:1528143858445};\\\", \\\"{x:1352,y:981,t:1528143858462};\\\", \\\"{x:1352,y:982,t:1528143858479};\\\", \\\"{x:1352,y:983,t:1528143858531};\\\", \\\"{x:1352,y:982,t:1528143858634};\\\", \\\"{x:1354,y:977,t:1528143858644};\\\", \\\"{x:1357,y:973,t:1528143858662};\\\", \\\"{x:1361,y:966,t:1528143858679};\\\", \\\"{x:1365,y:956,t:1528143858696};\\\", \\\"{x:1366,y:942,t:1528143858712};\\\", \\\"{x:1366,y:938,t:1528143858728};\\\", \\\"{x:1366,y:937,t:1528143858867};\\\", \\\"{x:1368,y:936,t:1528143858890};\\\", \\\"{x:1368,y:933,t:1528143858899};\\\", \\\"{x:1369,y:932,t:1528143858912};\\\", \\\"{x:1371,y:927,t:1528143858929};\\\", \\\"{x:1377,y:918,t:1528143858946};\\\", \\\"{x:1381,y:911,t:1528143858962};\\\", \\\"{x:1385,y:904,t:1528143858978};\\\", \\\"{x:1386,y:899,t:1528143858997};\\\", \\\"{x:1390,y:893,t:1528143859012};\\\", \\\"{x:1393,y:888,t:1528143859029};\\\", \\\"{x:1395,y:883,t:1528143859046};\\\", \\\"{x:1398,y:878,t:1528143859061};\\\", \\\"{x:1399,y:874,t:1528143859079};\\\", \\\"{x:1401,y:870,t:1528143859096};\\\", \\\"{x:1403,y:866,t:1528143859112};\\\", \\\"{x:1404,y:865,t:1528143859129};\\\", \\\"{x:1405,y:863,t:1528143859146};\\\", \\\"{x:1405,y:860,t:1528143859162};\\\", \\\"{x:1408,y:855,t:1528143859178};\\\", \\\"{x:1410,y:852,t:1528143859196};\\\", \\\"{x:1411,y:848,t:1528143859213};\\\", \\\"{x:1412,y:845,t:1528143859229};\\\", \\\"{x:1416,y:839,t:1528143859246};\\\", \\\"{x:1419,y:834,t:1528143859262};\\\", \\\"{x:1420,y:831,t:1528143859279};\\\", \\\"{x:1423,y:826,t:1528143859295};\\\", \\\"{x:1427,y:820,t:1528143859313};\\\", \\\"{x:1429,y:814,t:1528143859329};\\\", \\\"{x:1432,y:810,t:1528143859345};\\\", \\\"{x:1436,y:804,t:1528143859362};\\\", \\\"{x:1437,y:799,t:1528143859378};\\\", \\\"{x:1439,y:796,t:1528143859396};\\\", \\\"{x:1440,y:792,t:1528143859413};\\\", \\\"{x:1443,y:787,t:1528143859429};\\\", \\\"{x:1443,y:782,t:1528143859445};\\\", \\\"{x:1446,y:778,t:1528143859463};\\\", \\\"{x:1447,y:774,t:1528143859479};\\\", \\\"{x:1449,y:768,t:1528143859496};\\\", \\\"{x:1451,y:765,t:1528143859513};\\\", \\\"{x:1454,y:757,t:1528143859529};\\\", \\\"{x:1456,y:752,t:1528143859546};\\\", \\\"{x:1459,y:743,t:1528143859562};\\\", \\\"{x:1464,y:733,t:1528143859579};\\\", \\\"{x:1467,y:724,t:1528143859596};\\\", \\\"{x:1474,y:711,t:1528143859613};\\\", \\\"{x:1478,y:701,t:1528143859629};\\\", \\\"{x:1483,y:688,t:1528143859646};\\\", \\\"{x:1489,y:674,t:1528143859663};\\\", \\\"{x:1495,y:660,t:1528143859679};\\\", \\\"{x:1499,y:647,t:1528143859696};\\\", \\\"{x:1506,y:631,t:1528143859713};\\\", \\\"{x:1514,y:615,t:1528143859729};\\\", \\\"{x:1520,y:599,t:1528143859746};\\\", \\\"{x:1529,y:579,t:1528143859763};\\\", \\\"{x:1535,y:563,t:1528143859780};\\\", \\\"{x:1539,y:549,t:1528143859796};\\\", \\\"{x:1542,y:538,t:1528143859813};\\\", \\\"{x:1546,y:529,t:1528143859829};\\\", \\\"{x:1550,y:522,t:1528143859846};\\\", \\\"{x:1552,y:516,t:1528143859863};\\\", \\\"{x:1553,y:513,t:1528143859879};\\\", \\\"{x:1554,y:511,t:1528143859896};\\\", \\\"{x:1556,y:508,t:1528143859913};\\\", \\\"{x:1557,y:506,t:1528143859930};\\\", \\\"{x:1557,y:504,t:1528143859946};\\\", \\\"{x:1560,y:502,t:1528143859963};\\\", \\\"{x:1561,y:501,t:1528143859980};\\\", \\\"{x:1562,y:501,t:1528143859996};\\\", \\\"{x:1563,y:500,t:1528143860012};\\\", \\\"{x:1565,y:498,t:1528143860029};\\\", \\\"{x:1570,y:496,t:1528143860045};\\\", \\\"{x:1573,y:494,t:1528143860062};\\\", \\\"{x:1576,y:493,t:1528143860079};\\\", \\\"{x:1579,y:491,t:1528143860095};\\\", \\\"{x:1582,y:489,t:1528143860112};\\\", \\\"{x:1586,y:488,t:1528143860130};\\\", \\\"{x:1588,y:487,t:1528143860145};\\\", \\\"{x:1589,y:487,t:1528143860163};\\\", \\\"{x:1590,y:486,t:1528143860180};\\\", \\\"{x:1590,y:488,t:1528143860387};\\\", \\\"{x:1572,y:510,t:1528143860397};\\\", \\\"{x:1547,y:552,t:1528143860413};\\\", \\\"{x:1530,y:595,t:1528143860430};\\\", \\\"{x:1486,y:674,t:1528143860446};\\\", \\\"{x:1425,y:768,t:1528143860463};\\\", \\\"{x:1346,y:864,t:1528143860479};\\\", \\\"{x:1248,y:937,t:1528143860496};\\\", \\\"{x:1149,y:994,t:1528143860512};\\\", \\\"{x:1061,y:1034,t:1528143860529};\\\", \\\"{x:982,y:1045,t:1528143860546};\\\", \\\"{x:947,y:1042,t:1528143860562};\\\", \\\"{x:876,y:1017,t:1528143860579};\\\", \\\"{x:759,y:960,t:1528143860596};\\\", \\\"{x:643,y:885,t:1528143860612};\\\", \\\"{x:538,y:813,t:1528143860629};\\\", \\\"{x:478,y:767,t:1528143860646};\\\", \\\"{x:462,y:746,t:1528143860663};\\\", \\\"{x:452,y:727,t:1528143860679};\\\", \\\"{x:442,y:706,t:1528143860696};\\\", \\\"{x:439,y:694,t:1528143860706};\\\", \\\"{x:439,y:687,t:1528143860723};\\\", \\\"{x:439,y:679,t:1528143860740};\\\", \\\"{x:442,y:671,t:1528143860756};\\\", \\\"{x:455,y:658,t:1528143860775};\\\", \\\"{x:469,y:642,t:1528143860790};\\\", \\\"{x:492,y:611,t:1528143860814};\\\", \\\"{x:509,y:590,t:1528143860831};\\\", \\\"{x:525,y:571,t:1528143860847};\\\", \\\"{x:539,y:555,t:1528143860863};\\\", \\\"{x:548,y:540,t:1528143860880};\\\", \\\"{x:552,y:533,t:1528143860897};\\\", \\\"{x:554,y:526,t:1528143860913};\\\", \\\"{x:556,y:523,t:1528143860931};\\\", \\\"{x:556,y:522,t:1528143860947};\\\", \\\"{x:555,y:521,t:1528143861051};\\\", \\\"{x:552,y:521,t:1528143861064};\\\", \\\"{x:547,y:521,t:1528143861081};\\\", \\\"{x:541,y:522,t:1528143861098};\\\", \\\"{x:536,y:523,t:1528143861115};\\\", \\\"{x:535,y:524,t:1528143861131};\\\", \\\"{x:534,y:526,t:1528143861156};\\\", \\\"{x:532,y:527,t:1528143861164};\\\", \\\"{x:527,y:531,t:1528143861180};\\\", \\\"{x:521,y:531,t:1528143861197};\\\", \\\"{x:512,y:531,t:1528143861214};\\\", \\\"{x:502,y:529,t:1528143861230};\\\", \\\"{x:500,y:528,t:1528143861247};\\\", \\\"{x:499,y:528,t:1528143861264};\\\", \\\"{x:497,y:528,t:1528143861281};\\\", \\\"{x:495,y:528,t:1528143861296};\\\", \\\"{x:491,y:528,t:1528143861314};\\\", \\\"{x:489,y:528,t:1528143861330};\\\", \\\"{x:487,y:530,t:1528143861347};\\\", \\\"{x:482,y:532,t:1528143861364};\\\", \\\"{x:475,y:533,t:1528143861381};\\\", \\\"{x:462,y:535,t:1528143861397};\\\", \\\"{x:447,y:540,t:1528143861414};\\\", \\\"{x:432,y:546,t:1528143861430};\\\", \\\"{x:424,y:549,t:1528143861448};\\\", \\\"{x:416,y:551,t:1528143861465};\\\", \\\"{x:407,y:552,t:1528143861480};\\\", \\\"{x:399,y:553,t:1528143861497};\\\", \\\"{x:395,y:553,t:1528143861515};\\\", \\\"{x:393,y:553,t:1528143861531};\\\", \\\"{x:392,y:553,t:1528143861578};\\\", \\\"{x:390,y:553,t:1528143861586};\\\", \\\"{x:388,y:553,t:1528143861602};\\\", \\\"{x:387,y:553,t:1528143861615};\\\", \\\"{x:387,y:554,t:1528143861899};\\\", \\\"{x:388,y:556,t:1528143861916};\\\", \\\"{x:390,y:566,t:1528143861932};\\\", \\\"{x:387,y:584,t:1528143861947};\\\", \\\"{x:386,y:594,t:1528143861965};\\\", \\\"{x:386,y:599,t:1528143861981};\\\", \\\"{x:383,y:608,t:1528143861997};\\\", \\\"{x:381,y:612,t:1528143862014};\\\", \\\"{x:379,y:618,t:1528143862031};\\\", \\\"{x:378,y:622,t:1528143862047};\\\", \\\"{x:378,y:629,t:1528143862064};\\\", \\\"{x:378,y:635,t:1528143862081};\\\", \\\"{x:376,y:641,t:1528143862098};\\\", \\\"{x:375,y:644,t:1528143862114};\\\", \\\"{x:374,y:645,t:1528143862132};\\\", \\\"{x:374,y:643,t:1528143862282};\\\", \\\"{x:375,y:640,t:1528143862298};\\\", \\\"{x:376,y:637,t:1528143862316};\\\", \\\"{x:377,y:631,t:1528143862332};\\\", \\\"{x:378,y:628,t:1528143862348};\\\", \\\"{x:379,y:627,t:1528143862365};\\\", \\\"{x:379,y:625,t:1528143862658};\\\", \\\"{x:379,y:624,t:1528143862690};\\\", \\\"{x:379,y:623,t:1528143862698};\\\", \\\"{x:380,y:619,t:1528143862715};\\\", \\\"{x:381,y:613,t:1528143862732};\\\", \\\"{x:383,y:606,t:1528143862749};\\\", \\\"{x:384,y:599,t:1528143862767};\\\", \\\"{x:387,y:586,t:1528143862783};\\\", \\\"{x:390,y:572,t:1528143862799};\\\", \\\"{x:393,y:562,t:1528143862816};\\\", \\\"{x:394,y:553,t:1528143862832};\\\", \\\"{x:395,y:549,t:1528143862849};\\\", \\\"{x:395,y:545,t:1528143862866};\\\", \\\"{x:395,y:540,t:1528143862882};\\\", \\\"{x:396,y:538,t:1528143862898};\\\", \\\"{x:396,y:537,t:1528143862915};\\\", \\\"{x:397,y:535,t:1528143862932};\\\", \\\"{x:397,y:529,t:1528143862948};\\\", \\\"{x:397,y:526,t:1528143862966};\\\", \\\"{x:397,y:525,t:1528143862983};\\\", \\\"{x:397,y:524,t:1528143863011};\\\", \\\"{x:396,y:524,t:1528143863058};\\\", \\\"{x:394,y:524,t:1528143863066};\\\", \\\"{x:393,y:524,t:1528143863083};\\\", \\\"{x:391,y:524,t:1528143863098};\\\", \\\"{x:383,y:526,t:1528143863124};\\\", \\\"{x:382,y:528,t:1528143863133};\\\", \\\"{x:380,y:529,t:1528143863154};\\\", \\\"{x:380,y:530,t:1528143863169};\\\", \\\"{x:380,y:531,t:1528143863506};\\\", \\\"{x:381,y:532,t:1528143863602};\\\", \\\"{x:388,y:534,t:1528143863615};\\\", \\\"{x:406,y:543,t:1528143863633};\\\", \\\"{x:426,y:551,t:1528143863650};\\\", \\\"{x:454,y:563,t:1528143863667};\\\", \\\"{x:557,y:621,t:1528143863683};\\\", \\\"{x:696,y:721,t:1528143863700};\\\", \\\"{x:862,y:811,t:1528143863716};\\\", \\\"{x:1011,y:873,t:1528143863732};\\\", \\\"{x:1156,y:901,t:1528143863749};\\\", \\\"{x:1290,y:931,t:1528143863766};\\\", \\\"{x:1440,y:952,t:1528143863782};\\\", \\\"{x:1581,y:974,t:1528143863800};\\\", \\\"{x:1699,y:986,t:1528143863816};\\\", \\\"{x:1752,y:992,t:1528143863832};\\\", \\\"{x:1768,y:995,t:1528143863850};\\\", \\\"{x:1768,y:994,t:1528143863971};\\\", \\\"{x:1756,y:989,t:1528143863982};\\\", \\\"{x:1692,y:972,t:1528143864000};\\\", \\\"{x:1592,y:968,t:1528143864018};\\\", \\\"{x:1492,y:968,t:1528143864032};\\\", \\\"{x:1400,y:979,t:1528143864050};\\\", \\\"{x:1294,y:982,t:1528143864066};\\\", \\\"{x:1224,y:984,t:1528143864083};\\\", \\\"{x:1191,y:983,t:1528143864100};\\\", \\\"{x:1183,y:981,t:1528143864117};\\\", \\\"{x:1181,y:980,t:1528143864132};\\\", \\\"{x:1181,y:978,t:1528143864170};\\\", \\\"{x:1181,y:976,t:1528143864183};\\\", \\\"{x:1181,y:974,t:1528143864199};\\\", \\\"{x:1183,y:972,t:1528143864217};\\\", \\\"{x:1189,y:969,t:1528143864233};\\\", \\\"{x:1195,y:969,t:1528143864250};\\\", \\\"{x:1202,y:968,t:1528143864267};\\\", \\\"{x:1204,y:966,t:1528143864284};\\\", \\\"{x:1209,y:963,t:1528143864300};\\\", \\\"{x:1217,y:956,t:1528143864317};\\\", \\\"{x:1230,y:947,t:1528143864334};\\\", \\\"{x:1240,y:934,t:1528143864349};\\\", \\\"{x:1249,y:925,t:1528143864367};\\\", \\\"{x:1259,y:919,t:1528143864384};\\\", \\\"{x:1267,y:915,t:1528143864400};\\\", \\\"{x:1268,y:915,t:1528143864417};\\\", \\\"{x:1270,y:914,t:1528143864434};\\\", \\\"{x:1272,y:914,t:1528143864450};\\\", \\\"{x:1281,y:915,t:1528143864467};\\\", \\\"{x:1287,y:917,t:1528143864484};\\\", \\\"{x:1288,y:917,t:1528143864500};\\\", \\\"{x:1288,y:918,t:1528143864517};\\\", \\\"{x:1289,y:919,t:1528143864538};\\\", \\\"{x:1290,y:920,t:1528143864550};\\\", \\\"{x:1296,y:922,t:1528143864567};\\\", \\\"{x:1299,y:924,t:1528143864584};\\\", \\\"{x:1304,y:926,t:1528143864600};\\\", \\\"{x:1305,y:926,t:1528143864617};\\\", \\\"{x:1310,y:928,t:1528143864787};\\\", \\\"{x:1312,y:930,t:1528143864801};\\\", \\\"{x:1319,y:933,t:1528143864817};\\\", \\\"{x:1325,y:938,t:1528143864834};\\\", \\\"{x:1329,y:945,t:1528143864851};\\\", \\\"{x:1329,y:953,t:1528143864867};\\\", \\\"{x:1329,y:957,t:1528143864884};\\\", \\\"{x:1329,y:960,t:1528143864901};\\\", \\\"{x:1329,y:962,t:1528143864917};\\\", \\\"{x:1330,y:963,t:1528143864954};\\\", \\\"{x:1331,y:963,t:1528143865001};\\\", \\\"{x:1331,y:961,t:1528143865016};\\\", \\\"{x:1344,y:937,t:1528143865033};\\\", \\\"{x:1353,y:921,t:1528143865050};\\\", \\\"{x:1364,y:907,t:1528143865067};\\\", \\\"{x:1374,y:892,t:1528143865083};\\\", \\\"{x:1383,y:876,t:1528143865100};\\\", \\\"{x:1392,y:858,t:1528143865118};\\\", \\\"{x:1401,y:841,t:1528143865134};\\\", \\\"{x:1406,y:824,t:1528143865150};\\\", \\\"{x:1413,y:803,t:1528143865168};\\\", \\\"{x:1418,y:781,t:1528143865184};\\\", \\\"{x:1423,y:758,t:1528143865200};\\\", \\\"{x:1437,y:711,t:1528143865217};\\\", \\\"{x:1443,y:695,t:1528143865233};\\\", \\\"{x:1459,y:654,t:1528143865250};\\\", \\\"{x:1472,y:630,t:1528143865268};\\\", \\\"{x:1481,y:611,t:1528143865284};\\\", \\\"{x:1488,y:593,t:1528143865301};\\\", \\\"{x:1495,y:577,t:1528143865317};\\\", \\\"{x:1500,y:565,t:1528143865333};\\\", \\\"{x:1509,y:550,t:1528143865351};\\\", \\\"{x:1514,y:540,t:1528143865367};\\\", \\\"{x:1523,y:530,t:1528143865384};\\\", \\\"{x:1531,y:522,t:1528143865401};\\\", \\\"{x:1538,y:512,t:1528143865418};\\\", \\\"{x:1544,y:505,t:1528143865434};\\\", \\\"{x:1548,y:501,t:1528143865451};\\\", \\\"{x:1551,y:495,t:1528143865468};\\\", \\\"{x:1552,y:492,t:1528143865485};\\\", \\\"{x:1553,y:491,t:1528143865500};\\\", \\\"{x:1554,y:489,t:1528143865517};\\\", \\\"{x:1556,y:489,t:1528143865535};\\\", \\\"{x:1540,y:499,t:1528143865594};\\\", \\\"{x:1519,y:514,t:1528143865603};\\\", \\\"{x:1446,y:556,t:1528143865619};\\\", \\\"{x:1305,y:622,t:1528143865634};\\\", \\\"{x:1135,y:680,t:1528143865651};\\\", \\\"{x:947,y:742,t:1528143865668};\\\", \\\"{x:765,y:788,t:1528143865684};\\\", \\\"{x:657,y:806,t:1528143865700};\\\", \\\"{x:584,y:817,t:1528143865717};\\\", \\\"{x:504,y:824,t:1528143865734};\\\", \\\"{x:454,y:832,t:1528143865750};\\\", \\\"{x:438,y:835,t:1528143865768};\\\", \\\"{x:437,y:835,t:1528143865825};\\\", \\\"{x:436,y:835,t:1528143865841};\\\", \\\"{x:436,y:831,t:1528143865850};\\\", \\\"{x:434,y:827,t:1528143865867};\\\", \\\"{x:434,y:811,t:1528143865885};\\\", \\\"{x:442,y:786,t:1528143865901};\\\", \\\"{x:449,y:770,t:1528143865918};\\\", \\\"{x:457,y:757,t:1528143865935};\\\", \\\"{x:461,y:749,t:1528143865952};\\\", \\\"{x:465,y:740,t:1528143865967};\\\", \\\"{x:469,y:724,t:1528143865984};\\\", \\\"{x:472,y:717,t:1528143866001};\\\", \\\"{x:473,y:714,t:1528143866016};\\\", \\\"{x:473,y:713,t:1528143866035};\\\", \\\"{x:474,y:712,t:1528143866052};\\\", \\\"{x:475,y:712,t:1528143866138};\\\", \\\"{x:476,y:712,t:1528143866265};\\\", \\\"{x:476,y:713,t:1528143866297};\\\", \\\"{x:476,y:714,t:1528143866305};\\\", \\\"{x:474,y:715,t:1528143866319};\\\", \\\"{x:473,y:718,t:1528143866335};\\\", \\\"{x:472,y:719,t:1528143866352};\\\", \\\"{x:470,y:722,t:1528143866369};\\\", \\\"{x:469,y:723,t:1528143866385};\\\", \\\"{x:468,y:724,t:1528143866401};\\\", \\\"{x:467,y:724,t:1528143866418};\\\", \\\"{x:467,y:725,t:1528143866553};\\\", \\\"{x:467,y:725,t:1528143866621};\\\", \\\"{x:468,y:726,t:1528143866883};\\\" ] }, { \\\"rt\\\": 10764, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 899446, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -G -08 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:467,y:726,t:1528143868425};\\\", \\\"{x:465,y:725,t:1528143868436};\\\", \\\"{x:461,y:721,t:1528143868454};\\\", \\\"{x:456,y:708,t:1528143868471};\\\", \\\"{x:447,y:699,t:1528143868488};\\\", \\\"{x:443,y:688,t:1528143868504};\\\", \\\"{x:440,y:677,t:1528143868519};\\\", \\\"{x:437,y:662,t:1528143868537};\\\", \\\"{x:436,y:630,t:1528143868554};\\\", \\\"{x:439,y:602,t:1528143868569};\\\", \\\"{x:444,y:584,t:1528143868587};\\\", \\\"{x:451,y:564,t:1528143868603};\\\", \\\"{x:456,y:544,t:1528143868620};\\\", \\\"{x:460,y:526,t:1528143868636};\\\", \\\"{x:463,y:513,t:1528143868654};\\\", \\\"{x:465,y:508,t:1528143868669};\\\", \\\"{x:465,y:504,t:1528143868687};\\\", \\\"{x:465,y:500,t:1528143868703};\\\", \\\"{x:466,y:490,t:1528143868719};\\\", \\\"{x:469,y:476,t:1528143868737};\\\", \\\"{x:474,y:447,t:1528143868754};\\\", \\\"{x:477,y:434,t:1528143868770};\\\", \\\"{x:483,y:424,t:1528143868786};\\\", \\\"{x:490,y:416,t:1528143868803};\\\", \\\"{x:498,y:409,t:1528143868821};\\\", \\\"{x:506,y:404,t:1528143868837};\\\", \\\"{x:510,y:402,t:1528143868853};\\\", \\\"{x:513,y:401,t:1528143869131};\\\", \\\"{x:529,y:399,t:1528143869139};\\\", \\\"{x:612,y:386,t:1528143869154};\\\", \\\"{x:710,y:366,t:1528143869171};\\\", \\\"{x:781,y:352,t:1528143869188};\\\", \\\"{x:829,y:345,t:1528143869203};\\\", \\\"{x:868,y:333,t:1528143869221};\\\", \\\"{x:894,y:329,t:1528143869238};\\\", \\\"{x:926,y:328,t:1528143869253};\\\", \\\"{x:956,y:328,t:1528143869271};\\\", \\\"{x:1008,y:330,t:1528143869288};\\\", \\\"{x:1055,y:344,t:1528143869305};\\\", \\\"{x:1097,y:359,t:1528143869321};\\\", \\\"{x:1141,y:378,t:1528143869338};\\\", \\\"{x:1163,y:387,t:1528143869354};\\\", \\\"{x:1179,y:397,t:1528143869371};\\\", \\\"{x:1197,y:408,t:1528143869388};\\\", \\\"{x:1219,y:422,t:1528143869405};\\\", \\\"{x:1239,y:430,t:1528143869421};\\\", \\\"{x:1251,y:434,t:1528143869438};\\\", \\\"{x:1254,y:435,t:1528143869454};\\\", \\\"{x:1255,y:435,t:1528143869471};\\\", \\\"{x:1257,y:435,t:1528143869488};\\\", \\\"{x:1258,y:435,t:1528143869505};\\\", \\\"{x:1261,y:435,t:1528143869522};\\\", \\\"{x:1272,y:434,t:1528143869538};\\\", \\\"{x:1288,y:430,t:1528143869555};\\\", \\\"{x:1298,y:427,t:1528143869573};\\\", \\\"{x:1315,y:422,t:1528143869588};\\\", \\\"{x:1336,y:417,t:1528143869605};\\\", \\\"{x:1358,y:413,t:1528143869622};\\\", \\\"{x:1373,y:410,t:1528143869638};\\\", \\\"{x:1381,y:406,t:1528143869655};\\\", \\\"{x:1389,y:403,t:1528143869671};\\\", \\\"{x:1393,y:403,t:1528143870002};\\\", \\\"{x:1394,y:416,t:1528143870010};\\\", \\\"{x:1395,y:433,t:1528143870022};\\\", \\\"{x:1405,y:471,t:1528143870039};\\\", \\\"{x:1414,y:498,t:1528143870056};\\\", \\\"{x:1425,y:526,t:1528143870072};\\\", \\\"{x:1442,y:561,t:1528143870089};\\\", \\\"{x:1461,y:608,t:1528143870106};\\\", \\\"{x:1473,y:645,t:1528143870122};\\\", \\\"{x:1479,y:670,t:1528143870139};\\\", \\\"{x:1482,y:694,t:1528143870157};\\\", \\\"{x:1484,y:712,t:1528143870172};\\\", \\\"{x:1486,y:725,t:1528143870189};\\\", \\\"{x:1486,y:734,t:1528143870206};\\\", \\\"{x:1486,y:740,t:1528143870223};\\\", \\\"{x:1485,y:746,t:1528143870239};\\\", \\\"{x:1482,y:750,t:1528143870256};\\\", \\\"{x:1479,y:752,t:1528143870272};\\\", \\\"{x:1476,y:752,t:1528143870288};\\\", \\\"{x:1472,y:752,t:1528143870305};\\\", \\\"{x:1469,y:752,t:1528143870322};\\\", \\\"{x:1465,y:750,t:1528143870339};\\\", \\\"{x:1459,y:746,t:1528143870355};\\\", \\\"{x:1450,y:738,t:1528143870372};\\\", \\\"{x:1442,y:727,t:1528143870389};\\\", \\\"{x:1438,y:722,t:1528143870406};\\\", \\\"{x:1432,y:715,t:1528143870423};\\\", \\\"{x:1413,y:701,t:1528143870440};\\\", \\\"{x:1394,y:691,t:1528143870456};\\\", \\\"{x:1379,y:685,t:1528143870473};\\\", \\\"{x:1375,y:683,t:1528143870489};\\\", \\\"{x:1373,y:683,t:1528143870595};\\\", \\\"{x:1366,y:685,t:1528143870606};\\\", \\\"{x:1359,y:690,t:1528143870623};\\\", \\\"{x:1359,y:691,t:1528143870658};\\\", \\\"{x:1358,y:693,t:1528143870672};\\\", \\\"{x:1356,y:694,t:1528143870690};\\\", \\\"{x:1355,y:696,t:1528143870707};\\\", \\\"{x:1354,y:696,t:1528143870723};\\\", \\\"{x:1353,y:696,t:1528143870742};\\\", \\\"{x:1352,y:697,t:1528143871090};\\\", \\\"{x:1351,y:697,t:1528143871122};\\\", \\\"{x:1349,y:697,t:1528143871130};\\\", \\\"{x:1347,y:697,t:1528143871141};\\\", \\\"{x:1346,y:697,t:1528143871157};\\\", \\\"{x:1345,y:697,t:1528143871174};\\\", \\\"{x:1344,y:698,t:1528143871191};\\\", \\\"{x:1343,y:698,t:1528143871207};\\\", \\\"{x:1341,y:698,t:1528143871225};\\\", \\\"{x:1340,y:698,t:1528143871314};\\\", \\\"{x:1338,y:698,t:1528143871409};\\\", \\\"{x:1337,y:698,t:1528143871506};\\\", \\\"{x:1337,y:697,t:1528143871555};\\\", \\\"{x:1335,y:697,t:1528143871610};\\\", \\\"{x:1334,y:697,t:1528143871635};\\\", \\\"{x:1333,y:696,t:1528143871643};\\\", \\\"{x:1331,y:695,t:1528143871659};\\\", \\\"{x:1330,y:694,t:1528143871674};\\\", \\\"{x:1328,y:694,t:1528143871691};\\\", \\\"{x:1327,y:693,t:1528143871891};\\\", \\\"{x:1328,y:692,t:1528143871906};\\\", \\\"{x:1330,y:691,t:1528143871914};\\\", \\\"{x:1331,y:691,t:1528143871930};\\\", \\\"{x:1334,y:690,t:1528143871942};\\\", \\\"{x:1337,y:688,t:1528143871959};\\\", \\\"{x:1339,y:687,t:1528143871975};\\\", \\\"{x:1340,y:687,t:1528143872010};\\\", \\\"{x:1341,y:687,t:1528143872289};\\\", \\\"{x:1341,y:686,t:1528143872297};\\\", \\\"{x:1342,y:685,t:1528143872309};\\\", \\\"{x:1345,y:683,t:1528143872325};\\\", \\\"{x:1349,y:680,t:1528143872341};\\\", \\\"{x:1350,y:676,t:1528143872358};\\\", \\\"{x:1354,y:668,t:1528143872376};\\\", \\\"{x:1359,y:658,t:1528143872392};\\\", \\\"{x:1362,y:648,t:1528143872409};\\\", \\\"{x:1372,y:625,t:1528143872426};\\\", \\\"{x:1375,y:612,t:1528143872443};\\\", \\\"{x:1379,y:601,t:1528143872459};\\\", \\\"{x:1382,y:592,t:1528143872476};\\\", \\\"{x:1384,y:586,t:1528143872493};\\\", \\\"{x:1386,y:581,t:1528143872509};\\\", \\\"{x:1390,y:573,t:1528143872526};\\\", \\\"{x:1394,y:568,t:1528143872542};\\\", \\\"{x:1396,y:562,t:1528143872559};\\\", \\\"{x:1399,y:556,t:1528143872576};\\\", \\\"{x:1402,y:549,t:1528143872592};\\\", \\\"{x:1404,y:545,t:1528143872608};\\\", \\\"{x:1413,y:533,t:1528143872626};\\\", \\\"{x:1417,y:527,t:1528143872643};\\\", \\\"{x:1422,y:519,t:1528143872660};\\\", \\\"{x:1425,y:516,t:1528143872675};\\\", \\\"{x:1426,y:514,t:1528143872693};\\\", \\\"{x:1427,y:514,t:1528143872710};\\\", \\\"{x:1427,y:513,t:1528143872726};\\\", \\\"{x:1428,y:512,t:1528143872826};\\\", \\\"{x:1429,y:512,t:1528143872898};\\\", \\\"{x:1431,y:513,t:1528143872910};\\\", \\\"{x:1435,y:515,t:1528143872928};\\\", \\\"{x:1436,y:516,t:1528143872943};\\\", \\\"{x:1437,y:516,t:1528143872971};\\\", \\\"{x:1438,y:517,t:1528143872994};\\\", \\\"{x:1438,y:518,t:1528143873026};\\\", \\\"{x:1438,y:520,t:1528143873050};\\\", \\\"{x:1434,y:529,t:1528143873060};\\\", \\\"{x:1426,y:538,t:1528143873077};\\\", \\\"{x:1416,y:545,t:1528143873095};\\\", \\\"{x:1409,y:547,t:1528143873111};\\\", \\\"{x:1403,y:551,t:1528143873127};\\\", \\\"{x:1399,y:552,t:1528143873144};\\\", \\\"{x:1396,y:552,t:1528143873160};\\\", \\\"{x:1394,y:553,t:1528143873178};\\\", \\\"{x:1400,y:551,t:1528143873282};\\\", \\\"{x:1403,y:548,t:1528143873294};\\\", \\\"{x:1412,y:542,t:1528143873310};\\\", \\\"{x:1415,y:539,t:1528143873327};\\\", \\\"{x:1416,y:539,t:1528143873344};\\\", \\\"{x:1417,y:539,t:1528143873361};\\\", \\\"{x:1418,y:538,t:1528143873377};\\\", \\\"{x:1419,y:538,t:1528143873531};\\\", \\\"{x:1420,y:538,t:1528143873544};\\\", \\\"{x:1423,y:539,t:1528143873561};\\\", \\\"{x:1424,y:540,t:1528143873586};\\\", \\\"{x:1425,y:540,t:1528143873611};\\\", \\\"{x:1425,y:541,t:1528143873629};\\\", \\\"{x:1420,y:546,t:1528143873795};\\\", \\\"{x:1406,y:566,t:1528143873812};\\\", \\\"{x:1398,y:580,t:1528143873829};\\\", \\\"{x:1388,y:597,t:1528143873845};\\\", \\\"{x:1377,y:615,t:1528143873861};\\\", \\\"{x:1366,y:635,t:1528143873878};\\\", \\\"{x:1354,y:653,t:1528143873895};\\\", \\\"{x:1342,y:669,t:1528143873911};\\\", \\\"{x:1329,y:687,t:1528143873929};\\\", \\\"{x:1315,y:704,t:1528143873945};\\\", \\\"{x:1305,y:716,t:1528143873961};\\\", \\\"{x:1297,y:727,t:1528143873978};\\\", \\\"{x:1294,y:730,t:1528143873995};\\\", \\\"{x:1293,y:730,t:1528143874012};\\\", \\\"{x:1292,y:731,t:1528143874034};\\\", \\\"{x:1292,y:732,t:1528143874091};\\\", \\\"{x:1291,y:732,t:1528143874107};\\\", \\\"{x:1289,y:732,t:1528143874114};\\\", \\\"{x:1286,y:732,t:1528143874128};\\\", \\\"{x:1272,y:725,t:1528143874146};\\\", \\\"{x:1214,y:696,t:1528143874163};\\\", \\\"{x:1149,y:664,t:1528143874178};\\\", \\\"{x:1023,y:615,t:1528143874196};\\\", \\\"{x:885,y:554,t:1528143874214};\\\", \\\"{x:776,y:515,t:1528143874229};\\\", \\\"{x:684,y:485,t:1528143874245};\\\", \\\"{x:562,y:448,t:1528143874272};\\\", \\\"{x:535,y:440,t:1528143874288};\\\", \\\"{x:523,y:437,t:1528143874304};\\\", \\\"{x:496,y:431,t:1528143874321};\\\", \\\"{x:481,y:428,t:1528143874338};\\\", \\\"{x:476,y:426,t:1528143874355};\\\", \\\"{x:474,y:426,t:1528143874394};\\\", \\\"{x:474,y:427,t:1528143874425};\\\", \\\"{x:473,y:429,t:1528143874437};\\\", \\\"{x:465,y:446,t:1528143874454};\\\", \\\"{x:460,y:471,t:1528143874472};\\\", \\\"{x:462,y:497,t:1528143874490};\\\", \\\"{x:470,y:512,t:1528143874505};\\\", \\\"{x:476,y:519,t:1528143874525};\\\", \\\"{x:484,y:525,t:1528143874542};\\\", \\\"{x:497,y:532,t:1528143874558};\\\", \\\"{x:505,y:539,t:1528143874575};\\\", \\\"{x:508,y:539,t:1528143874592};\\\", \\\"{x:510,y:540,t:1528143874608};\\\", \\\"{x:511,y:541,t:1528143874625};\\\", \\\"{x:513,y:541,t:1528143874641};\\\", \\\"{x:515,y:541,t:1528143874658};\\\", \\\"{x:516,y:541,t:1528143874675};\\\", \\\"{x:518,y:541,t:1528143874745};\\\", \\\"{x:519,y:541,t:1528143874758};\\\", \\\"{x:521,y:541,t:1528143874774};\\\", \\\"{x:526,y:541,t:1528143874791};\\\", \\\"{x:533,y:541,t:1528143874807};\\\", \\\"{x:543,y:537,t:1528143874824};\\\", \\\"{x:553,y:531,t:1528143874842};\\\", \\\"{x:561,y:523,t:1528143874859};\\\", \\\"{x:569,y:512,t:1528143874875};\\\", \\\"{x:576,y:504,t:1528143874892};\\\", \\\"{x:583,y:498,t:1528143874907};\\\", \\\"{x:587,y:494,t:1528143874925};\\\", \\\"{x:591,y:492,t:1528143874942};\\\", \\\"{x:592,y:492,t:1528143874970};\\\", \\\"{x:594,y:492,t:1528143875066};\\\", \\\"{x:597,y:492,t:1528143875075};\\\", \\\"{x:604,y:494,t:1528143875093};\\\", \\\"{x:611,y:497,t:1528143875108};\\\", \\\"{x:615,y:499,t:1528143875124};\\\", \\\"{x:618,y:500,t:1528143875141};\\\", \\\"{x:620,y:501,t:1528143875158};\\\", \\\"{x:625,y:502,t:1528143875175};\\\", \\\"{x:640,y:503,t:1528143875191};\\\", \\\"{x:659,y:503,t:1528143875209};\\\", \\\"{x:670,y:503,t:1528143875224};\\\", \\\"{x:674,y:503,t:1528143875241};\\\", \\\"{x:678,y:503,t:1528143875259};\\\", \\\"{x:685,y:503,t:1528143875275};\\\", \\\"{x:690,y:501,t:1528143875292};\\\", \\\"{x:697,y:500,t:1528143875309};\\\", \\\"{x:705,y:497,t:1528143875325};\\\", \\\"{x:710,y:496,t:1528143875342};\\\", \\\"{x:714,y:494,t:1528143875359};\\\", \\\"{x:714,y:493,t:1528143875375};\\\", \\\"{x:720,y:493,t:1528143875392};\\\", \\\"{x:725,y:491,t:1528143875410};\\\", \\\"{x:733,y:489,t:1528143875425};\\\", \\\"{x:753,y:485,t:1528143875442};\\\", \\\"{x:772,y:483,t:1528143875459};\\\", \\\"{x:784,y:482,t:1528143875474};\\\", \\\"{x:789,y:480,t:1528143875491};\\\", \\\"{x:790,y:480,t:1528143875509};\\\", \\\"{x:800,y:479,t:1528143875526};\\\", \\\"{x:815,y:479,t:1528143875542};\\\", \\\"{x:827,y:479,t:1528143875558};\\\", \\\"{x:833,y:480,t:1528143875575};\\\", \\\"{x:834,y:481,t:1528143875591};\\\", \\\"{x:837,y:481,t:1528143875634};\\\", \\\"{x:842,y:481,t:1528143875642};\\\", \\\"{x:849,y:486,t:1528143875659};\\\", \\\"{x:850,y:488,t:1528143875691};\\\", \\\"{x:850,y:489,t:1528143875713};\\\", \\\"{x:850,y:491,t:1528143875726};\\\", \\\"{x:851,y:492,t:1528143875741};\\\", \\\"{x:851,y:493,t:1528143875819};\\\", \\\"{x:850,y:493,t:1528143875834};\\\", \\\"{x:849,y:494,t:1528143875842};\\\", \\\"{x:848,y:497,t:1528143876089};\\\", \\\"{x:848,y:499,t:1528143876097};\\\", \\\"{x:848,y:501,t:1528143876109};\\\", \\\"{x:846,y:506,t:1528143876126};\\\", \\\"{x:844,y:512,t:1528143876143};\\\", \\\"{x:842,y:518,t:1528143876184};\\\", \\\"{x:841,y:519,t:1528143876209};\\\", \\\"{x:839,y:524,t:1528143876225};\\\", \\\"{x:838,y:525,t:1528143876243};\\\", \\\"{x:838,y:526,t:1528143876259};\\\", \\\"{x:838,y:528,t:1528143876276};\\\", \\\"{x:837,y:528,t:1528143876292};\\\", \\\"{x:836,y:530,t:1528143876337};\\\", \\\"{x:835,y:531,t:1528143876353};\\\", \\\"{x:834,y:532,t:1528143876362};\\\", \\\"{x:834,y:534,t:1528143876376};\\\", \\\"{x:832,y:537,t:1528143876393};\\\", \\\"{x:830,y:539,t:1528143876410};\\\", \\\"{x:829,y:540,t:1528143876482};\\\", \\\"{x:831,y:542,t:1528143876762};\\\", \\\"{x:844,y:547,t:1528143876778};\\\", \\\"{x:929,y:598,t:1528143876818};\\\", \\\"{x:949,y:614,t:1528143876827};\\\", \\\"{x:992,y:655,t:1528143876843};\\\", \\\"{x:1029,y:694,t:1528143876859};\\\", \\\"{x:1058,y:732,t:1528143876877};\\\", \\\"{x:1085,y:776,t:1528143876892};\\\", \\\"{x:1112,y:824,t:1528143876910};\\\", \\\"{x:1153,y:893,t:1528143876927};\\\", \\\"{x:1204,y:988,t:1528143876942};\\\", \\\"{x:1249,y:1060,t:1528143876960};\\\", \\\"{x:1276,y:1099,t:1528143876977};\\\", \\\"{x:1286,y:1115,t:1528143876992};\\\", \\\"{x:1292,y:1128,t:1528143877009};\\\", \\\"{x:1293,y:1131,t:1528143877027};\\\", \\\"{x:1293,y:1133,t:1528143877042};\\\", \\\"{x:1293,y:1135,t:1528143877060};\\\", \\\"{x:1293,y:1136,t:1528143877077};\\\", \\\"{x:1291,y:1137,t:1528143877093};\\\", \\\"{x:1287,y:1137,t:1528143877110};\\\", \\\"{x:1285,y:1138,t:1528143877127};\\\", \\\"{x:1285,y:1139,t:1528143877143};\\\", \\\"{x:1284,y:1139,t:1528143877170};\\\", \\\"{x:1283,y:1139,t:1528143877194};\\\", \\\"{x:1279,y:1137,t:1528143877210};\\\", \\\"{x:1266,y:1122,t:1528143877227};\\\", \\\"{x:1247,y:1095,t:1528143877243};\\\", \\\"{x:1239,y:1077,t:1528143877260};\\\", \\\"{x:1237,y:1073,t:1528143877277};\\\", \\\"{x:1236,y:1069,t:1528143877293};\\\", \\\"{x:1236,y:1067,t:1528143877310};\\\", \\\"{x:1234,y:1064,t:1528143877327};\\\", \\\"{x:1233,y:1063,t:1528143877343};\\\", \\\"{x:1232,y:1062,t:1528143877522};\\\", \\\"{x:1232,y:1061,t:1528143877554};\\\", \\\"{x:1231,y:1061,t:1528143877562};\\\", \\\"{x:1230,y:1060,t:1528143877578};\\\", \\\"{x:1228,y:1059,t:1528143877594};\\\", \\\"{x:1218,y:1055,t:1528143877610};\\\", \\\"{x:1208,y:1050,t:1528143877628};\\\", \\\"{x:1193,y:1044,t:1528143877644};\\\", \\\"{x:1175,y:1033,t:1528143877659};\\\", \\\"{x:1159,y:1023,t:1528143877676};\\\", \\\"{x:1148,y:1014,t:1528143877694};\\\", \\\"{x:1140,y:1007,t:1528143877709};\\\", \\\"{x:1135,y:1002,t:1528143877726};\\\", \\\"{x:1132,y:998,t:1528143877744};\\\", \\\"{x:1128,y:994,t:1528143877760};\\\", \\\"{x:1108,y:984,t:1528143877777};\\\", \\\"{x:1083,y:972,t:1528143877793};\\\", \\\"{x:1042,y:956,t:1528143877811};\\\", \\\"{x:971,y:927,t:1528143877827};\\\", \\\"{x:882,y:900,t:1528143877844};\\\", \\\"{x:793,y:873,t:1528143877860};\\\", \\\"{x:721,y:853,t:1528143877876};\\\", \\\"{x:651,y:833,t:1528143877894};\\\", \\\"{x:583,y:818,t:1528143877911};\\\", \\\"{x:516,y:798,t:1528143877928};\\\", \\\"{x:461,y:784,t:1528143877945};\\\", \\\"{x:402,y:776,t:1528143877960};\\\", \\\"{x:369,y:771,t:1528143877977};\\\", \\\"{x:353,y:771,t:1528143877994};\\\", \\\"{x:351,y:771,t:1528143878010};\\\", \\\"{x:350,y:771,t:1528143878027};\\\", \\\"{x:351,y:771,t:1528143878098};\\\", \\\"{x:354,y:768,t:1528143878110};\\\", \\\"{x:362,y:764,t:1528143878127};\\\", \\\"{x:382,y:754,t:1528143878144};\\\", \\\"{x:420,y:736,t:1528143878161};\\\", \\\"{x:443,y:723,t:1528143878178};\\\", \\\"{x:459,y:717,t:1528143878194};\\\", \\\"{x:462,y:717,t:1528143878211};\\\", \\\"{x:464,y:717,t:1528143878227};\\\", \\\"{x:466,y:717,t:1528143878244};\\\", \\\"{x:468,y:718,t:1528143878261};\\\", \\\"{x:470,y:720,t:1528143878316};\\\", \\\"{x:472,y:720,t:1528143878327};\\\", \\\"{x:476,y:722,t:1528143878344};\\\", \\\"{x:480,y:723,t:1528143878360};\\\", \\\"{x:484,y:726,t:1528143878425};\\\", \\\"{x:486,y:727,t:1528143878443};\\\", \\\"{x:489,y:729,t:1528143878460};\\\", \\\"{x:490,y:733,t:1528143878476};\\\", \\\"{x:490,y:735,t:1528143878492};\\\", \\\"{x:489,y:736,t:1528143879744};\\\", \\\"{x:496,y:736,t:1528143879760};\\\", \\\"{x:502,y:736,t:1528143879777};\\\", \\\"{x:503,y:736,t:1528143879793};\\\" ] }, { \\\"rt\\\": 12936, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 913675, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:697,t:1528143879970};\\\", \\\"{x:542,y:693,t:1528143879978};\\\", \\\"{x:542,y:692,t:1528143879996};\\\", \\\"{x:542,y:690,t:1528143880010};\\\", \\\"{x:542,y:689,t:1528143880027};\\\", \\\"{x:542,y:686,t:1528143880044};\\\", \\\"{x:542,y:684,t:1528143880062};\\\", \\\"{x:542,y:683,t:1528143880079};\\\", \\\"{x:541,y:683,t:1528143880094};\\\", \\\"{x:541,y:682,t:1528143880111};\\\", \\\"{x:539,y:682,t:1528143880280};\\\", \\\"{x:538,y:682,t:1528143880295};\\\", \\\"{x:536,y:689,t:1528143880390};\\\", \\\"{x:535,y:689,t:1528143880403};\\\", \\\"{x:535,y:691,t:1528143880511};\\\", \\\"{x:536,y:691,t:1528143880527};\\\", \\\"{x:537,y:691,t:1528143880544};\\\", \\\"{x:538,y:691,t:1528143880824};\\\", \\\"{x:538,y:690,t:1528143880833};\\\", \\\"{x:538,y:687,t:1528143880845};\\\", \\\"{x:536,y:679,t:1528143880862};\\\", \\\"{x:534,y:669,t:1528143880879};\\\", \\\"{x:533,y:663,t:1528143880895};\\\", \\\"{x:530,y:655,t:1528143880911};\\\", \\\"{x:529,y:650,t:1528143880928};\\\", \\\"{x:528,y:646,t:1528143880944};\\\", \\\"{x:528,y:643,t:1528143880961};\\\", \\\"{x:525,y:640,t:1528143880979};\\\", \\\"{x:522,y:638,t:1528143880994};\\\", \\\"{x:514,y:635,t:1528143881012};\\\", \\\"{x:505,y:630,t:1528143881030};\\\", \\\"{x:495,y:626,t:1528143881045};\\\", \\\"{x:483,y:621,t:1528143881062};\\\", \\\"{x:466,y:614,t:1528143881078};\\\", \\\"{x:431,y:597,t:1528143881097};\\\", \\\"{x:411,y:581,t:1528143881112};\\\", \\\"{x:393,y:563,t:1528143881128};\\\", \\\"{x:374,y:547,t:1528143881146};\\\", \\\"{x:357,y:535,t:1528143881161};\\\", \\\"{x:346,y:526,t:1528143881179};\\\", \\\"{x:341,y:521,t:1528143881196};\\\", \\\"{x:332,y:517,t:1528143881212};\\\", \\\"{x:329,y:517,t:1528143881229};\\\", \\\"{x:327,y:517,t:1528143881245};\\\", \\\"{x:326,y:517,t:1528143881272};\\\", \\\"{x:327,y:519,t:1528143881288};\\\", \\\"{x:329,y:520,t:1528143881295};\\\", \\\"{x:329,y:521,t:1528143881311};\\\", \\\"{x:330,y:521,t:1528143881368};\\\", \\\"{x:331,y:521,t:1528143881384};\\\", \\\"{x:334,y:521,t:1528143881395};\\\", \\\"{x:376,y:521,t:1528143881411};\\\", \\\"{x:456,y:530,t:1528143881428};\\\", \\\"{x:477,y:532,t:1528143881444};\\\", \\\"{x:483,y:533,t:1528143881462};\\\", \\\"{x:484,y:533,t:1528143881488};\\\", \\\"{x:485,y:533,t:1528143881504};\\\", \\\"{x:486,y:533,t:1528143881513};\\\", \\\"{x:487,y:533,t:1528143881536};\\\", \\\"{x:488,y:533,t:1528143881552};\\\", \\\"{x:489,y:533,t:1528143881563};\\\", \\\"{x:491,y:533,t:1528143881579};\\\", \\\"{x:493,y:533,t:1528143881595};\\\", \\\"{x:494,y:533,t:1528143881613};\\\", \\\"{x:495,y:532,t:1528143881629};\\\", \\\"{x:496,y:532,t:1528143884064};\\\", \\\"{x:499,y:530,t:1528143884107};\\\", \\\"{x:508,y:525,t:1528143884117};\\\", \\\"{x:556,y:517,t:1528143884134};\\\", \\\"{x:636,y:506,t:1528143884149};\\\", \\\"{x:723,y:493,t:1528143884164};\\\", \\\"{x:832,y:489,t:1528143884181};\\\", \\\"{x:940,y:489,t:1528143884197};\\\", \\\"{x:1048,y:489,t:1528143884214};\\\", \\\"{x:1150,y:489,t:1528143884230};\\\", \\\"{x:1331,y:508,t:1528143884248};\\\", \\\"{x:1450,y:525,t:1528143884264};\\\", \\\"{x:1552,y:537,t:1528143884280};\\\", \\\"{x:1635,y:548,t:1528143884297};\\\", \\\"{x:1691,y:554,t:1528143884313};\\\", \\\"{x:1721,y:558,t:1528143884331};\\\", \\\"{x:1738,y:560,t:1528143884347};\\\", \\\"{x:1741,y:560,t:1528143884363};\\\", \\\"{x:1742,y:561,t:1528143884381};\\\", \\\"{x:1743,y:561,t:1528143884441};\\\", \\\"{x:1741,y:568,t:1528143884448};\\\", \\\"{x:1728,y:592,t:1528143884464};\\\", \\\"{x:1711,y:624,t:1528143884480};\\\", \\\"{x:1696,y:654,t:1528143884498};\\\", \\\"{x:1682,y:677,t:1528143884514};\\\", \\\"{x:1670,y:689,t:1528143884531};\\\", \\\"{x:1667,y:693,t:1528143884547};\\\", \\\"{x:1664,y:697,t:1528143884564};\\\", \\\"{x:1661,y:700,t:1528143884581};\\\", \\\"{x:1658,y:704,t:1528143884596};\\\", \\\"{x:1654,y:706,t:1528143884613};\\\", \\\"{x:1653,y:707,t:1528143884630};\\\", \\\"{x:1652,y:707,t:1528143884646};\\\", \\\"{x:1650,y:707,t:1528143884664};\\\", \\\"{x:1649,y:707,t:1528143884681};\\\", \\\"{x:1648,y:707,t:1528143884703};\\\", \\\"{x:1647,y:707,t:1528143884760};\\\", \\\"{x:1645,y:707,t:1528143884768};\\\", \\\"{x:1642,y:705,t:1528143884781};\\\", \\\"{x:1639,y:703,t:1528143884796};\\\", \\\"{x:1629,y:696,t:1528143884814};\\\", \\\"{x:1617,y:676,t:1528143884830};\\\", \\\"{x:1597,y:642,t:1528143884847};\\\", \\\"{x:1573,y:599,t:1528143884864};\\\", \\\"{x:1557,y:562,t:1528143884880};\\\", \\\"{x:1542,y:522,t:1528143884897};\\\", \\\"{x:1529,y:490,t:1528143884914};\\\", \\\"{x:1526,y:474,t:1528143884930};\\\", \\\"{x:1526,y:461,t:1528143884947};\\\", \\\"{x:1535,y:423,t:1528143884964};\\\", \\\"{x:1549,y:378,t:1528143884980};\\\", \\\"{x:1558,y:355,t:1528143884997};\\\", \\\"{x:1561,y:348,t:1528143885014};\\\", \\\"{x:1563,y:346,t:1528143885029};\\\", \\\"{x:1563,y:344,t:1528143885056};\\\", \\\"{x:1562,y:343,t:1528143885072};\\\", \\\"{x:1561,y:342,t:1528143885079};\\\", \\\"{x:1560,y:339,t:1528143885096};\\\", \\\"{x:1559,y:338,t:1528143885113};\\\", \\\"{x:1559,y:337,t:1528143885130};\\\", \\\"{x:1558,y:337,t:1528143885457};\\\", \\\"{x:1556,y:340,t:1528143885464};\\\", \\\"{x:1554,y:342,t:1528143885480};\\\", \\\"{x:1554,y:343,t:1528143885498};\\\", \\\"{x:1554,y:344,t:1528143885552};\\\", \\\"{x:1554,y:345,t:1528143885616};\\\", \\\"{x:1554,y:347,t:1528143885629};\\\", \\\"{x:1556,y:351,t:1528143885646};\\\", \\\"{x:1557,y:354,t:1528143885663};\\\", \\\"{x:1559,y:357,t:1528143885680};\\\", \\\"{x:1565,y:365,t:1528143885696};\\\", \\\"{x:1577,y:380,t:1528143885713};\\\", \\\"{x:1591,y:397,t:1528143885730};\\\", \\\"{x:1603,y:414,t:1528143885746};\\\", \\\"{x:1611,y:428,t:1528143885763};\\\", \\\"{x:1619,y:442,t:1528143885780};\\\", \\\"{x:1625,y:452,t:1528143885796};\\\", \\\"{x:1633,y:465,t:1528143885813};\\\", \\\"{x:1640,y:481,t:1528143885829};\\\", \\\"{x:1649,y:499,t:1528143885846};\\\", \\\"{x:1659,y:518,t:1528143885862};\\\", \\\"{x:1665,y:532,t:1528143885879};\\\", \\\"{x:1671,y:544,t:1528143885896};\\\", \\\"{x:1676,y:556,t:1528143885913};\\\", \\\"{x:1684,y:572,t:1528143885929};\\\", \\\"{x:1691,y:582,t:1528143885946};\\\", \\\"{x:1692,y:589,t:1528143885963};\\\", \\\"{x:1693,y:594,t:1528143885979};\\\", \\\"{x:1694,y:596,t:1528143885996};\\\", \\\"{x:1693,y:596,t:1528143886137};\\\", \\\"{x:1690,y:595,t:1528143886146};\\\", \\\"{x:1677,y:588,t:1528143886162};\\\", \\\"{x:1669,y:583,t:1528143886179};\\\", \\\"{x:1661,y:580,t:1528143886196};\\\", \\\"{x:1658,y:578,t:1528143886212};\\\", \\\"{x:1658,y:577,t:1528143886229};\\\", \\\"{x:1658,y:576,t:1528143886273};\\\", \\\"{x:1658,y:575,t:1528143886337};\\\", \\\"{x:1658,y:573,t:1528143886377};\\\", \\\"{x:1657,y:573,t:1528143886825};\\\", \\\"{x:1652,y:583,t:1528143886833};\\\", \\\"{x:1649,y:592,t:1528143886845};\\\", \\\"{x:1644,y:605,t:1528143886862};\\\", \\\"{x:1639,y:619,t:1528143886879};\\\", \\\"{x:1639,y:627,t:1528143886895};\\\", \\\"{x:1639,y:632,t:1528143886913};\\\", \\\"{x:1637,y:637,t:1528143886928};\\\", \\\"{x:1636,y:647,t:1528143886945};\\\", \\\"{x:1634,y:661,t:1528143886962};\\\", \\\"{x:1632,y:678,t:1528143886978};\\\", \\\"{x:1631,y:688,t:1528143886994};\\\", \\\"{x:1631,y:693,t:1528143887012};\\\", \\\"{x:1631,y:694,t:1528143887028};\\\", \\\"{x:1630,y:695,t:1528143887044};\\\", \\\"{x:1630,y:698,t:1528143887062};\\\", \\\"{x:1629,y:701,t:1528143887077};\\\", \\\"{x:1628,y:708,t:1528143887095};\\\", \\\"{x:1626,y:712,t:1528143887111};\\\", \\\"{x:1624,y:720,t:1528143887128};\\\", \\\"{x:1624,y:721,t:1528143887144};\\\", \\\"{x:1624,y:722,t:1528143887161};\\\", \\\"{x:1624,y:723,t:1528143887178};\\\", \\\"{x:1623,y:724,t:1528143887195};\\\", \\\"{x:1622,y:725,t:1528143887210};\\\", \\\"{x:1621,y:725,t:1528143887264};\\\", \\\"{x:1621,y:724,t:1528143887280};\\\", \\\"{x:1621,y:723,t:1528143887304};\\\", \\\"{x:1621,y:722,t:1528143887321};\\\", \\\"{x:1621,y:721,t:1528143887345};\\\", \\\"{x:1621,y:720,t:1528143887433};\\\", \\\"{x:1621,y:719,t:1528143887444};\\\", \\\"{x:1621,y:716,t:1528143887461};\\\", \\\"{x:1619,y:713,t:1528143887478};\\\", \\\"{x:1619,y:711,t:1528143887513};\\\", \\\"{x:1619,y:709,t:1528143887529};\\\", \\\"{x:1619,y:707,t:1528143887545};\\\", \\\"{x:1618,y:706,t:1528143887562};\\\", \\\"{x:1618,y:704,t:1528143887579};\\\", \\\"{x:1618,y:703,t:1528143887737};\\\", \\\"{x:1618,y:701,t:1528143887820};\\\", \\\"{x:1617,y:700,t:1528143887952};\\\", \\\"{x:1617,y:698,t:1528143887960};\\\", \\\"{x:1617,y:697,t:1528143887985};\\\", \\\"{x:1616,y:696,t:1528143888008};\\\", \\\"{x:1615,y:694,t:1528143888032};\\\", \\\"{x:1615,y:693,t:1528143888137};\\\", \\\"{x:1613,y:693,t:1528143888248};\\\", \\\"{x:1612,y:695,t:1528143888261};\\\", \\\"{x:1611,y:698,t:1528143888277};\\\", \\\"{x:1609,y:701,t:1528143888296};\\\", \\\"{x:1608,y:706,t:1528143888310};\\\", \\\"{x:1607,y:711,t:1528143888328};\\\", \\\"{x:1603,y:718,t:1528143888344};\\\", \\\"{x:1602,y:721,t:1528143888360};\\\", \\\"{x:1600,y:724,t:1528143888377};\\\", \\\"{x:1600,y:727,t:1528143888394};\\\", \\\"{x:1597,y:731,t:1528143888411};\\\", \\\"{x:1597,y:735,t:1528143888428};\\\", \\\"{x:1595,y:743,t:1528143888443};\\\", \\\"{x:1593,y:749,t:1528143888460};\\\", \\\"{x:1589,y:760,t:1528143888478};\\\", \\\"{x:1585,y:770,t:1528143888493};\\\", \\\"{x:1582,y:777,t:1528143888511};\\\", \\\"{x:1580,y:780,t:1528143888527};\\\", \\\"{x:1580,y:782,t:1528143888543};\\\", \\\"{x:1577,y:788,t:1528143888560};\\\", \\\"{x:1577,y:792,t:1528143888577};\\\", \\\"{x:1576,y:799,t:1528143888593};\\\", \\\"{x:1575,y:803,t:1528143888610};\\\", \\\"{x:1574,y:807,t:1528143888628};\\\", \\\"{x:1572,y:809,t:1528143888643};\\\", \\\"{x:1571,y:811,t:1528143888660};\\\", \\\"{x:1570,y:814,t:1528143888677};\\\", \\\"{x:1569,y:817,t:1528143888693};\\\", \\\"{x:1567,y:821,t:1528143888710};\\\", \\\"{x:1566,y:822,t:1528143888727};\\\", \\\"{x:1565,y:825,t:1528143888743};\\\", \\\"{x:1563,y:828,t:1528143888759};\\\", \\\"{x:1562,y:830,t:1528143888776};\\\", \\\"{x:1560,y:832,t:1528143888792};\\\", \\\"{x:1560,y:834,t:1528143888810};\\\", \\\"{x:1558,y:835,t:1528143888826};\\\", \\\"{x:1558,y:837,t:1528143888843};\\\", \\\"{x:1556,y:839,t:1528143888860};\\\", \\\"{x:1555,y:841,t:1528143888876};\\\", \\\"{x:1552,y:844,t:1528143888893};\\\", \\\"{x:1550,y:848,t:1528143888910};\\\", \\\"{x:1549,y:850,t:1528143888926};\\\", \\\"{x:1546,y:852,t:1528143888943};\\\", \\\"{x:1545,y:854,t:1528143888960};\\\", \\\"{x:1543,y:857,t:1528143888976};\\\", \\\"{x:1542,y:858,t:1528143888993};\\\", \\\"{x:1542,y:859,t:1528143889010};\\\", \\\"{x:1542,y:860,t:1528143889027};\\\", \\\"{x:1540,y:862,t:1528143889043};\\\", \\\"{x:1540,y:863,t:1528143889060};\\\", \\\"{x:1539,y:864,t:1528143889081};\\\", \\\"{x:1537,y:867,t:1528143889113};\\\", \\\"{x:1537,y:868,t:1528143889129};\\\", \\\"{x:1536,y:869,t:1528143889143};\\\", \\\"{x:1536,y:870,t:1528143889160};\\\", \\\"{x:1533,y:873,t:1528143889176};\\\", \\\"{x:1532,y:874,t:1528143889193};\\\", \\\"{x:1530,y:876,t:1528143889209};\\\", \\\"{x:1529,y:878,t:1528143889227};\\\", \\\"{x:1528,y:880,t:1528143889244};\\\", \\\"{x:1526,y:883,t:1528143889259};\\\", \\\"{x:1525,y:884,t:1528143889277};\\\", \\\"{x:1523,y:886,t:1528143889293};\\\", \\\"{x:1521,y:888,t:1528143889309};\\\", \\\"{x:1519,y:890,t:1528143889327};\\\", \\\"{x:1518,y:891,t:1528143889343};\\\", \\\"{x:1516,y:893,t:1528143889359};\\\", \\\"{x:1514,y:896,t:1528143889377};\\\", \\\"{x:1512,y:899,t:1528143889392};\\\", \\\"{x:1512,y:900,t:1528143889410};\\\", \\\"{x:1511,y:901,t:1528143889426};\\\", \\\"{x:1509,y:903,t:1528143889442};\\\", \\\"{x:1508,y:904,t:1528143889459};\\\", \\\"{x:1507,y:906,t:1528143889476};\\\", \\\"{x:1506,y:907,t:1528143889505};\\\", \\\"{x:1505,y:908,t:1528143889520};\\\", \\\"{x:1505,y:909,t:1528143889528};\\\", \\\"{x:1504,y:910,t:1528143889542};\\\", \\\"{x:1503,y:912,t:1528143889559};\\\", \\\"{x:1501,y:914,t:1528143889575};\\\", \\\"{x:1500,y:915,t:1528143889607};\\\", \\\"{x:1500,y:917,t:1528143889632};\\\", \\\"{x:1499,y:917,t:1528143889642};\\\", \\\"{x:1498,y:917,t:1528143889659};\\\", \\\"{x:1497,y:918,t:1528143889676};\\\", \\\"{x:1497,y:919,t:1528143889696};\\\", \\\"{x:1496,y:920,t:1528143889712};\\\", \\\"{x:1495,y:920,t:1528143889724};\\\", \\\"{x:1495,y:921,t:1528143889742};\\\", \\\"{x:1494,y:923,t:1528143889759};\\\", \\\"{x:1493,y:924,t:1528143889775};\\\", \\\"{x:1491,y:927,t:1528143889792};\\\", \\\"{x:1490,y:928,t:1528143889809};\\\", \\\"{x:1489,y:929,t:1528143889825};\\\", \\\"{x:1488,y:930,t:1528143889842};\\\", \\\"{x:1488,y:931,t:1528143889859};\\\", \\\"{x:1488,y:932,t:1528143889888};\\\", \\\"{x:1487,y:933,t:1528143889921};\\\", \\\"{x:1486,y:935,t:1528143889936};\\\", \\\"{x:1485,y:935,t:1528143889952};\\\", \\\"{x:1485,y:936,t:1528143889977};\\\", \\\"{x:1484,y:938,t:1528143890016};\\\", \\\"{x:1483,y:939,t:1528143890039};\\\", \\\"{x:1482,y:940,t:1528143890055};\\\", \\\"{x:1481,y:940,t:1528143890064};\\\", \\\"{x:1481,y:941,t:1528143890075};\\\", \\\"{x:1479,y:942,t:1528143890091};\\\", \\\"{x:1478,y:942,t:1528143890120};\\\", \\\"{x:1477,y:942,t:1528143890135};\\\", \\\"{x:1476,y:942,t:1528143890281};\\\", \\\"{x:1476,y:938,t:1528143890369};\\\", \\\"{x:1471,y:923,t:1528143890377};\\\", \\\"{x:1467,y:907,t:1528143890392};\\\", \\\"{x:1436,y:860,t:1528143890408};\\\", \\\"{x:1377,y:789,t:1528143890425};\\\", \\\"{x:1322,y:721,t:1528143890442};\\\", \\\"{x:1279,y:671,t:1528143890459};\\\", \\\"{x:1229,y:618,t:1528143890476};\\\", \\\"{x:1167,y:558,t:1528143890491};\\\", \\\"{x:1094,y:500,t:1528143890508};\\\", \\\"{x:1007,y:433,t:1528143890525};\\\", \\\"{x:903,y:373,t:1528143890541};\\\", \\\"{x:844,y:343,t:1528143890558};\\\", \\\"{x:813,y:332,t:1528143890574};\\\", \\\"{x:795,y:328,t:1528143890591};\\\", \\\"{x:783,y:327,t:1528143890608};\\\", \\\"{x:780,y:327,t:1528143890625};\\\", \\\"{x:776,y:328,t:1528143890641};\\\", \\\"{x:765,y:334,t:1528143890658};\\\", \\\"{x:751,y:345,t:1528143890674};\\\", \\\"{x:738,y:364,t:1528143890691};\\\", \\\"{x:724,y:392,t:1528143890708};\\\", \\\"{x:705,y:423,t:1528143890724};\\\", \\\"{x:691,y:444,t:1528143890741};\\\", \\\"{x:677,y:462,t:1528143890758};\\\", \\\"{x:668,y:476,t:1528143890775};\\\", \\\"{x:661,y:487,t:1528143890791};\\\", \\\"{x:652,y:500,t:1528143890807};\\\", \\\"{x:648,y:506,t:1528143890824};\\\", \\\"{x:645,y:510,t:1528143890836};\\\", \\\"{x:639,y:516,t:1528143890853};\\\", \\\"{x:632,y:523,t:1528143890870};\\\", \\\"{x:624,y:528,t:1528143890886};\\\", \\\"{x:620,y:530,t:1528143890903};\\\", \\\"{x:618,y:531,t:1528143890920};\\\", \\\"{x:617,y:531,t:1528143890967};\\\", \\\"{x:616,y:531,t:1528143891016};\\\", \\\"{x:615,y:531,t:1528143891065};\\\", \\\"{x:615,y:527,t:1528143891073};\\\", \\\"{x:615,y:524,t:1528143891086};\\\", \\\"{x:615,y:523,t:1528143891103};\\\", \\\"{x:615,y:516,t:1528143891119};\\\", \\\"{x:615,y:512,t:1528143891137};\\\", \\\"{x:615,y:510,t:1528143891153};\\\", \\\"{x:615,y:508,t:1528143891415};\\\", \\\"{x:616,y:508,t:1528143891424};\\\", \\\"{x:618,y:506,t:1528143891437};\\\", \\\"{x:630,y:501,t:1528143891452};\\\", \\\"{x:652,y:492,t:1528143891470};\\\", \\\"{x:691,y:483,t:1528143891487};\\\", \\\"{x:722,y:473,t:1528143891503};\\\", \\\"{x:737,y:469,t:1528143891519};\\\", \\\"{x:742,y:469,t:1528143891537};\\\", \\\"{x:748,y:468,t:1528143891552};\\\", \\\"{x:754,y:466,t:1528143891569};\\\", \\\"{x:758,y:466,t:1528143891587};\\\", \\\"{x:761,y:466,t:1528143891603};\\\", \\\"{x:764,y:466,t:1528143891620};\\\", \\\"{x:766,y:466,t:1528143891647};\\\", \\\"{x:768,y:466,t:1528143891664};\\\", \\\"{x:770,y:467,t:1528143891671};\\\", \\\"{x:775,y:469,t:1528143891687};\\\", \\\"{x:783,y:474,t:1528143891704};\\\", \\\"{x:787,y:475,t:1528143891719};\\\", \\\"{x:790,y:477,t:1528143891737};\\\", \\\"{x:791,y:477,t:1528143891754};\\\", \\\"{x:795,y:480,t:1528143891770};\\\", \\\"{x:804,y:485,t:1528143891788};\\\", \\\"{x:818,y:500,t:1528143891805};\\\", \\\"{x:825,y:508,t:1528143891820};\\\", \\\"{x:828,y:510,t:1528143891837};\\\", \\\"{x:829,y:510,t:1528143891936};\\\", \\\"{x:830,y:510,t:1528143891952};\\\", \\\"{x:831,y:510,t:1528143892070};\\\", \\\"{x:831,y:510,t:1528143892099};\\\", \\\"{x:828,y:512,t:1528143892152};\\\", \\\"{x:823,y:516,t:1528143892160};\\\", \\\"{x:818,y:521,t:1528143892171};\\\", \\\"{x:811,y:531,t:1528143892188};\\\", \\\"{x:804,y:540,t:1528143892204};\\\", \\\"{x:788,y:555,t:1528143892221};\\\", \\\"{x:775,y:563,t:1528143892238};\\\", \\\"{x:762,y:572,t:1528143892253};\\\", \\\"{x:749,y:582,t:1528143892271};\\\", \\\"{x:730,y:595,t:1528143892287};\\\", \\\"{x:700,y:620,t:1528143892304};\\\", \\\"{x:684,y:634,t:1528143892322};\\\", \\\"{x:672,y:644,t:1528143892338};\\\", \\\"{x:659,y:652,t:1528143892353};\\\", \\\"{x:638,y:660,t:1528143892371};\\\", \\\"{x:605,y:670,t:1528143892387};\\\", \\\"{x:571,y:680,t:1528143892404};\\\", \\\"{x:547,y:686,t:1528143892421};\\\", \\\"{x:536,y:690,t:1528143892437};\\\", \\\"{x:531,y:691,t:1528143892454};\\\", \\\"{x:526,y:692,t:1528143892471};\\\", \\\"{x:522,y:693,t:1528143892488};\\\", \\\"{x:520,y:694,t:1528143892504};\\\", \\\"{x:519,y:696,t:1528143892535};\\\", \\\"{x:518,y:696,t:1528143892543};\\\", \\\"{x:515,y:698,t:1528143892554};\\\", \\\"{x:508,y:704,t:1528143892571};\\\", \\\"{x:504,y:708,t:1528143892588};\\\", \\\"{x:501,y:711,t:1528143892604};\\\", \\\"{x:498,y:714,t:1528143892622};\\\", \\\"{x:497,y:716,t:1528143892638};\\\", \\\"{x:495,y:720,t:1528143892655};\\\", \\\"{x:495,y:722,t:1528143892671};\\\", \\\"{x:493,y:726,t:1528143892688};\\\", \\\"{x:493,y:729,t:1528143892704};\\\", \\\"{x:492,y:731,t:1528143892722};\\\", \\\"{x:492,y:732,t:1528143892738};\\\", \\\"{x:492,y:733,t:1528143892793};\\\", \\\"{x:491,y:733,t:1528143892808};\\\", \\\"{x:490,y:733,t:1528143893153};\\\" ] }, { \\\"rt\\\": 6279, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 921251, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:732,t:1528143895016};\\\", \\\"{x:489,y:726,t:1528143895024};\\\", \\\"{x:489,y:719,t:1528143895039};\\\", \\\"{x:488,y:711,t:1528143895055};\\\", \\\"{x:488,y:704,t:1528143895073};\\\", \\\"{x:488,y:700,t:1528143895089};\\\", \\\"{x:489,y:699,t:1528143895106};\\\", \\\"{x:491,y:696,t:1528143895122};\\\", \\\"{x:500,y:686,t:1528143895140};\\\", \\\"{x:512,y:672,t:1528143895157};\\\", \\\"{x:523,y:661,t:1528143895173};\\\", \\\"{x:535,y:645,t:1528143895190};\\\", \\\"{x:545,y:635,t:1528143895207};\\\", \\\"{x:554,y:624,t:1528143895224};\\\", \\\"{x:578,y:602,t:1528143895240};\\\", \\\"{x:602,y:585,t:1528143895257};\\\", \\\"{x:627,y:566,t:1528143895273};\\\", \\\"{x:648,y:549,t:1528143895291};\\\", \\\"{x:670,y:532,t:1528143895306};\\\", \\\"{x:688,y:516,t:1528143895324};\\\", \\\"{x:706,y:503,t:1528143895340};\\\", \\\"{x:726,y:491,t:1528143895357};\\\", \\\"{x:748,y:477,t:1528143895373};\\\", \\\"{x:763,y:464,t:1528143895390};\\\", \\\"{x:781,y:447,t:1528143895406};\\\", \\\"{x:799,y:427,t:1528143895423};\\\", \\\"{x:822,y:408,t:1528143895440};\\\", \\\"{x:842,y:397,t:1528143895457};\\\", \\\"{x:877,y:383,t:1528143895473};\\\", \\\"{x:933,y:376,t:1528143895490};\\\", \\\"{x:996,y:371,t:1528143895507};\\\", \\\"{x:1065,y:371,t:1528143895523};\\\", \\\"{x:1161,y:373,t:1528143895540};\\\", \\\"{x:1253,y:391,t:1528143895557};\\\", \\\"{x:1350,y:420,t:1528143895573};\\\", \\\"{x:1445,y:450,t:1528143895590};\\\", \\\"{x:1513,y:477,t:1528143895607};\\\", \\\"{x:1615,y:538,t:1528143895624};\\\", \\\"{x:1689,y:603,t:1528143895640};\\\", \\\"{x:1751,y:672,t:1528143895657};\\\", \\\"{x:1786,y:729,t:1528143895674};\\\", \\\"{x:1806,y:774,t:1528143895691};\\\", \\\"{x:1813,y:799,t:1528143895707};\\\", \\\"{x:1819,y:823,t:1528143895724};\\\", \\\"{x:1825,y:847,t:1528143895741};\\\", \\\"{x:1827,y:872,t:1528143895757};\\\", \\\"{x:1827,y:906,t:1528143895773};\\\", \\\"{x:1811,y:955,t:1528143895790};\\\", \\\"{x:1788,y:1007,t:1528143895808};\\\", \\\"{x:1770,y:1045,t:1528143895824};\\\", \\\"{x:1751,y:1076,t:1528143895841};\\\", \\\"{x:1741,y:1088,t:1528143895857};\\\", \\\"{x:1731,y:1097,t:1528143895874};\\\", \\\"{x:1720,y:1104,t:1528143895890};\\\", \\\"{x:1704,y:1113,t:1528143895908};\\\", \\\"{x:1680,y:1124,t:1528143895924};\\\", \\\"{x:1657,y:1126,t:1528143895940};\\\", \\\"{x:1652,y:1126,t:1528143895958};\\\", \\\"{x:1650,y:1126,t:1528143895974};\\\", \\\"{x:1648,y:1126,t:1528143895991};\\\", \\\"{x:1644,y:1125,t:1528143896008};\\\", \\\"{x:1644,y:1121,t:1528143896024};\\\", \\\"{x:1643,y:1116,t:1528143896040};\\\", \\\"{x:1640,y:1107,t:1528143896057};\\\", \\\"{x:1636,y:1100,t:1528143896074};\\\", \\\"{x:1631,y:1092,t:1528143896091};\\\", \\\"{x:1626,y:1082,t:1528143896107};\\\", \\\"{x:1619,y:1065,t:1528143896124};\\\", \\\"{x:1612,y:1049,t:1528143896141};\\\", \\\"{x:1607,y:1036,t:1528143896158};\\\", \\\"{x:1604,y:1029,t:1528143896175};\\\", \\\"{x:1603,y:1025,t:1528143896190};\\\", \\\"{x:1600,y:1017,t:1528143896208};\\\", \\\"{x:1596,y:1004,t:1528143896224};\\\", \\\"{x:1594,y:998,t:1528143896241};\\\", \\\"{x:1589,y:986,t:1528143896257};\\\", \\\"{x:1581,y:970,t:1528143896274};\\\", \\\"{x:1571,y:956,t:1528143896290};\\\", \\\"{x:1566,y:949,t:1528143896307};\\\", \\\"{x:1564,y:946,t:1528143896324};\\\", \\\"{x:1563,y:946,t:1528143896344};\\\", \\\"{x:1563,y:945,t:1528143896358};\\\", \\\"{x:1562,y:945,t:1528143896374};\\\", \\\"{x:1561,y:945,t:1528143896392};\\\", \\\"{x:1560,y:945,t:1528143896408};\\\", \\\"{x:1559,y:945,t:1528143896433};\\\", \\\"{x:1557,y:945,t:1528143896441};\\\", \\\"{x:1556,y:945,t:1528143896465};\\\", \\\"{x:1555,y:945,t:1528143896481};\\\", \\\"{x:1554,y:945,t:1528143896536};\\\", \\\"{x:1552,y:945,t:1528143896639};\\\", \\\"{x:1551,y:945,t:1528143896648};\\\", \\\"{x:1550,y:945,t:1528143896658};\\\", \\\"{x:1534,y:923,t:1528143896674};\\\", \\\"{x:1520,y:903,t:1528143896691};\\\", \\\"{x:1507,y:885,t:1528143896708};\\\", \\\"{x:1496,y:870,t:1528143896724};\\\", \\\"{x:1490,y:858,t:1528143896741};\\\", \\\"{x:1489,y:854,t:1528143896758};\\\", \\\"{x:1487,y:849,t:1528143896775};\\\", \\\"{x:1487,y:847,t:1528143896799};\\\", \\\"{x:1486,y:845,t:1528143896808};\\\", \\\"{x:1486,y:842,t:1528143896825};\\\", \\\"{x:1485,y:839,t:1528143896841};\\\", \\\"{x:1484,y:838,t:1528143896858};\\\", \\\"{x:1479,y:840,t:1528143897137};\\\", \\\"{x:1457,y:851,t:1528143897145};\\\", \\\"{x:1408,y:861,t:1528143897159};\\\", \\\"{x:1228,y:865,t:1528143897175};\\\", \\\"{x:1049,y:865,t:1528143897191};\\\", \\\"{x:822,y:825,t:1528143897208};\\\", \\\"{x:698,y:791,t:1528143897226};\\\", \\\"{x:596,y:749,t:1528143897242};\\\", \\\"{x:509,y:701,t:1528143897259};\\\", \\\"{x:460,y:662,t:1528143897277};\\\", \\\"{x:426,y:632,t:1528143897292};\\\", \\\"{x:397,y:586,t:1528143897325};\\\", \\\"{x:391,y:574,t:1528143897341};\\\", \\\"{x:389,y:569,t:1528143897358};\\\", \\\"{x:389,y:568,t:1528143897375};\\\", \\\"{x:389,y:564,t:1528143897391};\\\", \\\"{x:386,y:555,t:1528143897408};\\\", \\\"{x:386,y:554,t:1528143897425};\\\", \\\"{x:386,y:553,t:1528143897455};\\\", \\\"{x:388,y:553,t:1528143897464};\\\", \\\"{x:392,y:553,t:1528143897474};\\\", \\\"{x:395,y:553,t:1528143897491};\\\", \\\"{x:404,y:554,t:1528143897508};\\\", \\\"{x:427,y:564,t:1528143897525};\\\", \\\"{x:470,y:579,t:1528143897541};\\\", \\\"{x:533,y:582,t:1528143897559};\\\", \\\"{x:569,y:582,t:1528143897575};\\\", \\\"{x:593,y:585,t:1528143897591};\\\", \\\"{x:598,y:587,t:1528143897608};\\\", \\\"{x:599,y:588,t:1528143897625};\\\", \\\"{x:598,y:588,t:1528143897680};\\\", \\\"{x:596,y:587,t:1528143897691};\\\", \\\"{x:591,y:584,t:1528143897708};\\\", \\\"{x:585,y:581,t:1528143897725};\\\", \\\"{x:580,y:579,t:1528143897742};\\\", \\\"{x:582,y:578,t:1528143897809};\\\", \\\"{x:586,y:577,t:1528143897825};\\\", \\\"{x:589,y:576,t:1528143897842};\\\", \\\"{x:590,y:576,t:1528143897859};\\\", \\\"{x:593,y:574,t:1528143897875};\\\", \\\"{x:596,y:574,t:1528143897892};\\\", \\\"{x:599,y:572,t:1528143897909};\\\", \\\"{x:600,y:572,t:1528143897926};\\\", \\\"{x:602,y:571,t:1528143897942};\\\", \\\"{x:604,y:570,t:1528143897958};\\\", \\\"{x:608,y:570,t:1528143897974};\\\", \\\"{x:610,y:569,t:1528143897992};\\\", \\\"{x:611,y:569,t:1528143898008};\\\", \\\"{x:612,y:569,t:1528143898295};\\\", \\\"{x:618,y:569,t:1528143898309};\\\", \\\"{x:634,y:576,t:1528143898325};\\\", \\\"{x:651,y:596,t:1528143898342};\\\", \\\"{x:667,y:612,t:1528143898359};\\\", \\\"{x:680,y:620,t:1528143898375};\\\", \\\"{x:705,y:632,t:1528143898392};\\\", \\\"{x:766,y:658,t:1528143898409};\\\", \\\"{x:840,y:688,t:1528143898425};\\\", \\\"{x:915,y:722,t:1528143898442};\\\", \\\"{x:992,y:754,t:1528143898459};\\\", \\\"{x:1088,y:792,t:1528143898475};\\\", \\\"{x:1186,y:830,t:1528143898492};\\\", \\\"{x:1254,y:851,t:1528143898510};\\\", \\\"{x:1334,y:871,t:1528143898525};\\\", \\\"{x:1431,y:901,t:1528143898542};\\\", \\\"{x:1553,y:937,t:1528143898559};\\\", \\\"{x:1603,y:951,t:1528143898575};\\\", \\\"{x:1622,y:955,t:1528143898592};\\\", \\\"{x:1627,y:955,t:1528143898608};\\\", \\\"{x:1633,y:957,t:1528143898625};\\\", \\\"{x:1639,y:960,t:1528143898642};\\\", \\\"{x:1646,y:962,t:1528143898659};\\\", \\\"{x:1656,y:964,t:1528143898676};\\\", \\\"{x:1661,y:965,t:1528143898692};\\\", \\\"{x:1664,y:965,t:1528143898709};\\\", \\\"{x:1669,y:967,t:1528143898726};\\\", \\\"{x:1673,y:969,t:1528143898742};\\\", \\\"{x:1675,y:971,t:1528143898759};\\\", \\\"{x:1675,y:972,t:1528143898775};\\\", \\\"{x:1675,y:975,t:1528143898792};\\\", \\\"{x:1668,y:980,t:1528143898809};\\\", \\\"{x:1662,y:982,t:1528143898826};\\\", \\\"{x:1653,y:984,t:1528143898843};\\\", \\\"{x:1632,y:984,t:1528143898860};\\\", \\\"{x:1616,y:984,t:1528143898876};\\\", \\\"{x:1585,y:977,t:1528143898893};\\\", \\\"{x:1515,y:964,t:1528143898909};\\\", \\\"{x:1437,y:953,t:1528143898926};\\\", \\\"{x:1358,y:948,t:1528143898942};\\\", \\\"{x:1318,y:946,t:1528143898959};\\\", \\\"{x:1312,y:945,t:1528143898975};\\\", \\\"{x:1311,y:940,t:1528143898992};\\\", \\\"{x:1310,y:940,t:1528143899009};\\\", \\\"{x:1302,y:934,t:1528143899026};\\\", \\\"{x:1282,y:929,t:1528143899042};\\\", \\\"{x:1225,y:910,t:1528143899059};\\\", \\\"{x:1218,y:902,t:1528143899076};\\\", \\\"{x:1216,y:898,t:1528143899092};\\\", \\\"{x:1200,y:894,t:1528143899109};\\\", \\\"{x:1184,y:893,t:1528143899126};\\\", \\\"{x:1182,y:893,t:1528143899151};\\\", \\\"{x:1181,y:893,t:1528143899159};\\\", \\\"{x:1178,y:895,t:1528143899176};\\\", \\\"{x:1178,y:896,t:1528143899193};\\\", \\\"{x:1176,y:896,t:1528143899209};\\\", \\\"{x:1162,y:899,t:1528143899226};\\\", \\\"{x:1124,y:910,t:1528143899243};\\\", \\\"{x:1051,y:912,t:1528143899259};\\\", \\\"{x:954,y:914,t:1528143899276};\\\", \\\"{x:859,y:913,t:1528143899293};\\\", \\\"{x:767,y:900,t:1528143899309};\\\", \\\"{x:659,y:886,t:1528143899326};\\\", \\\"{x:576,y:857,t:1528143899343};\\\", \\\"{x:551,y:844,t:1528143899359};\\\", \\\"{x:544,y:839,t:1528143899376};\\\", \\\"{x:543,y:839,t:1528143899393};\\\", \\\"{x:543,y:838,t:1528143899415};\\\", \\\"{x:544,y:827,t:1528143899425};\\\", \\\"{x:550,y:784,t:1528143899443};\\\", \\\"{x:550,y:758,t:1528143899459};\\\", \\\"{x:548,y:744,t:1528143899477};\\\", \\\"{x:547,y:737,t:1528143899493};\\\", \\\"{x:546,y:729,t:1528143899509};\\\", \\\"{x:545,y:728,t:1528143899526};\\\", \\\"{x:545,y:724,t:1528143899543};\\\", \\\"{x:545,y:718,t:1528143899560};\\\", \\\"{x:544,y:709,t:1528143899576};\\\", \\\"{x:540,y:701,t:1528143899593};\\\", \\\"{x:539,y:699,t:1528143899610};\\\", \\\"{x:539,y:698,t:1528143899626};\\\", \\\"{x:537,y:699,t:1528143899688};\\\", \\\"{x:532,y:702,t:1528143899695};\\\", \\\"{x:527,y:705,t:1528143899710};\\\", \\\"{x:516,y:713,t:1528143899726};\\\", \\\"{x:502,y:720,t:1528143899743};\\\", \\\"{x:500,y:720,t:1528143899760};\\\", \\\"{x:499,y:720,t:1528143899776};\\\", \\\"{x:499,y:721,t:1528143899793};\\\", \\\"{x:499,y:722,t:1528143899810};\\\", \\\"{x:500,y:723,t:1528143899991};\\\", \\\"{x:500,y:725,t:1528143900008};\\\", \\\"{x:500,y:727,t:1528143900015};\\\", \\\"{x:500,y:728,t:1528143900027};\\\", \\\"{x:500,y:729,t:1528143900043};\\\", \\\"{x:500,y:730,t:1528143900063};\\\", \\\"{x:500,y:731,t:1528143900087};\\\", \\\"{x:500,y:732,t:1528143900993};\\\", \\\"{x:500,y:733,t:1528143901217};\\\" ] }, { \\\"rt\\\": 17570, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 940093, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-X -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:733,t:1528143903832};\\\", \\\"{x:499,y:723,t:1528143903847};\\\", \\\"{x:523,y:672,t:1528143903864};\\\", \\\"{x:534,y:657,t:1528143903880};\\\", \\\"{x:553,y:623,t:1528143903898};\\\", \\\"{x:605,y:555,t:1528143903914};\\\", \\\"{x:654,y:488,t:1528143903931};\\\", \\\"{x:697,y:429,t:1528143903946};\\\", \\\"{x:724,y:383,t:1528143903964};\\\", \\\"{x:754,y:345,t:1528143903980};\\\", \\\"{x:772,y:327,t:1528143903996};\\\", \\\"{x:787,y:317,t:1528143904013};\\\", \\\"{x:802,y:311,t:1528143904031};\\\", \\\"{x:806,y:309,t:1528143904046};\\\", \\\"{x:813,y:308,t:1528143904063};\\\", \\\"{x:820,y:308,t:1528143904080};\\\", \\\"{x:829,y:309,t:1528143904096};\\\", \\\"{x:841,y:314,t:1528143904113};\\\", \\\"{x:852,y:321,t:1528143904130};\\\", \\\"{x:857,y:331,t:1528143904146};\\\", \\\"{x:857,y:346,t:1528143904163};\\\", \\\"{x:854,y:365,t:1528143904181};\\\", \\\"{x:842,y:387,t:1528143904196};\\\", \\\"{x:830,y:411,t:1528143904214};\\\", \\\"{x:825,y:440,t:1528143904231};\\\", \\\"{x:823,y:465,t:1528143904247};\\\", \\\"{x:823,y:480,t:1528143904264};\\\", \\\"{x:823,y:483,t:1528143910000};\\\", \\\"{x:823,y:484,t:1528143910018};\\\", \\\"{x:830,y:502,t:1528143910050};\\\", \\\"{x:845,y:533,t:1528143910068};\\\", \\\"{x:841,y:527,t:1528143910353};\\\", \\\"{x:826,y:504,t:1528143910360};\\\", \\\"{x:815,y:475,t:1528143910369};\\\", \\\"{x:794,y:437,t:1528143910385};\\\", \\\"{x:781,y:416,t:1528143910401};\\\", \\\"{x:781,y:413,t:1528143910419};\\\", \\\"{x:783,y:407,t:1528143910436};\\\", \\\"{x:790,y:400,t:1528143910452};\\\", \\\"{x:791,y:399,t:1528143910469};\\\", \\\"{x:793,y:393,t:1528143910486};\\\", \\\"{x:797,y:388,t:1528143910502};\\\", \\\"{x:804,y:378,t:1528143910519};\\\", \\\"{x:819,y:362,t:1528143910535};\\\", \\\"{x:832,y:345,t:1528143910553};\\\", \\\"{x:855,y:311,t:1528143910568};\\\", \\\"{x:888,y:291,t:1528143910586};\\\", \\\"{x:923,y:285,t:1528143910603};\\\", \\\"{x:943,y:284,t:1528143910619};\\\", \\\"{x:960,y:284,t:1528143910635};\\\", \\\"{x:979,y:285,t:1528143910653};\\\", \\\"{x:1008,y:300,t:1528143910670};\\\", \\\"{x:1045,y:329,t:1528143910685};\\\", \\\"{x:1090,y:379,t:1528143910703};\\\", \\\"{x:1139,y:459,t:1528143910719};\\\", \\\"{x:1168,y:543,t:1528143910735};\\\", \\\"{x:1211,y:673,t:1528143910753};\\\", \\\"{x:1268,y:816,t:1528143910770};\\\", \\\"{x:1330,y:941,t:1528143910786};\\\", \\\"{x:1389,y:1053,t:1528143910803};\\\", \\\"{x:1493,y:1199,t:1528143910820};\\\", \\\"{x:1607,y:1199,t:1528143910837};\\\", \\\"{x:1682,y:1199,t:1528143910852};\\\", \\\"{x:1718,y:1199,t:1528143910868};\\\", \\\"{x:1728,y:1199,t:1528143910886};\\\", \\\"{x:1729,y:1199,t:1528143910937};\\\", \\\"{x:1730,y:1199,t:1528143910952};\\\", \\\"{x:1732,y:1184,t:1528143910969};\\\", \\\"{x:1732,y:1155,t:1528143910986};\\\", \\\"{x:1732,y:1068,t:1528143911002};\\\", \\\"{x:1710,y:946,t:1528143911019};\\\", \\\"{x:1702,y:861,t:1528143911036};\\\", \\\"{x:1702,y:824,t:1528143911053};\\\", \\\"{x:1702,y:782,t:1528143911069};\\\", \\\"{x:1701,y:753,t:1528143911086};\\\", \\\"{x:1698,y:733,t:1528143911103};\\\", \\\"{x:1697,y:726,t:1528143911119};\\\", \\\"{x:1697,y:724,t:1528143911136};\\\", \\\"{x:1690,y:727,t:1528143911184};\\\", \\\"{x:1670,y:745,t:1528143911192};\\\", \\\"{x:1628,y:781,t:1528143911203};\\\", \\\"{x:1526,y:871,t:1528143911221};\\\", \\\"{x:1480,y:907,t:1528143911236};\\\", \\\"{x:1456,y:924,t:1528143911253};\\\", \\\"{x:1436,y:943,t:1528143911270};\\\", \\\"{x:1418,y:961,t:1528143911286};\\\", \\\"{x:1410,y:970,t:1528143911303};\\\", \\\"{x:1407,y:973,t:1528143911320};\\\", \\\"{x:1406,y:973,t:1528143911352};\\\", \\\"{x:1410,y:966,t:1528143911371};\\\", \\\"{x:1422,y:952,t:1528143911386};\\\", \\\"{x:1435,y:938,t:1528143911404};\\\", \\\"{x:1449,y:919,t:1528143911420};\\\", \\\"{x:1472,y:900,t:1528143911436};\\\", \\\"{x:1493,y:882,t:1528143911453};\\\", \\\"{x:1506,y:874,t:1528143911471};\\\", \\\"{x:1514,y:871,t:1528143911486};\\\", \\\"{x:1517,y:871,t:1528143911504};\\\", \\\"{x:1518,y:871,t:1528143911520};\\\", \\\"{x:1519,y:871,t:1528143911536};\\\", \\\"{x:1519,y:870,t:1528143911591};\\\", \\\"{x:1517,y:868,t:1528143911607};\\\", \\\"{x:1514,y:867,t:1528143911623};\\\", \\\"{x:1513,y:865,t:1528143911635};\\\", \\\"{x:1506,y:862,t:1528143911653};\\\", \\\"{x:1502,y:860,t:1528143911669};\\\", \\\"{x:1499,y:858,t:1528143911686};\\\", \\\"{x:1494,y:854,t:1528143911702};\\\", \\\"{x:1486,y:849,t:1528143911720};\\\", \\\"{x:1484,y:847,t:1528143911737};\\\", \\\"{x:1484,y:846,t:1528143911753};\\\", \\\"{x:1482,y:845,t:1528143911770};\\\", \\\"{x:1482,y:843,t:1528143911787};\\\", \\\"{x:1482,y:841,t:1528143911808};\\\", \\\"{x:1482,y:840,t:1528143911820};\\\", \\\"{x:1483,y:840,t:1528143911836};\\\", \\\"{x:1483,y:839,t:1528143911853};\\\", \\\"{x:1483,y:837,t:1528143911869};\\\", \\\"{x:1483,y:836,t:1528143911887};\\\", \\\"{x:1483,y:835,t:1528143911914};\\\", \\\"{x:1484,y:834,t:1528143911937};\\\", \\\"{x:1484,y:833,t:1528143912024};\\\", \\\"{x:1484,y:832,t:1528143912047};\\\", \\\"{x:1484,y:830,t:1528143912055};\\\", \\\"{x:1484,y:826,t:1528143912069};\\\", \\\"{x:1485,y:818,t:1528143912088};\\\", \\\"{x:1487,y:790,t:1528143912104};\\\", \\\"{x:1491,y:762,t:1528143912120};\\\", \\\"{x:1493,y:720,t:1528143912137};\\\", \\\"{x:1499,y:683,t:1528143912154};\\\", \\\"{x:1518,y:619,t:1528143912170};\\\", \\\"{x:1536,y:547,t:1528143912187};\\\", \\\"{x:1542,y:518,t:1528143912204};\\\", \\\"{x:1545,y:468,t:1528143912220};\\\", \\\"{x:1546,y:429,t:1528143912237};\\\", \\\"{x:1550,y:411,t:1528143912253};\\\", \\\"{x:1552,y:395,t:1528143912270};\\\", \\\"{x:1556,y:386,t:1528143912286};\\\", \\\"{x:1561,y:375,t:1528143912303};\\\", \\\"{x:1561,y:372,t:1528143912319};\\\", \\\"{x:1561,y:369,t:1528143912337};\\\", \\\"{x:1561,y:362,t:1528143912353};\\\", \\\"{x:1561,y:355,t:1528143912369};\\\", \\\"{x:1561,y:353,t:1528143912386};\\\", \\\"{x:1561,y:352,t:1528143912407};\\\", \\\"{x:1561,y:350,t:1528143912420};\\\", \\\"{x:1559,y:346,t:1528143912437};\\\", \\\"{x:1551,y:333,t:1528143912454};\\\", \\\"{x:1540,y:317,t:1528143912470};\\\", \\\"{x:1532,y:302,t:1528143912487};\\\", \\\"{x:1532,y:299,t:1528143912504};\\\", \\\"{x:1532,y:298,t:1528143912527};\\\", \\\"{x:1532,y:297,t:1528143912552};\\\", \\\"{x:1530,y:295,t:1528143912560};\\\", \\\"{x:1528,y:294,t:1528143912576};\\\", \\\"{x:1524,y:292,t:1528143912587};\\\", \\\"{x:1519,y:288,t:1528143912604};\\\", \\\"{x:1514,y:286,t:1528143912621};\\\", \\\"{x:1512,y:286,t:1528143912637};\\\", \\\"{x:1506,y:285,t:1528143912654};\\\", \\\"{x:1481,y:283,t:1528143912671};\\\", \\\"{x:1397,y:289,t:1528143912688};\\\", \\\"{x:1179,y:323,t:1528143912704};\\\", \\\"{x:1003,y:323,t:1528143912721};\\\", \\\"{x:816,y:315,t:1528143912738};\\\", \\\"{x:648,y:313,t:1528143912754};\\\", \\\"{x:515,y:296,t:1528143912771};\\\", \\\"{x:442,y:286,t:1528143912787};\\\", \\\"{x:413,y:283,t:1528143912804};\\\", \\\"{x:408,y:283,t:1528143912822};\\\", \\\"{x:407,y:283,t:1528143912837};\\\", \\\"{x:406,y:283,t:1528143912854};\\\", \\\"{x:412,y:286,t:1528143912928};\\\", \\\"{x:422,y:306,t:1528143912937};\\\", \\\"{x:438,y:378,t:1528143912954};\\\", \\\"{x:438,y:447,t:1528143912972};\\\", \\\"{x:430,y:517,t:1528143912989};\\\", \\\"{x:429,y:546,t:1528143913004};\\\", \\\"{x:434,y:562,t:1528143913021};\\\", \\\"{x:446,y:575,t:1528143913038};\\\", \\\"{x:470,y:590,t:1528143913054};\\\", \\\"{x:501,y:603,t:1528143913072};\\\", \\\"{x:520,y:610,t:1528143913087};\\\", \\\"{x:523,y:611,t:1528143913103};\\\", \\\"{x:524,y:612,t:1528143913121};\\\", \\\"{x:527,y:613,t:1528143913136};\\\", \\\"{x:540,y:618,t:1528143913155};\\\", \\\"{x:554,y:625,t:1528143913170};\\\", \\\"{x:565,y:629,t:1528143913188};\\\", \\\"{x:566,y:630,t:1528143913203};\\\", \\\"{x:572,y:630,t:1528143913220};\\\", \\\"{x:596,y:627,t:1528143913237};\\\", \\\"{x:643,y:613,t:1528143913255};\\\", \\\"{x:673,y:597,t:1528143913271};\\\", \\\"{x:699,y:579,t:1528143913286};\\\", \\\"{x:716,y:567,t:1528143913304};\\\", \\\"{x:728,y:559,t:1528143913321};\\\", \\\"{x:737,y:551,t:1528143913337};\\\", \\\"{x:745,y:547,t:1528143913355};\\\", \\\"{x:758,y:542,t:1528143913371};\\\", \\\"{x:767,y:538,t:1528143913388};\\\", \\\"{x:773,y:537,t:1528143913405};\\\", \\\"{x:776,y:536,t:1528143913421};\\\", \\\"{x:780,y:535,t:1528143913438};\\\", \\\"{x:781,y:535,t:1528143913560};\\\", \\\"{x:780,y:535,t:1528143913571};\\\", \\\"{x:753,y:552,t:1528143913589};\\\", \\\"{x:733,y:563,t:1528143913605};\\\", \\\"{x:722,y:568,t:1528143913620};\\\", \\\"{x:712,y:568,t:1528143913637};\\\", \\\"{x:705,y:568,t:1528143913655};\\\", \\\"{x:693,y:564,t:1528143913670};\\\", \\\"{x:688,y:561,t:1528143913687};\\\", \\\"{x:686,y:560,t:1528143913704};\\\", \\\"{x:680,y:560,t:1528143913721};\\\", \\\"{x:673,y:562,t:1528143913738};\\\", \\\"{x:667,y:562,t:1528143913755};\\\", \\\"{x:666,y:562,t:1528143913770};\\\", \\\"{x:665,y:562,t:1528143913788};\\\", \\\"{x:663,y:563,t:1528143913805};\\\", \\\"{x:662,y:564,t:1528143913821};\\\", \\\"{x:661,y:565,t:1528143913838};\\\", \\\"{x:659,y:565,t:1528143913855};\\\", \\\"{x:657,y:566,t:1528143913871};\\\", \\\"{x:656,y:567,t:1528143913888};\\\", \\\"{x:655,y:568,t:1528143913905};\\\", \\\"{x:653,y:568,t:1528143913922};\\\", \\\"{x:651,y:570,t:1528143913938};\\\", \\\"{x:647,y:571,t:1528143913955};\\\", \\\"{x:644,y:572,t:1528143913972};\\\", \\\"{x:642,y:574,t:1528143913988};\\\", \\\"{x:641,y:574,t:1528143914005};\\\", \\\"{x:640,y:575,t:1528143914039};\\\", \\\"{x:639,y:575,t:1528143914056};\\\", \\\"{x:637,y:577,t:1528143914073};\\\", \\\"{x:635,y:577,t:1528143914088};\\\", \\\"{x:633,y:577,t:1528143914105};\\\", \\\"{x:633,y:578,t:1528143914122};\\\", \\\"{x:631,y:579,t:1528143914138};\\\", \\\"{x:629,y:580,t:1528143914156};\\\", \\\"{x:627,y:581,t:1528143914172};\\\", \\\"{x:626,y:581,t:1528143914188};\\\", \\\"{x:625,y:582,t:1528143914204};\\\", \\\"{x:624,y:583,t:1528143914221};\\\", \\\"{x:622,y:584,t:1528143914239};\\\", \\\"{x:620,y:584,t:1528143914255};\\\", \\\"{x:619,y:584,t:1528143914311};\\\", \\\"{x:619,y:585,t:1528143914321};\\\", \\\"{x:618,y:586,t:1528143914367};\\\", \\\"{x:617,y:586,t:1528143914383};\\\", \\\"{x:616,y:587,t:1528143914400};\\\", \\\"{x:616,y:588,t:1528143914567};\\\", \\\"{x:616,y:589,t:1528143914575};\\\", \\\"{x:617,y:589,t:1528143914588};\\\", \\\"{x:618,y:589,t:1528143914604};\\\", \\\"{x:617,y:589,t:1528143914688};\\\", \\\"{x:607,y:589,t:1528143914695};\\\", \\\"{x:588,y:589,t:1528143914705};\\\", \\\"{x:531,y:592,t:1528143914721};\\\", \\\"{x:480,y:595,t:1528143914740};\\\", \\\"{x:441,y:595,t:1528143914754};\\\", \\\"{x:407,y:595,t:1528143914772};\\\", \\\"{x:389,y:599,t:1528143914788};\\\", \\\"{x:384,y:599,t:1528143914805};\\\", \\\"{x:382,y:599,t:1528143914822};\\\", \\\"{x:383,y:599,t:1528143914880};\\\", \\\"{x:385,y:599,t:1528143914903};\\\", \\\"{x:386,y:599,t:1528143914920};\\\", \\\"{x:387,y:599,t:1528143914936};\\\", \\\"{x:388,y:599,t:1528143914960};\\\", \\\"{x:391,y:599,t:1528143914975};\\\", \\\"{x:393,y:599,t:1528143914989};\\\", \\\"{x:395,y:599,t:1528143915007};\\\", \\\"{x:400,y:599,t:1528143915447};\\\", \\\"{x:407,y:608,t:1528143915456};\\\", \\\"{x:426,y:633,t:1528143915473};\\\", \\\"{x:435,y:645,t:1528143915488};\\\", \\\"{x:444,y:658,t:1528143915507};\\\", \\\"{x:455,y:671,t:1528143915522};\\\", \\\"{x:473,y:693,t:1528143915539};\\\", \\\"{x:503,y:728,t:1528143915555};\\\", \\\"{x:522,y:746,t:1528143915573};\\\", \\\"{x:534,y:756,t:1528143915590};\\\", \\\"{x:537,y:756,t:1528143915606};\\\", \\\"{x:537,y:757,t:1528143915719};\\\", \\\"{x:537,y:760,t:1528143915727};\\\", \\\"{x:534,y:761,t:1528143915740};\\\", \\\"{x:531,y:764,t:1528143915756};\\\", \\\"{x:528,y:767,t:1528143915773};\\\", \\\"{x:525,y:768,t:1528143915790};\\\", \\\"{x:524,y:769,t:1528143916105};\\\", \\\"{x:526,y:767,t:1528143916135};\\\", \\\"{x:529,y:765,t:1528143916142};\\\", \\\"{x:530,y:764,t:1528143916157};\\\", \\\"{x:534,y:760,t:1528143916173};\\\", \\\"{x:534,y:759,t:1528143916190};\\\", \\\"{x:534,y:758,t:1528143916207};\\\", \\\"{x:537,y:755,t:1528143916222};\\\", \\\"{x:538,y:753,t:1528143916239};\\\" ] }, { \\\"rt\\\": 266563, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1207898, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"To find out which shifts start at 12 pm you look at the x axis at the point that corresponds to 12pm then follow the diagonal line up and to the right. In this case it would be M and L. Conversely, to see which shifts end at 12 you would go diagonally up and to the left. In this case there are none. To see which shift have a break at 12 you just go vertically up from 12 pm. In this case B and F.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10344, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1219248, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 12380, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1232649, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 16255, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1250231, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"AV66J\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"AV66J\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 147, dom: 180, initialDom: 208",
  "javascriptErrors": []
}