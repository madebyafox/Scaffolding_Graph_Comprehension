var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "31fef55698ceb97207eb62e03894af9b",
  "created": "2018-05-21T12:09:19.8135032-07:00",
  "lastActivity": "2018-05-21T12:11:04.082996-07:00",
  "pageViews": [
    {
      "id": "05211958753085838b12467a31efba45d37cb25d",
      "startTime": "2018-05-21T12:09:19.9849858-07:00",
      "endTime": "2018-05-21T12:11:04.082996-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 104388,
      "engagementTime": 93190,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 104388,
  "engagementTime": 93190,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "18c7535f2c384bb0b60cec3e2fb2abc8",
  "gdpr": false
}