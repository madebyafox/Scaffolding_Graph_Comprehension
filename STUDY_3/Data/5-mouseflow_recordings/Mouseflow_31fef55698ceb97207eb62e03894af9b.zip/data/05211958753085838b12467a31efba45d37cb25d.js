var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05211958753085838b12467a31efba45d37cb25d"] = {
  "startTime": "2018-05-21T19:09:19.9849858Z",
  "websitePageUrl": "/",
  "visitTime": 104388,
  "engagementTime": 93190,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "31fef55698ceb97207eb62e03894af9b",
    "created": "2018-05-21T19:09:19.8135032+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "18c7535f2c384bb0b60cec3e2fb2abc8",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/31fef55698ceb97207eb62e03894af9b/play"
  },
  "events": [
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 257,
      "e": 257,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 468,
      "y": 323
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 970,
      "y": 771
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 33340,
      "y": 51158,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 935,
      "y": 797
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 898,
      "y": 806
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 27879,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 2,
      "x": 867,
      "y": 806
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 987,
      "y": 737
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 1000,
      "y": 725
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 34979,
      "y": 47389,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 1000,
      "y": 723
    },
    {
      "t": 1754,
      "e": 1754,
      "ty": 41,
      "x": 34979,
      "y": 47226,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1000,
      "y": 789
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 34979,
      "y": 48291,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1004,
      "y": 779
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1011,
      "y": 767
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 35634,
      "y": 46488,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1012,
      "y": 767
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 37873,
      "y": 44932,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 1072,
      "y": 738
    },
    {
      "t": 7007,
      "e": 7007,
      "ty": 41,
      "x": 38911,
      "y": 44113,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 1069,
      "y": 699
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 38692,
      "y": 39771,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 1068,
      "y": 685
    },
    {
      "t": 7935,
      "e": 7935,
      "ty": 3,
      "x": 1068,
      "y": 685,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7974,
      "e": 7974,
      "ty": 4,
      "x": 38692,
      "y": 39771,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7975,
      "e": 7975,
      "ty": 5,
      "x": 1068,
      "y": 685,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1027,
      "y": 677
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 742,
      "y": 969
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 727,
      "y": 1040
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 24760,
      "y": 57170,
      "ta": "html > body"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 746,
      "y": 976
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 761,
      "y": 936
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 22036,
      "y": 57056,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8800,
      "e": 8800,
      "ty": 2,
      "x": 761,
      "y": 846
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 2,
      "x": 707,
      "y": 751
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 2,
      "x": 628,
      "y": 669
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 41,
      "x": 14663,
      "y": 38460,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9107,
      "e": 9107,
      "ty": 2,
      "x": 621,
      "y": 657
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 816,
      "y": 912
    },
    {
      "t": 9250,
      "e": 9250,
      "ty": 41,
      "x": 26787,
      "y": 60660,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9307,
      "e": 9307,
      "ty": 2,
      "x": 850,
      "y": 940
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 846,
      "y": 914
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 2,
      "x": 843,
      "y": 854
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 41,
      "x": 26405,
      "y": 53615,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9567,
      "e": 9567,
      "ty": 3,
      "x": 843,
      "y": 854,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9646,
      "e": 9646,
      "ty": 4,
      "x": 26405,
      "y": 53615,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9646,
      "e": 9646,
      "ty": 5,
      "x": 843,
      "y": 854,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 2,
      "x": 844,
      "y": 844
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 41,
      "x": 26459,
      "y": 52796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10100,
      "e": 10100,
      "ty": 2,
      "x": 860,
      "y": 777
    },
    {
      "t": 10255,
      "e": 10255,
      "ty": 41,
      "x": 27333,
      "y": 47308,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12200,
      "e": 12200,
      "ty": 2,
      "x": 730,
      "y": 317
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 20998,
      "y": 3317,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12301,
      "e": 12301,
      "ty": 2,
      "x": 744,
      "y": 243
    },
    {
      "t": 12400,
      "e": 12400,
      "ty": 2,
      "x": 644,
      "y": 394
    },
    {
      "t": 12500,
      "e": 12500,
      "ty": 2,
      "x": 651,
      "y": 401
    },
    {
      "t": 12500,
      "e": 12500,
      "ty": 41,
      "x": 15919,
      "y": 16506,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12600,
      "e": 12600,
      "ty": 2,
      "x": 724,
      "y": 529
    },
    {
      "t": 12700,
      "e": 12700,
      "ty": 2,
      "x": 715,
      "y": 607
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 19196,
      "y": 33299,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12787,
      "e": 12787,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 12800,
      "e": 12800,
      "ty": 2,
      "x": 705,
      "y": 606
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 2,
      "x": 679,
      "y": 617
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 1,
      "x": 0,
      "y": 13
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 2,
      "x": 675,
      "y": 623
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 13000,
      "e": 13000,
      "ty": 41,
      "x": 22969,
      "y": 34069,
      "ta": "html > body"
    },
    {
      "t": 13101,
      "e": 13101,
      "ty": 2,
      "x": 676,
      "y": 622
    },
    {
      "t": 13201,
      "e": 13201,
      "ty": 2,
      "x": 821,
      "y": 622
    },
    {
      "t": 13250,
      "e": 13250,
      "ty": 41,
      "x": 28721,
      "y": 34290,
      "ta": "html > body"
    },
    {
      "t": 13304,
      "e": 13304,
      "ty": 2,
      "x": 843,
      "y": 628
    },
    {
      "t": 13506,
      "e": 13506,
      "ty": 41,
      "x": 28755,
      "y": 34346,
      "ta": "html > body"
    },
    {
      "t": 13874,
      "e": 13874,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 14000,
      "e": 14000,
      "ty": 2,
      "x": 904,
      "y": 458
    },
    {
      "t": 14000,
      "e": 14000,
      "ty": 41,
      "x": 30037,
      "y": 14307,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 14100,
      "e": 14100,
      "ty": 2,
      "x": 991,
      "y": 206
    },
    {
      "t": 14258,
      "e": 14258,
      "ty": 41,
      "x": 34317,
      "y": 5519,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 15200,
      "e": 15200,
      "ty": 2,
      "x": 786,
      "y": 680
    },
    {
      "t": 15250,
      "e": 15250,
      "ty": 41,
      "x": 22017,
      "y": 57385,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 15307,
      "e": 15307,
      "ty": 2,
      "x": 741,
      "y": 958
    },
    {
      "t": 15400,
      "e": 15400,
      "ty": 2,
      "x": 748,
      "y": 979
    },
    {
      "t": 15500,
      "e": 15500,
      "ty": 2,
      "x": 835,
      "y": 928
    },
    {
      "t": 15500,
      "e": 15500,
      "ty": 41,
      "x": 6627,
      "y": 59623,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 15600,
      "e": 15600,
      "ty": 2,
      "x": 834,
      "y": 924
    },
    {
      "t": 15700,
      "e": 15700,
      "ty": 2,
      "x": 829,
      "y": 924
    },
    {
      "t": 15750,
      "e": 15750,
      "ty": 41,
      "x": 4317,
      "y": 38771,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 15806,
      "e": 15806,
      "ty": 2,
      "x": 819,
      "y": 919
    },
    {
      "t": 15900,
      "e": 15900,
      "ty": 2,
      "x": 817,
      "y": 918
    },
    {
      "t": 15902,
      "e": 15902,
      "ty": 3,
      "x": 817,
      "y": 918,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 15957,
      "e": 15957,
      "ty": 4,
      "x": 44440,
      "y": 22988,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 15957,
      "e": 15957,
      "ty": 5,
      "x": 817,
      "y": 918,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 15957,
      "e": 15957,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 15960,
      "e": 15960,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 16000,
      "e": 16000,
      "ty": 2,
      "x": 816,
      "y": 918
    },
    {
      "t": 16000,
      "e": 16000,
      "ty": 41,
      "x": 41164,
      "y": 22988,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 16100,
      "e": 16100,
      "ty": 2,
      "x": 810,
      "y": 911
    },
    {
      "t": 16255,
      "e": 16255,
      "ty": 41,
      "x": 21503,
      "y": 51,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 16600,
      "e": 16600,
      "ty": 2,
      "x": 891,
      "y": 955
    },
    {
      "t": 16700,
      "e": 16700,
      "ty": 2,
      "x": 1023,
      "y": 1045
    },
    {
      "t": 16750,
      "e": 16750,
      "ty": 41,
      "x": 35849,
      "y": 59718,
      "ta": "> div.masterdiv"
    },
    {
      "t": 16800,
      "e": 16800,
      "ty": 2,
      "x": 1050,
      "y": 1087
    },
    {
      "t": 16900,
      "e": 16900,
      "ty": 2,
      "x": 1047,
      "y": 1087
    },
    {
      "t": 16963,
      "e": 16963,
      "ty": 6,
      "x": 1027,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 17000,
      "e": 17000,
      "ty": 2,
      "x": 1004,
      "y": 1076
    },
    {
      "t": 17000,
      "e": 17000,
      "ty": 41,
      "x": 51608,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 17104,
      "e": 17104,
      "ty": 2,
      "x": 996,
      "y": 1073
    },
    {
      "t": 17200,
      "e": 17200,
      "ty": 2,
      "x": 994,
      "y": 1083
    },
    {
      "t": 17251,
      "e": 17251,
      "ty": 41,
      "x": 46147,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 17304,
      "e": 17304,
      "ty": 2,
      "x": 994,
      "y": 1085
    },
    {
      "t": 20007,
      "e": 20007,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30901,
      "e": 22304,
      "ty": 2,
      "x": 992,
      "y": 1096
    },
    {
      "t": 31001,
      "e": 22404,
      "ty": 2,
      "x": 973,
      "y": 1092
    },
    {
      "t": 31001,
      "e": 22404,
      "ty": 41,
      "x": 34678,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 31101,
      "e": 22504,
      "ty": 2,
      "x": 968,
      "y": 1091
    },
    {
      "t": 31251,
      "e": 22654,
      "ty": 41,
      "x": 31948,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 33870,
      "e": 25273,
      "ty": 3,
      "x": 968,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 33870,
      "e": 25273,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 33870,
      "e": 25273,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 33965,
      "e": 25368,
      "ty": 4,
      "x": 31948,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 33965,
      "e": 25368,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 33966,
      "e": 25369,
      "ty": 5,
      "x": 968,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 33967,
      "e": 25370,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 34972,
      "e": 26375,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 35100,
      "e": 26503,
      "ty": 2,
      "x": 967,
      "y": 1065
    },
    {
      "t": 35145,
      "e": 26548,
      "ty": 6,
      "x": 901,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35161,
      "e": 26564,
      "ty": 7,
      "x": 860,
      "y": 552,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35200,
      "e": 26603,
      "ty": 2,
      "x": 834,
      "y": 458
    },
    {
      "t": 35250,
      "e": 26653,
      "ty": 41,
      "x": 28445,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 35300,
      "e": 26703,
      "ty": 2,
      "x": 834,
      "y": 454
    },
    {
      "t": 35400,
      "e": 26803,
      "ty": 2,
      "x": 834,
      "y": 455
    },
    {
      "t": 35500,
      "e": 26903,
      "ty": 2,
      "x": 845,
      "y": 485
    },
    {
      "t": 35500,
      "e": 26903,
      "ty": 41,
      "x": 18034,
      "y": 21064,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 35600,
      "e": 27003,
      "ty": 2,
      "x": 861,
      "y": 554
    },
    {
      "t": 35661,
      "e": 27064,
      "ty": 6,
      "x": 861,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35700,
      "e": 27103,
      "ty": 2,
      "x": 861,
      "y": 593
    },
    {
      "t": 35750,
      "e": 27153,
      "ty": 41,
      "x": 11679,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35801,
      "e": 27204,
      "ty": 2,
      "x": 862,
      "y": 595
    },
    {
      "t": 35846,
      "e": 27249,
      "ty": 3,
      "x": 862,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35847,
      "e": 27250,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35949,
      "e": 27352,
      "ty": 4,
      "x": 11679,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35949,
      "e": 27352,
      "ty": 5,
      "x": 862,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37584,
      "e": 28987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 37777,
      "e": 29180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 37778,
      "e": 29181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37825,
      "e": 29228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 37865,
      "e": 29268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 37904,
      "e": 29307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 37904,
      "e": 29307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37969,
      "e": 29372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Ch"
    },
    {
      "t": 38025,
      "e": 29428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 38025,
      "e": 29428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38112,
      "e": 29515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Che"
    },
    {
      "t": 38305,
      "e": 29708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 38377,
      "e": 29780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Ch"
    },
    {
      "t": 38392,
      "e": 29795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 38393,
      "e": 29796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38481,
      "e": 29884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 38481,
      "e": 29884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38537,
      "e": 29940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Char"
    },
    {
      "t": 38585,
      "e": 29988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 39001,
      "e": 30404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 39003,
      "e": 30406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39064,
      "e": 30467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||l"
    },
    {
      "t": 39177,
      "e": 30580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 39177,
      "e": 30580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39193,
      "e": 30596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 39193,
      "e": 30596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39224,
      "e": 30627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||ie"
    },
    {
      "t": 39273,
      "e": 30676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 39801,
      "e": 31204,
      "ty": 2,
      "x": 867,
      "y": 595
    },
    {
      "t": 39850,
      "e": 31253,
      "ty": 7,
      "x": 889,
      "y": 620,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39900,
      "e": 31303,
      "ty": 2,
      "x": 866,
      "y": 632
    },
    {
      "t": 39999,
      "e": 31402,
      "ty": 6,
      "x": 864,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40000,
      "e": 31403,
      "ty": 2,
      "x": 864,
      "y": 679
    },
    {
      "t": 40000,
      "e": 31403,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40001,
      "e": 31404,
      "ty": 41,
      "x": 12112,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40100,
      "e": 31503,
      "ty": 2,
      "x": 859,
      "y": 687
    },
    {
      "t": 40200,
      "e": 31603,
      "ty": 2,
      "x": 858,
      "y": 695
    },
    {
      "t": 40205,
      "e": 31608,
      "ty": 3,
      "x": 858,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40207,
      "e": 31610,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Charlie"
    },
    {
      "t": 40208,
      "e": 31611,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40208,
      "e": 31611,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40251,
      "e": 31654,
      "ty": 41,
      "x": 10814,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40276,
      "e": 31679,
      "ty": 4,
      "x": 10814,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40276,
      "e": 31679,
      "ty": 5,
      "x": 858,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40700,
      "e": 32103,
      "ty": 2,
      "x": 859,
      "y": 694
    },
    {
      "t": 40751,
      "e": 32154,
      "ty": 41,
      "x": 11246,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40800,
      "e": 32203,
      "ty": 2,
      "x": 860,
      "y": 693
    },
    {
      "t": 41577,
      "e": 32980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 41578,
      "e": 32981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41640,
      "e": 33043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 42370,
      "e": 33773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42473,
      "e": 33876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42689,
      "e": 34092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 42865,
      "e": 34268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 43073,
      "e": 34476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 43161,
      "e": 34564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43162,
      "e": 34565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43216,
      "e": 34619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 43304,
      "e": 34707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43305,
      "e": 34708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43368,
      "e": 34771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "II"
    },
    {
      "t": 43458,
      "e": 34861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43458,
      "e": 34861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43513,
      "e": 34916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "III"
    },
    {
      "t": 43649,
      "e": 35052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "III"
    },
    {
      "t": 44701,
      "e": 36104,
      "ty": 2,
      "x": 869,
      "y": 689
    },
    {
      "t": 44751,
      "e": 36154,
      "ty": 41,
      "x": 13193,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45100,
      "e": 36503,
      "ty": 2,
      "x": 860,
      "y": 694
    },
    {
      "t": 45104,
      "e": 36507,
      "ty": 7,
      "x": 858,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45136,
      "e": 36539,
      "ty": 6,
      "x": 905,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45152,
      "e": 36555,
      "ty": 7,
      "x": 923,
      "y": 746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45200,
      "e": 36603,
      "ty": 2,
      "x": 923,
      "y": 746
    },
    {
      "t": 45250,
      "e": 36653,
      "ty": 41,
      "x": 31510,
      "y": 40883,
      "ta": "html > body"
    },
    {
      "t": 45801,
      "e": 37204,
      "ty": 2,
      "x": 923,
      "y": 748
    },
    {
      "t": 45900,
      "e": 37303,
      "ty": 2,
      "x": 923,
      "y": 751
    },
    {
      "t": 46000,
      "e": 37403,
      "ty": 2,
      "x": 923,
      "y": 754
    },
    {
      "t": 46001,
      "e": 37404,
      "ty": 41,
      "x": 31510,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 46251,
      "e": 37654,
      "ty": 41,
      "x": 31476,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 46301,
      "e": 37704,
      "ty": 2,
      "x": 922,
      "y": 754
    },
    {
      "t": 46701,
      "e": 38104,
      "ty": 2,
      "x": 919,
      "y": 755
    },
    {
      "t": 46751,
      "e": 38154,
      "ty": 41,
      "x": 31131,
      "y": 41437,
      "ta": "html > body"
    },
    {
      "t": 46801,
      "e": 38204,
      "ty": 2,
      "x": 905,
      "y": 758
    },
    {
      "t": 46900,
      "e": 38303,
      "ty": 2,
      "x": 903,
      "y": 758
    },
    {
      "t": 47001,
      "e": 38404,
      "ty": 41,
      "x": 30821,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 47700,
      "e": 39103,
      "ty": 2,
      "x": 904,
      "y": 758
    },
    {
      "t": 47751,
      "e": 39154,
      "ty": 41,
      "x": 30856,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 48001,
      "e": 39404,
      "ty": 2,
      "x": 909,
      "y": 763
    },
    {
      "t": 48001,
      "e": 39404,
      "ty": 41,
      "x": 31028,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 48100,
      "e": 39503,
      "ty": 2,
      "x": 911,
      "y": 773
    },
    {
      "t": 48201,
      "e": 39604,
      "ty": 2,
      "x": 914,
      "y": 774
    },
    {
      "t": 48251,
      "e": 39654,
      "ty": 41,
      "x": 31820,
      "y": 41880,
      "ta": "html > body"
    },
    {
      "t": 48300,
      "e": 39703,
      "ty": 2,
      "x": 938,
      "y": 760
    },
    {
      "t": 48390,
      "e": 39793,
      "ty": 6,
      "x": 951,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48400,
      "e": 39803,
      "ty": 2,
      "x": 951,
      "y": 740
    },
    {
      "t": 48500,
      "e": 39903,
      "ty": 2,
      "x": 958,
      "y": 734
    },
    {
      "t": 48501,
      "e": 39904,
      "ty": 41,
      "x": 31994,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50001,
      "e": 41404,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50600,
      "e": 42003,
      "ty": 2,
      "x": 961,
      "y": 720
    },
    {
      "t": 50700,
      "e": 42103,
      "ty": 2,
      "x": 962,
      "y": 710
    },
    {
      "t": 50741,
      "e": 42144,
      "ty": 7,
      "x": 962,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50751,
      "e": 42154,
      "ty": 41,
      "x": 33308,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50791,
      "e": 42194,
      "ty": 6,
      "x": 962,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50801,
      "e": 42204,
      "ty": 2,
      "x": 962,
      "y": 698
    },
    {
      "t": 50900,
      "e": 42303,
      "ty": 2,
      "x": 962,
      "y": 687
    },
    {
      "t": 51001,
      "e": 42404,
      "ty": 2,
      "x": 962,
      "y": 681
    },
    {
      "t": 51001,
      "e": 42404,
      "ty": 41,
      "x": 33308,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51038,
      "e": 42441,
      "ty": 7,
      "x": 962,
      "y": 678,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51100,
      "e": 42503,
      "ty": 2,
      "x": 962,
      "y": 676
    },
    {
      "t": 51251,
      "e": 42654,
      "ty": 41,
      "x": 32875,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 51301,
      "e": 42704,
      "ty": 2,
      "x": 958,
      "y": 674
    },
    {
      "t": 51400,
      "e": 42803,
      "ty": 2,
      "x": 943,
      "y": 630
    },
    {
      "t": 51501,
      "e": 42904,
      "ty": 2,
      "x": 940,
      "y": 621
    },
    {
      "t": 51501,
      "e": 42904,
      "ty": 41,
      "x": 28549,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 51601,
      "e": 43004,
      "ty": 2,
      "x": 933,
      "y": 611
    },
    {
      "t": 51609,
      "e": 43012,
      "ty": 6,
      "x": 930,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51701,
      "e": 43104,
      "ty": 2,
      "x": 919,
      "y": 591
    },
    {
      "t": 51751,
      "e": 43154,
      "ty": 41,
      "x": 24007,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51766,
      "e": 43169,
      "ty": 3,
      "x": 919,
      "y": 591,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51767,
      "e": 43170,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "III"
    },
    {
      "t": 51768,
      "e": 43171,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51769,
      "e": 43172,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51800,
      "e": 43203,
      "ty": 2,
      "x": 919,
      "y": 590
    },
    {
      "t": 51844,
      "e": 43247,
      "ty": 4,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51844,
      "e": 43247,
      "ty": 5,
      "x": 919,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51925,
      "e": 43328,
      "ty": 3,
      "x": 919,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51988,
      "e": 43391,
      "ty": 4,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51988,
      "e": 43391,
      "ty": 5,
      "x": 919,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52001,
      "e": 43404,
      "ty": 41,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52061,
      "e": 43464,
      "ty": 3,
      "x": 919,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52125,
      "e": 43528,
      "ty": 4,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52125,
      "e": 43528,
      "ty": 5,
      "x": 919,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52409,
      "e": 43812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 52865,
      "e": 44268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 52866,
      "e": 44269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52945,
      "e": 44348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "C"
    },
    {
      "t": 53169,
      "e": 44572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 53170,
      "e": 44573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53224,
      "e": 44627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CH"
    },
    {
      "t": 53280,
      "e": 44683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 53280,
      "e": 44683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53369,
      "e": 44772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHA"
    },
    {
      "t": 53489,
      "e": 44892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 53490,
      "e": 44893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53560,
      "e": 44963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHAR"
    },
    {
      "t": 53608,
      "e": 45011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 53609,
      "e": 45012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53681,
      "e": 45084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||L"
    },
    {
      "t": 53793,
      "e": 45196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 53794,
      "e": 45197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53848,
      "e": 45251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||I"
    },
    {
      "t": 54008,
      "e": 45411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 54112,
      "e": 45515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 54612,
      "e": 46015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 54641,
      "e": 46044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 54641,
      "e": 46044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54696,
      "e": 46099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 54720,
      "e": 46123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 54781,
      "e": 46184,
      "ty": 7,
      "x": 928,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54800,
      "e": 46203,
      "ty": 2,
      "x": 936,
      "y": 622
    },
    {
      "t": 54901,
      "e": 46304,
      "ty": 2,
      "x": 962,
      "y": 669
    },
    {
      "t": 55001,
      "e": 46404,
      "ty": 41,
      "x": 33308,
      "y": 38052,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 55100,
      "e": 46503,
      "ty": 2,
      "x": 956,
      "y": 669
    },
    {
      "t": 55201,
      "e": 46604,
      "ty": 2,
      "x": 949,
      "y": 669
    },
    {
      "t": 55251,
      "e": 46654,
      "ty": 41,
      "x": 28333,
      "y": 40166,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 55278,
      "e": 46681,
      "ty": 6,
      "x": 911,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55300,
      "e": 46703,
      "ty": 2,
      "x": 901,
      "y": 682
    },
    {
      "t": 55401,
      "e": 46804,
      "ty": 2,
      "x": 886,
      "y": 682
    },
    {
      "t": 55429,
      "e": 46832,
      "ty": 3,
      "x": 886,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55430,
      "e": 46833,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "CHARLIE"
    },
    {
      "t": 55431,
      "e": 46834,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55431,
      "e": 46834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55501,
      "e": 46904,
      "ty": 41,
      "x": 16870,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55516,
      "e": 46919,
      "ty": 4,
      "x": 16870,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55517,
      "e": 46920,
      "ty": 5,
      "x": 886,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55677,
      "e": 47080,
      "ty": 3,
      "x": 886,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55756,
      "e": 47159,
      "ty": 4,
      "x": 16870,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55756,
      "e": 47159,
      "ty": 5,
      "x": 886,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56751,
      "e": 48154,
      "ty": 41,
      "x": 16654,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56801,
      "e": 48204,
      "ty": 2,
      "x": 888,
      "y": 688
    },
    {
      "t": 56862,
      "e": 48265,
      "ty": 7,
      "x": 898,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56895,
      "e": 48298,
      "ty": 6,
      "x": 907,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56900,
      "e": 48303,
      "ty": 2,
      "x": 907,
      "y": 708
    },
    {
      "t": 57000,
      "e": 48403,
      "ty": 2,
      "x": 920,
      "y": 718
    },
    {
      "t": 57001,
      "e": 48404,
      "ty": 41,
      "x": 12409,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57101,
      "e": 48504,
      "ty": 2,
      "x": 926,
      "y": 727
    },
    {
      "t": 57251,
      "e": 48654,
      "ty": 41,
      "x": 16532,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57300,
      "e": 48703,
      "ty": 2,
      "x": 936,
      "y": 712
    },
    {
      "t": 57347,
      "e": 48750,
      "ty": 7,
      "x": 938,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57400,
      "e": 48803,
      "ty": 2,
      "x": 938,
      "y": 701
    },
    {
      "t": 57414,
      "e": 48817,
      "ty": 6,
      "x": 938,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57501,
      "e": 48904,
      "ty": 2,
      "x": 941,
      "y": 688
    },
    {
      "t": 57502,
      "e": 48905,
      "ty": 41,
      "x": 28766,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57601,
      "e": 49004,
      "ty": 2,
      "x": 942,
      "y": 684
    },
    {
      "t": 57751,
      "e": 49154,
      "ty": 41,
      "x": 28982,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57925,
      "e": 49328,
      "ty": 3,
      "x": 942,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58020,
      "e": 49423,
      "ty": 4,
      "x": 28982,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58021,
      "e": 49424,
      "ty": 5,
      "x": 942,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58901,
      "e": 50304,
      "ty": 2,
      "x": 942,
      "y": 689
    },
    {
      "t": 58998,
      "e": 50401,
      "ty": 7,
      "x": 942,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59001,
      "e": 50404,
      "ty": 2,
      "x": 942,
      "y": 704
    },
    {
      "t": 59001,
      "e": 50404,
      "ty": 41,
      "x": 28982,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 59015,
      "e": 50418,
      "ty": 6,
      "x": 942,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59101,
      "e": 50504,
      "ty": 2,
      "x": 941,
      "y": 716
    },
    {
      "t": 59201,
      "e": 50604,
      "ty": 2,
      "x": 942,
      "y": 718
    },
    {
      "t": 59251,
      "e": 50654,
      "ty": 41,
      "x": 23748,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59301,
      "e": 50704,
      "ty": 2,
      "x": 943,
      "y": 718
    },
    {
      "t": 59404,
      "e": 50807,
      "ty": 2,
      "x": 946,
      "y": 718
    },
    {
      "t": 59505,
      "e": 50908,
      "ty": 41,
      "x": 25809,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 59905,
      "e": 51308,
      "ty": 2,
      "x": 947,
      "y": 718
    },
    {
      "t": 60004,
      "e": 51407,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60007,
      "e": 51410,
      "ty": 41,
      "x": 26325,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63204,
      "e": 54607,
      "ty": 2,
      "x": 948,
      "y": 718
    },
    {
      "t": 63255,
      "e": 54658,
      "ty": 41,
      "x": 26840,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63704,
      "e": 55107,
      "ty": 2,
      "x": 949,
      "y": 719
    },
    {
      "t": 63754,
      "e": 55157,
      "ty": 41,
      "x": 28386,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63803,
      "e": 55206,
      "ty": 2,
      "x": 953,
      "y": 720
    },
    {
      "t": 64004,
      "e": 55407,
      "ty": 41,
      "x": 29417,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 65004,
      "e": 56407,
      "ty": 2,
      "x": 955,
      "y": 722
    },
    {
      "t": 65004,
      "e": 56407,
      "ty": 41,
      "x": 30448,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67404,
      "e": 58807,
      "ty": 2,
      "x": 952,
      "y": 715
    },
    {
      "t": 67442,
      "e": 58845,
      "ty": 7,
      "x": 947,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67504,
      "e": 58907,
      "ty": 2,
      "x": 937,
      "y": 700
    },
    {
      "t": 67504,
      "e": 58907,
      "ty": 41,
      "x": 27901,
      "y": 59897,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67508,
      "e": 58911,
      "ty": 6,
      "x": 935,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67604,
      "e": 59007,
      "ty": 2,
      "x": 929,
      "y": 695
    },
    {
      "t": 67704,
      "e": 59107,
      "ty": 2,
      "x": 919,
      "y": 683
    },
    {
      "t": 67754,
      "e": 59157,
      "ty": 41,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67761,
      "e": 59164,
      "ty": 3,
      "x": 919,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67856,
      "e": 59259,
      "ty": 4,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67857,
      "e": 59260,
      "ty": 5,
      "x": 919,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67929,
      "e": 59332,
      "ty": 3,
      "x": 919,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67992,
      "e": 59395,
      "ty": 4,
      "x": 24007,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67993,
      "e": 59396,
      "ty": 5,
      "x": 919,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68580,
      "e": 59983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 68580,
      "e": 59983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68643,
      "e": 60046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 68732,
      "e": 60135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 68732,
      "e": 60135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68820,
      "e": 60223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 68908,
      "e": 60311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 68909,
      "e": 60312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68979,
      "e": 60382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 69204,
      "e": 60607,
      "ty": 2,
      "x": 918,
      "y": 696
    },
    {
      "t": 69210,
      "e": 60613,
      "ty": 7,
      "x": 918,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69253,
      "e": 60656,
      "ty": 41,
      "x": 23791,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 69304,
      "e": 60707,
      "ty": 2,
      "x": 920,
      "y": 707
    },
    {
      "t": 69326,
      "e": 60729,
      "ty": 6,
      "x": 923,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69404,
      "e": 60807,
      "ty": 2,
      "x": 926,
      "y": 710
    },
    {
      "t": 69504,
      "e": 60907,
      "ty": 2,
      "x": 935,
      "y": 714
    },
    {
      "t": 69504,
      "e": 60907,
      "ty": 41,
      "x": 20140,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69604,
      "e": 61007,
      "ty": 2,
      "x": 938,
      "y": 717
    },
    {
      "t": 69624,
      "e": 61027,
      "ty": 3,
      "x": 938,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69624,
      "e": 61027,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 69624,
      "e": 61027,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69625,
      "e": 61028,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69711,
      "e": 61114,
      "ty": 4,
      "x": 21686,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69713,
      "e": 61116,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69713,
      "e": 61116,
      "ty": 5,
      "x": 938,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69714,
      "e": 61117,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 69754,
      "e": 61157,
      "ty": 41,
      "x": 32027,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 70004,
      "e": 61407,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70404,
      "e": 61807,
      "ty": 2,
      "x": 939,
      "y": 712
    },
    {
      "t": 70504,
      "e": 61907,
      "ty": 41,
      "x": 32061,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 70799,
      "e": 62202,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 70829,
      "e": 62232,
      "ty": 6,
      "x": 939,
      "y": 712,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 70904,
      "e": 62307,
      "ty": 2,
      "x": 941,
      "y": 710
    },
    {
      "t": 70994,
      "e": 62397,
      "ty": 7,
      "x": 837,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 70995,
      "e": 62398,
      "ty": 6,
      "x": 837,
      "y": 697,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 71004,
      "e": 62407,
      "ty": 2,
      "x": 837,
      "y": 697
    },
    {
      "t": 71004,
      "e": 62407,
      "ty": 41,
      "x": 25584,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 71060,
      "e": 62463,
      "ty": 7,
      "x": 806,
      "y": 666,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 71104,
      "e": 62507,
      "ty": 2,
      "x": 806,
      "y": 657
    },
    {
      "t": 71204,
      "e": 62607,
      "ty": 2,
      "x": 806,
      "y": 649
    },
    {
      "t": 71254,
      "e": 62657,
      "ty": 41,
      "x": 25363,
      "y": 37485,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71304,
      "e": 62707,
      "ty": 2,
      "x": 809,
      "y": 641
    },
    {
      "t": 71604,
      "e": 63007,
      "ty": 2,
      "x": 796,
      "y": 639
    },
    {
      "t": 71704,
      "e": 63107,
      "ty": 2,
      "x": 775,
      "y": 646
    },
    {
      "t": 71754,
      "e": 63157,
      "ty": 41,
      "x": 22067,
      "y": 37485,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 71804,
      "e": 63207,
      "ty": 2,
      "x": 722,
      "y": 628
    },
    {
      "t": 71904,
      "e": 63307,
      "ty": 2,
      "x": 703,
      "y": 607
    },
    {
      "t": 72004,
      "e": 63407,
      "ty": 41,
      "x": 20148,
      "y": 31143,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 72104,
      "e": 63507,
      "ty": 2,
      "x": 702,
      "y": 607
    },
    {
      "t": 72254,
      "e": 63657,
      "ty": 41,
      "x": 19804,
      "y": 31453,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 72304,
      "e": 63707,
      "ty": 2,
      "x": 696,
      "y": 609
    },
    {
      "t": 73754,
      "e": 65157,
      "ty": 41,
      "x": 19804,
      "y": 31607,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 73804,
      "e": 65207,
      "ty": 2,
      "x": 732,
      "y": 621
    },
    {
      "t": 73904,
      "e": 65307,
      "ty": 2,
      "x": 812,
      "y": 631
    },
    {
      "t": 74004,
      "e": 65407,
      "ty": 41,
      "x": 25510,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 74404,
      "e": 65807,
      "ty": 2,
      "x": 817,
      "y": 645
    },
    {
      "t": 74430,
      "e": 65833,
      "ty": 6,
      "x": 831,
      "y": 682,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 74447,
      "e": 65850,
      "ty": 7,
      "x": 843,
      "y": 719,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 74447,
      "e": 65850,
      "ty": 6,
      "x": 843,
      "y": 719,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 74464,
      "e": 65867,
      "ty": 7,
      "x": 876,
      "y": 830,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 74504,
      "e": 65907,
      "ty": 2,
      "x": 973,
      "y": 1032
    },
    {
      "t": 74504,
      "e": 65907,
      "ty": 41,
      "x": 33431,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74604,
      "e": 66007,
      "ty": 2,
      "x": 1053,
      "y": 1201
    },
    {
      "t": 74755,
      "e": 66158,
      "ty": 41,
      "x": 35298,
      "y": 64759,
      "ta": "> div.masterdiv"
    },
    {
      "t": 74804,
      "e": 66207,
      "ty": 2,
      "x": 1016,
      "y": 1146
    },
    {
      "t": 74904,
      "e": 66307,
      "ty": 2,
      "x": 1003,
      "y": 1107
    },
    {
      "t": 74914,
      "e": 66317,
      "ty": 6,
      "x": 1001,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 75004,
      "e": 66407,
      "ty": 2,
      "x": 997,
      "y": 1093
    },
    {
      "t": 75004,
      "e": 66407,
      "ty": 41,
      "x": 47785,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 80004,
      "e": 71407,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 82605,
      "e": 71407,
      "ty": 2,
      "x": 997,
      "y": 1092
    },
    {
      "t": 82755,
      "e": 71557,
      "ty": 41,
      "x": 47785,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 83104,
      "e": 71906,
      "ty": 2,
      "x": 996,
      "y": 1092
    },
    {
      "t": 83254,
      "e": 72056,
      "ty": 41,
      "x": 46147,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 83304,
      "e": 72106,
      "ty": 2,
      "x": 994,
      "y": 1094
    },
    {
      "t": 83404,
      "e": 72206,
      "ty": 2,
      "x": 993,
      "y": 1097
    },
    {
      "t": 83504,
      "e": 72306,
      "ty": 2,
      "x": 996,
      "y": 1102
    },
    {
      "t": 83504,
      "e": 72306,
      "ty": 41,
      "x": 47239,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 85405,
      "e": 74207,
      "ty": 2,
      "x": 997,
      "y": 1104
    },
    {
      "t": 85451,
      "e": 74253,
      "ty": 7,
      "x": 997,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 85504,
      "e": 74306,
      "ty": 2,
      "x": 997,
      "y": 1107
    },
    {
      "t": 85504,
      "e": 74306,
      "ty": 41,
      "x": 50321,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 85728,
      "e": 74530,
      "ty": 6,
      "x": 999,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 85754,
      "e": 74556,
      "ty": 41,
      "x": 48878,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 85804,
      "e": 74606,
      "ty": 2,
      "x": 999,
      "y": 1105
    },
    {
      "t": 85904,
      "e": 74706,
      "ty": 2,
      "x": 1002,
      "y": 1098
    },
    {
      "t": 86005,
      "e": 74807,
      "ty": 41,
      "x": 50516,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 87204,
      "e": 76006,
      "ty": 2,
      "x": 1003,
      "y": 1096
    },
    {
      "t": 87255,
      "e": 76057,
      "ty": 41,
      "x": 51062,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 88304,
      "e": 77106,
      "ty": 2,
      "x": 1003,
      "y": 1094
    },
    {
      "t": 88405,
      "e": 77207,
      "ty": 2,
      "x": 1003,
      "y": 1092
    },
    {
      "t": 88504,
      "e": 77306,
      "ty": 2,
      "x": 1009,
      "y": 1082
    },
    {
      "t": 88504,
      "e": 77306,
      "ty": 41,
      "x": 54339,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 88905,
      "e": 77707,
      "ty": 2,
      "x": 1009,
      "y": 1083
    },
    {
      "t": 88976,
      "e": 77778,
      "ty": 7,
      "x": 1030,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 89004,
      "e": 77806,
      "ty": 2,
      "x": 1030,
      "y": 1090
    },
    {
      "t": 89004,
      "e": 77806,
      "ty": 41,
      "x": 35195,
      "y": 59939,
      "ta": "> div.masterdiv"
    },
    {
      "t": 89105,
      "e": 77907,
      "ty": 2,
      "x": 1031,
      "y": 1090
    },
    {
      "t": 89255,
      "e": 78057,
      "ty": 41,
      "x": 35229,
      "y": 59939,
      "ta": "> div.masterdiv"
    },
    {
      "t": 89304,
      "e": 78106,
      "ty": 2,
      "x": 1030,
      "y": 1091
    },
    {
      "t": 89441,
      "e": 78243,
      "ty": 6,
      "x": 1029,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 89505,
      "e": 78307,
      "ty": 2,
      "x": 1026,
      "y": 1093
    },
    {
      "t": 89505,
      "e": 78307,
      "ty": 41,
      "x": 63623,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 89605,
      "e": 78407,
      "ty": 2,
      "x": 1023,
      "y": 1095
    },
    {
      "t": 89705,
      "e": 78507,
      "ty": 2,
      "x": 1020,
      "y": 1095
    },
    {
      "t": 89755,
      "e": 78557,
      "ty": 41,
      "x": 55977,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 89803,
      "e": 78605,
      "ty": 2,
      "x": 1001,
      "y": 1088
    },
    {
      "t": 89904,
      "e": 78706,
      "ty": 2,
      "x": 999,
      "y": 1082
    },
    {
      "t": 89927,
      "e": 78729,
      "ty": 7,
      "x": 995,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 90004,
      "e": 78806,
      "ty": 2,
      "x": 993,
      "y": 1069
    },
    {
      "t": 90004,
      "e": 78806,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90006,
      "e": 78808,
      "ty": 41,
      "x": 34415,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90605,
      "e": 79407,
      "ty": 2,
      "x": 991,
      "y": 1070
    },
    {
      "t": 90755,
      "e": 79557,
      "ty": 41,
      "x": 34218,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90760,
      "e": 79562,
      "ty": 6,
      "x": 988,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 90803,
      "e": 79605,
      "ty": 2,
      "x": 986,
      "y": 1073
    },
    {
      "t": 90904,
      "e": 79706,
      "ty": 2,
      "x": 984,
      "y": 1075
    },
    {
      "t": 91004,
      "e": 79806,
      "ty": 41,
      "x": 40686,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 91049,
      "e": 79851,
      "ty": 3,
      "x": 984,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 91050,
      "e": 79852,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 91127,
      "e": 79929,
      "ty": 4,
      "x": 40686,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 91128,
      "e": 79930,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 91128,
      "e": 79930,
      "ty": 5,
      "x": 984,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 91129,
      "e": 79931,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 92131,
      "e": 80933,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 92503,
      "e": 81305,
      "ty": 2,
      "x": 983,
      "y": 1077
    },
    {
      "t": 92504,
      "e": 81306,
      "ty": 41,
      "x": 33576,
      "y": 59219,
      "ta": "html > body"
    },
    {
      "t": 92604,
      "e": 81406,
      "ty": 2,
      "x": 980,
      "y": 1078
    },
    {
      "t": 92754,
      "e": 81556,
      "ty": 41,
      "x": 33473,
      "y": 59275,
      "ta": "html > body"
    },
    {
      "t": 93403,
      "e": 82205,
      "ty": 2,
      "x": 963,
      "y": 930
    },
    {
      "t": 93504,
      "e": 82306,
      "ty": 2,
      "x": 932,
      "y": 756
    },
    {
      "t": 93504,
      "e": 82306,
      "ty": 41,
      "x": 31432,
      "y": 47404,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 95704,
      "e": 84506,
      "ty": 2,
      "x": 932,
      "y": 757
    },
    {
      "t": 95754,
      "e": 84556,
      "ty": 41,
      "x": 31432,
      "y": 47481,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 95904,
      "e": 84706,
      "ty": 2,
      "x": 931,
      "y": 757
    },
    {
      "t": 96003,
      "e": 84805,
      "ty": 2,
      "x": 931,
      "y": 758
    },
    {
      "t": 96005,
      "e": 84807,
      "ty": 41,
      "x": 31383,
      "y": 47559,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 96104,
      "e": 84906,
      "ty": 2,
      "x": 929,
      "y": 759
    },
    {
      "t": 96204,
      "e": 85006,
      "ty": 2,
      "x": 926,
      "y": 760
    },
    {
      "t": 96254,
      "e": 85056,
      "ty": 41,
      "x": 31141,
      "y": 47792,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 96304,
      "e": 85106,
      "ty": 2,
      "x": 925,
      "y": 762
    },
    {
      "t": 96404,
      "e": 85206,
      "ty": 2,
      "x": 923,
      "y": 763
    },
    {
      "t": 96504,
      "e": 85306,
      "ty": 2,
      "x": 921,
      "y": 767
    },
    {
      "t": 96505,
      "e": 85307,
      "ty": 41,
      "x": 30898,
      "y": 48258,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 96603,
      "e": 85405,
      "ty": 2,
      "x": 920,
      "y": 769
    },
    {
      "t": 96704,
      "e": 85506,
      "ty": 2,
      "x": 919,
      "y": 771
    },
    {
      "t": 96754,
      "e": 85556,
      "ty": 41,
      "x": 30801,
      "y": 48568,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 96804,
      "e": 85606,
      "ty": 2,
      "x": 918,
      "y": 772
    },
    {
      "t": 96904,
      "e": 85706,
      "ty": 2,
      "x": 917,
      "y": 773
    },
    {
      "t": 97004,
      "e": 85806,
      "ty": 41,
      "x": 30704,
      "y": 48724,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 99104,
      "e": 87906,
      "ty": 2,
      "x": 910,
      "y": 865
    },
    {
      "t": 99204,
      "e": 88006,
      "ty": 2,
      "x": 896,
      "y": 936
    },
    {
      "t": 99254,
      "e": 88056,
      "ty": 41,
      "x": 29248,
      "y": 63011,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 99303,
      "e": 88105,
      "ty": 2,
      "x": 886,
      "y": 958
    },
    {
      "t": 99505,
      "e": 88307,
      "ty": 41,
      "x": 29199,
      "y": 63089,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 99604,
      "e": 88406,
      "ty": 2,
      "x": 886,
      "y": 960
    },
    {
      "t": 99704,
      "e": 88506,
      "ty": 2,
      "x": 897,
      "y": 1009
    },
    {
      "t": 99754,
      "e": 88556,
      "ty": 41,
      "x": 14183,
      "y": 62024,
      "ta": "> p"
    },
    {
      "t": 99804,
      "e": 88606,
      "ty": 2,
      "x": 910,
      "y": 1040
    },
    {
      "t": 99904,
      "e": 88706,
      "ty": 2,
      "x": 924,
      "y": 1060
    },
    {
      "t": 100004,
      "e": 88806,
      "ty": 2,
      "x": 930,
      "y": 1034
    },
    {
      "t": 100004,
      "e": 88806,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100006,
      "e": 88808,
      "ty": 41,
      "x": 22326,
      "y": 62024,
      "ta": "> p"
    },
    {
      "t": 100105,
      "e": 88907,
      "ty": 2,
      "x": 936,
      "y": 1008
    },
    {
      "t": 100254,
      "e": 89056,
      "ty": 41,
      "x": 24450,
      "y": 1170,
      "ta": "> p"
    },
    {
      "t": 103381,
      "e": 92183,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 104388,
      "e": 93190,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 316, dom: 957, initialDom: 961",
  "javascriptErrors": []
}