var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "deb509a304ea12d9989df31053d52a12",
  "created": "2018-05-25T10:16:18.6316253-07:00",
  "lastActivity": "2018-05-25T10:17:55.7476253-07:00",
  "pageViews": [
    {
      "id": "05251811e8642f26a2f0140b758fa7b86250bbff",
      "startTime": "2018-05-25T10:16:18.6316253-07:00",
      "endTime": "2018-05-25T10:17:55.7476253-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 97116,
      "engagementTime": 27906,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 97116,
  "engagementTime": 27906,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FL092",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ee639d77af83de713e9987c3565be599",
  "gdpr": false
}