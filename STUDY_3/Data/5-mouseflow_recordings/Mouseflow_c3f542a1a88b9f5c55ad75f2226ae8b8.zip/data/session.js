var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c3f542a1a88b9f5c55ad75f2226ae8b8",
  "created": "2018-05-25T11:06:43.5642061-07:00",
  "lastActivity": "2018-05-25T11:09:34.0993568-07:00",
  "pageViews": [
    {
      "id": "05254319686886904ae0fb24591acae755e95ebd",
      "startTime": "2018-05-25T11:06:43.5642061-07:00",
      "endTime": "2018-05-25T11:09:34.0993568-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 170590,
      "engagementTime": 77907,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 170590,
  "engagementTime": 77907,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7bede94f4aa88d3553cdf250599a2825",
  "gdpr": false
}