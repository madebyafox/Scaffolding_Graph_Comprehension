var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05254319686886904ae0fb24591acae755e95ebd"] = {
  "startTime": "2018-05-25T18:06:43.5642061Z",
  "websitePageUrl": "/",
  "visitTime": 170590,
  "engagementTime": 77907,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c3f542a1a88b9f5c55ad75f2226ae8b8",
    "created": "2018-05-25T18:06:43.5642061+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7bede94f4aa88d3553cdf250599a2825",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c3f542a1a88b9f5c55ad75f2226ae8b8/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 362,
      "e": 362,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 511,
      "y": 1044
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 17322,
      "y": 57391,
      "ta": "html > body"
    },
    {
      "t": 10001,
      "e": 9252,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21401,
      "e": 9252,
      "ty": 2,
      "x": 510,
      "y": 1042
    },
    {
      "t": 21502,
      "e": 9353,
      "ty": 41,
      "x": 17287,
      "y": 57280,
      "ta": "html > body"
    },
    {
      "t": 30001,
      "e": 14353,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 104705,
      "e": 14353,
      "ty": 2,
      "x": 524,
      "y": 1028
    },
    {
      "t": 104756,
      "e": 14404,
      "ty": 41,
      "x": 16557,
      "y": 57108,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 104805,
      "e": 14453,
      "ty": 2,
      "x": 696,
      "y": 891
    },
    {
      "t": 104905,
      "e": 14553,
      "ty": 2,
      "x": 731,
      "y": 870
    },
    {
      "t": 105005,
      "e": 14653,
      "ty": 2,
      "x": 742,
      "y": 876
    },
    {
      "t": 105006,
      "e": 14654,
      "ty": 41,
      "x": 22067,
      "y": 52680,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 105105,
      "e": 14753,
      "ty": 2,
      "x": 771,
      "y": 887
    },
    {
      "t": 105205,
      "e": 14853,
      "ty": 2,
      "x": 806,
      "y": 896
    },
    {
      "t": 105255,
      "e": 14903,
      "ty": 41,
      "x": 25609,
      "y": 61913,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 105305,
      "e": 14953,
      "ty": 2,
      "x": 817,
      "y": 902
    },
    {
      "t": 105405,
      "e": 15053,
      "ty": 2,
      "x": 822,
      "y": 915
    },
    {
      "t": 105455,
      "e": 15103,
      "ty": 3,
      "x": 826,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 105505,
      "e": 15153,
      "ty": 2,
      "x": 826,
      "y": 922
    },
    {
      "t": 105506,
      "e": 15154,
      "ty": 41,
      "x": 4737,
      "y": 41750,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 105584,
      "e": 15232,
      "ty": 4,
      "x": 4737,
      "y": 41750,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 105584,
      "e": 15232,
      "ty": 5,
      "x": 826,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 105585,
      "e": 15233,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 105591,
      "e": 15239,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 105704,
      "e": 15352,
      "ty": 2,
      "x": 834,
      "y": 929
    },
    {
      "t": 105755,
      "e": 15403,
      "ty": 41,
      "x": 27232,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 105805,
      "e": 15453,
      "ty": 2,
      "x": 863,
      "y": 969
    },
    {
      "t": 105905,
      "e": 15553,
      "ty": 2,
      "x": 929,
      "y": 1050
    },
    {
      "t": 106005,
      "e": 15653,
      "ty": 2,
      "x": 941,
      "y": 1066
    },
    {
      "t": 106005,
      "e": 15653,
      "ty": 41,
      "x": 31857,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 106106,
      "e": 15754,
      "ty": 2,
      "x": 945,
      "y": 1071
    },
    {
      "t": 106205,
      "e": 15853,
      "ty": 2,
      "x": 948,
      "y": 1074
    },
    {
      "t": 106255,
      "e": 15903,
      "ty": 41,
      "x": 21571,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 106305,
      "e": 15953,
      "ty": 2,
      "x": 949,
      "y": 1076
    },
    {
      "t": 106377,
      "e": 16025,
      "ty": 3,
      "x": 949,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 106378,
      "e": 16026,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 106379,
      "e": 16027,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106528,
      "e": 16176,
      "ty": 4,
      "x": 21571,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 106531,
      "e": 16179,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 106535,
      "e": 16183,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 106535,
      "e": 16183,
      "ty": 5,
      "x": 949,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 107540,
      "e": 17188,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 108205,
      "e": 17853,
      "ty": 2,
      "x": 948,
      "y": 1065
    },
    {
      "t": 108256,
      "e": 17904,
      "ty": 41,
      "x": 31923,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 108305,
      "e": 17953,
      "ty": 2,
      "x": 925,
      "y": 965
    },
    {
      "t": 108406,
      "e": 18054,
      "ty": 2,
      "x": 902,
      "y": 889
    },
    {
      "t": 108505,
      "e": 18153,
      "ty": 2,
      "x": 873,
      "y": 745
    },
    {
      "t": 108505,
      "e": 18153,
      "ty": 41,
      "x": 29788,
      "y": 40827,
      "ta": "html > body"
    },
    {
      "t": 108542,
      "e": 18190,
      "ty": 6,
      "x": 872,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108574,
      "e": 18222,
      "ty": 7,
      "x": 872,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 108605,
      "e": 18253,
      "ty": 2,
      "x": 872,
      "y": 668
    },
    {
      "t": 108705,
      "e": 18353,
      "ty": 2,
      "x": 894,
      "y": 615
    },
    {
      "t": 108724,
      "e": 18372,
      "ty": 6,
      "x": 906,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108755,
      "e": 18403,
      "ty": 41,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108805,
      "e": 18453,
      "ty": 2,
      "x": 907,
      "y": 602
    },
    {
      "t": 108976,
      "e": 18624,
      "ty": 3,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 108978,
      "e": 18626,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109119,
      "e": 18767,
      "ty": 4,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 109119,
      "e": 18767,
      "ty": 5,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 110005,
      "e": 19653,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 111933,
      "e": 21581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 112404,
      "e": 22052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 112684,
      "e": 22332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 112811,
      "e": 22459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 112812,
      "e": 22460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 112859,
      "e": 22507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 112875,
      "e": 22523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 112955,
      "e": 22603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 112955,
      "e": 22603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113027,
      "e": 22675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 113067,
      "e": 22715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 113070,
      "e": 22718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113171,
      "e": 22819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 113387,
      "e": 23035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 113388,
      "e": 23036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113491,
      "e": 23139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 113491,
      "e": 23139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113522,
      "e": 23170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Novem"
    },
    {
      "t": 113603,
      "e": 23251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 113715,
      "e": 23363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 113717,
      "e": 23365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113803,
      "e": 23451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 113883,
      "e": 23531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 113884,
      "e": 23532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113964,
      "e": 23612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 113965,
      "e": 23613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 113995,
      "e": 23643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||er"
    },
    {
      "t": 114068,
      "e": 23716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 115132,
      "e": 24780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 115133,
      "e": 24781,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 115133,
      "e": 24781,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 115134,
      "e": 24782,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 115275,
      "e": 24923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 117784,
      "e": 27432,
      "ty": 3,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 117785,
      "e": 27433,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 117786,
      "e": 27434,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 117870,
      "e": 27518,
      "ty": 4,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 117870,
      "e": 27518,
      "ty": 5,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 117951,
      "e": 27599,
      "ty": 3,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118031,
      "e": 27679,
      "ty": 4,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118031,
      "e": 27679,
      "ty": 5,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118579,
      "e": 28227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 118580,
      "e": 28228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118691,
      "e": 28339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 118691,
      "e": 28339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118698,
      "e": 28346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "no"
    },
    {
      "t": 118795,
      "e": 28443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 118795,
      "e": 28443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 118802,
      "e": 28450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nob"
    },
    {
      "t": 118867,
      "e": 28515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nob"
    },
    {
      "t": 118924,
      "e": 28572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 118924,
      "e": 28572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 119043,
      "e": 28691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 119043,
      "e": 28691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 119051,
      "e": 28699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nobem"
    },
    {
      "t": 119131,
      "e": 28779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 119179,
      "e": 28827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 119181,
      "e": 28829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 119258,
      "e": 28906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 119420,
      "e": 29068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 119474,
      "e": 29122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nobem"
    },
    {
      "t": 119578,
      "e": 29226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 119615,
      "e": 29263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nobe"
    },
    {
      "t": 119704,
      "e": 29352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 119750,
      "e": 29398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nob"
    },
    {
      "t": 119847,
      "e": 29495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 119887,
      "e": 29535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 119887,
      "e": 29535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 119911,
      "e": 29559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nov"
    },
    {
      "t": 119975,
      "e": 29623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nov"
    },
    {
      "t": 120008,
      "e": 29656,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120062,
      "e": 29710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 120062,
      "e": 29710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120167,
      "e": 29815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "novm"
    },
    {
      "t": 120327,
      "e": 29975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 120382,
      "e": 30030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nov"
    },
    {
      "t": 120391,
      "e": 30039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 120391,
      "e": 30039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120470,
      "e": 30118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "nove"
    },
    {
      "t": 120503,
      "e": 30151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 120503,
      "e": 30151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120575,
      "e": 30223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 120575,
      "e": 30223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 120576,
      "e": 30224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120686,
      "e": 30334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 120742,
      "e": 30390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 120742,
      "e": 30390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120839,
      "e": 30487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 120840,
      "e": 30488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 120887,
      "e": 30535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||er"
    },
    {
      "t": 120959,
      "e": 30607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 122504,
      "e": 32152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 122504,
      "e": 32152,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "november"
    },
    {
      "t": 122505,
      "e": 32153,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 122507,
      "e": 32155,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 122671,
      "e": 32319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 123014,
      "e": 32662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 123016,
      "e": 32664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123127,
      "e": 32775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 123239,
      "e": 32887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 123240,
      "e": 32888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123360,
      "e": 33008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 123360,
      "e": 33008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 123391,
      "e": 33039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 123455,
      "e": 33103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 124371,
      "e": 34019,
      "ty": 3,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124373,
      "e": 34021,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 124373,
      "e": 34021,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 124374,
      "e": 34022,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124442,
      "e": 34090,
      "ty": 4,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124442,
      "e": 34090,
      "ty": 5,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124514,
      "e": 34162,
      "ty": 3,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124586,
      "e": 34234,
      "ty": 4,
      "x": 21412,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124586,
      "e": 34234,
      "ty": 5,
      "x": 907,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 124791,
      "e": 34439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 124902,
      "e": 34550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 125119,
      "e": 34767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 125120,
      "e": 34768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125214,
      "e": 34862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 125215,
      "e": 34863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125254,
      "e": 34902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 125311,
      "e": 34959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 125351,
      "e": 34999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 125353,
      "e": 35001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125455,
      "e": 35103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 125462,
      "e": 35110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 125462,
      "e": 35110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125526,
      "e": 35174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 125543,
      "e": 35191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 125543,
      "e": 35191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125631,
      "e": 35279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 125663,
      "e": 35311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 125664,
      "e": 35312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125750,
      "e": 35398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||B"
    },
    {
      "t": 125806,
      "e": 35454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 125807,
      "e": 35455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125871,
      "e": 35519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 125871,
      "e": 35519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 125894,
      "e": 35542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||ER"
    },
    {
      "t": 125934,
      "e": 35582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 126071,
      "e": 35719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 126191,
      "e": 35839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 126467,
      "e": 36115,
      "ty": 7,
      "x": 887,
      "y": 615,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126509,
      "e": 36157,
      "ty": 2,
      "x": 799,
      "y": 674
    },
    {
      "t": 126509,
      "e": 36157,
      "ty": 41,
      "x": 27240,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 126609,
      "e": 36257,
      "ty": 2,
      "x": 831,
      "y": 721
    },
    {
      "t": 126709,
      "e": 36357,
      "ty": 2,
      "x": 899,
      "y": 743
    },
    {
      "t": 126759,
      "e": 36407,
      "ty": 41,
      "x": 31062,
      "y": 40772,
      "ta": "html > body"
    },
    {
      "t": 126809,
      "e": 36457,
      "ty": 6,
      "x": 935,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 126810,
      "e": 36458,
      "ty": 2,
      "x": 935,
      "y": 740
    },
    {
      "t": 126908,
      "e": 36556,
      "ty": 2,
      "x": 943,
      "y": 733
    },
    {
      "t": 127009,
      "e": 36657,
      "ty": 41,
      "x": 24263,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129044,
      "e": 38692,
      "ty": 7,
      "x": 924,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129060,
      "e": 38708,
      "ty": 6,
      "x": 921,
      "y": 694,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129109,
      "e": 38757,
      "ty": 2,
      "x": 913,
      "y": 687
    },
    {
      "t": 129208,
      "e": 38856,
      "ty": 2,
      "x": 909,
      "y": 684
    },
    {
      "t": 129259,
      "e": 38907,
      "ty": 41,
      "x": 21628,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129299,
      "e": 38947,
      "ty": 3,
      "x": 908,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129300,
      "e": 38948,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 129301,
      "e": 38949,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129302,
      "e": 38950,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129309,
      "e": 38957,
      "ty": 2,
      "x": 908,
      "y": 683
    },
    {
      "t": 129434,
      "e": 39082,
      "ty": 4,
      "x": 21628,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129435,
      "e": 39083,
      "ty": 5,
      "x": 908,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129677,
      "e": 39325,
      "ty": 7,
      "x": 942,
      "y": 703,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 129709,
      "e": 39357,
      "ty": 2,
      "x": 951,
      "y": 706
    },
    {
      "t": 129711,
      "e": 39359,
      "ty": 6,
      "x": 963,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129759,
      "e": 39407,
      "ty": 41,
      "x": 38694,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129809,
      "e": 39457,
      "ty": 2,
      "x": 972,
      "y": 717
    },
    {
      "t": 130009,
      "e": 39657,
      "ty": 41,
      "x": 39209,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 130009,
      "e": 39657,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130654,
      "e": 40302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 130838,
      "e": 40486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 131587,
      "e": 41235,
      "ty": 3,
      "x": 972,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 131589,
      "e": 41237,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131589,
      "e": 41237,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 131666,
      "e": 41314,
      "ty": 4,
      "x": 39209,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 131668,
      "e": 41316,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 131668,
      "e": 41316,
      "ty": 5,
      "x": 972,
      "y": 717,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 131668,
      "e": 41316,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 132785,
      "e": 42433,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 132812,
      "e": 42460,
      "ty": 6,
      "x": 972,
      "y": 717,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 134209,
      "e": 43857,
      "ty": 2,
      "x": 964,
      "y": 721
    },
    {
      "t": 134259,
      "e": 43907,
      "ty": 41,
      "x": 31917,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 134308,
      "e": 43956,
      "ty": 2,
      "x": 962,
      "y": 722
    },
    {
      "t": 134609,
      "e": 44257,
      "ty": 2,
      "x": 961,
      "y": 722
    },
    {
      "t": 134759,
      "e": 44407,
      "ty": 41,
      "x": 31866,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 134983,
      "e": 44631,
      "ty": 7,
      "x": 953,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 134983,
      "e": 44631,
      "ty": 6,
      "x": 953,
      "y": 729,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 135009,
      "e": 44657,
      "ty": 2,
      "x": 942,
      "y": 734
    },
    {
      "t": 135010,
      "e": 44658,
      "ty": 41,
      "x": 30904,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 135109,
      "e": 44757,
      "ty": 2,
      "x": 919,
      "y": 746
    },
    {
      "t": 135259,
      "e": 44907,
      "ty": 41,
      "x": 29738,
      "y": 44506,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 135300,
      "e": 44948,
      "ty": 7,
      "x": 887,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 135300,
      "e": 44948,
      "ty": 6,
      "x": 887,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 135309,
      "e": 44957,
      "ty": 2,
      "x": 887,
      "y": 711
    },
    {
      "t": 135316,
      "e": 44964,
      "ty": 7,
      "x": 846,
      "y": 668,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 135366,
      "e": 45014,
      "ty": 6,
      "x": 691,
      "y": 512,
      "ta": "#da1"
    },
    {
      "t": 135383,
      "e": 45031,
      "ty": 7,
      "x": 650,
      "y": 469,
      "ta": "#da1"
    },
    {
      "t": 135409,
      "e": 45057,
      "ty": 2,
      "x": 635,
      "y": 453
    },
    {
      "t": 135509,
      "e": 45157,
      "ty": 2,
      "x": 628,
      "y": 440
    },
    {
      "t": 135509,
      "e": 45157,
      "ty": 41,
      "x": 16458,
      "y": 39807,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 135609,
      "e": 45257,
      "ty": 2,
      "x": 582,
      "y": 492
    },
    {
      "t": 135633,
      "e": 45281,
      "ty": 6,
      "x": 563,
      "y": 518,
      "ta": "#da1"
    },
    {
      "t": 135683,
      "e": 45331,
      "ty": 7,
      "x": 546,
      "y": 535,
      "ta": "#da1"
    },
    {
      "t": 135709,
      "e": 45357,
      "ty": 2,
      "x": 546,
      "y": 535
    },
    {
      "t": 135759,
      "e": 45407,
      "ty": 41,
      "x": 24594,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 135809,
      "e": 45457,
      "ty": 2,
      "x": 562,
      "y": 562
    },
    {
      "t": 135908,
      "e": 45556,
      "ty": 2,
      "x": 569,
      "y": 566
    },
    {
      "t": 136010,
      "e": 45658,
      "ty": 41,
      "x": 25684,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 140009,
      "e": 49657,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140109,
      "e": 49757,
      "ty": 2,
      "x": 569,
      "y": 572
    },
    {
      "t": 140209,
      "e": 49857,
      "ty": 2,
      "x": 561,
      "y": 597
    },
    {
      "t": 140260,
      "e": 49908,
      "ty": 41,
      "x": 24703,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td"
    },
    {
      "t": 140309,
      "e": 49957,
      "ty": 2,
      "x": 566,
      "y": 614
    },
    {
      "t": 140409,
      "e": 50057,
      "ty": 2,
      "x": 578,
      "y": 638
    },
    {
      "t": 140509,
      "e": 50157,
      "ty": 2,
      "x": 581,
      "y": 642
    },
    {
      "t": 140509,
      "e": 50157,
      "ty": 41,
      "x": 62860,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 140609,
      "e": 50257,
      "ty": 2,
      "x": 582,
      "y": 642
    },
    {
      "t": 140759,
      "e": 50407,
      "ty": 41,
      "x": 63079,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 142205,
      "e": 51853,
      "ty": 6,
      "x": 592,
      "y": 672,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 142209,
      "e": 51857,
      "ty": 2,
      "x": 592,
      "y": 672
    },
    {
      "t": 142260,
      "e": 51908,
      "ty": 41,
      "x": 13475,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 142271,
      "e": 51919,
      "ty": 7,
      "x": 604,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 142271,
      "e": 51919,
      "ty": 6,
      "x": 604,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 142309,
      "e": 51957,
      "ty": 2,
      "x": 614,
      "y": 716
    },
    {
      "t": 142371,
      "e": 52019,
      "ty": 7,
      "x": 616,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 142372,
      "e": 52020,
      "ty": 6,
      "x": 616,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 142410,
      "e": 52058,
      "ty": 2,
      "x": 616,
      "y": 728
    },
    {
      "t": 142505,
      "e": 52153,
      "ty": 7,
      "x": 635,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 142506,
      "e": 52154,
      "ty": 6,
      "x": 635,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 142509,
      "e": 52157,
      "ty": 2,
      "x": 635,
      "y": 756
    },
    {
      "t": 142510,
      "e": 52158,
      "ty": 41,
      "x": 15350,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 142555,
      "e": 52203,
      "ty": 7,
      "x": 657,
      "y": 788,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 142610,
      "e": 52258,
      "ty": 2,
      "x": 684,
      "y": 822
    },
    {
      "t": 142709,
      "e": 52357,
      "ty": 2,
      "x": 720,
      "y": 883
    },
    {
      "t": 142760,
      "e": 52408,
      "ty": 41,
      "x": 21673,
      "y": 54200,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 142809,
      "e": 52457,
      "ty": 2,
      "x": 742,
      "y": 923
    },
    {
      "t": 142909,
      "e": 52557,
      "ty": 2,
      "x": 754,
      "y": 936
    },
    {
      "t": 143009,
      "e": 52657,
      "ty": 2,
      "x": 756,
      "y": 936
    },
    {
      "t": 143010,
      "e": 52658,
      "ty": 41,
      "x": 22755,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143109,
      "e": 52757,
      "ty": 2,
      "x": 767,
      "y": 926
    },
    {
      "t": 143209,
      "e": 52857,
      "ty": 2,
      "x": 792,
      "y": 903
    },
    {
      "t": 143259,
      "e": 52907,
      "ty": 41,
      "x": 24871,
      "y": 53507,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143309,
      "e": 52957,
      "ty": 2,
      "x": 802,
      "y": 899
    },
    {
      "t": 143409,
      "e": 53057,
      "ty": 2,
      "x": 842,
      "y": 930
    },
    {
      "t": 143509,
      "e": 53157,
      "ty": 2,
      "x": 866,
      "y": 950
    },
    {
      "t": 143509,
      "e": 53157,
      "ty": 41,
      "x": 28167,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143910,
      "e": 53558,
      "ty": 2,
      "x": 873,
      "y": 951
    },
    {
      "t": 144010,
      "e": 53658,
      "ty": 2,
      "x": 875,
      "y": 953
    },
    {
      "t": 144010,
      "e": 53658,
      "ty": 41,
      "x": 28610,
      "y": 57246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144109,
      "e": 53757,
      "ty": 2,
      "x": 883,
      "y": 973
    },
    {
      "t": 144209,
      "e": 53857,
      "ty": 2,
      "x": 896,
      "y": 1003
    },
    {
      "t": 144259,
      "e": 53907,
      "ty": 41,
      "x": 29643,
      "y": 60709,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146509,
      "e": 56157,
      "ty": 2,
      "x": 896,
      "y": 1002
    },
    {
      "t": 146509,
      "e": 56157,
      "ty": 41,
      "x": 29643,
      "y": 60640,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146609,
      "e": 56257,
      "ty": 2,
      "x": 894,
      "y": 1001
    },
    {
      "t": 146759,
      "e": 56407,
      "ty": 41,
      "x": 29545,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146892,
      "e": 56540,
      "ty": 6,
      "x": 954,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 146909,
      "e": 56557,
      "ty": 2,
      "x": 965,
      "y": 1092
    },
    {
      "t": 146958,
      "e": 56606,
      "ty": 7,
      "x": 978,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 147008,
      "e": 56656,
      "ty": 2,
      "x": 981,
      "y": 1113
    },
    {
      "t": 147008,
      "e": 56656,
      "ty": 41,
      "x": 42831,
      "y": 22332,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 147108,
      "e": 56756,
      "ty": 2,
      "x": 991,
      "y": 1126
    },
    {
      "t": 147208,
      "e": 56856,
      "ty": 6,
      "x": 994,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 147209,
      "e": 56857,
      "ty": 2,
      "x": 994,
      "y": 1101
    },
    {
      "t": 147259,
      "e": 56907,
      "ty": 41,
      "x": 40140,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 147309,
      "e": 56957,
      "ty": 2,
      "x": 983,
      "y": 1078
    },
    {
      "t": 147508,
      "e": 57156,
      "ty": 2,
      "x": 981,
      "y": 1077
    },
    {
      "t": 147509,
      "e": 57157,
      "ty": 41,
      "x": 39047,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 147608,
      "e": 57256,
      "ty": 2,
      "x": 975,
      "y": 1084
    },
    {
      "t": 147708,
      "e": 57356,
      "ty": 2,
      "x": 971,
      "y": 1087
    },
    {
      "t": 147758,
      "e": 57406,
      "ty": 41,
      "x": 33586,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 148909,
      "e": 58557,
      "ty": 2,
      "x": 968,
      "y": 1087
    },
    {
      "t": 149008,
      "e": 58656,
      "ty": 41,
      "x": 31948,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 150008,
      "e": 59656,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150608,
      "e": 60256,
      "ty": 2,
      "x": 967,
      "y": 1087
    },
    {
      "t": 150708,
      "e": 60356,
      "ty": 2,
      "x": 965,
      "y": 1088
    },
    {
      "t": 150759,
      "e": 60407,
      "ty": 41,
      "x": 30309,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 151108,
      "e": 60756,
      "ty": 2,
      "x": 965,
      "y": 1089
    },
    {
      "t": 151259,
      "e": 60907,
      "ty": 41,
      "x": 30309,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 152259,
      "e": 61907,
      "ty": 41,
      "x": 29763,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 152309,
      "e": 61957,
      "ty": 2,
      "x": 959,
      "y": 1089
    },
    {
      "t": 152408,
      "e": 62056,
      "ty": 2,
      "x": 954,
      "y": 1089
    },
    {
      "t": 152509,
      "e": 62157,
      "ty": 41,
      "x": 24302,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 153409,
      "e": 63057,
      "ty": 2,
      "x": 953,
      "y": 1090
    },
    {
      "t": 153509,
      "e": 63157,
      "ty": 41,
      "x": 23756,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 153515,
      "e": 63163,
      "ty": 3,
      "x": 953,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 153517,
      "e": 63165,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153657,
      "e": 63305,
      "ty": 4,
      "x": 23756,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 153658,
      "e": 63306,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 153659,
      "e": 63307,
      "ty": 5,
      "x": 953,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 153662,
      "e": 63310,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 154662,
      "e": 64310,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 155108,
      "e": 64756,
      "ty": 2,
      "x": 953,
      "y": 1091
    },
    {
      "t": 155258,
      "e": 64906,
      "ty": 41,
      "x": 32543,
      "y": 59995,
      "ta": "html > body"
    },
    {
      "t": 156208,
      "e": 65856,
      "ty": 2,
      "x": 931,
      "y": 1080
    },
    {
      "t": 156259,
      "e": 65907,
      "ty": 41,
      "x": 30167,
      "y": 57502,
      "ta": "html > body"
    },
    {
      "t": 156308,
      "e": 65956,
      "ty": 2,
      "x": 869,
      "y": 1030
    },
    {
      "t": 156409,
      "e": 66057,
      "ty": 2,
      "x": 856,
      "y": 1022
    },
    {
      "t": 156509,
      "e": 66157,
      "ty": 2,
      "x": 849,
      "y": 1018
    },
    {
      "t": 156509,
      "e": 66157,
      "ty": 41,
      "x": 28962,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 156709,
      "e": 66357,
      "ty": 2,
      "x": 845,
      "y": 1016
    },
    {
      "t": 156759,
      "e": 66407,
      "ty": 41,
      "x": 28824,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 156809,
      "e": 66457,
      "ty": 2,
      "x": 843,
      "y": 1016
    },
    {
      "t": 156908,
      "e": 66556,
      "ty": 2,
      "x": 841,
      "y": 1014
    },
    {
      "t": 157008,
      "e": 66656,
      "ty": 2,
      "x": 839,
      "y": 1014
    },
    {
      "t": 157008,
      "e": 66656,
      "ty": 41,
      "x": 28617,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 157108,
      "e": 66756,
      "ty": 2,
      "x": 836,
      "y": 1012
    },
    {
      "t": 157209,
      "e": 66857,
      "ty": 2,
      "x": 833,
      "y": 1011
    },
    {
      "t": 157259,
      "e": 66907,
      "ty": 41,
      "x": 28411,
      "y": 55563,
      "ta": "html > body"
    },
    {
      "t": 157309,
      "e": 66957,
      "ty": 2,
      "x": 830,
      "y": 1010
    },
    {
      "t": 157408,
      "e": 67056,
      "ty": 2,
      "x": 829,
      "y": 1010
    },
    {
      "t": 157509,
      "e": 67157,
      "ty": 41,
      "x": 28273,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 160009,
      "e": 69657,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 161009,
      "e": 70657,
      "ty": 2,
      "x": 827,
      "y": 1008
    },
    {
      "t": 161009,
      "e": 70657,
      "ty": 41,
      "x": 28204,
      "y": 55397,
      "ta": "html > body"
    },
    {
      "t": 161109,
      "e": 70757,
      "ty": 2,
      "x": 818,
      "y": 998
    },
    {
      "t": 161209,
      "e": 70857,
      "ty": 2,
      "x": 813,
      "y": 996
    },
    {
      "t": 161259,
      "e": 70907,
      "ty": 41,
      "x": 27722,
      "y": 54732,
      "ta": "html > body"
    },
    {
      "t": 163209,
      "e": 72857,
      "ty": 2,
      "x": 811,
      "y": 996
    },
    {
      "t": 163259,
      "e": 72907,
      "ty": 41,
      "x": 27653,
      "y": 54732,
      "ta": "html > body"
    },
    {
      "t": 169584,
      "e": 77907,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 170009,
      "e": 77907,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170590,
      "e": 77907,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 297, dom: 1253, initialDom: 1556",
  "javascriptErrors": []
}