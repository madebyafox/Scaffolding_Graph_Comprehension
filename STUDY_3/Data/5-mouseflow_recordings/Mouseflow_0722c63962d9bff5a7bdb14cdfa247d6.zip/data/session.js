var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0722c63962d9bff5a7bdb14cdfa247d6",
  "created": "2018-06-01T11:27:06.0503718-07:00",
  "lastActivity": "2018-06-01T11:27:19.8293718-07:00",
  "pageViews": [
    {
      "id": "06010614aae142972feefd35bb12da5e21b9f938",
      "startTime": "2018-06-01T11:27:06.0503718-07:00",
      "endTime": "2018-06-01T11:27:19.8293718-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 13779,
      "engagementTime": 13779,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13779,
  "engagementTime": 13779,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FBPNS",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "196eab2669de5698e80d0ea0a5d8f0cf",
  "gdpr": false
}