var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529096954adbf08b82a3a06bb7bebadef0d7933"] = {
  "startTime": "2018-05-29T21:17:08.9673159Z",
  "websitePageUrl": "/16",
  "visitTime": 129364,
  "engagementTime": 105258,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2002ea4d864465758b03c94926eb7f7a",
    "created": "2018-05-29T21:17:08.9673159+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=7H6QC",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bcf614857d4cf29145c3ba74d20dcfed",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2002ea4d864465758b03c94926eb7f7a/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 182,
      "e": 182,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 182,
      "e": 182,
      "ty": 2,
      "x": 512,
      "y": 752
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 46639,
      "y": 41215,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 503,
      "y": 737
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 40906,
      "y": 35509,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 754,
      "e": 754,
      "ty": 6,
      "x": 440,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 424,
      "y": 560
    },
    {
      "t": 905,
      "e": 905,
      "ty": 2,
      "x": 422,
      "y": 552
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 36522,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1143,
      "e": 1143,
      "ty": 3,
      "x": 422,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1143,
      "e": 1143,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1295,
      "e": 1295,
      "ty": 4,
      "x": 36522,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1295,
      "e": 1295,
      "ty": 5,
      "x": 422,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 354,
      "y": 583
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 28878,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4057,
      "e": 4057,
      "ty": 7,
      "x": 275,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 268,
      "y": 609
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 266,
      "y": 610
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 18874,
      "y": 64563,
      "ta": "#.strategy"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 265,
      "y": 610
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 264,
      "y": 610
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 258,
      "y": 609
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 18087,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 257,
      "y": 608
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 257,
      "y": 606
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 17975,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 4759,
      "e": 4759,
      "ty": 6,
      "x": 257,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 257,
      "y": 602
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 258,
      "y": 600
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 260,
      "y": 599
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 18312,
      "y": 61704,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 264,
      "y": 593
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 292,
      "y": 547
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 306,
      "y": 537
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 23483,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5541,
      "e": 5541,
      "ty": 7,
      "x": 333,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 431,
      "y": 440
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 580,
      "y": 267
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 54283,
      "y": 14237,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 580,
      "y": 265
    },
    {
      "t": 7091,
      "e": 7091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 7091,
      "e": 7091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7195,
      "e": 7195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 7195,
      "e": 7195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7267,
      "e": 7267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "im"
    },
    {
      "t": 7338,
      "e": 7338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "im"
    },
    {
      "t": 7370,
      "e": 7370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7370,
      "e": 7370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7506,
      "e": 7506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "ima"
    },
    {
      "t": 7587,
      "e": 7587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 7587,
      "e": 7587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7707,
      "e": 7707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 7707,
      "e": 7707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7731,
      "e": 7731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "imagi"
    },
    {
      "t": 7778,
      "e": 7778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7779,
      "e": 7779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7834,
      "e": 7834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 7851,
      "e": 7851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7851,
      "e": 7851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7867,
      "e": 7867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 7962,
      "e": 7962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7970,
      "e": 7970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7971,
      "e": 7971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8012,
      "e": 8012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8012,
      "e": 8012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8043,
      "e": 8043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 8139,
      "e": 8139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8139,
      "e": 8139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8147,
      "e": 8147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8235,
      "e": 8235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8290,
      "e": 8290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 8290,
      "e": 8290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8307,
      "e": 8307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 8643,
      "e": 8643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8723,
      "e": 8723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "imagine a "
    },
    {
      "t": 8778,
      "e": 8778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 8779,
      "e": 8779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8890,
      "e": 8890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 9003,
      "e": 9003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9003,
      "e": 9003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9042,
      "e": 9042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 9043,
      "e": 9043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9106,
      "e": 9106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 9123,
      "e": 9123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9227,
      "e": 9227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9227,
      "e": 9227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9299,
      "e": 9299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9307,
      "e": 9307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 9307,
      "e": 9307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9355,
      "e": 9355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 9707,
      "e": 9707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 9708,
      "e": 9708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9738,
      "e": 9738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9738,
      "e": 9738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9771,
      "e": 9771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 9866,
      "e": 9866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9914,
      "e": 9914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9915,
      "e": 9915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10027,
      "e": 10027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 10128,
      "e": 10128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10243,
      "e": 10243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10243,
      "e": 10243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10395,
      "e": 10395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10395,
      "e": 10395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10427,
      "e": 10427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 10458,
      "e": 10458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10458,
      "e": 10458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10522,
      "e": 10522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11043,
      "e": 11043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11043,
      "e": 11043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11147,
      "e": 11147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11339,
      "e": 11339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11339,
      "e": 11339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11435,
      "e": 11435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 16435,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30358,
      "e": 16435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30858,
      "e": 16935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30891,
      "e": 16968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30923,
      "e": 17000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30957,
      "e": 17034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30990,
      "e": 17067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31023,
      "e": 17100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31056,
      "e": 17133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31088,
      "e": 17165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31122,
      "e": 17199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31155,
      "e": 17232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31188,
      "e": 17265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31221,
      "e": 17298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31254,
      "e": 17331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31287,
      "e": 17364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31320,
      "e": 17397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31353,
      "e": 17430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31386,
      "e": 17463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31419,
      "e": 17496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31452,
      "e": 17529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31485,
      "e": 17562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31518,
      "e": 17595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31551,
      "e": 17628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31584,
      "e": 17661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31617,
      "e": 17694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31650,
      "e": 17727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31683,
      "e": 17760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31715,
      "e": 17792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31748,
      "e": 17825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31782,
      "e": 17859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31782,
      "e": 17859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 31997,
      "e": 18074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31998,
      "e": 18075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32110,
      "e": 18187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "a"
    },
    {
      "t": 32142,
      "e": 18219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32143,
      "e": 18220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32222,
      "e": 18299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "al"
    },
    {
      "t": 32262,
      "e": 18339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32262,
      "e": 18339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32358,
      "e": 18435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all"
    },
    {
      "t": 32582,
      "e": 18659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32582,
      "e": 18659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32670,
      "e": 18747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "alll"
    },
    {
      "t": 33038,
      "e": 19115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33150,
      "e": 19227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all"
    },
    {
      "t": 33262,
      "e": 19339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33262,
      "e": 19339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33398,
      "e": 19475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all "
    },
    {
      "t": 33470,
      "e": 19547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33470,
      "e": 19547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33558,
      "e": 19635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33646,
      "e": 19723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33646,
      "e": 19723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33734,
      "e": 19811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33734,
      "e": 19811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33838,
      "e": 19915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oi"
    },
    {
      "t": 33838,
      "e": 19915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33838,
      "e": 19915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33894,
      "e": 19971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33934,
      "e": 20011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33934,
      "e": 20011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33974,
      "e": 20051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34030,
      "e": 20107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34031,
      "e": 20108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34086,
      "e": 20163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34134,
      "e": 20211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34134,
      "e": 20211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34166,
      "e": 20243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34245,
      "e": 20322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34246,
      "e": 20323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34254,
      "e": 20331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34310,
      "e": 20387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34310,
      "e": 20387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34342,
      "e": 20419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34382,
      "e": 20459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34430,
      "e": 20507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34430,
      "e": 20507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34494,
      "e": 20571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34494,
      "e": 20571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34541,
      "e": 20618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34542,
      "e": 20619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34566,
      "e": 20643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at "
    },
    {
      "t": 34606,
      "e": 20683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34638,
      "e": 20715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34670,
      "e": 20747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34670,
      "e": 20747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34750,
      "e": 20827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34750,
      "e": 20827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34822,
      "e": 20899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 34838,
      "e": 20915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34838,
      "e": 20915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34862,
      "e": 20939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34974,
      "e": 21051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35086,
      "e": 21163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35086,
      "e": 21163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35134,
      "e": 21211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35134,
      "e": 21211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35246,
      "e": 21323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 35286,
      "e": 21363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35382,
      "e": 21459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 35382,
      "e": 21459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35470,
      "e": 21547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35470,
      "e": 21547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35526,
      "e": 21603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ce"
    },
    {
      "t": 35613,
      "e": 21690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35829,
      "e": 21906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35830,
      "e": 21907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35918,
      "e": 21995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 35981,
      "e": 22058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35981,
      "e": 22058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36102,
      "e": 22179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36102,
      "e": 22179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36109,
      "e": 22186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 36182,
      "e": 22259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40005,
      "e": 26082,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 43838,
      "e": 27259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44005,
      "e": 27426,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that intercept"
    },
    {
      "t": 44337,
      "e": 27758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44370,
      "e": 27791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44403,
      "e": 27824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44437,
      "e": 27858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44470,
      "e": 27891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44503,
      "e": 27924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44535,
      "e": 27956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44568,
      "e": 27989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44601,
      "e": 28022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44629,
      "e": 28050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that "
    },
    {
      "t": 45222,
      "e": 28643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45222,
      "e": 28643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45342,
      "e": 28763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45438,
      "e": 28859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45438,
      "e": 28859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45541,
      "e": 28962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 45542,
      "e": 28963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45549,
      "e": 28970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ay"
    },
    {
      "t": 45702,
      "e": 29123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45703,
      "e": 29124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45710,
      "e": 29131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45821,
      "e": 29242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46078,
      "e": 29499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46078,
      "e": 29499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46174,
      "e": 29595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46174,
      "e": 29595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46270,
      "e": 29691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 46270,
      "e": 29691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46270,
      "e": 29691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46309,
      "e": 29730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46381,
      "e": 29802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46534,
      "e": 29955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46534,
      "e": 29955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46653,
      "e": 30074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46654,
      "e": 30075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46693,
      "e": 30114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 46725,
      "e": 30146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46726,
      "e": 30147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46733,
      "e": 30154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46822,
      "e": 30243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46894,
      "e": 30315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46895,
      "e": 30316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46990,
      "e": 30411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47237,
      "e": 30658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 47238,
      "e": 30659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47350,
      "e": 30771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 47517,
      "e": 30938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 47518,
      "e": 30939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47630,
      "e": 31051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 47782,
      "e": 31203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47782,
      "e": 31203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47878,
      "e": 31299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47878,
      "e": 31299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47926,
      "e": 31347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 47998,
      "e": 31419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48246,
      "e": 31667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48246,
      "e": 31667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48398,
      "e": 31819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48454,
      "e": 31875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48454,
      "e": 31875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48518,
      "e": 31939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48518,
      "e": 31939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48590,
      "e": 32011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 48606,
      "e": 32027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48710,
      "e": 32131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 48710,
      "e": 32131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48806,
      "e": 32227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48806,
      "e": 32227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48870,
      "e": 32291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ce"
    },
    {
      "t": 48926,
      "e": 32347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 48926,
      "e": 32347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48934,
      "e": 32355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 49022,
      "e": 32443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49062,
      "e": 32483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49062,
      "e": 32483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49166,
      "e": 32587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49166,
      "e": 32587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49174,
      "e": 32595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 49293,
      "e": 32714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49325,
      "e": 32746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49325,
      "e": 32746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49398,
      "e": 32819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49398,
      "e": 32819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49462,
      "e": 32883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 49502,
      "e": 32923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49502,
      "e": 32923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49525,
      "e": 32946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49630,
      "e": 33051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49749,
      "e": 33170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 49750,
      "e": 33171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49854,
      "e": 33275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 49854,
      "e": 33275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49958,
      "e": 33379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 50004,
      "e": 33425,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50005,
      "e": 33426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50822,
      "e": 34243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50822,
      "e": 34243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50918,
      "e": 34339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50918,
      "e": 34339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50941,
      "e": 34362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 51013,
      "e": 34434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52704,
      "e": 36125,
      "ty": 2,
      "x": 267,
      "y": 410
    },
    {
      "t": 52754,
      "e": 36175,
      "ty": 41,
      "x": 14377,
      "y": 24984,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 52784,
      "e": 36205,
      "ty": 6,
      "x": 225,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52805,
      "e": 36226,
      "ty": 2,
      "x": 225,
      "y": 572
    },
    {
      "t": 52817,
      "e": 36238,
      "ty": 7,
      "x": 241,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52904,
      "e": 36325,
      "ty": 2,
      "x": 294,
      "y": 688
    },
    {
      "t": 53004,
      "e": 36425,
      "ty": 2,
      "x": 328,
      "y": 721
    },
    {
      "t": 53004,
      "e": 36425,
      "ty": 41,
      "x": 4403,
      "y": 65053,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 53104,
      "e": 36525,
      "ty": 2,
      "x": 347,
      "y": 717
    },
    {
      "t": 53205,
      "e": 36626,
      "ty": 2,
      "x": 366,
      "y": 697
    },
    {
      "t": 53254,
      "e": 36675,
      "ty": 41,
      "x": 24999,
      "y": 44737,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 53267,
      "e": 36688,
      "ty": 6,
      "x": 374,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 53304,
      "e": 36725,
      "ty": 2,
      "x": 377,
      "y": 683
    },
    {
      "t": 53384,
      "e": 36805,
      "ty": 7,
      "x": 388,
      "y": 652,
      "ta": "#strategyButton"
    },
    {
      "t": 53405,
      "e": 36826,
      "ty": 2,
      "x": 389,
      "y": 645
    },
    {
      "t": 53451,
      "e": 36872,
      "ty": 6,
      "x": 395,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53504,
      "e": 36925,
      "ty": 2,
      "x": 395,
      "y": 597
    },
    {
      "t": 53505,
      "e": 36926,
      "ty": 41,
      "x": 33487,
      "y": 60086,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53604,
      "e": 37025,
      "ty": 2,
      "x": 391,
      "y": 558
    },
    {
      "t": 53704,
      "e": 37125,
      "ty": 2,
      "x": 389,
      "y": 552
    },
    {
      "t": 53754,
      "e": 37175,
      "ty": 41,
      "x": 32475,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53804,
      "e": 37225,
      "ty": 2,
      "x": 378,
      "y": 531
    },
    {
      "t": 53904,
      "e": 37325,
      "ty": 2,
      "x": 364,
      "y": 523
    },
    {
      "t": 54004,
      "e": 37425,
      "ty": 2,
      "x": 369,
      "y": 524
    },
    {
      "t": 54005,
      "e": 37426,
      "ty": 41,
      "x": 30564,
      "y": 1023,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54105,
      "e": 37526,
      "ty": 2,
      "x": 379,
      "y": 529
    },
    {
      "t": 54205,
      "e": 37626,
      "ty": 2,
      "x": 386,
      "y": 533
    },
    {
      "t": 54255,
      "e": 37676,
      "ty": 41,
      "x": 32475,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54403,
      "e": 37824,
      "ty": 3,
      "x": 386,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54513,
      "e": 37934,
      "ty": 4,
      "x": 32475,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54514,
      "e": 37935,
      "ty": 5,
      "x": 386,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54704,
      "e": 38125,
      "ty": 2,
      "x": 364,
      "y": 543
    },
    {
      "t": 54755,
      "e": 38176,
      "ty": 41,
      "x": 27754,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54804,
      "e": 38225,
      "ty": 2,
      "x": 342,
      "y": 546
    },
    {
      "t": 54904,
      "e": 38325,
      "ty": 2,
      "x": 305,
      "y": 543
    },
    {
      "t": 55004,
      "e": 38425,
      "ty": 2,
      "x": 241,
      "y": 542
    },
    {
      "t": 55004,
      "e": 38425,
      "ty": 41,
      "x": 16176,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55204,
      "e": 38625,
      "ty": 2,
      "x": 274,
      "y": 538
    },
    {
      "t": 55255,
      "e": 38676,
      "ty": 41,
      "x": 19998,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55304,
      "e": 38725,
      "ty": 2,
      "x": 276,
      "y": 537
    },
    {
      "t": 55404,
      "e": 38825,
      "ty": 2,
      "x": 286,
      "y": 529
    },
    {
      "t": 55453,
      "e": 38874,
      "ty": 7,
      "x": 295,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55504,
      "e": 38925,
      "ty": 2,
      "x": 299,
      "y": 517
    },
    {
      "t": 55504,
      "e": 38925,
      "ty": 41,
      "x": 22696,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 55638,
      "e": 39059,
      "ty": 6,
      "x": 296,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55705,
      "e": 39126,
      "ty": 2,
      "x": 285,
      "y": 543
    },
    {
      "t": 55755,
      "e": 39176,
      "ty": 41,
      "x": 21122,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55905,
      "e": 39326,
      "ty": 2,
      "x": 296,
      "y": 542
    },
    {
      "t": 56005,
      "e": 39426,
      "ty": 2,
      "x": 301,
      "y": 540
    },
    {
      "t": 56005,
      "e": 39426,
      "ty": 41,
      "x": 22921,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56090,
      "e": 39511,
      "ty": 3,
      "x": 301,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56201,
      "e": 39622,
      "ty": 4,
      "x": 22921,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56201,
      "e": 39622,
      "ty": 5,
      "x": 301,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56304,
      "e": 39725,
      "ty": 2,
      "x": 302,
      "y": 539
    },
    {
      "t": 56405,
      "e": 39826,
      "ty": 2,
      "x": 344,
      "y": 539
    },
    {
      "t": 56504,
      "e": 39925,
      "ty": 2,
      "x": 357,
      "y": 538
    },
    {
      "t": 56504,
      "e": 39925,
      "ty": 41,
      "x": 29216,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56605,
      "e": 40026,
      "ty": 2,
      "x": 378,
      "y": 536
    },
    {
      "t": 56704,
      "e": 40125,
      "ty": 2,
      "x": 381,
      "y": 532
    },
    {
      "t": 56755,
      "e": 40176,
      "ty": 41,
      "x": 32026,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56804,
      "e": 40225,
      "ty": 2,
      "x": 377,
      "y": 526
    },
    {
      "t": 56838,
      "e": 40259,
      "ty": 7,
      "x": 369,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56905,
      "e": 40326,
      "ty": 2,
      "x": 344,
      "y": 499
    },
    {
      "t": 57005,
      "e": 40426,
      "ty": 41,
      "x": 27754,
      "y": 9983,
      "ta": "#.strategy > p"
    },
    {
      "t": 57519,
      "e": 40940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 57670,
      "e": 41091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 57671,
      "e": 41092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57766,
      "e": 41187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (x-intercept at 12pm"
    },
    {
      "t": 57789,
      "e": 41210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57918,
      "e": 41339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 57919,
      "e": 41340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58008,
      "e": 41429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vx-intercept at 12pm"
    },
    {
      "t": 58150,
      "e": 41571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58151,
      "e": 41572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58253,
      "e": 41674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 58254,
      "e": 41675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58334,
      "e": 41755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (verx-intercept at 12pm"
    },
    {
      "t": 58334,
      "e": 41755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58430,
      "e": 41851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58431,
      "e": 41852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58526,
      "e": 41947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertx-intercept at 12pm"
    },
    {
      "t": 58550,
      "e": 41971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58550,
      "e": 41971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58630,
      "e": 42051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertix-intercept at 12pm"
    },
    {
      "t": 58703,
      "e": 42124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 58703,
      "e": 42124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58774,
      "e": 42195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58774,
      "e": 42195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58830,
      "e": 42251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 58830,
      "e": 42251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58838,
      "e": 42259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (verticalx-intercept at 12pm"
    },
    {
      "t": 58902,
      "e": 42323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58943,
      "e": 42364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59246,
      "e": 42667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59425,
      "e": 42669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 59426,
      "e": 42670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59494,
      "e": 42738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertical)x-intercept at 12pm"
    },
    {
      "t": 59502,
      "e": 42746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59542,
      "e": 42786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59542,
      "e": 42786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59638,
      "e": 42882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertical) x-intercept at 12pm"
    },
    {
      "t": 61659,
      "e": 44903,
      "ty": 6,
      "x": 360,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61705,
      "e": 44949,
      "ty": 2,
      "x": 369,
      "y": 572
    },
    {
      "t": 61754,
      "e": 44998,
      "ty": 41,
      "x": 30789,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61775,
      "e": 45019,
      "ty": 7,
      "x": 371,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61805,
      "e": 45049,
      "ty": 2,
      "x": 372,
      "y": 627
    },
    {
      "t": 61875,
      "e": 45119,
      "ty": 6,
      "x": 382,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 61905,
      "e": 45149,
      "ty": 2,
      "x": 389,
      "y": 662
    },
    {
      "t": 62005,
      "e": 45249,
      "ty": 2,
      "x": 404,
      "y": 670
    },
    {
      "t": 62006,
      "e": 45250,
      "ty": 41,
      "x": 35719,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 62646,
      "e": 45890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62742,
      "e": 45986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertical)x-intercept at 12pm"
    },
    {
      "t": 62838,
      "e": 46082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62918,
      "e": 46162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (verticalx-intercept at 12pm"
    },
    {
      "t": 62966,
      "e": 46210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62967,
      "e": 46211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63101,
      "e": 46345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the (vertical x-intercept at 12pm"
    },
    {
      "t": 63631,
      "e": 46875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64130,
      "e": 47374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64162,
      "e": 47406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64190,
      "e": 47434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64302,
      "e": 47546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64365,
      "e": 47609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64471,
      "e": 47715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64533,
      "e": 47777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64654,
      "e": 47898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64734,
      "e": 47978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64807,
      "e": 48051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 64877,
      "e": 48121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64973,
      "e": 48217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 65029,
      "e": 48273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65213,
      "e": 48457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 65326,
      "e": 48570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65430,
      "e": 48674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 65493,
      "e": 48737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the vertical x-intercept at 12pm"
    },
    {
      "t": 65606,
      "e": 48850,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the vertical x-intercept at 12pm"
    },
    {
      "t": 67731,
      "e": 50975,
      "ty": 3,
      "x": 404,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 67732,
      "e": 50976,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "all points that lay on the vertical x-intercept at 12pm"
    },
    {
      "t": 67734,
      "e": 50978,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67735,
      "e": 50979,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 67825,
      "e": 51069,
      "ty": 4,
      "x": 35719,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 67837,
      "e": 51081,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 67838,
      "e": 51082,
      "ty": 5,
      "x": 404,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 67846,
      "e": 51090,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 68846,
      "e": 52090,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 69404,
      "e": 52648,
      "ty": 2,
      "x": 786,
      "y": 551
    },
    {
      "t": 69503,
      "e": 52747,
      "ty": 2,
      "x": 1023,
      "y": 472
    },
    {
      "t": 69504,
      "e": 52748,
      "ty": 41,
      "x": 34954,
      "y": 25704,
      "ta": "html > body"
    },
    {
      "t": 69604,
      "e": 52848,
      "ty": 2,
      "x": 1041,
      "y": 469
    },
    {
      "t": 69648,
      "e": 52892,
      "ty": 6,
      "x": 1025,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69664,
      "e": 52908,
      "ty": 7,
      "x": 1013,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69704,
      "e": 52948,
      "ty": 2,
      "x": 1012,
      "y": 579
    },
    {
      "t": 69755,
      "e": 52999,
      "ty": 41,
      "x": 43906,
      "y": 2114,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 69805,
      "e": 53049,
      "ty": 2,
      "x": 1011,
      "y": 586
    },
    {
      "t": 70004,
      "e": 53248,
      "ty": 2,
      "x": 1013,
      "y": 579
    },
    {
      "t": 70004,
      "e": 53248,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70007,
      "e": 53251,
      "ty": 41,
      "x": 44338,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 70031,
      "e": 53275,
      "ty": 6,
      "x": 1018,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70104,
      "e": 53348,
      "ty": 2,
      "x": 1024,
      "y": 564
    },
    {
      "t": 70204,
      "e": 53448,
      "ty": 2,
      "x": 1025,
      "y": 563
    },
    {
      "t": 70226,
      "e": 53470,
      "ty": 3,
      "x": 1025,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70227,
      "e": 53471,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70254,
      "e": 53498,
      "ty": 41,
      "x": 46934,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70346,
      "e": 53590,
      "ty": 4,
      "x": 46934,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 70347,
      "e": 53591,
      "ty": 5,
      "x": 1025,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71727,
      "e": 54971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 71727,
      "e": 54971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 71885,
      "e": 55129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 72197,
      "e": 55441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 72197,
      "e": 55441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72254,
      "e": 55498,
      "ty": 41,
      "x": 46718,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72267,
      "e": 55511,
      "ty": 7,
      "x": 1022,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72304,
      "e": 55548,
      "ty": 2,
      "x": 1017,
      "y": 626
    },
    {
      "t": 72334,
      "e": 55578,
      "ty": 6,
      "x": 1011,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72341,
      "e": 55585,
      "ty": 7,
      "x": 1010,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72342,
      "e": 55586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 72350,
      "e": 55594,
      "ty": 6,
      "x": 1007,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72404,
      "e": 55648,
      "ty": 2,
      "x": 1002,
      "y": 701
    },
    {
      "t": 72504,
      "e": 55748,
      "ty": 2,
      "x": 1001,
      "y": 707
    },
    {
      "t": 72505,
      "e": 55749,
      "ty": 41,
      "x": 54156,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72605,
      "e": 55849,
      "ty": 2,
      "x": 1015,
      "y": 688
    },
    {
      "t": 72634,
      "e": 55878,
      "ty": 7,
      "x": 1023,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 72704,
      "e": 55948,
      "ty": 2,
      "x": 1024,
      "y": 676
    },
    {
      "t": 72754,
      "e": 55998,
      "ty": 41,
      "x": 48232,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 72767,
      "e": 56011,
      "ty": 6,
      "x": 1033,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72804,
      "e": 56048,
      "ty": 2,
      "x": 1037,
      "y": 664
    },
    {
      "t": 72904,
      "e": 56148,
      "ty": 2,
      "x": 1039,
      "y": 661
    },
    {
      "t": 72946,
      "e": 56190,
      "ty": 3,
      "x": 1039,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 72947,
      "e": 56191,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 72948,
      "e": 56192,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72949,
      "e": 56193,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73005,
      "e": 56249,
      "ty": 41,
      "x": 49962,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73106,
      "e": 56350,
      "ty": 4,
      "x": 49962,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73106,
      "e": 56350,
      "ty": 5,
      "x": 1039,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 73966,
      "e": 57210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 73967,
      "e": 57211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74110,
      "e": 57354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 74110,
      "e": 57354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74117,
      "e": 57361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "un"
    },
    {
      "t": 74310,
      "e": 57554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 74311,
      "e": 57555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74389,
      "e": 57633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uni"
    },
    {
      "t": 74405,
      "e": 57649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 74405,
      "e": 57649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74445,
      "e": 57689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unit"
    },
    {
      "t": 74534,
      "e": 57778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 74671,
      "e": 57915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 74671,
      "e": 57915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74749,
      "e": 57993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 74749,
      "e": 57993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 74765,
      "e": 58009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 74894,
      "e": 58138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 75102,
      "e": 58346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 75166,
      "e": 58410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unitd"
    },
    {
      "t": 75246,
      "e": 58490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 75326,
      "e": 58570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "unit"
    },
    {
      "t": 75390,
      "e": 58634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 75391,
      "e": 58635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75469,
      "e": 58713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 75550,
      "e": 58794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 75550,
      "e": 58794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75662,
      "e": 58906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 75670,
      "e": 58914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 75671,
      "e": 58915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 75757,
      "e": 59001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 75886,
      "e": 59130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 75887,
      "e": 59131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76005,
      "e": 59249,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united s"
    },
    {
      "t": 76038,
      "e": 59282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 76039,
      "e": 59283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76045,
      "e": 59289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||st"
    },
    {
      "t": 76118,
      "e": 59362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 76126,
      "e": 59370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 76127,
      "e": 59371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76221,
      "e": 59465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 76221,
      "e": 59465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76261,
      "e": 59505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 76286,
      "e": 59530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 76286,
      "e": 59530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76366,
      "e": 59610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 76367,
      "e": 59611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 76367,
      "e": 59611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76454,
      "e": 59698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 76480,
      "e": 59724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 76654,
      "e": 59898,
      "ty": 7,
      "x": 1030,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76704,
      "e": 59948,
      "ty": 6,
      "x": 1022,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76706,
      "e": 59950,
      "ty": 2,
      "x": 1022,
      "y": 682
    },
    {
      "t": 76755,
      "e": 59999,
      "ty": 41,
      "x": 62917,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76804,
      "e": 60048,
      "ty": 2,
      "x": 1014,
      "y": 686
    },
    {
      "t": 76905,
      "e": 60149,
      "ty": 2,
      "x": 1008,
      "y": 688
    },
    {
      "t": 76922,
      "e": 60166,
      "ty": 3,
      "x": 1008,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 76924,
      "e": 60168,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "united states"
    },
    {
      "t": 76924,
      "e": 60168,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76925,
      "e": 60169,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77004,
      "e": 60248,
      "ty": 41,
      "x": 57763,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77018,
      "e": 60262,
      "ty": 4,
      "x": 57763,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77020,
      "e": 60264,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77021,
      "e": 60265,
      "ty": 5,
      "x": 1008,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 77022,
      "e": 60266,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 77405,
      "e": 60649,
      "ty": 2,
      "x": 1007,
      "y": 688
    },
    {
      "t": 77505,
      "e": 60749,
      "ty": 41,
      "x": 34403,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 78042,
      "e": 61286,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 78504,
      "e": 61748,
      "ty": 2,
      "x": 1007,
      "y": 686
    },
    {
      "t": 78505,
      "e": 61749,
      "ty": 41,
      "x": 44042,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 78604,
      "e": 61848,
      "ty": 2,
      "x": 992,
      "y": 582
    },
    {
      "t": 78704,
      "e": 61948,
      "ty": 2,
      "x": 985,
      "y": 531
    },
    {
      "t": 78755,
      "e": 61999,
      "ty": 41,
      "x": 36685,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 78804,
      "e": 62048,
      "ty": 2,
      "x": 960,
      "y": 388
    },
    {
      "t": 78905,
      "e": 62149,
      "ty": 2,
      "x": 922,
      "y": 263
    },
    {
      "t": 79004,
      "e": 62248,
      "ty": 2,
      "x": 902,
      "y": 219
    },
    {
      "t": 79005,
      "e": 62249,
      "ty": 41,
      "x": 19123,
      "y": 16591,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 79105,
      "e": 62250,
      "ty": 2,
      "x": 894,
      "y": 218
    },
    {
      "t": 79204,
      "e": 62349,
      "ty": 2,
      "x": 889,
      "y": 222
    },
    {
      "t": 79254,
      "e": 62399,
      "ty": 41,
      "x": 15325,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 79304,
      "e": 62449,
      "ty": 2,
      "x": 884,
      "y": 227
    },
    {
      "t": 79405,
      "e": 62550,
      "ty": 2,
      "x": 880,
      "y": 231
    },
    {
      "t": 79410,
      "e": 62555,
      "ty": 3,
      "x": 880,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 79505,
      "e": 62650,
      "ty": 41,
      "x": 47967,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 79554,
      "e": 62699,
      "ty": 4,
      "x": 47967,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 79555,
      "e": 62700,
      "ty": 5,
      "x": 880,
      "y": 231,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 79556,
      "e": 62701,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 79557,
      "e": 62702,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 79805,
      "e": 62950,
      "ty": 2,
      "x": 880,
      "y": 233
    },
    {
      "t": 79906,
      "e": 63051,
      "ty": 2,
      "x": 878,
      "y": 239
    },
    {
      "t": 80004,
      "e": 63149,
      "ty": 2,
      "x": 877,
      "y": 240
    },
    {
      "t": 80005,
      "e": 63150,
      "ty": 41,
      "x": 45511,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 80104,
      "e": 63249,
      "ty": 2,
      "x": 875,
      "y": 269
    },
    {
      "t": 80204,
      "e": 63349,
      "ty": 2,
      "x": 872,
      "y": 300
    },
    {
      "t": 80254,
      "e": 63399,
      "ty": 41,
      "x": 11528,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 80304,
      "e": 63449,
      "ty": 2,
      "x": 870,
      "y": 327
    },
    {
      "t": 80404,
      "e": 63549,
      "ty": 2,
      "x": 866,
      "y": 360
    },
    {
      "t": 80505,
      "e": 63650,
      "ty": 2,
      "x": 866,
      "y": 390
    },
    {
      "t": 80505,
      "e": 63650,
      "ty": 41,
      "x": 10579,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 80605,
      "e": 63750,
      "ty": 2,
      "x": 866,
      "y": 408
    },
    {
      "t": 80705,
      "e": 63850,
      "ty": 2,
      "x": 866,
      "y": 419
    },
    {
      "t": 80755,
      "e": 63900,
      "ty": 41,
      "x": 52182,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 80805,
      "e": 63950,
      "ty": 2,
      "x": 866,
      "y": 420
    },
    {
      "t": 81404,
      "e": 64549,
      "ty": 2,
      "x": 866,
      "y": 431
    },
    {
      "t": 81505,
      "e": 64650,
      "ty": 2,
      "x": 866,
      "y": 439
    },
    {
      "t": 81505,
      "e": 64650,
      "ty": 41,
      "x": 35606,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 81604,
      "e": 64749,
      "ty": 2,
      "x": 864,
      "y": 444
    },
    {
      "t": 81704,
      "e": 64849,
      "ty": 2,
      "x": 864,
      "y": 445
    },
    {
      "t": 81755,
      "e": 64900,
      "ty": 41,
      "x": 34009,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83602,
      "e": 66747,
      "ty": 3,
      "x": 864,
      "y": 445,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83604,
      "e": 66749,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 83705,
      "e": 66850,
      "ty": 4,
      "x": 34009,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83705,
      "e": 66850,
      "ty": 5,
      "x": 864,
      "y": 445,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83705,
      "e": 66850,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 83706,
      "e": 66851,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 84405,
      "e": 67550,
      "ty": 2,
      "x": 972,
      "y": 781
    },
    {
      "t": 84504,
      "e": 67649,
      "ty": 2,
      "x": 1164,
      "y": 1145
    },
    {
      "t": 84504,
      "e": 67649,
      "ty": 41,
      "x": 39810,
      "y": 62986,
      "ta": "html > body"
    },
    {
      "t": 84605,
      "e": 67750,
      "ty": 2,
      "x": 1139,
      "y": 1093
    },
    {
      "t": 84705,
      "e": 67850,
      "ty": 2,
      "x": 927,
      "y": 729
    },
    {
      "t": 84754,
      "e": 67899,
      "ty": 41,
      "x": 18648,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 84805,
      "e": 67950,
      "ty": 2,
      "x": 900,
      "y": 685
    },
    {
      "t": 85005,
      "e": 68150,
      "ty": 41,
      "x": 18648,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 85105,
      "e": 68250,
      "ty": 2,
      "x": 905,
      "y": 675
    },
    {
      "t": 85204,
      "e": 68349,
      "ty": 2,
      "x": 910,
      "y": 670
    },
    {
      "t": 85254,
      "e": 68399,
      "ty": 41,
      "x": 23783,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 85304,
      "e": 68449,
      "ty": 2,
      "x": 917,
      "y": 672
    },
    {
      "t": 85405,
      "e": 68550,
      "ty": 2,
      "x": 929,
      "y": 683
    },
    {
      "t": 85504,
      "e": 68649,
      "ty": 2,
      "x": 939,
      "y": 704
    },
    {
      "t": 85506,
      "e": 68651,
      "ty": 41,
      "x": 29627,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 85605,
      "e": 68750,
      "ty": 2,
      "x": 947,
      "y": 728
    },
    {
      "t": 85705,
      "e": 68850,
      "ty": 2,
      "x": 949,
      "y": 745
    },
    {
      "t": 85754,
      "e": 68899,
      "ty": 41,
      "x": 53232,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 85805,
      "e": 68950,
      "ty": 2,
      "x": 949,
      "y": 758
    },
    {
      "t": 85904,
      "e": 69049,
      "ty": 2,
      "x": 954,
      "y": 748
    },
    {
      "t": 86004,
      "e": 69149,
      "ty": 2,
      "x": 969,
      "y": 706
    },
    {
      "t": 86005,
      "e": 69150,
      "ty": 41,
      "x": 37187,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 86104,
      "e": 69249,
      "ty": 2,
      "x": 969,
      "y": 689
    },
    {
      "t": 86205,
      "e": 69350,
      "ty": 2,
      "x": 970,
      "y": 677
    },
    {
      "t": 86254,
      "e": 69399,
      "ty": 41,
      "x": 39893,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 86605,
      "e": 69750,
      "ty": 2,
      "x": 972,
      "y": 690
    },
    {
      "t": 86705,
      "e": 69850,
      "ty": 2,
      "x": 973,
      "y": 697
    },
    {
      "t": 86755,
      "e": 69900,
      "ty": 41,
      "x": 38194,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87005,
      "e": 70150,
      "ty": 2,
      "x": 971,
      "y": 699
    },
    {
      "t": 87005,
      "e": 70150,
      "ty": 41,
      "x": 37690,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87104,
      "e": 70249,
      "ty": 2,
      "x": 925,
      "y": 712
    },
    {
      "t": 87205,
      "e": 70350,
      "ty": 2,
      "x": 923,
      "y": 712
    },
    {
      "t": 87255,
      "e": 70400,
      "ty": 41,
      "x": 25595,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87405,
      "e": 70550,
      "ty": 2,
      "x": 922,
      "y": 712
    },
    {
      "t": 87411,
      "e": 70556,
      "ty": 3,
      "x": 922,
      "y": 712,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87412,
      "e": 70557,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 87505,
      "e": 70650,
      "ty": 41,
      "x": 25343,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87545,
      "e": 70690,
      "ty": 4,
      "x": 25343,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87545,
      "e": 70690,
      "ty": 5,
      "x": 922,
      "y": 712,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87546,
      "e": 70691,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87547,
      "e": 70692,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 87904,
      "e": 71049,
      "ty": 2,
      "x": 921,
      "y": 708
    },
    {
      "t": 88004,
      "e": 71149,
      "ty": 2,
      "x": 919,
      "y": 713
    },
    {
      "t": 88005,
      "e": 71150,
      "ty": 41,
      "x": 23157,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 88105,
      "e": 71250,
      "ty": 2,
      "x": 917,
      "y": 801
    },
    {
      "t": 88204,
      "e": 71349,
      "ty": 2,
      "x": 939,
      "y": 922
    },
    {
      "t": 88255,
      "e": 71400,
      "ty": 41,
      "x": 28141,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 88304,
      "e": 71449,
      "ty": 2,
      "x": 940,
      "y": 923
    },
    {
      "t": 88605,
      "e": 71750,
      "ty": 2,
      "x": 906,
      "y": 971
    },
    {
      "t": 88758,
      "e": 71903,
      "ty": 41,
      "x": 20072,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 89008,
      "e": 72153,
      "ty": 2,
      "x": 905,
      "y": 971
    },
    {
      "t": 89009,
      "e": 72154,
      "ty": 41,
      "x": 19835,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 89208,
      "e": 72353,
      "ty": 2,
      "x": 901,
      "y": 965
    },
    {
      "t": 89258,
      "e": 72403,
      "ty": 41,
      "x": 62754,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 89309,
      "e": 72454,
      "ty": 2,
      "x": 896,
      "y": 961
    },
    {
      "t": 89409,
      "e": 72554,
      "ty": 2,
      "x": 895,
      "y": 959
    },
    {
      "t": 89508,
      "e": 72653,
      "ty": 41,
      "x": 59518,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 89908,
      "e": 73053,
      "ty": 2,
      "x": 893,
      "y": 958
    },
    {
      "t": 90009,
      "e": 73154,
      "ty": 2,
      "x": 891,
      "y": 958
    },
    {
      "t": 90009,
      "e": 73154,
      "ty": 41,
      "x": 56283,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 90108,
      "e": 73253,
      "ty": 2,
      "x": 890,
      "y": 958
    },
    {
      "t": 90259,
      "e": 73404,
      "ty": 41,
      "x": 55474,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 90309,
      "e": 73454,
      "ty": 2,
      "x": 888,
      "y": 958
    },
    {
      "t": 90409,
      "e": 73554,
      "ty": 2,
      "x": 887,
      "y": 958
    },
    {
      "t": 90509,
      "e": 73654,
      "ty": 41,
      "x": 53047,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 90709,
      "e": 73854,
      "ty": 2,
      "x": 881,
      "y": 953
    },
    {
      "t": 90758,
      "e": 73903,
      "ty": 41,
      "x": 13664,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 90808,
      "e": 73953,
      "ty": 2,
      "x": 876,
      "y": 937
    },
    {
      "t": 90908,
      "e": 74053,
      "ty": 2,
      "x": 873,
      "y": 931
    },
    {
      "t": 91009,
      "e": 74154,
      "ty": 2,
      "x": 870,
      "y": 931
    },
    {
      "t": 91009,
      "e": 74154,
      "ty": 41,
      "x": 53059,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91110,
      "e": 74255,
      "ty": 3,
      "x": 870,
      "y": 931,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91111,
      "e": 74256,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 91229,
      "e": 74374,
      "ty": 4,
      "x": 53059,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91229,
      "e": 74374,
      "ty": 5,
      "x": 870,
      "y": 931,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 91229,
      "e": 74374,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 91230,
      "e": 74374,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 91508,
      "e": 74652,
      "ty": 2,
      "x": 885,
      "y": 951
    },
    {
      "t": 91509,
      "e": 74653,
      "ty": 41,
      "x": 15088,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 91609,
      "e": 74753,
      "ty": 2,
      "x": 905,
      "y": 991
    },
    {
      "t": 91654,
      "e": 74798,
      "ty": 6,
      "x": 911,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91709,
      "e": 74853,
      "ty": 2,
      "x": 920,
      "y": 1022
    },
    {
      "t": 91758,
      "e": 74902,
      "ty": 41,
      "x": 47198,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 91809,
      "e": 74953,
      "ty": 2,
      "x": 921,
      "y": 1022
    },
    {
      "t": 93470,
      "e": 76614,
      "ty": 3,
      "x": 921,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93471,
      "e": 76615,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 93471,
      "e": 76615,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93580,
      "e": 76724,
      "ty": 4,
      "x": 47198,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93581,
      "e": 76725,
      "ty": 5,
      "x": 921,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93584,
      "e": 76728,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93584,
      "e": 76728,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 93586,
      "e": 76730,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 94109,
      "e": 77253,
      "ty": 2,
      "x": 815,
      "y": 792
    },
    {
      "t": 94208,
      "e": 77352,
      "ty": 2,
      "x": 590,
      "y": 513
    },
    {
      "t": 94259,
      "e": 77403,
      "ty": 41,
      "x": 20042,
      "y": 27975,
      "ta": "html > body"
    },
    {
      "t": 94709,
      "e": 77853,
      "ty": 2,
      "x": 590,
      "y": 512
    },
    {
      "t": 94758,
      "e": 77902,
      "ty": 41,
      "x": 20042,
      "y": 27920,
      "ta": "html > body"
    },
    {
      "t": 94900,
      "e": 78044,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 95008,
      "e": 78152,
      "ty": 41,
      "x": 14441,
      "y": 11513,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95009,
      "e": 78153,
      "ty": 2,
      "x": 587,
      "y": 512
    },
    {
      "t": 95108,
      "e": 78252,
      "ty": 2,
      "x": 586,
      "y": 512
    },
    {
      "t": 95208,
      "e": 78352,
      "ty": 2,
      "x": 584,
      "y": 511
    },
    {
      "t": 95258,
      "e": 78402,
      "ty": 41,
      "x": 14244,
      "y": 10733,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 95307,
      "e": 78451,
      "ty": 2,
      "x": 583,
      "y": 510
    },
    {
      "t": 95408,
      "e": 78552,
      "ty": 2,
      "x": 659,
      "y": 748
    },
    {
      "t": 95508,
      "e": 78652,
      "ty": 2,
      "x": 770,
      "y": 914
    },
    {
      "t": 95509,
      "e": 78653,
      "ty": 41,
      "x": 23444,
      "y": 54546,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95708,
      "e": 78852,
      "ty": 2,
      "x": 830,
      "y": 985
    },
    {
      "t": 95758,
      "e": 78902,
      "ty": 41,
      "x": 26396,
      "y": 59462,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 96008,
      "e": 79152,
      "ty": 2,
      "x": 825,
      "y": 987
    },
    {
      "t": 96009,
      "e": 79153,
      "ty": 41,
      "x": 26150,
      "y": 59601,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 96508,
      "e": 79652,
      "ty": 2,
      "x": 818,
      "y": 989
    },
    {
      "t": 96508,
      "e": 79652,
      "ty": 41,
      "x": 25806,
      "y": 59739,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 96708,
      "e": 79852,
      "ty": 2,
      "x": 804,
      "y": 1004
    },
    {
      "t": 96758,
      "e": 79902,
      "ty": 41,
      "x": 25314,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 96807,
      "e": 79951,
      "ty": 2,
      "x": 812,
      "y": 1025
    },
    {
      "t": 97008,
      "e": 80152,
      "ty": 41,
      "x": 25510,
      "y": 62232,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 97208,
      "e": 80352,
      "ty": 2,
      "x": 806,
      "y": 1029
    },
    {
      "t": 97258,
      "e": 80402,
      "ty": 41,
      "x": 25018,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 97308,
      "e": 80452,
      "ty": 2,
      "x": 800,
      "y": 1027
    },
    {
      "t": 97508,
      "e": 80652,
      "ty": 41,
      "x": 24920,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 97608,
      "e": 80752,
      "ty": 2,
      "x": 796,
      "y": 1027
    },
    {
      "t": 97708,
      "e": 80852,
      "ty": 2,
      "x": 762,
      "y": 1029
    },
    {
      "t": 97759,
      "e": 80903,
      "ty": 41,
      "x": 22313,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 97808,
      "e": 80952,
      "ty": 2,
      "x": 742,
      "y": 1032
    },
    {
      "t": 98009,
      "e": 81153,
      "ty": 41,
      "x": 22067,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 99758,
      "e": 82902,
      "ty": 41,
      "x": 22017,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 99808,
      "e": 82952,
      "ty": 2,
      "x": 741,
      "y": 1032
    },
    {
      "t": 100008,
      "e": 83152,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100208,
      "e": 83352,
      "ty": 2,
      "x": 739,
      "y": 1032
    },
    {
      "t": 100258,
      "e": 83402,
      "ty": 41,
      "x": 21821,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100308,
      "e": 83452,
      "ty": 2,
      "x": 737,
      "y": 1031
    },
    {
      "t": 100408,
      "e": 83552,
      "ty": 2,
      "x": 736,
      "y": 1030
    },
    {
      "t": 100508,
      "e": 83652,
      "ty": 41,
      "x": 21771,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109008,
      "e": 88652,
      "ty": 2,
      "x": 732,
      "y": 1015
    },
    {
      "t": 109008,
      "e": 88652,
      "ty": 41,
      "x": 21575,
      "y": 61540,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 109108,
      "e": 88752,
      "ty": 2,
      "x": 724,
      "y": 993
    },
    {
      "t": 109208,
      "e": 88852,
      "ty": 2,
      "x": 724,
      "y": 991
    },
    {
      "t": 109258,
      "e": 88902,
      "ty": 41,
      "x": 21181,
      "y": 59878,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110008,
      "e": 89652,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 118008,
      "e": 93902,
      "ty": 2,
      "x": 735,
      "y": 987
    },
    {
      "t": 118009,
      "e": 93903,
      "ty": 41,
      "x": 21722,
      "y": 59601,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118109,
      "e": 94003,
      "ty": 2,
      "x": 820,
      "y": 1009
    },
    {
      "t": 118209,
      "e": 94103,
      "ty": 2,
      "x": 903,
      "y": 1041
    },
    {
      "t": 118258,
      "e": 94152,
      "ty": 41,
      "x": 30086,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118309,
      "e": 94203,
      "ty": 2,
      "x": 905,
      "y": 1042
    },
    {
      "t": 118409,
      "e": 94303,
      "ty": 2,
      "x": 904,
      "y": 1042
    },
    {
      "t": 118509,
      "e": 94403,
      "ty": 41,
      "x": 30037,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121495,
      "e": 97389,
      "ty": 6,
      "x": 937,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 121509,
      "e": 97403,
      "ty": 2,
      "x": 937,
      "y": 1076
    },
    {
      "t": 121509,
      "e": 97403,
      "ty": 41,
      "x": 15018,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 121609,
      "e": 97503,
      "ty": 2,
      "x": 944,
      "y": 1080
    },
    {
      "t": 121709,
      "e": 97603,
      "ty": 2,
      "x": 947,
      "y": 1081
    },
    {
      "t": 121759,
      "e": 97653,
      "ty": 41,
      "x": 20479,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 121978,
      "e": 97872,
      "ty": 7,
      "x": 946,
      "y": 1065,
      "ta": "#start"
    },
    {
      "t": 122009,
      "e": 97903,
      "ty": 2,
      "x": 945,
      "y": 1053
    },
    {
      "t": 122009,
      "e": 97903,
      "ty": 41,
      "x": 32054,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122109,
      "e": 98003,
      "ty": 2,
      "x": 945,
      "y": 1042
    },
    {
      "t": 122259,
      "e": 98153,
      "ty": 41,
      "x": 32054,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122409,
      "e": 98303,
      "ty": 2,
      "x": 944,
      "y": 1042
    },
    {
      "t": 122509,
      "e": 98403,
      "ty": 41,
      "x": 32004,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122758,
      "e": 98652,
      "ty": 41,
      "x": 32004,
      "y": 63479,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122808,
      "e": 98702,
      "ty": 2,
      "x": 944,
      "y": 1052
    },
    {
      "t": 122880,
      "e": 98774,
      "ty": 6,
      "x": 944,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 122908,
      "e": 98802,
      "ty": 2,
      "x": 944,
      "y": 1075
    },
    {
      "t": 123009,
      "e": 98903,
      "ty": 2,
      "x": 944,
      "y": 1089
    },
    {
      "t": 123009,
      "e": 98903,
      "ty": 41,
      "x": 18841,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 123108,
      "e": 99002,
      "ty": 2,
      "x": 946,
      "y": 1099
    },
    {
      "t": 123208,
      "e": 99102,
      "ty": 2,
      "x": 947,
      "y": 1100
    },
    {
      "t": 123258,
      "e": 99152,
      "ty": 41,
      "x": 20479,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 126608,
      "e": 102502,
      "ty": 2,
      "x": 947,
      "y": 1098
    },
    {
      "t": 126758,
      "e": 102652,
      "ty": 41,
      "x": 20479,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 126774,
      "e": 102668,
      "ty": 3,
      "x": 947,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 126775,
      "e": 102669,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126884,
      "e": 102778,
      "ty": 4,
      "x": 20479,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 126884,
      "e": 102778,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126885,
      "e": 102779,
      "ty": 5,
      "x": 947,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 126885,
      "e": 102779,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 127924,
      "e": 103818,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 128745,
      "e": 104639,
      "ty": 2,
      "x": 798,
      "y": 913
    },
    {
      "t": 128745,
      "e": 104639,
      "ty": 41,
      "x": 24904,
      "y": 32836,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 128805,
      "e": 104699,
      "ty": 41,
      "x": 24855,
      "y": 32836,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 128808,
      "e": 104702,
      "ty": 2,
      "x": 797,
      "y": 912
    },
    {
      "t": 128908,
      "e": 104802,
      "ty": 2,
      "x": 795,
      "y": 910
    },
    {
      "t": 129008,
      "e": 104902,
      "ty": 2,
      "x": 792,
      "y": 909
    },
    {
      "t": 129008,
      "e": 104902,
      "ty": 41,
      "x": 24612,
      "y": 32835,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 129108,
      "e": 105002,
      "ty": 2,
      "x": 791,
      "y": 908
    },
    {
      "t": 129208,
      "e": 105102,
      "ty": 2,
      "x": 789,
      "y": 908
    },
    {
      "t": 129258,
      "e": 105152,
      "ty": 41,
      "x": 24417,
      "y": 32835,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 129308,
      "e": 105202,
      "ty": 2,
      "x": 788,
      "y": 908
    },
    {
      "t": 129364,
      "e": 105258,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 10497, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 10500, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32480, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 44080, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8714, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"romeo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 53804, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10853, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 65747, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 20618, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 87367, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 31757, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 120361, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -A -A -11 AM-A -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1077,y:763,t:1527627967233};\\\", \\\"{x:1040,y:747,t:1527627967240};\\\", \\\"{x:978,y:724,t:1527627967253};\\\", \\\"{x:829,y:662,t:1527627967269};\\\", \\\"{x:652,y:607,t:1527627967287};\\\", \\\"{x:481,y:558,t:1527627967304};\\\", \\\"{x:280,y:504,t:1527627967321};\\\", \\\"{x:213,y:476,t:1527627967336};\\\", \\\"{x:193,y:467,t:1527627967353};\\\", \\\"{x:193,y:466,t:1527627967370};\\\", \\\"{x:192,y:465,t:1527627967386};\\\", \\\"{x:189,y:465,t:1527627967404};\\\", \\\"{x:168,y:445,t:1527627967420};\\\", \\\"{x:165,y:344,t:1527627967437};\\\", \\\"{x:165,y:189,t:1527627967454};\\\", \\\"{x:165,y:18,t:1527627967471};\\\", \\\"{x:181,y:0,t:1527627967486};\\\", \\\"{x:202,y:0,t:1527627967504};\\\", \\\"{x:213,y:0,t:1527627967520};\\\", \\\"{x:215,y:0,t:1527627967536};\\\", \\\"{x:187,y:0,t:1527627967553};\\\", \\\"{x:179,y:0,t:1527627967570};\\\", \\\"{x:178,y:0,t:1527627967625};\\\", \\\"{x:166,y:0,t:1527627967636};\\\", \\\"{x:120,y:0,t:1527627967653};\\\", \\\"{x:97,y:0,t:1527627967670};\\\", \\\"{x:82,y:0,t:1527627967686};\\\", \\\"{x:75,y:0,t:1527627967703};\\\", \\\"{x:80,y:2,t:1527627967761};\\\", \\\"{x:84,y:4,t:1527627967771};\\\", \\\"{x:95,y:6,t:1527627967788};\\\", \\\"{x:101,y:10,t:1527627967804};\\\", \\\"{x:104,y:12,t:1527627967821};\\\", \\\"{x:108,y:18,t:1527627967837};\\\", \\\"{x:117,y:28,t:1527627967854};\\\", \\\"{x:128,y:36,t:1527627967871};\\\", \\\"{x:138,y:43,t:1527627967888};\\\", \\\"{x:151,y:53,t:1527627967903};\\\", \\\"{x:197,y:85,t:1527627967920};\\\", \\\"{x:217,y:101,t:1527627967937};\\\", \\\"{x:235,y:118,t:1527627967953};\\\", \\\"{x:252,y:131,t:1527627967970};\\\", \\\"{x:268,y:143,t:1527627967987};\\\", \\\"{x:294,y:161,t:1527627968003};\\\", \\\"{x:333,y:187,t:1527627968020};\\\", \\\"{x:372,y:216,t:1527627968037};\\\", \\\"{x:407,y:240,t:1527627968054};\\\", \\\"{x:442,y:260,t:1527627968071};\\\", \\\"{x:472,y:277,t:1527627968087};\\\", \\\"{x:504,y:298,t:1527627968103};\\\", \\\"{x:541,y:324,t:1527627968120};\\\", \\\"{x:569,y:341,t:1527627968137};\\\", \\\"{x:590,y:352,t:1527627968154};\\\", \\\"{x:606,y:360,t:1527627968170};\\\", \\\"{x:625,y:367,t:1527627968187};\\\", \\\"{x:666,y:383,t:1527627968204};\\\", \\\"{x:719,y:404,t:1527627968220};\\\", \\\"{x:772,y:420,t:1527627968237};\\\", \\\"{x:809,y:433,t:1527627968254};\\\", \\\"{x:838,y:441,t:1527627968270};\\\", \\\"{x:876,y:453,t:1527627968287};\\\", \\\"{x:950,y:485,t:1527627968303};\\\", \\\"{x:987,y:505,t:1527627968320};\\\", \\\"{x:1009,y:519,t:1527627968338};\\\", \\\"{x:1028,y:533,t:1527627968354};\\\", \\\"{x:1047,y:550,t:1527627968371};\\\", \\\"{x:1070,y:572,t:1527627968388};\\\", \\\"{x:1086,y:586,t:1527627968404};\\\", \\\"{x:1098,y:603,t:1527627968420};\\\", \\\"{x:1119,y:626,t:1527627968438};\\\", \\\"{x:1149,y:659,t:1527627968455};\\\", \\\"{x:1176,y:690,t:1527627968470};\\\", \\\"{x:1193,y:711,t:1527627968487};\\\", \\\"{x:1205,y:729,t:1527627968505};\\\", \\\"{x:1216,y:746,t:1527627968521};\\\", \\\"{x:1229,y:764,t:1527627968537};\\\", \\\"{x:1235,y:778,t:1527627968555};\\\", \\\"{x:1236,y:782,t:1527627968571};\\\", \\\"{x:1236,y:788,t:1527627968587};\\\", \\\"{x:1236,y:792,t:1527627968605};\\\", \\\"{x:1237,y:795,t:1527627968621};\\\", \\\"{x:1241,y:806,t:1527627968638};\\\", \\\"{x:1246,y:819,t:1527627968655};\\\", \\\"{x:1250,y:831,t:1527627968672};\\\", \\\"{x:1250,y:835,t:1527627968688};\\\", \\\"{x:1253,y:840,t:1527627968705};\\\", \\\"{x:1254,y:847,t:1527627968722};\\\", \\\"{x:1257,y:856,t:1527627968738};\\\", \\\"{x:1259,y:864,t:1527627968755};\\\", \\\"{x:1260,y:869,t:1527627968772};\\\", \\\"{x:1262,y:875,t:1527627968788};\\\", \\\"{x:1263,y:879,t:1527627968805};\\\", \\\"{x:1265,y:884,t:1527627968822};\\\", \\\"{x:1266,y:892,t:1527627968838};\\\", \\\"{x:1267,y:905,t:1527627968855};\\\", \\\"{x:1269,y:916,t:1527627968872};\\\", \\\"{x:1270,y:923,t:1527627968887};\\\", \\\"{x:1274,y:942,t:1527627968904};\\\", \\\"{x:1275,y:948,t:1527627968921};\\\", \\\"{x:1275,y:953,t:1527627968937};\\\", \\\"{x:1276,y:955,t:1527627968954};\\\", \\\"{x:1278,y:957,t:1527627968971};\\\", \\\"{x:1279,y:957,t:1527627969000};\\\", \\\"{x:1280,y:957,t:1527627969016};\\\", \\\"{x:1281,y:958,t:1527627969032};\\\", \\\"{x:1282,y:958,t:1527627969048};\\\", \\\"{x:1284,y:959,t:1527627969064};\\\", \\\"{x:1285,y:959,t:1527627969096};\\\", \\\"{x:1285,y:960,t:1527627969112};\\\", \\\"{x:1286,y:960,t:1527627969241};\\\", \\\"{x:1286,y:961,t:1527627969537};\\\", \\\"{x:1285,y:961,t:1527627969600};\\\", \\\"{x:1284,y:962,t:1527627969657};\\\", \\\"{x:1283,y:963,t:1527627969697};\\\", \\\"{x:1282,y:964,t:1527627969737};\\\", \\\"{x:1282,y:965,t:1527627969753};\\\", \\\"{x:1280,y:965,t:1527627969760};\\\", \\\"{x:1280,y:966,t:1527627969772};\\\", \\\"{x:1278,y:968,t:1527627969789};\\\", \\\"{x:1274,y:972,t:1527627969806};\\\", \\\"{x:1272,y:974,t:1527627969822};\\\", \\\"{x:1271,y:974,t:1527627969839};\\\", \\\"{x:1271,y:973,t:1527627970072};\\\", \\\"{x:1271,y:969,t:1527627970089};\\\", \\\"{x:1271,y:966,t:1527627970106};\\\", \\\"{x:1271,y:958,t:1527627970123};\\\", \\\"{x:1271,y:954,t:1527627970139};\\\", \\\"{x:1270,y:947,t:1527627970156};\\\", \\\"{x:1269,y:940,t:1527627970172};\\\", \\\"{x:1269,y:932,t:1527627970188};\\\", \\\"{x:1269,y:927,t:1527627970205};\\\", \\\"{x:1266,y:919,t:1527627970222};\\\", \\\"{x:1266,y:913,t:1527627970238};\\\", \\\"{x:1264,y:901,t:1527627970255};\\\", \\\"{x:1262,y:887,t:1527627970271};\\\", \\\"{x:1260,y:879,t:1527627970288};\\\", \\\"{x:1260,y:877,t:1527627970305};\\\", \\\"{x:1260,y:876,t:1527627970322};\\\", \\\"{x:1260,y:875,t:1527627970352};\\\", \\\"{x:1260,y:874,t:1527627970360};\\\", \\\"{x:1260,y:873,t:1527627970372};\\\", \\\"{x:1260,y:872,t:1527627970392};\\\", \\\"{x:1260,y:870,t:1527627970405};\\\", \\\"{x:1260,y:867,t:1527627970423};\\\", \\\"{x:1260,y:866,t:1527627970439};\\\", \\\"{x:1261,y:862,t:1527627970456};\\\", \\\"{x:1263,y:858,t:1527627970472};\\\", \\\"{x:1263,y:856,t:1527627970490};\\\", \\\"{x:1263,y:855,t:1527627970513};\\\", \\\"{x:1264,y:855,t:1527627970523};\\\", \\\"{x:1264,y:854,t:1527627970540};\\\", \\\"{x:1265,y:853,t:1527627970560};\\\", \\\"{x:1266,y:852,t:1527627970573};\\\", \\\"{x:1266,y:850,t:1527627970592};\\\", \\\"{x:1268,y:848,t:1527627970606};\\\", \\\"{x:1269,y:847,t:1527627970623};\\\", \\\"{x:1269,y:844,t:1527627970640};\\\", \\\"{x:1270,y:843,t:1527627970656};\\\", \\\"{x:1270,y:841,t:1527627970673};\\\", \\\"{x:1271,y:841,t:1527627970690};\\\", \\\"{x:1271,y:840,t:1527627970706};\\\", \\\"{x:1271,y:839,t:1527627970744};\\\", \\\"{x:1271,y:838,t:1527627970760};\\\", \\\"{x:1272,y:837,t:1527627970773};\\\", \\\"{x:1272,y:836,t:1527627970967};\\\", \\\"{x:1272,y:835,t:1527627970984};\\\", \\\"{x:1272,y:834,t:1527627970991};\\\", \\\"{x:1272,y:833,t:1527627971007};\\\", \\\"{x:1272,y:832,t:1527627971048};\\\", \\\"{x:1272,y:831,t:1527627971056};\\\", \\\"{x:1272,y:830,t:1527627971079};\\\", \\\"{x:1272,y:829,t:1527627971096};\\\", \\\"{x:1272,y:828,t:1527627971224};\\\", \\\"{x:1273,y:827,t:1527627971449};\\\", \\\"{x:1274,y:827,t:1527627971633};\\\", \\\"{x:1275,y:827,t:1527627971641};\\\", \\\"{x:1276,y:827,t:1527627971659};\\\", \\\"{x:1278,y:825,t:1527627971673};\\\", \\\"{x:1280,y:824,t:1527627971689};\\\", \\\"{x:1283,y:824,t:1527627971706};\\\", \\\"{x:1284,y:823,t:1527627971723};\\\", \\\"{x:1285,y:823,t:1527627971739};\\\", \\\"{x:1286,y:822,t:1527627971756};\\\", \\\"{x:1287,y:822,t:1527627971775};\\\", \\\"{x:1287,y:821,t:1527627971816};\\\", \\\"{x:1287,y:822,t:1527627972272};\\\", \\\"{x:1287,y:823,t:1527627972287};\\\", \\\"{x:1287,y:824,t:1527627972296};\\\", \\\"{x:1287,y:825,t:1527627972311};\\\", \\\"{x:1287,y:827,t:1527627972323};\\\", \\\"{x:1287,y:828,t:1527627972384};\\\", \\\"{x:1287,y:829,t:1527627972407};\\\", \\\"{x:1286,y:830,t:1527627972424};\\\", \\\"{x:1285,y:831,t:1527627972440};\\\", \\\"{x:1284,y:831,t:1527627972464};\\\", \\\"{x:1283,y:831,t:1527627972474};\\\", \\\"{x:1282,y:831,t:1527627972497};\\\", \\\"{x:1281,y:832,t:1527627972508};\\\", \\\"{x:1280,y:832,t:1527627972524};\\\", \\\"{x:1278,y:832,t:1527627972541};\\\", \\\"{x:1277,y:833,t:1527627972558};\\\", \\\"{x:1278,y:832,t:1527627972729};\\\", \\\"{x:1279,y:831,t:1527627972745};\\\", \\\"{x:1280,y:830,t:1527627972757};\\\", \\\"{x:1282,y:828,t:1527627972774};\\\", \\\"{x:1282,y:827,t:1527627972791};\\\", \\\"{x:1282,y:825,t:1527627972872};\\\", \\\"{x:1280,y:822,t:1527627972881};\\\", \\\"{x:1263,y:814,t:1527627972890};\\\", \\\"{x:1174,y:769,t:1527627972907};\\\", \\\"{x:1017,y:678,t:1527627972924};\\\", \\\"{x:808,y:550,t:1527627972941};\\\", \\\"{x:542,y:391,t:1527627972957};\\\", \\\"{x:270,y:242,t:1527627972974};\\\", \\\"{x:68,y:138,t:1527627972989};\\\", \\\"{x:0,y:87,t:1527627973006};\\\", \\\"{x:0,y:77,t:1527627973023};\\\", \\\"{x:0,y:76,t:1527627973063};\\\", \\\"{x:1,y:73,t:1527627973073};\\\", \\\"{x:6,y:73,t:1527627973091};\\\", \\\"{x:9,y:73,t:1527627973106};\\\", \\\"{x:10,y:73,t:1527627973123};\\\", \\\"{x:8,y:81,t:1527627973140};\\\", \\\"{x:6,y:90,t:1527627973157};\\\", \\\"{x:3,y:103,t:1527627973173};\\\", \\\"{x:3,y:120,t:1527627973190};\\\", \\\"{x:3,y:156,t:1527627973208};\\\", \\\"{x:4,y:180,t:1527627973223};\\\", \\\"{x:10,y:200,t:1527627973240};\\\", \\\"{x:17,y:219,t:1527627973257};\\\", \\\"{x:27,y:237,t:1527627973275};\\\", \\\"{x:40,y:259,t:1527627973290};\\\", \\\"{x:47,y:271,t:1527627973308};\\\", \\\"{x:53,y:282,t:1527627973324};\\\", \\\"{x:60,y:294,t:1527627973341};\\\", \\\"{x:73,y:309,t:1527627973358};\\\", \\\"{x:85,y:323,t:1527627973375};\\\", \\\"{x:100,y:338,t:1527627973392};\\\", \\\"{x:111,y:349,t:1527627973408};\\\", \\\"{x:124,y:367,t:1527627973425};\\\", \\\"{x:139,y:387,t:1527627973441};\\\", \\\"{x:157,y:412,t:1527627973458};\\\", \\\"{x:178,y:443,t:1527627973474};\\\", \\\"{x:195,y:470,t:1527627973491};\\\", \\\"{x:210,y:500,t:1527627973509};\\\", \\\"{x:225,y:532,t:1527627973526};\\\", \\\"{x:235,y:556,t:1527627973543};\\\", \\\"{x:239,y:573,t:1527627973558};\\\", \\\"{x:239,y:584,t:1527627973577};\\\", \\\"{x:239,y:588,t:1527627973591};\\\", \\\"{x:240,y:588,t:1527627973647};\\\", \\\"{x:242,y:589,t:1527627973658};\\\", \\\"{x:234,y:582,t:1527627973712};\\\", \\\"{x:223,y:574,t:1527627973726};\\\", \\\"{x:202,y:561,t:1527627973741};\\\", \\\"{x:187,y:550,t:1527627973759};\\\", \\\"{x:171,y:538,t:1527627973776};\\\", \\\"{x:169,y:533,t:1527627973792};\\\", \\\"{x:166,y:526,t:1527627973808};\\\", \\\"{x:162,y:519,t:1527627973825};\\\", \\\"{x:161,y:514,t:1527627973842};\\\", \\\"{x:161,y:512,t:1527627973858};\\\", \\\"{x:161,y:511,t:1527627973877};\\\", \\\"{x:162,y:510,t:1527627973893};\\\", \\\"{x:163,y:509,t:1527627973911};\\\", \\\"{x:166,y:508,t:1527627973935};\\\", \\\"{x:169,y:507,t:1527627973951};\\\", \\\"{x:173,y:507,t:1527627973959};\\\", \\\"{x:188,y:507,t:1527627973975};\\\", \\\"{x:215,y:512,t:1527627973993};\\\", \\\"{x:249,y:520,t:1527627974009};\\\", \\\"{x:279,y:525,t:1527627974026};\\\", \\\"{x:303,y:526,t:1527627974042};\\\", \\\"{x:324,y:526,t:1527627974058};\\\", \\\"{x:335,y:526,t:1527627974075};\\\", \\\"{x:339,y:526,t:1527627974093};\\\", \\\"{x:340,y:526,t:1527627974185};\\\", \\\"{x:341,y:526,t:1527627974192};\\\", \\\"{x:342,y:526,t:1527627974240};\\\", \\\"{x:343,y:526,t:1527627974247};\\\", \\\"{x:344,y:526,t:1527627974258};\\\", \\\"{x:345,y:526,t:1527627974279};\\\", \\\"{x:346,y:526,t:1527627974292};\\\", \\\"{x:352,y:524,t:1527627974308};\\\", \\\"{x:359,y:524,t:1527627974326};\\\", \\\"{x:365,y:524,t:1527627974343};\\\", \\\"{x:368,y:523,t:1527627974358};\\\", \\\"{x:370,y:522,t:1527627974375};\\\", \\\"{x:372,y:521,t:1527627974392};\\\", \\\"{x:375,y:520,t:1527627974409};\\\", \\\"{x:378,y:520,t:1527627974425};\\\", \\\"{x:379,y:520,t:1527627975072};\\\", \\\"{x:380,y:519,t:1527627975079};\\\", \\\"{x:381,y:517,t:1527627975093};\\\", \\\"{x:387,y:517,t:1527627975110};\\\", \\\"{x:392,y:517,t:1527627975126};\\\", \\\"{x:398,y:516,t:1527627975142};\\\", \\\"{x:401,y:514,t:1527627975159};\\\", \\\"{x:401,y:513,t:1527627975176};\\\", \\\"{x:402,y:513,t:1527627975471};\\\", \\\"{x:403,y:513,t:1527627975479};\\\", \\\"{x:405,y:513,t:1527627975493};\\\", \\\"{x:407,y:513,t:1527627975510};\\\", \\\"{x:409,y:514,t:1527627975526};\\\", \\\"{x:414,y:517,t:1527627975544};\\\", \\\"{x:416,y:519,t:1527627975560};\\\", \\\"{x:417,y:521,t:1527627975577};\\\", \\\"{x:418,y:522,t:1527627975594};\\\", \\\"{x:423,y:525,t:1527627975610};\\\", \\\"{x:441,y:531,t:1527627975626};\\\", \\\"{x:465,y:542,t:1527627975643};\\\", \\\"{x:497,y:556,t:1527627975660};\\\", \\\"{x:553,y:581,t:1527627975676};\\\", \\\"{x:638,y:618,t:1527627975693};\\\", \\\"{x:737,y:659,t:1527627975710};\\\", \\\"{x:849,y:700,t:1527627975726};\\\", \\\"{x:1006,y:755,t:1527627975743};\\\", \\\"{x:1081,y:777,t:1527627975760};\\\", \\\"{x:1133,y:790,t:1527627975777};\\\", \\\"{x:1181,y:804,t:1527627975793};\\\", \\\"{x:1222,y:822,t:1527627975810};\\\", \\\"{x:1252,y:837,t:1527627975826};\\\", \\\"{x:1269,y:847,t:1527627975843};\\\", \\\"{x:1278,y:849,t:1527627975861};\\\", \\\"{x:1284,y:853,t:1527627975876};\\\", \\\"{x:1287,y:853,t:1527627975894};\\\", \\\"{x:1288,y:853,t:1527627975911};\\\", \\\"{x:1289,y:855,t:1527627975936};\\\", \\\"{x:1290,y:855,t:1527627975944};\\\", \\\"{x:1291,y:856,t:1527627975960};\\\", \\\"{x:1292,y:856,t:1527627976017};\\\", \\\"{x:1293,y:856,t:1527627976027};\\\", \\\"{x:1294,y:858,t:1527627976044};\\\", \\\"{x:1295,y:860,t:1527627976079};\\\", \\\"{x:1295,y:861,t:1527627976094};\\\", \\\"{x:1295,y:863,t:1527627976111};\\\", \\\"{x:1295,y:865,t:1527627976128};\\\", \\\"{x:1295,y:868,t:1527627976143};\\\", \\\"{x:1294,y:872,t:1527627976161};\\\", \\\"{x:1293,y:877,t:1527627976178};\\\", \\\"{x:1291,y:883,t:1527627976194};\\\", \\\"{x:1283,y:894,t:1527627976210};\\\", \\\"{x:1277,y:904,t:1527627976228};\\\", \\\"{x:1272,y:917,t:1527627976244};\\\", \\\"{x:1268,y:927,t:1527627976261};\\\", \\\"{x:1262,y:938,t:1527627976278};\\\", \\\"{x:1259,y:942,t:1527627976294};\\\", \\\"{x:1256,y:948,t:1527627976311};\\\", \\\"{x:1254,y:953,t:1527627976328};\\\", \\\"{x:1254,y:956,t:1527627976344};\\\", \\\"{x:1254,y:958,t:1527627976360};\\\", \\\"{x:1254,y:959,t:1527627976378};\\\", \\\"{x:1254,y:962,t:1527627976394};\\\", \\\"{x:1254,y:963,t:1527627976410};\\\", \\\"{x:1254,y:965,t:1527627976447};\\\", \\\"{x:1255,y:965,t:1527627976471};\\\", \\\"{x:1256,y:967,t:1527627976479};\\\", \\\"{x:1257,y:968,t:1527627976494};\\\", \\\"{x:1262,y:972,t:1527627976510};\\\", \\\"{x:1268,y:974,t:1527627976528};\\\", \\\"{x:1273,y:974,t:1527627976544};\\\", \\\"{x:1276,y:974,t:1527627976560};\\\", \\\"{x:1278,y:974,t:1527627976578};\\\", \\\"{x:1283,y:974,t:1527627976595};\\\", \\\"{x:1285,y:974,t:1527627976610};\\\", \\\"{x:1288,y:974,t:1527627976627};\\\", \\\"{x:1290,y:974,t:1527627976648};\\\", \\\"{x:1291,y:974,t:1527627976681};\\\", \\\"{x:1291,y:973,t:1527627976745};\\\", \\\"{x:1291,y:972,t:1527627976801};\\\", \\\"{x:1289,y:970,t:1527627976824};\\\", \\\"{x:1288,y:970,t:1527627976833};\\\", \\\"{x:1287,y:969,t:1527627976845};\\\", \\\"{x:1286,y:968,t:1527627976865};\\\", \\\"{x:1286,y:967,t:1527627976878};\\\", \\\"{x:1285,y:967,t:1527627976912};\\\", \\\"{x:1285,y:966,t:1527627976928};\\\", \\\"{x:1285,y:964,t:1527627976945};\\\", \\\"{x:1285,y:963,t:1527627976968};\\\", \\\"{x:1284,y:962,t:1527627976978};\\\", \\\"{x:1284,y:961,t:1527627976995};\\\", \\\"{x:1284,y:960,t:1527627977012};\\\", \\\"{x:1283,y:957,t:1527627977028};\\\", \\\"{x:1282,y:955,t:1527627977045};\\\", \\\"{x:1281,y:951,t:1527627977062};\\\", \\\"{x:1280,y:949,t:1527627977078};\\\", \\\"{x:1280,y:947,t:1527627977095};\\\", \\\"{x:1278,y:945,t:1527627977112};\\\", \\\"{x:1278,y:944,t:1527627977161};\\\", \\\"{x:1277,y:942,t:1527627977184};\\\", \\\"{x:1277,y:941,t:1527627977232};\\\", \\\"{x:1277,y:939,t:1527627977256};\\\", \\\"{x:1277,y:938,t:1527627977273};\\\", \\\"{x:1277,y:936,t:1527627977288};\\\", \\\"{x:1277,y:935,t:1527627977296};\\\", \\\"{x:1277,y:933,t:1527627977312};\\\", \\\"{x:1275,y:930,t:1527627977328};\\\", \\\"{x:1275,y:926,t:1527627977345};\\\", \\\"{x:1275,y:924,t:1527627977362};\\\", \\\"{x:1274,y:918,t:1527627977378};\\\", \\\"{x:1274,y:913,t:1527627977394};\\\", \\\"{x:1274,y:907,t:1527627977412};\\\", \\\"{x:1274,y:901,t:1527627977428};\\\", \\\"{x:1274,y:896,t:1527627977444};\\\", \\\"{x:1274,y:894,t:1527627977461};\\\", \\\"{x:1274,y:888,t:1527627977479};\\\", \\\"{x:1275,y:883,t:1527627977495};\\\", \\\"{x:1276,y:876,t:1527627977511};\\\", \\\"{x:1276,y:869,t:1527627977529};\\\", \\\"{x:1278,y:855,t:1527627977544};\\\", \\\"{x:1280,y:846,t:1527627977562};\\\", \\\"{x:1282,y:841,t:1527627977579};\\\", \\\"{x:1283,y:838,t:1527627977594};\\\", \\\"{x:1284,y:834,t:1527627977612};\\\", \\\"{x:1284,y:830,t:1527627977629};\\\", \\\"{x:1284,y:827,t:1527627977645};\\\", \\\"{x:1285,y:826,t:1527627977662};\\\", \\\"{x:1285,y:825,t:1527627977680};\\\", \\\"{x:1285,y:824,t:1527627977695};\\\", \\\"{x:1286,y:823,t:1527627977712};\\\", \\\"{x:1285,y:824,t:1527627977967};\\\", \\\"{x:1284,y:824,t:1527627977978};\\\", \\\"{x:1283,y:826,t:1527627977995};\\\", \\\"{x:1283,y:827,t:1527627978945};\\\", \\\"{x:1283,y:828,t:1527627979097};\\\", \\\"{x:1283,y:829,t:1527627979152};\\\", \\\"{x:1283,y:830,t:1527627982591};\\\", \\\"{x:1283,y:832,t:1527627982607};\\\", \\\"{x:1282,y:833,t:1527627982615};\\\", \\\"{x:1279,y:836,t:1527627982633};\\\", \\\"{x:1278,y:837,t:1527627982649};\\\", \\\"{x:1277,y:838,t:1527627982671};\\\", \\\"{x:1277,y:837,t:1527627983808};\\\", \\\"{x:1277,y:836,t:1527627983816};\\\", \\\"{x:1277,y:835,t:1527627983848};\\\", \\\"{x:1277,y:834,t:1527627983863};\\\", \\\"{x:1278,y:834,t:1527627987257};\\\", \\\"{x:1279,y:834,t:1527627987728};\\\", \\\"{x:1279,y:835,t:1527627988128};\\\", \\\"{x:1280,y:835,t:1527627988440};\\\", \\\"{x:1281,y:836,t:1527627988545};\\\", \\\"{x:1281,y:837,t:1527627988656};\\\", \\\"{x:1282,y:837,t:1527627989273};\\\", \\\"{x:1283,y:837,t:1527627989296};\\\", \\\"{x:1284,y:838,t:1527627989392};\\\", \\\"{x:1285,y:838,t:1527627989648};\\\", \\\"{x:1285,y:839,t:1527627989927};\\\", \\\"{x:1286,y:839,t:1527627990152};\\\", \\\"{x:1286,y:840,t:1527627990281};\\\", \\\"{x:1286,y:841,t:1527627990289};\\\", \\\"{x:1284,y:843,t:1527627990305};\\\", \\\"{x:1273,y:843,t:1527627990323};\\\", \\\"{x:1247,y:843,t:1527627990339};\\\", \\\"{x:1175,y:839,t:1527627990356};\\\", \\\"{x:1068,y:819,t:1527627990372};\\\", \\\"{x:944,y:785,t:1527627990388};\\\", \\\"{x:822,y:745,t:1527627990405};\\\", \\\"{x:701,y:694,t:1527627990422};\\\", \\\"{x:553,y:627,t:1527627990441};\\\", \\\"{x:487,y:591,t:1527627990455};\\\", \\\"{x:415,y:547,t:1527627990489};\\\", \\\"{x:407,y:542,t:1527627990502};\\\", \\\"{x:404,y:540,t:1527627990518};\\\", \\\"{x:404,y:539,t:1527627990559};\\\", \\\"{x:405,y:539,t:1527627990571};\\\", \\\"{x:412,y:541,t:1527627990588};\\\", \\\"{x:427,y:551,t:1527627990606};\\\", \\\"{x:448,y:562,t:1527627990621};\\\", \\\"{x:489,y:589,t:1527627990639};\\\", \\\"{x:517,y:608,t:1527627990656};\\\", \\\"{x:545,y:628,t:1527627990672};\\\", \\\"{x:569,y:643,t:1527627990689};\\\", \\\"{x:584,y:654,t:1527627990706};\\\", \\\"{x:587,y:658,t:1527627990722};\\\", \\\"{x:587,y:660,t:1527627990739};\\\", \\\"{x:587,y:664,t:1527627990756};\\\", \\\"{x:584,y:668,t:1527627990772};\\\", \\\"{x:581,y:672,t:1527627990789};\\\", \\\"{x:576,y:676,t:1527627990806};\\\", \\\"{x:569,y:681,t:1527627990822};\\\", \\\"{x:557,y:690,t:1527627990839};\\\", \\\"{x:551,y:694,t:1527627990856};\\\", \\\"{x:543,y:700,t:1527627990872};\\\", \\\"{x:539,y:703,t:1527627990891};\\\", \\\"{x:537,y:704,t:1527627990906};\\\", \\\"{x:535,y:706,t:1527627990923};\\\", \\\"{x:534,y:707,t:1527627990938};\\\", \\\"{x:533,y:708,t:1527627990956};\\\", \\\"{x:533,y:709,t:1527627990973};\\\", \\\"{x:533,y:714,t:1527627990988};\\\", \\\"{x:533,y:720,t:1527627991006};\\\", \\\"{x:533,y:727,t:1527627991023};\\\", \\\"{x:533,y:729,t:1527627991039};\\\", \\\"{x:534,y:729,t:1527627992015};\\\", \\\"{x:534,y:728,t:1527627992023};\\\" ] }, { \\\"rt\\\": 11372, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 132982, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:727,t:1527627999995};\\\", \\\"{x:539,y:727,t:1527628000008};\\\", \\\"{x:545,y:727,t:1527628000017};\\\", \\\"{x:561,y:725,t:1527628000033};\\\", \\\"{x:607,y:721,t:1527628000050};\\\", \\\"{x:762,y:734,t:1527628000066};\\\", \\\"{x:848,y:745,t:1527628000083};\\\", \\\"{x:939,y:757,t:1527628000101};\\\", \\\"{x:1048,y:775,t:1527628000116};\\\", \\\"{x:1146,y:792,t:1527628000134};\\\", \\\"{x:1213,y:802,t:1527628000150};\\\", \\\"{x:1242,y:808,t:1527628000167};\\\", \\\"{x:1259,y:812,t:1527628000184};\\\", \\\"{x:1267,y:814,t:1527628000201};\\\", \\\"{x:1269,y:814,t:1527628000217};\\\", \\\"{x:1273,y:817,t:1527628000234};\\\", \\\"{x:1304,y:829,t:1527628000250};\\\", \\\"{x:1338,y:842,t:1527628000267};\\\", \\\"{x:1371,y:857,t:1527628000284};\\\", \\\"{x:1389,y:864,t:1527628000301};\\\", \\\"{x:1394,y:865,t:1527628000317};\\\", \\\"{x:1397,y:866,t:1527628000334};\\\", \\\"{x:1401,y:868,t:1527628000350};\\\", \\\"{x:1408,y:871,t:1527628000367};\\\", \\\"{x:1411,y:873,t:1527628000384};\\\", \\\"{x:1412,y:873,t:1527628000475};\\\", \\\"{x:1413,y:874,t:1527628000499};\\\", \\\"{x:1413,y:875,t:1527628000515};\\\", \\\"{x:1413,y:876,t:1527628000539};\\\", \\\"{x:1413,y:877,t:1527628000563};\\\", \\\"{x:1413,y:878,t:1527628000571};\\\", \\\"{x:1413,y:879,t:1527628000587};\\\", \\\"{x:1413,y:880,t:1527628000684};\\\", \\\"{x:1413,y:881,t:1527628000707};\\\", \\\"{x:1413,y:882,t:1527628000739};\\\", \\\"{x:1412,y:883,t:1527628001035};\\\", \\\"{x:1412,y:884,t:1527628001283};\\\", \\\"{x:1412,y:885,t:1527628001298};\\\", \\\"{x:1413,y:885,t:1527628001371};\\\", \\\"{x:1413,y:886,t:1527628001891};\\\", \\\"{x:1413,y:887,t:1527628001902};\\\", \\\"{x:1413,y:888,t:1527628001920};\\\", \\\"{x:1413,y:890,t:1527628001936};\\\", \\\"{x:1412,y:891,t:1527628001953};\\\", \\\"{x:1412,y:893,t:1527628001969};\\\", \\\"{x:1411,y:894,t:1527628001986};\\\", \\\"{x:1409,y:899,t:1527628002003};\\\", \\\"{x:1408,y:901,t:1527628002019};\\\", \\\"{x:1407,y:904,t:1527628002036};\\\", \\\"{x:1406,y:905,t:1527628002054};\\\", \\\"{x:1406,y:906,t:1527628002069};\\\", \\\"{x:1404,y:910,t:1527628002086};\\\", \\\"{x:1404,y:911,t:1527628002103};\\\", \\\"{x:1404,y:913,t:1527628002119};\\\", \\\"{x:1404,y:914,t:1527628002136};\\\", \\\"{x:1403,y:915,t:1527628002153};\\\", \\\"{x:1403,y:916,t:1527628002179};\\\", \\\"{x:1402,y:916,t:1527628002259};\\\", \\\"{x:1402,y:917,t:1527628002372};\\\", \\\"{x:1402,y:918,t:1527628002811};\\\", \\\"{x:1403,y:918,t:1527628003556};\\\", \\\"{x:1403,y:919,t:1527628003668};\\\", \\\"{x:1404,y:919,t:1527628004524};\\\", \\\"{x:1402,y:918,t:1527628006179};\\\", \\\"{x:1399,y:917,t:1527628006190};\\\", \\\"{x:1386,y:909,t:1527628006208};\\\", \\\"{x:1368,y:900,t:1527628006224};\\\", \\\"{x:1353,y:893,t:1527628006240};\\\", \\\"{x:1337,y:886,t:1527628006257};\\\", \\\"{x:1322,y:880,t:1527628006274};\\\", \\\"{x:1310,y:873,t:1527628006291};\\\", \\\"{x:1303,y:871,t:1527628006307};\\\", \\\"{x:1299,y:868,t:1527628006325};\\\", \\\"{x:1293,y:864,t:1527628006341};\\\", \\\"{x:1283,y:858,t:1527628006357};\\\", \\\"{x:1271,y:851,t:1527628006374};\\\", \\\"{x:1251,y:841,t:1527628006391};\\\", \\\"{x:1222,y:827,t:1527628006407};\\\", \\\"{x:1178,y:809,t:1527628006425};\\\", \\\"{x:1114,y:782,t:1527628006441};\\\", \\\"{x:1048,y:754,t:1527628006457};\\\", \\\"{x:974,y:722,t:1527628006474};\\\", \\\"{x:843,y:668,t:1527628006491};\\\", \\\"{x:749,y:628,t:1527628006508};\\\", \\\"{x:661,y:588,t:1527628006525};\\\", \\\"{x:586,y:555,t:1527628006541};\\\", \\\"{x:553,y:541,t:1527628006557};\\\", \\\"{x:543,y:537,t:1527628006572};\\\", \\\"{x:542,y:537,t:1527628006601};\\\", \\\"{x:540,y:535,t:1527628006610};\\\", \\\"{x:539,y:534,t:1527628006642};\\\", \\\"{x:538,y:533,t:1527628006658};\\\", \\\"{x:538,y:532,t:1527628006674};\\\", \\\"{x:538,y:529,t:1527628006698};\\\", \\\"{x:537,y:529,t:1527628006706};\\\", \\\"{x:536,y:528,t:1527628006722};\\\", \\\"{x:532,y:521,t:1527628006738};\\\", \\\"{x:528,y:514,t:1527628006755};\\\", \\\"{x:524,y:509,t:1527628006772};\\\", \\\"{x:521,y:506,t:1527628006788};\\\", \\\"{x:520,y:506,t:1527628006805};\\\", \\\"{x:520,y:504,t:1527628006823};\\\", \\\"{x:520,y:505,t:1527628007107};\\\", \\\"{x:522,y:505,t:1527628007131};\\\", \\\"{x:522,y:506,t:1527628007147};\\\", \\\"{x:523,y:506,t:1527628007243};\\\", \\\"{x:523,y:507,t:1527628007259};\\\", \\\"{x:524,y:507,t:1527628007315};\\\", \\\"{x:526,y:507,t:1527628007499};\\\", \\\"{x:526,y:508,t:1527628007506};\\\", \\\"{x:528,y:511,t:1527628007914};\\\", \\\"{x:529,y:516,t:1527628007923};\\\", \\\"{x:529,y:519,t:1527628007940};\\\", \\\"{x:530,y:524,t:1527628007956};\\\", \\\"{x:530,y:525,t:1527628007973};\\\", \\\"{x:530,y:526,t:1527628007990};\\\", \\\"{x:530,y:528,t:1527628008011};\\\", \\\"{x:530,y:529,t:1527628008027};\\\", \\\"{x:530,y:530,t:1527628008083};\\\", \\\"{x:530,y:532,t:1527628008091};\\\", \\\"{x:526,y:533,t:1527628008107};\\\", \\\"{x:517,y:537,t:1527628008124};\\\", \\\"{x:503,y:542,t:1527628008140};\\\", \\\"{x:487,y:545,t:1527628008157};\\\", \\\"{x:466,y:548,t:1527628008174};\\\", \\\"{x:448,y:552,t:1527628008189};\\\", \\\"{x:432,y:558,t:1527628008206};\\\", \\\"{x:424,y:561,t:1527628008222};\\\", \\\"{x:422,y:562,t:1527628008240};\\\", \\\"{x:422,y:563,t:1527628008256};\\\", \\\"{x:420,y:563,t:1527628008307};\\\", \\\"{x:417,y:564,t:1527628008323};\\\", \\\"{x:411,y:564,t:1527628008341};\\\", \\\"{x:400,y:564,t:1527628008357};\\\", \\\"{x:385,y:564,t:1527628008374};\\\", \\\"{x:365,y:564,t:1527628008391};\\\", \\\"{x:347,y:564,t:1527628008407};\\\", \\\"{x:331,y:567,t:1527628008423};\\\", \\\"{x:317,y:572,t:1527628008440};\\\", \\\"{x:304,y:577,t:1527628008458};\\\", \\\"{x:295,y:582,t:1527628008475};\\\", \\\"{x:293,y:583,t:1527628008489};\\\", \\\"{x:293,y:585,t:1527628008522};\\\", \\\"{x:292,y:585,t:1527628008619};\\\", \\\"{x:292,y:586,t:1527628008699};\\\", \\\"{x:287,y:589,t:1527628008706};\\\", \\\"{x:273,y:598,t:1527628008724};\\\", \\\"{x:257,y:606,t:1527628008741};\\\", \\\"{x:234,y:617,t:1527628008757};\\\", \\\"{x:218,y:626,t:1527628008775};\\\", \\\"{x:205,y:631,t:1527628008791};\\\", \\\"{x:194,y:636,t:1527628008807};\\\", \\\"{x:183,y:641,t:1527628008824};\\\", \\\"{x:168,y:646,t:1527628008841};\\\", \\\"{x:154,y:650,t:1527628008857};\\\", \\\"{x:150,y:651,t:1527628008874};\\\", \\\"{x:148,y:652,t:1527628008890};\\\", \\\"{x:141,y:652,t:1527628008906};\\\", \\\"{x:134,y:652,t:1527628008924};\\\", \\\"{x:131,y:652,t:1527628008940};\\\", \\\"{x:129,y:652,t:1527628008970};\\\", \\\"{x:129,y:650,t:1527628008978};\\\", \\\"{x:129,y:648,t:1527628008991};\\\", \\\"{x:129,y:644,t:1527628009008};\\\", \\\"{x:129,y:639,t:1527628009024};\\\", \\\"{x:129,y:635,t:1527628009041};\\\", \\\"{x:135,y:630,t:1527628009058};\\\", \\\"{x:137,y:630,t:1527628009073};\\\", \\\"{x:137,y:629,t:1527628009091};\\\", \\\"{x:138,y:629,t:1527628009108};\\\", \\\"{x:140,y:629,t:1527628009163};\\\", \\\"{x:143,y:629,t:1527628009175};\\\", \\\"{x:151,y:629,t:1527628009192};\\\", \\\"{x:166,y:629,t:1527628009208};\\\", \\\"{x:182,y:629,t:1527628009224};\\\", \\\"{x:188,y:631,t:1527628009241};\\\", \\\"{x:189,y:633,t:1527628009258};\\\", \\\"{x:189,y:634,t:1527628009458};\\\", \\\"{x:189,y:635,t:1527628009474};\\\", \\\"{x:189,y:636,t:1527628009490};\\\", \\\"{x:189,y:637,t:1527628009530};\\\", \\\"{x:188,y:637,t:1527628009546};\\\", \\\"{x:187,y:638,t:1527628009578};\\\", \\\"{x:187,y:639,t:1527628009594};\\\", \\\"{x:187,y:641,t:1527628009608};\\\", \\\"{x:188,y:644,t:1527628009625};\\\", \\\"{x:200,y:647,t:1527628009641};\\\", \\\"{x:268,y:664,t:1527628009658};\\\", \\\"{x:351,y:687,t:1527628009674};\\\", \\\"{x:434,y:709,t:1527628009690};\\\", \\\"{x:503,y:734,t:1527628009708};\\\", \\\"{x:534,y:742,t:1527628009725};\\\", \\\"{x:548,y:746,t:1527628009740};\\\", \\\"{x:554,y:747,t:1527628009757};\\\", \\\"{x:556,y:748,t:1527628009778};\\\", \\\"{x:557,y:749,t:1527628009791};\\\", \\\"{x:559,y:752,t:1527628009808};\\\", \\\"{x:569,y:763,t:1527628009825};\\\", \\\"{x:580,y:772,t:1527628009841};\\\", \\\"{x:592,y:777,t:1527628009858};\\\", \\\"{x:593,y:777,t:1527628009930};\\\", \\\"{x:593,y:774,t:1527628009947};\\\", \\\"{x:589,y:770,t:1527628009958};\\\", \\\"{x:579,y:760,t:1527628009975};\\\", \\\"{x:567,y:751,t:1527628009992};\\\", \\\"{x:561,y:748,t:1527628010009};\\\", \\\"{x:559,y:747,t:1527628010025};\\\", \\\"{x:554,y:743,t:1527628010041};\\\", \\\"{x:549,y:740,t:1527628010058};\\\", \\\"{x:546,y:737,t:1527628010075};\\\", \\\"{x:546,y:735,t:1527628010196};\\\", \\\"{x:546,y:734,t:1527628010207};\\\", \\\"{x:545,y:731,t:1527628010225};\\\", \\\"{x:545,y:725,t:1527628010242};\\\", \\\"{x:543,y:721,t:1527628010257};\\\", \\\"{x:541,y:716,t:1527628010275};\\\", \\\"{x:537,y:711,t:1527628010292};\\\", \\\"{x:536,y:708,t:1527628010309};\\\", \\\"{x:535,y:707,t:1527628010325};\\\", \\\"{x:536,y:707,t:1527628010626};\\\", \\\"{x:537,y:707,t:1527628010650};\\\" ] }, { \\\"rt\\\": 18426, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 152638, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:708,t:1527628012947};\\\", \\\"{x:537,y:709,t:1527628013515};\\\", \\\"{x:537,y:710,t:1527628013539};\\\", \\\"{x:537,y:711,t:1527628018722};\\\", \\\"{x:537,y:712,t:1527628018729};\\\", \\\"{x:537,y:713,t:1527628018995};\\\", \\\"{x:537,y:714,t:1527628019010};\\\", \\\"{x:537,y:715,t:1527628019028};\\\", \\\"{x:537,y:716,t:1527628020059};\\\", \\\"{x:537,y:717,t:1527628023234};\\\", \\\"{x:537,y:718,t:1527628023634};\\\", \\\"{x:537,y:719,t:1527628023803};\\\", \\\"{x:537,y:720,t:1527628023818};\\\", \\\"{x:537,y:721,t:1527628023842};\\\", \\\"{x:536,y:723,t:1527628027475};\\\", \\\"{x:535,y:724,t:1527628027492};\\\", \\\"{x:530,y:727,t:1527628027508};\\\", \\\"{x:526,y:730,t:1527628027525};\\\", \\\"{x:521,y:736,t:1527628027543};\\\", \\\"{x:516,y:744,t:1527628027558};\\\", \\\"{x:510,y:754,t:1527628027574};\\\", \\\"{x:505,y:759,t:1527628027585};\\\", \\\"{x:498,y:767,t:1527628027601};\\\", \\\"{x:492,y:775,t:1527628027618};\\\", \\\"{x:490,y:777,t:1527628027634};\\\", \\\"{x:490,y:778,t:1527628027651};\\\", \\\"{x:490,y:775,t:1527628027722};\\\", \\\"{x:491,y:770,t:1527628027735};\\\", \\\"{x:494,y:761,t:1527628027751};\\\", \\\"{x:498,y:753,t:1527628027767};\\\", \\\"{x:499,y:747,t:1527628027784};\\\", \\\"{x:501,y:743,t:1527628027801};\\\", \\\"{x:501,y:740,t:1527628027818};\\\", \\\"{x:500,y:736,t:1527628027834};\\\", \\\"{x:499,y:731,t:1527628027853};\\\", \\\"{x:495,y:726,t:1527628027868};\\\", \\\"{x:461,y:700,t:1527628027890};\\\", \\\"{x:423,y:678,t:1527628027907};\\\", \\\"{x:372,y:650,t:1527628027923};\\\", \\\"{x:299,y:612,t:1527628027940};\\\", \\\"{x:210,y:565,t:1527628027957};\\\", \\\"{x:118,y:519,t:1527628027973};\\\", \\\"{x:41,y:475,t:1527628027990};\\\", \\\"{x:0,y:452,t:1527628028007};\\\", \\\"{x:0,y:447,t:1527628028023};\\\", \\\"{x:0,y:446,t:1527628028039};\\\", \\\"{x:2,y:446,t:1527628028106};\\\", \\\"{x:4,y:447,t:1527628028122};\\\", \\\"{x:7,y:452,t:1527628028140};\\\", \\\"{x:8,y:456,t:1527628028156};\\\", \\\"{x:11,y:463,t:1527628028173};\\\", \\\"{x:20,y:473,t:1527628028189};\\\", \\\"{x:37,y:485,t:1527628028207};\\\", \\\"{x:62,y:496,t:1527628028223};\\\", \\\"{x:92,y:508,t:1527628028240};\\\", \\\"{x:117,y:516,t:1527628028257};\\\", \\\"{x:152,y:527,t:1527628028274};\\\", \\\"{x:168,y:531,t:1527628028289};\\\", \\\"{x:183,y:537,t:1527628028308};\\\", \\\"{x:195,y:540,t:1527628028323};\\\", \\\"{x:203,y:542,t:1527628028340};\\\", \\\"{x:205,y:542,t:1527628028442};\\\", \\\"{x:205,y:543,t:1527628028457};\\\", \\\"{x:206,y:546,t:1527628028476};\\\", \\\"{x:206,y:547,t:1527628028489};\\\", \\\"{x:206,y:549,t:1527628028507};\\\", \\\"{x:201,y:551,t:1527628028523};\\\", \\\"{x:194,y:554,t:1527628028540};\\\", \\\"{x:189,y:555,t:1527628028557};\\\", \\\"{x:188,y:556,t:1527628028574};\\\", \\\"{x:187,y:556,t:1527628028589};\\\", \\\"{x:186,y:557,t:1527628028606};\\\", \\\"{x:184,y:557,t:1527628028650};\\\", \\\"{x:184,y:558,t:1527628028666};\\\", \\\"{x:186,y:558,t:1527628029090};\\\", \\\"{x:196,y:563,t:1527628029108};\\\", \\\"{x:214,y:573,t:1527628029123};\\\", \\\"{x:252,y:595,t:1527628029141};\\\", \\\"{x:290,y:616,t:1527628029158};\\\", \\\"{x:320,y:640,t:1527628029174};\\\", \\\"{x:338,y:654,t:1527628029191};\\\", \\\"{x:343,y:659,t:1527628029208};\\\", \\\"{x:343,y:666,t:1527628029223};\\\", \\\"{x:345,y:673,t:1527628029241};\\\", \\\"{x:352,y:687,t:1527628029258};\\\", \\\"{x:355,y:693,t:1527628029273};\\\", \\\"{x:360,y:701,t:1527628029290};\\\", \\\"{x:368,y:710,t:1527628029307};\\\", \\\"{x:375,y:718,t:1527628029324};\\\", \\\"{x:380,y:727,t:1527628029341};\\\", \\\"{x:386,y:735,t:1527628029358};\\\", \\\"{x:393,y:740,t:1527628029373};\\\", \\\"{x:397,y:743,t:1527628029391};\\\", \\\"{x:403,y:748,t:1527628029407};\\\", \\\"{x:408,y:751,t:1527628029423};\\\", \\\"{x:409,y:751,t:1527628029440};\\\", \\\"{x:410,y:751,t:1527628029514};\\\", \\\"{x:412,y:751,t:1527628029538};\\\", \\\"{x:414,y:751,t:1527628029547};\\\", \\\"{x:418,y:749,t:1527628029558};\\\", \\\"{x:422,y:747,t:1527628029575};\\\", \\\"{x:423,y:746,t:1527628029591};\\\", \\\"{x:428,y:744,t:1527628029608};\\\", \\\"{x:433,y:742,t:1527628029624};\\\", \\\"{x:438,y:738,t:1527628029641};\\\", \\\"{x:444,y:734,t:1527628029658};\\\", \\\"{x:447,y:732,t:1527628029675};\\\", \\\"{x:451,y:728,t:1527628029691};\\\", \\\"{x:455,y:723,t:1527628029708};\\\", \\\"{x:460,y:719,t:1527628029725};\\\", \\\"{x:466,y:716,t:1527628029741};\\\", \\\"{x:470,y:715,t:1527628029758};\\\", \\\"{x:474,y:713,t:1527628029774};\\\", \\\"{x:475,y:712,t:1527628029791};\\\", \\\"{x:476,y:712,t:1527628029908};\\\", \\\"{x:476,y:713,t:1527628030970};\\\", \\\"{x:476,y:714,t:1527628030977};\\\", \\\"{x:476,y:715,t:1527628031058};\\\", \\\"{x:477,y:715,t:1527628031076};\\\", \\\"{x:477,y:716,t:1527628031122};\\\", \\\"{x:478,y:716,t:1527628031161};\\\" ] }, { \\\"rt\\\": 73513, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 227385, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-04 PM-04 PM-04 PM-04 PM-03 PM-04 PM-E -E -02 PM-08 PM-05 PM-U -U -U -Z -Z -Z -O -O -O -O -Z -12 PM-11 AM-O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:716,t:1527628031357};\\\", \\\"{x:481,y:716,t:1527628031393};\\\", \\\"{x:482,y:716,t:1527628031426};\\\", \\\"{x:483,y:716,t:1527628031442};\\\", \\\"{x:484,y:716,t:1527628031486};\\\", \\\"{x:485,y:716,t:1527628031493};\\\", \\\"{x:486,y:715,t:1527628031508};\\\", \\\"{x:486,y:714,t:1527628031618};\\\", \\\"{x:486,y:713,t:1527628031633};\\\", \\\"{x:486,y:712,t:1527628031657};\\\", \\\"{x:485,y:711,t:1527628031829};\\\", \\\"{x:484,y:711,t:1527628031843};\\\", \\\"{x:483,y:711,t:1527628031860};\\\", \\\"{x:482,y:711,t:1527628031875};\\\", \\\"{x:481,y:711,t:1527628031892};\\\", \\\"{x:480,y:712,t:1527628031909};\\\", \\\"{x:479,y:712,t:1527628031926};\\\", \\\"{x:478,y:713,t:1527628031943};\\\", \\\"{x:477,y:713,t:1527628031978};\\\", \\\"{x:476,y:714,t:1527628032050};\\\", \\\"{x:476,y:715,t:1527628032130};\\\", \\\"{x:476,y:716,t:1527628032146};\\\", \\\"{x:476,y:718,t:1527628032160};\\\", \\\"{x:476,y:721,t:1527628032177};\\\", \\\"{x:472,y:727,t:1527628032193};\\\", \\\"{x:467,y:738,t:1527628032211};\\\", \\\"{x:467,y:739,t:1527628032227};\\\", \\\"{x:465,y:740,t:1527628032274};\\\", \\\"{x:463,y:742,t:1527628032298};\\\", \\\"{x:462,y:742,t:1527628032322};\\\", \\\"{x:461,y:742,t:1527628032682};\\\", \\\"{x:460,y:742,t:1527628032694};\\\", \\\"{x:459,y:742,t:1527628032858};\\\", \\\"{x:459,y:741,t:1527628033066};\\\", \\\"{x:457,y:741,t:1527628033281};\\\", \\\"{x:455,y:745,t:1527628033295};\\\", \\\"{x:453,y:748,t:1527628033311};\\\", \\\"{x:451,y:748,t:1527628033327};\\\", \\\"{x:449,y:748,t:1527628033345};\\\", \\\"{x:447,y:749,t:1527628033361};\\\", \\\"{x:442,y:750,t:1527628033377};\\\", \\\"{x:440,y:750,t:1527628033394};\\\", \\\"{x:438,y:749,t:1527628033412};\\\", \\\"{x:438,y:747,t:1527628033475};\\\", \\\"{x:438,y:738,t:1527628033482};\\\", \\\"{x:443,y:726,t:1527628033495};\\\", \\\"{x:457,y:701,t:1527628033513};\\\", \\\"{x:479,y:663,t:1527628033529};\\\", \\\"{x:503,y:624,t:1527628033546};\\\", \\\"{x:534,y:577,t:1527628033561};\\\", \\\"{x:575,y:516,t:1527628033578};\\\", \\\"{x:591,y:490,t:1527628033594};\\\", \\\"{x:604,y:474,t:1527628033610};\\\", \\\"{x:609,y:470,t:1527628033627};\\\", \\\"{x:614,y:468,t:1527628033644};\\\", \\\"{x:619,y:468,t:1527628033660};\\\", \\\"{x:629,y:474,t:1527628033678};\\\", \\\"{x:638,y:481,t:1527628033694};\\\", \\\"{x:639,y:490,t:1527628033711};\\\", \\\"{x:641,y:491,t:1527628033727};\\\", \\\"{x:637,y:499,t:1527628033744};\\\", \\\"{x:630,y:510,t:1527628033761};\\\", \\\"{x:620,y:526,t:1527628033778};\\\", \\\"{x:615,y:534,t:1527628033795};\\\", \\\"{x:614,y:536,t:1527628033811};\\\", \\\"{x:613,y:537,t:1527628034107};\\\", \\\"{x:613,y:539,t:1527628034129};\\\", \\\"{x:613,y:540,t:1527628034144};\\\", \\\"{x:612,y:541,t:1527628034161};\\\", \\\"{x:612,y:543,t:1527628034178};\\\", \\\"{x:612,y:545,t:1527628034195};\\\", \\\"{x:610,y:547,t:1527628034212};\\\", \\\"{x:610,y:549,t:1527628034228};\\\", \\\"{x:610,y:552,t:1527628034245};\\\", \\\"{x:609,y:554,t:1527628034262};\\\", \\\"{x:609,y:556,t:1527628034277};\\\", \\\"{x:609,y:557,t:1527628034295};\\\", \\\"{x:609,y:560,t:1527628034312};\\\", \\\"{x:609,y:564,t:1527628034327};\\\", \\\"{x:609,y:575,t:1527628034346};\\\", \\\"{x:609,y:594,t:1527628034362};\\\", \\\"{x:611,y:618,t:1527628034378};\\\", \\\"{x:639,y:682,t:1527628034395};\\\", \\\"{x:707,y:792,t:1527628034412};\\\", \\\"{x:803,y:907,t:1527628034427};\\\", \\\"{x:894,y:992,t:1527628034445};\\\", \\\"{x:955,y:1044,t:1527628034462};\\\", \\\"{x:980,y:1060,t:1527628034478};\\\", \\\"{x:999,y:1068,t:1527628034494};\\\", \\\"{x:1021,y:1079,t:1527628034511};\\\", \\\"{x:1037,y:1090,t:1527628034527};\\\", \\\"{x:1054,y:1101,t:1527628034544};\\\", \\\"{x:1065,y:1102,t:1527628034562};\\\", \\\"{x:1068,y:1102,t:1527628034578};\\\", \\\"{x:1069,y:1100,t:1527628035394};\\\", \\\"{x:1079,y:1091,t:1527628035412};\\\", \\\"{x:1087,y:1082,t:1527628035429};\\\", \\\"{x:1093,y:1076,t:1527628035446};\\\", \\\"{x:1095,y:1074,t:1527628035462};\\\", \\\"{x:1096,y:1072,t:1527628035479};\\\", \\\"{x:1097,y:1071,t:1527628035496};\\\", \\\"{x:1097,y:1069,t:1527628035512};\\\", \\\"{x:1098,y:1067,t:1527628035529};\\\", \\\"{x:1100,y:1063,t:1527628035546};\\\", \\\"{x:1104,y:1058,t:1527628035562};\\\", \\\"{x:1108,y:1052,t:1527628035580};\\\", \\\"{x:1111,y:1048,t:1527628035596};\\\", \\\"{x:1115,y:1041,t:1527628035613};\\\", \\\"{x:1119,y:1034,t:1527628035630};\\\", \\\"{x:1123,y:1029,t:1527628035646};\\\", \\\"{x:1127,y:1022,t:1527628035663};\\\", \\\"{x:1129,y:1019,t:1527628035680};\\\", \\\"{x:1131,y:1016,t:1527628035697};\\\", \\\"{x:1131,y:1015,t:1527628035713};\\\", \\\"{x:1131,y:1014,t:1527628035730};\\\", \\\"{x:1130,y:1014,t:1527628036266};\\\", \\\"{x:1129,y:1014,t:1527628036315};\\\", \\\"{x:1128,y:1014,t:1527628036330};\\\", \\\"{x:1126,y:1014,t:1527628036346};\\\", \\\"{x:1125,y:1015,t:1527628036364};\\\", \\\"{x:1124,y:1015,t:1527628036394};\\\", \\\"{x:1123,y:1015,t:1527628036411};\\\", \\\"{x:1122,y:1016,t:1527628036434};\\\", \\\"{x:1121,y:1016,t:1527628036491};\\\", \\\"{x:1120,y:1017,t:1527628036498};\\\", \\\"{x:1119,y:1017,t:1527628036514};\\\", \\\"{x:1118,y:1017,t:1527628036530};\\\", \\\"{x:1116,y:1018,t:1527628036546};\\\", \\\"{x:1115,y:1018,t:1527628036578};\\\", \\\"{x:1114,y:1019,t:1527628036603};\\\", \\\"{x:1113,y:1019,t:1527628036642};\\\", \\\"{x:1112,y:1020,t:1527628036666};\\\", \\\"{x:1111,y:1020,t:1527628036747};\\\", \\\"{x:1110,y:1020,t:1527628036763};\\\", \\\"{x:1109,y:1020,t:1527628036891};\\\", \\\"{x:1108,y:1020,t:1527628036914};\\\", \\\"{x:1107,y:1021,t:1527628036930};\\\", \\\"{x:1105,y:1022,t:1527628037011};\\\", \\\"{x:1107,y:1024,t:1527628037250};\\\", \\\"{x:1112,y:1028,t:1527628037263};\\\", \\\"{x:1131,y:1033,t:1527628037281};\\\", \\\"{x:1175,y:1034,t:1527628037296};\\\", \\\"{x:1259,y:1034,t:1527628037313};\\\", \\\"{x:1391,y:1016,t:1527628037331};\\\", \\\"{x:1461,y:1002,t:1527628037347};\\\", \\\"{x:1486,y:999,t:1527628037364};\\\", \\\"{x:1488,y:997,t:1527628037380};\\\", \\\"{x:1491,y:997,t:1527628037435};\\\", \\\"{x:1495,y:996,t:1527628037446};\\\", \\\"{x:1521,y:988,t:1527628037463};\\\", \\\"{x:1609,y:969,t:1527628037480};\\\", \\\"{x:1688,y:951,t:1527628037497};\\\", \\\"{x:1698,y:943,t:1527628037513};\\\", \\\"{x:1704,y:932,t:1527628037531};\\\", \\\"{x:1704,y:928,t:1527628037547};\\\", \\\"{x:1705,y:926,t:1527628037563};\\\", \\\"{x:1706,y:924,t:1527628037635};\\\", \\\"{x:1706,y:928,t:1527628037739};\\\", \\\"{x:1704,y:935,t:1527628037747};\\\", \\\"{x:1696,y:951,t:1527628037763};\\\", \\\"{x:1684,y:971,t:1527628037781};\\\", \\\"{x:1674,y:986,t:1527628037798};\\\", \\\"{x:1665,y:1000,t:1527628037814};\\\", \\\"{x:1656,y:1012,t:1527628037830};\\\", \\\"{x:1652,y:1017,t:1527628037846};\\\", \\\"{x:1650,y:1020,t:1527628037863};\\\", \\\"{x:1649,y:1020,t:1527628037890};\\\", \\\"{x:1647,y:1020,t:1527628038003};\\\", \\\"{x:1645,y:1020,t:1527628038013};\\\", \\\"{x:1640,y:1018,t:1527628038030};\\\", \\\"{x:1636,y:1014,t:1527628038047};\\\", \\\"{x:1635,y:1014,t:1527628038063};\\\", \\\"{x:1632,y:1013,t:1527628038080};\\\", \\\"{x:1629,y:1011,t:1527628038097};\\\", \\\"{x:1627,y:1007,t:1527628038113};\\\", \\\"{x:1624,y:1002,t:1527628038130};\\\", \\\"{x:1624,y:1000,t:1527628038147};\\\", \\\"{x:1622,y:997,t:1527628038163};\\\", \\\"{x:1622,y:995,t:1527628038202};\\\", \\\"{x:1622,y:994,t:1527628038218};\\\", \\\"{x:1621,y:992,t:1527628038230};\\\", \\\"{x:1619,y:988,t:1527628038247};\\\", \\\"{x:1617,y:984,t:1527628038264};\\\", \\\"{x:1616,y:980,t:1527628038280};\\\", \\\"{x:1614,y:977,t:1527628038297};\\\", \\\"{x:1613,y:971,t:1527628038314};\\\", \\\"{x:1613,y:968,t:1527628038330};\\\", \\\"{x:1611,y:965,t:1527628038347};\\\", \\\"{x:1611,y:964,t:1527628038385};\\\", \\\"{x:1611,y:963,t:1527628038401};\\\", \\\"{x:1611,y:962,t:1527628038417};\\\", \\\"{x:1610,y:960,t:1527628038474};\\\", \\\"{x:1610,y:959,t:1527628038506};\\\", \\\"{x:1610,y:958,t:1527628038530};\\\", \\\"{x:1610,y:956,t:1527628038548};\\\", \\\"{x:1609,y:954,t:1527628038564};\\\", \\\"{x:1609,y:952,t:1527628038581};\\\", \\\"{x:1609,y:951,t:1527628038667};\\\", \\\"{x:1609,y:950,t:1527628038771};\\\", \\\"{x:1609,y:949,t:1527628038818};\\\", \\\"{x:1609,y:948,t:1527628038851};\\\", \\\"{x:1609,y:947,t:1527628038882};\\\", \\\"{x:1609,y:945,t:1527628038906};\\\", \\\"{x:1609,y:944,t:1527628038946};\\\", \\\"{x:1609,y:942,t:1527628038978};\\\", \\\"{x:1609,y:941,t:1527628039050};\\\", \\\"{x:1609,y:939,t:1527628039107};\\\", \\\"{x:1609,y:938,t:1527628039130};\\\", \\\"{x:1610,y:937,t:1527628039148};\\\", \\\"{x:1612,y:935,t:1527628039164};\\\", \\\"{x:1615,y:931,t:1527628039181};\\\", \\\"{x:1616,y:931,t:1527628039197};\\\", \\\"{x:1617,y:929,t:1527628039214};\\\", \\\"{x:1618,y:928,t:1527628039265};\\\", \\\"{x:1619,y:928,t:1527628039305};\\\", \\\"{x:1620,y:927,t:1527628039353};\\\", \\\"{x:1620,y:929,t:1527628039450};\\\", \\\"{x:1620,y:934,t:1527628039465};\\\", \\\"{x:1619,y:942,t:1527628039481};\\\", \\\"{x:1615,y:958,t:1527628039497};\\\", \\\"{x:1609,y:977,t:1527628039515};\\\", \\\"{x:1609,y:984,t:1527628039532};\\\", \\\"{x:1609,y:988,t:1527628039548};\\\", \\\"{x:1609,y:989,t:1527628039565};\\\", \\\"{x:1609,y:988,t:1527628039730};\\\", \\\"{x:1610,y:985,t:1527628039748};\\\", \\\"{x:1611,y:983,t:1527628039765};\\\", \\\"{x:1611,y:981,t:1527628039782};\\\", \\\"{x:1612,y:979,t:1527628039798};\\\", \\\"{x:1613,y:977,t:1527628039814};\\\", \\\"{x:1613,y:976,t:1527628039831};\\\", \\\"{x:1613,y:974,t:1527628039848};\\\", \\\"{x:1614,y:973,t:1527628039864};\\\", \\\"{x:1614,y:972,t:1527628039898};\\\", \\\"{x:1614,y:971,t:1527628039970};\\\", \\\"{x:1614,y:970,t:1527628040338};\\\", \\\"{x:1614,y:969,t:1527628040706};\\\", \\\"{x:1614,y:968,t:1527628041571};\\\", \\\"{x:1613,y:968,t:1527628041583};\\\", \\\"{x:1612,y:968,t:1527628041599};\\\", \\\"{x:1609,y:970,t:1527628041616};\\\", \\\"{x:1608,y:970,t:1527628041633};\\\", \\\"{x:1606,y:971,t:1527628041649};\\\", \\\"{x:1605,y:971,t:1527628041738};\\\", \\\"{x:1604,y:971,t:1527628041803};\\\", \\\"{x:1603,y:971,t:1527628041815};\\\", \\\"{x:1602,y:970,t:1527628041842};\\\", \\\"{x:1602,y:969,t:1527628041858};\\\", \\\"{x:1602,y:968,t:1527628041883};\\\", \\\"{x:1602,y:967,t:1527628041900};\\\", \\\"{x:1602,y:966,t:1527628041915};\\\", \\\"{x:1602,y:965,t:1527628041938};\\\", \\\"{x:1602,y:964,t:1527628041994};\\\", \\\"{x:1602,y:962,t:1527628042017};\\\", \\\"{x:1602,y:961,t:1527628042033};\\\", \\\"{x:1602,y:960,t:1527628042048};\\\", \\\"{x:1602,y:957,t:1527628042065};\\\", \\\"{x:1603,y:956,t:1527628042082};\\\", \\\"{x:1604,y:955,t:1527628042099};\\\", \\\"{x:1604,y:954,t:1527628042115};\\\", \\\"{x:1606,y:952,t:1527628042131};\\\", \\\"{x:1607,y:951,t:1527628042149};\\\", \\\"{x:1607,y:949,t:1527628042165};\\\", \\\"{x:1607,y:948,t:1527628042185};\\\", \\\"{x:1607,y:947,t:1527628042427};\\\", \\\"{x:1607,y:946,t:1527628042442};\\\", \\\"{x:1607,y:945,t:1527628042458};\\\", \\\"{x:1607,y:944,t:1527628042466};\\\", \\\"{x:1607,y:942,t:1527628042483};\\\", \\\"{x:1607,y:940,t:1527628042500};\\\", \\\"{x:1607,y:938,t:1527628042515};\\\", \\\"{x:1607,y:936,t:1527628042533};\\\", \\\"{x:1607,y:934,t:1527628042549};\\\", \\\"{x:1607,y:933,t:1527628042565};\\\", \\\"{x:1607,y:932,t:1527628042583};\\\", \\\"{x:1607,y:931,t:1527628042600};\\\", \\\"{x:1607,y:930,t:1527628042616};\\\", \\\"{x:1607,y:929,t:1527628042642};\\\", \\\"{x:1607,y:928,t:1527628042666};\\\", \\\"{x:1608,y:927,t:1527628042690};\\\", \\\"{x:1608,y:926,t:1527628042811};\\\", \\\"{x:1609,y:924,t:1527628042858};\\\", \\\"{x:1609,y:922,t:1527628042906};\\\", \\\"{x:1610,y:922,t:1527628042917};\\\", \\\"{x:1610,y:921,t:1527628042933};\\\", \\\"{x:1610,y:919,t:1527628042962};\\\", \\\"{x:1611,y:918,t:1527628042986};\\\", \\\"{x:1612,y:917,t:1527628042999};\\\", \\\"{x:1612,y:915,t:1527628043017};\\\", \\\"{x:1612,y:913,t:1527628043034};\\\", \\\"{x:1612,y:911,t:1527628043050};\\\", \\\"{x:1612,y:909,t:1527628043066};\\\", \\\"{x:1612,y:907,t:1527628043082};\\\", \\\"{x:1613,y:906,t:1527628043100};\\\", \\\"{x:1613,y:904,t:1527628043117};\\\", \\\"{x:1613,y:900,t:1527628043132};\\\", \\\"{x:1613,y:898,t:1527628043149};\\\", \\\"{x:1613,y:897,t:1527628043167};\\\", \\\"{x:1613,y:895,t:1527628043183};\\\", \\\"{x:1613,y:894,t:1527628043199};\\\", \\\"{x:1613,y:893,t:1527628043216};\\\", \\\"{x:1613,y:891,t:1527628043233};\\\", \\\"{x:1613,y:890,t:1527628043249};\\\", \\\"{x:1613,y:888,t:1527628043266};\\\", \\\"{x:1613,y:887,t:1527628043289};\\\", \\\"{x:1613,y:885,t:1527628043306};\\\", \\\"{x:1613,y:884,t:1527628043316};\\\", \\\"{x:1613,y:881,t:1527628043333};\\\", \\\"{x:1613,y:880,t:1527628043349};\\\", \\\"{x:1613,y:879,t:1527628043366};\\\", \\\"{x:1613,y:878,t:1527628043383};\\\", \\\"{x:1613,y:877,t:1527628043555};\\\", \\\"{x:1613,y:876,t:1527628043566};\\\", \\\"{x:1613,y:875,t:1527628043584};\\\", \\\"{x:1613,y:874,t:1527628043600};\\\", \\\"{x:1613,y:873,t:1527628043617};\\\", \\\"{x:1613,y:872,t:1527628043634};\\\", \\\"{x:1613,y:871,t:1527628043898};\\\", \\\"{x:1613,y:870,t:1527628043916};\\\", \\\"{x:1613,y:869,t:1527628043938};\\\", \\\"{x:1613,y:868,t:1527628043995};\\\", \\\"{x:1613,y:867,t:1527628044058};\\\", \\\"{x:1613,y:866,t:1527628044306};\\\", \\\"{x:1613,y:865,t:1527628044507};\\\", \\\"{x:1613,y:864,t:1527628044538};\\\", \\\"{x:1613,y:863,t:1527628044562};\\\", \\\"{x:1613,y:862,t:1527628044578};\\\", \\\"{x:1613,y:861,t:1527628044587};\\\", \\\"{x:1613,y:860,t:1527628044626};\\\", \\\"{x:1612,y:859,t:1527628044682};\\\", \\\"{x:1612,y:858,t:1527628044701};\\\", \\\"{x:1612,y:857,t:1527628044717};\\\", \\\"{x:1611,y:857,t:1527628044734};\\\", \\\"{x:1611,y:856,t:1527628044762};\\\", \\\"{x:1610,y:856,t:1527628044778};\\\", \\\"{x:1609,y:855,t:1527628044818};\\\", \\\"{x:1608,y:855,t:1527628044834};\\\", \\\"{x:1607,y:855,t:1527628044858};\\\", \\\"{x:1606,y:855,t:1527628044874};\\\", \\\"{x:1605,y:855,t:1527628044884};\\\", \\\"{x:1604,y:855,t:1527628044900};\\\", \\\"{x:1600,y:855,t:1527628044918};\\\", \\\"{x:1597,y:855,t:1527628044934};\\\", \\\"{x:1594,y:855,t:1527628044951};\\\", \\\"{x:1592,y:855,t:1527628044967};\\\", \\\"{x:1590,y:855,t:1527628044984};\\\", \\\"{x:1589,y:855,t:1527628045001};\\\", \\\"{x:1587,y:854,t:1527628045018};\\\", \\\"{x:1586,y:854,t:1527628045042};\\\", \\\"{x:1585,y:854,t:1527628045058};\\\", \\\"{x:1584,y:854,t:1527628045067};\\\", \\\"{x:1581,y:855,t:1527628045084};\\\", \\\"{x:1578,y:856,t:1527628045101};\\\", \\\"{x:1574,y:857,t:1527628045117};\\\", \\\"{x:1572,y:858,t:1527628045133};\\\", \\\"{x:1570,y:858,t:1527628045151};\\\", \\\"{x:1568,y:859,t:1527628045167};\\\", \\\"{x:1566,y:859,t:1527628045184};\\\", \\\"{x:1564,y:860,t:1527628045201};\\\", \\\"{x:1558,y:861,t:1527628045218};\\\", \\\"{x:1553,y:863,t:1527628045234};\\\", \\\"{x:1548,y:866,t:1527628045250};\\\", \\\"{x:1540,y:869,t:1527628045267};\\\", \\\"{x:1532,y:873,t:1527628045284};\\\", \\\"{x:1524,y:876,t:1527628045301};\\\", \\\"{x:1514,y:878,t:1527628045318};\\\", \\\"{x:1509,y:880,t:1527628045334};\\\", \\\"{x:1500,y:882,t:1527628045351};\\\", \\\"{x:1495,y:883,t:1527628045368};\\\", \\\"{x:1488,y:883,t:1527628045384};\\\", \\\"{x:1480,y:884,t:1527628045401};\\\", \\\"{x:1469,y:886,t:1527628045418};\\\", \\\"{x:1466,y:886,t:1527628045434};\\\", \\\"{x:1465,y:886,t:1527628045450};\\\", \\\"{x:1465,y:887,t:1527628045468};\\\", \\\"{x:1463,y:887,t:1527628045484};\\\", \\\"{x:1459,y:888,t:1527628045500};\\\", \\\"{x:1456,y:890,t:1527628045518};\\\", \\\"{x:1452,y:890,t:1527628045535};\\\", \\\"{x:1448,y:891,t:1527628045551};\\\", \\\"{x:1443,y:892,t:1527628045567};\\\", \\\"{x:1439,y:893,t:1527628045584};\\\", \\\"{x:1433,y:894,t:1527628045601};\\\", \\\"{x:1426,y:895,t:1527628045618};\\\", \\\"{x:1420,y:895,t:1527628045634};\\\", \\\"{x:1416,y:896,t:1527628045652};\\\", \\\"{x:1412,y:897,t:1527628045668};\\\", \\\"{x:1410,y:898,t:1527628045685};\\\", \\\"{x:1408,y:898,t:1527628045700};\\\", \\\"{x:1406,y:899,t:1527628045718};\\\", \\\"{x:1402,y:900,t:1527628045735};\\\", \\\"{x:1401,y:900,t:1527628045751};\\\", \\\"{x:1398,y:901,t:1527628045768};\\\", \\\"{x:1397,y:901,t:1527628045785};\\\", \\\"{x:1396,y:902,t:1527628045800};\\\", \\\"{x:1394,y:902,t:1527628045817};\\\", \\\"{x:1394,y:903,t:1527628045834};\\\", \\\"{x:1393,y:903,t:1527628045851};\\\", \\\"{x:1393,y:904,t:1527628045868};\\\", \\\"{x:1393,y:906,t:1527628045890};\\\", \\\"{x:1394,y:912,t:1527628045901};\\\", \\\"{x:1421,y:926,t:1527628045918};\\\", \\\"{x:1471,y:949,t:1527628045934};\\\", \\\"{x:1531,y:975,t:1527628045951};\\\", \\\"{x:1581,y:996,t:1527628045968};\\\", \\\"{x:1597,y:1001,t:1527628045985};\\\", \\\"{x:1598,y:1001,t:1527628046001};\\\", \\\"{x:1600,y:1001,t:1527628046066};\\\", \\\"{x:1601,y:1000,t:1527628046090};\\\", \\\"{x:1603,y:1000,t:1527628046106};\\\", \\\"{x:1605,y:998,t:1527628046122};\\\", \\\"{x:1606,y:997,t:1527628046154};\\\", \\\"{x:1607,y:997,t:1527628046177};\\\", \\\"{x:1607,y:995,t:1527628046217};\\\", \\\"{x:1606,y:995,t:1527628046241};\\\", \\\"{x:1605,y:995,t:1527628046251};\\\", \\\"{x:1604,y:995,t:1527628046267};\\\", \\\"{x:1602,y:995,t:1527628046284};\\\", \\\"{x:1601,y:995,t:1527628046313};\\\", \\\"{x:1600,y:995,t:1527628046321};\\\", \\\"{x:1599,y:995,t:1527628046334};\\\", \\\"{x:1598,y:995,t:1527628046351};\\\", \\\"{x:1597,y:995,t:1527628046367};\\\", \\\"{x:1597,y:994,t:1527628046419};\\\", \\\"{x:1597,y:992,t:1527628046434};\\\", \\\"{x:1597,y:988,t:1527628046452};\\\", \\\"{x:1599,y:984,t:1527628046468};\\\", \\\"{x:1603,y:978,t:1527628046485};\\\", \\\"{x:1609,y:970,t:1527628046502};\\\", \\\"{x:1614,y:962,t:1527628046518};\\\", \\\"{x:1617,y:951,t:1527628046535};\\\", \\\"{x:1618,y:946,t:1527628046552};\\\", \\\"{x:1618,y:945,t:1527628046567};\\\", \\\"{x:1619,y:943,t:1527628046585};\\\", \\\"{x:1619,y:942,t:1527628046602};\\\", \\\"{x:1619,y:944,t:1527628046883};\\\", \\\"{x:1619,y:945,t:1527628046906};\\\", \\\"{x:1619,y:947,t:1527628047019};\\\", \\\"{x:1619,y:948,t:1527628047050};\\\", \\\"{x:1619,y:950,t:1527628047066};\\\", \\\"{x:1618,y:951,t:1527628047074};\\\", \\\"{x:1617,y:952,t:1527628047085};\\\", \\\"{x:1617,y:954,t:1527628047102};\\\", \\\"{x:1617,y:955,t:1527628047119};\\\", \\\"{x:1616,y:958,t:1527628047134};\\\", \\\"{x:1615,y:961,t:1527628047152};\\\", \\\"{x:1614,y:963,t:1527628047168};\\\", \\\"{x:1613,y:965,t:1527628047185};\\\", \\\"{x:1613,y:966,t:1527628047201};\\\", \\\"{x:1613,y:965,t:1527628047578};\\\", \\\"{x:1613,y:964,t:1527628047586};\\\", \\\"{x:1613,y:963,t:1527628047602};\\\", \\\"{x:1613,y:962,t:1527628047619};\\\", \\\"{x:1613,y:961,t:1527628047636};\\\", \\\"{x:1614,y:961,t:1527628047659};\\\", \\\"{x:1614,y:959,t:1527628047669};\\\", \\\"{x:1614,y:958,t:1527628047686};\\\", \\\"{x:1614,y:956,t:1527628047701};\\\", \\\"{x:1615,y:954,t:1527628047719};\\\", \\\"{x:1615,y:953,t:1527628047736};\\\", \\\"{x:1615,y:951,t:1527628047752};\\\", \\\"{x:1615,y:950,t:1527628047769};\\\", \\\"{x:1616,y:949,t:1527628047786};\\\", \\\"{x:1616,y:947,t:1527628047834};\\\", \\\"{x:1616,y:946,t:1527628047930};\\\", \\\"{x:1616,y:944,t:1527628047986};\\\", \\\"{x:1616,y:943,t:1527628048010};\\\", \\\"{x:1616,y:941,t:1527628048026};\\\", \\\"{x:1616,y:940,t:1527628048042};\\\", \\\"{x:1616,y:938,t:1527628048058};\\\", \\\"{x:1616,y:936,t:1527628048068};\\\", \\\"{x:1616,y:933,t:1527628048086};\\\", \\\"{x:1616,y:929,t:1527628048101};\\\", \\\"{x:1616,y:924,t:1527628048119};\\\", \\\"{x:1616,y:920,t:1527628048136};\\\", \\\"{x:1616,y:916,t:1527628048152};\\\", \\\"{x:1616,y:914,t:1527628048169};\\\", \\\"{x:1616,y:912,t:1527628048185};\\\", \\\"{x:1616,y:911,t:1527628048201};\\\", \\\"{x:1616,y:910,t:1527628048218};\\\", \\\"{x:1616,y:909,t:1527628048235};\\\", \\\"{x:1616,y:908,t:1527628048273};\\\", \\\"{x:1616,y:906,t:1527628048289};\\\", \\\"{x:1616,y:904,t:1527628048305};\\\", \\\"{x:1616,y:903,t:1527628048318};\\\", \\\"{x:1616,y:900,t:1527628048335};\\\", \\\"{x:1616,y:897,t:1527628048352};\\\", \\\"{x:1616,y:896,t:1527628048369};\\\", \\\"{x:1616,y:893,t:1527628048386};\\\", \\\"{x:1616,y:892,t:1527628048410};\\\", \\\"{x:1616,y:891,t:1527628048418};\\\", \\\"{x:1616,y:890,t:1527628048435};\\\", \\\"{x:1616,y:889,t:1527628048453};\\\", \\\"{x:1616,y:887,t:1527628048468};\\\", \\\"{x:1616,y:886,t:1527628048486};\\\", \\\"{x:1616,y:884,t:1527628048502};\\\", \\\"{x:1615,y:883,t:1527628048519};\\\", \\\"{x:1615,y:881,t:1527628048535};\\\", \\\"{x:1615,y:879,t:1527628048552};\\\", \\\"{x:1615,y:877,t:1527628048569};\\\", \\\"{x:1615,y:875,t:1527628048586};\\\", \\\"{x:1615,y:873,t:1527628048602};\\\", \\\"{x:1614,y:871,t:1527628048619};\\\", \\\"{x:1614,y:869,t:1527628048635};\\\", \\\"{x:1614,y:866,t:1527628048653};\\\", \\\"{x:1614,y:865,t:1527628048669};\\\", \\\"{x:1614,y:862,t:1527628048686};\\\", \\\"{x:1614,y:860,t:1527628048703};\\\", \\\"{x:1614,y:856,t:1527628048719};\\\", \\\"{x:1614,y:853,t:1527628048736};\\\", \\\"{x:1613,y:848,t:1527628048753};\\\", \\\"{x:1613,y:846,t:1527628048768};\\\", \\\"{x:1613,y:842,t:1527628048786};\\\", \\\"{x:1613,y:840,t:1527628048802};\\\", \\\"{x:1613,y:838,t:1527628048819};\\\", \\\"{x:1613,y:836,t:1527628048836};\\\", \\\"{x:1613,y:833,t:1527628048853};\\\", \\\"{x:1613,y:832,t:1527628048868};\\\", \\\"{x:1613,y:828,t:1527628048886};\\\", \\\"{x:1613,y:825,t:1527628048903};\\\", \\\"{x:1613,y:823,t:1527628048919};\\\", \\\"{x:1613,y:822,t:1527628048935};\\\", \\\"{x:1613,y:820,t:1527628048953};\\\", \\\"{x:1613,y:817,t:1527628048969};\\\", \\\"{x:1613,y:813,t:1527628048986};\\\", \\\"{x:1613,y:808,t:1527628049002};\\\", \\\"{x:1613,y:805,t:1527628049018};\\\", \\\"{x:1613,y:801,t:1527628049035};\\\", \\\"{x:1613,y:798,t:1527628049052};\\\", \\\"{x:1613,y:792,t:1527628049068};\\\", \\\"{x:1613,y:789,t:1527628049086};\\\", \\\"{x:1613,y:785,t:1527628049102};\\\", \\\"{x:1614,y:782,t:1527628049120};\\\", \\\"{x:1614,y:778,t:1527628049135};\\\", \\\"{x:1616,y:774,t:1527628049153};\\\", \\\"{x:1617,y:765,t:1527628049170};\\\", \\\"{x:1617,y:761,t:1527628049186};\\\", \\\"{x:1618,y:755,t:1527628049203};\\\", \\\"{x:1619,y:749,t:1527628049219};\\\", \\\"{x:1620,y:743,t:1527628049235};\\\", \\\"{x:1621,y:738,t:1527628049252};\\\", \\\"{x:1622,y:729,t:1527628049269};\\\", \\\"{x:1623,y:721,t:1527628049285};\\\", \\\"{x:1625,y:713,t:1527628049302};\\\", \\\"{x:1625,y:706,t:1527628049319};\\\", \\\"{x:1625,y:699,t:1527628049335};\\\", \\\"{x:1626,y:692,t:1527628049352};\\\", \\\"{x:1627,y:682,t:1527628049369};\\\", \\\"{x:1627,y:677,t:1527628049385};\\\", \\\"{x:1629,y:670,t:1527628049402};\\\", \\\"{x:1629,y:663,t:1527628049420};\\\", \\\"{x:1629,y:658,t:1527628049436};\\\", \\\"{x:1629,y:653,t:1527628049452};\\\", \\\"{x:1629,y:648,t:1527628049470};\\\", \\\"{x:1629,y:643,t:1527628049485};\\\", \\\"{x:1629,y:637,t:1527628049502};\\\", \\\"{x:1629,y:631,t:1527628049520};\\\", \\\"{x:1629,y:628,t:1527628049535};\\\", \\\"{x:1629,y:624,t:1527628049553};\\\", \\\"{x:1629,y:617,t:1527628049569};\\\", \\\"{x:1629,y:613,t:1527628049586};\\\", \\\"{x:1628,y:607,t:1527628049603};\\\", \\\"{x:1627,y:602,t:1527628049620};\\\", \\\"{x:1626,y:595,t:1527628049636};\\\", \\\"{x:1625,y:591,t:1527628049652};\\\", \\\"{x:1625,y:586,t:1527628049670};\\\", \\\"{x:1624,y:583,t:1527628049686};\\\", \\\"{x:1622,y:577,t:1527628049703};\\\", \\\"{x:1620,y:572,t:1527628049720};\\\", \\\"{x:1620,y:569,t:1527628049736};\\\", \\\"{x:1619,y:565,t:1527628049756};\\\", \\\"{x:1618,y:562,t:1527628049769};\\\", \\\"{x:1617,y:560,t:1527628049786};\\\", \\\"{x:1616,y:558,t:1527628049802};\\\", \\\"{x:1616,y:556,t:1527628049820};\\\", \\\"{x:1616,y:555,t:1527628049841};\\\", \\\"{x:1612,y:554,t:1527628058702};\\\", \\\"{x:1598,y:544,t:1527628058711};\\\", \\\"{x:1551,y:512,t:1527628058728};\\\", \\\"{x:1491,y:465,t:1527628058745};\\\", \\\"{x:1447,y:411,t:1527628058763};\\\", \\\"{x:1427,y:371,t:1527628058778};\\\", \\\"{x:1414,y:334,t:1527628058795};\\\", \\\"{x:1412,y:317,t:1527628058812};\\\", \\\"{x:1411,y:316,t:1527628058862};\\\", \\\"{x:1407,y:316,t:1527628058878};\\\", \\\"{x:1403,y:319,t:1527628058896};\\\", \\\"{x:1401,y:321,t:1527628058912};\\\", \\\"{x:1401,y:323,t:1527628058928};\\\", \\\"{x:1401,y:327,t:1527628058945};\\\", \\\"{x:1401,y:332,t:1527628058961};\\\", \\\"{x:1401,y:340,t:1527628058978};\\\", \\\"{x:1399,y:346,t:1527628058995};\\\", \\\"{x:1398,y:351,t:1527628059011};\\\", \\\"{x:1397,y:355,t:1527628059028};\\\", \\\"{x:1394,y:361,t:1527628059045};\\\", \\\"{x:1389,y:373,t:1527628059062};\\\", \\\"{x:1386,y:381,t:1527628059078};\\\", \\\"{x:1386,y:387,t:1527628059095};\\\", \\\"{x:1386,y:400,t:1527628059111};\\\", \\\"{x:1386,y:420,t:1527628059128};\\\", \\\"{x:1386,y:433,t:1527628059145};\\\", \\\"{x:1386,y:436,t:1527628059162};\\\", \\\"{x:1386,y:437,t:1527628059178};\\\", \\\"{x:1386,y:438,t:1527628061414};\\\", \\\"{x:1386,y:445,t:1527628061429};\\\", \\\"{x:1400,y:472,t:1527628061446};\\\", \\\"{x:1414,y:500,t:1527628061463};\\\", \\\"{x:1432,y:544,t:1527628061479};\\\", \\\"{x:1457,y:607,t:1527628061496};\\\", \\\"{x:1480,y:662,t:1527628061513};\\\", \\\"{x:1500,y:707,t:1527628061529};\\\", \\\"{x:1510,y:736,t:1527628061546};\\\", \\\"{x:1518,y:763,t:1527628061563};\\\", \\\"{x:1524,y:785,t:1527628061580};\\\", \\\"{x:1528,y:799,t:1527628061597};\\\", \\\"{x:1531,y:815,t:1527628061614};\\\", \\\"{x:1531,y:826,t:1527628061630};\\\", \\\"{x:1531,y:835,t:1527628061646};\\\", \\\"{x:1531,y:841,t:1527628061664};\\\", \\\"{x:1531,y:846,t:1527628061679};\\\", \\\"{x:1531,y:848,t:1527628061696};\\\", \\\"{x:1528,y:855,t:1527628061713};\\\", \\\"{x:1523,y:866,t:1527628061730};\\\", \\\"{x:1514,y:888,t:1527628061746};\\\", \\\"{x:1504,y:912,t:1527628061763};\\\", \\\"{x:1494,y:934,t:1527628061779};\\\", \\\"{x:1482,y:960,t:1527628061796};\\\", \\\"{x:1466,y:992,t:1527628061813};\\\", \\\"{x:1456,y:1009,t:1527628061829};\\\", \\\"{x:1450,y:1020,t:1527628061846};\\\", \\\"{x:1447,y:1024,t:1527628061863};\\\", \\\"{x:1445,y:1026,t:1527628061879};\\\", \\\"{x:1444,y:1026,t:1527628061896};\\\", \\\"{x:1443,y:1026,t:1527628062013};\\\", \\\"{x:1445,y:1016,t:1527628062030};\\\", \\\"{x:1452,y:1005,t:1527628062046};\\\", \\\"{x:1457,y:999,t:1527628062063};\\\", \\\"{x:1461,y:995,t:1527628062079};\\\", \\\"{x:1466,y:991,t:1527628062096};\\\", \\\"{x:1474,y:985,t:1527628062113};\\\", \\\"{x:1478,y:980,t:1527628062131};\\\", \\\"{x:1480,y:976,t:1527628062146};\\\", \\\"{x:1483,y:971,t:1527628062163};\\\", \\\"{x:1485,y:967,t:1527628062181};\\\", \\\"{x:1486,y:966,t:1527628062196};\\\", \\\"{x:1488,y:964,t:1527628062214};\\\", \\\"{x:1489,y:963,t:1527628062230};\\\", \\\"{x:1488,y:963,t:1527628062294};\\\", \\\"{x:1485,y:963,t:1527628062302};\\\", \\\"{x:1484,y:963,t:1527628062318};\\\", \\\"{x:1483,y:963,t:1527628063062};\\\", \\\"{x:1482,y:963,t:1527628063119};\\\", \\\"{x:1481,y:963,t:1527628063599};\\\", \\\"{x:1480,y:963,t:1527628063733};\\\", \\\"{x:1479,y:963,t:1527628063757};\\\", \\\"{x:1478,y:963,t:1527628063781};\\\", \\\"{x:1477,y:963,t:1527628063797};\\\", \\\"{x:1476,y:963,t:1527628063821};\\\", \\\"{x:1475,y:963,t:1527628063918};\\\", \\\"{x:1474,y:963,t:1527628063982};\\\", \\\"{x:1473,y:963,t:1527628063998};\\\", \\\"{x:1471,y:963,t:1527628064070};\\\", \\\"{x:1470,y:963,t:1527628064086};\\\", \\\"{x:1469,y:963,t:1527628064125};\\\", \\\"{x:1468,y:962,t:1527628064158};\\\", \\\"{x:1467,y:962,t:1527628064165};\\\", \\\"{x:1466,y:962,t:1527628064189};\\\", \\\"{x:1465,y:962,t:1527628064197};\\\", \\\"{x:1464,y:962,t:1527628064214};\\\", \\\"{x:1462,y:962,t:1527628064230};\\\", \\\"{x:1460,y:962,t:1527628064247};\\\", \\\"{x:1459,y:961,t:1527628064263};\\\", \\\"{x:1458,y:961,t:1527628064281};\\\", \\\"{x:1457,y:960,t:1527628064296};\\\", \\\"{x:1453,y:960,t:1527628064314};\\\", \\\"{x:1449,y:959,t:1527628064331};\\\", \\\"{x:1444,y:958,t:1527628064347};\\\", \\\"{x:1439,y:955,t:1527628064363};\\\", \\\"{x:1436,y:955,t:1527628064380};\\\", \\\"{x:1433,y:955,t:1527628064397};\\\", \\\"{x:1430,y:955,t:1527628064414};\\\", \\\"{x:1425,y:952,t:1527628064431};\\\", \\\"{x:1423,y:952,t:1527628064598};\\\", \\\"{x:1422,y:952,t:1527628064645};\\\", \\\"{x:1420,y:953,t:1527628064670};\\\", \\\"{x:1419,y:954,t:1527628064682};\\\", \\\"{x:1415,y:957,t:1527628064698};\\\", \\\"{x:1412,y:960,t:1527628064714};\\\", \\\"{x:1410,y:962,t:1527628064731};\\\", \\\"{x:1408,y:963,t:1527628064748};\\\", \\\"{x:1408,y:964,t:1527628064764};\\\", \\\"{x:1407,y:965,t:1527628064781};\\\", \\\"{x:1406,y:966,t:1527628064813};\\\", \\\"{x:1406,y:967,t:1527628064957};\\\", \\\"{x:1406,y:968,t:1527628065429};\\\", \\\"{x:1407,y:968,t:1527628065517};\\\", \\\"{x:1409,y:968,t:1527628065531};\\\", \\\"{x:1411,y:968,t:1527628065548};\\\", \\\"{x:1414,y:968,t:1527628065565};\\\", \\\"{x:1415,y:968,t:1527628065581};\\\", \\\"{x:1415,y:967,t:1527628067438};\\\", \\\"{x:1413,y:967,t:1527628069062};\\\", \\\"{x:1412,y:967,t:1527628070022};\\\", \\\"{x:1410,y:967,t:1527628070037};\\\", \\\"{x:1409,y:967,t:1527628070053};\\\", \\\"{x:1407,y:967,t:1527628070069};\\\", \\\"{x:1406,y:967,t:1527628070085};\\\", \\\"{x:1405,y:967,t:1527628070100};\\\", \\\"{x:1404,y:967,t:1527628070117};\\\", \\\"{x:1403,y:967,t:1527628070326};\\\", \\\"{x:1402,y:967,t:1527628070357};\\\", \\\"{x:1401,y:967,t:1527628070367};\\\", \\\"{x:1399,y:967,t:1527628070384};\\\", \\\"{x:1393,y:967,t:1527628070401};\\\", \\\"{x:1388,y:967,t:1527628070418};\\\", \\\"{x:1377,y:967,t:1527628070433};\\\", \\\"{x:1365,y:967,t:1527628070451};\\\", \\\"{x:1354,y:967,t:1527628070468};\\\", \\\"{x:1347,y:967,t:1527628070483};\\\", \\\"{x:1342,y:967,t:1527628070501};\\\", \\\"{x:1339,y:967,t:1527628070517};\\\", \\\"{x:1340,y:967,t:1527628070813};\\\", \\\"{x:1342,y:968,t:1527628070845};\\\", \\\"{x:1343,y:968,t:1527628071014};\\\", \\\"{x:1341,y:968,t:1527628071220};\\\", \\\"{x:1332,y:964,t:1527628071234};\\\", \\\"{x:1308,y:955,t:1527628071250};\\\", \\\"{x:1258,y:935,t:1527628071267};\\\", \\\"{x:1176,y:902,t:1527628071284};\\\", \\\"{x:1071,y:855,t:1527628071300};\\\", \\\"{x:907,y:784,t:1527628071317};\\\", \\\"{x:800,y:743,t:1527628071334};\\\", \\\"{x:710,y:708,t:1527628071351};\\\", \\\"{x:624,y:673,t:1527628071367};\\\", \\\"{x:569,y:657,t:1527628071384};\\\", \\\"{x:521,y:634,t:1527628071402};\\\", \\\"{x:496,y:615,t:1527628071417};\\\", \\\"{x:484,y:596,t:1527628071434};\\\", \\\"{x:463,y:526,t:1527628071463};\\\", \\\"{x:455,y:470,t:1527628071480};\\\", \\\"{x:449,y:412,t:1527628071496};\\\", \\\"{x:449,y:385,t:1527628071512};\\\", \\\"{x:453,y:372,t:1527628071528};\\\", \\\"{x:458,y:369,t:1527628071546};\\\", \\\"{x:468,y:370,t:1527628071562};\\\", \\\"{x:486,y:377,t:1527628071578};\\\", \\\"{x:510,y:389,t:1527628071596};\\\", \\\"{x:531,y:401,t:1527628071612};\\\", \\\"{x:539,y:417,t:1527628071628};\\\", \\\"{x:544,y:432,t:1527628071646};\\\", \\\"{x:548,y:440,t:1527628071662};\\\", \\\"{x:555,y:450,t:1527628071680};\\\", \\\"{x:564,y:460,t:1527628071696};\\\", \\\"{x:572,y:470,t:1527628071713};\\\", \\\"{x:584,y:485,t:1527628071730};\\\", \\\"{x:596,y:500,t:1527628071746};\\\", \\\"{x:609,y:520,t:1527628071763};\\\", \\\"{x:628,y:542,t:1527628071780};\\\", \\\"{x:646,y:559,t:1527628071796};\\\", \\\"{x:670,y:574,t:1527628071812};\\\", \\\"{x:677,y:576,t:1527628071829};\\\", \\\"{x:679,y:576,t:1527628071846};\\\", \\\"{x:676,y:578,t:1527628071966};\\\", \\\"{x:672,y:579,t:1527628071981};\\\", \\\"{x:657,y:589,t:1527628071998};\\\", \\\"{x:638,y:601,t:1527628072014};\\\", \\\"{x:615,y:610,t:1527628072030};\\\", \\\"{x:586,y:626,t:1527628072046};\\\", \\\"{x:564,y:637,t:1527628072063};\\\", \\\"{x:542,y:641,t:1527628072080};\\\", \\\"{x:525,y:643,t:1527628072095};\\\", \\\"{x:520,y:644,t:1527628072113};\\\", \\\"{x:522,y:639,t:1527628072189};\\\", \\\"{x:529,y:631,t:1527628072196};\\\", \\\"{x:544,y:620,t:1527628072213};\\\", \\\"{x:561,y:609,t:1527628072231};\\\", \\\"{x:574,y:601,t:1527628072247};\\\", \\\"{x:587,y:593,t:1527628072263};\\\", \\\"{x:591,y:592,t:1527628072280};\\\", \\\"{x:595,y:590,t:1527628072296};\\\", \\\"{x:597,y:589,t:1527628072313};\\\", \\\"{x:598,y:589,t:1527628072330};\\\", \\\"{x:599,y:589,t:1527628072347};\\\", \\\"{x:600,y:588,t:1527628072404};\\\", \\\"{x:601,y:588,t:1527628072436};\\\", \\\"{x:602,y:588,t:1527628072469};\\\", \\\"{x:603,y:588,t:1527628072480};\\\", \\\"{x:604,y:588,t:1527628072497};\\\", \\\"{x:605,y:588,t:1527628072533};\\\", \\\"{x:606,y:588,t:1527628072556};\\\", \\\"{x:606,y:588,t:1527628072625};\\\", \\\"{x:607,y:588,t:1527628072692};\\\", \\\"{x:610,y:590,t:1527628072709};\\\", \\\"{x:614,y:591,t:1527628072716};\\\", \\\"{x:622,y:596,t:1527628072730};\\\", \\\"{x:645,y:601,t:1527628072747};\\\", \\\"{x:694,y:609,t:1527628072764};\\\", \\\"{x:788,y:635,t:1527628072781};\\\", \\\"{x:970,y:683,t:1527628072797};\\\", \\\"{x:1111,y:720,t:1527628072815};\\\", \\\"{x:1271,y:764,t:1527628072830};\\\", \\\"{x:1425,y:804,t:1527628072847};\\\", \\\"{x:1566,y:843,t:1527628072864};\\\", \\\"{x:1677,y:873,t:1527628072880};\\\", \\\"{x:1746,y:893,t:1527628072898};\\\", \\\"{x:1797,y:917,t:1527628072915};\\\", \\\"{x:1832,y:937,t:1527628072931};\\\", \\\"{x:1848,y:948,t:1527628072948};\\\", \\\"{x:1859,y:957,t:1527628072965};\\\", \\\"{x:1863,y:963,t:1527628072981};\\\", \\\"{x:1863,y:970,t:1527628072998};\\\", \\\"{x:1855,y:980,t:1527628073015};\\\", \\\"{x:1836,y:984,t:1527628073030};\\\", \\\"{x:1807,y:989,t:1527628073047};\\\", \\\"{x:1778,y:991,t:1527628073064};\\\", \\\"{x:1750,y:991,t:1527628073081};\\\", \\\"{x:1726,y:986,t:1527628073097};\\\", \\\"{x:1699,y:976,t:1527628073114};\\\", \\\"{x:1678,y:967,t:1527628073131};\\\", \\\"{x:1658,y:956,t:1527628073147};\\\", \\\"{x:1640,y:945,t:1527628073164};\\\", \\\"{x:1617,y:934,t:1527628073182};\\\", \\\"{x:1606,y:927,t:1527628073198};\\\", \\\"{x:1588,y:916,t:1527628073215};\\\", \\\"{x:1570,y:909,t:1527628073230};\\\", \\\"{x:1559,y:903,t:1527628073247};\\\", \\\"{x:1552,y:896,t:1527628073265};\\\", \\\"{x:1547,y:888,t:1527628073281};\\\", \\\"{x:1544,y:881,t:1527628073296};\\\", \\\"{x:1543,y:875,t:1527628073314};\\\", \\\"{x:1543,y:869,t:1527628073331};\\\", \\\"{x:1543,y:861,t:1527628073347};\\\", \\\"{x:1543,y:849,t:1527628073364};\\\", \\\"{x:1543,y:823,t:1527628073381};\\\", \\\"{x:1543,y:809,t:1527628073397};\\\", \\\"{x:1543,y:808,t:1527628073414};\\\", \\\"{x:1543,y:809,t:1527628075501};\\\", \\\"{x:1543,y:818,t:1527628075516};\\\", \\\"{x:1542,y:841,t:1527628075533};\\\", \\\"{x:1542,y:875,t:1527628075550};\\\", \\\"{x:1545,y:884,t:1527628075565};\\\", \\\"{x:1545,y:885,t:1527628075583};\\\", \\\"{x:1539,y:885,t:1527628075600};\\\", \\\"{x:1534,y:885,t:1527628075617};\\\", \\\"{x:1530,y:880,t:1527628075632};\\\", \\\"{x:1527,y:868,t:1527628075650};\\\", \\\"{x:1519,y:847,t:1527628075667};\\\", \\\"{x:1513,y:832,t:1527628075683};\\\", \\\"{x:1512,y:827,t:1527628075699};\\\", \\\"{x:1508,y:818,t:1527628075717};\\\", \\\"{x:1502,y:804,t:1527628075732};\\\", \\\"{x:1496,y:783,t:1527628075749};\\\", \\\"{x:1492,y:772,t:1527628075767};\\\", \\\"{x:1488,y:758,t:1527628075783};\\\", \\\"{x:1483,y:744,t:1527628075800};\\\", \\\"{x:1479,y:735,t:1527628075817};\\\", \\\"{x:1477,y:733,t:1527628075833};\\\", \\\"{x:1476,y:733,t:1527628075909};\\\", \\\"{x:1476,y:736,t:1527628075925};\\\", \\\"{x:1476,y:739,t:1527628075934};\\\", \\\"{x:1476,y:746,t:1527628075950};\\\", \\\"{x:1475,y:757,t:1527628075967};\\\", \\\"{x:1475,y:768,t:1527628075983};\\\", \\\"{x:1475,y:779,t:1527628076000};\\\", \\\"{x:1475,y:785,t:1527628076017};\\\", \\\"{x:1475,y:797,t:1527628076034};\\\", \\\"{x:1476,y:806,t:1527628076049};\\\", \\\"{x:1479,y:814,t:1527628076067};\\\", \\\"{x:1482,y:822,t:1527628076084};\\\", \\\"{x:1482,y:824,t:1527628076100};\\\", \\\"{x:1483,y:825,t:1527628076117};\\\", \\\"{x:1484,y:825,t:1527628076133};\\\", \\\"{x:1484,y:832,t:1527628076150};\\\", \\\"{x:1484,y:836,t:1527628076166};\\\", \\\"{x:1483,y:836,t:1527628076638};\\\", \\\"{x:1482,y:834,t:1527628076651};\\\", \\\"{x:1480,y:833,t:1527628076666};\\\", \\\"{x:1478,y:832,t:1527628076925};\\\", \\\"{x:1478,y:831,t:1527628076934};\\\", \\\"{x:1477,y:830,t:1527628076958};\\\", \\\"{x:1476,y:829,t:1527628076967};\\\", \\\"{x:1473,y:826,t:1527628076985};\\\", \\\"{x:1470,y:823,t:1527628077000};\\\", \\\"{x:1469,y:820,t:1527628077018};\\\", \\\"{x:1466,y:818,t:1527628077034};\\\", \\\"{x:1465,y:817,t:1527628077051};\\\", \\\"{x:1463,y:813,t:1527628077068};\\\", \\\"{x:1462,y:811,t:1527628077084};\\\", \\\"{x:1459,y:808,t:1527628077101};\\\", \\\"{x:1455,y:804,t:1527628077117};\\\", \\\"{x:1455,y:801,t:1527628077134};\\\", \\\"{x:1454,y:799,t:1527628077151};\\\", \\\"{x:1452,y:794,t:1527628077168};\\\", \\\"{x:1449,y:787,t:1527628077183};\\\", \\\"{x:1446,y:778,t:1527628077200};\\\", \\\"{x:1443,y:771,t:1527628077218};\\\", \\\"{x:1443,y:769,t:1527628077233};\\\", \\\"{x:1443,y:767,t:1527628077251};\\\", \\\"{x:1443,y:763,t:1527628077268};\\\", \\\"{x:1443,y:761,t:1527628077284};\\\", \\\"{x:1443,y:760,t:1527628077301};\\\", \\\"{x:1443,y:758,t:1527628077317};\\\", \\\"{x:1444,y:758,t:1527628077334};\\\", \\\"{x:1445,y:758,t:1527628077414};\\\", \\\"{x:1446,y:758,t:1527628077422};\\\", \\\"{x:1447,y:758,t:1527628077437};\\\", \\\"{x:1448,y:758,t:1527628077451};\\\", \\\"{x:1450,y:758,t:1527628077468};\\\", \\\"{x:1452,y:762,t:1527628077485};\\\", \\\"{x:1453,y:766,t:1527628077500};\\\", \\\"{x:1453,y:768,t:1527628077518};\\\", \\\"{x:1452,y:768,t:1527628077670};\\\", \\\"{x:1451,y:767,t:1527628077685};\\\", \\\"{x:1448,y:761,t:1527628077701};\\\", \\\"{x:1447,y:758,t:1527628077718};\\\", \\\"{x:1446,y:758,t:1527628077735};\\\", \\\"{x:1446,y:757,t:1527628077751};\\\", \\\"{x:1446,y:756,t:1527628077789};\\\", \\\"{x:1446,y:757,t:1527628078117};\\\", \\\"{x:1446,y:761,t:1527628078135};\\\", \\\"{x:1446,y:762,t:1527628078152};\\\", \\\"{x:1446,y:764,t:1527628078168};\\\", \\\"{x:1445,y:764,t:1527628078334};\\\", \\\"{x:1445,y:763,t:1527628078358};\\\", \\\"{x:1445,y:762,t:1527628078369};\\\", \\\"{x:1445,y:760,t:1527628078384};\\\", \\\"{x:1445,y:759,t:1527628078402};\\\", \\\"{x:1444,y:760,t:1527628079029};\\\", \\\"{x:1443,y:761,t:1527628079044};\\\", \\\"{x:1442,y:761,t:1527628079052};\\\", \\\"{x:1441,y:762,t:1527628079068};\\\", \\\"{x:1440,y:763,t:1527628079085};\\\", \\\"{x:1439,y:763,t:1527628079101};\\\", \\\"{x:1437,y:763,t:1527628079118};\\\", \\\"{x:1436,y:763,t:1527628079221};\\\", \\\"{x:1435,y:763,t:1527628079236};\\\", \\\"{x:1434,y:763,t:1527628079252};\\\", \\\"{x:1433,y:763,t:1527628079269};\\\", \\\"{x:1432,y:763,t:1527628079301};\\\", \\\"{x:1431,y:763,t:1527628079382};\\\", \\\"{x:1430,y:763,t:1527628079389};\\\", \\\"{x:1428,y:763,t:1527628079405};\\\", \\\"{x:1427,y:763,t:1527628079419};\\\", \\\"{x:1421,y:763,t:1527628079436};\\\", \\\"{x:1416,y:763,t:1527628079453};\\\", \\\"{x:1409,y:762,t:1527628079470};\\\", \\\"{x:1401,y:759,t:1527628079486};\\\", \\\"{x:1399,y:757,t:1527628079502};\\\", \\\"{x:1398,y:757,t:1527628079519};\\\", \\\"{x:1400,y:757,t:1527628079693};\\\", \\\"{x:1401,y:758,t:1527628079703};\\\", \\\"{x:1403,y:759,t:1527628079719};\\\", \\\"{x:1405,y:760,t:1527628079736};\\\", \\\"{x:1411,y:765,t:1527628079752};\\\", \\\"{x:1414,y:769,t:1527628079769};\\\", \\\"{x:1415,y:770,t:1527628079786};\\\", \\\"{x:1416,y:768,t:1527628080022};\\\", \\\"{x:1416,y:765,t:1527628080036};\\\", \\\"{x:1416,y:759,t:1527628080053};\\\", \\\"{x:1416,y:754,t:1527628080069};\\\", \\\"{x:1416,y:753,t:1527628080093};\\\", \\\"{x:1416,y:754,t:1527628080245};\\\", \\\"{x:1416,y:756,t:1527628080253};\\\", \\\"{x:1416,y:761,t:1527628080270};\\\", \\\"{x:1416,y:765,t:1527628080285};\\\", \\\"{x:1416,y:766,t:1527628080303};\\\", \\\"{x:1416,y:767,t:1527628080320};\\\", \\\"{x:1415,y:766,t:1527628080541};\\\", \\\"{x:1415,y:765,t:1527628080557};\\\", \\\"{x:1414,y:765,t:1527628080589};\\\", \\\"{x:1414,y:764,t:1527628080774};\\\", \\\"{x:1412,y:761,t:1527628080787};\\\", \\\"{x:1411,y:761,t:1527628080804};\\\", \\\"{x:1408,y:756,t:1527628080820};\\\", \\\"{x:1404,y:746,t:1527628080837};\\\", \\\"{x:1400,y:740,t:1527628080853};\\\", \\\"{x:1398,y:735,t:1527628080870};\\\", \\\"{x:1394,y:730,t:1527628080887};\\\", \\\"{x:1392,y:729,t:1527628080904};\\\", \\\"{x:1391,y:727,t:1527628080920};\\\", \\\"{x:1391,y:726,t:1527628080937};\\\", \\\"{x:1391,y:725,t:1527628080954};\\\", \\\"{x:1389,y:723,t:1527628080970};\\\", \\\"{x:1389,y:722,t:1527628081005};\\\", \\\"{x:1389,y:721,t:1527628081022};\\\", \\\"{x:1389,y:720,t:1527628081046};\\\", \\\"{x:1388,y:718,t:1527628081053};\\\", \\\"{x:1384,y:712,t:1527628081070};\\\", \\\"{x:1376,y:702,t:1527628081087};\\\", \\\"{x:1371,y:694,t:1527628081104};\\\", \\\"{x:1363,y:685,t:1527628081120};\\\", \\\"{x:1354,y:680,t:1527628081137};\\\", \\\"{x:1344,y:675,t:1527628081154};\\\", \\\"{x:1340,y:672,t:1527628081170};\\\", \\\"{x:1339,y:672,t:1527628081187};\\\", \\\"{x:1338,y:672,t:1527628081204};\\\", \\\"{x:1338,y:674,t:1527628081261};\\\", \\\"{x:1338,y:675,t:1527628081270};\\\", \\\"{x:1336,y:682,t:1527628081286};\\\", \\\"{x:1335,y:689,t:1527628081303};\\\", \\\"{x:1335,y:697,t:1527628081320};\\\", \\\"{x:1335,y:709,t:1527628081337};\\\", \\\"{x:1337,y:714,t:1527628081353};\\\", \\\"{x:1340,y:718,t:1527628081370};\\\", \\\"{x:1340,y:722,t:1527628081386};\\\", \\\"{x:1343,y:719,t:1527628081469};\\\", \\\"{x:1345,y:713,t:1527628081487};\\\", \\\"{x:1347,y:707,t:1527628081503};\\\", \\\"{x:1348,y:704,t:1527628081521};\\\", \\\"{x:1349,y:702,t:1527628081537};\\\", \\\"{x:1350,y:703,t:1527628081814};\\\", \\\"{x:1350,y:704,t:1527628081829};\\\", \\\"{x:1351,y:704,t:1527628082006};\\\", \\\"{x:1351,y:703,t:1527628082021};\\\", \\\"{x:1351,y:702,t:1527628082038};\\\", \\\"{x:1351,y:701,t:1527628082054};\\\", \\\"{x:1352,y:700,t:1527628082071};\\\", \\\"{x:1352,y:698,t:1527628082087};\\\", \\\"{x:1353,y:697,t:1527628082104};\\\", \\\"{x:1354,y:696,t:1527628082121};\\\", \\\"{x:1354,y:695,t:1527628082158};\\\", \\\"{x:1355,y:694,t:1527628082172};\\\", \\\"{x:1355,y:693,t:1527628082187};\\\", \\\"{x:1362,y:674,t:1527628082204};\\\", \\\"{x:1363,y:670,t:1527628082220};\\\", \\\"{x:1364,y:669,t:1527628082238};\\\", \\\"{x:1365,y:668,t:1527628082254};\\\", \\\"{x:1365,y:667,t:1527628082270};\\\", \\\"{x:1366,y:667,t:1527628082288};\\\", \\\"{x:1366,y:666,t:1527628082406};\\\", \\\"{x:1366,y:664,t:1527628082421};\\\", \\\"{x:1366,y:657,t:1527628082437};\\\", \\\"{x:1368,y:652,t:1527628082455};\\\", \\\"{x:1368,y:651,t:1527628082471};\\\", \\\"{x:1368,y:650,t:1527628082487};\\\", \\\"{x:1368,y:649,t:1527628082504};\\\", \\\"{x:1368,y:651,t:1527628083037};\\\", \\\"{x:1352,y:704,t:1527628083055};\\\", \\\"{x:1337,y:794,t:1527628083073};\\\", \\\"{x:1326,y:866,t:1527628083088};\\\", \\\"{x:1321,y:911,t:1527628083105};\\\", \\\"{x:1321,y:950,t:1527628083122};\\\", \\\"{x:1321,y:978,t:1527628083138};\\\", \\\"{x:1319,y:988,t:1527628083155};\\\", \\\"{x:1317,y:994,t:1527628083172};\\\", \\\"{x:1316,y:995,t:1527628083188};\\\", \\\"{x:1316,y:990,t:1527628083357};\\\", \\\"{x:1318,y:983,t:1527628083372};\\\", \\\"{x:1329,y:964,t:1527628083390};\\\", \\\"{x:1335,y:956,t:1527628083406};\\\", \\\"{x:1338,y:951,t:1527628083421};\\\", \\\"{x:1339,y:949,t:1527628083439};\\\", \\\"{x:1340,y:948,t:1527628083455};\\\", \\\"{x:1341,y:948,t:1527628083581};\\\", \\\"{x:1343,y:949,t:1527628083589};\\\", \\\"{x:1344,y:955,t:1527628083606};\\\", \\\"{x:1344,y:958,t:1527628083622};\\\", \\\"{x:1345,y:961,t:1527628083639};\\\", \\\"{x:1346,y:962,t:1527628083893};\\\", \\\"{x:1347,y:962,t:1527628083925};\\\", \\\"{x:1347,y:960,t:1527628083939};\\\", \\\"{x:1348,y:954,t:1527628083956};\\\", \\\"{x:1349,y:941,t:1527628083972};\\\", \\\"{x:1351,y:925,t:1527628083989};\\\", \\\"{x:1351,y:919,t:1527628084006};\\\", \\\"{x:1351,y:912,t:1527628084022};\\\", \\\"{x:1351,y:907,t:1527628084039};\\\", \\\"{x:1351,y:903,t:1527628084056};\\\", \\\"{x:1351,y:902,t:1527628084072};\\\", \\\"{x:1351,y:901,t:1527628084090};\\\", \\\"{x:1351,y:900,t:1527628084333};\\\", \\\"{x:1350,y:901,t:1527628084341};\\\", \\\"{x:1346,y:904,t:1527628084357};\\\", \\\"{x:1333,y:920,t:1527628084373};\\\", \\\"{x:1323,y:929,t:1527628084389};\\\", \\\"{x:1315,y:935,t:1527628084406};\\\", \\\"{x:1309,y:939,t:1527628084423};\\\", \\\"{x:1304,y:943,t:1527628084439};\\\", \\\"{x:1301,y:945,t:1527628084456};\\\", \\\"{x:1297,y:950,t:1527628084473};\\\", \\\"{x:1294,y:955,t:1527628084489};\\\", \\\"{x:1289,y:963,t:1527628084506};\\\", \\\"{x:1289,y:964,t:1527628084523};\\\", \\\"{x:1288,y:965,t:1527628084540};\\\", \\\"{x:1287,y:966,t:1527628084774};\\\", \\\"{x:1286,y:966,t:1527628084813};\\\", \\\"{x:1284,y:966,t:1527628084837};\\\", \\\"{x:1283,y:966,t:1527628084861};\\\", \\\"{x:1282,y:967,t:1527628084926};\\\", \\\"{x:1281,y:967,t:1527628084974};\\\", \\\"{x:1280,y:966,t:1527628085070};\\\", \\\"{x:1281,y:962,t:1527628085077};\\\", \\\"{x:1285,y:960,t:1527628085090};\\\", \\\"{x:1293,y:955,t:1527628085106};\\\", \\\"{x:1302,y:951,t:1527628085123};\\\", \\\"{x:1307,y:950,t:1527628085140};\\\", \\\"{x:1308,y:949,t:1527628085158};\\\", \\\"{x:1309,y:949,t:1527628085197};\\\", \\\"{x:1310,y:948,t:1527628085208};\\\", \\\"{x:1311,y:948,t:1527628085223};\\\", \\\"{x:1318,y:948,t:1527628085240};\\\", \\\"{x:1326,y:948,t:1527628085257};\\\", \\\"{x:1332,y:948,t:1527628085273};\\\", \\\"{x:1333,y:948,t:1527628085290};\\\", \\\"{x:1334,y:948,t:1527628085307};\\\", \\\"{x:1335,y:948,t:1527628085323};\\\", \\\"{x:1336,y:948,t:1527628085340};\\\", \\\"{x:1342,y:947,t:1527628085357};\\\", \\\"{x:1343,y:947,t:1527628085373};\\\", \\\"{x:1345,y:944,t:1527628085390};\\\", \\\"{x:1345,y:941,t:1527628085407};\\\", \\\"{x:1345,y:926,t:1527628085423};\\\", \\\"{x:1345,y:908,t:1527628085440};\\\", \\\"{x:1345,y:893,t:1527628085458};\\\", \\\"{x:1345,y:882,t:1527628085474};\\\", \\\"{x:1345,y:876,t:1527628085491};\\\", \\\"{x:1345,y:874,t:1527628085507};\\\", \\\"{x:1345,y:872,t:1527628085523};\\\", \\\"{x:1345,y:871,t:1527628085558};\\\", \\\"{x:1345,y:869,t:1527628085574};\\\", \\\"{x:1345,y:867,t:1527628085590};\\\", \\\"{x:1345,y:865,t:1527628085607};\\\", \\\"{x:1344,y:859,t:1527628085624};\\\", \\\"{x:1339,y:847,t:1527628085640};\\\", \\\"{x:1328,y:831,t:1527628085658};\\\", \\\"{x:1314,y:814,t:1527628085674};\\\", \\\"{x:1296,y:792,t:1527628085690};\\\", \\\"{x:1282,y:769,t:1527628085707};\\\", \\\"{x:1272,y:747,t:1527628085724};\\\", \\\"{x:1267,y:714,t:1527628085740};\\\", \\\"{x:1267,y:678,t:1527628085757};\\\", \\\"{x:1267,y:668,t:1527628085774};\\\", \\\"{x:1267,y:665,t:1527628085790};\\\", \\\"{x:1267,y:662,t:1527628085807};\\\", \\\"{x:1270,y:659,t:1527628085824};\\\", \\\"{x:1277,y:654,t:1527628085840};\\\", \\\"{x:1288,y:648,t:1527628085857};\\\", \\\"{x:1296,y:643,t:1527628085875};\\\", \\\"{x:1303,y:639,t:1527628085890};\\\", \\\"{x:1314,y:634,t:1527628085908};\\\", \\\"{x:1323,y:630,t:1527628085925};\\\", \\\"{x:1325,y:629,t:1527628085940};\\\", \\\"{x:1326,y:628,t:1527628085957};\\\", \\\"{x:1327,y:629,t:1527628086069};\\\", \\\"{x:1327,y:632,t:1527628086077};\\\", \\\"{x:1327,y:635,t:1527628086091};\\\", \\\"{x:1326,y:638,t:1527628086107};\\\", \\\"{x:1325,y:642,t:1527628086124};\\\", \\\"{x:1324,y:641,t:1527628086245};\\\", \\\"{x:1322,y:637,t:1527628086257};\\\", \\\"{x:1322,y:635,t:1527628086274};\\\", \\\"{x:1322,y:634,t:1527628086291};\\\", \\\"{x:1322,y:633,t:1527628086309};\\\", \\\"{x:1322,y:632,t:1527628086381};\\\", \\\"{x:1321,y:631,t:1527628086485};\\\", \\\"{x:1320,y:630,t:1527628086504};\\\", \\\"{x:1318,y:629,t:1527628086523};\\\", \\\"{x:1314,y:627,t:1527628086540};\\\", \\\"{x:1313,y:626,t:1527628086558};\\\", \\\"{x:1311,y:625,t:1527628086588};\\\", \\\"{x:1311,y:624,t:1527628086612};\\\", \\\"{x:1309,y:624,t:1527628086653};\\\", \\\"{x:1309,y:625,t:1527628087174};\\\", \\\"{x:1309,y:626,t:1527628087253};\\\", \\\"{x:1309,y:627,t:1527628087406};\\\", \\\"{x:1310,y:627,t:1527628087461};\\\", \\\"{x:1311,y:627,t:1527628087485};\\\", \\\"{x:1312,y:628,t:1527628087662};\\\", \\\"{x:1312,y:631,t:1527628087675};\\\", \\\"{x:1312,y:637,t:1527628087693};\\\", \\\"{x:1310,y:644,t:1527628087708};\\\", \\\"{x:1309,y:649,t:1527628087725};\\\", \\\"{x:1308,y:651,t:1527628087741};\\\", \\\"{x:1308,y:652,t:1527628087759};\\\", \\\"{x:1307,y:653,t:1527628087781};\\\", \\\"{x:1307,y:654,t:1527628087805};\\\", \\\"{x:1307,y:655,t:1527628087813};\\\", \\\"{x:1307,y:656,t:1527628087825};\\\", \\\"{x:1306,y:658,t:1527628087842};\\\", \\\"{x:1306,y:659,t:1527628087859};\\\", \\\"{x:1306,y:661,t:1527628087875};\\\", \\\"{x:1305,y:666,t:1527628087892};\\\", \\\"{x:1304,y:673,t:1527628087909};\\\", \\\"{x:1304,y:677,t:1527628087925};\\\", \\\"{x:1304,y:679,t:1527628087942};\\\", \\\"{x:1304,y:681,t:1527628087960};\\\", \\\"{x:1304,y:684,t:1527628087975};\\\", \\\"{x:1304,y:686,t:1527628087992};\\\", \\\"{x:1304,y:688,t:1527628088009};\\\", \\\"{x:1304,y:691,t:1527628088025};\\\", \\\"{x:1304,y:694,t:1527628088042};\\\", \\\"{x:1304,y:697,t:1527628088059};\\\", \\\"{x:1304,y:700,t:1527628088076};\\\", \\\"{x:1304,y:702,t:1527628088092};\\\", \\\"{x:1304,y:713,t:1527628088109};\\\", \\\"{x:1304,y:722,t:1527628088125};\\\", \\\"{x:1304,y:736,t:1527628088142};\\\", \\\"{x:1304,y:751,t:1527628088159};\\\", \\\"{x:1304,y:772,t:1527628088176};\\\", \\\"{x:1304,y:791,t:1527628088192};\\\", \\\"{x:1304,y:807,t:1527628088209};\\\", \\\"{x:1304,y:822,t:1527628088225};\\\", \\\"{x:1304,y:837,t:1527628088242};\\\", \\\"{x:1304,y:849,t:1527628088259};\\\", \\\"{x:1304,y:860,t:1527628088276};\\\", \\\"{x:1304,y:868,t:1527628088291};\\\", \\\"{x:1304,y:877,t:1527628088308};\\\", \\\"{x:1304,y:884,t:1527628088325};\\\", \\\"{x:1303,y:889,t:1527628088341};\\\", \\\"{x:1302,y:892,t:1527628088358};\\\", \\\"{x:1301,y:892,t:1527628088375};\\\", \\\"{x:1301,y:893,t:1527628088391};\\\", \\\"{x:1301,y:896,t:1527628088409};\\\", \\\"{x:1301,y:898,t:1527628088426};\\\", \\\"{x:1301,y:901,t:1527628088442};\\\", \\\"{x:1301,y:903,t:1527628088458};\\\", \\\"{x:1301,y:905,t:1527628088492};\\\", \\\"{x:1302,y:909,t:1527628088509};\\\", \\\"{x:1306,y:917,t:1527628088526};\\\", \\\"{x:1307,y:923,t:1527628088541};\\\", \\\"{x:1309,y:929,t:1527628088559};\\\", \\\"{x:1311,y:933,t:1527628088576};\\\", \\\"{x:1311,y:936,t:1527628088592};\\\", \\\"{x:1311,y:937,t:1527628088613};\\\", \\\"{x:1311,y:938,t:1527628088627};\\\", \\\"{x:1313,y:940,t:1527628088642};\\\", \\\"{x:1313,y:942,t:1527628088660};\\\", \\\"{x:1314,y:946,t:1527628088676};\\\", \\\"{x:1315,y:948,t:1527628088692};\\\", \\\"{x:1315,y:949,t:1527628088709};\\\", \\\"{x:1315,y:950,t:1527628088733};\\\", \\\"{x:1315,y:951,t:1527628088742};\\\", \\\"{x:1315,y:953,t:1527628088760};\\\", \\\"{x:1315,y:957,t:1527628088776};\\\", \\\"{x:1316,y:957,t:1527628088793};\\\", \\\"{x:1317,y:959,t:1527628088829};\\\", \\\"{x:1317,y:960,t:1527628088870};\\\", \\\"{x:1317,y:961,t:1527628088893};\\\", \\\"{x:1317,y:962,t:1527628088933};\\\", \\\"{x:1317,y:964,t:1527628088949};\\\", \\\"{x:1317,y:965,t:1527628088960};\\\", \\\"{x:1317,y:966,t:1527628088976};\\\", \\\"{x:1317,y:968,t:1527628088993};\\\", \\\"{x:1317,y:969,t:1527628089009};\\\", \\\"{x:1317,y:970,t:1527628089029};\\\", \\\"{x:1317,y:971,t:1527628089077};\\\", \\\"{x:1318,y:972,t:1527628089222};\\\", \\\"{x:1319,y:972,t:1527628089717};\\\", \\\"{x:1319,y:971,t:1527628089774};\\\", \\\"{x:1319,y:970,t:1527628089781};\\\", \\\"{x:1319,y:969,t:1527628089793};\\\", \\\"{x:1318,y:968,t:1527628089854};\\\", \\\"{x:1318,y:967,t:1527628089869};\\\", \\\"{x:1318,y:966,t:1527628089885};\\\", \\\"{x:1317,y:966,t:1527628089893};\\\", \\\"{x:1316,y:965,t:1527628089925};\\\", \\\"{x:1314,y:965,t:1527628089990};\\\", \\\"{x:1313,y:965,t:1527628090406};\\\", \\\"{x:1313,y:964,t:1527628090429};\\\", \\\"{x:1313,y:963,t:1527628090453};\\\", \\\"{x:1313,y:961,t:1527628090469};\\\", \\\"{x:1313,y:959,t:1527628090477};\\\", \\\"{x:1313,y:952,t:1527628090494};\\\", \\\"{x:1313,y:951,t:1527628090517};\\\", \\\"{x:1313,y:950,t:1527628090528};\\\", \\\"{x:1313,y:949,t:1527628090549};\\\", \\\"{x:1313,y:948,t:1527628090733};\\\", \\\"{x:1313,y:946,t:1527628090749};\\\", \\\"{x:1313,y:945,t:1527628090761};\\\", \\\"{x:1313,y:943,t:1527628090778};\\\", \\\"{x:1313,y:941,t:1527628090795};\\\", \\\"{x:1313,y:939,t:1527628090811};\\\", \\\"{x:1313,y:934,t:1527628090828};\\\", \\\"{x:1314,y:929,t:1527628090844};\\\", \\\"{x:1315,y:920,t:1527628090861};\\\", \\\"{x:1317,y:916,t:1527628090877};\\\", \\\"{x:1317,y:915,t:1527628090894};\\\", \\\"{x:1317,y:914,t:1527628090917};\\\", \\\"{x:1317,y:913,t:1527628090927};\\\", \\\"{x:1317,y:911,t:1527628090949};\\\", \\\"{x:1317,y:910,t:1527628090973};\\\", \\\"{x:1317,y:908,t:1527628090989};\\\", \\\"{x:1318,y:907,t:1527628091013};\\\", \\\"{x:1318,y:905,t:1527628091029};\\\", \\\"{x:1318,y:903,t:1527628091044};\\\", \\\"{x:1321,y:887,t:1527628091062};\\\", \\\"{x:1321,y:876,t:1527628091077};\\\", \\\"{x:1322,y:866,t:1527628091094};\\\", \\\"{x:1322,y:859,t:1527628091112};\\\", \\\"{x:1322,y:853,t:1527628091127};\\\", \\\"{x:1322,y:846,t:1527628091144};\\\", \\\"{x:1322,y:838,t:1527628091164};\\\", \\\"{x:1322,y:831,t:1527628091177};\\\", \\\"{x:1322,y:827,t:1527628091194};\\\", \\\"{x:1322,y:824,t:1527628091211};\\\", \\\"{x:1322,y:823,t:1527628091228};\\\", \\\"{x:1322,y:822,t:1527628091244};\\\", \\\"{x:1322,y:821,t:1527628091260};\\\", \\\"{x:1322,y:820,t:1527628091308};\\\", \\\"{x:1322,y:824,t:1527628091597};\\\", \\\"{x:1323,y:829,t:1527628091612};\\\", \\\"{x:1327,y:844,t:1527628091628};\\\", \\\"{x:1332,y:862,t:1527628091645};\\\", \\\"{x:1338,y:885,t:1527628091663};\\\", \\\"{x:1341,y:894,t:1527628091678};\\\", \\\"{x:1343,y:900,t:1527628091695};\\\", \\\"{x:1343,y:909,t:1527628091713};\\\", \\\"{x:1347,y:922,t:1527628091728};\\\", \\\"{x:1352,y:933,t:1527628091746};\\\", \\\"{x:1355,y:938,t:1527628091762};\\\", \\\"{x:1356,y:938,t:1527628091778};\\\", \\\"{x:1356,y:939,t:1527628091821};\\\", \\\"{x:1356,y:940,t:1527628091837};\\\", \\\"{x:1356,y:941,t:1527628091845};\\\", \\\"{x:1356,y:944,t:1527628091861};\\\", \\\"{x:1356,y:946,t:1527628091893};\\\", \\\"{x:1356,y:947,t:1527628091949};\\\", \\\"{x:1356,y:949,t:1527628091962};\\\", \\\"{x:1356,y:951,t:1527628091978};\\\", \\\"{x:1356,y:953,t:1527628091995};\\\", \\\"{x:1356,y:956,t:1527628092011};\\\", \\\"{x:1355,y:957,t:1527628092028};\\\", \\\"{x:1355,y:961,t:1527628092045};\\\", \\\"{x:1355,y:962,t:1527628092061};\\\", \\\"{x:1355,y:963,t:1527628092078};\\\", \\\"{x:1355,y:964,t:1527628092095};\\\", \\\"{x:1354,y:966,t:1527628092112};\\\", \\\"{x:1354,y:967,t:1527628092133};\\\", \\\"{x:1353,y:967,t:1527628092146};\\\", \\\"{x:1352,y:967,t:1527628092268};\\\", \\\"{x:1352,y:966,t:1527628092292};\\\", \\\"{x:1352,y:964,t:1527628092300};\\\", \\\"{x:1352,y:960,t:1527628092312};\\\", \\\"{x:1352,y:955,t:1527628092328};\\\", \\\"{x:1352,y:951,t:1527628092344};\\\", \\\"{x:1352,y:949,t:1527628092362};\\\", \\\"{x:1352,y:947,t:1527628092378};\\\", \\\"{x:1352,y:944,t:1527628092395};\\\", \\\"{x:1352,y:943,t:1527628092412};\\\", \\\"{x:1353,y:941,t:1527628092428};\\\", \\\"{x:1353,y:939,t:1527628092445};\\\", \\\"{x:1353,y:938,t:1527628092462};\\\", \\\"{x:1353,y:937,t:1527628092478};\\\", \\\"{x:1353,y:936,t:1527628092501};\\\", \\\"{x:1353,y:935,t:1527628092517};\\\", \\\"{x:1353,y:933,t:1527628092533};\\\", \\\"{x:1353,y:932,t:1527628092549};\\\", \\\"{x:1353,y:930,t:1527628092573};\\\", \\\"{x:1354,y:930,t:1527628092589};\\\", \\\"{x:1354,y:929,t:1527628092596};\\\", \\\"{x:1354,y:927,t:1527628092612};\\\", \\\"{x:1354,y:926,t:1527628092629};\\\", \\\"{x:1354,y:924,t:1527628092646};\\\", \\\"{x:1354,y:923,t:1527628092662};\\\", \\\"{x:1354,y:921,t:1527628092680};\\\", \\\"{x:1354,y:920,t:1527628092696};\\\", \\\"{x:1354,y:917,t:1527628092713};\\\", \\\"{x:1354,y:915,t:1527628092729};\\\", \\\"{x:1354,y:914,t:1527628092749};\\\", \\\"{x:1354,y:913,t:1527628092765};\\\", \\\"{x:1354,y:912,t:1527628092781};\\\", \\\"{x:1354,y:911,t:1527628092805};\\\", \\\"{x:1354,y:910,t:1527628092812};\\\", \\\"{x:1354,y:909,t:1527628092829};\\\", \\\"{x:1354,y:907,t:1527628092845};\\\", \\\"{x:1354,y:906,t:1527628092862};\\\", \\\"{x:1354,y:905,t:1527628092879};\\\", \\\"{x:1354,y:904,t:1527628092895};\\\", \\\"{x:1354,y:903,t:1527628092912};\\\", \\\"{x:1354,y:900,t:1527628092929};\\\", \\\"{x:1354,y:899,t:1527628092946};\\\", \\\"{x:1354,y:897,t:1527628092964};\\\", \\\"{x:1354,y:896,t:1527628092981};\\\", \\\"{x:1354,y:898,t:1527628093590};\\\", \\\"{x:1354,y:899,t:1527628093597};\\\", \\\"{x:1354,y:901,t:1527628093613};\\\", \\\"{x:1354,y:902,t:1527628093629};\\\", \\\"{x:1354,y:903,t:1527628093669};\\\", \\\"{x:1354,y:905,t:1527628093693};\\\", \\\"{x:1354,y:906,t:1527628093701};\\\", \\\"{x:1354,y:907,t:1527628093713};\\\", \\\"{x:1353,y:911,t:1527628093729};\\\", \\\"{x:1353,y:915,t:1527628093747};\\\", \\\"{x:1352,y:916,t:1527628093763};\\\", \\\"{x:1352,y:918,t:1527628093779};\\\", \\\"{x:1352,y:919,t:1527628093796};\\\", \\\"{x:1352,y:921,t:1527628093812};\\\", \\\"{x:1351,y:924,t:1527628093829};\\\", \\\"{x:1350,y:927,t:1527628093845};\\\", \\\"{x:1350,y:929,t:1527628093863};\\\", \\\"{x:1348,y:932,t:1527628093878};\\\", \\\"{x:1348,y:933,t:1527628093900};\\\", \\\"{x:1348,y:935,t:1527628093912};\\\", \\\"{x:1348,y:936,t:1527628093929};\\\", \\\"{x:1348,y:939,t:1527628093945};\\\", \\\"{x:1345,y:945,t:1527628093962};\\\", \\\"{x:1345,y:949,t:1527628093979};\\\", \\\"{x:1344,y:951,t:1527628093995};\\\", \\\"{x:1344,y:954,t:1527628094012};\\\", \\\"{x:1344,y:956,t:1527628094029};\\\", \\\"{x:1344,y:958,t:1527628094046};\\\", \\\"{x:1344,y:961,t:1527628094063};\\\", \\\"{x:1344,y:962,t:1527628094084};\\\", \\\"{x:1344,y:964,t:1527628094124};\\\", \\\"{x:1344,y:965,t:1527628094133};\\\", \\\"{x:1344,y:966,t:1527628094146};\\\", \\\"{x:1344,y:967,t:1527628094163};\\\", \\\"{x:1343,y:967,t:1527628094180};\\\", \\\"{x:1343,y:968,t:1527628094196};\\\", \\\"{x:1341,y:968,t:1527628094293};\\\", \\\"{x:1340,y:967,t:1527628094333};\\\", \\\"{x:1339,y:966,t:1527628094381};\\\", \\\"{x:1339,y:965,t:1527628094405};\\\", \\\"{x:1339,y:964,t:1527628094429};\\\", \\\"{x:1339,y:962,t:1527628094446};\\\", \\\"{x:1338,y:961,t:1527628094463};\\\", \\\"{x:1338,y:959,t:1527628094480};\\\", \\\"{x:1338,y:957,t:1527628094496};\\\", \\\"{x:1338,y:956,t:1527628094513};\\\", \\\"{x:1338,y:952,t:1527628094530};\\\", \\\"{x:1338,y:949,t:1527628094547};\\\", \\\"{x:1338,y:945,t:1527628094564};\\\", \\\"{x:1338,y:939,t:1527628094580};\\\", \\\"{x:1338,y:931,t:1527628094597};\\\", \\\"{x:1338,y:924,t:1527628094613};\\\", \\\"{x:1339,y:917,t:1527628094631};\\\", \\\"{x:1341,y:908,t:1527628094648};\\\", \\\"{x:1341,y:903,t:1527628094663};\\\", \\\"{x:1342,y:902,t:1527628094680};\\\", \\\"{x:1342,y:901,t:1527628094697};\\\", \\\"{x:1343,y:901,t:1527628094821};\\\", \\\"{x:1343,y:902,t:1527628094831};\\\", \\\"{x:1344,y:906,t:1527628094848};\\\", \\\"{x:1344,y:909,t:1527628094863};\\\", \\\"{x:1344,y:912,t:1527628094880};\\\", \\\"{x:1344,y:913,t:1527628094897};\\\", \\\"{x:1344,y:918,t:1527628094913};\\\", \\\"{x:1344,y:923,t:1527628094931};\\\", \\\"{x:1344,y:927,t:1527628094947};\\\", \\\"{x:1344,y:933,t:1527628094964};\\\", \\\"{x:1344,y:939,t:1527628094980};\\\", \\\"{x:1344,y:949,t:1527628094997};\\\", \\\"{x:1344,y:953,t:1527628095014};\\\", \\\"{x:1344,y:958,t:1527628095030};\\\", \\\"{x:1344,y:961,t:1527628095047};\\\", \\\"{x:1344,y:964,t:1527628095065};\\\", \\\"{x:1344,y:965,t:1527628095085};\\\", \\\"{x:1343,y:967,t:1527628095149};\\\", \\\"{x:1342,y:968,t:1527628095173};\\\", \\\"{x:1341,y:968,t:1527628095221};\\\", \\\"{x:1340,y:968,t:1527628095237};\\\", \\\"{x:1339,y:968,t:1527628095261};\\\", \\\"{x:1338,y:970,t:1527628095269};\\\", \\\"{x:1337,y:970,t:1527628095284};\\\", \\\"{x:1336,y:970,t:1527628095301};\\\", \\\"{x:1333,y:970,t:1527628095314};\\\", \\\"{x:1332,y:971,t:1527628095330};\\\", \\\"{x:1330,y:971,t:1527628095347};\\\", \\\"{x:1325,y:971,t:1527628095365};\\\", \\\"{x:1312,y:971,t:1527628095381};\\\", \\\"{x:1301,y:971,t:1527628095397};\\\", \\\"{x:1292,y:971,t:1527628095414};\\\", \\\"{x:1285,y:971,t:1527628095431};\\\", \\\"{x:1281,y:971,t:1527628095447};\\\", \\\"{x:1276,y:970,t:1527628095464};\\\", \\\"{x:1271,y:970,t:1527628095482};\\\", \\\"{x:1270,y:969,t:1527628095497};\\\", \\\"{x:1269,y:969,t:1527628095515};\\\", \\\"{x:1268,y:969,t:1527628095565};\\\", \\\"{x:1267,y:969,t:1527628095597};\\\", \\\"{x:1266,y:967,t:1527628095621};\\\", \\\"{x:1266,y:966,t:1527628095637};\\\", \\\"{x:1266,y:963,t:1527628095647};\\\", \\\"{x:1266,y:956,t:1527628095665};\\\", \\\"{x:1266,y:947,t:1527628095681};\\\", \\\"{x:1266,y:926,t:1527628095697};\\\", \\\"{x:1266,y:908,t:1527628095714};\\\", \\\"{x:1266,y:895,t:1527628095731};\\\", \\\"{x:1266,y:882,t:1527628095747};\\\", \\\"{x:1266,y:871,t:1527628095764};\\\", \\\"{x:1266,y:858,t:1527628095780};\\\", \\\"{x:1266,y:854,t:1527628095798};\\\", \\\"{x:1266,y:853,t:1527628095814};\\\", \\\"{x:1266,y:855,t:1527628095885};\\\", \\\"{x:1266,y:861,t:1527628095898};\\\", \\\"{x:1266,y:880,t:1527628095914};\\\", \\\"{x:1266,y:897,t:1527628095931};\\\", \\\"{x:1266,y:913,t:1527628095949};\\\", \\\"{x:1266,y:925,t:1527628095964};\\\", \\\"{x:1264,y:932,t:1527628095981};\\\", \\\"{x:1264,y:933,t:1527628095998};\\\", \\\"{x:1264,y:934,t:1527628096015};\\\", \\\"{x:1263,y:936,t:1527628096031};\\\", \\\"{x:1262,y:940,t:1527628096048};\\\", \\\"{x:1259,y:943,t:1527628096064};\\\", \\\"{x:1254,y:946,t:1527628096081};\\\", \\\"{x:1245,y:951,t:1527628096098};\\\", \\\"{x:1234,y:957,t:1527628096114};\\\", \\\"{x:1225,y:961,t:1527628096131};\\\", \\\"{x:1221,y:963,t:1527628096149};\\\", \\\"{x:1219,y:964,t:1527628096164};\\\", \\\"{x:1218,y:965,t:1527628096181};\\\", \\\"{x:1217,y:965,t:1527628096198};\\\", \\\"{x:1217,y:966,t:1527628096244};\\\", \\\"{x:1216,y:960,t:1527628096292};\\\", \\\"{x:1215,y:949,t:1527628096300};\\\", \\\"{x:1211,y:936,t:1527628096314};\\\", \\\"{x:1211,y:916,t:1527628096331};\\\", \\\"{x:1211,y:910,t:1527628096348};\\\", \\\"{x:1211,y:915,t:1527628096413};\\\", \\\"{x:1211,y:920,t:1527628096420};\\\", \\\"{x:1212,y:925,t:1527628096431};\\\", \\\"{x:1214,y:936,t:1527628096448};\\\", \\\"{x:1219,y:946,t:1527628096465};\\\", \\\"{x:1221,y:950,t:1527628096481};\\\", \\\"{x:1224,y:952,t:1527628096498};\\\", \\\"{x:1225,y:952,t:1527628096515};\\\", \\\"{x:1230,y:952,t:1527628096531};\\\", \\\"{x:1233,y:953,t:1527628096548};\\\", \\\"{x:1238,y:953,t:1527628096565};\\\", \\\"{x:1242,y:953,t:1527628096581};\\\", \\\"{x:1243,y:953,t:1527628096598};\\\", \\\"{x:1244,y:953,t:1527628096615};\\\", \\\"{x:1245,y:953,t:1527628096631};\\\", \\\"{x:1248,y:953,t:1527628096649};\\\", \\\"{x:1250,y:953,t:1527628096669};\\\", \\\"{x:1251,y:953,t:1527628096681};\\\", \\\"{x:1255,y:951,t:1527628096698};\\\", \\\"{x:1258,y:947,t:1527628096715};\\\", \\\"{x:1260,y:945,t:1527628096731};\\\", \\\"{x:1262,y:942,t:1527628096749};\\\", \\\"{x:1264,y:939,t:1527628096765};\\\", \\\"{x:1267,y:930,t:1527628096782};\\\", \\\"{x:1270,y:913,t:1527628096799};\\\", \\\"{x:1273,y:884,t:1527628096816};\\\", \\\"{x:1275,y:854,t:1527628096832};\\\", \\\"{x:1275,y:849,t:1527628096848};\\\", \\\"{x:1275,y:848,t:1527628096866};\\\", \\\"{x:1276,y:850,t:1527628097166};\\\", \\\"{x:1281,y:864,t:1527628097182};\\\", \\\"{x:1285,y:880,t:1527628097199};\\\", \\\"{x:1287,y:889,t:1527628097215};\\\", \\\"{x:1289,y:894,t:1527628097233};\\\", \\\"{x:1290,y:895,t:1527628097249};\\\", \\\"{x:1290,y:891,t:1527628097477};\\\", \\\"{x:1291,y:879,t:1527628097485};\\\", \\\"{x:1296,y:863,t:1527628097500};\\\", \\\"{x:1315,y:786,t:1527628097515};\\\", \\\"{x:1334,y:648,t:1527628097533};\\\", \\\"{x:1336,y:543,t:1527628097549};\\\", \\\"{x:1336,y:457,t:1527628097566};\\\", \\\"{x:1336,y:406,t:1527628097582};\\\", \\\"{x:1336,y:396,t:1527628097600};\\\", \\\"{x:1336,y:395,t:1527628097615};\\\", \\\"{x:1336,y:394,t:1527628097637};\\\", \\\"{x:1336,y:398,t:1527628097717};\\\", \\\"{x:1330,y:435,t:1527628097732};\\\", \\\"{x:1325,y:469,t:1527628097749};\\\", \\\"{x:1320,y:500,t:1527628097765};\\\", \\\"{x:1316,y:521,t:1527628097783};\\\", \\\"{x:1313,y:534,t:1527628097799};\\\", \\\"{x:1309,y:541,t:1527628097816};\\\", \\\"{x:1308,y:543,t:1527628097833};\\\", \\\"{x:1307,y:543,t:1527628097901};\\\", \\\"{x:1307,y:538,t:1527628097917};\\\", \\\"{x:1307,y:536,t:1527628097932};\\\", \\\"{x:1307,y:532,t:1527628097950};\\\", \\\"{x:1306,y:527,t:1527628097967};\\\", \\\"{x:1306,y:523,t:1527628097982};\\\", \\\"{x:1306,y:521,t:1527628098000};\\\", \\\"{x:1306,y:519,t:1527628098016};\\\", \\\"{x:1306,y:517,t:1527628098032};\\\", \\\"{x:1306,y:516,t:1527628098049};\\\", \\\"{x:1306,y:515,t:1527628098066};\\\", \\\"{x:1307,y:513,t:1527628098174};\\\", \\\"{x:1310,y:512,t:1527628098188};\\\", \\\"{x:1313,y:509,t:1527628098200};\\\", \\\"{x:1319,y:507,t:1527628098216};\\\", \\\"{x:1322,y:505,t:1527628098233};\\\", \\\"{x:1323,y:505,t:1527628098253};\\\", \\\"{x:1325,y:505,t:1527628098269};\\\", \\\"{x:1325,y:506,t:1527628098317};\\\", \\\"{x:1325,y:513,t:1527628098333};\\\", \\\"{x:1325,y:526,t:1527628098350};\\\", \\\"{x:1325,y:534,t:1527628098367};\\\", \\\"{x:1326,y:538,t:1527628098384};\\\", \\\"{x:1326,y:539,t:1527628098400};\\\", \\\"{x:1326,y:538,t:1527628098532};\\\", \\\"{x:1326,y:527,t:1527628098549};\\\", \\\"{x:1326,y:518,t:1527628098566};\\\", \\\"{x:1326,y:512,t:1527628098584};\\\", \\\"{x:1326,y:506,t:1527628098599};\\\", \\\"{x:1326,y:505,t:1527628098617};\\\", \\\"{x:1326,y:503,t:1527628098633};\\\", \\\"{x:1326,y:502,t:1527628098649};\\\", \\\"{x:1326,y:508,t:1527628098734};\\\", \\\"{x:1326,y:521,t:1527628098750};\\\", \\\"{x:1325,y:530,t:1527628098766};\\\", \\\"{x:1325,y:536,t:1527628098783};\\\", \\\"{x:1325,y:545,t:1527628098800};\\\", \\\"{x:1325,y:554,t:1527628098817};\\\", \\\"{x:1325,y:565,t:1527628098833};\\\", \\\"{x:1325,y:573,t:1527628098851};\\\", \\\"{x:1325,y:580,t:1527628098866};\\\", \\\"{x:1323,y:590,t:1527628098883};\\\", \\\"{x:1316,y:609,t:1527628098901};\\\", \\\"{x:1315,y:611,t:1527628098917};\\\", \\\"{x:1315,y:613,t:1527628098933};\\\", \\\"{x:1315,y:615,t:1527628098950};\\\", \\\"{x:1315,y:623,t:1527628098966};\\\", \\\"{x:1316,y:642,t:1527628098982};\\\", \\\"{x:1324,y:676,t:1527628099000};\\\", \\\"{x:1341,y:722,t:1527628099016};\\\", \\\"{x:1350,y:743,t:1527628099032};\\\", \\\"{x:1357,y:767,t:1527628099050};\\\", \\\"{x:1364,y:796,t:1527628099066};\\\", \\\"{x:1369,y:816,t:1527628099083};\\\", \\\"{x:1371,y:828,t:1527628099100};\\\", \\\"{x:1371,y:830,t:1527628099116};\\\", \\\"{x:1371,y:835,t:1527628099133};\\\", \\\"{x:1371,y:846,t:1527628099150};\\\", \\\"{x:1371,y:863,t:1527628099166};\\\", \\\"{x:1371,y:881,t:1527628099183};\\\", \\\"{x:1371,y:902,t:1527628099201};\\\", \\\"{x:1371,y:925,t:1527628099217};\\\", \\\"{x:1372,y:937,t:1527628099233};\\\", \\\"{x:1372,y:939,t:1527628099251};\\\", \\\"{x:1372,y:941,t:1527628099277};\\\", \\\"{x:1372,y:945,t:1527628099293};\\\", \\\"{x:1372,y:950,t:1527628099300};\\\", \\\"{x:1372,y:961,t:1527628099316};\\\", \\\"{x:1372,y:967,t:1527628099333};\\\", \\\"{x:1372,y:968,t:1527628099356};\\\", \\\"{x:1370,y:968,t:1527628099645};\\\", \\\"{x:1369,y:968,t:1527628099677};\\\", \\\"{x:1367,y:968,t:1527628099814};\\\", \\\"{x:1366,y:968,t:1527628099837};\\\", \\\"{x:1365,y:968,t:1527628099853};\\\", \\\"{x:1364,y:966,t:1527628099869};\\\", \\\"{x:1363,y:961,t:1527628099885};\\\", \\\"{x:1363,y:957,t:1527628099901};\\\", \\\"{x:1362,y:951,t:1527628099917};\\\", \\\"{x:1362,y:948,t:1527628099934};\\\", \\\"{x:1361,y:943,t:1527628099951};\\\", \\\"{x:1361,y:939,t:1527628099967};\\\", \\\"{x:1361,y:937,t:1527628099984};\\\", \\\"{x:1361,y:936,t:1527628100000};\\\", \\\"{x:1361,y:935,t:1527628100017};\\\", \\\"{x:1362,y:935,t:1527628100077};\\\", \\\"{x:1365,y:935,t:1527628100084};\\\", \\\"{x:1366,y:935,t:1527628100100};\\\", \\\"{x:1367,y:935,t:1527628100182};\\\", \\\"{x:1368,y:936,t:1527628100188};\\\", \\\"{x:1369,y:936,t:1527628100202};\\\", \\\"{x:1370,y:938,t:1527628100217};\\\", \\\"{x:1373,y:941,t:1527628100234};\\\", \\\"{x:1373,y:942,t:1527628100252};\\\", \\\"{x:1374,y:944,t:1527628100268};\\\", \\\"{x:1374,y:945,t:1527628100293};\\\", \\\"{x:1374,y:947,t:1527628100309};\\\", \\\"{x:1374,y:948,t:1527628100317};\\\", \\\"{x:1374,y:950,t:1527628100334};\\\", \\\"{x:1374,y:951,t:1527628100352};\\\", \\\"{x:1374,y:952,t:1527628100367};\\\", \\\"{x:1374,y:954,t:1527628100384};\\\", \\\"{x:1374,y:958,t:1527628100401};\\\", \\\"{x:1374,y:961,t:1527628100418};\\\", \\\"{x:1374,y:965,t:1527628100434};\\\", \\\"{x:1374,y:969,t:1527628100452};\\\", \\\"{x:1374,y:973,t:1527628100468};\\\", \\\"{x:1374,y:975,t:1527628100484};\\\", \\\"{x:1375,y:976,t:1527628100581};\\\", \\\"{x:1376,y:976,t:1527628100597};\\\", \\\"{x:1377,y:975,t:1527628100621};\\\", \\\"{x:1378,y:975,t:1527628100634};\\\", \\\"{x:1379,y:975,t:1527628100651};\\\", \\\"{x:1380,y:974,t:1527628100667};\\\", \\\"{x:1382,y:974,t:1527628100684};\\\", \\\"{x:1383,y:973,t:1527628100765};\\\", \\\"{x:1383,y:972,t:1527628100781};\\\", \\\"{x:1383,y:970,t:1527628100837};\\\", \\\"{x:1383,y:968,t:1527628100852};\\\", \\\"{x:1386,y:958,t:1527628100868};\\\", \\\"{x:1387,y:948,t:1527628100885};\\\", \\\"{x:1388,y:933,t:1527628100901};\\\", \\\"{x:1390,y:915,t:1527628100919};\\\", \\\"{x:1390,y:901,t:1527628100934};\\\", \\\"{x:1390,y:895,t:1527628100951};\\\", \\\"{x:1390,y:890,t:1527628100968};\\\", \\\"{x:1391,y:883,t:1527628100985};\\\", \\\"{x:1391,y:880,t:1527628101002};\\\", \\\"{x:1391,y:878,t:1527628101018};\\\", \\\"{x:1391,y:877,t:1527628101034};\\\", \\\"{x:1391,y:876,t:1527628101052};\\\", \\\"{x:1391,y:875,t:1527628101069};\\\", \\\"{x:1391,y:873,t:1527628101085};\\\", \\\"{x:1391,y:870,t:1527628101102};\\\", \\\"{x:1391,y:867,t:1527628101119};\\\", \\\"{x:1391,y:862,t:1527628101135};\\\", \\\"{x:1391,y:856,t:1527628101152};\\\", \\\"{x:1391,y:853,t:1527628101168};\\\", \\\"{x:1391,y:846,t:1527628101185};\\\", \\\"{x:1391,y:832,t:1527628101200};\\\", \\\"{x:1391,y:817,t:1527628101218};\\\", \\\"{x:1392,y:809,t:1527628101235};\\\", \\\"{x:1393,y:807,t:1527628101251};\\\", \\\"{x:1394,y:807,t:1527628101332};\\\", \\\"{x:1396,y:809,t:1527628101348};\\\", \\\"{x:1399,y:820,t:1527628101355};\\\", \\\"{x:1401,y:830,t:1527628101368};\\\", \\\"{x:1407,y:854,t:1527628101385};\\\", \\\"{x:1415,y:875,t:1527628101401};\\\", \\\"{x:1418,y:888,t:1527628101418};\\\", \\\"{x:1423,y:909,t:1527628101435};\\\", \\\"{x:1429,y:925,t:1527628101451};\\\", \\\"{x:1430,y:936,t:1527628101468};\\\", \\\"{x:1431,y:944,t:1527628101484};\\\", \\\"{x:1432,y:948,t:1527628101502};\\\", \\\"{x:1432,y:950,t:1527628101519};\\\", \\\"{x:1432,y:951,t:1527628101541};\\\", \\\"{x:1432,y:953,t:1527628101581};\\\", \\\"{x:1432,y:955,t:1527628101589};\\\", \\\"{x:1432,y:957,t:1527628101603};\\\", \\\"{x:1434,y:959,t:1527628101619};\\\", \\\"{x:1434,y:960,t:1527628101636};\\\", \\\"{x:1434,y:961,t:1527628101662};\\\", \\\"{x:1434,y:962,t:1527628101701};\\\", \\\"{x:1434,y:963,t:1527628101734};\\\", \\\"{x:1433,y:964,t:1527628101740};\\\", \\\"{x:1432,y:964,t:1527628101764};\\\", \\\"{x:1432,y:965,t:1527628101773};\\\", \\\"{x:1432,y:966,t:1527628101845};\\\", \\\"{x:1431,y:967,t:1527628101917};\\\", \\\"{x:1431,y:964,t:1527628101933};\\\", \\\"{x:1431,y:957,t:1527628101941};\\\", \\\"{x:1431,y:950,t:1527628101952};\\\", \\\"{x:1431,y:942,t:1527628101969};\\\", \\\"{x:1431,y:935,t:1527628101986};\\\", \\\"{x:1430,y:929,t:1527628102003};\\\", \\\"{x:1428,y:924,t:1527628102019};\\\", \\\"{x:1428,y:920,t:1527628102036};\\\", \\\"{x:1428,y:918,t:1527628102053};\\\", \\\"{x:1428,y:917,t:1527628102070};\\\", \\\"{x:1428,y:916,t:1527628102261};\\\", \\\"{x:1428,y:915,t:1527628102389};\\\", \\\"{x:1428,y:914,t:1527628102413};\\\", \\\"{x:1428,y:911,t:1527628102421};\\\", \\\"{x:1428,y:908,t:1527628102435};\\\", \\\"{x:1428,y:895,t:1527628102452};\\\", \\\"{x:1428,y:890,t:1527628102469};\\\", \\\"{x:1427,y:888,t:1527628102486};\\\", \\\"{x:1427,y:887,t:1527628102503};\\\", \\\"{x:1427,y:885,t:1527628102540};\\\", \\\"{x:1427,y:884,t:1527628102565};\\\", \\\"{x:1427,y:882,t:1527628102597};\\\", \\\"{x:1427,y:881,t:1527628102605};\\\", \\\"{x:1427,y:879,t:1527628102621};\\\", \\\"{x:1427,y:875,t:1527628102637};\\\", \\\"{x:1427,y:870,t:1527628102652};\\\", \\\"{x:1427,y:865,t:1527628102670};\\\", \\\"{x:1427,y:859,t:1527628102686};\\\", \\\"{x:1427,y:847,t:1527628102702};\\\", \\\"{x:1427,y:828,t:1527628102719};\\\", \\\"{x:1427,y:804,t:1527628102737};\\\", \\\"{x:1427,y:784,t:1527628102753};\\\", \\\"{x:1427,y:765,t:1527628102769};\\\", \\\"{x:1427,y:754,t:1527628102786};\\\", \\\"{x:1427,y:744,t:1527628102802};\\\", \\\"{x:1423,y:732,t:1527628102819};\\\", \\\"{x:1420,y:725,t:1527628102837};\\\", \\\"{x:1418,y:716,t:1527628102853};\\\", \\\"{x:1412,y:704,t:1527628102870};\\\", \\\"{x:1405,y:693,t:1527628102887};\\\", \\\"{x:1400,y:687,t:1527628102902};\\\", \\\"{x:1396,y:682,t:1527628102920};\\\", \\\"{x:1395,y:679,t:1527628102937};\\\", \\\"{x:1392,y:677,t:1527628102953};\\\", \\\"{x:1391,y:674,t:1527628102970};\\\", \\\"{x:1388,y:668,t:1527628102987};\\\", \\\"{x:1380,y:655,t:1527628103003};\\\", \\\"{x:1360,y:630,t:1527628103020};\\\", \\\"{x:1312,y:591,t:1527628103036};\\\", \\\"{x:1268,y:573,t:1527628103053};\\\", \\\"{x:1215,y:557,t:1527628103069};\\\", \\\"{x:1138,y:550,t:1527628103086};\\\", \\\"{x:1049,y:550,t:1527628103104};\\\", \\\"{x:954,y:555,t:1527628103120};\\\", \\\"{x:887,y:563,t:1527628103138};\\\", \\\"{x:831,y:571,t:1527628103153};\\\", \\\"{x:794,y:576,t:1527628103169};\\\", \\\"{x:742,y:583,t:1527628103190};\\\", \\\"{x:722,y:583,t:1527628103205};\\\", \\\"{x:712,y:583,t:1527628103222};\\\", \\\"{x:708,y:583,t:1527628103239};\\\", \\\"{x:705,y:582,t:1527628103255};\\\", \\\"{x:704,y:582,t:1527628103272};\\\", \\\"{x:702,y:584,t:1527628103437};\\\", \\\"{x:702,y:586,t:1527628103444};\\\", \\\"{x:701,y:590,t:1527628103456};\\\", \\\"{x:697,y:599,t:1527628103472};\\\", \\\"{x:691,y:612,t:1527628103490};\\\", \\\"{x:686,y:625,t:1527628103508};\\\", \\\"{x:677,y:641,t:1527628103522};\\\", \\\"{x:660,y:662,t:1527628103540};\\\", \\\"{x:641,y:679,t:1527628103555};\\\", \\\"{x:607,y:707,t:1527628103572};\\\", \\\"{x:560,y:735,t:1527628103590};\\\", \\\"{x:498,y:767,t:1527628103605};\\\", \\\"{x:441,y:798,t:1527628103622};\\\", \\\"{x:415,y:813,t:1527628103639};\\\", \\\"{x:401,y:822,t:1527628103657};\\\", \\\"{x:390,y:825,t:1527628103672};\\\", \\\"{x:383,y:825,t:1527628103689};\\\", \\\"{x:381,y:825,t:1527628103706};\\\", \\\"{x:379,y:825,t:1527628103740};\\\", \\\"{x:379,y:815,t:1527628103756};\\\", \\\"{x:379,y:799,t:1527628103772};\\\", \\\"{x:388,y:786,t:1527628103790};\\\", \\\"{x:394,y:779,t:1527628103807};\\\", \\\"{x:405,y:766,t:1527628103823};\\\", \\\"{x:412,y:757,t:1527628103839};\\\", \\\"{x:414,y:755,t:1527628103856};\\\", \\\"{x:418,y:750,t:1527628103872};\\\", \\\"{x:425,y:743,t:1527628103889};\\\", \\\"{x:438,y:734,t:1527628103906};\\\", \\\"{x:451,y:725,t:1527628103922};\\\", \\\"{x:459,y:721,t:1527628103939};\\\", \\\"{x:470,y:714,t:1527628103956};\\\", \\\"{x:472,y:714,t:1527628103972};\\\", \\\"{x:474,y:712,t:1527628103989};\\\", \\\"{x:475,y:712,t:1527628104006};\\\", \\\"{x:476,y:711,t:1527628104022};\\\", \\\"{x:477,y:711,t:1527628104039};\\\", \\\"{x:479,y:710,t:1527628104056};\\\", \\\"{x:480,y:709,t:1527628104092};\\\", \\\"{x:482,y:710,t:1527628104493};\\\", \\\"{x:484,y:710,t:1527628105340};\\\", \\\"{x:510,y:686,t:1527628105357};\\\", \\\"{x:562,y:623,t:1527628105374};\\\", \\\"{x:622,y:554,t:1527628105390};\\\", \\\"{x:667,y:508,t:1527628105407};\\\", \\\"{x:693,y:488,t:1527628105423};\\\", \\\"{x:705,y:476,t:1527628105440};\\\", \\\"{x:712,y:466,t:1527628105457};\\\", \\\"{x:713,y:466,t:1527628105474};\\\", \\\"{x:713,y:465,t:1527628105490};\\\", \\\"{x:713,y:464,t:1527628105557};\\\" ] }, { \\\"rt\\\": 91421, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 320391, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -O -O -I -I -04 PM-E -03 PM-03 PM-03 PM-A -U -F -F -3-B -B -F -O -O -H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:713,y:463,t:1527628106455};\\\", \\\"{x:712,y:463,t:1527628107597};\\\", \\\"{x:711,y:463,t:1527628107620};\\\", \\\"{x:710,y:463,t:1527628107661};\\\", \\\"{x:709,y:463,t:1527628107700};\\\", \\\"{x:708,y:463,t:1527628107885};\\\", \\\"{x:707,y:463,t:1527628108124};\\\", \\\"{x:706,y:463,t:1527628109165};\\\", \\\"{x:705,y:463,t:1527628109245};\\\", \\\"{x:704,y:463,t:1527628110173};\\\", \\\"{x:704,y:464,t:1527628123281};\\\", \\\"{x:716,y:472,t:1527628123291};\\\", \\\"{x:776,y:494,t:1527628123308};\\\", \\\"{x:805,y:501,t:1527628123325};\\\", \\\"{x:811,y:504,t:1527628123341};\\\", \\\"{x:812,y:504,t:1527628123358};\\\", \\\"{x:813,y:504,t:1527628123383};\\\", \\\"{x:814,y:501,t:1527628123399};\\\", \\\"{x:816,y:496,t:1527628123407};\\\", \\\"{x:816,y:486,t:1527628123425};\\\", \\\"{x:817,y:472,t:1527628123440};\\\", \\\"{x:818,y:460,t:1527628123457};\\\", \\\"{x:822,y:447,t:1527628123475};\\\", \\\"{x:828,y:427,t:1527628123491};\\\", \\\"{x:834,y:405,t:1527628123508};\\\", \\\"{x:834,y:404,t:1527628123525};\\\", \\\"{x:833,y:404,t:1527628124121};\\\", \\\"{x:832,y:404,t:1527628124152};\\\", \\\"{x:832,y:405,t:1527628124232};\\\", \\\"{x:832,y:406,t:1527628124248};\\\", \\\"{x:832,y:407,t:1527628124258};\\\", \\\"{x:832,y:411,t:1527628124275};\\\", \\\"{x:832,y:423,t:1527628124292};\\\", \\\"{x:835,y:449,t:1527628124311};\\\", \\\"{x:853,y:490,t:1527628124325};\\\", \\\"{x:881,y:534,t:1527628124344};\\\", \\\"{x:916,y:582,t:1527628124360};\\\", \\\"{x:947,y:623,t:1527628124375};\\\", \\\"{x:990,y:671,t:1527628124393};\\\", \\\"{x:1021,y:699,t:1527628124409};\\\", \\\"{x:1058,y:728,t:1527628124427};\\\", \\\"{x:1102,y:753,t:1527628124443};\\\", \\\"{x:1157,y:778,t:1527628124460};\\\", \\\"{x:1214,y:796,t:1527628124476};\\\", \\\"{x:1255,y:808,t:1527628124494};\\\", \\\"{x:1290,y:811,t:1527628124510};\\\", \\\"{x:1322,y:815,t:1527628124527};\\\", \\\"{x:1356,y:815,t:1527628124543};\\\", \\\"{x:1368,y:815,t:1527628124560};\\\", \\\"{x:1374,y:811,t:1527628124577};\\\", \\\"{x:1380,y:806,t:1527628124593};\\\", \\\"{x:1388,y:801,t:1527628124610};\\\", \\\"{x:1391,y:798,t:1527628124627};\\\", \\\"{x:1394,y:791,t:1527628124644};\\\", \\\"{x:1394,y:779,t:1527628124660};\\\", \\\"{x:1394,y:766,t:1527628124677};\\\", \\\"{x:1394,y:759,t:1527628124694};\\\", \\\"{x:1394,y:756,t:1527628124709};\\\", \\\"{x:1394,y:750,t:1527628124727};\\\", \\\"{x:1400,y:732,t:1527628124744};\\\", \\\"{x:1404,y:719,t:1527628124760};\\\", \\\"{x:1404,y:698,t:1527628124777};\\\", \\\"{x:1394,y:648,t:1527628124794};\\\", \\\"{x:1368,y:587,t:1527628124810};\\\", \\\"{x:1339,y:528,t:1527628124827};\\\", \\\"{x:1324,y:488,t:1527628124844};\\\", \\\"{x:1320,y:473,t:1527628124860};\\\", \\\"{x:1320,y:469,t:1527628124877};\\\", \\\"{x:1320,y:468,t:1527628124894};\\\", \\\"{x:1320,y:467,t:1527628124911};\\\", \\\"{x:1320,y:466,t:1527628124961};\\\", \\\"{x:1322,y:464,t:1527628124977};\\\", \\\"{x:1323,y:459,t:1527628124994};\\\", \\\"{x:1325,y:452,t:1527628125011};\\\", \\\"{x:1325,y:449,t:1527628125027};\\\", \\\"{x:1325,y:448,t:1527628125044};\\\", \\\"{x:1325,y:451,t:1527628125152};\\\", \\\"{x:1325,y:458,t:1527628125161};\\\", \\\"{x:1325,y:471,t:1527628125177};\\\", \\\"{x:1325,y:479,t:1527628125194};\\\", \\\"{x:1325,y:484,t:1527628125211};\\\", \\\"{x:1325,y:488,t:1527628125227};\\\", \\\"{x:1325,y:491,t:1527628125244};\\\", \\\"{x:1325,y:492,t:1527628125353};\\\", \\\"{x:1325,y:494,t:1527628125361};\\\", \\\"{x:1325,y:497,t:1527628125378};\\\", \\\"{x:1325,y:498,t:1527628125394};\\\", \\\"{x:1325,y:500,t:1527628125416};\\\", \\\"{x:1325,y:501,t:1527628125696};\\\", \\\"{x:1324,y:501,t:1527628125720};\\\", \\\"{x:1323,y:502,t:1527628125752};\\\", \\\"{x:1321,y:502,t:1527628125776};\\\", \\\"{x:1320,y:502,t:1527628125888};\\\", \\\"{x:1319,y:502,t:1527628126208};\\\", \\\"{x:1318,y:502,t:1527628126216};\\\", \\\"{x:1318,y:501,t:1527628126233};\\\", \\\"{x:1317,y:500,t:1527628126262};\\\", \\\"{x:1317,y:499,t:1527628126278};\\\", \\\"{x:1317,y:498,t:1527628126295};\\\", \\\"{x:1316,y:497,t:1527628126368};\\\", \\\"{x:1315,y:497,t:1527628129856};\\\", \\\"{x:1315,y:500,t:1527628129864};\\\", \\\"{x:1315,y:505,t:1527628129883};\\\", \\\"{x:1315,y:510,t:1527628129899};\\\", \\\"{x:1315,y:515,t:1527628129914};\\\", \\\"{x:1315,y:520,t:1527628129930};\\\", \\\"{x:1315,y:523,t:1527628129948};\\\", \\\"{x:1315,y:526,t:1527628129963};\\\", \\\"{x:1315,y:528,t:1527628129981};\\\", \\\"{x:1315,y:529,t:1527628129998};\\\", \\\"{x:1315,y:531,t:1527628130014};\\\", \\\"{x:1315,y:533,t:1527628130031};\\\", \\\"{x:1315,y:535,t:1527628130048};\\\", \\\"{x:1315,y:538,t:1527628130064};\\\", \\\"{x:1315,y:543,t:1527628130081};\\\", \\\"{x:1315,y:547,t:1527628130098};\\\", \\\"{x:1315,y:554,t:1527628130115};\\\", \\\"{x:1315,y:564,t:1527628130131};\\\", \\\"{x:1315,y:578,t:1527628130148};\\\", \\\"{x:1315,y:593,t:1527628130166};\\\", \\\"{x:1315,y:614,t:1527628130182};\\\", \\\"{x:1315,y:635,t:1527628130199};\\\", \\\"{x:1315,y:654,t:1527628130217};\\\", \\\"{x:1317,y:675,t:1527628130232};\\\", \\\"{x:1321,y:701,t:1527628130248};\\\", \\\"{x:1323,y:719,t:1527628130265};\\\", \\\"{x:1327,y:743,t:1527628130282};\\\", \\\"{x:1328,y:773,t:1527628130298};\\\", \\\"{x:1328,y:797,t:1527628130315};\\\", \\\"{x:1328,y:816,t:1527628130332};\\\", \\\"{x:1328,y:838,t:1527628130349};\\\", \\\"{x:1328,y:862,t:1527628130366};\\\", \\\"{x:1328,y:883,t:1527628130381};\\\", \\\"{x:1328,y:893,t:1527628130399};\\\", \\\"{x:1326,y:900,t:1527628130415};\\\", \\\"{x:1322,y:920,t:1527628130432};\\\", \\\"{x:1319,y:932,t:1527628130448};\\\", \\\"{x:1316,y:940,t:1527628130465};\\\", \\\"{x:1315,y:945,t:1527628130481};\\\", \\\"{x:1313,y:947,t:1527628130498};\\\", \\\"{x:1313,y:949,t:1527628130516};\\\", \\\"{x:1313,y:950,t:1527628130552};\\\", \\\"{x:1313,y:952,t:1527628130576};\\\", \\\"{x:1313,y:953,t:1527628130672};\\\", \\\"{x:1313,y:954,t:1527628130688};\\\", \\\"{x:1313,y:956,t:1527628130698};\\\", \\\"{x:1315,y:959,t:1527628130715};\\\", \\\"{x:1317,y:961,t:1527628130733};\\\", \\\"{x:1319,y:963,t:1527628130749};\\\", \\\"{x:1319,y:964,t:1527628130992};\\\", \\\"{x:1318,y:964,t:1527628131016};\\\", \\\"{x:1317,y:965,t:1527628131032};\\\", \\\"{x:1316,y:967,t:1527628131050};\\\", \\\"{x:1315,y:970,t:1527628131066};\\\", \\\"{x:1315,y:972,t:1527628131083};\\\", \\\"{x:1314,y:972,t:1527628131440};\\\", \\\"{x:1313,y:972,t:1527628131464};\\\", \\\"{x:1313,y:971,t:1527628131488};\\\", \\\"{x:1312,y:970,t:1527628131504};\\\", \\\"{x:1311,y:969,t:1527628131528};\\\", \\\"{x:1311,y:967,t:1527628131544};\\\", \\\"{x:1310,y:966,t:1527628131552};\\\", \\\"{x:1310,y:965,t:1527628131576};\\\", \\\"{x:1309,y:964,t:1527628131584};\\\", \\\"{x:1309,y:963,t:1527628131608};\\\", \\\"{x:1310,y:963,t:1527628131880};\\\", \\\"{x:1312,y:963,t:1527628132144};\\\", \\\"{x:1313,y:962,t:1527628132184};\\\", \\\"{x:1316,y:947,t:1527628132200};\\\", \\\"{x:1327,y:907,t:1527628132216};\\\", \\\"{x:1333,y:862,t:1527628132234};\\\", \\\"{x:1333,y:823,t:1527628132249};\\\", \\\"{x:1333,y:804,t:1527628132267};\\\", \\\"{x:1333,y:782,t:1527628132284};\\\", \\\"{x:1333,y:759,t:1527628132301};\\\", \\\"{x:1333,y:732,t:1527628132317};\\\", \\\"{x:1333,y:700,t:1527628132334};\\\", \\\"{x:1331,y:672,t:1527628132350};\\\", \\\"{x:1325,y:655,t:1527628132367};\\\", \\\"{x:1322,y:642,t:1527628132384};\\\", \\\"{x:1321,y:639,t:1527628132401};\\\", \\\"{x:1320,y:637,t:1527628132416};\\\", \\\"{x:1318,y:635,t:1527628132434};\\\", \\\"{x:1318,y:633,t:1527628132451};\\\", \\\"{x:1316,y:629,t:1527628132466};\\\", \\\"{x:1315,y:625,t:1527628132483};\\\", \\\"{x:1313,y:615,t:1527628132501};\\\", \\\"{x:1310,y:605,t:1527628132517};\\\", \\\"{x:1307,y:598,t:1527628132534};\\\", \\\"{x:1304,y:589,t:1527628132550};\\\", \\\"{x:1300,y:577,t:1527628132567};\\\", \\\"{x:1296,y:560,t:1527628132583};\\\", \\\"{x:1292,y:542,t:1527628132600};\\\", \\\"{x:1291,y:536,t:1527628132617};\\\", \\\"{x:1291,y:534,t:1527628132634};\\\", \\\"{x:1291,y:533,t:1527628132664};\\\", \\\"{x:1291,y:532,t:1527628132760};\\\", \\\"{x:1291,y:531,t:1527628132768};\\\", \\\"{x:1291,y:530,t:1527628132783};\\\", \\\"{x:1291,y:528,t:1527628132801};\\\", \\\"{x:1291,y:526,t:1527628132817};\\\", \\\"{x:1292,y:523,t:1527628132834};\\\", \\\"{x:1296,y:518,t:1527628132850};\\\", \\\"{x:1299,y:512,t:1527628132867};\\\", \\\"{x:1301,y:506,t:1527628132884};\\\", \\\"{x:1303,y:503,t:1527628132901};\\\", \\\"{x:1303,y:502,t:1527628132920};\\\", \\\"{x:1303,y:500,t:1527628132936};\\\", \\\"{x:1304,y:500,t:1527628132951};\\\", \\\"{x:1305,y:497,t:1527628132968};\\\", \\\"{x:1306,y:495,t:1527628132984};\\\", \\\"{x:1307,y:494,t:1527628133001};\\\", \\\"{x:1308,y:492,t:1527628133064};\\\", \\\"{x:1309,y:492,t:1527628133096};\\\", \\\"{x:1310,y:491,t:1527628133120};\\\", \\\"{x:1311,y:491,t:1527628133215};\\\", \\\"{x:1312,y:492,t:1527628133264};\\\", \\\"{x:1314,y:497,t:1527628133284};\\\", \\\"{x:1314,y:498,t:1527628133300};\\\", \\\"{x:1315,y:499,t:1527628133335};\\\", \\\"{x:1316,y:499,t:1527628133367};\\\", \\\"{x:1316,y:500,t:1527628133390};\\\", \\\"{x:1317,y:500,t:1527628133656};\\\", \\\"{x:1318,y:500,t:1527628133815};\\\", \\\"{x:1319,y:500,t:1527628138552};\\\", \\\"{x:1320,y:500,t:1527628138569};\\\", \\\"{x:1321,y:500,t:1527628138576};\\\", \\\"{x:1322,y:499,t:1527628138591};\\\", \\\"{x:1323,y:499,t:1527628138712};\\\", \\\"{x:1323,y:498,t:1527628138864};\\\", \\\"{x:1324,y:498,t:1527628138872};\\\", \\\"{x:1325,y:498,t:1527628138903};\\\", \\\"{x:1326,y:497,t:1527628138920};\\\", \\\"{x:1327,y:497,t:1527628139054};\\\", \\\"{x:1328,y:497,t:1527628139071};\\\", \\\"{x:1337,y:499,t:1527628139088};\\\", \\\"{x:1354,y:507,t:1527628139105};\\\", \\\"{x:1380,y:527,t:1527628139121};\\\", \\\"{x:1405,y:548,t:1527628139138};\\\", \\\"{x:1431,y:579,t:1527628139155};\\\", \\\"{x:1468,y:637,t:1527628139171};\\\", \\\"{x:1504,y:700,t:1527628139188};\\\", \\\"{x:1537,y:757,t:1527628139205};\\\", \\\"{x:1553,y:793,t:1527628139221};\\\", \\\"{x:1564,y:820,t:1527628139238};\\\", \\\"{x:1573,y:850,t:1527628139255};\\\", \\\"{x:1575,y:864,t:1527628139272};\\\", \\\"{x:1577,y:874,t:1527628139288};\\\", \\\"{x:1578,y:884,t:1527628139306};\\\", \\\"{x:1578,y:888,t:1527628139322};\\\", \\\"{x:1578,y:889,t:1527628139338};\\\", \\\"{x:1577,y:891,t:1527628139359};\\\", \\\"{x:1576,y:895,t:1527628139376};\\\", \\\"{x:1576,y:902,t:1527628139388};\\\", \\\"{x:1576,y:918,t:1527628139406};\\\", \\\"{x:1576,y:926,t:1527628139422};\\\", \\\"{x:1576,y:929,t:1527628139439};\\\", \\\"{x:1575,y:936,t:1527628139455};\\\", \\\"{x:1575,y:946,t:1527628139472};\\\", \\\"{x:1574,y:960,t:1527628139489};\\\", \\\"{x:1574,y:969,t:1527628139505};\\\", \\\"{x:1574,y:978,t:1527628139523};\\\", \\\"{x:1574,y:983,t:1527628139538};\\\", \\\"{x:1574,y:985,t:1527628139555};\\\", \\\"{x:1574,y:986,t:1527628139572};\\\", \\\"{x:1574,y:987,t:1527628139589};\\\", \\\"{x:1574,y:988,t:1527628139605};\\\", \\\"{x:1574,y:989,t:1527628139623};\\\", \\\"{x:1575,y:990,t:1527628139639};\\\", \\\"{x:1577,y:990,t:1527628139656};\\\", \\\"{x:1581,y:989,t:1527628139672};\\\", \\\"{x:1584,y:988,t:1527628139688};\\\", \\\"{x:1585,y:987,t:1527628139705};\\\", \\\"{x:1588,y:985,t:1527628139722};\\\", \\\"{x:1593,y:983,t:1527628139740};\\\", \\\"{x:1598,y:980,t:1527628139756};\\\", \\\"{x:1603,y:976,t:1527628139772};\\\", \\\"{x:1606,y:973,t:1527628139789};\\\", \\\"{x:1609,y:970,t:1527628139806};\\\", \\\"{x:1611,y:968,t:1527628139823};\\\", \\\"{x:1612,y:966,t:1527628139839};\\\", \\\"{x:1614,y:966,t:1527628139856};\\\", \\\"{x:1614,y:964,t:1527628139873};\\\", \\\"{x:1615,y:964,t:1527628139890};\\\", \\\"{x:1615,y:962,t:1527628139906};\\\", \\\"{x:1615,y:961,t:1527628140088};\\\", \\\"{x:1615,y:958,t:1527628140096};\\\", \\\"{x:1615,y:957,t:1527628140112};\\\", \\\"{x:1615,y:955,t:1527628140122};\\\", \\\"{x:1615,y:954,t:1527628140139};\\\", \\\"{x:1615,y:952,t:1527628140159};\\\", \\\"{x:1615,y:951,t:1527628140175};\\\", \\\"{x:1615,y:949,t:1527628140192};\\\", \\\"{x:1615,y:948,t:1527628140248};\\\", \\\"{x:1615,y:946,t:1527628140271};\\\", \\\"{x:1614,y:945,t:1527628140289};\\\", \\\"{x:1614,y:943,t:1527628140306};\\\", \\\"{x:1614,y:941,t:1527628140322};\\\", \\\"{x:1614,y:936,t:1527628140340};\\\", \\\"{x:1614,y:931,t:1527628140356};\\\", \\\"{x:1614,y:925,t:1527628140373};\\\", \\\"{x:1614,y:921,t:1527628140390};\\\", \\\"{x:1614,y:917,t:1527628140407};\\\", \\\"{x:1614,y:916,t:1527628140422};\\\", \\\"{x:1614,y:913,t:1527628140439};\\\", \\\"{x:1614,y:911,t:1527628140457};\\\", \\\"{x:1614,y:910,t:1527628140472};\\\", \\\"{x:1614,y:908,t:1527628140503};\\\", \\\"{x:1614,y:907,t:1527628140519};\\\", \\\"{x:1614,y:905,t:1527628140535};\\\", \\\"{x:1614,y:904,t:1527628140551};\\\", \\\"{x:1614,y:902,t:1527628140558};\\\", \\\"{x:1614,y:901,t:1527628140573};\\\", \\\"{x:1614,y:898,t:1527628140589};\\\", \\\"{x:1614,y:896,t:1527628140606};\\\", \\\"{x:1614,y:892,t:1527628140623};\\\", \\\"{x:1614,y:889,t:1527628140639};\\\", \\\"{x:1614,y:885,t:1527628140657};\\\", \\\"{x:1614,y:881,t:1527628140674};\\\", \\\"{x:1614,y:877,t:1527628140689};\\\", \\\"{x:1614,y:874,t:1527628140706};\\\", \\\"{x:1614,y:872,t:1527628140723};\\\", \\\"{x:1614,y:870,t:1527628140740};\\\", \\\"{x:1614,y:867,t:1527628140756};\\\", \\\"{x:1614,y:864,t:1527628140774};\\\", \\\"{x:1614,y:861,t:1527628140790};\\\", \\\"{x:1614,y:860,t:1527628140807};\\\", \\\"{x:1614,y:858,t:1527628140824};\\\", \\\"{x:1614,y:857,t:1527628140840};\\\", \\\"{x:1614,y:855,t:1527628140857};\\\", \\\"{x:1614,y:854,t:1527628140874};\\\", \\\"{x:1614,y:849,t:1527628140890};\\\", \\\"{x:1614,y:846,t:1527628140907};\\\", \\\"{x:1614,y:844,t:1527628140923};\\\", \\\"{x:1614,y:842,t:1527628140940};\\\", \\\"{x:1614,y:839,t:1527628140956};\\\", \\\"{x:1614,y:835,t:1527628140973};\\\", \\\"{x:1612,y:829,t:1527628140990};\\\", \\\"{x:1612,y:824,t:1527628141007};\\\", \\\"{x:1611,y:822,t:1527628141023};\\\", \\\"{x:1611,y:821,t:1527628141041};\\\", \\\"{x:1610,y:819,t:1527628141057};\\\", \\\"{x:1610,y:818,t:1527628141073};\\\", \\\"{x:1610,y:817,t:1527628141091};\\\", \\\"{x:1609,y:815,t:1527628141107};\\\", \\\"{x:1609,y:814,t:1527628141124};\\\", \\\"{x:1609,y:812,t:1527628141141};\\\", \\\"{x:1608,y:810,t:1527628141157};\\\", \\\"{x:1607,y:806,t:1527628141174};\\\", \\\"{x:1607,y:804,t:1527628141191};\\\", \\\"{x:1607,y:803,t:1527628141207};\\\", \\\"{x:1606,y:803,t:1527628141223};\\\", \\\"{x:1606,y:801,t:1527628141240};\\\", \\\"{x:1606,y:798,t:1527628141256};\\\", \\\"{x:1605,y:794,t:1527628141273};\\\", \\\"{x:1605,y:789,t:1527628141291};\\\", \\\"{x:1605,y:787,t:1527628141306};\\\", \\\"{x:1605,y:786,t:1527628141323};\\\", \\\"{x:1605,y:784,t:1527628141340};\\\", \\\"{x:1604,y:783,t:1527628141356};\\\", \\\"{x:1604,y:777,t:1527628141374};\\\", \\\"{x:1602,y:768,t:1527628141391};\\\", \\\"{x:1602,y:764,t:1527628141406};\\\", \\\"{x:1602,y:760,t:1527628141423};\\\", \\\"{x:1602,y:757,t:1527628141441};\\\", \\\"{x:1602,y:755,t:1527628141464};\\\", \\\"{x:1602,y:754,t:1527628141473};\\\", \\\"{x:1602,y:753,t:1527628141490};\\\", \\\"{x:1602,y:752,t:1527628141512};\\\", \\\"{x:1602,y:751,t:1527628141543};\\\", \\\"{x:1602,y:749,t:1527628141567};\\\", \\\"{x:1602,y:748,t:1527628141591};\\\", \\\"{x:1602,y:746,t:1527628141607};\\\", \\\"{x:1602,y:745,t:1527628141623};\\\", \\\"{x:1602,y:742,t:1527628141641};\\\", \\\"{x:1602,y:741,t:1527628141658};\\\", \\\"{x:1602,y:740,t:1527628141674};\\\", \\\"{x:1602,y:738,t:1527628141691};\\\", \\\"{x:1602,y:733,t:1527628141708};\\\", \\\"{x:1602,y:726,t:1527628141723};\\\", \\\"{x:1603,y:706,t:1527628141740};\\\", \\\"{x:1603,y:703,t:1527628141758};\\\", \\\"{x:1603,y:699,t:1527628141773};\\\", \\\"{x:1604,y:693,t:1527628141790};\\\", \\\"{x:1604,y:683,t:1527628141808};\\\", \\\"{x:1604,y:679,t:1527628141824};\\\", \\\"{x:1604,y:672,t:1527628141841};\\\", \\\"{x:1604,y:662,t:1527628141858};\\\", \\\"{x:1605,y:658,t:1527628141874};\\\", \\\"{x:1605,y:656,t:1527628141890};\\\", \\\"{x:1607,y:653,t:1527628141908};\\\", \\\"{x:1607,y:652,t:1527628141925};\\\", \\\"{x:1607,y:650,t:1527628141941};\\\", \\\"{x:1607,y:647,t:1527628141957};\\\", \\\"{x:1607,y:645,t:1527628141974};\\\", \\\"{x:1607,y:641,t:1527628141991};\\\", \\\"{x:1607,y:637,t:1527628142007};\\\", \\\"{x:1607,y:631,t:1527628142025};\\\", \\\"{x:1607,y:624,t:1527628142041};\\\", \\\"{x:1608,y:615,t:1527628142058};\\\", \\\"{x:1608,y:607,t:1527628142075};\\\", \\\"{x:1609,y:602,t:1527628142091};\\\", \\\"{x:1609,y:597,t:1527628142108};\\\", \\\"{x:1611,y:591,t:1527628142125};\\\", \\\"{x:1611,y:586,t:1527628142141};\\\", \\\"{x:1611,y:580,t:1527628142158};\\\", \\\"{x:1611,y:578,t:1527628142175};\\\", \\\"{x:1612,y:573,t:1527628142191};\\\", \\\"{x:1613,y:569,t:1527628142208};\\\", \\\"{x:1613,y:568,t:1527628142240};\\\", \\\"{x:1613,y:567,t:1527628142274};\\\", \\\"{x:1613,y:566,t:1527628150808};\\\", \\\"{x:1613,y:563,t:1527628155000};\\\", \\\"{x:1608,y:557,t:1527628155008};\\\", \\\"{x:1603,y:548,t:1527628155018};\\\", \\\"{x:1595,y:535,t:1527628155035};\\\", \\\"{x:1588,y:522,t:1527628155051};\\\", \\\"{x:1585,y:518,t:1527628155068};\\\", \\\"{x:1584,y:518,t:1527628155085};\\\", \\\"{x:1583,y:517,t:1527628155288};\\\", \\\"{x:1581,y:517,t:1527628155311};\\\", \\\"{x:1581,y:519,t:1527628155320};\\\", \\\"{x:1580,y:521,t:1527628155335};\\\", \\\"{x:1577,y:525,t:1527628155350};\\\", \\\"{x:1574,y:532,t:1527628155367};\\\", \\\"{x:1567,y:550,t:1527628155384};\\\", \\\"{x:1561,y:590,t:1527628155402};\\\", \\\"{x:1556,y:645,t:1527628155418};\\\", \\\"{x:1546,y:706,t:1527628155435};\\\", \\\"{x:1535,y:784,t:1527628155452};\\\", \\\"{x:1524,y:859,t:1527628155467};\\\", \\\"{x:1516,y:921,t:1527628155484};\\\", \\\"{x:1510,y:955,t:1527628155502};\\\", \\\"{x:1509,y:979,t:1527628155518};\\\", \\\"{x:1503,y:1026,t:1527628155535};\\\", \\\"{x:1499,y:1050,t:1527628155552};\\\", \\\"{x:1497,y:1065,t:1527628155568};\\\", \\\"{x:1495,y:1077,t:1527628155584};\\\", \\\"{x:1495,y:1081,t:1527628155602};\\\", \\\"{x:1495,y:1085,t:1527628155618};\\\", \\\"{x:1495,y:1089,t:1527628155635};\\\", \\\"{x:1495,y:1095,t:1527628155652};\\\", \\\"{x:1495,y:1097,t:1527628155668};\\\", \\\"{x:1496,y:1097,t:1527628155686};\\\", \\\"{x:1497,y:1097,t:1527628155702};\\\", \\\"{x:1502,y:1093,t:1527628155718};\\\", \\\"{x:1513,y:1050,t:1527628155736};\\\", \\\"{x:1525,y:1006,t:1527628155752};\\\", \\\"{x:1536,y:964,t:1527628155769};\\\", \\\"{x:1547,y:940,t:1527628155785};\\\", \\\"{x:1554,y:921,t:1527628155803};\\\", \\\"{x:1559,y:912,t:1527628155818};\\\", \\\"{x:1561,y:907,t:1527628155835};\\\", \\\"{x:1562,y:905,t:1527628155852};\\\", \\\"{x:1562,y:909,t:1527628155943};\\\", \\\"{x:1562,y:915,t:1527628155952};\\\", \\\"{x:1562,y:928,t:1527628155969};\\\", \\\"{x:1561,y:943,t:1527628155985};\\\", \\\"{x:1557,y:959,t:1527628156003};\\\", \\\"{x:1550,y:975,t:1527628156020};\\\", \\\"{x:1547,y:984,t:1527628156035};\\\", \\\"{x:1544,y:988,t:1527628156052};\\\", \\\"{x:1543,y:989,t:1527628156068};\\\", \\\"{x:1542,y:990,t:1527628156085};\\\", \\\"{x:1538,y:994,t:1527628156101};\\\", \\\"{x:1529,y:1001,t:1527628156118};\\\", \\\"{x:1526,y:1004,t:1527628156134};\\\", \\\"{x:1524,y:1004,t:1527628156152};\\\", \\\"{x:1524,y:1005,t:1527628156169};\\\", \\\"{x:1524,y:1004,t:1527628156287};\\\", \\\"{x:1524,y:995,t:1527628156303};\\\", \\\"{x:1522,y:975,t:1527628156319};\\\", \\\"{x:1522,y:968,t:1527628156335};\\\", \\\"{x:1519,y:948,t:1527628156353};\\\", \\\"{x:1519,y:929,t:1527628156370};\\\", \\\"{x:1519,y:913,t:1527628156386};\\\", \\\"{x:1519,y:897,t:1527628156403};\\\", \\\"{x:1519,y:890,t:1527628156419};\\\", \\\"{x:1519,y:887,t:1527628156436};\\\", \\\"{x:1519,y:886,t:1527628156452};\\\", \\\"{x:1519,y:882,t:1527628156468};\\\", \\\"{x:1519,y:874,t:1527628156486};\\\", \\\"{x:1519,y:856,t:1527628156501};\\\", \\\"{x:1519,y:843,t:1527628156519};\\\", \\\"{x:1519,y:838,t:1527628156535};\\\", \\\"{x:1519,y:826,t:1527628156552};\\\", \\\"{x:1519,y:806,t:1527628156569};\\\", \\\"{x:1519,y:787,t:1527628156586};\\\", \\\"{x:1519,y:767,t:1527628156602};\\\", \\\"{x:1519,y:752,t:1527628156619};\\\", \\\"{x:1519,y:746,t:1527628156636};\\\", \\\"{x:1519,y:740,t:1527628156652};\\\", \\\"{x:1519,y:732,t:1527628156669};\\\", \\\"{x:1519,y:717,t:1527628156686};\\\", \\\"{x:1519,y:700,t:1527628156702};\\\", \\\"{x:1517,y:692,t:1527628156719};\\\", \\\"{x:1517,y:691,t:1527628156736};\\\", \\\"{x:1517,y:689,t:1527628156767};\\\", \\\"{x:1515,y:688,t:1527628156775};\\\", \\\"{x:1515,y:687,t:1527628156786};\\\", \\\"{x:1515,y:685,t:1527628156803};\\\", \\\"{x:1515,y:682,t:1527628156819};\\\", \\\"{x:1515,y:675,t:1527628156836};\\\", \\\"{x:1515,y:666,t:1527628156853};\\\", \\\"{x:1515,y:662,t:1527628156870};\\\", \\\"{x:1516,y:658,t:1527628156886};\\\", \\\"{x:1518,y:645,t:1527628156903};\\\", \\\"{x:1522,y:628,t:1527628156919};\\\", \\\"{x:1527,y:613,t:1527628156937};\\\", \\\"{x:1530,y:602,t:1527628156954};\\\", \\\"{x:1535,y:589,t:1527628156969};\\\", \\\"{x:1537,y:581,t:1527628156986};\\\", \\\"{x:1539,y:578,t:1527628157003};\\\", \\\"{x:1540,y:576,t:1527628157019};\\\", \\\"{x:1540,y:574,t:1527628157037};\\\", \\\"{x:1542,y:573,t:1527628157053};\\\", \\\"{x:1542,y:571,t:1527628157072};\\\", \\\"{x:1543,y:569,t:1527628157103};\\\", \\\"{x:1544,y:567,t:1527628157152};\\\", \\\"{x:1545,y:570,t:1527628157328};\\\", \\\"{x:1545,y:574,t:1527628157336};\\\", \\\"{x:1546,y:577,t:1527628157354};\\\", \\\"{x:1547,y:581,t:1527628157370};\\\", \\\"{x:1547,y:582,t:1527628157387};\\\", \\\"{x:1549,y:584,t:1527628157407};\\\", \\\"{x:1549,y:587,t:1527628157423};\\\", \\\"{x:1553,y:595,t:1527628157436};\\\", \\\"{x:1564,y:627,t:1527628157454};\\\", \\\"{x:1578,y:672,t:1527628157470};\\\", \\\"{x:1587,y:721,t:1527628157486};\\\", \\\"{x:1598,y:785,t:1527628157503};\\\", \\\"{x:1605,y:813,t:1527628157520};\\\", \\\"{x:1610,y:838,t:1527628157536};\\\", \\\"{x:1611,y:856,t:1527628157553};\\\", \\\"{x:1611,y:868,t:1527628157571};\\\", \\\"{x:1608,y:880,t:1527628157587};\\\", \\\"{x:1597,y:908,t:1527628157603};\\\", \\\"{x:1585,y:945,t:1527628157620};\\\", \\\"{x:1578,y:985,t:1527628157637};\\\", \\\"{x:1572,y:1011,t:1527628157654};\\\", \\\"{x:1570,y:1024,t:1527628157671};\\\", \\\"{x:1567,y:1031,t:1527628157688};\\\", \\\"{x:1567,y:1032,t:1527628157703};\\\", \\\"{x:1566,y:1032,t:1527628157728};\\\", \\\"{x:1565,y:1032,t:1527628157743};\\\", \\\"{x:1564,y:1032,t:1527628157753};\\\", \\\"{x:1563,y:1032,t:1527628157776};\\\", \\\"{x:1562,y:1032,t:1527628157787};\\\", \\\"{x:1557,y:1031,t:1527628157803};\\\", \\\"{x:1553,y:1025,t:1527628157821};\\\", \\\"{x:1550,y:1020,t:1527628157838};\\\", \\\"{x:1543,y:1004,t:1527628157854};\\\", \\\"{x:1537,y:990,t:1527628157871};\\\", \\\"{x:1537,y:975,t:1527628157888};\\\", \\\"{x:1537,y:960,t:1527628157904};\\\", \\\"{x:1537,y:948,t:1527628157920};\\\", \\\"{x:1537,y:935,t:1527628157937};\\\", \\\"{x:1537,y:928,t:1527628157954};\\\", \\\"{x:1537,y:923,t:1527628157970};\\\", \\\"{x:1537,y:922,t:1527628157999};\\\", \\\"{x:1537,y:921,t:1527628158064};\\\", \\\"{x:1537,y:920,t:1527628158071};\\\", \\\"{x:1538,y:920,t:1527628158087};\\\", \\\"{x:1540,y:919,t:1527628158104};\\\", \\\"{x:1541,y:919,t:1527628158121};\\\", \\\"{x:1543,y:919,t:1527628158138};\\\", \\\"{x:1544,y:919,t:1527628158159};\\\", \\\"{x:1545,y:920,t:1527628158191};\\\", \\\"{x:1546,y:926,t:1527628158204};\\\", \\\"{x:1546,y:934,t:1527628158220};\\\", \\\"{x:1546,y:943,t:1527628158237};\\\", \\\"{x:1546,y:951,t:1527628158254};\\\", \\\"{x:1546,y:957,t:1527628158271};\\\", \\\"{x:1546,y:965,t:1527628158287};\\\", \\\"{x:1546,y:967,t:1527628158305};\\\", \\\"{x:1546,y:968,t:1527628158320};\\\", \\\"{x:1546,y:969,t:1527628158337};\\\", \\\"{x:1547,y:968,t:1527628158463};\\\", \\\"{x:1547,y:964,t:1527628158471};\\\", \\\"{x:1548,y:957,t:1527628158487};\\\", \\\"{x:1549,y:953,t:1527628158503};\\\", \\\"{x:1549,y:949,t:1527628158521};\\\", \\\"{x:1549,y:944,t:1527628158537};\\\", \\\"{x:1549,y:941,t:1527628158554};\\\", \\\"{x:1549,y:935,t:1527628158571};\\\", \\\"{x:1548,y:932,t:1527628158587};\\\", \\\"{x:1548,y:931,t:1527628158604};\\\", \\\"{x:1548,y:930,t:1527628158621};\\\", \\\"{x:1548,y:923,t:1527628158637};\\\", \\\"{x:1548,y:907,t:1527628158654};\\\", \\\"{x:1548,y:890,t:1527628158671};\\\", \\\"{x:1548,y:886,t:1527628158687};\\\", \\\"{x:1548,y:885,t:1527628158704};\\\", \\\"{x:1548,y:883,t:1527628158721};\\\", \\\"{x:1548,y:882,t:1527628158737};\\\", \\\"{x:1548,y:877,t:1527628158755};\\\", \\\"{x:1548,y:869,t:1527628158771};\\\", \\\"{x:1548,y:863,t:1527628158788};\\\", \\\"{x:1548,y:857,t:1527628158805};\\\", \\\"{x:1548,y:851,t:1527628158821};\\\", \\\"{x:1548,y:844,t:1527628158838};\\\", \\\"{x:1548,y:839,t:1527628158854};\\\", \\\"{x:1548,y:834,t:1527628158871};\\\", \\\"{x:1548,y:830,t:1527628158888};\\\", \\\"{x:1548,y:828,t:1527628158904};\\\", \\\"{x:1549,y:826,t:1527628158921};\\\", \\\"{x:1550,y:825,t:1527628158959};\\\", \\\"{x:1550,y:824,t:1527628158972};\\\", \\\"{x:1551,y:821,t:1527628158988};\\\", \\\"{x:1552,y:818,t:1527628159004};\\\", \\\"{x:1553,y:814,t:1527628159021};\\\", \\\"{x:1554,y:812,t:1527628159038};\\\", \\\"{x:1555,y:811,t:1527628159096};\\\", \\\"{x:1555,y:812,t:1527628159135};\\\", \\\"{x:1555,y:814,t:1527628159144};\\\", \\\"{x:1555,y:818,t:1527628159154};\\\", \\\"{x:1555,y:821,t:1527628159172};\\\", \\\"{x:1555,y:825,t:1527628159189};\\\", \\\"{x:1555,y:827,t:1527628159204};\\\", \\\"{x:1555,y:829,t:1527628159221};\\\", \\\"{x:1555,y:830,t:1527628159238};\\\", \\\"{x:1555,y:831,t:1527628159352};\\\", \\\"{x:1554,y:831,t:1527628159383};\\\", \\\"{x:1553,y:831,t:1527628159400};\\\", \\\"{x:1552,y:831,t:1527628159439};\\\", \\\"{x:1551,y:831,t:1527628159559};\\\", \\\"{x:1549,y:831,t:1527628159572};\\\", \\\"{x:1546,y:831,t:1527628159589};\\\", \\\"{x:1545,y:831,t:1527628159606};\\\", \\\"{x:1539,y:831,t:1527628159621};\\\", \\\"{x:1537,y:831,t:1527628159638};\\\", \\\"{x:1538,y:831,t:1527628159832};\\\", \\\"{x:1539,y:831,t:1527628159839};\\\", \\\"{x:1540,y:831,t:1527628159864};\\\", \\\"{x:1541,y:831,t:1527628159936};\\\", \\\"{x:1541,y:830,t:1527628159944};\\\", \\\"{x:1543,y:830,t:1527628160016};\\\", \\\"{x:1544,y:830,t:1527628160047};\\\", \\\"{x:1546,y:830,t:1527628160064};\\\", \\\"{x:1547,y:830,t:1527628160080};\\\", \\\"{x:1549,y:830,t:1527628160095};\\\", \\\"{x:1550,y:830,t:1527628160111};\\\", \\\"{x:1549,y:830,t:1527628161111};\\\", \\\"{x:1548,y:830,t:1527628161123};\\\", \\\"{x:1547,y:830,t:1527628161262};\\\", \\\"{x:1547,y:829,t:1527628161272};\\\", \\\"{x:1546,y:829,t:1527628161289};\\\", \\\"{x:1545,y:828,t:1527628161306};\\\", \\\"{x:1544,y:827,t:1527628162104};\\\", \\\"{x:1544,y:826,t:1527628163631};\\\", \\\"{x:1545,y:826,t:1527628163648};\\\", \\\"{x:1546,y:826,t:1527628163659};\\\", \\\"{x:1547,y:826,t:1527628163728};\\\", \\\"{x:1548,y:826,t:1527628163752};\\\", \\\"{x:1549,y:826,t:1527628163823};\\\", \\\"{x:1550,y:826,t:1527628163830};\\\", \\\"{x:1549,y:826,t:1527628165079};\\\", \\\"{x:1547,y:824,t:1527628165093};\\\", \\\"{x:1544,y:824,t:1527628165111};\\\", \\\"{x:1543,y:823,t:1527628165127};\\\", \\\"{x:1535,y:820,t:1527628165143};\\\", \\\"{x:1463,y:788,t:1527628165159};\\\", \\\"{x:1331,y:734,t:1527628165177};\\\", \\\"{x:1169,y:671,t:1527628165193};\\\", \\\"{x:989,y:614,t:1527628165209};\\\", \\\"{x:808,y:573,t:1527628165227};\\\", \\\"{x:662,y:554,t:1527628165242};\\\", \\\"{x:553,y:550,t:1527628165259};\\\", \\\"{x:511,y:550,t:1527628165277};\\\", \\\"{x:507,y:550,t:1527628165293};\\\", \\\"{x:512,y:555,t:1527628165472};\\\", \\\"{x:526,y:565,t:1527628165479};\\\", \\\"{x:536,y:572,t:1527628165493};\\\", \\\"{x:559,y:588,t:1527628165510};\\\", \\\"{x:563,y:592,t:1527628165526};\\\", \\\"{x:573,y:599,t:1527628165543};\\\", \\\"{x:579,y:601,t:1527628165560};\\\", \\\"{x:582,y:604,t:1527628165577};\\\", \\\"{x:583,y:605,t:1527628165593};\\\", \\\"{x:584,y:606,t:1527628165610};\\\", \\\"{x:585,y:606,t:1527628165628};\\\", \\\"{x:586,y:606,t:1527628165695};\\\", \\\"{x:590,y:607,t:1527628165711};\\\", \\\"{x:594,y:610,t:1527628165727};\\\", \\\"{x:597,y:611,t:1527628165743};\\\", \\\"{x:600,y:612,t:1527628165761};\\\", \\\"{x:600,y:613,t:1527628165894};\\\", \\\"{x:600,y:613,t:1527628165979};\\\", \\\"{x:599,y:614,t:1527628165994};\\\", \\\"{x:600,y:616,t:1527628166046};\\\", \\\"{x:608,y:619,t:1527628166060};\\\", \\\"{x:662,y:644,t:1527628166078};\\\", \\\"{x:780,y:695,t:1527628166095};\\\", \\\"{x:994,y:767,t:1527628166111};\\\", \\\"{x:1123,y:794,t:1527628166127};\\\", \\\"{x:1205,y:809,t:1527628166144};\\\", \\\"{x:1247,y:814,t:1527628166161};\\\", \\\"{x:1257,y:816,t:1527628166178};\\\", \\\"{x:1260,y:816,t:1527628166195};\\\", \\\"{x:1262,y:816,t:1527628166264};\\\", \\\"{x:1263,y:816,t:1527628166278};\\\", \\\"{x:1268,y:816,t:1527628166294};\\\", \\\"{x:1278,y:816,t:1527628166311};\\\", \\\"{x:1292,y:812,t:1527628166328};\\\", \\\"{x:1312,y:803,t:1527628166345};\\\", \\\"{x:1351,y:791,t:1527628166362};\\\", \\\"{x:1403,y:787,t:1527628166379};\\\", \\\"{x:1458,y:780,t:1527628166395};\\\", \\\"{x:1503,y:780,t:1527628166411};\\\", \\\"{x:1532,y:780,t:1527628166428};\\\", \\\"{x:1547,y:780,t:1527628166445};\\\", \\\"{x:1554,y:780,t:1527628166462};\\\", \\\"{x:1558,y:780,t:1527628166479};\\\", \\\"{x:1561,y:781,t:1527628166495};\\\", \\\"{x:1563,y:782,t:1527628166511};\\\", \\\"{x:1563,y:783,t:1527628166591};\\\", \\\"{x:1563,y:785,t:1527628166600};\\\", \\\"{x:1563,y:789,t:1527628166612};\\\", \\\"{x:1562,y:798,t:1527628166628};\\\", \\\"{x:1560,y:812,t:1527628166644};\\\", \\\"{x:1560,y:820,t:1527628166662};\\\", \\\"{x:1560,y:824,t:1527628166678};\\\", \\\"{x:1557,y:831,t:1527628166695};\\\", \\\"{x:1557,y:835,t:1527628166711};\\\", \\\"{x:1557,y:836,t:1527628166864};\\\", \\\"{x:1557,y:837,t:1527628166896};\\\", \\\"{x:1556,y:838,t:1527628166951};\\\", \\\"{x:1555,y:838,t:1527628167007};\\\", \\\"{x:1553,y:837,t:1527628167040};\\\", \\\"{x:1552,y:837,t:1527628167087};\\\", \\\"{x:1552,y:836,t:1527628167096};\\\", \\\"{x:1551,y:834,t:1527628167208};\\\", \\\"{x:1551,y:833,t:1527628167327};\\\", \\\"{x:1550,y:832,t:1527628167345};\\\", \\\"{x:1550,y:831,t:1527628167456};\\\", \\\"{x:1549,y:831,t:1527628167504};\\\", \\\"{x:1549,y:830,t:1527628167616};\\\", \\\"{x:1548,y:829,t:1527628167720};\\\", \\\"{x:1548,y:828,t:1527628167799};\\\", \\\"{x:1548,y:827,t:1527628167872};\\\", \\\"{x:1547,y:827,t:1527628168327};\\\", \\\"{x:1546,y:827,t:1527628168335};\\\", \\\"{x:1545,y:827,t:1527628168347};\\\", \\\"{x:1542,y:827,t:1527628168364};\\\", \\\"{x:1539,y:827,t:1527628168379};\\\", \\\"{x:1533,y:826,t:1527628168396};\\\", \\\"{x:1525,y:825,t:1527628168413};\\\", \\\"{x:1519,y:823,t:1527628168429};\\\", \\\"{x:1511,y:821,t:1527628168446};\\\", \\\"{x:1504,y:818,t:1527628168463};\\\", \\\"{x:1492,y:814,t:1527628168480};\\\", \\\"{x:1479,y:811,t:1527628168497};\\\", \\\"{x:1463,y:807,t:1527628168513};\\\", \\\"{x:1441,y:797,t:1527628168530};\\\", \\\"{x:1421,y:789,t:1527628168547};\\\", \\\"{x:1400,y:780,t:1527628168563};\\\", \\\"{x:1390,y:773,t:1527628168580};\\\", \\\"{x:1379,y:768,t:1527628168597};\\\", \\\"{x:1374,y:765,t:1527628168614};\\\", \\\"{x:1371,y:762,t:1527628168630};\\\", \\\"{x:1370,y:761,t:1527628168647};\\\", \\\"{x:1369,y:761,t:1527628168664};\\\", \\\"{x:1368,y:760,t:1527628168687};\\\", \\\"{x:1367,y:759,t:1527628168697};\\\", \\\"{x:1366,y:759,t:1527628168719};\\\", \\\"{x:1366,y:758,t:1527628168735};\\\", \\\"{x:1370,y:758,t:1527628168839};\\\", \\\"{x:1371,y:758,t:1527628168847};\\\", \\\"{x:1374,y:757,t:1527628168864};\\\", \\\"{x:1376,y:756,t:1527628168881};\\\", \\\"{x:1378,y:755,t:1527628168898};\\\", \\\"{x:1378,y:756,t:1527628169728};\\\", \\\"{x:1377,y:756,t:1527628169735};\\\", \\\"{x:1376,y:756,t:1527628177363};\\\", \\\"{x:1371,y:757,t:1527628177572};\\\", \\\"{x:1364,y:757,t:1527628177579};\\\", \\\"{x:1357,y:760,t:1527628177593};\\\", \\\"{x:1341,y:761,t:1527628177610};\\\", \\\"{x:1322,y:765,t:1527628177626};\\\", \\\"{x:1289,y:765,t:1527628177643};\\\", \\\"{x:1274,y:765,t:1527628177660};\\\", \\\"{x:1258,y:765,t:1527628177676};\\\", \\\"{x:1231,y:765,t:1527628177693};\\\", \\\"{x:1182,y:765,t:1527628177710};\\\", \\\"{x:1129,y:765,t:1527628177726};\\\", \\\"{x:1090,y:765,t:1527628177743};\\\", \\\"{x:1061,y:762,t:1527628177760};\\\", \\\"{x:1035,y:758,t:1527628177777};\\\", \\\"{x:1009,y:754,t:1527628177792};\\\", \\\"{x:984,y:751,t:1527628177810};\\\", \\\"{x:947,y:745,t:1527628177827};\\\", \\\"{x:928,y:743,t:1527628177843};\\\", \\\"{x:911,y:743,t:1527628177860};\\\", \\\"{x:896,y:743,t:1527628177877};\\\", \\\"{x:884,y:742,t:1527628177892};\\\", \\\"{x:867,y:741,t:1527628177910};\\\", \\\"{x:849,y:737,t:1527628177927};\\\", \\\"{x:835,y:736,t:1527628177943};\\\", \\\"{x:819,y:731,t:1527628177960};\\\", \\\"{x:802,y:729,t:1527628177977};\\\", \\\"{x:779,y:725,t:1527628177993};\\\", \\\"{x:754,y:720,t:1527628178010};\\\", \\\"{x:713,y:712,t:1527628178026};\\\", \\\"{x:685,y:706,t:1527628178043};\\\", \\\"{x:664,y:701,t:1527628178060};\\\", \\\"{x:649,y:697,t:1527628178077};\\\", \\\"{x:641,y:693,t:1527628178094};\\\", \\\"{x:639,y:693,t:1527628178110};\\\", \\\"{x:638,y:692,t:1527628178130};\\\", \\\"{x:636,y:691,t:1527628178147};\\\", \\\"{x:635,y:690,t:1527628178159};\\\", \\\"{x:634,y:689,t:1527628178219};\\\", \\\"{x:634,y:688,t:1527628178227};\\\", \\\"{x:634,y:685,t:1527628178244};\\\", \\\"{x:633,y:681,t:1527628178260};\\\", \\\"{x:633,y:676,t:1527628178276};\\\", \\\"{x:632,y:668,t:1527628178294};\\\", \\\"{x:631,y:659,t:1527628178311};\\\", \\\"{x:631,y:650,t:1527628178326};\\\", \\\"{x:631,y:647,t:1527628178343};\\\", \\\"{x:631,y:644,t:1527628178357};\\\", \\\"{x:631,y:640,t:1527628178372};\\\", \\\"{x:631,y:639,t:1527628178394};\\\", \\\"{x:631,y:638,t:1527628178406};\\\", \\\"{x:631,y:637,t:1527628178423};\\\", \\\"{x:627,y:637,t:1527628178554};\\\", \\\"{x:622,y:637,t:1527628178563};\\\", \\\"{x:618,y:637,t:1527628178574};\\\", \\\"{x:607,y:637,t:1527628178591};\\\", \\\"{x:600,y:637,t:1527628178607};\\\", \\\"{x:598,y:637,t:1527628178624};\\\", \\\"{x:594,y:637,t:1527628178640};\\\", \\\"{x:580,y:637,t:1527628178657};\\\", \\\"{x:565,y:637,t:1527628178674};\\\", \\\"{x:545,y:637,t:1527628178691};\\\", \\\"{x:524,y:638,t:1527628178708};\\\", \\\"{x:502,y:642,t:1527628178724};\\\", \\\"{x:490,y:644,t:1527628178742};\\\", \\\"{x:483,y:645,t:1527628178759};\\\", \\\"{x:481,y:645,t:1527628178774};\\\", \\\"{x:480,y:645,t:1527628178791};\\\", \\\"{x:479,y:645,t:1527628178809};\\\", \\\"{x:476,y:645,t:1527628178824};\\\", \\\"{x:473,y:643,t:1527628178842};\\\", \\\"{x:468,y:640,t:1527628178858};\\\", \\\"{x:466,y:639,t:1527628178876};\\\", \\\"{x:461,y:636,t:1527628178892};\\\", \\\"{x:455,y:634,t:1527628178908};\\\", \\\"{x:453,y:632,t:1527628178925};\\\", \\\"{x:452,y:631,t:1527628178941};\\\", \\\"{x:450,y:629,t:1527628178959};\\\", \\\"{x:446,y:626,t:1527628178977};\\\", \\\"{x:439,y:622,t:1527628178991};\\\", \\\"{x:425,y:615,t:1527628179008};\\\", \\\"{x:412,y:608,t:1527628179026};\\\", \\\"{x:398,y:600,t:1527628179042};\\\", \\\"{x:385,y:593,t:1527628179059};\\\", \\\"{x:367,y:585,t:1527628179076};\\\", \\\"{x:350,y:577,t:1527628179092};\\\", \\\"{x:330,y:568,t:1527628179108};\\\", \\\"{x:320,y:563,t:1527628179126};\\\", \\\"{x:322,y:563,t:1527628179219};\\\", \\\"{x:325,y:564,t:1527628179226};\\\", \\\"{x:330,y:565,t:1527628179241};\\\", \\\"{x:345,y:568,t:1527628179258};\\\", \\\"{x:349,y:569,t:1527628179276};\\\", \\\"{x:354,y:569,t:1527628179292};\\\", \\\"{x:358,y:569,t:1527628179308};\\\", \\\"{x:365,y:567,t:1527628179325};\\\", \\\"{x:368,y:567,t:1527628179342};\\\", \\\"{x:373,y:566,t:1527628179358};\\\", \\\"{x:376,y:564,t:1527628179377};\\\", \\\"{x:380,y:562,t:1527628179392};\\\", \\\"{x:384,y:560,t:1527628179408};\\\", \\\"{x:385,y:561,t:1527628179947};\\\", \\\"{x:395,y:566,t:1527628179959};\\\", \\\"{x:428,y:579,t:1527628179976};\\\", \\\"{x:495,y:598,t:1527628179993};\\\", \\\"{x:575,y:621,t:1527628180010};\\\", \\\"{x:662,y:646,t:1527628180026};\\\", \\\"{x:675,y:650,t:1527628180042};\\\", \\\"{x:675,y:651,t:1527628180162};\\\", \\\"{x:672,y:652,t:1527628180176};\\\", \\\"{x:664,y:652,t:1527628180193};\\\", \\\"{x:649,y:652,t:1527628180210};\\\", \\\"{x:622,y:652,t:1527628180227};\\\", \\\"{x:552,y:652,t:1527628180243};\\\", \\\"{x:504,y:652,t:1527628180259};\\\", \\\"{x:465,y:652,t:1527628180277};\\\", \\\"{x:442,y:652,t:1527628180293};\\\", \\\"{x:424,y:652,t:1527628180310};\\\", \\\"{x:413,y:650,t:1527628180327};\\\", \\\"{x:406,y:648,t:1527628180342};\\\", \\\"{x:403,y:646,t:1527628180359};\\\", \\\"{x:402,y:645,t:1527628180376};\\\", \\\"{x:400,y:642,t:1527628180392};\\\", \\\"{x:398,y:639,t:1527628180409};\\\", \\\"{x:394,y:631,t:1527628180426};\\\", \\\"{x:390,y:620,t:1527628180444};\\\", \\\"{x:390,y:614,t:1527628180459};\\\", \\\"{x:388,y:605,t:1527628180476};\\\", \\\"{x:385,y:590,t:1527628180494};\\\", \\\"{x:384,y:582,t:1527628180510};\\\", \\\"{x:384,y:579,t:1527628180526};\\\", \\\"{x:384,y:575,t:1527628180542};\\\", \\\"{x:384,y:573,t:1527628180559};\\\", \\\"{x:384,y:572,t:1527628180577};\\\", \\\"{x:384,y:571,t:1527628180592};\\\", \\\"{x:384,y:570,t:1527628180946};\\\", \\\"{x:392,y:570,t:1527628180960};\\\", \\\"{x:418,y:581,t:1527628180976};\\\", \\\"{x:464,y:594,t:1527628180994};\\\", \\\"{x:579,y:621,t:1527628181010};\\\", \\\"{x:648,y:639,t:1527628181027};\\\", \\\"{x:687,y:649,t:1527628181043};\\\", \\\"{x:721,y:660,t:1527628181060};\\\", \\\"{x:774,y:668,t:1527628181077};\\\", \\\"{x:844,y:678,t:1527628181094};\\\", \\\"{x:928,y:695,t:1527628181111};\\\", \\\"{x:1043,y:717,t:1527628181126};\\\", \\\"{x:1152,y:735,t:1527628181144};\\\", \\\"{x:1258,y:753,t:1527628181161};\\\", \\\"{x:1385,y:770,t:1527628181178};\\\", \\\"{x:1522,y:802,t:1527628181194};\\\", \\\"{x:1640,y:819,t:1527628181211};\\\", \\\"{x:1683,y:826,t:1527628181228};\\\", \\\"{x:1698,y:827,t:1527628181243};\\\", \\\"{x:1700,y:827,t:1527628181260};\\\", \\\"{x:1699,y:829,t:1527628181403};\\\", \\\"{x:1695,y:829,t:1527628181411};\\\", \\\"{x:1685,y:831,t:1527628181428};\\\", \\\"{x:1675,y:831,t:1527628181445};\\\", \\\"{x:1653,y:834,t:1527628181461};\\\", \\\"{x:1617,y:834,t:1527628181478};\\\", \\\"{x:1580,y:834,t:1527628181495};\\\", \\\"{x:1558,y:834,t:1527628181511};\\\", \\\"{x:1548,y:832,t:1527628181528};\\\", \\\"{x:1543,y:830,t:1527628181545};\\\", \\\"{x:1537,y:829,t:1527628181562};\\\", \\\"{x:1524,y:825,t:1527628181578};\\\", \\\"{x:1497,y:816,t:1527628181595};\\\", \\\"{x:1489,y:813,t:1527628181612};\\\", \\\"{x:1480,y:809,t:1527628181628};\\\", \\\"{x:1466,y:803,t:1527628181644};\\\", \\\"{x:1453,y:795,t:1527628181662};\\\", \\\"{x:1442,y:787,t:1527628181678};\\\", \\\"{x:1434,y:779,t:1527628181694};\\\", \\\"{x:1426,y:770,t:1527628181711};\\\", \\\"{x:1420,y:762,t:1527628181728};\\\", \\\"{x:1416,y:758,t:1527628181745};\\\", \\\"{x:1414,y:757,t:1527628181762};\\\", \\\"{x:1414,y:756,t:1527628181778};\\\", \\\"{x:1413,y:755,t:1527628181795};\\\", \\\"{x:1413,y:754,t:1527628181812};\\\", \\\"{x:1412,y:753,t:1527628181829};\\\", \\\"{x:1411,y:752,t:1527628181845};\\\", \\\"{x:1410,y:752,t:1527628182099};\\\", \\\"{x:1409,y:752,t:1527628182115};\\\", \\\"{x:1405,y:752,t:1527628182129};\\\", \\\"{x:1400,y:752,t:1527628182145};\\\", \\\"{x:1393,y:752,t:1527628182162};\\\", \\\"{x:1387,y:756,t:1527628182178};\\\", \\\"{x:1377,y:760,t:1527628182196};\\\", \\\"{x:1372,y:761,t:1527628182213};\\\", \\\"{x:1371,y:762,t:1527628182229};\\\", \\\"{x:1370,y:762,t:1527628182246};\\\", \\\"{x:1368,y:762,t:1527628182603};\\\", \\\"{x:1364,y:757,t:1527628182613};\\\", \\\"{x:1355,y:735,t:1527628182630};\\\", \\\"{x:1347,y:721,t:1527628182647};\\\", \\\"{x:1343,y:715,t:1527628182663};\\\", \\\"{x:1338,y:708,t:1527628182680};\\\", \\\"{x:1335,y:702,t:1527628182696};\\\", \\\"{x:1333,y:697,t:1527628182716};\\\", \\\"{x:1332,y:695,t:1527628182731};\\\", \\\"{x:1332,y:693,t:1527628182746};\\\", \\\"{x:1330,y:687,t:1527628182763};\\\", \\\"{x:1330,y:682,t:1527628182780};\\\", \\\"{x:1328,y:677,t:1527628182796};\\\", \\\"{x:1327,y:674,t:1527628182813};\\\", \\\"{x:1327,y:667,t:1527628182830};\\\", \\\"{x:1325,y:657,t:1527628182848};\\\", \\\"{x:1322,y:642,t:1527628182863};\\\", \\\"{x:1321,y:632,t:1527628182881};\\\", \\\"{x:1320,y:626,t:1527628182898};\\\", \\\"{x:1320,y:622,t:1527628182915};\\\", \\\"{x:1319,y:619,t:1527628182930};\\\", \\\"{x:1319,y:616,t:1527628182947};\\\", \\\"{x:1318,y:615,t:1527628182963};\\\", \\\"{x:1318,y:613,t:1527628182987};\\\", \\\"{x:1318,y:612,t:1527628183026};\\\", \\\"{x:1317,y:612,t:1527628183083};\\\", \\\"{x:1315,y:612,t:1527628183099};\\\", \\\"{x:1313,y:612,t:1527628183115};\\\", \\\"{x:1311,y:613,t:1527628183130};\\\", \\\"{x:1309,y:617,t:1527628183147};\\\", \\\"{x:1309,y:618,t:1527628183164};\\\", \\\"{x:1309,y:619,t:1527628183180};\\\", \\\"{x:1309,y:620,t:1527628183202};\\\", \\\"{x:1309,y:621,t:1527628183215};\\\", \\\"{x:1309,y:622,t:1527628183251};\\\", \\\"{x:1310,y:622,t:1527628183331};\\\", \\\"{x:1311,y:622,t:1527628183347};\\\", \\\"{x:1312,y:622,t:1527628183370};\\\", \\\"{x:1313,y:622,t:1527628183380};\\\", \\\"{x:1314,y:622,t:1527628183402};\\\", \\\"{x:1314,y:621,t:1527628183418};\\\", \\\"{x:1312,y:621,t:1527628188466};\\\", \\\"{x:1309,y:623,t:1527628188474};\\\", \\\"{x:1305,y:627,t:1527628188487};\\\", \\\"{x:1297,y:632,t:1527628188505};\\\", \\\"{x:1292,y:636,t:1527628188520};\\\", \\\"{x:1286,y:639,t:1527628188537};\\\", \\\"{x:1285,y:639,t:1527628188554};\\\", \\\"{x:1285,y:642,t:1527628188691};\\\", \\\"{x:1286,y:644,t:1527628188706};\\\", \\\"{x:1292,y:659,t:1527628188723};\\\", \\\"{x:1298,y:673,t:1527628188738};\\\", \\\"{x:1304,y:682,t:1527628188755};\\\", \\\"{x:1308,y:691,t:1527628188772};\\\", \\\"{x:1310,y:698,t:1527628188788};\\\", \\\"{x:1312,y:705,t:1527628188805};\\\", \\\"{x:1315,y:712,t:1527628188822};\\\", \\\"{x:1317,y:720,t:1527628188838};\\\", \\\"{x:1320,y:730,t:1527628188855};\\\", \\\"{x:1325,y:746,t:1527628188872};\\\", \\\"{x:1329,y:762,t:1527628188888};\\\", \\\"{x:1332,y:774,t:1527628188906};\\\", \\\"{x:1335,y:783,t:1527628188923};\\\", \\\"{x:1336,y:786,t:1527628188939};\\\", \\\"{x:1337,y:788,t:1527628188955};\\\", \\\"{x:1338,y:790,t:1527628188973};\\\", \\\"{x:1340,y:790,t:1527628188989};\\\", \\\"{x:1340,y:791,t:1527628189005};\\\", \\\"{x:1341,y:791,t:1527628189022};\\\", \\\"{x:1342,y:791,t:1527628189039};\\\", \\\"{x:1343,y:791,t:1527628189059};\\\", \\\"{x:1345,y:791,t:1527628189115};\\\", \\\"{x:1346,y:791,t:1527628189131};\\\", \\\"{x:1347,y:791,t:1527628189139};\\\", \\\"{x:1350,y:791,t:1527628189157};\\\", \\\"{x:1352,y:789,t:1527628189172};\\\", \\\"{x:1357,y:784,t:1527628189189};\\\", \\\"{x:1360,y:781,t:1527628189206};\\\", \\\"{x:1362,y:778,t:1527628189222};\\\", \\\"{x:1363,y:776,t:1527628189240};\\\", \\\"{x:1364,y:775,t:1527628189256};\\\", \\\"{x:1365,y:775,t:1527628189315};\\\", \\\"{x:1365,y:774,t:1527628189330};\\\", \\\"{x:1365,y:773,t:1527628189339};\\\", \\\"{x:1366,y:773,t:1527628189357};\\\", \\\"{x:1367,y:773,t:1527628193611};\\\", \\\"{x:1367,y:772,t:1527628193618};\\\", \\\"{x:1368,y:772,t:1527628193707};\\\", \\\"{x:1370,y:772,t:1527628193730};\\\", \\\"{x:1370,y:771,t:1527628193746};\\\", \\\"{x:1372,y:770,t:1527628193762};\\\", \\\"{x:1373,y:767,t:1527628193786};\\\", \\\"{x:1373,y:763,t:1527628193796};\\\", \\\"{x:1375,y:753,t:1527628193813};\\\", \\\"{x:1375,y:751,t:1527628193830};\\\", \\\"{x:1388,y:724,t:1527628193847};\\\", \\\"{x:1397,y:703,t:1527628193862};\\\", \\\"{x:1404,y:679,t:1527628193879};\\\", \\\"{x:1413,y:657,t:1527628193896};\\\", \\\"{x:1417,y:646,t:1527628193912};\\\", \\\"{x:1420,y:634,t:1527628193929};\\\", \\\"{x:1423,y:616,t:1527628193946};\\\", \\\"{x:1425,y:604,t:1527628193961};\\\", \\\"{x:1427,y:594,t:1527628193979};\\\", \\\"{x:1428,y:590,t:1527628193996};\\\", \\\"{x:1428,y:586,t:1527628194012};\\\", \\\"{x:1428,y:585,t:1527628194067};\\\", \\\"{x:1428,y:584,t:1527628194079};\\\", \\\"{x:1428,y:574,t:1527628194097};\\\", \\\"{x:1427,y:557,t:1527628194115};\\\", \\\"{x:1427,y:553,t:1527628194129};\\\", \\\"{x:1427,y:545,t:1527628194146};\\\", \\\"{x:1427,y:541,t:1527628194163};\\\", \\\"{x:1427,y:538,t:1527628194179};\\\", \\\"{x:1427,y:534,t:1527628194197};\\\", \\\"{x:1427,y:532,t:1527628194213};\\\", \\\"{x:1427,y:531,t:1527628194229};\\\", \\\"{x:1427,y:530,t:1527628194246};\\\", \\\"{x:1426,y:530,t:1527628194263};\\\", \\\"{x:1424,y:532,t:1527628194331};\\\", \\\"{x:1424,y:538,t:1527628194347};\\\", \\\"{x:1423,y:544,t:1527628194363};\\\", \\\"{x:1423,y:550,t:1527628194381};\\\", \\\"{x:1422,y:554,t:1527628194396};\\\", \\\"{x:1421,y:556,t:1527628194414};\\\", \\\"{x:1421,y:557,t:1527628194430};\\\", \\\"{x:1421,y:558,t:1527628194467};\\\", \\\"{x:1421,y:559,t:1527628194481};\\\", \\\"{x:1421,y:560,t:1527628194496};\\\", \\\"{x:1420,y:563,t:1527628194514};\\\", \\\"{x:1420,y:564,t:1527628194531};\\\", \\\"{x:1419,y:566,t:1527628194546};\\\", \\\"{x:1418,y:568,t:1527628194587};\\\", \\\"{x:1417,y:570,t:1527628194610};\\\", \\\"{x:1416,y:570,t:1527628194723};\\\", \\\"{x:1416,y:568,t:1527628194867};\\\", \\\"{x:1416,y:567,t:1527628194881};\\\", \\\"{x:1416,y:565,t:1527628195418};\\\", \\\"{x:1416,y:564,t:1527628195442};\\\", \\\"{x:1417,y:564,t:1527628195458};\\\", \\\"{x:1418,y:562,t:1527628195498};\\\", \\\"{x:1415,y:565,t:1527628197098};\\\", \\\"{x:1405,y:573,t:1527628197107};\\\", \\\"{x:1389,y:584,t:1527628197117};\\\", \\\"{x:1328,y:626,t:1527628197135};\\\", \\\"{x:1259,y:671,t:1527628197151};\\\", \\\"{x:1178,y:726,t:1527628197167};\\\", \\\"{x:1119,y:769,t:1527628197185};\\\", \\\"{x:1069,y:804,t:1527628197200};\\\", \\\"{x:1039,y:821,t:1527628197218};\\\", \\\"{x:1024,y:828,t:1527628197234};\\\", \\\"{x:1020,y:828,t:1527628197251};\\\", \\\"{x:1017,y:828,t:1527628197267};\\\", \\\"{x:1006,y:830,t:1527628197284};\\\", \\\"{x:987,y:830,t:1527628197300};\\\", \\\"{x:938,y:827,t:1527628197318};\\\", \\\"{x:852,y:813,t:1527628197335};\\\", \\\"{x:771,y:801,t:1527628197351};\\\", \\\"{x:685,y:789,t:1527628197367};\\\", \\\"{x:619,y:782,t:1527628197384};\\\", \\\"{x:571,y:782,t:1527628197402};\\\", \\\"{x:532,y:777,t:1527628197418};\\\", \\\"{x:508,y:773,t:1527628197434};\\\", \\\"{x:504,y:773,t:1527628197452};\\\", \\\"{x:500,y:772,t:1527628197468};\\\", \\\"{x:496,y:771,t:1527628197484};\\\", \\\"{x:494,y:770,t:1527628197501};\\\", \\\"{x:493,y:769,t:1527628197518};\\\", \\\"{x:492,y:768,t:1527628197579};\\\", \\\"{x:492,y:767,t:1527628197586};\\\", \\\"{x:492,y:763,t:1527628197602};\\\", \\\"{x:492,y:751,t:1527628197618};\\\", \\\"{x:494,y:745,t:1527628197636};\\\", \\\"{x:498,y:736,t:1527628197651};\\\", \\\"{x:502,y:729,t:1527628197668};\\\", \\\"{x:503,y:726,t:1527628197684};\\\", \\\"{x:504,y:724,t:1527628197702};\\\", \\\"{x:505,y:724,t:1527628198041};\\\", \\\"{x:505,y:726,t:1527628198057};\\\", \\\"{x:505,y:729,t:1527628198073};\\\", \\\"{x:505,y:732,t:1527628198091};\\\", \\\"{x:504,y:733,t:1527628198107};\\\" ] }, { \\\"rt\\\": 19676, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 341585, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:734,t:1527628200563};\\\", \\\"{x:505,y:734,t:1527628200643};\\\", \\\"{x:506,y:734,t:1527628201370};\\\", \\\"{x:507,y:734,t:1527628201378};\\\", \\\"{x:508,y:734,t:1527628201394};\\\", \\\"{x:520,y:733,t:1527628201410};\\\", \\\"{x:528,y:733,t:1527628201427};\\\", \\\"{x:551,y:729,t:1527628201444};\\\", \\\"{x:610,y:729,t:1527628201462};\\\", \\\"{x:693,y:729,t:1527628201477};\\\", \\\"{x:791,y:748,t:1527628201493};\\\", \\\"{x:899,y:774,t:1527628201509};\\\", \\\"{x:986,y:791,t:1527628201526};\\\", \\\"{x:1053,y:802,t:1527628201542};\\\", \\\"{x:1122,y:810,t:1527628201559};\\\", \\\"{x:1195,y:823,t:1527628201576};\\\", \\\"{x:1273,y:834,t:1527628201593};\\\", \\\"{x:1381,y:862,t:1527628201609};\\\", \\\"{x:1467,y:874,t:1527628201625};\\\", \\\"{x:1570,y:891,t:1527628201642};\\\", \\\"{x:1673,y:907,t:1527628201660};\\\", \\\"{x:1762,y:918,t:1527628201677};\\\", \\\"{x:1809,y:924,t:1527628201692};\\\", \\\"{x:1819,y:925,t:1527628201709};\\\", \\\"{x:1820,y:925,t:1527628201727};\\\", \\\"{x:1814,y:925,t:1527628202091};\\\", \\\"{x:1803,y:925,t:1527628202099};\\\", \\\"{x:1789,y:925,t:1527628202110};\\\", \\\"{x:1738,y:925,t:1527628202126};\\\", \\\"{x:1654,y:923,t:1527628202143};\\\", \\\"{x:1573,y:923,t:1527628202160};\\\", \\\"{x:1504,y:923,t:1527628202177};\\\", \\\"{x:1456,y:923,t:1527628202193};\\\", \\\"{x:1418,y:926,t:1527628202210};\\\", \\\"{x:1403,y:929,t:1527628202226};\\\", \\\"{x:1401,y:930,t:1527628202243};\\\", \\\"{x:1399,y:931,t:1527628206042};\\\", \\\"{x:1398,y:933,t:1527628206061};\\\", \\\"{x:1397,y:936,t:1527628206077};\\\", \\\"{x:1395,y:939,t:1527628206094};\\\", \\\"{x:1395,y:941,t:1527628206112};\\\", \\\"{x:1395,y:942,t:1527628206127};\\\", \\\"{x:1394,y:942,t:1527628206144};\\\", \\\"{x:1394,y:943,t:1527628206202};\\\", \\\"{x:1394,y:944,t:1527628206218};\\\", \\\"{x:1394,y:945,t:1527628206242};\\\", \\\"{x:1394,y:946,t:1527628208339};\\\", \\\"{x:1394,y:947,t:1527628208931};\\\", \\\"{x:1394,y:948,t:1527628208961};\\\", \\\"{x:1394,y:949,t:1527628208977};\\\", \\\"{x:1392,y:950,t:1527628209009};\\\", \\\"{x:1392,y:952,t:1527628210467};\\\", \\\"{x:1393,y:953,t:1527628210818};\\\", \\\"{x:1393,y:955,t:1527628210834};\\\", \\\"{x:1393,y:956,t:1527628210850};\\\", \\\"{x:1395,y:957,t:1527628210866};\\\", \\\"{x:1395,y:959,t:1527628210879};\\\", \\\"{x:1396,y:959,t:1527628210895};\\\", \\\"{x:1399,y:960,t:1527628210912};\\\", \\\"{x:1401,y:961,t:1527628210927};\\\", \\\"{x:1407,y:963,t:1527628210945};\\\", \\\"{x:1413,y:966,t:1527628210960};\\\", \\\"{x:1422,y:970,t:1527628210977};\\\", \\\"{x:1426,y:972,t:1527628210995};\\\", \\\"{x:1429,y:973,t:1527628211011};\\\", \\\"{x:1429,y:974,t:1527628211027};\\\", \\\"{x:1430,y:974,t:1527628211044};\\\", \\\"{x:1430,y:975,t:1527628214035};\\\", \\\"{x:1426,y:977,t:1527628214045};\\\", \\\"{x:1400,y:977,t:1527628214062};\\\", \\\"{x:1359,y:970,t:1527628214080};\\\", \\\"{x:1306,y:954,t:1527628214096};\\\", \\\"{x:1244,y:924,t:1527628214112};\\\", \\\"{x:1199,y:892,t:1527628214129};\\\", \\\"{x:1168,y:879,t:1527628214145};\\\", \\\"{x:1159,y:873,t:1527628214162};\\\", \\\"{x:1156,y:862,t:1527628214179};\\\", \\\"{x:1153,y:849,t:1527628214195};\\\", \\\"{x:1153,y:843,t:1527628214212};\\\", \\\"{x:1153,y:829,t:1527628214229};\\\", \\\"{x:1158,y:807,t:1527628214245};\\\", \\\"{x:1162,y:786,t:1527628214262};\\\", \\\"{x:1162,y:770,t:1527628214279};\\\", \\\"{x:1163,y:753,t:1527628214296};\\\", \\\"{x:1163,y:728,t:1527628214312};\\\", \\\"{x:1162,y:711,t:1527628214329};\\\", \\\"{x:1156,y:696,t:1527628214345};\\\", \\\"{x:1142,y:669,t:1527628214363};\\\", \\\"{x:1127,y:646,t:1527628214379};\\\", \\\"{x:1114,y:627,t:1527628214395};\\\", \\\"{x:1099,y:605,t:1527628214412};\\\", \\\"{x:1092,y:593,t:1527628214429};\\\", \\\"{x:1088,y:587,t:1527628214445};\\\", \\\"{x:1086,y:585,t:1527628214462};\\\", \\\"{x:1085,y:583,t:1527628214479};\\\", \\\"{x:1084,y:581,t:1527628214496};\\\", \\\"{x:1082,y:577,t:1527628214513};\\\", \\\"{x:1082,y:573,t:1527628214529};\\\", \\\"{x:1082,y:570,t:1527628214545};\\\", \\\"{x:1082,y:569,t:1527628214562};\\\", \\\"{x:1082,y:568,t:1527628214579};\\\", \\\"{x:1082,y:566,t:1527628214595};\\\", \\\"{x:1083,y:566,t:1527628214612};\\\", \\\"{x:1084,y:565,t:1527628214629};\\\", \\\"{x:1087,y:563,t:1527628214645};\\\", \\\"{x:1092,y:563,t:1527628214662};\\\", \\\"{x:1098,y:563,t:1527628214679};\\\", \\\"{x:1105,y:563,t:1527628214695};\\\", \\\"{x:1117,y:563,t:1527628214712};\\\", \\\"{x:1134,y:563,t:1527628214729};\\\", \\\"{x:1154,y:563,t:1527628214746};\\\", \\\"{x:1184,y:563,t:1527628214762};\\\", \\\"{x:1205,y:563,t:1527628214779};\\\", \\\"{x:1230,y:563,t:1527628214795};\\\", \\\"{x:1258,y:568,t:1527628214812};\\\", \\\"{x:1298,y:572,t:1527628214829};\\\", \\\"{x:1338,y:579,t:1527628214845};\\\", \\\"{x:1380,y:584,t:1527628214861};\\\", \\\"{x:1411,y:589,t:1527628214878};\\\", \\\"{x:1429,y:593,t:1527628214895};\\\", \\\"{x:1439,y:595,t:1527628214912};\\\", \\\"{x:1441,y:596,t:1527628214929};\\\", \\\"{x:1441,y:598,t:1527628214944};\\\", \\\"{x:1429,y:607,t:1527628214961};\\\", \\\"{x:1407,y:616,t:1527628214979};\\\", \\\"{x:1365,y:623,t:1527628214995};\\\", \\\"{x:1307,y:631,t:1527628215012};\\\", \\\"{x:1248,y:639,t:1527628215029};\\\", \\\"{x:1200,y:639,t:1527628215045};\\\", \\\"{x:1147,y:639,t:1527628215061};\\\", \\\"{x:1086,y:639,t:1527628215079};\\\", \\\"{x:1044,y:639,t:1527628215095};\\\", \\\"{x:1017,y:639,t:1527628215111};\\\", \\\"{x:1000,y:640,t:1527628215129};\\\", \\\"{x:986,y:642,t:1527628215145};\\\", \\\"{x:960,y:645,t:1527628215161};\\\", \\\"{x:946,y:647,t:1527628215178};\\\", \\\"{x:921,y:647,t:1527628215194};\\\", \\\"{x:888,y:647,t:1527628215211};\\\", \\\"{x:857,y:647,t:1527628215228};\\\", \\\"{x:819,y:647,t:1527628215245};\\\", \\\"{x:772,y:641,t:1527628215261};\\\", \\\"{x:711,y:633,t:1527628215278};\\\", \\\"{x:650,y:618,t:1527628215295};\\\", \\\"{x:583,y:598,t:1527628215312};\\\", \\\"{x:522,y:581,t:1527628215321};\\\", \\\"{x:485,y:569,t:1527628215338};\\\", \\\"{x:454,y:563,t:1527628215355};\\\", \\\"{x:433,y:561,t:1527628215372};\\\", \\\"{x:420,y:558,t:1527628215389};\\\", \\\"{x:411,y:557,t:1527628215404};\\\", \\\"{x:409,y:557,t:1527628215422};\\\", \\\"{x:405,y:557,t:1527628215438};\\\", \\\"{x:396,y:557,t:1527628215455};\\\", \\\"{x:379,y:554,t:1527628215472};\\\", \\\"{x:360,y:554,t:1527628215489};\\\", \\\"{x:339,y:553,t:1527628215504};\\\", \\\"{x:306,y:550,t:1527628215521};\\\", \\\"{x:285,y:546,t:1527628215538};\\\", \\\"{x:270,y:546,t:1527628215555};\\\", \\\"{x:262,y:546,t:1527628215572};\\\", \\\"{x:256,y:546,t:1527628215589};\\\", \\\"{x:255,y:546,t:1527628215605};\\\", \\\"{x:254,y:546,t:1527628215621};\\\", \\\"{x:256,y:546,t:1527628215722};\\\", \\\"{x:262,y:543,t:1527628215739};\\\", \\\"{x:270,y:538,t:1527628215756};\\\", \\\"{x:285,y:528,t:1527628215772};\\\", \\\"{x:298,y:518,t:1527628215788};\\\", \\\"{x:309,y:509,t:1527628215806};\\\", \\\"{x:324,y:501,t:1527628215822};\\\", \\\"{x:345,y:495,t:1527628215839};\\\", \\\"{x:360,y:491,t:1527628215856};\\\", \\\"{x:364,y:490,t:1527628215872};\\\", \\\"{x:366,y:488,t:1527628215889};\\\", \\\"{x:368,y:488,t:1527628215905};\\\", \\\"{x:369,y:488,t:1527628215922};\\\", \\\"{x:371,y:487,t:1527628215939};\\\", \\\"{x:378,y:487,t:1527628215955};\\\", \\\"{x:392,y:487,t:1527628215971};\\\", \\\"{x:408,y:487,t:1527628215988};\\\", \\\"{x:422,y:487,t:1527628216005};\\\", \\\"{x:433,y:487,t:1527628216021};\\\", \\\"{x:440,y:487,t:1527628216038};\\\", \\\"{x:448,y:487,t:1527628216055};\\\", \\\"{x:463,y:487,t:1527628216071};\\\", \\\"{x:473,y:487,t:1527628216088};\\\", \\\"{x:486,y:486,t:1527628216106};\\\", \\\"{x:492,y:485,t:1527628216122};\\\", \\\"{x:499,y:485,t:1527628216139};\\\", \\\"{x:521,y:485,t:1527628216156};\\\", \\\"{x:541,y:485,t:1527628216172};\\\", \\\"{x:564,y:486,t:1527628216189};\\\", \\\"{x:586,y:487,t:1527628216206};\\\", \\\"{x:604,y:487,t:1527628216222};\\\", \\\"{x:613,y:487,t:1527628216239};\\\", \\\"{x:615,y:487,t:1527628216256};\\\", \\\"{x:616,y:487,t:1527628216273};\\\", \\\"{x:618,y:487,t:1527628216289};\\\", \\\"{x:620,y:487,t:1527628216305};\\\", \\\"{x:621,y:487,t:1527628216322};\\\", \\\"{x:621,y:488,t:1527628216353};\\\", \\\"{x:622,y:488,t:1527628216361};\\\", \\\"{x:623,y:489,t:1527628216372};\\\", \\\"{x:624,y:489,t:1527628216389};\\\", \\\"{x:624,y:490,t:1527628216406};\\\", \\\"{x:624,y:492,t:1527628216422};\\\", \\\"{x:624,y:494,t:1527628216438};\\\", \\\"{x:624,y:495,t:1527628216456};\\\", \\\"{x:624,y:497,t:1527628216521};\\\", \\\"{x:624,y:498,t:1527628216554};\\\", \\\"{x:623,y:498,t:1527628216562};\\\", \\\"{x:622,y:499,t:1527628216594};\\\", \\\"{x:621,y:499,t:1527628216610};\\\", \\\"{x:620,y:499,t:1527628216623};\\\", \\\"{x:620,y:500,t:1527628216639};\\\", \\\"{x:619,y:500,t:1527628216656};\\\", \\\"{x:620,y:501,t:1527628217122};\\\", \\\"{x:621,y:501,t:1527628217155};\\\", \\\"{x:622,y:501,t:1527628217186};\\\", \\\"{x:624,y:501,t:1527628217194};\\\", \\\"{x:626,y:502,t:1527628217207};\\\", \\\"{x:630,y:502,t:1527628217223};\\\", \\\"{x:639,y:502,t:1527628217240};\\\", \\\"{x:651,y:502,t:1527628217258};\\\", \\\"{x:668,y:502,t:1527628217272};\\\", \\\"{x:695,y:502,t:1527628217290};\\\", \\\"{x:711,y:502,t:1527628217307};\\\", \\\"{x:731,y:504,t:1527628217325};\\\", \\\"{x:755,y:510,t:1527628217339};\\\", \\\"{x:778,y:517,t:1527628217357};\\\", \\\"{x:799,y:524,t:1527628217375};\\\", \\\"{x:808,y:526,t:1527628217390};\\\", \\\"{x:819,y:531,t:1527628217407};\\\", \\\"{x:827,y:536,t:1527628217423};\\\", \\\"{x:833,y:540,t:1527628217440};\\\", \\\"{x:834,y:541,t:1527628217456};\\\", \\\"{x:835,y:542,t:1527628217473};\\\", \\\"{x:835,y:543,t:1527628217489};\\\", \\\"{x:835,y:544,t:1527628217507};\\\", \\\"{x:835,y:546,t:1527628217523};\\\", \\\"{x:835,y:547,t:1527628217540};\\\", \\\"{x:834,y:550,t:1527628217557};\\\", \\\"{x:828,y:553,t:1527628217573};\\\", \\\"{x:827,y:554,t:1527628217589};\\\", \\\"{x:826,y:554,t:1527628217674};\\\", \\\"{x:823,y:557,t:1527628217987};\\\", \\\"{x:807,y:567,t:1527628218007};\\\", \\\"{x:784,y:580,t:1527628218024};\\\", \\\"{x:762,y:593,t:1527628218041};\\\", \\\"{x:742,y:608,t:1527628218058};\\\", \\\"{x:740,y:609,t:1527628218073};\\\", \\\"{x:742,y:608,t:1527628218121};\\\", \\\"{x:749,y:602,t:1527628218129};\\\", \\\"{x:756,y:595,t:1527628218141};\\\", \\\"{x:775,y:581,t:1527628218159};\\\", \\\"{x:794,y:567,t:1527628218174};\\\", \\\"{x:807,y:558,t:1527628218191};\\\", \\\"{x:819,y:552,t:1527628218208};\\\", \\\"{x:826,y:549,t:1527628218224};\\\", \\\"{x:830,y:548,t:1527628218241};\\\", \\\"{x:832,y:547,t:1527628218258};\\\", \\\"{x:833,y:546,t:1527628218273};\\\", \\\"{x:833,y:547,t:1527628218433};\\\", \\\"{x:833,y:548,t:1527628218441};\\\", \\\"{x:833,y:549,t:1527628218456};\\\", \\\"{x:833,y:550,t:1527628218474};\\\", \\\"{x:833,y:551,t:1527628218490};\\\", \\\"{x:833,y:552,t:1527628218507};\\\", \\\"{x:824,y:561,t:1527628218525};\\\", \\\"{x:803,y:576,t:1527628218541};\\\", \\\"{x:754,y:617,t:1527628218559};\\\", \\\"{x:692,y:679,t:1527628218575};\\\", \\\"{x:633,y:733,t:1527628218591};\\\", \\\"{x:588,y:775,t:1527628218607};\\\", \\\"{x:565,y:791,t:1527628218624};\\\", \\\"{x:551,y:800,t:1527628218640};\\\", \\\"{x:542,y:804,t:1527628218657};\\\", \\\"{x:541,y:804,t:1527628218674};\\\", \\\"{x:541,y:803,t:1527628218778};\\\", \\\"{x:541,y:802,t:1527628218791};\\\", \\\"{x:541,y:797,t:1527628218808};\\\", \\\"{x:541,y:780,t:1527628218826};\\\", \\\"{x:541,y:758,t:1527628218841};\\\", \\\"{x:541,y:740,t:1527628218859};\\\", \\\"{x:541,y:732,t:1527628218874};\\\", \\\"{x:541,y:729,t:1527628218890};\\\", \\\"{x:541,y:725,t:1527628218908};\\\", \\\"{x:541,y:722,t:1527628218925};\\\", \\\"{x:541,y:721,t:1527628218942};\\\", \\\"{x:541,y:720,t:1527628219185};\\\", \\\"{x:541,y:718,t:1527628220026};\\\", \\\"{x:550,y:712,t:1527628220042};\\\", \\\"{x:554,y:710,t:1527628220059};\\\", \\\"{x:557,y:708,t:1527628220075};\\\", \\\"{x:559,y:708,t:1527628220104};\\\" ] }, { \\\"rt\\\": 18240, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 361044, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:709,t:1527628221642};\\\", \\\"{x:557,y:710,t:1527628221681};\\\", \\\"{x:556,y:711,t:1527628221694};\\\", \\\"{x:555,y:712,t:1527628221710};\\\", \\\"{x:552,y:714,t:1527628221727};\\\", \\\"{x:551,y:715,t:1527628221743};\\\", \\\"{x:550,y:716,t:1527628221760};\\\", \\\"{x:549,y:716,t:1527628221793};\\\", \\\"{x:548,y:717,t:1527628221841};\\\", \\\"{x:547,y:717,t:1527628221865};\\\", \\\"{x:547,y:718,t:1527628221929};\\\", \\\"{x:546,y:719,t:1527628221977};\\\", \\\"{x:545,y:720,t:1527628222049};\\\", \\\"{x:543,y:722,t:1527628222153};\\\", \\\"{x:542,y:723,t:1527628222200};\\\", \\\"{x:541,y:724,t:1527628222233};\\\", \\\"{x:540,y:725,t:1527628222249};\\\", \\\"{x:539,y:726,t:1527628222265};\\\", \\\"{x:538,y:727,t:1527628222313};\\\", \\\"{x:537,y:728,t:1527628222344};\\\", \\\"{x:536,y:729,t:1527628222401};\\\", \\\"{x:539,y:729,t:1527628224290};\\\", \\\"{x:546,y:729,t:1527628224298};\\\", \\\"{x:552,y:729,t:1527628224313};\\\", \\\"{x:575,y:720,t:1527628224331};\\\", \\\"{x:595,y:709,t:1527628224346};\\\", \\\"{x:612,y:696,t:1527628224362};\\\", \\\"{x:621,y:684,t:1527628224379};\\\", \\\"{x:628,y:677,t:1527628224396};\\\", \\\"{x:640,y:669,t:1527628224412};\\\", \\\"{x:659,y:658,t:1527628224429};\\\", \\\"{x:696,y:645,t:1527628224446};\\\", \\\"{x:782,y:632,t:1527628224462};\\\", \\\"{x:923,y:613,t:1527628224479};\\\", \\\"{x:1111,y:613,t:1527628224497};\\\", \\\"{x:1445,y:639,t:1527628224513};\\\", \\\"{x:1671,y:667,t:1527628224529};\\\", \\\"{x:1893,y:679,t:1527628224545};\\\", \\\"{x:1919,y:688,t:1527628224563};\\\", \\\"{x:1919,y:707,t:1527628224578};\\\", \\\"{x:1919,y:718,t:1527628224596};\\\", \\\"{x:1919,y:724,t:1527628224612};\\\", \\\"{x:1919,y:725,t:1527628224629};\\\", \\\"{x:1919,y:726,t:1527628224698};\\\", \\\"{x:1919,y:727,t:1527628224712};\\\", \\\"{x:1918,y:730,t:1527628224729};\\\", \\\"{x:1915,y:731,t:1527628224746};\\\", \\\"{x:1914,y:732,t:1527628224762};\\\", \\\"{x:1913,y:733,t:1527628224779};\\\", \\\"{x:1912,y:733,t:1527628224795};\\\", \\\"{x:1911,y:734,t:1527628224812};\\\", \\\"{x:1910,y:735,t:1527628224829};\\\", \\\"{x:1907,y:737,t:1527628224845};\\\", \\\"{x:1904,y:740,t:1527628224862};\\\", \\\"{x:1901,y:742,t:1527628224879};\\\", \\\"{x:1899,y:743,t:1527628224896};\\\", \\\"{x:1895,y:745,t:1527628224913};\\\", \\\"{x:1883,y:750,t:1527628224930};\\\", \\\"{x:1874,y:755,t:1527628224947};\\\", \\\"{x:1867,y:760,t:1527628224964};\\\", \\\"{x:1858,y:768,t:1527628224980};\\\", \\\"{x:1850,y:780,t:1527628224998};\\\", \\\"{x:1833,y:795,t:1527628225014};\\\", \\\"{x:1817,y:810,t:1527628225030};\\\", \\\"{x:1800,y:820,t:1527628225048};\\\", \\\"{x:1784,y:829,t:1527628225063};\\\", \\\"{x:1777,y:834,t:1527628225081};\\\", \\\"{x:1767,y:840,t:1527628225098};\\\", \\\"{x:1761,y:841,t:1527628225114};\\\", \\\"{x:1757,y:843,t:1527628225130};\\\", \\\"{x:1755,y:844,t:1527628225148};\\\", \\\"{x:1753,y:845,t:1527628225164};\\\", \\\"{x:1751,y:846,t:1527628225180};\\\", \\\"{x:1749,y:847,t:1527628225198};\\\", \\\"{x:1745,y:848,t:1527628225214};\\\", \\\"{x:1744,y:849,t:1527628225230};\\\", \\\"{x:1743,y:850,t:1527628225257};\\\", \\\"{x:1742,y:850,t:1527628225280};\\\", \\\"{x:1741,y:850,t:1527628225296};\\\", \\\"{x:1740,y:851,t:1527628225314};\\\", \\\"{x:1739,y:851,t:1527628225354};\\\", \\\"{x:1739,y:852,t:1527628225442};\\\", \\\"{x:1738,y:852,t:1527628230425};\\\", \\\"{x:1735,y:852,t:1527628231354};\\\", \\\"{x:1732,y:853,t:1527628231362};\\\", \\\"{x:1731,y:854,t:1527628231375};\\\", \\\"{x:1722,y:857,t:1527628231391};\\\", \\\"{x:1711,y:858,t:1527628231408};\\\", \\\"{x:1700,y:858,t:1527628231425};\\\", \\\"{x:1685,y:858,t:1527628231441};\\\", \\\"{x:1661,y:855,t:1527628231457};\\\", \\\"{x:1649,y:847,t:1527628231475};\\\", \\\"{x:1633,y:838,t:1527628231491};\\\", \\\"{x:1610,y:827,t:1527628231508};\\\", \\\"{x:1580,y:814,t:1527628231524};\\\", \\\"{x:1542,y:797,t:1527628231541};\\\", \\\"{x:1519,y:788,t:1527628231557};\\\", \\\"{x:1491,y:776,t:1527628231575};\\\", \\\"{x:1452,y:759,t:1527628231591};\\\", \\\"{x:1400,y:738,t:1527628231607};\\\", \\\"{x:1342,y:712,t:1527628231625};\\\", \\\"{x:1246,y:679,t:1527628231641};\\\", \\\"{x:1182,y:661,t:1527628231659};\\\", \\\"{x:1110,y:642,t:1527628231675};\\\", \\\"{x:1032,y:617,t:1527628231692};\\\", \\\"{x:965,y:605,t:1527628231709};\\\", \\\"{x:925,y:600,t:1527628231725};\\\", \\\"{x:895,y:599,t:1527628231741};\\\", \\\"{x:871,y:599,t:1527628231759};\\\", \\\"{x:851,y:599,t:1527628231775};\\\", \\\"{x:831,y:599,t:1527628231792};\\\", \\\"{x:816,y:603,t:1527628231810};\\\", \\\"{x:805,y:607,t:1527628231824};\\\", \\\"{x:785,y:619,t:1527628231841};\\\", \\\"{x:779,y:625,t:1527628231851};\\\", \\\"{x:764,y:635,t:1527628231868};\\\", \\\"{x:750,y:647,t:1527628231884};\\\", \\\"{x:735,y:658,t:1527628231901};\\\", \\\"{x:725,y:666,t:1527628231918};\\\", \\\"{x:714,y:674,t:1527628231935};\\\", \\\"{x:706,y:679,t:1527628231952};\\\", \\\"{x:699,y:684,t:1527628231968};\\\", \\\"{x:685,y:695,t:1527628231985};\\\", \\\"{x:676,y:704,t:1527628232002};\\\", \\\"{x:671,y:707,t:1527628232019};\\\", \\\"{x:667,y:710,t:1527628232036};\\\", \\\"{x:666,y:711,t:1527628232053};\\\", \\\"{x:665,y:711,t:1527628232073};\\\", \\\"{x:664,y:711,t:1527628232113};\\\", \\\"{x:663,y:711,t:1527628232162};\\\", \\\"{x:662,y:711,t:1527628232177};\\\", \\\"{x:660,y:711,t:1527628232185};\\\", \\\"{x:656,y:711,t:1527628232203};\\\", \\\"{x:649,y:709,t:1527628232219};\\\", \\\"{x:645,y:706,t:1527628232235};\\\", \\\"{x:638,y:702,t:1527628232252};\\\", \\\"{x:625,y:697,t:1527628232269};\\\", \\\"{x:610,y:691,t:1527628232286};\\\", \\\"{x:594,y:685,t:1527628232302};\\\", \\\"{x:574,y:676,t:1527628232319};\\\", \\\"{x:555,y:669,t:1527628232335};\\\", \\\"{x:540,y:663,t:1527628232352};\\\", \\\"{x:527,y:657,t:1527628232369};\\\", \\\"{x:523,y:655,t:1527628232385};\\\", \\\"{x:514,y:649,t:1527628232403};\\\", \\\"{x:497,y:641,t:1527628232421};\\\", \\\"{x:483,y:632,t:1527628232437};\\\", \\\"{x:470,y:626,t:1527628232452};\\\", \\\"{x:454,y:619,t:1527628232469};\\\", \\\"{x:432,y:613,t:1527628232485};\\\", \\\"{x:408,y:606,t:1527628232503};\\\", \\\"{x:381,y:603,t:1527628232520};\\\", \\\"{x:340,y:596,t:1527628232537};\\\", \\\"{x:299,y:592,t:1527628232553};\\\", \\\"{x:276,y:588,t:1527628232568};\\\", \\\"{x:273,y:588,t:1527628232587};\\\", \\\"{x:267,y:587,t:1527628232604};\\\", \\\"{x:263,y:585,t:1527628232619};\\\", \\\"{x:260,y:585,t:1527628232636};\\\", \\\"{x:259,y:585,t:1527628232652};\\\", \\\"{x:258,y:585,t:1527628232672};\\\", \\\"{x:258,y:584,t:1527628232686};\\\", \\\"{x:257,y:584,t:1527628232702};\\\", \\\"{x:254,y:583,t:1527628232719};\\\", \\\"{x:253,y:582,t:1527628232736};\\\", \\\"{x:252,y:581,t:1527628232752};\\\", \\\"{x:249,y:579,t:1527628232769};\\\", \\\"{x:248,y:578,t:1527628232786};\\\", \\\"{x:247,y:578,t:1527628232817};\\\", \\\"{x:247,y:577,t:1527628232826};\\\", \\\"{x:252,y:572,t:1527628232837};\\\", \\\"{x:264,y:565,t:1527628232852};\\\", \\\"{x:279,y:554,t:1527628232872};\\\", \\\"{x:297,y:543,t:1527628232887};\\\", \\\"{x:320,y:531,t:1527628232902};\\\", \\\"{x:337,y:521,t:1527628232920};\\\", \\\"{x:351,y:515,t:1527628232937};\\\", \\\"{x:379,y:504,t:1527628232953};\\\", \\\"{x:399,y:498,t:1527628232970};\\\", \\\"{x:409,y:495,t:1527628232987};\\\", \\\"{x:417,y:492,t:1527628233004};\\\", \\\"{x:422,y:490,t:1527628233019};\\\", \\\"{x:431,y:487,t:1527628233037};\\\", \\\"{x:438,y:485,t:1527628233054};\\\", \\\"{x:455,y:484,t:1527628233070};\\\", \\\"{x:477,y:484,t:1527628233086};\\\", \\\"{x:496,y:484,t:1527628233103};\\\", \\\"{x:514,y:484,t:1527628233119};\\\", \\\"{x:530,y:484,t:1527628233136};\\\", \\\"{x:544,y:484,t:1527628233153};\\\", \\\"{x:553,y:487,t:1527628233170};\\\", \\\"{x:563,y:491,t:1527628233186};\\\", \\\"{x:567,y:491,t:1527628233203};\\\", \\\"{x:571,y:492,t:1527628233219};\\\", \\\"{x:574,y:493,t:1527628233237};\\\", \\\"{x:576,y:494,t:1527628233254};\\\", \\\"{x:578,y:495,t:1527628233269};\\\", \\\"{x:581,y:495,t:1527628233287};\\\", \\\"{x:594,y:500,t:1527628233304};\\\", \\\"{x:608,y:504,t:1527628233320};\\\", \\\"{x:621,y:505,t:1527628233337};\\\", \\\"{x:650,y:509,t:1527628233353};\\\", \\\"{x:656,y:509,t:1527628233370};\\\", \\\"{x:657,y:509,t:1527628233387};\\\", \\\"{x:658,y:509,t:1527628233408};\\\", \\\"{x:659,y:509,t:1527628233425};\\\", \\\"{x:660,y:509,t:1527628233436};\\\", \\\"{x:661,y:509,t:1527628233453};\\\", \\\"{x:667,y:508,t:1527628233470};\\\", \\\"{x:672,y:507,t:1527628233486};\\\", \\\"{x:676,y:506,t:1527628233503};\\\", \\\"{x:689,y:505,t:1527628233520};\\\", \\\"{x:705,y:505,t:1527628233536};\\\", \\\"{x:730,y:505,t:1527628233554};\\\", \\\"{x:746,y:505,t:1527628233570};\\\", \\\"{x:761,y:505,t:1527628233586};\\\", \\\"{x:778,y:505,t:1527628233603};\\\", \\\"{x:793,y:508,t:1527628233620};\\\", \\\"{x:809,y:511,t:1527628233637};\\\", \\\"{x:830,y:512,t:1527628233655};\\\", \\\"{x:855,y:512,t:1527628233670};\\\", \\\"{x:878,y:512,t:1527628233686};\\\", \\\"{x:893,y:512,t:1527628233703};\\\", \\\"{x:896,y:512,t:1527628233721};\\\", \\\"{x:897,y:513,t:1527628233882};\\\", \\\"{x:896,y:514,t:1527628233897};\\\", \\\"{x:895,y:515,t:1527628233906};\\\", \\\"{x:894,y:515,t:1527628233920};\\\", \\\"{x:891,y:516,t:1527628233937};\\\", \\\"{x:881,y:516,t:1527628233953};\\\", \\\"{x:874,y:516,t:1527628233971};\\\", \\\"{x:864,y:513,t:1527628233987};\\\", \\\"{x:860,y:511,t:1527628234005};\\\", \\\"{x:854,y:510,t:1527628234020};\\\", \\\"{x:848,y:506,t:1527628234037};\\\", \\\"{x:843,y:505,t:1527628234053};\\\", \\\"{x:841,y:503,t:1527628234070};\\\", \\\"{x:840,y:503,t:1527628234954};\\\", \\\"{x:840,y:507,t:1527628234972};\\\", \\\"{x:840,y:512,t:1527628234988};\\\", \\\"{x:840,y:516,t:1527628235006};\\\", \\\"{x:840,y:518,t:1527628235021};\\\", \\\"{x:840,y:519,t:1527628235037};\\\", \\\"{x:840,y:520,t:1527628235072};\\\", \\\"{x:840,y:521,t:1527628235096};\\\", \\\"{x:840,y:522,t:1527628235105};\\\", \\\"{x:839,y:523,t:1527628235121};\\\", \\\"{x:839,y:526,t:1527628235138};\\\", \\\"{x:839,y:527,t:1527628235154};\\\", \\\"{x:839,y:530,t:1527628235172};\\\", \\\"{x:839,y:532,t:1527628235188};\\\", \\\"{x:838,y:533,t:1527628235205};\\\", \\\"{x:838,y:535,t:1527628235221};\\\", \\\"{x:838,y:538,t:1527628235238};\\\", \\\"{x:838,y:541,t:1527628235255};\\\", \\\"{x:838,y:545,t:1527628235271};\\\", \\\"{x:838,y:547,t:1527628235289};\\\", \\\"{x:838,y:552,t:1527628235306};\\\", \\\"{x:837,y:556,t:1527628235322};\\\", \\\"{x:834,y:560,t:1527628235338};\\\", \\\"{x:829,y:567,t:1527628235356};\\\", \\\"{x:820,y:575,t:1527628235371};\\\", \\\"{x:804,y:581,t:1527628235388};\\\", \\\"{x:777,y:587,t:1527628235404};\\\", \\\"{x:746,y:592,t:1527628235421};\\\", \\\"{x:716,y:596,t:1527628235439};\\\", \\\"{x:694,y:597,t:1527628235455};\\\", \\\"{x:679,y:597,t:1527628235471};\\\", \\\"{x:677,y:597,t:1527628235488};\\\", \\\"{x:675,y:597,t:1527628235504};\\\", \\\"{x:672,y:597,t:1527628235594};\\\", \\\"{x:668,y:597,t:1527628235606};\\\", \\\"{x:653,y:597,t:1527628235621};\\\", \\\"{x:625,y:601,t:1527628235640};\\\", \\\"{x:592,y:604,t:1527628235655};\\\", \\\"{x:555,y:611,t:1527628235672};\\\", \\\"{x:524,y:615,t:1527628235688};\\\", \\\"{x:487,y:618,t:1527628235705};\\\", \\\"{x:477,y:618,t:1527628235721};\\\", \\\"{x:476,y:618,t:1527628235738};\\\", \\\"{x:474,y:618,t:1527628235801};\\\", \\\"{x:471,y:617,t:1527628235816};\\\", \\\"{x:469,y:616,t:1527628235825};\\\", \\\"{x:465,y:615,t:1527628235839};\\\", \\\"{x:456,y:612,t:1527628235855};\\\", \\\"{x:443,y:610,t:1527628235872};\\\", \\\"{x:426,y:610,t:1527628235889};\\\", \\\"{x:409,y:610,t:1527628235906};\\\", \\\"{x:404,y:610,t:1527628235922};\\\", \\\"{x:391,y:610,t:1527628235939};\\\", \\\"{x:376,y:610,t:1527628235956};\\\", \\\"{x:369,y:610,t:1527628235972};\\\", \\\"{x:359,y:610,t:1527628235988};\\\", \\\"{x:346,y:613,t:1527628236005};\\\", \\\"{x:333,y:615,t:1527628236022};\\\", \\\"{x:319,y:617,t:1527628236038};\\\", \\\"{x:301,y:619,t:1527628236056};\\\", \\\"{x:278,y:619,t:1527628236072};\\\", \\\"{x:251,y:619,t:1527628236089};\\\", \\\"{x:197,y:601,t:1527628236105};\\\", \\\"{x:164,y:586,t:1527628236124};\\\", \\\"{x:154,y:581,t:1527628236139};\\\", \\\"{x:153,y:581,t:1527628236156};\\\", \\\"{x:152,y:581,t:1527628236185};\\\", \\\"{x:152,y:580,t:1527628236193};\\\", \\\"{x:152,y:577,t:1527628236206};\\\", \\\"{x:153,y:570,t:1527628236223};\\\", \\\"{x:153,y:563,t:1527628236239};\\\", \\\"{x:153,y:557,t:1527628236256};\\\", \\\"{x:153,y:553,t:1527628236272};\\\", \\\"{x:153,y:550,t:1527628236289};\\\", \\\"{x:153,y:547,t:1527628236305};\\\", \\\"{x:153,y:546,t:1527628236322};\\\", \\\"{x:153,y:545,t:1527628236339};\\\", \\\"{x:153,y:543,t:1527628236356};\\\", \\\"{x:153,y:542,t:1527628236385};\\\", \\\"{x:154,y:540,t:1527628236409};\\\", \\\"{x:156,y:540,t:1527628236529};\\\", \\\"{x:157,y:540,t:1527628236539};\\\", \\\"{x:162,y:544,t:1527628236555};\\\", \\\"{x:164,y:545,t:1527628236572};\\\", \\\"{x:165,y:546,t:1527628236589};\\\", \\\"{x:165,y:546,t:1527628236621};\\\", \\\"{x:166,y:546,t:1527628236736};\\\", \\\"{x:167,y:546,t:1527628236753};\\\", \\\"{x:168,y:546,t:1527628236761};\\\", \\\"{x:171,y:547,t:1527628236772};\\\", \\\"{x:179,y:551,t:1527628236790};\\\", \\\"{x:190,y:557,t:1527628236806};\\\", \\\"{x:205,y:567,t:1527628236822};\\\", \\\"{x:216,y:574,t:1527628236840};\\\", \\\"{x:233,y:580,t:1527628236856};\\\", \\\"{x:248,y:588,t:1527628236872};\\\", \\\"{x:270,y:598,t:1527628236890};\\\", \\\"{x:288,y:608,t:1527628236907};\\\", \\\"{x:300,y:614,t:1527628236922};\\\", \\\"{x:317,y:622,t:1527628236940};\\\", \\\"{x:330,y:627,t:1527628236955};\\\", \\\"{x:348,y:638,t:1527628236974};\\\", \\\"{x:357,y:644,t:1527628236990};\\\", \\\"{x:364,y:648,t:1527628237007};\\\", \\\"{x:375,y:655,t:1527628237022};\\\", \\\"{x:382,y:661,t:1527628237039};\\\", \\\"{x:388,y:667,t:1527628237057};\\\", \\\"{x:395,y:679,t:1527628237073};\\\", \\\"{x:396,y:683,t:1527628237090};\\\", \\\"{x:403,y:692,t:1527628237107};\\\", \\\"{x:410,y:706,t:1527628237127};\\\", \\\"{x:417,y:719,t:1527628237143};\\\", \\\"{x:421,y:727,t:1527628237161};\\\", \\\"{x:426,y:739,t:1527628237179};\\\", \\\"{x:436,y:754,t:1527628237194};\\\", \\\"{x:442,y:769,t:1527628237211};\\\", \\\"{x:450,y:780,t:1527628237228};\\\", \\\"{x:453,y:786,t:1527628237244};\\\", \\\"{x:455,y:790,t:1527628237261};\\\", \\\"{x:460,y:798,t:1527628237277};\\\", \\\"{x:463,y:804,t:1527628237294};\\\", \\\"{x:466,y:808,t:1527628237311};\\\", \\\"{x:467,y:809,t:1527628237328};\\\", \\\"{x:467,y:810,t:1527628237344};\\\", \\\"{x:468,y:810,t:1527628237870};\\\", \\\"{x:469,y:810,t:1527628237918};\\\", \\\"{x:471,y:809,t:1527628237942};\\\", \\\"{x:474,y:807,t:1527628237950};\\\", \\\"{x:479,y:799,t:1527628237961};\\\", \\\"{x:492,y:776,t:1527628237978};\\\", \\\"{x:507,y:750,t:1527628237997};\\\", \\\"{x:518,y:722,t:1527628238011};\\\", \\\"{x:524,y:705,t:1527628238028};\\\", \\\"{x:526,y:698,t:1527628238044};\\\", \\\"{x:526,y:700,t:1527628238230};\\\", \\\"{x:526,y:708,t:1527628238245};\\\", \\\"{x:523,y:733,t:1527628238263};\\\", \\\"{x:523,y:741,t:1527628238278};\\\", \\\"{x:523,y:746,t:1527628238295};\\\", \\\"{x:522,y:746,t:1527628239062};\\\", \\\"{x:521,y:746,t:1527628239085};\\\", \\\"{x:520,y:746,t:1527628239158};\\\", \\\"{x:519,y:746,t:1527628239182};\\\", \\\"{x:518,y:746,t:1527628239238};\\\", \\\"{x:517,y:746,t:1527628239453};\\\", \\\"{x:516,y:746,t:1527628239485};\\\", \\\"{x:515,y:746,t:1527628239509};\\\", \\\"{x:512,y:746,t:1527628239593};\\\", \\\"{x:510,y:746,t:1527628239611};\\\", \\\"{x:509,y:746,t:1527628239629};\\\", \\\"{x:508,y:746,t:1527628239646};\\\", \\\"{x:507,y:746,t:1527628239661};\\\" ] }, { \\\"rt\\\": 66252, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 428532, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -F -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:746,t:1527628239767};\\\", \\\"{x:501,y:746,t:1527628239791};\\\", \\\"{x:500,y:746,t:1527628239933};\\\", \\\"{x:499,y:746,t:1527628239957};\\\", \\\"{x:498,y:746,t:1527628239973};\\\", \\\"{x:497,y:746,t:1527628239989};\\\", \\\"{x:496,y:746,t:1527628240004};\\\", \\\"{x:495,y:746,t:1527628240021};\\\", \\\"{x:494,y:746,t:1527628240037};\\\", \\\"{x:494,y:747,t:1527628240045};\\\", \\\"{x:493,y:748,t:1527628240063};\\\", \\\"{x:490,y:748,t:1527628240265};\\\", \\\"{x:489,y:748,t:1527628240290};\\\", \\\"{x:488,y:748,t:1527628240309};\\\", \\\"{x:487,y:748,t:1527628240390};\\\", \\\"{x:486,y:748,t:1527628240420};\\\", \\\"{x:499,y:741,t:1527628288229};\\\", \\\"{x:526,y:728,t:1527628288237};\\\", \\\"{x:563,y:708,t:1527628288256};\\\", \\\"{x:610,y:687,t:1527628288271};\\\", \\\"{x:637,y:675,t:1527628288287};\\\", \\\"{x:649,y:670,t:1527628288302};\\\", \\\"{x:652,y:669,t:1527628288320};\\\", \\\"{x:655,y:668,t:1527628288597};\\\", \\\"{x:661,y:666,t:1527628288604};\\\", \\\"{x:668,y:663,t:1527628288619};\\\", \\\"{x:687,y:652,t:1527628288637};\\\", \\\"{x:695,y:646,t:1527628288653};\\\", \\\"{x:700,y:642,t:1527628288670};\\\", \\\"{x:702,y:641,t:1527628288686};\\\", \\\"{x:703,y:641,t:1527628288703};\\\", \\\"{x:704,y:641,t:1527628288720};\\\", \\\"{x:700,y:641,t:1527628289381};\\\", \\\"{x:696,y:641,t:1527628289389};\\\", \\\"{x:693,y:641,t:1527628289404};\\\", \\\"{x:687,y:642,t:1527628289420};\\\", \\\"{x:681,y:645,t:1527628289437};\\\", \\\"{x:674,y:649,t:1527628289454};\\\", \\\"{x:666,y:654,t:1527628289471};\\\", \\\"{x:656,y:657,t:1527628289486};\\\", \\\"{x:651,y:660,t:1527628289504};\\\", \\\"{x:647,y:663,t:1527628289521};\\\", \\\"{x:646,y:664,t:1527628289537};\\\", \\\"{x:646,y:666,t:1527628289554};\\\", \\\"{x:647,y:666,t:1527628289604};\\\", \\\"{x:653,y:665,t:1527628289621};\\\", \\\"{x:664,y:662,t:1527628289637};\\\", \\\"{x:681,y:660,t:1527628289653};\\\", \\\"{x:706,y:656,t:1527628289671};\\\", \\\"{x:731,y:649,t:1527628289687};\\\", \\\"{x:765,y:644,t:1527628289704};\\\", \\\"{x:802,y:638,t:1527628289721};\\\", \\\"{x:853,y:631,t:1527628289738};\\\", \\\"{x:914,y:621,t:1527628289753};\\\", \\\"{x:965,y:613,t:1527628289770};\\\", \\\"{x:1018,y:605,t:1527628289786};\\\", \\\"{x:1082,y:599,t:1527628289804};\\\", \\\"{x:1108,y:599,t:1527628289821};\\\", \\\"{x:1133,y:599,t:1527628289838};\\\", \\\"{x:1153,y:599,t:1527628289853};\\\", \\\"{x:1169,y:602,t:1527628289870};\\\", \\\"{x:1183,y:606,t:1527628289887};\\\", \\\"{x:1194,y:611,t:1527628289904};\\\", \\\"{x:1202,y:616,t:1527628289921};\\\", \\\"{x:1212,y:624,t:1527628289938};\\\", \\\"{x:1221,y:630,t:1527628289954};\\\", \\\"{x:1236,y:635,t:1527628289971};\\\", \\\"{x:1246,y:640,t:1527628289987};\\\", \\\"{x:1257,y:644,t:1527628290004};\\\", \\\"{x:1275,y:652,t:1527628290021};\\\", \\\"{x:1275,y:654,t:1527628290270};\\\", \\\"{x:1270,y:658,t:1527628290277};\\\", \\\"{x:1265,y:662,t:1527628290288};\\\", \\\"{x:1263,y:671,t:1527628290305};\\\", \\\"{x:1269,y:695,t:1527628290321};\\\", \\\"{x:1279,y:718,t:1527628290338};\\\", \\\"{x:1290,y:733,t:1527628290354};\\\", \\\"{x:1302,y:746,t:1527628290371};\\\", \\\"{x:1318,y:759,t:1527628290387};\\\", \\\"{x:1341,y:775,t:1527628290403};\\\", \\\"{x:1350,y:782,t:1527628290420};\\\", \\\"{x:1353,y:784,t:1527628290438};\\\", \\\"{x:1355,y:784,t:1527628290468};\\\", \\\"{x:1357,y:784,t:1527628290476};\\\", \\\"{x:1359,y:784,t:1527628290492};\\\", \\\"{x:1360,y:784,t:1527628290508};\\\", \\\"{x:1363,y:784,t:1527628290520};\\\", \\\"{x:1364,y:784,t:1527628290538};\\\", \\\"{x:1366,y:784,t:1527628290555};\\\", \\\"{x:1367,y:784,t:1527628290570};\\\", \\\"{x:1368,y:784,t:1527628290588};\\\", \\\"{x:1369,y:783,t:1527628290604};\\\", \\\"{x:1370,y:778,t:1527628290621};\\\", \\\"{x:1371,y:775,t:1527628290638};\\\", \\\"{x:1371,y:770,t:1527628290655};\\\", \\\"{x:1371,y:766,t:1527628290671};\\\", \\\"{x:1371,y:763,t:1527628290688};\\\", \\\"{x:1371,y:757,t:1527628290706};\\\", \\\"{x:1371,y:754,t:1527628290722};\\\", \\\"{x:1371,y:752,t:1527628290738};\\\", \\\"{x:1371,y:751,t:1527628290765};\\\", \\\"{x:1370,y:750,t:1527628290780};\\\", \\\"{x:1369,y:749,t:1527628290813};\\\", \\\"{x:1369,y:747,t:1527628290836};\\\", \\\"{x:1368,y:746,t:1527628290893};\\\", \\\"{x:1367,y:746,t:1527628290905};\\\", \\\"{x:1366,y:746,t:1527628290922};\\\", \\\"{x:1365,y:746,t:1527628290938};\\\", \\\"{x:1363,y:747,t:1527628290955};\\\", \\\"{x:1362,y:747,t:1527628290972};\\\", \\\"{x:1361,y:747,t:1527628290988};\\\", \\\"{x:1360,y:747,t:1527628291141};\\\", \\\"{x:1360,y:748,t:1527628291165};\\\", \\\"{x:1358,y:748,t:1527628291213};\\\", \\\"{x:1357,y:749,t:1527628291564};\\\", \\\"{x:1355,y:750,t:1527628291580};\\\", \\\"{x:1354,y:750,t:1527628291612};\\\", \\\"{x:1352,y:751,t:1527628291669};\\\", \\\"{x:1352,y:752,t:1527628291796};\\\", \\\"{x:1352,y:753,t:1527628291820};\\\", \\\"{x:1352,y:755,t:1527628291981};\\\", \\\"{x:1351,y:756,t:1527628292021};\\\", \\\"{x:1350,y:756,t:1527628292028};\\\", \\\"{x:1350,y:757,t:1527628292039};\\\", \\\"{x:1348,y:759,t:1527628292059};\\\", \\\"{x:1347,y:760,t:1527628292072};\\\", \\\"{x:1344,y:764,t:1527628292088};\\\", \\\"{x:1343,y:766,t:1527628292105};\\\", \\\"{x:1342,y:767,t:1527628292123};\\\", \\\"{x:1342,y:768,t:1527628292138};\\\", \\\"{x:1342,y:769,t:1527628292156};\\\", \\\"{x:1342,y:770,t:1527628292813};\\\", \\\"{x:1342,y:772,t:1527628292836};\\\", \\\"{x:1343,y:772,t:1527628292859};\\\", \\\"{x:1344,y:772,t:1527628292872};\\\", \\\"{x:1345,y:772,t:1527628292900};\\\", \\\"{x:1346,y:772,t:1527628292940};\\\", \\\"{x:1347,y:773,t:1527628292956};\\\", \\\"{x:1348,y:773,t:1527628292988};\\\", \\\"{x:1349,y:773,t:1527628293365};\\\", \\\"{x:1349,y:772,t:1527628293380};\\\", \\\"{x:1350,y:771,t:1527628293391};\\\", \\\"{x:1352,y:770,t:1527628293408};\\\", \\\"{x:1353,y:768,t:1527628293424};\\\", \\\"{x:1353,y:767,t:1527628293444};\\\", \\\"{x:1354,y:766,t:1527628293460};\\\", \\\"{x:1354,y:765,t:1527628293491};\\\", \\\"{x:1354,y:764,t:1527628293532};\\\", \\\"{x:1354,y:763,t:1527628293645};\\\", \\\"{x:1354,y:762,t:1527628293758};\\\", \\\"{x:1353,y:762,t:1527628293775};\\\", \\\"{x:1351,y:762,t:1527628293791};\\\", \\\"{x:1350,y:762,t:1527628293807};\\\", \\\"{x:1349,y:762,t:1527628293824};\\\", \\\"{x:1348,y:762,t:1527628293841};\\\", \\\"{x:1348,y:760,t:1527628296045};\\\", \\\"{x:1348,y:759,t:1527628296059};\\\", \\\"{x:1348,y:757,t:1527628296078};\\\", \\\"{x:1348,y:756,t:1527628296092};\\\", \\\"{x:1348,y:755,t:1527628296108};\\\", \\\"{x:1348,y:754,t:1527628296126};\\\", \\\"{x:1348,y:753,t:1527628296156};\\\", \\\"{x:1348,y:752,t:1527628296181};\\\", \\\"{x:1348,y:751,t:1527628296197};\\\", \\\"{x:1348,y:750,t:1527628296213};\\\", \\\"{x:1348,y:749,t:1527628296236};\\\", \\\"{x:1348,y:748,t:1527628296260};\\\", \\\"{x:1347,y:747,t:1527628296293};\\\", \\\"{x:1347,y:746,t:1527628296381};\\\", \\\"{x:1347,y:745,t:1527628296420};\\\", \\\"{x:1347,y:744,t:1527628296452};\\\", \\\"{x:1347,y:743,t:1527628296516};\\\", \\\"{x:1347,y:742,t:1527628296540};\\\", \\\"{x:1347,y:741,t:1527628296548};\\\", \\\"{x:1347,y:740,t:1527628296580};\\\", \\\"{x:1347,y:739,t:1527628296595};\\\", \\\"{x:1347,y:738,t:1527628296609};\\\", \\\"{x:1347,y:736,t:1527628296628};\\\", \\\"{x:1347,y:735,t:1527628296644};\\\", \\\"{x:1347,y:734,t:1527628296660};\\\", \\\"{x:1347,y:733,t:1527628296676};\\\", \\\"{x:1347,y:730,t:1527628296693};\\\", \\\"{x:1347,y:729,t:1527628296716};\\\", \\\"{x:1347,y:727,t:1527628296732};\\\", \\\"{x:1347,y:726,t:1527628296764};\\\", \\\"{x:1347,y:724,t:1527628296788};\\\", \\\"{x:1347,y:723,t:1527628296812};\\\", \\\"{x:1347,y:721,t:1527628296837};\\\", \\\"{x:1347,y:720,t:1527628296844};\\\", \\\"{x:1347,y:718,t:1527628296860};\\\", \\\"{x:1347,y:717,t:1527628296876};\\\", \\\"{x:1347,y:715,t:1527628296893};\\\", \\\"{x:1347,y:714,t:1527628296917};\\\", \\\"{x:1347,y:713,t:1527628296926};\\\", \\\"{x:1347,y:712,t:1527628296944};\\\", \\\"{x:1347,y:711,t:1527628296960};\\\", \\\"{x:1347,y:709,t:1527628296976};\\\", \\\"{x:1347,y:708,t:1527628296994};\\\", \\\"{x:1347,y:706,t:1527628297011};\\\", \\\"{x:1347,y:705,t:1527628297027};\\\", \\\"{x:1347,y:703,t:1527628297043};\\\", \\\"{x:1347,y:701,t:1527628297061};\\\", \\\"{x:1347,y:700,t:1527628297076};\\\", \\\"{x:1347,y:698,t:1527628297095};\\\", \\\"{x:1347,y:697,t:1527628297137};\\\", \\\"{x:1347,y:696,t:1527628297147};\\\", \\\"{x:1347,y:695,t:1527628297177};\\\", \\\"{x:1347,y:694,t:1527628297200};\\\", \\\"{x:1347,y:693,t:1527628297224};\\\", \\\"{x:1347,y:692,t:1527628297249};\\\", \\\"{x:1347,y:690,t:1527628297265};\\\", \\\"{x:1347,y:688,t:1527628297281};\\\", \\\"{x:1347,y:686,t:1527628297297};\\\", \\\"{x:1347,y:684,t:1527628297314};\\\", \\\"{x:1348,y:683,t:1527628297331};\\\", \\\"{x:1348,y:680,t:1527628297348};\\\", \\\"{x:1348,y:679,t:1527628297365};\\\", \\\"{x:1348,y:678,t:1527628297381};\\\", \\\"{x:1348,y:675,t:1527628297398};\\\", \\\"{x:1348,y:674,t:1527628297414};\\\", \\\"{x:1348,y:673,t:1527628297431};\\\", \\\"{x:1348,y:671,t:1527628297448};\\\", \\\"{x:1348,y:669,t:1527628297472};\\\", \\\"{x:1348,y:668,t:1527628297505};\\\", \\\"{x:1348,y:666,t:1527628297537};\\\", \\\"{x:1348,y:665,t:1527628297553};\\\", \\\"{x:1348,y:663,t:1527628297569};\\\", \\\"{x:1348,y:662,t:1527628297585};\\\", \\\"{x:1348,y:661,t:1527628297598};\\\", \\\"{x:1348,y:658,t:1527628297614};\\\", \\\"{x:1348,y:655,t:1527628297631};\\\", \\\"{x:1348,y:649,t:1527628297648};\\\", \\\"{x:1348,y:640,t:1527628297665};\\\", \\\"{x:1348,y:632,t:1527628297682};\\\", \\\"{x:1348,y:622,t:1527628297698};\\\", \\\"{x:1348,y:610,t:1527628297714};\\\", \\\"{x:1348,y:597,t:1527628297731};\\\", \\\"{x:1348,y:586,t:1527628297749};\\\", \\\"{x:1348,y:578,t:1527628297765};\\\", \\\"{x:1346,y:566,t:1527628297782};\\\", \\\"{x:1343,y:554,t:1527628297800};\\\", \\\"{x:1340,y:544,t:1527628297815};\\\", \\\"{x:1337,y:534,t:1527628297831};\\\", \\\"{x:1336,y:525,t:1527628297847};\\\", \\\"{x:1336,y:519,t:1527628297864};\\\", \\\"{x:1336,y:515,t:1527628297881};\\\", \\\"{x:1336,y:512,t:1527628297898};\\\", \\\"{x:1335,y:508,t:1527628297914};\\\", \\\"{x:1334,y:507,t:1527628297931};\\\", \\\"{x:1334,y:505,t:1527628297948};\\\", \\\"{x:1334,y:504,t:1527628297964};\\\", \\\"{x:1334,y:503,t:1527628298000};\\\", \\\"{x:1332,y:503,t:1527628298297};\\\", \\\"{x:1332,y:504,t:1527628298305};\\\", \\\"{x:1331,y:505,t:1527628298316};\\\", \\\"{x:1331,y:506,t:1527628298332};\\\", \\\"{x:1330,y:507,t:1527628298348};\\\", \\\"{x:1328,y:510,t:1527628298366};\\\", \\\"{x:1327,y:511,t:1527628298381};\\\", \\\"{x:1327,y:513,t:1527628298399};\\\", \\\"{x:1327,y:514,t:1527628298417};\\\", \\\"{x:1326,y:514,t:1527628298432};\\\", \\\"{x:1325,y:515,t:1527628298449};\\\", \\\"{x:1324,y:516,t:1527628298465};\\\", \\\"{x:1322,y:517,t:1527628298482};\\\", \\\"{x:1321,y:518,t:1527628298498};\\\", \\\"{x:1319,y:519,t:1527628298516};\\\", \\\"{x:1318,y:520,t:1527628298531};\\\", \\\"{x:1318,y:521,t:1527628298549};\\\", \\\"{x:1316,y:521,t:1527628298565};\\\", \\\"{x:1315,y:522,t:1527628298582};\\\", \\\"{x:1314,y:523,t:1527628298600};\\\", \\\"{x:1313,y:524,t:1527628298616};\\\", \\\"{x:1312,y:524,t:1527628298631};\\\", \\\"{x:1311,y:525,t:1527628298649};\\\", \\\"{x:1308,y:528,t:1527628298666};\\\", \\\"{x:1306,y:531,t:1527628298683};\\\", \\\"{x:1305,y:533,t:1527628298699};\\\", \\\"{x:1304,y:533,t:1527628298715};\\\", \\\"{x:1302,y:536,t:1527628298733};\\\", \\\"{x:1301,y:537,t:1527628298749};\\\", \\\"{x:1300,y:538,t:1527628298765};\\\", \\\"{x:1299,y:539,t:1527628298782};\\\", \\\"{x:1298,y:540,t:1527628298800};\\\", \\\"{x:1296,y:542,t:1527628298816};\\\", \\\"{x:1295,y:544,t:1527628298833};\\\", \\\"{x:1294,y:544,t:1527628298849};\\\", \\\"{x:1293,y:546,t:1527628298866};\\\", \\\"{x:1291,y:547,t:1527628298883};\\\", \\\"{x:1290,y:548,t:1527628298899};\\\", \\\"{x:1288,y:549,t:1527628298916};\\\", \\\"{x:1286,y:551,t:1527628298933};\\\", \\\"{x:1283,y:554,t:1527628298949};\\\", \\\"{x:1280,y:555,t:1527628298965};\\\", \\\"{x:1276,y:558,t:1527628298982};\\\", \\\"{x:1271,y:561,t:1527628298999};\\\", \\\"{x:1264,y:564,t:1527628299015};\\\", \\\"{x:1255,y:569,t:1527628299031};\\\", \\\"{x:1246,y:573,t:1527628299049};\\\", \\\"{x:1233,y:577,t:1527628299065};\\\", \\\"{x:1218,y:581,t:1527628299082};\\\", \\\"{x:1201,y:585,t:1527628299100};\\\", \\\"{x:1193,y:587,t:1527628299115};\\\", \\\"{x:1186,y:588,t:1527628299133};\\\", \\\"{x:1178,y:589,t:1527628299149};\\\", \\\"{x:1174,y:590,t:1527628299166};\\\", \\\"{x:1171,y:590,t:1527628299183};\\\", \\\"{x:1168,y:590,t:1527628299200};\\\", \\\"{x:1166,y:590,t:1527628299215};\\\", \\\"{x:1164,y:590,t:1527628299232};\\\", \\\"{x:1163,y:590,t:1527628299249};\\\", \\\"{x:1161,y:591,t:1527628299266};\\\", \\\"{x:1158,y:591,t:1527628299282};\\\", \\\"{x:1150,y:592,t:1527628299300};\\\", \\\"{x:1125,y:594,t:1527628299316};\\\", \\\"{x:1063,y:594,t:1527628299332};\\\", \\\"{x:952,y:594,t:1527628299349};\\\", \\\"{x:822,y:593,t:1527628299368};\\\", \\\"{x:676,y:554,t:1527628299382};\\\", \\\"{x:543,y:517,t:1527628299399};\\\", \\\"{x:470,y:500,t:1527628299414};\\\", \\\"{x:436,y:495,t:1527628299430};\\\", \\\"{x:420,y:495,t:1527628299449};\\\", \\\"{x:416,y:495,t:1527628299466};\\\", \\\"{x:413,y:495,t:1527628299482};\\\", \\\"{x:410,y:494,t:1527628299499};\\\", \\\"{x:409,y:494,t:1527628299516};\\\", \\\"{x:408,y:494,t:1527628299624};\\\", \\\"{x:407,y:494,t:1527628299634};\\\", \\\"{x:406,y:494,t:1527628299649};\\\", \\\"{x:405,y:494,t:1527628299667};\\\", \\\"{x:405,y:495,t:1527628299683};\\\", \\\"{x:406,y:495,t:1527628299745};\\\", \\\"{x:411,y:495,t:1527628299752};\\\", \\\"{x:418,y:495,t:1527628299768};\\\", \\\"{x:438,y:489,t:1527628299783};\\\", \\\"{x:463,y:484,t:1527628299799};\\\", \\\"{x:501,y:480,t:1527628299816};\\\", \\\"{x:521,y:476,t:1527628299833};\\\", \\\"{x:531,y:471,t:1527628299849};\\\", \\\"{x:536,y:467,t:1527628299866};\\\", \\\"{x:540,y:462,t:1527628299883};\\\", \\\"{x:540,y:460,t:1527628299899};\\\", \\\"{x:541,y:459,t:1527628299920};\\\", \\\"{x:542,y:458,t:1527628299944};\\\", \\\"{x:544,y:458,t:1527628299968};\\\", \\\"{x:545,y:458,t:1527628299983};\\\", \\\"{x:548,y:460,t:1527628299999};\\\", \\\"{x:552,y:464,t:1527628300016};\\\", \\\"{x:555,y:467,t:1527628300034};\\\", \\\"{x:558,y:470,t:1527628300051};\\\", \\\"{x:563,y:478,t:1527628300066};\\\", \\\"{x:566,y:482,t:1527628300083};\\\", \\\"{x:568,y:485,t:1527628300100};\\\", \\\"{x:572,y:486,t:1527628300116};\\\", \\\"{x:575,y:488,t:1527628300134};\\\", \\\"{x:578,y:488,t:1527628300150};\\\", \\\"{x:579,y:488,t:1527628300166};\\\", \\\"{x:580,y:488,t:1527628300183};\\\", \\\"{x:584,y:489,t:1527628300200};\\\", \\\"{x:586,y:489,t:1527628300216};\\\", \\\"{x:588,y:489,t:1527628300233};\\\", \\\"{x:591,y:489,t:1527628300250};\\\", \\\"{x:592,y:489,t:1527628300265};\\\", \\\"{x:594,y:489,t:1527628300282};\\\", \\\"{x:597,y:489,t:1527628300300};\\\", \\\"{x:598,y:489,t:1527628300316};\\\", \\\"{x:599,y:489,t:1527628300332};\\\", \\\"{x:600,y:489,t:1527628300352};\\\", \\\"{x:601,y:489,t:1527628300375};\\\", \\\"{x:602,y:489,t:1527628300392};\\\", \\\"{x:603,y:489,t:1527628300520};\\\", \\\"{x:603,y:489,t:1527628300674};\\\", \\\"{x:603,y:490,t:1527628301226};\\\", \\\"{x:603,y:491,t:1527628301255};\\\", \\\"{x:603,y:492,t:1527628301393};\\\", \\\"{x:602,y:492,t:1527628301401};\\\", \\\"{x:602,y:494,t:1527628301417};\\\", \\\"{x:600,y:496,t:1527628301434};\\\", \\\"{x:600,y:498,t:1527628301452};\\\", \\\"{x:599,y:500,t:1527628301467};\\\", \\\"{x:596,y:504,t:1527628301484};\\\", \\\"{x:596,y:505,t:1527628301501};\\\", \\\"{x:594,y:509,t:1527628301518};\\\", \\\"{x:593,y:510,t:1527628301534};\\\", \\\"{x:592,y:512,t:1527628301551};\\\", \\\"{x:591,y:515,t:1527628301567};\\\", \\\"{x:590,y:518,t:1527628301585};\\\", \\\"{x:589,y:519,t:1527628301601};\\\", \\\"{x:588,y:521,t:1527628301617};\\\", \\\"{x:587,y:524,t:1527628301634};\\\", \\\"{x:586,y:529,t:1527628301651};\\\", \\\"{x:585,y:532,t:1527628301667};\\\", \\\"{x:583,y:536,t:1527628301684};\\\", \\\"{x:582,y:541,t:1527628301701};\\\", \\\"{x:581,y:544,t:1527628301718};\\\", \\\"{x:579,y:551,t:1527628301734};\\\", \\\"{x:578,y:556,t:1527628301752};\\\", \\\"{x:575,y:563,t:1527628301768};\\\", \\\"{x:571,y:574,t:1527628301784};\\\", \\\"{x:568,y:582,t:1527628301801};\\\", \\\"{x:565,y:587,t:1527628301819};\\\", \\\"{x:562,y:593,t:1527628301834};\\\", \\\"{x:561,y:597,t:1527628301852};\\\", \\\"{x:559,y:600,t:1527628301868};\\\", \\\"{x:557,y:604,t:1527628301885};\\\", \\\"{x:557,y:606,t:1527628301901};\\\", \\\"{x:557,y:607,t:1527628301918};\\\", \\\"{x:557,y:608,t:1527628301934};\\\", \\\"{x:557,y:609,t:1527628301952};\\\", \\\"{x:556,y:610,t:1527628301969};\\\", \\\"{x:556,y:611,t:1527628302041};\\\", \\\"{x:556,y:612,t:1527628302064};\\\", \\\"{x:556,y:613,t:1527628302088};\\\", \\\"{x:556,y:614,t:1527628302121};\\\", \\\"{x:556,y:615,t:1527628302145};\\\", \\\"{x:555,y:615,t:1527628302152};\\\", \\\"{x:555,y:616,t:1527628302249};\\\", \\\"{x:555,y:617,t:1527628302305};\\\", \\\"{x:554,y:617,t:1527628302344};\\\", \\\"{x:554,y:618,t:1527628302352};\\\", \\\"{x:554,y:619,t:1527628302384};\\\", \\\"{x:554,y:620,t:1527628302401};\\\", \\\"{x:554,y:621,t:1527628302418};\\\", \\\"{x:553,y:622,t:1527628302435};\\\", \\\"{x:552,y:624,t:1527628302451};\\\", \\\"{x:552,y:625,t:1527628302468};\\\", \\\"{x:552,y:628,t:1527628302485};\\\", \\\"{x:552,y:631,t:1527628302502};\\\", \\\"{x:552,y:632,t:1527628302520};\\\", \\\"{x:552,y:635,t:1527628302535};\\\", \\\"{x:552,y:637,t:1527628302551};\\\", \\\"{x:552,y:640,t:1527628302568};\\\", \\\"{x:552,y:641,t:1527628302584};\\\", \\\"{x:552,y:643,t:1527628302602};\\\", \\\"{x:551,y:643,t:1527628302618};\\\", \\\"{x:552,y:642,t:1527628302920};\\\", \\\"{x:553,y:641,t:1527628302936};\\\", \\\"{x:555,y:639,t:1527628302951};\\\", \\\"{x:557,y:635,t:1527628302968};\\\", \\\"{x:559,y:631,t:1527628302986};\\\", \\\"{x:561,y:628,t:1527628303001};\\\", \\\"{x:564,y:623,t:1527628303018};\\\", \\\"{x:567,y:618,t:1527628303035};\\\", \\\"{x:569,y:611,t:1527628303053};\\\", \\\"{x:571,y:603,t:1527628303069};\\\", \\\"{x:574,y:596,t:1527628303086};\\\", \\\"{x:575,y:590,t:1527628303103};\\\", \\\"{x:578,y:580,t:1527628303119};\\\", \\\"{x:580,y:575,t:1527628303134};\\\", \\\"{x:584,y:567,t:1527628303152};\\\", \\\"{x:585,y:564,t:1527628303169};\\\", \\\"{x:588,y:557,t:1527628303185};\\\", \\\"{x:591,y:551,t:1527628303202};\\\", \\\"{x:592,y:545,t:1527628303219};\\\", \\\"{x:595,y:541,t:1527628303236};\\\", \\\"{x:597,y:537,t:1527628303252};\\\", \\\"{x:599,y:535,t:1527628303269};\\\", \\\"{x:601,y:530,t:1527628303287};\\\", \\\"{x:603,y:528,t:1527628303302};\\\", \\\"{x:604,y:526,t:1527628303320};\\\", \\\"{x:605,y:523,t:1527628303336};\\\", \\\"{x:606,y:520,t:1527628303352};\\\", \\\"{x:609,y:516,t:1527628303370};\\\", \\\"{x:610,y:514,t:1527628303386};\\\", \\\"{x:610,y:513,t:1527628303403};\\\", \\\"{x:612,y:511,t:1527628303419};\\\", \\\"{x:613,y:509,t:1527628303436};\\\", \\\"{x:614,y:507,t:1527628303452};\\\", \\\"{x:616,y:504,t:1527628303470};\\\", \\\"{x:616,y:503,t:1527628303486};\\\", \\\"{x:616,y:501,t:1527628303502};\\\", \\\"{x:616,y:500,t:1527628303887};\\\", \\\"{x:615,y:500,t:1527628304209};\\\", \\\"{x:614,y:500,t:1527628304220};\\\", \\\"{x:613,y:500,t:1527628304237};\\\", \\\"{x:612,y:501,t:1527628304253};\\\", \\\"{x:611,y:502,t:1527628304280};\\\", \\\"{x:611,y:503,t:1527628304304};\\\", \\\"{x:609,y:504,t:1527628304319};\\\", \\\"{x:608,y:505,t:1527628304352};\\\", \\\"{x:607,y:507,t:1527628304360};\\\", \\\"{x:606,y:510,t:1527628304376};\\\", \\\"{x:605,y:511,t:1527628304387};\\\", \\\"{x:605,y:515,t:1527628304404};\\\", \\\"{x:602,y:521,t:1527628304420};\\\", \\\"{x:601,y:528,t:1527628304437};\\\", \\\"{x:599,y:533,t:1527628304453};\\\", \\\"{x:597,y:539,t:1527628304471};\\\", \\\"{x:595,y:544,t:1527628304486};\\\", \\\"{x:594,y:550,t:1527628304503};\\\", \\\"{x:594,y:559,t:1527628304520};\\\", \\\"{x:593,y:568,t:1527628304537};\\\", \\\"{x:591,y:577,t:1527628304553};\\\", \\\"{x:590,y:586,t:1527628304570};\\\", \\\"{x:589,y:594,t:1527628304588};\\\", \\\"{x:586,y:605,t:1527628304603};\\\", \\\"{x:583,y:615,t:1527628304621};\\\", \\\"{x:581,y:625,t:1527628304637};\\\", \\\"{x:579,y:638,t:1527628304653};\\\", \\\"{x:575,y:650,t:1527628304670};\\\", \\\"{x:574,y:664,t:1527628304687};\\\", \\\"{x:572,y:679,t:1527628304703};\\\", \\\"{x:570,y:696,t:1527628304720};\\\", \\\"{x:570,y:707,t:1527628304738};\\\", \\\"{x:569,y:716,t:1527628304753};\\\", \\\"{x:568,y:725,t:1527628304770};\\\", \\\"{x:566,y:731,t:1527628304787};\\\", \\\"{x:566,y:736,t:1527628304803};\\\", \\\"{x:566,y:742,t:1527628304821};\\\", \\\"{x:565,y:746,t:1527628304837};\\\", \\\"{x:565,y:748,t:1527628304853};\\\", \\\"{x:565,y:751,t:1527628304871};\\\", \\\"{x:563,y:753,t:1527628304888};\\\", \\\"{x:561,y:757,t:1527628304903};\\\", \\\"{x:560,y:758,t:1527628304920};\\\", \\\"{x:559,y:761,t:1527628304938};\\\", \\\"{x:558,y:761,t:1527628304954};\\\", \\\"{x:557,y:762,t:1527628304970};\\\", \\\"{x:556,y:763,t:1527628304987};\\\", \\\"{x:556,y:764,t:1527628305005};\\\", \\\"{x:554,y:764,t:1527628305041};\\\", \\\"{x:553,y:764,t:1527628305056};\\\", \\\"{x:551,y:764,t:1527628305072};\\\", \\\"{x:550,y:764,t:1527628305088};\\\", \\\"{x:548,y:764,t:1527628305105};\\\", \\\"{x:547,y:764,t:1527628305120};\\\", \\\"{x:545,y:764,t:1527628305138};\\\", \\\"{x:544,y:764,t:1527628305160};\\\", \\\"{x:543,y:764,t:1527628305171};\\\", \\\"{x:541,y:763,t:1527628305187};\\\", \\\"{x:538,y:763,t:1527628305204};\\\", \\\"{x:536,y:762,t:1527628305222};\\\", \\\"{x:535,y:762,t:1527628305240};\\\", \\\"{x:534,y:761,t:1527628305255};\\\", \\\"{x:532,y:760,t:1527628305272};\\\", \\\"{x:530,y:758,t:1527628305287};\\\", \\\"{x:524,y:754,t:1527628305306};\\\", \\\"{x:523,y:753,t:1527628305321};\\\", \\\"{x:522,y:752,t:1527628305337};\\\", \\\"{x:520,y:751,t:1527628305353};\\\", \\\"{x:519,y:750,t:1527628305375};\\\", \\\"{x:518,y:749,t:1527628305424};\\\", \\\"{x:516,y:749,t:1527628306055};\\\" ] }, { \\\"rt\\\": 132909, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 563018, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:749,t:1527628310665};\\\", \\\"{x:506,y:751,t:1527628310673};\\\", \\\"{x:501,y:753,t:1527628310684};\\\", \\\"{x:498,y:755,t:1527628310702};\\\", \\\"{x:497,y:755,t:1527628310717};\\\", \\\"{x:494,y:757,t:1527628310734};\\\", \\\"{x:491,y:757,t:1527628310758};\\\", \\\"{x:490,y:757,t:1527628311665};\\\", \\\"{x:484,y:757,t:1527628311676};\\\", \\\"{x:466,y:749,t:1527628311694};\\\", \\\"{x:456,y:747,t:1527628311709};\\\", \\\"{x:454,y:747,t:1527628311726};\\\", \\\"{x:454,y:748,t:1527628312960};\\\", \\\"{x:456,y:749,t:1527628312976};\\\", \\\"{x:457,y:750,t:1527628312993};\\\", \\\"{x:457,y:752,t:1527628313216};\\\", \\\"{x:456,y:753,t:1527628314409};\\\", \\\"{x:455,y:753,t:1527628314416};\\\", \\\"{x:454,y:754,t:1527628314428};\\\", \\\"{x:451,y:755,t:1527628314446};\\\", \\\"{x:448,y:757,t:1527628314462};\\\", \\\"{x:444,y:760,t:1527628314478};\\\", \\\"{x:442,y:762,t:1527628314495};\\\", \\\"{x:442,y:763,t:1527628314736};\\\", \\\"{x:442,y:765,t:1527628314745};\\\", \\\"{x:439,y:767,t:1527628314762};\\\", \\\"{x:438,y:767,t:1527628314779};\\\", \\\"{x:437,y:767,t:1527628315368};\\\", \\\"{x:436,y:767,t:1527628317801};\\\", \\\"{x:435,y:767,t:1527628317832};\\\", \\\"{x:435,y:768,t:1527628317848};\\\", \\\"{x:433,y:769,t:1527628318193};\\\", \\\"{x:432,y:769,t:1527628318296};\\\", \\\"{x:431,y:769,t:1527628318304};\\\", \\\"{x:430,y:769,t:1527628318320};\\\", \\\"{x:430,y:770,t:1527628318552};\\\", \\\"{x:429,y:771,t:1527628318896};\\\", \\\"{x:429,y:772,t:1527628318920};\\\", \\\"{x:428,y:772,t:1527628318936};\\\", \\\"{x:427,y:772,t:1527628323640};\\\", \\\"{x:426,y:772,t:1527628323663};\\\", \\\"{x:425,y:772,t:1527628323712};\\\", \\\"{x:424,y:773,t:1527628323744};\\\", \\\"{x:423,y:773,t:1527628323824};\\\", \\\"{x:421,y:774,t:1527628323855};\\\", \\\"{x:420,y:774,t:1527628323880};\\\", \\\"{x:419,y:775,t:1527628323888};\\\", \\\"{x:418,y:775,t:1527628323902};\\\", \\\"{x:417,y:775,t:1527628324082};\\\", \\\"{x:416,y:775,t:1527628324144};\\\", \\\"{x:415,y:776,t:1527628324176};\\\", \\\"{x:414,y:776,t:1527628324896};\\\", \\\"{x:413,y:776,t:1527628324912};\\\", \\\"{x:412,y:776,t:1527628325384};\\\", \\\"{x:411,y:764,t:1527628363027};\\\", \\\"{x:411,y:703,t:1527628363037};\\\", \\\"{x:411,y:614,t:1527628363055};\\\", \\\"{x:448,y:518,t:1527628363071};\\\", \\\"{x:509,y:409,t:1527628363087};\\\", \\\"{x:586,y:295,t:1527628363105};\\\", \\\"{x:663,y:184,t:1527628363121};\\\", \\\"{x:766,y:37,t:1527628363137};\\\", \\\"{x:810,y:0,t:1527628363155};\\\", \\\"{x:821,y:0,t:1527628363171};\\\", \\\"{x:819,y:0,t:1527628363209};\\\", \\\"{x:821,y:0,t:1527628364643};\\\", \\\"{x:825,y:0,t:1527628364656};\\\", \\\"{x:835,y:0,t:1527628364673};\\\", \\\"{x:838,y:0,t:1527628364690};\\\", \\\"{x:839,y:0,t:1527628364706};\\\", \\\"{x:839,y:6,t:1527628365850};\\\", \\\"{x:839,y:21,t:1527628365858};\\\", \\\"{x:839,y:29,t:1527628365873};\\\", \\\"{x:861,y:43,t:1527628365890};\\\", \\\"{x:907,y:51,t:1527628365907};\\\", \\\"{x:988,y:62,t:1527628365924};\\\", \\\"{x:1011,y:67,t:1527628365940};\\\", \\\"{x:1014,y:68,t:1527628365957};\\\", \\\"{x:1019,y:73,t:1527628366147};\\\", \\\"{x:1019,y:76,t:1527628366157};\\\", \\\"{x:1019,y:78,t:1527628366174};\\\", \\\"{x:1019,y:79,t:1527628366194};\\\", \\\"{x:1019,y:80,t:1527628366210};\\\", \\\"{x:1019,y:81,t:1527628366227};\\\", \\\"{x:1018,y:82,t:1527628366240};\\\", \\\"{x:1017,y:82,t:1527628366257};\\\", \\\"{x:1016,y:82,t:1527628366970};\\\", \\\"{x:1014,y:82,t:1527628366978};\\\", \\\"{x:1013,y:82,t:1527628367818};\\\", \\\"{x:1013,y:81,t:1527628368114};\\\", \\\"{x:1013,y:79,t:1527628368130};\\\", \\\"{x:1013,y:78,t:1527628368146};\\\", \\\"{x:1013,y:77,t:1527628368170};\\\", \\\"{x:1013,y:75,t:1527628368178};\\\", \\\"{x:1013,y:74,t:1527628368194};\\\", \\\"{x:1013,y:73,t:1527628368210};\\\", \\\"{x:1014,y:69,t:1527628368225};\\\", \\\"{x:1014,y:67,t:1527628368242};\\\", \\\"{x:1015,y:66,t:1527628368258};\\\", \\\"{x:1015,y:64,t:1527628368282};\\\", \\\"{x:1015,y:62,t:1527628368292};\\\", \\\"{x:1015,y:59,t:1527628368309};\\\", \\\"{x:1015,y:58,t:1527628368395};\\\", \\\"{x:1015,y:57,t:1527628368443};\\\", \\\"{x:1015,y:52,t:1527628368459};\\\", \\\"{x:1015,y:45,t:1527628368475};\\\", \\\"{x:1013,y:41,t:1527628368492};\\\", \\\"{x:1013,y:40,t:1527628368509};\\\", \\\"{x:1013,y:37,t:1527628368526};\\\", \\\"{x:1013,y:34,t:1527628368542};\\\", \\\"{x:1013,y:33,t:1527628368558};\\\", \\\"{x:1012,y:33,t:1527628368610};\\\", \\\"{x:1010,y:33,t:1527628368625};\\\", \\\"{x:1009,y:33,t:1527628368642};\\\", \\\"{x:1007,y:33,t:1527628368658};\\\", \\\"{x:1006,y:33,t:1527628368675};\\\", \\\"{x:1004,y:33,t:1527628368692};\\\", \\\"{x:999,y:33,t:1527628368709};\\\", \\\"{x:997,y:33,t:1527628368726};\\\", \\\"{x:994,y:33,t:1527628368742};\\\", \\\"{x:993,y:33,t:1527628368758};\\\", \\\"{x:991,y:33,t:1527628368775};\\\", \\\"{x:990,y:33,t:1527628368794};\\\", \\\"{x:988,y:33,t:1527628368809};\\\", \\\"{x:987,y:33,t:1527628368826};\\\", \\\"{x:986,y:33,t:1527628368842};\\\", \\\"{x:983,y:35,t:1527628368859};\\\", \\\"{x:980,y:36,t:1527628368876};\\\", \\\"{x:979,y:36,t:1527628368906};\\\", \\\"{x:977,y:37,t:1527628368914};\\\", \\\"{x:976,y:38,t:1527628368926};\\\", \\\"{x:973,y:38,t:1527628368941};\\\", \\\"{x:970,y:40,t:1527628368959};\\\", \\\"{x:968,y:41,t:1527628368976};\\\", \\\"{x:966,y:42,t:1527628369411};\\\", \\\"{x:965,y:42,t:1527628369507};\\\", \\\"{x:964,y:41,t:1527628369515};\\\", \\\"{x:963,y:41,t:1527628369547};\\\", \\\"{x:961,y:42,t:1527628370475};\\\", \\\"{x:960,y:44,t:1527628370483};\\\", \\\"{x:956,y:52,t:1527628370494};\\\", \\\"{x:951,y:62,t:1527628370510};\\\", \\\"{x:948,y:65,t:1527628370527};\\\", \\\"{x:945,y:65,t:1527628370626};\\\", \\\"{x:936,y:65,t:1527628370645};\\\", \\\"{x:927,y:65,t:1527628370660};\\\", \\\"{x:918,y:64,t:1527628370677};\\\", \\\"{x:913,y:64,t:1527628370694};\\\", \\\"{x:909,y:64,t:1527628370711};\\\", \\\"{x:905,y:64,t:1527628373819};\\\", \\\"{x:890,y:64,t:1527628373829};\\\", \\\"{x:821,y:64,t:1527628373846};\\\", \\\"{x:685,y:46,t:1527628373863};\\\", \\\"{x:620,y:34,t:1527628373880};\\\", \\\"{x:618,y:34,t:1527628373896};\\\", \\\"{x:618,y:35,t:1527628376842};\\\", \\\"{x:626,y:44,t:1527628376850};\\\", \\\"{x:641,y:59,t:1527628376866};\\\", \\\"{x:704,y:128,t:1527628376882};\\\", \\\"{x:768,y:197,t:1527628376899};\\\", \\\"{x:855,y:287,t:1527628376915};\\\", \\\"{x:945,y:379,t:1527628376933};\\\", \\\"{x:1023,y:462,t:1527628376950};\\\", \\\"{x:1085,y:536,t:1527628376966};\\\", \\\"{x:1127,y:590,t:1527628376982};\\\", \\\"{x:1148,y:623,t:1527628376999};\\\", \\\"{x:1158,y:643,t:1527628377016};\\\", \\\"{x:1163,y:657,t:1527628377033};\\\", \\\"{x:1168,y:671,t:1527628377050};\\\", \\\"{x:1178,y:694,t:1527628377066};\\\", \\\"{x:1200,y:749,t:1527628377082};\\\", \\\"{x:1218,y:785,t:1527628377099};\\\", \\\"{x:1224,y:801,t:1527628377115};\\\", \\\"{x:1224,y:804,t:1527628377132};\\\", \\\"{x:1224,y:806,t:1527628377149};\\\", \\\"{x:1224,y:807,t:1527628377165};\\\", \\\"{x:1224,y:810,t:1527628377182};\\\", \\\"{x:1225,y:811,t:1527628377199};\\\", \\\"{x:1226,y:811,t:1527628377931};\\\", \\\"{x:1233,y:816,t:1527628377938};\\\", \\\"{x:1238,y:826,t:1527628377950};\\\", \\\"{x:1243,y:844,t:1527628377966};\\\", \\\"{x:1243,y:849,t:1527628377983};\\\", \\\"{x:1243,y:852,t:1527628378000};\\\", \\\"{x:1243,y:853,t:1527628378016};\\\", \\\"{x:1242,y:853,t:1527628378075};\\\", \\\"{x:1242,y:854,t:1527628382898};\\\", \\\"{x:1241,y:854,t:1527628382945};\\\", \\\"{x:1240,y:854,t:1527628434110};\\\", \\\"{x:1229,y:846,t:1527628434117};\\\", \\\"{x:1177,y:799,t:1527628434132};\\\", \\\"{x:1125,y:743,t:1527628434149};\\\", \\\"{x:1099,y:711,t:1527628434166};\\\", \\\"{x:1097,y:707,t:1527628434182};\\\", \\\"{x:1102,y:706,t:1527628434199};\\\", \\\"{x:1114,y:703,t:1527628434215};\\\", \\\"{x:1132,y:703,t:1527628434233};\\\", \\\"{x:1146,y:705,t:1527628434249};\\\", \\\"{x:1148,y:705,t:1527628434265};\\\", \\\"{x:1154,y:704,t:1527628434282};\\\", \\\"{x:1169,y:693,t:1527628434299};\\\", \\\"{x:1213,y:671,t:1527628434316};\\\", \\\"{x:1263,y:657,t:1527628434333};\\\", \\\"{x:1284,y:656,t:1527628434349};\\\", \\\"{x:1302,y:651,t:1527628434365};\\\", \\\"{x:1314,y:648,t:1527628434383};\\\", \\\"{x:1318,y:645,t:1527628434399};\\\", \\\"{x:1319,y:645,t:1527628434677};\\\", \\\"{x:1319,y:644,t:1527628435293};\\\", \\\"{x:1319,y:643,t:1527628435301};\\\", \\\"{x:1319,y:640,t:1527628435317};\\\", \\\"{x:1319,y:639,t:1527628435332};\\\", \\\"{x:1319,y:636,t:1527628435357};\\\", \\\"{x:1316,y:635,t:1527628435366};\\\", \\\"{x:1307,y:631,t:1527628435383};\\\", \\\"{x:1301,y:631,t:1527628435399};\\\", \\\"{x:1292,y:628,t:1527628435416};\\\", \\\"{x:1283,y:626,t:1527628435433};\\\", \\\"{x:1273,y:621,t:1527628435450};\\\", \\\"{x:1260,y:618,t:1527628435467};\\\", \\\"{x:1252,y:618,t:1527628435483};\\\", \\\"{x:1244,y:618,t:1527628435500};\\\", \\\"{x:1208,y:618,t:1527628435517};\\\", \\\"{x:1177,y:618,t:1527628435533};\\\", \\\"{x:1143,y:618,t:1527628435550};\\\", \\\"{x:1096,y:625,t:1527628435566};\\\", \\\"{x:1050,y:628,t:1527628435584};\\\", \\\"{x:1007,y:635,t:1527628435600};\\\", \\\"{x:965,y:640,t:1527628435617};\\\", \\\"{x:917,y:642,t:1527628435633};\\\", \\\"{x:856,y:642,t:1527628435649};\\\", \\\"{x:778,y:630,t:1527628435668};\\\", \\\"{x:697,y:608,t:1527628435685};\\\", \\\"{x:628,y:588,t:1527628435699};\\\", \\\"{x:570,y:573,t:1527628435715};\\\", \\\"{x:514,y:558,t:1527628435732};\\\", \\\"{x:491,y:550,t:1527628435749};\\\", \\\"{x:476,y:547,t:1527628435767};\\\", \\\"{x:467,y:545,t:1527628435785};\\\", \\\"{x:461,y:545,t:1527628435801};\\\", \\\"{x:460,y:545,t:1527628435817};\\\", \\\"{x:457,y:545,t:1527628435835};\\\", \\\"{x:453,y:545,t:1527628435852};\\\", \\\"{x:450,y:546,t:1527628435868};\\\", \\\"{x:448,y:548,t:1527628435885};\\\", \\\"{x:446,y:548,t:1527628435902};\\\", \\\"{x:446,y:549,t:1527628436085};\\\", \\\"{x:454,y:553,t:1527628436102};\\\", \\\"{x:465,y:558,t:1527628436120};\\\", \\\"{x:468,y:561,t:1527628436135};\\\", \\\"{x:469,y:561,t:1527628436152};\\\", \\\"{x:469,y:562,t:1527628436169};\\\", \\\"{x:469,y:566,t:1527628436186};\\\", \\\"{x:469,y:568,t:1527628436202};\\\", \\\"{x:468,y:570,t:1527628436219};\\\", \\\"{x:467,y:574,t:1527628436235};\\\", \\\"{x:465,y:578,t:1527628436252};\\\", \\\"{x:465,y:582,t:1527628436268};\\\", \\\"{x:465,y:583,t:1527628436285};\\\", \\\"{x:465,y:584,t:1527628436325};\\\", \\\"{x:465,y:585,t:1527628436335};\\\", \\\"{x:464,y:585,t:1527628436421};\\\", \\\"{x:463,y:585,t:1527628436435};\\\", \\\"{x:460,y:584,t:1527628436453};\\\", \\\"{x:453,y:583,t:1527628436469};\\\", \\\"{x:441,y:583,t:1527628436486};\\\", \\\"{x:430,y:583,t:1527628436503};\\\", \\\"{x:416,y:583,t:1527628436520};\\\", \\\"{x:401,y:583,t:1527628436536};\\\", \\\"{x:380,y:583,t:1527628436552};\\\", \\\"{x:355,y:583,t:1527628436569};\\\", \\\"{x:321,y:583,t:1527628436585};\\\", \\\"{x:270,y:586,t:1527628436603};\\\", \\\"{x:238,y:587,t:1527628436619};\\\", \\\"{x:202,y:587,t:1527628436636};\\\", \\\"{x:185,y:587,t:1527628436653};\\\", \\\"{x:177,y:587,t:1527628436669};\\\", \\\"{x:176,y:587,t:1527628436686};\\\", \\\"{x:175,y:586,t:1527628436708};\\\", \\\"{x:172,y:583,t:1527628436724};\\\", \\\"{x:172,y:579,t:1527628436736};\\\", \\\"{x:169,y:572,t:1527628436752};\\\", \\\"{x:166,y:563,t:1527628436769};\\\", \\\"{x:164,y:557,t:1527628436786};\\\", \\\"{x:161,y:551,t:1527628436803};\\\", \\\"{x:159,y:542,t:1527628436819};\\\", \\\"{x:153,y:519,t:1527628436837};\\\", \\\"{x:150,y:513,t:1527628436853};\\\", \\\"{x:149,y:507,t:1527628436869};\\\", \\\"{x:149,y:502,t:1527628436886};\\\", \\\"{x:149,y:499,t:1527628436903};\\\", \\\"{x:149,y:496,t:1527628436918};\\\", \\\"{x:149,y:495,t:1527628436936};\\\", \\\"{x:149,y:493,t:1527628436953};\\\", \\\"{x:149,y:492,t:1527628436969};\\\", \\\"{x:149,y:491,t:1527628436986};\\\", \\\"{x:149,y:490,t:1527628437004};\\\", \\\"{x:158,y:495,t:1527628437302};\\\", \\\"{x:224,y:524,t:1527628437320};\\\", \\\"{x:269,y:544,t:1527628437337};\\\", \\\"{x:293,y:555,t:1527628437354};\\\", \\\"{x:306,y:561,t:1527628437371};\\\", \\\"{x:308,y:562,t:1527628437386};\\\", \\\"{x:309,y:563,t:1527628437462};\\\", \\\"{x:307,y:564,t:1527628437596};\\\", \\\"{x:297,y:561,t:1527628437605};\\\", \\\"{x:276,y:551,t:1527628437621};\\\", \\\"{x:265,y:546,t:1527628437636};\\\", \\\"{x:259,y:544,t:1527628437653};\\\", \\\"{x:253,y:542,t:1527628437670};\\\", \\\"{x:247,y:537,t:1527628437686};\\\", \\\"{x:234,y:530,t:1527628437704};\\\", \\\"{x:218,y:520,t:1527628437721};\\\", \\\"{x:201,y:507,t:1527628437739};\\\", \\\"{x:184,y:498,t:1527628437753};\\\", \\\"{x:172,y:491,t:1527628437770};\\\", \\\"{x:157,y:482,t:1527628437787};\\\", \\\"{x:142,y:477,t:1527628437803};\\\", \\\"{x:136,y:475,t:1527628437819};\\\", \\\"{x:135,y:474,t:1527628437837};\\\", \\\"{x:135,y:473,t:1527628437860};\\\", \\\"{x:136,y:473,t:1527628437956};\\\", \\\"{x:139,y:476,t:1527628437971};\\\", \\\"{x:143,y:493,t:1527628437988};\\\", \\\"{x:146,y:499,t:1527628438002};\\\", \\\"{x:148,y:502,t:1527628438020};\\\", \\\"{x:149,y:502,t:1527628438052};\\\", \\\"{x:150,y:502,t:1527628438197};\\\", \\\"{x:152,y:501,t:1527628438213};\\\", \\\"{x:153,y:500,t:1527628438221};\\\", \\\"{x:156,y:498,t:1527628438237};\\\", \\\"{x:156,y:497,t:1527628438253};\\\", \\\"{x:157,y:497,t:1527628438308};\\\", \\\"{x:158,y:497,t:1527628438332};\\\", \\\"{x:158,y:497,t:1527628438407};\\\", \\\"{x:159,y:497,t:1527628438484};\\\", \\\"{x:161,y:498,t:1527628438491};\\\", \\\"{x:166,y:505,t:1527628438504};\\\", \\\"{x:176,y:521,t:1527628438520};\\\", \\\"{x:217,y:548,t:1527628438538};\\\", \\\"{x:268,y:585,t:1527628438555};\\\", \\\"{x:303,y:615,t:1527628438570};\\\", \\\"{x:325,y:631,t:1527628438586};\\\", \\\"{x:329,y:635,t:1527628438604};\\\", \\\"{x:330,y:636,t:1527628438628};\\\", \\\"{x:331,y:637,t:1527628438637};\\\", \\\"{x:333,y:639,t:1527628438655};\\\", \\\"{x:334,y:641,t:1527628438671};\\\", \\\"{x:334,y:642,t:1527628438692};\\\", \\\"{x:334,y:643,t:1527628438704};\\\", \\\"{x:335,y:644,t:1527628438721};\\\", \\\"{x:342,y:649,t:1527628438737};\\\", \\\"{x:363,y:662,t:1527628438754};\\\", \\\"{x:403,y:696,t:1527628438773};\\\", \\\"{x:487,y:760,t:1527628438788};\\\", \\\"{x:614,y:860,t:1527628438804};\\\", \\\"{x:654,y:891,t:1527628438821};\\\", \\\"{x:664,y:896,t:1527628438837};\\\", \\\"{x:665,y:896,t:1527628438854};\\\", \\\"{x:666,y:896,t:1527628438870};\\\", \\\"{x:670,y:896,t:1527628438888};\\\", \\\"{x:676,y:896,t:1527628438904};\\\", \\\"{x:684,y:891,t:1527628438921};\\\", \\\"{x:689,y:872,t:1527628438938};\\\", \\\"{x:693,y:845,t:1527628438955};\\\", \\\"{x:694,y:839,t:1527628438971};\\\", \\\"{x:698,y:835,t:1527628438988};\\\", \\\"{x:701,y:828,t:1527628439005};\\\", \\\"{x:701,y:824,t:1527628439021};\\\", \\\"{x:698,y:814,t:1527628439038};\\\", \\\"{x:682,y:799,t:1527628439054};\\\", \\\"{x:659,y:784,t:1527628439071};\\\", \\\"{x:632,y:774,t:1527628439088};\\\", \\\"{x:600,y:758,t:1527628439104};\\\", \\\"{x:563,y:744,t:1527628439121};\\\", \\\"{x:518,y:732,t:1527628439137};\\\", \\\"{x:477,y:720,t:1527628439154};\\\", \\\"{x:446,y:712,t:1527628439172};\\\", \\\"{x:408,y:706,t:1527628439188};\\\", \\\"{x:402,y:704,t:1527628439204};\\\", \\\"{x:403,y:704,t:1527628439349};\\\", \\\"{x:405,y:704,t:1527628439356};\\\", \\\"{x:407,y:704,t:1527628439372};\\\", \\\"{x:419,y:713,t:1527628439388};\\\", \\\"{x:433,y:723,t:1527628439405};\\\", \\\"{x:452,y:734,t:1527628439422};\\\", \\\"{x:467,y:740,t:1527628439438};\\\", \\\"{x:476,y:745,t:1527628439454};\\\", \\\"{x:480,y:746,t:1527628439472};\\\", \\\"{x:483,y:746,t:1527628439489};\\\", \\\"{x:484,y:746,t:1527628439541};\\\", \\\"{x:487,y:746,t:1527628439555};\\\", \\\"{x:490,y:746,t:1527628439572};\\\", \\\"{x:491,y:746,t:1527628439588};\\\", \\\"{x:493,y:746,t:1527628439612};\\\", \\\"{x:494,y:745,t:1527628439683};\\\", \\\"{x:495,y:744,t:1527628439700};\\\", \\\"{x:496,y:744,t:1527628439723};\\\", \\\"{x:496,y:743,t:1527628439738};\\\", \\\"{x:498,y:741,t:1527628439754};\\\", \\\"{x:499,y:741,t:1527628439771};\\\", \\\"{x:500,y:740,t:1527628439788};\\\", \\\"{x:501,y:740,t:1527628439805};\\\" ] }, { \\\"rt\\\": 45717, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 610339, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O -F -B -X -X -X -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:739,t:1527628446429};\\\", \\\"{x:515,y:736,t:1527628446444};\\\", \\\"{x:556,y:720,t:1527628446460};\\\", \\\"{x:572,y:714,t:1527628446478};\\\", \\\"{x:593,y:708,t:1527628446493};\\\", \\\"{x:617,y:704,t:1527628446510};\\\", \\\"{x:650,y:699,t:1527628446528};\\\", \\\"{x:700,y:694,t:1527628446543};\\\", \\\"{x:765,y:682,t:1527628446561};\\\", \\\"{x:842,y:673,t:1527628446577};\\\", \\\"{x:904,y:670,t:1527628446594};\\\", \\\"{x:963,y:670,t:1527628446611};\\\", \\\"{x:1024,y:670,t:1527628446628};\\\", \\\"{x:1100,y:670,t:1527628446644};\\\", \\\"{x:1147,y:670,t:1527628446661};\\\", \\\"{x:1187,y:670,t:1527628446678};\\\", \\\"{x:1219,y:669,t:1527628446695};\\\", \\\"{x:1246,y:664,t:1527628446711};\\\", \\\"{x:1262,y:663,t:1527628446727};\\\", \\\"{x:1269,y:660,t:1527628446745};\\\", \\\"{x:1271,y:659,t:1527628446760};\\\", \\\"{x:1274,y:657,t:1527628446778};\\\", \\\"{x:1277,y:654,t:1527628446795};\\\", \\\"{x:1281,y:649,t:1527628446812};\\\", \\\"{x:1287,y:639,t:1527628446828};\\\", \\\"{x:1299,y:620,t:1527628446844};\\\", \\\"{x:1308,y:602,t:1527628446862};\\\", \\\"{x:1318,y:586,t:1527628446877};\\\", \\\"{x:1325,y:574,t:1527628446895};\\\", \\\"{x:1329,y:567,t:1527628446911};\\\", \\\"{x:1329,y:565,t:1527628446928};\\\", \\\"{x:1330,y:564,t:1527628446945};\\\", \\\"{x:1331,y:564,t:1527628447141};\\\", \\\"{x:1331,y:563,t:1527628447149};\\\", \\\"{x:1333,y:558,t:1527628447163};\\\", \\\"{x:1347,y:545,t:1527628447179};\\\", \\\"{x:1363,y:532,t:1527628447195};\\\", \\\"{x:1373,y:522,t:1527628447212};\\\", \\\"{x:1379,y:515,t:1527628447228};\\\", \\\"{x:1383,y:510,t:1527628447245};\\\", \\\"{x:1385,y:505,t:1527628447262};\\\", \\\"{x:1386,y:503,t:1527628447279};\\\", \\\"{x:1387,y:499,t:1527628447296};\\\", \\\"{x:1389,y:494,t:1527628447312};\\\", \\\"{x:1390,y:489,t:1527628447329};\\\", \\\"{x:1391,y:485,t:1527628447346};\\\", \\\"{x:1392,y:482,t:1527628447362};\\\", \\\"{x:1394,y:479,t:1527628447379};\\\", \\\"{x:1394,y:478,t:1527628447396};\\\", \\\"{x:1394,y:482,t:1527628447500};\\\", \\\"{x:1392,y:483,t:1527628447512};\\\", \\\"{x:1388,y:486,t:1527628447528};\\\", \\\"{x:1386,y:487,t:1527628447546};\\\", \\\"{x:1385,y:487,t:1527628447686};\\\", \\\"{x:1384,y:489,t:1527628447697};\\\", \\\"{x:1382,y:489,t:1527628447713};\\\", \\\"{x:1381,y:490,t:1527628447729};\\\", \\\"{x:1379,y:491,t:1527628447746};\\\", \\\"{x:1378,y:491,t:1527628447765};\\\", \\\"{x:1377,y:491,t:1527628447797};\\\", \\\"{x:1377,y:492,t:1527628447829};\\\", \\\"{x:1376,y:493,t:1527628447837};\\\", \\\"{x:1375,y:493,t:1527628447852};\\\", \\\"{x:1373,y:494,t:1527628447864};\\\", \\\"{x:1368,y:497,t:1527628447879};\\\", \\\"{x:1363,y:501,t:1527628447895};\\\", \\\"{x:1353,y:508,t:1527628447912};\\\", \\\"{x:1341,y:514,t:1527628447930};\\\", \\\"{x:1330,y:519,t:1527628447946};\\\", \\\"{x:1324,y:521,t:1527628447962};\\\", \\\"{x:1322,y:523,t:1527628447979};\\\", \\\"{x:1321,y:523,t:1527628447996};\\\", \\\"{x:1320,y:524,t:1527628448036};\\\", \\\"{x:1319,y:524,t:1527628448077};\\\", \\\"{x:1318,y:526,t:1527628448084};\\\", \\\"{x:1316,y:527,t:1527628448100};\\\", \\\"{x:1315,y:527,t:1527628448124};\\\", \\\"{x:1313,y:528,t:1527628448565};\\\", \\\"{x:1311,y:529,t:1527628448596};\\\", \\\"{x:1310,y:529,t:1527628448637};\\\", \\\"{x:1309,y:529,t:1527628448646};\\\", \\\"{x:1308,y:530,t:1527628448663};\\\", \\\"{x:1307,y:531,t:1527628448681};\\\", \\\"{x:1306,y:531,t:1527628448697};\\\", \\\"{x:1305,y:531,t:1527628448731};\\\", \\\"{x:1304,y:531,t:1527628448788};\\\", \\\"{x:1303,y:531,t:1527628448828};\\\", \\\"{x:1301,y:532,t:1527628448869};\\\", \\\"{x:1299,y:533,t:1527628448892};\\\", \\\"{x:1296,y:534,t:1527628448909};\\\", \\\"{x:1295,y:534,t:1527628449789};\\\", \\\"{x:1294,y:534,t:1527628449799};\\\", \\\"{x:1293,y:534,t:1527628449817};\\\", \\\"{x:1292,y:534,t:1527628449861};\\\", \\\"{x:1291,y:534,t:1527628449884};\\\", \\\"{x:1290,y:534,t:1527628449900};\\\", \\\"{x:1289,y:534,t:1527628449916};\\\", \\\"{x:1288,y:536,t:1527628449933};\\\", \\\"{x:1287,y:536,t:1527628449949};\\\", \\\"{x:1286,y:536,t:1527628449966};\\\", \\\"{x:1284,y:536,t:1527628449983};\\\", \\\"{x:1283,y:536,t:1527628450021};\\\", \\\"{x:1282,y:536,t:1527628450085};\\\", \\\"{x:1281,y:536,t:1527628450613};\\\", \\\"{x:1281,y:537,t:1527628450621};\\\", \\\"{x:1280,y:537,t:1527628450634};\\\", \\\"{x:1277,y:539,t:1527628450650};\\\", \\\"{x:1275,y:540,t:1527628450668};\\\", \\\"{x:1270,y:543,t:1527628450684};\\\", \\\"{x:1268,y:543,t:1527628450701};\\\", \\\"{x:1266,y:544,t:1527628450717};\\\", \\\"{x:1265,y:545,t:1527628450734};\\\", \\\"{x:1264,y:545,t:1527628450751};\\\", \\\"{x:1263,y:546,t:1527628450768};\\\", \\\"{x:1262,y:550,t:1527628450901};\\\", \\\"{x:1261,y:560,t:1527628450919};\\\", \\\"{x:1261,y:581,t:1527628450934};\\\", \\\"{x:1261,y:608,t:1527628450951};\\\", \\\"{x:1264,y:654,t:1527628450968};\\\", \\\"{x:1279,y:710,t:1527628450984};\\\", \\\"{x:1292,y:750,t:1527628451001};\\\", \\\"{x:1297,y:772,t:1527628451018};\\\", \\\"{x:1301,y:788,t:1527628451034};\\\", \\\"{x:1305,y:803,t:1527628451052};\\\", \\\"{x:1307,y:812,t:1527628451069};\\\", \\\"{x:1309,y:817,t:1527628451085};\\\", \\\"{x:1310,y:817,t:1527628451101};\\\", \\\"{x:1311,y:817,t:1527628451119};\\\", \\\"{x:1317,y:817,t:1527628451135};\\\", \\\"{x:1329,y:809,t:1527628451151};\\\", \\\"{x:1338,y:804,t:1527628451168};\\\", \\\"{x:1343,y:797,t:1527628451185};\\\", \\\"{x:1350,y:786,t:1527628451201};\\\", \\\"{x:1359,y:771,t:1527628451218};\\\", \\\"{x:1375,y:751,t:1527628451235};\\\", \\\"{x:1389,y:737,t:1527628451252};\\\", \\\"{x:1397,y:729,t:1527628451268};\\\", \\\"{x:1406,y:720,t:1527628451284};\\\", \\\"{x:1409,y:714,t:1527628451302};\\\", \\\"{x:1412,y:709,t:1527628451317};\\\", \\\"{x:1413,y:705,t:1527628451334};\\\", \\\"{x:1418,y:700,t:1527628451351};\\\", \\\"{x:1420,y:698,t:1527628451368};\\\", \\\"{x:1422,y:695,t:1527628451385};\\\", \\\"{x:1424,y:693,t:1527628451401};\\\", \\\"{x:1426,y:692,t:1527628451417};\\\", \\\"{x:1426,y:691,t:1527628451435};\\\", \\\"{x:1427,y:691,t:1527628451451};\\\", \\\"{x:1427,y:694,t:1527628451556};\\\", \\\"{x:1427,y:697,t:1527628451568};\\\", \\\"{x:1427,y:702,t:1527628451584};\\\", \\\"{x:1427,y:705,t:1527628451601};\\\", \\\"{x:1427,y:706,t:1527628451618};\\\", \\\"{x:1427,y:707,t:1527628451635};\\\", \\\"{x:1427,y:708,t:1527628451651};\\\", \\\"{x:1428,y:707,t:1527628451837};\\\", \\\"{x:1435,y:703,t:1527628451852};\\\", \\\"{x:1443,y:699,t:1527628451869};\\\", \\\"{x:1451,y:694,t:1527628451885};\\\", \\\"{x:1458,y:690,t:1527628451901};\\\", \\\"{x:1466,y:687,t:1527628451919};\\\", \\\"{x:1472,y:685,t:1527628451935};\\\", \\\"{x:1478,y:681,t:1527628451952};\\\", \\\"{x:1483,y:680,t:1527628451969};\\\", \\\"{x:1487,y:677,t:1527628451985};\\\", \\\"{x:1491,y:677,t:1527628452003};\\\", \\\"{x:1494,y:676,t:1527628452019};\\\", \\\"{x:1495,y:676,t:1527628452052};\\\", \\\"{x:1496,y:676,t:1527628452092};\\\", \\\"{x:1498,y:676,t:1527628452103};\\\", \\\"{x:1500,y:682,t:1527628452119};\\\", \\\"{x:1500,y:686,t:1527628452135};\\\", \\\"{x:1502,y:693,t:1527628452153};\\\", \\\"{x:1502,y:697,t:1527628452168};\\\", \\\"{x:1502,y:701,t:1527628452186};\\\", \\\"{x:1502,y:703,t:1527628452202};\\\", \\\"{x:1502,y:704,t:1527628452219};\\\", \\\"{x:1502,y:705,t:1527628452285};\\\", \\\"{x:1501,y:705,t:1527628452437};\\\", \\\"{x:1500,y:705,t:1527628452453};\\\", \\\"{x:1499,y:704,t:1527628452470};\\\", \\\"{x:1498,y:703,t:1527628452487};\\\", \\\"{x:1497,y:700,t:1527628452504};\\\", \\\"{x:1497,y:699,t:1527628452520};\\\", \\\"{x:1497,y:697,t:1527628452538};\\\", \\\"{x:1497,y:696,t:1527628452556};\\\", \\\"{x:1497,y:694,t:1527628452569};\\\", \\\"{x:1497,y:692,t:1527628452596};\\\", \\\"{x:1497,y:691,t:1527628452604};\\\", \\\"{x:1498,y:690,t:1527628452620};\\\", \\\"{x:1503,y:687,t:1527628452637};\\\", \\\"{x:1508,y:685,t:1527628452653};\\\", \\\"{x:1512,y:683,t:1527628452670};\\\", \\\"{x:1519,y:680,t:1527628452686};\\\", \\\"{x:1521,y:679,t:1527628452703};\\\", \\\"{x:1523,y:679,t:1527628452719};\\\", \\\"{x:1525,y:679,t:1527628452737};\\\", \\\"{x:1528,y:678,t:1527628452754};\\\", \\\"{x:1530,y:678,t:1527628452770};\\\", \\\"{x:1531,y:678,t:1527628452787};\\\", \\\"{x:1532,y:678,t:1527628452804};\\\", \\\"{x:1533,y:678,t:1527628452820};\\\", \\\"{x:1535,y:678,t:1527628452837};\\\", \\\"{x:1538,y:681,t:1527628452854};\\\", \\\"{x:1539,y:684,t:1527628452870};\\\", \\\"{x:1540,y:688,t:1527628452887};\\\", \\\"{x:1542,y:691,t:1527628452904};\\\", \\\"{x:1543,y:694,t:1527628452921};\\\", \\\"{x:1544,y:698,t:1527628452937};\\\", \\\"{x:1546,y:701,t:1527628452953};\\\", \\\"{x:1547,y:704,t:1527628452970};\\\", \\\"{x:1548,y:705,t:1527628453044};\\\", \\\"{x:1549,y:705,t:1527628453067};\\\", \\\"{x:1550,y:704,t:1527628453075};\\\", \\\"{x:1551,y:702,t:1527628453087};\\\", \\\"{x:1553,y:697,t:1527628453103};\\\", \\\"{x:1555,y:693,t:1527628453120};\\\", \\\"{x:1560,y:689,t:1527628453137};\\\", \\\"{x:1571,y:683,t:1527628453153};\\\", \\\"{x:1577,y:681,t:1527628453171};\\\", \\\"{x:1580,y:680,t:1527628453187};\\\", \\\"{x:1581,y:680,t:1527628453204};\\\", \\\"{x:1582,y:680,t:1527628453284};\\\", \\\"{x:1584,y:680,t:1527628453291};\\\", \\\"{x:1585,y:680,t:1527628453303};\\\", \\\"{x:1588,y:680,t:1527628453320};\\\", \\\"{x:1590,y:680,t:1527628453337};\\\", \\\"{x:1596,y:682,t:1527628453354};\\\", \\\"{x:1604,y:690,t:1527628453371};\\\", \\\"{x:1614,y:698,t:1527628453388};\\\", \\\"{x:1620,y:703,t:1527628453405};\\\", \\\"{x:1624,y:707,t:1527628453420};\\\", \\\"{x:1626,y:709,t:1527628453438};\\\", \\\"{x:1627,y:711,t:1527628453455};\\\", \\\"{x:1628,y:711,t:1527628453470};\\\", \\\"{x:1629,y:712,t:1527628453500};\\\", \\\"{x:1630,y:712,t:1527628453828};\\\", \\\"{x:1631,y:712,t:1527628453924};\\\", \\\"{x:1632,y:712,t:1527628453939};\\\", \\\"{x:1633,y:711,t:1527628454028};\\\", \\\"{x:1633,y:710,t:1527628454060};\\\", \\\"{x:1633,y:709,t:1527628454072};\\\", \\\"{x:1633,y:708,t:1527628454088};\\\", \\\"{x:1633,y:706,t:1527628454105};\\\", \\\"{x:1633,y:705,t:1527628454122};\\\", \\\"{x:1633,y:701,t:1527628454139};\\\", \\\"{x:1633,y:694,t:1527628454155};\\\", \\\"{x:1633,y:689,t:1527628454171};\\\", \\\"{x:1633,y:687,t:1527628454189};\\\", \\\"{x:1633,y:686,t:1527628454206};\\\", \\\"{x:1633,y:684,t:1527628454221};\\\", \\\"{x:1632,y:684,t:1527628455387};\\\", \\\"{x:1631,y:684,t:1527628455419};\\\", \\\"{x:1631,y:683,t:1527628455435};\\\", \\\"{x:1630,y:683,t:1527628455580};\\\", \\\"{x:1629,y:683,t:1527628455676};\\\", \\\"{x:1628,y:683,t:1527628455836};\\\", \\\"{x:1627,y:682,t:1527628455851};\\\", \\\"{x:1627,y:681,t:1527628455868};\\\", \\\"{x:1626,y:680,t:1527628455884};\\\", \\\"{x:1625,y:680,t:1527628455908};\\\", \\\"{x:1625,y:679,t:1527628456164};\\\", \\\"{x:1624,y:678,t:1527628456175};\\\", \\\"{x:1623,y:677,t:1527628456192};\\\", \\\"{x:1622,y:675,t:1527628456212};\\\", \\\"{x:1621,y:673,t:1527628456225};\\\", \\\"{x:1620,y:670,t:1527628456242};\\\", \\\"{x:1619,y:668,t:1527628456259};\\\", \\\"{x:1618,y:667,t:1527628456275};\\\", \\\"{x:1617,y:665,t:1527628456292};\\\", \\\"{x:1617,y:664,t:1527628456309};\\\", \\\"{x:1616,y:664,t:1527628456326};\\\", \\\"{x:1616,y:662,t:1527628456342};\\\", \\\"{x:1616,y:661,t:1527628456364};\\\", \\\"{x:1616,y:659,t:1527628456436};\\\", \\\"{x:1616,y:658,t:1527628456451};\\\", \\\"{x:1615,y:658,t:1527628456459};\\\", \\\"{x:1614,y:656,t:1527628456484};\\\", \\\"{x:1614,y:655,t:1527628456499};\\\", \\\"{x:1613,y:654,t:1527628456523};\\\", \\\"{x:1613,y:653,t:1527628456588};\\\", \\\"{x:1612,y:653,t:1527628456932};\\\", \\\"{x:1609,y:653,t:1527628456943};\\\", \\\"{x:1604,y:660,t:1527628456960};\\\", \\\"{x:1596,y:670,t:1527628456976};\\\", \\\"{x:1585,y:683,t:1527628456993};\\\", \\\"{x:1575,y:695,t:1527628457010};\\\", \\\"{x:1566,y:704,t:1527628457027};\\\", \\\"{x:1561,y:709,t:1527628457043};\\\", \\\"{x:1561,y:710,t:1527628457059};\\\", \\\"{x:1560,y:712,t:1527628457077};\\\", \\\"{x:1558,y:714,t:1527628457093};\\\", \\\"{x:1558,y:715,t:1527628457110};\\\", \\\"{x:1558,y:716,t:1527628457127};\\\", \\\"{x:1558,y:717,t:1527628457147};\\\", \\\"{x:1557,y:719,t:1527628457164};\\\", \\\"{x:1556,y:720,t:1527628457179};\\\", \\\"{x:1555,y:721,t:1527628457204};\\\", \\\"{x:1554,y:723,t:1527628457211};\\\", \\\"{x:1554,y:724,t:1527628457228};\\\", \\\"{x:1552,y:728,t:1527628457244};\\\", \\\"{x:1551,y:729,t:1527628457259};\\\", \\\"{x:1550,y:731,t:1527628457277};\\\", \\\"{x:1549,y:732,t:1527628457293};\\\", \\\"{x:1548,y:733,t:1527628457310};\\\", \\\"{x:1546,y:736,t:1527628457540};\\\", \\\"{x:1544,y:738,t:1527628457548};\\\", \\\"{x:1542,y:741,t:1527628457561};\\\", \\\"{x:1538,y:746,t:1527628457577};\\\", \\\"{x:1533,y:752,t:1527628457593};\\\", \\\"{x:1532,y:754,t:1527628457610};\\\", \\\"{x:1530,y:756,t:1527628457627};\\\", \\\"{x:1529,y:758,t:1527628457643};\\\", \\\"{x:1527,y:758,t:1527628457661};\\\", \\\"{x:1526,y:759,t:1527628457684};\\\", \\\"{x:1525,y:760,t:1527628457732};\\\", \\\"{x:1524,y:760,t:1527628457780};\\\", \\\"{x:1524,y:761,t:1527628457795};\\\", \\\"{x:1523,y:761,t:1527628457811};\\\", \\\"{x:1520,y:762,t:1527628457827};\\\", \\\"{x:1519,y:762,t:1527628457844};\\\", \\\"{x:1519,y:763,t:1527628457861};\\\", \\\"{x:1518,y:763,t:1527628457878};\\\", \\\"{x:1517,y:764,t:1527628457895};\\\", \\\"{x:1516,y:764,t:1527628457911};\\\", \\\"{x:1515,y:765,t:1527628457928};\\\", \\\"{x:1489,y:747,t:1527628461406};\\\", \\\"{x:1453,y:689,t:1527628461416};\\\", \\\"{x:1338,y:552,t:1527628461433};\\\", \\\"{x:1228,y:438,t:1527628461451};\\\", \\\"{x:1136,y:372,t:1527628461467};\\\", \\\"{x:1092,y:331,t:1527628461484};\\\", \\\"{x:1048,y:269,t:1527628461501};\\\", \\\"{x:1029,y:236,t:1527628461517};\\\", \\\"{x:1020,y:215,t:1527628461533};\\\", \\\"{x:1018,y:198,t:1527628461550};\\\", \\\"{x:1017,y:192,t:1527628461566};\\\", \\\"{x:1017,y:191,t:1527628461900};\\\", \\\"{x:1040,y:201,t:1527628461917};\\\", \\\"{x:1041,y:199,t:1527628461934};\\\", \\\"{x:1038,y:185,t:1527628461950};\\\", \\\"{x:1038,y:186,t:1527628462509};\\\", \\\"{x:1038,y:187,t:1527628462524};\\\", \\\"{x:1038,y:190,t:1527628462535};\\\", \\\"{x:1038,y:192,t:1527628462628};\\\", \\\"{x:1038,y:194,t:1527628462635};\\\", \\\"{x:1040,y:210,t:1527628462652};\\\", \\\"{x:1054,y:243,t:1527628462668};\\\", \\\"{x:1070,y:274,t:1527628462685};\\\", \\\"{x:1096,y:316,t:1527628462702};\\\", \\\"{x:1143,y:375,t:1527628462718};\\\", \\\"{x:1197,y:439,t:1527628462736};\\\", \\\"{x:1240,y:488,t:1527628462752};\\\", \\\"{x:1278,y:528,t:1527628462768};\\\", \\\"{x:1305,y:560,t:1527628462785};\\\", \\\"{x:1327,y:583,t:1527628462803};\\\", \\\"{x:1344,y:589,t:1527628462819};\\\", \\\"{x:1357,y:603,t:1527628462835};\\\", \\\"{x:1376,y:634,t:1527628462851};\\\", \\\"{x:1383,y:643,t:1527628462869};\\\", \\\"{x:1384,y:644,t:1527628462885};\\\", \\\"{x:1384,y:642,t:1527628463020};\\\", \\\"{x:1384,y:640,t:1527628463035};\\\", \\\"{x:1384,y:637,t:1527628463053};\\\", \\\"{x:1384,y:636,t:1527628463070};\\\", \\\"{x:1384,y:635,t:1527628463087};\\\", \\\"{x:1384,y:634,t:1527628463109};\\\", \\\"{x:1384,y:633,t:1527628463333};\\\", \\\"{x:1381,y:634,t:1527628463340};\\\", \\\"{x:1380,y:634,t:1527628463354};\\\", \\\"{x:1374,y:637,t:1527628463369};\\\", \\\"{x:1369,y:639,t:1527628463386};\\\", \\\"{x:1363,y:649,t:1527628463403};\\\", \\\"{x:1360,y:657,t:1527628463420};\\\", \\\"{x:1358,y:663,t:1527628463436};\\\", \\\"{x:1355,y:669,t:1527628463454};\\\", \\\"{x:1354,y:675,t:1527628463469};\\\", \\\"{x:1351,y:684,t:1527628463487};\\\", \\\"{x:1349,y:699,t:1527628463504};\\\", \\\"{x:1346,y:715,t:1527628463521};\\\", \\\"{x:1345,y:730,t:1527628463536};\\\", \\\"{x:1345,y:738,t:1527628463553};\\\", \\\"{x:1345,y:744,t:1527628463570};\\\", \\\"{x:1345,y:745,t:1527628463586};\\\", \\\"{x:1345,y:746,t:1527628463603};\\\", \\\"{x:1345,y:748,t:1527628463619};\\\", \\\"{x:1345,y:749,t:1527628463636};\\\", \\\"{x:1345,y:751,t:1527628463653};\\\", \\\"{x:1345,y:752,t:1527628463670};\\\", \\\"{x:1344,y:753,t:1527628463687};\\\", \\\"{x:1342,y:748,t:1527628463704};\\\", \\\"{x:1341,y:736,t:1527628463720};\\\", \\\"{x:1338,y:730,t:1527628463738};\\\", \\\"{x:1337,y:728,t:1527628463753};\\\", \\\"{x:1339,y:735,t:1527628465981};\\\", \\\"{x:1346,y:742,t:1527628465991};\\\", \\\"{x:1360,y:755,t:1527628466007};\\\", \\\"{x:1369,y:762,t:1527628466023};\\\", \\\"{x:1373,y:765,t:1527628466041};\\\", \\\"{x:1378,y:767,t:1527628466058};\\\", \\\"{x:1385,y:768,t:1527628466074};\\\", \\\"{x:1392,y:768,t:1527628466091};\\\", \\\"{x:1398,y:768,t:1527628466108};\\\", \\\"{x:1405,y:768,t:1527628466124};\\\", \\\"{x:1412,y:768,t:1527628466141};\\\", \\\"{x:1414,y:768,t:1527628466158};\\\", \\\"{x:1416,y:768,t:1527628466173};\\\", \\\"{x:1423,y:768,t:1527628466190};\\\", \\\"{x:1430,y:768,t:1527628466208};\\\", \\\"{x:1434,y:770,t:1527628466225};\\\", \\\"{x:1437,y:771,t:1527628466240};\\\", \\\"{x:1441,y:772,t:1527628466258};\\\", \\\"{x:1442,y:772,t:1527628466275};\\\", \\\"{x:1444,y:773,t:1527628466325};\\\", \\\"{x:1446,y:775,t:1527628466341};\\\", \\\"{x:1448,y:778,t:1527628466357};\\\", \\\"{x:1452,y:783,t:1527628466374};\\\", \\\"{x:1453,y:784,t:1527628466391};\\\", \\\"{x:1453,y:786,t:1527628466407};\\\", \\\"{x:1453,y:787,t:1527628466425};\\\", \\\"{x:1453,y:788,t:1527628466444};\\\", \\\"{x:1454,y:789,t:1527628466457};\\\", \\\"{x:1455,y:790,t:1527628466508};\\\", \\\"{x:1456,y:795,t:1527628466524};\\\", \\\"{x:1459,y:803,t:1527628466542};\\\", \\\"{x:1463,y:811,t:1527628466558};\\\", \\\"{x:1470,y:821,t:1527628466575};\\\", \\\"{x:1481,y:836,t:1527628466592};\\\", \\\"{x:1490,y:848,t:1527628466607};\\\", \\\"{x:1495,y:854,t:1527628466625};\\\", \\\"{x:1496,y:855,t:1527628466642};\\\", \\\"{x:1497,y:855,t:1527628466733};\\\", \\\"{x:1498,y:855,t:1527628466781};\\\", \\\"{x:1498,y:854,t:1527628466792};\\\", \\\"{x:1498,y:853,t:1527628466809};\\\", \\\"{x:1498,y:851,t:1527628466860};\\\", \\\"{x:1497,y:849,t:1527628466876};\\\", \\\"{x:1496,y:848,t:1527628466892};\\\", \\\"{x:1494,y:845,t:1527628466909};\\\", \\\"{x:1493,y:844,t:1527628466926};\\\", \\\"{x:1492,y:844,t:1527628466948};\\\", \\\"{x:1491,y:843,t:1527628466964};\\\", \\\"{x:1490,y:843,t:1527628466981};\\\", \\\"{x:1489,y:841,t:1527628466992};\\\", \\\"{x:1486,y:840,t:1527628467009};\\\", \\\"{x:1484,y:838,t:1527628467026};\\\", \\\"{x:1484,y:837,t:1527628467042};\\\", \\\"{x:1483,y:837,t:1527628467573};\\\", \\\"{x:1482,y:837,t:1527628467605};\\\", \\\"{x:1481,y:836,t:1527628467612};\\\", \\\"{x:1481,y:835,t:1527628467662};\\\", \\\"{x:1481,y:834,t:1527628467677};\\\", \\\"{x:1481,y:831,t:1527628467693};\\\", \\\"{x:1481,y:829,t:1527628467709};\\\", \\\"{x:1481,y:828,t:1527628467728};\\\", \\\"{x:1481,y:827,t:1527628467743};\\\", \\\"{x:1480,y:825,t:1527628467780};\\\", \\\"{x:1480,y:824,t:1527628469101};\\\", \\\"{x:1480,y:826,t:1527628471501};\\\", \\\"{x:1480,y:828,t:1527628471516};\\\", \\\"{x:1480,y:830,t:1527628471531};\\\", \\\"{x:1480,y:832,t:1527628471548};\\\", \\\"{x:1480,y:833,t:1527628471571};\\\", \\\"{x:1481,y:835,t:1527628471588};\\\", \\\"{x:1481,y:837,t:1527628471604};\\\", \\\"{x:1482,y:838,t:1527628471616};\\\", \\\"{x:1482,y:842,t:1527628471632};\\\", \\\"{x:1483,y:845,t:1527628471649};\\\", \\\"{x:1483,y:848,t:1527628471665};\\\", \\\"{x:1483,y:852,t:1527628471683};\\\", \\\"{x:1486,y:857,t:1527628471698};\\\", \\\"{x:1489,y:868,t:1527628471715};\\\", \\\"{x:1489,y:872,t:1527628471732};\\\", \\\"{x:1490,y:873,t:1527628471748};\\\", \\\"{x:1490,y:874,t:1527628471805};\\\", \\\"{x:1494,y:878,t:1527628471815};\\\", \\\"{x:1503,y:893,t:1527628471833};\\\", \\\"{x:1510,y:904,t:1527628471850};\\\", \\\"{x:1521,y:918,t:1527628471867};\\\", \\\"{x:1535,y:933,t:1527628471883};\\\", \\\"{x:1565,y:954,t:1527628471900};\\\", \\\"{x:1587,y:967,t:1527628471916};\\\", \\\"{x:1621,y:985,t:1527628471933};\\\", \\\"{x:1643,y:1000,t:1527628471950};\\\", \\\"{x:1657,y:1009,t:1527628471966};\\\", \\\"{x:1666,y:1016,t:1527628471983};\\\", \\\"{x:1669,y:1018,t:1527628472000};\\\", \\\"{x:1670,y:1018,t:1527628472016};\\\", \\\"{x:1671,y:1018,t:1527628472116};\\\", \\\"{x:1672,y:1018,t:1527628472220};\\\", \\\"{x:1673,y:1014,t:1527628472348};\\\", \\\"{x:1640,y:982,t:1527628472367};\\\", \\\"{x:1579,y:941,t:1527628472384};\\\", \\\"{x:1511,y:902,t:1527628472400};\\\", \\\"{x:1426,y:865,t:1527628472418};\\\", \\\"{x:1327,y:810,t:1527628472434};\\\", \\\"{x:1209,y:741,t:1527628472450};\\\", \\\"{x:1095,y:677,t:1527628472467};\\\", \\\"{x:955,y:611,t:1527628472484};\\\", \\\"{x:871,y:587,t:1527628472501};\\\", \\\"{x:802,y:567,t:1527628472516};\\\", \\\"{x:725,y:547,t:1527628472534};\\\", \\\"{x:652,y:523,t:1527628472548};\\\", \\\"{x:570,y:506,t:1527628472565};\\\", \\\"{x:506,y:496,t:1527628472581};\\\", \\\"{x:446,y:493,t:1527628472598};\\\", \\\"{x:373,y:494,t:1527628472616};\\\", \\\"{x:299,y:499,t:1527628472631};\\\", \\\"{x:234,y:502,t:1527628472648};\\\", \\\"{x:180,y:505,t:1527628472666};\\\", \\\"{x:160,y:512,t:1527628472682};\\\", \\\"{x:153,y:513,t:1527628472698};\\\", \\\"{x:153,y:514,t:1527628472716};\\\", \\\"{x:153,y:515,t:1527628472731};\\\", \\\"{x:157,y:515,t:1527628472748};\\\", \\\"{x:160,y:515,t:1527628472765};\\\", \\\"{x:171,y:515,t:1527628472782};\\\", \\\"{x:184,y:514,t:1527628472799};\\\", \\\"{x:199,y:513,t:1527628472815};\\\", \\\"{x:213,y:513,t:1527628472832};\\\", \\\"{x:223,y:514,t:1527628472849};\\\", \\\"{x:239,y:517,t:1527628472866};\\\", \\\"{x:261,y:523,t:1527628472883};\\\", \\\"{x:300,y:534,t:1527628472900};\\\", \\\"{x:328,y:538,t:1527628472915};\\\", \\\"{x:355,y:538,t:1527628472932};\\\", \\\"{x:382,y:538,t:1527628472950};\\\", \\\"{x:409,y:535,t:1527628472966};\\\", \\\"{x:434,y:530,t:1527628472983};\\\", \\\"{x:452,y:529,t:1527628472998};\\\", \\\"{x:472,y:529,t:1527628473015};\\\", \\\"{x:490,y:529,t:1527628473032};\\\", \\\"{x:505,y:529,t:1527628473051};\\\", \\\"{x:509,y:529,t:1527628473065};\\\", \\\"{x:510,y:529,t:1527628473101};\\\", \\\"{x:512,y:529,t:1527628473116};\\\", \\\"{x:519,y:533,t:1527628473133};\\\", \\\"{x:532,y:542,t:1527628473149};\\\", \\\"{x:542,y:549,t:1527628473166};\\\", \\\"{x:553,y:557,t:1527628473184};\\\", \\\"{x:564,y:563,t:1527628473200};\\\", \\\"{x:576,y:568,t:1527628473215};\\\", \\\"{x:589,y:573,t:1527628473232};\\\", \\\"{x:600,y:578,t:1527628473250};\\\", \\\"{x:609,y:581,t:1527628473266};\\\", \\\"{x:614,y:583,t:1527628473282};\\\", \\\"{x:616,y:584,t:1527628473300};\\\", \\\"{x:617,y:584,t:1527628473315};\\\", \\\"{x:618,y:584,t:1527628473348};\\\", \\\"{x:619,y:584,t:1527628473356};\\\", \\\"{x:620,y:584,t:1527628473366};\\\", \\\"{x:622,y:584,t:1527628473383};\\\", \\\"{x:623,y:584,t:1527628473399};\\\", \\\"{x:624,y:584,t:1527628473416};\\\", \\\"{x:625,y:584,t:1527628473433};\\\", \\\"{x:626,y:585,t:1527628473499};\\\", \\\"{x:626,y:585,t:1527628473609};\\\", \\\"{x:627,y:588,t:1527628473756};\\\", \\\"{x:621,y:600,t:1527628473767};\\\", \\\"{x:601,y:630,t:1527628473784};\\\", \\\"{x:577,y:666,t:1527628473800};\\\", \\\"{x:562,y:693,t:1527628473817};\\\", \\\"{x:553,y:715,t:1527628473833};\\\", \\\"{x:547,y:730,t:1527628473850};\\\", \\\"{x:543,y:745,t:1527628473866};\\\", \\\"{x:537,y:766,t:1527628473883};\\\", \\\"{x:536,y:771,t:1527628473899};\\\", \\\"{x:536,y:772,t:1527628473916};\\\", \\\"{x:535,y:774,t:1527628473932};\\\", \\\"{x:535,y:775,t:1527628473950};\\\", \\\"{x:534,y:775,t:1527628474068};\\\", \\\"{x:533,y:774,t:1527628474084};\\\", \\\"{x:532,y:768,t:1527628474100};\\\", \\\"{x:530,y:760,t:1527628474117};\\\", \\\"{x:530,y:756,t:1527628474134};\\\", \\\"{x:529,y:752,t:1527628474151};\\\", \\\"{x:529,y:746,t:1527628474167};\\\", \\\"{x:529,y:741,t:1527628474184};\\\", \\\"{x:528,y:739,t:1527628474201};\\\", \\\"{x:528,y:737,t:1527628474216};\\\", \\\"{x:528,y:736,t:1527628474259};\\\", \\\"{x:527,y:736,t:1527628474267};\\\", \\\"{x:527,y:735,t:1527628474291};\\\", \\\"{x:527,y:736,t:1527628480168};\\\", \\\"{x:527,y:737,t:1527628481960};\\\", \\\"{x:528,y:738,t:1527628482456};\\\", \\\"{x:529,y:738,t:1527628482471};\\\", \\\"{x:529,y:739,t:1527628483192};\\\", \\\"{x:529,y:740,t:1527628483295};\\\", \\\"{x:529,y:741,t:1527628483552};\\\", \\\"{x:529,y:744,t:1527628483592};\\\", \\\"{x:529,y:745,t:1527628483605};\\\", \\\"{x:531,y:750,t:1527628483621};\\\", \\\"{x:544,y:759,t:1527628483639};\\\", \\\"{x:556,y:768,t:1527628483655};\\\", \\\"{x:587,y:785,t:1527628483671};\\\", \\\"{x:625,y:800,t:1527628483687};\\\", \\\"{x:681,y:815,t:1527628483710};\\\", \\\"{x:797,y:845,t:1527628483728};\\\", \\\"{x:870,y:861,t:1527628483745};\\\", \\\"{x:924,y:870,t:1527628483761};\\\", \\\"{x:958,y:875,t:1527628483777};\\\", \\\"{x:982,y:879,t:1527628483794};\\\", \\\"{x:1000,y:882,t:1527628483810};\\\", \\\"{x:1018,y:884,t:1527628483828};\\\", \\\"{x:1029,y:886,t:1527628483845};\\\", \\\"{x:1037,y:887,t:1527628483860};\\\", \\\"{x:1041,y:887,t:1527628483878};\\\", \\\"{x:1051,y:887,t:1527628483895};\\\", \\\"{x:1061,y:884,t:1527628483911};\\\", \\\"{x:1095,y:878,t:1527628483927};\\\", \\\"{x:1125,y:878,t:1527628483944};\\\", \\\"{x:1161,y:878,t:1527628483961};\\\", \\\"{x:1194,y:876,t:1527628483978};\\\", \\\"{x:1234,y:875,t:1527628483996};\\\", \\\"{x:1270,y:875,t:1527628484012};\\\", \\\"{x:1315,y:875,t:1527628484029};\\\", \\\"{x:1357,y:875,t:1527628484045};\\\", \\\"{x:1383,y:876,t:1527628484062};\\\", \\\"{x:1402,y:878,t:1527628484078};\\\", \\\"{x:1407,y:880,t:1527628484095};\\\", \\\"{x:1411,y:880,t:1527628484112};\\\", \\\"{x:1415,y:884,t:1527628484128};\\\", \\\"{x:1420,y:891,t:1527628484145};\\\", \\\"{x:1423,y:897,t:1527628484162};\\\", \\\"{x:1423,y:901,t:1527628484179};\\\", \\\"{x:1423,y:904,t:1527628484195};\\\", \\\"{x:1423,y:908,t:1527628484212};\\\", \\\"{x:1422,y:914,t:1527628484228};\\\", \\\"{x:1419,y:917,t:1527628484245};\\\", \\\"{x:1416,y:920,t:1527628484262};\\\", \\\"{x:1411,y:922,t:1527628484278};\\\", \\\"{x:1405,y:924,t:1527628484295};\\\", \\\"{x:1390,y:931,t:1527628484312};\\\", \\\"{x:1380,y:934,t:1527628484328};\\\", \\\"{x:1372,y:934,t:1527628484345};\\\", \\\"{x:1363,y:934,t:1527628484363};\\\", \\\"{x:1361,y:934,t:1527628484378};\\\", \\\"{x:1361,y:936,t:1527628484585};\\\", \\\"{x:1361,y:939,t:1527628484596};\\\", \\\"{x:1361,y:944,t:1527628484612};\\\", \\\"{x:1361,y:953,t:1527628484630};\\\", \\\"{x:1361,y:959,t:1527628484645};\\\", \\\"{x:1362,y:966,t:1527628484662};\\\", \\\"{x:1363,y:971,t:1527628484679};\\\", \\\"{x:1363,y:973,t:1527628484695};\\\", \\\"{x:1363,y:976,t:1527628484712};\\\", \\\"{x:1363,y:978,t:1527628484729};\\\", \\\"{x:1363,y:979,t:1527628484745};\\\", \\\"{x:1363,y:980,t:1527628484800};\\\", \\\"{x:1361,y:981,t:1527628484816};\\\", \\\"{x:1359,y:981,t:1527628484839};\\\", \\\"{x:1357,y:982,t:1527628484847};\\\", \\\"{x:1356,y:983,t:1527628484864};\\\", \\\"{x:1355,y:983,t:1527628484879};\\\", \\\"{x:1354,y:983,t:1527628484895};\\\", \\\"{x:1354,y:984,t:1527628484928};\\\", \\\"{x:1353,y:984,t:1527628485056};\\\", \\\"{x:1352,y:983,t:1527628485079};\\\", \\\"{x:1351,y:981,t:1527628485096};\\\", \\\"{x:1350,y:979,t:1527628485144};\\\", \\\"{x:1350,y:978,t:1527628485159};\\\", \\\"{x:1349,y:978,t:1527628485168};\\\", \\\"{x:1348,y:977,t:1527628485179};\\\", \\\"{x:1346,y:975,t:1527628485196};\\\", \\\"{x:1345,y:974,t:1527628485212};\\\", \\\"{x:1345,y:973,t:1527628485229};\\\", \\\"{x:1344,y:972,t:1527628485246};\\\", \\\"{x:1344,y:971,t:1527628485304};\\\", \\\"{x:1344,y:970,t:1527628485312};\\\", \\\"{x:1344,y:969,t:1527628485329};\\\", \\\"{x:1344,y:968,t:1527628485465};\\\", \\\"{x:1345,y:967,t:1527628485480};\\\", \\\"{x:1346,y:967,t:1527628485528};\\\", \\\"{x:1346,y:966,t:1527628485536};\\\", \\\"{x:1345,y:965,t:1527628485808};\\\", \\\"{x:1339,y:961,t:1527628485815};\\\", \\\"{x:1331,y:959,t:1527628485830};\\\", \\\"{x:1310,y:950,t:1527628485846};\\\", \\\"{x:1273,y:936,t:1527628485863};\\\", \\\"{x:1145,y:886,t:1527628485880};\\\", \\\"{x:1061,y:855,t:1527628485896};\\\", \\\"{x:971,y:822,t:1527628485913};\\\", \\\"{x:894,y:792,t:1527628485932};\\\", \\\"{x:783,y:720,t:1527628485946};\\\", \\\"{x:738,y:693,t:1527628485963};\\\", \\\"{x:737,y:692,t:1527628485983};\\\", \\\"{x:737,y:690,t:1527628485996};\\\", \\\"{x:736,y:689,t:1527628486013};\\\", \\\"{x:736,y:686,t:1527628486030};\\\", \\\"{x:735,y:686,t:1527628486088};\\\", \\\"{x:733,y:686,t:1527628486103};\\\", \\\"{x:732,y:686,t:1527628486113};\\\", \\\"{x:729,y:686,t:1527628486131};\\\", \\\"{x:725,y:686,t:1527628486146};\\\", \\\"{x:721,y:683,t:1527628486163};\\\", \\\"{x:719,y:680,t:1527628486180};\\\", \\\"{x:717,y:679,t:1527628486196};\\\", \\\"{x:712,y:675,t:1527628486213};\\\", \\\"{x:708,y:673,t:1527628486231};\\\", \\\"{x:706,y:671,t:1527628486246};\\\", \\\"{x:702,y:669,t:1527628486263};\\\", \\\"{x:699,y:669,t:1527628486280};\\\", \\\"{x:696,y:667,t:1527628486296};\\\", \\\"{x:691,y:665,t:1527628486313};\\\", \\\"{x:686,y:661,t:1527628486332};\\\", \\\"{x:679,y:655,t:1527628486347};\\\", \\\"{x:673,y:649,t:1527628486363};\\\", \\\"{x:667,y:644,t:1527628486381};\\\", \\\"{x:655,y:635,t:1527628486397};\\\", \\\"{x:645,y:629,t:1527628486414};\\\", \\\"{x:639,y:625,t:1527628486431};\\\", \\\"{x:633,y:619,t:1527628486446};\\\", \\\"{x:629,y:616,t:1527628486464};\\\", \\\"{x:626,y:614,t:1527628486480};\\\", \\\"{x:621,y:608,t:1527628486496};\\\", \\\"{x:617,y:603,t:1527628486514};\\\", \\\"{x:615,y:598,t:1527628486531};\\\", \\\"{x:612,y:593,t:1527628486549};\\\", \\\"{x:609,y:590,t:1527628486564};\\\", \\\"{x:604,y:581,t:1527628486581};\\\", \\\"{x:598,y:575,t:1527628486598};\\\", \\\"{x:588,y:568,t:1527628486614};\\\", \\\"{x:576,y:562,t:1527628486631};\\\", \\\"{x:566,y:557,t:1527628486647};\\\", \\\"{x:551,y:552,t:1527628486664};\\\", \\\"{x:538,y:548,t:1527628486681};\\\", \\\"{x:532,y:546,t:1527628486697};\\\", \\\"{x:529,y:544,t:1527628486714};\\\", \\\"{x:527,y:542,t:1527628486731};\\\", \\\"{x:524,y:540,t:1527628486748};\\\", \\\"{x:524,y:545,t:1527628486840};\\\", \\\"{x:524,y:554,t:1527628486847};\\\", \\\"{x:524,y:572,t:1527628486865};\\\", \\\"{x:519,y:597,t:1527628486881};\\\", \\\"{x:517,y:615,t:1527628486898};\\\", \\\"{x:512,y:632,t:1527628486914};\\\", \\\"{x:508,y:644,t:1527628486931};\\\", \\\"{x:505,y:657,t:1527628486947};\\\", \\\"{x:502,y:666,t:1527628486964};\\\", \\\"{x:502,y:673,t:1527628486981};\\\", \\\"{x:500,y:681,t:1527628486998};\\\", \\\"{x:500,y:687,t:1527628487015};\\\", \\\"{x:500,y:693,t:1527628487030};\\\", \\\"{x:500,y:698,t:1527628487048};\\\", \\\"{x:500,y:707,t:1527628487065};\\\", \\\"{x:500,y:718,t:1527628487081};\\\", \\\"{x:500,y:723,t:1527628487098};\\\", \\\"{x:500,y:725,t:1527628487115};\\\", \\\"{x:500,y:728,t:1527628487131};\\\", \\\"{x:500,y:732,t:1527628487148};\\\", \\\"{x:500,y:734,t:1527628487164};\\\", \\\"{x:500,y:735,t:1527628487182};\\\", \\\"{x:500,y:736,t:1527628487232};\\\", \\\"{x:500,y:738,t:1527628487248};\\\", \\\"{x:500,y:741,t:1527628487265};\\\", \\\"{x:500,y:744,t:1527628487282};\\\", \\\"{x:500,y:746,t:1527628487299};\\\", \\\"{x:500,y:747,t:1527628487316};\\\", \\\"{x:500,y:746,t:1527628487527};\\\", \\\"{x:500,y:745,t:1527628487536};\\\", \\\"{x:501,y:745,t:1527628487549};\\\", \\\"{x:501,y:744,t:1527628487566};\\\", \\\"{x:502,y:743,t:1527628487584};\\\", \\\"{x:502,y:742,t:1527628487623};\\\", \\\"{x:502,y:741,t:1527628487640};\\\", \\\"{x:503,y:741,t:1527628487742};\\\", \\\"{x:503,y:740,t:1527628487783};\\\", \\\"{x:503,y:740,t:1527628487842};\\\", \\\"{x:503,y:739,t:1527628488408};\\\", \\\"{x:503,y:738,t:1527628488415};\\\", \\\"{x:503,y:736,t:1527628488431};\\\", \\\"{x:503,y:735,t:1527628488449};\\\", \\\"{x:503,y:734,t:1527628488466};\\\", \\\"{x:502,y:733,t:1527628488487};\\\", \\\"{x:501,y:732,t:1527628488519};\\\", \\\"{x:500,y:732,t:1527628488584};\\\", \\\"{x:502,y:727,t:1527628488599};\\\", \\\"{x:504,y:724,t:1527628488615};\\\", \\\"{x:505,y:719,t:1527628488632};\\\", \\\"{x:507,y:715,t:1527628488649};\\\", \\\"{x:507,y:714,t:1527628488671};\\\", \\\"{x:507,y:712,t:1527628488728};\\\", \\\"{x:508,y:711,t:1527628488759};\\\", \\\"{x:509,y:711,t:1527628488767};\\\", \\\"{x:510,y:711,t:1527628488783};\\\", \\\"{x:512,y:711,t:1527628488799};\\\", \\\"{x:529,y:725,t:1527628488816};\\\", \\\"{x:535,y:737,t:1527628488833};\\\", \\\"{x:536,y:738,t:1527628488852};\\\" ] }, { \\\"rt\\\": 8650, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 620203, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:753,t:1527628490880};\\\", \\\"{x:619,y:789,t:1527628490889};\\\", \\\"{x:810,y:890,t:1527628490903};\\\", \\\"{x:956,y:947,t:1527628490925};\\\", \\\"{x:1003,y:965,t:1527628490934};\\\", \\\"{x:1100,y:993,t:1527628490951};\\\", \\\"{x:1129,y:996,t:1527628490967};\\\", \\\"{x:1144,y:990,t:1527628490984};\\\", \\\"{x:1156,y:985,t:1527628491000};\\\", \\\"{x:1170,y:978,t:1527628491017};\\\", \\\"{x:1186,y:975,t:1527628491034};\\\", \\\"{x:1198,y:975,t:1527628491051};\\\", \\\"{x:1221,y:975,t:1527628491067};\\\", \\\"{x:1286,y:975,t:1527628491085};\\\", \\\"{x:1372,y:975,t:1527628491102};\\\", \\\"{x:1455,y:975,t:1527628491118};\\\", \\\"{x:1505,y:980,t:1527628491134};\\\", \\\"{x:1543,y:986,t:1527628491151};\\\", \\\"{x:1554,y:989,t:1527628491168};\\\", \\\"{x:1562,y:989,t:1527628491184};\\\", \\\"{x:1577,y:989,t:1527628491201};\\\", \\\"{x:1600,y:989,t:1527628491219};\\\", \\\"{x:1628,y:989,t:1527628491234};\\\", \\\"{x:1653,y:989,t:1527628491251};\\\", \\\"{x:1673,y:989,t:1527628491268};\\\", \\\"{x:1695,y:989,t:1527628491285};\\\", \\\"{x:1714,y:990,t:1527628491301};\\\", \\\"{x:1723,y:990,t:1527628491318};\\\", \\\"{x:1726,y:993,t:1527628491334};\\\", \\\"{x:1727,y:995,t:1527628491352};\\\", \\\"{x:1727,y:997,t:1527628491368};\\\", \\\"{x:1724,y:1000,t:1527628491384};\\\", \\\"{x:1716,y:1004,t:1527628491401};\\\", \\\"{x:1702,y:1010,t:1527628491418};\\\", \\\"{x:1684,y:1017,t:1527628491434};\\\", \\\"{x:1664,y:1021,t:1527628491451};\\\", \\\"{x:1637,y:1024,t:1527628491469};\\\", \\\"{x:1616,y:1025,t:1527628491484};\\\", \\\"{x:1605,y:1025,t:1527628491501};\\\", \\\"{x:1600,y:1026,t:1527628491519};\\\", \\\"{x:1594,y:1029,t:1527628491534};\\\", \\\"{x:1587,y:1029,t:1527628491551};\\\", \\\"{x:1576,y:1029,t:1527628491568};\\\", \\\"{x:1561,y:1028,t:1527628491584};\\\", \\\"{x:1546,y:1024,t:1527628491602};\\\", \\\"{x:1532,y:1022,t:1527628491619};\\\", \\\"{x:1517,y:1022,t:1527628491636};\\\", \\\"{x:1500,y:1022,t:1527628491651};\\\", \\\"{x:1483,y:1017,t:1527628491667};\\\", \\\"{x:1472,y:1016,t:1527628491685};\\\", \\\"{x:1461,y:1014,t:1527628491701};\\\", \\\"{x:1449,y:1009,t:1527628491717};\\\", \\\"{x:1434,y:997,t:1527628491734};\\\", \\\"{x:1422,y:986,t:1527628491750};\\\", \\\"{x:1411,y:975,t:1527628491768};\\\", \\\"{x:1406,y:968,t:1527628491785};\\\", \\\"{x:1403,y:964,t:1527628491801};\\\", \\\"{x:1402,y:959,t:1527628491819};\\\", \\\"{x:1402,y:957,t:1527628491835};\\\", \\\"{x:1402,y:950,t:1527628491852};\\\", \\\"{x:1402,y:940,t:1527628491869};\\\", \\\"{x:1402,y:929,t:1527628491885};\\\", \\\"{x:1402,y:925,t:1527628491901};\\\", \\\"{x:1401,y:923,t:1527628491918};\\\", \\\"{x:1394,y:916,t:1527628491935};\\\", \\\"{x:1386,y:910,t:1527628491952};\\\", \\\"{x:1378,y:906,t:1527628491969};\\\", \\\"{x:1373,y:903,t:1527628491985};\\\", \\\"{x:1359,y:901,t:1527628492002};\\\", \\\"{x:1337,y:901,t:1527628492018};\\\", \\\"{x:1315,y:901,t:1527628492035};\\\", \\\"{x:1305,y:903,t:1527628492051};\\\", \\\"{x:1300,y:904,t:1527628492068};\\\", \\\"{x:1295,y:913,t:1527628492085};\\\", \\\"{x:1295,y:926,t:1527628492101};\\\", \\\"{x:1301,y:951,t:1527628492118};\\\", \\\"{x:1326,y:993,t:1527628492136};\\\", \\\"{x:1341,y:1021,t:1527628492151};\\\", \\\"{x:1356,y:1043,t:1527628492169};\\\", \\\"{x:1364,y:1051,t:1527628492186};\\\", \\\"{x:1368,y:1053,t:1527628492202};\\\", \\\"{x:1369,y:1054,t:1527628492219};\\\", \\\"{x:1369,y:1055,t:1527628492236};\\\", \\\"{x:1370,y:1056,t:1527628492254};\\\", \\\"{x:1370,y:1055,t:1527628492384};\\\", \\\"{x:1369,y:1051,t:1527628492392};\\\", \\\"{x:1368,y:1049,t:1527628492402};\\\", \\\"{x:1361,y:1039,t:1527628492419};\\\", \\\"{x:1355,y:1016,t:1527628492436};\\\", \\\"{x:1350,y:998,t:1527628492454};\\\", \\\"{x:1347,y:986,t:1527628492468};\\\", \\\"{x:1345,y:978,t:1527628492485};\\\", \\\"{x:1345,y:970,t:1527628492503};\\\", \\\"{x:1345,y:957,t:1527628492519};\\\", \\\"{x:1345,y:944,t:1527628492536};\\\", \\\"{x:1345,y:939,t:1527628492552};\\\", \\\"{x:1346,y:937,t:1527628492569};\\\", \\\"{x:1347,y:936,t:1527628492585};\\\", \\\"{x:1349,y:934,t:1527628492602};\\\", \\\"{x:1351,y:930,t:1527628492619};\\\", \\\"{x:1354,y:922,t:1527628492635};\\\", \\\"{x:1355,y:918,t:1527628492654};\\\", \\\"{x:1358,y:906,t:1527628492668};\\\", \\\"{x:1358,y:889,t:1527628492685};\\\", \\\"{x:1359,y:868,t:1527628492702};\\\", \\\"{x:1359,y:839,t:1527628492719};\\\", \\\"{x:1358,y:828,t:1527628492735};\\\", \\\"{x:1357,y:814,t:1527628492751};\\\", \\\"{x:1357,y:806,t:1527628492769};\\\", \\\"{x:1357,y:804,t:1527628492785};\\\", \\\"{x:1356,y:801,t:1527628492802};\\\", \\\"{x:1355,y:800,t:1527628492819};\\\", \\\"{x:1353,y:801,t:1527628492835};\\\", \\\"{x:1344,y:804,t:1527628492852};\\\", \\\"{x:1320,y:810,t:1527628492869};\\\", \\\"{x:1288,y:819,t:1527628492885};\\\", \\\"{x:1250,y:820,t:1527628492901};\\\", \\\"{x:1189,y:815,t:1527628492919};\\\", \\\"{x:1123,y:799,t:1527628492935};\\\", \\\"{x:1067,y:783,t:1527628492952};\\\", \\\"{x:1024,y:774,t:1527628492969};\\\", \\\"{x:993,y:769,t:1527628492985};\\\", \\\"{x:951,y:765,t:1527628493002};\\\", \\\"{x:881,y:753,t:1527628493020};\\\", \\\"{x:790,y:732,t:1527628493035};\\\", \\\"{x:751,y:720,t:1527628493053};\\\", \\\"{x:750,y:719,t:1527628493069};\\\", \\\"{x:748,y:714,t:1527628493383};\\\", \\\"{x:714,y:707,t:1527628493392};\\\", \\\"{x:641,y:696,t:1527628493402};\\\", \\\"{x:503,y:661,t:1527628493420};\\\", \\\"{x:421,y:629,t:1527628493438};\\\", \\\"{x:366,y:603,t:1527628493453};\\\", \\\"{x:344,y:592,t:1527628493470};\\\", \\\"{x:334,y:582,t:1527628493486};\\\", \\\"{x:332,y:578,t:1527628493503};\\\", \\\"{x:332,y:574,t:1527628493520};\\\", \\\"{x:332,y:565,t:1527628493535};\\\", \\\"{x:338,y:552,t:1527628493554};\\\", \\\"{x:352,y:536,t:1527628493569};\\\", \\\"{x:358,y:528,t:1527628493586};\\\", \\\"{x:366,y:517,t:1527628493603};\\\", \\\"{x:372,y:509,t:1527628493620};\\\", \\\"{x:377,y:498,t:1527628493636};\\\", \\\"{x:384,y:483,t:1527628493654};\\\", \\\"{x:398,y:471,t:1527628493670};\\\", \\\"{x:421,y:462,t:1527628493686};\\\", \\\"{x:459,y:455,t:1527628493703};\\\", \\\"{x:481,y:453,t:1527628493720};\\\", \\\"{x:503,y:453,t:1527628493737};\\\", \\\"{x:542,y:453,t:1527628493753};\\\", \\\"{x:601,y:453,t:1527628493770};\\\", \\\"{x:681,y:461,t:1527628493787};\\\", \\\"{x:762,y:486,t:1527628493803};\\\", \\\"{x:820,y:502,t:1527628493821};\\\", \\\"{x:864,y:514,t:1527628493837};\\\", \\\"{x:886,y:524,t:1527628493853};\\\", \\\"{x:898,y:529,t:1527628493870};\\\", \\\"{x:903,y:532,t:1527628493887};\\\", \\\"{x:903,y:533,t:1527628493926};\\\", \\\"{x:902,y:535,t:1527628493937};\\\", \\\"{x:896,y:536,t:1527628493952};\\\", \\\"{x:885,y:536,t:1527628493970};\\\", \\\"{x:863,y:536,t:1527628493987};\\\", \\\"{x:830,y:536,t:1527628494003};\\\", \\\"{x:792,y:537,t:1527628494020};\\\", \\\"{x:757,y:538,t:1527628494037};\\\", \\\"{x:726,y:538,t:1527628494053};\\\", \\\"{x:687,y:538,t:1527628494071};\\\", \\\"{x:595,y:547,t:1527628494086};\\\", \\\"{x:517,y:547,t:1527628494103};\\\", \\\"{x:439,y:547,t:1527628494121};\\\", \\\"{x:378,y:547,t:1527628494137};\\\", \\\"{x:338,y:543,t:1527628494153};\\\", \\\"{x:319,y:542,t:1527628494170};\\\", \\\"{x:308,y:542,t:1527628494187};\\\", \\\"{x:303,y:542,t:1527628494204};\\\", \\\"{x:302,y:542,t:1527628494220};\\\", \\\"{x:298,y:542,t:1527628494237};\\\", \\\"{x:290,y:542,t:1527628494254};\\\", \\\"{x:285,y:544,t:1527628494270};\\\", \\\"{x:284,y:544,t:1527628494304};\\\", \\\"{x:283,y:545,t:1527628494321};\\\", \\\"{x:277,y:548,t:1527628494337};\\\", \\\"{x:266,y:551,t:1527628494356};\\\", \\\"{x:251,y:551,t:1527628494371};\\\", \\\"{x:239,y:551,t:1527628494387};\\\", \\\"{x:228,y:549,t:1527628494404};\\\", \\\"{x:210,y:545,t:1527628494420};\\\", \\\"{x:194,y:540,t:1527628494437};\\\", \\\"{x:186,y:538,t:1527628494454};\\\", \\\"{x:183,y:536,t:1527628494471};\\\", \\\"{x:183,y:535,t:1527628494767};\\\", \\\"{x:185,y:535,t:1527628494774};\\\", \\\"{x:192,y:535,t:1527628494787};\\\", \\\"{x:228,y:537,t:1527628494804};\\\", \\\"{x:303,y:549,t:1527628494822};\\\", \\\"{x:378,y:568,t:1527628494837};\\\", \\\"{x:444,y:585,t:1527628494854};\\\", \\\"{x:520,y:602,t:1527628494871};\\\", \\\"{x:567,y:614,t:1527628494887};\\\", \\\"{x:594,y:620,t:1527628494904};\\\", \\\"{x:607,y:625,t:1527628494922};\\\", \\\"{x:609,y:626,t:1527628494937};\\\", \\\"{x:611,y:627,t:1527628495056};\\\", \\\"{x:612,y:627,t:1527628495071};\\\", \\\"{x:613,y:629,t:1527628495090};\\\", \\\"{x:615,y:629,t:1527628495111};\\\", \\\"{x:617,y:629,t:1527628495127};\\\", \\\"{x:620,y:629,t:1527628495138};\\\", \\\"{x:634,y:625,t:1527628495155};\\\", \\\"{x:651,y:618,t:1527628495171};\\\", \\\"{x:668,y:613,t:1527628495188};\\\", \\\"{x:690,y:611,t:1527628495204};\\\", \\\"{x:704,y:608,t:1527628495221};\\\", \\\"{x:712,y:606,t:1527628495238};\\\", \\\"{x:715,y:604,t:1527628495254};\\\", \\\"{x:719,y:603,t:1527628495271};\\\", \\\"{x:720,y:602,t:1527628495288};\\\", \\\"{x:720,y:601,t:1527628495343};\\\", \\\"{x:720,y:600,t:1527628495360};\\\", \\\"{x:724,y:597,t:1527628495371};\\\", \\\"{x:728,y:595,t:1527628495387};\\\", \\\"{x:736,y:592,t:1527628495406};\\\", \\\"{x:744,y:588,t:1527628495421};\\\", \\\"{x:755,y:582,t:1527628495438};\\\", \\\"{x:772,y:572,t:1527628495455};\\\", \\\"{x:791,y:561,t:1527628495471};\\\", \\\"{x:814,y:550,t:1527628495488};\\\", \\\"{x:833,y:539,t:1527628495505};\\\", \\\"{x:849,y:530,t:1527628495521};\\\", \\\"{x:856,y:525,t:1527628495538};\\\", \\\"{x:863,y:519,t:1527628495555};\\\", \\\"{x:869,y:515,t:1527628495571};\\\", \\\"{x:873,y:512,t:1527628495588};\\\", \\\"{x:876,y:511,t:1527628495605};\\\", \\\"{x:878,y:510,t:1527628495621};\\\", \\\"{x:878,y:509,t:1527628495638};\\\", \\\"{x:879,y:509,t:1527628495655};\\\", \\\"{x:880,y:509,t:1527628495671};\\\", \\\"{x:880,y:508,t:1527628495703};\\\", \\\"{x:879,y:508,t:1527628495760};\\\", \\\"{x:877,y:509,t:1527628495771};\\\", \\\"{x:875,y:509,t:1527628495788};\\\", \\\"{x:873,y:509,t:1527628495958};\\\", \\\"{x:870,y:509,t:1527628495971};\\\", \\\"{x:854,y:516,t:1527628495987};\\\", \\\"{x:817,y:538,t:1527628496004};\\\", \\\"{x:770,y:567,t:1527628496022};\\\", \\\"{x:722,y:593,t:1527628496038};\\\", \\\"{x:662,y:628,t:1527628496056};\\\", \\\"{x:629,y:648,t:1527628496073};\\\", \\\"{x:600,y:670,t:1527628496088};\\\", \\\"{x:532,y:707,t:1527628496105};\\\", \\\"{x:477,y:739,t:1527628496123};\\\", \\\"{x:443,y:763,t:1527628496139};\\\", \\\"{x:436,y:774,t:1527628496155};\\\", \\\"{x:436,y:778,t:1527628496173};\\\", \\\"{x:438,y:782,t:1527628496189};\\\", \\\"{x:439,y:784,t:1527628496205};\\\", \\\"{x:440,y:784,t:1527628496279};\\\", \\\"{x:444,y:784,t:1527628496289};\\\", \\\"{x:462,y:774,t:1527628496305};\\\", \\\"{x:501,y:751,t:1527628496324};\\\", \\\"{x:585,y:689,t:1527628496339};\\\", \\\"{x:693,y:619,t:1527628496355};\\\", \\\"{x:799,y:563,t:1527628496372};\\\", \\\"{x:839,y:541,t:1527628496389};\\\", \\\"{x:861,y:528,t:1527628496405};\\\", \\\"{x:880,y:517,t:1527628496422};\\\", \\\"{x:893,y:510,t:1527628496437};\\\", \\\"{x:895,y:508,t:1527628496455};\\\", \\\"{x:892,y:508,t:1527628496600};\\\", \\\"{x:885,y:508,t:1527628496607};\\\", \\\"{x:877,y:508,t:1527628496622};\\\", \\\"{x:864,y:506,t:1527628496640};\\\", \\\"{x:854,y:504,t:1527628496655};\\\", \\\"{x:847,y:502,t:1527628496672};\\\", \\\"{x:846,y:502,t:1527628496690};\\\", \\\"{x:846,y:501,t:1527628496727};\\\", \\\"{x:845,y:501,t:1527628496759};\\\", \\\"{x:843,y:501,t:1527628496967};\\\", \\\"{x:839,y:503,t:1527628496975};\\\", \\\"{x:831,y:509,t:1527628496989};\\\", \\\"{x:810,y:523,t:1527628497006};\\\", \\\"{x:774,y:542,t:1527628497023};\\\", \\\"{x:688,y:587,t:1527628497039};\\\", \\\"{x:624,y:617,t:1527628497057};\\\", \\\"{x:586,y:638,t:1527628497073};\\\", \\\"{x:576,y:643,t:1527628497089};\\\", \\\"{x:575,y:643,t:1527628497106};\\\", \\\"{x:575,y:645,t:1527628497123};\\\", \\\"{x:574,y:652,t:1527628497139};\\\", \\\"{x:567,y:668,t:1527628497156};\\\", \\\"{x:556,y:681,t:1527628497173};\\\", \\\"{x:542,y:698,t:1527628497189};\\\", \\\"{x:529,y:713,t:1527628497206};\\\", \\\"{x:511,y:728,t:1527628497223};\\\", \\\"{x:501,y:736,t:1527628497239};\\\", \\\"{x:496,y:740,t:1527628497256};\\\", \\\"{x:496,y:742,t:1527628497274};\\\", \\\"{x:496,y:743,t:1527628498176};\\\", \\\"{x:496,y:744,t:1527628498190};\\\", \\\"{x:496,y:747,t:1527628498207};\\\", \\\"{x:496,y:748,t:1527628498223};\\\", \\\"{x:495,y:748,t:1527628498247};\\\" ] }, { \\\"rt\\\": 13359, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 634836, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:748,t:1527628500984};\\\", \\\"{x:483,y:748,t:1527628500998};\\\", \\\"{x:450,y:727,t:1527628501015};\\\", \\\"{x:394,y:692,t:1527628501032};\\\", \\\"{x:340,y:663,t:1527628501048};\\\", \\\"{x:314,y:654,t:1527628501064};\\\", \\\"{x:312,y:654,t:1527628501102};\\\", \\\"{x:310,y:655,t:1527628501110};\\\", \\\"{x:304,y:655,t:1527628501124};\\\", \\\"{x:286,y:655,t:1527628501141};\\\", \\\"{x:269,y:649,t:1527628501158};\\\", \\\"{x:251,y:640,t:1527628501174};\\\", \\\"{x:244,y:638,t:1527628501193};\\\", \\\"{x:242,y:638,t:1527628509463};\\\", \\\"{x:235,y:638,t:1527628509479};\\\", \\\"{x:232,y:639,t:1527628509497};\\\", \\\"{x:233,y:637,t:1527628509575};\\\", \\\"{x:285,y:618,t:1527628509594};\\\", \\\"{x:393,y:589,t:1527628509617};\\\", \\\"{x:456,y:563,t:1527628509632};\\\", \\\"{x:490,y:547,t:1527628509650};\\\", \\\"{x:501,y:533,t:1527628509667};\\\", \\\"{x:501,y:527,t:1527628509682};\\\", \\\"{x:493,y:518,t:1527628509700};\\\", \\\"{x:478,y:510,t:1527628509717};\\\", \\\"{x:458,y:506,t:1527628509733};\\\", \\\"{x:428,y:503,t:1527628509749};\\\", \\\"{x:382,y:503,t:1527628509766};\\\", \\\"{x:357,y:502,t:1527628509782};\\\", \\\"{x:327,y:497,t:1527628509799};\\\", \\\"{x:307,y:493,t:1527628509816};\\\", \\\"{x:294,y:491,t:1527628509833};\\\", \\\"{x:292,y:491,t:1527628509849};\\\", \\\"{x:291,y:491,t:1527628509871};\\\", \\\"{x:287,y:491,t:1527628509911};\\\", \\\"{x:284,y:491,t:1527628509919};\\\", \\\"{x:280,y:491,t:1527628509934};\\\", \\\"{x:274,y:493,t:1527628509950};\\\", \\\"{x:270,y:498,t:1527628509968};\\\", \\\"{x:264,y:510,t:1527628509984};\\\", \\\"{x:251,y:522,t:1527628510000};\\\", \\\"{x:236,y:532,t:1527628510017};\\\", \\\"{x:224,y:539,t:1527628510034};\\\", \\\"{x:210,y:545,t:1527628510049};\\\", \\\"{x:206,y:548,t:1527628510066};\\\", \\\"{x:203,y:549,t:1527628510084};\\\", \\\"{x:201,y:550,t:1527628510100};\\\", \\\"{x:199,y:551,t:1527628510117};\\\", \\\"{x:197,y:552,t:1527628510134};\\\", \\\"{x:197,y:554,t:1527628510456};\\\", \\\"{x:201,y:558,t:1527628510468};\\\", \\\"{x:225,y:578,t:1527628510484};\\\", \\\"{x:274,y:621,t:1527628510501};\\\", \\\"{x:330,y:661,t:1527628510517};\\\", \\\"{x:406,y:716,t:1527628510534};\\\", \\\"{x:516,y:803,t:1527628510551};\\\", \\\"{x:586,y:852,t:1527628510567};\\\", \\\"{x:636,y:886,t:1527628510583};\\\", \\\"{x:663,y:899,t:1527628510601};\\\", \\\"{x:672,y:901,t:1527628510617};\\\", \\\"{x:674,y:901,t:1527628510633};\\\", \\\"{x:672,y:901,t:1527628510650};\\\", \\\"{x:623,y:877,t:1527628510667};\\\", \\\"{x:515,y:825,t:1527628510683};\\\", \\\"{x:389,y:773,t:1527628510700};\\\", \\\"{x:287,y:728,t:1527628510717};\\\", \\\"{x:228,y:703,t:1527628510733};\\\", \\\"{x:191,y:681,t:1527628510750};\\\", \\\"{x:173,y:667,t:1527628510768};\\\", \\\"{x:160,y:657,t:1527628510783};\\\", \\\"{x:154,y:648,t:1527628510801};\\\", \\\"{x:148,y:641,t:1527628510817};\\\", \\\"{x:145,y:635,t:1527628510834};\\\", \\\"{x:145,y:629,t:1527628510851};\\\", \\\"{x:151,y:618,t:1527628510867};\\\", \\\"{x:154,y:613,t:1527628510883};\\\", \\\"{x:156,y:611,t:1527628510900};\\\", \\\"{x:160,y:609,t:1527628510917};\\\", \\\"{x:166,y:605,t:1527628510934};\\\", \\\"{x:171,y:601,t:1527628510951};\\\", \\\"{x:174,y:595,t:1527628510967};\\\", \\\"{x:174,y:592,t:1527628510984};\\\", \\\"{x:174,y:587,t:1527628511001};\\\", \\\"{x:174,y:583,t:1527628511018};\\\", \\\"{x:174,y:579,t:1527628511034};\\\", \\\"{x:174,y:576,t:1527628511051};\\\", \\\"{x:174,y:570,t:1527628511067};\\\", \\\"{x:174,y:566,t:1527628511083};\\\", \\\"{x:174,y:563,t:1527628511101};\\\", \\\"{x:174,y:558,t:1527628511118};\\\", \\\"{x:172,y:552,t:1527628511135};\\\", \\\"{x:171,y:549,t:1527628511151};\\\", \\\"{x:170,y:548,t:1527628511168};\\\", \\\"{x:170,y:546,t:1527628511184};\\\", \\\"{x:170,y:545,t:1527628511201};\\\", \\\"{x:170,y:544,t:1527628511218};\\\", \\\"{x:169,y:542,t:1527628511234};\\\", \\\"{x:167,y:540,t:1527628511251};\\\", \\\"{x:166,y:539,t:1527628511267};\\\", \\\"{x:165,y:538,t:1527628511283};\\\", \\\"{x:164,y:538,t:1527628511301};\\\", \\\"{x:163,y:538,t:1527628511317};\\\", \\\"{x:161,y:538,t:1527628511334};\\\", \\\"{x:161,y:539,t:1527628511519};\\\", \\\"{x:169,y:554,t:1527628511535};\\\", \\\"{x:184,y:567,t:1527628511552};\\\", \\\"{x:193,y:572,t:1527628511568};\\\", \\\"{x:195,y:575,t:1527628511585};\\\", \\\"{x:200,y:579,t:1527628511600};\\\", \\\"{x:208,y:590,t:1527628511618};\\\", \\\"{x:217,y:598,t:1527628511635};\\\", \\\"{x:224,y:604,t:1527628511652};\\\", \\\"{x:227,y:605,t:1527628511668};\\\", \\\"{x:229,y:606,t:1527628511685};\\\", \\\"{x:235,y:607,t:1527628511701};\\\", \\\"{x:242,y:610,t:1527628511718};\\\", \\\"{x:261,y:614,t:1527628511735};\\\", \\\"{x:279,y:617,t:1527628511753};\\\", \\\"{x:309,y:623,t:1527628511767};\\\", \\\"{x:338,y:632,t:1527628511785};\\\", \\\"{x:361,y:639,t:1527628511801};\\\", \\\"{x:381,y:644,t:1527628511818};\\\", \\\"{x:396,y:654,t:1527628511835};\\\", \\\"{x:412,y:662,t:1527628511851};\\\", \\\"{x:437,y:676,t:1527628511868};\\\", \\\"{x:455,y:687,t:1527628511885};\\\", \\\"{x:461,y:693,t:1527628511902};\\\", \\\"{x:462,y:696,t:1527628511917};\\\", \\\"{x:462,y:699,t:1527628511935};\\\", \\\"{x:462,y:703,t:1527628511952};\\\", \\\"{x:463,y:708,t:1527628511968};\\\", \\\"{x:464,y:713,t:1527628511984};\\\", \\\"{x:467,y:717,t:1527628512002};\\\", \\\"{x:469,y:720,t:1527628512019};\\\", \\\"{x:470,y:722,t:1527628512035};\\\", \\\"{x:471,y:722,t:1527628512063};\\\", \\\"{x:471,y:723,t:1527628512071};\\\", \\\"{x:472,y:724,t:1527628512085};\\\", \\\"{x:476,y:728,t:1527628512102};\\\", \\\"{x:479,y:735,t:1527628512119};\\\", \\\"{x:480,y:737,t:1527628512135};\\\", \\\"{x:481,y:737,t:1527628512159};\\\", \\\"{x:482,y:738,t:1527628512169};\\\", \\\"{x:482,y:739,t:1527628512191};\\\", \\\"{x:486,y:738,t:1527628513007};\\\", \\\"{x:489,y:736,t:1527628513019};\\\", \\\"{x:491,y:733,t:1527628513035};\\\", \\\"{x:493,y:730,t:1527628513053};\\\", \\\"{x:495,y:729,t:1527628513068};\\\", \\\"{x:497,y:726,t:1527628513085};\\\", \\\"{x:499,y:724,t:1527628513102};\\\", \\\"{x:500,y:724,t:1527628513118};\\\", \\\"{x:502,y:724,t:1527628513136};\\\", \\\"{x:505,y:724,t:1527628513152};\\\", \\\"{x:508,y:724,t:1527628513168};\\\", \\\"{x:510,y:724,t:1527628513186};\\\", \\\"{x:511,y:724,t:1527628513203};\\\", \\\"{x:512,y:724,t:1527628513219};\\\" ] }, { \\\"rt\\\": 20148, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 656208, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -Z -04 PM-X -M -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:722,t:1527628514984};\\\", \\\"{x:511,y:718,t:1527628514994};\\\", \\\"{x:511,y:714,t:1527628515009};\\\", \\\"{x:511,y:711,t:1527628515021};\\\", \\\"{x:511,y:707,t:1527628515037};\\\", \\\"{x:506,y:700,t:1527628515054};\\\", \\\"{x:492,y:689,t:1527628515070};\\\", \\\"{x:489,y:686,t:1527628515087};\\\", \\\"{x:491,y:685,t:1527628515126};\\\", \\\"{x:492,y:685,t:1527628515138};\\\", \\\"{x:493,y:684,t:1527628515155};\\\", \\\"{x:496,y:680,t:1527628515171};\\\", \\\"{x:498,y:678,t:1527628515188};\\\", \\\"{x:506,y:673,t:1527628515205};\\\", \\\"{x:522,y:665,t:1527628515221};\\\", \\\"{x:549,y:655,t:1527628515238};\\\", \\\"{x:611,y:611,t:1527628515254};\\\", \\\"{x:636,y:579,t:1527628515271};\\\", \\\"{x:650,y:548,t:1527628515288};\\\", \\\"{x:650,y:528,t:1527628515304};\\\", \\\"{x:650,y:522,t:1527628515321};\\\", \\\"{x:648,y:519,t:1527628515337};\\\", \\\"{x:647,y:518,t:1527628515354};\\\", \\\"{x:648,y:518,t:1527628515576};\\\", \\\"{x:649,y:518,t:1527628515599};\\\", \\\"{x:650,y:518,t:1527628515607};\\\", \\\"{x:651,y:518,t:1527628515638};\\\", \\\"{x:652,y:519,t:1527628515654};\\\", \\\"{x:657,y:521,t:1527628515671};\\\", \\\"{x:667,y:524,t:1527628515688};\\\", \\\"{x:683,y:524,t:1527628515704};\\\", \\\"{x:709,y:524,t:1527628515721};\\\", \\\"{x:743,y:524,t:1527628515738};\\\", \\\"{x:801,y:529,t:1527628515756};\\\", \\\"{x:865,y:539,t:1527628515772};\\\", \\\"{x:924,y:547,t:1527628515788};\\\", \\\"{x:975,y:556,t:1527628515805};\\\", \\\"{x:1013,y:564,t:1527628515822};\\\", \\\"{x:1058,y:578,t:1527628515838};\\\", \\\"{x:1118,y:598,t:1527628515855};\\\", \\\"{x:1144,y:608,t:1527628515872};\\\", \\\"{x:1164,y:617,t:1527628515888};\\\", \\\"{x:1174,y:622,t:1527628515905};\\\", \\\"{x:1180,y:626,t:1527628515923};\\\", \\\"{x:1188,y:631,t:1527628515939};\\\", \\\"{x:1201,y:640,t:1527628515955};\\\", \\\"{x:1216,y:647,t:1527628515972};\\\", \\\"{x:1230,y:652,t:1527628515988};\\\", \\\"{x:1243,y:657,t:1527628516005};\\\", \\\"{x:1253,y:660,t:1527628516022};\\\", \\\"{x:1263,y:660,t:1527628516038};\\\", \\\"{x:1273,y:661,t:1527628516054};\\\", \\\"{x:1275,y:662,t:1527628516094};\\\", \\\"{x:1274,y:665,t:1527628516472};\\\", \\\"{x:1255,y:663,t:1527628516489};\\\", \\\"{x:1228,y:657,t:1527628516505};\\\", \\\"{x:1189,y:656,t:1527628516522};\\\", \\\"{x:1177,y:653,t:1527628516539};\\\", \\\"{x:1176,y:653,t:1527628516555};\\\", \\\"{x:1175,y:653,t:1527628516583};\\\", \\\"{x:1173,y:654,t:1527628516599};\\\", \\\"{x:1172,y:655,t:1527628516607};\\\", \\\"{x:1171,y:656,t:1527628516623};\\\", \\\"{x:1169,y:659,t:1527628516639};\\\", \\\"{x:1169,y:665,t:1527628516656};\\\", \\\"{x:1170,y:674,t:1527628516672};\\\", \\\"{x:1176,y:685,t:1527628516689};\\\", \\\"{x:1185,y:698,t:1527628516707};\\\", \\\"{x:1192,y:711,t:1527628516722};\\\", \\\"{x:1208,y:727,t:1527628516740};\\\", \\\"{x:1226,y:745,t:1527628516757};\\\", \\\"{x:1248,y:764,t:1527628516773};\\\", \\\"{x:1274,y:777,t:1527628516790};\\\", \\\"{x:1291,y:785,t:1527628516807};\\\", \\\"{x:1303,y:786,t:1527628516823};\\\", \\\"{x:1308,y:786,t:1527628516839};\\\", \\\"{x:1309,y:786,t:1527628516863};\\\", \\\"{x:1312,y:786,t:1527628516872};\\\", \\\"{x:1326,y:786,t:1527628516890};\\\", \\\"{x:1342,y:786,t:1527628516907};\\\", \\\"{x:1352,y:786,t:1527628516923};\\\", \\\"{x:1359,y:786,t:1527628516940};\\\", \\\"{x:1365,y:786,t:1527628516956};\\\", \\\"{x:1372,y:787,t:1527628516972};\\\", \\\"{x:1388,y:792,t:1527628516989};\\\", \\\"{x:1415,y:801,t:1527628517007};\\\", \\\"{x:1448,y:815,t:1527628517022};\\\", \\\"{x:1504,y:838,t:1527628517039};\\\", \\\"{x:1537,y:852,t:1527628517056};\\\", \\\"{x:1563,y:864,t:1527628517072};\\\", \\\"{x:1585,y:874,t:1527628517089};\\\", \\\"{x:1600,y:879,t:1527628517107};\\\", \\\"{x:1605,y:882,t:1527628517122};\\\", \\\"{x:1604,y:882,t:1527628517247};\\\", \\\"{x:1601,y:882,t:1527628517257};\\\", \\\"{x:1598,y:882,t:1527628517274};\\\", \\\"{x:1597,y:882,t:1527628517289};\\\", \\\"{x:1594,y:882,t:1527628517306};\\\", \\\"{x:1593,y:882,t:1527628517323};\\\", \\\"{x:1590,y:882,t:1527628517340};\\\", \\\"{x:1588,y:882,t:1527628517357};\\\", \\\"{x:1587,y:882,t:1527628517374};\\\", \\\"{x:1586,y:882,t:1527628517432};\\\", \\\"{x:1586,y:879,t:1527628517455};\\\", \\\"{x:1584,y:870,t:1527628517474};\\\", \\\"{x:1584,y:854,t:1527628517490};\\\", \\\"{x:1584,y:824,t:1527628517506};\\\", \\\"{x:1584,y:771,t:1527628517523};\\\", \\\"{x:1582,y:714,t:1527628517539};\\\", \\\"{x:1575,y:671,t:1527628517557};\\\", \\\"{x:1563,y:648,t:1527628517573};\\\", \\\"{x:1550,y:633,t:1527628517591};\\\", \\\"{x:1537,y:625,t:1527628517606};\\\", \\\"{x:1517,y:617,t:1527628517623};\\\", \\\"{x:1510,y:612,t:1527628517640};\\\", \\\"{x:1507,y:608,t:1527628517656};\\\", \\\"{x:1506,y:603,t:1527628517674};\\\", \\\"{x:1505,y:597,t:1527628517691};\\\", \\\"{x:1505,y:590,t:1527628517706};\\\", \\\"{x:1508,y:583,t:1527628517724};\\\", \\\"{x:1511,y:575,t:1527628517741};\\\", \\\"{x:1516,y:564,t:1527628517756};\\\", \\\"{x:1517,y:550,t:1527628517773};\\\", \\\"{x:1517,y:535,t:1527628517790};\\\", \\\"{x:1511,y:512,t:1527628517807};\\\", \\\"{x:1496,y:474,t:1527628517824};\\\", \\\"{x:1491,y:458,t:1527628517841};\\\", \\\"{x:1491,y:443,t:1527628517856};\\\", \\\"{x:1491,y:427,t:1527628517873};\\\", \\\"{x:1491,y:397,t:1527628517891};\\\", \\\"{x:1491,y:369,t:1527628517907};\\\", \\\"{x:1491,y:360,t:1527628517923};\\\", \\\"{x:1490,y:353,t:1527628517941};\\\", \\\"{x:1489,y:346,t:1527628517957};\\\", \\\"{x:1487,y:343,t:1527628517973};\\\", \\\"{x:1487,y:339,t:1527628517990};\\\", \\\"{x:1487,y:337,t:1527628518006};\\\", \\\"{x:1487,y:334,t:1527628518023};\\\", \\\"{x:1487,y:333,t:1527628518055};\\\", \\\"{x:1485,y:332,t:1527628518176};\\\", \\\"{x:1484,y:332,t:1527628518191};\\\", \\\"{x:1478,y:332,t:1527628518207};\\\", \\\"{x:1474,y:334,t:1527628518223};\\\", \\\"{x:1471,y:335,t:1527628518240};\\\", \\\"{x:1468,y:336,t:1527628518258};\\\", \\\"{x:1465,y:339,t:1527628518273};\\\", \\\"{x:1459,y:343,t:1527628518291};\\\", \\\"{x:1456,y:349,t:1527628518308};\\\", \\\"{x:1453,y:357,t:1527628518324};\\\", \\\"{x:1447,y:367,t:1527628518340};\\\", \\\"{x:1442,y:376,t:1527628518357};\\\", \\\"{x:1434,y:388,t:1527628518374};\\\", \\\"{x:1427,y:399,t:1527628518391};\\\", \\\"{x:1415,y:415,t:1527628518407};\\\", \\\"{x:1409,y:424,t:1527628518426};\\\", \\\"{x:1399,y:435,t:1527628518441};\\\", \\\"{x:1394,y:446,t:1527628518457};\\\", \\\"{x:1387,y:459,t:1527628518475};\\\", \\\"{x:1383,y:471,t:1527628518491};\\\", \\\"{x:1379,y:483,t:1527628518508};\\\", \\\"{x:1373,y:500,t:1527628518524};\\\", \\\"{x:1364,y:520,t:1527628518540};\\\", \\\"{x:1357,y:541,t:1527628518557};\\\", \\\"{x:1351,y:560,t:1527628518574};\\\", \\\"{x:1352,y:579,t:1527628518591};\\\", \\\"{x:1357,y:598,t:1527628518607};\\\", \\\"{x:1359,y:609,t:1527628518625};\\\", \\\"{x:1359,y:620,t:1527628518641};\\\", \\\"{x:1359,y:634,t:1527628518657};\\\", \\\"{x:1359,y:649,t:1527628518675};\\\", \\\"{x:1359,y:663,t:1527628518690};\\\", \\\"{x:1359,y:671,t:1527628518706};\\\", \\\"{x:1359,y:677,t:1527628518724};\\\", \\\"{x:1359,y:685,t:1527628518740};\\\", \\\"{x:1359,y:697,t:1527628518757};\\\", \\\"{x:1359,y:706,t:1527628518774};\\\", \\\"{x:1362,y:715,t:1527628518790};\\\", \\\"{x:1367,y:730,t:1527628518807};\\\", \\\"{x:1369,y:738,t:1527628518823};\\\", \\\"{x:1372,y:746,t:1527628518839};\\\", \\\"{x:1374,y:754,t:1527628518857};\\\", \\\"{x:1378,y:765,t:1527628518874};\\\", \\\"{x:1382,y:773,t:1527628518890};\\\", \\\"{x:1385,y:781,t:1527628518907};\\\", \\\"{x:1387,y:787,t:1527628518924};\\\", \\\"{x:1389,y:794,t:1527628518941};\\\", \\\"{x:1391,y:802,t:1527628518957};\\\", \\\"{x:1395,y:810,t:1527628518974};\\\", \\\"{x:1403,y:820,t:1527628518990};\\\", \\\"{x:1407,y:825,t:1527628519006};\\\", \\\"{x:1410,y:830,t:1527628519024};\\\", \\\"{x:1412,y:831,t:1527628519041};\\\", \\\"{x:1412,y:834,t:1527628519057};\\\", \\\"{x:1414,y:837,t:1527628519074};\\\", \\\"{x:1415,y:840,t:1527628519091};\\\", \\\"{x:1416,y:842,t:1527628519107};\\\", \\\"{x:1417,y:846,t:1527628519124};\\\", \\\"{x:1418,y:848,t:1527628519141};\\\", \\\"{x:1419,y:850,t:1527628519157};\\\", \\\"{x:1421,y:854,t:1527628519174};\\\", \\\"{x:1423,y:858,t:1527628519191};\\\", \\\"{x:1426,y:861,t:1527628519207};\\\", \\\"{x:1426,y:862,t:1527628519224};\\\", \\\"{x:1427,y:862,t:1527628519241};\\\", \\\"{x:1430,y:862,t:1527628519258};\\\", \\\"{x:1432,y:862,t:1527628519274};\\\", \\\"{x:1437,y:862,t:1527628519291};\\\", \\\"{x:1443,y:862,t:1527628519309};\\\", \\\"{x:1452,y:859,t:1527628519324};\\\", \\\"{x:1465,y:856,t:1527628519342};\\\", \\\"{x:1474,y:854,t:1527628519359};\\\", \\\"{x:1479,y:853,t:1527628519375};\\\", \\\"{x:1481,y:852,t:1527628519392};\\\", \\\"{x:1483,y:851,t:1527628519409};\\\", \\\"{x:1489,y:848,t:1527628519424};\\\", \\\"{x:1499,y:842,t:1527628519442};\\\", \\\"{x:1515,y:834,t:1527628519458};\\\", \\\"{x:1527,y:825,t:1527628519475};\\\", \\\"{x:1551,y:814,t:1527628519492};\\\", \\\"{x:1569,y:803,t:1527628519508};\\\", \\\"{x:1582,y:791,t:1527628519524};\\\", \\\"{x:1594,y:774,t:1527628519542};\\\", \\\"{x:1608,y:757,t:1527628519559};\\\", \\\"{x:1616,y:745,t:1527628519575};\\\", \\\"{x:1623,y:734,t:1527628519591};\\\", \\\"{x:1625,y:731,t:1527628519608};\\\", \\\"{x:1626,y:728,t:1527628519624};\\\", \\\"{x:1627,y:725,t:1527628519641};\\\", \\\"{x:1628,y:722,t:1527628519658};\\\", \\\"{x:1630,y:717,t:1527628519673};\\\", \\\"{x:1630,y:715,t:1527628519690};\\\", \\\"{x:1631,y:711,t:1527628519708};\\\", \\\"{x:1633,y:708,t:1527628519724};\\\", \\\"{x:1634,y:703,t:1527628519741};\\\", \\\"{x:1635,y:701,t:1527628519758};\\\", \\\"{x:1635,y:698,t:1527628519774};\\\", \\\"{x:1635,y:697,t:1527628519791};\\\", \\\"{x:1636,y:696,t:1527628519809};\\\", \\\"{x:1637,y:695,t:1527628519826};\\\", \\\"{x:1637,y:694,t:1527628519841};\\\", \\\"{x:1638,y:693,t:1527628519858};\\\", \\\"{x:1638,y:692,t:1527628519875};\\\", \\\"{x:1637,y:692,t:1527628520503};\\\", \\\"{x:1635,y:692,t:1527628520511};\\\", \\\"{x:1634,y:692,t:1527628520526};\\\", \\\"{x:1630,y:695,t:1527628520542};\\\", \\\"{x:1626,y:697,t:1527628520559};\\\", \\\"{x:1623,y:700,t:1527628520575};\\\", \\\"{x:1619,y:702,t:1527628520593};\\\", \\\"{x:1617,y:702,t:1527628520608};\\\", \\\"{x:1616,y:703,t:1527628520712};\\\", \\\"{x:1615,y:703,t:1527628520743};\\\", \\\"{x:1613,y:704,t:1527628520759};\\\", \\\"{x:1612,y:704,t:1527628520776};\\\", \\\"{x:1612,y:703,t:1527628521360};\\\", \\\"{x:1612,y:702,t:1527628521376};\\\", \\\"{x:1612,y:701,t:1527628521395};\\\", \\\"{x:1612,y:698,t:1527628521409};\\\", \\\"{x:1613,y:697,t:1527628521426};\\\", \\\"{x:1613,y:695,t:1527628521441};\\\", \\\"{x:1614,y:694,t:1527628521459};\\\", \\\"{x:1614,y:693,t:1527628521494};\\\", \\\"{x:1614,y:692,t:1527628521510};\\\", \\\"{x:1614,y:693,t:1527628522127};\\\", \\\"{x:1614,y:695,t:1527628522143};\\\", \\\"{x:1614,y:696,t:1527628522160};\\\", \\\"{x:1614,y:699,t:1527628522176};\\\", \\\"{x:1613,y:702,t:1527628522193};\\\", \\\"{x:1613,y:705,t:1527628522212};\\\", \\\"{x:1613,y:707,t:1527628522227};\\\", \\\"{x:1612,y:709,t:1527628522244};\\\", \\\"{x:1610,y:715,t:1527628522261};\\\", \\\"{x:1609,y:719,t:1527628522277};\\\", \\\"{x:1608,y:724,t:1527628522293};\\\", \\\"{x:1605,y:733,t:1527628522311};\\\", \\\"{x:1604,y:738,t:1527628522326};\\\", \\\"{x:1604,y:743,t:1527628522342};\\\", \\\"{x:1604,y:747,t:1527628522360};\\\", \\\"{x:1601,y:757,t:1527628522377};\\\", \\\"{x:1599,y:773,t:1527628522393};\\\", \\\"{x:1598,y:792,t:1527628522410};\\\", \\\"{x:1598,y:804,t:1527628522427};\\\", \\\"{x:1598,y:818,t:1527628522443};\\\", \\\"{x:1598,y:829,t:1527628522461};\\\", \\\"{x:1598,y:842,t:1527628522477};\\\", \\\"{x:1598,y:857,t:1527628522493};\\\", \\\"{x:1598,y:887,t:1527628522510};\\\", \\\"{x:1598,y:902,t:1527628522527};\\\", \\\"{x:1600,y:912,t:1527628522543};\\\", \\\"{x:1603,y:921,t:1527628522560};\\\", \\\"{x:1606,y:926,t:1527628522577};\\\", \\\"{x:1606,y:928,t:1527628522593};\\\", \\\"{x:1607,y:933,t:1527628522610};\\\", \\\"{x:1609,y:938,t:1527628522628};\\\", \\\"{x:1609,y:943,t:1527628522643};\\\", \\\"{x:1609,y:947,t:1527628522661};\\\", \\\"{x:1609,y:951,t:1527628522678};\\\", \\\"{x:1609,y:952,t:1527628522694};\\\", \\\"{x:1609,y:953,t:1527628522711};\\\", \\\"{x:1610,y:958,t:1527628522728};\\\", \\\"{x:1614,y:963,t:1527628522744};\\\", \\\"{x:1616,y:967,t:1527628522761};\\\", \\\"{x:1616,y:971,t:1527628522778};\\\", \\\"{x:1616,y:972,t:1527628522794};\\\", \\\"{x:1617,y:974,t:1527628522810};\\\", \\\"{x:1617,y:975,t:1527628522827};\\\", \\\"{x:1617,y:976,t:1527628522848};\\\", \\\"{x:1617,y:977,t:1527628522862};\\\", \\\"{x:1617,y:976,t:1527628523063};\\\", \\\"{x:1617,y:973,t:1527628523077};\\\", \\\"{x:1620,y:955,t:1527628523096};\\\", \\\"{x:1621,y:946,t:1527628523111};\\\", \\\"{x:1621,y:945,t:1527628523128};\\\", \\\"{x:1622,y:940,t:1527628523631};\\\", \\\"{x:1622,y:937,t:1527628523644};\\\", \\\"{x:1622,y:935,t:1527628524448};\\\", \\\"{x:1624,y:935,t:1527628524519};\\\", \\\"{x:1625,y:935,t:1527628524528};\\\", \\\"{x:1627,y:935,t:1527628524559};\\\", \\\"{x:1628,y:935,t:1527628524575};\\\", \\\"{x:1628,y:933,t:1527628524584};\\\", \\\"{x:1628,y:928,t:1527628524596};\\\", \\\"{x:1626,y:922,t:1527628524613};\\\", \\\"{x:1619,y:918,t:1527628524629};\\\", \\\"{x:1614,y:915,t:1527628524645};\\\", \\\"{x:1611,y:912,t:1527628524663};\\\", \\\"{x:1609,y:911,t:1527628524679};\\\", \\\"{x:1605,y:908,t:1527628524695};\\\", \\\"{x:1602,y:905,t:1527628524713};\\\", \\\"{x:1601,y:904,t:1527628524728};\\\", \\\"{x:1600,y:903,t:1527628524746};\\\", \\\"{x:1599,y:902,t:1527628524763};\\\", \\\"{x:1597,y:902,t:1527628524779};\\\", \\\"{x:1594,y:901,t:1527628524796};\\\", \\\"{x:1590,y:900,t:1527628524813};\\\", \\\"{x:1587,y:897,t:1527628524828};\\\", \\\"{x:1582,y:893,t:1527628524845};\\\", \\\"{x:1575,y:887,t:1527628524862};\\\", \\\"{x:1567,y:881,t:1527628524878};\\\", \\\"{x:1547,y:869,t:1527628524895};\\\", \\\"{x:1515,y:849,t:1527628524912};\\\", \\\"{x:1493,y:837,t:1527628524928};\\\", \\\"{x:1477,y:823,t:1527628524945};\\\", \\\"{x:1475,y:821,t:1527628524962};\\\", \\\"{x:1475,y:820,t:1527628525007};\\\", \\\"{x:1475,y:821,t:1527628525311};\\\", \\\"{x:1475,y:822,t:1527628525335};\\\", \\\"{x:1475,y:824,t:1527628525359};\\\", \\\"{x:1475,y:825,t:1527628525471};\\\", \\\"{x:1473,y:826,t:1527628526280};\\\", \\\"{x:1465,y:826,t:1527628526296};\\\", \\\"{x:1459,y:828,t:1527628526314};\\\", \\\"{x:1444,y:828,t:1527628526331};\\\", \\\"{x:1406,y:828,t:1527628526347};\\\", \\\"{x:1323,y:828,t:1527628526364};\\\", \\\"{x:1231,y:814,t:1527628526381};\\\", \\\"{x:1133,y:784,t:1527628526397};\\\", \\\"{x:1019,y:744,t:1527628526413};\\\", \\\"{x:829,y:651,t:1527628526430};\\\", \\\"{x:719,y:605,t:1527628526446};\\\", \\\"{x:624,y:555,t:1527628526463};\\\", \\\"{x:553,y:516,t:1527628526481};\\\", \\\"{x:542,y:508,t:1527628526493};\\\", \\\"{x:524,y:495,t:1527628526509};\\\", \\\"{x:522,y:493,t:1527628526527};\\\", \\\"{x:522,y:492,t:1527628526543};\\\", \\\"{x:522,y:489,t:1527628526559};\\\", \\\"{x:522,y:488,t:1527628526606};\\\", \\\"{x:522,y:487,t:1527628526614};\\\", \\\"{x:525,y:486,t:1527628526628};\\\", \\\"{x:526,y:486,t:1527628526644};\\\", \\\"{x:528,y:486,t:1527628526663};\\\", \\\"{x:526,y:486,t:1527628526701};\\\", \\\"{x:525,y:486,t:1527628526713};\\\", \\\"{x:523,y:487,t:1527628526730};\\\", \\\"{x:522,y:487,t:1527628526748};\\\", \\\"{x:522,y:488,t:1527628526766};\\\", \\\"{x:522,y:489,t:1527628526780};\\\", \\\"{x:522,y:492,t:1527628526797};\\\", \\\"{x:522,y:494,t:1527628526813};\\\", \\\"{x:529,y:496,t:1527628526830};\\\", \\\"{x:533,y:496,t:1527628526847};\\\", \\\"{x:542,y:496,t:1527628526864};\\\", \\\"{x:552,y:492,t:1527628526880};\\\", \\\"{x:564,y:490,t:1527628526897};\\\", \\\"{x:582,y:489,t:1527628526915};\\\", \\\"{x:603,y:489,t:1527628526930};\\\", \\\"{x:626,y:492,t:1527628526950};\\\", \\\"{x:641,y:497,t:1527628526964};\\\", \\\"{x:648,y:501,t:1527628526980};\\\", \\\"{x:652,y:504,t:1527628526997};\\\", \\\"{x:655,y:512,t:1527628527014};\\\", \\\"{x:658,y:522,t:1527628527030};\\\", \\\"{x:661,y:536,t:1527628527047};\\\", \\\"{x:666,y:555,t:1527628527064};\\\", \\\"{x:670,y:569,t:1527628527081};\\\", \\\"{x:674,y:579,t:1527628527097};\\\", \\\"{x:674,y:588,t:1527628527114};\\\", \\\"{x:674,y:594,t:1527628527131};\\\", \\\"{x:673,y:596,t:1527628527147};\\\", \\\"{x:671,y:598,t:1527628527164};\\\", \\\"{x:669,y:601,t:1527628527180};\\\", \\\"{x:666,y:603,t:1527628527197};\\\", \\\"{x:664,y:603,t:1527628527214};\\\", \\\"{x:660,y:603,t:1527628527230};\\\", \\\"{x:655,y:603,t:1527628527247};\\\", \\\"{x:653,y:603,t:1527628527264};\\\", \\\"{x:652,y:603,t:1527628527287};\\\", \\\"{x:651,y:603,t:1527628527297};\\\", \\\"{x:648,y:602,t:1527628527314};\\\", \\\"{x:647,y:601,t:1527628527331};\\\", \\\"{x:643,y:597,t:1527628527349};\\\", \\\"{x:639,y:595,t:1527628527364};\\\", \\\"{x:636,y:593,t:1527628527381};\\\", \\\"{x:631,y:588,t:1527628527397};\\\", \\\"{x:623,y:582,t:1527628527413};\\\", \\\"{x:621,y:579,t:1527628527431};\\\", \\\"{x:619,y:578,t:1527628527448};\\\", \\\"{x:618,y:578,t:1527628527542};\\\", \\\"{x:619,y:577,t:1527628527741};\\\", \\\"{x:620,y:577,t:1527628527758};\\\", \\\"{x:621,y:577,t:1527628527766};\\\", \\\"{x:623,y:577,t:1527628527781};\\\", \\\"{x:633,y:585,t:1527628527797};\\\", \\\"{x:649,y:602,t:1527628527815};\\\", \\\"{x:703,y:636,t:1527628527832};\\\", \\\"{x:815,y:695,t:1527628527849};\\\", \\\"{x:919,y:736,t:1527628527864};\\\", \\\"{x:1019,y:762,t:1527628527881};\\\", \\\"{x:1108,y:789,t:1527628527898};\\\", \\\"{x:1191,y:813,t:1527628527914};\\\", \\\"{x:1266,y:837,t:1527628527931};\\\", \\\"{x:1330,y:864,t:1527628527948};\\\", \\\"{x:1365,y:877,t:1527628527964};\\\", \\\"{x:1377,y:882,t:1527628527981};\\\", \\\"{x:1381,y:884,t:1527628527998};\\\", \\\"{x:1386,y:888,t:1527628528015};\\\", \\\"{x:1394,y:893,t:1527628528031};\\\", \\\"{x:1405,y:899,t:1527628528049};\\\", \\\"{x:1412,y:901,t:1527628528064};\\\", \\\"{x:1413,y:902,t:1527628528081};\\\", \\\"{x:1415,y:902,t:1527628528102};\\\", \\\"{x:1418,y:901,t:1527628528115};\\\", \\\"{x:1436,y:897,t:1527628528131};\\\", \\\"{x:1463,y:890,t:1527628528148};\\\", \\\"{x:1479,y:884,t:1527628528165};\\\", \\\"{x:1486,y:878,t:1527628528181};\\\", \\\"{x:1502,y:860,t:1527628528199};\\\", \\\"{x:1523,y:840,t:1527628528215};\\\", \\\"{x:1543,y:823,t:1527628528231};\\\", \\\"{x:1546,y:821,t:1527628528248};\\\", \\\"{x:1546,y:822,t:1527628528382};\\\", \\\"{x:1542,y:825,t:1527628528398};\\\", \\\"{x:1536,y:827,t:1527628528415};\\\", \\\"{x:1532,y:828,t:1527628528432};\\\", \\\"{x:1525,y:830,t:1527628528449};\\\", \\\"{x:1522,y:832,t:1527628528465};\\\", \\\"{x:1520,y:834,t:1527628528482};\\\", \\\"{x:1518,y:835,t:1527628528499};\\\", \\\"{x:1517,y:836,t:1527628528516};\\\", \\\"{x:1516,y:838,t:1527628528531};\\\", \\\"{x:1513,y:841,t:1527628528548};\\\", \\\"{x:1512,y:841,t:1527628528566};\\\", \\\"{x:1511,y:842,t:1527628528582};\\\", \\\"{x:1509,y:842,t:1527628528607};\\\", \\\"{x:1508,y:843,t:1527628528615};\\\", \\\"{x:1505,y:845,t:1527628528633};\\\", \\\"{x:1502,y:846,t:1527628528649};\\\", \\\"{x:1500,y:848,t:1527628528666};\\\", \\\"{x:1499,y:849,t:1527628528683};\\\", \\\"{x:1495,y:850,t:1527628528699};\\\", \\\"{x:1490,y:851,t:1527628528716};\\\", \\\"{x:1484,y:853,t:1527628528733};\\\", \\\"{x:1481,y:853,t:1527628528750};\\\", \\\"{x:1480,y:853,t:1527628528766};\\\", \\\"{x:1479,y:852,t:1527628528896};\\\", \\\"{x:1478,y:852,t:1527628528903};\\\", \\\"{x:1476,y:849,t:1527628528916};\\\", \\\"{x:1466,y:835,t:1527628528933};\\\", \\\"{x:1451,y:820,t:1527628528949};\\\", \\\"{x:1433,y:803,t:1527628528965};\\\", \\\"{x:1400,y:776,t:1527628528982};\\\", \\\"{x:1379,y:754,t:1527628528999};\\\", \\\"{x:1365,y:744,t:1527628529016};\\\", \\\"{x:1361,y:741,t:1527628529033};\\\", \\\"{x:1359,y:738,t:1527628529050};\\\", \\\"{x:1357,y:734,t:1527628529066};\\\", \\\"{x:1356,y:733,t:1527628529083};\\\", \\\"{x:1355,y:733,t:1527628529100};\\\", \\\"{x:1354,y:733,t:1527628529167};\\\", \\\"{x:1352,y:731,t:1527628529183};\\\", \\\"{x:1351,y:731,t:1527628529199};\\\", \\\"{x:1350,y:730,t:1527628529216};\\\", \\\"{x:1347,y:727,t:1527628529233};\\\", \\\"{x:1346,y:724,t:1527628529249};\\\", \\\"{x:1345,y:720,t:1527628529266};\\\", \\\"{x:1345,y:718,t:1527628529282};\\\", \\\"{x:1345,y:715,t:1527628529299};\\\", \\\"{x:1345,y:714,t:1527628529343};\\\", \\\"{x:1344,y:711,t:1527628529359};\\\", \\\"{x:1344,y:710,t:1527628529375};\\\", \\\"{x:1344,y:708,t:1527628529383};\\\", \\\"{x:1344,y:705,t:1527628529399};\\\", \\\"{x:1344,y:702,t:1527628529416};\\\", \\\"{x:1344,y:701,t:1527628529434};\\\", \\\"{x:1344,y:697,t:1527628529449};\\\", \\\"{x:1343,y:694,t:1527628529467};\\\", \\\"{x:1342,y:692,t:1527628529484};\\\", \\\"{x:1342,y:691,t:1527628529503};\\\", \\\"{x:1342,y:690,t:1527628529631};\\\", \\\"{x:1339,y:687,t:1527628530558};\\\", \\\"{x:1312,y:686,t:1527628530566};\\\", \\\"{x:1214,y:672,t:1527628530583};\\\", \\\"{x:1115,y:672,t:1527628530600};\\\", \\\"{x:1037,y:672,t:1527628530616};\\\", \\\"{x:959,y:682,t:1527628530633};\\\", \\\"{x:887,y:691,t:1527628530651};\\\", \\\"{x:815,y:691,t:1527628530667};\\\", \\\"{x:738,y:688,t:1527628530683};\\\", \\\"{x:665,y:672,t:1527628530701};\\\", \\\"{x:609,y:656,t:1527628530717};\\\", \\\"{x:575,y:645,t:1527628530734};\\\", \\\"{x:554,y:635,t:1527628530750};\\\", \\\"{x:551,y:633,t:1527628530767};\\\", \\\"{x:550,y:632,t:1527628530783};\\\", \\\"{x:549,y:630,t:1527628530801};\\\", \\\"{x:548,y:625,t:1527628530817};\\\", \\\"{x:546,y:613,t:1527628530833};\\\", \\\"{x:541,y:595,t:1527628530851};\\\", \\\"{x:525,y:568,t:1527628530868};\\\", \\\"{x:509,y:544,t:1527628530883};\\\", \\\"{x:499,y:523,t:1527628530900};\\\", \\\"{x:495,y:508,t:1527628530918};\\\", \\\"{x:494,y:495,t:1527628530933};\\\", \\\"{x:494,y:475,t:1527628530950};\\\", \\\"{x:497,y:467,t:1527628530967};\\\", \\\"{x:499,y:464,t:1527628530983};\\\", \\\"{x:500,y:463,t:1527628531000};\\\", \\\"{x:503,y:462,t:1527628531017};\\\", \\\"{x:511,y:461,t:1527628531034};\\\", \\\"{x:517,y:461,t:1527628531051};\\\", \\\"{x:519,y:461,t:1527628531067};\\\", \\\"{x:521,y:462,t:1527628531083};\\\", \\\"{x:521,y:465,t:1527628531100};\\\", \\\"{x:521,y:472,t:1527628531117};\\\", \\\"{x:518,y:485,t:1527628531133};\\\", \\\"{x:507,y:510,t:1527628531151};\\\", \\\"{x:499,y:529,t:1527628531169};\\\", \\\"{x:484,y:545,t:1527628531185};\\\", \\\"{x:465,y:557,t:1527628531200};\\\", \\\"{x:442,y:563,t:1527628531217};\\\", \\\"{x:419,y:568,t:1527628531234};\\\", \\\"{x:406,y:568,t:1527628531251};\\\", \\\"{x:401,y:570,t:1527628531267};\\\", \\\"{x:408,y:570,t:1527628531350};\\\", \\\"{x:449,y:558,t:1527628531368};\\\", \\\"{x:510,y:544,t:1527628531385};\\\", \\\"{x:573,y:527,t:1527628531400};\\\", \\\"{x:618,y:515,t:1527628531418};\\\", \\\"{x:643,y:508,t:1527628531435};\\\", \\\"{x:666,y:501,t:1527628531450};\\\", \\\"{x:691,y:496,t:1527628531467};\\\", \\\"{x:710,y:491,t:1527628531484};\\\", \\\"{x:716,y:489,t:1527628531501};\\\", \\\"{x:718,y:488,t:1527628531517};\\\", \\\"{x:720,y:488,t:1527628531534};\\\", \\\"{x:722,y:487,t:1527628531551};\\\", \\\"{x:725,y:486,t:1527628531568};\\\", \\\"{x:728,y:485,t:1527628531584};\\\", \\\"{x:732,y:484,t:1527628531601};\\\", \\\"{x:741,y:482,t:1527628531617};\\\", \\\"{x:747,y:482,t:1527628531634};\\\", \\\"{x:755,y:480,t:1527628531651};\\\", \\\"{x:762,y:479,t:1527628531667};\\\", \\\"{x:766,y:478,t:1527628531684};\\\", \\\"{x:768,y:477,t:1527628531701};\\\", \\\"{x:770,y:476,t:1527628531717};\\\", \\\"{x:776,y:474,t:1527628531735};\\\", \\\"{x:780,y:474,t:1527628531752};\\\", \\\"{x:782,y:474,t:1527628531768};\\\", \\\"{x:783,y:474,t:1527628531784};\\\", \\\"{x:786,y:474,t:1527628531823};\\\", \\\"{x:793,y:476,t:1527628531835};\\\", \\\"{x:821,y:481,t:1527628531851};\\\", \\\"{x:860,y:488,t:1527628531871};\\\", \\\"{x:881,y:492,t:1527628531884};\\\", \\\"{x:887,y:493,t:1527628531901};\\\", \\\"{x:883,y:496,t:1527628532022};\\\", \\\"{x:879,y:498,t:1527628532035};\\\", \\\"{x:873,y:500,t:1527628532051};\\\", \\\"{x:866,y:501,t:1527628532069};\\\", \\\"{x:861,y:502,t:1527628532085};\\\", \\\"{x:856,y:503,t:1527628532102};\\\", \\\"{x:851,y:503,t:1527628532119};\\\", \\\"{x:849,y:503,t:1527628532135};\\\", \\\"{x:848,y:503,t:1527628532174};\\\", \\\"{x:847,y:503,t:1527628532231};\\\", \\\"{x:846,y:503,t:1527628532239};\\\", \\\"{x:845,y:503,t:1527628532252};\\\", \\\"{x:844,y:503,t:1527628532268};\\\", \\\"{x:841,y:503,t:1527628532285};\\\", \\\"{x:838,y:501,t:1527628532302};\\\", \\\"{x:837,y:500,t:1527628532319};\\\", \\\"{x:836,y:500,t:1527628532407};\\\", \\\"{x:835,y:501,t:1527628533055};\\\", \\\"{x:826,y:509,t:1527628533069};\\\", \\\"{x:790,y:549,t:1527628533088};\\\", \\\"{x:695,y:644,t:1527628533103};\\\", \\\"{x:622,y:700,t:1527628533118};\\\", \\\"{x:547,y:750,t:1527628533135};\\\", \\\"{x:491,y:779,t:1527628533153};\\\", \\\"{x:457,y:796,t:1527628533168};\\\", \\\"{x:447,y:800,t:1527628533185};\\\", \\\"{x:447,y:801,t:1527628533202};\\\", \\\"{x:446,y:801,t:1527628533254};\\\", \\\"{x:445,y:801,t:1527628533270};\\\", \\\"{x:444,y:800,t:1527628533310};\\\", \\\"{x:447,y:791,t:1527628533319};\\\", \\\"{x:456,y:777,t:1527628533336};\\\", \\\"{x:464,y:766,t:1527628533353};\\\", \\\"{x:473,y:755,t:1527628533369};\\\", \\\"{x:477,y:749,t:1527628533386};\\\", \\\"{x:479,y:747,t:1527628533402};\\\", \\\"{x:480,y:746,t:1527628533418};\\\", \\\"{x:481,y:746,t:1527628533436};\\\", \\\"{x:483,y:745,t:1527628533453};\\\", \\\"{x:484,y:744,t:1527628533470};\\\", \\\"{x:485,y:743,t:1527628533486};\\\", \\\"{x:486,y:743,t:1527628533502};\\\", \\\"{x:487,y:742,t:1527628533566};\\\", \\\"{x:487,y:741,t:1527628534742};\\\", \\\"{x:485,y:741,t:1527628534753};\\\", \\\"{x:480,y:740,t:1527628534770};\\\", \\\"{x:478,y:740,t:1527628534787};\\\" ] }, { \\\"rt\\\": 53707, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 711173, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -04 PM-03 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:460,y:740,t:1527628534952};\\\", \\\"{x:459,y:740,t:1527628534970};\\\", \\\"{x:457,y:741,t:1527628534987};\\\", \\\"{x:456,y:741,t:1527628535003};\\\", \\\"{x:455,y:742,t:1527628535020};\\\", \\\"{x:453,y:742,t:1527628535071};\\\", \\\"{x:453,y:743,t:1527628535125};\\\", \\\"{x:452,y:744,t:1527628535142};\\\", \\\"{x:450,y:744,t:1527628535158};\\\", \\\"{x:449,y:746,t:1527628535171};\\\", \\\"{x:447,y:747,t:1527628535188};\\\", \\\"{x:444,y:748,t:1527628535204};\\\", \\\"{x:443,y:749,t:1527628535238};\\\", \\\"{x:448,y:749,t:1527628535968};\\\", \\\"{x:499,y:761,t:1527628535987};\\\", \\\"{x:564,y:773,t:1527628536004};\\\", \\\"{x:670,y:793,t:1527628536022};\\\", \\\"{x:815,y:827,t:1527628536037};\\\", \\\"{x:891,y:839,t:1527628536054};\\\", \\\"{x:942,y:847,t:1527628536071};\\\", \\\"{x:990,y:854,t:1527628536088};\\\", \\\"{x:1052,y:868,t:1527628536104};\\\", \\\"{x:1107,y:873,t:1527628536122};\\\", \\\"{x:1169,y:884,t:1527628536139};\\\", \\\"{x:1225,y:892,t:1527628536154};\\\", \\\"{x:1284,y:900,t:1527628536171};\\\", \\\"{x:1340,y:908,t:1527628536189};\\\", \\\"{x:1389,y:913,t:1527628536205};\\\", \\\"{x:1418,y:913,t:1527628536222};\\\", \\\"{x:1432,y:913,t:1527628536238};\\\", \\\"{x:1437,y:912,t:1527628536255};\\\", \\\"{x:1441,y:912,t:1527628536272};\\\", \\\"{x:1452,y:911,t:1527628536289};\\\", \\\"{x:1468,y:909,t:1527628536304};\\\", \\\"{x:1486,y:906,t:1527628536324};\\\", \\\"{x:1494,y:904,t:1527628536340};\\\", \\\"{x:1495,y:904,t:1527628536383};\\\", \\\"{x:1496,y:904,t:1527628536527};\\\", \\\"{x:1497,y:904,t:1527628536539};\\\", \\\"{x:1495,y:904,t:1527628536687};\\\", \\\"{x:1491,y:904,t:1527628536695};\\\", \\\"{x:1483,y:900,t:1527628536706};\\\", \\\"{x:1459,y:890,t:1527628536723};\\\", \\\"{x:1435,y:880,t:1527628536739};\\\", \\\"{x:1414,y:865,t:1527628536756};\\\", \\\"{x:1398,y:854,t:1527628536772};\\\", \\\"{x:1387,y:845,t:1527628536789};\\\", \\\"{x:1377,y:836,t:1527628536806};\\\", \\\"{x:1373,y:831,t:1527628536822};\\\", \\\"{x:1372,y:825,t:1527628536839};\\\", \\\"{x:1372,y:822,t:1527628536856};\\\", \\\"{x:1372,y:815,t:1527628536873};\\\", \\\"{x:1372,y:810,t:1527628536889};\\\", \\\"{x:1372,y:805,t:1527628536906};\\\", \\\"{x:1376,y:797,t:1527628536923};\\\", \\\"{x:1386,y:781,t:1527628536939};\\\", \\\"{x:1396,y:768,t:1527628536956};\\\", \\\"{x:1400,y:762,t:1527628536973};\\\", \\\"{x:1409,y:753,t:1527628536989};\\\", \\\"{x:1412,y:751,t:1527628537006};\\\", \\\"{x:1414,y:749,t:1527628537023};\\\", \\\"{x:1416,y:749,t:1527628537039};\\\", \\\"{x:1422,y:749,t:1527628537057};\\\", \\\"{x:1432,y:747,t:1527628537073};\\\", \\\"{x:1447,y:747,t:1527628537089};\\\", \\\"{x:1465,y:747,t:1527628537106};\\\", \\\"{x:1477,y:747,t:1527628537124};\\\", \\\"{x:1483,y:749,t:1527628537140};\\\", \\\"{x:1487,y:750,t:1527628537156};\\\", \\\"{x:1490,y:752,t:1527628537173};\\\", \\\"{x:1493,y:753,t:1527628537190};\\\", \\\"{x:1500,y:757,t:1527628537206};\\\", \\\"{x:1514,y:766,t:1527628537224};\\\", \\\"{x:1524,y:773,t:1527628537240};\\\", \\\"{x:1531,y:779,t:1527628537256};\\\", \\\"{x:1534,y:782,t:1527628537272};\\\", \\\"{x:1535,y:784,t:1527628537289};\\\", \\\"{x:1535,y:786,t:1527628537305};\\\", \\\"{x:1534,y:786,t:1527628537611};\\\", \\\"{x:1533,y:786,t:1527628537716};\\\", \\\"{x:1533,y:785,t:1527628538179};\\\", \\\"{x:1531,y:779,t:1527628538195};\\\", \\\"{x:1530,y:773,t:1527628538211};\\\", \\\"{x:1528,y:767,t:1527628538228};\\\", \\\"{x:1527,y:764,t:1527628538245};\\\", \\\"{x:1527,y:763,t:1527628538261};\\\", \\\"{x:1526,y:761,t:1527628538279};\\\", \\\"{x:1524,y:760,t:1527628538491};\\\", \\\"{x:1523,y:760,t:1527628538499};\\\", \\\"{x:1522,y:760,t:1527628538515};\\\", \\\"{x:1521,y:761,t:1527628538530};\\\", \\\"{x:1520,y:762,t:1527628538546};\\\", \\\"{x:1518,y:763,t:1527628538561};\\\", \\\"{x:1515,y:765,t:1527628538578};\\\", \\\"{x:1513,y:765,t:1527628538595};\\\", \\\"{x:1514,y:767,t:1527628539739};\\\", \\\"{x:1515,y:767,t:1527628539747};\\\", \\\"{x:1516,y:767,t:1527628539762};\\\", \\\"{x:1520,y:768,t:1527628539780};\\\", \\\"{x:1524,y:772,t:1527628539796};\\\", \\\"{x:1530,y:782,t:1527628539813};\\\", \\\"{x:1539,y:803,t:1527628539829};\\\", \\\"{x:1548,y:831,t:1527628539846};\\\", \\\"{x:1561,y:862,t:1527628539863};\\\", \\\"{x:1577,y:895,t:1527628539878};\\\", \\\"{x:1594,y:927,t:1527628539895};\\\", \\\"{x:1614,y:956,t:1527628539912};\\\", \\\"{x:1626,y:978,t:1527628539929};\\\", \\\"{x:1632,y:993,t:1527628539945};\\\", \\\"{x:1633,y:997,t:1527628539962};\\\", \\\"{x:1633,y:1000,t:1527628539978};\\\", \\\"{x:1633,y:1001,t:1527628540051};\\\", \\\"{x:1633,y:1002,t:1527628540064};\\\", \\\"{x:1623,y:1002,t:1527628540080};\\\", \\\"{x:1610,y:1002,t:1527628540096};\\\", \\\"{x:1601,y:1002,t:1527628540113};\\\", \\\"{x:1593,y:1002,t:1527628540131};\\\", \\\"{x:1590,y:1002,t:1527628540146};\\\", \\\"{x:1585,y:998,t:1527628540163};\\\", \\\"{x:1580,y:991,t:1527628540180};\\\", \\\"{x:1567,y:980,t:1527628540196};\\\", \\\"{x:1551,y:966,t:1527628540214};\\\", \\\"{x:1534,y:953,t:1527628540231};\\\", \\\"{x:1520,y:941,t:1527628540246};\\\", \\\"{x:1513,y:932,t:1527628540263};\\\", \\\"{x:1507,y:924,t:1527628540280};\\\", \\\"{x:1505,y:920,t:1527628540297};\\\", \\\"{x:1504,y:919,t:1527628540313};\\\", \\\"{x:1504,y:918,t:1527628540330};\\\", \\\"{x:1508,y:921,t:1527628540467};\\\", \\\"{x:1514,y:926,t:1527628540480};\\\", \\\"{x:1522,y:933,t:1527628540497};\\\", \\\"{x:1532,y:940,t:1527628540513};\\\", \\\"{x:1547,y:951,t:1527628540531};\\\", \\\"{x:1552,y:955,t:1527628540546};\\\", \\\"{x:1555,y:955,t:1527628540563};\\\", \\\"{x:1556,y:957,t:1527628540731};\\\", \\\"{x:1556,y:958,t:1527628540747};\\\", \\\"{x:1554,y:961,t:1527628540764};\\\", \\\"{x:1551,y:963,t:1527628540781};\\\", \\\"{x:1549,y:965,t:1527628540797};\\\", \\\"{x:1547,y:966,t:1527628540814};\\\", \\\"{x:1546,y:967,t:1527628540830};\\\", \\\"{x:1546,y:965,t:1527628541043};\\\", \\\"{x:1546,y:964,t:1527628541058};\\\", \\\"{x:1546,y:963,t:1527628541074};\\\", \\\"{x:1548,y:961,t:1527628541082};\\\", \\\"{x:1549,y:959,t:1527628541114};\\\", \\\"{x:1549,y:958,t:1527628541146};\\\", \\\"{x:1549,y:957,t:1527628541162};\\\", \\\"{x:1550,y:957,t:1527628541178};\\\", \\\"{x:1550,y:956,t:1527628541275};\\\", \\\"{x:1550,y:955,t:1527628541298};\\\", \\\"{x:1551,y:954,t:1527628541331};\\\", \\\"{x:1551,y:953,t:1527628541387};\\\", \\\"{x:1551,y:952,t:1527628541523};\\\", \\\"{x:1551,y:951,t:1527628541539};\\\", \\\"{x:1551,y:950,t:1527628541554};\\\", \\\"{x:1551,y:949,t:1527628541571};\\\", \\\"{x:1551,y:948,t:1527628541587};\\\", \\\"{x:1551,y:947,t:1527628541603};\\\", \\\"{x:1551,y:946,t:1527628541683};\\\", \\\"{x:1551,y:945,t:1527628541699};\\\", \\\"{x:1551,y:944,t:1527628541714};\\\", \\\"{x:1551,y:943,t:1527628541731};\\\", \\\"{x:1551,y:940,t:1527628541748};\\\", \\\"{x:1551,y:939,t:1527628541765};\\\", \\\"{x:1551,y:937,t:1527628541782};\\\", \\\"{x:1551,y:933,t:1527628541798};\\\", \\\"{x:1551,y:932,t:1527628541816};\\\", \\\"{x:1551,y:930,t:1527628541832};\\\", \\\"{x:1550,y:929,t:1527628541848};\\\", \\\"{x:1550,y:928,t:1527628541867};\\\", \\\"{x:1550,y:927,t:1527628541883};\\\", \\\"{x:1550,y:926,t:1527628541906};\\\", \\\"{x:1549,y:925,t:1527628541922};\\\", \\\"{x:1549,y:924,t:1527628541939};\\\", \\\"{x:1549,y:923,t:1527628541971};\\\", \\\"{x:1549,y:922,t:1527628541982};\\\", \\\"{x:1549,y:921,t:1527628541999};\\\", \\\"{x:1549,y:920,t:1527628542019};\\\", \\\"{x:1549,y:919,t:1527628542031};\\\", \\\"{x:1549,y:918,t:1527628542048};\\\", \\\"{x:1549,y:917,t:1527628542067};\\\", \\\"{x:1549,y:916,t:1527628542082};\\\", \\\"{x:1549,y:915,t:1527628542099};\\\", \\\"{x:1549,y:914,t:1527628542147};\\\", \\\"{x:1549,y:913,t:1527628542155};\\\", \\\"{x:1549,y:912,t:1527628542170};\\\", \\\"{x:1549,y:911,t:1527628542203};\\\", \\\"{x:1549,y:910,t:1527628542215};\\\", \\\"{x:1549,y:909,t:1527628542233};\\\", \\\"{x:1549,y:908,t:1527628542250};\\\", \\\"{x:1548,y:906,t:1527628542265};\\\", \\\"{x:1547,y:903,t:1527628542283};\\\", \\\"{x:1547,y:899,t:1527628542298};\\\", \\\"{x:1545,y:893,t:1527628542315};\\\", \\\"{x:1545,y:892,t:1527628542332};\\\", \\\"{x:1545,y:890,t:1527628542348};\\\", \\\"{x:1545,y:888,t:1527628542365};\\\", \\\"{x:1545,y:887,t:1527628542383};\\\", \\\"{x:1545,y:885,t:1527628542398};\\\", \\\"{x:1545,y:884,t:1527628542415};\\\", \\\"{x:1544,y:882,t:1527628542432};\\\", \\\"{x:1544,y:880,t:1527628542449};\\\", \\\"{x:1543,y:877,t:1527628542465};\\\", \\\"{x:1543,y:874,t:1527628542482};\\\", \\\"{x:1542,y:869,t:1527628542499};\\\", \\\"{x:1542,y:867,t:1527628542515};\\\", \\\"{x:1542,y:865,t:1527628542533};\\\", \\\"{x:1541,y:862,t:1527628542549};\\\", \\\"{x:1541,y:860,t:1527628542565};\\\", \\\"{x:1541,y:859,t:1527628542582};\\\", \\\"{x:1541,y:856,t:1527628542600};\\\", \\\"{x:1541,y:854,t:1527628542615};\\\", \\\"{x:1541,y:850,t:1527628542632};\\\", \\\"{x:1541,y:847,t:1527628542650};\\\", \\\"{x:1541,y:842,t:1527628542666};\\\", \\\"{x:1541,y:837,t:1527628542683};\\\", \\\"{x:1541,y:831,t:1527628542698};\\\", \\\"{x:1541,y:825,t:1527628542715};\\\", \\\"{x:1541,y:823,t:1527628542733};\\\", \\\"{x:1542,y:818,t:1527628542749};\\\", \\\"{x:1542,y:816,t:1527628542765};\\\", \\\"{x:1542,y:814,t:1527628542783};\\\", \\\"{x:1542,y:810,t:1527628542799};\\\", \\\"{x:1542,y:808,t:1527628542816};\\\", \\\"{x:1542,y:806,t:1527628542833};\\\", \\\"{x:1542,y:804,t:1527628542850};\\\", \\\"{x:1542,y:801,t:1527628542867};\\\", \\\"{x:1543,y:797,t:1527628542883};\\\", \\\"{x:1543,y:796,t:1527628542899};\\\", \\\"{x:1543,y:794,t:1527628542917};\\\", \\\"{x:1543,y:791,t:1527628542932};\\\", \\\"{x:1543,y:789,t:1527628542950};\\\", \\\"{x:1543,y:788,t:1527628542966};\\\", \\\"{x:1543,y:785,t:1527628542982};\\\", \\\"{x:1543,y:782,t:1527628543000};\\\", \\\"{x:1543,y:780,t:1527628543016};\\\", \\\"{x:1543,y:779,t:1527628543032};\\\", \\\"{x:1543,y:776,t:1527628543049};\\\", \\\"{x:1543,y:772,t:1527628543066};\\\", \\\"{x:1543,y:770,t:1527628543082};\\\", \\\"{x:1543,y:769,t:1527628543099};\\\", \\\"{x:1543,y:767,t:1527628543116};\\\", \\\"{x:1543,y:766,t:1527628543132};\\\", \\\"{x:1543,y:763,t:1527628543149};\\\", \\\"{x:1543,y:761,t:1527628543166};\\\", \\\"{x:1543,y:760,t:1527628543182};\\\", \\\"{x:1543,y:757,t:1527628543199};\\\", \\\"{x:1543,y:755,t:1527628543216};\\\", \\\"{x:1543,y:751,t:1527628543233};\\\", \\\"{x:1543,y:746,t:1527628543248};\\\", \\\"{x:1543,y:740,t:1527628543266};\\\", \\\"{x:1543,y:735,t:1527628543282};\\\", \\\"{x:1543,y:731,t:1527628543299};\\\", \\\"{x:1543,y:726,t:1527628543316};\\\", \\\"{x:1543,y:722,t:1527628543333};\\\", \\\"{x:1543,y:719,t:1527628543349};\\\", \\\"{x:1543,y:717,t:1527628543366};\\\", \\\"{x:1543,y:715,t:1527628543383};\\\", \\\"{x:1543,y:714,t:1527628543399};\\\", \\\"{x:1543,y:713,t:1527628543416};\\\", \\\"{x:1543,y:712,t:1527628543434};\\\", \\\"{x:1543,y:711,t:1527628543547};\\\", \\\"{x:1543,y:710,t:1527628543563};\\\", \\\"{x:1543,y:709,t:1527628543571};\\\", \\\"{x:1543,y:708,t:1527628543583};\\\", \\\"{x:1543,y:704,t:1527628543601};\\\", \\\"{x:1543,y:701,t:1527628543616};\\\", \\\"{x:1543,y:697,t:1527628543634};\\\", \\\"{x:1543,y:694,t:1527628543650};\\\", \\\"{x:1543,y:696,t:1527628548947};\\\", \\\"{x:1543,y:697,t:1527628548955};\\\", \\\"{x:1544,y:699,t:1527628548971};\\\", \\\"{x:1544,y:700,t:1527628549067};\\\", \\\"{x:1544,y:702,t:1527628549075};\\\", \\\"{x:1544,y:703,t:1527628549089};\\\", \\\"{x:1544,y:707,t:1527628549106};\\\", \\\"{x:1545,y:712,t:1527628549122};\\\", \\\"{x:1546,y:720,t:1527628549138};\\\", \\\"{x:1547,y:729,t:1527628549156};\\\", \\\"{x:1547,y:744,t:1527628549172};\\\", \\\"{x:1547,y:763,t:1527628549188};\\\", \\\"{x:1547,y:786,t:1527628549206};\\\", \\\"{x:1549,y:824,t:1527628549222};\\\", \\\"{x:1551,y:854,t:1527628549238};\\\", \\\"{x:1552,y:882,t:1527628549256};\\\", \\\"{x:1552,y:899,t:1527628549272};\\\", \\\"{x:1552,y:918,t:1527628549289};\\\", \\\"{x:1552,y:924,t:1527628549305};\\\", \\\"{x:1552,y:931,t:1527628549323};\\\", \\\"{x:1551,y:935,t:1527628549339};\\\", \\\"{x:1551,y:937,t:1527628549356};\\\", \\\"{x:1550,y:938,t:1527628549373};\\\", \\\"{x:1550,y:940,t:1527628549394};\\\", \\\"{x:1549,y:940,t:1527628549467};\\\", \\\"{x:1549,y:941,t:1527628549475};\\\", \\\"{x:1549,y:943,t:1527628549490};\\\", \\\"{x:1549,y:947,t:1527628549506};\\\", \\\"{x:1548,y:955,t:1527628549522};\\\", \\\"{x:1547,y:960,t:1527628549539};\\\", \\\"{x:1546,y:961,t:1527628549556};\\\", \\\"{x:1546,y:959,t:1527628550923};\\\", \\\"{x:1547,y:954,t:1527628550941};\\\", \\\"{x:1547,y:950,t:1527628550958};\\\", \\\"{x:1548,y:946,t:1527628550973};\\\", \\\"{x:1548,y:941,t:1527628550991};\\\", \\\"{x:1549,y:936,t:1527628551007};\\\", \\\"{x:1549,y:933,t:1527628551024};\\\", \\\"{x:1549,y:929,t:1527628551041};\\\", \\\"{x:1549,y:926,t:1527628551057};\\\", \\\"{x:1549,y:921,t:1527628551073};\\\", \\\"{x:1549,y:906,t:1527628551091};\\\", \\\"{x:1549,y:900,t:1527628551108};\\\", \\\"{x:1549,y:890,t:1527628551124};\\\", \\\"{x:1549,y:873,t:1527628551140};\\\", \\\"{x:1549,y:866,t:1527628551157};\\\", \\\"{x:1549,y:862,t:1527628551173};\\\", \\\"{x:1549,y:858,t:1527628551190};\\\", \\\"{x:1549,y:853,t:1527628551208};\\\", \\\"{x:1549,y:844,t:1527628551224};\\\", \\\"{x:1549,y:842,t:1527628551241};\\\", \\\"{x:1549,y:840,t:1527628551257};\\\", \\\"{x:1549,y:838,t:1527628551274};\\\", \\\"{x:1549,y:832,t:1527628551291};\\\", \\\"{x:1549,y:831,t:1527628552282};\\\", \\\"{x:1548,y:831,t:1527628552291};\\\", \\\"{x:1543,y:831,t:1527628552308};\\\", \\\"{x:1536,y:831,t:1527628552324};\\\", \\\"{x:1529,y:831,t:1527628552341};\\\", \\\"{x:1524,y:831,t:1527628552358};\\\", \\\"{x:1521,y:831,t:1527628552375};\\\", \\\"{x:1520,y:831,t:1527628552390};\\\", \\\"{x:1519,y:831,t:1527628552505};\\\", \\\"{x:1518,y:831,t:1527628553058};\\\", \\\"{x:1516,y:831,t:1527628553234};\\\", \\\"{x:1515,y:831,t:1527628553251};\\\", \\\"{x:1513,y:831,t:1527628553259};\\\", \\\"{x:1511,y:831,t:1527628553276};\\\", \\\"{x:1509,y:831,t:1527628553293};\\\", \\\"{x:1508,y:831,t:1527628553322};\\\", \\\"{x:1506,y:831,t:1527628553442};\\\", \\\"{x:1505,y:831,t:1527628553459};\\\", \\\"{x:1503,y:831,t:1527628553476};\\\", \\\"{x:1501,y:831,t:1527628553493};\\\", \\\"{x:1496,y:831,t:1527628553510};\\\", \\\"{x:1482,y:831,t:1527628553528};\\\", \\\"{x:1467,y:831,t:1527628553543};\\\", \\\"{x:1448,y:831,t:1527628553560};\\\", \\\"{x:1427,y:831,t:1527628553577};\\\", \\\"{x:1411,y:831,t:1527628553593};\\\", \\\"{x:1400,y:831,t:1527628553610};\\\", \\\"{x:1398,y:831,t:1527628553627};\\\", \\\"{x:1399,y:831,t:1527628553746};\\\", \\\"{x:1401,y:829,t:1527628553759};\\\", \\\"{x:1402,y:829,t:1527628553776};\\\", \\\"{x:1406,y:828,t:1527628553793};\\\", \\\"{x:1410,y:827,t:1527628553809};\\\", \\\"{x:1422,y:824,t:1527628553826};\\\", \\\"{x:1436,y:820,t:1527628553843};\\\", \\\"{x:1444,y:815,t:1527628553859};\\\", \\\"{x:1448,y:815,t:1527628553876};\\\", \\\"{x:1449,y:814,t:1527628553893};\\\", \\\"{x:1451,y:813,t:1527628553909};\\\", \\\"{x:1452,y:813,t:1527628553926};\\\", \\\"{x:1454,y:813,t:1527628554027};\\\", \\\"{x:1454,y:812,t:1527628554044};\\\", \\\"{x:1455,y:812,t:1527628554139};\\\", \\\"{x:1458,y:812,t:1527628554162};\\\", \\\"{x:1459,y:812,t:1527628554177};\\\", \\\"{x:1460,y:812,t:1527628554194};\\\", \\\"{x:1461,y:812,t:1527628554211};\\\", \\\"{x:1462,y:812,t:1527628554227};\\\", \\\"{x:1465,y:814,t:1527628554244};\\\", \\\"{x:1469,y:816,t:1527628554261};\\\", \\\"{x:1471,y:817,t:1527628554277};\\\", \\\"{x:1472,y:817,t:1527628554294};\\\", \\\"{x:1474,y:817,t:1527628554311};\\\", \\\"{x:1475,y:818,t:1527628554330};\\\", \\\"{x:1476,y:819,t:1527628554354};\\\", \\\"{x:1478,y:819,t:1527628554370};\\\", \\\"{x:1478,y:820,t:1527628554378};\\\", \\\"{x:1480,y:820,t:1527628554394};\\\", \\\"{x:1481,y:822,t:1527628554410};\\\", \\\"{x:1483,y:822,t:1527628554434};\\\", \\\"{x:1483,y:823,t:1527628554450};\\\", \\\"{x:1484,y:823,t:1527628554547};\\\", \\\"{x:1484,y:824,t:1527628554562};\\\", \\\"{x:1484,y:825,t:1527628554579};\\\", \\\"{x:1484,y:828,t:1527628554593};\\\", \\\"{x:1484,y:830,t:1527628554610};\\\", \\\"{x:1484,y:831,t:1527628554627};\\\", \\\"{x:1484,y:832,t:1527628554643};\\\", \\\"{x:1484,y:833,t:1527628554660};\\\", \\\"{x:1484,y:834,t:1527628554745};\\\", \\\"{x:1484,y:835,t:1527628554995};\\\", \\\"{x:1484,y:836,t:1527628555018};\\\", \\\"{x:1485,y:836,t:1527628555042};\\\", \\\"{x:1486,y:836,t:1527628555050};\\\", \\\"{x:1488,y:836,t:1527628555066};\\\", \\\"{x:1490,y:836,t:1527628555078};\\\", \\\"{x:1496,y:836,t:1527628555095};\\\", \\\"{x:1503,y:836,t:1527628555110};\\\", \\\"{x:1510,y:836,t:1527628555127};\\\", \\\"{x:1520,y:834,t:1527628555144};\\\", \\\"{x:1530,y:834,t:1527628555160};\\\", \\\"{x:1541,y:834,t:1527628555178};\\\", \\\"{x:1550,y:834,t:1527628555194};\\\", \\\"{x:1552,y:834,t:1527628555212};\\\", \\\"{x:1553,y:834,t:1527628555242};\\\", \\\"{x:1555,y:834,t:1527628555258};\\\", \\\"{x:1556,y:834,t:1527628555283};\\\", \\\"{x:1558,y:834,t:1527628555306};\\\", \\\"{x:1557,y:834,t:1527628555851};\\\", \\\"{x:1556,y:834,t:1527628555862};\\\", \\\"{x:1555,y:834,t:1527628555899};\\\", \\\"{x:1554,y:834,t:1527628555912};\\\", \\\"{x:1553,y:833,t:1527628555929};\\\", \\\"{x:1552,y:833,t:1527628555946};\\\", \\\"{x:1550,y:833,t:1527628555962};\\\", \\\"{x:1543,y:830,t:1527628555979};\\\", \\\"{x:1538,y:828,t:1527628555996};\\\", \\\"{x:1533,y:826,t:1527628556011};\\\", \\\"{x:1530,y:825,t:1527628556029};\\\", \\\"{x:1530,y:824,t:1527628556046};\\\", \\\"{x:1529,y:824,t:1527628556379};\\\", \\\"{x:1532,y:822,t:1527628556396};\\\", \\\"{x:1537,y:822,t:1527628556413};\\\", \\\"{x:1541,y:822,t:1527628556429};\\\", \\\"{x:1542,y:822,t:1527628556445};\\\", \\\"{x:1543,y:822,t:1527628556466};\\\", \\\"{x:1544,y:822,t:1527628556531};\\\", \\\"{x:1545,y:822,t:1527628556547};\\\", \\\"{x:1547,y:822,t:1527628556563};\\\", \\\"{x:1547,y:823,t:1527628556578};\\\", \\\"{x:1548,y:823,t:1527628556602};\\\", \\\"{x:1548,y:825,t:1527628556619};\\\", \\\"{x:1548,y:826,t:1527628556629};\\\", \\\"{x:1548,y:828,t:1527628556646};\\\", \\\"{x:1547,y:829,t:1527628556663};\\\", \\\"{x:1547,y:831,t:1527628556680};\\\", \\\"{x:1546,y:832,t:1527628556715};\\\", \\\"{x:1542,y:832,t:1527628582825};\\\", \\\"{x:1529,y:829,t:1527628582838};\\\", \\\"{x:1507,y:825,t:1527628582854};\\\", \\\"{x:1496,y:830,t:1527628582870};\\\", \\\"{x:1495,y:839,t:1527628582888};\\\", \\\"{x:1495,y:840,t:1527628582903};\\\", \\\"{x:1494,y:849,t:1527628582921};\\\", \\\"{x:1481,y:856,t:1527628583121};\\\", \\\"{x:1440,y:878,t:1527628583138};\\\", \\\"{x:1424,y:889,t:1527628583155};\\\", \\\"{x:1409,y:905,t:1527628583171};\\\", \\\"{x:1397,y:919,t:1527628583187};\\\", \\\"{x:1384,y:935,t:1527628583205};\\\", \\\"{x:1375,y:945,t:1527628583220};\\\", \\\"{x:1367,y:951,t:1527628583238};\\\", \\\"{x:1361,y:951,t:1527628583255};\\\", \\\"{x:1358,y:953,t:1527628583271};\\\", \\\"{x:1357,y:953,t:1527628583352};\\\", \\\"{x:1357,y:943,t:1527628583360};\\\", \\\"{x:1357,y:926,t:1527628583372};\\\", \\\"{x:1355,y:899,t:1527628583388};\\\", \\\"{x:1355,y:871,t:1527628583405};\\\", \\\"{x:1355,y:841,t:1527628583422};\\\", \\\"{x:1355,y:815,t:1527628583437};\\\", \\\"{x:1351,y:797,t:1527628583455};\\\", \\\"{x:1351,y:790,t:1527628583472};\\\", \\\"{x:1351,y:779,t:1527628583488};\\\", \\\"{x:1357,y:767,t:1527628583505};\\\", \\\"{x:1360,y:767,t:1527628583529};\\\", \\\"{x:1363,y:767,t:1527628583538};\\\", \\\"{x:1367,y:767,t:1527628583555};\\\", \\\"{x:1366,y:765,t:1527628583792};\\\", \\\"{x:1359,y:752,t:1527628583805};\\\", \\\"{x:1350,y:733,t:1527628583822};\\\", \\\"{x:1349,y:727,t:1527628583839};\\\", \\\"{x:1346,y:724,t:1527628583854};\\\", \\\"{x:1337,y:718,t:1527628583871};\\\", \\\"{x:1286,y:701,t:1527628583889};\\\", \\\"{x:1202,y:684,t:1527628583905};\\\", \\\"{x:1098,y:662,t:1527628583922};\\\", \\\"{x:1001,y:650,t:1527628583939};\\\", \\\"{x:926,y:640,t:1527628583955};\\\", \\\"{x:872,y:636,t:1527628583972};\\\", \\\"{x:842,y:636,t:1527628583989};\\\", \\\"{x:806,y:645,t:1527628584005};\\\", \\\"{x:761,y:658,t:1527628584022};\\\", \\\"{x:712,y:669,t:1527628584039};\\\", \\\"{x:678,y:669,t:1527628584055};\\\", \\\"{x:659,y:668,t:1527628584072};\\\", \\\"{x:650,y:666,t:1527628584088};\\\", \\\"{x:646,y:666,t:1527628584106};\\\", \\\"{x:639,y:665,t:1527628584122};\\\", \\\"{x:631,y:660,t:1527628584139};\\\", \\\"{x:621,y:653,t:1527628584156};\\\", \\\"{x:604,y:644,t:1527628584172};\\\", \\\"{x:554,y:624,t:1527628584190};\\\", \\\"{x:464,y:592,t:1527628584206};\\\", \\\"{x:376,y:557,t:1527628584222};\\\", \\\"{x:256,y:506,t:1527628584243};\\\", \\\"{x:160,y:464,t:1527628584259};\\\", \\\"{x:43,y:405,t:1527628584281};\\\", \\\"{x:18,y:388,t:1527628584298};\\\", \\\"{x:14,y:386,t:1527628584315};\\\", \\\"{x:13,y:385,t:1527628584336};\\\", \\\"{x:15,y:385,t:1527628584377};\\\", \\\"{x:20,y:386,t:1527628584384};\\\", \\\"{x:23,y:387,t:1527628584397};\\\", \\\"{x:33,y:394,t:1527628584415};\\\", \\\"{x:48,y:404,t:1527628584431};\\\", \\\"{x:61,y:417,t:1527628584448};\\\", \\\"{x:82,y:448,t:1527628584465};\\\", \\\"{x:92,y:476,t:1527628584481};\\\", \\\"{x:98,y:497,t:1527628584498};\\\", \\\"{x:98,y:512,t:1527628584515};\\\", \\\"{x:100,y:516,t:1527628584536};\\\", \\\"{x:102,y:517,t:1527628584548};\\\", \\\"{x:103,y:518,t:1527628584729};\\\", \\\"{x:109,y:523,t:1527628584736};\\\", \\\"{x:115,y:528,t:1527628584749};\\\", \\\"{x:130,y:544,t:1527628584765};\\\", \\\"{x:141,y:557,t:1527628584783};\\\", \\\"{x:154,y:573,t:1527628584799};\\\", \\\"{x:157,y:575,t:1527628584815};\\\", \\\"{x:160,y:576,t:1527628584832};\\\", \\\"{x:162,y:576,t:1527628584848};\\\", \\\"{x:168,y:576,t:1527628584865};\\\", \\\"{x:170,y:576,t:1527628584882};\\\", \\\"{x:172,y:576,t:1527628584897};\\\", \\\"{x:172,y:573,t:1527628584915};\\\", \\\"{x:173,y:569,t:1527628584932};\\\", \\\"{x:173,y:567,t:1527628584948};\\\", \\\"{x:171,y:561,t:1527628584966};\\\", \\\"{x:167,y:552,t:1527628584982};\\\", \\\"{x:163,y:546,t:1527628584999};\\\", \\\"{x:160,y:541,t:1527628585015};\\\", \\\"{x:158,y:537,t:1527628585032};\\\", \\\"{x:157,y:535,t:1527628585048};\\\", \\\"{x:157,y:533,t:1527628585065};\\\", \\\"{x:156,y:533,t:1527628585113};\\\", \\\"{x:155,y:533,t:1527628585593};\\\", \\\"{x:158,y:537,t:1527628585640};\\\", \\\"{x:179,y:547,t:1527628585649};\\\", \\\"{x:236,y:580,t:1527628585667};\\\", \\\"{x:338,y:627,t:1527628585682};\\\", \\\"{x:478,y:675,t:1527628585699};\\\", \\\"{x:652,y:729,t:1527628585716};\\\", \\\"{x:844,y:796,t:1527628585732};\\\", \\\"{x:1019,y:865,t:1527628585750};\\\", \\\"{x:1170,y:922,t:1527628585766};\\\", \\\"{x:1297,y:958,t:1527628585782};\\\", \\\"{x:1394,y:986,t:1527628585800};\\\", \\\"{x:1439,y:992,t:1527628585816};\\\", \\\"{x:1454,y:992,t:1527628585832};\\\", \\\"{x:1458,y:992,t:1527628585849};\\\", \\\"{x:1459,y:989,t:1527628585873};\\\", \\\"{x:1459,y:985,t:1527628585883};\\\", \\\"{x:1459,y:977,t:1527628585899};\\\", \\\"{x:1459,y:970,t:1527628585916};\\\", \\\"{x:1459,y:967,t:1527628585933};\\\", \\\"{x:1459,y:965,t:1527628585949};\\\", \\\"{x:1459,y:958,t:1527628585967};\\\", \\\"{x:1459,y:946,t:1527628585984};\\\", \\\"{x:1453,y:929,t:1527628585999};\\\", \\\"{x:1433,y:906,t:1527628586016};\\\", \\\"{x:1406,y:879,t:1527628586033};\\\", \\\"{x:1399,y:869,t:1527628586050};\\\", \\\"{x:1395,y:863,t:1527628586066};\\\", \\\"{x:1389,y:855,t:1527628586083};\\\", \\\"{x:1378,y:841,t:1527628586099};\\\", \\\"{x:1367,y:833,t:1527628586116};\\\", \\\"{x:1355,y:827,t:1527628586133};\\\", \\\"{x:1350,y:825,t:1527628586149};\\\", \\\"{x:1343,y:821,t:1527628586166};\\\", \\\"{x:1334,y:820,t:1527628586183};\\\", \\\"{x:1325,y:815,t:1527628586200};\\\", \\\"{x:1318,y:810,t:1527628586217};\\\", \\\"{x:1316,y:808,t:1527628586233};\\\", \\\"{x:1315,y:808,t:1527628586250};\\\", \\\"{x:1314,y:806,t:1527628586266};\\\", \\\"{x:1313,y:804,t:1527628586283};\\\", \\\"{x:1313,y:802,t:1527628586300};\\\", \\\"{x:1313,y:798,t:1527628586316};\\\", \\\"{x:1313,y:792,t:1527628586333};\\\", \\\"{x:1316,y:788,t:1527628586350};\\\", \\\"{x:1324,y:782,t:1527628586366};\\\", \\\"{x:1329,y:778,t:1527628586383};\\\", \\\"{x:1332,y:777,t:1527628586400};\\\", \\\"{x:1332,y:776,t:1527628586416};\\\", \\\"{x:1333,y:774,t:1527628586433};\\\", \\\"{x:1333,y:771,t:1527628586450};\\\", \\\"{x:1335,y:764,t:1527628586465};\\\", \\\"{x:1335,y:760,t:1527628586483};\\\", \\\"{x:1336,y:756,t:1527628586500};\\\", \\\"{x:1337,y:752,t:1527628586516};\\\", \\\"{x:1339,y:749,t:1527628586533};\\\", \\\"{x:1340,y:745,t:1527628586551};\\\", \\\"{x:1341,y:743,t:1527628586567};\\\", \\\"{x:1341,y:742,t:1527628586657};\\\", \\\"{x:1339,y:742,t:1527628586667};\\\", \\\"{x:1330,y:742,t:1527628586683};\\\", \\\"{x:1322,y:742,t:1527628586700};\\\", \\\"{x:1296,y:748,t:1527628586717};\\\", \\\"{x:1264,y:758,t:1527628586733};\\\", \\\"{x:1211,y:781,t:1527628586750};\\\", \\\"{x:1145,y:810,t:1527628586767};\\\", \\\"{x:1082,y:836,t:1527628586783};\\\", \\\"{x:1031,y:860,t:1527628586800};\\\", \\\"{x:974,y:886,t:1527628586816};\\\", \\\"{x:949,y:894,t:1527628586833};\\\", \\\"{x:928,y:902,t:1527628586850};\\\", \\\"{x:914,y:907,t:1527628586867};\\\", \\\"{x:904,y:912,t:1527628586883};\\\", \\\"{x:895,y:913,t:1527628586900};\\\", \\\"{x:885,y:914,t:1527628586917};\\\", \\\"{x:876,y:914,t:1527628586934};\\\", \\\"{x:862,y:912,t:1527628586950};\\\", \\\"{x:851,y:910,t:1527628586967};\\\", \\\"{x:844,y:910,t:1527628586984};\\\", \\\"{x:839,y:910,t:1527628587000};\\\", \\\"{x:834,y:908,t:1527628587017};\\\", \\\"{x:829,y:907,t:1527628587034};\\\", \\\"{x:819,y:904,t:1527628587050};\\\", \\\"{x:803,y:901,t:1527628587067};\\\", \\\"{x:787,y:894,t:1527628587084};\\\", \\\"{x:778,y:887,t:1527628587100};\\\", \\\"{x:769,y:880,t:1527628587118};\\\", \\\"{x:766,y:877,t:1527628587134};\\\", \\\"{x:761,y:875,t:1527628587150};\\\", \\\"{x:756,y:873,t:1527628587167};\\\", \\\"{x:746,y:870,t:1527628587184};\\\", \\\"{x:728,y:865,t:1527628587200};\\\", \\\"{x:694,y:855,t:1527628587217};\\\", \\\"{x:672,y:848,t:1527628587234};\\\", \\\"{x:644,y:840,t:1527628587250};\\\", \\\"{x:610,y:823,t:1527628587267};\\\", \\\"{x:558,y:804,t:1527628587284};\\\", \\\"{x:508,y:781,t:1527628587300};\\\", \\\"{x:467,y:765,t:1527628587317};\\\", \\\"{x:435,y:752,t:1527628587334};\\\", \\\"{x:418,y:743,t:1527628587351};\\\", \\\"{x:410,y:742,t:1527628587367};\\\", \\\"{x:403,y:738,t:1527628587384};\\\", \\\"{x:402,y:738,t:1527628587401};\\\", \\\"{x:404,y:738,t:1527628587465};\\\", \\\"{x:406,y:738,t:1527628587480};\\\", \\\"{x:407,y:738,t:1527628587489};\\\", \\\"{x:408,y:738,t:1527628587502};\\\", \\\"{x:416,y:734,t:1527628587517};\\\", \\\"{x:428,y:730,t:1527628587534};\\\", \\\"{x:449,y:728,t:1527628587552};\\\", \\\"{x:468,y:726,t:1527628587568};\\\", \\\"{x:486,y:726,t:1527628587584};\\\", \\\"{x:505,y:726,t:1527628587601};\\\", \\\"{x:520,y:734,t:1527628587617};\\\", \\\"{x:533,y:740,t:1527628587634};\\\", \\\"{x:539,y:741,t:1527628587651};\\\", \\\"{x:542,y:744,t:1527628587667};\\\", \\\"{x:544,y:744,t:1527628587684};\\\", \\\"{x:547,y:747,t:1527628587701};\\\", \\\"{x:549,y:747,t:1527628587717};\\\", \\\"{x:550,y:747,t:1527628587734};\\\", \\\"{x:550,y:748,t:1527628587801};\\\", \\\"{x:550,y:747,t:1527628588345};\\\", \\\"{x:549,y:746,t:1527628588353};\\\", \\\"{x:549,y:745,t:1527628588368};\\\", \\\"{x:549,y:743,t:1527628588385};\\\", \\\"{x:548,y:742,t:1527628588409};\\\", \\\"{x:548,y:741,t:1527628588832};\\\", \\\"{x:548,y:740,t:1527628588848};\\\", \\\"{x:549,y:739,t:1527628588864};\\\", \\\"{x:550,y:738,t:1527628588880};\\\", \\\"{x:551,y:738,t:1527628588889};\\\", \\\"{x:552,y:738,t:1527628588902};\\\", \\\"{x:553,y:737,t:1527628588918};\\\", \\\"{x:554,y:737,t:1527628588935};\\\", \\\"{x:555,y:736,t:1527628588952};\\\", \\\"{x:558,y:735,t:1527628588968};\\\", \\\"{x:559,y:734,t:1527628588985};\\\", \\\"{x:558,y:734,t:1527628589601};\\\", \\\"{x:553,y:733,t:1527628589608};\\\", \\\"{x:544,y:731,t:1527628589619};\\\", \\\"{x:531,y:730,t:1527628589636};\\\", \\\"{x:519,y:729,t:1527628589652};\\\", \\\"{x:512,y:728,t:1527628589676};\\\", \\\"{x:511,y:728,t:1527628589686};\\\", \\\"{x:507,y:728,t:1527628589702};\\\", \\\"{x:501,y:728,t:1527628589719};\\\", \\\"{x:496,y:730,t:1527628589736};\\\" ] }, { \\\"rt\\\": 38186, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 750568, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-12 PM-02 PM-02 PM-02 PM-X -X -X -X -B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:736,t:1527628589866};\\\", \\\"{x:483,y:737,t:1527628590097};\\\", \\\"{x:484,y:738,t:1527628590104};\\\", \\\"{x:485,y:739,t:1527628590119};\\\", \\\"{x:485,y:741,t:1527628590136};\\\", \\\"{x:486,y:742,t:1527628591600};\\\", \\\"{x:488,y:743,t:1527628591609};\\\", \\\"{x:495,y:748,t:1527628591620};\\\", \\\"{x:518,y:780,t:1527628591637};\\\", \\\"{x:564,y:825,t:1527628591655};\\\", \\\"{x:639,y:877,t:1527628591670};\\\", \\\"{x:642,y:880,t:1527628591687};\\\", \\\"{x:644,y:880,t:1527628592402};\\\", \\\"{x:648,y:880,t:1527628592410};\\\", \\\"{x:649,y:880,t:1527628592421};\\\", \\\"{x:682,y:885,t:1527628592439};\\\", \\\"{x:693,y:888,t:1527628592455};\\\", \\\"{x:703,y:888,t:1527628592472};\\\", \\\"{x:717,y:888,t:1527628592489};\\\", \\\"{x:731,y:888,t:1527628592504};\\\", \\\"{x:732,y:887,t:1527628592522};\\\", \\\"{x:740,y:888,t:1527628592538};\\\", \\\"{x:773,y:888,t:1527628593050};\\\", \\\"{x:811,y:882,t:1527628593058};\\\", \\\"{x:877,y:865,t:1527628593073};\\\", \\\"{x:941,y:847,t:1527628593089};\\\", \\\"{x:1021,y:825,t:1527628593106};\\\", \\\"{x:1113,y:800,t:1527628593122};\\\", \\\"{x:1238,y:781,t:1527628593139};\\\", \\\"{x:1386,y:770,t:1527628593156};\\\", \\\"{x:1557,y:770,t:1527628593172};\\\", \\\"{x:1696,y:766,t:1527628593188};\\\", \\\"{x:1823,y:766,t:1527628593205};\\\", \\\"{x:1915,y:755,t:1527628593223};\\\", \\\"{x:1919,y:752,t:1527628593239};\\\", \\\"{x:1919,y:750,t:1527628593256};\\\", \\\"{x:1919,y:754,t:1527628593377};\\\", \\\"{x:1919,y:759,t:1527628593389};\\\", \\\"{x:1912,y:774,t:1527628593405};\\\", \\\"{x:1909,y:791,t:1527628593423};\\\", \\\"{x:1907,y:809,t:1527628593438};\\\", \\\"{x:1907,y:825,t:1527628593456};\\\", \\\"{x:1904,y:853,t:1527628593472};\\\", \\\"{x:1900,y:870,t:1527628593489};\\\", \\\"{x:1896,y:881,t:1527628593505};\\\", \\\"{x:1887,y:890,t:1527628593523};\\\", \\\"{x:1876,y:898,t:1527628593540};\\\", \\\"{x:1861,y:906,t:1527628593555};\\\", \\\"{x:1842,y:917,t:1527628593572};\\\", \\\"{x:1812,y:930,t:1527628593590};\\\", \\\"{x:1769,y:944,t:1527628593605};\\\", \\\"{x:1681,y:965,t:1527628593623};\\\", \\\"{x:1522,y:1003,t:1527628593640};\\\", \\\"{x:1407,y:1047,t:1527628593655};\\\", \\\"{x:1370,y:1062,t:1527628593673};\\\", \\\"{x:1369,y:1062,t:1527628593689};\\\", \\\"{x:1374,y:1057,t:1527628593705};\\\", \\\"{x:1382,y:1047,t:1527628593722};\\\", \\\"{x:1389,y:1035,t:1527628593739};\\\", \\\"{x:1395,y:1018,t:1527628593756};\\\", \\\"{x:1397,y:1001,t:1527628593773};\\\", \\\"{x:1400,y:991,t:1527628593790};\\\", \\\"{x:1403,y:983,t:1527628593806};\\\", \\\"{x:1406,y:976,t:1527628593822};\\\", \\\"{x:1413,y:968,t:1527628593840};\\\", \\\"{x:1424,y:955,t:1527628593856};\\\", \\\"{x:1431,y:945,t:1527628593873};\\\", \\\"{x:1437,y:939,t:1527628593890};\\\", \\\"{x:1439,y:936,t:1527628593906};\\\", \\\"{x:1445,y:930,t:1527628593923};\\\", \\\"{x:1450,y:925,t:1527628593940};\\\", \\\"{x:1455,y:919,t:1527628593957};\\\", \\\"{x:1460,y:914,t:1527628593973};\\\", \\\"{x:1466,y:906,t:1527628593990};\\\", \\\"{x:1475,y:896,t:1527628594007};\\\", \\\"{x:1478,y:893,t:1527628594023};\\\", \\\"{x:1480,y:892,t:1527628594040};\\\", \\\"{x:1481,y:890,t:1527628594057};\\\", \\\"{x:1482,y:890,t:1527628594072};\\\", \\\"{x:1488,y:886,t:1527628594090};\\\", \\\"{x:1492,y:886,t:1527628594107};\\\", \\\"{x:1493,y:886,t:1527628594123};\\\", \\\"{x:1494,y:886,t:1527628594140};\\\", \\\"{x:1495,y:886,t:1527628594156};\\\", \\\"{x:1496,y:886,t:1527628594172};\\\", \\\"{x:1497,y:886,t:1527628594190};\\\", \\\"{x:1504,y:897,t:1527628594206};\\\", \\\"{x:1515,y:912,t:1527628594222};\\\", \\\"{x:1522,y:928,t:1527628594240};\\\", \\\"{x:1527,y:945,t:1527628594257};\\\", \\\"{x:1530,y:952,t:1527628594273};\\\", \\\"{x:1530,y:957,t:1527628594290};\\\", \\\"{x:1530,y:961,t:1527628594307};\\\", \\\"{x:1530,y:962,t:1527628594561};\\\", \\\"{x:1525,y:964,t:1527628594585};\\\", \\\"{x:1521,y:966,t:1527628594593};\\\", \\\"{x:1517,y:967,t:1527628594607};\\\", \\\"{x:1514,y:969,t:1527628594623};\\\", \\\"{x:1513,y:970,t:1527628594640};\\\", \\\"{x:1506,y:972,t:1527628595082};\\\", \\\"{x:1494,y:974,t:1527628595092};\\\", \\\"{x:1467,y:977,t:1527628595107};\\\", \\\"{x:1445,y:981,t:1527628595125};\\\", \\\"{x:1430,y:986,t:1527628595141};\\\", \\\"{x:1416,y:991,t:1527628595156};\\\", \\\"{x:1397,y:999,t:1527628595174};\\\", \\\"{x:1373,y:1004,t:1527628595191};\\\", \\\"{x:1356,y:1010,t:1527628595208};\\\", \\\"{x:1352,y:1012,t:1527628595224};\\\", \\\"{x:1352,y:1010,t:1527628595409};\\\", \\\"{x:1352,y:1009,t:1527628595424};\\\", \\\"{x:1352,y:1002,t:1527628595441};\\\", \\\"{x:1352,y:999,t:1527628595457};\\\", \\\"{x:1352,y:998,t:1527628595481};\\\", \\\"{x:1352,y:995,t:1527628595491};\\\", \\\"{x:1352,y:988,t:1527628595508};\\\", \\\"{x:1352,y:983,t:1527628595524};\\\", \\\"{x:1352,y:976,t:1527628595541};\\\", \\\"{x:1352,y:969,t:1527628595558};\\\", \\\"{x:1352,y:958,t:1527628595574};\\\", \\\"{x:1352,y:948,t:1527628595591};\\\", \\\"{x:1350,y:939,t:1527628595608};\\\", \\\"{x:1349,y:929,t:1527628595624};\\\", \\\"{x:1349,y:928,t:1527628595641};\\\", \\\"{x:1350,y:927,t:1527628595761};\\\", \\\"{x:1360,y:929,t:1527628595774};\\\", \\\"{x:1377,y:930,t:1527628595791};\\\", \\\"{x:1399,y:930,t:1527628595807};\\\", \\\"{x:1417,y:932,t:1527628595825};\\\", \\\"{x:1427,y:933,t:1527628595840};\\\", \\\"{x:1441,y:934,t:1527628595857};\\\", \\\"{x:1455,y:933,t:1527628595875};\\\", \\\"{x:1460,y:932,t:1527628595890};\\\", \\\"{x:1463,y:930,t:1527628595908};\\\", \\\"{x:1468,y:928,t:1527628595925};\\\", \\\"{x:1476,y:924,t:1527628595941};\\\", \\\"{x:1486,y:920,t:1527628595958};\\\", \\\"{x:1488,y:918,t:1527628595975};\\\", \\\"{x:1486,y:921,t:1527628596090};\\\", \\\"{x:1483,y:925,t:1527628596097};\\\", \\\"{x:1480,y:931,t:1527628596108};\\\", \\\"{x:1476,y:940,t:1527628596125};\\\", \\\"{x:1476,y:949,t:1527628596142};\\\", \\\"{x:1476,y:953,t:1527628596158};\\\", \\\"{x:1475,y:958,t:1527628596175};\\\", \\\"{x:1475,y:959,t:1527628596192};\\\", \\\"{x:1475,y:960,t:1527628596208};\\\", \\\"{x:1475,y:962,t:1527628596225};\\\", \\\"{x:1475,y:963,t:1527628596242};\\\", \\\"{x:1475,y:964,t:1527628596266};\\\", \\\"{x:1476,y:965,t:1527628596282};\\\", \\\"{x:1478,y:965,t:1527628596292};\\\", \\\"{x:1481,y:967,t:1527628596308};\\\", \\\"{x:1485,y:967,t:1527628596324};\\\", \\\"{x:1489,y:969,t:1527628596342};\\\", \\\"{x:1492,y:969,t:1527628596358};\\\", \\\"{x:1496,y:970,t:1527628596375};\\\", \\\"{x:1499,y:971,t:1527628596392};\\\", \\\"{x:1501,y:972,t:1527628596407};\\\", \\\"{x:1505,y:974,t:1527628596425};\\\", \\\"{x:1503,y:974,t:1527628596673};\\\", \\\"{x:1500,y:974,t:1527628596681};\\\", \\\"{x:1496,y:972,t:1527628596691};\\\", \\\"{x:1484,y:967,t:1527628596709};\\\", \\\"{x:1478,y:965,t:1527628596725};\\\", \\\"{x:1477,y:964,t:1527628596741};\\\", \\\"{x:1476,y:964,t:1527628596793};\\\", \\\"{x:1474,y:968,t:1527628596808};\\\", \\\"{x:1474,y:972,t:1527628596825};\\\", \\\"{x:1477,y:974,t:1527628596842};\\\", \\\"{x:1477,y:975,t:1527628596921};\\\", \\\"{x:1477,y:977,t:1527628596929};\\\", \\\"{x:1477,y:979,t:1527628596942};\\\", \\\"{x:1477,y:981,t:1527628596958};\\\", \\\"{x:1478,y:984,t:1527628596976};\\\", \\\"{x:1479,y:984,t:1527628597258};\\\", \\\"{x:1481,y:983,t:1527628597276};\\\", \\\"{x:1481,y:982,t:1527628597292};\\\", \\\"{x:1481,y:980,t:1527628597309};\\\", \\\"{x:1481,y:979,t:1527628597326};\\\", \\\"{x:1481,y:978,t:1527628597343};\\\", \\\"{x:1481,y:977,t:1527628597369};\\\", \\\"{x:1481,y:976,t:1527628597377};\\\", \\\"{x:1481,y:973,t:1527628597394};\\\", \\\"{x:1481,y:972,t:1527628597409};\\\", \\\"{x:1482,y:969,t:1527628597426};\\\", \\\"{x:1482,y:965,t:1527628597443};\\\", \\\"{x:1482,y:958,t:1527628597459};\\\", \\\"{x:1482,y:948,t:1527628597480};\\\", \\\"{x:1479,y:938,t:1527628597497};\\\", \\\"{x:1477,y:929,t:1527628597513};\\\", \\\"{x:1474,y:917,t:1527628597531};\\\", \\\"{x:1468,y:905,t:1527628597547};\\\", \\\"{x:1466,y:899,t:1527628597563};\\\", \\\"{x:1465,y:895,t:1527628597580};\\\", \\\"{x:1463,y:889,t:1527628597597};\\\", \\\"{x:1463,y:886,t:1527628597613};\\\", \\\"{x:1460,y:880,t:1527628597630};\\\", \\\"{x:1457,y:874,t:1527628597647};\\\", \\\"{x:1456,y:868,t:1527628597664};\\\", \\\"{x:1455,y:862,t:1527628597681};\\\", \\\"{x:1454,y:857,t:1527628597697};\\\", \\\"{x:1454,y:852,t:1527628597714};\\\", \\\"{x:1453,y:847,t:1527628597731};\\\", \\\"{x:1453,y:843,t:1527628597747};\\\", \\\"{x:1453,y:840,t:1527628597763};\\\", \\\"{x:1453,y:837,t:1527628597780};\\\", \\\"{x:1454,y:830,t:1527628597798};\\\", \\\"{x:1455,y:825,t:1527628597813};\\\", \\\"{x:1457,y:820,t:1527628597830};\\\", \\\"{x:1459,y:816,t:1527628597847};\\\", \\\"{x:1462,y:813,t:1527628597864};\\\", \\\"{x:1464,y:809,t:1527628597880};\\\", \\\"{x:1465,y:807,t:1527628597897};\\\", \\\"{x:1466,y:806,t:1527628597916};\\\", \\\"{x:1467,y:805,t:1527628597981};\\\", \\\"{x:1468,y:804,t:1527628597997};\\\", \\\"{x:1472,y:804,t:1527628598014};\\\", \\\"{x:1480,y:813,t:1527628598030};\\\", \\\"{x:1485,y:824,t:1527628598047};\\\", \\\"{x:1489,y:833,t:1527628598064};\\\", \\\"{x:1490,y:838,t:1527628598080};\\\", \\\"{x:1490,y:845,t:1527628598097};\\\", \\\"{x:1490,y:847,t:1527628598115};\\\", \\\"{x:1490,y:848,t:1527628598130};\\\", \\\"{x:1490,y:846,t:1527628598333};\\\", \\\"{x:1490,y:845,t:1527628598349};\\\", \\\"{x:1490,y:843,t:1527628598373};\\\", \\\"{x:1490,y:842,t:1527628598380};\\\", \\\"{x:1490,y:841,t:1527628598397};\\\", \\\"{x:1490,y:840,t:1527628598414};\\\", \\\"{x:1490,y:839,t:1527628598431};\\\", \\\"{x:1490,y:837,t:1527628598447};\\\", \\\"{x:1490,y:835,t:1527628598468};\\\", \\\"{x:1489,y:833,t:1527628598484};\\\", \\\"{x:1489,y:832,t:1527628598497};\\\", \\\"{x:1487,y:829,t:1527628598514};\\\", \\\"{x:1486,y:828,t:1527628598532};\\\", \\\"{x:1485,y:827,t:1527628598547};\\\", \\\"{x:1484,y:826,t:1527628598573};\\\", \\\"{x:1483,y:825,t:1527628598604};\\\", \\\"{x:1482,y:825,t:1527628598661};\\\", \\\"{x:1481,y:825,t:1527628598701};\\\", \\\"{x:1480,y:825,t:1527628598749};\\\", \\\"{x:1478,y:825,t:1527628598789};\\\", \\\"{x:1477,y:826,t:1527628598805};\\\", \\\"{x:1478,y:826,t:1527628599773};\\\", \\\"{x:1478,y:827,t:1527628599781};\\\", \\\"{x:1478,y:829,t:1527628599798};\\\", \\\"{x:1478,y:830,t:1527628599837};\\\", \\\"{x:1478,y:829,t:1527628600124};\\\", \\\"{x:1478,y:830,t:1527628600581};\\\", \\\"{x:1478,y:834,t:1527628600589};\\\", \\\"{x:1478,y:837,t:1527628600600};\\\", \\\"{x:1478,y:846,t:1527628600616};\\\", \\\"{x:1479,y:856,t:1527628600632};\\\", \\\"{x:1479,y:866,t:1527628600649};\\\", \\\"{x:1482,y:876,t:1527628600666};\\\", \\\"{x:1483,y:883,t:1527628600682};\\\", \\\"{x:1483,y:889,t:1527628600699};\\\", \\\"{x:1486,y:894,t:1527628600716};\\\", \\\"{x:1486,y:897,t:1527628600732};\\\", \\\"{x:1486,y:899,t:1527628600749};\\\", \\\"{x:1487,y:900,t:1527628600766};\\\", \\\"{x:1487,y:899,t:1527628601389};\\\", \\\"{x:1487,y:898,t:1527628601404};\\\", \\\"{x:1487,y:897,t:1527628601453};\\\", \\\"{x:1487,y:896,t:1527628601636};\\\", \\\"{x:1487,y:895,t:1527628601668};\\\", \\\"{x:1486,y:895,t:1527628601764};\\\", \\\"{x:1485,y:895,t:1527628602125};\\\", \\\"{x:1485,y:896,t:1527628602357};\\\", \\\"{x:1485,y:897,t:1527628602367};\\\", \\\"{x:1485,y:898,t:1527628602389};\\\", \\\"{x:1485,y:899,t:1527628602421};\\\", \\\"{x:1485,y:900,t:1527628602445};\\\", \\\"{x:1485,y:897,t:1527628605037};\\\", \\\"{x:1485,y:896,t:1527628605052};\\\", \\\"{x:1485,y:890,t:1527628605069};\\\", \\\"{x:1485,y:889,t:1527628605086};\\\", \\\"{x:1485,y:887,t:1527628605102};\\\", \\\"{x:1485,y:886,t:1527628605157};\\\", \\\"{x:1485,y:885,t:1527628605173};\\\", \\\"{x:1485,y:884,t:1527628605188};\\\", \\\"{x:1484,y:884,t:1527628605203};\\\", \\\"{x:1483,y:883,t:1527628605219};\\\", \\\"{x:1483,y:882,t:1527628605244};\\\", \\\"{x:1483,y:881,t:1527628605252};\\\", \\\"{x:1483,y:879,t:1527628605285};\\\", \\\"{x:1483,y:877,t:1527628605293};\\\", \\\"{x:1482,y:874,t:1527628605303};\\\", \\\"{x:1481,y:871,t:1527628605319};\\\", \\\"{x:1481,y:869,t:1527628605335};\\\", \\\"{x:1480,y:867,t:1527628605353};\\\", \\\"{x:1479,y:866,t:1527628605372};\\\", \\\"{x:1479,y:865,t:1527628605388};\\\", \\\"{x:1479,y:864,t:1527628605403};\\\", \\\"{x:1478,y:862,t:1527628605419};\\\", \\\"{x:1478,y:861,t:1527628605436};\\\", \\\"{x:1478,y:860,t:1527628605461};\\\", \\\"{x:1478,y:859,t:1527628605476};\\\", \\\"{x:1478,y:858,t:1527628605486};\\\", \\\"{x:1478,y:857,t:1527628605503};\\\", \\\"{x:1478,y:856,t:1527628605519};\\\", \\\"{x:1478,y:855,t:1527628605536};\\\", \\\"{x:1478,y:854,t:1527628605557};\\\", \\\"{x:1478,y:853,t:1527628605572};\\\", \\\"{x:1478,y:852,t:1527628605586};\\\", \\\"{x:1478,y:851,t:1527628605603};\\\", \\\"{x:1478,y:850,t:1527628605620};\\\", \\\"{x:1478,y:849,t:1527628605636};\\\", \\\"{x:1478,y:847,t:1527628605653};\\\", \\\"{x:1478,y:846,t:1527628605670};\\\", \\\"{x:1478,y:844,t:1527628605686};\\\", \\\"{x:1478,y:843,t:1527628605703};\\\", \\\"{x:1478,y:842,t:1527628605720};\\\", \\\"{x:1478,y:840,t:1527628605736};\\\", \\\"{x:1478,y:839,t:1527628605753};\\\", \\\"{x:1478,y:838,t:1527628605770};\\\", \\\"{x:1478,y:837,t:1527628605786};\\\", \\\"{x:1478,y:835,t:1527628606101};\\\", \\\"{x:1479,y:833,t:1527628606117};\\\", \\\"{x:1479,y:831,t:1527628606156};\\\", \\\"{x:1479,y:830,t:1527628606196};\\\", \\\"{x:1479,y:828,t:1527628606285};\\\", \\\"{x:1479,y:827,t:1527628606381};\\\", \\\"{x:1479,y:825,t:1527628606428};\\\", \\\"{x:1480,y:823,t:1527628606453};\\\", \\\"{x:1480,y:822,t:1527628606476};\\\", \\\"{x:1480,y:821,t:1527628606516};\\\", \\\"{x:1480,y:820,t:1527628606524};\\\", \\\"{x:1480,y:819,t:1527628606537};\\\", \\\"{x:1480,y:818,t:1527628606556};\\\", \\\"{x:1480,y:817,t:1527628606580};\\\", \\\"{x:1480,y:816,t:1527628606588};\\\", \\\"{x:1480,y:815,t:1527628606613};\\\", \\\"{x:1480,y:814,t:1527628606620};\\\", \\\"{x:1480,y:812,t:1527628606645};\\\", \\\"{x:1480,y:811,t:1527628606660};\\\", \\\"{x:1480,y:810,t:1527628606670};\\\", \\\"{x:1479,y:809,t:1527628606687};\\\", \\\"{x:1479,y:808,t:1527628606708};\\\", \\\"{x:1479,y:807,t:1527628606724};\\\", \\\"{x:1479,y:806,t:1527628606765};\\\", \\\"{x:1479,y:805,t:1527628606788};\\\", \\\"{x:1479,y:804,t:1527628606828};\\\", \\\"{x:1478,y:804,t:1527628606845};\\\", \\\"{x:1478,y:803,t:1527628606892};\\\", \\\"{x:1478,y:802,t:1527628606924};\\\", \\\"{x:1478,y:801,t:1527628606980};\\\", \\\"{x:1478,y:800,t:1527628607060};\\\", \\\"{x:1478,y:798,t:1527628607071};\\\", \\\"{x:1478,y:797,t:1527628607087};\\\", \\\"{x:1478,y:795,t:1527628607105};\\\", \\\"{x:1478,y:794,t:1527628607122};\\\", \\\"{x:1478,y:793,t:1527628607138};\\\", \\\"{x:1478,y:792,t:1527628607154};\\\", \\\"{x:1478,y:791,t:1527628607171};\\\", \\\"{x:1478,y:790,t:1527628607244};\\\", \\\"{x:1478,y:789,t:1527628607261};\\\", \\\"{x:1478,y:788,t:1527628607276};\\\", \\\"{x:1478,y:787,t:1527628607300};\\\", \\\"{x:1478,y:786,t:1527628607316};\\\", \\\"{x:1478,y:785,t:1527628607324};\\\", \\\"{x:1478,y:784,t:1527628607348};\\\", \\\"{x:1478,y:782,t:1527628607356};\\\", \\\"{x:1478,y:781,t:1527628607372};\\\", \\\"{x:1478,y:779,t:1527628607388};\\\", \\\"{x:1478,y:777,t:1527628607404};\\\", \\\"{x:1478,y:774,t:1527628607421};\\\", \\\"{x:1478,y:770,t:1527628607438};\\\", \\\"{x:1478,y:768,t:1527628607454};\\\", \\\"{x:1478,y:766,t:1527628607471};\\\", \\\"{x:1478,y:764,t:1527628607488};\\\", \\\"{x:1478,y:762,t:1527628607504};\\\", \\\"{x:1478,y:761,t:1527628607521};\\\", \\\"{x:1478,y:759,t:1527628607538};\\\", \\\"{x:1478,y:758,t:1527628607554};\\\", \\\"{x:1478,y:757,t:1527628607571};\\\", \\\"{x:1478,y:756,t:1527628607588};\\\", \\\"{x:1478,y:755,t:1527628607604};\\\", \\\"{x:1478,y:753,t:1527628607621};\\\", \\\"{x:1478,y:752,t:1527628607653};\\\", \\\"{x:1478,y:751,t:1527628607660};\\\", \\\"{x:1478,y:750,t:1527628607671};\\\", \\\"{x:1478,y:749,t:1527628607689};\\\", \\\"{x:1478,y:747,t:1527628607704};\\\", \\\"{x:1478,y:745,t:1527628607721};\\\", \\\"{x:1478,y:744,t:1527628607738};\\\", \\\"{x:1478,y:742,t:1527628607754};\\\", \\\"{x:1478,y:741,t:1527628607772};\\\", \\\"{x:1478,y:739,t:1527628607789};\\\", \\\"{x:1478,y:738,t:1527628607804};\\\", \\\"{x:1478,y:736,t:1527628607821};\\\", \\\"{x:1478,y:733,t:1527628607838};\\\", \\\"{x:1478,y:731,t:1527628607855};\\\", \\\"{x:1478,y:728,t:1527628607871};\\\", \\\"{x:1478,y:725,t:1527628607888};\\\", \\\"{x:1478,y:723,t:1527628607905};\\\", \\\"{x:1478,y:720,t:1527628607921};\\\", \\\"{x:1478,y:718,t:1527628607938};\\\", \\\"{x:1478,y:716,t:1527628607955};\\\", \\\"{x:1478,y:712,t:1527628607971};\\\", \\\"{x:1478,y:709,t:1527628607988};\\\", \\\"{x:1478,y:702,t:1527628608005};\\\", \\\"{x:1478,y:698,t:1527628608021};\\\", \\\"{x:1478,y:693,t:1527628608038};\\\", \\\"{x:1478,y:688,t:1527628608055};\\\", \\\"{x:1478,y:684,t:1527628608071};\\\", \\\"{x:1478,y:680,t:1527628608088};\\\", \\\"{x:1478,y:676,t:1527628608105};\\\", \\\"{x:1478,y:672,t:1527628608122};\\\", \\\"{x:1478,y:670,t:1527628608138};\\\", \\\"{x:1478,y:666,t:1527628608155};\\\", \\\"{x:1478,y:664,t:1527628608171};\\\", \\\"{x:1478,y:659,t:1527628608188};\\\", \\\"{x:1478,y:655,t:1527628608205};\\\", \\\"{x:1478,y:649,t:1527628608222};\\\", \\\"{x:1478,y:647,t:1527628608238};\\\", \\\"{x:1478,y:645,t:1527628608256};\\\", \\\"{x:1478,y:642,t:1527628608272};\\\", \\\"{x:1478,y:637,t:1527628608288};\\\", \\\"{x:1478,y:631,t:1527628608305};\\\", \\\"{x:1478,y:628,t:1527628608322};\\\", \\\"{x:1478,y:624,t:1527628608339};\\\", \\\"{x:1478,y:621,t:1527628608355};\\\", \\\"{x:1478,y:620,t:1527628608372};\\\", \\\"{x:1478,y:618,t:1527628608388};\\\", \\\"{x:1478,y:617,t:1527628608406};\\\", \\\"{x:1478,y:614,t:1527628608422};\\\", \\\"{x:1478,y:613,t:1527628608439};\\\", \\\"{x:1478,y:611,t:1527628608455};\\\", \\\"{x:1478,y:607,t:1527628608473};\\\", \\\"{x:1478,y:600,t:1527628608488};\\\", \\\"{x:1478,y:593,t:1527628608505};\\\", \\\"{x:1478,y:587,t:1527628608523};\\\", \\\"{x:1478,y:581,t:1527628608538};\\\", \\\"{x:1478,y:575,t:1527628608555};\\\", \\\"{x:1478,y:569,t:1527628608572};\\\", \\\"{x:1478,y:562,t:1527628608588};\\\", \\\"{x:1478,y:558,t:1527628608605};\\\", \\\"{x:1478,y:552,t:1527628608622};\\\", \\\"{x:1478,y:548,t:1527628608639};\\\", \\\"{x:1478,y:546,t:1527628608655};\\\", \\\"{x:1478,y:543,t:1527628608672};\\\", \\\"{x:1478,y:541,t:1527628608689};\\\", \\\"{x:1478,y:537,t:1527628608705};\\\", \\\"{x:1478,y:536,t:1527628608722};\\\", \\\"{x:1478,y:534,t:1527628608739};\\\", \\\"{x:1478,y:531,t:1527628608755};\\\", \\\"{x:1478,y:529,t:1527628608772};\\\", \\\"{x:1478,y:527,t:1527628608789};\\\", \\\"{x:1477,y:529,t:1527628609013};\\\", \\\"{x:1476,y:532,t:1527628609022};\\\", \\\"{x:1475,y:536,t:1527628609039};\\\", \\\"{x:1474,y:540,t:1527628609055};\\\", \\\"{x:1472,y:544,t:1527628609073};\\\", \\\"{x:1472,y:547,t:1527628609089};\\\", \\\"{x:1472,y:551,t:1527628609107};\\\", \\\"{x:1471,y:553,t:1527628609123};\\\", \\\"{x:1471,y:560,t:1527628609140};\\\", \\\"{x:1471,y:569,t:1527628609157};\\\", \\\"{x:1472,y:575,t:1527628609173};\\\", \\\"{x:1472,y:577,t:1527628609190};\\\", \\\"{x:1472,y:579,t:1527628609206};\\\", \\\"{x:1473,y:580,t:1527628609222};\\\", \\\"{x:1473,y:582,t:1527628609244};\\\", \\\"{x:1474,y:583,t:1527628609256};\\\", \\\"{x:1474,y:585,t:1527628609272};\\\", \\\"{x:1474,y:587,t:1527628609289};\\\", \\\"{x:1476,y:590,t:1527628609306};\\\", \\\"{x:1476,y:593,t:1527628609322};\\\", \\\"{x:1477,y:595,t:1527628609339};\\\", \\\"{x:1478,y:600,t:1527628609356};\\\", \\\"{x:1478,y:604,t:1527628609372};\\\", \\\"{x:1479,y:607,t:1527628609389};\\\", \\\"{x:1479,y:609,t:1527628609406};\\\", \\\"{x:1479,y:611,t:1527628609422};\\\", \\\"{x:1479,y:613,t:1527628609439};\\\", \\\"{x:1479,y:615,t:1527628609456};\\\", \\\"{x:1479,y:616,t:1527628609472};\\\", \\\"{x:1479,y:617,t:1527628609489};\\\", \\\"{x:1479,y:620,t:1527628609506};\\\", \\\"{x:1479,y:621,t:1527628609524};\\\", \\\"{x:1479,y:622,t:1527628609540};\\\", \\\"{x:1479,y:623,t:1527628609605};\\\", \\\"{x:1479,y:624,t:1527628609652};\\\", \\\"{x:1479,y:625,t:1527628609692};\\\", \\\"{x:1479,y:626,t:1527628609706};\\\", \\\"{x:1478,y:627,t:1527628609732};\\\", \\\"{x:1478,y:628,t:1527628609757};\\\", \\\"{x:1478,y:629,t:1527628609773};\\\", \\\"{x:1459,y:629,t:1527628615541};\\\", \\\"{x:1409,y:616,t:1527628615548};\\\", \\\"{x:1342,y:596,t:1527628615560};\\\", \\\"{x:1162,y:567,t:1527628615577};\\\", \\\"{x:938,y:560,t:1527628615595};\\\", \\\"{x:635,y:560,t:1527628615611};\\\", \\\"{x:382,y:529,t:1527628615628};\\\", \\\"{x:278,y:505,t:1527628615644};\\\", \\\"{x:227,y:496,t:1527628615662};\\\", \\\"{x:206,y:493,t:1527628615679};\\\", \\\"{x:189,y:490,t:1527628615694};\\\", \\\"{x:181,y:490,t:1527628615711};\\\", \\\"{x:177,y:489,t:1527628615729};\\\", \\\"{x:175,y:488,t:1527628615746};\\\", \\\"{x:174,y:487,t:1527628615780};\\\", \\\"{x:177,y:485,t:1527628615892};\\\", \\\"{x:182,y:485,t:1527628615900};\\\", \\\"{x:197,y:485,t:1527628615912};\\\", \\\"{x:241,y:485,t:1527628615928};\\\", \\\"{x:319,y:495,t:1527628615945};\\\", \\\"{x:407,y:507,t:1527628615963};\\\", \\\"{x:502,y:522,t:1527628615979};\\\", \\\"{x:569,y:532,t:1527628615994};\\\", \\\"{x:619,y:538,t:1527628616011};\\\", \\\"{x:683,y:543,t:1527628616028};\\\", \\\"{x:710,y:543,t:1527628616045};\\\", \\\"{x:734,y:543,t:1527628616061};\\\", \\\"{x:744,y:541,t:1527628616078};\\\", \\\"{x:744,y:540,t:1527628616095};\\\", \\\"{x:745,y:540,t:1527628616111};\\\", \\\"{x:745,y:539,t:1527628616132};\\\", \\\"{x:745,y:538,t:1527628616146};\\\", \\\"{x:744,y:538,t:1527628616181};\\\", \\\"{x:739,y:538,t:1527628616196};\\\", \\\"{x:720,y:538,t:1527628616211};\\\", \\\"{x:693,y:535,t:1527628616228};\\\", \\\"{x:683,y:531,t:1527628616246};\\\", \\\"{x:676,y:527,t:1527628616261};\\\", \\\"{x:672,y:524,t:1527628616278};\\\", \\\"{x:669,y:522,t:1527628616296};\\\", \\\"{x:666,y:519,t:1527628616311};\\\", \\\"{x:665,y:518,t:1527628616328};\\\", \\\"{x:663,y:517,t:1527628616345};\\\", \\\"{x:662,y:516,t:1527628616361};\\\", \\\"{x:657,y:513,t:1527628616379};\\\", \\\"{x:651,y:509,t:1527628616395};\\\", \\\"{x:649,y:509,t:1527628616412};\\\", \\\"{x:647,y:507,t:1527628616429};\\\", \\\"{x:646,y:507,t:1527628616446};\\\", \\\"{x:645,y:507,t:1527628617300};\\\", \\\"{x:644,y:507,t:1527628617312};\\\", \\\"{x:643,y:507,t:1527628617330};\\\", \\\"{x:642,y:507,t:1527628617345};\\\", \\\"{x:640,y:507,t:1527628617362};\\\", \\\"{x:638,y:507,t:1527628617380};\\\", \\\"{x:637,y:507,t:1527628617396};\\\", \\\"{x:637,y:508,t:1527628617428};\\\", \\\"{x:635,y:508,t:1527628617484};\\\", \\\"{x:634,y:508,t:1527628617540};\\\", \\\"{x:634,y:509,t:1527628617580};\\\", \\\"{x:633,y:509,t:1527628617604};\\\", \\\"{x:632,y:509,t:1527628617620};\\\", \\\"{x:631,y:510,t:1527628617629};\\\", \\\"{x:630,y:511,t:1527628617647};\\\", \\\"{x:629,y:511,t:1527628617664};\\\", \\\"{x:626,y:513,t:1527628617679};\\\", \\\"{x:625,y:513,t:1527628617697};\\\", \\\"{x:624,y:513,t:1527628617714};\\\", \\\"{x:623,y:514,t:1527628617729};\\\", \\\"{x:621,y:514,t:1527628617746};\\\", \\\"{x:618,y:516,t:1527628617763};\\\", \\\"{x:616,y:516,t:1527628617779};\\\", \\\"{x:615,y:519,t:1527628618132};\\\", \\\"{x:617,y:523,t:1527628618146};\\\", \\\"{x:677,y:541,t:1527628618164};\\\", \\\"{x:852,y:593,t:1527628618180};\\\", \\\"{x:987,y:630,t:1527628618197};\\\", \\\"{x:1107,y:670,t:1527628618213};\\\", \\\"{x:1219,y:713,t:1527628618230};\\\", \\\"{x:1299,y:748,t:1527628618247};\\\", \\\"{x:1339,y:767,t:1527628618263};\\\", \\\"{x:1343,y:769,t:1527628618280};\\\", \\\"{x:1344,y:769,t:1527628618396};\\\", \\\"{x:1345,y:769,t:1527628618414};\\\", \\\"{x:1346,y:769,t:1527628618431};\\\", \\\"{x:1346,y:764,t:1527628618452};\\\", \\\"{x:1346,y:760,t:1527628618463};\\\", \\\"{x:1346,y:751,t:1527628618481};\\\", \\\"{x:1343,y:734,t:1527628618498};\\\", \\\"{x:1336,y:714,t:1527628618513};\\\", \\\"{x:1332,y:699,t:1527628618530};\\\", \\\"{x:1328,y:688,t:1527628618548};\\\", \\\"{x:1325,y:679,t:1527628618564};\\\", \\\"{x:1324,y:675,t:1527628618580};\\\", \\\"{x:1323,y:673,t:1527628618597};\\\", \\\"{x:1324,y:673,t:1527628618740};\\\", \\\"{x:1330,y:673,t:1527628618748};\\\", \\\"{x:1335,y:678,t:1527628618764};\\\", \\\"{x:1354,y:698,t:1527628618780};\\\", \\\"{x:1366,y:712,t:1527628618797};\\\", \\\"{x:1373,y:723,t:1527628618814};\\\", \\\"{x:1376,y:729,t:1527628618831};\\\", \\\"{x:1378,y:733,t:1527628618848};\\\", \\\"{x:1379,y:734,t:1527628618864};\\\", \\\"{x:1379,y:735,t:1527628618884};\\\", \\\"{x:1377,y:735,t:1527628618980};\\\", \\\"{x:1372,y:734,t:1527628618997};\\\", \\\"{x:1365,y:731,t:1527628619015};\\\", \\\"{x:1360,y:728,t:1527628619031};\\\", \\\"{x:1357,y:728,t:1527628619047};\\\", \\\"{x:1354,y:726,t:1527628619065};\\\", \\\"{x:1351,y:724,t:1527628619081};\\\", \\\"{x:1350,y:723,t:1527628619098};\\\", \\\"{x:1349,y:723,t:1527628619114};\\\", \\\"{x:1347,y:722,t:1527628619131};\\\", \\\"{x:1347,y:721,t:1527628619452};\\\", \\\"{x:1347,y:717,t:1527628619549};\\\", \\\"{x:1346,y:710,t:1527628619564};\\\", \\\"{x:1346,y:705,t:1527628619582};\\\", \\\"{x:1346,y:697,t:1527628619598};\\\", \\\"{x:1346,y:685,t:1527628619614};\\\", \\\"{x:1346,y:675,t:1527628619632};\\\", \\\"{x:1346,y:670,t:1527628619647};\\\", \\\"{x:1346,y:669,t:1527628619668};\\\", \\\"{x:1345,y:669,t:1527628619780};\\\", \\\"{x:1342,y:672,t:1527628619788};\\\", \\\"{x:1333,y:681,t:1527628619798};\\\", \\\"{x:1310,y:706,t:1527628619814};\\\", \\\"{x:1269,y:732,t:1527628619832};\\\", \\\"{x:1226,y:755,t:1527628619847};\\\", \\\"{x:1182,y:771,t:1527628619864};\\\", \\\"{x:1135,y:779,t:1527628619882};\\\", \\\"{x:1103,y:779,t:1527628619899};\\\", \\\"{x:1053,y:772,t:1527628619915};\\\", \\\"{x:985,y:745,t:1527628619931};\\\", \\\"{x:869,y:688,t:1527628619948};\\\", \\\"{x:773,y:628,t:1527628619965};\\\", \\\"{x:676,y:569,t:1527628619982};\\\", \\\"{x:575,y:507,t:1527628619999};\\\", \\\"{x:485,y:457,t:1527628620015};\\\", \\\"{x:425,y:412,t:1527628620032};\\\", \\\"{x:391,y:381,t:1527628620049};\\\", \\\"{x:381,y:370,t:1527628620065};\\\", \\\"{x:378,y:366,t:1527628620082};\\\", \\\"{x:377,y:364,t:1527628620098};\\\", \\\"{x:377,y:363,t:1527628620114};\\\", \\\"{x:376,y:360,t:1527628620132};\\\", \\\"{x:375,y:358,t:1527628620148};\\\", \\\"{x:375,y:354,t:1527628620164};\\\", \\\"{x:380,y:352,t:1527628620181};\\\", \\\"{x:389,y:348,t:1527628620198};\\\", \\\"{x:393,y:345,t:1527628620215};\\\", \\\"{x:395,y:345,t:1527628620232};\\\", \\\"{x:399,y:346,t:1527628620249};\\\", \\\"{x:403,y:353,t:1527628620265};\\\", \\\"{x:411,y:367,t:1527628620281};\\\", \\\"{x:420,y:381,t:1527628620298};\\\", \\\"{x:431,y:397,t:1527628620314};\\\", \\\"{x:441,y:419,t:1527628620332};\\\", \\\"{x:458,y:456,t:1527628620348};\\\", \\\"{x:476,y:484,t:1527628620365};\\\", \\\"{x:487,y:499,t:1527628620382};\\\", \\\"{x:496,y:507,t:1527628620399};\\\", \\\"{x:501,y:511,t:1527628620416};\\\", \\\"{x:505,y:514,t:1527628620432};\\\", \\\"{x:507,y:516,t:1527628620449};\\\", \\\"{x:509,y:518,t:1527628620466};\\\", \\\"{x:512,y:520,t:1527628620481};\\\", \\\"{x:513,y:521,t:1527628620498};\\\", \\\"{x:515,y:522,t:1527628620515};\\\", \\\"{x:518,y:525,t:1527628620532};\\\", \\\"{x:525,y:529,t:1527628620548};\\\", \\\"{x:533,y:532,t:1527628620566};\\\", \\\"{x:537,y:534,t:1527628620583};\\\", \\\"{x:540,y:535,t:1527628620598};\\\", \\\"{x:541,y:535,t:1527628620616};\\\", \\\"{x:542,y:535,t:1527628620632};\\\", \\\"{x:543,y:535,t:1527628620660};\\\", \\\"{x:544,y:535,t:1527628620668};\\\", \\\"{x:545,y:535,t:1527628620683};\\\", \\\"{x:548,y:537,t:1527628620699};\\\", \\\"{x:551,y:540,t:1527628620716};\\\", \\\"{x:553,y:543,t:1527628620732};\\\", \\\"{x:554,y:543,t:1527628620812};\\\", \\\"{x:554,y:544,t:1527628620932};\\\", \\\"{x:554,y:545,t:1527628620948};\\\", \\\"{x:558,y:550,t:1527628620964};\\\", \\\"{x:567,y:556,t:1527628620980};\\\", \\\"{x:578,y:565,t:1527628620998};\\\", \\\"{x:586,y:571,t:1527628621014};\\\", \\\"{x:596,y:577,t:1527628621031};\\\", \\\"{x:598,y:579,t:1527628621050};\\\", \\\"{x:600,y:579,t:1527628621065};\\\", \\\"{x:602,y:580,t:1527628621083};\\\", \\\"{x:603,y:581,t:1527628621124};\\\", \\\"{x:602,y:581,t:1527628621229};\\\", \\\"{x:601,y:581,t:1527628621268};\\\", \\\"{x:600,y:581,t:1527628621284};\\\", \\\"{x:598,y:581,t:1527628621308};\\\", \\\"{x:596,y:580,t:1527628621316};\\\", \\\"{x:590,y:580,t:1527628621332};\\\", \\\"{x:585,y:578,t:1527628621350};\\\", \\\"{x:576,y:577,t:1527628621365};\\\", \\\"{x:566,y:575,t:1527628621383};\\\", \\\"{x:552,y:571,t:1527628621399};\\\", \\\"{x:535,y:567,t:1527628621417};\\\", \\\"{x:514,y:565,t:1527628621432};\\\", \\\"{x:492,y:561,t:1527628621450};\\\", \\\"{x:470,y:559,t:1527628621467};\\\", \\\"{x:451,y:556,t:1527628621483};\\\", \\\"{x:438,y:554,t:1527628621500};\\\", \\\"{x:422,y:551,t:1527628621516};\\\", \\\"{x:417,y:551,t:1527628621533};\\\", \\\"{x:414,y:551,t:1527628621549};\\\", \\\"{x:413,y:551,t:1527628621567};\\\", \\\"{x:412,y:551,t:1527628621612};\\\", \\\"{x:411,y:552,t:1527628621701};\\\", \\\"{x:410,y:552,t:1527628621716};\\\", \\\"{x:410,y:553,t:1527628621733};\\\", \\\"{x:410,y:554,t:1527628621772};\\\", \\\"{x:410,y:555,t:1527628621782};\\\", \\\"{x:410,y:556,t:1527628621800};\\\", \\\"{x:410,y:559,t:1527628621816};\\\", \\\"{x:410,y:561,t:1527628621833};\\\", \\\"{x:410,y:562,t:1527628621850};\\\", \\\"{x:410,y:563,t:1527628621866};\\\", \\\"{x:413,y:563,t:1527628621932};\\\", \\\"{x:417,y:563,t:1527628621940};\\\", \\\"{x:422,y:563,t:1527628621950};\\\", \\\"{x:439,y:563,t:1527628621967};\\\", \\\"{x:456,y:560,t:1527628621983};\\\", \\\"{x:469,y:556,t:1527628621999};\\\", \\\"{x:479,y:553,t:1527628622016};\\\", \\\"{x:488,y:550,t:1527628622034};\\\", \\\"{x:499,y:548,t:1527628622050};\\\", \\\"{x:511,y:547,t:1527628622067};\\\", \\\"{x:522,y:544,t:1527628622084};\\\", \\\"{x:525,y:543,t:1527628622099};\\\", \\\"{x:527,y:543,t:1527628622116};\\\", \\\"{x:530,y:543,t:1527628622133};\\\", \\\"{x:534,y:543,t:1527628622149};\\\", \\\"{x:539,y:543,t:1527628622166};\\\", \\\"{x:545,y:543,t:1527628622183};\\\", \\\"{x:550,y:543,t:1527628622200};\\\", \\\"{x:555,y:542,t:1527628622217};\\\", \\\"{x:561,y:540,t:1527628622234};\\\", \\\"{x:579,y:535,t:1527628622250};\\\", \\\"{x:604,y:529,t:1527628622267};\\\", \\\"{x:630,y:522,t:1527628622283};\\\", \\\"{x:670,y:512,t:1527628622300};\\\", \\\"{x:687,y:506,t:1527628622316};\\\", \\\"{x:697,y:503,t:1527628622333};\\\", \\\"{x:706,y:501,t:1527628622350};\\\", \\\"{x:720,y:500,t:1527628622367};\\\", \\\"{x:740,y:500,t:1527628622384};\\\", \\\"{x:758,y:500,t:1527628622400};\\\", \\\"{x:771,y:500,t:1527628622416};\\\", \\\"{x:779,y:500,t:1527628622433};\\\", \\\"{x:790,y:500,t:1527628622450};\\\", \\\"{x:796,y:500,t:1527628622467};\\\", \\\"{x:801,y:500,t:1527628622483};\\\", \\\"{x:804,y:500,t:1527628622500};\\\", \\\"{x:806,y:500,t:1527628622517};\\\", \\\"{x:808,y:501,t:1527628622534};\\\", \\\"{x:811,y:502,t:1527628622551};\\\", \\\"{x:812,y:503,t:1527628622566};\\\", \\\"{x:813,y:504,t:1527628622612};\\\", \\\"{x:814,y:504,t:1527628622620};\\\", \\\"{x:821,y:508,t:1527628622633};\\\", \\\"{x:830,y:512,t:1527628622651};\\\", \\\"{x:835,y:513,t:1527628622667};\\\", \\\"{x:841,y:518,t:1527628623204};\\\", \\\"{x:853,y:533,t:1527628623219};\\\", \\\"{x:900,y:584,t:1527628623235};\\\", \\\"{x:969,y:643,t:1527628623251};\\\", \\\"{x:1065,y:702,t:1527628623267};\\\", \\\"{x:1211,y:773,t:1527628623284};\\\", \\\"{x:1313,y:814,t:1527628623301};\\\", \\\"{x:1407,y:841,t:1527628623317};\\\", \\\"{x:1483,y:867,t:1527628623335};\\\", \\\"{x:1516,y:876,t:1527628623351};\\\", \\\"{x:1521,y:877,t:1527628623367};\\\", \\\"{x:1521,y:876,t:1527628623541};\\\", \\\"{x:1520,y:874,t:1527628623551};\\\", \\\"{x:1520,y:873,t:1527628623568};\\\", \\\"{x:1513,y:870,t:1527628623585};\\\", \\\"{x:1502,y:862,t:1527628623601};\\\", \\\"{x:1482,y:849,t:1527628623618};\\\", \\\"{x:1452,y:833,t:1527628623634};\\\", \\\"{x:1426,y:823,t:1527628623652};\\\", \\\"{x:1402,y:810,t:1527628623667};\\\", \\\"{x:1381,y:801,t:1527628623685};\\\", \\\"{x:1376,y:799,t:1527628623702};\\\", \\\"{x:1375,y:798,t:1527628623724};\\\", \\\"{x:1374,y:798,t:1527628623734};\\\", \\\"{x:1373,y:798,t:1527628624533};\\\", \\\"{x:1371,y:798,t:1527628624580};\\\", \\\"{x:1370,y:798,t:1527628624588};\\\", \\\"{x:1369,y:798,t:1527628624601};\\\", \\\"{x:1367,y:801,t:1527628624618};\\\", \\\"{x:1366,y:807,t:1527628624636};\\\", \\\"{x:1365,y:813,t:1527628624652};\\\", \\\"{x:1365,y:817,t:1527628624669};\\\", \\\"{x:1364,y:820,t:1527628624686};\\\", \\\"{x:1364,y:821,t:1527628624702};\\\", \\\"{x:1363,y:824,t:1527628624718};\\\", \\\"{x:1363,y:825,t:1527628624740};\\\", \\\"{x:1361,y:826,t:1527628624752};\\\", \\\"{x:1356,y:829,t:1527628624768};\\\", \\\"{x:1353,y:832,t:1527628624785};\\\", \\\"{x:1351,y:833,t:1527628624801};\\\", \\\"{x:1350,y:834,t:1527628624819};\\\", \\\"{x:1350,y:835,t:1527628624835};\\\", \\\"{x:1350,y:837,t:1527628624851};\\\", \\\"{x:1349,y:838,t:1527628624869};\\\", \\\"{x:1349,y:841,t:1527628624885};\\\", \\\"{x:1348,y:844,t:1527628624902};\\\", \\\"{x:1348,y:848,t:1527628624919};\\\", \\\"{x:1348,y:853,t:1527628624936};\\\", \\\"{x:1348,y:858,t:1527628624952};\\\", \\\"{x:1348,y:862,t:1527628624969};\\\", \\\"{x:1348,y:867,t:1527628624985};\\\", \\\"{x:1348,y:870,t:1527628625003};\\\", \\\"{x:1346,y:873,t:1527628625019};\\\", \\\"{x:1346,y:876,t:1527628625036};\\\", \\\"{x:1344,y:877,t:1527628625052};\\\", \\\"{x:1338,y:879,t:1527628625069};\\\", \\\"{x:1336,y:881,t:1527628625086};\\\", \\\"{x:1336,y:883,t:1527628625103};\\\", \\\"{x:1336,y:885,t:1527628625118};\\\", \\\"{x:1336,y:886,t:1527628625136};\\\", \\\"{x:1336,y:887,t:1527628625153};\\\", \\\"{x:1336,y:889,t:1527628625221};\\\", \\\"{x:1336,y:890,t:1527628625236};\\\", \\\"{x:1336,y:891,t:1527628625252};\\\", \\\"{x:1337,y:891,t:1527628625532};\\\", \\\"{x:1335,y:889,t:1527628625844};\\\", \\\"{x:1322,y:884,t:1527628625853};\\\", \\\"{x:1289,y:874,t:1527628625869};\\\", \\\"{x:1249,y:858,t:1527628625886};\\\", \\\"{x:1222,y:850,t:1527628625903};\\\", \\\"{x:1199,y:843,t:1527628625920};\\\", \\\"{x:1178,y:837,t:1527628625937};\\\", \\\"{x:1146,y:829,t:1527628625953};\\\", \\\"{x:1116,y:820,t:1527628625969};\\\", \\\"{x:1094,y:813,t:1527628625987};\\\", \\\"{x:1074,y:808,t:1527628626003};\\\", \\\"{x:1052,y:798,t:1527628626020};\\\", \\\"{x:1040,y:794,t:1527628626036};\\\", \\\"{x:1020,y:787,t:1527628626053};\\\", \\\"{x:998,y:781,t:1527628626070};\\\", \\\"{x:972,y:775,t:1527628626087};\\\", \\\"{x:947,y:770,t:1527628626103};\\\", \\\"{x:926,y:763,t:1527628626120};\\\", \\\"{x:910,y:755,t:1527628626137};\\\", \\\"{x:895,y:749,t:1527628626153};\\\", \\\"{x:882,y:743,t:1527628626170};\\\", \\\"{x:874,y:740,t:1527628626187};\\\", \\\"{x:854,y:738,t:1527628626203};\\\", \\\"{x:844,y:739,t:1527628626219};\\\", \\\"{x:840,y:739,t:1527628626237};\\\", \\\"{x:836,y:739,t:1527628626254};\\\", \\\"{x:832,y:739,t:1527628626270};\\\", \\\"{x:830,y:739,t:1527628626286};\\\", \\\"{x:826,y:739,t:1527628626304};\\\", \\\"{x:821,y:739,t:1527628626320};\\\", \\\"{x:816,y:739,t:1527628626336};\\\", \\\"{x:807,y:741,t:1527628626354};\\\", \\\"{x:793,y:743,t:1527628626370};\\\", \\\"{x:781,y:744,t:1527628626387};\\\", \\\"{x:753,y:744,t:1527628626404};\\\", \\\"{x:744,y:744,t:1527628626419};\\\", \\\"{x:708,y:744,t:1527628626437};\\\", \\\"{x:674,y:744,t:1527628626454};\\\", \\\"{x:638,y:744,t:1527628626469};\\\", \\\"{x:598,y:744,t:1527628626487};\\\", \\\"{x:562,y:744,t:1527628626504};\\\", \\\"{x:533,y:744,t:1527628626520};\\\", \\\"{x:517,y:742,t:1527628626537};\\\", \\\"{x:511,y:740,t:1527628626551};\\\", \\\"{x:510,y:740,t:1527628626568};\\\", \\\"{x:512,y:740,t:1527628626756};\\\", \\\"{x:513,y:740,t:1527628626780};\\\", \\\"{x:514,y:742,t:1527628626788};\\\", \\\"{x:514,y:744,t:1527628626801};\\\", \\\"{x:516,y:747,t:1527628626818};\\\", \\\"{x:516,y:748,t:1527628626834};\\\", \\\"{x:517,y:749,t:1527628626851};\\\", \\\"{x:516,y:749,t:1527628628836};\\\", \\\"{x:516,y:751,t:1527628628884};\\\", \\\"{x:514,y:751,t:1527628629076};\\\" ] }, { \\\"rt\\\": 67646, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 819413, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"all points that lay on the vertical x-intercept at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8176, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"united states\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 828596, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15543, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 845159, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 31987, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 878460, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"7H6QC\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"7H6QC\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 353, dom: 1024, initialDom: 1098",
  "javascriptErrors": []
}