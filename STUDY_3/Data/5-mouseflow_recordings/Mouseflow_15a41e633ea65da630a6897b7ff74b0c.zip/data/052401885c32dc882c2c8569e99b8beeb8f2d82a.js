var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052401885c32dc882c2c8569e99b8beeb8f2d82a"] = {
  "startTime": "2018-05-24T19:13:01.0340428Z",
  "websitePageUrl": "/16",
  "visitTime": 84263,
  "engagementTime": 83845,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "15a41e633ea65da630a6897b7ff74b0c",
    "created": "2018-05-24T19:13:01.0340428+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=3Z8ZL",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bcd5cdbeb8e1a1e484819ecb3a62088b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/15a41e633ea65da630a6897b7ff74b0c/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 247,
      "e": 247,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 554,
      "y": 682
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 563,
      "y": 606
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 52372,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 1026,
      "e": 1026,
      "ty": 6,
      "x": 563,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 564,
      "y": 601
    },
    {
      "t": 1134,
      "e": 1134,
      "ty": 3,
      "x": 564,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1136,
      "e": 1136,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 52484,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1311,
      "e": 1311,
      "ty": 4,
      "x": 52484,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1312,
      "e": 1312,
      "ty": 5,
      "x": 564,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2303,
      "e": 2303,
      "ty": 3,
      "x": 564,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2375,
      "e": 2375,
      "ty": 4,
      "x": 52484,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2376,
      "e": 2376,
      "ty": 5,
      "x": 564,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6171,
      "e": 6171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6483,
      "e": 6483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 6484,
      "e": 6484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6586,
      "e": 6586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 6618,
      "e": 6618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 6643,
      "e": 6643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 6643,
      "e": 6643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6747,
      "e": 6747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sh"
    },
    {
      "t": 6787,
      "e": 6787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 6787,
      "e": 6787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6834,
      "e": 6834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 6834,
      "e": 6834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6882,
      "e": 6882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shif"
    },
    {
      "t": 6906,
      "e": 6906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7019,
      "e": 7019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7019,
      "e": 7019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7090,
      "e": 7090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 7090,
      "e": 7090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7123,
      "e": 7123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 7194,
      "e": 7194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7203,
      "e": 7203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7203,
      "e": 7203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7314,
      "e": 7314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7322,
      "e": 7322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7379,
      "e": 7379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 7379,
      "e": 7379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7442,
      "e": 7442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 7491,
      "e": 7491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7739,
      "e": 7739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7740,
      "e": 7740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7827,
      "e": 7827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7866,
      "e": 7866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7866,
      "e": 7866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7947,
      "e": 7947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7948,
      "e": 7948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7954,
      "e": 7954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 8018,
      "e": 8018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8018,
      "e": 8018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 8018,
      "e": 8018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8106,
      "e": 8106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 8114,
      "e": 8114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8115,
      "e": 8115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8170,
      "e": 8170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8187,
      "e": 8187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8330,
      "e": 8330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 8330,
      "e": 8330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8330,
      "e": 8330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8354,
      "e": 8354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8426,
      "e": 8426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8475,
      "e": 8475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 8475,
      "e": 8475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8554,
      "e": 8554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 8562,
      "e": 8562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8562,
      "e": 8562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8650,
      "e": 8650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8682,
      "e": 8682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8683,
      "e": 8683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8762,
      "e": 8762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 8762,
      "e": 8762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8781,
      "e": 8781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 8834,
      "e": 8834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8914,
      "e": 8914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8914,
      "e": 8914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8971,
      "e": 8971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8994,
      "e": 8994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 8995,
      "e": 8995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9107,
      "e": 9107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 9107,
      "e": 9107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9108,
      "e": 9108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9178,
      "e": 9178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11651,
      "e": 11651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11787,
      "e": 11787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11788,
      "e": 11788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11858,
      "e": 11858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 11890,
      "e": 11890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11947,
      "e": 11947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11947,
      "e": 11947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12018,
      "e": 12018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12051,
      "e": 12051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12051,
      "e": 12051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12130,
      "e": 12130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12162,
      "e": 12162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12162,
      "e": 12162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12202,
      "e": 12202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 12299,
      "e": 12299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12299,
      "e": 12299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12346,
      "e": 12346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12370,
      "e": 12370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12370,
      "e": 12370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12427,
      "e": 12427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12435,
      "e": 12435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12548,
      "e": 12548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 12549,
      "e": 12549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12635,
      "e": 12635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12635,
      "e": 12635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12651,
      "e": 12651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||J "
    },
    {
      "t": 12658,
      "e": 12658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12714,
      "e": 12714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12802,
      "e": 12802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12803,
      "e": 12803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12875,
      "e": 12875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12883,
      "e": 12883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12883,
      "e": 12883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12954,
      "e": 12954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12970,
      "e": 12970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12970,
      "e": 12970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13067,
      "e": 13067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13067,
      "e": 13067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13091,
      "e": 13091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 13187,
      "e": 13187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14267,
      "e": 14267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 14268,
      "e": 14268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14362,
      "e": 14362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14362,
      "e": 14362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14402,
      "e": 14402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 14466,
      "e": 14466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14707,
      "e": 14707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14771,
      "e": 14771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14772,
      "e": 14772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14826,
      "e": 14826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 14875,
      "e": 14875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14955,
      "e": 14955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14956,
      "e": 14956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15051,
      "e": 15051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15074,
      "e": 15074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15074,
      "e": 15074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15123,
      "e": 15123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15123,
      "e": 15123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15162,
      "e": 15162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 15195,
      "e": 15195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15307,
      "e": 15307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15307,
      "e": 15307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15387,
      "e": 15387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15427,
      "e": 15427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15428,
      "e": 15428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15483,
      "e": 15483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15603,
      "e": 15603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift "
    },
    {
      "t": 15667,
      "e": 15667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15739,
      "e": 15739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15740,
      "e": 15740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15794,
      "e": 15794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15794,
      "e": 15794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15834,
      "e": 15834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I "
    },
    {
      "t": 15842,
      "e": 15842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15907,
      "e": 15907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16154,
      "e": 16154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16195,
      "e": 16195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I"
    },
    {
      "t": 16315,
      "e": 16315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16386,
      "e": 16386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift "
    },
    {
      "t": 16482,
      "e": 16482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16539,
      "e": 16539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift"
    },
    {
      "t": 16891,
      "e": 16891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16892,
      "e": 16892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16962,
      "e": 16962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16978,
      "e": 16978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17075,
      "e": 17075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17075,
      "e": 17075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17130,
      "e": 17130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17132,
      "e": 17132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17154,
      "e": 17154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I "
    },
    {
      "t": 17226,
      "e": 17226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17234,
      "e": 17234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17451,
      "e": 17451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17451,
      "e": 17451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17482,
      "e": 17482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17483,
      "e": 17483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17507,
      "e": 17507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 17563,
      "e": 17563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17595,
      "e": 17595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17596,
      "e": 17596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17658,
      "e": 17658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17659,
      "e": 17659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17682,
      "e": 17682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 17754,
      "e": 17754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17778,
      "e": 17778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17867,
      "e": 17867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 17868,
      "e": 17868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17970,
      "e": 17970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17971,
      "e": 17971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18003,
      "e": 18003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||J "
    },
    {
      "t": 18018,
      "e": 18018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18067,
      "e": 18019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18363,
      "e": 18315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18363,
      "e": 18315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18426,
      "e": 18378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18435,
      "e": 18387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18435,
      "e": 18387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18490,
      "e": 18442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18530,
      "e": 18482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18531,
      "e": 18483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18650,
      "e": 18602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18651,
      "e": 18603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18674,
      "e": 18626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 18755,
      "e": 18707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19099,
      "e": 19051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 19102,
      "e": 19054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19186,
      "e": 19138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19186,
      "e": 19138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19218,
      "e": 19170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 19298,
      "e": 19250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22498,
      "e": 22450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 22667,
      "e": 22619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22668,
      "e": 22620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22754,
      "e": 22706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 22786,
      "e": 22738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22794,
      "e": 22746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22794,
      "e": 22746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22882,
      "e": 22834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22891,
      "e": 22843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22891,
      "e": 22843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22938,
      "e": 22890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 22938,
      "e": 22890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22962,
      "e": 22914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 23010,
      "e": 22962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23123,
      "e": 23075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23123,
      "e": 23075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23171,
      "e": 23123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23178,
      "e": 23130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23180,
      "e": 23132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23266,
      "e": 23218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23274,
      "e": 23226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 23330,
      "e": 23282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23330,
      "e": 23282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23379,
      "e": 23331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 23403,
      "e": 23355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23404,
      "e": 23356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23433,
      "e": 23385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23474,
      "e": 23426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23522,
      "e": 23474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23522,
      "e": 23474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23570,
      "e": 23522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23570,
      "e": 23522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23595,
      "e": 23547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 23618,
      "e": 23570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23619,
      "e": 23571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23658,
      "e": 23610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23690,
      "e": 23642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23755,
      "e": 23707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23756,
      "e": 23708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23834,
      "e": 23786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23867,
      "e": 23819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23867,
      "e": 23819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23954,
      "e": 23906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23978,
      "e": 23930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23978,
      "e": 23930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24018,
      "e": 23970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24123,
      "e": 24075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24124,
      "e": 24076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24170,
      "e": 24122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 24242,
      "e": 24194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24242,
      "e": 24194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24324,
      "e": 24276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24324,
      "e": 24276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24330,
      "e": 24282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 24402,
      "e": 24354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24402,
      "e": 24354,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24410,
      "e": 24362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 24482,
      "e": 24434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24483,
      "e": 24435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24498,
      "e": 24450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24530,
      "e": 24482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24723,
      "e": 24675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24724,
      "e": 24676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24834,
      "e": 24786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24898,
      "e": 24850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24899,
      "e": 24851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24995,
      "e": 24947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24996,
      "e": 24948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25010,
      "e": 24962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25010,
      "e": 24962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25042,
      "e": 24994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng "
    },
    {
      "t": 25066,
      "e": 25018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25170,
      "e": 25122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25203,
      "e": 25155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25204,
      "e": 25156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25258,
      "e": 25210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25329,
      "e": 25281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25330,
      "e": 25282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25386,
      "e": 25338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25506,
      "e": 25458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 25507,
      "e": 25459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25570,
      "e": 25522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 27183,
      "e": 27135,
      "ty": 7,
      "x": 563,
      "y": 610,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27201,
      "e": 27153,
      "ty": 2,
      "x": 558,
      "y": 620
    },
    {
      "t": 27251,
      "e": 27203,
      "ty": 41,
      "x": 46527,
      "y": 36839,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 27300,
      "e": 27252,
      "ty": 2,
      "x": 510,
      "y": 674
    },
    {
      "t": 27401,
      "e": 27353,
      "ty": 2,
      "x": 502,
      "y": 680
    },
    {
      "t": 27501,
      "e": 27453,
      "ty": 2,
      "x": 498,
      "y": 688
    },
    {
      "t": 27502,
      "e": 27454,
      "ty": 41,
      "x": 45065,
      "y": 37670,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 27601,
      "e": 27553,
      "ty": 2,
      "x": 487,
      "y": 706
    },
    {
      "t": 27701,
      "e": 27653,
      "ty": 2,
      "x": 473,
      "y": 720
    },
    {
      "t": 27751,
      "e": 27703,
      "ty": 41,
      "x": 41693,
      "y": 39830,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 27801,
      "e": 27753,
      "ty": 2,
      "x": 468,
      "y": 727
    },
    {
      "t": 28401,
      "e": 28353,
      "ty": 2,
      "x": 462,
      "y": 722
    },
    {
      "t": 28501,
      "e": 28453,
      "ty": 2,
      "x": 454,
      "y": 707
    },
    {
      "t": 28502,
      "e": 28454,
      "ty": 41,
      "x": 63384,
      "y": 55878,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 28601,
      "e": 28553,
      "ty": 2,
      "x": 442,
      "y": 692
    },
    {
      "t": 28616,
      "e": 28568,
      "ty": 6,
      "x": 440,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 28700,
      "e": 28652,
      "ty": 2,
      "x": 436,
      "y": 681
    },
    {
      "t": 28751,
      "e": 28703,
      "ty": 41,
      "x": 51557,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 28801,
      "e": 28753,
      "ty": 2,
      "x": 431,
      "y": 674
    },
    {
      "t": 28901,
      "e": 28853,
      "ty": 2,
      "x": 426,
      "y": 669
    },
    {
      "t": 29001,
      "e": 28953,
      "ty": 41,
      "x": 47734,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 30001,
      "e": 29953,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31001,
      "e": 30953,
      "ty": 7,
      "x": 412,
      "y": 646,
      "ta": "#strategyButton"
    },
    {
      "t": 31003,
      "e": 30955,
      "ty": 2,
      "x": 412,
      "y": 646
    },
    {
      "t": 31004,
      "e": 30956,
      "ty": 41,
      "x": 43724,
      "y": 15902,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 31100,
      "e": 31052,
      "ty": 2,
      "x": 378,
      "y": 605
    },
    {
      "t": 31116,
      "e": 31068,
      "ty": 6,
      "x": 374,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31201,
      "e": 31153,
      "ty": 2,
      "x": 346,
      "y": 580
    },
    {
      "t": 31251,
      "e": 31203,
      "ty": 41,
      "x": 26630,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31301,
      "e": 31253,
      "ty": 2,
      "x": 331,
      "y": 568
    },
    {
      "t": 31501,
      "e": 31453,
      "ty": 41,
      "x": 26293,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31848,
      "e": 31800,
      "ty": 3,
      "x": 331,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32014,
      "e": 31966,
      "ty": 4,
      "x": 26293,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32015,
      "e": 31967,
      "ty": 5,
      "x": 331,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32901,
      "e": 32853,
      "ty": 2,
      "x": 330,
      "y": 568
    },
    {
      "t": 33001,
      "e": 32953,
      "ty": 2,
      "x": 297,
      "y": 560
    },
    {
      "t": 33001,
      "e": 32953,
      "ty": 41,
      "x": 22471,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33101,
      "e": 33053,
      "ty": 2,
      "x": 296,
      "y": 559
    },
    {
      "t": 33205,
      "e": 33157,
      "ty": 2,
      "x": 286,
      "y": 557
    },
    {
      "t": 33256,
      "e": 33208,
      "ty": 41,
      "x": 20785,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33306,
      "e": 33258,
      "ty": 2,
      "x": 279,
      "y": 553
    },
    {
      "t": 33406,
      "e": 33358,
      "ty": 2,
      "x": 270,
      "y": 550
    },
    {
      "t": 33505,
      "e": 33457,
      "ty": 2,
      "x": 265,
      "y": 545
    },
    {
      "t": 33505,
      "e": 33457,
      "ty": 41,
      "x": 18874,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33605,
      "e": 33557,
      "ty": 2,
      "x": 259,
      "y": 542
    },
    {
      "t": 33706,
      "e": 33658,
      "ty": 2,
      "x": 251,
      "y": 538
    },
    {
      "t": 33756,
      "e": 33708,
      "ty": 41,
      "x": 16850,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33805,
      "e": 33757,
      "ty": 2,
      "x": 246,
      "y": 536
    },
    {
      "t": 33828,
      "e": 33780,
      "ty": 3,
      "x": 246,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33905,
      "e": 33857,
      "ty": 2,
      "x": 247,
      "y": 532
    },
    {
      "t": 33914,
      "e": 33866,
      "ty": 4,
      "x": 16850,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33914,
      "e": 33866,
      "ty": 5,
      "x": 247,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34005,
      "e": 33957,
      "ty": 2,
      "x": 300,
      "y": 552
    },
    {
      "t": 34006,
      "e": 33958,
      "ty": 41,
      "x": 22808,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34105,
      "e": 34057,
      "ty": 2,
      "x": 375,
      "y": 574
    },
    {
      "t": 34205,
      "e": 34157,
      "ty": 2,
      "x": 375,
      "y": 575
    },
    {
      "t": 34256,
      "e": 34208,
      "ty": 41,
      "x": 31239,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35015,
      "e": 34967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 35126,
      "e": 35078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35222,
      "e": 35174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "40"
    },
    {
      "t": 35311,
      "e": 35263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35751,
      "e": 35703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 35751,
      "e": 35703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35814,
      "e": 35766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 36175,
      "e": 36127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 36176,
      "e": 36128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36270,
      "e": 36222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 36351,
      "e": 36303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36851,
      "e": 36803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36885,
      "e": 36837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36917,
      "e": 36869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36950,
      "e": 36902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36983,
      "e": 36935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 36991,
      "e": 36943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36991,
      "e": 36943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37078,
      "e": 37030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 37103,
      "e": 37055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37208,
      "e": 37160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37209,
      "e": 37161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37246,
      "e": 37198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37326,
      "e": 37278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37326,
      "e": 37278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37374,
      "e": 37326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 37374,
      "e": 37326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37430,
      "e": 37382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 37446,
      "e": 37398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37446,
      "e": 37398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37510,
      "e": 37462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37551,
      "e": 37503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37551,
      "e": 37503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37552,
      "e": 37504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37598,
      "e": 37550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37614,
      "e": 37566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37614,
      "e": 37566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37678,
      "e": 37630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37679,
      "e": 37631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37718,
      "e": 37670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 37726,
      "e": 37678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37726,
      "e": 37678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37766,
      "e": 37718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37775,
      "e": 37727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37838,
      "e": 37790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37840,
      "e": 37792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37886,
      "e": 37838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37886,
      "e": 37838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37918,
      "e": 37870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 37942,
      "e": 37894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37942,
      "e": 37894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37958,
      "e": 37910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38022,
      "e": 37974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38054,
      "e": 38006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38055,
      "e": 38007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38095,
      "e": 38047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38095,
      "e": 38047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38159,
      "e": 38111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 38175,
      "e": 38127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 38176,
      "e": 38128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38183,
      "e": 38135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 38262,
      "e": 38214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38359,
      "e": 38311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38359,
      "e": 38311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38423,
      "e": 38375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38423,
      "e": 38375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38430,
      "e": 38382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 38502,
      "e": 38454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38558,
      "e": 38510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38558,
      "e": 38510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38647,
      "e": 38599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38655,
      "e": 38607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 38655,
      "e": 38607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38710,
      "e": 38662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38711,
      "e": 38663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38734,
      "e": 38686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 38839,
      "e": 38791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38863,
      "e": 38815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 38864,
      "e": 38816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38959,
      "e": 38911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 39079,
      "e": 39031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 39079,
      "e": 39031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39087,
      "e": 39039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "51"
    },
    {
      "t": 39089,
      "e": 39041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39118,
      "e": 39070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||23"
    },
    {
      "t": 39134,
      "e": 39086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39134,
      "e": 39086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39135,
      "e": 39087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39214,
      "e": 39166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39279,
      "e": 39231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39279,
      "e": 39231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39358,
      "e": 39310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39367,
      "e": 39319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39368,
      "e": 39320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39422,
      "e": 39374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39598,
      "e": 39550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39601,
      "e": 39553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 39602,
      "e": 39554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39623,
      "e": 39555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 123 t="
    },
    {
      "t": 39638,
      "e": 39570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39750,
      "e": 39682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39790,
      "e": 39722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 123 t"
    },
    {
      "t": 39895,
      "e": 39827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39934,
      "e": 39866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 123 "
    },
    {
      "t": 40038,
      "e": 39970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40086,
      "e": 40018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 123"
    },
    {
      "t": 40175,
      "e": 40107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40238,
      "e": 40170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40239,
      "e": 40171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40254,
      "e": 40186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 "
    },
    {
      "t": 40335,
      "e": 40267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40342,
      "e": 40274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40342,
      "e": 40274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40407,
      "e": 40339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40422,
      "e": 40354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40423,
      "e": 40355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40487,
      "e": 40419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40488,
      "e": 40420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40494,
      "e": 40426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 40558,
      "e": 40490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40558,
      "e": 40490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40590,
      "e": 40522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40630,
      "e": 40562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40630,
      "e": 40562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40670,
      "e": 40602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40686,
      "e": 40618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40759,
      "e": 40691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40759,
      "e": 40691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40822,
      "e": 40754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40823,
      "e": 40755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40838,
      "e": 40770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 40902,
      "e": 40834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40951,
      "e": 40883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 40951,
      "e": 40883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41014,
      "e": 40946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41015,
      "e": 40947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41030,
      "e": 40962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 41078,
      "e": 41010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41151,
      "e": 41083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41151,
      "e": 41083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41207,
      "e": 41139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41207,
      "e": 41139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41238,
      "e": 41170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 41262,
      "e": 41194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41262,
      "e": 41194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41270,
      "e": 41202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41326,
      "e": 41258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42367,
      "e": 42299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42369,
      "e": 42301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42430,
      "e": 42362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42430,
      "e": 42362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42454,
      "e": 42386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 42494,
      "e": 42426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42542,
      "e": 42474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 42543,
      "e": 42475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42544,
      "e": 42476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42544,
      "e": 42476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42598,
      "e": 42530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 42613,
      "e": 42545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42726,
      "e": 42658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42726,
      "e": 42658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42798,
      "e": 42658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42799,
      "e": 42659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42807,
      "e": 42667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 42878,
      "e": 42738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42902,
      "e": 42762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42903,
      "e": 42763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42982,
      "e": 42842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43208,
      "e": 43068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43209,
      "e": 43069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43262,
      "e": 43122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 43350,
      "e": 43210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 43350,
      "e": 43210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43471,
      "e": 43331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 43543,
      "e": 43403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43615,
      "e": 43475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shfits a"
    },
    {
      "t": 43719,
      "e": 43579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43766,
      "e": 43626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shfits "
    },
    {
      "t": 43862,
      "e": 43722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43918,
      "e": 43778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shfits"
    },
    {
      "t": 44008,
      "e": 43868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44070,
      "e": 43930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shfit"
    },
    {
      "t": 44167,
      "e": 44027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44214,
      "e": 44074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shfi"
    },
    {
      "t": 44310,
      "e": 44170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44359,
      "e": 44219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shf"
    },
    {
      "t": 44455,
      "e": 44315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44504,
      "e": 44316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what sh"
    },
    {
      "t": 44607,
      "e": 44419,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what sh"
    },
    {
      "t": 44615,
      "e": 44427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44616,
      "e": 44428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44663,
      "e": 44475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44663,
      "e": 44475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44686,
      "e": 44498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 44718,
      "e": 44530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44798,
      "e": 44610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44799,
      "e": 44611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44863,
      "e": 44675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44863,
      "e": 44675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44911,
      "e": 44723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 44951,
      "e": 44763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44951,
      "e": 44763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44958,
      "e": 44770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45046,
      "e": 44858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45062,
      "e": 44874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45062,
      "e": 44874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45126,
      "e": 44938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 45126,
      "e": 44938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45134,
      "e": 44946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 45208,
      "e": 45020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45209,
      "e": 45021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45222,
      "e": 45034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45222,
      "e": 45034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45238,
      "e": 45050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 45294,
      "e": 45106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45318,
      "e": 45130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45383,
      "e": 45195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 45384,
      "e": 45196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45438,
      "e": 45250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45438,
      "e": 45250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45470,
      "e": 45282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 45486,
      "e": 45298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45486,
      "e": 45298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45526,
      "e": 45338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45534,
      "e": 45346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45640,
      "e": 45452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45640,
      "e": 45452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45678,
      "e": 45490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45758,
      "e": 45570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45758,
      "e": 45570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45790,
      "e": 45602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45790,
      "e": 45602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45830,
      "e": 45642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 45887,
      "e": 45699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45975,
      "e": 45787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45976,
      "e": 45788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46013,
      "e": 45825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46015,
      "e": 45827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46021,
      "e": 45833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||oc"
    },
    {
      "t": 46102,
      "e": 45914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46166,
      "e": 45978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46166,
      "e": 45978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46247,
      "e": 46059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 46263,
      "e": 46075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 46263,
      "e": 46075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46326,
      "e": 46138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 46374,
      "e": 46186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46374,
      "e": 46186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46438,
      "e": 46250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46446,
      "e": 46258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46446,
      "e": 46258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46486,
      "e": 46298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46510,
      "e": 46322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46511,
      "e": 46323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46591,
      "e": 46403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46591,
      "e": 46403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46606,
      "e": 46418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 46662,
      "e": 46474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46791,
      "e": 46603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 46791,
      "e": 46603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46894,
      "e": 46706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 46926,
      "e": 46738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46926,
      "e": 46738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46982,
      "e": 46794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47199,
      "e": 47011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47246,
      "e": 47058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shifts are still occuring/"
    },
    {
      "t": 47438,
      "e": 47250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47439,
      "e": 47251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47494,
      "e": 47306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47494,
      "e": 47306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47534,
      "e": 47306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 47598,
      "e": 47370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47662,
      "e": 47434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 47663,
      "e": 47435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47725,
      "e": 47497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 47974,
      "e": 47746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48474,
      "e": 48246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48507,
      "e": 48279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48539,
      "e": 48311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48573,
      "e": 48345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48605,
      "e": 48377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48639,
      "e": 48411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48671,
      "e": 48443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48678,
      "e": 48450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shifts are still occu"
    },
    {
      "t": 48807,
      "e": 48579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shifts are still occu"
    },
    {
      "t": 49182,
      "e": 48954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49183,
      "e": 48955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49254,
      "e": 49026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49335,
      "e": 49107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49336,
      "e": 49108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49382,
      "e": 49154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49382,
      "e": 49154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49389,
      "e": 49161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ri"
    },
    {
      "t": 49446,
      "e": 49218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49478,
      "e": 49250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49479,
      "e": 49251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49534,
      "e": 49306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 49534,
      "e": 49306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49567,
      "e": 49339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 49608,
      "e": 49380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49710,
      "e": 49482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 49711,
      "e": 49483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49790,
      "e": 49562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 49991,
      "e": 49763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50039,
      "e": 49811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shifts are still occurring"
    },
    {
      "t": 50208,
      "e": 49980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 50208,
      "e": 49980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50254,
      "e": 50026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 50318,
      "e": 50090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50318,
      "e": 50090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50374,
      "e": 50146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50406,
      "e": 50178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50407,
      "e": 50179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50470,
      "e": 50242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50470,
      "e": 50242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50471,
      "e": 50243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50566,
      "e": 50338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 50615,
      "e": 50387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50615,
      "e": 50387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50655,
      "e": 50427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 50694,
      "e": 50466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50695,
      "e": 50467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50750,
      "e": 50522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 50750,
      "e": 50522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50774,
      "e": 50546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 50830,
      "e": 50602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50894,
      "e": 50666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 50895,
      "e": 50667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50974,
      "e": 50746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50975,
      "e": 50747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51006,
      "e": 50778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 51079,
      "e": 50851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52166,
      "e": 51938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52168,
      "e": 51940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52231,
      "e": 52003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52232,
      "e": 52004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52238,
      "e": 52010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 52302,
      "e": 52074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52302,
      "e": 52074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 52302,
      "e": 52074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52350,
      "e": 52122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52353,
      "e": 52125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52366,
      "e": 52138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 52453,
      "e": 52225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52696,
      "e": 52468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52696,
      "e": 52468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52782,
      "e": 52468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52790,
      "e": 52476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52790,
      "e": 52476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52854,
      "e": 52540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52934,
      "e": 52620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 52934,
      "e": 52620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52998,
      "e": 52684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52998,
      "e": 52684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53014,
      "e": 52700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||so"
    },
    {
      "t": 53046,
      "e": 52732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53046,
      "e": 52732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53054,
      "e": 52740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53126,
      "e": 52812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53174,
      "e": 52860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 53174,
      "e": 52860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53238,
      "e": 52924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 53335,
      "e": 53021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53336,
      "e": 53022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53375,
      "e": 53061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 53454,
      "e": 53140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53455,
      "e": 53141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53517,
      "e": 53203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 53518,
      "e": 53204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53557,
      "e": 53243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 53574,
      "e": 53260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53574,
      "e": 53260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53646,
      "e": 53332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53679,
      "e": 53365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53710,
      "e": 53396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53711,
      "e": 53397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53798,
      "e": 53484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53798,
      "e": 53484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53830,
      "e": 53516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 53878,
      "e": 53564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53878,
      "e": 53564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53894,
      "e": 53580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53982,
      "e": 53668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54398,
      "e": 54084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 54399,
      "e": 54085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54486,
      "e": 54172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 54582,
      "e": 54268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 54583,
      "e": 54269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54654,
      "e": 54340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 54814,
      "e": 54500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 54998,
      "e": 54684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55134,
      "e": 54820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55134,
      "e": 54820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55206,
      "e": 54892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55294,
      "e": 54980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55294,
      "e": 54980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55334,
      "e": 55020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55334,
      "e": 55020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55358,
      "e": 55044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 55398,
      "e": 55084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55398,
      "e": 55084,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55414,
      "e": 55100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55478,
      "e": 55164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 55479,
      "e": 55165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55486,
      "e": 55172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 55518,
      "e": 55204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55519,
      "e": 55205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55606,
      "e": 55292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55614,
      "e": 55300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55694,
      "e": 55380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55694,
      "e": 55380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55742,
      "e": 55428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55742,
      "e": 55428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55782,
      "e": 55468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 55822,
      "e": 55508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56038,
      "e": 55724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 56039,
      "e": 55725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56142,
      "e": 55828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 56150,
      "e": 55836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56151,
      "e": 55837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56237,
      "e": 55923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56237,
      "e": 55923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56261,
      "e": 55947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 56317,
      "e": 56003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56319,
      "e": 56005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56342,
      "e": 56028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56358,
      "e": 56044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56359,
      "e": 56045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56382,
      "e": 56068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56438,
      "e": 56124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56478,
      "e": 56164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 56478,
      "e": 56164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56557,
      "e": 56243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56557,
      "e": 56243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56565,
      "e": 56251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 56621,
      "e": 56307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56637,
      "e": 56323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56637,
      "e": 56323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56702,
      "e": 56388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 56702,
      "e": 56388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56725,
      "e": 56411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 56758,
      "e": 56444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56878,
      "e": 56564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56878,
      "e": 56564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56927,
      "e": 56613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 56928,
      "e": 56614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56941,
      "e": 56627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 56997,
      "e": 56683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56998,
      "e": 56684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57005,
      "e": 56691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57126,
      "e": 56812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57134,
      "e": 56820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57135,
      "e": 56821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57198,
      "e": 56884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57206,
      "e": 56892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57206,
      "e": 56892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57311,
      "e": 56997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57311,
      "e": 56997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57341,
      "e": 57027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 57350,
      "e": 57036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57350,
      "e": 57036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57374,
      "e": 57060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57446,
      "e": 57132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57487,
      "e": 57173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57487,
      "e": 57173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57550,
      "e": 57236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57550,
      "e": 57236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57565,
      "e": 57251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 57621,
      "e": 57307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57677,
      "e": 57363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57678,
      "e": 57364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57743,
      "e": 57429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 57743,
      "e": 57429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57765,
      "e": 57451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 57814,
      "e": 57500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57902,
      "e": 57588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57903,
      "e": 57589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57959,
      "e": 57645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57983,
      "e": 57669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57984,
      "e": 57670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58045,
      "e": 57731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 58086,
      "e": 57772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58086,
      "e": 57772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58141,
      "e": 57827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 58431,
      "e": 58117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 58431,
      "e": 58117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58486,
      "e": 58172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 58566,
      "e": 58252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 58566,
      "e": 58252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58622,
      "e": 58308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58622,
      "e": 58308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58646,
      "e": 58332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 58710,
      "e": 58396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59756,
      "e": 59442,
      "ty": 41,
      "x": 33600,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59806,
      "e": 59492,
      "ty": 2,
      "x": 413,
      "y": 603
    },
    {
      "t": 59906,
      "e": 59592,
      "ty": 2,
      "x": 429,
      "y": 600
    },
    {
      "t": 60006,
      "e": 59692,
      "ty": 2,
      "x": 441,
      "y": 594
    },
    {
      "t": 60006,
      "e": 59692,
      "ty": 41,
      "x": 38658,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60105,
      "e": 59791,
      "ty": 2,
      "x": 441,
      "y": 600
    },
    {
      "t": 60112,
      "e": 59798,
      "ty": 7,
      "x": 440,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60205,
      "e": 59891,
      "ty": 2,
      "x": 428,
      "y": 624
    },
    {
      "t": 60256,
      "e": 59942,
      "ty": 41,
      "x": 51213,
      "y": 1484,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 60305,
      "e": 59991,
      "ty": 2,
      "x": 428,
      "y": 629
    },
    {
      "t": 60406,
      "e": 60092,
      "ty": 2,
      "x": 427,
      "y": 640
    },
    {
      "t": 60506,
      "e": 60192,
      "ty": 41,
      "x": 50745,
      "y": 11970,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 60606,
      "e": 60292,
      "ty": 2,
      "x": 427,
      "y": 642
    },
    {
      "t": 60705,
      "e": 60391,
      "ty": 2,
      "x": 425,
      "y": 651
    },
    {
      "t": 60756,
      "e": 60442,
      "ty": 41,
      "x": 49809,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 60798,
      "e": 60484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60799,
      "e": 60485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60830,
      "e": 60516,
      "ty": 6,
      "x": 420,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 60845,
      "e": 60531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60905,
      "e": 60591,
      "ty": 2,
      "x": 413,
      "y": 666
    },
    {
      "t": 61006,
      "e": 60692,
      "ty": 2,
      "x": 408,
      "y": 670
    },
    {
      "t": 61006,
      "e": 60692,
      "ty": 41,
      "x": 37904,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 61195,
      "e": 60881,
      "ty": 3,
      "x": 408,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 61196,
      "e": 60882,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\n\nLook to the left of 12 to see what shifts are still occurring/ending, and also look at 12 to see what shifts are starting.  "
    },
    {
      "t": 61198,
      "e": 60884,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61198,
      "e": 60884,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61282,
      "e": 60968,
      "ty": 4,
      "x": 37904,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 61291,
      "e": 60977,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61293,
      "e": 60979,
      "ty": 5,
      "x": 408,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 61300,
      "e": 60986,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 61906,
      "e": 61592,
      "ty": 2,
      "x": 408,
      "y": 672
    },
    {
      "t": 62005,
      "e": 61691,
      "ty": 2,
      "x": 446,
      "y": 722
    },
    {
      "t": 62005,
      "e": 61691,
      "ty": 41,
      "x": 15083,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 62299,
      "e": 61985,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 62405,
      "e": 62091,
      "ty": 2,
      "x": 446,
      "y": 723
    },
    {
      "t": 62506,
      "e": 62192,
      "ty": 2,
      "x": 455,
      "y": 725
    },
    {
      "t": 62506,
      "e": 62192,
      "ty": 41,
      "x": 15393,
      "y": 39719,
      "ta": "html > body"
    },
    {
      "t": 62606,
      "e": 62292,
      "ty": 2,
      "x": 461,
      "y": 725
    },
    {
      "t": 62706,
      "e": 62392,
      "ty": 2,
      "x": 705,
      "y": 708
    },
    {
      "t": 62755,
      "e": 62441,
      "ty": 41,
      "x": 28686,
      "y": 38002,
      "ta": "html > body"
    },
    {
      "t": 62781,
      "e": 62467,
      "ty": 6,
      "x": 902,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62843,
      "e": 62529,
      "ty": 2,
      "x": 923,
      "y": 681
    },
    {
      "t": 62844,
      "e": 62530,
      "ty": 7,
      "x": 957,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62849,
      "e": 62535,
      "ty": 6,
      "x": 968,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62898,
      "e": 62584,
      "ty": 7,
      "x": 1010,
      "y": 638,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62905,
      "e": 62591,
      "ty": 2,
      "x": 1010,
      "y": 638
    },
    {
      "t": 63006,
      "e": 62692,
      "ty": 2,
      "x": 1034,
      "y": 594
    },
    {
      "t": 63006,
      "e": 62692,
      "ty": 41,
      "x": 48880,
      "y": 7751,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 63106,
      "e": 62792,
      "ty": 2,
      "x": 1034,
      "y": 586
    },
    {
      "t": 63199,
      "e": 62885,
      "ty": 6,
      "x": 1034,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63205,
      "e": 62891,
      "ty": 2,
      "x": 1034,
      "y": 572
    },
    {
      "t": 63256,
      "e": 62942,
      "ty": 41,
      "x": 48880,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63306,
      "e": 62992,
      "ty": 2,
      "x": 1034,
      "y": 559
    },
    {
      "t": 63315,
      "e": 63001,
      "ty": 3,
      "x": 1034,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63316,
      "e": 63002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63395,
      "e": 63081,
      "ty": 4,
      "x": 48880,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63395,
      "e": 63081,
      "ty": 5,
      "x": 1034,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63505,
      "e": 63191,
      "ty": 41,
      "x": 48880,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64182,
      "e": 63868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 64183,
      "e": 63869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64256,
      "e": 63942,
      "ty": 41,
      "x": 48880,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64267,
      "e": 63953,
      "ty": 7,
      "x": 1034,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64301,
      "e": 63987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "104"
    },
    {
      "t": 64302,
      "e": 63988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64305,
      "e": 63991,
      "ty": 2,
      "x": 1036,
      "y": 597
    },
    {
      "t": 64374,
      "e": 64060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 64382,
      "e": 64068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 64405,
      "e": 64091,
      "ty": 2,
      "x": 1033,
      "y": 639
    },
    {
      "t": 64504,
      "e": 64190,
      "ty": 2,
      "x": 1033,
      "y": 643
    },
    {
      "t": 64505,
      "e": 64191,
      "ty": 41,
      "x": 48664,
      "y": 42280,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 64606,
      "e": 64292,
      "ty": 2,
      "x": 1033,
      "y": 644
    },
    {
      "t": 64619,
      "e": 64305,
      "ty": 6,
      "x": 1033,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64706,
      "e": 64392,
      "ty": 2,
      "x": 1033,
      "y": 659
    },
    {
      "t": 64715,
      "e": 64401,
      "ty": 3,
      "x": 1033,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64716,
      "e": 64402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 64717,
      "e": 64403,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64718,
      "e": 64404,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64755,
      "e": 64441,
      "ty": 41,
      "x": 48664,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64809,
      "e": 64495,
      "ty": 4,
      "x": 48664,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64809,
      "e": 64495,
      "ty": 5,
      "x": 1033,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66086,
      "e": 65772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 66175,
      "e": 65861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 66175,
      "e": 65861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66238,
      "e": 65924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 66238,
      "e": 65924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66254,
      "e": 65940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 66359,
      "e": 66045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 66359,
      "e": 66045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66366,
      "e": 66052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66470,
      "e": 66052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66485,
      "e": 66067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67035,
      "e": 66617,
      "ty": 7,
      "x": 1023,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67052,
      "e": 66634,
      "ty": 6,
      "x": 1016,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67105,
      "e": 66687,
      "ty": 2,
      "x": 1003,
      "y": 687
    },
    {
      "t": 67205,
      "e": 66787,
      "ty": 2,
      "x": 995,
      "y": 697
    },
    {
      "t": 67243,
      "e": 66825,
      "ty": 3,
      "x": 995,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67244,
      "e": 66826,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67244,
      "e": 66826,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67244,
      "e": 66826,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67255,
      "e": 66837,
      "ty": 41,
      "x": 51063,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67298,
      "e": 66880,
      "ty": 4,
      "x": 51063,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67300,
      "e": 66882,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67302,
      "e": 66884,
      "ty": 5,
      "x": 995,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67302,
      "e": 66884,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 67605,
      "e": 67187,
      "ty": 2,
      "x": 999,
      "y": 705
    },
    {
      "t": 67755,
      "e": 67337,
      "ty": 41,
      "x": 34127,
      "y": 38611,
      "ta": "html > body"
    },
    {
      "t": 68314,
      "e": 67896,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 68830,
      "e": 68412,
      "ty": 2,
      "x": 1000,
      "y": 684
    },
    {
      "t": 68904,
      "e": 68486,
      "ty": 2,
      "x": 989,
      "y": 460
    },
    {
      "t": 69004,
      "e": 68586,
      "ty": 2,
      "x": 949,
      "y": 263
    },
    {
      "t": 69005,
      "e": 68587,
      "ty": 41,
      "x": 30277,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 69105,
      "e": 68687,
      "ty": 2,
      "x": 917,
      "y": 185
    },
    {
      "t": 69205,
      "e": 68787,
      "ty": 2,
      "x": 896,
      "y": 158
    },
    {
      "t": 69255,
      "e": 68837,
      "ty": 41,
      "x": 15563,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 69304,
      "e": 68886,
      "ty": 2,
      "x": 886,
      "y": 199
    },
    {
      "t": 69404,
      "e": 68986,
      "ty": 2,
      "x": 886,
      "y": 222
    },
    {
      "t": 69505,
      "e": 69087,
      "ty": 41,
      "x": 15325,
      "y": 17835,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 69604,
      "e": 69186,
      "ty": 2,
      "x": 883,
      "y": 229
    },
    {
      "t": 69634,
      "e": 69216,
      "ty": 3,
      "x": 883,
      "y": 229,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69730,
      "e": 69312,
      "ty": 4,
      "x": 50424,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69731,
      "e": 69313,
      "ty": 5,
      "x": 883,
      "y": 229,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69732,
      "e": 69314,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69734,
      "e": 69316,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 69755,
      "e": 69337,
      "ty": 41,
      "x": 50424,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70005,
      "e": 69587,
      "ty": 2,
      "x": 886,
      "y": 233
    },
    {
      "t": 70005,
      "e": 69587,
      "ty": 41,
      "x": 52880,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70105,
      "e": 69687,
      "ty": 2,
      "x": 890,
      "y": 246
    },
    {
      "t": 70204,
      "e": 69786,
      "ty": 2,
      "x": 895,
      "y": 274
    },
    {
      "t": 70256,
      "e": 69838,
      "ty": 41,
      "x": 23059,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 70305,
      "e": 69887,
      "ty": 2,
      "x": 896,
      "y": 321
    },
    {
      "t": 70405,
      "e": 69987,
      "ty": 2,
      "x": 898,
      "y": 379
    },
    {
      "t": 70505,
      "e": 70087,
      "ty": 2,
      "x": 898,
      "y": 377
    },
    {
      "t": 70505,
      "e": 70087,
      "ty": 41,
      "x": 18173,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 70606,
      "e": 70188,
      "ty": 2,
      "x": 899,
      "y": 273
    },
    {
      "t": 70705,
      "e": 70287,
      "ty": 2,
      "x": 902,
      "y": 262
    },
    {
      "t": 70755,
      "e": 70337,
      "ty": 41,
      "x": 61369,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 70805,
      "e": 70387,
      "ty": 2,
      "x": 902,
      "y": 261
    },
    {
      "t": 71005,
      "e": 70587,
      "ty": 2,
      "x": 899,
      "y": 286
    },
    {
      "t": 71005,
      "e": 70587,
      "ty": 41,
      "x": 24313,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 71105,
      "e": 70687,
      "ty": 2,
      "x": 901,
      "y": 300
    },
    {
      "t": 71204,
      "e": 70786,
      "ty": 2,
      "x": 884,
      "y": 308
    },
    {
      "t": 71255,
      "e": 70837,
      "ty": 41,
      "x": 11766,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 71304,
      "e": 70886,
      "ty": 2,
      "x": 863,
      "y": 313
    },
    {
      "t": 71330,
      "e": 70912,
      "ty": 3,
      "x": 863,
      "y": 313,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71331,
      "e": 70913,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71418,
      "e": 71000,
      "ty": 4,
      "x": 41275,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71419,
      "e": 71001,
      "ty": 5,
      "x": 863,
      "y": 313,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71421,
      "e": 71003,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 71423,
      "e": 71005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 71505,
      "e": 71087,
      "ty": 41,
      "x": 41275,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 71605,
      "e": 71187,
      "ty": 2,
      "x": 863,
      "y": 322
    },
    {
      "t": 71704,
      "e": 71286,
      "ty": 2,
      "x": 897,
      "y": 409
    },
    {
      "t": 71755,
      "e": 71337,
      "ty": 41,
      "x": 21971,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 71805,
      "e": 71387,
      "ty": 2,
      "x": 916,
      "y": 455
    },
    {
      "t": 71905,
      "e": 71487,
      "ty": 2,
      "x": 917,
      "y": 465
    },
    {
      "t": 72005,
      "e": 71587,
      "ty": 2,
      "x": 885,
      "y": 447
    },
    {
      "t": 72005,
      "e": 71587,
      "ty": 41,
      "x": 50783,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 72105,
      "e": 71687,
      "ty": 2,
      "x": 876,
      "y": 434
    },
    {
      "t": 72205,
      "e": 71787,
      "ty": 2,
      "x": 868,
      "y": 422
    },
    {
      "t": 72255,
      "e": 71837,
      "ty": 41,
      "x": 49841,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72304,
      "e": 71886,
      "ty": 2,
      "x": 863,
      "y": 418
    },
    {
      "t": 72379,
      "e": 71961,
      "ty": 3,
      "x": 863,
      "y": 418,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72380,
      "e": 71962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 72449,
      "e": 72031,
      "ty": 4,
      "x": 48671,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72450,
      "e": 72032,
      "ty": 5,
      "x": 863,
      "y": 418,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72450,
      "e": 72032,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 72451,
      "e": 72033,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 72504,
      "e": 72086,
      "ty": 41,
      "x": 48671,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72904,
      "e": 72486,
      "ty": 2,
      "x": 876,
      "y": 456
    },
    {
      "t": 73005,
      "e": 72587,
      "ty": 2,
      "x": 942,
      "y": 597
    },
    {
      "t": 73005,
      "e": 72587,
      "ty": 41,
      "x": 28616,
      "y": 32580,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 73105,
      "e": 72687,
      "ty": 2,
      "x": 965,
      "y": 662
    },
    {
      "t": 73205,
      "e": 72787,
      "ty": 2,
      "x": 965,
      "y": 723
    },
    {
      "t": 73255,
      "e": 72837,
      "ty": 41,
      "x": 36287,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 73305,
      "e": 72887,
      "ty": 2,
      "x": 966,
      "y": 723
    },
    {
      "t": 73505,
      "e": 73087,
      "ty": 2,
      "x": 967,
      "y": 720
    },
    {
      "t": 73505,
      "e": 73087,
      "ty": 41,
      "x": 34549,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 73605,
      "e": 73187,
      "ty": 2,
      "x": 970,
      "y": 707
    },
    {
      "t": 73704,
      "e": 73286,
      "ty": 2,
      "x": 975,
      "y": 688
    },
    {
      "t": 73755,
      "e": 73337,
      "ty": 41,
      "x": 36685,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 73805,
      "e": 73387,
      "ty": 2,
      "x": 976,
      "y": 686
    },
    {
      "t": 73905,
      "e": 73487,
      "ty": 2,
      "x": 975,
      "y": 690
    },
    {
      "t": 74005,
      "e": 73587,
      "ty": 2,
      "x": 975,
      "y": 693
    },
    {
      "t": 74005,
      "e": 73587,
      "ty": 41,
      "x": 38698,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74105,
      "e": 73687,
      "ty": 2,
      "x": 976,
      "y": 706
    },
    {
      "t": 74219,
      "e": 73801,
      "ty": 3,
      "x": 976,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74220,
      "e": 73802,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 74255,
      "e": 73837,
      "ty": 41,
      "x": 38950,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74257,
      "e": 73839,
      "ty": 4,
      "x": 38950,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74257,
      "e": 73839,
      "ty": 5,
      "x": 976,
      "y": 706,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74258,
      "e": 73840,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74259,
      "e": 73841,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 74259,
      "e": 73841,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 74505,
      "e": 74087,
      "ty": 2,
      "x": 978,
      "y": 708
    },
    {
      "t": 74506,
      "e": 74088,
      "ty": 41,
      "x": 39454,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74755,
      "e": 74337,
      "ty": 41,
      "x": 38295,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 74805,
      "e": 74387,
      "ty": 2,
      "x": 957,
      "y": 784
    },
    {
      "t": 74905,
      "e": 74487,
      "ty": 2,
      "x": 902,
      "y": 904
    },
    {
      "t": 75005,
      "e": 74587,
      "ty": 2,
      "x": 880,
      "y": 919
    },
    {
      "t": 75006,
      "e": 74588,
      "ty": 41,
      "x": 13902,
      "y": 22181,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 75105,
      "e": 74687,
      "ty": 2,
      "x": 861,
      "y": 931
    },
    {
      "t": 75205,
      "e": 74787,
      "ty": 2,
      "x": 858,
      "y": 933
    },
    {
      "t": 75219,
      "e": 74801,
      "ty": 3,
      "x": 858,
      "y": 933,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75220,
      "e": 74802,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 75255,
      "e": 74837,
      "ty": 41,
      "x": 39952,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75282,
      "e": 74864,
      "ty": 4,
      "x": 39952,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75283,
      "e": 74865,
      "ty": 5,
      "x": 858,
      "y": 933,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 75283,
      "e": 74865,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75285,
      "e": 74867,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 75405,
      "e": 74987,
      "ty": 2,
      "x": 859,
      "y": 936
    },
    {
      "t": 75505,
      "e": 75087,
      "ty": 2,
      "x": 900,
      "y": 998
    },
    {
      "t": 75505,
      "e": 75087,
      "ty": 41,
      "x": 18648,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 75509,
      "e": 75091,
      "ty": 6,
      "x": 905,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75605,
      "e": 75187,
      "ty": 2,
      "x": 914,
      "y": 1037
    },
    {
      "t": 75755,
      "e": 75337,
      "ty": 41,
      "x": 43590,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76026,
      "e": 75608,
      "ty": 3,
      "x": 914,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76028,
      "e": 75610,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 76028,
      "e": 75610,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76097,
      "e": 75679,
      "ty": 4,
      "x": 43590,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76098,
      "e": 75680,
      "ty": 5,
      "x": 914,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76100,
      "e": 75682,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76100,
      "e": 75682,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76102,
      "e": 75684,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 77444,
      "e": 77026,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 78105,
      "e": 77687,
      "ty": 2,
      "x": 902,
      "y": 992
    },
    {
      "t": 78205,
      "e": 77787,
      "ty": 2,
      "x": 892,
      "y": 843
    },
    {
      "t": 78255,
      "e": 77837,
      "ty": 41,
      "x": 28708,
      "y": 59400,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 78306,
      "e": 77888,
      "ty": 2,
      "x": 833,
      "y": 698
    },
    {
      "t": 78405,
      "e": 77987,
      "ty": 2,
      "x": 728,
      "y": 586
    },
    {
      "t": 78506,
      "e": 78088,
      "ty": 2,
      "x": 690,
      "y": 541
    },
    {
      "t": 78506,
      "e": 78088,
      "ty": 41,
      "x": 19508,
      "y": 22826,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78605,
      "e": 78187,
      "ty": 2,
      "x": 683,
      "y": 518
    },
    {
      "t": 78756,
      "e": 78338,
      "ty": 41,
      "x": 19164,
      "y": 13854,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 78805,
      "e": 78387,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 78905,
      "e": 78487,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 79805,
      "e": 79387,
      "ty": 2,
      "x": 685,
      "y": 541
    },
    {
      "t": 79905,
      "e": 79487,
      "ty": 2,
      "x": 719,
      "y": 595
    },
    {
      "t": 80005,
      "e": 79587,
      "ty": 2,
      "x": 909,
      "y": 911
    },
    {
      "t": 80005,
      "e": 79587,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80008,
      "e": 79590,
      "ty": 41,
      "x": 30283,
      "y": 54338,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80105,
      "e": 79687,
      "ty": 2,
      "x": 952,
      "y": 978
    },
    {
      "t": 80205,
      "e": 79787,
      "ty": 2,
      "x": 957,
      "y": 997
    },
    {
      "t": 80255,
      "e": 79837,
      "ty": 41,
      "x": 32792,
      "y": 63340,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80296,
      "e": 79878,
      "ty": 6,
      "x": 961,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 80305,
      "e": 79887,
      "ty": 2,
      "x": 961,
      "y": 1074
    },
    {
      "t": 80405,
      "e": 79987,
      "ty": 2,
      "x": 962,
      "y": 1091
    },
    {
      "t": 80474,
      "e": 80056,
      "ty": 7,
      "x": 962,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 80505,
      "e": 80087,
      "ty": 2,
      "x": 966,
      "y": 1118
    },
    {
      "t": 80505,
      "e": 80087,
      "ty": 41,
      "x": 35810,
      "y": 25102,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 80606,
      "e": 80188,
      "ty": 2,
      "x": 967,
      "y": 1121
    },
    {
      "t": 80756,
      "e": 80338,
      "ty": 41,
      "x": 36278,
      "y": 26764,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 80805,
      "e": 80387,
      "ty": 2,
      "x": 969,
      "y": 1120
    },
    {
      "t": 80905,
      "e": 80487,
      "ty": 2,
      "x": 971,
      "y": 1111
    },
    {
      "t": 81006,
      "e": 80588,
      "ty": 41,
      "x": 38150,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 81105,
      "e": 80687,
      "ty": 2,
      "x": 972,
      "y": 1110
    },
    {
      "t": 81130,
      "e": 80712,
      "ty": 6,
      "x": 973,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 81205,
      "e": 80787,
      "ty": 2,
      "x": 975,
      "y": 1100
    },
    {
      "t": 81251,
      "e": 80833,
      "ty": 3,
      "x": 975,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 81251,
      "e": 80833,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 81256,
      "e": 80838,
      "ty": 41,
      "x": 35771,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 81362,
      "e": 80944,
      "ty": 4,
      "x": 35771,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 81365,
      "e": 80947,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 81367,
      "e": 80949,
      "ty": 5,
      "x": 975,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 81368,
      "e": 80950,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 81705,
      "e": 81287,
      "ty": 2,
      "x": 983,
      "y": 1096
    },
    {
      "t": 81755,
      "e": 81337,
      "ty": 41,
      "x": 33680,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 81805,
      "e": 81387,
      "ty": 2,
      "x": 986,
      "y": 1094
    },
    {
      "t": 82411,
      "e": 81993,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 84263,
      "e": 83845,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 67194, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 67197, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 2551, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 71082, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 5259, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 77347, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 10349, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 88784, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 8986, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 98772, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 42994, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 143124, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-08 AM-11 AM-11 AM-A -1-C -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1091,y:1001,t:1527188717839};\\\", \\\"{x:1091,y:996,t:1527188717846};\\\", \\\"{x:1087,y:984,t:1527188717858};\\\", \\\"{x:1076,y:966,t:1527188717875};\\\", \\\"{x:1075,y:964,t:1527188717891};\\\", \\\"{x:1075,y:966,t:1527188718055};\\\", \\\"{x:1075,y:973,t:1527188718063};\\\", \\\"{x:1075,y:974,t:1527188718095};\\\", \\\"{x:1076,y:974,t:1527188718407};\\\", \\\"{x:1079,y:971,t:1527188718416};\\\", \\\"{x:1081,y:969,t:1527188718426};\\\", \\\"{x:1086,y:964,t:1527188718443};\\\", \\\"{x:1091,y:960,t:1527188718459};\\\", \\\"{x:1097,y:956,t:1527188718476};\\\", \\\"{x:1101,y:954,t:1527188718493};\\\", \\\"{x:1104,y:951,t:1527188718509};\\\", \\\"{x:1108,y:950,t:1527188718525};\\\", \\\"{x:1112,y:947,t:1527188718542};\\\", \\\"{x:1118,y:947,t:1527188718559};\\\", \\\"{x:1127,y:943,t:1527188718576};\\\", \\\"{x:1132,y:942,t:1527188718592};\\\", \\\"{x:1145,y:940,t:1527188718609};\\\", \\\"{x:1161,y:939,t:1527188718626};\\\", \\\"{x:1170,y:939,t:1527188718643};\\\", \\\"{x:1189,y:941,t:1527188718659};\\\", \\\"{x:1205,y:947,t:1527188718675};\\\", \\\"{x:1220,y:951,t:1527188718693};\\\", \\\"{x:1230,y:953,t:1527188718711};\\\", \\\"{x:1235,y:955,t:1527188718726};\\\", \\\"{x:1238,y:956,t:1527188718743};\\\", \\\"{x:1241,y:956,t:1527188719279};\\\", \\\"{x:1246,y:958,t:1527188719292};\\\", \\\"{x:1250,y:959,t:1527188719309};\\\", \\\"{x:1254,y:960,t:1527188719327};\\\", \\\"{x:1255,y:960,t:1527188719343};\\\", \\\"{x:1259,y:963,t:1527188719359};\\\", \\\"{x:1260,y:963,t:1527188719495};\\\", \\\"{x:1260,y:964,t:1527188719528};\\\", \\\"{x:1262,y:966,t:1527188719543};\\\", \\\"{x:1264,y:968,t:1527188719559};\\\", \\\"{x:1264,y:970,t:1527188719577};\\\", \\\"{x:1265,y:971,t:1527188719592};\\\", \\\"{x:1265,y:972,t:1527188719609};\\\", \\\"{x:1266,y:973,t:1527188720240};\\\", \\\"{x:1266,y:974,t:1527188720271};\\\", \\\"{x:1266,y:976,t:1527188720287};\\\", \\\"{x:1266,y:978,t:1527188720295};\\\", \\\"{x:1267,y:979,t:1527188720311};\\\", \\\"{x:1267,y:982,t:1527188720326};\\\", \\\"{x:1268,y:989,t:1527188720343};\\\", \\\"{x:1270,y:991,t:1527188720360};\\\", \\\"{x:1273,y:993,t:1527188720377};\\\", \\\"{x:1274,y:996,t:1527188720393};\\\", \\\"{x:1275,y:996,t:1527188720721};\\\", \\\"{x:1275,y:995,t:1527188720737};\\\", \\\"{x:1275,y:994,t:1527188720744};\\\", \\\"{x:1276,y:990,t:1527188720760};\\\", \\\"{x:1276,y:989,t:1527188720783};\\\", \\\"{x:1276,y:987,t:1527188720831};\\\", \\\"{x:1276,y:986,t:1527188720855};\\\", \\\"{x:1277,y:985,t:1527188720863};\\\", \\\"{x:1277,y:984,t:1527188720877};\\\", \\\"{x:1277,y:982,t:1527188720893};\\\", \\\"{x:1278,y:980,t:1527188720911};\\\", \\\"{x:1278,y:979,t:1527188720944};\\\", \\\"{x:1278,y:977,t:1527188720961};\\\", \\\"{x:1278,y:976,t:1527188720978};\\\", \\\"{x:1278,y:975,t:1527188720994};\\\", \\\"{x:1278,y:974,t:1527188721011};\\\", \\\"{x:1278,y:973,t:1527188721032};\\\", \\\"{x:1278,y:971,t:1527188721225};\\\", \\\"{x:1278,y:970,t:1527188721248};\\\", \\\"{x:1278,y:969,t:1527188721263};\\\", \\\"{x:1278,y:968,t:1527188721753};\\\", \\\"{x:1277,y:964,t:1527188721762};\\\", \\\"{x:1276,y:963,t:1527188721778};\\\", \\\"{x:1276,y:961,t:1527188721795};\\\", \\\"{x:1276,y:959,t:1527188721812};\\\", \\\"{x:1276,y:955,t:1527188721828};\\\", \\\"{x:1275,y:949,t:1527188721845};\\\", \\\"{x:1274,y:944,t:1527188721862};\\\", \\\"{x:1274,y:938,t:1527188721877};\\\", \\\"{x:1274,y:930,t:1527188721895};\\\", \\\"{x:1274,y:920,t:1527188721911};\\\", \\\"{x:1274,y:915,t:1527188721928};\\\", \\\"{x:1274,y:910,t:1527188721945};\\\", \\\"{x:1274,y:908,t:1527188721961};\\\", \\\"{x:1274,y:905,t:1527188721978};\\\", \\\"{x:1274,y:898,t:1527188721995};\\\", \\\"{x:1275,y:892,t:1527188722012};\\\", \\\"{x:1277,y:885,t:1527188722028};\\\", \\\"{x:1277,y:881,t:1527188722045};\\\", \\\"{x:1278,y:876,t:1527188722061};\\\", \\\"{x:1279,y:873,t:1527188722079};\\\", \\\"{x:1279,y:871,t:1527188722112};\\\", \\\"{x:1279,y:869,t:1527188722128};\\\", \\\"{x:1280,y:865,t:1527188722145};\\\", \\\"{x:1281,y:863,t:1527188722162};\\\", \\\"{x:1281,y:862,t:1527188722192};\\\", \\\"{x:1282,y:862,t:1527188722200};\\\", \\\"{x:1282,y:861,t:1527188722249};\\\", \\\"{x:1282,y:859,t:1527188722263};\\\", \\\"{x:1282,y:857,t:1527188722279};\\\", \\\"{x:1282,y:854,t:1527188722295};\\\", \\\"{x:1282,y:853,t:1527188722312};\\\", \\\"{x:1282,y:851,t:1527188722392};\\\", \\\"{x:1282,y:850,t:1527188722400};\\\", \\\"{x:1282,y:847,t:1527188722412};\\\", \\\"{x:1282,y:846,t:1527188722430};\\\", \\\"{x:1282,y:844,t:1527188722445};\\\", \\\"{x:1282,y:843,t:1527188722527};\\\", \\\"{x:1282,y:841,t:1527188722551};\\\", \\\"{x:1282,y:840,t:1527188722561};\\\", \\\"{x:1282,y:839,t:1527188722578};\\\", \\\"{x:1282,y:838,t:1527188722595};\\\", \\\"{x:1282,y:837,t:1527188722719};\\\", \\\"{x:1282,y:835,t:1527188723552};\\\", \\\"{x:1282,y:834,t:1527188723563};\\\", \\\"{x:1282,y:830,t:1527188723579};\\\", \\\"{x:1282,y:828,t:1527188723595};\\\", \\\"{x:1282,y:827,t:1527188723612};\\\", \\\"{x:1282,y:828,t:1527188736696};\\\", \\\"{x:1282,y:830,t:1527188736703};\\\", \\\"{x:1281,y:832,t:1527188736713};\\\", \\\"{x:1281,y:833,t:1527188736730};\\\", \\\"{x:1281,y:835,t:1527188736746};\\\", \\\"{x:1280,y:838,t:1527188736765};\\\", \\\"{x:1280,y:840,t:1527188736783};\\\", \\\"{x:1280,y:841,t:1527188736823};\\\", \\\"{x:1280,y:843,t:1527188736831};\\\", \\\"{x:1280,y:846,t:1527188736847};\\\", \\\"{x:1280,y:848,t:1527188736864};\\\", \\\"{x:1280,y:851,t:1527188736880};\\\", \\\"{x:1279,y:852,t:1527188736902};\\\", \\\"{x:1279,y:853,t:1527188736951};\\\", \\\"{x:1279,y:854,t:1527188736964};\\\", \\\"{x:1279,y:856,t:1527188736980};\\\", \\\"{x:1279,y:859,t:1527188736997};\\\", \\\"{x:1279,y:862,t:1527188737014};\\\", \\\"{x:1279,y:864,t:1527188737030};\\\", \\\"{x:1279,y:867,t:1527188737047};\\\", \\\"{x:1279,y:868,t:1527188737070};\\\", \\\"{x:1279,y:870,t:1527188737080};\\\", \\\"{x:1278,y:872,t:1527188737097};\\\", \\\"{x:1278,y:873,t:1527188737114};\\\", \\\"{x:1277,y:875,t:1527188737130};\\\", \\\"{x:1277,y:876,t:1527188737147};\\\", \\\"{x:1277,y:878,t:1527188737164};\\\", \\\"{x:1277,y:881,t:1527188737180};\\\", \\\"{x:1276,y:883,t:1527188737197};\\\", \\\"{x:1275,y:886,t:1527188737215};\\\", \\\"{x:1274,y:888,t:1527188737230};\\\", \\\"{x:1272,y:892,t:1527188737247};\\\", \\\"{x:1271,y:895,t:1527188737264};\\\", \\\"{x:1270,y:896,t:1527188737281};\\\", \\\"{x:1268,y:900,t:1527188737297};\\\", \\\"{x:1267,y:902,t:1527188737313};\\\", \\\"{x:1266,y:903,t:1527188737317};\\\", \\\"{x:1266,y:904,t:1527188737333};\\\", \\\"{x:1264,y:905,t:1527188737348};\\\", \\\"{x:1264,y:906,t:1527188737366};\\\", \\\"{x:1262,y:907,t:1527188737382};\\\", \\\"{x:1261,y:907,t:1527188737398};\\\", \\\"{x:1261,y:908,t:1527188737415};\\\", \\\"{x:1260,y:908,t:1527188737470};\\\", \\\"{x:1258,y:908,t:1527188737736};\\\", \\\"{x:1252,y:908,t:1527188737750};\\\", \\\"{x:1232,y:908,t:1527188737766};\\\", \\\"{x:1209,y:908,t:1527188737783};\\\", \\\"{x:1204,y:908,t:1527188737800};\\\", \\\"{x:1201,y:908,t:1527188737816};\\\", \\\"{x:1197,y:908,t:1527188737833};\\\", \\\"{x:1192,y:904,t:1527188737850};\\\", \\\"{x:1187,y:901,t:1527188737866};\\\", \\\"{x:1186,y:900,t:1527188737883};\\\", \\\"{x:1185,y:899,t:1527188737900};\\\", \\\"{x:1185,y:898,t:1527188738334};\\\", \\\"{x:1177,y:893,t:1527188738350};\\\", \\\"{x:1147,y:878,t:1527188738366};\\\", \\\"{x:1128,y:871,t:1527188738382};\\\", \\\"{x:1101,y:859,t:1527188738399};\\\", \\\"{x:1065,y:844,t:1527188738416};\\\", \\\"{x:1031,y:828,t:1527188738433};\\\", \\\"{x:979,y:805,t:1527188738449};\\\", \\\"{x:910,y:778,t:1527188738467};\\\", \\\"{x:841,y:745,t:1527188738483};\\\", \\\"{x:804,y:728,t:1527188738500};\\\", \\\"{x:787,y:720,t:1527188738517};\\\", \\\"{x:776,y:715,t:1527188738534};\\\", \\\"{x:772,y:710,t:1527188738549};\\\", \\\"{x:760,y:700,t:1527188738566};\\\", \\\"{x:742,y:693,t:1527188738584};\\\", \\\"{x:727,y:689,t:1527188738600};\\\", \\\"{x:699,y:684,t:1527188738617};\\\", \\\"{x:690,y:676,t:1527188738633};\\\", \\\"{x:682,y:667,t:1527188738649};\\\", \\\"{x:669,y:654,t:1527188738667};\\\", \\\"{x:650,y:649,t:1527188738684};\\\", \\\"{x:626,y:642,t:1527188738699};\\\", \\\"{x:617,y:638,t:1527188738717};\\\", \\\"{x:610,y:636,t:1527188738734};\\\", \\\"{x:601,y:633,t:1527188738750};\\\", \\\"{x:598,y:630,t:1527188738766};\\\", \\\"{x:595,y:627,t:1527188738783};\\\", \\\"{x:587,y:623,t:1527188738800};\\\", \\\"{x:580,y:618,t:1527188738817};\\\", \\\"{x:559,y:612,t:1527188738835};\\\", \\\"{x:535,y:607,t:1527188738849};\\\", \\\"{x:515,y:600,t:1527188738866};\\\", \\\"{x:494,y:592,t:1527188738886};\\\", \\\"{x:478,y:586,t:1527188738901};\\\", \\\"{x:465,y:580,t:1527188738917};\\\", \\\"{x:449,y:573,t:1527188738934};\\\", \\\"{x:426,y:563,t:1527188738949};\\\", \\\"{x:408,y:555,t:1527188738967};\\\", \\\"{x:396,y:550,t:1527188738983};\\\", \\\"{x:396,y:549,t:1527188739038};\\\", \\\"{x:396,y:548,t:1527188739051};\\\", \\\"{x:396,y:544,t:1527188739068};\\\", \\\"{x:396,y:539,t:1527188739085};\\\", \\\"{x:396,y:533,t:1527188739102};\\\", \\\"{x:396,y:531,t:1527188739116};\\\", \\\"{x:396,y:529,t:1527188739134};\\\", \\\"{x:396,y:528,t:1527188739151};\\\", \\\"{x:396,y:526,t:1527188739167};\\\", \\\"{x:396,y:525,t:1527188739190};\\\", \\\"{x:396,y:524,t:1527188745758};\\\", \\\"{x:398,y:524,t:1527188745772};\\\", \\\"{x:410,y:539,t:1527188745789};\\\", \\\"{x:439,y:564,t:1527188745805};\\\", \\\"{x:457,y:577,t:1527188745822};\\\", \\\"{x:473,y:585,t:1527188745840};\\\", \\\"{x:492,y:594,t:1527188745856};\\\", \\\"{x:505,y:601,t:1527188745873};\\\", \\\"{x:524,y:609,t:1527188745890};\\\", \\\"{x:541,y:619,t:1527188745906};\\\", \\\"{x:562,y:632,t:1527188745922};\\\", \\\"{x:579,y:640,t:1527188745939};\\\", \\\"{x:596,y:649,t:1527188745956};\\\", \\\"{x:615,y:656,t:1527188745973};\\\", \\\"{x:646,y:670,t:1527188745989};\\\", \\\"{x:664,y:681,t:1527188746005};\\\", \\\"{x:681,y:689,t:1527188746023};\\\", \\\"{x:699,y:700,t:1527188746039};\\\", \\\"{x:719,y:712,t:1527188746057};\\\", \\\"{x:746,y:728,t:1527188746073};\\\", \\\"{x:771,y:746,t:1527188746089};\\\", \\\"{x:793,y:763,t:1527188746107};\\\", \\\"{x:820,y:774,t:1527188746122};\\\", \\\"{x:846,y:786,t:1527188746139};\\\", \\\"{x:871,y:798,t:1527188746156};\\\", \\\"{x:920,y:819,t:1527188746173};\\\", \\\"{x:1016,y:864,t:1527188746189};\\\", \\\"{x:1063,y:884,t:1527188746206};\\\", \\\"{x:1087,y:891,t:1527188746224};\\\", \\\"{x:1103,y:894,t:1527188746240};\\\", \\\"{x:1116,y:896,t:1527188746257};\\\", \\\"{x:1121,y:897,t:1527188746273};\\\", \\\"{x:1122,y:897,t:1527188746318};\\\", \\\"{x:1125,y:897,t:1527188746334};\\\", \\\"{x:1130,y:897,t:1527188746342};\\\", \\\"{x:1136,y:897,t:1527188746357};\\\", \\\"{x:1166,y:898,t:1527188746374};\\\", \\\"{x:1188,y:898,t:1527188746390};\\\", \\\"{x:1213,y:898,t:1527188746407};\\\", \\\"{x:1234,y:895,t:1527188746424};\\\", \\\"{x:1247,y:891,t:1527188746440};\\\", \\\"{x:1253,y:889,t:1527188746456};\\\", \\\"{x:1257,y:887,t:1527188746474};\\\", \\\"{x:1261,y:886,t:1527188746491};\\\", \\\"{x:1263,y:885,t:1527188746506};\\\", \\\"{x:1264,y:884,t:1527188746524};\\\", \\\"{x:1265,y:883,t:1527188746541};\\\", \\\"{x:1268,y:881,t:1527188746558};\\\", \\\"{x:1270,y:880,t:1527188746574};\\\", \\\"{x:1272,y:878,t:1527188746591};\\\", \\\"{x:1273,y:877,t:1527188746608};\\\", \\\"{x:1277,y:875,t:1527188746624};\\\", \\\"{x:1286,y:874,t:1527188746641};\\\", \\\"{x:1301,y:871,t:1527188746658};\\\", \\\"{x:1312,y:869,t:1527188746674};\\\", \\\"{x:1322,y:866,t:1527188746691};\\\", \\\"{x:1330,y:863,t:1527188746708};\\\", \\\"{x:1330,y:862,t:1527188746824};\\\", \\\"{x:1330,y:861,t:1527188746831};\\\", \\\"{x:1330,y:859,t:1527188746842};\\\", \\\"{x:1321,y:855,t:1527188746859};\\\", \\\"{x:1307,y:852,t:1527188746876};\\\", \\\"{x:1286,y:848,t:1527188746892};\\\", \\\"{x:1270,y:842,t:1527188746908};\\\", \\\"{x:1249,y:837,t:1527188746924};\\\", \\\"{x:1230,y:830,t:1527188746941};\\\", \\\"{x:1223,y:825,t:1527188746958};\\\", \\\"{x:1216,y:821,t:1527188746975};\\\", \\\"{x:1210,y:818,t:1527188746992};\\\", \\\"{x:1206,y:816,t:1527188747009};\\\", \\\"{x:1201,y:814,t:1527188747025};\\\", \\\"{x:1195,y:810,t:1527188747042};\\\", \\\"{x:1191,y:810,t:1527188747059};\\\", \\\"{x:1188,y:810,t:1527188747074};\\\", \\\"{x:1185,y:809,t:1527188747091};\\\", \\\"{x:1183,y:809,t:1527188747109};\\\", \\\"{x:1181,y:808,t:1527188747126};\\\", \\\"{x:1179,y:807,t:1527188747141};\\\", \\\"{x:1177,y:807,t:1527188747158};\\\", \\\"{x:1174,y:806,t:1527188747176};\\\", \\\"{x:1168,y:806,t:1527188747192};\\\", \\\"{x:1160,y:805,t:1527188747208};\\\", \\\"{x:1157,y:804,t:1527188747226};\\\", \\\"{x:1155,y:804,t:1527188747241};\\\", \\\"{x:1154,y:804,t:1527188747259};\\\", \\\"{x:1153,y:804,t:1527188747276};\\\", \\\"{x:1153,y:805,t:1527188747870};\\\", \\\"{x:1154,y:810,t:1527188747877};\\\", \\\"{x:1161,y:820,t:1527188747894};\\\", \\\"{x:1169,y:830,t:1527188747910};\\\", \\\"{x:1177,y:838,t:1527188747926};\\\", \\\"{x:1187,y:844,t:1527188747944};\\\", \\\"{x:1196,y:850,t:1527188747961};\\\", \\\"{x:1204,y:853,t:1527188747977};\\\", \\\"{x:1207,y:855,t:1527188747994};\\\", \\\"{x:1210,y:858,t:1527188748010};\\\", \\\"{x:1217,y:862,t:1527188748027};\\\", \\\"{x:1227,y:867,t:1527188748044};\\\", \\\"{x:1238,y:872,t:1527188748061};\\\", \\\"{x:1253,y:878,t:1527188748077};\\\", \\\"{x:1262,y:882,t:1527188748093};\\\", \\\"{x:1269,y:885,t:1527188748111};\\\", \\\"{x:1272,y:887,t:1527188748128};\\\", \\\"{x:1275,y:889,t:1527188748144};\\\", \\\"{x:1276,y:890,t:1527188748161};\\\", \\\"{x:1280,y:892,t:1527188748178};\\\", \\\"{x:1281,y:893,t:1527188748194};\\\", \\\"{x:1282,y:893,t:1527188748211};\\\", \\\"{x:1284,y:893,t:1527188748228};\\\", \\\"{x:1286,y:893,t:1527188748245};\\\", \\\"{x:1293,y:896,t:1527188748260};\\\", \\\"{x:1313,y:904,t:1527188748278};\\\", \\\"{x:1328,y:909,t:1527188748295};\\\", \\\"{x:1345,y:915,t:1527188748310};\\\", \\\"{x:1361,y:920,t:1527188748327};\\\", \\\"{x:1374,y:925,t:1527188748345};\\\", \\\"{x:1385,y:930,t:1527188748360};\\\", \\\"{x:1389,y:932,t:1527188748377};\\\", \\\"{x:1397,y:935,t:1527188748395};\\\", \\\"{x:1399,y:935,t:1527188748412};\\\", \\\"{x:1400,y:935,t:1527188748427};\\\", \\\"{x:1398,y:933,t:1527188748623};\\\", \\\"{x:1395,y:931,t:1527188748630};\\\", \\\"{x:1393,y:931,t:1527188748645};\\\", \\\"{x:1385,y:927,t:1527188748663};\\\", \\\"{x:1382,y:925,t:1527188748679};\\\", \\\"{x:1381,y:925,t:1527188748703};\\\", \\\"{x:1380,y:924,t:1527188748719};\\\", \\\"{x:1379,y:924,t:1527188748742};\\\", \\\"{x:1378,y:923,t:1527188748767};\\\", \\\"{x:1376,y:923,t:1527188748807};\\\", \\\"{x:1376,y:922,t:1527188748822};\\\", \\\"{x:1375,y:921,t:1527188748830};\\\", \\\"{x:1375,y:920,t:1527188748847};\\\", \\\"{x:1373,y:918,t:1527188748862};\\\", \\\"{x:1370,y:917,t:1527188748879};\\\", \\\"{x:1369,y:916,t:1527188749247};\\\", \\\"{x:1367,y:915,t:1527188749263};\\\", \\\"{x:1364,y:914,t:1527188749280};\\\", \\\"{x:1360,y:912,t:1527188749297};\\\", \\\"{x:1357,y:911,t:1527188749314};\\\", \\\"{x:1356,y:911,t:1527188749331};\\\", \\\"{x:1355,y:911,t:1527188749348};\\\", \\\"{x:1353,y:911,t:1527188749365};\\\", \\\"{x:1351,y:911,t:1527188749391};\\\", \\\"{x:1349,y:911,t:1527188749406};\\\", \\\"{x:1349,y:912,t:1527188749415};\\\", \\\"{x:1344,y:913,t:1527188749431};\\\", \\\"{x:1339,y:916,t:1527188749447};\\\", \\\"{x:1333,y:920,t:1527188749464};\\\", \\\"{x:1329,y:920,t:1527188749481};\\\", \\\"{x:1322,y:924,t:1527188749498};\\\", \\\"{x:1318,y:927,t:1527188749514};\\\", \\\"{x:1313,y:931,t:1527188749531};\\\", \\\"{x:1308,y:938,t:1527188749547};\\\", \\\"{x:1300,y:948,t:1527188749565};\\\", \\\"{x:1300,y:950,t:1527188749581};\\\", \\\"{x:1298,y:954,t:1527188749597};\\\", \\\"{x:1298,y:957,t:1527188749615};\\\", \\\"{x:1297,y:959,t:1527188749631};\\\", \\\"{x:1297,y:960,t:1527188749649};\\\", \\\"{x:1297,y:961,t:1527188749727};\\\", \\\"{x:1297,y:962,t:1527188749735};\\\", \\\"{x:1297,y:963,t:1527188749749};\\\", \\\"{x:1297,y:964,t:1527188749764};\\\", \\\"{x:1297,y:965,t:1527188749781};\\\", \\\"{x:1297,y:966,t:1527188749799};\\\", \\\"{x:1297,y:967,t:1527188749815};\\\", \\\"{x:1297,y:969,t:1527188749832};\\\", \\\"{x:1296,y:971,t:1527188749848};\\\", \\\"{x:1296,y:972,t:1527188749866};\\\", \\\"{x:1294,y:972,t:1527188749895};\\\", \\\"{x:1293,y:972,t:1527188749935};\\\", \\\"{x:1291,y:972,t:1527188749951};\\\", \\\"{x:1290,y:972,t:1527188750111};\\\", \\\"{x:1289,y:971,t:1527188750119};\\\", \\\"{x:1288,y:970,t:1527188750142};\\\", \\\"{x:1287,y:969,t:1527188750166};\\\", \\\"{x:1287,y:968,t:1527188750213};\\\", \\\"{x:1285,y:968,t:1527188750286};\\\", \\\"{x:1283,y:968,t:1527188750317};\\\", \\\"{x:1282,y:967,t:1527188750342};\\\", \\\"{x:1281,y:966,t:1527188750349};\\\", \\\"{x:1280,y:965,t:1527188750365};\\\", \\\"{x:1278,y:963,t:1527188750534};\\\", \\\"{x:1278,y:962,t:1527188750550};\\\", \\\"{x:1278,y:961,t:1527188750566};\\\", \\\"{x:1277,y:960,t:1527188750582};\\\", \\\"{x:1276,y:958,t:1527188750766};\\\", \\\"{x:1274,y:957,t:1527188751518};\\\", \\\"{x:1267,y:951,t:1527188751535};\\\", \\\"{x:1248,y:943,t:1527188751552};\\\", \\\"{x:1215,y:927,t:1527188751568};\\\", \\\"{x:1149,y:897,t:1527188751585};\\\", \\\"{x:1039,y:853,t:1527188751602};\\\", \\\"{x:924,y:807,t:1527188751618};\\\", \\\"{x:797,y:751,t:1527188751634};\\\", \\\"{x:681,y:701,t:1527188751651};\\\", \\\"{x:587,y:661,t:1527188751669};\\\", \\\"{x:523,y:630,t:1527188751685};\\\", \\\"{x:490,y:613,t:1527188751702};\\\", \\\"{x:485,y:608,t:1527188751719};\\\", \\\"{x:484,y:606,t:1527188751739};\\\", \\\"{x:484,y:604,t:1527188751755};\\\", \\\"{x:484,y:603,t:1527188751772};\\\", \\\"{x:484,y:605,t:1527188751845};\\\", \\\"{x:484,y:610,t:1527188751855};\\\", \\\"{x:484,y:620,t:1527188751872};\\\", \\\"{x:489,y:628,t:1527188751889};\\\", \\\"{x:497,y:640,t:1527188751911};\\\", \\\"{x:500,y:648,t:1527188751928};\\\", \\\"{x:501,y:652,t:1527188751944};\\\", \\\"{x:504,y:658,t:1527188751961};\\\", \\\"{x:506,y:667,t:1527188751978};\\\", \\\"{x:509,y:681,t:1527188751994};\\\", \\\"{x:510,y:686,t:1527188752011};\\\", \\\"{x:512,y:687,t:1527188752030};\\\", \\\"{x:512,y:688,t:1527188752045};\\\", \\\"{x:513,y:690,t:1527188752078};\\\", \\\"{x:513,y:692,t:1527188752101};\\\", \\\"{x:514,y:693,t:1527188752117};\\\", \\\"{x:514,y:694,t:1527188752182};\\\", \\\"{x:514,y:695,t:1527188752194};\\\", \\\"{x:514,y:697,t:1527188752213};\\\", \\\"{x:515,y:698,t:1527188752227};\\\", \\\"{x:515,y:699,t:1527188752245};\\\", \\\"{x:516,y:699,t:1527188752260};\\\", \\\"{x:517,y:700,t:1527188752278};\\\", \\\"{x:518,y:702,t:1527188752295};\\\", \\\"{x:520,y:704,t:1527188752318};\\\", \\\"{x:521,y:705,t:1527188752328};\\\", \\\"{x:523,y:708,t:1527188752345};\\\", \\\"{x:525,y:710,t:1527188752362};\\\", \\\"{x:526,y:711,t:1527188752378};\\\", \\\"{x:527,y:712,t:1527188752438};\\\", \\\"{x:529,y:713,t:1527188752461};\\\", \\\"{x:530,y:715,t:1527188752479};\\\", \\\"{x:531,y:715,t:1527188752501};\\\" ] }, { \\\"rt\\\": 16299, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 160669, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -E -E -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:715,t:1527188760686};\\\", \\\"{x:539,y:716,t:1527188760700};\\\", \\\"{x:573,y:722,t:1527188760718};\\\", \\\"{x:596,y:730,t:1527188760734};\\\", \\\"{x:621,y:733,t:1527188760752};\\\", \\\"{x:641,y:737,t:1527188760768};\\\", \\\"{x:656,y:739,t:1527188760785};\\\", \\\"{x:665,y:741,t:1527188760801};\\\", \\\"{x:669,y:741,t:1527188760818};\\\", \\\"{x:672,y:741,t:1527188760835};\\\", \\\"{x:673,y:741,t:1527188760852};\\\", \\\"{x:676,y:741,t:1527188760868};\\\", \\\"{x:688,y:741,t:1527188760885};\\\", \\\"{x:698,y:743,t:1527188760901};\\\", \\\"{x:711,y:746,t:1527188760918};\\\", \\\"{x:729,y:748,t:1527188760935};\\\", \\\"{x:751,y:753,t:1527188760952};\\\", \\\"{x:775,y:760,t:1527188760968};\\\", \\\"{x:803,y:769,t:1527188760985};\\\", \\\"{x:840,y:774,t:1527188761002};\\\", \\\"{x:876,y:778,t:1527188761018};\\\", \\\"{x:919,y:785,t:1527188761035};\\\", \\\"{x:960,y:790,t:1527188761052};\\\", \\\"{x:1042,y:801,t:1527188761069};\\\", \\\"{x:1109,y:810,t:1527188761086};\\\", \\\"{x:1160,y:821,t:1527188761102};\\\", \\\"{x:1212,y:830,t:1527188761120};\\\", \\\"{x:1264,y:836,t:1527188761136};\\\", \\\"{x:1295,y:840,t:1527188761153};\\\", \\\"{x:1328,y:840,t:1527188761169};\\\", \\\"{x:1340,y:847,t:1527188761185};\\\", \\\"{x:1349,y:848,t:1527188761202};\\\", \\\"{x:1350,y:848,t:1527188761219};\\\", \\\"{x:1350,y:847,t:1527188761983};\\\", \\\"{x:1349,y:847,t:1527188761998};\\\", \\\"{x:1348,y:846,t:1527188762007};\\\", \\\"{x:1347,y:846,t:1527188762039};\\\", \\\"{x:1346,y:846,t:1527188762054};\\\", \\\"{x:1344,y:845,t:1527188762070};\\\", \\\"{x:1343,y:844,t:1527188762093};\\\", \\\"{x:1342,y:843,t:1527188762118};\\\", \\\"{x:1341,y:842,t:1527188762157};\\\", \\\"{x:1339,y:841,t:1527188762174};\\\", \\\"{x:1338,y:839,t:1527188762189};\\\", \\\"{x:1337,y:837,t:1527188762203};\\\", \\\"{x:1334,y:831,t:1527188762220};\\\", \\\"{x:1330,y:825,t:1527188762236};\\\", \\\"{x:1325,y:816,t:1527188762253};\\\", \\\"{x:1321,y:811,t:1527188762270};\\\", \\\"{x:1318,y:804,t:1527188762286};\\\", \\\"{x:1314,y:796,t:1527188762303};\\\", \\\"{x:1312,y:787,t:1527188762320};\\\", \\\"{x:1308,y:778,t:1527188762336};\\\", \\\"{x:1305,y:773,t:1527188762353};\\\", \\\"{x:1304,y:767,t:1527188762371};\\\", \\\"{x:1303,y:762,t:1527188762387};\\\", \\\"{x:1303,y:756,t:1527188762403};\\\", \\\"{x:1302,y:751,t:1527188762420};\\\", \\\"{x:1300,y:743,t:1527188762437};\\\", \\\"{x:1300,y:740,t:1527188762453};\\\", \\\"{x:1300,y:736,t:1527188762470};\\\", \\\"{x:1300,y:733,t:1527188762488};\\\", \\\"{x:1300,y:730,t:1527188762503};\\\", \\\"{x:1300,y:729,t:1527188762533};\\\", \\\"{x:1300,y:728,t:1527188762541};\\\", \\\"{x:1300,y:727,t:1527188762557};\\\", \\\"{x:1300,y:725,t:1527188762581};\\\", \\\"{x:1301,y:723,t:1527188762590};\\\", \\\"{x:1302,y:722,t:1527188762606};\\\", \\\"{x:1305,y:719,t:1527188762620};\\\", \\\"{x:1310,y:717,t:1527188762638};\\\", \\\"{x:1314,y:715,t:1527188762653};\\\", \\\"{x:1322,y:712,t:1527188762670};\\\", \\\"{x:1330,y:710,t:1527188762687};\\\", \\\"{x:1335,y:709,t:1527188762704};\\\", \\\"{x:1340,y:706,t:1527188762720};\\\", \\\"{x:1342,y:706,t:1527188762737};\\\", \\\"{x:1344,y:704,t:1527188762754};\\\", \\\"{x:1347,y:702,t:1527188762770};\\\", \\\"{x:1350,y:702,t:1527188762787};\\\", \\\"{x:1359,y:699,t:1527188762804};\\\", \\\"{x:1371,y:696,t:1527188762820};\\\", \\\"{x:1394,y:696,t:1527188762837};\\\", \\\"{x:1411,y:696,t:1527188762855};\\\", \\\"{x:1422,y:697,t:1527188762870};\\\", \\\"{x:1433,y:700,t:1527188762888};\\\", \\\"{x:1441,y:700,t:1527188762904};\\\", \\\"{x:1450,y:700,t:1527188762920};\\\", \\\"{x:1454,y:700,t:1527188762938};\\\", \\\"{x:1457,y:700,t:1527188762954};\\\", \\\"{x:1458,y:700,t:1527188762970};\\\", \\\"{x:1461,y:700,t:1527188762987};\\\", \\\"{x:1463,y:700,t:1527188763004};\\\", \\\"{x:1468,y:700,t:1527188763022};\\\", \\\"{x:1475,y:701,t:1527188763038};\\\", \\\"{x:1483,y:702,t:1527188763054};\\\", \\\"{x:1489,y:702,t:1527188763072};\\\", \\\"{x:1496,y:702,t:1527188763087};\\\", \\\"{x:1500,y:702,t:1527188763104};\\\", \\\"{x:1502,y:702,t:1527188763121};\\\", \\\"{x:1504,y:702,t:1527188763137};\\\", \\\"{x:1506,y:702,t:1527188763154};\\\", \\\"{x:1510,y:701,t:1527188763171};\\\", \\\"{x:1513,y:699,t:1527188763187};\\\", \\\"{x:1518,y:699,t:1527188763204};\\\", \\\"{x:1525,y:699,t:1527188763221};\\\", \\\"{x:1531,y:696,t:1527188763238};\\\", \\\"{x:1534,y:696,t:1527188763255};\\\", \\\"{x:1540,y:696,t:1527188763272};\\\", \\\"{x:1547,y:696,t:1527188763288};\\\", \\\"{x:1552,y:696,t:1527188763304};\\\", \\\"{x:1554,y:696,t:1527188763321};\\\", \\\"{x:1556,y:696,t:1527188763341};\\\", \\\"{x:1558,y:696,t:1527188763354};\\\", \\\"{x:1564,y:693,t:1527188763371};\\\", \\\"{x:1570,y:691,t:1527188763388};\\\", \\\"{x:1579,y:687,t:1527188763404};\\\", \\\"{x:1594,y:680,t:1527188763422};\\\", \\\"{x:1598,y:677,t:1527188763438};\\\", \\\"{x:1603,y:674,t:1527188763456};\\\", \\\"{x:1607,y:670,t:1527188763471};\\\", \\\"{x:1616,y:663,t:1527188763489};\\\", \\\"{x:1629,y:650,t:1527188763505};\\\", \\\"{x:1636,y:642,t:1527188763521};\\\", \\\"{x:1640,y:639,t:1527188763539};\\\", \\\"{x:1641,y:637,t:1527188763554};\\\", \\\"{x:1643,y:634,t:1527188763572};\\\", \\\"{x:1644,y:632,t:1527188763588};\\\", \\\"{x:1644,y:631,t:1527188763605};\\\", \\\"{x:1645,y:631,t:1527188763622};\\\", \\\"{x:1645,y:634,t:1527188763911};\\\", \\\"{x:1645,y:640,t:1527188763923};\\\", \\\"{x:1645,y:649,t:1527188763938};\\\", \\\"{x:1645,y:656,t:1527188763956};\\\", \\\"{x:1645,y:658,t:1527188763972};\\\", \\\"{x:1645,y:660,t:1527188763989};\\\", \\\"{x:1645,y:664,t:1527188764006};\\\", \\\"{x:1645,y:671,t:1527188764022};\\\", \\\"{x:1645,y:678,t:1527188764038};\\\", \\\"{x:1646,y:681,t:1527188764056};\\\", \\\"{x:1648,y:687,t:1527188764073};\\\", \\\"{x:1648,y:688,t:1527188764088};\\\", \\\"{x:1649,y:690,t:1527188764106};\\\", \\\"{x:1650,y:693,t:1527188764123};\\\", \\\"{x:1652,y:698,t:1527188764139};\\\", \\\"{x:1653,y:700,t:1527188764156};\\\", \\\"{x:1653,y:701,t:1527188764247};\\\", \\\"{x:1653,y:695,t:1527188764256};\\\", \\\"{x:1651,y:679,t:1527188764272};\\\", \\\"{x:1648,y:664,t:1527188764289};\\\", \\\"{x:1642,y:647,t:1527188764305};\\\", \\\"{x:1636,y:632,t:1527188764322};\\\", \\\"{x:1632,y:622,t:1527188764339};\\\", \\\"{x:1631,y:616,t:1527188764355};\\\", \\\"{x:1629,y:609,t:1527188764372};\\\", \\\"{x:1622,y:592,t:1527188764389};\\\", \\\"{x:1620,y:576,t:1527188764406};\\\", \\\"{x:1616,y:554,t:1527188764422};\\\", \\\"{x:1614,y:539,t:1527188764440};\\\", \\\"{x:1612,y:528,t:1527188764455};\\\", \\\"{x:1611,y:521,t:1527188764473};\\\", \\\"{x:1610,y:512,t:1527188764490};\\\", \\\"{x:1608,y:505,t:1527188764505};\\\", \\\"{x:1608,y:495,t:1527188764522};\\\", \\\"{x:1608,y:482,t:1527188764539};\\\", \\\"{x:1608,y:471,t:1527188764556};\\\", \\\"{x:1608,y:463,t:1527188764573};\\\", \\\"{x:1608,y:455,t:1527188764590};\\\", \\\"{x:1608,y:452,t:1527188764606};\\\", \\\"{x:1609,y:447,t:1527188764622};\\\", \\\"{x:1609,y:445,t:1527188764639};\\\", \\\"{x:1609,y:441,t:1527188764657};\\\", \\\"{x:1609,y:439,t:1527188764672};\\\", \\\"{x:1609,y:436,t:1527188764690};\\\", \\\"{x:1609,y:435,t:1527188764706};\\\", \\\"{x:1609,y:438,t:1527188764806};\\\", \\\"{x:1609,y:448,t:1527188764823};\\\", \\\"{x:1609,y:470,t:1527188764840};\\\", \\\"{x:1609,y:497,t:1527188764857};\\\", \\\"{x:1614,y:528,t:1527188764872};\\\", \\\"{x:1620,y:558,t:1527188764889};\\\", \\\"{x:1625,y:580,t:1527188764906};\\\", \\\"{x:1627,y:597,t:1527188764924};\\\", \\\"{x:1632,y:612,t:1527188764939};\\\", \\\"{x:1633,y:623,t:1527188764957};\\\", \\\"{x:1633,y:637,t:1527188764974};\\\", \\\"{x:1633,y:642,t:1527188764989};\\\", \\\"{x:1633,y:645,t:1527188765006};\\\", \\\"{x:1633,y:646,t:1527188765023};\\\", \\\"{x:1633,y:647,t:1527188765069};\\\", \\\"{x:1631,y:649,t:1527188765077};\\\", \\\"{x:1630,y:648,t:1527188765327};\\\", \\\"{x:1629,y:643,t:1527188765340};\\\", \\\"{x:1627,y:637,t:1527188765357};\\\", \\\"{x:1623,y:622,t:1527188765374};\\\", \\\"{x:1621,y:605,t:1527188765390};\\\", \\\"{x:1617,y:586,t:1527188765406};\\\", \\\"{x:1616,y:569,t:1527188765424};\\\", \\\"{x:1616,y:550,t:1527188765441};\\\", \\\"{x:1612,y:532,t:1527188765457};\\\", \\\"{x:1612,y:512,t:1527188765473};\\\", \\\"{x:1611,y:498,t:1527188765491};\\\", \\\"{x:1611,y:487,t:1527188765507};\\\", \\\"{x:1612,y:473,t:1527188765524};\\\", \\\"{x:1612,y:461,t:1527188765541};\\\", \\\"{x:1613,y:450,t:1527188765558};\\\", \\\"{x:1613,y:446,t:1527188765574};\\\", \\\"{x:1613,y:444,t:1527188765590};\\\", \\\"{x:1613,y:441,t:1527188765608};\\\", \\\"{x:1613,y:440,t:1527188765630};\\\", \\\"{x:1613,y:438,t:1527188765663};\\\", \\\"{x:1613,y:437,t:1527188766255};\\\", \\\"{x:1613,y:435,t:1527188766262};\\\", \\\"{x:1613,y:433,t:1527188766292};\\\", \\\"{x:1614,y:431,t:1527188766308};\\\", \\\"{x:1615,y:430,t:1527188766326};\\\", \\\"{x:1615,y:429,t:1527188766350};\\\", \\\"{x:1615,y:430,t:1527188766559};\\\", \\\"{x:1615,y:440,t:1527188766576};\\\", \\\"{x:1616,y:450,t:1527188766592};\\\", \\\"{x:1618,y:454,t:1527188766609};\\\", \\\"{x:1619,y:457,t:1527188766625};\\\", \\\"{x:1619,y:459,t:1527188766654};\\\", \\\"{x:1619,y:460,t:1527188766662};\\\", \\\"{x:1619,y:462,t:1527188766675};\\\", \\\"{x:1619,y:467,t:1527188766692};\\\", \\\"{x:1621,y:472,t:1527188766709};\\\", \\\"{x:1621,y:478,t:1527188766725};\\\", \\\"{x:1621,y:490,t:1527188766743};\\\", \\\"{x:1621,y:495,t:1527188766759};\\\", \\\"{x:1621,y:499,t:1527188766776};\\\", \\\"{x:1621,y:501,t:1527188766792};\\\", \\\"{x:1621,y:505,t:1527188766809};\\\", \\\"{x:1621,y:510,t:1527188766826};\\\", \\\"{x:1621,y:515,t:1527188766842};\\\", \\\"{x:1622,y:521,t:1527188766859};\\\", \\\"{x:1622,y:533,t:1527188766876};\\\", \\\"{x:1622,y:544,t:1527188766892};\\\", \\\"{x:1623,y:551,t:1527188766909};\\\", \\\"{x:1623,y:557,t:1527188766926};\\\", \\\"{x:1624,y:562,t:1527188766942};\\\", \\\"{x:1625,y:567,t:1527188766959};\\\", \\\"{x:1625,y:573,t:1527188766976};\\\", \\\"{x:1625,y:577,t:1527188766992};\\\", \\\"{x:1625,y:581,t:1527188767009};\\\", \\\"{x:1625,y:583,t:1527188767026};\\\", \\\"{x:1625,y:584,t:1527188767042};\\\", \\\"{x:1625,y:585,t:1527188767058};\\\", \\\"{x:1625,y:587,t:1527188767087};\\\", \\\"{x:1625,y:588,t:1527188767094};\\\", \\\"{x:1625,y:590,t:1527188767110};\\\", \\\"{x:1625,y:594,t:1527188767127};\\\", \\\"{x:1625,y:597,t:1527188767143};\\\", \\\"{x:1625,y:602,t:1527188767159};\\\", \\\"{x:1625,y:606,t:1527188767176};\\\", \\\"{x:1625,y:613,t:1527188767193};\\\", \\\"{x:1624,y:621,t:1527188767209};\\\", \\\"{x:1624,y:630,t:1527188767227};\\\", \\\"{x:1624,y:643,t:1527188767244};\\\", \\\"{x:1624,y:654,t:1527188767259};\\\", \\\"{x:1623,y:667,t:1527188767276};\\\", \\\"{x:1623,y:675,t:1527188767293};\\\", \\\"{x:1623,y:683,t:1527188767309};\\\", \\\"{x:1623,y:696,t:1527188767327};\\\", \\\"{x:1623,y:703,t:1527188767342};\\\", \\\"{x:1625,y:711,t:1527188767359};\\\", \\\"{x:1626,y:727,t:1527188767376};\\\", \\\"{x:1628,y:743,t:1527188767393};\\\", \\\"{x:1628,y:756,t:1527188767410};\\\", \\\"{x:1628,y:765,t:1527188767426};\\\", \\\"{x:1629,y:777,t:1527188767443};\\\", \\\"{x:1629,y:785,t:1527188767460};\\\", \\\"{x:1630,y:792,t:1527188767476};\\\", \\\"{x:1630,y:797,t:1527188767493};\\\", \\\"{x:1630,y:801,t:1527188767510};\\\", \\\"{x:1632,y:804,t:1527188767526};\\\", \\\"{x:1632,y:808,t:1527188767543};\\\", \\\"{x:1633,y:813,t:1527188767560};\\\", \\\"{x:1633,y:817,t:1527188767576};\\\", \\\"{x:1634,y:823,t:1527188767593};\\\", \\\"{x:1636,y:831,t:1527188767610};\\\", \\\"{x:1636,y:836,t:1527188767626};\\\", \\\"{x:1637,y:840,t:1527188767643};\\\", \\\"{x:1638,y:846,t:1527188767660};\\\", \\\"{x:1640,y:852,t:1527188767676};\\\", \\\"{x:1642,y:861,t:1527188767692};\\\", \\\"{x:1644,y:870,t:1527188767710};\\\", \\\"{x:1645,y:879,t:1527188767726};\\\", \\\"{x:1646,y:886,t:1527188767743};\\\", \\\"{x:1646,y:893,t:1527188767760};\\\", \\\"{x:1648,y:897,t:1527188767777};\\\", \\\"{x:1648,y:903,t:1527188767794};\\\", \\\"{x:1649,y:908,t:1527188767810};\\\", \\\"{x:1653,y:912,t:1527188767827};\\\", \\\"{x:1653,y:914,t:1527188767843};\\\", \\\"{x:1653,y:915,t:1527188767860};\\\", \\\"{x:1653,y:916,t:1527188767877};\\\", \\\"{x:1653,y:915,t:1527188767982};\\\", \\\"{x:1647,y:909,t:1527188767993};\\\", \\\"{x:1629,y:892,t:1527188768010};\\\", \\\"{x:1583,y:864,t:1527188768027};\\\", \\\"{x:1523,y:829,t:1527188768044};\\\", \\\"{x:1446,y:797,t:1527188768060};\\\", \\\"{x:1371,y:763,t:1527188768077};\\\", \\\"{x:1284,y:724,t:1527188768093};\\\", \\\"{x:1237,y:706,t:1527188768110};\\\", \\\"{x:1203,y:694,t:1527188768126};\\\", \\\"{x:1185,y:686,t:1527188768144};\\\", \\\"{x:1176,y:680,t:1527188768160};\\\", \\\"{x:1169,y:675,t:1527188768177};\\\", \\\"{x:1158,y:667,t:1527188768193};\\\", \\\"{x:1137,y:657,t:1527188768209};\\\", \\\"{x:1115,y:649,t:1527188768226};\\\", \\\"{x:1094,y:643,t:1527188768243};\\\", \\\"{x:1072,y:639,t:1527188768259};\\\", \\\"{x:1048,y:635,t:1527188768276};\\\", \\\"{x:1003,y:628,t:1527188768293};\\\", \\\"{x:966,y:622,t:1527188768310};\\\", \\\"{x:927,y:618,t:1527188768327};\\\", \\\"{x:896,y:615,t:1527188768343};\\\", \\\"{x:885,y:614,t:1527188768361};\\\", \\\"{x:879,y:614,t:1527188768376};\\\", \\\"{x:874,y:614,t:1527188768393};\\\", \\\"{x:872,y:614,t:1527188768410};\\\", \\\"{x:866,y:614,t:1527188768426};\\\", \\\"{x:862,y:614,t:1527188768443};\\\", \\\"{x:845,y:614,t:1527188768460};\\\", \\\"{x:820,y:610,t:1527188768477};\\\", \\\"{x:788,y:603,t:1527188768493};\\\", \\\"{x:772,y:602,t:1527188768510};\\\", \\\"{x:766,y:602,t:1527188768524};\\\", \\\"{x:756,y:602,t:1527188768541};\\\", \\\"{x:751,y:602,t:1527188768557};\\\", \\\"{x:749,y:601,t:1527188768574};\\\", \\\"{x:744,y:601,t:1527188768591};\\\", \\\"{x:739,y:601,t:1527188768607};\\\", \\\"{x:728,y:601,t:1527188768625};\\\", \\\"{x:722,y:601,t:1527188768642};\\\", \\\"{x:716,y:601,t:1527188768657};\\\", \\\"{x:712,y:601,t:1527188768674};\\\", \\\"{x:708,y:601,t:1527188768691};\\\", \\\"{x:704,y:601,t:1527188768709};\\\", \\\"{x:700,y:601,t:1527188768724};\\\", \\\"{x:694,y:601,t:1527188768741};\\\", \\\"{x:690,y:601,t:1527188768758};\\\", \\\"{x:686,y:601,t:1527188768775};\\\", \\\"{x:683,y:601,t:1527188768798};\\\", \\\"{x:677,y:604,t:1527188768808};\\\", \\\"{x:668,y:605,t:1527188768825};\\\", \\\"{x:660,y:606,t:1527188768842};\\\", \\\"{x:658,y:606,t:1527188768859};\\\", \\\"{x:657,y:606,t:1527188768876};\\\", \\\"{x:655,y:606,t:1527188768901};\\\", \\\"{x:654,y:606,t:1527188768917};\\\", \\\"{x:653,y:607,t:1527188768925};\\\", \\\"{x:650,y:607,t:1527188768942};\\\", \\\"{x:641,y:609,t:1527188768958};\\\", \\\"{x:623,y:609,t:1527188768976};\\\", \\\"{x:606,y:609,t:1527188768991};\\\", \\\"{x:576,y:609,t:1527188769009};\\\", \\\"{x:536,y:609,t:1527188769025};\\\", \\\"{x:495,y:609,t:1527188769043};\\\", \\\"{x:464,y:609,t:1527188769059};\\\", \\\"{x:437,y:609,t:1527188769076};\\\", \\\"{x:412,y:612,t:1527188769092};\\\", \\\"{x:381,y:613,t:1527188769109};\\\", \\\"{x:338,y:616,t:1527188769125};\\\", \\\"{x:323,y:619,t:1527188769142};\\\", \\\"{x:311,y:620,t:1527188769158};\\\", \\\"{x:307,y:621,t:1527188769175};\\\", \\\"{x:301,y:625,t:1527188769192};\\\", \\\"{x:296,y:627,t:1527188769209};\\\", \\\"{x:287,y:628,t:1527188769225};\\\", \\\"{x:277,y:632,t:1527188769241};\\\", \\\"{x:263,y:634,t:1527188769258};\\\", \\\"{x:256,y:636,t:1527188769275};\\\", \\\"{x:252,y:637,t:1527188769292};\\\", \\\"{x:246,y:637,t:1527188769308};\\\", \\\"{x:237,y:640,t:1527188769326};\\\", \\\"{x:230,y:642,t:1527188769342};\\\", \\\"{x:218,y:645,t:1527188769358};\\\", \\\"{x:210,y:646,t:1527188769375};\\\", \\\"{x:209,y:646,t:1527188769392};\\\", \\\"{x:207,y:646,t:1527188769409};\\\", \\\"{x:207,y:647,t:1527188769686};\\\", \\\"{x:212,y:650,t:1527188769693};\\\", \\\"{x:222,y:655,t:1527188769711};\\\", \\\"{x:266,y:669,t:1527188769726};\\\", \\\"{x:328,y:690,t:1527188769742};\\\", \\\"{x:380,y:702,t:1527188769760};\\\", \\\"{x:416,y:715,t:1527188769775};\\\", \\\"{x:454,y:729,t:1527188769792};\\\", \\\"{x:481,y:737,t:1527188769810};\\\", \\\"{x:497,y:744,t:1527188769825};\\\", \\\"{x:505,y:745,t:1527188769842};\\\", \\\"{x:506,y:745,t:1527188769860};\\\", \\\"{x:507,y:745,t:1527188769941};\\\", \\\"{x:508,y:745,t:1527188769965};\\\", \\\"{x:509,y:745,t:1527188769981};\\\", \\\"{x:509,y:744,t:1527188770005};\\\", \\\"{x:509,y:741,t:1527188770022};\\\", \\\"{x:508,y:740,t:1527188770029};\\\", \\\"{x:508,y:739,t:1527188770069};\\\", \\\"{x:507,y:739,t:1527188770078};\\\", \\\"{x:507,y:738,t:1527188770134};\\\", \\\"{x:506,y:737,t:1527188770157};\\\", \\\"{x:505,y:737,t:1527188770174};\\\", \\\"{x:503,y:737,t:1527188770902};\\\", \\\"{x:496,y:737,t:1527188770910};\\\", \\\"{x:482,y:733,t:1527188770928};\\\", \\\"{x:468,y:730,t:1527188770943};\\\", \\\"{x:443,y:726,t:1527188770961};\\\", \\\"{x:419,y:718,t:1527188770977};\\\", \\\"{x:398,y:716,t:1527188770994};\\\", \\\"{x:376,y:712,t:1527188771010};\\\", \\\"{x:357,y:707,t:1527188771026};\\\", \\\"{x:339,y:704,t:1527188771044};\\\", \\\"{x:322,y:701,t:1527188771061};\\\", \\\"{x:310,y:699,t:1527188771077};\\\", \\\"{x:305,y:697,t:1527188771093};\\\", \\\"{x:304,y:696,t:1527188771125};\\\", \\\"{x:303,y:695,t:1527188771133};\\\", \\\"{x:301,y:695,t:1527188771143};\\\", \\\"{x:294,y:692,t:1527188771161};\\\", \\\"{x:285,y:690,t:1527188771176};\\\", \\\"{x:271,y:686,t:1527188771194};\\\", \\\"{x:258,y:681,t:1527188771211};\\\", \\\"{x:243,y:676,t:1527188771227};\\\", \\\"{x:230,y:669,t:1527188771244};\\\", \\\"{x:215,y:663,t:1527188771261};\\\", \\\"{x:207,y:658,t:1527188771277};\\\", \\\"{x:201,y:657,t:1527188771294};\\\", \\\"{x:200,y:655,t:1527188771311};\\\", \\\"{x:199,y:655,t:1527188771382};\\\", \\\"{x:198,y:655,t:1527188771397};\\\", \\\"{x:198,y:654,t:1527188771411};\\\", \\\"{x:196,y:654,t:1527188771428};\\\", \\\"{x:191,y:652,t:1527188771444};\\\", \\\"{x:185,y:650,t:1527188771462};\\\", \\\"{x:176,y:647,t:1527188771477};\\\", \\\"{x:168,y:646,t:1527188771493};\\\", \\\"{x:167,y:646,t:1527188771510};\\\", \\\"{x:166,y:645,t:1527188771573};\\\", \\\"{x:166,y:644,t:1527188771589};\\\", \\\"{x:165,y:643,t:1527188771597};\\\", \\\"{x:164,y:640,t:1527188771610};\\\", \\\"{x:162,y:638,t:1527188771627};\\\", \\\"{x:160,y:637,t:1527188771644};\\\", \\\"{x:160,y:636,t:1527188771661};\\\", \\\"{x:166,y:637,t:1527188772045};\\\", \\\"{x:175,y:640,t:1527188772061};\\\", \\\"{x:222,y:661,t:1527188772078};\\\", \\\"{x:278,y:675,t:1527188772094};\\\", \\\"{x:339,y:693,t:1527188772111};\\\", \\\"{x:394,y:709,t:1527188772128};\\\", \\\"{x:427,y:719,t:1527188772145};\\\", \\\"{x:449,y:722,t:1527188772162};\\\", \\\"{x:461,y:724,t:1527188772178};\\\", \\\"{x:466,y:724,t:1527188772194};\\\", \\\"{x:468,y:724,t:1527188772211};\\\", \\\"{x:469,y:724,t:1527188772245};\\\", \\\"{x:469,y:722,t:1527188772294};\\\", \\\"{x:471,y:721,t:1527188772302};\\\", \\\"{x:472,y:720,t:1527188772312};\\\", \\\"{x:476,y:718,t:1527188772327};\\\" ] }, { \\\"rt\\\": 16058, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 177943, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:717,t:1527188778261};\\\", \\\"{x:479,y:717,t:1527188778269};\\\", \\\"{x:493,y:717,t:1527188778285};\\\", \\\"{x:515,y:720,t:1527188778302};\\\", \\\"{x:545,y:725,t:1527188778318};\\\", \\\"{x:584,y:731,t:1527188778337};\\\", \\\"{x:630,y:735,t:1527188778353};\\\", \\\"{x:685,y:746,t:1527188778368};\\\", \\\"{x:744,y:756,t:1527188778383};\\\", \\\"{x:798,y:767,t:1527188778399};\\\", \\\"{x:851,y:775,t:1527188778417};\\\", \\\"{x:894,y:782,t:1527188778433};\\\", \\\"{x:941,y:794,t:1527188778449};\\\", \\\"{x:973,y:799,t:1527188778466};\\\", \\\"{x:1012,y:808,t:1527188778482};\\\", \\\"{x:1052,y:816,t:1527188778500};\\\", \\\"{x:1089,y:822,t:1527188778517};\\\", \\\"{x:1137,y:833,t:1527188778532};\\\", \\\"{x:1162,y:836,t:1527188778550};\\\", \\\"{x:1183,y:841,t:1527188778567};\\\", \\\"{x:1206,y:844,t:1527188778583};\\\", \\\"{x:1226,y:851,t:1527188778600};\\\", \\\"{x:1245,y:856,t:1527188778617};\\\", \\\"{x:1264,y:858,t:1527188778633};\\\", \\\"{x:1281,y:860,t:1527188778649};\\\", \\\"{x:1290,y:861,t:1527188778667};\\\", \\\"{x:1291,y:861,t:1527188778685};\\\", \\\"{x:1292,y:861,t:1527188779053};\\\", \\\"{x:1293,y:861,t:1527188779069};\\\", \\\"{x:1294,y:861,t:1527188779109};\\\", \\\"{x:1295,y:861,t:1527188779117};\\\", \\\"{x:1296,y:861,t:1527188779134};\\\", \\\"{x:1297,y:861,t:1527188779150};\\\", \\\"{x:1297,y:860,t:1527188779174};\\\", \\\"{x:1297,y:859,t:1527188779189};\\\", \\\"{x:1296,y:858,t:1527188779366};\\\", \\\"{x:1294,y:858,t:1527188779373};\\\", \\\"{x:1291,y:857,t:1527188779383};\\\", \\\"{x:1288,y:855,t:1527188779401};\\\", \\\"{x:1279,y:852,t:1527188779416};\\\", \\\"{x:1272,y:850,t:1527188779433};\\\", \\\"{x:1265,y:848,t:1527188779451};\\\", \\\"{x:1258,y:847,t:1527188779467};\\\", \\\"{x:1253,y:846,t:1527188779484};\\\", \\\"{x:1245,y:845,t:1527188779501};\\\", \\\"{x:1243,y:845,t:1527188779517};\\\", \\\"{x:1240,y:844,t:1527188779533};\\\", \\\"{x:1237,y:843,t:1527188779551};\\\", \\\"{x:1236,y:842,t:1527188779566};\\\", \\\"{x:1235,y:842,t:1527188779584};\\\", \\\"{x:1234,y:841,t:1527188779601};\\\", \\\"{x:1233,y:840,t:1527188779617};\\\", \\\"{x:1231,y:839,t:1527188779634};\\\", \\\"{x:1230,y:838,t:1527188779653};\\\", \\\"{x:1230,y:837,t:1527188779669};\\\", \\\"{x:1230,y:836,t:1527188779701};\\\", \\\"{x:1229,y:836,t:1527188779813};\\\", \\\"{x:1228,y:836,t:1527188779822};\\\", \\\"{x:1225,y:833,t:1527188779834};\\\", \\\"{x:1223,y:833,t:1527188779851};\\\", \\\"{x:1219,y:831,t:1527188779869};\\\", \\\"{x:1217,y:831,t:1527188779884};\\\", \\\"{x:1216,y:830,t:1527188779901};\\\", \\\"{x:1215,y:830,t:1527188780046};\\\", \\\"{x:1214,y:829,t:1527188780102};\\\", \\\"{x:1213,y:829,t:1527188780470};\\\", \\\"{x:1212,y:829,t:1527188780958};\\\", \\\"{x:1216,y:829,t:1527188782589};\\\", \\\"{x:1219,y:830,t:1527188782605};\\\", \\\"{x:1220,y:830,t:1527188782620};\\\", \\\"{x:1222,y:830,t:1527188782637};\\\", \\\"{x:1231,y:833,t:1527188782653};\\\", \\\"{x:1240,y:836,t:1527188782669};\\\", \\\"{x:1250,y:841,t:1527188782686};\\\", \\\"{x:1259,y:844,t:1527188782702};\\\", \\\"{x:1272,y:851,t:1527188782720};\\\", \\\"{x:1281,y:854,t:1527188782736};\\\", \\\"{x:1287,y:859,t:1527188782753};\\\", \\\"{x:1290,y:860,t:1527188782769};\\\", \\\"{x:1292,y:862,t:1527188782786};\\\", \\\"{x:1293,y:862,t:1527188782803};\\\", \\\"{x:1293,y:864,t:1527188782820};\\\", \\\"{x:1294,y:867,t:1527188782836};\\\", \\\"{x:1299,y:877,t:1527188782853};\\\", \\\"{x:1303,y:884,t:1527188782870};\\\", \\\"{x:1305,y:887,t:1527188782886};\\\", \\\"{x:1305,y:888,t:1527188782917};\\\", \\\"{x:1307,y:889,t:1527188782933};\\\", \\\"{x:1307,y:891,t:1527188782941};\\\", \\\"{x:1309,y:894,t:1527188782953};\\\", \\\"{x:1313,y:898,t:1527188782969};\\\", \\\"{x:1314,y:902,t:1527188782986};\\\", \\\"{x:1314,y:903,t:1527188783003};\\\", \\\"{x:1315,y:904,t:1527188783069};\\\", \\\"{x:1317,y:904,t:1527188783109};\\\", \\\"{x:1321,y:904,t:1527188783120};\\\", \\\"{x:1324,y:904,t:1527188783137};\\\", \\\"{x:1327,y:904,t:1527188783153};\\\", \\\"{x:1330,y:904,t:1527188783170};\\\", \\\"{x:1331,y:903,t:1527188783252};\\\", \\\"{x:1331,y:902,t:1527188783276};\\\", \\\"{x:1331,y:901,t:1527188783293};\\\", \\\"{x:1331,y:900,t:1527188783309};\\\", \\\"{x:1332,y:899,t:1527188783333};\\\", \\\"{x:1332,y:898,t:1527188783438};\\\", \\\"{x:1332,y:896,t:1527188783454};\\\", \\\"{x:1332,y:895,t:1527188783477};\\\", \\\"{x:1332,y:894,t:1527188783493};\\\", \\\"{x:1334,y:893,t:1527188783606};\\\", \\\"{x:1335,y:893,t:1527188783621};\\\", \\\"{x:1337,y:893,t:1527188783636};\\\", \\\"{x:1339,y:893,t:1527188783654};\\\", \\\"{x:1340,y:893,t:1527188783677};\\\", \\\"{x:1341,y:893,t:1527188784045};\\\", \\\"{x:1342,y:893,t:1527188784053};\\\", \\\"{x:1344,y:893,t:1527188784093};\\\", \\\"{x:1342,y:890,t:1527188784373};\\\", \\\"{x:1336,y:887,t:1527188784386};\\\", \\\"{x:1317,y:882,t:1527188784404};\\\", \\\"{x:1267,y:865,t:1527188784421};\\\", \\\"{x:1206,y:848,t:1527188784437};\\\", \\\"{x:1149,y:828,t:1527188784454};\\\", \\\"{x:1091,y:803,t:1527188784471};\\\", \\\"{x:1045,y:779,t:1527188784487};\\\", \\\"{x:1003,y:758,t:1527188784504};\\\", \\\"{x:954,y:732,t:1527188784521};\\\", \\\"{x:908,y:705,t:1527188784538};\\\", \\\"{x:878,y:687,t:1527188784554};\\\", \\\"{x:860,y:672,t:1527188784571};\\\", \\\"{x:846,y:663,t:1527188784588};\\\", \\\"{x:837,y:659,t:1527188784604};\\\", \\\"{x:820,y:655,t:1527188784621};\\\", \\\"{x:803,y:652,t:1527188784638};\\\", \\\"{x:783,y:649,t:1527188784654};\\\", \\\"{x:761,y:648,t:1527188784671};\\\", \\\"{x:733,y:643,t:1527188784687};\\\", \\\"{x:693,y:636,t:1527188784706};\\\", \\\"{x:665,y:633,t:1527188784721};\\\", \\\"{x:632,y:627,t:1527188784738};\\\", \\\"{x:585,y:616,t:1527188784755};\\\", \\\"{x:526,y:608,t:1527188784773};\\\", \\\"{x:477,y:604,t:1527188784788};\\\", \\\"{x:419,y:594,t:1527188784805};\\\", \\\"{x:397,y:589,t:1527188784822};\\\", \\\"{x:364,y:580,t:1527188784839};\\\", \\\"{x:316,y:573,t:1527188784855};\\\", \\\"{x:289,y:570,t:1527188784872};\\\", \\\"{x:269,y:565,t:1527188784889};\\\", \\\"{x:266,y:565,t:1527188784905};\\\", \\\"{x:268,y:574,t:1527188785053};\\\", \\\"{x:272,y:584,t:1527188785063};\\\", \\\"{x:273,y:591,t:1527188785072};\\\", \\\"{x:274,y:604,t:1527188785088};\\\", \\\"{x:274,y:611,t:1527188785105};\\\", \\\"{x:273,y:617,t:1527188785122};\\\", \\\"{x:268,y:619,t:1527188785138};\\\", \\\"{x:265,y:619,t:1527188785156};\\\", \\\"{x:263,y:619,t:1527188785173};\\\", \\\"{x:260,y:617,t:1527188785189};\\\", \\\"{x:259,y:616,t:1527188785206};\\\", \\\"{x:257,y:614,t:1527188785221};\\\", \\\"{x:257,y:613,t:1527188785238};\\\", \\\"{x:261,y:613,t:1527188785341};\\\", \\\"{x:272,y:614,t:1527188785356};\\\", \\\"{x:301,y:621,t:1527188785374};\\\", \\\"{x:311,y:622,t:1527188785388};\\\", \\\"{x:312,y:622,t:1527188785405};\\\", \\\"{x:312,y:621,t:1527188785453};\\\", \\\"{x:305,y:619,t:1527188785469};\\\", \\\"{x:290,y:615,t:1527188785477};\\\", \\\"{x:277,y:611,t:1527188785489};\\\", \\\"{x:251,y:604,t:1527188785506};\\\", \\\"{x:224,y:596,t:1527188785522};\\\", \\\"{x:186,y:585,t:1527188785539};\\\", \\\"{x:162,y:574,t:1527188785556};\\\", \\\"{x:146,y:566,t:1527188785572};\\\", \\\"{x:139,y:560,t:1527188785588};\\\", \\\"{x:138,y:560,t:1527188785606};\\\", \\\"{x:138,y:559,t:1527188785645};\\\", \\\"{x:138,y:558,t:1527188785709};\\\", \\\"{x:138,y:556,t:1527188785749};\\\", \\\"{x:139,y:556,t:1527188785893};\\\", \\\"{x:141,y:556,t:1527188785917};\\\", \\\"{x:142,y:556,t:1527188785933};\\\", \\\"{x:143,y:557,t:1527188785949};\\\", \\\"{x:144,y:557,t:1527188785981};\\\", \\\"{x:144,y:557,t:1527188786102};\\\", \\\"{x:145,y:557,t:1527188787052};\\\", \\\"{x:155,y:561,t:1527188787061};\\\", \\\"{x:175,y:569,t:1527188787073};\\\", \\\"{x:236,y:595,t:1527188787091};\\\", \\\"{x:302,y:622,t:1527188787108};\\\", \\\"{x:352,y:645,t:1527188787124};\\\", \\\"{x:376,y:655,t:1527188787140};\\\", \\\"{x:395,y:663,t:1527188787156};\\\", \\\"{x:396,y:664,t:1527188787181};\\\", \\\"{x:395,y:664,t:1527188787213};\\\", \\\"{x:393,y:664,t:1527188787224};\\\", \\\"{x:387,y:661,t:1527188787239};\\\", \\\"{x:384,y:658,t:1527188787257};\\\", \\\"{x:380,y:655,t:1527188787274};\\\", \\\"{x:373,y:650,t:1527188787290};\\\", \\\"{x:361,y:643,t:1527188787307};\\\", \\\"{x:347,y:635,t:1527188787324};\\\", \\\"{x:330,y:626,t:1527188787339};\\\", \\\"{x:299,y:610,t:1527188787358};\\\", \\\"{x:284,y:604,t:1527188787374};\\\", \\\"{x:279,y:602,t:1527188787390};\\\", \\\"{x:276,y:601,t:1527188787407};\\\", \\\"{x:275,y:601,t:1527188787424};\\\", \\\"{x:274,y:600,t:1527188787461};\\\", \\\"{x:273,y:599,t:1527188787474};\\\", \\\"{x:267,y:596,t:1527188787491};\\\", \\\"{x:262,y:592,t:1527188787507};\\\", \\\"{x:259,y:591,t:1527188787524};\\\", \\\"{x:257,y:589,t:1527188787541};\\\", \\\"{x:254,y:588,t:1527188787557};\\\", \\\"{x:252,y:587,t:1527188787573};\\\", \\\"{x:250,y:586,t:1527188787591};\\\", \\\"{x:242,y:584,t:1527188787607};\\\", \\\"{x:236,y:582,t:1527188787624};\\\", \\\"{x:229,y:578,t:1527188787641};\\\", \\\"{x:219,y:573,t:1527188787658};\\\", \\\"{x:213,y:568,t:1527188787674};\\\", \\\"{x:206,y:565,t:1527188787690};\\\", \\\"{x:200,y:563,t:1527188787707};\\\", \\\"{x:195,y:561,t:1527188787724};\\\", \\\"{x:190,y:560,t:1527188787741};\\\", \\\"{x:189,y:560,t:1527188787757};\\\", \\\"{x:189,y:559,t:1527188787829};\\\", \\\"{x:191,y:563,t:1527188788245};\\\", \\\"{x:203,y:574,t:1527188788258};\\\", \\\"{x:232,y:593,t:1527188788274};\\\", \\\"{x:264,y:620,t:1527188788292};\\\", \\\"{x:306,y:646,t:1527188788309};\\\", \\\"{x:359,y:676,t:1527188788325};\\\", \\\"{x:380,y:686,t:1527188788341};\\\", \\\"{x:393,y:692,t:1527188788358};\\\", \\\"{x:404,y:697,t:1527188788374};\\\", \\\"{x:413,y:704,t:1527188788391};\\\", \\\"{x:418,y:706,t:1527188788408};\\\", \\\"{x:422,y:708,t:1527188788425};\\\", \\\"{x:424,y:709,t:1527188788445};\\\", \\\"{x:426,y:709,t:1527188788461};\\\", \\\"{x:428,y:709,t:1527188788475};\\\", \\\"{x:432,y:709,t:1527188788491};\\\", \\\"{x:436,y:711,t:1527188788508};\\\", \\\"{x:440,y:712,t:1527188788525};\\\", \\\"{x:441,y:712,t:1527188788541};\\\", \\\"{x:442,y:712,t:1527188788558};\\\", \\\"{x:445,y:712,t:1527188788598};\\\", \\\"{x:447,y:712,t:1527188788608};\\\", \\\"{x:456,y:712,t:1527188788625};\\\", \\\"{x:464,y:712,t:1527188788642};\\\", \\\"{x:468,y:712,t:1527188788658};\\\", \\\"{x:473,y:713,t:1527188788675};\\\", \\\"{x:475,y:713,t:1527188789806};\\\", \\\"{x:476,y:715,t:1527188789822};\\\", \\\"{x:477,y:716,t:1527188789846};\\\", \\\"{x:478,y:716,t:1527188789864};\\\", \\\"{x:478,y:717,t:1527188789880};\\\", \\\"{x:479,y:718,t:1527188789897};\\\", \\\"{x:479,y:719,t:1527188789989};\\\", \\\"{x:479,y:720,t:1527188790005};\\\", \\\"{x:479,y:721,t:1527188790021};\\\", \\\"{x:479,y:722,t:1527188790030};\\\", \\\"{x:479,y:723,t:1527188790047};\\\", \\\"{x:479,y:724,t:1527188790069};\\\" ] }, { \\\"rt\\\": 24901, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 204055, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-04 PM-U -F -A -F -O -Z -Z -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:728,t:1527188794697};\\\", \\\"{x:501,y:736,t:1527188794716};\\\", \\\"{x:509,y:740,t:1527188794720};\\\", \\\"{x:521,y:744,t:1527188794734};\\\", \\\"{x:544,y:752,t:1527188794750};\\\", \\\"{x:566,y:761,t:1527188794767};\\\", \\\"{x:588,y:772,t:1527188794784};\\\", \\\"{x:607,y:779,t:1527188794800};\\\", \\\"{x:638,y:790,t:1527188794817};\\\", \\\"{x:662,y:801,t:1527188794835};\\\", \\\"{x:687,y:806,t:1527188794850};\\\", \\\"{x:714,y:814,t:1527188794868};\\\", \\\"{x:752,y:827,t:1527188794885};\\\", \\\"{x:799,y:849,t:1527188794900};\\\", \\\"{x:844,y:864,t:1527188794917};\\\", \\\"{x:889,y:877,t:1527188794934};\\\", \\\"{x:949,y:891,t:1527188794951};\\\", \\\"{x:1011,y:908,t:1527188794968};\\\", \\\"{x:1075,y:929,t:1527188794984};\\\", \\\"{x:1179,y:950,t:1527188795000};\\\", \\\"{x:1242,y:967,t:1527188795018};\\\", \\\"{x:1288,y:976,t:1527188795035};\\\", \\\"{x:1319,y:982,t:1527188795051};\\\", \\\"{x:1345,y:987,t:1527188795068};\\\", \\\"{x:1369,y:994,t:1527188795084};\\\", \\\"{x:1387,y:999,t:1527188795101};\\\", \\\"{x:1400,y:1002,t:1527188795118};\\\", \\\"{x:1405,y:1003,t:1527188795135};\\\", \\\"{x:1407,y:1003,t:1527188795150};\\\", \\\"{x:1408,y:1003,t:1527188795168};\\\", \\\"{x:1411,y:1003,t:1527188795184};\\\", \\\"{x:1418,y:1004,t:1527188795201};\\\", \\\"{x:1422,y:1004,t:1527188795218};\\\", \\\"{x:1427,y:1004,t:1527188795234};\\\", \\\"{x:1430,y:1004,t:1527188795251};\\\", \\\"{x:1436,y:1004,t:1527188795267};\\\", \\\"{x:1448,y:1004,t:1527188795284};\\\", \\\"{x:1468,y:1007,t:1527188795301};\\\", \\\"{x:1489,y:1008,t:1527188795317};\\\", \\\"{x:1509,y:1009,t:1527188795334};\\\", \\\"{x:1531,y:1011,t:1527188795351};\\\", \\\"{x:1548,y:1011,t:1527188795368};\\\", \\\"{x:1564,y:1011,t:1527188795385};\\\", \\\"{x:1578,y:1011,t:1527188795400};\\\", \\\"{x:1581,y:1011,t:1527188795418};\\\", \\\"{x:1583,y:1011,t:1527188795435};\\\", \\\"{x:1585,y:1011,t:1527188795473};\\\", \\\"{x:1587,y:1011,t:1527188795489};\\\", \\\"{x:1588,y:1011,t:1527188795502};\\\", \\\"{x:1591,y:1011,t:1527188795518};\\\", \\\"{x:1593,y:1011,t:1527188795535};\\\", \\\"{x:1597,y:1009,t:1527188795552};\\\", \\\"{x:1599,y:1008,t:1527188795569};\\\", \\\"{x:1602,y:1005,t:1527188795585};\\\", \\\"{x:1604,y:1004,t:1527188795602};\\\", \\\"{x:1605,y:1002,t:1527188795619};\\\", \\\"{x:1605,y:1001,t:1527188795665};\\\", \\\"{x:1605,y:999,t:1527188795680};\\\", \\\"{x:1606,y:999,t:1527188795688};\\\", \\\"{x:1606,y:997,t:1527188795702};\\\", \\\"{x:1606,y:993,t:1527188795719};\\\", \\\"{x:1608,y:991,t:1527188795734};\\\", \\\"{x:1608,y:988,t:1527188795751};\\\", \\\"{x:1608,y:986,t:1527188795768};\\\", \\\"{x:1608,y:985,t:1527188795785};\\\", \\\"{x:1608,y:983,t:1527188795801};\\\", \\\"{x:1608,y:982,t:1527188795818};\\\", \\\"{x:1608,y:981,t:1527188795857};\\\", \\\"{x:1608,y:980,t:1527188795869};\\\", \\\"{x:1608,y:979,t:1527188795921};\\\", \\\"{x:1608,y:977,t:1527188795985};\\\", \\\"{x:1609,y:976,t:1527188796018};\\\", \\\"{x:1609,y:974,t:1527188796050};\\\", \\\"{x:1610,y:974,t:1527188796057};\\\", \\\"{x:1610,y:973,t:1527188796069};\\\", \\\"{x:1611,y:971,t:1527188796089};\\\", \\\"{x:1612,y:970,t:1527188796129};\\\", \\\"{x:1612,y:968,t:1527188796138};\\\", \\\"{x:1612,y:966,t:1527188796153};\\\", \\\"{x:1613,y:966,t:1527188796168};\\\", \\\"{x:1614,y:964,t:1527188796185};\\\", \\\"{x:1614,y:963,t:1527188796201};\\\", \\\"{x:1611,y:960,t:1527188799346};\\\", \\\"{x:1603,y:957,t:1527188799355};\\\", \\\"{x:1590,y:951,t:1527188799370};\\\", \\\"{x:1582,y:949,t:1527188799387};\\\", \\\"{x:1576,y:947,t:1527188799405};\\\", \\\"{x:1573,y:946,t:1527188799421};\\\", \\\"{x:1571,y:945,t:1527188799437};\\\", \\\"{x:1570,y:945,t:1527188799457};\\\", \\\"{x:1568,y:943,t:1527188799793};\\\", \\\"{x:1565,y:941,t:1527188799804};\\\", \\\"{x:1559,y:937,t:1527188799822};\\\", \\\"{x:1550,y:933,t:1527188799839};\\\", \\\"{x:1533,y:923,t:1527188799854};\\\", \\\"{x:1518,y:912,t:1527188799872};\\\", \\\"{x:1495,y:898,t:1527188799888};\\\", \\\"{x:1479,y:887,t:1527188799904};\\\", \\\"{x:1468,y:881,t:1527188799921};\\\", \\\"{x:1461,y:877,t:1527188799938};\\\", \\\"{x:1460,y:876,t:1527188799954};\\\", \\\"{x:1457,y:873,t:1527188799972};\\\", \\\"{x:1456,y:871,t:1527188799989};\\\", \\\"{x:1456,y:869,t:1527188800004};\\\", \\\"{x:1455,y:869,t:1527188800021};\\\", \\\"{x:1454,y:868,t:1527188800039};\\\", \\\"{x:1454,y:867,t:1527188800057};\\\", \\\"{x:1454,y:865,t:1527188800072};\\\", \\\"{x:1455,y:859,t:1527188800089};\\\", \\\"{x:1458,y:854,t:1527188800105};\\\", \\\"{x:1459,y:850,t:1527188800122};\\\", \\\"{x:1461,y:847,t:1527188800139};\\\", \\\"{x:1462,y:846,t:1527188800155};\\\", \\\"{x:1463,y:846,t:1527188800171};\\\", \\\"{x:1463,y:844,t:1527188800225};\\\", \\\"{x:1464,y:844,t:1527188800257};\\\", \\\"{x:1464,y:843,t:1527188800272};\\\", \\\"{x:1465,y:843,t:1527188800289};\\\", \\\"{x:1466,y:840,t:1527188800306};\\\", \\\"{x:1468,y:838,t:1527188800322};\\\", \\\"{x:1468,y:837,t:1527188800339};\\\", \\\"{x:1469,y:835,t:1527188800356};\\\", \\\"{x:1471,y:835,t:1527188800372};\\\", \\\"{x:1471,y:834,t:1527188800389};\\\", \\\"{x:1472,y:834,t:1527188800406};\\\", \\\"{x:1472,y:833,t:1527188800425};\\\", \\\"{x:1474,y:833,t:1527188800522};\\\", \\\"{x:1476,y:833,t:1527188800539};\\\", \\\"{x:1477,y:833,t:1527188800558};\\\", \\\"{x:1479,y:833,t:1527188800571};\\\", \\\"{x:1480,y:833,t:1527188800589};\\\", \\\"{x:1481,y:833,t:1527188801306};\\\", \\\"{x:1481,y:832,t:1527188801689};\\\", \\\"{x:1480,y:831,t:1527188802121};\\\", \\\"{x:1471,y:830,t:1527188802129};\\\", \\\"{x:1460,y:826,t:1527188802141};\\\", \\\"{x:1436,y:823,t:1527188802157};\\\", \\\"{x:1403,y:819,t:1527188802174};\\\", \\\"{x:1362,y:811,t:1527188802190};\\\", \\\"{x:1312,y:803,t:1527188802207};\\\", \\\"{x:1256,y:796,t:1527188802224};\\\", \\\"{x:1189,y:787,t:1527188802240};\\\", \\\"{x:1089,y:757,t:1527188802257};\\\", \\\"{x:1031,y:731,t:1527188802273};\\\", \\\"{x:1005,y:717,t:1527188802289};\\\", \\\"{x:975,y:700,t:1527188802307};\\\", \\\"{x:961,y:689,t:1527188802324};\\\", \\\"{x:955,y:683,t:1527188802340};\\\", \\\"{x:946,y:675,t:1527188802356};\\\", \\\"{x:939,y:668,t:1527188802374};\\\", \\\"{x:929,y:662,t:1527188802389};\\\", \\\"{x:916,y:656,t:1527188802406};\\\", \\\"{x:895,y:649,t:1527188802423};\\\", \\\"{x:870,y:640,t:1527188802439};\\\", \\\"{x:821,y:631,t:1527188802456};\\\", \\\"{x:765,y:623,t:1527188802474};\\\", \\\"{x:701,y:615,t:1527188802491};\\\", \\\"{x:634,y:604,t:1527188802508};\\\", \\\"{x:558,y:592,t:1527188802524};\\\", \\\"{x:510,y:583,t:1527188802540};\\\", \\\"{x:451,y:574,t:1527188802557};\\\", \\\"{x:400,y:567,t:1527188802573};\\\", \\\"{x:373,y:566,t:1527188802591};\\\", \\\"{x:358,y:566,t:1527188802608};\\\", \\\"{x:355,y:566,t:1527188802623};\\\", \\\"{x:354,y:566,t:1527188802640};\\\", \\\"{x:354,y:567,t:1527188802657};\\\", \\\"{x:356,y:571,t:1527188802674};\\\", \\\"{x:359,y:577,t:1527188802691};\\\", \\\"{x:364,y:586,t:1527188802708};\\\", \\\"{x:368,y:591,t:1527188802724};\\\", \\\"{x:372,y:598,t:1527188802741};\\\", \\\"{x:377,y:604,t:1527188802758};\\\", \\\"{x:390,y:609,t:1527188802775};\\\", \\\"{x:408,y:613,t:1527188802790};\\\", \\\"{x:433,y:615,t:1527188802807};\\\", \\\"{x:456,y:615,t:1527188802823};\\\", \\\"{x:483,y:615,t:1527188802840};\\\", \\\"{x:495,y:615,t:1527188802857};\\\", \\\"{x:500,y:615,t:1527188802874};\\\", \\\"{x:503,y:615,t:1527188802891};\\\", \\\"{x:509,y:615,t:1527188802907};\\\", \\\"{x:526,y:615,t:1527188802923};\\\", \\\"{x:546,y:615,t:1527188802941};\\\", \\\"{x:564,y:615,t:1527188802957};\\\", \\\"{x:569,y:616,t:1527188802974};\\\", \\\"{x:571,y:616,t:1527188802991};\\\", \\\"{x:572,y:616,t:1527188803184};\\\", \\\"{x:576,y:616,t:1527188803192};\\\", \\\"{x:580,y:616,t:1527188803207};\\\", \\\"{x:591,y:616,t:1527188803225};\\\", \\\"{x:596,y:616,t:1527188803240};\\\", \\\"{x:597,y:615,t:1527188803257};\\\", \\\"{x:598,y:615,t:1527188803281};\\\", \\\"{x:598,y:614,t:1527188803408};\\\", \\\"{x:599,y:614,t:1527188803448};\\\", \\\"{x:599,y:613,t:1527188803472};\\\", \\\"{x:599,y:612,t:1527188803480};\\\", \\\"{x:600,y:611,t:1527188803490};\\\", \\\"{x:602,y:609,t:1527188803507};\\\", \\\"{x:604,y:607,t:1527188803524};\\\", \\\"{x:606,y:604,t:1527188803542};\\\", \\\"{x:606,y:603,t:1527188803561};\\\", \\\"{x:606,y:601,t:1527188803576};\\\", \\\"{x:607,y:601,t:1527188803600};\\\", \\\"{x:609,y:600,t:1527188804425};\\\", \\\"{x:626,y:621,t:1527188804442};\\\", \\\"{x:654,y:646,t:1527188804458};\\\", \\\"{x:696,y:672,t:1527188804476};\\\", \\\"{x:733,y:692,t:1527188804492};\\\", \\\"{x:787,y:723,t:1527188804509};\\\", \\\"{x:847,y:754,t:1527188804525};\\\", \\\"{x:896,y:784,t:1527188804541};\\\", \\\"{x:932,y:805,t:1527188804558};\\\", \\\"{x:962,y:819,t:1527188804576};\\\", \\\"{x:986,y:829,t:1527188804592};\\\", \\\"{x:1019,y:842,t:1527188804608};\\\", \\\"{x:1040,y:847,t:1527188804626};\\\", \\\"{x:1052,y:852,t:1527188804643};\\\", \\\"{x:1065,y:853,t:1527188804658};\\\", \\\"{x:1076,y:855,t:1527188804676};\\\", \\\"{x:1091,y:856,t:1527188804692};\\\", \\\"{x:1105,y:857,t:1527188804709};\\\", \\\"{x:1122,y:857,t:1527188804725};\\\", \\\"{x:1142,y:857,t:1527188804743};\\\", \\\"{x:1160,y:857,t:1527188804759};\\\", \\\"{x:1181,y:856,t:1527188804776};\\\", \\\"{x:1217,y:855,t:1527188804792};\\\", \\\"{x:1241,y:855,t:1527188804808};\\\", \\\"{x:1271,y:855,t:1527188804825};\\\", \\\"{x:1299,y:855,t:1527188804843};\\\", \\\"{x:1329,y:855,t:1527188804859};\\\", \\\"{x:1355,y:855,t:1527188804876};\\\", \\\"{x:1379,y:853,t:1527188804893};\\\", \\\"{x:1401,y:852,t:1527188804909};\\\", \\\"{x:1419,y:852,t:1527188804925};\\\", \\\"{x:1434,y:852,t:1527188804942};\\\", \\\"{x:1444,y:852,t:1527188804958};\\\", \\\"{x:1451,y:852,t:1527188804975};\\\", \\\"{x:1458,y:851,t:1527188804993};\\\", \\\"{x:1459,y:851,t:1527188805081};\\\", \\\"{x:1460,y:851,t:1527188805092};\\\", \\\"{x:1463,y:851,t:1527188805109};\\\", \\\"{x:1464,y:851,t:1527188805144};\\\", \\\"{x:1471,y:851,t:1527188805160};\\\", \\\"{x:1495,y:852,t:1527188805176};\\\", \\\"{x:1556,y:858,t:1527188805193};\\\", \\\"{x:1593,y:859,t:1527188805210};\\\", \\\"{x:1627,y:859,t:1527188805226};\\\", \\\"{x:1638,y:859,t:1527188805243};\\\", \\\"{x:1639,y:859,t:1527188805260};\\\", \\\"{x:1638,y:862,t:1527188805657};\\\", \\\"{x:1636,y:867,t:1527188805664};\\\", \\\"{x:1633,y:872,t:1527188805677};\\\", \\\"{x:1629,y:880,t:1527188805692};\\\", \\\"{x:1623,y:888,t:1527188805710};\\\", \\\"{x:1615,y:900,t:1527188805726};\\\", \\\"{x:1609,y:909,t:1527188805743};\\\", \\\"{x:1603,y:917,t:1527188805760};\\\", \\\"{x:1595,y:929,t:1527188805776};\\\", \\\"{x:1594,y:931,t:1527188805793};\\\", \\\"{x:1593,y:932,t:1527188805810};\\\", \\\"{x:1593,y:933,t:1527188805880};\\\", \\\"{x:1593,y:934,t:1527188805893};\\\", \\\"{x:1593,y:938,t:1527188805910};\\\", \\\"{x:1593,y:941,t:1527188805927};\\\", \\\"{x:1594,y:943,t:1527188805944};\\\", \\\"{x:1594,y:944,t:1527188805959};\\\", \\\"{x:1596,y:948,t:1527188805976};\\\", \\\"{x:1598,y:951,t:1527188805994};\\\", \\\"{x:1598,y:952,t:1527188806009};\\\", \\\"{x:1598,y:953,t:1527188806104};\\\", \\\"{x:1598,y:954,t:1527188806113};\\\", \\\"{x:1597,y:954,t:1527188806127};\\\", \\\"{x:1594,y:955,t:1527188806144};\\\", \\\"{x:1589,y:955,t:1527188806160};\\\", \\\"{x:1572,y:952,t:1527188806176};\\\", \\\"{x:1558,y:946,t:1527188806194};\\\", \\\"{x:1549,y:941,t:1527188806209};\\\", \\\"{x:1538,y:933,t:1527188806227};\\\", \\\"{x:1527,y:920,t:1527188806243};\\\", \\\"{x:1512,y:902,t:1527188806260};\\\", \\\"{x:1495,y:884,t:1527188806277};\\\", \\\"{x:1465,y:864,t:1527188806294};\\\", \\\"{x:1439,y:850,t:1527188806310};\\\", \\\"{x:1427,y:844,t:1527188806327};\\\", \\\"{x:1419,y:840,t:1527188806344};\\\", \\\"{x:1410,y:839,t:1527188806360};\\\", \\\"{x:1407,y:837,t:1527188806377};\\\", \\\"{x:1406,y:836,t:1527188806394};\\\", \\\"{x:1403,y:833,t:1527188806411};\\\", \\\"{x:1402,y:830,t:1527188806426};\\\", \\\"{x:1400,y:825,t:1527188806444};\\\", \\\"{x:1398,y:821,t:1527188806461};\\\", \\\"{x:1395,y:815,t:1527188806476};\\\", \\\"{x:1392,y:810,t:1527188806494};\\\", \\\"{x:1387,y:803,t:1527188806510};\\\", \\\"{x:1386,y:799,t:1527188806526};\\\", \\\"{x:1386,y:798,t:1527188806543};\\\", \\\"{x:1386,y:797,t:1527188806593};\\\", \\\"{x:1386,y:796,t:1527188806600};\\\", \\\"{x:1386,y:795,t:1527188806611};\\\", \\\"{x:1386,y:793,t:1527188806627};\\\", \\\"{x:1386,y:790,t:1527188806644};\\\", \\\"{x:1386,y:788,t:1527188806661};\\\", \\\"{x:1386,y:787,t:1527188806677};\\\", \\\"{x:1386,y:786,t:1527188806693};\\\", \\\"{x:1386,y:784,t:1527188806721};\\\", \\\"{x:1386,y:783,t:1527188806736};\\\", \\\"{x:1386,y:781,t:1527188806752};\\\", \\\"{x:1386,y:780,t:1527188806761};\\\", \\\"{x:1386,y:779,t:1527188806778};\\\", \\\"{x:1386,y:778,t:1527188806808};\\\", \\\"{x:1386,y:777,t:1527188806816};\\\", \\\"{x:1386,y:776,t:1527188806832};\\\", \\\"{x:1386,y:775,t:1527188806844};\\\", \\\"{x:1386,y:773,t:1527188806861};\\\", \\\"{x:1385,y:771,t:1527188806877};\\\", \\\"{x:1384,y:770,t:1527188806893};\\\", \\\"{x:1383,y:769,t:1527188807297};\\\", \\\"{x:1382,y:769,t:1527188807329};\\\", \\\"{x:1381,y:768,t:1527188807489};\\\", \\\"{x:1380,y:768,t:1527188807510};\\\", \\\"{x:1380,y:767,t:1527188807528};\\\", \\\"{x:1378,y:765,t:1527188807544};\\\", \\\"{x:1378,y:764,t:1527188807584};\\\", \\\"{x:1379,y:764,t:1527188808560};\\\", \\\"{x:1379,y:765,t:1527188808593};\\\", \\\"{x:1380,y:766,t:1527188808704};\\\", \\\"{x:1381,y:767,t:1527188808744};\\\", \\\"{x:1382,y:768,t:1527188808752};\\\", \\\"{x:1382,y:769,t:1527188808769};\\\", \\\"{x:1383,y:770,t:1527188808784};\\\", \\\"{x:1383,y:771,t:1527188808937};\\\", \\\"{x:1383,y:773,t:1527188808947};\\\", \\\"{x:1383,y:774,t:1527188808962};\\\", \\\"{x:1383,y:775,t:1527188808979};\\\", \\\"{x:1383,y:777,t:1527188808997};\\\", \\\"{x:1383,y:779,t:1527188809013};\\\", \\\"{x:1383,y:781,t:1527188809029};\\\", \\\"{x:1383,y:784,t:1527188809047};\\\", \\\"{x:1383,y:786,t:1527188809064};\\\", \\\"{x:1383,y:787,t:1527188809080};\\\", \\\"{x:1383,y:790,t:1527188809097};\\\", \\\"{x:1386,y:803,t:1527188809113};\\\", \\\"{x:1390,y:819,t:1527188809130};\\\", \\\"{x:1395,y:834,t:1527188809146};\\\", \\\"{x:1396,y:847,t:1527188809164};\\\", \\\"{x:1397,y:858,t:1527188809179};\\\", \\\"{x:1398,y:869,t:1527188809197};\\\", \\\"{x:1399,y:881,t:1527188809213};\\\", \\\"{x:1401,y:893,t:1527188809229};\\\", \\\"{x:1403,y:907,t:1527188809246};\\\", \\\"{x:1403,y:915,t:1527188809264};\\\", \\\"{x:1403,y:919,t:1527188809279};\\\", \\\"{x:1403,y:921,t:1527188809296};\\\", \\\"{x:1403,y:922,t:1527188809313};\\\", \\\"{x:1403,y:924,t:1527188809353};\\\", \\\"{x:1403,y:925,t:1527188809363};\\\", \\\"{x:1403,y:929,t:1527188809380};\\\", \\\"{x:1399,y:936,t:1527188809397};\\\", \\\"{x:1397,y:941,t:1527188809413};\\\", \\\"{x:1394,y:945,t:1527188809430};\\\", \\\"{x:1391,y:949,t:1527188809446};\\\", \\\"{x:1390,y:951,t:1527188809463};\\\", \\\"{x:1389,y:953,t:1527188809480};\\\", \\\"{x:1389,y:955,t:1527188809496};\\\", \\\"{x:1387,y:960,t:1527188809512};\\\", \\\"{x:1387,y:962,t:1527188809530};\\\", \\\"{x:1385,y:964,t:1527188809547};\\\", \\\"{x:1384,y:965,t:1527188809564};\\\", \\\"{x:1383,y:967,t:1527188809580};\\\", \\\"{x:1383,y:969,t:1527188809596};\\\", \\\"{x:1383,y:970,t:1527188809613};\\\", \\\"{x:1383,y:971,t:1527188809630};\\\", \\\"{x:1383,y:972,t:1527188809753};\\\", \\\"{x:1382,y:972,t:1527188809763};\\\", \\\"{x:1381,y:962,t:1527188809781};\\\", \\\"{x:1377,y:941,t:1527188809796};\\\", \\\"{x:1375,y:920,t:1527188809813};\\\", \\\"{x:1370,y:906,t:1527188809830};\\\", \\\"{x:1369,y:894,t:1527188809848};\\\", \\\"{x:1367,y:886,t:1527188809863};\\\", \\\"{x:1366,y:876,t:1527188809880};\\\", \\\"{x:1365,y:853,t:1527188809897};\\\", \\\"{x:1365,y:842,t:1527188809913};\\\", \\\"{x:1365,y:833,t:1527188809930};\\\", \\\"{x:1364,y:825,t:1527188809948};\\\", \\\"{x:1363,y:819,t:1527188809963};\\\", \\\"{x:1362,y:815,t:1527188809980};\\\", \\\"{x:1361,y:811,t:1527188809997};\\\", \\\"{x:1361,y:807,t:1527188810013};\\\", \\\"{x:1362,y:803,t:1527188810031};\\\", \\\"{x:1363,y:797,t:1527188810047};\\\", \\\"{x:1364,y:792,t:1527188810063};\\\", \\\"{x:1364,y:789,t:1527188810081};\\\", \\\"{x:1366,y:786,t:1527188810097};\\\", \\\"{x:1367,y:785,t:1527188810113};\\\", \\\"{x:1367,y:784,t:1527188810130};\\\", \\\"{x:1368,y:781,t:1527188810148};\\\", \\\"{x:1369,y:777,t:1527188810163};\\\", \\\"{x:1371,y:772,t:1527188810180};\\\", \\\"{x:1373,y:766,t:1527188810197};\\\", \\\"{x:1374,y:762,t:1527188810213};\\\", \\\"{x:1375,y:761,t:1527188810322};\\\", \\\"{x:1374,y:762,t:1527188811338};\\\", \\\"{x:1372,y:769,t:1527188811348};\\\", \\\"{x:1368,y:781,t:1527188811364};\\\", \\\"{x:1362,y:792,t:1527188811382};\\\", \\\"{x:1356,y:803,t:1527188811399};\\\", \\\"{x:1351,y:811,t:1527188811414};\\\", \\\"{x:1348,y:814,t:1527188811432};\\\", \\\"{x:1346,y:816,t:1527188811448};\\\", \\\"{x:1344,y:818,t:1527188811465};\\\", \\\"{x:1341,y:820,t:1527188811481};\\\", \\\"{x:1337,y:823,t:1527188811498};\\\", \\\"{x:1333,y:827,t:1527188811515};\\\", \\\"{x:1329,y:830,t:1527188811532};\\\", \\\"{x:1324,y:833,t:1527188811549};\\\", \\\"{x:1320,y:834,t:1527188811565};\\\", \\\"{x:1316,y:837,t:1527188811581};\\\", \\\"{x:1312,y:838,t:1527188811598};\\\", \\\"{x:1308,y:838,t:1527188811615};\\\", \\\"{x:1304,y:839,t:1527188811631};\\\", \\\"{x:1300,y:840,t:1527188811649};\\\", \\\"{x:1299,y:840,t:1527188811665};\\\", \\\"{x:1295,y:840,t:1527188811682};\\\", \\\"{x:1294,y:840,t:1527188811699};\\\", \\\"{x:1293,y:840,t:1527188811716};\\\", \\\"{x:1292,y:840,t:1527188811732};\\\", \\\"{x:1291,y:839,t:1527188811905};\\\", \\\"{x:1290,y:838,t:1527188811915};\\\", \\\"{x:1289,y:838,t:1527188811931};\\\", \\\"{x:1289,y:837,t:1527188811948};\\\", \\\"{x:1288,y:837,t:1527188811969};\\\", \\\"{x:1287,y:837,t:1527188811993};\\\", \\\"{x:1286,y:837,t:1527188812009};\\\", \\\"{x:1286,y:836,t:1527188812058};\\\", \\\"{x:1285,y:836,t:1527188812097};\\\", \\\"{x:1284,y:836,t:1527188812115};\\\", \\\"{x:1284,y:835,t:1527188812132};\\\", \\\"{x:1283,y:835,t:1527188812162};\\\", \\\"{x:1283,y:834,t:1527188812650};\\\", \\\"{x:1282,y:831,t:1527188812666};\\\", \\\"{x:1287,y:827,t:1527188812684};\\\", \\\"{x:1292,y:822,t:1527188812699};\\\", \\\"{x:1301,y:815,t:1527188812716};\\\", \\\"{x:1307,y:809,t:1527188812732};\\\", \\\"{x:1313,y:803,t:1527188812750};\\\", \\\"{x:1321,y:796,t:1527188812765};\\\", \\\"{x:1332,y:789,t:1527188812782};\\\", \\\"{x:1339,y:785,t:1527188812799};\\\", \\\"{x:1347,y:782,t:1527188812815};\\\", \\\"{x:1355,y:778,t:1527188812832};\\\", \\\"{x:1362,y:777,t:1527188812849};\\\", \\\"{x:1366,y:774,t:1527188812866};\\\", \\\"{x:1369,y:774,t:1527188812882};\\\", \\\"{x:1370,y:774,t:1527188812899};\\\", \\\"{x:1372,y:773,t:1527188812916};\\\", \\\"{x:1373,y:772,t:1527188812953};\\\", \\\"{x:1373,y:771,t:1527188812966};\\\", \\\"{x:1374,y:770,t:1527188812982};\\\", \\\"{x:1375,y:768,t:1527188812999};\\\", \\\"{x:1377,y:767,t:1527188813016};\\\", \\\"{x:1376,y:762,t:1527188813473};\\\", \\\"{x:1373,y:756,t:1527188813484};\\\", \\\"{x:1365,y:744,t:1527188813500};\\\", \\\"{x:1360,y:737,t:1527188813516};\\\", \\\"{x:1357,y:731,t:1527188813533};\\\", \\\"{x:1351,y:724,t:1527188813549};\\\", \\\"{x:1340,y:708,t:1527188813567};\\\", \\\"{x:1335,y:697,t:1527188813583};\\\", \\\"{x:1329,y:686,t:1527188813599};\\\", \\\"{x:1326,y:679,t:1527188813616};\\\", \\\"{x:1317,y:668,t:1527188813633};\\\", \\\"{x:1316,y:666,t:1527188813651};\\\", \\\"{x:1315,y:662,t:1527188813666};\\\", \\\"{x:1313,y:660,t:1527188813683};\\\", \\\"{x:1313,y:658,t:1527188813699};\\\", \\\"{x:1311,y:655,t:1527188813715};\\\", \\\"{x:1310,y:653,t:1527188813733};\\\", \\\"{x:1309,y:650,t:1527188813750};\\\", \\\"{x:1307,y:648,t:1527188813766};\\\", \\\"{x:1307,y:647,t:1527188813824};\\\", \\\"{x:1306,y:645,t:1527188813833};\\\", \\\"{x:1305,y:641,t:1527188813850};\\\", \\\"{x:1305,y:639,t:1527188813866};\\\", \\\"{x:1304,y:639,t:1527188813883};\\\", \\\"{x:1304,y:638,t:1527188814193};\\\", \\\"{x:1304,y:637,t:1527188814201};\\\", \\\"{x:1308,y:635,t:1527188814217};\\\", \\\"{x:1312,y:634,t:1527188814234};\\\", \\\"{x:1313,y:634,t:1527188814250};\\\", \\\"{x:1315,y:634,t:1527188814267};\\\", \\\"{x:1316,y:632,t:1527188814283};\\\", \\\"{x:1318,y:632,t:1527188814300};\\\", \\\"{x:1318,y:631,t:1527188814329};\\\", \\\"{x:1318,y:635,t:1527188814971};\\\", \\\"{x:1318,y:655,t:1527188814985};\\\", \\\"{x:1318,y:669,t:1527188815001};\\\", \\\"{x:1318,y:685,t:1527188815017};\\\", \\\"{x:1324,y:712,t:1527188815035};\\\", \\\"{x:1338,y:760,t:1527188815051};\\\", \\\"{x:1347,y:806,t:1527188815067};\\\", \\\"{x:1347,y:836,t:1527188815084};\\\", \\\"{x:1347,y:860,t:1527188815101};\\\", \\\"{x:1345,y:876,t:1527188815117};\\\", \\\"{x:1345,y:884,t:1527188815134};\\\", \\\"{x:1344,y:891,t:1527188815151};\\\", \\\"{x:1344,y:892,t:1527188815167};\\\", \\\"{x:1344,y:896,t:1527188815200};\\\", \\\"{x:1343,y:899,t:1527188815217};\\\", \\\"{x:1342,y:902,t:1527188815235};\\\", \\\"{x:1342,y:904,t:1527188815251};\\\", \\\"{x:1341,y:905,t:1527188815330};\\\", \\\"{x:1341,y:908,t:1527188815337};\\\", \\\"{x:1341,y:911,t:1527188815352};\\\", \\\"{x:1341,y:916,t:1527188815368};\\\", \\\"{x:1340,y:920,t:1527188815385};\\\", \\\"{x:1340,y:924,t:1527188815401};\\\", \\\"{x:1340,y:930,t:1527188815418};\\\", \\\"{x:1340,y:939,t:1527188815435};\\\", \\\"{x:1341,y:945,t:1527188815451};\\\", \\\"{x:1343,y:949,t:1527188815467};\\\", \\\"{x:1339,y:941,t:1527188815625};\\\", \\\"{x:1338,y:938,t:1527188815635};\\\", \\\"{x:1329,y:923,t:1527188815651};\\\", \\\"{x:1318,y:904,t:1527188815669};\\\", \\\"{x:1305,y:886,t:1527188815685};\\\", \\\"{x:1288,y:864,t:1527188815702};\\\", \\\"{x:1276,y:846,t:1527188815719};\\\", \\\"{x:1272,y:842,t:1527188815735};\\\", \\\"{x:1272,y:839,t:1527188815751};\\\", \\\"{x:1264,y:832,t:1527188815769};\\\", \\\"{x:1261,y:832,t:1527188815784};\\\", \\\"{x:1256,y:830,t:1527188815801};\\\", \\\"{x:1248,y:828,t:1527188815818};\\\", \\\"{x:1235,y:826,t:1527188815834};\\\", \\\"{x:1221,y:823,t:1527188815851};\\\", \\\"{x:1204,y:820,t:1527188815868};\\\", \\\"{x:1184,y:815,t:1527188815884};\\\", \\\"{x:1162,y:810,t:1527188815901};\\\", \\\"{x:1131,y:807,t:1527188815918};\\\", \\\"{x:1112,y:804,t:1527188815934};\\\", \\\"{x:1091,y:804,t:1527188815951};\\\", \\\"{x:1071,y:804,t:1527188815968};\\\", \\\"{x:1057,y:804,t:1527188815985};\\\", \\\"{x:1054,y:804,t:1527188816001};\\\", \\\"{x:1051,y:804,t:1527188816018};\\\", \\\"{x:1050,y:804,t:1527188816036};\\\", \\\"{x:1048,y:804,t:1527188816052};\\\", \\\"{x:1043,y:801,t:1527188816069};\\\", \\\"{x:1036,y:801,t:1527188816086};\\\", \\\"{x:1026,y:801,t:1527188816102};\\\", \\\"{x:1012,y:801,t:1527188816118};\\\", \\\"{x:1000,y:801,t:1527188816136};\\\", \\\"{x:984,y:802,t:1527188816151};\\\", \\\"{x:952,y:808,t:1527188816169};\\\", \\\"{x:930,y:812,t:1527188816185};\\\", \\\"{x:908,y:819,t:1527188816202};\\\", \\\"{x:896,y:823,t:1527188816218};\\\", \\\"{x:892,y:823,t:1527188816235};\\\", \\\"{x:891,y:824,t:1527188816265};\\\", \\\"{x:892,y:826,t:1527188816281};\\\", \\\"{x:902,y:830,t:1527188816289};\\\", \\\"{x:913,y:837,t:1527188816301};\\\", \\\"{x:962,y:856,t:1527188816318};\\\", \\\"{x:1047,y:877,t:1527188816336};\\\", \\\"{x:1128,y:890,t:1527188816352};\\\", \\\"{x:1229,y:902,t:1527188816369};\\\", \\\"{x:1257,y:904,t:1527188816385};\\\", \\\"{x:1280,y:906,t:1527188816402};\\\", \\\"{x:1294,y:906,t:1527188816418};\\\", \\\"{x:1296,y:906,t:1527188816436};\\\", \\\"{x:1297,y:906,t:1527188816506};\\\", \\\"{x:1299,y:904,t:1527188816519};\\\", \\\"{x:1299,y:902,t:1527188816535};\\\", \\\"{x:1300,y:891,t:1527188816553};\\\", \\\"{x:1300,y:878,t:1527188816568};\\\", \\\"{x:1295,y:864,t:1527188816585};\\\", \\\"{x:1292,y:857,t:1527188816602};\\\", \\\"{x:1292,y:856,t:1527188816619};\\\", \\\"{x:1292,y:852,t:1527188816636};\\\", \\\"{x:1292,y:849,t:1527188816653};\\\", \\\"{x:1292,y:845,t:1527188816669};\\\", \\\"{x:1293,y:840,t:1527188816686};\\\", \\\"{x:1293,y:836,t:1527188816702};\\\", \\\"{x:1293,y:833,t:1527188816719};\\\", \\\"{x:1293,y:832,t:1527188816735};\\\", \\\"{x:1293,y:830,t:1527188816753};\\\", \\\"{x:1293,y:829,t:1527188816769};\\\", \\\"{x:1293,y:828,t:1527188816786};\\\", \\\"{x:1293,y:826,t:1527188816802};\\\", \\\"{x:1293,y:825,t:1527188816832};\\\", \\\"{x:1293,y:824,t:1527188817169};\\\", \\\"{x:1293,y:822,t:1527188817185};\\\", \\\"{x:1291,y:822,t:1527188817202};\\\", \\\"{x:1290,y:822,t:1527188817219};\\\", \\\"{x:1288,y:822,t:1527188817235};\\\", \\\"{x:1287,y:822,t:1527188817252};\\\", \\\"{x:1286,y:822,t:1527188817269};\\\", \\\"{x:1285,y:823,t:1527188817426};\\\", \\\"{x:1284,y:825,t:1527188817437};\\\", \\\"{x:1284,y:828,t:1527188817452};\\\", \\\"{x:1282,y:830,t:1527188817469};\\\", \\\"{x:1277,y:831,t:1527188817486};\\\", \\\"{x:1270,y:833,t:1527188817503};\\\", \\\"{x:1260,y:833,t:1527188817520};\\\", \\\"{x:1241,y:833,t:1527188817537};\\\", \\\"{x:1192,y:827,t:1527188817553};\\\", \\\"{x:1144,y:820,t:1527188817570};\\\", \\\"{x:1100,y:815,t:1527188817586};\\\", \\\"{x:1056,y:805,t:1527188817602};\\\", \\\"{x:1022,y:800,t:1527188817619};\\\", \\\"{x:1004,y:796,t:1527188817637};\\\", \\\"{x:987,y:789,t:1527188817653};\\\", \\\"{x:971,y:785,t:1527188817670};\\\", \\\"{x:957,y:781,t:1527188817686};\\\", \\\"{x:937,y:778,t:1527188817703};\\\", \\\"{x:920,y:775,t:1527188817720};\\\", \\\"{x:886,y:775,t:1527188817737};\\\", \\\"{x:860,y:775,t:1527188817753};\\\", \\\"{x:833,y:775,t:1527188817770};\\\", \\\"{x:806,y:771,t:1527188817786};\\\", \\\"{x:780,y:767,t:1527188817804};\\\", \\\"{x:765,y:764,t:1527188817819};\\\", \\\"{x:761,y:761,t:1527188817836};\\\", \\\"{x:759,y:761,t:1527188817853};\\\", \\\"{x:758,y:760,t:1527188817873};\\\", \\\"{x:757,y:760,t:1527188817985};\\\", \\\"{x:755,y:759,t:1527188817992};\\\", \\\"{x:752,y:757,t:1527188818004};\\\", \\\"{x:748,y:754,t:1527188818020};\\\", \\\"{x:742,y:751,t:1527188818037};\\\", \\\"{x:736,y:748,t:1527188818053};\\\", \\\"{x:729,y:746,t:1527188818069};\\\", \\\"{x:714,y:744,t:1527188818086};\\\", \\\"{x:701,y:740,t:1527188818103};\\\", \\\"{x:694,y:736,t:1527188818120};\\\", \\\"{x:689,y:733,t:1527188818136};\\\", \\\"{x:684,y:729,t:1527188818154};\\\", \\\"{x:679,y:724,t:1527188818170};\\\", \\\"{x:667,y:719,t:1527188818187};\\\", \\\"{x:648,y:714,t:1527188818203};\\\", \\\"{x:627,y:709,t:1527188818221};\\\", \\\"{x:612,y:707,t:1527188818237};\\\", \\\"{x:604,y:706,t:1527188818254};\\\", \\\"{x:601,y:706,t:1527188818271};\\\", \\\"{x:598,y:706,t:1527188818287};\\\", \\\"{x:594,y:706,t:1527188818303};\\\", \\\"{x:586,y:706,t:1527188818321};\\\", \\\"{x:577,y:706,t:1527188818337};\\\", \\\"{x:574,y:706,t:1527188818353};\\\", \\\"{x:573,y:706,t:1527188818425};\\\", \\\"{x:570,y:706,t:1527188818437};\\\", \\\"{x:565,y:709,t:1527188818454};\\\", \\\"{x:557,y:713,t:1527188818472};\\\", \\\"{x:553,y:716,t:1527188818486};\\\", \\\"{x:549,y:716,t:1527188818504};\\\" ] }, { \\\"rt\\\": 104537, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 309826, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -I -03 PM-03 PM-K -U -U -U -U -F -F -K -H -H -H -F -F -F -F -F -F -F -F -12 PM-O -O -Z -O -O -Z -Z -Z -Z -12 PM-A -I -O -12 PM-A -A -11 AM-A -A -11 AM-A -C -Z -Z -12 PM-12 PM-Z -Z -O -O -F -F -H -01 PM-H -01 PM-01 PM-01 PM-01 PM-H -J -J -J -H -J -F -01 PM-01 PM-K -U -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:717,t:1527188820937};\\\", \\\"{x:548,y:719,t:1527188820944};\\\", \\\"{x:550,y:721,t:1527188820957};\\\", \\\"{x:560,y:727,t:1527188820974};\\\", \\\"{x:568,y:734,t:1527188820994};\\\", \\\"{x:584,y:740,t:1527188821008};\\\", \\\"{x:595,y:745,t:1527188821022};\\\", \\\"{x:608,y:750,t:1527188821039};\\\", \\\"{x:626,y:758,t:1527188821055};\\\", \\\"{x:638,y:763,t:1527188821072};\\\", \\\"{x:649,y:769,t:1527188821089};\\\", \\\"{x:665,y:775,t:1527188821106};\\\", \\\"{x:681,y:782,t:1527188821122};\\\", \\\"{x:703,y:793,t:1527188821139};\\\", \\\"{x:726,y:802,t:1527188821156};\\\", \\\"{x:750,y:809,t:1527188821172};\\\", \\\"{x:771,y:816,t:1527188821189};\\\", \\\"{x:781,y:818,t:1527188821207};\\\", \\\"{x:785,y:818,t:1527188821223};\\\", \\\"{x:787,y:819,t:1527188821239};\\\", \\\"{x:790,y:819,t:1527188824793};\\\", \\\"{x:800,y:819,t:1527188824809};\\\", \\\"{x:813,y:819,t:1527188824826};\\\", \\\"{x:829,y:819,t:1527188824843};\\\", \\\"{x:849,y:819,t:1527188824860};\\\", \\\"{x:873,y:819,t:1527188824875};\\\", \\\"{x:906,y:824,t:1527188824893};\\\", \\\"{x:933,y:832,t:1527188824910};\\\", \\\"{x:970,y:839,t:1527188824925};\\\", \\\"{x:1009,y:844,t:1527188824943};\\\", \\\"{x:1041,y:850,t:1527188824959};\\\", \\\"{x:1090,y:853,t:1527188824976};\\\", \\\"{x:1195,y:858,t:1527188824993};\\\", \\\"{x:1261,y:858,t:1527188825010};\\\", \\\"{x:1300,y:858,t:1527188825026};\\\", \\\"{x:1330,y:858,t:1527188825043};\\\", \\\"{x:1359,y:858,t:1527188825060};\\\", \\\"{x:1386,y:858,t:1527188825075};\\\", \\\"{x:1405,y:856,t:1527188825092};\\\", \\\"{x:1422,y:853,t:1527188825109};\\\", \\\"{x:1439,y:850,t:1527188825125};\\\", \\\"{x:1450,y:849,t:1527188825142};\\\", \\\"{x:1458,y:847,t:1527188825159};\\\", \\\"{x:1468,y:844,t:1527188825175};\\\", \\\"{x:1482,y:837,t:1527188825192};\\\", \\\"{x:1491,y:834,t:1527188825209};\\\", \\\"{x:1501,y:829,t:1527188825226};\\\", \\\"{x:1509,y:827,t:1527188825243};\\\", \\\"{x:1522,y:823,t:1527188825259};\\\", \\\"{x:1542,y:822,t:1527188825277};\\\", \\\"{x:1565,y:821,t:1527188825292};\\\", \\\"{x:1590,y:817,t:1527188825310};\\\", \\\"{x:1626,y:810,t:1527188825326};\\\", \\\"{x:1651,y:809,t:1527188825343};\\\", \\\"{x:1673,y:806,t:1527188825360};\\\", \\\"{x:1718,y:806,t:1527188825376};\\\", \\\"{x:1739,y:806,t:1527188825393};\\\", \\\"{x:1752,y:806,t:1527188825410};\\\", \\\"{x:1756,y:804,t:1527188825427};\\\", \\\"{x:1757,y:804,t:1527188825443};\\\", \\\"{x:1757,y:802,t:1527188825601};\\\", \\\"{x:1755,y:801,t:1527188825610};\\\", \\\"{x:1750,y:799,t:1527188825627};\\\", \\\"{x:1741,y:797,t:1527188825644};\\\", \\\"{x:1731,y:795,t:1527188825660};\\\", \\\"{x:1716,y:793,t:1527188825677};\\\", \\\"{x:1701,y:789,t:1527188825694};\\\", \\\"{x:1678,y:789,t:1527188825711};\\\", \\\"{x:1655,y:789,t:1527188825727};\\\", \\\"{x:1629,y:789,t:1527188825744};\\\", \\\"{x:1611,y:789,t:1527188825760};\\\", \\\"{x:1585,y:789,t:1527188825777};\\\", \\\"{x:1566,y:789,t:1527188825794};\\\", \\\"{x:1556,y:790,t:1527188825810};\\\", \\\"{x:1547,y:794,t:1527188825826};\\\", \\\"{x:1537,y:796,t:1527188825844};\\\", \\\"{x:1528,y:799,t:1527188825859};\\\", \\\"{x:1519,y:799,t:1527188825876};\\\", \\\"{x:1508,y:799,t:1527188825894};\\\", \\\"{x:1501,y:798,t:1527188825909};\\\", \\\"{x:1498,y:796,t:1527188825927};\\\", \\\"{x:1491,y:795,t:1527188825943};\\\", \\\"{x:1482,y:792,t:1527188825960};\\\", \\\"{x:1472,y:786,t:1527188825976};\\\", \\\"{x:1463,y:781,t:1527188825993};\\\", \\\"{x:1453,y:777,t:1527188826009};\\\", \\\"{x:1444,y:772,t:1527188826026};\\\", \\\"{x:1437,y:767,t:1527188826043};\\\", \\\"{x:1427,y:761,t:1527188826059};\\\", \\\"{x:1416,y:753,t:1527188826077};\\\", \\\"{x:1410,y:748,t:1527188826094};\\\", \\\"{x:1404,y:742,t:1527188826110};\\\", \\\"{x:1399,y:732,t:1527188826127};\\\", \\\"{x:1393,y:720,t:1527188826144};\\\", \\\"{x:1386,y:697,t:1527188826161};\\\", \\\"{x:1381,y:678,t:1527188826177};\\\", \\\"{x:1379,y:668,t:1527188826194};\\\", \\\"{x:1378,y:659,t:1527188826211};\\\", \\\"{x:1377,y:647,t:1527188826227};\\\", \\\"{x:1377,y:637,t:1527188826244};\\\", \\\"{x:1379,y:622,t:1527188826262};\\\", \\\"{x:1381,y:608,t:1527188826277};\\\", \\\"{x:1384,y:591,t:1527188826294};\\\", \\\"{x:1385,y:576,t:1527188826311};\\\", \\\"{x:1385,y:560,t:1527188826327};\\\", \\\"{x:1385,y:553,t:1527188826344};\\\", \\\"{x:1383,y:544,t:1527188826361};\\\", \\\"{x:1380,y:536,t:1527188826376};\\\", \\\"{x:1377,y:530,t:1527188826393};\\\", \\\"{x:1374,y:525,t:1527188826411};\\\", \\\"{x:1371,y:520,t:1527188826427};\\\", \\\"{x:1369,y:519,t:1527188826444};\\\", \\\"{x:1364,y:516,t:1527188826461};\\\", \\\"{x:1361,y:515,t:1527188826477};\\\", \\\"{x:1356,y:513,t:1527188826494};\\\", \\\"{x:1352,y:510,t:1527188826512};\\\", \\\"{x:1349,y:508,t:1527188826528};\\\", \\\"{x:1344,y:506,t:1527188826544};\\\", \\\"{x:1340,y:504,t:1527188826561};\\\", \\\"{x:1339,y:503,t:1527188826577};\\\", \\\"{x:1338,y:502,t:1527188826601};\\\", \\\"{x:1337,y:501,t:1527188826611};\\\", \\\"{x:1332,y:501,t:1527188826628};\\\", \\\"{x:1327,y:500,t:1527188826643};\\\", \\\"{x:1319,y:498,t:1527188826663};\\\", \\\"{x:1313,y:497,t:1527188826677};\\\", \\\"{x:1312,y:497,t:1527188826693};\\\", \\\"{x:1311,y:496,t:1527188826760};\\\", \\\"{x:1310,y:498,t:1527188827497};\\\", \\\"{x:1310,y:503,t:1527188827513};\\\", \\\"{x:1310,y:520,t:1527188827529};\\\", \\\"{x:1310,y:549,t:1527188827544};\\\", \\\"{x:1310,y:573,t:1527188827565};\\\", \\\"{x:1313,y:601,t:1527188827578};\\\", \\\"{x:1313,y:624,t:1527188827595};\\\", \\\"{x:1313,y:645,t:1527188827612};\\\", \\\"{x:1314,y:677,t:1527188827628};\\\", \\\"{x:1321,y:715,t:1527188827645};\\\", \\\"{x:1323,y:750,t:1527188827662};\\\", \\\"{x:1330,y:783,t:1527188827678};\\\", \\\"{x:1333,y:815,t:1527188827695};\\\", \\\"{x:1338,y:842,t:1527188827712};\\\", \\\"{x:1338,y:857,t:1527188827728};\\\", \\\"{x:1339,y:880,t:1527188827745};\\\", \\\"{x:1342,y:889,t:1527188827762};\\\", \\\"{x:1342,y:899,t:1527188827778};\\\", \\\"{x:1342,y:900,t:1527188827795};\\\", \\\"{x:1342,y:901,t:1527188827812};\\\", \\\"{x:1342,y:902,t:1527188827937};\\\", \\\"{x:1342,y:905,t:1527188827976};\\\", \\\"{x:1342,y:906,t:1527188828001};\\\", \\\"{x:1342,y:909,t:1527188828012};\\\", \\\"{x:1342,y:910,t:1527188828106};\\\", \\\"{x:1342,y:911,t:1527188828112};\\\", \\\"{x:1343,y:912,t:1527188828209};\\\", \\\"{x:1344,y:915,t:1527188828216};\\\", \\\"{x:1344,y:917,t:1527188828229};\\\", \\\"{x:1347,y:921,t:1527188828245};\\\", \\\"{x:1347,y:924,t:1527188828262};\\\", \\\"{x:1347,y:925,t:1527188828337};\\\", \\\"{x:1347,y:928,t:1527188828361};\\\", \\\"{x:1345,y:933,t:1527188828379};\\\", \\\"{x:1345,y:937,t:1527188828396};\\\", \\\"{x:1345,y:938,t:1527188828412};\\\", \\\"{x:1345,y:940,t:1527188828429};\\\", \\\"{x:1343,y:941,t:1527188828446};\\\", \\\"{x:1343,y:942,t:1527188828462};\\\", \\\"{x:1343,y:943,t:1527188828479};\\\", \\\"{x:1343,y:944,t:1527188828497};\\\", \\\"{x:1342,y:945,t:1527188828609};\\\", \\\"{x:1342,y:947,t:1527188828625};\\\", \\\"{x:1342,y:948,t:1527188828633};\\\", \\\"{x:1341,y:950,t:1527188828646};\\\", \\\"{x:1340,y:954,t:1527188828662};\\\", \\\"{x:1339,y:957,t:1527188828679};\\\", \\\"{x:1339,y:958,t:1527188828696};\\\", \\\"{x:1340,y:961,t:1527188828713};\\\", \\\"{x:1339,y:961,t:1527188828897};\\\", \\\"{x:1339,y:958,t:1527188828913};\\\", \\\"{x:1339,y:953,t:1527188828929};\\\", \\\"{x:1339,y:945,t:1527188828947};\\\", \\\"{x:1339,y:931,t:1527188828963};\\\", \\\"{x:1339,y:917,t:1527188828979};\\\", \\\"{x:1339,y:897,t:1527188828996};\\\", \\\"{x:1338,y:876,t:1527188829013};\\\", \\\"{x:1335,y:852,t:1527188829029};\\\", \\\"{x:1335,y:832,t:1527188829046};\\\", \\\"{x:1335,y:805,t:1527188829064};\\\", \\\"{x:1335,y:782,t:1527188829080};\\\", \\\"{x:1335,y:761,t:1527188829096};\\\", \\\"{x:1332,y:732,t:1527188829113};\\\", \\\"{x:1329,y:712,t:1527188829130};\\\", \\\"{x:1327,y:697,t:1527188829146};\\\", \\\"{x:1327,y:682,t:1527188829164};\\\", \\\"{x:1325,y:660,t:1527188829180};\\\", \\\"{x:1325,y:640,t:1527188829196};\\\", \\\"{x:1325,y:629,t:1527188829212};\\\", \\\"{x:1325,y:616,t:1527188829230};\\\", \\\"{x:1324,y:604,t:1527188829246};\\\", \\\"{x:1324,y:598,t:1527188829263};\\\", \\\"{x:1324,y:592,t:1527188829280};\\\", \\\"{x:1324,y:584,t:1527188829296};\\\", \\\"{x:1324,y:573,t:1527188829313};\\\", \\\"{x:1324,y:566,t:1527188829330};\\\", \\\"{x:1324,y:558,t:1527188829346};\\\", \\\"{x:1324,y:554,t:1527188829364};\\\", \\\"{x:1324,y:551,t:1527188829380};\\\", \\\"{x:1324,y:546,t:1527188829396};\\\", \\\"{x:1324,y:540,t:1527188829413};\\\", \\\"{x:1324,y:535,t:1527188829430};\\\", \\\"{x:1323,y:528,t:1527188829446};\\\", \\\"{x:1323,y:519,t:1527188829463};\\\", \\\"{x:1322,y:515,t:1527188829480};\\\", \\\"{x:1321,y:509,t:1527188829496};\\\", \\\"{x:1321,y:506,t:1527188829513};\\\", \\\"{x:1320,y:502,t:1527188829529};\\\", \\\"{x:1320,y:499,t:1527188829546};\\\", \\\"{x:1319,y:497,t:1527188829563};\\\", \\\"{x:1319,y:494,t:1527188829580};\\\", \\\"{x:1319,y:492,t:1527188829598};\\\", \\\"{x:1320,y:491,t:1527188829769};\\\", \\\"{x:1327,y:491,t:1527188829780};\\\", \\\"{x:1344,y:491,t:1527188829797};\\\", \\\"{x:1364,y:493,t:1527188829813};\\\", \\\"{x:1389,y:497,t:1527188829830};\\\", \\\"{x:1414,y:501,t:1527188829847};\\\", \\\"{x:1432,y:505,t:1527188829863};\\\", \\\"{x:1441,y:505,t:1527188829880};\\\", \\\"{x:1446,y:506,t:1527188829895};\\\", \\\"{x:1446,y:508,t:1527188829935};\\\", \\\"{x:1447,y:511,t:1527188829946};\\\", \\\"{x:1454,y:524,t:1527188829963};\\\", \\\"{x:1463,y:545,t:1527188829980};\\\", \\\"{x:1472,y:567,t:1527188829997};\\\", \\\"{x:1480,y:587,t:1527188830013};\\\", \\\"{x:1488,y:610,t:1527188830030};\\\", \\\"{x:1494,y:639,t:1527188830047};\\\", \\\"{x:1501,y:686,t:1527188830064};\\\", \\\"{x:1504,y:738,t:1527188830080};\\\", \\\"{x:1504,y:836,t:1527188830097};\\\", \\\"{x:1506,y:873,t:1527188830114};\\\", \\\"{x:1511,y:898,t:1527188830130};\\\", \\\"{x:1516,y:915,t:1527188830147};\\\", \\\"{x:1518,y:927,t:1527188830164};\\\", \\\"{x:1519,y:934,t:1527188830180};\\\", \\\"{x:1520,y:947,t:1527188830197};\\\", \\\"{x:1525,y:963,t:1527188830214};\\\", \\\"{x:1530,y:980,t:1527188830230};\\\", \\\"{x:1535,y:993,t:1527188830247};\\\", \\\"{x:1537,y:997,t:1527188830264};\\\", \\\"{x:1538,y:997,t:1527188830393};\\\", \\\"{x:1539,y:995,t:1527188830400};\\\", \\\"{x:1539,y:994,t:1527188830414};\\\", \\\"{x:1539,y:992,t:1527188830430};\\\", \\\"{x:1539,y:989,t:1527188830447};\\\", \\\"{x:1539,y:986,t:1527188830464};\\\", \\\"{x:1539,y:982,t:1527188830480};\\\", \\\"{x:1539,y:980,t:1527188830497};\\\", \\\"{x:1539,y:979,t:1527188830514};\\\", \\\"{x:1539,y:978,t:1527188830545};\\\", \\\"{x:1539,y:977,t:1527188830561};\\\", \\\"{x:1539,y:976,t:1527188830576};\\\", \\\"{x:1540,y:976,t:1527188830584};\\\", \\\"{x:1540,y:975,t:1527188830601};\\\", \\\"{x:1540,y:974,t:1527188830614};\\\", \\\"{x:1540,y:973,t:1527188830631};\\\", \\\"{x:1541,y:971,t:1527188830673};\\\", \\\"{x:1542,y:971,t:1527188830696};\\\", \\\"{x:1542,y:970,t:1527188830720};\\\", \\\"{x:1542,y:969,t:1527188830745};\\\", \\\"{x:1542,y:968,t:1527188830754};\\\", \\\"{x:1542,y:967,t:1527188830769};\\\", \\\"{x:1543,y:965,t:1527188830781};\\\", \\\"{x:1544,y:962,t:1527188830797};\\\", \\\"{x:1544,y:960,t:1527188830814};\\\", \\\"{x:1544,y:958,t:1527188830831};\\\", \\\"{x:1545,y:955,t:1527188830847};\\\", \\\"{x:1546,y:949,t:1527188830864};\\\", \\\"{x:1549,y:930,t:1527188830881};\\\", \\\"{x:1549,y:921,t:1527188830898};\\\", \\\"{x:1549,y:908,t:1527188830914};\\\", \\\"{x:1549,y:894,t:1527188830931};\\\", \\\"{x:1550,y:881,t:1527188830948};\\\", \\\"{x:1550,y:864,t:1527188830965};\\\", \\\"{x:1550,y:848,t:1527188830981};\\\", \\\"{x:1551,y:831,t:1527188830999};\\\", \\\"{x:1551,y:811,t:1527188831015};\\\", \\\"{x:1552,y:786,t:1527188831031};\\\", \\\"{x:1552,y:766,t:1527188831048};\\\", \\\"{x:1548,y:735,t:1527188831064};\\\", \\\"{x:1547,y:717,t:1527188831081};\\\", \\\"{x:1546,y:706,t:1527188831098};\\\", \\\"{x:1545,y:696,t:1527188831115};\\\", \\\"{x:1545,y:683,t:1527188831132};\\\", \\\"{x:1544,y:672,t:1527188831148};\\\", \\\"{x:1542,y:666,t:1527188831164};\\\", \\\"{x:1541,y:660,t:1527188831181};\\\", \\\"{x:1540,y:658,t:1527188831198};\\\", \\\"{x:1540,y:654,t:1527188831214};\\\", \\\"{x:1539,y:651,t:1527188831231};\\\", \\\"{x:1537,y:648,t:1527188831248};\\\", \\\"{x:1536,y:647,t:1527188831265};\\\", \\\"{x:1536,y:644,t:1527188831281};\\\", \\\"{x:1535,y:644,t:1527188831305};\\\", \\\"{x:1534,y:643,t:1527188831337};\\\", \\\"{x:1533,y:642,t:1527188831401};\\\", \\\"{x:1531,y:641,t:1527188831473};\\\", \\\"{x:1530,y:641,t:1527188831481};\\\", \\\"{x:1529,y:641,t:1527188831505};\\\", \\\"{x:1527,y:640,t:1527188831521};\\\", \\\"{x:1526,y:639,t:1527188831577};\\\", \\\"{x:1525,y:639,t:1527188831609};\\\", \\\"{x:1523,y:637,t:1527188831657};\\\", \\\"{x:1522,y:637,t:1527188831721};\\\", \\\"{x:1521,y:637,t:1527188831732};\\\", \\\"{x:1520,y:636,t:1527188831785};\\\", \\\"{x:1519,y:636,t:1527188831841};\\\", \\\"{x:1518,y:636,t:1527188831865};\\\", \\\"{x:1518,y:635,t:1527188831889};\\\", \\\"{x:1517,y:634,t:1527188831913};\\\", \\\"{x:1515,y:634,t:1527188831932};\\\", \\\"{x:1514,y:634,t:1527188831969};\\\", \\\"{x:1513,y:634,t:1527188832009};\\\", \\\"{x:1512,y:633,t:1527188832065};\\\", \\\"{x:1512,y:636,t:1527188833186};\\\", \\\"{x:1506,y:646,t:1527188833199};\\\", \\\"{x:1501,y:665,t:1527188833217};\\\", \\\"{x:1496,y:687,t:1527188833233};\\\", \\\"{x:1495,y:699,t:1527188833250};\\\", \\\"{x:1492,y:712,t:1527188833266};\\\", \\\"{x:1490,y:724,t:1527188833283};\\\", \\\"{x:1485,y:740,t:1527188833299};\\\", \\\"{x:1481,y:762,t:1527188833316};\\\", \\\"{x:1478,y:784,t:1527188833333};\\\", \\\"{x:1476,y:800,t:1527188833349};\\\", \\\"{x:1476,y:807,t:1527188833366};\\\", \\\"{x:1476,y:811,t:1527188833383};\\\", \\\"{x:1476,y:813,t:1527188833398};\\\", \\\"{x:1476,y:816,t:1527188833416};\\\", \\\"{x:1476,y:819,t:1527188833433};\\\", \\\"{x:1476,y:823,t:1527188833450};\\\", \\\"{x:1475,y:826,t:1527188833467};\\\", \\\"{x:1475,y:827,t:1527188833483};\\\", \\\"{x:1475,y:830,t:1527188834569};\\\", \\\"{x:1476,y:834,t:1527188834585};\\\", \\\"{x:1478,y:838,t:1527188834600};\\\", \\\"{x:1481,y:844,t:1527188834618};\\\", \\\"{x:1484,y:849,t:1527188834634};\\\", \\\"{x:1487,y:855,t:1527188834650};\\\", \\\"{x:1488,y:860,t:1527188834667};\\\", \\\"{x:1490,y:865,t:1527188834684};\\\", \\\"{x:1490,y:869,t:1527188834700};\\\", \\\"{x:1491,y:876,t:1527188834717};\\\", \\\"{x:1491,y:877,t:1527188834734};\\\", \\\"{x:1491,y:884,t:1527188834750};\\\", \\\"{x:1492,y:888,t:1527188834767};\\\", \\\"{x:1492,y:900,t:1527188834785};\\\", \\\"{x:1491,y:900,t:1527188835209};\\\", \\\"{x:1491,y:898,t:1527188835217};\\\", \\\"{x:1490,y:891,t:1527188835234};\\\", \\\"{x:1489,y:882,t:1527188835251};\\\", \\\"{x:1489,y:880,t:1527188835269};\\\", \\\"{x:1489,y:879,t:1527188835285};\\\", \\\"{x:1489,y:877,t:1527188835302};\\\", \\\"{x:1489,y:874,t:1527188835318};\\\", \\\"{x:1487,y:872,t:1527188835334};\\\", \\\"{x:1486,y:869,t:1527188835352};\\\", \\\"{x:1483,y:863,t:1527188835369};\\\", \\\"{x:1483,y:860,t:1527188835383};\\\", \\\"{x:1483,y:859,t:1527188835400};\\\", \\\"{x:1482,y:858,t:1527188835418};\\\", \\\"{x:1481,y:855,t:1527188835434};\\\", \\\"{x:1481,y:853,t:1527188835451};\\\", \\\"{x:1479,y:849,t:1527188835467};\\\", \\\"{x:1479,y:846,t:1527188835484};\\\", \\\"{x:1478,y:843,t:1527188835501};\\\", \\\"{x:1478,y:842,t:1527188835517};\\\", \\\"{x:1478,y:841,t:1527188835534};\\\", \\\"{x:1478,y:839,t:1527188835551};\\\", \\\"{x:1476,y:832,t:1527188835569};\\\", \\\"{x:1476,y:831,t:1527188835584};\\\", \\\"{x:1476,y:829,t:1527188835601};\\\", \\\"{x:1476,y:828,t:1527188835639};\\\", \\\"{x:1476,y:827,t:1527188835655};\\\", \\\"{x:1476,y:826,t:1527188835696};\\\", \\\"{x:1476,y:825,t:1527188835735};\\\", \\\"{x:1478,y:825,t:1527188835912};\\\", \\\"{x:1479,y:825,t:1527188835935};\\\", \\\"{x:1481,y:825,t:1527188835950};\\\", \\\"{x:1483,y:825,t:1527188835968};\\\", \\\"{x:1485,y:826,t:1527188835985};\\\", \\\"{x:1488,y:827,t:1527188836001};\\\", \\\"{x:1493,y:829,t:1527188836017};\\\", \\\"{x:1495,y:829,t:1527188836035};\\\", \\\"{x:1497,y:830,t:1527188836050};\\\", \\\"{x:1496,y:830,t:1527188836240};\\\", \\\"{x:1493,y:830,t:1527188836252};\\\", \\\"{x:1485,y:830,t:1527188836268};\\\", \\\"{x:1472,y:830,t:1527188836285};\\\", \\\"{x:1465,y:828,t:1527188836302};\\\", \\\"{x:1459,y:825,t:1527188836318};\\\", \\\"{x:1457,y:824,t:1527188836334};\\\", \\\"{x:1456,y:824,t:1527188836392};\\\", \\\"{x:1454,y:824,t:1527188836401};\\\", \\\"{x:1450,y:822,t:1527188836417};\\\", \\\"{x:1448,y:821,t:1527188836435};\\\", \\\"{x:1446,y:820,t:1527188836451};\\\", \\\"{x:1442,y:817,t:1527188836469};\\\", \\\"{x:1439,y:814,t:1527188836485};\\\", \\\"{x:1433,y:810,t:1527188836501};\\\", \\\"{x:1425,y:805,t:1527188836519};\\\", \\\"{x:1411,y:795,t:1527188836535};\\\", \\\"{x:1392,y:781,t:1527188836552};\\\", \\\"{x:1390,y:780,t:1527188836569};\\\", \\\"{x:1390,y:779,t:1527188836585};\\\", \\\"{x:1388,y:777,t:1527188836607};\\\", \\\"{x:1388,y:776,t:1527188836624};\\\", \\\"{x:1388,y:775,t:1527188836635};\\\", \\\"{x:1387,y:774,t:1527188836651};\\\", \\\"{x:1387,y:771,t:1527188836669};\\\", \\\"{x:1386,y:769,t:1527188836684};\\\", \\\"{x:1386,y:768,t:1527188836701};\\\", \\\"{x:1385,y:767,t:1527188837976};\\\", \\\"{x:1385,y:766,t:1527188837986};\\\", \\\"{x:1384,y:766,t:1527188838047};\\\", \\\"{x:1383,y:766,t:1527188838055};\\\", \\\"{x:1383,y:772,t:1527188838560};\\\", \\\"{x:1383,y:782,t:1527188838570};\\\", \\\"{x:1383,y:798,t:1527188838586};\\\", \\\"{x:1383,y:812,t:1527188838603};\\\", \\\"{x:1383,y:818,t:1527188838619};\\\", \\\"{x:1383,y:824,t:1527188838637};\\\", \\\"{x:1383,y:827,t:1527188838653};\\\", \\\"{x:1383,y:832,t:1527188838669};\\\", \\\"{x:1383,y:837,t:1527188838687};\\\", \\\"{x:1383,y:844,t:1527188838703};\\\", \\\"{x:1385,y:855,t:1527188838720};\\\", \\\"{x:1385,y:860,t:1527188838737};\\\", \\\"{x:1386,y:864,t:1527188838753};\\\", \\\"{x:1386,y:870,t:1527188838770};\\\", \\\"{x:1386,y:874,t:1527188838787};\\\", \\\"{x:1389,y:881,t:1527188838804};\\\", \\\"{x:1392,y:897,t:1527188838820};\\\", \\\"{x:1394,y:910,t:1527188838837};\\\", \\\"{x:1395,y:919,t:1527188838854};\\\", \\\"{x:1395,y:920,t:1527188838870};\\\", \\\"{x:1395,y:921,t:1527188838887};\\\", \\\"{x:1395,y:922,t:1527188838927};\\\", \\\"{x:1395,y:924,t:1527188838937};\\\", \\\"{x:1395,y:929,t:1527188838954};\\\", \\\"{x:1395,y:933,t:1527188838970};\\\", \\\"{x:1395,y:938,t:1527188838987};\\\", \\\"{x:1393,y:940,t:1527188839004};\\\", \\\"{x:1393,y:941,t:1527188839020};\\\", \\\"{x:1391,y:942,t:1527188839037};\\\", \\\"{x:1390,y:943,t:1527188839054};\\\", \\\"{x:1389,y:944,t:1527188839069};\\\", \\\"{x:1388,y:944,t:1527188839087};\\\", \\\"{x:1387,y:944,t:1527188839144};\\\", \\\"{x:1386,y:945,t:1527188839159};\\\", \\\"{x:1385,y:946,t:1527188839175};\\\", \\\"{x:1385,y:947,t:1527188839186};\\\", \\\"{x:1383,y:947,t:1527188839240};\\\", \\\"{x:1382,y:947,t:1527188839253};\\\", \\\"{x:1381,y:945,t:1527188839271};\\\", \\\"{x:1380,y:932,t:1527188839287};\\\", \\\"{x:1377,y:914,t:1527188839304};\\\", \\\"{x:1376,y:904,t:1527188839321};\\\", \\\"{x:1376,y:892,t:1527188839337};\\\", \\\"{x:1376,y:886,t:1527188839354};\\\", \\\"{x:1376,y:881,t:1527188839371};\\\", \\\"{x:1376,y:876,t:1527188839387};\\\", \\\"{x:1376,y:865,t:1527188839404};\\\", \\\"{x:1376,y:851,t:1527188839421};\\\", \\\"{x:1376,y:840,t:1527188839437};\\\", \\\"{x:1376,y:826,t:1527188839454};\\\", \\\"{x:1376,y:816,t:1527188839471};\\\", \\\"{x:1376,y:809,t:1527188839487};\\\", \\\"{x:1376,y:803,t:1527188839503};\\\", \\\"{x:1376,y:802,t:1527188839521};\\\", \\\"{x:1376,y:800,t:1527188839536};\\\", \\\"{x:1376,y:795,t:1527188839554};\\\", \\\"{x:1376,y:792,t:1527188839571};\\\", \\\"{x:1376,y:788,t:1527188839587};\\\", \\\"{x:1376,y:785,t:1527188839604};\\\", \\\"{x:1376,y:783,t:1527188839621};\\\", \\\"{x:1376,y:782,t:1527188839640};\\\", \\\"{x:1376,y:781,t:1527188839744};\\\", \\\"{x:1376,y:780,t:1527188839776};\\\", \\\"{x:1376,y:779,t:1527188839788};\\\", \\\"{x:1376,y:778,t:1527188839803};\\\", \\\"{x:1376,y:777,t:1527188839821};\\\", \\\"{x:1376,y:776,t:1527188839847};\\\", \\\"{x:1377,y:776,t:1527188840040};\\\", \\\"{x:1377,y:775,t:1527188840152};\\\", \\\"{x:1377,y:774,t:1527188840168};\\\", \\\"{x:1377,y:773,t:1527188840312};\\\", \\\"{x:1378,y:773,t:1527188840321};\\\", \\\"{x:1378,y:772,t:1527188840344};\\\", \\\"{x:1379,y:771,t:1527188840376};\\\", \\\"{x:1380,y:770,t:1527188840536};\\\", \\\"{x:1378,y:771,t:1527188841760};\\\", \\\"{x:1376,y:772,t:1527188841773};\\\", \\\"{x:1368,y:778,t:1527188841789};\\\", \\\"{x:1361,y:781,t:1527188841806};\\\", \\\"{x:1358,y:783,t:1527188841823};\\\", \\\"{x:1357,y:784,t:1527188841839};\\\", \\\"{x:1355,y:785,t:1527188841856};\\\", \\\"{x:1355,y:786,t:1527188841873};\\\", \\\"{x:1353,y:787,t:1527188841889};\\\", \\\"{x:1352,y:789,t:1527188841906};\\\", \\\"{x:1352,y:786,t:1527188842080};\\\", \\\"{x:1352,y:784,t:1527188842089};\\\", \\\"{x:1352,y:780,t:1527188842106};\\\", \\\"{x:1356,y:777,t:1527188842123};\\\", \\\"{x:1362,y:772,t:1527188842139};\\\", \\\"{x:1372,y:765,t:1527188842156};\\\", \\\"{x:1378,y:761,t:1527188842173};\\\", \\\"{x:1382,y:759,t:1527188842190};\\\", \\\"{x:1387,y:755,t:1527188842206};\\\", \\\"{x:1394,y:750,t:1527188842222};\\\", \\\"{x:1400,y:741,t:1527188842240};\\\", \\\"{x:1405,y:733,t:1527188842256};\\\", \\\"{x:1413,y:724,t:1527188842273};\\\", \\\"{x:1423,y:713,t:1527188842290};\\\", \\\"{x:1432,y:699,t:1527188842306};\\\", \\\"{x:1441,y:684,t:1527188842323};\\\", \\\"{x:1458,y:664,t:1527188842340};\\\", \\\"{x:1469,y:646,t:1527188842356};\\\", \\\"{x:1477,y:634,t:1527188842373};\\\", \\\"{x:1484,y:620,t:1527188842390};\\\", \\\"{x:1488,y:610,t:1527188842406};\\\", \\\"{x:1489,y:605,t:1527188842423};\\\", \\\"{x:1490,y:604,t:1527188842439};\\\", \\\"{x:1490,y:603,t:1527188842456};\\\", \\\"{x:1490,y:602,t:1527188842473};\\\", \\\"{x:1491,y:602,t:1527188842687};\\\", \\\"{x:1491,y:603,t:1527188842696};\\\", \\\"{x:1492,y:603,t:1527188842706};\\\", \\\"{x:1492,y:604,t:1527188842808};\\\", \\\"{x:1492,y:605,t:1527188842823};\\\", \\\"{x:1492,y:611,t:1527188842839};\\\", \\\"{x:1495,y:615,t:1527188842857};\\\", \\\"{x:1496,y:619,t:1527188842872};\\\", \\\"{x:1498,y:621,t:1527188842890};\\\", \\\"{x:1498,y:622,t:1527188842907};\\\", \\\"{x:1500,y:624,t:1527188842923};\\\", \\\"{x:1500,y:625,t:1527188842943};\\\", \\\"{x:1500,y:626,t:1527188842957};\\\", \\\"{x:1501,y:627,t:1527188842973};\\\", \\\"{x:1501,y:629,t:1527188842990};\\\", \\\"{x:1502,y:629,t:1527188843080};\\\", \\\"{x:1502,y:630,t:1527188843200};\\\", \\\"{x:1503,y:630,t:1527188843207};\\\", \\\"{x:1507,y:630,t:1527188843223};\\\", \\\"{x:1509,y:630,t:1527188843240};\\\", \\\"{x:1511,y:630,t:1527188843256};\\\", \\\"{x:1512,y:630,t:1527188843274};\\\", \\\"{x:1513,y:630,t:1527188843290};\\\", \\\"{x:1514,y:630,t:1527188843351};\\\", \\\"{x:1515,y:630,t:1527188843688};\\\", \\\"{x:1515,y:634,t:1527188843695};\\\", \\\"{x:1515,y:641,t:1527188843707};\\\", \\\"{x:1515,y:655,t:1527188843724};\\\", \\\"{x:1515,y:667,t:1527188843741};\\\", \\\"{x:1515,y:681,t:1527188843757};\\\", \\\"{x:1516,y:700,t:1527188843774};\\\", \\\"{x:1517,y:725,t:1527188843791};\\\", \\\"{x:1517,y:747,t:1527188843807};\\\", \\\"{x:1517,y:771,t:1527188843824};\\\", \\\"{x:1518,y:778,t:1527188843841};\\\", \\\"{x:1518,y:786,t:1527188843856};\\\", \\\"{x:1518,y:811,t:1527188843874};\\\", \\\"{x:1518,y:842,t:1527188843891};\\\", \\\"{x:1518,y:863,t:1527188843906};\\\", \\\"{x:1518,y:879,t:1527188843924};\\\", \\\"{x:1518,y:883,t:1527188843941};\\\", \\\"{x:1518,y:886,t:1527188843958};\\\", \\\"{x:1518,y:893,t:1527188843974};\\\", \\\"{x:1518,y:898,t:1527188843991};\\\", \\\"{x:1518,y:908,t:1527188844007};\\\", \\\"{x:1518,y:912,t:1527188844024};\\\", \\\"{x:1518,y:915,t:1527188844041};\\\", \\\"{x:1519,y:916,t:1527188844058};\\\", \\\"{x:1520,y:921,t:1527188844074};\\\", \\\"{x:1522,y:927,t:1527188844091};\\\", \\\"{x:1524,y:933,t:1527188844108};\\\", \\\"{x:1527,y:939,t:1527188844124};\\\", \\\"{x:1528,y:939,t:1527188844141};\\\", \\\"{x:1528,y:940,t:1527188844158};\\\", \\\"{x:1529,y:941,t:1527188844215};\\\", \\\"{x:1529,y:943,t:1527188844279};\\\", \\\"{x:1531,y:946,t:1527188844291};\\\", \\\"{x:1534,y:951,t:1527188844308};\\\", \\\"{x:1536,y:956,t:1527188844324};\\\", \\\"{x:1537,y:959,t:1527188844341};\\\", \\\"{x:1538,y:960,t:1527188844359};\\\", \\\"{x:1538,y:958,t:1527188844680};\\\", \\\"{x:1538,y:955,t:1527188844691};\\\", \\\"{x:1538,y:941,t:1527188844708};\\\", \\\"{x:1538,y:919,t:1527188844725};\\\", \\\"{x:1538,y:896,t:1527188844741};\\\", \\\"{x:1537,y:873,t:1527188844758};\\\", \\\"{x:1531,y:851,t:1527188844775};\\\", \\\"{x:1529,y:818,t:1527188844791};\\\", \\\"{x:1524,y:791,t:1527188844808};\\\", \\\"{x:1519,y:769,t:1527188844825};\\\", \\\"{x:1512,y:751,t:1527188844841};\\\", \\\"{x:1505,y:732,t:1527188844858};\\\", \\\"{x:1498,y:719,t:1527188844875};\\\", \\\"{x:1493,y:707,t:1527188844892};\\\", \\\"{x:1488,y:695,t:1527188844907};\\\", \\\"{x:1484,y:686,t:1527188844925};\\\", \\\"{x:1479,y:676,t:1527188844942};\\\", \\\"{x:1474,y:664,t:1527188844958};\\\", \\\"{x:1471,y:656,t:1527188844975};\\\", \\\"{x:1466,y:649,t:1527188844991};\\\", \\\"{x:1465,y:647,t:1527188845008};\\\", \\\"{x:1464,y:645,t:1527188845025};\\\", \\\"{x:1463,y:643,t:1527188845042};\\\", \\\"{x:1460,y:637,t:1527188845058};\\\", \\\"{x:1459,y:632,t:1527188845075};\\\", \\\"{x:1457,y:628,t:1527188845092};\\\", \\\"{x:1455,y:625,t:1527188845108};\\\", \\\"{x:1452,y:619,t:1527188845125};\\\", \\\"{x:1451,y:616,t:1527188845142};\\\", \\\"{x:1450,y:614,t:1527188845158};\\\", \\\"{x:1449,y:611,t:1527188845175};\\\", \\\"{x:1448,y:605,t:1527188845192};\\\", \\\"{x:1447,y:598,t:1527188845208};\\\", \\\"{x:1446,y:594,t:1527188845225};\\\", \\\"{x:1444,y:587,t:1527188845242};\\\", \\\"{x:1443,y:584,t:1527188845259};\\\", \\\"{x:1443,y:580,t:1527188845275};\\\", \\\"{x:1443,y:578,t:1527188845292};\\\", \\\"{x:1443,y:571,t:1527188845309};\\\", \\\"{x:1443,y:564,t:1527188845324};\\\", \\\"{x:1443,y:556,t:1527188845342};\\\", \\\"{x:1443,y:546,t:1527188845359};\\\", \\\"{x:1443,y:539,t:1527188845375};\\\", \\\"{x:1443,y:532,t:1527188845392};\\\", \\\"{x:1443,y:527,t:1527188845409};\\\", \\\"{x:1443,y:524,t:1527188845425};\\\", \\\"{x:1443,y:522,t:1527188845447};\\\", \\\"{x:1442,y:521,t:1527188845504};\\\", \\\"{x:1441,y:521,t:1527188845552};\\\", \\\"{x:1438,y:521,t:1527188845559};\\\", \\\"{x:1432,y:524,t:1527188845575};\\\", \\\"{x:1420,y:538,t:1527188845592};\\\", \\\"{x:1411,y:548,t:1527188845609};\\\", \\\"{x:1406,y:555,t:1527188845626};\\\", \\\"{x:1404,y:557,t:1527188845642};\\\", \\\"{x:1403,y:558,t:1527188845659};\\\", \\\"{x:1403,y:559,t:1527188845887};\\\", \\\"{x:1407,y:559,t:1527188845912};\\\", \\\"{x:1408,y:559,t:1527188846040};\\\", \\\"{x:1410,y:559,t:1527188846105};\\\", \\\"{x:1411,y:560,t:1527188846184};\\\", \\\"{x:1411,y:561,t:1527188846216};\\\", \\\"{x:1411,y:565,t:1527188846227};\\\", \\\"{x:1414,y:577,t:1527188846244};\\\", \\\"{x:1414,y:596,t:1527188846259};\\\", \\\"{x:1416,y:614,t:1527188846277};\\\", \\\"{x:1419,y:633,t:1527188846294};\\\", \\\"{x:1421,y:647,t:1527188846310};\\\", \\\"{x:1422,y:667,t:1527188846327};\\\", \\\"{x:1423,y:690,t:1527188846344};\\\", \\\"{x:1423,y:715,t:1527188846360};\\\", \\\"{x:1423,y:747,t:1527188846376};\\\", \\\"{x:1426,y:758,t:1527188846394};\\\", \\\"{x:1427,y:767,t:1527188846410};\\\", \\\"{x:1430,y:784,t:1527188846426};\\\", \\\"{x:1435,y:804,t:1527188846443};\\\", \\\"{x:1442,y:826,t:1527188846460};\\\", \\\"{x:1446,y:840,t:1527188846477};\\\", \\\"{x:1448,y:849,t:1527188846493};\\\", \\\"{x:1448,y:857,t:1527188846510};\\\", \\\"{x:1448,y:863,t:1527188846526};\\\", \\\"{x:1449,y:875,t:1527188846543};\\\", \\\"{x:1449,y:889,t:1527188846560};\\\", \\\"{x:1449,y:904,t:1527188846576};\\\", \\\"{x:1449,y:911,t:1527188846594};\\\", \\\"{x:1449,y:916,t:1527188846610};\\\", \\\"{x:1449,y:917,t:1527188846626};\\\", \\\"{x:1449,y:921,t:1527188846644};\\\", \\\"{x:1447,y:925,t:1527188846661};\\\", \\\"{x:1446,y:931,t:1527188846677};\\\", \\\"{x:1443,y:939,t:1527188846694};\\\", \\\"{x:1443,y:941,t:1527188846710};\\\", \\\"{x:1442,y:944,t:1527188846727};\\\", \\\"{x:1442,y:945,t:1527188846744};\\\", \\\"{x:1441,y:949,t:1527188846761};\\\", \\\"{x:1441,y:952,t:1527188846777};\\\", \\\"{x:1440,y:956,t:1527188846793};\\\", \\\"{x:1440,y:958,t:1527188846810};\\\", \\\"{x:1440,y:959,t:1527188846864};\\\", \\\"{x:1440,y:958,t:1527188846984};\\\", \\\"{x:1440,y:951,t:1527188846994};\\\", \\\"{x:1440,y:935,t:1527188847012};\\\", \\\"{x:1440,y:911,t:1527188847027};\\\", \\\"{x:1442,y:880,t:1527188847043};\\\", \\\"{x:1445,y:853,t:1527188847060};\\\", \\\"{x:1445,y:823,t:1527188847078};\\\", \\\"{x:1445,y:791,t:1527188847094};\\\", \\\"{x:1445,y:755,t:1527188847111};\\\", \\\"{x:1445,y:729,t:1527188847128};\\\", \\\"{x:1445,y:706,t:1527188847143};\\\", \\\"{x:1445,y:683,t:1527188847160};\\\", \\\"{x:1445,y:669,t:1527188847178};\\\", \\\"{x:1445,y:658,t:1527188847194};\\\", \\\"{x:1444,y:646,t:1527188847211};\\\", \\\"{x:1443,y:632,t:1527188847228};\\\", \\\"{x:1439,y:621,t:1527188847244};\\\", \\\"{x:1438,y:616,t:1527188847261};\\\", \\\"{x:1437,y:613,t:1527188847278};\\\", \\\"{x:1436,y:611,t:1527188847294};\\\", \\\"{x:1436,y:609,t:1527188847311};\\\", \\\"{x:1433,y:606,t:1527188847327};\\\", \\\"{x:1432,y:602,t:1527188847344};\\\", \\\"{x:1429,y:596,t:1527188847361};\\\", \\\"{x:1425,y:587,t:1527188847377};\\\", \\\"{x:1419,y:579,t:1527188847394};\\\", \\\"{x:1416,y:574,t:1527188847410};\\\", \\\"{x:1415,y:571,t:1527188847428};\\\", \\\"{x:1413,y:568,t:1527188847444};\\\", \\\"{x:1412,y:566,t:1527188847461};\\\", \\\"{x:1412,y:565,t:1527188847478};\\\", \\\"{x:1411,y:573,t:1527188847770};\\\", \\\"{x:1411,y:587,t:1527188847777};\\\", \\\"{x:1411,y:606,t:1527188847794};\\\", \\\"{x:1411,y:628,t:1527188847810};\\\", \\\"{x:1411,y:649,t:1527188847827};\\\", \\\"{x:1411,y:671,t:1527188847845};\\\", \\\"{x:1415,y:694,t:1527188847860};\\\", \\\"{x:1418,y:709,t:1527188847878};\\\", \\\"{x:1422,y:728,t:1527188847895};\\\", \\\"{x:1426,y:752,t:1527188847911};\\\", \\\"{x:1433,y:780,t:1527188847927};\\\", \\\"{x:1444,y:819,t:1527188847944};\\\", \\\"{x:1447,y:835,t:1527188847962};\\\", \\\"{x:1449,y:848,t:1527188847977};\\\", \\\"{x:1454,y:865,t:1527188847995};\\\", \\\"{x:1458,y:882,t:1527188848012};\\\", \\\"{x:1463,y:897,t:1527188848028};\\\", \\\"{x:1464,y:907,t:1527188848045};\\\", \\\"{x:1464,y:915,t:1527188848062};\\\", \\\"{x:1464,y:921,t:1527188848078};\\\", \\\"{x:1464,y:927,t:1527188848095};\\\", \\\"{x:1464,y:936,t:1527188848112};\\\", \\\"{x:1464,y:939,t:1527188848128};\\\", \\\"{x:1467,y:945,t:1527188848145};\\\", \\\"{x:1467,y:946,t:1527188848163};\\\", \\\"{x:1467,y:950,t:1527188848178};\\\", \\\"{x:1467,y:951,t:1527188848195};\\\", \\\"{x:1467,y:953,t:1527188848212};\\\", \\\"{x:1465,y:953,t:1527188848377};\\\", \\\"{x:1463,y:953,t:1527188848384};\\\", \\\"{x:1463,y:950,t:1527188848395};\\\", \\\"{x:1459,y:937,t:1527188848412};\\\", \\\"{x:1454,y:914,t:1527188848429};\\\", \\\"{x:1446,y:884,t:1527188848445};\\\", \\\"{x:1442,y:859,t:1527188848462};\\\", \\\"{x:1440,y:837,t:1527188848479};\\\", \\\"{x:1436,y:814,t:1527188848495};\\\", \\\"{x:1435,y:788,t:1527188848512};\\\", \\\"{x:1433,y:746,t:1527188848528};\\\", \\\"{x:1429,y:724,t:1527188848545};\\\", \\\"{x:1428,y:708,t:1527188848563};\\\", \\\"{x:1427,y:698,t:1527188848579};\\\", \\\"{x:1427,y:687,t:1527188848595};\\\", \\\"{x:1425,y:674,t:1527188848612};\\\", \\\"{x:1422,y:659,t:1527188848629};\\\", \\\"{x:1421,y:650,t:1527188848645};\\\", \\\"{x:1420,y:643,t:1527188848662};\\\", \\\"{x:1419,y:636,t:1527188848678};\\\", \\\"{x:1417,y:634,t:1527188848695};\\\", \\\"{x:1417,y:632,t:1527188848712};\\\", \\\"{x:1417,y:631,t:1527188848729};\\\", \\\"{x:1416,y:628,t:1527188848744};\\\", \\\"{x:1415,y:625,t:1527188848763};\\\", \\\"{x:1415,y:621,t:1527188848779};\\\", \\\"{x:1414,y:618,t:1527188848796};\\\", \\\"{x:1413,y:614,t:1527188848811};\\\", \\\"{x:1413,y:612,t:1527188848828};\\\", \\\"{x:1413,y:611,t:1527188848846};\\\", \\\"{x:1413,y:609,t:1527188848862};\\\", \\\"{x:1413,y:604,t:1527188848879};\\\", \\\"{x:1413,y:598,t:1527188848896};\\\", \\\"{x:1413,y:592,t:1527188848912};\\\", \\\"{x:1413,y:585,t:1527188848928};\\\", \\\"{x:1413,y:583,t:1527188848946};\\\", \\\"{x:1413,y:582,t:1527188848963};\\\", \\\"{x:1413,y:580,t:1527188848979};\\\", \\\"{x:1413,y:579,t:1527188849000};\\\", \\\"{x:1412,y:580,t:1527188849144};\\\", \\\"{x:1412,y:592,t:1527188849163};\\\", \\\"{x:1410,y:605,t:1527188849179};\\\", \\\"{x:1410,y:611,t:1527188849196};\\\", \\\"{x:1409,y:619,t:1527188849212};\\\", \\\"{x:1408,y:629,t:1527188849229};\\\", \\\"{x:1408,y:648,t:1527188849245};\\\", \\\"{x:1408,y:670,t:1527188849263};\\\", \\\"{x:1408,y:693,t:1527188849279};\\\", \\\"{x:1408,y:716,t:1527188849295};\\\", \\\"{x:1412,y:744,t:1527188849313};\\\", \\\"{x:1417,y:759,t:1527188849329};\\\", \\\"{x:1420,y:775,t:1527188849346};\\\", \\\"{x:1422,y:793,t:1527188849364};\\\", \\\"{x:1425,y:808,t:1527188849378};\\\", \\\"{x:1427,y:824,t:1527188849395};\\\", \\\"{x:1428,y:835,t:1527188849412};\\\", \\\"{x:1430,y:843,t:1527188849428};\\\", \\\"{x:1431,y:851,t:1527188849445};\\\", \\\"{x:1432,y:863,t:1527188849462};\\\", \\\"{x:1436,y:878,t:1527188849478};\\\", \\\"{x:1438,y:890,t:1527188849495};\\\", \\\"{x:1440,y:898,t:1527188849511};\\\", \\\"{x:1441,y:900,t:1527188849528};\\\", \\\"{x:1441,y:904,t:1527188849545};\\\", \\\"{x:1441,y:907,t:1527188849562};\\\", \\\"{x:1442,y:913,t:1527188849579};\\\", \\\"{x:1443,y:921,t:1527188849596};\\\", \\\"{x:1444,y:926,t:1527188849613};\\\", \\\"{x:1444,y:929,t:1527188849629};\\\", \\\"{x:1444,y:927,t:1527188849776};\\\", \\\"{x:1443,y:922,t:1527188849784};\\\", \\\"{x:1443,y:916,t:1527188849795};\\\", \\\"{x:1442,y:897,t:1527188849813};\\\", \\\"{x:1439,y:875,t:1527188849830};\\\", \\\"{x:1437,y:856,t:1527188849846};\\\", \\\"{x:1432,y:831,t:1527188849862};\\\", \\\"{x:1421,y:790,t:1527188849879};\\\", \\\"{x:1418,y:776,t:1527188849895};\\\", \\\"{x:1407,y:737,t:1527188849912};\\\", \\\"{x:1404,y:716,t:1527188849930};\\\", \\\"{x:1400,y:697,t:1527188849946};\\\", \\\"{x:1398,y:679,t:1527188849963};\\\", \\\"{x:1396,y:666,t:1527188849980};\\\", \\\"{x:1393,y:657,t:1527188849996};\\\", \\\"{x:1392,y:648,t:1527188850012};\\\", \\\"{x:1389,y:637,t:1527188850030};\\\", \\\"{x:1387,y:630,t:1527188850046};\\\", \\\"{x:1387,y:623,t:1527188850063};\\\", \\\"{x:1387,y:620,t:1527188850080};\\\", \\\"{x:1386,y:618,t:1527188850097};\\\", \\\"{x:1386,y:623,t:1527188850240};\\\", \\\"{x:1386,y:635,t:1527188850248};\\\", \\\"{x:1386,y:646,t:1527188850263};\\\", \\\"{x:1386,y:674,t:1527188850280};\\\", \\\"{x:1385,y:711,t:1527188850296};\\\", \\\"{x:1385,y:725,t:1527188850313};\\\", \\\"{x:1385,y:731,t:1527188850329};\\\", \\\"{x:1384,y:735,t:1527188850347};\\\", \\\"{x:1382,y:742,t:1527188850364};\\\", \\\"{x:1381,y:751,t:1527188850380};\\\", \\\"{x:1379,y:760,t:1527188850398};\\\", \\\"{x:1377,y:766,t:1527188850412};\\\", \\\"{x:1376,y:770,t:1527188850430};\\\", \\\"{x:1376,y:772,t:1527188850447};\\\", \\\"{x:1376,y:773,t:1527188850464};\\\", \\\"{x:1378,y:772,t:1527188850673};\\\", \\\"{x:1380,y:769,t:1527188850680};\\\", \\\"{x:1381,y:764,t:1527188850696};\\\", \\\"{x:1382,y:761,t:1527188850714};\\\", \\\"{x:1383,y:760,t:1527188850730};\\\", \\\"{x:1383,y:759,t:1527188850746};\\\", \\\"{x:1384,y:760,t:1527188850872};\\\", \\\"{x:1385,y:767,t:1527188850880};\\\", \\\"{x:1386,y:779,t:1527188850898};\\\", \\\"{x:1389,y:790,t:1527188850914};\\\", \\\"{x:1393,y:801,t:1527188850930};\\\", \\\"{x:1395,y:808,t:1527188850947};\\\", \\\"{x:1397,y:817,t:1527188850964};\\\", \\\"{x:1399,y:825,t:1527188850981};\\\", \\\"{x:1403,y:835,t:1527188850997};\\\", \\\"{x:1404,y:841,t:1527188851014};\\\", \\\"{x:1405,y:846,t:1527188851031};\\\", \\\"{x:1406,y:849,t:1527188851047};\\\", \\\"{x:1406,y:858,t:1527188851065};\\\", \\\"{x:1406,y:864,t:1527188851080};\\\", \\\"{x:1406,y:868,t:1527188851096};\\\", \\\"{x:1406,y:874,t:1527188851113};\\\", \\\"{x:1406,y:879,t:1527188851131};\\\", \\\"{x:1406,y:885,t:1527188851147};\\\", \\\"{x:1406,y:892,t:1527188851164};\\\", \\\"{x:1406,y:898,t:1527188851181};\\\", \\\"{x:1406,y:905,t:1527188851197};\\\", \\\"{x:1406,y:913,t:1527188851214};\\\", \\\"{x:1406,y:919,t:1527188851231};\\\", \\\"{x:1406,y:924,t:1527188851247};\\\", \\\"{x:1406,y:930,t:1527188851264};\\\", \\\"{x:1405,y:935,t:1527188851280};\\\", \\\"{x:1405,y:938,t:1527188851297};\\\", \\\"{x:1405,y:943,t:1527188851314};\\\", \\\"{x:1403,y:946,t:1527188851331};\\\", \\\"{x:1402,y:951,t:1527188851346};\\\", \\\"{x:1402,y:955,t:1527188851364};\\\", \\\"{x:1401,y:959,t:1527188851381};\\\", \\\"{x:1399,y:961,t:1527188851397};\\\", \\\"{x:1399,y:962,t:1527188851414};\\\", \\\"{x:1398,y:964,t:1527188851431};\\\", \\\"{x:1397,y:964,t:1527188851496};\\\", \\\"{x:1394,y:964,t:1527188851513};\\\", \\\"{x:1391,y:962,t:1527188851531};\\\", \\\"{x:1388,y:949,t:1527188851548};\\\", \\\"{x:1386,y:933,t:1527188851564};\\\", \\\"{x:1384,y:913,t:1527188851581};\\\", \\\"{x:1382,y:888,t:1527188851598};\\\", \\\"{x:1378,y:864,t:1527188851614};\\\", \\\"{x:1377,y:841,t:1527188851631};\\\", \\\"{x:1376,y:816,t:1527188851648};\\\", \\\"{x:1376,y:804,t:1527188851664};\\\", \\\"{x:1376,y:794,t:1527188851681};\\\", \\\"{x:1376,y:786,t:1527188851698};\\\", \\\"{x:1376,y:780,t:1527188851714};\\\", \\\"{x:1378,y:770,t:1527188851731};\\\", \\\"{x:1379,y:761,t:1527188851748};\\\", \\\"{x:1379,y:757,t:1527188851764};\\\", \\\"{x:1379,y:751,t:1527188851780};\\\", \\\"{x:1381,y:746,t:1527188851797};\\\", \\\"{x:1382,y:743,t:1527188851815};\\\", \\\"{x:1383,y:749,t:1527188851945};\\\", \\\"{x:1383,y:760,t:1527188851952};\\\", \\\"{x:1383,y:771,t:1527188851966};\\\", \\\"{x:1383,y:790,t:1527188851980};\\\", \\\"{x:1383,y:809,t:1527188851997};\\\", \\\"{x:1383,y:832,t:1527188852015};\\\", \\\"{x:1384,y:852,t:1527188852031};\\\", \\\"{x:1388,y:874,t:1527188852048};\\\", \\\"{x:1389,y:882,t:1527188852064};\\\", \\\"{x:1389,y:889,t:1527188852080};\\\", \\\"{x:1390,y:895,t:1527188852098};\\\", \\\"{x:1390,y:901,t:1527188852114};\\\", \\\"{x:1391,y:906,t:1527188852131};\\\", \\\"{x:1391,y:912,t:1527188852148};\\\", \\\"{x:1391,y:918,t:1527188852165};\\\", \\\"{x:1391,y:924,t:1527188852181};\\\", \\\"{x:1391,y:929,t:1527188852198};\\\", \\\"{x:1391,y:931,t:1527188852215};\\\", \\\"{x:1391,y:934,t:1527188852231};\\\", \\\"{x:1391,y:938,t:1527188852248};\\\", \\\"{x:1390,y:942,t:1527188852265};\\\", \\\"{x:1389,y:945,t:1527188852282};\\\", \\\"{x:1388,y:947,t:1527188852298};\\\", \\\"{x:1386,y:951,t:1527188852315};\\\", \\\"{x:1383,y:958,t:1527188852332};\\\", \\\"{x:1381,y:965,t:1527188852348};\\\", \\\"{x:1380,y:970,t:1527188852365};\\\", \\\"{x:1379,y:972,t:1527188852382};\\\", \\\"{x:1378,y:972,t:1527188852398};\\\", \\\"{x:1378,y:970,t:1527188852457};\\\", \\\"{x:1378,y:963,t:1527188852464};\\\", \\\"{x:1375,y:943,t:1527188852482};\\\", \\\"{x:1375,y:920,t:1527188852498};\\\", \\\"{x:1375,y:892,t:1527188852515};\\\", \\\"{x:1375,y:866,t:1527188852532};\\\", \\\"{x:1375,y:843,t:1527188852547};\\\", \\\"{x:1375,y:828,t:1527188852565};\\\", \\\"{x:1375,y:818,t:1527188852582};\\\", \\\"{x:1375,y:811,t:1527188852598};\\\", \\\"{x:1375,y:804,t:1527188852615};\\\", \\\"{x:1377,y:794,t:1527188852633};\\\", \\\"{x:1379,y:790,t:1527188852649};\\\", \\\"{x:1379,y:787,t:1527188852665};\\\", \\\"{x:1380,y:783,t:1527188852682};\\\", \\\"{x:1381,y:781,t:1527188852699};\\\", \\\"{x:1381,y:780,t:1527188852720};\\\", \\\"{x:1381,y:781,t:1527188852896};\\\", \\\"{x:1381,y:786,t:1527188852905};\\\", \\\"{x:1381,y:794,t:1527188852915};\\\", \\\"{x:1380,y:807,t:1527188852932};\\\", \\\"{x:1380,y:819,t:1527188852949};\\\", \\\"{x:1380,y:828,t:1527188852965};\\\", \\\"{x:1380,y:835,t:1527188852982};\\\", \\\"{x:1380,y:840,t:1527188852999};\\\", \\\"{x:1381,y:849,t:1527188853015};\\\", \\\"{x:1384,y:858,t:1527188853032};\\\", \\\"{x:1385,y:864,t:1527188853049};\\\", \\\"{x:1386,y:868,t:1527188853065};\\\", \\\"{x:1386,y:875,t:1527188853082};\\\", \\\"{x:1387,y:880,t:1527188853099};\\\", \\\"{x:1387,y:885,t:1527188853115};\\\", \\\"{x:1387,y:888,t:1527188853132};\\\", \\\"{x:1387,y:893,t:1527188853149};\\\", \\\"{x:1389,y:897,t:1527188853166};\\\", \\\"{x:1390,y:902,t:1527188853182};\\\", \\\"{x:1391,y:908,t:1527188853199};\\\", \\\"{x:1393,y:917,t:1527188853216};\\\", \\\"{x:1393,y:923,t:1527188853232};\\\", \\\"{x:1393,y:926,t:1527188853248};\\\", \\\"{x:1393,y:931,t:1527188853267};\\\", \\\"{x:1393,y:938,t:1527188853282};\\\", \\\"{x:1393,y:943,t:1527188853299};\\\", \\\"{x:1394,y:947,t:1527188853316};\\\", \\\"{x:1395,y:948,t:1527188853332};\\\", \\\"{x:1396,y:950,t:1527188853349};\\\", \\\"{x:1397,y:951,t:1527188853366};\\\", \\\"{x:1393,y:947,t:1527188853584};\\\", \\\"{x:1393,y:945,t:1527188853599};\\\", \\\"{x:1393,y:937,t:1527188853617};\\\", \\\"{x:1393,y:929,t:1527188853633};\\\", \\\"{x:1393,y:916,t:1527188853649};\\\", \\\"{x:1393,y:901,t:1527188853666};\\\", \\\"{x:1393,y:887,t:1527188853683};\\\", \\\"{x:1393,y:874,t:1527188853699};\\\", \\\"{x:1393,y:863,t:1527188853716};\\\", \\\"{x:1393,y:851,t:1527188853733};\\\", \\\"{x:1393,y:836,t:1527188853749};\\\", \\\"{x:1391,y:823,t:1527188853766};\\\", \\\"{x:1391,y:818,t:1527188853783};\\\", \\\"{x:1391,y:813,t:1527188853799};\\\", \\\"{x:1389,y:807,t:1527188853816};\\\", \\\"{x:1389,y:805,t:1527188853832};\\\", \\\"{x:1389,y:802,t:1527188853849};\\\", \\\"{x:1389,y:797,t:1527188853866};\\\", \\\"{x:1389,y:794,t:1527188853883};\\\", \\\"{x:1388,y:790,t:1527188853899};\\\", \\\"{x:1388,y:787,t:1527188853916};\\\", \\\"{x:1387,y:786,t:1527188853932};\\\", \\\"{x:1387,y:785,t:1527188853952};\\\", \\\"{x:1387,y:784,t:1527188853969};\\\", \\\"{x:1387,y:783,t:1527188853986};\\\", \\\"{x:1386,y:782,t:1527188854003};\\\", \\\"{x:1386,y:780,t:1527188854019};\\\", \\\"{x:1385,y:778,t:1527188854037};\\\", \\\"{x:1385,y:776,t:1527188854053};\\\", \\\"{x:1384,y:774,t:1527188854070};\\\", \\\"{x:1383,y:771,t:1527188854086};\\\", \\\"{x:1382,y:769,t:1527188854103};\\\", \\\"{x:1382,y:768,t:1527188854120};\\\", \\\"{x:1382,y:767,t:1527188854136};\\\", \\\"{x:1382,y:772,t:1527188854260};\\\", \\\"{x:1382,y:778,t:1527188854270};\\\", \\\"{x:1382,y:794,t:1527188854286};\\\", \\\"{x:1382,y:815,t:1527188854304};\\\", \\\"{x:1386,y:836,t:1527188854319};\\\", \\\"{x:1393,y:857,t:1527188854336};\\\", \\\"{x:1399,y:876,t:1527188854353};\\\", \\\"{x:1401,y:894,t:1527188854370};\\\", \\\"{x:1404,y:903,t:1527188854386};\\\", \\\"{x:1405,y:907,t:1527188854404};\\\", \\\"{x:1405,y:899,t:1527188854508};\\\", \\\"{x:1405,y:890,t:1527188854519};\\\", \\\"{x:1404,y:864,t:1527188854536};\\\", \\\"{x:1400,y:834,t:1527188854553};\\\", \\\"{x:1392,y:804,t:1527188854571};\\\", \\\"{x:1385,y:782,t:1527188854587};\\\", \\\"{x:1371,y:748,t:1527188854603};\\\", \\\"{x:1366,y:729,t:1527188854620};\\\", \\\"{x:1358,y:710,t:1527188854636};\\\", \\\"{x:1355,y:691,t:1527188854654};\\\", \\\"{x:1351,y:678,t:1527188854670};\\\", \\\"{x:1346,y:664,t:1527188854687};\\\", \\\"{x:1343,y:657,t:1527188854704};\\\", \\\"{x:1342,y:654,t:1527188854720};\\\", \\\"{x:1341,y:652,t:1527188854736};\\\", \\\"{x:1340,y:651,t:1527188854753};\\\", \\\"{x:1339,y:649,t:1527188854787};\\\", \\\"{x:1337,y:646,t:1527188854804};\\\", \\\"{x:1334,y:645,t:1527188854820};\\\", \\\"{x:1332,y:642,t:1527188854838};\\\", \\\"{x:1328,y:640,t:1527188854853};\\\", \\\"{x:1327,y:639,t:1527188854870};\\\", \\\"{x:1325,y:638,t:1527188854887};\\\", \\\"{x:1324,y:638,t:1527188854903};\\\", \\\"{x:1323,y:637,t:1527188854920};\\\", \\\"{x:1320,y:636,t:1527188854937};\\\", \\\"{x:1319,y:635,t:1527188854954};\\\", \\\"{x:1319,y:643,t:1527188855491};\\\", \\\"{x:1319,y:654,t:1527188855505};\\\", \\\"{x:1320,y:669,t:1527188855520};\\\", \\\"{x:1322,y:686,t:1527188855537};\\\", \\\"{x:1324,y:700,t:1527188855555};\\\", \\\"{x:1326,y:712,t:1527188855570};\\\", \\\"{x:1326,y:742,t:1527188855587};\\\", \\\"{x:1326,y:762,t:1527188855604};\\\", \\\"{x:1326,y:777,t:1527188855621};\\\", \\\"{x:1326,y:788,t:1527188855637};\\\", \\\"{x:1326,y:798,t:1527188855655};\\\", \\\"{x:1326,y:807,t:1527188855671};\\\", \\\"{x:1326,y:816,t:1527188855688};\\\", \\\"{x:1326,y:828,t:1527188855705};\\\", \\\"{x:1325,y:840,t:1527188855721};\\\", \\\"{x:1325,y:847,t:1527188855738};\\\", \\\"{x:1323,y:855,t:1527188855755};\\\", \\\"{x:1323,y:864,t:1527188855772};\\\", \\\"{x:1323,y:875,t:1527188855788};\\\", \\\"{x:1323,y:887,t:1527188855805};\\\", \\\"{x:1323,y:904,t:1527188855822};\\\", \\\"{x:1325,y:918,t:1527188855838};\\\", \\\"{x:1326,y:927,t:1527188855855};\\\", \\\"{x:1327,y:935,t:1527188855871};\\\", \\\"{x:1330,y:941,t:1527188855888};\\\", \\\"{x:1330,y:947,t:1527188855905};\\\", \\\"{x:1330,y:954,t:1527188855922};\\\", \\\"{x:1330,y:957,t:1527188855938};\\\", \\\"{x:1330,y:961,t:1527188855955};\\\", \\\"{x:1331,y:968,t:1527188855972};\\\", \\\"{x:1333,y:973,t:1527188855989};\\\", \\\"{x:1333,y:975,t:1527188856005};\\\", \\\"{x:1333,y:976,t:1527188856022};\\\", \\\"{x:1333,y:968,t:1527188856125};\\\", \\\"{x:1332,y:960,t:1527188856138};\\\", \\\"{x:1331,y:941,t:1527188856155};\\\", \\\"{x:1331,y:907,t:1527188856172};\\\", \\\"{x:1331,y:885,t:1527188856189};\\\", \\\"{x:1331,y:863,t:1527188856206};\\\", \\\"{x:1331,y:834,t:1527188856222};\\\", \\\"{x:1333,y:807,t:1527188856239};\\\", \\\"{x:1334,y:780,t:1527188856256};\\\", \\\"{x:1334,y:753,t:1527188856272};\\\", \\\"{x:1333,y:729,t:1527188856289};\\\", \\\"{x:1332,y:718,t:1527188856305};\\\", \\\"{x:1332,y:707,t:1527188856322};\\\", \\\"{x:1329,y:694,t:1527188856340};\\\", \\\"{x:1327,y:679,t:1527188856355};\\\", \\\"{x:1323,y:660,t:1527188856372};\\\", \\\"{x:1319,y:648,t:1527188856389};\\\", \\\"{x:1317,y:637,t:1527188856405};\\\", \\\"{x:1315,y:631,t:1527188856422};\\\", \\\"{x:1314,y:627,t:1527188856439};\\\", \\\"{x:1314,y:625,t:1527188856455};\\\", \\\"{x:1313,y:622,t:1527188856473};\\\", \\\"{x:1313,y:618,t:1527188856489};\\\", \\\"{x:1313,y:614,t:1527188856505};\\\", \\\"{x:1311,y:610,t:1527188856522};\\\", \\\"{x:1310,y:609,t:1527188856605};\\\", \\\"{x:1306,y:612,t:1527188856622};\\\", \\\"{x:1302,y:623,t:1527188856640};\\\", \\\"{x:1298,y:635,t:1527188856656};\\\", \\\"{x:1294,y:650,t:1527188856673};\\\", \\\"{x:1293,y:664,t:1527188856689};\\\", \\\"{x:1292,y:678,t:1527188856706};\\\", \\\"{x:1292,y:693,t:1527188856722};\\\", \\\"{x:1292,y:711,t:1527188856740};\\\", \\\"{x:1292,y:745,t:1527188856756};\\\", \\\"{x:1292,y:767,t:1527188856772};\\\", \\\"{x:1292,y:788,t:1527188856788};\\\", \\\"{x:1294,y:808,t:1527188856806};\\\", \\\"{x:1296,y:826,t:1527188856821};\\\", \\\"{x:1299,y:839,t:1527188856838};\\\", \\\"{x:1303,y:849,t:1527188856856};\\\", \\\"{x:1305,y:862,t:1527188856872};\\\", \\\"{x:1309,y:874,t:1527188856889};\\\", \\\"{x:1310,y:883,t:1527188856905};\\\", \\\"{x:1310,y:890,t:1527188856921};\\\", \\\"{x:1310,y:895,t:1527188856938};\\\", \\\"{x:1310,y:906,t:1527188856956};\\\", \\\"{x:1312,y:911,t:1527188856973};\\\", \\\"{x:1313,y:920,t:1527188856989};\\\", \\\"{x:1314,y:931,t:1527188857006};\\\", \\\"{x:1315,y:944,t:1527188857022};\\\", \\\"{x:1315,y:957,t:1527188857039};\\\", \\\"{x:1315,y:969,t:1527188857056};\\\", \\\"{x:1315,y:977,t:1527188857073};\\\", \\\"{x:1315,y:985,t:1527188857089};\\\", \\\"{x:1315,y:988,t:1527188857107};\\\", \\\"{x:1315,y:989,t:1527188857124};\\\", \\\"{x:1315,y:990,t:1527188857139};\\\", \\\"{x:1316,y:989,t:1527188857229};\\\", \\\"{x:1317,y:984,t:1527188857239};\\\", \\\"{x:1322,y:967,t:1527188857256};\\\", \\\"{x:1329,y:949,t:1527188857273};\\\", \\\"{x:1336,y:924,t:1527188857289};\\\", \\\"{x:1342,y:896,t:1527188857306};\\\", \\\"{x:1346,y:869,t:1527188857324};\\\", \\\"{x:1351,y:833,t:1527188857339};\\\", \\\"{x:1356,y:793,t:1527188857356};\\\", \\\"{x:1356,y:774,t:1527188857373};\\\", \\\"{x:1356,y:761,t:1527188857389};\\\", \\\"{x:1356,y:751,t:1527188857406};\\\", \\\"{x:1356,y:743,t:1527188857423};\\\", \\\"{x:1356,y:737,t:1527188857439};\\\", \\\"{x:1356,y:731,t:1527188857456};\\\", \\\"{x:1356,y:721,t:1527188857473};\\\", \\\"{x:1356,y:716,t:1527188857489};\\\", \\\"{x:1356,y:713,t:1527188857506};\\\", \\\"{x:1356,y:708,t:1527188857524};\\\", \\\"{x:1356,y:701,t:1527188857540};\\\", \\\"{x:1356,y:691,t:1527188857556};\\\", \\\"{x:1356,y:679,t:1527188857573};\\\", \\\"{x:1356,y:669,t:1527188857590};\\\", \\\"{x:1356,y:662,t:1527188857606};\\\", \\\"{x:1354,y:651,t:1527188857623};\\\", \\\"{x:1352,y:638,t:1527188857640};\\\", \\\"{x:1351,y:633,t:1527188857656};\\\", \\\"{x:1350,y:630,t:1527188857673};\\\", \\\"{x:1348,y:627,t:1527188857691};\\\", \\\"{x:1347,y:624,t:1527188857706};\\\", \\\"{x:1344,y:619,t:1527188857723};\\\", \\\"{x:1343,y:616,t:1527188857740};\\\", \\\"{x:1342,y:616,t:1527188857756};\\\", \\\"{x:1342,y:615,t:1527188857773};\\\", \\\"{x:1337,y:615,t:1527188858180};\\\", \\\"{x:1327,y:620,t:1527188858191};\\\", \\\"{x:1309,y:634,t:1527188858207};\\\", \\\"{x:1291,y:647,t:1527188858223};\\\", \\\"{x:1288,y:650,t:1527188858240};\\\", \\\"{x:1288,y:651,t:1527188858257};\\\", \\\"{x:1287,y:653,t:1527188858276};\\\", \\\"{x:1286,y:656,t:1527188858291};\\\", \\\"{x:1285,y:665,t:1527188858307};\\\", \\\"{x:1285,y:679,t:1527188858324};\\\", \\\"{x:1285,y:701,t:1527188858340};\\\", \\\"{x:1285,y:715,t:1527188858357};\\\", \\\"{x:1288,y:726,t:1527188858373};\\\", \\\"{x:1292,y:741,t:1527188858390};\\\", \\\"{x:1295,y:760,t:1527188858407};\\\", \\\"{x:1297,y:778,t:1527188858424};\\\", \\\"{x:1300,y:796,t:1527188858440};\\\", \\\"{x:1303,y:817,t:1527188858457};\\\", \\\"{x:1303,y:838,t:1527188858474};\\\", \\\"{x:1303,y:857,t:1527188858490};\\\", \\\"{x:1303,y:868,t:1527188858507};\\\", \\\"{x:1306,y:886,t:1527188858524};\\\", \\\"{x:1307,y:897,t:1527188858540};\\\", \\\"{x:1308,y:907,t:1527188858558};\\\", \\\"{x:1308,y:917,t:1527188858574};\\\", \\\"{x:1308,y:923,t:1527188858590};\\\", \\\"{x:1308,y:931,t:1527188858607};\\\", \\\"{x:1308,y:939,t:1527188858624};\\\", \\\"{x:1308,y:948,t:1527188858640};\\\", \\\"{x:1308,y:952,t:1527188858657};\\\", \\\"{x:1308,y:956,t:1527188858674};\\\", \\\"{x:1307,y:958,t:1527188858690};\\\", \\\"{x:1307,y:959,t:1527188858707};\\\", \\\"{x:1307,y:961,t:1527188858724};\\\", \\\"{x:1307,y:959,t:1527188858892};\\\", \\\"{x:1307,y:953,t:1527188858907};\\\", \\\"{x:1306,y:932,t:1527188858924};\\\", \\\"{x:1305,y:914,t:1527188858941};\\\", \\\"{x:1305,y:902,t:1527188858957};\\\", \\\"{x:1305,y:890,t:1527188858974};\\\", \\\"{x:1305,y:882,t:1527188858991};\\\", \\\"{x:1305,y:871,t:1527188859007};\\\", \\\"{x:1305,y:860,t:1527188859025};\\\", \\\"{x:1305,y:846,t:1527188859041};\\\", \\\"{x:1305,y:832,t:1527188859058};\\\", \\\"{x:1305,y:824,t:1527188859074};\\\", \\\"{x:1305,y:816,t:1527188859092};\\\", \\\"{x:1306,y:809,t:1527188859107};\\\", \\\"{x:1310,y:786,t:1527188859124};\\\", \\\"{x:1312,y:774,t:1527188859141};\\\", \\\"{x:1314,y:761,t:1527188859157};\\\", \\\"{x:1316,y:750,t:1527188859174};\\\", \\\"{x:1317,y:742,t:1527188859191};\\\", \\\"{x:1318,y:735,t:1527188859207};\\\", \\\"{x:1319,y:728,t:1527188859224};\\\", \\\"{x:1322,y:716,t:1527188859241};\\\", \\\"{x:1323,y:704,t:1527188859258};\\\", \\\"{x:1327,y:691,t:1527188859274};\\\", \\\"{x:1332,y:673,t:1527188859291};\\\", \\\"{x:1338,y:648,t:1527188859308};\\\", \\\"{x:1339,y:642,t:1527188859324};\\\", \\\"{x:1339,y:636,t:1527188859341};\\\", \\\"{x:1341,y:627,t:1527188859358};\\\", \\\"{x:1341,y:622,t:1527188859374};\\\", \\\"{x:1341,y:620,t:1527188859390};\\\", \\\"{x:1341,y:619,t:1527188859407};\\\", \\\"{x:1341,y:625,t:1527188859532};\\\", \\\"{x:1341,y:634,t:1527188859541};\\\", \\\"{x:1339,y:658,t:1527188859557};\\\", \\\"{x:1337,y:679,t:1527188859574};\\\", \\\"{x:1337,y:699,t:1527188859591};\\\", \\\"{x:1337,y:720,t:1527188859608};\\\", \\\"{x:1338,y:742,t:1527188859624};\\\", \\\"{x:1338,y:768,t:1527188859641};\\\", \\\"{x:1338,y:793,t:1527188859657};\\\", \\\"{x:1338,y:821,t:1527188859674};\\\", \\\"{x:1338,y:841,t:1527188859691};\\\", \\\"{x:1336,y:862,t:1527188859708};\\\", \\\"{x:1335,y:872,t:1527188859725};\\\", \\\"{x:1335,y:886,t:1527188859741};\\\", \\\"{x:1335,y:894,t:1527188859758};\\\", \\\"{x:1335,y:904,t:1527188859774};\\\", \\\"{x:1334,y:916,t:1527188859791};\\\", \\\"{x:1332,y:926,t:1527188859807};\\\", \\\"{x:1331,y:932,t:1527188859825};\\\", \\\"{x:1328,y:939,t:1527188859841};\\\", \\\"{x:1326,y:946,t:1527188859858};\\\", \\\"{x:1325,y:951,t:1527188859875};\\\", \\\"{x:1324,y:951,t:1527188859890};\\\", \\\"{x:1324,y:952,t:1527188859955};\\\", \\\"{x:1323,y:952,t:1527188859971};\\\", \\\"{x:1322,y:949,t:1527188859980};\\\", \\\"{x:1322,y:943,t:1527188859990};\\\", \\\"{x:1322,y:927,t:1527188860008};\\\", \\\"{x:1322,y:908,t:1527188860025};\\\", \\\"{x:1322,y:886,t:1527188860041};\\\", \\\"{x:1322,y:863,t:1527188860058};\\\", \\\"{x:1322,y:838,t:1527188860075};\\\", \\\"{x:1322,y:813,t:1527188860091};\\\", \\\"{x:1323,y:781,t:1527188860108};\\\", \\\"{x:1326,y:763,t:1527188860125};\\\", \\\"{x:1328,y:746,t:1527188860143};\\\", \\\"{x:1328,y:734,t:1527188860159};\\\", \\\"{x:1328,y:725,t:1527188860176};\\\", \\\"{x:1328,y:721,t:1527188860192};\\\", \\\"{x:1328,y:717,t:1527188860208};\\\", \\\"{x:1328,y:710,t:1527188860225};\\\", \\\"{x:1328,y:705,t:1527188860242};\\\", \\\"{x:1328,y:698,t:1527188860258};\\\", \\\"{x:1328,y:691,t:1527188860275};\\\", \\\"{x:1327,y:684,t:1527188860292};\\\", \\\"{x:1326,y:682,t:1527188860308};\\\", \\\"{x:1325,y:679,t:1527188860325};\\\", \\\"{x:1325,y:677,t:1527188860343};\\\", \\\"{x:1325,y:676,t:1527188860364};\\\", \\\"{x:1325,y:674,t:1527188860388};\\\", \\\"{x:1324,y:673,t:1527188860396};\\\", \\\"{x:1323,y:672,t:1527188860412};\\\", \\\"{x:1323,y:671,t:1527188860426};\\\", \\\"{x:1323,y:670,t:1527188860444};\\\", \\\"{x:1323,y:669,t:1527188860458};\\\", \\\"{x:1323,y:668,t:1527188860677};\\\", \\\"{x:1323,y:666,t:1527188860692};\\\", \\\"{x:1323,y:664,t:1527188860709};\\\", \\\"{x:1323,y:663,t:1527188860725};\\\", \\\"{x:1323,y:660,t:1527188860742};\\\", \\\"{x:1323,y:657,t:1527188860759};\\\", \\\"{x:1323,y:655,t:1527188860775};\\\", \\\"{x:1323,y:654,t:1527188860792};\\\", \\\"{x:1323,y:652,t:1527188860808};\\\", \\\"{x:1323,y:651,t:1527188860824};\\\", \\\"{x:1323,y:649,t:1527188860842};\\\", \\\"{x:1323,y:648,t:1527188860860};\\\", \\\"{x:1323,y:647,t:1527188860875};\\\", \\\"{x:1323,y:646,t:1527188861052};\\\", \\\"{x:1322,y:644,t:1527188861084};\\\", \\\"{x:1321,y:643,t:1527188861091};\\\", \\\"{x:1321,y:642,t:1527188861109};\\\", \\\"{x:1321,y:641,t:1527188861140};\\\", \\\"{x:1321,y:639,t:1527188861453};\\\", \\\"{x:1320,y:639,t:1527188861460};\\\", \\\"{x:1319,y:635,t:1527188861476};\\\", \\\"{x:1319,y:633,t:1527188861494};\\\", \\\"{x:1318,y:631,t:1527188861509};\\\", \\\"{x:1316,y:628,t:1527188861526};\\\", \\\"{x:1315,y:627,t:1527188861547};\\\", \\\"{x:1315,y:626,t:1527188861563};\\\", \\\"{x:1315,y:625,t:1527188861596};\\\", \\\"{x:1315,y:624,t:1527188861620};\\\", \\\"{x:1315,y:623,t:1527188861636};\\\", \\\"{x:1314,y:622,t:1527188861652};\\\", \\\"{x:1314,y:621,t:1527188861660};\\\", \\\"{x:1313,y:619,t:1527188861676};\\\", \\\"{x:1313,y:618,t:1527188861700};\\\", \\\"{x:1312,y:617,t:1527188861709};\\\", \\\"{x:1312,y:622,t:1527188862076};\\\", \\\"{x:1312,y:637,t:1527188862094};\\\", \\\"{x:1312,y:658,t:1527188862110};\\\", \\\"{x:1312,y:680,t:1527188862126};\\\", \\\"{x:1316,y:697,t:1527188862143};\\\", \\\"{x:1319,y:709,t:1527188862161};\\\", \\\"{x:1321,y:718,t:1527188862176};\\\", \\\"{x:1321,y:729,t:1527188862193};\\\", \\\"{x:1327,y:749,t:1527188862210};\\\", \\\"{x:1331,y:766,t:1527188862227};\\\", \\\"{x:1332,y:780,t:1527188862243};\\\", \\\"{x:1336,y:793,t:1527188862260};\\\", \\\"{x:1337,y:802,t:1527188862276};\\\", \\\"{x:1339,y:810,t:1527188862294};\\\", \\\"{x:1339,y:818,t:1527188862310};\\\", \\\"{x:1340,y:831,t:1527188862328};\\\", \\\"{x:1341,y:838,t:1527188862343};\\\", \\\"{x:1341,y:845,t:1527188862360};\\\", \\\"{x:1341,y:854,t:1527188862378};\\\", \\\"{x:1343,y:867,t:1527188862394};\\\", \\\"{x:1346,y:883,t:1527188862410};\\\", \\\"{x:1348,y:898,t:1527188862428};\\\", \\\"{x:1348,y:913,t:1527188862444};\\\", \\\"{x:1348,y:929,t:1527188862460};\\\", \\\"{x:1348,y:935,t:1527188862478};\\\", \\\"{x:1348,y:938,t:1527188862493};\\\", \\\"{x:1348,y:939,t:1527188862510};\\\", \\\"{x:1348,y:940,t:1527188862527};\\\", \\\"{x:1348,y:942,t:1527188862544};\\\", \\\"{x:1348,y:943,t:1527188862560};\\\", \\\"{x:1348,y:944,t:1527188862577};\\\", \\\"{x:1348,y:945,t:1527188862629};\\\", \\\"{x:1348,y:946,t:1527188862643};\\\", \\\"{x:1348,y:948,t:1527188862660};\\\", \\\"{x:1348,y:947,t:1527188863668};\\\", \\\"{x:1348,y:946,t:1527188863679};\\\", \\\"{x:1348,y:945,t:1527188863700};\\\", \\\"{x:1348,y:943,t:1527188863712};\\\", \\\"{x:1348,y:940,t:1527188863729};\\\", \\\"{x:1348,y:936,t:1527188863744};\\\", \\\"{x:1346,y:932,t:1527188863762};\\\", \\\"{x:1345,y:928,t:1527188863778};\\\", \\\"{x:1345,y:922,t:1527188863794};\\\", \\\"{x:1345,y:915,t:1527188863811};\\\", \\\"{x:1345,y:901,t:1527188863828};\\\", \\\"{x:1344,y:881,t:1527188863845};\\\", \\\"{x:1343,y:863,t:1527188863862};\\\", \\\"{x:1340,y:847,t:1527188863879};\\\", \\\"{x:1338,y:835,t:1527188863894};\\\", \\\"{x:1336,y:829,t:1527188863912};\\\", \\\"{x:1334,y:820,t:1527188863929};\\\", \\\"{x:1333,y:810,t:1527188863945};\\\", \\\"{x:1332,y:804,t:1527188863961};\\\", \\\"{x:1332,y:798,t:1527188863978};\\\", \\\"{x:1331,y:796,t:1527188863994};\\\", \\\"{x:1330,y:795,t:1527188864011};\\\", \\\"{x:1329,y:791,t:1527188864027};\\\", \\\"{x:1326,y:784,t:1527188864044};\\\", \\\"{x:1319,y:773,t:1527188864060};\\\", \\\"{x:1314,y:764,t:1527188864078};\\\", \\\"{x:1310,y:758,t:1527188864095};\\\", \\\"{x:1307,y:750,t:1527188864111};\\\", \\\"{x:1300,y:740,t:1527188864128};\\\", \\\"{x:1298,y:731,t:1527188864145};\\\", \\\"{x:1294,y:724,t:1527188864161};\\\", \\\"{x:1293,y:722,t:1527188864178};\\\", \\\"{x:1292,y:719,t:1527188864195};\\\", \\\"{x:1292,y:717,t:1527188864211};\\\", \\\"{x:1291,y:714,t:1527188864228};\\\", \\\"{x:1291,y:710,t:1527188864246};\\\", \\\"{x:1290,y:704,t:1527188864261};\\\", \\\"{x:1288,y:697,t:1527188864278};\\\", \\\"{x:1288,y:690,t:1527188864295};\\\", \\\"{x:1288,y:683,t:1527188864311};\\\", \\\"{x:1286,y:678,t:1527188864329};\\\", \\\"{x:1286,y:674,t:1527188864345};\\\", \\\"{x:1284,y:665,t:1527188864362};\\\", \\\"{x:1284,y:660,t:1527188864379};\\\", \\\"{x:1285,y:658,t:1527188864396};\\\", \\\"{x:1285,y:656,t:1527188864412};\\\", \\\"{x:1287,y:651,t:1527188864428};\\\", \\\"{x:1288,y:648,t:1527188864445};\\\", \\\"{x:1289,y:646,t:1527188864461};\\\", \\\"{x:1291,y:643,t:1527188864478};\\\", \\\"{x:1292,y:642,t:1527188864495};\\\", \\\"{x:1294,y:639,t:1527188864513};\\\", \\\"{x:1296,y:634,t:1527188864528};\\\", \\\"{x:1297,y:632,t:1527188864545};\\\", \\\"{x:1298,y:630,t:1527188864562};\\\", \\\"{x:1299,y:628,t:1527188864580};\\\", \\\"{x:1300,y:626,t:1527188864604};\\\", \\\"{x:1301,y:626,t:1527188864805};\\\", \\\"{x:1302,y:628,t:1527188864820};\\\", \\\"{x:1301,y:634,t:1527188864828};\\\", \\\"{x:1296,y:647,t:1527188864845};\\\", \\\"{x:1289,y:665,t:1527188864863};\\\", \\\"{x:1284,y:681,t:1527188864879};\\\", \\\"{x:1277,y:702,t:1527188864895};\\\", \\\"{x:1272,y:721,t:1527188864912};\\\", \\\"{x:1268,y:738,t:1527188864928};\\\", \\\"{x:1267,y:755,t:1527188864946};\\\", \\\"{x:1267,y:769,t:1527188864962};\\\", \\\"{x:1267,y:782,t:1527188864979};\\\", \\\"{x:1267,y:797,t:1527188864996};\\\", \\\"{x:1271,y:840,t:1527188865012};\\\", \\\"{x:1281,y:876,t:1527188865028};\\\", \\\"{x:1287,y:906,t:1527188865045};\\\", \\\"{x:1290,y:915,t:1527188865062};\\\", \\\"{x:1290,y:908,t:1527188865252};\\\", \\\"{x:1290,y:893,t:1527188865263};\\\", \\\"{x:1290,y:873,t:1527188865280};\\\", \\\"{x:1293,y:853,t:1527188865295};\\\", \\\"{x:1299,y:833,t:1527188865313};\\\", \\\"{x:1301,y:809,t:1527188865329};\\\", \\\"{x:1304,y:790,t:1527188865345};\\\", \\\"{x:1306,y:772,t:1527188865363};\\\", \\\"{x:1309,y:751,t:1527188865379};\\\", \\\"{x:1307,y:720,t:1527188865396};\\\", \\\"{x:1306,y:702,t:1527188865413};\\\", \\\"{x:1306,y:684,t:1527188865430};\\\", \\\"{x:1306,y:673,t:1527188865447};\\\", \\\"{x:1309,y:662,t:1527188865462};\\\", \\\"{x:1309,y:655,t:1527188865480};\\\", \\\"{x:1310,y:652,t:1527188865497};\\\", \\\"{x:1311,y:649,t:1527188865513};\\\", \\\"{x:1312,y:644,t:1527188865529};\\\", \\\"{x:1312,y:642,t:1527188865548};\\\", \\\"{x:1313,y:642,t:1527188865884};\\\", \\\"{x:1313,y:646,t:1527188865896};\\\", \\\"{x:1313,y:654,t:1527188865914};\\\", \\\"{x:1312,y:668,t:1527188865929};\\\", \\\"{x:1312,y:682,t:1527188865946};\\\", \\\"{x:1312,y:697,t:1527188865963};\\\", \\\"{x:1311,y:714,t:1527188865979};\\\", \\\"{x:1311,y:749,t:1527188865996};\\\", \\\"{x:1314,y:783,t:1527188866013};\\\", \\\"{x:1315,y:824,t:1527188866029};\\\", \\\"{x:1316,y:861,t:1527188866047};\\\", \\\"{x:1320,y:888,t:1527188866063};\\\", \\\"{x:1322,y:910,t:1527188866079};\\\", \\\"{x:1326,y:929,t:1527188866096};\\\", \\\"{x:1329,y:945,t:1527188866113};\\\", \\\"{x:1330,y:956,t:1527188866130};\\\", \\\"{x:1330,y:962,t:1527188866146};\\\", \\\"{x:1331,y:966,t:1527188866163};\\\", \\\"{x:1332,y:968,t:1527188866180};\\\", \\\"{x:1332,y:971,t:1527188866197};\\\", \\\"{x:1332,y:972,t:1527188866213};\\\", \\\"{x:1332,y:973,t:1527188866229};\\\", \\\"{x:1331,y:973,t:1527188866300};\\\", \\\"{x:1329,y:973,t:1527188866313};\\\", \\\"{x:1327,y:973,t:1527188866331};\\\", \\\"{x:1325,y:963,t:1527188866347};\\\", \\\"{x:1323,y:946,t:1527188866364};\\\", \\\"{x:1322,y:908,t:1527188866380};\\\", \\\"{x:1321,y:879,t:1527188866397};\\\", \\\"{x:1320,y:858,t:1527188866413};\\\", \\\"{x:1317,y:838,t:1527188866430};\\\", \\\"{x:1316,y:819,t:1527188866447};\\\", \\\"{x:1316,y:800,t:1527188866463};\\\", \\\"{x:1316,y:783,t:1527188866480};\\\", \\\"{x:1316,y:764,t:1527188866496};\\\", \\\"{x:1315,y:746,t:1527188866513};\\\", \\\"{x:1315,y:731,t:1527188866531};\\\", \\\"{x:1315,y:724,t:1527188866546};\\\", \\\"{x:1315,y:715,t:1527188866563};\\\", \\\"{x:1315,y:706,t:1527188866580};\\\", \\\"{x:1315,y:700,t:1527188866596};\\\", \\\"{x:1315,y:695,t:1527188866613};\\\", \\\"{x:1316,y:690,t:1527188866631};\\\", \\\"{x:1317,y:685,t:1527188866646};\\\", \\\"{x:1317,y:679,t:1527188866663};\\\", \\\"{x:1317,y:676,t:1527188866680};\\\", \\\"{x:1318,y:671,t:1527188866697};\\\", \\\"{x:1320,y:665,t:1527188866714};\\\", \\\"{x:1321,y:659,t:1527188866731};\\\", \\\"{x:1321,y:656,t:1527188866747};\\\", \\\"{x:1321,y:654,t:1527188866764};\\\", \\\"{x:1321,y:653,t:1527188866780};\\\", \\\"{x:1320,y:663,t:1527188867069};\\\", \\\"{x:1320,y:668,t:1527188867080};\\\", \\\"{x:1315,y:683,t:1527188867097};\\\", \\\"{x:1314,y:697,t:1527188867114};\\\", \\\"{x:1312,y:712,t:1527188867130};\\\", \\\"{x:1309,y:730,t:1527188867148};\\\", \\\"{x:1304,y:765,t:1527188867164};\\\", \\\"{x:1301,y:792,t:1527188867181};\\\", \\\"{x:1298,y:815,t:1527188867198};\\\", \\\"{x:1298,y:835,t:1527188867215};\\\", \\\"{x:1298,y:852,t:1527188867230};\\\", \\\"{x:1298,y:866,t:1527188867247};\\\", \\\"{x:1297,y:883,t:1527188867265};\\\", \\\"{x:1297,y:895,t:1527188867280};\\\", \\\"{x:1297,y:905,t:1527188867297};\\\", \\\"{x:1297,y:912,t:1527188867314};\\\", \\\"{x:1297,y:916,t:1527188867330};\\\", \\\"{x:1297,y:921,t:1527188867347};\\\", \\\"{x:1297,y:927,t:1527188867364};\\\", \\\"{x:1296,y:933,t:1527188867381};\\\", \\\"{x:1295,y:936,t:1527188867397};\\\", \\\"{x:1295,y:937,t:1527188867415};\\\", \\\"{x:1295,y:938,t:1527188867460};\\\", \\\"{x:1294,y:934,t:1527188867659};\\\", \\\"{x:1294,y:931,t:1527188867667};\\\", \\\"{x:1293,y:929,t:1527188867681};\\\", \\\"{x:1292,y:923,t:1527188867697};\\\", \\\"{x:1292,y:918,t:1527188867714};\\\", \\\"{x:1291,y:914,t:1527188867731};\\\", \\\"{x:1291,y:909,t:1527188867747};\\\", \\\"{x:1291,y:907,t:1527188867764};\\\", \\\"{x:1292,y:902,t:1527188867781};\\\", \\\"{x:1294,y:896,t:1527188867797};\\\", \\\"{x:1295,y:888,t:1527188867814};\\\", \\\"{x:1295,y:884,t:1527188867831};\\\", \\\"{x:1296,y:880,t:1527188867847};\\\", \\\"{x:1296,y:878,t:1527188867864};\\\", \\\"{x:1296,y:875,t:1527188867881};\\\", \\\"{x:1296,y:872,t:1527188867897};\\\", \\\"{x:1298,y:868,t:1527188867914};\\\", \\\"{x:1299,y:861,t:1527188867931};\\\", \\\"{x:1300,y:852,t:1527188867948};\\\", \\\"{x:1300,y:848,t:1527188867964};\\\", \\\"{x:1302,y:841,t:1527188867981};\\\", \\\"{x:1303,y:838,t:1527188867998};\\\", \\\"{x:1303,y:832,t:1527188868014};\\\", \\\"{x:1304,y:822,t:1527188868031};\\\", \\\"{x:1304,y:814,t:1527188868049};\\\", \\\"{x:1304,y:807,t:1527188868065};\\\", \\\"{x:1304,y:803,t:1527188868082};\\\", \\\"{x:1306,y:797,t:1527188868099};\\\", \\\"{x:1306,y:792,t:1527188868114};\\\", \\\"{x:1306,y:786,t:1527188868131};\\\", \\\"{x:1306,y:780,t:1527188868149};\\\", \\\"{x:1306,y:778,t:1527188868165};\\\", \\\"{x:1306,y:777,t:1527188868181};\\\", \\\"{x:1305,y:779,t:1527188868532};\\\", \\\"{x:1301,y:793,t:1527188868549};\\\", \\\"{x:1298,y:801,t:1527188868565};\\\", \\\"{x:1296,y:805,t:1527188868581};\\\", \\\"{x:1295,y:808,t:1527188868598};\\\", \\\"{x:1294,y:809,t:1527188868619};\\\", \\\"{x:1293,y:811,t:1527188868636};\\\", \\\"{x:1292,y:812,t:1527188868652};\\\", \\\"{x:1291,y:814,t:1527188868666};\\\", \\\"{x:1289,y:818,t:1527188868681};\\\", \\\"{x:1286,y:824,t:1527188868698};\\\", \\\"{x:1285,y:826,t:1527188868716};\\\", \\\"{x:1284,y:828,t:1527188868731};\\\", \\\"{x:1283,y:830,t:1527188868780};\\\", \\\"{x:1281,y:831,t:1527188868788};\\\", \\\"{x:1281,y:832,t:1527188868799};\\\", \\\"{x:1279,y:834,t:1527188868815};\\\", \\\"{x:1278,y:834,t:1527188869332};\\\", \\\"{x:1278,y:833,t:1527188875356};\\\", \\\"{x:1286,y:829,t:1527188875371};\\\", \\\"{x:1302,y:820,t:1527188875388};\\\", \\\"{x:1314,y:807,t:1527188875404};\\\", \\\"{x:1322,y:801,t:1527188875421};\\\", \\\"{x:1323,y:799,t:1527188875437};\\\", \\\"{x:1324,y:799,t:1527188875454};\\\", \\\"{x:1332,y:808,t:1527188875470};\\\", \\\"{x:1343,y:837,t:1527188875488};\\\", \\\"{x:1345,y:853,t:1527188875504};\\\", \\\"{x:1345,y:861,t:1527188875521};\\\", \\\"{x:1345,y:863,t:1527188875537};\\\", \\\"{x:1345,y:865,t:1527188875556};\\\", \\\"{x:1345,y:866,t:1527188875571};\\\", \\\"{x:1343,y:875,t:1527188875587};\\\", \\\"{x:1340,y:881,t:1527188875604};\\\", \\\"{x:1340,y:886,t:1527188875620};\\\", \\\"{x:1336,y:889,t:1527188875638};\\\", \\\"{x:1335,y:891,t:1527188875654};\\\", \\\"{x:1334,y:893,t:1527188875671};\\\", \\\"{x:1333,y:894,t:1527188875688};\\\", \\\"{x:1333,y:885,t:1527188876021};\\\", \\\"{x:1333,y:856,t:1527188876038};\\\", \\\"{x:1335,y:823,t:1527188876055};\\\", \\\"{x:1344,y:772,t:1527188876071};\\\", \\\"{x:1344,y:714,t:1527188876088};\\\", \\\"{x:1344,y:669,t:1527188876104};\\\", \\\"{x:1344,y:632,t:1527188876121};\\\", \\\"{x:1344,y:602,t:1527188876137};\\\", \\\"{x:1336,y:576,t:1527188876155};\\\", \\\"{x:1333,y:562,t:1527188876170};\\\", \\\"{x:1325,y:536,t:1527188876188};\\\", \\\"{x:1323,y:526,t:1527188876204};\\\", \\\"{x:1319,y:514,t:1527188876221};\\\", \\\"{x:1316,y:504,t:1527188876238};\\\", \\\"{x:1314,y:499,t:1527188876255};\\\", \\\"{x:1314,y:501,t:1527188876452};\\\", \\\"{x:1314,y:510,t:1527188876460};\\\", \\\"{x:1314,y:521,t:1527188876472};\\\", \\\"{x:1314,y:549,t:1527188876488};\\\", \\\"{x:1314,y:582,t:1527188876504};\\\", \\\"{x:1314,y:615,t:1527188876522};\\\", \\\"{x:1314,y:652,t:1527188876539};\\\", \\\"{x:1314,y:679,t:1527188876555};\\\", \\\"{x:1314,y:738,t:1527188876572};\\\", \\\"{x:1314,y:766,t:1527188876588};\\\", \\\"{x:1314,y:788,t:1527188876605};\\\", \\\"{x:1314,y:806,t:1527188876622};\\\", \\\"{x:1314,y:819,t:1527188876638};\\\", \\\"{x:1317,y:831,t:1527188876655};\\\", \\\"{x:1317,y:839,t:1527188876672};\\\", \\\"{x:1317,y:847,t:1527188876688};\\\", \\\"{x:1317,y:853,t:1527188876705};\\\", \\\"{x:1317,y:861,t:1527188876721};\\\", \\\"{x:1317,y:866,t:1527188876739};\\\", \\\"{x:1321,y:871,t:1527188876755};\\\", \\\"{x:1324,y:884,t:1527188876771};\\\", \\\"{x:1327,y:893,t:1527188876788};\\\", \\\"{x:1329,y:905,t:1527188876804};\\\", \\\"{x:1331,y:915,t:1527188876821};\\\", \\\"{x:1331,y:922,t:1527188876838};\\\", \\\"{x:1331,y:929,t:1527188876854};\\\", \\\"{x:1333,y:938,t:1527188876871};\\\", \\\"{x:1334,y:944,t:1527188876888};\\\", \\\"{x:1336,y:946,t:1527188876904};\\\", \\\"{x:1336,y:948,t:1527188876922};\\\", \\\"{x:1337,y:948,t:1527188876978};\\\", \\\"{x:1338,y:952,t:1527188877187};\\\", \\\"{x:1338,y:959,t:1527188877195};\\\", \\\"{x:1338,y:962,t:1527188877206};\\\", \\\"{x:1339,y:969,t:1527188877222};\\\", \\\"{x:1340,y:970,t:1527188877284};\\\", \\\"{x:1341,y:969,t:1527188877420};\\\", \\\"{x:1341,y:963,t:1527188877429};\\\", \\\"{x:1340,y:953,t:1527188877439};\\\", \\\"{x:1340,y:926,t:1527188877455};\\\", \\\"{x:1340,y:892,t:1527188877472};\\\", \\\"{x:1340,y:861,t:1527188877489};\\\", \\\"{x:1339,y:831,t:1527188877506};\\\", \\\"{x:1338,y:797,t:1527188877522};\\\", \\\"{x:1336,y:764,t:1527188877539};\\\", \\\"{x:1334,y:725,t:1527188877556};\\\", \\\"{x:1332,y:692,t:1527188877572};\\\", \\\"{x:1332,y:666,t:1527188877589};\\\", \\\"{x:1329,y:645,t:1527188877606};\\\", \\\"{x:1325,y:628,t:1527188877622};\\\", \\\"{x:1324,y:617,t:1527188877639};\\\", \\\"{x:1322,y:609,t:1527188877656};\\\", \\\"{x:1320,y:599,t:1527188877673};\\\", \\\"{x:1319,y:584,t:1527188877688};\\\", \\\"{x:1317,y:569,t:1527188877706};\\\", \\\"{x:1312,y:555,t:1527188877724};\\\", \\\"{x:1309,y:544,t:1527188877739};\\\", \\\"{x:1308,y:538,t:1527188877756};\\\", \\\"{x:1308,y:534,t:1527188877773};\\\", \\\"{x:1305,y:528,t:1527188877789};\\\", \\\"{x:1302,y:519,t:1527188877806};\\\", \\\"{x:1301,y:509,t:1527188877823};\\\", \\\"{x:1300,y:500,t:1527188877838};\\\", \\\"{x:1299,y:496,t:1527188877856};\\\", \\\"{x:1298,y:492,t:1527188877873};\\\", \\\"{x:1298,y:491,t:1527188877889};\\\", \\\"{x:1298,y:495,t:1527188878092};\\\", \\\"{x:1299,y:506,t:1527188878106};\\\", \\\"{x:1302,y:527,t:1527188878123};\\\", \\\"{x:1307,y:561,t:1527188878139};\\\", \\\"{x:1316,y:601,t:1527188878156};\\\", \\\"{x:1330,y:654,t:1527188878172};\\\", \\\"{x:1343,y:703,t:1527188878190};\\\", \\\"{x:1357,y:751,t:1527188878206};\\\", \\\"{x:1367,y:787,t:1527188878223};\\\", \\\"{x:1375,y:810,t:1527188878240};\\\", \\\"{x:1381,y:827,t:1527188878256};\\\", \\\"{x:1385,y:847,t:1527188878273};\\\", \\\"{x:1387,y:868,t:1527188878290};\\\", \\\"{x:1391,y:887,t:1527188878306};\\\", \\\"{x:1395,y:901,t:1527188878323};\\\", \\\"{x:1395,y:913,t:1527188878340};\\\", \\\"{x:1396,y:919,t:1527188878355};\\\", \\\"{x:1396,y:925,t:1527188878373};\\\", \\\"{x:1396,y:927,t:1527188878390};\\\", \\\"{x:1396,y:928,t:1527188878406};\\\", \\\"{x:1396,y:929,t:1527188878422};\\\", \\\"{x:1396,y:932,t:1527188878440};\\\", \\\"{x:1396,y:935,t:1527188878457};\\\", \\\"{x:1396,y:937,t:1527188878473};\\\", \\\"{x:1396,y:939,t:1527188878490};\\\", \\\"{x:1396,y:940,t:1527188878507};\\\", \\\"{x:1396,y:942,t:1527188878523};\\\", \\\"{x:1396,y:945,t:1527188878540};\\\", \\\"{x:1395,y:947,t:1527188878556};\\\", \\\"{x:1395,y:948,t:1527188878644};\\\", \\\"{x:1394,y:948,t:1527188878683};\\\", \\\"{x:1392,y:948,t:1527188878692};\\\", \\\"{x:1391,y:945,t:1527188878707};\\\", \\\"{x:1389,y:937,t:1527188878723};\\\", \\\"{x:1386,y:923,t:1527188878740};\\\", \\\"{x:1382,y:912,t:1527188878756};\\\", \\\"{x:1378,y:891,t:1527188878773};\\\", \\\"{x:1373,y:865,t:1527188878790};\\\", \\\"{x:1367,y:830,t:1527188878807};\\\", \\\"{x:1361,y:806,t:1527188878823};\\\", \\\"{x:1359,y:780,t:1527188878839};\\\", \\\"{x:1354,y:756,t:1527188878856};\\\", \\\"{x:1353,y:733,t:1527188878872};\\\", \\\"{x:1352,y:715,t:1527188878889};\\\", \\\"{x:1352,y:693,t:1527188878906};\\\", \\\"{x:1352,y:666,t:1527188878923};\\\", \\\"{x:1352,y:655,t:1527188878940};\\\", \\\"{x:1350,y:646,t:1527188878957};\\\", \\\"{x:1348,y:635,t:1527188878974};\\\", \\\"{x:1347,y:628,t:1527188878990};\\\", \\\"{x:1346,y:619,t:1527188879007};\\\", \\\"{x:1345,y:611,t:1527188879024};\\\", \\\"{x:1343,y:596,t:1527188879040};\\\", \\\"{x:1340,y:583,t:1527188879057};\\\", \\\"{x:1338,y:573,t:1527188879074};\\\", \\\"{x:1336,y:568,t:1527188879090};\\\", \\\"{x:1335,y:563,t:1527188879107};\\\", \\\"{x:1334,y:562,t:1527188879124};\\\", \\\"{x:1333,y:560,t:1527188879140};\\\", \\\"{x:1332,y:558,t:1527188879157};\\\", \\\"{x:1331,y:556,t:1527188879174};\\\", \\\"{x:1330,y:556,t:1527188879196};\\\", \\\"{x:1328,y:556,t:1527188879268};\\\", \\\"{x:1323,y:565,t:1527188879276};\\\", \\\"{x:1318,y:583,t:1527188879290};\\\", \\\"{x:1309,y:636,t:1527188879307};\\\", \\\"{x:1292,y:731,t:1527188879324};\\\", \\\"{x:1287,y:775,t:1527188879340};\\\", \\\"{x:1286,y:803,t:1527188879357};\\\", \\\"{x:1286,y:830,t:1527188879374};\\\", \\\"{x:1286,y:854,t:1527188879392};\\\", \\\"{x:1286,y:866,t:1527188879407};\\\", \\\"{x:1286,y:878,t:1527188879424};\\\", \\\"{x:1285,y:887,t:1527188879441};\\\", \\\"{x:1285,y:892,t:1527188879457};\\\", \\\"{x:1285,y:893,t:1527188879473};\\\", \\\"{x:1283,y:894,t:1527188879580};\\\", \\\"{x:1279,y:891,t:1527188879591};\\\", \\\"{x:1276,y:881,t:1527188879607};\\\", \\\"{x:1272,y:873,t:1527188879624};\\\", \\\"{x:1270,y:866,t:1527188879641};\\\", \\\"{x:1269,y:859,t:1527188879657};\\\", \\\"{x:1268,y:849,t:1527188879674};\\\", \\\"{x:1267,y:843,t:1527188879691};\\\", \\\"{x:1266,y:837,t:1527188879707};\\\", \\\"{x:1266,y:834,t:1527188879724};\\\", \\\"{x:1266,y:833,t:1527188879755};\\\", \\\"{x:1266,y:832,t:1527188879900};\\\", \\\"{x:1267,y:832,t:1527188879908};\\\", \\\"{x:1269,y:831,t:1527188879924};\\\", \\\"{x:1272,y:831,t:1527188879941};\\\", \\\"{x:1274,y:831,t:1527188879958};\\\", \\\"{x:1275,y:831,t:1527188879980};\\\", \\\"{x:1277,y:831,t:1527188879996};\\\", \\\"{x:1281,y:831,t:1527188880024};\\\", \\\"{x:1283,y:832,t:1527188880041};\\\", \\\"{x:1284,y:832,t:1527188880058};\\\", \\\"{x:1285,y:833,t:1527188880612};\\\", \\\"{x:1285,y:834,t:1527188880624};\\\", \\\"{x:1285,y:842,t:1527188880642};\\\", \\\"{x:1285,y:852,t:1527188880658};\\\", \\\"{x:1285,y:865,t:1527188880675};\\\", \\\"{x:1283,y:877,t:1527188880692};\\\", \\\"{x:1283,y:880,t:1527188880708};\\\", \\\"{x:1282,y:887,t:1527188880725};\\\", \\\"{x:1282,y:892,t:1527188880742};\\\", \\\"{x:1280,y:897,t:1527188880758};\\\", \\\"{x:1280,y:902,t:1527188880775};\\\", \\\"{x:1279,y:909,t:1527188880791};\\\", \\\"{x:1278,y:921,t:1527188880807};\\\", \\\"{x:1275,y:932,t:1527188880824};\\\", \\\"{x:1275,y:943,t:1527188880841};\\\", \\\"{x:1274,y:952,t:1527188880857};\\\", \\\"{x:1274,y:959,t:1527188880874};\\\", \\\"{x:1273,y:965,t:1527188880890};\\\", \\\"{x:1273,y:970,t:1527188880907};\\\", \\\"{x:1273,y:975,t:1527188880925};\\\", \\\"{x:1273,y:978,t:1527188880941};\\\", \\\"{x:1273,y:982,t:1527188880957};\\\", \\\"{x:1274,y:983,t:1527188880975};\\\", \\\"{x:1275,y:984,t:1527188880991};\\\", \\\"{x:1275,y:982,t:1527188881140};\\\", \\\"{x:1275,y:975,t:1527188881147};\\\", \\\"{x:1275,y:969,t:1527188881159};\\\", \\\"{x:1275,y:958,t:1527188881175};\\\", \\\"{x:1274,y:945,t:1527188881191};\\\", \\\"{x:1269,y:933,t:1527188881209};\\\", \\\"{x:1269,y:924,t:1527188881225};\\\", \\\"{x:1268,y:921,t:1527188881242};\\\", \\\"{x:1268,y:918,t:1527188881258};\\\", \\\"{x:1268,y:915,t:1527188881274};\\\", \\\"{x:1268,y:908,t:1527188881291};\\\", \\\"{x:1268,y:904,t:1527188881308};\\\", \\\"{x:1269,y:897,t:1527188881325};\\\", \\\"{x:1269,y:892,t:1527188881342};\\\", \\\"{x:1270,y:885,t:1527188881359};\\\", \\\"{x:1270,y:879,t:1527188881375};\\\", \\\"{x:1270,y:876,t:1527188881392};\\\", \\\"{x:1271,y:873,t:1527188881408};\\\", \\\"{x:1271,y:868,t:1527188881425};\\\", \\\"{x:1272,y:863,t:1527188881442};\\\", \\\"{x:1272,y:860,t:1527188881459};\\\", \\\"{x:1273,y:858,t:1527188881475};\\\", \\\"{x:1274,y:855,t:1527188881492};\\\", \\\"{x:1274,y:853,t:1527188881532};\\\", \\\"{x:1274,y:852,t:1527188881542};\\\", \\\"{x:1274,y:850,t:1527188881559};\\\", \\\"{x:1274,y:846,t:1527188881576};\\\", \\\"{x:1274,y:842,t:1527188881592};\\\", \\\"{x:1276,y:836,t:1527188881609};\\\", \\\"{x:1277,y:830,t:1527188881626};\\\", \\\"{x:1281,y:820,t:1527188881643};\\\", \\\"{x:1285,y:803,t:1527188881659};\\\", \\\"{x:1295,y:777,t:1527188881675};\\\", \\\"{x:1303,y:746,t:1527188881692};\\\", \\\"{x:1315,y:709,t:1527188881709};\\\", \\\"{x:1319,y:698,t:1527188881726};\\\", \\\"{x:1323,y:690,t:1527188881742};\\\", \\\"{x:1323,y:684,t:1527188881759};\\\", \\\"{x:1323,y:676,t:1527188881776};\\\", \\\"{x:1324,y:664,t:1527188881792};\\\", \\\"{x:1327,y:652,t:1527188881809};\\\", \\\"{x:1329,y:639,t:1527188881826};\\\", \\\"{x:1329,y:629,t:1527188881842};\\\", \\\"{x:1331,y:620,t:1527188881859};\\\", \\\"{x:1332,y:610,t:1527188881876};\\\", \\\"{x:1333,y:603,t:1527188881892};\\\", \\\"{x:1333,y:597,t:1527188881909};\\\", \\\"{x:1333,y:593,t:1527188881926};\\\", \\\"{x:1332,y:585,t:1527188881942};\\\", \\\"{x:1331,y:582,t:1527188881959};\\\", \\\"{x:1331,y:576,t:1527188881975};\\\", \\\"{x:1331,y:569,t:1527188881992};\\\", \\\"{x:1331,y:566,t:1527188882008};\\\", \\\"{x:1331,y:564,t:1527188882025};\\\", \\\"{x:1331,y:567,t:1527188882188};\\\", \\\"{x:1331,y:580,t:1527188882195};\\\", \\\"{x:1331,y:597,t:1527188882209};\\\", \\\"{x:1331,y:636,t:1527188882226};\\\", \\\"{x:1331,y:695,t:1527188882243};\\\", \\\"{x:1337,y:756,t:1527188882259};\\\", \\\"{x:1348,y:827,t:1527188882276};\\\", \\\"{x:1351,y:852,t:1527188882293};\\\", \\\"{x:1354,y:873,t:1527188882309};\\\", \\\"{x:1356,y:889,t:1527188882326};\\\", \\\"{x:1358,y:902,t:1527188882343};\\\", \\\"{x:1358,y:916,t:1527188882359};\\\", \\\"{x:1358,y:932,t:1527188882376};\\\", \\\"{x:1358,y:945,t:1527188882393};\\\", \\\"{x:1358,y:953,t:1527188882410};\\\", \\\"{x:1358,y:959,t:1527188882426};\\\", \\\"{x:1358,y:962,t:1527188882443};\\\", \\\"{x:1358,y:963,t:1527188882460};\\\", \\\"{x:1356,y:963,t:1527188882556};\\\", \\\"{x:1354,y:963,t:1527188882571};\\\", \\\"{x:1350,y:963,t:1527188882580};\\\", \\\"{x:1348,y:960,t:1527188882593};\\\", \\\"{x:1334,y:950,t:1527188882610};\\\", \\\"{x:1320,y:938,t:1527188882626};\\\", \\\"{x:1309,y:928,t:1527188882643};\\\", \\\"{x:1281,y:904,t:1527188882660};\\\", \\\"{x:1267,y:889,t:1527188882676};\\\", \\\"{x:1261,y:883,t:1527188882693};\\\", \\\"{x:1258,y:879,t:1527188882710};\\\", \\\"{x:1257,y:876,t:1527188882726};\\\", \\\"{x:1256,y:872,t:1527188882743};\\\", \\\"{x:1255,y:871,t:1527188882764};\\\", \\\"{x:1255,y:870,t:1527188882828};\\\", \\\"{x:1255,y:869,t:1527188882860};\\\", \\\"{x:1255,y:867,t:1527188882877};\\\", \\\"{x:1255,y:865,t:1527188882893};\\\", \\\"{x:1255,y:864,t:1527188882910};\\\", \\\"{x:1256,y:863,t:1527188882939};\\\", \\\"{x:1256,y:862,t:1527188882947};\\\", \\\"{x:1256,y:861,t:1527188882960};\\\", \\\"{x:1256,y:859,t:1527188882976};\\\", \\\"{x:1256,y:857,t:1527188882993};\\\", \\\"{x:1258,y:855,t:1527188883010};\\\", \\\"{x:1259,y:854,t:1527188883027};\\\", \\\"{x:1261,y:851,t:1527188883043};\\\", \\\"{x:1262,y:850,t:1527188883060};\\\", \\\"{x:1263,y:850,t:1527188883077};\\\", \\\"{x:1265,y:849,t:1527188883093};\\\", \\\"{x:1268,y:847,t:1527188883110};\\\", \\\"{x:1269,y:846,t:1527188883127};\\\", \\\"{x:1272,y:843,t:1527188883143};\\\", \\\"{x:1273,y:843,t:1527188883160};\\\", \\\"{x:1273,y:841,t:1527188883177};\\\", \\\"{x:1274,y:841,t:1527188883193};\\\", \\\"{x:1275,y:840,t:1527188883268};\\\", \\\"{x:1276,y:840,t:1527188883300};\\\", \\\"{x:1276,y:838,t:1527188883316};\\\", \\\"{x:1277,y:838,t:1527188883332};\\\", \\\"{x:1279,y:838,t:1527188883932};\\\", \\\"{x:1280,y:839,t:1527188883948};\\\", \\\"{x:1281,y:840,t:1527188883961};\\\", \\\"{x:1283,y:842,t:1527188883977};\\\", \\\"{x:1284,y:843,t:1527188883996};\\\", \\\"{x:1284,y:844,t:1527188884011};\\\", \\\"{x:1286,y:843,t:1527188884100};\\\", \\\"{x:1287,y:842,t:1527188884112};\\\", \\\"{x:1288,y:838,t:1527188884128};\\\", \\\"{x:1289,y:836,t:1527188884144};\\\", \\\"{x:1289,y:834,t:1527188884161};\\\", \\\"{x:1289,y:832,t:1527188884180};\\\", \\\"{x:1289,y:831,t:1527188884194};\\\", \\\"{x:1289,y:834,t:1527188884300};\\\", \\\"{x:1288,y:840,t:1527188884311};\\\", \\\"{x:1285,y:857,t:1527188884329};\\\", \\\"{x:1284,y:874,t:1527188884344};\\\", \\\"{x:1284,y:886,t:1527188884362};\\\", \\\"{x:1284,y:894,t:1527188884379};\\\", \\\"{x:1284,y:901,t:1527188884394};\\\", \\\"{x:1283,y:908,t:1527188884411};\\\", \\\"{x:1283,y:923,t:1527188884427};\\\", \\\"{x:1283,y:933,t:1527188884444};\\\", \\\"{x:1283,y:941,t:1527188884461};\\\", \\\"{x:1283,y:951,t:1527188884478};\\\", \\\"{x:1283,y:956,t:1527188884494};\\\", \\\"{x:1283,y:964,t:1527188884512};\\\", \\\"{x:1282,y:972,t:1527188884529};\\\", \\\"{x:1282,y:976,t:1527188884544};\\\", \\\"{x:1282,y:978,t:1527188884561};\\\", \\\"{x:1281,y:974,t:1527188884660};\\\", \\\"{x:1281,y:973,t:1527188884678};\\\", \\\"{x:1281,y:961,t:1527188884696};\\\", \\\"{x:1281,y:952,t:1527188884711};\\\", \\\"{x:1281,y:939,t:1527188884728};\\\", \\\"{x:1281,y:927,t:1527188884745};\\\", \\\"{x:1282,y:915,t:1527188884761};\\\", \\\"{x:1283,y:909,t:1527188884778};\\\", \\\"{x:1284,y:900,t:1527188884795};\\\", \\\"{x:1284,y:893,t:1527188884811};\\\", \\\"{x:1284,y:881,t:1527188884828};\\\", \\\"{x:1284,y:868,t:1527188884845};\\\", \\\"{x:1284,y:860,t:1527188884861};\\\", \\\"{x:1284,y:851,t:1527188884878};\\\", \\\"{x:1284,y:845,t:1527188884896};\\\", \\\"{x:1283,y:839,t:1527188884911};\\\", \\\"{x:1282,y:836,t:1527188884928};\\\", \\\"{x:1282,y:835,t:1527188884945};\\\", \\\"{x:1282,y:834,t:1527188884978};\\\", \\\"{x:1282,y:838,t:1527188885188};\\\", \\\"{x:1282,y:844,t:1527188885195};\\\", \\\"{x:1282,y:859,t:1527188885211};\\\", \\\"{x:1282,y:874,t:1527188885228};\\\", \\\"{x:1282,y:889,t:1527188885245};\\\", \\\"{x:1282,y:905,t:1527188885262};\\\", \\\"{x:1282,y:917,t:1527188885278};\\\", \\\"{x:1282,y:924,t:1527188885295};\\\", \\\"{x:1282,y:928,t:1527188885312};\\\", \\\"{x:1283,y:933,t:1527188885328};\\\", \\\"{x:1283,y:934,t:1527188885363};\\\", \\\"{x:1283,y:935,t:1527188885380};\\\", \\\"{x:1282,y:936,t:1527188885436};\\\", \\\"{x:1280,y:936,t:1527188885452};\\\", \\\"{x:1278,y:935,t:1527188885468};\\\", \\\"{x:1277,y:932,t:1527188885479};\\\", \\\"{x:1270,y:923,t:1527188885495};\\\", \\\"{x:1265,y:914,t:1527188885512};\\\", \\\"{x:1260,y:900,t:1527188885529};\\\", \\\"{x:1248,y:885,t:1527188885545};\\\", \\\"{x:1239,y:871,t:1527188885562};\\\", \\\"{x:1225,y:860,t:1527188885579};\\\", \\\"{x:1217,y:856,t:1527188885595};\\\", \\\"{x:1213,y:853,t:1527188885612};\\\", \\\"{x:1211,y:853,t:1527188885629};\\\", \\\"{x:1209,y:852,t:1527188885645};\\\", \\\"{x:1208,y:850,t:1527188885692};\\\", \\\"{x:1208,y:849,t:1527188885716};\\\", \\\"{x:1208,y:848,t:1527188885747};\\\", \\\"{x:1208,y:847,t:1527188885779};\\\", \\\"{x:1208,y:845,t:1527188885796};\\\", \\\"{x:1208,y:842,t:1527188885812};\\\", \\\"{x:1210,y:840,t:1527188885829};\\\", \\\"{x:1212,y:837,t:1527188885845};\\\", \\\"{x:1213,y:835,t:1527188885863};\\\", \\\"{x:1214,y:832,t:1527188885879};\\\", \\\"{x:1215,y:831,t:1527188885940};\\\", \\\"{x:1215,y:832,t:1527188886036};\\\", \\\"{x:1215,y:837,t:1527188886047};\\\", \\\"{x:1215,y:851,t:1527188886062};\\\", \\\"{x:1215,y:861,t:1527188886080};\\\", \\\"{x:1215,y:876,t:1527188886096};\\\", \\\"{x:1216,y:892,t:1527188886112};\\\", \\\"{x:1217,y:905,t:1527188886129};\\\", \\\"{x:1221,y:921,t:1527188886146};\\\", \\\"{x:1223,y:930,t:1527188886162};\\\", \\\"{x:1226,y:934,t:1527188886180};\\\", \\\"{x:1227,y:939,t:1527188886195};\\\", \\\"{x:1229,y:941,t:1527188886212};\\\", \\\"{x:1231,y:941,t:1527188886300};\\\", \\\"{x:1234,y:938,t:1527188886313};\\\", \\\"{x:1241,y:933,t:1527188886329};\\\", \\\"{x:1254,y:920,t:1527188886347};\\\", \\\"{x:1273,y:904,t:1527188886363};\\\", \\\"{x:1283,y:895,t:1527188886380};\\\", \\\"{x:1289,y:887,t:1527188886396};\\\", \\\"{x:1296,y:879,t:1527188886413};\\\", \\\"{x:1301,y:867,t:1527188886429};\\\", \\\"{x:1306,y:856,t:1527188886446};\\\", \\\"{x:1311,y:843,t:1527188886463};\\\", \\\"{x:1313,y:835,t:1527188886479};\\\", \\\"{x:1316,y:830,t:1527188886496};\\\", \\\"{x:1316,y:829,t:1527188886513};\\\", \\\"{x:1316,y:827,t:1527188886529};\\\", \\\"{x:1316,y:825,t:1527188886546};\\\", \\\"{x:1320,y:816,t:1527188886563};\\\", \\\"{x:1321,y:810,t:1527188886579};\\\", \\\"{x:1323,y:807,t:1527188886596};\\\", \\\"{x:1324,y:806,t:1527188886628};\\\", \\\"{x:1327,y:805,t:1527188886643};\\\", \\\"{x:1329,y:805,t:1527188886659};\\\", \\\"{x:1330,y:805,t:1527188886667};\\\", \\\"{x:1331,y:805,t:1527188886684};\\\", \\\"{x:1331,y:806,t:1527188886696};\\\", \\\"{x:1331,y:808,t:1527188886713};\\\", \\\"{x:1334,y:816,t:1527188886729};\\\", \\\"{x:1335,y:826,t:1527188886746};\\\", \\\"{x:1338,y:843,t:1527188886764};\\\", \\\"{x:1342,y:855,t:1527188886779};\\\", \\\"{x:1344,y:864,t:1527188886795};\\\", \\\"{x:1347,y:872,t:1527188886813};\\\", \\\"{x:1349,y:876,t:1527188886829};\\\", \\\"{x:1349,y:878,t:1527188886846};\\\", \\\"{x:1349,y:879,t:1527188886883};\\\", \\\"{x:1349,y:882,t:1527188886895};\\\", \\\"{x:1349,y:885,t:1527188886913};\\\", \\\"{x:1349,y:889,t:1527188886929};\\\", \\\"{x:1351,y:891,t:1527188886946};\\\", \\\"{x:1351,y:895,t:1527188886964};\\\", \\\"{x:1351,y:900,t:1527188886979};\\\", \\\"{x:1351,y:915,t:1527188886997};\\\", \\\"{x:1351,y:932,t:1527188887013};\\\", \\\"{x:1352,y:943,t:1527188887030};\\\", \\\"{x:1353,y:946,t:1527188887046};\\\", \\\"{x:1354,y:948,t:1527188887067};\\\", \\\"{x:1354,y:949,t:1527188887108};\\\", \\\"{x:1354,y:948,t:1527188887291};\\\", \\\"{x:1354,y:947,t:1527188887300};\\\", \\\"{x:1354,y:944,t:1527188887314};\\\", \\\"{x:1354,y:942,t:1527188887330};\\\", \\\"{x:1354,y:940,t:1527188887347};\\\", \\\"{x:1353,y:939,t:1527188887364};\\\", \\\"{x:1353,y:938,t:1527188887380};\\\", \\\"{x:1353,y:936,t:1527188887404};\\\", \\\"{x:1353,y:935,t:1527188887413};\\\", \\\"{x:1353,y:933,t:1527188887430};\\\", \\\"{x:1353,y:930,t:1527188887447};\\\", \\\"{x:1353,y:927,t:1527188887464};\\\", \\\"{x:1353,y:925,t:1527188887480};\\\", \\\"{x:1353,y:922,t:1527188887497};\\\", \\\"{x:1353,y:918,t:1527188887513};\\\", \\\"{x:1353,y:913,t:1527188887531};\\\", \\\"{x:1353,y:906,t:1527188887548};\\\", \\\"{x:1353,y:904,t:1527188887564};\\\", \\\"{x:1353,y:903,t:1527188887580};\\\", \\\"{x:1353,y:907,t:1527188887724};\\\", \\\"{x:1353,y:913,t:1527188887731};\\\", \\\"{x:1353,y:925,t:1527188887748};\\\", \\\"{x:1353,y:935,t:1527188887763};\\\", \\\"{x:1353,y:946,t:1527188887780};\\\", \\\"{x:1353,y:960,t:1527188887797};\\\", \\\"{x:1353,y:971,t:1527188887814};\\\", \\\"{x:1353,y:979,t:1527188887829};\\\", \\\"{x:1355,y:985,t:1527188887847};\\\", \\\"{x:1355,y:988,t:1527188887864};\\\", \\\"{x:1355,y:985,t:1527188887979};\\\", \\\"{x:1355,y:980,t:1527188887987};\\\", \\\"{x:1355,y:975,t:1527188887997};\\\", \\\"{x:1353,y:964,t:1527188888013};\\\", \\\"{x:1350,y:951,t:1527188888030};\\\", \\\"{x:1350,y:940,t:1527188888046};\\\", \\\"{x:1349,y:930,t:1527188888064};\\\", \\\"{x:1349,y:923,t:1527188888081};\\\", \\\"{x:1348,y:918,t:1527188888097};\\\", \\\"{x:1347,y:914,t:1527188888114};\\\", \\\"{x:1346,y:909,t:1527188888131};\\\", \\\"{x:1345,y:901,t:1527188888148};\\\", \\\"{x:1344,y:897,t:1527188888163};\\\", \\\"{x:1344,y:894,t:1527188888181};\\\", \\\"{x:1344,y:892,t:1527188888197};\\\", \\\"{x:1344,y:891,t:1527188888215};\\\", \\\"{x:1344,y:890,t:1527188888235};\\\", \\\"{x:1343,y:884,t:1527188888644};\\\", \\\"{x:1343,y:877,t:1527188888652};\\\", \\\"{x:1343,y:867,t:1527188888664};\\\", \\\"{x:1342,y:851,t:1527188888681};\\\", \\\"{x:1342,y:830,t:1527188888698};\\\", \\\"{x:1341,y:810,t:1527188888715};\\\", \\\"{x:1335,y:779,t:1527188888732};\\\", \\\"{x:1331,y:765,t:1527188888748};\\\", \\\"{x:1326,y:745,t:1527188888764};\\\", \\\"{x:1320,y:724,t:1527188888781};\\\", \\\"{x:1314,y:700,t:1527188888798};\\\", \\\"{x:1309,y:682,t:1527188888814};\\\", \\\"{x:1307,y:674,t:1527188888830};\\\", \\\"{x:1305,y:670,t:1527188888847};\\\", \\\"{x:1303,y:662,t:1527188888863};\\\", \\\"{x:1301,y:658,t:1527188888881};\\\", \\\"{x:1300,y:654,t:1527188888897};\\\", \\\"{x:1300,y:652,t:1527188888914};\\\", \\\"{x:1299,y:647,t:1527188888931};\\\", \\\"{x:1299,y:645,t:1527188888948};\\\", \\\"{x:1299,y:644,t:1527188889076};\\\", \\\"{x:1299,y:643,t:1527188889083};\\\", \\\"{x:1299,y:642,t:1527188889098};\\\", \\\"{x:1299,y:641,t:1527188889115};\\\", \\\"{x:1301,y:639,t:1527188889131};\\\", \\\"{x:1302,y:638,t:1527188889148};\\\", \\\"{x:1303,y:637,t:1527188889171};\\\", \\\"{x:1303,y:636,t:1527188889236};\\\", \\\"{x:1304,y:636,t:1527188889249};\\\", \\\"{x:1304,y:635,t:1527188889266};\\\", \\\"{x:1305,y:635,t:1527188889331};\\\", \\\"{x:1306,y:635,t:1527188889371};\\\", \\\"{x:1307,y:634,t:1527188889382};\\\", \\\"{x:1308,y:633,t:1527188889436};\\\", \\\"{x:1309,y:633,t:1527188889476};\\\", \\\"{x:1310,y:633,t:1527188893421};\\\", \\\"{x:1310,y:632,t:1527188893436};\\\", \\\"{x:1310,y:618,t:1527188893452};\\\", \\\"{x:1310,y:611,t:1527188893468};\\\", \\\"{x:1310,y:604,t:1527188893486};\\\", \\\"{x:1310,y:596,t:1527188893501};\\\", \\\"{x:1309,y:594,t:1527188893519};\\\", \\\"{x:1309,y:593,t:1527188893536};\\\", \\\"{x:1309,y:592,t:1527188893748};\\\", \\\"{x:1311,y:592,t:1527188893779};\\\", \\\"{x:1312,y:592,t:1527188893795};\\\", \\\"{x:1314,y:593,t:1527188893812};\\\", \\\"{x:1316,y:594,t:1527188893827};\\\", \\\"{x:1318,y:595,t:1527188893843};\\\", \\\"{x:1320,y:596,t:1527188893852};\\\", \\\"{x:1323,y:599,t:1527188893868};\\\", \\\"{x:1328,y:603,t:1527188893885};\\\", \\\"{x:1339,y:611,t:1527188893903};\\\", \\\"{x:1350,y:619,t:1527188893919};\\\", \\\"{x:1357,y:623,t:1527188893936};\\\", \\\"{x:1362,y:626,t:1527188893953};\\\", \\\"{x:1368,y:630,t:1527188893969};\\\", \\\"{x:1372,y:633,t:1527188893985};\\\", \\\"{x:1373,y:634,t:1527188894052};\\\", \\\"{x:1375,y:636,t:1527188894068};\\\", \\\"{x:1375,y:637,t:1527188894085};\\\", \\\"{x:1376,y:637,t:1527188894156};\\\", \\\"{x:1376,y:638,t:1527188894172};\\\", \\\"{x:1377,y:639,t:1527188894185};\\\", \\\"{x:1379,y:643,t:1527188894202};\\\", \\\"{x:1379,y:644,t:1527188894219};\\\", \\\"{x:1382,y:646,t:1527188894235};\\\", \\\"{x:1385,y:648,t:1527188894252};\\\", \\\"{x:1386,y:648,t:1527188894300};\\\", \\\"{x:1385,y:649,t:1527188895251};\\\", \\\"{x:1384,y:649,t:1527188895260};\\\", \\\"{x:1383,y:649,t:1527188895276};\\\", \\\"{x:1382,y:649,t:1527188895299};\\\", \\\"{x:1381,y:649,t:1527188895307};\\\", \\\"{x:1380,y:649,t:1527188895323};\\\", \\\"{x:1378,y:649,t:1527188895340};\\\", \\\"{x:1377,y:649,t:1527188895354};\\\", \\\"{x:1375,y:650,t:1527188895369};\\\", \\\"{x:1374,y:652,t:1527188896580};\\\", \\\"{x:1374,y:659,t:1527188896587};\\\", \\\"{x:1374,y:664,t:1527188896605};\\\", \\\"{x:1374,y:669,t:1527188896620};\\\", \\\"{x:1374,y:675,t:1527188896637};\\\", \\\"{x:1374,y:685,t:1527188896655};\\\", \\\"{x:1375,y:693,t:1527188896671};\\\", \\\"{x:1375,y:700,t:1527188896687};\\\", \\\"{x:1375,y:705,t:1527188896704};\\\", \\\"{x:1375,y:712,t:1527188896721};\\\", \\\"{x:1375,y:720,t:1527188896738};\\\", \\\"{x:1378,y:731,t:1527188896755};\\\", \\\"{x:1378,y:739,t:1527188896771};\\\", \\\"{x:1380,y:750,t:1527188896787};\\\", \\\"{x:1382,y:752,t:1527188896805};\\\", \\\"{x:1382,y:755,t:1527188896821};\\\", \\\"{x:1386,y:766,t:1527188896838};\\\", \\\"{x:1389,y:775,t:1527188896856};\\\", \\\"{x:1395,y:785,t:1527188896872};\\\", \\\"{x:1397,y:790,t:1527188896887};\\\", \\\"{x:1397,y:791,t:1527188896904};\\\", \\\"{x:1396,y:789,t:1527188897028};\\\", \\\"{x:1394,y:787,t:1527188897038};\\\", \\\"{x:1391,y:782,t:1527188897055};\\\", \\\"{x:1390,y:781,t:1527188897072};\\\", \\\"{x:1389,y:781,t:1527188897088};\\\", \\\"{x:1388,y:780,t:1527188897105};\\\", \\\"{x:1388,y:779,t:1527188897347};\\\", \\\"{x:1387,y:779,t:1527188897355};\\\", \\\"{x:1385,y:779,t:1527188897372};\\\", \\\"{x:1384,y:777,t:1527188897387};\\\", \\\"{x:1379,y:777,t:1527188897404};\\\", \\\"{x:1374,y:775,t:1527188897421};\\\", \\\"{x:1371,y:774,t:1527188897437};\\\", \\\"{x:1370,y:773,t:1527188897454};\\\", \\\"{x:1368,y:773,t:1527188897475};\\\", \\\"{x:1368,y:774,t:1527188897692};\\\", \\\"{x:1368,y:777,t:1527188897704};\\\", \\\"{x:1368,y:784,t:1527188897721};\\\", \\\"{x:1368,y:788,t:1527188897738};\\\", \\\"{x:1368,y:802,t:1527188897755};\\\", \\\"{x:1373,y:822,t:1527188897770};\\\", \\\"{x:1382,y:853,t:1527188897788};\\\", \\\"{x:1388,y:880,t:1527188897805};\\\", \\\"{x:1390,y:898,t:1527188897821};\\\", \\\"{x:1391,y:905,t:1527188897838};\\\", \\\"{x:1391,y:908,t:1527188897855};\\\", \\\"{x:1391,y:910,t:1527188897871};\\\", \\\"{x:1391,y:915,t:1527188897888};\\\", \\\"{x:1391,y:923,t:1527188897905};\\\", \\\"{x:1391,y:932,t:1527188897922};\\\", \\\"{x:1391,y:936,t:1527188897938};\\\", \\\"{x:1392,y:939,t:1527188897956};\\\", \\\"{x:1392,y:941,t:1527188898066};\\\", \\\"{x:1392,y:942,t:1527188898082};\\\", \\\"{x:1391,y:942,t:1527188898155};\\\", \\\"{x:1387,y:942,t:1527188898172};\\\", \\\"{x:1383,y:934,t:1527188898189};\\\", \\\"{x:1380,y:922,t:1527188898206};\\\", \\\"{x:1376,y:908,t:1527188898222};\\\", \\\"{x:1373,y:892,t:1527188898239};\\\", \\\"{x:1368,y:876,t:1527188898255};\\\", \\\"{x:1366,y:870,t:1527188898272};\\\", \\\"{x:1366,y:859,t:1527188898288};\\\", \\\"{x:1364,y:849,t:1527188898305};\\\", \\\"{x:1364,y:840,t:1527188898322};\\\", \\\"{x:1364,y:828,t:1527188898338};\\\", \\\"{x:1364,y:817,t:1527188898355};\\\", \\\"{x:1364,y:812,t:1527188898372};\\\", \\\"{x:1364,y:807,t:1527188898389};\\\", \\\"{x:1364,y:803,t:1527188898406};\\\", \\\"{x:1365,y:796,t:1527188898423};\\\", \\\"{x:1365,y:791,t:1527188898439};\\\", \\\"{x:1366,y:783,t:1527188898455};\\\", \\\"{x:1367,y:778,t:1527188898472};\\\", \\\"{x:1368,y:775,t:1527188898489};\\\", \\\"{x:1368,y:774,t:1527188898505};\\\", \\\"{x:1368,y:772,t:1527188898572};\\\", \\\"{x:1368,y:770,t:1527188898595};\\\", \\\"{x:1370,y:757,t:1527188900204};\\\", \\\"{x:1374,y:736,t:1527188900211};\\\", \\\"{x:1376,y:723,t:1527188900224};\\\", \\\"{x:1379,y:705,t:1527188900241};\\\", \\\"{x:1379,y:691,t:1527188900257};\\\", \\\"{x:1380,y:680,t:1527188900273};\\\", \\\"{x:1381,y:671,t:1527188900291};\\\", \\\"{x:1382,y:661,t:1527188900308};\\\", \\\"{x:1382,y:656,t:1527188900324};\\\", \\\"{x:1383,y:649,t:1527188900341};\\\", \\\"{x:1383,y:645,t:1527188900357};\\\", \\\"{x:1383,y:641,t:1527188900373};\\\", \\\"{x:1385,y:636,t:1527188900390};\\\", \\\"{x:1385,y:632,t:1527188900408};\\\", \\\"{x:1387,y:630,t:1527188900424};\\\", \\\"{x:1389,y:626,t:1527188900441};\\\", \\\"{x:1390,y:622,t:1527188900458};\\\", \\\"{x:1392,y:618,t:1527188900473};\\\", \\\"{x:1395,y:612,t:1527188900491};\\\", \\\"{x:1400,y:602,t:1527188900508};\\\", \\\"{x:1407,y:590,t:1527188900524};\\\", \\\"{x:1409,y:586,t:1527188900540};\\\", \\\"{x:1410,y:584,t:1527188900557};\\\", \\\"{x:1410,y:582,t:1527188900579};\\\", \\\"{x:1411,y:581,t:1527188900590};\\\", \\\"{x:1411,y:580,t:1527188900607};\\\", \\\"{x:1411,y:579,t:1527188900635};\\\", \\\"{x:1411,y:578,t:1527188900731};\\\", \\\"{x:1411,y:577,t:1527188900741};\\\", \\\"{x:1411,y:575,t:1527188900757};\\\", \\\"{x:1411,y:574,t:1527188900779};\\\", \\\"{x:1411,y:572,t:1527188900791};\\\", \\\"{x:1411,y:571,t:1527188900808};\\\", \\\"{x:1411,y:570,t:1527188900825};\\\", \\\"{x:1411,y:569,t:1527188900841};\\\", \\\"{x:1411,y:570,t:1527188901011};\\\", \\\"{x:1411,y:581,t:1527188901025};\\\", \\\"{x:1411,y:615,t:1527188901040};\\\", \\\"{x:1411,y:654,t:1527188901058};\\\", \\\"{x:1411,y:689,t:1527188901075};\\\", \\\"{x:1411,y:711,t:1527188901091};\\\", \\\"{x:1411,y:735,t:1527188901108};\\\", \\\"{x:1411,y:754,t:1527188901125};\\\", \\\"{x:1411,y:783,t:1527188901142};\\\", \\\"{x:1411,y:810,t:1527188901157};\\\", \\\"{x:1410,y:826,t:1527188901174};\\\", \\\"{x:1410,y:835,t:1527188901192};\\\", \\\"{x:1408,y:844,t:1527188901208};\\\", \\\"{x:1408,y:856,t:1527188901225};\\\", \\\"{x:1408,y:873,t:1527188901242};\\\", \\\"{x:1413,y:895,t:1527188901258};\\\", \\\"{x:1416,y:907,t:1527188901275};\\\", \\\"{x:1418,y:913,t:1527188901291};\\\", \\\"{x:1419,y:914,t:1527188901307};\\\", \\\"{x:1420,y:917,t:1527188901325};\\\", \\\"{x:1422,y:926,t:1527188901341};\\\", \\\"{x:1424,y:934,t:1527188901358};\\\", \\\"{x:1428,y:943,t:1527188901374};\\\", \\\"{x:1429,y:946,t:1527188901391};\\\", \\\"{x:1430,y:948,t:1527188901407};\\\", \\\"{x:1431,y:949,t:1527188901424};\\\", \\\"{x:1432,y:952,t:1527188901441};\\\", \\\"{x:1435,y:958,t:1527188901457};\\\", \\\"{x:1437,y:963,t:1527188901474};\\\", \\\"{x:1440,y:968,t:1527188901490};\\\", \\\"{x:1440,y:967,t:1527188901691};\\\", \\\"{x:1441,y:965,t:1527188901709};\\\", \\\"{x:1441,y:962,t:1527188901725};\\\", \\\"{x:1441,y:961,t:1527188901742};\\\", \\\"{x:1441,y:959,t:1527188901758};\\\", \\\"{x:1442,y:957,t:1527188901779};\\\", \\\"{x:1442,y:956,t:1527188901803};\\\", \\\"{x:1442,y:955,t:1527188901812};\\\", \\\"{x:1442,y:954,t:1527188901851};\\\", \\\"{x:1442,y:953,t:1527188901859};\\\", \\\"{x:1442,y:952,t:1527188901875};\\\", \\\"{x:1442,y:951,t:1527188901892};\\\", \\\"{x:1442,y:949,t:1527188901909};\\\", \\\"{x:1442,y:946,t:1527188901925};\\\", \\\"{x:1442,y:939,t:1527188901942};\\\", \\\"{x:1442,y:924,t:1527188901959};\\\", \\\"{x:1442,y:906,t:1527188901975};\\\", \\\"{x:1442,y:886,t:1527188901992};\\\", \\\"{x:1442,y:861,t:1527188902009};\\\", \\\"{x:1442,y:841,t:1527188902025};\\\", \\\"{x:1440,y:819,t:1527188902042};\\\", \\\"{x:1438,y:794,t:1527188902059};\\\", \\\"{x:1432,y:765,t:1527188902075};\\\", \\\"{x:1430,y:752,t:1527188902092};\\\", \\\"{x:1428,y:742,t:1527188902108};\\\", \\\"{x:1428,y:735,t:1527188902126};\\\", \\\"{x:1424,y:722,t:1527188902142};\\\", \\\"{x:1421,y:709,t:1527188902158};\\\", \\\"{x:1418,y:694,t:1527188902176};\\\", \\\"{x:1417,y:682,t:1527188902192};\\\", \\\"{x:1417,y:676,t:1527188902209};\\\", \\\"{x:1417,y:664,t:1527188902225};\\\", \\\"{x:1417,y:646,t:1527188902242};\\\", \\\"{x:1415,y:634,t:1527188902259};\\\", \\\"{x:1415,y:616,t:1527188902275};\\\", \\\"{x:1415,y:608,t:1527188902292};\\\", \\\"{x:1415,y:601,t:1527188902309};\\\", \\\"{x:1415,y:592,t:1527188902326};\\\", \\\"{x:1415,y:587,t:1527188902342};\\\", \\\"{x:1415,y:582,t:1527188902359};\\\", \\\"{x:1415,y:578,t:1527188902376};\\\", \\\"{x:1415,y:575,t:1527188902392};\\\", \\\"{x:1415,y:573,t:1527188902408};\\\", \\\"{x:1416,y:570,t:1527188902425};\\\", \\\"{x:1416,y:567,t:1527188902443};\\\", \\\"{x:1417,y:566,t:1527188902459};\\\", \\\"{x:1417,y:565,t:1527188902475};\\\", \\\"{x:1417,y:571,t:1527188902701};\\\", \\\"{x:1416,y:578,t:1527188902709};\\\", \\\"{x:1413,y:599,t:1527188902726};\\\", \\\"{x:1411,y:619,t:1527188902743};\\\", \\\"{x:1411,y:636,t:1527188902759};\\\", \\\"{x:1411,y:649,t:1527188902776};\\\", \\\"{x:1410,y:659,t:1527188902792};\\\", \\\"{x:1410,y:669,t:1527188902809};\\\", \\\"{x:1408,y:677,t:1527188902825};\\\", \\\"{x:1408,y:689,t:1527188902843};\\\", \\\"{x:1408,y:711,t:1527188902859};\\\", \\\"{x:1408,y:724,t:1527188902876};\\\", \\\"{x:1408,y:732,t:1527188902893};\\\", \\\"{x:1409,y:742,t:1527188902910};\\\", \\\"{x:1409,y:750,t:1527188902926};\\\", \\\"{x:1409,y:754,t:1527188902943};\\\", \\\"{x:1409,y:762,t:1527188902960};\\\", \\\"{x:1410,y:771,t:1527188902976};\\\", \\\"{x:1412,y:778,t:1527188902992};\\\", \\\"{x:1413,y:783,t:1527188903009};\\\", \\\"{x:1413,y:787,t:1527188903026};\\\", \\\"{x:1413,y:791,t:1527188903043};\\\", \\\"{x:1416,y:800,t:1527188903059};\\\", \\\"{x:1417,y:806,t:1527188903076};\\\", \\\"{x:1419,y:816,t:1527188903093};\\\", \\\"{x:1422,y:825,t:1527188903109};\\\", \\\"{x:1424,y:832,t:1527188903126};\\\", \\\"{x:1426,y:837,t:1527188903142};\\\", \\\"{x:1426,y:840,t:1527188903160};\\\", \\\"{x:1426,y:842,t:1527188903176};\\\", \\\"{x:1427,y:846,t:1527188903193};\\\", \\\"{x:1427,y:851,t:1527188903210};\\\", \\\"{x:1427,y:857,t:1527188903226};\\\", \\\"{x:1427,y:862,t:1527188903242};\\\", \\\"{x:1427,y:866,t:1527188903260};\\\", \\\"{x:1427,y:870,t:1527188903275};\\\", \\\"{x:1427,y:877,t:1527188903292};\\\", \\\"{x:1427,y:885,t:1527188903310};\\\", \\\"{x:1427,y:895,t:1527188903326};\\\", \\\"{x:1427,y:902,t:1527188903343};\\\", \\\"{x:1427,y:907,t:1527188903360};\\\", \\\"{x:1427,y:911,t:1527188903377};\\\", \\\"{x:1427,y:916,t:1527188903393};\\\", \\\"{x:1427,y:924,t:1527188903410};\\\", \\\"{x:1427,y:934,t:1527188903427};\\\", \\\"{x:1429,y:943,t:1527188903443};\\\", \\\"{x:1429,y:949,t:1527188903460};\\\", \\\"{x:1430,y:950,t:1527188903491};\\\", \\\"{x:1430,y:951,t:1527188903500};\\\", \\\"{x:1430,y:953,t:1527188903509};\\\", \\\"{x:1430,y:956,t:1527188903527};\\\", \\\"{x:1430,y:960,t:1527188903543};\\\", \\\"{x:1430,y:963,t:1527188903560};\\\", \\\"{x:1431,y:966,t:1527188903576};\\\", \\\"{x:1431,y:967,t:1527188903592};\\\", \\\"{x:1431,y:968,t:1527188903609};\\\", \\\"{x:1431,y:969,t:1527188903635};\\\", \\\"{x:1431,y:970,t:1527188903650};\\\", \\\"{x:1430,y:972,t:1527188903666};\\\", \\\"{x:1429,y:973,t:1527188903682};\\\", \\\"{x:1428,y:974,t:1527188903731};\\\", \\\"{x:1426,y:972,t:1527188904043};\\\", \\\"{x:1423,y:960,t:1527188904060};\\\", \\\"{x:1419,y:936,t:1527188904077};\\\", \\\"{x:1413,y:912,t:1527188904094};\\\", \\\"{x:1410,y:890,t:1527188904110};\\\", \\\"{x:1407,y:864,t:1527188904126};\\\", \\\"{x:1403,y:843,t:1527188904144};\\\", \\\"{x:1403,y:830,t:1527188904160};\\\", \\\"{x:1403,y:816,t:1527188904177};\\\", \\\"{x:1403,y:802,t:1527188904193};\\\", \\\"{x:1403,y:787,t:1527188904210};\\\", \\\"{x:1403,y:762,t:1527188904227};\\\", \\\"{x:1404,y:752,t:1527188904243};\\\", \\\"{x:1404,y:744,t:1527188904261};\\\", \\\"{x:1404,y:735,t:1527188904277};\\\", \\\"{x:1404,y:726,t:1527188904294};\\\", \\\"{x:1404,y:717,t:1527188904311};\\\", \\\"{x:1404,y:710,t:1527188904327};\\\", \\\"{x:1404,y:700,t:1527188904344};\\\", \\\"{x:1404,y:689,t:1527188904361};\\\", \\\"{x:1404,y:679,t:1527188904377};\\\", \\\"{x:1404,y:673,t:1527188904394};\\\", \\\"{x:1404,y:659,t:1527188904411};\\\", \\\"{x:1403,y:648,t:1527188904427};\\\", \\\"{x:1402,y:640,t:1527188904444};\\\", \\\"{x:1402,y:632,t:1527188904461};\\\", \\\"{x:1402,y:624,t:1527188904477};\\\", \\\"{x:1402,y:614,t:1527188904494};\\\", \\\"{x:1402,y:608,t:1527188904511};\\\", \\\"{x:1402,y:605,t:1527188904527};\\\", \\\"{x:1402,y:600,t:1527188904544};\\\", \\\"{x:1402,y:593,t:1527188904560};\\\", \\\"{x:1402,y:589,t:1527188904577};\\\", \\\"{x:1402,y:586,t:1527188904594};\\\", \\\"{x:1403,y:582,t:1527188904611};\\\", \\\"{x:1404,y:579,t:1527188904627};\\\", \\\"{x:1404,y:578,t:1527188904644};\\\", \\\"{x:1405,y:574,t:1527188904661};\\\", \\\"{x:1407,y:570,t:1527188904678};\\\", \\\"{x:1407,y:568,t:1527188904693};\\\", \\\"{x:1408,y:567,t:1527188904711};\\\", \\\"{x:1408,y:565,t:1527188904728};\\\", \\\"{x:1410,y:564,t:1527188904788};\\\", \\\"{x:1410,y:565,t:1527188904964};\\\", \\\"{x:1410,y:570,t:1527188904979};\\\", \\\"{x:1410,y:581,t:1527188904993};\\\", \\\"{x:1410,y:596,t:1527188905010};\\\", \\\"{x:1410,y:605,t:1527188905028};\\\", \\\"{x:1410,y:612,t:1527188905043};\\\", \\\"{x:1410,y:619,t:1527188905060};\\\", \\\"{x:1410,y:627,t:1527188905077};\\\", \\\"{x:1410,y:636,t:1527188905095};\\\", \\\"{x:1410,y:646,t:1527188905111};\\\", \\\"{x:1410,y:658,t:1527188905127};\\\", \\\"{x:1410,y:670,t:1527188905144};\\\", \\\"{x:1410,y:679,t:1527188905161};\\\", \\\"{x:1410,y:689,t:1527188905178};\\\", \\\"{x:1411,y:706,t:1527188905195};\\\", \\\"{x:1413,y:714,t:1527188905210};\\\", \\\"{x:1414,y:725,t:1527188905227};\\\", \\\"{x:1415,y:732,t:1527188905245};\\\", \\\"{x:1416,y:743,t:1527188905260};\\\", \\\"{x:1420,y:759,t:1527188905277};\\\", \\\"{x:1425,y:775,t:1527188905294};\\\", \\\"{x:1427,y:785,t:1527188905311};\\\", \\\"{x:1430,y:795,t:1527188905328};\\\", \\\"{x:1432,y:804,t:1527188905345};\\\", \\\"{x:1434,y:814,t:1527188905361};\\\", \\\"{x:1435,y:823,t:1527188905378};\\\", \\\"{x:1436,y:841,t:1527188905394};\\\", \\\"{x:1436,y:854,t:1527188905411};\\\", \\\"{x:1437,y:872,t:1527188905428};\\\", \\\"{x:1437,y:888,t:1527188905444};\\\", \\\"{x:1437,y:898,t:1527188905461};\\\", \\\"{x:1439,y:908,t:1527188905478};\\\", \\\"{x:1439,y:913,t:1527188905495};\\\", \\\"{x:1439,y:918,t:1527188905512};\\\", \\\"{x:1439,y:925,t:1527188905528};\\\", \\\"{x:1439,y:935,t:1527188905545};\\\", \\\"{x:1439,y:944,t:1527188905561};\\\", \\\"{x:1439,y:953,t:1527188905578};\\\", \\\"{x:1437,y:962,t:1527188905594};\\\", \\\"{x:1434,y:968,t:1527188905611};\\\", \\\"{x:1434,y:969,t:1527188905628};\\\", \\\"{x:1434,y:971,t:1527188905645};\\\", \\\"{x:1432,y:975,t:1527188905662};\\\", \\\"{x:1430,y:978,t:1527188905678};\\\", \\\"{x:1427,y:983,t:1527188905695};\\\", \\\"{x:1426,y:984,t:1527188905711};\\\", \\\"{x:1425,y:984,t:1527188905728};\\\", \\\"{x:1425,y:985,t:1527188905746};\\\", \\\"{x:1424,y:985,t:1527188905762};\\\", \\\"{x:1423,y:986,t:1527188905787};\\\", \\\"{x:1421,y:986,t:1527188905947};\\\", \\\"{x:1420,y:986,t:1527188905961};\\\", \\\"{x:1418,y:986,t:1527188905977};\\\", \\\"{x:1418,y:980,t:1527188905995};\\\", \\\"{x:1418,y:977,t:1527188906012};\\\", \\\"{x:1418,y:975,t:1527188906028};\\\", \\\"{x:1418,y:973,t:1527188906045};\\\", \\\"{x:1418,y:970,t:1527188906061};\\\", \\\"{x:1418,y:968,t:1527188906079};\\\", \\\"{x:1418,y:963,t:1527188906095};\\\", \\\"{x:1418,y:958,t:1527188906112};\\\", \\\"{x:1418,y:951,t:1527188906129};\\\", \\\"{x:1419,y:944,t:1527188906145};\\\", \\\"{x:1419,y:934,t:1527188906162};\\\", \\\"{x:1419,y:906,t:1527188906179};\\\", \\\"{x:1419,y:885,t:1527188906195};\\\", \\\"{x:1419,y:860,t:1527188906212};\\\", \\\"{x:1419,y:843,t:1527188906229};\\\", \\\"{x:1419,y:826,t:1527188906245};\\\", \\\"{x:1419,y:810,t:1527188906261};\\\", \\\"{x:1419,y:791,t:1527188906279};\\\", \\\"{x:1419,y:774,t:1527188906295};\\\", \\\"{x:1419,y:754,t:1527188906312};\\\", \\\"{x:1419,y:740,t:1527188906329};\\\", \\\"{x:1419,y:727,t:1527188906345};\\\", \\\"{x:1419,y:710,t:1527188906362};\\\", \\\"{x:1419,y:697,t:1527188906379};\\\", \\\"{x:1419,y:687,t:1527188906395};\\\", \\\"{x:1419,y:679,t:1527188906412};\\\", \\\"{x:1419,y:670,t:1527188906428};\\\", \\\"{x:1419,y:662,t:1527188906446};\\\", \\\"{x:1420,y:652,t:1527188906462};\\\", \\\"{x:1420,y:643,t:1527188906479};\\\", \\\"{x:1420,y:636,t:1527188906496};\\\", \\\"{x:1422,y:630,t:1527188906512};\\\", \\\"{x:1422,y:625,t:1527188906530};\\\", \\\"{x:1423,y:618,t:1527188906546};\\\", \\\"{x:1424,y:614,t:1527188906562};\\\", \\\"{x:1425,y:607,t:1527188906579};\\\", \\\"{x:1427,y:601,t:1527188906595};\\\", \\\"{x:1428,y:594,t:1527188906612};\\\", \\\"{x:1430,y:589,t:1527188906628};\\\", \\\"{x:1430,y:585,t:1527188906646};\\\", \\\"{x:1431,y:581,t:1527188906662};\\\", \\\"{x:1431,y:579,t:1527188906679};\\\", \\\"{x:1432,y:576,t:1527188906696};\\\", \\\"{x:1432,y:572,t:1527188906712};\\\", \\\"{x:1433,y:569,t:1527188906729};\\\", \\\"{x:1434,y:568,t:1527188906746};\\\", \\\"{x:1434,y:566,t:1527188906762};\\\", \\\"{x:1434,y:565,t:1527188906796};\\\", \\\"{x:1434,y:564,t:1527188906836};\\\", \\\"{x:1433,y:564,t:1527188907043};\\\", \\\"{x:1432,y:564,t:1527188907050};\\\", \\\"{x:1430,y:564,t:1527188907063};\\\", \\\"{x:1426,y:566,t:1527188907079};\\\", \\\"{x:1423,y:568,t:1527188907096};\\\", \\\"{x:1422,y:570,t:1527188907113};\\\", \\\"{x:1420,y:571,t:1527188907128};\\\", \\\"{x:1418,y:574,t:1527188907145};\\\", \\\"{x:1416,y:580,t:1527188907162};\\\", \\\"{x:1415,y:585,t:1527188907178};\\\", \\\"{x:1413,y:590,t:1527188907195};\\\", \\\"{x:1410,y:603,t:1527188907212};\\\", \\\"{x:1406,y:620,t:1527188907228};\\\", \\\"{x:1403,y:641,t:1527188907245};\\\", \\\"{x:1400,y:665,t:1527188907262};\\\", \\\"{x:1397,y:686,t:1527188907279};\\\", \\\"{x:1397,y:708,t:1527188907295};\\\", \\\"{x:1397,y:726,t:1527188907312};\\\", \\\"{x:1397,y:742,t:1527188907330};\\\", \\\"{x:1397,y:760,t:1527188907345};\\\", \\\"{x:1397,y:795,t:1527188907363};\\\", \\\"{x:1397,y:826,t:1527188907379};\\\", \\\"{x:1397,y:856,t:1527188907395};\\\", \\\"{x:1397,y:876,t:1527188907413};\\\", \\\"{x:1397,y:887,t:1527188907429};\\\", \\\"{x:1397,y:894,t:1527188907446};\\\", \\\"{x:1397,y:903,t:1527188907463};\\\", \\\"{x:1399,y:916,t:1527188907480};\\\", \\\"{x:1402,y:934,t:1527188907496};\\\", \\\"{x:1404,y:955,t:1527188907513};\\\", \\\"{x:1407,y:970,t:1527188907530};\\\", \\\"{x:1409,y:978,t:1527188907546};\\\", \\\"{x:1412,y:981,t:1527188907563};\\\", \\\"{x:1412,y:985,t:1527188907580};\\\", \\\"{x:1415,y:989,t:1527188907596};\\\", \\\"{x:1415,y:995,t:1527188907613};\\\", \\\"{x:1417,y:1001,t:1527188907630};\\\", \\\"{x:1418,y:1002,t:1527188907646};\\\", \\\"{x:1418,y:997,t:1527188907810};\\\", \\\"{x:1418,y:992,t:1527188907819};\\\", \\\"{x:1418,y:982,t:1527188907829};\\\", \\\"{x:1418,y:963,t:1527188907846};\\\", \\\"{x:1418,y:943,t:1527188907863};\\\", \\\"{x:1418,y:918,t:1527188907879};\\\", \\\"{x:1418,y:895,t:1527188907897};\\\", \\\"{x:1418,y:868,t:1527188907912};\\\", \\\"{x:1419,y:841,t:1527188907929};\\\", \\\"{x:1419,y:811,t:1527188907947};\\\", \\\"{x:1419,y:791,t:1527188907963};\\\", \\\"{x:1419,y:778,t:1527188907980};\\\", \\\"{x:1421,y:764,t:1527188907997};\\\", \\\"{x:1427,y:736,t:1527188908013};\\\", \\\"{x:1438,y:697,t:1527188908030};\\\", \\\"{x:1440,y:673,t:1527188908047};\\\", \\\"{x:1443,y:658,t:1527188908063};\\\", \\\"{x:1444,y:649,t:1527188908079};\\\", \\\"{x:1444,y:646,t:1527188908096};\\\", \\\"{x:1444,y:641,t:1527188908113};\\\", \\\"{x:1444,y:634,t:1527188908130};\\\", \\\"{x:1445,y:619,t:1527188908147};\\\", \\\"{x:1445,y:612,t:1527188908163};\\\", \\\"{x:1445,y:603,t:1527188908180};\\\", \\\"{x:1445,y:597,t:1527188908197};\\\", \\\"{x:1444,y:594,t:1527188908214};\\\", \\\"{x:1442,y:591,t:1527188908230};\\\", \\\"{x:1439,y:586,t:1527188908247};\\\", \\\"{x:1438,y:582,t:1527188908264};\\\", \\\"{x:1435,y:579,t:1527188908279};\\\", \\\"{x:1434,y:577,t:1527188908297};\\\", \\\"{x:1432,y:574,t:1527188908314};\\\", \\\"{x:1432,y:573,t:1527188908588};\\\", \\\"{x:1431,y:573,t:1527188908597};\\\", \\\"{x:1430,y:573,t:1527188908614};\\\", \\\"{x:1429,y:573,t:1527188908631};\\\", \\\"{x:1427,y:572,t:1527188908647};\\\", \\\"{x:1426,y:571,t:1527188908664};\\\", \\\"{x:1424,y:571,t:1527188908681};\\\", \\\"{x:1422,y:570,t:1527188908697};\\\", \\\"{x:1419,y:569,t:1527188908714};\\\", \\\"{x:1415,y:568,t:1527188908732};\\\", \\\"{x:1413,y:567,t:1527188908747};\\\", \\\"{x:1412,y:567,t:1527188908804};\\\", \\\"{x:1412,y:568,t:1527188908987};\\\", \\\"{x:1411,y:576,t:1527188908998};\\\", \\\"{x:1408,y:591,t:1527188909014};\\\", \\\"{x:1407,y:609,t:1527188909031};\\\", \\\"{x:1407,y:632,t:1527188909048};\\\", \\\"{x:1407,y:657,t:1527188909064};\\\", \\\"{x:1407,y:676,t:1527188909081};\\\", \\\"{x:1407,y:695,t:1527188909097};\\\", \\\"{x:1407,y:711,t:1527188909113};\\\", \\\"{x:1407,y:739,t:1527188909130};\\\", \\\"{x:1407,y:767,t:1527188909147};\\\", \\\"{x:1407,y:789,t:1527188909163};\\\", \\\"{x:1407,y:805,t:1527188909181};\\\", \\\"{x:1407,y:816,t:1527188909198};\\\", \\\"{x:1407,y:827,t:1527188909214};\\\", \\\"{x:1407,y:847,t:1527188909231};\\\", \\\"{x:1409,y:869,t:1527188909248};\\\", \\\"{x:1413,y:893,t:1527188909263};\\\", \\\"{x:1420,y:916,t:1527188909280};\\\", \\\"{x:1422,y:923,t:1527188909297};\\\", \\\"{x:1423,y:925,t:1527188909313};\\\", \\\"{x:1425,y:929,t:1527188909331};\\\", \\\"{x:1425,y:935,t:1527188909348};\\\", \\\"{x:1427,y:943,t:1527188909364};\\\", \\\"{x:1428,y:950,t:1527188909381};\\\", \\\"{x:1429,y:955,t:1527188909398};\\\", \\\"{x:1429,y:956,t:1527188909414};\\\", \\\"{x:1429,y:957,t:1527188909523};\\\", \\\"{x:1428,y:958,t:1527188909531};\\\", \\\"{x:1427,y:960,t:1527188909548};\\\", \\\"{x:1426,y:961,t:1527188909565};\\\", \\\"{x:1425,y:963,t:1527188909581};\\\", \\\"{x:1425,y:964,t:1527188909627};\\\", \\\"{x:1423,y:965,t:1527188909636};\\\", \\\"{x:1422,y:966,t:1527188909651};\\\", \\\"{x:1421,y:967,t:1527188909665};\\\", \\\"{x:1420,y:967,t:1527188909681};\\\", \\\"{x:1419,y:967,t:1527188909914};\\\", \\\"{x:1418,y:963,t:1527188909971};\\\", \\\"{x:1417,y:957,t:1527188909982};\\\", \\\"{x:1416,y:951,t:1527188909998};\\\", \\\"{x:1414,y:945,t:1527188910015};\\\", \\\"{x:1414,y:942,t:1527188910032};\\\", \\\"{x:1414,y:941,t:1527188910047};\\\", \\\"{x:1414,y:939,t:1527188910064};\\\", \\\"{x:1413,y:937,t:1527188910081};\\\", \\\"{x:1413,y:934,t:1527188910099};\\\", \\\"{x:1413,y:928,t:1527188910115};\\\", \\\"{x:1412,y:920,t:1527188910132};\\\", \\\"{x:1412,y:906,t:1527188910148};\\\", \\\"{x:1412,y:887,t:1527188910165};\\\", \\\"{x:1409,y:869,t:1527188910182};\\\", \\\"{x:1408,y:847,t:1527188910198};\\\", \\\"{x:1407,y:826,t:1527188910214};\\\", \\\"{x:1407,y:810,t:1527188910232};\\\", \\\"{x:1407,y:797,t:1527188910247};\\\", \\\"{x:1404,y:788,t:1527188910265};\\\", \\\"{x:1404,y:780,t:1527188910282};\\\", \\\"{x:1404,y:767,t:1527188910298};\\\", \\\"{x:1403,y:756,t:1527188910314};\\\", \\\"{x:1403,y:744,t:1527188910331};\\\", \\\"{x:1403,y:739,t:1527188910348};\\\", \\\"{x:1403,y:727,t:1527188910364};\\\", \\\"{x:1403,y:717,t:1527188910382};\\\", \\\"{x:1403,y:708,t:1527188910399};\\\", \\\"{x:1403,y:702,t:1527188910414};\\\", \\\"{x:1403,y:693,t:1527188910431};\\\", \\\"{x:1403,y:682,t:1527188910448};\\\", \\\"{x:1403,y:665,t:1527188910465};\\\", \\\"{x:1403,y:653,t:1527188910481};\\\", \\\"{x:1403,y:640,t:1527188910498};\\\", \\\"{x:1403,y:633,t:1527188910515};\\\", \\\"{x:1403,y:628,t:1527188910531};\\\", \\\"{x:1403,y:618,t:1527188910549};\\\", \\\"{x:1403,y:609,t:1527188910565};\\\", \\\"{x:1403,y:601,t:1527188910582};\\\", \\\"{x:1403,y:595,t:1527188910599};\\\", \\\"{x:1403,y:592,t:1527188910615};\\\", \\\"{x:1403,y:589,t:1527188910632};\\\", \\\"{x:1403,y:587,t:1527188910649};\\\", \\\"{x:1403,y:585,t:1527188910665};\\\", \\\"{x:1403,y:583,t:1527188910682};\\\", \\\"{x:1403,y:578,t:1527188910699};\\\", \\\"{x:1403,y:575,t:1527188910715};\\\", \\\"{x:1403,y:572,t:1527188910732};\\\", \\\"{x:1403,y:571,t:1527188910749};\\\", \\\"{x:1403,y:568,t:1527188910767};\\\", \\\"{x:1403,y:566,t:1527188910782};\\\", \\\"{x:1403,y:565,t:1527188910799};\\\", \\\"{x:1403,y:563,t:1527188910816};\\\", \\\"{x:1403,y:561,t:1527188910832};\\\", \\\"{x:1403,y:559,t:1527188910849};\\\", \\\"{x:1403,y:557,t:1527188910867};\\\", \\\"{x:1403,y:556,t:1527188910882};\\\", \\\"{x:1403,y:554,t:1527188910899};\\\", \\\"{x:1403,y:553,t:1527188910916};\\\", \\\"{x:1403,y:552,t:1527188910932};\\\", \\\"{x:1403,y:551,t:1527188910949};\\\", \\\"{x:1403,y:550,t:1527188910968};\\\", \\\"{x:1403,y:549,t:1527188910982};\\\", \\\"{x:1403,y:548,t:1527188911003};\\\", \\\"{x:1403,y:540,t:1527188911411};\\\", \\\"{x:1402,y:530,t:1527188911420};\\\", \\\"{x:1402,y:522,t:1527188911433};\\\", \\\"{x:1402,y:506,t:1527188911449};\\\", \\\"{x:1398,y:477,t:1527188911466};\\\", \\\"{x:1393,y:451,t:1527188911483};\\\", \\\"{x:1393,y:445,t:1527188911499};\\\", \\\"{x:1393,y:440,t:1527188911516};\\\", \\\"{x:1393,y:436,t:1527188911533};\\\", \\\"{x:1392,y:431,t:1527188911548};\\\", \\\"{x:1392,y:429,t:1527188911567};\\\", \\\"{x:1391,y:428,t:1527188911587};\\\", \\\"{x:1392,y:427,t:1527188911891};\\\", \\\"{x:1393,y:427,t:1527188911899};\\\", \\\"{x:1395,y:428,t:1527188911916};\\\", \\\"{x:1397,y:428,t:1527188911938};\\\", \\\"{x:1397,y:429,t:1527188911950};\\\", \\\"{x:1399,y:434,t:1527188911966};\\\", \\\"{x:1399,y:441,t:1527188911983};\\\", \\\"{x:1399,y:455,t:1527188911999};\\\", \\\"{x:1399,y:476,t:1527188912015};\\\", \\\"{x:1399,y:501,t:1527188912033};\\\", \\\"{x:1399,y:526,t:1527188912049};\\\", \\\"{x:1399,y:562,t:1527188912067};\\\", \\\"{x:1399,y:585,t:1527188912083};\\\", \\\"{x:1399,y:603,t:1527188912100};\\\", \\\"{x:1397,y:625,t:1527188912117};\\\", \\\"{x:1396,y:643,t:1527188912133};\\\", \\\"{x:1392,y:654,t:1527188912150};\\\", \\\"{x:1392,y:669,t:1527188912166};\\\", \\\"{x:1392,y:684,t:1527188912184};\\\", \\\"{x:1392,y:704,t:1527188912200};\\\", \\\"{x:1392,y:727,t:1527188912218};\\\", \\\"{x:1392,y:745,t:1527188912233};\\\", \\\"{x:1392,y:760,t:1527188912250};\\\", \\\"{x:1392,y:784,t:1527188912267};\\\", \\\"{x:1392,y:797,t:1527188912283};\\\", \\\"{x:1392,y:813,t:1527188912300};\\\", \\\"{x:1392,y:824,t:1527188912317};\\\", \\\"{x:1392,y:836,t:1527188912333};\\\", \\\"{x:1394,y:848,t:1527188912350};\\\", \\\"{x:1395,y:858,t:1527188912368};\\\", \\\"{x:1396,y:870,t:1527188912383};\\\", \\\"{x:1400,y:885,t:1527188912400};\\\", \\\"{x:1404,y:900,t:1527188912417};\\\", \\\"{x:1409,y:912,t:1527188912433};\\\", \\\"{x:1410,y:917,t:1527188912451};\\\", \\\"{x:1412,y:920,t:1527188912467};\\\", \\\"{x:1414,y:923,t:1527188912484};\\\", \\\"{x:1414,y:926,t:1527188912507};\\\", \\\"{x:1416,y:930,t:1527188912517};\\\", \\\"{x:1417,y:934,t:1527188912534};\\\", \\\"{x:1418,y:938,t:1527188912550};\\\", \\\"{x:1418,y:939,t:1527188912567};\\\", \\\"{x:1420,y:932,t:1527188912715};\\\", \\\"{x:1420,y:923,t:1527188912723};\\\", \\\"{x:1420,y:913,t:1527188912734};\\\", \\\"{x:1422,y:891,t:1527188912750};\\\", \\\"{x:1422,y:862,t:1527188912767};\\\", \\\"{x:1422,y:830,t:1527188912785};\\\", \\\"{x:1424,y:788,t:1527188912801};\\\", \\\"{x:1424,y:743,t:1527188912818};\\\", \\\"{x:1424,y:711,t:1527188912834};\\\", \\\"{x:1424,y:675,t:1527188912851};\\\", \\\"{x:1424,y:623,t:1527188912867};\\\", \\\"{x:1424,y:592,t:1527188912884};\\\", \\\"{x:1424,y:563,t:1527188912900};\\\", \\\"{x:1424,y:534,t:1527188912917};\\\", \\\"{x:1424,y:525,t:1527188912934};\\\", \\\"{x:1424,y:522,t:1527188912951};\\\", \\\"{x:1424,y:517,t:1527188912967};\\\", \\\"{x:1422,y:510,t:1527188912984};\\\", \\\"{x:1421,y:502,t:1527188913001};\\\", \\\"{x:1421,y:496,t:1527188913018};\\\", \\\"{x:1419,y:489,t:1527188913035};\\\", \\\"{x:1418,y:485,t:1527188913051};\\\", \\\"{x:1416,y:483,t:1527188913067};\\\", \\\"{x:1416,y:482,t:1527188913084};\\\", \\\"{x:1415,y:480,t:1527188913101};\\\", \\\"{x:1415,y:475,t:1527188913117};\\\", \\\"{x:1414,y:471,t:1527188913134};\\\", \\\"{x:1413,y:465,t:1527188913151};\\\", \\\"{x:1413,y:461,t:1527188913167};\\\", \\\"{x:1413,y:456,t:1527188913184};\\\", \\\"{x:1413,y:450,t:1527188913201};\\\", \\\"{x:1413,y:445,t:1527188913217};\\\", \\\"{x:1413,y:436,t:1527188913234};\\\", \\\"{x:1413,y:425,t:1527188913252};\\\", \\\"{x:1413,y:420,t:1527188913267};\\\", \\\"{x:1413,y:417,t:1527188913284};\\\", \\\"{x:1413,y:416,t:1527188913307};\\\", \\\"{x:1413,y:415,t:1527188913317};\\\", \\\"{x:1413,y:419,t:1527188913419};\\\", \\\"{x:1413,y:429,t:1527188913435};\\\", \\\"{x:1413,y:467,t:1527188913452};\\\", \\\"{x:1413,y:525,t:1527188913468};\\\", \\\"{x:1413,y:598,t:1527188913484};\\\", \\\"{x:1413,y:651,t:1527188913501};\\\", \\\"{x:1413,y:707,t:1527188913518};\\\", \\\"{x:1413,y:738,t:1527188913534};\\\", \\\"{x:1413,y:770,t:1527188913551};\\\", \\\"{x:1416,y:813,t:1527188913568};\\\", \\\"{x:1416,y:858,t:1527188913584};\\\", \\\"{x:1416,y:894,t:1527188913601};\\\", \\\"{x:1416,y:921,t:1527188913618};\\\", \\\"{x:1416,y:938,t:1527188913635};\\\", \\\"{x:1416,y:965,t:1527188913651};\\\", \\\"{x:1416,y:985,t:1527188913668};\\\", \\\"{x:1416,y:1006,t:1527188913684};\\\", \\\"{x:1417,y:1016,t:1527188913701};\\\", \\\"{x:1417,y:1020,t:1527188913718};\\\", \\\"{x:1417,y:1022,t:1527188913734};\\\", \\\"{x:1417,y:1023,t:1527188913751};\\\", \\\"{x:1417,y:1022,t:1527188913851};\\\", \\\"{x:1417,y:1005,t:1527188913868};\\\", \\\"{x:1417,y:986,t:1527188913885};\\\", \\\"{x:1419,y:958,t:1527188913901};\\\", \\\"{x:1422,y:916,t:1527188913918};\\\", \\\"{x:1421,y:851,t:1527188913935};\\\", \\\"{x:1418,y:797,t:1527188913951};\\\", \\\"{x:1418,y:725,t:1527188913972};\\\", \\\"{x:1418,y:655,t:1527188913989};\\\", \\\"{x:1418,y:608,t:1527188914005};\\\", \\\"{x:1418,y:566,t:1527188914022};\\\", \\\"{x:1418,y:512,t:1527188914040};\\\", \\\"{x:1418,y:477,t:1527188914055};\\\", \\\"{x:1421,y:458,t:1527188914072};\\\", \\\"{x:1422,y:445,t:1527188914089};\\\", \\\"{x:1422,y:430,t:1527188914106};\\\", \\\"{x:1422,y:419,t:1527188914122};\\\", \\\"{x:1422,y:410,t:1527188914140};\\\", \\\"{x:1422,y:404,t:1527188914155};\\\", \\\"{x:1422,y:401,t:1527188914172};\\\", \\\"{x:1422,y:400,t:1527188914189};\\\", \\\"{x:1421,y:400,t:1527188914319};\\\", \\\"{x:1418,y:411,t:1527188914327};\\\", \\\"{x:1415,y:422,t:1527188914339};\\\", \\\"{x:1409,y:459,t:1527188914357};\\\", \\\"{x:1401,y:520,t:1527188914373};\\\", \\\"{x:1395,y:613,t:1527188914389};\\\", \\\"{x:1395,y:721,t:1527188914406};\\\", \\\"{x:1395,y:821,t:1527188914422};\\\", \\\"{x:1395,y:932,t:1527188914438};\\\", \\\"{x:1395,y:964,t:1527188914456};\\\", \\\"{x:1395,y:989,t:1527188914472};\\\", \\\"{x:1395,y:1016,t:1527188914488};\\\", \\\"{x:1395,y:1046,t:1527188914506};\\\", \\\"{x:1395,y:1069,t:1527188914522};\\\", \\\"{x:1395,y:1084,t:1527188914539};\\\", \\\"{x:1395,y:1093,t:1527188914555};\\\", \\\"{x:1395,y:1096,t:1527188914572};\\\", \\\"{x:1395,y:1079,t:1527188914687};\\\", \\\"{x:1395,y:1064,t:1527188914695};\\\", \\\"{x:1395,y:1050,t:1527188914707};\\\", \\\"{x:1396,y:1010,t:1527188914724};\\\", \\\"{x:1397,y:967,t:1527188914740};\\\", \\\"{x:1399,y:914,t:1527188914756};\\\", \\\"{x:1405,y:850,t:1527188914773};\\\", \\\"{x:1407,y:772,t:1527188914789};\\\", \\\"{x:1422,y:682,t:1527188914807};\\\", \\\"{x:1432,y:595,t:1527188914823};\\\", \\\"{x:1438,y:556,t:1527188914839};\\\", \\\"{x:1438,y:537,t:1527188914856};\\\", \\\"{x:1438,y:521,t:1527188914873};\\\", \\\"{x:1438,y:507,t:1527188914889};\\\", \\\"{x:1439,y:495,t:1527188914906};\\\", \\\"{x:1439,y:486,t:1527188914923};\\\", \\\"{x:1439,y:476,t:1527188914939};\\\", \\\"{x:1439,y:470,t:1527188914956};\\\", \\\"{x:1441,y:463,t:1527188914974};\\\", \\\"{x:1441,y:461,t:1527188914990};\\\", \\\"{x:1442,y:459,t:1527188915006};\\\", \\\"{x:1442,y:458,t:1527188915071};\\\", \\\"{x:1441,y:458,t:1527188915079};\\\", \\\"{x:1438,y:465,t:1527188915089};\\\", \\\"{x:1427,y:502,t:1527188915106};\\\", \\\"{x:1413,y:575,t:1527188915124};\\\", \\\"{x:1396,y:663,t:1527188915141};\\\", \\\"{x:1386,y:764,t:1527188915156};\\\", \\\"{x:1383,y:860,t:1527188915174};\\\", \\\"{x:1377,y:944,t:1527188915190};\\\", \\\"{x:1377,y:1008,t:1527188915206};\\\", \\\"{x:1377,y:1086,t:1527188915223};\\\", \\\"{x:1377,y:1115,t:1527188915240};\\\", \\\"{x:1377,y:1126,t:1527188915257};\\\", \\\"{x:1377,y:1127,t:1527188915273};\\\", \\\"{x:1378,y:1120,t:1527188915383};\\\", \\\"{x:1379,y:1095,t:1527188915391};\\\", \\\"{x:1384,y:1063,t:1527188915406};\\\", \\\"{x:1386,y:990,t:1527188915423};\\\", \\\"{x:1386,y:912,t:1527188915441};\\\", \\\"{x:1386,y:815,t:1527188915457};\\\", \\\"{x:1386,y:731,t:1527188915473};\\\", \\\"{x:1386,y:678,t:1527188915490};\\\", \\\"{x:1396,y:611,t:1527188915506};\\\", \\\"{x:1399,y:565,t:1527188915523};\\\", \\\"{x:1399,y:541,t:1527188915540};\\\", \\\"{x:1399,y:527,t:1527188915557};\\\", \\\"{x:1399,y:514,t:1527188915573};\\\", \\\"{x:1399,y:505,t:1527188915591};\\\", \\\"{x:1399,y:493,t:1527188915607};\\\", \\\"{x:1399,y:486,t:1527188915623};\\\", \\\"{x:1399,y:483,t:1527188915640};\\\", \\\"{x:1398,y:486,t:1527188915704};\\\", \\\"{x:1396,y:496,t:1527188915711};\\\", \\\"{x:1395,y:507,t:1527188915723};\\\", \\\"{x:1392,y:538,t:1527188915740};\\\", \\\"{x:1390,y:579,t:1527188915757};\\\", \\\"{x:1390,y:647,t:1527188915774};\\\", \\\"{x:1403,y:731,t:1527188915791};\\\", \\\"{x:1418,y:851,t:1527188915807};\\\", \\\"{x:1426,y:904,t:1527188915823};\\\", \\\"{x:1432,y:946,t:1527188915840};\\\", \\\"{x:1433,y:967,t:1527188915858};\\\", \\\"{x:1433,y:983,t:1527188915877};\\\", \\\"{x:1433,y:997,t:1527188915890};\\\", \\\"{x:1433,y:1002,t:1527188915906};\\\", \\\"{x:1433,y:997,t:1527188916111};\\\", \\\"{x:1432,y:993,t:1527188916125};\\\", \\\"{x:1428,y:985,t:1527188916140};\\\", \\\"{x:1428,y:982,t:1527188916158};\\\", \\\"{x:1427,y:982,t:1527188916175};\\\", \\\"{x:1427,y:981,t:1527188916214};\\\", \\\"{x:1427,y:974,t:1527188916224};\\\", \\\"{x:1427,y:948,t:1527188916240};\\\", \\\"{x:1427,y:913,t:1527188916256};\\\", \\\"{x:1427,y:883,t:1527188916273};\\\", \\\"{x:1427,y:855,t:1527188916290};\\\", \\\"{x:1430,y:805,t:1527188916307};\\\", \\\"{x:1440,y:732,t:1527188916324};\\\", \\\"{x:1443,y:683,t:1527188916340};\\\", \\\"{x:1443,y:622,t:1527188916357};\\\", \\\"{x:1443,y:579,t:1527188916374};\\\", \\\"{x:1443,y:556,t:1527188916390};\\\", \\\"{x:1443,y:537,t:1527188916406};\\\", \\\"{x:1443,y:528,t:1527188916425};\\\", \\\"{x:1443,y:521,t:1527188916440};\\\", \\\"{x:1443,y:515,t:1527188916457};\\\", \\\"{x:1441,y:512,t:1527188916474};\\\", \\\"{x:1440,y:508,t:1527188916491};\\\", \\\"{x:1440,y:507,t:1527188916507};\\\", \\\"{x:1440,y:505,t:1527188916524};\\\", \\\"{x:1439,y:502,t:1527188916541};\\\", \\\"{x:1437,y:499,t:1527188916557};\\\", \\\"{x:1434,y:494,t:1527188916575};\\\", \\\"{x:1432,y:483,t:1527188916591};\\\", \\\"{x:1431,y:479,t:1527188916607};\\\", \\\"{x:1430,y:473,t:1527188916625};\\\", \\\"{x:1430,y:468,t:1527188916641};\\\", \\\"{x:1429,y:466,t:1527188916657};\\\", \\\"{x:1428,y:463,t:1527188916675};\\\", \\\"{x:1427,y:462,t:1527188916691};\\\", \\\"{x:1427,y:461,t:1527188916711};\\\", \\\"{x:1427,y:458,t:1527188917056};\\\", \\\"{x:1427,y:452,t:1527188917063};\\\", \\\"{x:1427,y:445,t:1527188917074};\\\", \\\"{x:1430,y:433,t:1527188917091};\\\", \\\"{x:1434,y:424,t:1527188917109};\\\", \\\"{x:1444,y:410,t:1527188917124};\\\", \\\"{x:1453,y:399,t:1527188917142};\\\", \\\"{x:1459,y:383,t:1527188917159};\\\", \\\"{x:1464,y:365,t:1527188917175};\\\", \\\"{x:1468,y:334,t:1527188917191};\\\", \\\"{x:1469,y:319,t:1527188917208};\\\", \\\"{x:1469,y:308,t:1527188917224};\\\", \\\"{x:1469,y:305,t:1527188917242};\\\", \\\"{x:1469,y:302,t:1527188917258};\\\", \\\"{x:1469,y:296,t:1527188917275};\\\", \\\"{x:1469,y:287,t:1527188917292};\\\", \\\"{x:1468,y:277,t:1527188917308};\\\", \\\"{x:1467,y:269,t:1527188917325};\\\", \\\"{x:1467,y:265,t:1527188917342};\\\", \\\"{x:1467,y:262,t:1527188917358};\\\", \\\"{x:1467,y:258,t:1527188917375};\\\", \\\"{x:1467,y:255,t:1527188917392};\\\", \\\"{x:1467,y:252,t:1527188917408};\\\", \\\"{x:1467,y:249,t:1527188917426};\\\", \\\"{x:1468,y:244,t:1527188917442};\\\", \\\"{x:1469,y:241,t:1527188917458};\\\", \\\"{x:1470,y:236,t:1527188917475};\\\", \\\"{x:1472,y:232,t:1527188917491};\\\", \\\"{x:1474,y:227,t:1527188917509};\\\", \\\"{x:1475,y:223,t:1527188917526};\\\", \\\"{x:1477,y:221,t:1527188917542};\\\", \\\"{x:1479,y:215,t:1527188917558};\\\", \\\"{x:1483,y:203,t:1527188917575};\\\", \\\"{x:1487,y:191,t:1527188917591};\\\", \\\"{x:1492,y:180,t:1527188917608};\\\", \\\"{x:1495,y:172,t:1527188917626};\\\", \\\"{x:1498,y:168,t:1527188917641};\\\", \\\"{x:1498,y:165,t:1527188917658};\\\", \\\"{x:1498,y:174,t:1527188917903};\\\", \\\"{x:1500,y:191,t:1527188917911};\\\", \\\"{x:1504,y:213,t:1527188917925};\\\", \\\"{x:1507,y:246,t:1527188917943};\\\", \\\"{x:1508,y:276,t:1527188917959};\\\", \\\"{x:1514,y:330,t:1527188917975};\\\", \\\"{x:1514,y:366,t:1527188917993};\\\", \\\"{x:1514,y:402,t:1527188918009};\\\", \\\"{x:1517,y:453,t:1527188918025};\\\", \\\"{x:1517,y:509,t:1527188918042};\\\", \\\"{x:1517,y:579,t:1527188918059};\\\", \\\"{x:1517,y:634,t:1527188918076};\\\", \\\"{x:1517,y:679,t:1527188918094};\\\", \\\"{x:1517,y:705,t:1527188918109};\\\", \\\"{x:1516,y:716,t:1527188918126};\\\", \\\"{x:1513,y:724,t:1527188918143};\\\", \\\"{x:1508,y:739,t:1527188918159};\\\", \\\"{x:1495,y:773,t:1527188918176};\\\", \\\"{x:1482,y:795,t:1527188918193};\\\", \\\"{x:1474,y:806,t:1527188918209};\\\", \\\"{x:1471,y:810,t:1527188918226};\\\", \\\"{x:1470,y:810,t:1527188918312};\\\", \\\"{x:1469,y:810,t:1527188918327};\\\", \\\"{x:1469,y:807,t:1527188918342};\\\", \\\"{x:1469,y:792,t:1527188918359};\\\", \\\"{x:1471,y:783,t:1527188918376};\\\", \\\"{x:1471,y:780,t:1527188918393};\\\", \\\"{x:1471,y:784,t:1527188918824};\\\", \\\"{x:1472,y:787,t:1527188918831};\\\", \\\"{x:1473,y:790,t:1527188918843};\\\", \\\"{x:1475,y:794,t:1527188918859};\\\", \\\"{x:1475,y:799,t:1527188918877};\\\", \\\"{x:1476,y:802,t:1527188918892};\\\", \\\"{x:1478,y:808,t:1527188918910};\\\", \\\"{x:1479,y:812,t:1527188918927};\\\", \\\"{x:1480,y:814,t:1527188918943};\\\", \\\"{x:1480,y:815,t:1527188918959};\\\", \\\"{x:1481,y:817,t:1527188918991};\\\", \\\"{x:1482,y:818,t:1527188918999};\\\", \\\"{x:1482,y:819,t:1527188919009};\\\", \\\"{x:1482,y:821,t:1527188919026};\\\", \\\"{x:1483,y:822,t:1527188919042};\\\", \\\"{x:1483,y:823,t:1527188919087};\\\", \\\"{x:1483,y:824,t:1527188919095};\\\", \\\"{x:1483,y:827,t:1527188919110};\\\", \\\"{x:1483,y:831,t:1527188919126};\\\", \\\"{x:1483,y:832,t:1527188919143};\\\", \\\"{x:1484,y:834,t:1527188919159};\\\", \\\"{x:1485,y:835,t:1527188919178};\\\", \\\"{x:1485,y:840,t:1527188919193};\\\", \\\"{x:1485,y:848,t:1527188919210};\\\", \\\"{x:1486,y:854,t:1527188919227};\\\", \\\"{x:1487,y:857,t:1527188919244};\\\", \\\"{x:1487,y:860,t:1527188919260};\\\", \\\"{x:1487,y:863,t:1527188919277};\\\", \\\"{x:1488,y:872,t:1527188919293};\\\", \\\"{x:1489,y:881,t:1527188919309};\\\", \\\"{x:1489,y:888,t:1527188919327};\\\", \\\"{x:1489,y:891,t:1527188919343};\\\", \\\"{x:1489,y:897,t:1527188919360};\\\", \\\"{x:1489,y:899,t:1527188919376};\\\", \\\"{x:1487,y:901,t:1527188919393};\\\", \\\"{x:1486,y:904,t:1527188919409};\\\", \\\"{x:1485,y:906,t:1527188919504};\\\", \\\"{x:1485,y:907,t:1527188919520};\\\", \\\"{x:1484,y:908,t:1527188919526};\\\", \\\"{x:1482,y:916,t:1527188919543};\\\", \\\"{x:1482,y:919,t:1527188919561};\\\", \\\"{x:1481,y:921,t:1527188919822};\\\", \\\"{x:1480,y:921,t:1527188919830};\\\", \\\"{x:1480,y:924,t:1527188919878};\\\", \\\"{x:1480,y:925,t:1527188919893};\\\", \\\"{x:1480,y:926,t:1527188919910};\\\", \\\"{x:1480,y:927,t:1527188919942};\\\", \\\"{x:1480,y:928,t:1527188919950};\\\", \\\"{x:1479,y:929,t:1527188919960};\\\", \\\"{x:1479,y:930,t:1527188919977};\\\", \\\"{x:1478,y:933,t:1527188919993};\\\", \\\"{x:1478,y:936,t:1527188920063};\\\", \\\"{x:1478,y:938,t:1527188920077};\\\", \\\"{x:1478,y:945,t:1527188920093};\\\", \\\"{x:1478,y:950,t:1527188920110};\\\", \\\"{x:1478,y:951,t:1527188920127};\\\", \\\"{x:1478,y:952,t:1527188920207};\\\", \\\"{x:1478,y:948,t:1527188920328};\\\", \\\"{x:1475,y:942,t:1527188920343};\\\", \\\"{x:1475,y:939,t:1527188920360};\\\", \\\"{x:1473,y:935,t:1527188920377};\\\", \\\"{x:1472,y:931,t:1527188920394};\\\", \\\"{x:1471,y:929,t:1527188920410};\\\", \\\"{x:1471,y:925,t:1527188920427};\\\", \\\"{x:1470,y:924,t:1527188920444};\\\", \\\"{x:1470,y:923,t:1527188920460};\\\", \\\"{x:1470,y:920,t:1527188920511};\\\", \\\"{x:1468,y:917,t:1527188920527};\\\", \\\"{x:1468,y:913,t:1527188920545};\\\", \\\"{x:1467,y:910,t:1527188920561};\\\", \\\"{x:1467,y:906,t:1527188920578};\\\", \\\"{x:1467,y:900,t:1527188920595};\\\", \\\"{x:1467,y:896,t:1527188920611};\\\", \\\"{x:1467,y:892,t:1527188920628};\\\", \\\"{x:1467,y:889,t:1527188920644};\\\", \\\"{x:1467,y:881,t:1527188920661};\\\", \\\"{x:1467,y:877,t:1527188920678};\\\", \\\"{x:1467,y:873,t:1527188920695};\\\", \\\"{x:1467,y:869,t:1527188920711};\\\", \\\"{x:1467,y:866,t:1527188920727};\\\", \\\"{x:1467,y:863,t:1527188920745};\\\", \\\"{x:1467,y:860,t:1527188920760};\\\", \\\"{x:1467,y:855,t:1527188920777};\\\", \\\"{x:1467,y:849,t:1527188920794};\\\", \\\"{x:1467,y:845,t:1527188920811};\\\", \\\"{x:1467,y:842,t:1527188920827};\\\", \\\"{x:1467,y:841,t:1527188920847};\\\", \\\"{x:1467,y:839,t:1527188920887};\\\", \\\"{x:1467,y:838,t:1527188920895};\\\", \\\"{x:1467,y:832,t:1527188920911};\\\", \\\"{x:1467,y:830,t:1527188920927};\\\", \\\"{x:1467,y:828,t:1527188920945};\\\", \\\"{x:1467,y:827,t:1527188920967};\\\", \\\"{x:1468,y:826,t:1527188921271};\\\", \\\"{x:1470,y:825,t:1527188921279};\\\", \\\"{x:1472,y:825,t:1527188921294};\\\", \\\"{x:1478,y:823,t:1527188921311};\\\", \\\"{x:1485,y:823,t:1527188921329};\\\", \\\"{x:1486,y:823,t:1527188921344};\\\", \\\"{x:1490,y:824,t:1527188921361};\\\", \\\"{x:1494,y:824,t:1527188921379};\\\", \\\"{x:1499,y:824,t:1527188921395};\\\", \\\"{x:1505,y:825,t:1527188921411};\\\", \\\"{x:1509,y:825,t:1527188921428};\\\", \\\"{x:1512,y:826,t:1527188921445};\\\", \\\"{x:1514,y:826,t:1527188921461};\\\", \\\"{x:1517,y:826,t:1527188921478};\\\", \\\"{x:1519,y:827,t:1527188921494};\\\", \\\"{x:1521,y:828,t:1527188921510};\\\", \\\"{x:1529,y:829,t:1527188921528};\\\", \\\"{x:1538,y:832,t:1527188921544};\\\", \\\"{x:1544,y:833,t:1527188921561};\\\", \\\"{x:1547,y:834,t:1527188921578};\\\", \\\"{x:1549,y:834,t:1527188921594};\\\", \\\"{x:1550,y:834,t:1527188921611};\\\", \\\"{x:1552,y:834,t:1527188921628};\\\", \\\"{x:1556,y:834,t:1527188921644};\\\", \\\"{x:1571,y:836,t:1527188921661};\\\", \\\"{x:1598,y:839,t:1527188921678};\\\", \\\"{x:1619,y:841,t:1527188921695};\\\", \\\"{x:1630,y:841,t:1527188921712};\\\", \\\"{x:1636,y:841,t:1527188921729};\\\", \\\"{x:1636,y:842,t:1527188921815};\\\", \\\"{x:1634,y:842,t:1527188922135};\\\", \\\"{x:1633,y:842,t:1527188922145};\\\", \\\"{x:1630,y:842,t:1527188922162};\\\", \\\"{x:1626,y:842,t:1527188922179};\\\", \\\"{x:1619,y:842,t:1527188922195};\\\", \\\"{x:1610,y:841,t:1527188922213};\\\", \\\"{x:1597,y:839,t:1527188922228};\\\", \\\"{x:1582,y:836,t:1527188922246};\\\", \\\"{x:1561,y:836,t:1527188922263};\\\", \\\"{x:1547,y:836,t:1527188922279};\\\", \\\"{x:1536,y:836,t:1527188922296};\\\", \\\"{x:1528,y:836,t:1527188922312};\\\", \\\"{x:1523,y:836,t:1527188922328};\\\", \\\"{x:1521,y:836,t:1527188922346};\\\", \\\"{x:1520,y:836,t:1527188922362};\\\", \\\"{x:1518,y:836,t:1527188922378};\\\", \\\"{x:1516,y:836,t:1527188922395};\\\", \\\"{x:1512,y:836,t:1527188922412};\\\", \\\"{x:1503,y:836,t:1527188922429};\\\", \\\"{x:1495,y:836,t:1527188922445};\\\", \\\"{x:1482,y:836,t:1527188922463};\\\", \\\"{x:1477,y:834,t:1527188922480};\\\", \\\"{x:1470,y:834,t:1527188922497};\\\", \\\"{x:1467,y:833,t:1527188922513};\\\", \\\"{x:1464,y:833,t:1527188922529};\\\", \\\"{x:1462,y:833,t:1527188922546};\\\", \\\"{x:1459,y:833,t:1527188922563};\\\", \\\"{x:1455,y:833,t:1527188922579};\\\", \\\"{x:1454,y:833,t:1527188922596};\\\", \\\"{x:1453,y:833,t:1527188922613};\\\", \\\"{x:1452,y:833,t:1527188922630};\\\", \\\"{x:1452,y:832,t:1527188922831};\\\", \\\"{x:1452,y:831,t:1527188922845};\\\", \\\"{x:1461,y:829,t:1527188922863};\\\", \\\"{x:1472,y:829,t:1527188922879};\\\", \\\"{x:1484,y:829,t:1527188922896};\\\", \\\"{x:1498,y:829,t:1527188922914};\\\", \\\"{x:1510,y:829,t:1527188922929};\\\", \\\"{x:1522,y:829,t:1527188922945};\\\", \\\"{x:1527,y:829,t:1527188922963};\\\", \\\"{x:1531,y:829,t:1527188922979};\\\", \\\"{x:1534,y:829,t:1527188922996};\\\", \\\"{x:1537,y:829,t:1527188923013};\\\", \\\"{x:1541,y:829,t:1527188923030};\\\", \\\"{x:1545,y:829,t:1527188923046};\\\", \\\"{x:1557,y:829,t:1527188923063};\\\", \\\"{x:1564,y:830,t:1527188923079};\\\", \\\"{x:1573,y:832,t:1527188923097};\\\", \\\"{x:1575,y:832,t:1527188923113};\\\", \\\"{x:1581,y:833,t:1527188923130};\\\", \\\"{x:1590,y:837,t:1527188923147};\\\", \\\"{x:1598,y:838,t:1527188923163};\\\", \\\"{x:1602,y:839,t:1527188923179};\\\", \\\"{x:1604,y:841,t:1527188923196};\\\", \\\"{x:1602,y:841,t:1527188923311};\\\", \\\"{x:1597,y:840,t:1527188923319};\\\", \\\"{x:1593,y:840,t:1527188923330};\\\", \\\"{x:1590,y:839,t:1527188923346};\\\", \\\"{x:1586,y:839,t:1527188923363};\\\", \\\"{x:1584,y:839,t:1527188923380};\\\", \\\"{x:1579,y:839,t:1527188923397};\\\", \\\"{x:1578,y:839,t:1527188923413};\\\", \\\"{x:1574,y:839,t:1527188923430};\\\", \\\"{x:1563,y:839,t:1527188923447};\\\", \\\"{x:1550,y:837,t:1527188923463};\\\", \\\"{x:1532,y:836,t:1527188923480};\\\", \\\"{x:1510,y:836,t:1527188923497};\\\", \\\"{x:1484,y:836,t:1527188923513};\\\", \\\"{x:1456,y:836,t:1527188923530};\\\", \\\"{x:1420,y:835,t:1527188923546};\\\", \\\"{x:1378,y:830,t:1527188923564};\\\", \\\"{x:1323,y:826,t:1527188923580};\\\", \\\"{x:1247,y:809,t:1527188923596};\\\", \\\"{x:1198,y:803,t:1527188923614};\\\", \\\"{x:1167,y:794,t:1527188923629};\\\", \\\"{x:1129,y:782,t:1527188923646};\\\", \\\"{x:1084,y:772,t:1527188923663};\\\", \\\"{x:1051,y:772,t:1527188923680};\\\", \\\"{x:1021,y:771,t:1527188923697};\\\", \\\"{x:1007,y:770,t:1527188923714};\\\", \\\"{x:1005,y:769,t:1527188923729};\\\", \\\"{x:1004,y:769,t:1527188923746};\\\", \\\"{x:1000,y:769,t:1527188923764};\\\", \\\"{x:998,y:769,t:1527188923780};\\\", \\\"{x:993,y:769,t:1527188923797};\\\", \\\"{x:983,y:769,t:1527188923814};\\\", \\\"{x:967,y:777,t:1527188923829};\\\", \\\"{x:939,y:783,t:1527188923847};\\\", \\\"{x:918,y:788,t:1527188923862};\\\", \\\"{x:897,y:788,t:1527188923881};\\\", \\\"{x:872,y:788,t:1527188923896};\\\", \\\"{x:851,y:785,t:1527188923914};\\\", \\\"{x:822,y:782,t:1527188923930};\\\", \\\"{x:796,y:777,t:1527188923946};\\\", \\\"{x:774,y:774,t:1527188923963};\\\", \\\"{x:755,y:768,t:1527188923980};\\\", \\\"{x:744,y:764,t:1527188923996};\\\", \\\"{x:735,y:760,t:1527188924013};\\\", \\\"{x:721,y:754,t:1527188924031};\\\", \\\"{x:708,y:751,t:1527188924047};\\\", \\\"{x:697,y:750,t:1527188924063};\\\", \\\"{x:683,y:749,t:1527188924081};\\\", \\\"{x:672,y:747,t:1527188924097};\\\", \\\"{x:662,y:745,t:1527188924114};\\\", \\\"{x:648,y:740,t:1527188924131};\\\", \\\"{x:631,y:735,t:1527188924146};\\\", \\\"{x:614,y:732,t:1527188924163};\\\", \\\"{x:596,y:729,t:1527188924181};\\\", \\\"{x:579,y:725,t:1527188924196};\\\", \\\"{x:569,y:724,t:1527188924213};\\\", \\\"{x:557,y:724,t:1527188924232};\\\", \\\"{x:552,y:722,t:1527188924247};\\\", \\\"{x:548,y:721,t:1527188924263};\\\", \\\"{x:545,y:721,t:1527188924283};\\\", \\\"{x:544,y:720,t:1527188924302};\\\", \\\"{x:545,y:720,t:1527188925023};\\\", \\\"{x:553,y:721,t:1527188925034};\\\", \\\"{x:581,y:729,t:1527188925052};\\\", \\\"{x:629,y:744,t:1527188925068};\\\", \\\"{x:669,y:758,t:1527188925084};\\\", \\\"{x:732,y:774,t:1527188925101};\\\", \\\"{x:796,y:793,t:1527188925117};\\\", \\\"{x:864,y:809,t:1527188925134};\\\", \\\"{x:886,y:814,t:1527188925151};\\\", \\\"{x:897,y:818,t:1527188925167};\\\" ] }, { \\\"rt\\\": 7711, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 319090, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:904,y:817,t:1527188927830};\\\", \\\"{x:915,y:811,t:1527188927838};\\\", \\\"{x:925,y:810,t:1527188927853};\\\", \\\"{x:965,y:808,t:1527188927870};\\\", \\\"{x:1000,y:808,t:1527188927886};\\\", \\\"{x:1037,y:808,t:1527188927903};\\\", \\\"{x:1067,y:808,t:1527188927920};\\\", \\\"{x:1088,y:808,t:1527188927936};\\\", \\\"{x:1112,y:808,t:1527188927954};\\\", \\\"{x:1135,y:808,t:1527188927970};\\\", \\\"{x:1161,y:809,t:1527188927986};\\\", \\\"{x:1174,y:809,t:1527188928003};\\\", \\\"{x:1179,y:808,t:1527188928021};\\\", \\\"{x:1183,y:807,t:1527188928036};\\\", \\\"{x:1186,y:807,t:1527188928053};\\\", \\\"{x:1194,y:806,t:1527188928071};\\\", \\\"{x:1197,y:803,t:1527188928086};\\\", \\\"{x:1198,y:802,t:1527188928104};\\\", \\\"{x:1199,y:801,t:1527188928542};\\\", \\\"{x:1201,y:791,t:1527188928554};\\\", \\\"{x:1207,y:767,t:1527188928571};\\\", \\\"{x:1213,y:743,t:1527188928587};\\\", \\\"{x:1215,y:725,t:1527188928603};\\\", \\\"{x:1219,y:707,t:1527188928621};\\\", \\\"{x:1226,y:690,t:1527188928638};\\\", \\\"{x:1237,y:668,t:1527188928654};\\\", \\\"{x:1258,y:639,t:1527188928671};\\\", \\\"{x:1274,y:612,t:1527188928688};\\\", \\\"{x:1287,y:589,t:1527188928704};\\\", \\\"{x:1294,y:573,t:1527188928720};\\\", \\\"{x:1299,y:561,t:1527188928738};\\\", \\\"{x:1307,y:549,t:1527188928755};\\\", \\\"{x:1321,y:531,t:1527188928770};\\\", \\\"{x:1334,y:516,t:1527188928787};\\\", \\\"{x:1345,y:503,t:1527188928805};\\\", \\\"{x:1355,y:493,t:1527188928821};\\\", \\\"{x:1362,y:485,t:1527188928838};\\\", \\\"{x:1366,y:478,t:1527188928855};\\\", \\\"{x:1366,y:479,t:1527188929048};\\\", \\\"{x:1366,y:481,t:1527188929055};\\\", \\\"{x:1365,y:486,t:1527188929071};\\\", \\\"{x:1362,y:498,t:1527188929087};\\\", \\\"{x:1359,y:511,t:1527188929105};\\\", \\\"{x:1355,y:523,t:1527188929121};\\\", \\\"{x:1353,y:529,t:1527188929138};\\\", \\\"{x:1351,y:533,t:1527188929154};\\\", \\\"{x:1347,y:539,t:1527188929171};\\\", \\\"{x:1340,y:550,t:1527188929187};\\\", \\\"{x:1325,y:564,t:1527188929205};\\\", \\\"{x:1320,y:572,t:1527188929221};\\\", \\\"{x:1313,y:577,t:1527188929238};\\\", \\\"{x:1306,y:581,t:1527188929255};\\\", \\\"{x:1303,y:584,t:1527188929271};\\\", \\\"{x:1302,y:584,t:1527188929288};\\\", \\\"{x:1300,y:584,t:1527188929327};\\\", \\\"{x:1298,y:585,t:1527188929337};\\\", \\\"{x:1294,y:586,t:1527188929355};\\\", \\\"{x:1290,y:587,t:1527188929372};\\\", \\\"{x:1286,y:587,t:1527188929388};\\\", \\\"{x:1285,y:587,t:1527188929405};\\\", \\\"{x:1281,y:587,t:1527188929422};\\\", \\\"{x:1278,y:587,t:1527188929438};\\\", \\\"{x:1276,y:587,t:1527188929455};\\\", \\\"{x:1276,y:586,t:1527188929471};\\\", \\\"{x:1275,y:585,t:1527188929487};\\\", \\\"{x:1274,y:583,t:1527188929505};\\\", \\\"{x:1272,y:581,t:1527188929522};\\\", \\\"{x:1272,y:579,t:1527188929538};\\\", \\\"{x:1272,y:578,t:1527188929555};\\\", \\\"{x:1271,y:576,t:1527188929571};\\\", \\\"{x:1271,y:575,t:1527188929663};\\\", \\\"{x:1271,y:574,t:1527188929687};\\\", \\\"{x:1271,y:572,t:1527188929912};\\\", \\\"{x:1271,y:571,t:1527188929922};\\\", \\\"{x:1274,y:570,t:1527188929938};\\\", \\\"{x:1277,y:570,t:1527188929955};\\\", \\\"{x:1283,y:569,t:1527188929972};\\\", \\\"{x:1287,y:569,t:1527188929988};\\\", \\\"{x:1290,y:569,t:1527188930005};\\\", \\\"{x:1294,y:569,t:1527188930022};\\\", \\\"{x:1300,y:569,t:1527188930039};\\\", \\\"{x:1303,y:567,t:1527188930054};\\\", \\\"{x:1310,y:567,t:1527188930072};\\\", \\\"{x:1319,y:567,t:1527188930089};\\\", \\\"{x:1334,y:567,t:1527188930105};\\\", \\\"{x:1351,y:567,t:1527188930122};\\\", \\\"{x:1368,y:567,t:1527188930139};\\\", \\\"{x:1381,y:567,t:1527188930155};\\\", \\\"{x:1392,y:567,t:1527188930172};\\\", \\\"{x:1397,y:567,t:1527188930189};\\\", \\\"{x:1406,y:567,t:1527188930206};\\\", \\\"{x:1416,y:570,t:1527188930222};\\\", \\\"{x:1426,y:573,t:1527188930238};\\\", \\\"{x:1427,y:574,t:1527188930256};\\\", \\\"{x:1428,y:575,t:1527188930272};\\\", \\\"{x:1428,y:576,t:1527188930302};\\\", \\\"{x:1428,y:578,t:1527188930311};\\\", \\\"{x:1427,y:580,t:1527188930322};\\\", \\\"{x:1422,y:585,t:1527188930338};\\\", \\\"{x:1411,y:594,t:1527188930356};\\\", \\\"{x:1394,y:607,t:1527188930372};\\\", \\\"{x:1362,y:628,t:1527188930389};\\\", \\\"{x:1328,y:646,t:1527188930406};\\\", \\\"{x:1309,y:657,t:1527188930422};\\\", \\\"{x:1235,y:684,t:1527188930439};\\\", \\\"{x:1185,y:692,t:1527188930456};\\\", \\\"{x:1137,y:700,t:1527188930473};\\\", \\\"{x:1091,y:703,t:1527188930489};\\\", \\\"{x:1035,y:709,t:1527188930506};\\\", \\\"{x:985,y:709,t:1527188930522};\\\", \\\"{x:929,y:709,t:1527188930539};\\\", \\\"{x:861,y:698,t:1527188930556};\\\", \\\"{x:800,y:688,t:1527188930572};\\\", \\\"{x:778,y:682,t:1527188930589};\\\", \\\"{x:771,y:682,t:1527188930606};\\\", \\\"{x:764,y:678,t:1527188930622};\\\", \\\"{x:746,y:669,t:1527188930639};\\\", \\\"{x:731,y:660,t:1527188930655};\\\", \\\"{x:710,y:650,t:1527188930673};\\\", \\\"{x:697,y:640,t:1527188930689};\\\", \\\"{x:687,y:634,t:1527188930706};\\\", \\\"{x:680,y:630,t:1527188930724};\\\", \\\"{x:675,y:627,t:1527188930739};\\\", \\\"{x:664,y:626,t:1527188930755};\\\", \\\"{x:641,y:623,t:1527188930772};\\\", \\\"{x:618,y:623,t:1527188930788};\\\", \\\"{x:594,y:622,t:1527188930805};\\\", \\\"{x:574,y:622,t:1527188930822};\\\", \\\"{x:562,y:622,t:1527188930839};\\\", \\\"{x:550,y:622,t:1527188930856};\\\", \\\"{x:532,y:622,t:1527188930872};\\\", \\\"{x:504,y:617,t:1527188930889};\\\", \\\"{x:481,y:614,t:1527188930907};\\\", \\\"{x:458,y:609,t:1527188930922};\\\", \\\"{x:447,y:608,t:1527188930939};\\\", \\\"{x:434,y:603,t:1527188930956};\\\", \\\"{x:425,y:599,t:1527188930973};\\\", \\\"{x:419,y:597,t:1527188930989};\\\", \\\"{x:417,y:595,t:1527188931006};\\\", \\\"{x:416,y:595,t:1527188931031};\\\", \\\"{x:414,y:592,t:1527188931041};\\\", \\\"{x:407,y:590,t:1527188931056};\\\", \\\"{x:394,y:587,t:1527188931073};\\\", \\\"{x:379,y:585,t:1527188931089};\\\", \\\"{x:356,y:585,t:1527188931107};\\\", \\\"{x:334,y:585,t:1527188931122};\\\", \\\"{x:315,y:585,t:1527188931140};\\\", \\\"{x:289,y:585,t:1527188931156};\\\", \\\"{x:262,y:585,t:1527188931173};\\\", \\\"{x:248,y:584,t:1527188931189};\\\", \\\"{x:230,y:582,t:1527188931207};\\\", \\\"{x:224,y:580,t:1527188931222};\\\", \\\"{x:223,y:580,t:1527188931239};\\\", \\\"{x:221,y:580,t:1527188931257};\\\", \\\"{x:219,y:581,t:1527188931273};\\\", \\\"{x:218,y:581,t:1527188931289};\\\", \\\"{x:217,y:582,t:1527188931306};\\\", \\\"{x:215,y:584,t:1527188931324};\\\", \\\"{x:214,y:586,t:1527188931351};\\\", \\\"{x:213,y:586,t:1527188931367};\\\", \\\"{x:210,y:589,t:1527188931375};\\\", \\\"{x:207,y:593,t:1527188931390};\\\", \\\"{x:197,y:610,t:1527188931409};\\\", \\\"{x:192,y:615,t:1527188931423};\\\", \\\"{x:189,y:618,t:1527188931439};\\\", \\\"{x:188,y:619,t:1527188931456};\\\", \\\"{x:187,y:620,t:1527188931473};\\\", \\\"{x:187,y:623,t:1527188931489};\\\", \\\"{x:186,y:626,t:1527188931506};\\\", \\\"{x:185,y:630,t:1527188931524};\\\", \\\"{x:184,y:634,t:1527188931540};\\\", \\\"{x:184,y:635,t:1527188931623};\\\", \\\"{x:193,y:635,t:1527188931640};\\\", \\\"{x:222,y:631,t:1527188931657};\\\", \\\"{x:286,y:622,t:1527188931673};\\\", \\\"{x:362,y:619,t:1527188931689};\\\", \\\"{x:443,y:617,t:1527188931706};\\\", \\\"{x:513,y:615,t:1527188931724};\\\", \\\"{x:577,y:615,t:1527188931740};\\\", \\\"{x:613,y:615,t:1527188931756};\\\", \\\"{x:631,y:612,t:1527188931773};\\\", \\\"{x:640,y:612,t:1527188931789};\\\", \\\"{x:645,y:609,t:1527188931807};\\\", \\\"{x:646,y:608,t:1527188931823};\\\", \\\"{x:646,y:604,t:1527188931839};\\\", \\\"{x:646,y:597,t:1527188931857};\\\", \\\"{x:646,y:588,t:1527188931874};\\\", \\\"{x:646,y:583,t:1527188931891};\\\", \\\"{x:646,y:579,t:1527188931906};\\\", \\\"{x:646,y:572,t:1527188931923};\\\", \\\"{x:645,y:565,t:1527188931940};\\\", \\\"{x:633,y:550,t:1527188931958};\\\", \\\"{x:618,y:537,t:1527188931974};\\\", \\\"{x:604,y:526,t:1527188931991};\\\", \\\"{x:604,y:516,t:1527188932007};\\\", \\\"{x:604,y:509,t:1527188932024};\\\", \\\"{x:604,y:501,t:1527188932041};\\\", \\\"{x:605,y:496,t:1527188932057};\\\", \\\"{x:605,y:495,t:1527188932073};\\\", \\\"{x:607,y:494,t:1527188932606};\\\", \\\"{x:611,y:494,t:1527188932614};\\\", \\\"{x:619,y:494,t:1527188932624};\\\", \\\"{x:653,y:506,t:1527188932640};\\\", \\\"{x:688,y:519,t:1527188932658};\\\", \\\"{x:734,y:534,t:1527188932674};\\\", \\\"{x:772,y:543,t:1527188932690};\\\", \\\"{x:805,y:546,t:1527188932707};\\\", \\\"{x:827,y:546,t:1527188932725};\\\", \\\"{x:837,y:546,t:1527188932740};\\\", \\\"{x:838,y:546,t:1527188932757};\\\", \\\"{x:835,y:549,t:1527188933094};\\\", \\\"{x:827,y:556,t:1527188933107};\\\", \\\"{x:797,y:577,t:1527188933124};\\\", \\\"{x:759,y:597,t:1527188933141};\\\", \\\"{x:696,y:614,t:1527188933158};\\\", \\\"{x:631,y:627,t:1527188933173};\\\", \\\"{x:613,y:630,t:1527188933191};\\\", \\\"{x:603,y:633,t:1527188933208};\\\", \\\"{x:601,y:635,t:1527188933224};\\\", \\\"{x:600,y:644,t:1527188933242};\\\", \\\"{x:596,y:658,t:1527188933258};\\\", \\\"{x:592,y:672,t:1527188933275};\\\", \\\"{x:590,y:676,t:1527188933291};\\\", \\\"{x:588,y:679,t:1527188933308};\\\", \\\"{x:588,y:680,t:1527188933358};\\\", \\\"{x:588,y:682,t:1527188933376};\\\", \\\"{x:587,y:690,t:1527188933392};\\\", \\\"{x:586,y:693,t:1527188933409};\\\", \\\"{x:586,y:694,t:1527188933426};\\\", \\\"{x:586,y:695,t:1527188933442};\\\", \\\"{x:584,y:696,t:1527188933487};\\\", \\\"{x:579,y:702,t:1527188933494};\\\", \\\"{x:570,y:709,t:1527188933509};\\\", \\\"{x:549,y:727,t:1527188933527};\\\", \\\"{x:521,y:743,t:1527188933542};\\\", \\\"{x:514,y:743,t:1527188933558};\\\", \\\"{x:513,y:743,t:1527188933694};\\\", \\\"{x:513,y:742,t:1527188933708};\\\", \\\"{x:513,y:742,t:1527188933776};\\\" ] }, { \\\"rt\\\": 28594, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 348913, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -F -F -F -B -B -F -F -F -F -F -F -F -B -B -B -F -B -B -B -F -F -F -F -Z -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:742,t:1527188935458};\\\", \\\"{x:521,y:746,t:1527188935469};\\\", \\\"{x:522,y:746,t:1527188935476};\\\", \\\"{x:523,y:746,t:1527188935654};\\\", \\\"{x:525,y:748,t:1527188935662};\\\", \\\"{x:526,y:750,t:1527188935676};\\\", \\\"{x:531,y:750,t:1527188935693};\\\", \\\"{x:537,y:751,t:1527188935710};\\\", \\\"{x:544,y:752,t:1527188935726};\\\", \\\"{x:550,y:753,t:1527188935744};\\\", \\\"{x:560,y:755,t:1527188935760};\\\", \\\"{x:574,y:759,t:1527188935776};\\\", \\\"{x:592,y:761,t:1527188935794};\\\", \\\"{x:608,y:765,t:1527188935809};\\\", \\\"{x:623,y:767,t:1527188935827};\\\", \\\"{x:634,y:769,t:1527188935844};\\\", \\\"{x:643,y:770,t:1527188935859};\\\", \\\"{x:656,y:774,t:1527188935877};\\\", \\\"{x:669,y:776,t:1527188935894};\\\", \\\"{x:688,y:785,t:1527188935910};\\\", \\\"{x:719,y:801,t:1527188935927};\\\", \\\"{x:739,y:806,t:1527188935944};\\\", \\\"{x:746,y:808,t:1527188935961};\\\", \\\"{x:751,y:810,t:1527188935977};\\\", \\\"{x:754,y:810,t:1527188938535};\\\", \\\"{x:768,y:805,t:1527188938546};\\\", \\\"{x:824,y:796,t:1527188938562};\\\", \\\"{x:927,y:796,t:1527188938579};\\\", \\\"{x:1049,y:796,t:1527188938596};\\\", \\\"{x:1176,y:796,t:1527188938612};\\\", \\\"{x:1292,y:796,t:1527188938629};\\\", \\\"{x:1431,y:796,t:1527188938646};\\\", \\\"{x:1476,y:796,t:1527188938663};\\\", \\\"{x:1500,y:796,t:1527188938679};\\\", \\\"{x:1505,y:796,t:1527188938696};\\\", \\\"{x:1506,y:796,t:1527188938713};\\\", \\\"{x:1499,y:791,t:1527188939127};\\\", \\\"{x:1492,y:783,t:1527188939135};\\\", \\\"{x:1483,y:775,t:1527188939146};\\\", \\\"{x:1466,y:762,t:1527188939163};\\\", \\\"{x:1457,y:757,t:1527188939179};\\\", \\\"{x:1451,y:753,t:1527188939197};\\\", \\\"{x:1449,y:750,t:1527188939213};\\\", \\\"{x:1444,y:745,t:1527188939229};\\\", \\\"{x:1435,y:736,t:1527188939246};\\\", \\\"{x:1421,y:724,t:1527188939263};\\\", \\\"{x:1408,y:716,t:1527188939280};\\\", \\\"{x:1396,y:707,t:1527188939297};\\\", \\\"{x:1382,y:692,t:1527188939313};\\\", \\\"{x:1365,y:677,t:1527188939331};\\\", \\\"{x:1347,y:660,t:1527188939347};\\\", \\\"{x:1325,y:645,t:1527188939364};\\\", \\\"{x:1308,y:638,t:1527188939381};\\\", \\\"{x:1296,y:631,t:1527188939396};\\\", \\\"{x:1291,y:630,t:1527188939414};\\\", \\\"{x:1286,y:629,t:1527188939430};\\\", \\\"{x:1283,y:629,t:1527188939446};\\\", \\\"{x:1278,y:631,t:1527188939463};\\\", \\\"{x:1272,y:632,t:1527188939480};\\\", \\\"{x:1258,y:636,t:1527188939496};\\\", \\\"{x:1253,y:637,t:1527188939513};\\\", \\\"{x:1252,y:638,t:1527188939531};\\\", \\\"{x:1250,y:639,t:1527188939902};\\\", \\\"{x:1249,y:639,t:1527188939912};\\\", \\\"{x:1248,y:639,t:1527188939929};\\\", \\\"{x:1245,y:641,t:1527188939947};\\\", \\\"{x:1244,y:643,t:1527188939963};\\\", \\\"{x:1243,y:646,t:1527188939980};\\\", \\\"{x:1242,y:652,t:1527188939997};\\\", \\\"{x:1242,y:660,t:1527188940013};\\\", \\\"{x:1242,y:671,t:1527188940030};\\\", \\\"{x:1241,y:678,t:1527188940047};\\\", \\\"{x:1240,y:683,t:1527188940063};\\\", \\\"{x:1239,y:686,t:1527188940080};\\\", \\\"{x:1238,y:687,t:1527188940097};\\\", \\\"{x:1238,y:688,t:1527188940118};\\\", \\\"{x:1238,y:689,t:1527188940130};\\\", \\\"{x:1237,y:690,t:1527188940147};\\\", \\\"{x:1235,y:692,t:1527188940163};\\\", \\\"{x:1233,y:693,t:1527188940180};\\\", \\\"{x:1232,y:694,t:1527188940197};\\\", \\\"{x:1230,y:695,t:1527188940214};\\\", \\\"{x:1228,y:695,t:1527188940231};\\\", \\\"{x:1226,y:696,t:1527188940247};\\\", \\\"{x:1224,y:697,t:1527188940265};\\\", \\\"{x:1221,y:698,t:1527188940280};\\\", \\\"{x:1220,y:698,t:1527188940297};\\\", \\\"{x:1217,y:699,t:1527188940315};\\\", \\\"{x:1216,y:699,t:1527188940423};\\\", \\\"{x:1215,y:699,t:1527188940495};\\\", \\\"{x:1214,y:699,t:1527188940503};\\\", \\\"{x:1213,y:699,t:1527188940767};\\\", \\\"{x:1214,y:699,t:1527188940999};\\\", \\\"{x:1222,y:698,t:1527188941015};\\\", \\\"{x:1234,y:697,t:1527188941030};\\\", \\\"{x:1245,y:697,t:1527188941047};\\\", \\\"{x:1251,y:697,t:1527188941064};\\\", \\\"{x:1255,y:697,t:1527188941081};\\\", \\\"{x:1257,y:697,t:1527188941097};\\\", \\\"{x:1261,y:697,t:1527188941115};\\\", \\\"{x:1269,y:697,t:1527188941131};\\\", \\\"{x:1284,y:697,t:1527188941147};\\\", \\\"{x:1300,y:697,t:1527188941164};\\\", \\\"{x:1312,y:697,t:1527188941181};\\\", \\\"{x:1320,y:697,t:1527188941197};\\\", \\\"{x:1326,y:697,t:1527188941214};\\\", \\\"{x:1328,y:697,t:1527188941279};\\\", \\\"{x:1329,y:696,t:1527188941287};\\\", \\\"{x:1330,y:696,t:1527188941298};\\\", \\\"{x:1336,y:694,t:1527188941315};\\\", \\\"{x:1337,y:694,t:1527188941331};\\\", \\\"{x:1338,y:694,t:1527188941348};\\\", \\\"{x:1339,y:694,t:1527188941365};\\\", \\\"{x:1339,y:696,t:1527188941544};\\\", \\\"{x:1339,y:697,t:1527188941551};\\\", \\\"{x:1339,y:698,t:1527188941564};\\\", \\\"{x:1339,y:700,t:1527188941581};\\\", \\\"{x:1339,y:704,t:1527188941598};\\\", \\\"{x:1339,y:706,t:1527188941615};\\\", \\\"{x:1339,y:709,t:1527188941632};\\\", \\\"{x:1338,y:714,t:1527188941648};\\\", \\\"{x:1338,y:722,t:1527188941665};\\\", \\\"{x:1338,y:731,t:1527188941681};\\\", \\\"{x:1338,y:738,t:1527188941699};\\\", \\\"{x:1338,y:742,t:1527188941716};\\\", \\\"{x:1338,y:743,t:1527188941732};\\\", \\\"{x:1338,y:745,t:1527188941748};\\\", \\\"{x:1338,y:748,t:1527188941765};\\\", \\\"{x:1337,y:753,t:1527188941781};\\\", \\\"{x:1335,y:765,t:1527188941799};\\\", \\\"{x:1335,y:772,t:1527188941815};\\\", \\\"{x:1335,y:775,t:1527188941832};\\\", \\\"{x:1335,y:776,t:1527188941849};\\\", \\\"{x:1334,y:777,t:1527188941975};\\\", \\\"{x:1333,y:775,t:1527188941990};\\\", \\\"{x:1333,y:771,t:1527188941999};\\\", \\\"{x:1333,y:758,t:1527188942015};\\\", \\\"{x:1333,y:747,t:1527188942031};\\\", \\\"{x:1333,y:735,t:1527188942049};\\\", \\\"{x:1333,y:725,t:1527188942066};\\\", \\\"{x:1333,y:715,t:1527188942081};\\\", \\\"{x:1333,y:706,t:1527188942098};\\\", \\\"{x:1335,y:699,t:1527188942116};\\\", \\\"{x:1335,y:695,t:1527188942132};\\\", \\\"{x:1335,y:691,t:1527188942148};\\\", \\\"{x:1336,y:687,t:1527188942165};\\\", \\\"{x:1336,y:686,t:1527188942182};\\\", \\\"{x:1337,y:689,t:1527188942359};\\\", \\\"{x:1337,y:692,t:1527188942367};\\\", \\\"{x:1339,y:695,t:1527188942382};\\\", \\\"{x:1339,y:700,t:1527188942398};\\\", \\\"{x:1339,y:707,t:1527188942416};\\\", \\\"{x:1339,y:714,t:1527188942433};\\\", \\\"{x:1339,y:720,t:1527188942448};\\\", \\\"{x:1339,y:727,t:1527188942465};\\\", \\\"{x:1339,y:733,t:1527188942483};\\\", \\\"{x:1340,y:742,t:1527188942498};\\\", \\\"{x:1341,y:747,t:1527188942516};\\\", \\\"{x:1343,y:752,t:1527188942532};\\\", \\\"{x:1343,y:757,t:1527188942549};\\\", \\\"{x:1344,y:762,t:1527188942568};\\\", \\\"{x:1345,y:770,t:1527188942582};\\\", \\\"{x:1348,y:776,t:1527188942599};\\\", \\\"{x:1348,y:778,t:1527188942615};\\\", \\\"{x:1348,y:779,t:1527188942632};\\\", \\\"{x:1348,y:780,t:1527188942649};\\\", \\\"{x:1347,y:781,t:1527188942735};\\\", \\\"{x:1346,y:775,t:1527188942750};\\\", \\\"{x:1344,y:769,t:1527188942764};\\\", \\\"{x:1344,y:750,t:1527188942782};\\\", \\\"{x:1345,y:739,t:1527188942799};\\\", \\\"{x:1346,y:728,t:1527188942815};\\\", \\\"{x:1348,y:719,t:1527188942832};\\\", \\\"{x:1348,y:714,t:1527188942849};\\\", \\\"{x:1348,y:709,t:1527188942865};\\\", \\\"{x:1348,y:706,t:1527188942882};\\\", \\\"{x:1348,y:702,t:1527188942900};\\\", \\\"{x:1348,y:698,t:1527188942915};\\\", \\\"{x:1348,y:694,t:1527188942932};\\\", \\\"{x:1347,y:691,t:1527188942949};\\\", \\\"{x:1347,y:689,t:1527188942965};\\\", \\\"{x:1347,y:686,t:1527188942983};\\\", \\\"{x:1345,y:685,t:1527188942999};\\\", \\\"{x:1345,y:688,t:1527188943167};\\\", \\\"{x:1343,y:697,t:1527188943183};\\\", \\\"{x:1343,y:704,t:1527188943200};\\\", \\\"{x:1343,y:710,t:1527188943217};\\\", \\\"{x:1343,y:719,t:1527188943232};\\\", \\\"{x:1344,y:724,t:1527188943250};\\\", \\\"{x:1345,y:730,t:1527188943266};\\\", \\\"{x:1346,y:738,t:1527188943283};\\\", \\\"{x:1348,y:745,t:1527188943300};\\\", \\\"{x:1351,y:753,t:1527188943316};\\\", \\\"{x:1352,y:760,t:1527188943333};\\\", \\\"{x:1356,y:768,t:1527188943351};\\\", \\\"{x:1360,y:780,t:1527188943367};\\\", \\\"{x:1364,y:788,t:1527188943382};\\\", \\\"{x:1366,y:795,t:1527188943400};\\\", \\\"{x:1368,y:800,t:1527188943416};\\\", \\\"{x:1368,y:804,t:1527188943432};\\\", \\\"{x:1368,y:806,t:1527188943450};\\\", \\\"{x:1368,y:807,t:1527188943466};\\\", \\\"{x:1367,y:807,t:1527188943575};\\\", \\\"{x:1367,y:805,t:1527188943582};\\\", \\\"{x:1365,y:789,t:1527188943599};\\\", \\\"{x:1359,y:772,t:1527188943616};\\\", \\\"{x:1355,y:758,t:1527188943634};\\\", \\\"{x:1352,y:746,t:1527188943650};\\\", \\\"{x:1351,y:739,t:1527188943666};\\\", \\\"{x:1351,y:734,t:1527188943683};\\\", \\\"{x:1351,y:729,t:1527188943699};\\\", \\\"{x:1351,y:724,t:1527188943716};\\\", \\\"{x:1351,y:718,t:1527188943733};\\\", \\\"{x:1350,y:710,t:1527188943749};\\\", \\\"{x:1348,y:703,t:1527188943767};\\\", \\\"{x:1348,y:697,t:1527188943783};\\\", \\\"{x:1348,y:693,t:1527188943799};\\\", \\\"{x:1348,y:690,t:1527188943817};\\\", \\\"{x:1348,y:686,t:1527188943833};\\\", \\\"{x:1348,y:683,t:1527188943849};\\\", \\\"{x:1347,y:679,t:1527188943867};\\\", \\\"{x:1347,y:676,t:1527188943884};\\\", \\\"{x:1346,y:674,t:1527188943911};\\\", \\\"{x:1344,y:674,t:1527188944055};\\\", \\\"{x:1344,y:675,t:1527188944067};\\\", \\\"{x:1343,y:680,t:1527188944084};\\\", \\\"{x:1339,y:687,t:1527188944100};\\\", \\\"{x:1339,y:692,t:1527188944116};\\\", \\\"{x:1338,y:698,t:1527188944134};\\\", \\\"{x:1338,y:704,t:1527188944150};\\\", \\\"{x:1338,y:707,t:1527188944166};\\\", \\\"{x:1338,y:713,t:1527188944184};\\\", \\\"{x:1338,y:717,t:1527188944201};\\\", \\\"{x:1338,y:724,t:1527188944217};\\\", \\\"{x:1338,y:728,t:1527188944233};\\\", \\\"{x:1338,y:733,t:1527188944250};\\\", \\\"{x:1338,y:735,t:1527188944266};\\\", \\\"{x:1338,y:736,t:1527188944283};\\\", \\\"{x:1338,y:738,t:1527188944326};\\\", \\\"{x:1339,y:738,t:1527188944407};\\\", \\\"{x:1340,y:735,t:1527188944417};\\\", \\\"{x:1341,y:729,t:1527188944434};\\\", \\\"{x:1343,y:723,t:1527188944450};\\\", \\\"{x:1344,y:718,t:1527188944467};\\\", \\\"{x:1344,y:713,t:1527188944484};\\\", \\\"{x:1345,y:710,t:1527188944500};\\\", \\\"{x:1347,y:705,t:1527188944518};\\\", \\\"{x:1348,y:703,t:1527188944534};\\\", \\\"{x:1349,y:697,t:1527188944551};\\\", \\\"{x:1349,y:694,t:1527188944566};\\\", \\\"{x:1349,y:692,t:1527188944583};\\\", \\\"{x:1350,y:692,t:1527188945023};\\\", \\\"{x:1351,y:692,t:1527188945035};\\\", \\\"{x:1351,y:693,t:1527188945050};\\\", \\\"{x:1351,y:694,t:1527188945067};\\\", \\\"{x:1351,y:695,t:1527188945094};\\\", \\\"{x:1351,y:696,t:1527188945102};\\\", \\\"{x:1351,y:697,t:1527188945119};\\\", \\\"{x:1351,y:698,t:1527188945134};\\\", \\\"{x:1351,y:700,t:1527188945150};\\\", \\\"{x:1351,y:703,t:1527188945168};\\\", \\\"{x:1351,y:704,t:1527188945184};\\\", \\\"{x:1351,y:707,t:1527188945201};\\\", \\\"{x:1351,y:708,t:1527188945217};\\\", \\\"{x:1351,y:709,t:1527188945235};\\\", \\\"{x:1350,y:704,t:1527188945335};\\\", \\\"{x:1348,y:698,t:1527188945350};\\\", \\\"{x:1346,y:693,t:1527188945367};\\\", \\\"{x:1345,y:691,t:1527188945385};\\\", \\\"{x:1345,y:690,t:1527188945400};\\\", \\\"{x:1345,y:691,t:1527188946103};\\\", \\\"{x:1345,y:694,t:1527188946119};\\\", \\\"{x:1345,y:696,t:1527188946134};\\\", \\\"{x:1345,y:697,t:1527188946152};\\\", \\\"{x:1346,y:697,t:1527188946215};\\\", \\\"{x:1346,y:699,t:1527188946223};\\\", \\\"{x:1346,y:701,t:1527188946234};\\\", \\\"{x:1346,y:703,t:1527188946252};\\\", \\\"{x:1346,y:704,t:1527188946269};\\\", \\\"{x:1347,y:705,t:1527188946285};\\\", \\\"{x:1347,y:706,t:1527188946302};\\\", \\\"{x:1347,y:707,t:1527188946318};\\\", \\\"{x:1347,y:708,t:1527188946334};\\\", \\\"{x:1347,y:709,t:1527188946352};\\\", \\\"{x:1347,y:710,t:1527188946369};\\\", \\\"{x:1347,y:712,t:1527188946386};\\\", \\\"{x:1349,y:713,t:1527188946401};\\\", \\\"{x:1349,y:716,t:1527188946419};\\\", \\\"{x:1349,y:717,t:1527188946435};\\\", \\\"{x:1349,y:718,t:1527188946452};\\\", \\\"{x:1349,y:719,t:1527188946468};\\\", \\\"{x:1349,y:721,t:1527188946486};\\\", \\\"{x:1349,y:723,t:1527188946502};\\\", \\\"{x:1349,y:729,t:1527188946519};\\\", \\\"{x:1349,y:731,t:1527188946534};\\\", \\\"{x:1349,y:732,t:1527188946551};\\\", \\\"{x:1349,y:733,t:1527188946569};\\\", \\\"{x:1349,y:735,t:1527188946585};\\\", \\\"{x:1349,y:737,t:1527188946601};\\\", \\\"{x:1349,y:739,t:1527188946619};\\\", \\\"{x:1349,y:742,t:1527188946635};\\\", \\\"{x:1349,y:744,t:1527188946651};\\\", \\\"{x:1349,y:745,t:1527188946668};\\\", \\\"{x:1349,y:747,t:1527188946686};\\\", \\\"{x:1349,y:748,t:1527188946702};\\\", \\\"{x:1349,y:751,t:1527188946718};\\\", \\\"{x:1349,y:753,t:1527188946736};\\\", \\\"{x:1349,y:754,t:1527188946751};\\\", \\\"{x:1349,y:756,t:1527188946768};\\\", \\\"{x:1349,y:758,t:1527188946786};\\\", \\\"{x:1349,y:760,t:1527188946801};\\\", \\\"{x:1349,y:761,t:1527188946818};\\\", \\\"{x:1349,y:760,t:1527188947038};\\\", \\\"{x:1349,y:758,t:1527188947052};\\\", \\\"{x:1349,y:754,t:1527188947069};\\\", \\\"{x:1349,y:749,t:1527188947085};\\\", \\\"{x:1349,y:741,t:1527188947102};\\\", \\\"{x:1349,y:735,t:1527188947118};\\\", \\\"{x:1350,y:728,t:1527188947135};\\\", \\\"{x:1351,y:720,t:1527188947152};\\\", \\\"{x:1353,y:715,t:1527188947168};\\\", \\\"{x:1353,y:710,t:1527188947186};\\\", \\\"{x:1353,y:708,t:1527188947202};\\\", \\\"{x:1353,y:704,t:1527188947219};\\\", \\\"{x:1354,y:701,t:1527188947236};\\\", \\\"{x:1355,y:697,t:1527188947252};\\\", \\\"{x:1355,y:694,t:1527188947268};\\\", \\\"{x:1355,y:690,t:1527188947286};\\\", \\\"{x:1355,y:685,t:1527188947302};\\\", \\\"{x:1355,y:683,t:1527188947318};\\\", \\\"{x:1355,y:680,t:1527188947335};\\\", \\\"{x:1353,y:680,t:1527188947559};\\\", \\\"{x:1352,y:683,t:1527188947569};\\\", \\\"{x:1348,y:694,t:1527188947586};\\\", \\\"{x:1347,y:703,t:1527188947604};\\\", \\\"{x:1345,y:709,t:1527188947620};\\\", \\\"{x:1345,y:714,t:1527188947636};\\\", \\\"{x:1345,y:718,t:1527188947652};\\\", \\\"{x:1345,y:722,t:1527188947670};\\\", \\\"{x:1345,y:728,t:1527188947685};\\\", \\\"{x:1345,y:733,t:1527188947703};\\\", \\\"{x:1344,y:739,t:1527188947719};\\\", \\\"{x:1344,y:744,t:1527188947736};\\\", \\\"{x:1344,y:748,t:1527188947753};\\\", \\\"{x:1344,y:752,t:1527188947770};\\\", \\\"{x:1344,y:757,t:1527188947786};\\\", \\\"{x:1344,y:761,t:1527188947803};\\\", \\\"{x:1344,y:766,t:1527188947820};\\\", \\\"{x:1345,y:770,t:1527188947838};\\\", \\\"{x:1345,y:771,t:1527188947852};\\\", \\\"{x:1345,y:773,t:1527188947869};\\\", \\\"{x:1345,y:775,t:1527188947887};\\\", \\\"{x:1345,y:776,t:1527188947903};\\\", \\\"{x:1344,y:774,t:1527188948014};\\\", \\\"{x:1344,y:772,t:1527188948023};\\\", \\\"{x:1344,y:768,t:1527188948037};\\\", \\\"{x:1344,y:758,t:1527188948053};\\\", \\\"{x:1344,y:749,t:1527188948069};\\\", \\\"{x:1344,y:738,t:1527188948087};\\\", \\\"{x:1344,y:731,t:1527188948102};\\\", \\\"{x:1344,y:725,t:1527188948119};\\\", \\\"{x:1345,y:718,t:1527188948137};\\\", \\\"{x:1345,y:713,t:1527188948152};\\\", \\\"{x:1345,y:706,t:1527188948169};\\\", \\\"{x:1345,y:701,t:1527188948188};\\\", \\\"{x:1345,y:699,t:1527188948202};\\\", \\\"{x:1345,y:698,t:1527188948223};\\\", \\\"{x:1345,y:697,t:1527188948238};\\\", \\\"{x:1345,y:696,t:1527188948252};\\\", \\\"{x:1345,y:694,t:1527188948270};\\\", \\\"{x:1345,y:690,t:1527188948288};\\\", \\\"{x:1345,y:686,t:1527188948302};\\\", \\\"{x:1344,y:682,t:1527188948319};\\\", \\\"{x:1343,y:680,t:1527188948336};\\\", \\\"{x:1342,y:678,t:1527188948354};\\\", \\\"{x:1342,y:675,t:1527188948369};\\\", \\\"{x:1342,y:672,t:1527188948386};\\\", \\\"{x:1342,y:664,t:1527188948403};\\\", \\\"{x:1341,y:657,t:1527188948418};\\\", \\\"{x:1340,y:648,t:1527188948436};\\\", \\\"{x:1339,y:644,t:1527188948453};\\\", \\\"{x:1339,y:643,t:1527188948469};\\\", \\\"{x:1338,y:641,t:1527188948486};\\\", \\\"{x:1338,y:640,t:1527188948509};\\\", \\\"{x:1337,y:640,t:1527188948519};\\\", \\\"{x:1335,y:638,t:1527188948536};\\\", \\\"{x:1332,y:637,t:1527188948553};\\\", \\\"{x:1323,y:636,t:1527188948569};\\\", \\\"{x:1314,y:634,t:1527188948586};\\\", \\\"{x:1305,y:633,t:1527188948603};\\\", \\\"{x:1298,y:631,t:1527188948619};\\\", \\\"{x:1289,y:629,t:1527188948635};\\\", \\\"{x:1282,y:629,t:1527188948653};\\\", \\\"{x:1275,y:629,t:1527188948669};\\\", \\\"{x:1272,y:629,t:1527188948686};\\\", \\\"{x:1270,y:629,t:1527188948702};\\\", \\\"{x:1269,y:629,t:1527188948720};\\\", \\\"{x:1266,y:629,t:1527188948736};\\\", \\\"{x:1263,y:630,t:1527188948753};\\\", \\\"{x:1261,y:630,t:1527188948770};\\\", \\\"{x:1260,y:630,t:1527188948786};\\\", \\\"{x:1259,y:630,t:1527188948806};\\\", \\\"{x:1258,y:630,t:1527188948845};\\\", \\\"{x:1257,y:630,t:1527188948861};\\\", \\\"{x:1256,y:630,t:1527188948869};\\\", \\\"{x:1254,y:630,t:1527188948886};\\\", \\\"{x:1250,y:630,t:1527188948903};\\\", \\\"{x:1246,y:630,t:1527188948919};\\\", \\\"{x:1245,y:630,t:1527188948936};\\\", \\\"{x:1244,y:630,t:1527188948953};\\\", \\\"{x:1243,y:630,t:1527188948970};\\\", \\\"{x:1242,y:630,t:1527188949071};\\\", \\\"{x:1241,y:632,t:1527188949087};\\\", \\\"{x:1241,y:633,t:1527188949104};\\\", \\\"{x:1241,y:634,t:1527188949142};\\\", \\\"{x:1241,y:635,t:1527188949166};\\\", \\\"{x:1241,y:636,t:1527188949183};\\\", \\\"{x:1241,y:637,t:1527188949190};\\\", \\\"{x:1241,y:638,t:1527188949203};\\\", \\\"{x:1241,y:639,t:1527188949247};\\\", \\\"{x:1241,y:640,t:1527188949262};\\\", \\\"{x:1241,y:641,t:1527188949271};\\\", \\\"{x:1241,y:642,t:1527188949287};\\\", \\\"{x:1242,y:643,t:1527188949303};\\\", \\\"{x:1244,y:643,t:1527188949320};\\\", \\\"{x:1248,y:643,t:1527188949337};\\\", \\\"{x:1250,y:644,t:1527188949353};\\\", \\\"{x:1252,y:645,t:1527188949370};\\\", \\\"{x:1257,y:646,t:1527188949387};\\\", \\\"{x:1261,y:648,t:1527188949402};\\\", \\\"{x:1271,y:649,t:1527188949420};\\\", \\\"{x:1280,y:650,t:1527188949437};\\\", \\\"{x:1291,y:652,t:1527188949453};\\\", \\\"{x:1299,y:652,t:1527188949470};\\\", \\\"{x:1307,y:653,t:1527188949487};\\\", \\\"{x:1312,y:654,t:1527188949503};\\\", \\\"{x:1319,y:654,t:1527188949520};\\\", \\\"{x:1325,y:654,t:1527188949537};\\\", \\\"{x:1335,y:654,t:1527188949554};\\\", \\\"{x:1341,y:654,t:1527188949570};\\\", \\\"{x:1350,y:654,t:1527188949588};\\\", \\\"{x:1356,y:654,t:1527188949603};\\\", \\\"{x:1359,y:654,t:1527188949620};\\\", \\\"{x:1363,y:654,t:1527188949638};\\\", \\\"{x:1365,y:654,t:1527188949654};\\\", \\\"{x:1367,y:654,t:1527188949671};\\\", \\\"{x:1370,y:654,t:1527188949687};\\\", \\\"{x:1376,y:654,t:1527188949704};\\\", \\\"{x:1381,y:654,t:1527188949720};\\\", \\\"{x:1385,y:654,t:1527188949737};\\\", \\\"{x:1389,y:654,t:1527188949754};\\\", \\\"{x:1392,y:656,t:1527188949770};\\\", \\\"{x:1393,y:656,t:1527188949798};\\\", \\\"{x:1394,y:656,t:1527188949822};\\\", \\\"{x:1395,y:656,t:1527188949839};\\\", \\\"{x:1397,y:656,t:1527188949862};\\\", \\\"{x:1398,y:656,t:1527188949871};\\\", \\\"{x:1400,y:656,t:1527188949888};\\\", \\\"{x:1402,y:656,t:1527188949905};\\\", \\\"{x:1405,y:656,t:1527188949921};\\\", \\\"{x:1412,y:655,t:1527188949938};\\\", \\\"{x:1417,y:653,t:1527188949954};\\\", \\\"{x:1421,y:652,t:1527188949970};\\\", \\\"{x:1423,y:652,t:1527188949988};\\\", \\\"{x:1425,y:652,t:1527188950005};\\\", \\\"{x:1426,y:652,t:1527188950021};\\\", \\\"{x:1429,y:652,t:1527188950038};\\\", \\\"{x:1436,y:652,t:1527188950054};\\\", \\\"{x:1441,y:652,t:1527188950071};\\\", \\\"{x:1447,y:652,t:1527188950088};\\\", \\\"{x:1451,y:652,t:1527188950105};\\\", \\\"{x:1454,y:652,t:1527188950121};\\\", \\\"{x:1456,y:652,t:1527188950138};\\\", \\\"{x:1459,y:653,t:1527188950175};\\\", \\\"{x:1460,y:653,t:1527188950189};\\\", \\\"{x:1466,y:654,t:1527188950204};\\\", \\\"{x:1469,y:654,t:1527188950221};\\\", \\\"{x:1471,y:654,t:1527188950238};\\\", \\\"{x:1472,y:654,t:1527188950255};\\\", \\\"{x:1474,y:654,t:1527188950295};\\\", \\\"{x:1475,y:654,t:1527188950304};\\\", \\\"{x:1477,y:654,t:1527188950322};\\\", \\\"{x:1480,y:654,t:1527188950338};\\\", \\\"{x:1483,y:654,t:1527188950354};\\\", \\\"{x:1484,y:654,t:1527188950766};\\\", \\\"{x:1483,y:654,t:1527188950774};\\\", \\\"{x:1480,y:654,t:1527188950789};\\\", \\\"{x:1472,y:654,t:1527188950804};\\\", \\\"{x:1462,y:653,t:1527188950822};\\\", \\\"{x:1441,y:649,t:1527188950839};\\\", \\\"{x:1427,y:647,t:1527188950855};\\\", \\\"{x:1415,y:644,t:1527188950872};\\\", \\\"{x:1402,y:643,t:1527188950888};\\\", \\\"{x:1394,y:642,t:1527188950904};\\\", \\\"{x:1385,y:641,t:1527188950921};\\\", \\\"{x:1381,y:639,t:1527188950939};\\\", \\\"{x:1372,y:639,t:1527188950954};\\\", \\\"{x:1362,y:639,t:1527188950972};\\\", \\\"{x:1347,y:639,t:1527188950988};\\\", \\\"{x:1329,y:638,t:1527188951005};\\\", \\\"{x:1316,y:635,t:1527188951022};\\\", \\\"{x:1309,y:634,t:1527188951039};\\\", \\\"{x:1306,y:633,t:1527188951056};\\\", \\\"{x:1305,y:633,t:1527188951111};\\\", \\\"{x:1302,y:633,t:1527188951121};\\\", \\\"{x:1299,y:633,t:1527188951142};\\\", \\\"{x:1297,y:633,t:1527188951158};\\\", \\\"{x:1295,y:633,t:1527188951172};\\\", \\\"{x:1291,y:632,t:1527188951188};\\\", \\\"{x:1288,y:632,t:1527188951206};\\\", \\\"{x:1282,y:631,t:1527188951222};\\\", \\\"{x:1277,y:631,t:1527188951238};\\\", \\\"{x:1273,y:630,t:1527188951255};\\\", \\\"{x:1270,y:630,t:1527188951272};\\\", \\\"{x:1267,y:630,t:1527188951288};\\\", \\\"{x:1265,y:630,t:1527188951306};\\\", \\\"{x:1265,y:629,t:1527188951343};\\\", \\\"{x:1266,y:629,t:1527188951503};\\\", \\\"{x:1268,y:628,t:1527188951510};\\\", \\\"{x:1268,y:627,t:1527188951522};\\\", \\\"{x:1270,y:627,t:1527188951543};\\\", \\\"{x:1271,y:627,t:1527188951555};\\\", \\\"{x:1273,y:627,t:1527188951571};\\\", \\\"{x:1274,y:627,t:1527188951598};\\\", \\\"{x:1276,y:627,t:1527188951614};\\\", \\\"{x:1277,y:627,t:1527188951622};\\\", \\\"{x:1280,y:627,t:1527188951639};\\\", \\\"{x:1284,y:627,t:1527188951656};\\\", \\\"{x:1288,y:628,t:1527188951673};\\\", \\\"{x:1291,y:628,t:1527188951689};\\\", \\\"{x:1294,y:628,t:1527188951705};\\\", \\\"{x:1295,y:628,t:1527188951723};\\\", \\\"{x:1297,y:628,t:1527188951739};\\\", \\\"{x:1298,y:628,t:1527188952814};\\\", \\\"{x:1300,y:628,t:1527188952822};\\\", \\\"{x:1307,y:631,t:1527188952840};\\\", \\\"{x:1314,y:635,t:1527188952857};\\\", \\\"{x:1327,y:642,t:1527188952872};\\\", \\\"{x:1338,y:647,t:1527188952890};\\\", \\\"{x:1343,y:650,t:1527188952907};\\\", \\\"{x:1344,y:650,t:1527188952923};\\\", \\\"{x:1344,y:652,t:1527188952950};\\\", \\\"{x:1344,y:655,t:1527188952966};\\\", \\\"{x:1344,y:657,t:1527188952975};\\\", \\\"{x:1344,y:661,t:1527188952990};\\\", \\\"{x:1346,y:671,t:1527188953007};\\\", \\\"{x:1346,y:675,t:1527188953024};\\\", \\\"{x:1346,y:676,t:1527188953040};\\\", \\\"{x:1347,y:679,t:1527188953056};\\\", \\\"{x:1347,y:682,t:1527188953074};\\\", \\\"{x:1347,y:684,t:1527188953090};\\\", \\\"{x:1345,y:686,t:1527188953106};\\\", \\\"{x:1342,y:690,t:1527188953124};\\\", \\\"{x:1339,y:693,t:1527188953140};\\\", \\\"{x:1337,y:694,t:1527188953157};\\\", \\\"{x:1336,y:695,t:1527188953174};\\\", \\\"{x:1334,y:697,t:1527188953190};\\\", \\\"{x:1328,y:699,t:1527188953206};\\\", \\\"{x:1324,y:700,t:1527188953224};\\\", \\\"{x:1321,y:701,t:1527188953239};\\\", \\\"{x:1318,y:701,t:1527188953257};\\\", \\\"{x:1313,y:702,t:1527188953274};\\\", \\\"{x:1309,y:703,t:1527188953289};\\\", \\\"{x:1303,y:703,t:1527188953307};\\\", \\\"{x:1294,y:704,t:1527188953324};\\\", \\\"{x:1285,y:704,t:1527188953340};\\\", \\\"{x:1277,y:704,t:1527188953357};\\\", \\\"{x:1269,y:704,t:1527188953374};\\\", \\\"{x:1264,y:704,t:1527188953389};\\\", \\\"{x:1251,y:704,t:1527188953406};\\\", \\\"{x:1245,y:703,t:1527188953424};\\\", \\\"{x:1239,y:702,t:1527188953439};\\\", \\\"{x:1237,y:702,t:1527188953457};\\\", \\\"{x:1236,y:702,t:1527188953473};\\\", \\\"{x:1234,y:702,t:1527188953558};\\\", \\\"{x:1232,y:702,t:1527188953572};\\\", \\\"{x:1222,y:702,t:1527188953589};\\\", \\\"{x:1214,y:701,t:1527188953606};\\\", \\\"{x:1205,y:699,t:1527188953623};\\\", \\\"{x:1201,y:698,t:1527188953640};\\\", \\\"{x:1200,y:698,t:1527188953656};\\\", \\\"{x:1199,y:698,t:1527188953726};\\\", \\\"{x:1197,y:698,t:1527188953741};\\\", \\\"{x:1197,y:696,t:1527188953823};\\\", \\\"{x:1200,y:695,t:1527188953841};\\\", \\\"{x:1204,y:693,t:1527188953857};\\\", \\\"{x:1213,y:691,t:1527188953874};\\\", \\\"{x:1223,y:690,t:1527188953891};\\\", \\\"{x:1236,y:690,t:1527188953907};\\\", \\\"{x:1247,y:690,t:1527188953924};\\\", \\\"{x:1261,y:690,t:1527188953941};\\\", \\\"{x:1268,y:690,t:1527188953957};\\\", \\\"{x:1273,y:690,t:1527188953974};\\\", \\\"{x:1281,y:690,t:1527188953990};\\\", \\\"{x:1287,y:690,t:1527188954007};\\\", \\\"{x:1292,y:690,t:1527188954023};\\\", \\\"{x:1299,y:690,t:1527188954040};\\\", \\\"{x:1310,y:690,t:1527188954058};\\\", \\\"{x:1327,y:693,t:1527188954073};\\\", \\\"{x:1349,y:696,t:1527188954091};\\\", \\\"{x:1368,y:696,t:1527188954108};\\\", \\\"{x:1388,y:696,t:1527188954124};\\\", \\\"{x:1404,y:696,t:1527188954141};\\\", \\\"{x:1415,y:696,t:1527188954158};\\\", \\\"{x:1428,y:696,t:1527188954174};\\\", \\\"{x:1448,y:696,t:1527188954190};\\\", \\\"{x:1459,y:696,t:1527188954207};\\\", \\\"{x:1465,y:697,t:1527188954224};\\\", \\\"{x:1473,y:697,t:1527188954241};\\\", \\\"{x:1484,y:698,t:1527188954258};\\\", \\\"{x:1499,y:698,t:1527188954274};\\\", \\\"{x:1511,y:698,t:1527188954290};\\\", \\\"{x:1516,y:698,t:1527188954308};\\\", \\\"{x:1523,y:698,t:1527188954324};\\\", \\\"{x:1527,y:698,t:1527188954341};\\\", \\\"{x:1528,y:698,t:1527188954358};\\\", \\\"{x:1530,y:698,t:1527188954373};\\\", \\\"{x:1542,y:698,t:1527188954391};\\\", \\\"{x:1559,y:698,t:1527188954407};\\\", \\\"{x:1570,y:698,t:1527188954424};\\\", \\\"{x:1576,y:698,t:1527188954441};\\\", \\\"{x:1579,y:698,t:1527188954458};\\\", \\\"{x:1580,y:697,t:1527188954475};\\\", \\\"{x:1582,y:697,t:1527188954494};\\\", \\\"{x:1585,y:697,t:1527188954511};\\\", \\\"{x:1586,y:697,t:1527188954525};\\\", \\\"{x:1595,y:697,t:1527188954541};\\\", \\\"{x:1603,y:697,t:1527188954558};\\\", \\\"{x:1605,y:697,t:1527188954575};\\\", \\\"{x:1606,y:697,t:1527188954590};\\\", \\\"{x:1608,y:697,t:1527188954775};\\\", \\\"{x:1612,y:697,t:1527188954791};\\\", \\\"{x:1616,y:695,t:1527188954807};\\\", \\\"{x:1620,y:694,t:1527188954824};\\\", \\\"{x:1621,y:694,t:1527188954841};\\\", \\\"{x:1622,y:694,t:1527188954861};\\\", \\\"{x:1624,y:694,t:1527188954893};\\\", \\\"{x:1625,y:695,t:1527188954907};\\\", \\\"{x:1626,y:696,t:1527188954924};\\\", \\\"{x:1628,y:699,t:1527188954940};\\\", \\\"{x:1631,y:703,t:1527188954957};\\\", \\\"{x:1635,y:710,t:1527188954974};\\\", \\\"{x:1639,y:716,t:1527188954991};\\\", \\\"{x:1642,y:720,t:1527188955008};\\\", \\\"{x:1647,y:729,t:1527188955024};\\\", \\\"{x:1652,y:742,t:1527188955042};\\\", \\\"{x:1657,y:755,t:1527188955058};\\\", \\\"{x:1667,y:771,t:1527188955074};\\\", \\\"{x:1675,y:785,t:1527188955091};\\\", \\\"{x:1682,y:796,t:1527188955108};\\\", \\\"{x:1686,y:801,t:1527188955124};\\\", \\\"{x:1692,y:811,t:1527188955142};\\\", \\\"{x:1696,y:823,t:1527188955157};\\\", \\\"{x:1700,y:839,t:1527188955175};\\\", \\\"{x:1702,y:850,t:1527188955192};\\\", \\\"{x:1703,y:857,t:1527188955207};\\\", \\\"{x:1705,y:866,t:1527188955225};\\\", \\\"{x:1706,y:874,t:1527188955241};\\\", \\\"{x:1706,y:883,t:1527188955257};\\\", \\\"{x:1707,y:891,t:1527188955274};\\\", \\\"{x:1706,y:899,t:1527188955292};\\\", \\\"{x:1705,y:902,t:1527188955308};\\\", \\\"{x:1705,y:903,t:1527188955327};\\\", \\\"{x:1701,y:901,t:1527188955398};\\\", \\\"{x:1694,y:892,t:1527188955408};\\\", \\\"{x:1680,y:876,t:1527188955424};\\\", \\\"{x:1664,y:856,t:1527188955442};\\\", \\\"{x:1640,y:826,t:1527188955459};\\\", \\\"{x:1602,y:782,t:1527188955475};\\\", \\\"{x:1572,y:744,t:1527188955492};\\\", \\\"{x:1554,y:725,t:1527188955509};\\\", \\\"{x:1545,y:716,t:1527188955525};\\\", \\\"{x:1537,y:710,t:1527188955542};\\\", \\\"{x:1534,y:709,t:1527188955558};\\\", \\\"{x:1531,y:711,t:1527188955615};\\\", \\\"{x:1526,y:718,t:1527188955625};\\\", \\\"{x:1515,y:730,t:1527188955642};\\\", \\\"{x:1505,y:742,t:1527188955658};\\\", \\\"{x:1499,y:753,t:1527188955675};\\\", \\\"{x:1494,y:765,t:1527188955692};\\\", \\\"{x:1487,y:779,t:1527188955709};\\\", \\\"{x:1485,y:794,t:1527188955725};\\\", \\\"{x:1482,y:806,t:1527188955741};\\\", \\\"{x:1476,y:817,t:1527188955759};\\\", \\\"{x:1473,y:821,t:1527188955775};\\\", \\\"{x:1470,y:825,t:1527188955791};\\\", \\\"{x:1469,y:827,t:1527188955808};\\\", \\\"{x:1468,y:830,t:1527188955825};\\\", \\\"{x:1466,y:835,t:1527188955841};\\\", \\\"{x:1461,y:841,t:1527188955858};\\\", \\\"{x:1456,y:850,t:1527188955875};\\\", \\\"{x:1453,y:854,t:1527188955891};\\\", \\\"{x:1450,y:858,t:1527188955908};\\\", \\\"{x:1450,y:859,t:1527188955925};\\\", \\\"{x:1449,y:861,t:1527188955941};\\\", \\\"{x:1447,y:863,t:1527188955958};\\\", \\\"{x:1445,y:865,t:1527188955975};\\\", \\\"{x:1444,y:865,t:1527188955998};\\\", \\\"{x:1442,y:865,t:1527188956009};\\\", \\\"{x:1440,y:865,t:1527188956031};\\\", \\\"{x:1439,y:865,t:1527188956046};\\\", \\\"{x:1436,y:865,t:1527188956059};\\\", \\\"{x:1427,y:858,t:1527188956076};\\\", \\\"{x:1419,y:848,t:1527188956092};\\\", \\\"{x:1412,y:835,t:1527188956109};\\\", \\\"{x:1406,y:818,t:1527188956126};\\\", \\\"{x:1401,y:802,t:1527188956142};\\\", \\\"{x:1394,y:783,t:1527188956159};\\\", \\\"{x:1389,y:771,t:1527188956175};\\\", \\\"{x:1380,y:756,t:1527188956192};\\\", \\\"{x:1374,y:745,t:1527188956209};\\\", \\\"{x:1372,y:742,t:1527188956226};\\\", \\\"{x:1372,y:740,t:1527188956242};\\\", \\\"{x:1370,y:737,t:1527188956258};\\\", \\\"{x:1370,y:736,t:1527188956276};\\\", \\\"{x:1369,y:736,t:1527188956342};\\\", \\\"{x:1364,y:750,t:1527188956359};\\\", \\\"{x:1361,y:766,t:1527188956376};\\\", \\\"{x:1357,y:782,t:1527188956392};\\\", \\\"{x:1355,y:792,t:1527188956408};\\\", \\\"{x:1354,y:794,t:1527188956425};\\\", \\\"{x:1354,y:795,t:1527188956442};\\\", \\\"{x:1351,y:795,t:1527188956510};\\\", \\\"{x:1344,y:786,t:1527188956525};\\\", \\\"{x:1338,y:776,t:1527188956542};\\\", \\\"{x:1330,y:767,t:1527188956559};\\\", \\\"{x:1326,y:758,t:1527188956575};\\\", \\\"{x:1320,y:748,t:1527188956592};\\\", \\\"{x:1311,y:735,t:1527188956609};\\\", \\\"{x:1309,y:733,t:1527188956626};\\\", \\\"{x:1307,y:731,t:1527188956643};\\\", \\\"{x:1306,y:729,t:1527188956658};\\\", \\\"{x:1304,y:729,t:1527188956727};\\\", \\\"{x:1300,y:739,t:1527188956742};\\\", \\\"{x:1295,y:753,t:1527188956759};\\\", \\\"{x:1289,y:765,t:1527188956776};\\\", \\\"{x:1285,y:772,t:1527188956793};\\\", \\\"{x:1284,y:776,t:1527188956810};\\\", \\\"{x:1283,y:778,t:1527188956826};\\\", \\\"{x:1282,y:778,t:1527188956870};\\\", \\\"{x:1280,y:775,t:1527188956886};\\\", \\\"{x:1277,y:769,t:1527188956894};\\\", \\\"{x:1270,y:755,t:1527188956910};\\\", \\\"{x:1264,y:745,t:1527188956926};\\\", \\\"{x:1245,y:716,t:1527188956942};\\\", \\\"{x:1239,y:709,t:1527188956960};\\\", \\\"{x:1234,y:707,t:1527188956976};\\\", \\\"{x:1232,y:705,t:1527188956993};\\\", \\\"{x:1231,y:705,t:1527188957010};\\\", \\\"{x:1228,y:706,t:1527188957025};\\\", \\\"{x:1223,y:716,t:1527188957043};\\\", \\\"{x:1218,y:733,t:1527188957059};\\\", \\\"{x:1210,y:749,t:1527188957076};\\\", \\\"{x:1205,y:764,t:1527188957093};\\\", \\\"{x:1204,y:771,t:1527188957109};\\\", \\\"{x:1203,y:772,t:1527188957125};\\\", \\\"{x:1201,y:773,t:1527188957143};\\\", \\\"{x:1200,y:773,t:1527188957166};\\\", \\\"{x:1196,y:772,t:1527188957176};\\\", \\\"{x:1190,y:764,t:1527188957193};\\\", \\\"{x:1180,y:753,t:1527188957209};\\\", \\\"{x:1170,y:739,t:1527188957226};\\\", \\\"{x:1147,y:730,t:1527188957242};\\\", \\\"{x:1128,y:722,t:1527188957259};\\\", \\\"{x:1126,y:722,t:1527188957277};\\\", \\\"{x:1124,y:722,t:1527188957293};\\\", \\\"{x:1122,y:727,t:1527188957309};\\\", \\\"{x:1118,y:741,t:1527188957325};\\\", \\\"{x:1110,y:764,t:1527188957342};\\\", \\\"{x:1100,y:787,t:1527188957359};\\\", \\\"{x:1089,y:803,t:1527188957376};\\\", \\\"{x:1077,y:818,t:1527188957392};\\\", \\\"{x:1066,y:826,t:1527188957409};\\\", \\\"{x:1062,y:828,t:1527188957426};\\\", \\\"{x:1060,y:828,t:1527188957446};\\\", \\\"{x:1057,y:828,t:1527188957459};\\\", \\\"{x:1056,y:828,t:1527188957477};\\\", \\\"{x:1033,y:817,t:1527188957493};\\\", \\\"{x:999,y:800,t:1527188957510};\\\", \\\"{x:938,y:783,t:1527188957526};\\\", \\\"{x:907,y:768,t:1527188957542};\\\", \\\"{x:848,y:740,t:1527188957559};\\\", \\\"{x:800,y:716,t:1527188957577};\\\", \\\"{x:765,y:697,t:1527188957592};\\\", \\\"{x:744,y:686,t:1527188957610};\\\", \\\"{x:726,y:674,t:1527188957627};\\\", \\\"{x:711,y:665,t:1527188957643};\\\", \\\"{x:691,y:655,t:1527188957660};\\\", \\\"{x:670,y:648,t:1527188957676};\\\", \\\"{x:655,y:644,t:1527188957693};\\\", \\\"{x:645,y:639,t:1527188957710};\\\", \\\"{x:634,y:634,t:1527188957726};\\\", \\\"{x:623,y:633,t:1527188957743};\\\", \\\"{x:602,y:630,t:1527188957761};\\\", \\\"{x:579,y:628,t:1527188957776};\\\", \\\"{x:554,y:628,t:1527188957793};\\\", \\\"{x:528,y:628,t:1527188957811};\\\", \\\"{x:504,y:628,t:1527188957828};\\\", \\\"{x:479,y:628,t:1527188957846};\\\", \\\"{x:469,y:627,t:1527188957861};\\\", \\\"{x:464,y:625,t:1527188957878};\\\", \\\"{x:463,y:625,t:1527188957895};\\\", \\\"{x:462,y:623,t:1527188957926};\\\", \\\"{x:460,y:620,t:1527188957933};\\\", \\\"{x:458,y:616,t:1527188957945};\\\", \\\"{x:454,y:610,t:1527188957961};\\\", \\\"{x:447,y:605,t:1527188957978};\\\", \\\"{x:440,y:603,t:1527188957995};\\\", \\\"{x:437,y:601,t:1527188958012};\\\", \\\"{x:435,y:600,t:1527188958030};\\\", \\\"{x:410,y:593,t:1527188958046};\\\", \\\"{x:388,y:588,t:1527188958062};\\\", \\\"{x:365,y:584,t:1527188958079};\\\", \\\"{x:346,y:580,t:1527188958096};\\\", \\\"{x:327,y:578,t:1527188958112};\\\", \\\"{x:319,y:577,t:1527188958128};\\\", \\\"{x:317,y:575,t:1527188958146};\\\", \\\"{x:304,y:574,t:1527188958162};\\\", \\\"{x:303,y:574,t:1527188958398};\\\", \\\"{x:302,y:574,t:1527188958414};\\\", \\\"{x:300,y:574,t:1527188958438};\\\", \\\"{x:297,y:574,t:1527188958502};\\\", \\\"{x:296,y:574,t:1527188958514};\\\", \\\"{x:290,y:576,t:1527188958531};\\\", \\\"{x:284,y:583,t:1527188958547};\\\", \\\"{x:284,y:584,t:1527188958563};\\\", \\\"{x:284,y:585,t:1527188958580};\\\", \\\"{x:284,y:589,t:1527188958597};\\\", \\\"{x:294,y:595,t:1527188958613};\\\", \\\"{x:316,y:605,t:1527188958630};\\\", \\\"{x:343,y:613,t:1527188958646};\\\", \\\"{x:375,y:620,t:1527188958661};\\\", \\\"{x:403,y:625,t:1527188958679};\\\", \\\"{x:431,y:630,t:1527188958695};\\\", \\\"{x:447,y:631,t:1527188958712};\\\", \\\"{x:460,y:631,t:1527188958730};\\\", \\\"{x:469,y:631,t:1527188958745};\\\", \\\"{x:485,y:632,t:1527188958762};\\\", \\\"{x:503,y:634,t:1527188958780};\\\", \\\"{x:527,y:635,t:1527188958797};\\\", \\\"{x:550,y:635,t:1527188958812};\\\", \\\"{x:576,y:635,t:1527188958830};\\\", \\\"{x:595,y:635,t:1527188958845};\\\", \\\"{x:621,y:636,t:1527188958862};\\\", \\\"{x:646,y:638,t:1527188958879};\\\", \\\"{x:669,y:638,t:1527188958896};\\\", \\\"{x:691,y:638,t:1527188958913};\\\", \\\"{x:708,y:638,t:1527188958929};\\\", \\\"{x:717,y:636,t:1527188958946};\\\", \\\"{x:725,y:635,t:1527188958962};\\\", \\\"{x:734,y:633,t:1527188958980};\\\", \\\"{x:742,y:630,t:1527188958998};\\\", \\\"{x:748,y:629,t:1527188959012};\\\", \\\"{x:753,y:624,t:1527188959029};\\\", \\\"{x:757,y:621,t:1527188959046};\\\", \\\"{x:759,y:620,t:1527188959062};\\\", \\\"{x:761,y:617,t:1527188959079};\\\", \\\"{x:766,y:610,t:1527188959096};\\\", \\\"{x:780,y:593,t:1527188959113};\\\", \\\"{x:801,y:573,t:1527188959129};\\\", \\\"{x:815,y:560,t:1527188959146};\\\", \\\"{x:820,y:554,t:1527188959162};\\\", \\\"{x:824,y:549,t:1527188959179};\\\", \\\"{x:825,y:545,t:1527188959196};\\\", \\\"{x:827,y:540,t:1527188959212};\\\", \\\"{x:828,y:528,t:1527188959230};\\\", \\\"{x:831,y:522,t:1527188959247};\\\", \\\"{x:831,y:521,t:1527188959263};\\\", \\\"{x:831,y:520,t:1527188959280};\\\", \\\"{x:832,y:518,t:1527188959310};\\\", \\\"{x:833,y:516,t:1527188959327};\\\", \\\"{x:833,y:515,t:1527188959346};\\\", \\\"{x:833,y:514,t:1527188959364};\\\", \\\"{x:833,y:513,t:1527188959382};\\\", \\\"{x:834,y:513,t:1527188959405};\\\", \\\"{x:834,y:512,t:1527188959413};\\\", \\\"{x:834,y:511,t:1527188959429};\\\", \\\"{x:834,y:510,t:1527188959462};\\\", \\\"{x:835,y:509,t:1527188959478};\\\", \\\"{x:830,y:509,t:1527188959694};\\\", \\\"{x:820,y:510,t:1527188959702};\\\", \\\"{x:807,y:514,t:1527188959713};\\\", \\\"{x:777,y:522,t:1527188959731};\\\", \\\"{x:739,y:538,t:1527188959747};\\\", \\\"{x:703,y:552,t:1527188959765};\\\", \\\"{x:679,y:567,t:1527188959781};\\\", \\\"{x:659,y:580,t:1527188959797};\\\", \\\"{x:634,y:596,t:1527188959814};\\\", \\\"{x:620,y:608,t:1527188959831};\\\", \\\"{x:611,y:614,t:1527188959846};\\\", \\\"{x:604,y:621,t:1527188959863};\\\", \\\"{x:595,y:626,t:1527188959881};\\\", \\\"{x:578,y:636,t:1527188959896};\\\", \\\"{x:560,y:642,t:1527188959913};\\\", \\\"{x:541,y:650,t:1527188959931};\\\", \\\"{x:523,y:654,t:1527188959946};\\\", \\\"{x:510,y:657,t:1527188959964};\\\", \\\"{x:506,y:658,t:1527188959981};\\\", \\\"{x:503,y:658,t:1527188959997};\\\", \\\"{x:487,y:658,t:1527188960014};\\\", \\\"{x:472,y:658,t:1527188960030};\\\", \\\"{x:456,y:658,t:1527188960046};\\\", \\\"{x:453,y:658,t:1527188960064};\\\", \\\"{x:448,y:658,t:1527188960081};\\\", \\\"{x:446,y:658,t:1527188960097};\\\", \\\"{x:444,y:658,t:1527188960142};\\\", \\\"{x:443,y:658,t:1527188960150};\\\", \\\"{x:439,y:658,t:1527188960164};\\\", \\\"{x:435,y:658,t:1527188960181};\\\", \\\"{x:432,y:658,t:1527188960198};\\\", \\\"{x:429,y:658,t:1527188960213};\\\", \\\"{x:427,y:657,t:1527188960231};\\\", \\\"{x:425,y:656,t:1527188960248};\\\", \\\"{x:424,y:654,t:1527188960264};\\\", \\\"{x:423,y:653,t:1527188960280};\\\", \\\"{x:421,y:650,t:1527188960298};\\\", \\\"{x:421,y:647,t:1527188960314};\\\", \\\"{x:420,y:641,t:1527188960331};\\\", \\\"{x:420,y:633,t:1527188960349};\\\", \\\"{x:418,y:623,t:1527188960365};\\\", \\\"{x:413,y:612,t:1527188960381};\\\", \\\"{x:403,y:598,t:1527188960398};\\\", \\\"{x:400,y:594,t:1527188960413};\\\", \\\"{x:397,y:593,t:1527188960431};\\\", \\\"{x:393,y:593,t:1527188960448};\\\", \\\"{x:381,y:592,t:1527188960463};\\\", \\\"{x:374,y:591,t:1527188960480};\\\", \\\"{x:367,y:590,t:1527188960497};\\\", \\\"{x:354,y:590,t:1527188960514};\\\", \\\"{x:336,y:590,t:1527188960532};\\\", \\\"{x:317,y:590,t:1527188960548};\\\", \\\"{x:297,y:592,t:1527188960565};\\\", \\\"{x:259,y:605,t:1527188960583};\\\", \\\"{x:235,y:612,t:1527188960598};\\\", \\\"{x:218,y:617,t:1527188960614};\\\", \\\"{x:211,y:619,t:1527188960630};\\\", \\\"{x:209,y:620,t:1527188960647};\\\", \\\"{x:206,y:622,t:1527188960664};\\\", \\\"{x:200,y:624,t:1527188960680};\\\", \\\"{x:192,y:629,t:1527188960697};\\\", \\\"{x:174,y:638,t:1527188960715};\\\", \\\"{x:158,y:644,t:1527188960731};\\\", \\\"{x:147,y:652,t:1527188960747};\\\", \\\"{x:147,y:651,t:1527188960821};\\\", \\\"{x:148,y:648,t:1527188960831};\\\", \\\"{x:148,y:647,t:1527188960847};\\\", \\\"{x:149,y:645,t:1527188960864};\\\", \\\"{x:152,y:641,t:1527188960881};\\\", \\\"{x:159,y:632,t:1527188960898};\\\", \\\"{x:177,y:618,t:1527188960915};\\\", \\\"{x:194,y:608,t:1527188960930};\\\", \\\"{x:211,y:602,t:1527188960947};\\\", \\\"{x:236,y:598,t:1527188960965};\\\", \\\"{x:268,y:598,t:1527188960980};\\\", \\\"{x:375,y:609,t:1527188960997};\\\", \\\"{x:497,y:625,t:1527188961015};\\\", \\\"{x:636,y:644,t:1527188961032};\\\", \\\"{x:770,y:657,t:1527188961047};\\\", \\\"{x:881,y:671,t:1527188961065};\\\", \\\"{x:961,y:680,t:1527188961081};\\\", \\\"{x:990,y:684,t:1527188961098};\\\", \\\"{x:995,y:685,t:1527188961114};\\\", \\\"{x:994,y:685,t:1527188961158};\\\", \\\"{x:992,y:685,t:1527188961166};\\\", \\\"{x:987,y:681,t:1527188961182};\\\", \\\"{x:986,y:677,t:1527188961198};\\\", \\\"{x:977,y:663,t:1527188961215};\\\", \\\"{x:960,y:649,t:1527188961232};\\\", \\\"{x:936,y:640,t:1527188961248};\\\", \\\"{x:905,y:632,t:1527188961264};\\\", \\\"{x:870,y:627,t:1527188961283};\\\", \\\"{x:821,y:618,t:1527188961298};\\\", \\\"{x:729,y:603,t:1527188961314};\\\", \\\"{x:632,y:589,t:1527188961332};\\\", \\\"{x:522,y:577,t:1527188961348};\\\", \\\"{x:421,y:562,t:1527188961364};\\\", \\\"{x:343,y:546,t:1527188961382};\\\", \\\"{x:294,y:543,t:1527188961398};\\\", \\\"{x:266,y:538,t:1527188961415};\\\", \\\"{x:254,y:537,t:1527188961431};\\\", \\\"{x:250,y:537,t:1527188961449};\\\", \\\"{x:248,y:537,t:1527188961510};\\\", \\\"{x:242,y:537,t:1527188961525};\\\", \\\"{x:239,y:536,t:1527188961534};\\\", \\\"{x:234,y:536,t:1527188961549};\\\", \\\"{x:220,y:534,t:1527188961565};\\\", \\\"{x:217,y:534,t:1527188961582};\\\", \\\"{x:215,y:534,t:1527188961598};\\\", \\\"{x:214,y:534,t:1527188961616};\\\", \\\"{x:213,y:537,t:1527188961878};\\\", \\\"{x:216,y:547,t:1527188961885};\\\", \\\"{x:226,y:559,t:1527188961899};\\\", \\\"{x:269,y:598,t:1527188961915};\\\", \\\"{x:327,y:633,t:1527188961931};\\\", \\\"{x:376,y:661,t:1527188961949};\\\", \\\"{x:408,y:679,t:1527188961966};\\\", \\\"{x:424,y:687,t:1527188961982};\\\", \\\"{x:438,y:695,t:1527188961998};\\\", \\\"{x:447,y:703,t:1527188962016};\\\", \\\"{x:458,y:710,t:1527188962032};\\\", \\\"{x:468,y:713,t:1527188962049};\\\", \\\"{x:478,y:716,t:1527188962066};\\\", \\\"{x:485,y:717,t:1527188962082};\\\", \\\"{x:493,y:719,t:1527188962099};\\\", \\\"{x:494,y:719,t:1527188962151};\\\", \\\"{x:462,y:697,t:1527188962166};\\\", \\\"{x:423,y:670,t:1527188962182};\\\", \\\"{x:362,y:642,t:1527188962199};\\\", \\\"{x:307,y:618,t:1527188962215};\\\", \\\"{x:244,y:594,t:1527188962233};\\\", \\\"{x:215,y:583,t:1527188962249};\\\", \\\"{x:200,y:571,t:1527188962266};\\\", \\\"{x:194,y:559,t:1527188962283};\\\", \\\"{x:191,y:550,t:1527188962298};\\\", \\\"{x:191,y:545,t:1527188962316};\\\", \\\"{x:191,y:543,t:1527188962446};\\\", \\\"{x:191,y:540,t:1527188962453};\\\", \\\"{x:189,y:540,t:1527188962466};\\\", \\\"{x:185,y:537,t:1527188962482};\\\", \\\"{x:183,y:536,t:1527188962499};\\\", \\\"{x:183,y:538,t:1527188962869};\\\", \\\"{x:184,y:546,t:1527188962882};\\\", \\\"{x:199,y:570,t:1527188962900};\\\", \\\"{x:242,y:617,t:1527188962918};\\\", \\\"{x:302,y:664,t:1527188962933};\\\", \\\"{x:426,y:724,t:1527188962950};\\\", \\\"{x:490,y:754,t:1527188962967};\\\", \\\"{x:541,y:782,t:1527188962983};\\\", \\\"{x:585,y:809,t:1527188963000};\\\", \\\"{x:611,y:824,t:1527188963016};\\\", \\\"{x:621,y:831,t:1527188963033};\\\", \\\"{x:623,y:832,t:1527188963049};\\\", \\\"{x:623,y:831,t:1527188963143};\\\", \\\"{x:618,y:825,t:1527188963150};\\\", \\\"{x:608,y:814,t:1527188963167};\\\", \\\"{x:592,y:799,t:1527188963184};\\\", \\\"{x:576,y:786,t:1527188963201};\\\", \\\"{x:565,y:777,t:1527188963217};\\\", \\\"{x:552,y:769,t:1527188963234};\\\", \\\"{x:545,y:762,t:1527188963251};\\\", \\\"{x:541,y:759,t:1527188963267};\\\", \\\"{x:533,y:752,t:1527188963284};\\\", \\\"{x:520,y:745,t:1527188963301};\\\", \\\"{x:510,y:739,t:1527188963316};\\\", \\\"{x:508,y:737,t:1527188963333};\\\" ] }, { \\\"rt\\\": 37547, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 387692, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-G -E -J -E -E -J -E -E -J -E -E -E -E -E -E -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:737,t:1527188965718};\\\", \\\"{x:517,y:734,t:1527188967206};\\\", \\\"{x:540,y:733,t:1527188967214};\\\", \\\"{x:593,y:733,t:1527188967232};\\\", \\\"{x:679,y:731,t:1527188967246};\\\", \\\"{x:771,y:731,t:1527188967263};\\\", \\\"{x:927,y:725,t:1527188967287};\\\", \\\"{x:1010,y:715,t:1527188967302};\\\", \\\"{x:1051,y:713,t:1527188967319};\\\", \\\"{x:1100,y:706,t:1527188967336};\\\", \\\"{x:1134,y:700,t:1527188967353};\\\", \\\"{x:1153,y:696,t:1527188967370};\\\", \\\"{x:1162,y:695,t:1527188967387};\\\", \\\"{x:1168,y:693,t:1527188967404};\\\", \\\"{x:1171,y:690,t:1527188967419};\\\", \\\"{x:1184,y:676,t:1527188967437};\\\", \\\"{x:1199,y:652,t:1527188967453};\\\", \\\"{x:1209,y:639,t:1527188967469};\\\", \\\"{x:1219,y:623,t:1527188967487};\\\", \\\"{x:1225,y:606,t:1527188967505};\\\", \\\"{x:1231,y:589,t:1527188967520};\\\", \\\"{x:1237,y:569,t:1527188967536};\\\", \\\"{x:1247,y:552,t:1527188967554};\\\", \\\"{x:1252,y:538,t:1527188967570};\\\", \\\"{x:1255,y:529,t:1527188967587};\\\", \\\"{x:1257,y:520,t:1527188967604};\\\", \\\"{x:1263,y:508,t:1527188967620};\\\", \\\"{x:1276,y:496,t:1527188967637};\\\", \\\"{x:1302,y:481,t:1527188967653};\\\", \\\"{x:1313,y:481,t:1527188967670};\\\", \\\"{x:1321,y:481,t:1527188967687};\\\", \\\"{x:1322,y:481,t:1527188967704};\\\", \\\"{x:1323,y:481,t:1527188967726};\\\", \\\"{x:1324,y:481,t:1527188967737};\\\", \\\"{x:1328,y:485,t:1527188967754};\\\", \\\"{x:1333,y:489,t:1527188967771};\\\", \\\"{x:1338,y:492,t:1527188967787};\\\", \\\"{x:1339,y:493,t:1527188967804};\\\", \\\"{x:1340,y:494,t:1527188967838};\\\", \\\"{x:1340,y:495,t:1527188967853};\\\", \\\"{x:1342,y:496,t:1527188967871};\\\", \\\"{x:1343,y:497,t:1527188967887};\\\", \\\"{x:1344,y:498,t:1527188967904};\\\", \\\"{x:1345,y:498,t:1527188967920};\\\", \\\"{x:1346,y:499,t:1527188967937};\\\", \\\"{x:1347,y:500,t:1527188967956};\\\", \\\"{x:1352,y:503,t:1527188967971};\\\", \\\"{x:1365,y:508,t:1527188967987};\\\", \\\"{x:1379,y:514,t:1527188968004};\\\", \\\"{x:1393,y:518,t:1527188968021};\\\", \\\"{x:1397,y:519,t:1527188968037};\\\", \\\"{x:1401,y:519,t:1527188968054};\\\", \\\"{x:1404,y:520,t:1527188968071};\\\", \\\"{x:1406,y:521,t:1527188968088};\\\", \\\"{x:1411,y:523,t:1527188968104};\\\", \\\"{x:1418,y:526,t:1527188968120};\\\", \\\"{x:1420,y:526,t:1527188968138};\\\", \\\"{x:1421,y:526,t:1527188968153};\\\", \\\"{x:1422,y:527,t:1527188968171};\\\", \\\"{x:1423,y:530,t:1527188968206};\\\", \\\"{x:1425,y:539,t:1527188968222};\\\", \\\"{x:1427,y:545,t:1527188968238};\\\", \\\"{x:1428,y:547,t:1527188968255};\\\", \\\"{x:1428,y:548,t:1527188968293};\\\", \\\"{x:1428,y:549,t:1527188968304};\\\", \\\"{x:1428,y:554,t:1527188968321};\\\", \\\"{x:1428,y:557,t:1527188968338};\\\", \\\"{x:1428,y:558,t:1527188968355};\\\", \\\"{x:1428,y:559,t:1527188968663};\\\", \\\"{x:1427,y:559,t:1527188968686};\\\", \\\"{x:1426,y:559,t:1527188968694};\\\", \\\"{x:1425,y:559,t:1527188968718};\\\", \\\"{x:1423,y:559,t:1527188968742};\\\", \\\"{x:1421,y:559,t:1527188968790};\\\", \\\"{x:1420,y:559,t:1527188968935};\\\", \\\"{x:1418,y:559,t:1527188968960};\\\", \\\"{x:1417,y:559,t:1527188968989};\\\", \\\"{x:1414,y:559,t:1527188969006};\\\", \\\"{x:1413,y:559,t:1527188969061};\\\", \\\"{x:1408,y:559,t:1527188974841};\\\", \\\"{x:1403,y:559,t:1527188974850};\\\", \\\"{x:1393,y:561,t:1527188974866};\\\", \\\"{x:1384,y:561,t:1527188974883};\\\", \\\"{x:1379,y:563,t:1527188974900};\\\", \\\"{x:1377,y:565,t:1527188975761};\\\", \\\"{x:1375,y:567,t:1527188975768};\\\", \\\"{x:1370,y:569,t:1527188975784};\\\", \\\"{x:1365,y:573,t:1527188975801};\\\", \\\"{x:1361,y:575,t:1527188975817};\\\", \\\"{x:1360,y:576,t:1527188975834};\\\", \\\"{x:1359,y:577,t:1527188975851};\\\", \\\"{x:1358,y:577,t:1527188975896};\\\", \\\"{x:1357,y:578,t:1527188975904};\\\", \\\"{x:1356,y:579,t:1527188975919};\\\", \\\"{x:1354,y:580,t:1527188975934};\\\", \\\"{x:1351,y:582,t:1527188975951};\\\", \\\"{x:1350,y:583,t:1527188975968};\\\", \\\"{x:1349,y:583,t:1527188975984};\\\", \\\"{x:1347,y:583,t:1527188976001};\\\", \\\"{x:1345,y:584,t:1527188976018};\\\", \\\"{x:1345,y:585,t:1527188976034};\\\", \\\"{x:1343,y:586,t:1527188976051};\\\", \\\"{x:1342,y:586,t:1527188976068};\\\", \\\"{x:1341,y:587,t:1527188976085};\\\", \\\"{x:1339,y:587,t:1527188976193};\\\", \\\"{x:1338,y:587,t:1527188976208};\\\", \\\"{x:1337,y:587,t:1527188976224};\\\", \\\"{x:1336,y:587,t:1527188976235};\\\", \\\"{x:1333,y:587,t:1527188976251};\\\", \\\"{x:1332,y:587,t:1527188976268};\\\", \\\"{x:1328,y:587,t:1527188976285};\\\", \\\"{x:1325,y:587,t:1527188976301};\\\", \\\"{x:1323,y:587,t:1527188976318};\\\", \\\"{x:1322,y:587,t:1527188976336};\\\", \\\"{x:1318,y:586,t:1527188976353};\\\", \\\"{x:1315,y:584,t:1527188976368};\\\", \\\"{x:1312,y:583,t:1527188976385};\\\", \\\"{x:1311,y:581,t:1527188976402};\\\", \\\"{x:1309,y:581,t:1527188976473};\\\", \\\"{x:1307,y:579,t:1527188976485};\\\", \\\"{x:1305,y:576,t:1527188976502};\\\", \\\"{x:1305,y:575,t:1527188976518};\\\", \\\"{x:1304,y:574,t:1527188976535};\\\", \\\"{x:1303,y:573,t:1527188976553};\\\", \\\"{x:1300,y:571,t:1527188976568};\\\", \\\"{x:1299,y:570,t:1527188976586};\\\", \\\"{x:1298,y:569,t:1527188976602};\\\", \\\"{x:1296,y:567,t:1527188976625};\\\", \\\"{x:1295,y:566,t:1527188976664};\\\", \\\"{x:1294,y:566,t:1527188976688};\\\", \\\"{x:1293,y:566,t:1527188976721};\\\", \\\"{x:1293,y:565,t:1527188976776};\\\", \\\"{x:1292,y:565,t:1527188976832};\\\", \\\"{x:1289,y:564,t:1527188976952};\\\", \\\"{x:1285,y:563,t:1527188976970};\\\", \\\"{x:1275,y:562,t:1527188976987};\\\", \\\"{x:1268,y:561,t:1527188977002};\\\", \\\"{x:1268,y:560,t:1527188977424};\\\", \\\"{x:1270,y:560,t:1527188977436};\\\", \\\"{x:1273,y:562,t:1527188977453};\\\", \\\"{x:1274,y:563,t:1527188977470};\\\", \\\"{x:1275,y:564,t:1527188977486};\\\", \\\"{x:1275,y:566,t:1527188977512};\\\", \\\"{x:1275,y:569,t:1527188977520};\\\", \\\"{x:1275,y:571,t:1527188977536};\\\", \\\"{x:1275,y:575,t:1527188977553};\\\", \\\"{x:1275,y:578,t:1527188977570};\\\", \\\"{x:1273,y:583,t:1527188977587};\\\", \\\"{x:1271,y:587,t:1527188977604};\\\", \\\"{x:1269,y:593,t:1527188977620};\\\", \\\"{x:1266,y:601,t:1527188977638};\\\", \\\"{x:1260,y:611,t:1527188977653};\\\", \\\"{x:1245,y:631,t:1527188977670};\\\", \\\"{x:1235,y:646,t:1527188977687};\\\", \\\"{x:1225,y:661,t:1527188977703};\\\", \\\"{x:1214,y:682,t:1527188977720};\\\", \\\"{x:1206,y:694,t:1527188977737};\\\", \\\"{x:1202,y:708,t:1527188977754};\\\", \\\"{x:1199,y:722,t:1527188977770};\\\", \\\"{x:1198,y:734,t:1527188977787};\\\", \\\"{x:1197,y:744,t:1527188977804};\\\", \\\"{x:1194,y:754,t:1527188977820};\\\", \\\"{x:1191,y:761,t:1527188977838};\\\", \\\"{x:1188,y:765,t:1527188977853};\\\", \\\"{x:1186,y:771,t:1527188977870};\\\", \\\"{x:1185,y:779,t:1527188977888};\\\", \\\"{x:1184,y:788,t:1527188977904};\\\", \\\"{x:1184,y:791,t:1527188977920};\\\", \\\"{x:1184,y:792,t:1527188977938};\\\", \\\"{x:1184,y:793,t:1527188977976};\\\", \\\"{x:1185,y:794,t:1527188977992};\\\", \\\"{x:1186,y:796,t:1527188978004};\\\", \\\"{x:1191,y:802,t:1527188978021};\\\", \\\"{x:1197,y:809,t:1527188978037};\\\", \\\"{x:1204,y:814,t:1527188978054};\\\", \\\"{x:1211,y:818,t:1527188978071};\\\", \\\"{x:1217,y:824,t:1527188978087};\\\", \\\"{x:1226,y:836,t:1527188978104};\\\", \\\"{x:1227,y:838,t:1527188978120};\\\", \\\"{x:1229,y:843,t:1527188978137};\\\", \\\"{x:1231,y:846,t:1527188978154};\\\", \\\"{x:1232,y:843,t:1527188978200};\\\", \\\"{x:1232,y:835,t:1527188978208};\\\", \\\"{x:1235,y:828,t:1527188978221};\\\", \\\"{x:1237,y:814,t:1527188978237};\\\", \\\"{x:1245,y:785,t:1527188978254};\\\", \\\"{x:1254,y:742,t:1527188978272};\\\", \\\"{x:1259,y:707,t:1527188978288};\\\", \\\"{x:1263,y:676,t:1527188978304};\\\", \\\"{x:1265,y:668,t:1527188978322};\\\", \\\"{x:1266,y:662,t:1527188978337};\\\", \\\"{x:1268,y:650,t:1527188978355};\\\", \\\"{x:1269,y:635,t:1527188978371};\\\", \\\"{x:1270,y:615,t:1527188978389};\\\", \\\"{x:1272,y:590,t:1527188978404};\\\", \\\"{x:1272,y:580,t:1527188978421};\\\", \\\"{x:1273,y:575,t:1527188978438};\\\", \\\"{x:1274,y:573,t:1527188978454};\\\", \\\"{x:1275,y:572,t:1527188978736};\\\", \\\"{x:1278,y:571,t:1527188978744};\\\", \\\"{x:1279,y:568,t:1527188978756};\\\", \\\"{x:1281,y:565,t:1527188978771};\\\", \\\"{x:1281,y:563,t:1527188978788};\\\", \\\"{x:1282,y:562,t:1527188978872};\\\", \\\"{x:1279,y:563,t:1527188978928};\\\", \\\"{x:1277,y:567,t:1527188978939};\\\", \\\"{x:1265,y:581,t:1527188978956};\\\", \\\"{x:1250,y:601,t:1527188978972};\\\", \\\"{x:1230,y:627,t:1527188978989};\\\", \\\"{x:1212,y:645,t:1527188979005};\\\", \\\"{x:1199,y:659,t:1527188979022};\\\", \\\"{x:1191,y:667,t:1527188979038};\\\", \\\"{x:1183,y:679,t:1527188979055};\\\", \\\"{x:1175,y:706,t:1527188979072};\\\", \\\"{x:1169,y:726,t:1527188979089};\\\", \\\"{x:1167,y:743,t:1527188979106};\\\", \\\"{x:1167,y:750,t:1527188979123};\\\", \\\"{x:1167,y:755,t:1527188979138};\\\", \\\"{x:1167,y:762,t:1527188979155};\\\", \\\"{x:1177,y:780,t:1527188979173};\\\", \\\"{x:1193,y:808,t:1527188979190};\\\", \\\"{x:1208,y:844,t:1527188979206};\\\", \\\"{x:1218,y:864,t:1527188979222};\\\", \\\"{x:1221,y:876,t:1527188979239};\\\", \\\"{x:1223,y:880,t:1527188979255};\\\", \\\"{x:1224,y:880,t:1527188979273};\\\", \\\"{x:1224,y:877,t:1527188979336};\\\", \\\"{x:1224,y:873,t:1527188979344};\\\", \\\"{x:1224,y:866,t:1527188979355};\\\", \\\"{x:1225,y:847,t:1527188979373};\\\", \\\"{x:1230,y:823,t:1527188979389};\\\", \\\"{x:1234,y:801,t:1527188979405};\\\", \\\"{x:1240,y:771,t:1527188979422};\\\", \\\"{x:1246,y:748,t:1527188979439};\\\", \\\"{x:1260,y:686,t:1527188979456};\\\", \\\"{x:1268,y:648,t:1527188979472};\\\", \\\"{x:1273,y:631,t:1527188979489};\\\", \\\"{x:1276,y:616,t:1527188979507};\\\", \\\"{x:1278,y:610,t:1527188979522};\\\", \\\"{x:1278,y:608,t:1527188979539};\\\", \\\"{x:1278,y:606,t:1527188979556};\\\", \\\"{x:1278,y:605,t:1527188979572};\\\", \\\"{x:1280,y:602,t:1527188979589};\\\", \\\"{x:1280,y:598,t:1527188979606};\\\", \\\"{x:1281,y:593,t:1527188979622};\\\", \\\"{x:1281,y:591,t:1527188979640};\\\", \\\"{x:1281,y:590,t:1527188979656};\\\", \\\"{x:1281,y:588,t:1527188979720};\\\", \\\"{x:1281,y:587,t:1527188979728};\\\", \\\"{x:1281,y:585,t:1527188979740};\\\", \\\"{x:1281,y:581,t:1527188979756};\\\", \\\"{x:1281,y:579,t:1527188979774};\\\", \\\"{x:1281,y:577,t:1527188979790};\\\", \\\"{x:1281,y:575,t:1527188979807};\\\", \\\"{x:1281,y:571,t:1527188979824};\\\", \\\"{x:1281,y:568,t:1527188979839};\\\", \\\"{x:1280,y:566,t:1527188979857};\\\", \\\"{x:1280,y:565,t:1527188979904};\\\", \\\"{x:1279,y:564,t:1527188979952};\\\", \\\"{x:1275,y:565,t:1527188979960};\\\", \\\"{x:1272,y:569,t:1527188979973};\\\", \\\"{x:1259,y:582,t:1527188979990};\\\", \\\"{x:1243,y:598,t:1527188980006};\\\", \\\"{x:1233,y:615,t:1527188980023};\\\", \\\"{x:1216,y:645,t:1527188980040};\\\", \\\"{x:1210,y:658,t:1527188980056};\\\", \\\"{x:1205,y:669,t:1527188980074};\\\", \\\"{x:1200,y:680,t:1527188980090};\\\", \\\"{x:1196,y:693,t:1527188980106};\\\", \\\"{x:1191,y:706,t:1527188980123};\\\", \\\"{x:1188,y:719,t:1527188980141};\\\", \\\"{x:1187,y:726,t:1527188980156};\\\", \\\"{x:1187,y:735,t:1527188980174};\\\", \\\"{x:1187,y:740,t:1527188980191};\\\", \\\"{x:1190,y:751,t:1527188980207};\\\", \\\"{x:1195,y:767,t:1527188980224};\\\", \\\"{x:1206,y:793,t:1527188980240};\\\", \\\"{x:1214,y:812,t:1527188980258};\\\", \\\"{x:1219,y:821,t:1527188980274};\\\", \\\"{x:1221,y:824,t:1527188980290};\\\", \\\"{x:1223,y:826,t:1527188980308};\\\", \\\"{x:1227,y:825,t:1527188980432};\\\", \\\"{x:1228,y:816,t:1527188980440};\\\", \\\"{x:1231,y:796,t:1527188980457};\\\", \\\"{x:1233,y:778,t:1527188980474};\\\", \\\"{x:1238,y:755,t:1527188980490};\\\", \\\"{x:1240,y:729,t:1527188980508};\\\", \\\"{x:1243,y:708,t:1527188980524};\\\", \\\"{x:1251,y:685,t:1527188980541};\\\", \\\"{x:1263,y:653,t:1527188980558};\\\", \\\"{x:1275,y:626,t:1527188980575};\\\", \\\"{x:1281,y:610,t:1527188980590};\\\", \\\"{x:1284,y:602,t:1527188980608};\\\", \\\"{x:1285,y:602,t:1527188980625};\\\", \\\"{x:1285,y:601,t:1527188980649};\\\", \\\"{x:1287,y:598,t:1527188980658};\\\", \\\"{x:1289,y:595,t:1527188980674};\\\", \\\"{x:1291,y:588,t:1527188980690};\\\", \\\"{x:1292,y:584,t:1527188980707};\\\", \\\"{x:1292,y:583,t:1527188980724};\\\", \\\"{x:1292,y:581,t:1527188980741};\\\", \\\"{x:1292,y:580,t:1527188980800};\\\", \\\"{x:1292,y:578,t:1527188980808};\\\", \\\"{x:1292,y:577,t:1527188980832};\\\", \\\"{x:1292,y:576,t:1527188980848};\\\", \\\"{x:1292,y:575,t:1527188980858};\\\", \\\"{x:1292,y:574,t:1527188980881};\\\", \\\"{x:1292,y:572,t:1527188980896};\\\", \\\"{x:1291,y:570,t:1527188980912};\\\", \\\"{x:1291,y:567,t:1527188980924};\\\", \\\"{x:1290,y:565,t:1527188980942};\\\", \\\"{x:1289,y:562,t:1527188980958};\\\", \\\"{x:1288,y:560,t:1527188980974};\\\", \\\"{x:1283,y:567,t:1527188982521};\\\", \\\"{x:1269,y:597,t:1527188982544};\\\", \\\"{x:1251,y:634,t:1527188982560};\\\", \\\"{x:1241,y:648,t:1527188982577};\\\", \\\"{x:1237,y:656,t:1527188982593};\\\", \\\"{x:1231,y:664,t:1527188982610};\\\", \\\"{x:1227,y:672,t:1527188982626};\\\", \\\"{x:1222,y:681,t:1527188982644};\\\", \\\"{x:1219,y:688,t:1527188982660};\\\", \\\"{x:1217,y:692,t:1527188982677};\\\", \\\"{x:1215,y:697,t:1527188982694};\\\", \\\"{x:1213,y:699,t:1527188982711};\\\", \\\"{x:1212,y:704,t:1527188982727};\\\", \\\"{x:1210,y:708,t:1527188982744};\\\", \\\"{x:1207,y:715,t:1527188982760};\\\", \\\"{x:1204,y:720,t:1527188982778};\\\", \\\"{x:1200,y:725,t:1527188982793};\\\", \\\"{x:1198,y:736,t:1527188982811};\\\", \\\"{x:1195,y:747,t:1527188982828};\\\", \\\"{x:1195,y:760,t:1527188982843};\\\", \\\"{x:1193,y:770,t:1527188982861};\\\", \\\"{x:1191,y:777,t:1527188982878};\\\", \\\"{x:1190,y:780,t:1527188982893};\\\", \\\"{x:1190,y:781,t:1527188982944};\\\", \\\"{x:1190,y:784,t:1527188982960};\\\", \\\"{x:1190,y:785,t:1527188982978};\\\", \\\"{x:1193,y:790,t:1527188983032};\\\", \\\"{x:1200,y:798,t:1527188983045};\\\", \\\"{x:1204,y:807,t:1527188983061};\\\", \\\"{x:1204,y:811,t:1527188983077};\\\", \\\"{x:1204,y:812,t:1527188983094};\\\", \\\"{x:1205,y:812,t:1527188983192};\\\", \\\"{x:1207,y:811,t:1527188983208};\\\", \\\"{x:1208,y:800,t:1527188983215};\\\", \\\"{x:1208,y:794,t:1527188983227};\\\", \\\"{x:1201,y:766,t:1527188983245};\\\", \\\"{x:1196,y:744,t:1527188983261};\\\", \\\"{x:1196,y:718,t:1527188983278};\\\", \\\"{x:1198,y:691,t:1527188983295};\\\", \\\"{x:1202,y:669,t:1527188983311};\\\", \\\"{x:1211,y:650,t:1527188983328};\\\", \\\"{x:1222,y:625,t:1527188983343};\\\", \\\"{x:1229,y:612,t:1527188983361};\\\", \\\"{x:1232,y:604,t:1527188983378};\\\", \\\"{x:1237,y:595,t:1527188983395};\\\", \\\"{x:1241,y:585,t:1527188983412};\\\", \\\"{x:1246,y:572,t:1527188983428};\\\", \\\"{x:1257,y:558,t:1527188983445};\\\", \\\"{x:1262,y:551,t:1527188983462};\\\", \\\"{x:1268,y:548,t:1527188983477};\\\", \\\"{x:1273,y:545,t:1527188983495};\\\", \\\"{x:1275,y:545,t:1527188983512};\\\", \\\"{x:1276,y:545,t:1527188983569};\\\", \\\"{x:1280,y:545,t:1527188983578};\\\", \\\"{x:1286,y:545,t:1527188983595};\\\", \\\"{x:1289,y:543,t:1527188983612};\\\", \\\"{x:1290,y:543,t:1527188983630};\\\", \\\"{x:1292,y:543,t:1527188983664};\\\", \\\"{x:1293,y:543,t:1527188983679};\\\", \\\"{x:1297,y:547,t:1527188983695};\\\", \\\"{x:1299,y:551,t:1527188983712};\\\", \\\"{x:1301,y:552,t:1527188983729};\\\", \\\"{x:1301,y:554,t:1527188983761};\\\", \\\"{x:1301,y:556,t:1527188983768};\\\", \\\"{x:1301,y:558,t:1527188983778};\\\", \\\"{x:1301,y:563,t:1527188983795};\\\", \\\"{x:1299,y:569,t:1527188983812};\\\", \\\"{x:1296,y:574,t:1527188983829};\\\", \\\"{x:1292,y:583,t:1527188983845};\\\", \\\"{x:1284,y:594,t:1527188983861};\\\", \\\"{x:1275,y:604,t:1527188983879};\\\", \\\"{x:1263,y:614,t:1527188983896};\\\", \\\"{x:1255,y:625,t:1527188983912};\\\", \\\"{x:1245,y:643,t:1527188983929};\\\", \\\"{x:1242,y:652,t:1527188983945};\\\", \\\"{x:1241,y:660,t:1527188983962};\\\", \\\"{x:1236,y:673,t:1527188983978};\\\", \\\"{x:1230,y:690,t:1527188983996};\\\", \\\"{x:1225,y:709,t:1527188984012};\\\", \\\"{x:1219,y:730,t:1527188984029};\\\", \\\"{x:1214,y:745,t:1527188984046};\\\", \\\"{x:1211,y:761,t:1527188984062};\\\", \\\"{x:1208,y:771,t:1527188984079};\\\", \\\"{x:1204,y:784,t:1527188984096};\\\", \\\"{x:1195,y:802,t:1527188984113};\\\", \\\"{x:1188,y:816,t:1527188984129};\\\", \\\"{x:1180,y:826,t:1527188984146};\\\", \\\"{x:1172,y:838,t:1527188984163};\\\", \\\"{x:1163,y:847,t:1527188984179};\\\", \\\"{x:1159,y:850,t:1527188984196};\\\", \\\"{x:1157,y:851,t:1527188984213};\\\", \\\"{x:1157,y:854,t:1527188984288};\\\", \\\"{x:1158,y:854,t:1527188984295};\\\", \\\"{x:1163,y:857,t:1527188984312};\\\", \\\"{x:1168,y:862,t:1527188984329};\\\", \\\"{x:1174,y:867,t:1527188984345};\\\", \\\"{x:1183,y:874,t:1527188984362};\\\", \\\"{x:1190,y:880,t:1527188984379};\\\", \\\"{x:1197,y:885,t:1527188984396};\\\", \\\"{x:1201,y:887,t:1527188984413};\\\", \\\"{x:1201,y:881,t:1527188984552};\\\", \\\"{x:1201,y:872,t:1527188984563};\\\", \\\"{x:1209,y:854,t:1527188984580};\\\", \\\"{x:1219,y:832,t:1527188984597};\\\", \\\"{x:1230,y:803,t:1527188984613};\\\", \\\"{x:1245,y:758,t:1527188984630};\\\", \\\"{x:1257,y:726,t:1527188984647};\\\", \\\"{x:1264,y:700,t:1527188984663};\\\", \\\"{x:1266,y:682,t:1527188984680};\\\", \\\"{x:1265,y:655,t:1527188984696};\\\", \\\"{x:1265,y:634,t:1527188984713};\\\", \\\"{x:1265,y:619,t:1527188984729};\\\", \\\"{x:1267,y:602,t:1527188984746};\\\", \\\"{x:1271,y:589,t:1527188984762};\\\", \\\"{x:1274,y:584,t:1527188984779};\\\", \\\"{x:1275,y:582,t:1527188984797};\\\", \\\"{x:1276,y:580,t:1527188984814};\\\", \\\"{x:1277,y:579,t:1527188984849};\\\", \\\"{x:1278,y:579,t:1527188984864};\\\", \\\"{x:1279,y:578,t:1527188984952};\\\", \\\"{x:1279,y:577,t:1527188984964};\\\", \\\"{x:1280,y:575,t:1527188984980};\\\", \\\"{x:1281,y:574,t:1527188984996};\\\", \\\"{x:1283,y:572,t:1527188985014};\\\", \\\"{x:1283,y:569,t:1527188985522};\\\", \\\"{x:1283,y:568,t:1527188985532};\\\", \\\"{x:1283,y:565,t:1527188985547};\\\", \\\"{x:1283,y:562,t:1527188985564};\\\", \\\"{x:1283,y:560,t:1527188985581};\\\", \\\"{x:1283,y:559,t:1527188985600};\\\", \\\"{x:1283,y:558,t:1527188985688};\\\", \\\"{x:1283,y:556,t:1527188985744};\\\", \\\"{x:1282,y:560,t:1527188992618};\\\", \\\"{x:1279,y:565,t:1527188992624};\\\", \\\"{x:1275,y:573,t:1527188992640};\\\", \\\"{x:1272,y:578,t:1527188992657};\\\", \\\"{x:1272,y:580,t:1527188992674};\\\", \\\"{x:1270,y:582,t:1527188992690};\\\", \\\"{x:1269,y:584,t:1527188992707};\\\", \\\"{x:1267,y:587,t:1527188992723};\\\", \\\"{x:1264,y:591,t:1527188992740};\\\", \\\"{x:1261,y:596,t:1527188992757};\\\", \\\"{x:1260,y:598,t:1527188992774};\\\", \\\"{x:1257,y:601,t:1527188992791};\\\", \\\"{x:1257,y:603,t:1527188992807};\\\", \\\"{x:1254,y:609,t:1527188992825};\\\", \\\"{x:1250,y:616,t:1527188992841};\\\", \\\"{x:1246,y:623,t:1527188992857};\\\", \\\"{x:1241,y:632,t:1527188992874};\\\", \\\"{x:1236,y:642,t:1527188992891};\\\", \\\"{x:1231,y:652,t:1527188992907};\\\", \\\"{x:1228,y:660,t:1527188992924};\\\", \\\"{x:1226,y:665,t:1527188992941};\\\", \\\"{x:1223,y:669,t:1527188992957};\\\", \\\"{x:1221,y:673,t:1527188992974};\\\", \\\"{x:1218,y:677,t:1527188992991};\\\", \\\"{x:1214,y:684,t:1527188993007};\\\", \\\"{x:1200,y:706,t:1527188993025};\\\", \\\"{x:1196,y:712,t:1527188993042};\\\", \\\"{x:1192,y:716,t:1527188993059};\\\", \\\"{x:1191,y:718,t:1527188993075};\\\", \\\"{x:1188,y:722,t:1527188993091};\\\", \\\"{x:1186,y:727,t:1527188993109};\\\", \\\"{x:1182,y:733,t:1527188993124};\\\", \\\"{x:1176,y:740,t:1527188993142};\\\", \\\"{x:1172,y:751,t:1527188993159};\\\", \\\"{x:1169,y:757,t:1527188993175};\\\", \\\"{x:1167,y:762,t:1527188993191};\\\", \\\"{x:1167,y:764,t:1527188993242};\\\", \\\"{x:1171,y:778,t:1527188993259};\\\", \\\"{x:1179,y:789,t:1527188993275};\\\", \\\"{x:1182,y:795,t:1527188993292};\\\", \\\"{x:1184,y:800,t:1527188993308};\\\", \\\"{x:1186,y:804,t:1527188993326};\\\", \\\"{x:1190,y:815,t:1527188993341};\\\", \\\"{x:1192,y:825,t:1527188993359};\\\", \\\"{x:1192,y:830,t:1527188993376};\\\", \\\"{x:1195,y:836,t:1527188993391};\\\", \\\"{x:1196,y:837,t:1527188993408};\\\", \\\"{x:1197,y:835,t:1527188993489};\\\", \\\"{x:1198,y:831,t:1527188993497};\\\", \\\"{x:1199,y:823,t:1527188993508};\\\", \\\"{x:1201,y:801,t:1527188993525};\\\", \\\"{x:1209,y:781,t:1527188993543};\\\", \\\"{x:1215,y:759,t:1527188993558};\\\", \\\"{x:1222,y:735,t:1527188993575};\\\", \\\"{x:1228,y:707,t:1527188993593};\\\", \\\"{x:1233,y:694,t:1527188993609};\\\", \\\"{x:1236,y:684,t:1527188993626};\\\", \\\"{x:1238,y:677,t:1527188993642};\\\", \\\"{x:1238,y:673,t:1527188993659};\\\", \\\"{x:1238,y:667,t:1527188993676};\\\", \\\"{x:1242,y:656,t:1527188993692};\\\", \\\"{x:1245,y:650,t:1527188993709};\\\", \\\"{x:1247,y:647,t:1527188993726};\\\", \\\"{x:1249,y:642,t:1527188993742};\\\", \\\"{x:1254,y:635,t:1527188993759};\\\", \\\"{x:1255,y:635,t:1527188993776};\\\", \\\"{x:1255,y:634,t:1527188993793};\\\", \\\"{x:1257,y:632,t:1527188993810};\\\", \\\"{x:1258,y:629,t:1527188993825};\\\", \\\"{x:1261,y:624,t:1527188993843};\\\", \\\"{x:1264,y:618,t:1527188993860};\\\", \\\"{x:1266,y:614,t:1527188993876};\\\", \\\"{x:1267,y:612,t:1527188993893};\\\", \\\"{x:1268,y:609,t:1527188993909};\\\", \\\"{x:1268,y:608,t:1527188993926};\\\", \\\"{x:1268,y:607,t:1527188993942};\\\", \\\"{x:1269,y:606,t:1527188993959};\\\", \\\"{x:1269,y:603,t:1527188993976};\\\", \\\"{x:1271,y:600,t:1527188993992};\\\", \\\"{x:1271,y:599,t:1527188994009};\\\", \\\"{x:1271,y:597,t:1527188994026};\\\", \\\"{x:1271,y:594,t:1527188994043};\\\", \\\"{x:1271,y:592,t:1527188994059};\\\", \\\"{x:1272,y:590,t:1527188994077};\\\", \\\"{x:1273,y:587,t:1527188994092};\\\", \\\"{x:1273,y:586,t:1527188994121};\\\", \\\"{x:1273,y:584,t:1527188994153};\\\", \\\"{x:1273,y:583,t:1527188994169};\\\", \\\"{x:1274,y:582,t:1527188994177};\\\", \\\"{x:1274,y:581,t:1527188994193};\\\", \\\"{x:1274,y:580,t:1527188994225};\\\", \\\"{x:1275,y:580,t:1527188994265};\\\", \\\"{x:1275,y:579,t:1527188994329};\\\", \\\"{x:1275,y:578,t:1527188994344};\\\", \\\"{x:1275,y:577,t:1527188994369};\\\", \\\"{x:1275,y:575,t:1527188994400};\\\", \\\"{x:1275,y:574,t:1527188994424};\\\", \\\"{x:1275,y:572,t:1527188994472};\\\", \\\"{x:1275,y:571,t:1527188994504};\\\", \\\"{x:1275,y:569,t:1527188994609};\\\", \\\"{x:1275,y:568,t:1527188994665};\\\", \\\"{x:1276,y:567,t:1527188994681};\\\", \\\"{x:1276,y:566,t:1527188994694};\\\", \\\"{x:1276,y:562,t:1527188994710};\\\", \\\"{x:1277,y:555,t:1527188994726};\\\", \\\"{x:1277,y:551,t:1527188994742};\\\", \\\"{x:1277,y:550,t:1527188994760};\\\", \\\"{x:1278,y:553,t:1527188995129};\\\", \\\"{x:1278,y:557,t:1527188995144};\\\", \\\"{x:1278,y:561,t:1527188995161};\\\", \\\"{x:1278,y:563,t:1527188995177};\\\", \\\"{x:1278,y:564,t:1527188995200};\\\", \\\"{x:1278,y:565,t:1527188995257};\\\", \\\"{x:1278,y:566,t:1527188995273};\\\", \\\"{x:1278,y:567,t:1527188995281};\\\", \\\"{x:1278,y:568,t:1527188995345};\\\", \\\"{x:1278,y:569,t:1527188995361};\\\", \\\"{x:1278,y:572,t:1527188995378};\\\", \\\"{x:1278,y:575,t:1527188995395};\\\", \\\"{x:1278,y:579,t:1527188995411};\\\", \\\"{x:1278,y:581,t:1527188995428};\\\", \\\"{x:1277,y:585,t:1527188995444};\\\", \\\"{x:1277,y:589,t:1527188995461};\\\", \\\"{x:1276,y:591,t:1527188995478};\\\", \\\"{x:1276,y:594,t:1527188995494};\\\", \\\"{x:1276,y:596,t:1527188995512};\\\", \\\"{x:1275,y:599,t:1527188995528};\\\", \\\"{x:1275,y:601,t:1527188995545};\\\", \\\"{x:1274,y:603,t:1527188995561};\\\", \\\"{x:1274,y:608,t:1527188995578};\\\", \\\"{x:1274,y:615,t:1527188995595};\\\", \\\"{x:1274,y:624,t:1527188995612};\\\", \\\"{x:1274,y:634,t:1527188995629};\\\", \\\"{x:1274,y:639,t:1527188995645};\\\", \\\"{x:1274,y:642,t:1527188995662};\\\", \\\"{x:1274,y:646,t:1527188995679};\\\", \\\"{x:1274,y:651,t:1527188995694};\\\", \\\"{x:1274,y:655,t:1527188995711};\\\", \\\"{x:1273,y:656,t:1527188995728};\\\", \\\"{x:1273,y:658,t:1527188995744};\\\", \\\"{x:1273,y:659,t:1527188995777};\\\", \\\"{x:1273,y:661,t:1527188995801};\\\", \\\"{x:1273,y:662,t:1527188995811};\\\", \\\"{x:1273,y:664,t:1527188995829};\\\", \\\"{x:1273,y:668,t:1527188995846};\\\", \\\"{x:1271,y:671,t:1527188995861};\\\", \\\"{x:1271,y:676,t:1527188995879};\\\", \\\"{x:1270,y:679,t:1527188995896};\\\", \\\"{x:1270,y:682,t:1527188995912};\\\", \\\"{x:1270,y:686,t:1527188995929};\\\", \\\"{x:1269,y:689,t:1527188995945};\\\", \\\"{x:1269,y:694,t:1527188995962};\\\", \\\"{x:1269,y:701,t:1527188995979};\\\", \\\"{x:1269,y:708,t:1527188995996};\\\", \\\"{x:1272,y:715,t:1527188996012};\\\", \\\"{x:1272,y:717,t:1527188996029};\\\", \\\"{x:1272,y:720,t:1527188996045};\\\", \\\"{x:1272,y:723,t:1527188996061};\\\", \\\"{x:1272,y:725,t:1527188996079};\\\", \\\"{x:1272,y:728,t:1527188996095};\\\", \\\"{x:1272,y:735,t:1527188996112};\\\", \\\"{x:1272,y:737,t:1527188996128};\\\", \\\"{x:1272,y:741,t:1527188996145};\\\", \\\"{x:1272,y:743,t:1527188996162};\\\", \\\"{x:1272,y:745,t:1527188996178};\\\", \\\"{x:1272,y:750,t:1527188996195};\\\", \\\"{x:1272,y:755,t:1527188996212};\\\", \\\"{x:1272,y:760,t:1527188996228};\\\", \\\"{x:1272,y:767,t:1527188996245};\\\", \\\"{x:1272,y:774,t:1527188996262};\\\", \\\"{x:1273,y:782,t:1527188996278};\\\", \\\"{x:1275,y:787,t:1527188996295};\\\", \\\"{x:1275,y:795,t:1527188996312};\\\", \\\"{x:1276,y:803,t:1527188996329};\\\", \\\"{x:1277,y:813,t:1527188996345};\\\", \\\"{x:1279,y:824,t:1527188996362};\\\", \\\"{x:1280,y:833,t:1527188996379};\\\", \\\"{x:1280,y:839,t:1527188996395};\\\", \\\"{x:1280,y:845,t:1527188996412};\\\", \\\"{x:1280,y:854,t:1527188996429};\\\", \\\"{x:1280,y:865,t:1527188996445};\\\", \\\"{x:1280,y:877,t:1527188996462};\\\", \\\"{x:1280,y:886,t:1527188996479};\\\", \\\"{x:1280,y:890,t:1527188996495};\\\", \\\"{x:1280,y:899,t:1527188996512};\\\", \\\"{x:1279,y:907,t:1527188996529};\\\", \\\"{x:1278,y:916,t:1527188996545};\\\", \\\"{x:1278,y:923,t:1527188996562};\\\", \\\"{x:1278,y:928,t:1527188996579};\\\", \\\"{x:1278,y:933,t:1527188996595};\\\", \\\"{x:1278,y:934,t:1527188996613};\\\", \\\"{x:1278,y:936,t:1527188996630};\\\", \\\"{x:1278,y:937,t:1527188996646};\\\", \\\"{x:1278,y:940,t:1527188996663};\\\", \\\"{x:1278,y:943,t:1527188996680};\\\", \\\"{x:1278,y:945,t:1527188996696};\\\", \\\"{x:1278,y:946,t:1527188996713};\\\", \\\"{x:1278,y:947,t:1527188996744};\\\", \\\"{x:1278,y:948,t:1527188996769};\\\", \\\"{x:1278,y:949,t:1527188996841};\\\", \\\"{x:1279,y:945,t:1527188996849};\\\", \\\"{x:1279,y:939,t:1527188996862};\\\", \\\"{x:1281,y:923,t:1527188996880};\\\", \\\"{x:1287,y:887,t:1527188996897};\\\", \\\"{x:1294,y:862,t:1527188996912};\\\", \\\"{x:1299,y:838,t:1527188996930};\\\", \\\"{x:1303,y:817,t:1527188996947};\\\", \\\"{x:1307,y:798,t:1527188996963};\\\", \\\"{x:1309,y:781,t:1527188996979};\\\", \\\"{x:1312,y:767,t:1527188996996};\\\", \\\"{x:1313,y:755,t:1527188997014};\\\", \\\"{x:1314,y:744,t:1527188997029};\\\", \\\"{x:1314,y:736,t:1527188997046};\\\", \\\"{x:1315,y:730,t:1527188997064};\\\", \\\"{x:1315,y:722,t:1527188997079};\\\", \\\"{x:1315,y:709,t:1527188997097};\\\", \\\"{x:1315,y:701,t:1527188997113};\\\", \\\"{x:1315,y:687,t:1527188997131};\\\", \\\"{x:1314,y:671,t:1527188997146};\\\", \\\"{x:1310,y:656,t:1527188997163};\\\", \\\"{x:1305,y:644,t:1527188997180};\\\", \\\"{x:1302,y:631,t:1527188997196};\\\", \\\"{x:1298,y:613,t:1527188997213};\\\", \\\"{x:1294,y:601,t:1527188997230};\\\", \\\"{x:1294,y:596,t:1527188997246};\\\", \\\"{x:1293,y:593,t:1527188997263};\\\", \\\"{x:1292,y:591,t:1527188997280};\\\", \\\"{x:1292,y:590,t:1527188997296};\\\", \\\"{x:1292,y:589,t:1527188997320};\\\", \\\"{x:1291,y:586,t:1527188997330};\\\", \\\"{x:1291,y:584,t:1527188997346};\\\", \\\"{x:1291,y:583,t:1527188997363};\\\", \\\"{x:1288,y:583,t:1527188997400};\\\", \\\"{x:1277,y:586,t:1527188997413};\\\", \\\"{x:1272,y:591,t:1527188997430};\\\", \\\"{x:1271,y:591,t:1527188997802};\\\", \\\"{x:1270,y:591,t:1527188997815};\\\", \\\"{x:1263,y:591,t:1527188997831};\\\", \\\"{x:1249,y:590,t:1527188997848};\\\", \\\"{x:1221,y:587,t:1527188997865};\\\", \\\"{x:1198,y:587,t:1527188997881};\\\", \\\"{x:1179,y:587,t:1527188997898};\\\", \\\"{x:1156,y:588,t:1527188997915};\\\", \\\"{x:1125,y:593,t:1527188997931};\\\", \\\"{x:1096,y:595,t:1527188997948};\\\", \\\"{x:1045,y:604,t:1527188997964};\\\", \\\"{x:1006,y:610,t:1527188997982};\\\", \\\"{x:963,y:611,t:1527188997998};\\\", \\\"{x:913,y:611,t:1527188998016};\\\", \\\"{x:852,y:611,t:1527188998033};\\\", \\\"{x:787,y:610,t:1527188998048};\\\", \\\"{x:705,y:591,t:1527188998066};\\\", \\\"{x:671,y:582,t:1527188998081};\\\", \\\"{x:641,y:571,t:1527188998098};\\\", \\\"{x:620,y:564,t:1527188998115};\\\", \\\"{x:605,y:558,t:1527188998132};\\\", \\\"{x:601,y:556,t:1527188998149};\\\", \\\"{x:600,y:556,t:1527188998165};\\\", \\\"{x:599,y:555,t:1527188998257};\\\", \\\"{x:599,y:553,t:1527188998265};\\\", \\\"{x:599,y:548,t:1527188998282};\\\", \\\"{x:599,y:542,t:1527188998299};\\\", \\\"{x:601,y:538,t:1527188998317};\\\", \\\"{x:606,y:529,t:1527188998332};\\\", \\\"{x:612,y:520,t:1527188998349};\\\", \\\"{x:618,y:511,t:1527188998367};\\\", \\\"{x:622,y:505,t:1527188998382};\\\", \\\"{x:623,y:503,t:1527188998399};\\\", \\\"{x:624,y:502,t:1527188998415};\\\", \\\"{x:626,y:504,t:1527188999713};\\\", \\\"{x:649,y:523,t:1527188999722};\\\", \\\"{x:674,y:544,t:1527188999733};\\\", \\\"{x:743,y:583,t:1527188999750};\\\", \\\"{x:804,y:612,t:1527188999768};\\\", \\\"{x:864,y:648,t:1527188999783};\\\", \\\"{x:960,y:704,t:1527188999800};\\\", \\\"{x:1000,y:726,t:1527188999817};\\\", \\\"{x:1019,y:739,t:1527188999833};\\\", \\\"{x:1033,y:747,t:1527188999850};\\\", \\\"{x:1045,y:754,t:1527188999867};\\\", \\\"{x:1053,y:760,t:1527188999883};\\\", \\\"{x:1056,y:763,t:1527188999900};\\\", \\\"{x:1057,y:763,t:1527188999977};\\\", \\\"{x:1057,y:764,t:1527188999984};\\\", \\\"{x:1060,y:766,t:1527189000001};\\\", \\\"{x:1069,y:769,t:1527189000017};\\\", \\\"{x:1078,y:772,t:1527189000034};\\\", \\\"{x:1087,y:774,t:1527189000051};\\\", \\\"{x:1103,y:777,t:1527189000068};\\\", \\\"{x:1122,y:779,t:1527189000084};\\\", \\\"{x:1140,y:782,t:1527189000101};\\\", \\\"{x:1158,y:784,t:1527189000118};\\\", \\\"{x:1168,y:785,t:1527189000135};\\\", \\\"{x:1173,y:785,t:1527189000150};\\\", \\\"{x:1174,y:785,t:1527189000233};\\\", \\\"{x:1175,y:785,t:1527189000240};\\\", \\\"{x:1176,y:785,t:1527189000256};\\\", \\\"{x:1177,y:785,t:1527189000273};\\\", \\\"{x:1178,y:784,t:1527189000289};\\\", \\\"{x:1178,y:783,t:1527189000320};\\\", \\\"{x:1179,y:782,t:1527189000335};\\\", \\\"{x:1180,y:778,t:1527189000352};\\\", \\\"{x:1180,y:775,t:1527189000368};\\\", \\\"{x:1183,y:767,t:1527189000386};\\\", \\\"{x:1183,y:766,t:1527189000417};\\\", \\\"{x:1183,y:765,t:1527189000440};\\\", \\\"{x:1184,y:772,t:1527189000602};\\\", \\\"{x:1185,y:805,t:1527189000619};\\\", \\\"{x:1190,y:836,t:1527189000635};\\\", \\\"{x:1197,y:864,t:1527189000652};\\\", \\\"{x:1202,y:888,t:1527189000669};\\\", \\\"{x:1203,y:903,t:1527189000685};\\\", \\\"{x:1206,y:916,t:1527189000702};\\\", \\\"{x:1208,y:926,t:1527189000719};\\\", \\\"{x:1209,y:930,t:1527189000735};\\\", \\\"{x:1209,y:933,t:1527189000752};\\\", \\\"{x:1210,y:934,t:1527189000881};\\\", \\\"{x:1211,y:933,t:1527189000889};\\\", \\\"{x:1212,y:925,t:1527189000902};\\\", \\\"{x:1213,y:917,t:1527189000919};\\\", \\\"{x:1214,y:900,t:1527189000936};\\\", \\\"{x:1214,y:891,t:1527189000952};\\\", \\\"{x:1215,y:879,t:1527189000969};\\\", \\\"{x:1215,y:871,t:1527189000985};\\\", \\\"{x:1215,y:866,t:1527189001002};\\\", \\\"{x:1215,y:858,t:1527189001019};\\\", \\\"{x:1215,y:850,t:1527189001036};\\\", \\\"{x:1216,y:844,t:1527189001052};\\\", \\\"{x:1219,y:838,t:1527189001069};\\\", \\\"{x:1219,y:836,t:1527189001086};\\\", \\\"{x:1219,y:839,t:1527189001177};\\\", \\\"{x:1219,y:848,t:1527189001185};\\\", \\\"{x:1219,y:875,t:1527189001202};\\\", \\\"{x:1217,y:895,t:1527189001219};\\\", \\\"{x:1216,y:911,t:1527189001235};\\\", \\\"{x:1216,y:922,t:1527189001252};\\\", \\\"{x:1216,y:935,t:1527189001268};\\\", \\\"{x:1216,y:941,t:1527189001285};\\\", \\\"{x:1216,y:944,t:1527189001302};\\\", \\\"{x:1216,y:946,t:1527189001318};\\\", \\\"{x:1215,y:946,t:1527189001400};\\\", \\\"{x:1211,y:945,t:1527189001408};\\\", \\\"{x:1207,y:942,t:1527189001418};\\\", \\\"{x:1182,y:931,t:1527189001435};\\\", \\\"{x:1112,y:898,t:1527189001452};\\\", \\\"{x:1033,y:870,t:1527189001468};\\\", \\\"{x:965,y:852,t:1527189001485};\\\", \\\"{x:906,y:834,t:1527189001502};\\\", \\\"{x:874,y:822,t:1527189001518};\\\", \\\"{x:846,y:810,t:1527189001535};\\\", \\\"{x:811,y:798,t:1527189001552};\\\", \\\"{x:784,y:789,t:1527189001569};\\\", \\\"{x:758,y:784,t:1527189001586};\\\", \\\"{x:733,y:779,t:1527189001602};\\\", \\\"{x:713,y:776,t:1527189001620};\\\", \\\"{x:694,y:773,t:1527189001635};\\\", \\\"{x:686,y:770,t:1527189001653};\\\", \\\"{x:684,y:769,t:1527189001670};\\\", \\\"{x:682,y:767,t:1527189001686};\\\", \\\"{x:679,y:765,t:1527189001703};\\\", \\\"{x:671,y:761,t:1527189001720};\\\", \\\"{x:657,y:754,t:1527189001735};\\\", \\\"{x:632,y:745,t:1527189001753};\\\", \\\"{x:620,y:740,t:1527189001769};\\\", \\\"{x:611,y:736,t:1527189001786};\\\", \\\"{x:603,y:733,t:1527189001803};\\\", \\\"{x:588,y:728,t:1527189001819};\\\", \\\"{x:575,y:724,t:1527189001835};\\\", \\\"{x:562,y:721,t:1527189001853};\\\", \\\"{x:556,y:718,t:1527189001869};\\\", \\\"{x:551,y:718,t:1527189001886};\\\", \\\"{x:547,y:718,t:1527189001902};\\\", \\\"{x:546,y:718,t:1527189001919};\\\", \\\"{x:544,y:718,t:1527189001936};\\\", \\\"{x:541,y:718,t:1527189001952};\\\", \\\"{x:539,y:719,t:1527189001969};\\\", \\\"{x:538,y:719,t:1527189001987};\\\", \\\"{x:536,y:719,t:1527189002002};\\\", \\\"{x:534,y:720,t:1527189002020};\\\", \\\"{x:531,y:723,t:1527189002036};\\\", \\\"{x:527,y:725,t:1527189002052};\\\", \\\"{x:525,y:726,t:1527189002070};\\\", \\\"{x:523,y:728,t:1527189002085};\\\", \\\"{x:521,y:730,t:1527189002102};\\\", \\\"{x:520,y:733,t:1527189002119};\\\", \\\"{x:517,y:736,t:1527189002135};\\\", \\\"{x:517,y:738,t:1527189002152};\\\", \\\"{x:518,y:738,t:1527189003033};\\\", \\\"{x:521,y:738,t:1527189003040};\\\", \\\"{x:522,y:737,t:1527189003053};\\\", \\\"{x:525,y:735,t:1527189003070};\\\", \\\"{x:532,y:734,t:1527189003087};\\\", \\\"{x:537,y:734,t:1527189003102};\\\", \\\"{x:545,y:734,t:1527189003119};\\\", \\\"{x:563,y:734,t:1527189003136};\\\", \\\"{x:569,y:734,t:1527189003153};\\\", \\\"{x:584,y:735,t:1527189003169};\\\", \\\"{x:592,y:737,t:1527189003186};\\\", \\\"{x:596,y:737,t:1527189003204};\\\", \\\"{x:597,y:737,t:1527189003219};\\\", \\\"{x:601,y:737,t:1527189003236};\\\", \\\"{x:603,y:737,t:1527189003254};\\\", \\\"{x:605,y:737,t:1527189003270};\\\", \\\"{x:612,y:737,t:1527189003286};\\\", \\\"{x:627,y:736,t:1527189003303};\\\", \\\"{x:632,y:736,t:1527189003320};\\\", \\\"{x:636,y:736,t:1527189003337};\\\", \\\"{x:638,y:735,t:1527189003353};\\\", \\\"{x:639,y:735,t:1527189003427};\\\", \\\"{x:641,y:734,t:1527189003453};\\\", \\\"{x:643,y:732,t:1527189003496};\\\", \\\"{x:646,y:730,t:1527189003503};\\\" ] }, { \\\"rt\\\": 21012, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 409965, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:654,y:725,t:1527189003614};\\\", \\\"{x:656,y:724,t:1527189003622};\\\", \\\"{x:658,y:722,t:1527189003637};\\\", \\\"{x:662,y:720,t:1527189003654};\\\", \\\"{x:665,y:715,t:1527189003670};\\\", \\\"{x:671,y:709,t:1527189003687};\\\", \\\"{x:681,y:701,t:1527189003710};\\\", \\\"{x:689,y:695,t:1527189003719};\\\", \\\"{x:696,y:691,t:1527189003737};\\\", \\\"{x:702,y:688,t:1527189003753};\\\", \\\"{x:712,y:684,t:1527189003771};\\\", \\\"{x:718,y:682,t:1527189003787};\\\", \\\"{x:723,y:682,t:1527189003804};\\\", \\\"{x:727,y:682,t:1527189003821};\\\", \\\"{x:734,y:682,t:1527189003836};\\\", \\\"{x:744,y:685,t:1527189003853};\\\", \\\"{x:760,y:695,t:1527189003871};\\\", \\\"{x:779,y:703,t:1527189003887};\\\", \\\"{x:798,y:710,t:1527189003903};\\\", \\\"{x:818,y:717,t:1527189003920};\\\", \\\"{x:826,y:721,t:1527189003937};\\\", \\\"{x:829,y:722,t:1527189003953};\\\", \\\"{x:830,y:723,t:1527189003971};\\\", \\\"{x:831,y:723,t:1527189003988};\\\", \\\"{x:833,y:723,t:1527189004488};\\\", \\\"{x:847,y:736,t:1527189004504};\\\", \\\"{x:863,y:757,t:1527189004521};\\\", \\\"{x:881,y:780,t:1527189004538};\\\", \\\"{x:896,y:795,t:1527189004555};\\\", \\\"{x:901,y:800,t:1527189004570};\\\", \\\"{x:901,y:801,t:1527189005105};\\\", \\\"{x:902,y:802,t:1527189005122};\\\", \\\"{x:903,y:802,t:1527189005138};\\\", \\\"{x:906,y:790,t:1527189005155};\\\", \\\"{x:904,y:765,t:1527189005171};\\\", \\\"{x:883,y:740,t:1527189005188};\\\", \\\"{x:858,y:724,t:1527189005204};\\\", \\\"{x:853,y:720,t:1527189005221};\\\", \\\"{x:838,y:708,t:1527189005239};\\\", \\\"{x:821,y:696,t:1527189005255};\\\", \\\"{x:801,y:683,t:1527189005272};\\\", \\\"{x:798,y:680,t:1527189005289};\\\", \\\"{x:798,y:678,t:1527189005329};\\\", \\\"{x:803,y:676,t:1527189005339};\\\", \\\"{x:816,y:673,t:1527189005355};\\\", \\\"{x:824,y:673,t:1527189005371};\\\", \\\"{x:833,y:675,t:1527189005389};\\\", \\\"{x:841,y:679,t:1527189005404};\\\", \\\"{x:848,y:679,t:1527189005421};\\\", \\\"{x:861,y:679,t:1527189005439};\\\", \\\"{x:883,y:688,t:1527189005454};\\\", \\\"{x:903,y:697,t:1527189005472};\\\", \\\"{x:912,y:703,t:1527189005488};\\\", \\\"{x:913,y:703,t:1527189005841};\\\", \\\"{x:914,y:702,t:1527189005856};\\\", \\\"{x:915,y:701,t:1527189005872};\\\", \\\"{x:917,y:701,t:1527189005920};\\\", \\\"{x:920,y:701,t:1527189005927};\\\", \\\"{x:925,y:701,t:1527189005938};\\\", \\\"{x:936,y:703,t:1527189005956};\\\", \\\"{x:946,y:704,t:1527189005972};\\\", \\\"{x:951,y:705,t:1527189005988};\\\", \\\"{x:957,y:705,t:1527189006006};\\\", \\\"{x:965,y:705,t:1527189006022};\\\", \\\"{x:971,y:707,t:1527189006038};\\\", \\\"{x:974,y:708,t:1527189006056};\\\", \\\"{x:975,y:708,t:1527189006177};\\\", \\\"{x:977,y:708,t:1527189017313};\\\", \\\"{x:981,y:708,t:1527189017321};\\\", \\\"{x:986,y:708,t:1527189017331};\\\", \\\"{x:994,y:708,t:1527189017348};\\\", \\\"{x:1008,y:708,t:1527189017364};\\\", \\\"{x:1027,y:708,t:1527189017382};\\\", \\\"{x:1051,y:708,t:1527189017398};\\\", \\\"{x:1091,y:707,t:1527189017416};\\\", \\\"{x:1133,y:707,t:1527189017431};\\\", \\\"{x:1214,y:720,t:1527189017449};\\\", \\\"{x:1242,y:731,t:1527189017465};\\\", \\\"{x:1252,y:735,t:1527189017482};\\\", \\\"{x:1252,y:737,t:1527189017529};\\\", \\\"{x:1253,y:744,t:1527189017536};\\\", \\\"{x:1258,y:754,t:1527189017549};\\\", \\\"{x:1272,y:772,t:1527189017565};\\\", \\\"{x:1287,y:786,t:1527189017582};\\\", \\\"{x:1308,y:800,t:1527189017598};\\\", \\\"{x:1313,y:804,t:1527189017616};\\\", \\\"{x:1314,y:804,t:1527189018337};\\\", \\\"{x:1315,y:804,t:1527189018349};\\\", \\\"{x:1317,y:803,t:1527189018366};\\\", \\\"{x:1318,y:802,t:1527189018382};\\\", \\\"{x:1318,y:801,t:1527189018400};\\\", \\\"{x:1319,y:801,t:1527189018416};\\\", \\\"{x:1320,y:801,t:1527189018432};\\\", \\\"{x:1321,y:801,t:1527189018464};\\\", \\\"{x:1323,y:801,t:1527189018521};\\\", \\\"{x:1324,y:801,t:1527189018552};\\\", \\\"{x:1326,y:801,t:1527189018592};\\\", \\\"{x:1327,y:801,t:1527189018665};\\\", \\\"{x:1329,y:801,t:1527189018705};\\\", \\\"{x:1330,y:801,t:1527189018716};\\\", \\\"{x:1333,y:800,t:1527189018733};\\\", \\\"{x:1334,y:799,t:1527189018750};\\\", \\\"{x:1335,y:797,t:1527189018766};\\\", \\\"{x:1337,y:796,t:1527189018782};\\\", \\\"{x:1339,y:795,t:1527189018800};\\\", \\\"{x:1339,y:794,t:1527189018816};\\\", \\\"{x:1340,y:793,t:1527189018832};\\\", \\\"{x:1341,y:792,t:1527189018849};\\\", \\\"{x:1341,y:791,t:1527189018866};\\\", \\\"{x:1342,y:790,t:1527189018883};\\\", \\\"{x:1343,y:789,t:1527189018900};\\\", \\\"{x:1343,y:788,t:1527189018928};\\\", \\\"{x:1343,y:787,t:1527189018936};\\\", \\\"{x:1344,y:786,t:1527189018961};\\\", \\\"{x:1344,y:784,t:1527189018976};\\\", \\\"{x:1345,y:783,t:1527189018992};\\\", \\\"{x:1345,y:782,t:1527189019000};\\\", \\\"{x:1346,y:780,t:1527189019033};\\\", \\\"{x:1347,y:781,t:1527189019200};\\\", \\\"{x:1349,y:786,t:1527189019216};\\\", \\\"{x:1350,y:797,t:1527189019233};\\\", \\\"{x:1354,y:815,t:1527189019248};\\\", \\\"{x:1355,y:834,t:1527189019266};\\\", \\\"{x:1356,y:851,t:1527189019283};\\\", \\\"{x:1358,y:869,t:1527189019299};\\\", \\\"{x:1362,y:891,t:1527189019316};\\\", \\\"{x:1366,y:912,t:1527189019333};\\\", \\\"{x:1368,y:929,t:1527189019349};\\\", \\\"{x:1368,y:942,t:1527189019367};\\\", \\\"{x:1370,y:953,t:1527189019383};\\\", \\\"{x:1370,y:959,t:1527189019399};\\\", \\\"{x:1371,y:964,t:1527189019416};\\\", \\\"{x:1372,y:965,t:1527189019433};\\\", \\\"{x:1372,y:966,t:1527189019456};\\\", \\\"{x:1372,y:962,t:1527189019601};\\\", \\\"{x:1367,y:953,t:1527189019617};\\\", \\\"{x:1362,y:944,t:1527189019633};\\\", \\\"{x:1358,y:934,t:1527189019650};\\\", \\\"{x:1353,y:928,t:1527189019666};\\\", \\\"{x:1351,y:922,t:1527189019683};\\\", \\\"{x:1350,y:914,t:1527189019700};\\\", \\\"{x:1350,y:899,t:1527189019716};\\\", \\\"{x:1349,y:884,t:1527189019733};\\\", \\\"{x:1346,y:866,t:1527189019750};\\\", \\\"{x:1345,y:848,t:1527189019766};\\\", \\\"{x:1344,y:843,t:1527189019784};\\\", \\\"{x:1342,y:840,t:1527189019801};\\\", \\\"{x:1342,y:837,t:1527189019817};\\\", \\\"{x:1342,y:833,t:1527189019834};\\\", \\\"{x:1342,y:830,t:1527189019850};\\\", \\\"{x:1344,y:824,t:1527189019867};\\\", \\\"{x:1347,y:816,t:1527189019884};\\\", \\\"{x:1350,y:809,t:1527189019901};\\\", \\\"{x:1352,y:803,t:1527189019916};\\\", \\\"{x:1355,y:799,t:1527189019933};\\\", \\\"{x:1360,y:791,t:1527189019950};\\\", \\\"{x:1364,y:786,t:1527189019967};\\\", \\\"{x:1366,y:783,t:1527189019984};\\\", \\\"{x:1370,y:775,t:1527189020001};\\\", \\\"{x:1372,y:773,t:1527189020017};\\\", \\\"{x:1372,y:772,t:1527189020034};\\\", \\\"{x:1373,y:772,t:1527189020050};\\\", \\\"{x:1372,y:772,t:1527189020112};\\\", \\\"{x:1371,y:773,t:1527189020121};\\\", \\\"{x:1369,y:775,t:1527189020133};\\\", \\\"{x:1362,y:782,t:1527189020150};\\\", \\\"{x:1356,y:786,t:1527189020167};\\\", \\\"{x:1347,y:793,t:1527189020183};\\\", \\\"{x:1317,y:804,t:1527189020200};\\\", \\\"{x:1287,y:810,t:1527189020217};\\\", \\\"{x:1253,y:811,t:1527189020233};\\\", \\\"{x:1213,y:811,t:1527189020250};\\\", \\\"{x:1163,y:811,t:1527189020268};\\\", \\\"{x:1097,y:807,t:1527189020283};\\\", \\\"{x:1046,y:789,t:1527189020300};\\\", \\\"{x:981,y:766,t:1527189020317};\\\", \\\"{x:940,y:749,t:1527189020333};\\\", \\\"{x:909,y:734,t:1527189020350};\\\", \\\"{x:888,y:726,t:1527189020367};\\\", \\\"{x:864,y:718,t:1527189020383};\\\", \\\"{x:801,y:691,t:1527189020400};\\\", \\\"{x:738,y:663,t:1527189020417};\\\", \\\"{x:680,y:639,t:1527189020434};\\\", \\\"{x:622,y:615,t:1527189020451};\\\", \\\"{x:583,y:604,t:1527189020467};\\\", \\\"{x:566,y:594,t:1527189020484};\\\", \\\"{x:553,y:589,t:1527189020501};\\\", \\\"{x:544,y:588,t:1527189020518};\\\", \\\"{x:535,y:588,t:1527189020534};\\\", \\\"{x:527,y:588,t:1527189020551};\\\", \\\"{x:520,y:590,t:1527189020567};\\\", \\\"{x:508,y:596,t:1527189020584};\\\", \\\"{x:504,y:599,t:1527189020601};\\\", \\\"{x:500,y:602,t:1527189020618};\\\", \\\"{x:499,y:606,t:1527189020634};\\\", \\\"{x:496,y:615,t:1527189020652};\\\", \\\"{x:491,y:630,t:1527189020668};\\\", \\\"{x:490,y:645,t:1527189020685};\\\", \\\"{x:489,y:656,t:1527189020701};\\\", \\\"{x:486,y:664,t:1527189020718};\\\", \\\"{x:485,y:671,t:1527189020735};\\\", \\\"{x:484,y:676,t:1527189020751};\\\", \\\"{x:478,y:683,t:1527189020768};\\\", \\\"{x:472,y:692,t:1527189020784};\\\", \\\"{x:461,y:700,t:1527189020801};\\\", \\\"{x:447,y:705,t:1527189020818};\\\", \\\"{x:432,y:708,t:1527189020834};\\\", \\\"{x:423,y:709,t:1527189020851};\\\", \\\"{x:416,y:709,t:1527189020869};\\\", \\\"{x:412,y:709,t:1527189020884};\\\", \\\"{x:412,y:708,t:1527189020968};\\\", \\\"{x:412,y:703,t:1527189020985};\\\", \\\"{x:414,y:697,t:1527189021002};\\\", \\\"{x:419,y:690,t:1527189021019};\\\", \\\"{x:423,y:684,t:1527189021035};\\\", \\\"{x:426,y:681,t:1527189021051};\\\", \\\"{x:426,y:678,t:1527189021068};\\\", \\\"{x:428,y:674,t:1527189021084};\\\", \\\"{x:428,y:673,t:1527189021100};\\\", \\\"{x:429,y:671,t:1527189021118};\\\", \\\"{x:429,y:670,t:1527189021151};\\\", \\\"{x:429,y:668,t:1527189021168};\\\", \\\"{x:429,y:667,t:1527189021191};\\\", \\\"{x:429,y:666,t:1527189021201};\\\", \\\"{x:429,y:664,t:1527189021449};\\\", \\\"{x:426,y:662,t:1527189021456};\\\", \\\"{x:426,y:660,t:1527189021468};\\\", \\\"{x:423,y:658,t:1527189021485};\\\", \\\"{x:420,y:655,t:1527189021502};\\\", \\\"{x:415,y:652,t:1527189021519};\\\", \\\"{x:412,y:647,t:1527189021535};\\\", \\\"{x:409,y:643,t:1527189021551};\\\", \\\"{x:406,y:637,t:1527189021569};\\\", \\\"{x:404,y:634,t:1527189021585};\\\", \\\"{x:401,y:631,t:1527189021603};\\\", \\\"{x:397,y:626,t:1527189021618};\\\", \\\"{x:394,y:622,t:1527189021636};\\\", \\\"{x:393,y:617,t:1527189021651};\\\", \\\"{x:389,y:611,t:1527189021668};\\\", \\\"{x:389,y:605,t:1527189021685};\\\", \\\"{x:387,y:603,t:1527189021702};\\\", \\\"{x:387,y:602,t:1527189021718};\\\", \\\"{x:387,y:601,t:1527189021735};\\\", \\\"{x:387,y:597,t:1527189021752};\\\", \\\"{x:387,y:594,t:1527189021769};\\\", \\\"{x:387,y:588,t:1527189021785};\\\", \\\"{x:391,y:580,t:1527189021802};\\\", \\\"{x:392,y:574,t:1527189021819};\\\", \\\"{x:393,y:573,t:1527189021835};\\\", \\\"{x:391,y:573,t:1527189021880};\\\", \\\"{x:387,y:573,t:1527189021903};\\\", \\\"{x:376,y:573,t:1527189021919};\\\", \\\"{x:363,y:573,t:1527189021936};\\\", \\\"{x:361,y:573,t:1527189021951};\\\", \\\"{x:360,y:573,t:1527189021968};\\\", \\\"{x:348,y:579,t:1527189021985};\\\", \\\"{x:335,y:576,t:1527189022002};\\\", \\\"{x:334,y:576,t:1527189022019};\\\", \\\"{x:334,y:575,t:1527189022105};\\\", \\\"{x:334,y:573,t:1527189022120};\\\", \\\"{x:334,y:571,t:1527189022135};\\\", \\\"{x:325,y:548,t:1527189022156};\\\", \\\"{x:312,y:535,t:1527189022168};\\\", \\\"{x:303,y:525,t:1527189022185};\\\", \\\"{x:295,y:518,t:1527189022202};\\\", \\\"{x:287,y:510,t:1527189022220};\\\", \\\"{x:272,y:502,t:1527189022236};\\\", \\\"{x:262,y:497,t:1527189022252};\\\", \\\"{x:254,y:494,t:1527189022269};\\\", \\\"{x:245,y:491,t:1527189022286};\\\", \\\"{x:237,y:488,t:1527189022302};\\\", \\\"{x:232,y:487,t:1527189022319};\\\", \\\"{x:229,y:487,t:1527189022335};\\\", \\\"{x:228,y:487,t:1527189022352};\\\", \\\"{x:225,y:487,t:1527189022369};\\\", \\\"{x:223,y:487,t:1527189022386};\\\", \\\"{x:216,y:488,t:1527189022402};\\\", \\\"{x:208,y:490,t:1527189022419};\\\", \\\"{x:200,y:491,t:1527189022436};\\\", \\\"{x:193,y:493,t:1527189022452};\\\", \\\"{x:189,y:494,t:1527189022469};\\\", \\\"{x:188,y:494,t:1527189022488};\\\", \\\"{x:188,y:496,t:1527189022721};\\\", \\\"{x:220,y:529,t:1527189022737};\\\", \\\"{x:273,y:577,t:1527189022754};\\\", \\\"{x:335,y:624,t:1527189022770};\\\", \\\"{x:403,y:659,t:1527189022786};\\\", \\\"{x:469,y:688,t:1527189022804};\\\", \\\"{x:530,y:714,t:1527189022819};\\\", \\\"{x:577,y:736,t:1527189022836};\\\", \\\"{x:599,y:749,t:1527189022853};\\\", \\\"{x:603,y:753,t:1527189022869};\\\", \\\"{x:602,y:753,t:1527189022928};\\\", \\\"{x:593,y:753,t:1527189022936};\\\", \\\"{x:573,y:744,t:1527189022954};\\\", \\\"{x:543,y:732,t:1527189022971};\\\", \\\"{x:514,y:721,t:1527189022986};\\\", \\\"{x:485,y:706,t:1527189023004};\\\", \\\"{x:445,y:681,t:1527189023020};\\\", \\\"{x:403,y:653,t:1527189023036};\\\", \\\"{x:356,y:624,t:1527189023053};\\\", \\\"{x:313,y:591,t:1527189023070};\\\", \\\"{x:289,y:573,t:1527189023086};\\\", \\\"{x:270,y:557,t:1527189023103};\\\", \\\"{x:248,y:541,t:1527189023119};\\\", \\\"{x:221,y:522,t:1527189023137};\\\", \\\"{x:207,y:516,t:1527189023153};\\\", \\\"{x:196,y:511,t:1527189023170};\\\", \\\"{x:188,y:508,t:1527189023186};\\\", \\\"{x:183,y:506,t:1527189023203};\\\", \\\"{x:180,y:504,t:1527189023220};\\\", \\\"{x:175,y:504,t:1527189023263};\\\", \\\"{x:171,y:503,t:1527189023271};\\\", \\\"{x:167,y:503,t:1527189023287};\\\", \\\"{x:158,y:503,t:1527189023303};\\\", \\\"{x:155,y:501,t:1527189023320};\\\", \\\"{x:154,y:501,t:1527189023337};\\\", \\\"{x:154,y:500,t:1527189023386};\\\", \\\"{x:155,y:500,t:1527189023403};\\\", \\\"{x:156,y:500,t:1527189023420};\\\", \\\"{x:156,y:500,t:1527189023469};\\\", \\\"{x:159,y:501,t:1527189023560};\\\", \\\"{x:166,y:510,t:1527189023570};\\\", \\\"{x:191,y:548,t:1527189023588};\\\", \\\"{x:232,y:607,t:1527189023604};\\\", \\\"{x:285,y:668,t:1527189023620};\\\", \\\"{x:319,y:706,t:1527189023637};\\\", \\\"{x:353,y:737,t:1527189023653};\\\", \\\"{x:376,y:753,t:1527189023670};\\\", \\\"{x:395,y:764,t:1527189023687};\\\", \\\"{x:408,y:777,t:1527189023703};\\\", \\\"{x:437,y:800,t:1527189023720};\\\", \\\"{x:455,y:813,t:1527189023737};\\\", \\\"{x:467,y:820,t:1527189023753};\\\", \\\"{x:471,y:822,t:1527189023770};\\\", \\\"{x:476,y:823,t:1527189023788};\\\", \\\"{x:479,y:823,t:1527189023804};\\\", \\\"{x:481,y:823,t:1527189023821};\\\", \\\"{x:482,y:823,t:1527189023837};\\\", \\\"{x:484,y:823,t:1527189023854};\\\", \\\"{x:488,y:818,t:1527189023871};\\\", \\\"{x:491,y:812,t:1527189023887};\\\", \\\"{x:497,y:800,t:1527189023904};\\\", \\\"{x:499,y:797,t:1527189023921};\\\", \\\"{x:500,y:794,t:1527189023937};\\\", \\\"{x:500,y:791,t:1527189023954};\\\", \\\"{x:503,y:787,t:1527189023970};\\\", \\\"{x:507,y:778,t:1527189023988};\\\", \\\"{x:509,y:771,t:1527189024004};\\\", \\\"{x:511,y:767,t:1527189024020};\\\", \\\"{x:512,y:764,t:1527189024037};\\\", \\\"{x:512,y:762,t:1527189024054};\\\", \\\"{x:514,y:760,t:1527189024070};\\\", \\\"{x:514,y:759,t:1527189024087};\\\", \\\"{x:514,y:758,t:1527189024431};\\\", \\\"{x:518,y:754,t:1527189024440};\\\", \\\"{x:522,y:752,t:1527189024454};\\\", \\\"{x:525,y:751,t:1527189024471};\\\", \\\"{x:526,y:750,t:1527189024487};\\\" ] }, { \\\"rt\\\": 34051, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 445280, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -F -H -02 PM-X -X -X -02 PM-G -F -F -F -3-J -E -11 AM-10 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:754,t:1527189027104};\\\", \\\"{x:554,y:778,t:1527189027129};\\\", \\\"{x:565,y:786,t:1527189027140};\\\", \\\"{x:591,y:799,t:1527189027156};\\\", \\\"{x:615,y:810,t:1527189027173};\\\", \\\"{x:639,y:815,t:1527189027189};\\\", \\\"{x:670,y:825,t:1527189027206};\\\", \\\"{x:711,y:835,t:1527189027223};\\\", \\\"{x:743,y:845,t:1527189027239};\\\", \\\"{x:785,y:850,t:1527189027256};\\\", \\\"{x:839,y:858,t:1527189027273};\\\", \\\"{x:899,y:863,t:1527189027290};\\\", \\\"{x:975,y:867,t:1527189027306};\\\", \\\"{x:1067,y:867,t:1527189027323};\\\", \\\"{x:1151,y:872,t:1527189027340};\\\", \\\"{x:1236,y:878,t:1527189027357};\\\", \\\"{x:1311,y:880,t:1527189027373};\\\", \\\"{x:1373,y:880,t:1527189027390};\\\", \\\"{x:1473,y:880,t:1527189027408};\\\", \\\"{x:1534,y:880,t:1527189027424};\\\", \\\"{x:1571,y:880,t:1527189027440};\\\", \\\"{x:1593,y:880,t:1527189027457};\\\", \\\"{x:1597,y:880,t:1527189027473};\\\", \\\"{x:1598,y:879,t:1527189028064};\\\", \\\"{x:1598,y:877,t:1527189028080};\\\", \\\"{x:1598,y:876,t:1527189028092};\\\", \\\"{x:1598,y:875,t:1527189028109};\\\", \\\"{x:1598,y:874,t:1527189028124};\\\", \\\"{x:1599,y:872,t:1527189028142};\\\", \\\"{x:1599,y:870,t:1527189028225};\\\", \\\"{x:1600,y:868,t:1527189028529};\\\", \\\"{x:1600,y:867,t:1527189028543};\\\", \\\"{x:1600,y:866,t:1527189028576};\\\", \\\"{x:1601,y:864,t:1527189028592};\\\", \\\"{x:1602,y:863,t:1527189028609};\\\", \\\"{x:1604,y:859,t:1527189028626};\\\", \\\"{x:1604,y:857,t:1527189028643};\\\", \\\"{x:1607,y:852,t:1527189028659};\\\", \\\"{x:1614,y:843,t:1527189028676};\\\", \\\"{x:1621,y:832,t:1527189028693};\\\", \\\"{x:1632,y:816,t:1527189028709};\\\", \\\"{x:1643,y:801,t:1527189028725};\\\", \\\"{x:1652,y:791,t:1527189028742};\\\", \\\"{x:1659,y:782,t:1527189028760};\\\", \\\"{x:1663,y:777,t:1527189028776};\\\", \\\"{x:1665,y:773,t:1527189028793};\\\", \\\"{x:1667,y:766,t:1527189028810};\\\", \\\"{x:1669,y:759,t:1527189028826};\\\", \\\"{x:1676,y:746,t:1527189028843};\\\", \\\"{x:1683,y:733,t:1527189028860};\\\", \\\"{x:1689,y:724,t:1527189028876};\\\", \\\"{x:1693,y:717,t:1527189028893};\\\", \\\"{x:1702,y:709,t:1527189028910};\\\", \\\"{x:1707,y:703,t:1527189028927};\\\", \\\"{x:1709,y:700,t:1527189028943};\\\", \\\"{x:1712,y:696,t:1527189028961};\\\", \\\"{x:1716,y:690,t:1527189028976};\\\", \\\"{x:1721,y:686,t:1527189028993};\\\", \\\"{x:1731,y:679,t:1527189029010};\\\", \\\"{x:1737,y:675,t:1527189029027};\\\", \\\"{x:1740,y:671,t:1527189029043};\\\", \\\"{x:1741,y:670,t:1527189029059};\\\", \\\"{x:1741,y:665,t:1527189029077};\\\", \\\"{x:1738,y:659,t:1527189029094};\\\", \\\"{x:1730,y:655,t:1527189029110};\\\", \\\"{x:1721,y:647,t:1527189029127};\\\", \\\"{x:1721,y:641,t:1527189029144};\\\", \\\"{x:1721,y:642,t:1527189031161};\\\", \\\"{x:1721,y:645,t:1527189032081};\\\", \\\"{x:1711,y:651,t:1527189032098};\\\", \\\"{x:1697,y:660,t:1527189032115};\\\", \\\"{x:1681,y:666,t:1527189032130};\\\", \\\"{x:1664,y:673,t:1527189032148};\\\", \\\"{x:1658,y:676,t:1527189032165};\\\", \\\"{x:1650,y:679,t:1527189032182};\\\", \\\"{x:1641,y:683,t:1527189032197};\\\", \\\"{x:1625,y:687,t:1527189032215};\\\", \\\"{x:1592,y:696,t:1527189032232};\\\", \\\"{x:1569,y:702,t:1527189032248};\\\", \\\"{x:1554,y:705,t:1527189032265};\\\", \\\"{x:1545,y:707,t:1527189032282};\\\", \\\"{x:1543,y:707,t:1527189032298};\\\", \\\"{x:1541,y:707,t:1527189032344};\\\", \\\"{x:1537,y:707,t:1527189032352};\\\", \\\"{x:1534,y:707,t:1527189032365};\\\", \\\"{x:1527,y:707,t:1527189032382};\\\", \\\"{x:1524,y:707,t:1527189032398};\\\", \\\"{x:1523,y:707,t:1527189032415};\\\", \\\"{x:1519,y:707,t:1527189032431};\\\", \\\"{x:1515,y:707,t:1527189032449};\\\", \\\"{x:1502,y:707,t:1527189032465};\\\", \\\"{x:1481,y:707,t:1527189032481};\\\", \\\"{x:1465,y:707,t:1527189032499};\\\", \\\"{x:1456,y:707,t:1527189032514};\\\", \\\"{x:1448,y:707,t:1527189032532};\\\", \\\"{x:1441,y:707,t:1527189032548};\\\", \\\"{x:1436,y:707,t:1527189032565};\\\", \\\"{x:1429,y:706,t:1527189032582};\\\", \\\"{x:1423,y:704,t:1527189032599};\\\", \\\"{x:1417,y:703,t:1527189032616};\\\", \\\"{x:1413,y:703,t:1527189032632};\\\", \\\"{x:1406,y:703,t:1527189032649};\\\", \\\"{x:1402,y:703,t:1527189032666};\\\", \\\"{x:1400,y:703,t:1527189032682};\\\", \\\"{x:1395,y:703,t:1527189032699};\\\", \\\"{x:1391,y:704,t:1527189032716};\\\", \\\"{x:1385,y:704,t:1527189032731};\\\", \\\"{x:1376,y:704,t:1527189032749};\\\", \\\"{x:1372,y:704,t:1527189032766};\\\", \\\"{x:1371,y:704,t:1527189032783};\\\", \\\"{x:1368,y:704,t:1527189032849};\\\", \\\"{x:1367,y:706,t:1527189033065};\\\", \\\"{x:1368,y:716,t:1527189033073};\\\", \\\"{x:1375,y:736,t:1527189033083};\\\", \\\"{x:1377,y:765,t:1527189033100};\\\", \\\"{x:1378,y:794,t:1527189033115};\\\", \\\"{x:1376,y:824,t:1527189033133};\\\", \\\"{x:1374,y:850,t:1527189033150};\\\", \\\"{x:1374,y:866,t:1527189033166};\\\", \\\"{x:1374,y:875,t:1527189033183};\\\", \\\"{x:1374,y:879,t:1527189033200};\\\", \\\"{x:1374,y:883,t:1527189033216};\\\", \\\"{x:1375,y:887,t:1527189033233};\\\", \\\"{x:1375,y:888,t:1527189033321};\\\", \\\"{x:1373,y:887,t:1527189033377};\\\", \\\"{x:1373,y:885,t:1527189033384};\\\", \\\"{x:1371,y:878,t:1527189033400};\\\", \\\"{x:1368,y:869,t:1527189033418};\\\", \\\"{x:1362,y:858,t:1527189033434};\\\", \\\"{x:1356,y:843,t:1527189033450};\\\", \\\"{x:1354,y:833,t:1527189033467};\\\", \\\"{x:1351,y:821,t:1527189033484};\\\", \\\"{x:1351,y:806,t:1527189033500};\\\", \\\"{x:1349,y:795,t:1527189033517};\\\", \\\"{x:1347,y:780,t:1527189033534};\\\", \\\"{x:1344,y:769,t:1527189033550};\\\", \\\"{x:1342,y:762,t:1527189033569};\\\", \\\"{x:1341,y:758,t:1527189033586};\\\", \\\"{x:1341,y:756,t:1527189033600};\\\", \\\"{x:1341,y:752,t:1527189033617};\\\", \\\"{x:1341,y:751,t:1527189033634};\\\", \\\"{x:1341,y:749,t:1527189033651};\\\", \\\"{x:1341,y:746,t:1527189033668};\\\", \\\"{x:1341,y:745,t:1527189033684};\\\", \\\"{x:1341,y:743,t:1527189033701};\\\", \\\"{x:1341,y:740,t:1527189033717};\\\", \\\"{x:1341,y:739,t:1527189033734};\\\", \\\"{x:1341,y:735,t:1527189033751};\\\", \\\"{x:1341,y:730,t:1527189033767};\\\", \\\"{x:1341,y:728,t:1527189033784};\\\", \\\"{x:1341,y:727,t:1527189033801};\\\", \\\"{x:1341,y:726,t:1527189033817};\\\", \\\"{x:1341,y:725,t:1527189033834};\\\", \\\"{x:1341,y:723,t:1527189033852};\\\", \\\"{x:1341,y:719,t:1527189033869};\\\", \\\"{x:1341,y:713,t:1527189033884};\\\", \\\"{x:1341,y:711,t:1527189033901};\\\", \\\"{x:1341,y:709,t:1527189033918};\\\", \\\"{x:1341,y:708,t:1527189033953};\\\", \\\"{x:1341,y:705,t:1527189033968};\\\", \\\"{x:1342,y:703,t:1527189033984};\\\", \\\"{x:1342,y:702,t:1527189034001};\\\", \\\"{x:1342,y:700,t:1527189034018};\\\", \\\"{x:1343,y:699,t:1527189034244};\\\", \\\"{x:1344,y:699,t:1527189034255};\\\", \\\"{x:1345,y:699,t:1527189034276};\\\", \\\"{x:1347,y:699,t:1527189034308};\\\", \\\"{x:1348,y:698,t:1527189034322};\\\", \\\"{x:1349,y:698,t:1527189034339};\\\", \\\"{x:1354,y:696,t:1527189034356};\\\", \\\"{x:1360,y:696,t:1527189034372};\\\", \\\"{x:1368,y:696,t:1527189034389};\\\", \\\"{x:1380,y:696,t:1527189034406};\\\", \\\"{x:1388,y:696,t:1527189034422};\\\", \\\"{x:1398,y:696,t:1527189034439};\\\", \\\"{x:1406,y:696,t:1527189034456};\\\", \\\"{x:1411,y:696,t:1527189034473};\\\", \\\"{x:1417,y:698,t:1527189034489};\\\", \\\"{x:1426,y:702,t:1527189034506};\\\", \\\"{x:1446,y:711,t:1527189034524};\\\", \\\"{x:1498,y:740,t:1527189034539};\\\", \\\"{x:1596,y:797,t:1527189034556};\\\", \\\"{x:1629,y:816,t:1527189034572};\\\", \\\"{x:1639,y:825,t:1527189034590};\\\", \\\"{x:1640,y:829,t:1527189034606};\\\", \\\"{x:1640,y:839,t:1527189034623};\\\", \\\"{x:1640,y:862,t:1527189034639};\\\", \\\"{x:1640,y:890,t:1527189034656};\\\", \\\"{x:1640,y:918,t:1527189034674};\\\", \\\"{x:1640,y:935,t:1527189034689};\\\", \\\"{x:1640,y:947,t:1527189034706};\\\", \\\"{x:1640,y:952,t:1527189034724};\\\", \\\"{x:1640,y:953,t:1527189034756};\\\", \\\"{x:1636,y:958,t:1527189034773};\\\", \\\"{x:1628,y:963,t:1527189034790};\\\", \\\"{x:1621,y:966,t:1527189034807};\\\", \\\"{x:1620,y:967,t:1527189034824};\\\", \\\"{x:1618,y:967,t:1527189034861};\\\", \\\"{x:1617,y:967,t:1527189034873};\\\", \\\"{x:1613,y:965,t:1527189034890};\\\", \\\"{x:1610,y:964,t:1527189034907};\\\", \\\"{x:1609,y:964,t:1527189035012};\\\", \\\"{x:1609,y:961,t:1527189035318};\\\", \\\"{x:1607,y:955,t:1527189035324};\\\", \\\"{x:1605,y:941,t:1527189035340};\\\", \\\"{x:1604,y:927,t:1527189035357};\\\", \\\"{x:1601,y:911,t:1527189035374};\\\", \\\"{x:1599,y:896,t:1527189035391};\\\", \\\"{x:1599,y:880,t:1527189035407};\\\", \\\"{x:1599,y:856,t:1527189035424};\\\", \\\"{x:1599,y:820,t:1527189035441};\\\", \\\"{x:1595,y:790,t:1527189035457};\\\", \\\"{x:1593,y:772,t:1527189035475};\\\", \\\"{x:1591,y:763,t:1527189035491};\\\", \\\"{x:1590,y:755,t:1527189035508};\\\", \\\"{x:1590,y:738,t:1527189035524};\\\", \\\"{x:1590,y:729,t:1527189035541};\\\", \\\"{x:1589,y:723,t:1527189035558};\\\", \\\"{x:1589,y:720,t:1527189035575};\\\", \\\"{x:1589,y:719,t:1527189035592};\\\", \\\"{x:1589,y:718,t:1527189035691};\\\", \\\"{x:1587,y:712,t:1527189035732};\\\", \\\"{x:1587,y:711,t:1527189035740};\\\", \\\"{x:1586,y:707,t:1527189035758};\\\", \\\"{x:1586,y:702,t:1527189035775};\\\", \\\"{x:1586,y:697,t:1527189035791};\\\", \\\"{x:1585,y:693,t:1527189035808};\\\", \\\"{x:1584,y:688,t:1527189035824};\\\", \\\"{x:1583,y:676,t:1527189035841};\\\", \\\"{x:1583,y:661,t:1527189035858};\\\", \\\"{x:1583,y:650,t:1527189035875};\\\", \\\"{x:1583,y:645,t:1527189035891};\\\", \\\"{x:1582,y:644,t:1527189035908};\\\", \\\"{x:1582,y:643,t:1527189036005};\\\", \\\"{x:1581,y:643,t:1527189036189};\\\", \\\"{x:1581,y:640,t:1527189036461};\\\", \\\"{x:1578,y:618,t:1527189036477};\\\", \\\"{x:1571,y:599,t:1527189036493};\\\", \\\"{x:1567,y:577,t:1527189036510};\\\", \\\"{x:1566,y:559,t:1527189036527};\\\", \\\"{x:1565,y:545,t:1527189036543};\\\", \\\"{x:1565,y:539,t:1527189036559};\\\", \\\"{x:1565,y:536,t:1527189036576};\\\", \\\"{x:1565,y:533,t:1527189036592};\\\", \\\"{x:1564,y:530,t:1527189036610};\\\", \\\"{x:1563,y:529,t:1527189036627};\\\", \\\"{x:1561,y:526,t:1527189036642};\\\", \\\"{x:1559,y:523,t:1527189036660};\\\", \\\"{x:1559,y:521,t:1527189036676};\\\", \\\"{x:1559,y:520,t:1527189036692};\\\", \\\"{x:1559,y:517,t:1527189036710};\\\", \\\"{x:1559,y:513,t:1527189036727};\\\", \\\"{x:1559,y:508,t:1527189036743};\\\", \\\"{x:1559,y:502,t:1527189036759};\\\", \\\"{x:1558,y:497,t:1527189036777};\\\", \\\"{x:1558,y:491,t:1527189036793};\\\", \\\"{x:1558,y:487,t:1527189036809};\\\", \\\"{x:1556,y:482,t:1527189036826};\\\", \\\"{x:1555,y:478,t:1527189036843};\\\", \\\"{x:1555,y:483,t:1527189036933};\\\", \\\"{x:1555,y:490,t:1527189036943};\\\", \\\"{x:1554,y:512,t:1527189036960};\\\", \\\"{x:1554,y:540,t:1527189036977};\\\", \\\"{x:1551,y:567,t:1527189036993};\\\", \\\"{x:1551,y:591,t:1527189037010};\\\", \\\"{x:1551,y:614,t:1527189037026};\\\", \\\"{x:1550,y:636,t:1527189037044};\\\", \\\"{x:1548,y:665,t:1527189037060};\\\", \\\"{x:1545,y:682,t:1527189037076};\\\", \\\"{x:1543,y:698,t:1527189037093};\\\", \\\"{x:1540,y:716,t:1527189037111};\\\", \\\"{x:1540,y:722,t:1527189037128};\\\", \\\"{x:1540,y:726,t:1527189037144};\\\", \\\"{x:1540,y:729,t:1527189037161};\\\", \\\"{x:1540,y:730,t:1527189037177};\\\", \\\"{x:1539,y:732,t:1527189037193};\\\", \\\"{x:1538,y:732,t:1527189037292};\\\", \\\"{x:1537,y:732,t:1527189037300};\\\", \\\"{x:1537,y:733,t:1527189037311};\\\", \\\"{x:1536,y:733,t:1527189037332};\\\", \\\"{x:1533,y:736,t:1527189037364};\\\", \\\"{x:1532,y:739,t:1527189037380};\\\", \\\"{x:1529,y:744,t:1527189037394};\\\", \\\"{x:1528,y:749,t:1527189037410};\\\", \\\"{x:1527,y:756,t:1527189037428};\\\", \\\"{x:1525,y:765,t:1527189037444};\\\", \\\"{x:1525,y:766,t:1527189037460};\\\", \\\"{x:1524,y:767,t:1527189037525};\\\", \\\"{x:1524,y:768,t:1527189037532};\\\", \\\"{x:1522,y:768,t:1527189038084};\\\", \\\"{x:1521,y:768,t:1527189038141};\\\", \\\"{x:1519,y:768,t:1527189038173};\\\", \\\"{x:1517,y:769,t:1527189038261};\\\", \\\"{x:1517,y:770,t:1527189038293};\\\", \\\"{x:1516,y:770,t:1527189038397};\\\", \\\"{x:1516,y:772,t:1527189038580};\\\", \\\"{x:1516,y:774,t:1527189038596};\\\", \\\"{x:1515,y:790,t:1527189038612};\\\", \\\"{x:1513,y:801,t:1527189038630};\\\", \\\"{x:1511,y:815,t:1527189038646};\\\", \\\"{x:1509,y:828,t:1527189038663};\\\", \\\"{x:1508,y:846,t:1527189038679};\\\", \\\"{x:1504,y:864,t:1527189038696};\\\", \\\"{x:1504,y:890,t:1527189038712};\\\", \\\"{x:1504,y:914,t:1527189038730};\\\", \\\"{x:1504,y:933,t:1527189038747};\\\", \\\"{x:1504,y:943,t:1527189038763};\\\", \\\"{x:1504,y:948,t:1527189038780};\\\", \\\"{x:1504,y:954,t:1527189038796};\\\", \\\"{x:1504,y:962,t:1527189038812};\\\", \\\"{x:1504,y:974,t:1527189038829};\\\", \\\"{x:1504,y:993,t:1527189038846};\\\", \\\"{x:1506,y:1010,t:1527189038864};\\\", \\\"{x:1507,y:1016,t:1527189038880};\\\", \\\"{x:1508,y:1017,t:1527189038897};\\\", \\\"{x:1507,y:1017,t:1527189038973};\\\", \\\"{x:1504,y:1013,t:1527189038980};\\\", \\\"{x:1501,y:999,t:1527189038996};\\\", \\\"{x:1494,y:978,t:1527189039013};\\\", \\\"{x:1489,y:959,t:1527189039030};\\\", \\\"{x:1487,y:938,t:1527189039047};\\\", \\\"{x:1485,y:921,t:1527189039064};\\\", \\\"{x:1482,y:903,t:1527189039081};\\\", \\\"{x:1478,y:884,t:1527189039097};\\\", \\\"{x:1474,y:870,t:1527189039114};\\\", \\\"{x:1469,y:858,t:1527189039130};\\\", \\\"{x:1469,y:855,t:1527189039146};\\\", \\\"{x:1469,y:854,t:1527189039172};\\\", \\\"{x:1470,y:853,t:1527189039397};\\\", \\\"{x:1472,y:848,t:1527189039414};\\\", \\\"{x:1474,y:840,t:1527189039430};\\\", \\\"{x:1478,y:829,t:1527189039447};\\\", \\\"{x:1478,y:819,t:1527189039464};\\\", \\\"{x:1479,y:815,t:1527189039480};\\\", \\\"{x:1479,y:818,t:1527189039629};\\\", \\\"{x:1479,y:820,t:1527189039636};\\\", \\\"{x:1479,y:823,t:1527189039648};\\\", \\\"{x:1479,y:832,t:1527189039665};\\\", \\\"{x:1479,y:839,t:1527189039681};\\\", \\\"{x:1479,y:845,t:1527189039697};\\\", \\\"{x:1478,y:850,t:1527189039714};\\\", \\\"{x:1478,y:853,t:1527189039731};\\\", \\\"{x:1477,y:855,t:1527189039747};\\\", \\\"{x:1477,y:859,t:1527189039763};\\\", \\\"{x:1477,y:864,t:1527189039781};\\\", \\\"{x:1477,y:868,t:1527189039797};\\\", \\\"{x:1477,y:872,t:1527189039814};\\\", \\\"{x:1477,y:874,t:1527189039831};\\\", \\\"{x:1477,y:878,t:1527189039847};\\\", \\\"{x:1477,y:886,t:1527189039864};\\\", \\\"{x:1479,y:899,t:1527189039881};\\\", \\\"{x:1481,y:912,t:1527189039897};\\\", \\\"{x:1481,y:919,t:1527189039914};\\\", \\\"{x:1482,y:923,t:1527189039931};\\\", \\\"{x:1482,y:929,t:1527189039948};\\\", \\\"{x:1482,y:935,t:1527189039965};\\\", \\\"{x:1482,y:944,t:1527189039982};\\\", \\\"{x:1482,y:953,t:1527189039998};\\\", \\\"{x:1482,y:959,t:1527189040014};\\\", \\\"{x:1482,y:960,t:1527189040031};\\\", \\\"{x:1482,y:961,t:1527189040068};\\\", \\\"{x:1480,y:961,t:1527189040189};\\\", \\\"{x:1472,y:960,t:1527189040199};\\\", \\\"{x:1447,y:948,t:1527189040215};\\\", \\\"{x:1404,y:937,t:1527189040231};\\\", \\\"{x:1356,y:922,t:1527189040249};\\\", \\\"{x:1321,y:910,t:1527189040266};\\\", \\\"{x:1291,y:897,t:1527189040282};\\\", \\\"{x:1271,y:886,t:1527189040299};\\\", \\\"{x:1246,y:871,t:1527189040315};\\\", \\\"{x:1211,y:857,t:1527189040332};\\\", \\\"{x:1129,y:829,t:1527189040348};\\\", \\\"{x:1061,y:804,t:1527189040365};\\\", \\\"{x:979,y:776,t:1527189040383};\\\", \\\"{x:931,y:760,t:1527189040399};\\\", \\\"{x:929,y:759,t:1527189040596};\\\", \\\"{x:927,y:756,t:1527189040604};\\\", \\\"{x:920,y:751,t:1527189040616};\\\", \\\"{x:911,y:748,t:1527189040632};\\\", \\\"{x:904,y:747,t:1527189040649};\\\", \\\"{x:888,y:745,t:1527189040665};\\\", \\\"{x:869,y:741,t:1527189040682};\\\", \\\"{x:852,y:737,t:1527189040699};\\\", \\\"{x:829,y:726,t:1527189040715};\\\", \\\"{x:783,y:698,t:1527189040732};\\\", \\\"{x:753,y:685,t:1527189040750};\\\", \\\"{x:730,y:679,t:1527189040765};\\\", \\\"{x:711,y:677,t:1527189040782};\\\", \\\"{x:699,y:674,t:1527189040799};\\\", \\\"{x:693,y:672,t:1527189040816};\\\", \\\"{x:686,y:664,t:1527189040831};\\\", \\\"{x:670,y:648,t:1527189040849};\\\", \\\"{x:651,y:628,t:1527189040867};\\\", \\\"{x:632,y:611,t:1527189040882};\\\", \\\"{x:615,y:604,t:1527189040899};\\\", \\\"{x:600,y:600,t:1527189040922};\\\", \\\"{x:599,y:600,t:1527189040995};\\\", \\\"{x:599,y:599,t:1527189041100};\\\", \\\"{x:600,y:598,t:1527189041115};\\\", \\\"{x:600,y:597,t:1527189041124};\\\", \\\"{x:600,y:596,t:1527189041139};\\\", \\\"{x:604,y:589,t:1527189041158};\\\", \\\"{x:607,y:586,t:1527189041172};\\\", \\\"{x:609,y:584,t:1527189041189};\\\", \\\"{x:620,y:584,t:1527189041645};\\\", \\\"{x:653,y:599,t:1527189041658};\\\", \\\"{x:770,y:661,t:1527189041672};\\\", \\\"{x:903,y:729,t:1527189041689};\\\", \\\"{x:1055,y:798,t:1527189041706};\\\", \\\"{x:1204,y:865,t:1527189041723};\\\", \\\"{x:1339,y:926,t:1527189041739};\\\", \\\"{x:1480,y:979,t:1527189041756};\\\", \\\"{x:1524,y:991,t:1527189041773};\\\", \\\"{x:1542,y:999,t:1527189041788};\\\", \\\"{x:1551,y:1003,t:1527189041806};\\\", \\\"{x:1556,y:1005,t:1527189041823};\\\", \\\"{x:1558,y:1005,t:1527189041839};\\\", \\\"{x:1561,y:1005,t:1527189041856};\\\", \\\"{x:1563,y:1005,t:1527189041873};\\\", \\\"{x:1564,y:1005,t:1527189041891};\\\", \\\"{x:1565,y:1004,t:1527189041906};\\\", \\\"{x:1570,y:1002,t:1527189041923};\\\", \\\"{x:1574,y:1000,t:1527189041939};\\\", \\\"{x:1576,y:999,t:1527189041957};\\\", \\\"{x:1576,y:998,t:1527189041974};\\\", \\\"{x:1576,y:992,t:1527189041990};\\\", \\\"{x:1576,y:983,t:1527189042006};\\\", \\\"{x:1572,y:973,t:1527189042024};\\\", \\\"{x:1568,y:959,t:1527189042039};\\\", \\\"{x:1559,y:943,t:1527189042056};\\\", \\\"{x:1551,y:932,t:1527189042074};\\\", \\\"{x:1544,y:928,t:1527189042090};\\\", \\\"{x:1539,y:926,t:1527189042107};\\\", \\\"{x:1534,y:923,t:1527189042123};\\\", \\\"{x:1527,y:920,t:1527189042140};\\\", \\\"{x:1520,y:918,t:1527189042156};\\\", \\\"{x:1508,y:915,t:1527189042174};\\\", \\\"{x:1496,y:915,t:1527189042190};\\\", \\\"{x:1481,y:915,t:1527189042207};\\\", \\\"{x:1466,y:915,t:1527189042223};\\\", \\\"{x:1456,y:915,t:1527189042240};\\\", \\\"{x:1448,y:915,t:1527189042257};\\\", \\\"{x:1436,y:916,t:1527189042274};\\\", \\\"{x:1425,y:918,t:1527189042290};\\\", \\\"{x:1412,y:921,t:1527189042306};\\\", \\\"{x:1407,y:923,t:1527189042324};\\\", \\\"{x:1402,y:924,t:1527189042340};\\\", \\\"{x:1401,y:924,t:1527189042357};\\\", \\\"{x:1399,y:925,t:1527189042388};\\\", \\\"{x:1397,y:925,t:1527189042407};\\\", \\\"{x:1396,y:925,t:1527189042428};\\\", \\\"{x:1395,y:925,t:1527189042452};\\\", \\\"{x:1394,y:925,t:1527189042461};\\\", \\\"{x:1393,y:925,t:1527189042476};\\\", \\\"{x:1392,y:925,t:1527189042490};\\\", \\\"{x:1391,y:924,t:1527189042506};\\\", \\\"{x:1390,y:923,t:1527189042523};\\\", \\\"{x:1390,y:922,t:1527189042540};\\\", \\\"{x:1389,y:919,t:1527189042556};\\\", \\\"{x:1388,y:918,t:1527189042574};\\\", \\\"{x:1387,y:917,t:1527189042590};\\\", \\\"{x:1386,y:916,t:1527189042607};\\\", \\\"{x:1385,y:915,t:1527189042628};\\\", \\\"{x:1385,y:914,t:1527189042640};\\\", \\\"{x:1384,y:914,t:1527189042657};\\\", \\\"{x:1383,y:914,t:1527189042673};\\\", \\\"{x:1383,y:913,t:1527189042689};\\\", \\\"{x:1382,y:912,t:1527189042716};\\\", \\\"{x:1380,y:911,t:1527189042756};\\\", \\\"{x:1380,y:910,t:1527189042780};\\\", \\\"{x:1380,y:909,t:1527189042813};\\\", \\\"{x:1378,y:908,t:1527189042824};\\\", \\\"{x:1378,y:907,t:1527189042840};\\\", \\\"{x:1378,y:906,t:1527189042857};\\\", \\\"{x:1378,y:905,t:1527189042874};\\\", \\\"{x:1377,y:904,t:1527189042890};\\\", \\\"{x:1380,y:904,t:1527189043757};\\\", \\\"{x:1392,y:904,t:1527189043773};\\\", \\\"{x:1407,y:903,t:1527189043791};\\\", \\\"{x:1422,y:903,t:1527189043807};\\\", \\\"{x:1431,y:901,t:1527189043824};\\\", \\\"{x:1433,y:901,t:1527189043841};\\\", \\\"{x:1434,y:901,t:1527189043857};\\\", \\\"{x:1438,y:899,t:1527189043874};\\\", \\\"{x:1450,y:895,t:1527189043890};\\\", \\\"{x:1463,y:889,t:1527189043906};\\\", \\\"{x:1486,y:875,t:1527189043924};\\\", \\\"{x:1514,y:853,t:1527189043940};\\\", \\\"{x:1530,y:833,t:1527189043957};\\\", \\\"{x:1538,y:816,t:1527189043974};\\\", \\\"{x:1541,y:802,t:1527189043991};\\\", \\\"{x:1541,y:787,t:1527189044006};\\\", \\\"{x:1542,y:769,t:1527189044024};\\\", \\\"{x:1542,y:744,t:1527189044041};\\\", \\\"{x:1542,y:727,t:1527189044057};\\\", \\\"{x:1539,y:712,t:1527189044073};\\\", \\\"{x:1536,y:706,t:1527189044091};\\\", \\\"{x:1529,y:698,t:1527189044107};\\\", \\\"{x:1517,y:694,t:1527189044124};\\\", \\\"{x:1498,y:688,t:1527189044140};\\\", \\\"{x:1487,y:683,t:1527189044157};\\\", \\\"{x:1481,y:680,t:1527189044174};\\\", \\\"{x:1479,y:679,t:1527189044191};\\\", \\\"{x:1478,y:678,t:1527189044206};\\\", \\\"{x:1477,y:678,t:1527189044224};\\\", \\\"{x:1476,y:677,t:1527189044241};\\\", \\\"{x:1475,y:677,t:1527189044256};\\\", \\\"{x:1473,y:675,t:1527189044273};\\\", \\\"{x:1469,y:669,t:1527189044290};\\\", \\\"{x:1467,y:666,t:1527189044306};\\\", \\\"{x:1465,y:665,t:1527189044323};\\\", \\\"{x:1465,y:664,t:1527189044340};\\\", \\\"{x:1464,y:663,t:1527189044356};\\\", \\\"{x:1462,y:661,t:1527189044374};\\\", \\\"{x:1459,y:659,t:1527189044390};\\\", \\\"{x:1458,y:657,t:1527189044406};\\\", \\\"{x:1456,y:655,t:1527189044423};\\\", \\\"{x:1454,y:652,t:1527189044440};\\\", \\\"{x:1453,y:651,t:1527189044484};\\\", \\\"{x:1452,y:650,t:1527189044499};\\\", \\\"{x:1452,y:649,t:1527189044508};\\\", \\\"{x:1450,y:649,t:1527189044532};\\\", \\\"{x:1449,y:648,t:1527189044548};\\\", \\\"{x:1448,y:647,t:1527189044564};\\\", \\\"{x:1447,y:647,t:1527189044605};\\\", \\\"{x:1446,y:646,t:1527189044628};\\\", \\\"{x:1445,y:645,t:1527189044685};\\\", \\\"{x:1444,y:644,t:1527189044691};\\\", \\\"{x:1443,y:643,t:1527189044706};\\\", \\\"{x:1442,y:642,t:1527189044755};\\\", \\\"{x:1442,y:641,t:1527189044780};\\\", \\\"{x:1442,y:640,t:1527189044795};\\\", \\\"{x:1441,y:640,t:1527189044820};\\\", \\\"{x:1440,y:639,t:1527189044828};\\\", \\\"{x:1440,y:638,t:1527189044841};\\\", \\\"{x:1440,y:637,t:1527189044867};\\\", \\\"{x:1440,y:635,t:1527189044900};\\\", \\\"{x:1440,y:634,t:1527189044916};\\\", \\\"{x:1440,y:632,t:1527189044931};\\\", \\\"{x:1440,y:631,t:1527189044956};\\\", \\\"{x:1440,y:629,t:1527189044973};\\\", \\\"{x:1440,y:626,t:1527189044991};\\\", \\\"{x:1440,y:617,t:1527189045006};\\\", \\\"{x:1440,y:607,t:1527189045023};\\\", \\\"{x:1441,y:598,t:1527189045041};\\\", \\\"{x:1442,y:585,t:1527189045056};\\\", \\\"{x:1442,y:576,t:1527189045073};\\\", \\\"{x:1442,y:569,t:1527189045090};\\\", \\\"{x:1442,y:565,t:1527189045106};\\\", \\\"{x:1441,y:562,t:1527189045124};\\\", \\\"{x:1441,y:561,t:1527189045148};\\\", \\\"{x:1441,y:560,t:1527189045188};\\\", \\\"{x:1441,y:559,t:1527189045212};\\\", \\\"{x:1440,y:559,t:1527189045341};\\\", \\\"{x:1437,y:559,t:1527189045357};\\\", \\\"{x:1436,y:560,t:1527189045374};\\\", \\\"{x:1435,y:560,t:1527189045469};\\\", \\\"{x:1433,y:560,t:1527189045477};\\\", \\\"{x:1432,y:561,t:1527189045490};\\\", \\\"{x:1428,y:562,t:1527189045507};\\\", \\\"{x:1425,y:562,t:1527189045523};\\\", \\\"{x:1423,y:563,t:1527189045540};\\\", \\\"{x:1421,y:564,t:1527189045557};\\\", \\\"{x:1420,y:564,t:1527189045627};\\\", \\\"{x:1419,y:564,t:1527189046212};\\\", \\\"{x:1418,y:564,t:1527189046224};\\\", \\\"{x:1415,y:564,t:1527189046241};\\\", \\\"{x:1413,y:564,t:1527189046258};\\\", \\\"{x:1412,y:565,t:1527189046324};\\\", \\\"{x:1411,y:567,t:1527189046340};\\\", \\\"{x:1410,y:573,t:1527189046359};\\\", \\\"{x:1408,y:582,t:1527189046374};\\\", \\\"{x:1408,y:594,t:1527189046391};\\\", \\\"{x:1408,y:609,t:1527189046407};\\\", \\\"{x:1408,y:630,t:1527189046424};\\\", \\\"{x:1408,y:650,t:1527189046441};\\\", \\\"{x:1408,y:677,t:1527189046457};\\\", \\\"{x:1408,y:706,t:1527189046473};\\\", \\\"{x:1408,y:734,t:1527189046490};\\\", \\\"{x:1408,y:770,t:1527189046508};\\\", \\\"{x:1408,y:785,t:1527189046524};\\\", \\\"{x:1408,y:800,t:1527189046541};\\\", \\\"{x:1408,y:813,t:1527189046558};\\\", \\\"{x:1408,y:829,t:1527189046574};\\\", \\\"{x:1408,y:845,t:1527189046590};\\\", \\\"{x:1408,y:860,t:1527189046608};\\\", \\\"{x:1409,y:876,t:1527189046624};\\\", \\\"{x:1413,y:891,t:1527189046641};\\\", \\\"{x:1413,y:902,t:1527189046658};\\\", \\\"{x:1413,y:907,t:1527189046674};\\\", \\\"{x:1414,y:913,t:1527189046691};\\\", \\\"{x:1417,y:924,t:1527189046708};\\\", \\\"{x:1418,y:934,t:1527189046725};\\\", \\\"{x:1419,y:948,t:1527189046741};\\\", \\\"{x:1421,y:954,t:1527189046758};\\\", \\\"{x:1422,y:958,t:1527189046774};\\\", \\\"{x:1422,y:960,t:1527189046791};\\\", \\\"{x:1422,y:961,t:1527189046808};\\\", \\\"{x:1423,y:961,t:1527189046861};\\\", \\\"{x:1423,y:956,t:1527189046916};\\\", \\\"{x:1424,y:933,t:1527189046924};\\\", \\\"{x:1427,y:873,t:1527189046941};\\\", \\\"{x:1427,y:834,t:1527189046958};\\\", \\\"{x:1421,y:794,t:1527189046974};\\\", \\\"{x:1411,y:745,t:1527189046991};\\\", \\\"{x:1400,y:708,t:1527189047008};\\\", \\\"{x:1394,y:681,t:1527189047024};\\\", \\\"{x:1388,y:651,t:1527189047041};\\\", \\\"{x:1386,y:631,t:1527189047058};\\\", \\\"{x:1383,y:614,t:1527189047074};\\\", \\\"{x:1381,y:601,t:1527189047091};\\\", \\\"{x:1380,y:593,t:1527189047108};\\\", \\\"{x:1380,y:592,t:1527189047124};\\\", \\\"{x:1380,y:590,t:1527189047141};\\\", \\\"{x:1379,y:588,t:1527189047158};\\\", \\\"{x:1379,y:585,t:1527189047174};\\\", \\\"{x:1379,y:582,t:1527189047190};\\\", \\\"{x:1379,y:575,t:1527189047207};\\\", \\\"{x:1379,y:573,t:1527189047224};\\\", \\\"{x:1379,y:572,t:1527189047240};\\\", \\\"{x:1379,y:575,t:1527189047461};\\\", \\\"{x:1377,y:586,t:1527189047475};\\\", \\\"{x:1370,y:610,t:1527189047490};\\\", \\\"{x:1357,y:643,t:1527189047508};\\\", \\\"{x:1352,y:657,t:1527189047523};\\\", \\\"{x:1351,y:664,t:1527189047540};\\\", \\\"{x:1351,y:667,t:1527189047557};\\\", \\\"{x:1351,y:673,t:1527189047574};\\\", \\\"{x:1351,y:681,t:1527189047590};\\\", \\\"{x:1349,y:692,t:1527189047607};\\\", \\\"{x:1348,y:701,t:1527189047623};\\\", \\\"{x:1346,y:705,t:1527189047641};\\\", \\\"{x:1346,y:704,t:1527189047924};\\\", \\\"{x:1346,y:702,t:1527189047941};\\\", \\\"{x:1344,y:700,t:1527189047957};\\\", \\\"{x:1343,y:697,t:1527189047974};\\\", \\\"{x:1343,y:702,t:1527189048549};\\\", \\\"{x:1343,y:706,t:1527189048558};\\\", \\\"{x:1343,y:716,t:1527189048576};\\\", \\\"{x:1341,y:723,t:1527189048590};\\\", \\\"{x:1340,y:730,t:1527189048608};\\\", \\\"{x:1340,y:734,t:1527189048625};\\\", \\\"{x:1340,y:741,t:1527189048641};\\\", \\\"{x:1340,y:752,t:1527189048658};\\\", \\\"{x:1340,y:762,t:1527189048675};\\\", \\\"{x:1340,y:780,t:1527189048691};\\\", \\\"{x:1340,y:804,t:1527189048708};\\\", \\\"{x:1340,y:817,t:1527189048724};\\\", \\\"{x:1340,y:829,t:1527189048741};\\\", \\\"{x:1340,y:839,t:1527189048758};\\\", \\\"{x:1340,y:852,t:1527189048775};\\\", \\\"{x:1340,y:864,t:1527189048791};\\\", \\\"{x:1340,y:874,t:1527189048808};\\\", \\\"{x:1340,y:884,t:1527189048825};\\\", \\\"{x:1340,y:892,t:1527189048841};\\\", \\\"{x:1343,y:904,t:1527189048858};\\\", \\\"{x:1344,y:914,t:1527189048875};\\\", \\\"{x:1345,y:920,t:1527189048891};\\\", \\\"{x:1345,y:921,t:1527189048908};\\\", \\\"{x:1345,y:923,t:1527189048924};\\\", \\\"{x:1346,y:924,t:1527189048941};\\\", \\\"{x:1346,y:926,t:1527189048958};\\\", \\\"{x:1346,y:927,t:1527189048975};\\\", \\\"{x:1347,y:930,t:1527189048991};\\\", \\\"{x:1347,y:932,t:1527189049008};\\\", \\\"{x:1347,y:934,t:1527189049025};\\\", \\\"{x:1348,y:939,t:1527189049041};\\\", \\\"{x:1348,y:943,t:1527189049057};\\\", \\\"{x:1350,y:949,t:1527189049075};\\\", \\\"{x:1350,y:952,t:1527189049090};\\\", \\\"{x:1351,y:954,t:1527189049107};\\\", \\\"{x:1351,y:955,t:1527189049268};\\\", \\\"{x:1351,y:954,t:1527189049700};\\\", \\\"{x:1351,y:952,t:1527189049708};\\\", \\\"{x:1351,y:950,t:1527189049725};\\\", \\\"{x:1351,y:945,t:1527189049742};\\\", \\\"{x:1351,y:939,t:1527189049758};\\\", \\\"{x:1351,y:928,t:1527189049775};\\\", \\\"{x:1350,y:912,t:1527189049792};\\\", \\\"{x:1344,y:889,t:1527189049808};\\\", \\\"{x:1338,y:869,t:1527189049825};\\\", \\\"{x:1334,y:854,t:1527189049842};\\\", \\\"{x:1332,y:841,t:1527189049857};\\\", \\\"{x:1332,y:829,t:1527189049875};\\\", \\\"{x:1327,y:806,t:1527189049892};\\\", \\\"{x:1324,y:792,t:1527189049908};\\\", \\\"{x:1323,y:780,t:1527189049925};\\\", \\\"{x:1323,y:776,t:1527189049942};\\\", \\\"{x:1323,y:774,t:1527189049958};\\\", \\\"{x:1323,y:772,t:1527189049975};\\\", \\\"{x:1323,y:767,t:1527189049992};\\\", \\\"{x:1323,y:760,t:1527189050008};\\\", \\\"{x:1324,y:755,t:1527189050025};\\\", \\\"{x:1325,y:752,t:1527189050042};\\\", \\\"{x:1325,y:749,t:1527189050058};\\\", \\\"{x:1325,y:746,t:1527189050075};\\\", \\\"{x:1327,y:744,t:1527189050092};\\\", \\\"{x:1327,y:742,t:1527189050108};\\\", \\\"{x:1328,y:741,t:1527189050125};\\\", \\\"{x:1329,y:737,t:1527189050142};\\\", \\\"{x:1331,y:734,t:1527189050158};\\\", \\\"{x:1332,y:729,t:1527189050175};\\\", \\\"{x:1334,y:727,t:1527189050192};\\\", \\\"{x:1334,y:724,t:1527189050292};\\\", \\\"{x:1334,y:723,t:1527189050323};\\\", \\\"{x:1335,y:723,t:1527189050343};\\\", \\\"{x:1335,y:722,t:1527189050358};\\\", \\\"{x:1335,y:720,t:1527189050375};\\\", \\\"{x:1337,y:717,t:1527189050392};\\\", \\\"{x:1338,y:715,t:1527189050408};\\\", \\\"{x:1339,y:712,t:1527189050425};\\\", \\\"{x:1339,y:711,t:1527189050442};\\\", \\\"{x:1339,y:710,t:1527189050476};\\\", \\\"{x:1340,y:710,t:1527189051196};\\\", \\\"{x:1341,y:708,t:1527189051208};\\\", \\\"{x:1342,y:708,t:1527189051225};\\\", \\\"{x:1342,y:706,t:1527189051243};\\\", \\\"{x:1342,y:705,t:1527189051258};\\\", \\\"{x:1343,y:704,t:1527189051275};\\\", \\\"{x:1343,y:703,t:1527189051324};\\\", \\\"{x:1345,y:702,t:1527189051343};\\\", \\\"{x:1345,y:701,t:1527189051364};\\\", \\\"{x:1343,y:701,t:1527189052045};\\\", \\\"{x:1335,y:704,t:1527189052059};\\\", \\\"{x:1305,y:726,t:1527189052075};\\\", \\\"{x:1201,y:750,t:1527189052092};\\\", \\\"{x:1116,y:756,t:1527189052108};\\\", \\\"{x:1035,y:756,t:1527189052124};\\\", \\\"{x:952,y:734,t:1527189052142};\\\", \\\"{x:899,y:718,t:1527189052158};\\\", \\\"{x:851,y:694,t:1527189052175};\\\", \\\"{x:823,y:682,t:1527189052192};\\\", \\\"{x:803,y:671,t:1527189052208};\\\", \\\"{x:787,y:660,t:1527189052225};\\\", \\\"{x:764,y:646,t:1527189052241};\\\", \\\"{x:735,y:631,t:1527189052260};\\\", \\\"{x:708,y:618,t:1527189052276};\\\", \\\"{x:691,y:610,t:1527189052290};\\\", \\\"{x:689,y:608,t:1527189052314};\\\", \\\"{x:687,y:607,t:1527189052347};\\\", \\\"{x:682,y:606,t:1527189052354};\\\", \\\"{x:677,y:604,t:1527189052365};\\\", \\\"{x:667,y:599,t:1527189052381};\\\", \\\"{x:663,y:598,t:1527189052398};\\\", \\\"{x:661,y:597,t:1527189052415};\\\", \\\"{x:660,y:596,t:1527189052432};\\\", \\\"{x:656,y:595,t:1527189052449};\\\", \\\"{x:652,y:592,t:1527189052466};\\\", \\\"{x:651,y:591,t:1527189052482};\\\", \\\"{x:650,y:589,t:1527189052500};\\\", \\\"{x:649,y:587,t:1527189052515};\\\", \\\"{x:649,y:584,t:1527189052532};\\\", \\\"{x:649,y:579,t:1527189052549};\\\", \\\"{x:647,y:576,t:1527189052565};\\\", \\\"{x:645,y:571,t:1527189052583};\\\", \\\"{x:644,y:568,t:1527189052599};\\\", \\\"{x:644,y:563,t:1527189052616};\\\", \\\"{x:644,y:557,t:1527189052634};\\\", \\\"{x:648,y:549,t:1527189052651};\\\", \\\"{x:660,y:541,t:1527189052665};\\\", \\\"{x:677,y:536,t:1527189052682};\\\", \\\"{x:685,y:532,t:1527189052699};\\\", \\\"{x:689,y:531,t:1527189052715};\\\", \\\"{x:692,y:528,t:1527189052732};\\\", \\\"{x:697,y:526,t:1527189052749};\\\", \\\"{x:706,y:521,t:1527189052767};\\\", \\\"{x:720,y:518,t:1527189052782};\\\", \\\"{x:730,y:514,t:1527189052799};\\\", \\\"{x:733,y:513,t:1527189052815};\\\", \\\"{x:735,y:512,t:1527189052832};\\\", \\\"{x:738,y:511,t:1527189052848};\\\", \\\"{x:752,y:505,t:1527189052866};\\\", \\\"{x:770,y:497,t:1527189052882};\\\", \\\"{x:785,y:493,t:1527189052898};\\\", \\\"{x:793,y:491,t:1527189052915};\\\", \\\"{x:793,y:490,t:1527189052932};\\\", \\\"{x:794,y:490,t:1527189053011};\\\", \\\"{x:796,y:490,t:1527189053019};\\\", \\\"{x:797,y:490,t:1527189053035};\\\", \\\"{x:798,y:490,t:1527189053051};\\\", \\\"{x:803,y:493,t:1527189053780};\\\", \\\"{x:809,y:498,t:1527189053788};\\\", \\\"{x:814,y:502,t:1527189053799};\\\", \\\"{x:836,y:519,t:1527189053817};\\\", \\\"{x:874,y:550,t:1527189053834};\\\", \\\"{x:925,y:585,t:1527189053849};\\\", \\\"{x:983,y:626,t:1527189053867};\\\", \\\"{x:1053,y:682,t:1527189053882};\\\", \\\"{x:1082,y:705,t:1527189053899};\\\", \\\"{x:1105,y:725,t:1527189053916};\\\", \\\"{x:1122,y:743,t:1527189053933};\\\", \\\"{x:1146,y:762,t:1527189053949};\\\", \\\"{x:1169,y:780,t:1527189053967};\\\", \\\"{x:1192,y:794,t:1527189053984};\\\", \\\"{x:1215,y:805,t:1527189053999};\\\", \\\"{x:1235,y:818,t:1527189054017};\\\", \\\"{x:1251,y:827,t:1527189054034};\\\", \\\"{x:1273,y:843,t:1527189054050};\\\", \\\"{x:1290,y:855,t:1527189054066};\\\", \\\"{x:1321,y:872,t:1527189054083};\\\", \\\"{x:1343,y:884,t:1527189054100};\\\", \\\"{x:1363,y:894,t:1527189054116};\\\", \\\"{x:1384,y:907,t:1527189054133};\\\", \\\"{x:1403,y:917,t:1527189054150};\\\", \\\"{x:1418,y:924,t:1527189054167};\\\", \\\"{x:1427,y:927,t:1527189054184};\\\", \\\"{x:1432,y:930,t:1527189054199};\\\", \\\"{x:1433,y:930,t:1527189054235};\\\", \\\"{x:1434,y:930,t:1527189054268};\\\", \\\"{x:1430,y:929,t:1527189054499};\\\", \\\"{x:1419,y:923,t:1527189054507};\\\", \\\"{x:1400,y:913,t:1527189054516};\\\", \\\"{x:1349,y:885,t:1527189054533};\\\", \\\"{x:1272,y:855,t:1527189054551};\\\", \\\"{x:1194,y:817,t:1527189054567};\\\", \\\"{x:1114,y:779,t:1527189054583};\\\", \\\"{x:1051,y:752,t:1527189054601};\\\", \\\"{x:1015,y:733,t:1527189054617};\\\", \\\"{x:990,y:716,t:1527189054634};\\\", \\\"{x:975,y:703,t:1527189054651};\\\", \\\"{x:956,y:687,t:1527189054667};\\\", \\\"{x:934,y:669,t:1527189054684};\\\", \\\"{x:923,y:660,t:1527189054700};\\\", \\\"{x:915,y:652,t:1527189054717};\\\", \\\"{x:911,y:647,t:1527189054733};\\\", \\\"{x:905,y:639,t:1527189054750};\\\", \\\"{x:902,y:635,t:1527189054767};\\\", \\\"{x:898,y:632,t:1527189054784};\\\", \\\"{x:904,y:633,t:1527189054900};\\\", \\\"{x:939,y:657,t:1527189054918};\\\", \\\"{x:1000,y:699,t:1527189054934};\\\", \\\"{x:1069,y:740,t:1527189054951};\\\", \\\"{x:1132,y:777,t:1527189054968};\\\", \\\"{x:1188,y:805,t:1527189054984};\\\", \\\"{x:1215,y:824,t:1527189055001};\\\", \\\"{x:1230,y:833,t:1527189055018};\\\", \\\"{x:1239,y:838,t:1527189055035};\\\", \\\"{x:1254,y:846,t:1527189055051};\\\", \\\"{x:1279,y:861,t:1527189055068};\\\", \\\"{x:1296,y:872,t:1527189055084};\\\", \\\"{x:1315,y:882,t:1527189055101};\\\", \\\"{x:1335,y:892,t:1527189055118};\\\", \\\"{x:1351,y:898,t:1527189055134};\\\", \\\"{x:1366,y:904,t:1527189055151};\\\", \\\"{x:1370,y:907,t:1527189055168};\\\", \\\"{x:1373,y:907,t:1527189055185};\\\", \\\"{x:1374,y:903,t:1527189055524};\\\", \\\"{x:1373,y:898,t:1527189055535};\\\", \\\"{x:1370,y:890,t:1527189055552};\\\", \\\"{x:1368,y:886,t:1527189055568};\\\", \\\"{x:1366,y:880,t:1527189055585};\\\", \\\"{x:1363,y:875,t:1527189055602};\\\", \\\"{x:1361,y:870,t:1527189055618};\\\", \\\"{x:1360,y:867,t:1527189055635};\\\", \\\"{x:1357,y:857,t:1527189055652};\\\", \\\"{x:1352,y:847,t:1527189055668};\\\", \\\"{x:1350,y:837,t:1527189055685};\\\", \\\"{x:1344,y:814,t:1527189055702};\\\", \\\"{x:1340,y:800,t:1527189055718};\\\", \\\"{x:1336,y:784,t:1527189055735};\\\", \\\"{x:1334,y:765,t:1527189055752};\\\", \\\"{x:1331,y:751,t:1527189055768};\\\", \\\"{x:1329,y:741,t:1527189055785};\\\", \\\"{x:1327,y:733,t:1527189055802};\\\", \\\"{x:1326,y:726,t:1527189055818};\\\", \\\"{x:1325,y:717,t:1527189055835};\\\", \\\"{x:1324,y:701,t:1527189055852};\\\", \\\"{x:1324,y:694,t:1527189055868};\\\", \\\"{x:1322,y:686,t:1527189055885};\\\", \\\"{x:1322,y:678,t:1527189055902};\\\", \\\"{x:1322,y:671,t:1527189055918};\\\", \\\"{x:1322,y:665,t:1527189055935};\\\", \\\"{x:1321,y:659,t:1527189055952};\\\", \\\"{x:1320,y:656,t:1527189055968};\\\", \\\"{x:1319,y:652,t:1527189055985};\\\", \\\"{x:1319,y:651,t:1527189056002};\\\", \\\"{x:1318,y:649,t:1527189056018};\\\", \\\"{x:1316,y:646,t:1527189056035};\\\", \\\"{x:1314,y:638,t:1527189056052};\\\", \\\"{x:1313,y:633,t:1527189056069};\\\", \\\"{x:1311,y:630,t:1527189056085};\\\", \\\"{x:1311,y:629,t:1527189056102};\\\", \\\"{x:1311,y:626,t:1527189056119};\\\", \\\"{x:1310,y:622,t:1527189056135};\\\", \\\"{x:1310,y:616,t:1527189056152};\\\", \\\"{x:1309,y:611,t:1527189056169};\\\", \\\"{x:1307,y:605,t:1527189056186};\\\", \\\"{x:1307,y:603,t:1527189056202};\\\", \\\"{x:1307,y:601,t:1527189056219};\\\", \\\"{x:1307,y:598,t:1527189056235};\\\", \\\"{x:1307,y:597,t:1527189056252};\\\", \\\"{x:1307,y:594,t:1527189056269};\\\", \\\"{x:1307,y:592,t:1527189056285};\\\", \\\"{x:1307,y:591,t:1527189056302};\\\", \\\"{x:1307,y:590,t:1527189056324};\\\", \\\"{x:1307,y:589,t:1527189056364};\\\", \\\"{x:1307,y:588,t:1527189056379};\\\", \\\"{x:1307,y:587,t:1527189056388};\\\", \\\"{x:1307,y:586,t:1527189056402};\\\", \\\"{x:1307,y:584,t:1527189056420};\\\", \\\"{x:1307,y:583,t:1527189056436};\\\", \\\"{x:1307,y:582,t:1527189056452};\\\", \\\"{x:1307,y:581,t:1527189056500};\\\", \\\"{x:1306,y:580,t:1527189056516};\\\", \\\"{x:1306,y:579,t:1527189056524};\\\", \\\"{x:1306,y:578,t:1527189056536};\\\", \\\"{x:1303,y:575,t:1527189056552};\\\", \\\"{x:1298,y:571,t:1527189056569};\\\", \\\"{x:1293,y:568,t:1527189056586};\\\", \\\"{x:1287,y:564,t:1527189056602};\\\", \\\"{x:1286,y:564,t:1527189056619};\\\", \\\"{x:1285,y:564,t:1527189056652};\\\", \\\"{x:1284,y:563,t:1527189056669};\\\", \\\"{x:1282,y:562,t:1527189056686};\\\", \\\"{x:1281,y:562,t:1527189056702};\\\", \\\"{x:1280,y:562,t:1527189056732};\\\", \\\"{x:1278,y:562,t:1527189056821};\\\", \\\"{x:1277,y:569,t:1527189056837};\\\", \\\"{x:1272,y:580,t:1527189056853};\\\", \\\"{x:1269,y:588,t:1527189056869};\\\", \\\"{x:1266,y:598,t:1527189056886};\\\", \\\"{x:1265,y:607,t:1527189056904};\\\", \\\"{x:1263,y:616,t:1527189056919};\\\", \\\"{x:1263,y:627,t:1527189056936};\\\", \\\"{x:1262,y:650,t:1527189056954};\\\", \\\"{x:1259,y:695,t:1527189056969};\\\", \\\"{x:1254,y:777,t:1527189056986};\\\", \\\"{x:1250,y:872,t:1527189057003};\\\", \\\"{x:1250,y:944,t:1527189057019};\\\", \\\"{x:1250,y:986,t:1527189057036};\\\", \\\"{x:1251,y:1000,t:1527189057053};\\\", \\\"{x:1252,y:1008,t:1527189057070};\\\", \\\"{x:1254,y:1021,t:1527189057086};\\\", \\\"{x:1254,y:1027,t:1527189057103};\\\", \\\"{x:1254,y:1030,t:1527189057119};\\\", \\\"{x:1254,y:1031,t:1527189057323};\\\", \\\"{x:1259,y:1029,t:1527189057336};\\\", \\\"{x:1264,y:1017,t:1527189057352};\\\", \\\"{x:1268,y:1004,t:1527189057369};\\\", \\\"{x:1269,y:982,t:1527189057385};\\\", \\\"{x:1277,y:947,t:1527189057402};\\\", \\\"{x:1281,y:878,t:1527189057419};\\\", \\\"{x:1281,y:833,t:1527189057435};\\\", \\\"{x:1281,y:788,t:1527189057452};\\\", \\\"{x:1281,y:764,t:1527189057470};\\\", \\\"{x:1281,y:752,t:1527189057487};\\\", \\\"{x:1281,y:747,t:1527189057503};\\\", \\\"{x:1279,y:741,t:1527189057519};\\\", \\\"{x:1276,y:734,t:1527189057537};\\\", \\\"{x:1273,y:728,t:1527189057553};\\\", \\\"{x:1269,y:722,t:1527189057569};\\\", \\\"{x:1267,y:718,t:1527189057586};\\\", \\\"{x:1264,y:714,t:1527189057603};\\\", \\\"{x:1263,y:713,t:1527189057620};\\\", \\\"{x:1262,y:710,t:1527189057700};\\\", \\\"{x:1261,y:707,t:1527189057708};\\\", \\\"{x:1260,y:704,t:1527189057720};\\\", \\\"{x:1260,y:698,t:1527189057737};\\\", \\\"{x:1260,y:689,t:1527189057753};\\\", \\\"{x:1260,y:667,t:1527189057770};\\\", \\\"{x:1260,y:634,t:1527189057787};\\\", \\\"{x:1260,y:605,t:1527189057803};\\\", \\\"{x:1260,y:579,t:1527189057820};\\\", \\\"{x:1261,y:572,t:1527189057837};\\\", \\\"{x:1261,y:571,t:1527189057853};\\\", \\\"{x:1261,y:570,t:1527189057876};\\\", \\\"{x:1261,y:572,t:1527189057972};\\\", \\\"{x:1261,y:588,t:1527189057987};\\\", \\\"{x:1259,y:662,t:1527189058004};\\\", \\\"{x:1257,y:732,t:1527189058020};\\\", \\\"{x:1257,y:807,t:1527189058037};\\\", \\\"{x:1257,y:877,t:1527189058054};\\\", \\\"{x:1257,y:930,t:1527189058070};\\\", \\\"{x:1257,y:974,t:1527189058087};\\\", \\\"{x:1257,y:993,t:1527189058103};\\\", \\\"{x:1258,y:1004,t:1527189058120};\\\", \\\"{x:1259,y:1005,t:1527189058136};\\\", \\\"{x:1256,y:1001,t:1527189058292};\\\", \\\"{x:1247,y:984,t:1527189058304};\\\", \\\"{x:1235,y:958,t:1527189058320};\\\", \\\"{x:1225,y:929,t:1527189058337};\\\", \\\"{x:1212,y:896,t:1527189058354};\\\", \\\"{x:1209,y:874,t:1527189058371};\\\", \\\"{x:1207,y:862,t:1527189058386};\\\", \\\"{x:1206,y:857,t:1527189058403};\\\", \\\"{x:1206,y:855,t:1527189058420};\\\", \\\"{x:1205,y:855,t:1527189058437};\\\", \\\"{x:1205,y:857,t:1527189058517};\\\", \\\"{x:1205,y:865,t:1527189058524};\\\", \\\"{x:1205,y:876,t:1527189058537};\\\", \\\"{x:1205,y:901,t:1527189058554};\\\", \\\"{x:1203,y:928,t:1527189058571};\\\", \\\"{x:1202,y:951,t:1527189058587};\\\", \\\"{x:1202,y:974,t:1527189058604};\\\", \\\"{x:1202,y:978,t:1527189058621};\\\", \\\"{x:1202,y:979,t:1527189058637};\\\", \\\"{x:1202,y:980,t:1527189058708};\\\", \\\"{x:1205,y:971,t:1527189058721};\\\", \\\"{x:1211,y:949,t:1527189058737};\\\", \\\"{x:1217,y:918,t:1527189058754};\\\", \\\"{x:1220,y:885,t:1527189058771};\\\", \\\"{x:1220,y:843,t:1527189058788};\\\", \\\"{x:1221,y:828,t:1527189058804};\\\", \\\"{x:1221,y:821,t:1527189058822};\\\", \\\"{x:1221,y:823,t:1527189058900};\\\", \\\"{x:1221,y:833,t:1527189058908};\\\", \\\"{x:1221,y:852,t:1527189058922};\\\", \\\"{x:1221,y:899,t:1527189058938};\\\", \\\"{x:1221,y:936,t:1527189058954};\\\", \\\"{x:1221,y:958,t:1527189058971};\\\", \\\"{x:1223,y:971,t:1527189058989};\\\", \\\"{x:1223,y:973,t:1527189059004};\\\", \\\"{x:1224,y:976,t:1527189059021};\\\", \\\"{x:1224,y:977,t:1527189059052};\\\", \\\"{x:1218,y:977,t:1527189059092};\\\", \\\"{x:1198,y:970,t:1527189059104};\\\", \\\"{x:1122,y:940,t:1527189059121};\\\", \\\"{x:982,y:885,t:1527189059138};\\\", \\\"{x:836,y:828,t:1527189059154};\\\", \\\"{x:678,y:779,t:1527189059172};\\\", \\\"{x:645,y:771,t:1527189059188};\\\", \\\"{x:637,y:770,t:1527189059205};\\\", \\\"{x:636,y:770,t:1527189059268};\\\", \\\"{x:635,y:770,t:1527189059276};\\\", \\\"{x:634,y:770,t:1527189059288};\\\", \\\"{x:629,y:770,t:1527189059305};\\\", \\\"{x:626,y:770,t:1527189059321};\\\", \\\"{x:620,y:772,t:1527189059338};\\\", \\\"{x:619,y:772,t:1527189059355};\\\", \\\"{x:617,y:772,t:1527189059371};\\\", \\\"{x:615,y:770,t:1527189059460};\\\", \\\"{x:609,y:768,t:1527189059471};\\\", \\\"{x:595,y:764,t:1527189059488};\\\", \\\"{x:582,y:762,t:1527189059505};\\\", \\\"{x:570,y:758,t:1527189059521};\\\", \\\"{x:567,y:758,t:1527189059538};\\\", \\\"{x:566,y:758,t:1527189059555};\\\", \\\"{x:563,y:757,t:1527189059572};\\\", \\\"{x:561,y:756,t:1527189059596};\\\", \\\"{x:561,y:755,t:1527189059605};\\\", \\\"{x:560,y:754,t:1527189059621};\\\", \\\"{x:559,y:752,t:1527189059765};\\\", \\\"{x:555,y:748,t:1527189059772};\\\", \\\"{x:549,y:743,t:1527189059787};\\\", \\\"{x:546,y:740,t:1527189059804};\\\", \\\"{x:545,y:740,t:1527189060868};\\\", \\\"{x:545,y:742,t:1527189060875};\\\", \\\"{x:545,y:743,t:1527189060890};\\\" ] }, { \\\"rt\\\": 9713, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 456223, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-F -8\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:743,t:1527189061331};\\\", \\\"{x:554,y:742,t:1527189061357};\\\", \\\"{x:556,y:742,t:1527189061459};\\\", \\\"{x:557,y:742,t:1527189061473};\\\", \\\"{x:560,y:741,t:1527189061489};\\\", \\\"{x:561,y:741,t:1527189061515};\\\", \\\"{x:564,y:741,t:1527189061523};\\\", \\\"{x:571,y:741,t:1527189061539};\\\", \\\"{x:578,y:741,t:1527189061556};\\\", \\\"{x:607,y:745,t:1527189061616};\\\", \\\"{x:611,y:746,t:1527189061623};\\\", \\\"{x:632,y:755,t:1527189061645};\\\", \\\"{x:640,y:758,t:1527189061656};\\\", \\\"{x:657,y:763,t:1527189061673};\\\", \\\"{x:674,y:769,t:1527189061689};\\\", \\\"{x:691,y:773,t:1527189061706};\\\", \\\"{x:708,y:776,t:1527189061723};\\\", \\\"{x:740,y:785,t:1527189061739};\\\", \\\"{x:765,y:791,t:1527189061756};\\\", \\\"{x:789,y:796,t:1527189061773};\\\", \\\"{x:807,y:802,t:1527189061790};\\\", \\\"{x:815,y:803,t:1527189061805};\\\", \\\"{x:823,y:805,t:1527189061822};\\\", \\\"{x:825,y:805,t:1527189061839};\\\", \\\"{x:829,y:806,t:1527189061856};\\\", \\\"{x:838,y:808,t:1527189061872};\\\", \\\"{x:846,y:812,t:1527189061890};\\\", \\\"{x:853,y:815,t:1527189061907};\\\", \\\"{x:855,y:815,t:1527189061923};\\\", \\\"{x:856,y:815,t:1527189061940};\\\", \\\"{x:858,y:815,t:1527189062308};\\\", \\\"{x:864,y:816,t:1527189062323};\\\", \\\"{x:901,y:822,t:1527189062340};\\\", \\\"{x:929,y:827,t:1527189062357};\\\", \\\"{x:967,y:833,t:1527189062373};\\\", \\\"{x:1006,y:844,t:1527189062391};\\\", \\\"{x:1055,y:855,t:1527189062407};\\\", \\\"{x:1097,y:867,t:1527189062424};\\\", \\\"{x:1149,y:879,t:1527189062440};\\\", \\\"{x:1200,y:887,t:1527189062458};\\\", \\\"{x:1253,y:903,t:1527189062474};\\\", \\\"{x:1310,y:914,t:1527189062491};\\\", \\\"{x:1358,y:922,t:1527189062508};\\\", \\\"{x:1421,y:930,t:1527189062524};\\\", \\\"{x:1425,y:931,t:1527189062540};\\\", \\\"{x:1426,y:932,t:1527189062981};\\\", \\\"{x:1426,y:933,t:1527189062991};\\\", \\\"{x:1426,y:937,t:1527189063007};\\\", \\\"{x:1426,y:940,t:1527189063024};\\\", \\\"{x:1424,y:947,t:1527189063041};\\\", \\\"{x:1422,y:949,t:1527189063058};\\\", \\\"{x:1421,y:952,t:1527189063075};\\\", \\\"{x:1420,y:954,t:1527189063091};\\\", \\\"{x:1418,y:957,t:1527189063107};\\\", \\\"{x:1416,y:960,t:1527189063124};\\\", \\\"{x:1413,y:963,t:1527189063141};\\\", \\\"{x:1411,y:965,t:1527189063158};\\\", \\\"{x:1410,y:965,t:1527189063174};\\\", \\\"{x:1410,y:966,t:1527189063196};\\\", \\\"{x:1407,y:967,t:1527189063207};\\\", \\\"{x:1399,y:967,t:1527189063224};\\\", \\\"{x:1378,y:970,t:1527189063241};\\\", \\\"{x:1359,y:970,t:1527189063258};\\\", \\\"{x:1342,y:970,t:1527189063275};\\\", \\\"{x:1334,y:970,t:1527189063292};\\\", \\\"{x:1333,y:969,t:1527189063436};\\\", \\\"{x:1333,y:967,t:1527189063445};\\\", \\\"{x:1334,y:965,t:1527189063459};\\\", \\\"{x:1336,y:963,t:1527189063475};\\\", \\\"{x:1337,y:962,t:1527189063492};\\\", \\\"{x:1338,y:962,t:1527189063548};\\\", \\\"{x:1339,y:962,t:1527189063620};\\\", \\\"{x:1339,y:961,t:1527189063627};\\\", \\\"{x:1339,y:960,t:1527189063642};\\\", \\\"{x:1340,y:958,t:1527189063658};\\\", \\\"{x:1341,y:956,t:1527189063676};\\\", \\\"{x:1341,y:954,t:1527189063692};\\\", \\\"{x:1341,y:953,t:1527189063709};\\\", \\\"{x:1341,y:951,t:1527189063725};\\\", \\\"{x:1341,y:948,t:1527189063741};\\\", \\\"{x:1341,y:943,t:1527189063758};\\\", \\\"{x:1341,y:936,t:1527189063775};\\\", \\\"{x:1341,y:929,t:1527189063791};\\\", \\\"{x:1340,y:924,t:1527189063808};\\\", \\\"{x:1340,y:916,t:1527189063824};\\\", \\\"{x:1339,y:897,t:1527189063842};\\\", \\\"{x:1339,y:872,t:1527189063858};\\\", \\\"{x:1335,y:847,t:1527189063875};\\\", \\\"{x:1332,y:808,t:1527189063892};\\\", \\\"{x:1332,y:781,t:1527189063908};\\\", \\\"{x:1332,y:767,t:1527189063925};\\\", \\\"{x:1334,y:755,t:1527189063941};\\\", \\\"{x:1337,y:744,t:1527189063958};\\\", \\\"{x:1342,y:732,t:1527189063975};\\\", \\\"{x:1347,y:721,t:1527189063990};\\\", \\\"{x:1350,y:708,t:1527189064007};\\\", \\\"{x:1351,y:699,t:1527189064025};\\\", \\\"{x:1352,y:694,t:1527189064041};\\\", \\\"{x:1352,y:691,t:1527189064058};\\\", \\\"{x:1352,y:690,t:1527189064075};\\\", \\\"{x:1352,y:687,t:1527189064091};\\\", \\\"{x:1352,y:684,t:1527189064108};\\\", \\\"{x:1352,y:678,t:1527189064124};\\\", \\\"{x:1352,y:673,t:1527189064141};\\\", \\\"{x:1352,y:667,t:1527189064158};\\\", \\\"{x:1352,y:661,t:1527189064174};\\\", \\\"{x:1352,y:654,t:1527189064191};\\\", \\\"{x:1352,y:638,t:1527189064208};\\\", \\\"{x:1350,y:625,t:1527189064225};\\\", \\\"{x:1348,y:615,t:1527189064241};\\\", \\\"{x:1347,y:606,t:1527189064258};\\\", \\\"{x:1347,y:598,t:1527189064275};\\\", \\\"{x:1346,y:594,t:1527189064292};\\\", \\\"{x:1346,y:592,t:1527189064308};\\\", \\\"{x:1346,y:584,t:1527189064325};\\\", \\\"{x:1346,y:576,t:1527189064341};\\\", \\\"{x:1346,y:566,t:1527189064359};\\\", \\\"{x:1346,y:557,t:1527189064375};\\\", \\\"{x:1343,y:540,t:1527189064391};\\\", \\\"{x:1339,y:519,t:1527189064408};\\\", \\\"{x:1337,y:506,t:1527189064425};\\\", \\\"{x:1334,y:497,t:1527189064442};\\\", \\\"{x:1332,y:488,t:1527189064458};\\\", \\\"{x:1330,y:480,t:1527189064476};\\\", \\\"{x:1329,y:470,t:1527189064492};\\\", \\\"{x:1328,y:456,t:1527189064509};\\\", \\\"{x:1328,y:446,t:1527189064525};\\\", \\\"{x:1328,y:439,t:1527189064543};\\\", \\\"{x:1328,y:434,t:1527189064559};\\\", \\\"{x:1328,y:431,t:1527189064575};\\\", \\\"{x:1328,y:427,t:1527189064593};\\\", \\\"{x:1328,y:420,t:1527189064608};\\\", \\\"{x:1328,y:418,t:1527189064625};\\\", \\\"{x:1328,y:416,t:1527189064642};\\\", \\\"{x:1325,y:416,t:1527189064836};\\\", \\\"{x:1314,y:428,t:1527189064844};\\\", \\\"{x:1291,y:457,t:1527189064859};\\\", \\\"{x:1200,y:556,t:1527189064876};\\\", \\\"{x:1144,y:606,t:1527189064892};\\\", \\\"{x:1099,y:640,t:1527189064908};\\\", \\\"{x:1065,y:663,t:1527189064925};\\\", \\\"{x:1035,y:676,t:1527189064942};\\\", \\\"{x:1011,y:685,t:1527189064958};\\\", \\\"{x:981,y:692,t:1527189064976};\\\", \\\"{x:950,y:697,t:1527189064993};\\\", \\\"{x:920,y:697,t:1527189065009};\\\", \\\"{x:894,y:697,t:1527189065025};\\\", \\\"{x:868,y:697,t:1527189065042};\\\", \\\"{x:829,y:697,t:1527189065060};\\\", \\\"{x:803,y:697,t:1527189065075};\\\", \\\"{x:779,y:697,t:1527189065092};\\\", \\\"{x:758,y:691,t:1527189065109};\\\", \\\"{x:738,y:685,t:1527189065126};\\\", \\\"{x:722,y:677,t:1527189065142};\\\", \\\"{x:707,y:669,t:1527189065159};\\\", \\\"{x:690,y:664,t:1527189065175};\\\", \\\"{x:674,y:658,t:1527189065192};\\\", \\\"{x:667,y:657,t:1527189065210};\\\", \\\"{x:659,y:655,t:1527189065225};\\\", \\\"{x:653,y:655,t:1527189065242};\\\", \\\"{x:647,y:655,t:1527189065259};\\\", \\\"{x:641,y:653,t:1527189065276};\\\", \\\"{x:639,y:653,t:1527189065299};\\\", \\\"{x:639,y:650,t:1527189065316};\\\", \\\"{x:637,y:649,t:1527189065326};\\\", \\\"{x:630,y:642,t:1527189065342};\\\", \\\"{x:621,y:636,t:1527189065359};\\\", \\\"{x:617,y:630,t:1527189065376};\\\", \\\"{x:615,y:626,t:1527189065392};\\\", \\\"{x:615,y:618,t:1527189065408};\\\", \\\"{x:615,y:609,t:1527189065424};\\\", \\\"{x:614,y:600,t:1527189065442};\\\", \\\"{x:611,y:587,t:1527189065459};\\\", \\\"{x:610,y:582,t:1527189065475};\\\", \\\"{x:607,y:578,t:1527189065492};\\\", \\\"{x:607,y:576,t:1527189065509};\\\", \\\"{x:607,y:573,t:1527189065525};\\\", \\\"{x:607,y:564,t:1527189065543};\\\", \\\"{x:608,y:553,t:1527189065560};\\\", \\\"{x:609,y:543,t:1527189065576};\\\", \\\"{x:609,y:535,t:1527189065593};\\\", \\\"{x:609,y:532,t:1527189065609};\\\", \\\"{x:609,y:529,t:1527189065626};\\\", \\\"{x:609,y:522,t:1527189065643};\\\", \\\"{x:609,y:518,t:1527189065659};\\\", \\\"{x:609,y:513,t:1527189065677};\\\", \\\"{x:609,y:510,t:1527189065693};\\\", \\\"{x:609,y:508,t:1527189065710};\\\", \\\"{x:609,y:507,t:1527189065726};\\\", \\\"{x:609,y:505,t:1527189065743};\\\", \\\"{x:610,y:505,t:1527189065804};\\\", \\\"{x:614,y:504,t:1527189065812};\\\", \\\"{x:619,y:503,t:1527189065827};\\\", \\\"{x:651,y:497,t:1527189065844};\\\", \\\"{x:682,y:494,t:1527189065859};\\\", \\\"{x:707,y:493,t:1527189065876};\\\", \\\"{x:722,y:493,t:1527189065893};\\\", \\\"{x:731,y:491,t:1527189065911};\\\", \\\"{x:738,y:489,t:1527189065925};\\\", \\\"{x:743,y:488,t:1527189065943};\\\", \\\"{x:756,y:484,t:1527189065960};\\\", \\\"{x:771,y:480,t:1527189065977};\\\", \\\"{x:789,y:476,t:1527189065992};\\\", \\\"{x:804,y:473,t:1527189066010};\\\", \\\"{x:806,y:473,t:1527189066083};\\\", \\\"{x:809,y:473,t:1527189066093};\\\", \\\"{x:810,y:473,t:1527189066115};\\\", \\\"{x:811,y:474,t:1527189066156};\\\", \\\"{x:812,y:474,t:1527189066163};\\\", \\\"{x:813,y:475,t:1527189066177};\\\", \\\"{x:814,y:479,t:1527189066192};\\\", \\\"{x:814,y:480,t:1527189066210};\\\", \\\"{x:815,y:481,t:1527189066227};\\\", \\\"{x:816,y:483,t:1527189066243};\\\", \\\"{x:817,y:483,t:1527189066260};\\\", \\\"{x:817,y:484,t:1527189066277};\\\", \\\"{x:817,y:485,t:1527189066308};\\\", \\\"{x:820,y:486,t:1527189066508};\\\", \\\"{x:822,y:488,t:1527189066516};\\\", \\\"{x:824,y:489,t:1527189066527};\\\", \\\"{x:825,y:490,t:1527189066544};\\\", \\\"{x:826,y:490,t:1527189066560};\\\", \\\"{x:826,y:491,t:1527189066786};\\\", \\\"{x:828,y:493,t:1527189066795};\\\", \\\"{x:830,y:496,t:1527189066811};\\\", \\\"{x:830,y:497,t:1527189067044};\\\", \\\"{x:830,y:499,t:1527189067203};\\\", \\\"{x:825,y:502,t:1527189067212};\\\", \\\"{x:794,y:512,t:1527189067228};\\\", \\\"{x:737,y:524,t:1527189067245};\\\", \\\"{x:648,y:541,t:1527189067261};\\\", \\\"{x:555,y:560,t:1527189067278};\\\", \\\"{x:473,y:577,t:1527189067294};\\\", \\\"{x:402,y:593,t:1527189067311};\\\", \\\"{x:365,y:601,t:1527189067328};\\\", \\\"{x:347,y:607,t:1527189067344};\\\", \\\"{x:345,y:609,t:1527189067360};\\\", \\\"{x:345,y:612,t:1527189067403};\\\", \\\"{x:345,y:616,t:1527189067410};\\\", \\\"{x:346,y:627,t:1527189067427};\\\", \\\"{x:352,y:643,t:1527189067445};\\\", \\\"{x:365,y:660,t:1527189067461};\\\", \\\"{x:383,y:667,t:1527189067477};\\\", \\\"{x:396,y:672,t:1527189067495};\\\", \\\"{x:402,y:672,t:1527189067510};\\\", \\\"{x:392,y:672,t:1527189067587};\\\", \\\"{x:381,y:672,t:1527189067595};\\\", \\\"{x:351,y:662,t:1527189067611};\\\", \\\"{x:313,y:648,t:1527189067628};\\\", \\\"{x:271,y:630,t:1527189067646};\\\", \\\"{x:235,y:614,t:1527189067661};\\\", \\\"{x:204,y:601,t:1527189067677};\\\", \\\"{x:187,y:594,t:1527189067695};\\\", \\\"{x:183,y:590,t:1527189067712};\\\", \\\"{x:182,y:589,t:1527189067728};\\\", \\\"{x:182,y:585,t:1527189067745};\\\", \\\"{x:181,y:582,t:1527189067761};\\\", \\\"{x:181,y:581,t:1527189067778};\\\", \\\"{x:181,y:580,t:1527189067803};\\\", \\\"{x:180,y:578,t:1527189067827};\\\", \\\"{x:180,y:577,t:1527189067835};\\\", \\\"{x:180,y:576,t:1527189067851};\\\", \\\"{x:179,y:575,t:1527189067861};\\\", \\\"{x:179,y:574,t:1527189067878};\\\", \\\"{x:178,y:572,t:1527189067895};\\\", \\\"{x:176,y:569,t:1527189067911};\\\", \\\"{x:174,y:564,t:1527189067929};\\\", \\\"{x:172,y:557,t:1527189067945};\\\", \\\"{x:171,y:553,t:1527189067963};\\\", \\\"{x:170,y:552,t:1527189067978};\\\", \\\"{x:171,y:552,t:1527189068236};\\\", \\\"{x:183,y:560,t:1527189068246};\\\", \\\"{x:216,y:590,t:1527189068262};\\\", \\\"{x:260,y:619,t:1527189068278};\\\", \\\"{x:302,y:646,t:1527189068295};\\\", \\\"{x:338,y:669,t:1527189068312};\\\", \\\"{x:373,y:695,t:1527189068328};\\\", \\\"{x:390,y:707,t:1527189068344};\\\", \\\"{x:397,y:712,t:1527189068362};\\\", \\\"{x:399,y:712,t:1527189068378};\\\", \\\"{x:401,y:712,t:1527189068394};\\\", \\\"{x:402,y:712,t:1527189068412};\\\", \\\"{x:405,y:713,t:1527189068428};\\\", \\\"{x:409,y:716,t:1527189068445};\\\", \\\"{x:414,y:717,t:1527189068462};\\\", \\\"{x:416,y:719,t:1527189068478};\\\", \\\"{x:415,y:714,t:1527189068516};\\\", \\\"{x:408,y:708,t:1527189068530};\\\", \\\"{x:384,y:692,t:1527189068546};\\\", \\\"{x:356,y:679,t:1527189068563};\\\", \\\"{x:322,y:660,t:1527189068580};\\\", \\\"{x:304,y:644,t:1527189068595};\\\", \\\"{x:277,y:619,t:1527189068613};\\\", \\\"{x:254,y:600,t:1527189068629};\\\", \\\"{x:231,y:589,t:1527189068645};\\\", \\\"{x:217,y:583,t:1527189068662};\\\", \\\"{x:216,y:583,t:1527189068714};\\\", \\\"{x:213,y:583,t:1527189068728};\\\", \\\"{x:202,y:583,t:1527189068744};\\\", \\\"{x:191,y:583,t:1527189068762};\\\", \\\"{x:187,y:583,t:1527189068778};\\\", \\\"{x:185,y:583,t:1527189068819};\\\", \\\"{x:182,y:583,t:1527189068829};\\\", \\\"{x:171,y:579,t:1527189068845};\\\", \\\"{x:159,y:572,t:1527189068862};\\\", \\\"{x:151,y:569,t:1527189068879};\\\", \\\"{x:147,y:566,t:1527189068896};\\\", \\\"{x:146,y:565,t:1527189068912};\\\", \\\"{x:144,y:564,t:1527189068929};\\\", \\\"{x:143,y:563,t:1527189068946};\\\", \\\"{x:139,y:559,t:1527189068963};\\\", \\\"{x:132,y:554,t:1527189068980};\\\", \\\"{x:131,y:553,t:1527189068996};\\\", \\\"{x:131,y:552,t:1527189069011};\\\", \\\"{x:131,y:551,t:1527189069029};\\\", \\\"{x:131,y:550,t:1527189069046};\\\", \\\"{x:131,y:549,t:1527189069062};\\\", \\\"{x:132,y:548,t:1527189069124};\\\", \\\"{x:135,y:548,t:1527189069139};\\\", \\\"{x:138,y:548,t:1527189069148};\\\", \\\"{x:139,y:547,t:1527189069162};\\\", \\\"{x:142,y:546,t:1527189069179};\\\", \\\"{x:143,y:546,t:1527189069252};\\\", \\\"{x:150,y:546,t:1527189069461};\\\", \\\"{x:213,y:581,t:1527189069479};\\\", \\\"{x:296,y:620,t:1527189069496};\\\", \\\"{x:368,y:649,t:1527189069513};\\\", \\\"{x:424,y:668,t:1527189069529};\\\", \\\"{x:441,y:671,t:1527189069546};\\\", \\\"{x:442,y:671,t:1527189069563};\\\", \\\"{x:436,y:669,t:1527189069595};\\\", \\\"{x:402,y:659,t:1527189069613};\\\", \\\"{x:343,y:640,t:1527189069630};\\\", \\\"{x:272,y:613,t:1527189069646};\\\", \\\"{x:222,y:591,t:1527189069664};\\\", \\\"{x:208,y:585,t:1527189069680};\\\", \\\"{x:207,y:584,t:1527189069696};\\\", \\\"{x:206,y:583,t:1527189069731};\\\", \\\"{x:201,y:579,t:1527189069746};\\\", \\\"{x:190,y:571,t:1527189069764};\\\", \\\"{x:185,y:567,t:1527189069779};\\\", \\\"{x:184,y:567,t:1527189069796};\\\", \\\"{x:182,y:565,t:1527189069853};\\\", \\\"{x:179,y:561,t:1527189069864};\\\", \\\"{x:172,y:556,t:1527189069880};\\\", \\\"{x:165,y:552,t:1527189069896};\\\", \\\"{x:160,y:550,t:1527189069915};\\\", \\\"{x:159,y:549,t:1527189069930};\\\", \\\"{x:158,y:548,t:1527189069947};\\\", \\\"{x:157,y:546,t:1527189069962};\\\", \\\"{x:155,y:542,t:1527189069981};\\\", \\\"{x:152,y:539,t:1527189069997};\\\", \\\"{x:152,y:538,t:1527189070012};\\\", \\\"{x:165,y:544,t:1527189070420};\\\", \\\"{x:188,y:560,t:1527189070431};\\\", \\\"{x:256,y:598,t:1527189070447};\\\", \\\"{x:344,y:655,t:1527189070463};\\\", \\\"{x:391,y:686,t:1527189070480};\\\", \\\"{x:418,y:704,t:1527189070497};\\\", \\\"{x:424,y:708,t:1527189070514};\\\", \\\"{x:426,y:709,t:1527189070530};\\\", \\\"{x:428,y:710,t:1527189070546};\\\", \\\"{x:432,y:710,t:1527189070564};\\\", \\\"{x:439,y:710,t:1527189070580};\\\", \\\"{x:443,y:710,t:1527189070596};\\\", \\\"{x:447,y:710,t:1527189070614};\\\", \\\"{x:449,y:710,t:1527189070630};\\\", \\\"{x:450,y:710,t:1527189070647};\\\", \\\"{x:451,y:710,t:1527189070664};\\\", \\\"{x:453,y:710,t:1527189070691};\\\", \\\"{x:457,y:714,t:1527189070707};\\\", \\\"{x:461,y:720,t:1527189070716};\\\", \\\"{x:464,y:726,t:1527189070730};\\\", \\\"{x:469,y:732,t:1527189070746};\\\", \\\"{x:469,y:733,t:1527189070763};\\\" ] }, { \\\"rt\\\": 5661, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 463159, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:735,t:1527189073524};\\\", \\\"{x:496,y:743,t:1527189073535};\\\", \\\"{x:552,y:753,t:1527189073552};\\\", \\\"{x:591,y:759,t:1527189073569};\\\", \\\"{x:623,y:760,t:1527189073585};\\\", \\\"{x:663,y:765,t:1527189073602};\\\", \\\"{x:706,y:774,t:1527189073616};\\\", \\\"{x:763,y:786,t:1527189073632};\\\", \\\"{x:823,y:799,t:1527189073649};\\\", \\\"{x:929,y:811,t:1527189073666};\\\", \\\"{x:985,y:811,t:1527189073683};\\\", \\\"{x:1018,y:814,t:1527189073699};\\\", \\\"{x:1034,y:814,t:1527189073716};\\\", \\\"{x:1036,y:814,t:1527189073733};\\\", \\\"{x:1037,y:814,t:1527189073820};\\\", \\\"{x:1041,y:818,t:1527189073834};\\\", \\\"{x:1045,y:826,t:1527189073850};\\\", \\\"{x:1048,y:829,t:1527189073867};\\\", \\\"{x:1050,y:830,t:1527189073883};\\\", \\\"{x:1053,y:835,t:1527189073900};\\\", \\\"{x:1056,y:841,t:1527189073917};\\\", \\\"{x:1063,y:851,t:1527189073934};\\\", \\\"{x:1073,y:861,t:1527189073950};\\\", \\\"{x:1076,y:864,t:1527189073966};\\\", \\\"{x:1076,y:865,t:1527189073984};\\\", \\\"{x:1071,y:859,t:1527189074772};\\\", \\\"{x:1062,y:854,t:1527189074784};\\\", \\\"{x:1034,y:837,t:1527189074800};\\\", \\\"{x:996,y:815,t:1527189074818};\\\", \\\"{x:959,y:797,t:1527189074834};\\\", \\\"{x:927,y:780,t:1527189074851};\\\", \\\"{x:898,y:764,t:1527189074867};\\\", \\\"{x:882,y:753,t:1527189074884};\\\", \\\"{x:860,y:738,t:1527189074900};\\\", \\\"{x:829,y:717,t:1527189074918};\\\", \\\"{x:805,y:702,t:1527189074934};\\\", \\\"{x:770,y:680,t:1527189074951};\\\", \\\"{x:743,y:662,t:1527189074967};\\\", \\\"{x:725,y:653,t:1527189074983};\\\", \\\"{x:706,y:645,t:1527189075000};\\\", \\\"{x:686,y:637,t:1527189075017};\\\", \\\"{x:667,y:632,t:1527189075034};\\\", \\\"{x:648,y:626,t:1527189075052};\\\", \\\"{x:622,y:618,t:1527189075067};\\\", \\\"{x:607,y:613,t:1527189075083};\\\", \\\"{x:590,y:608,t:1527189075100};\\\", \\\"{x:573,y:603,t:1527189075118};\\\", \\\"{x:558,y:600,t:1527189075134};\\\", \\\"{x:550,y:598,t:1527189075151};\\\", \\\"{x:550,y:597,t:1527189075170};\\\", \\\"{x:555,y:596,t:1527189075186};\\\", \\\"{x:570,y:596,t:1527189075201};\\\", \\\"{x:613,y:596,t:1527189075217};\\\", \\\"{x:645,y:596,t:1527189075234};\\\", \\\"{x:681,y:596,t:1527189075251};\\\", \\\"{x:701,y:594,t:1527189075267};\\\", \\\"{x:707,y:591,t:1527189075285};\\\", \\\"{x:711,y:588,t:1527189075302};\\\", \\\"{x:715,y:583,t:1527189075317};\\\", \\\"{x:725,y:576,t:1527189075336};\\\", \\\"{x:736,y:573,t:1527189075351};\\\", \\\"{x:740,y:571,t:1527189075367};\\\", \\\"{x:746,y:568,t:1527189075384};\\\", \\\"{x:756,y:564,t:1527189075401};\\\", \\\"{x:768,y:559,t:1527189075417};\\\", \\\"{x:778,y:555,t:1527189075435};\\\", \\\"{x:797,y:552,t:1527189075450};\\\", \\\"{x:806,y:549,t:1527189075467};\\\", \\\"{x:814,y:549,t:1527189075484};\\\", \\\"{x:821,y:549,t:1527189075501};\\\", \\\"{x:830,y:548,t:1527189075518};\\\", \\\"{x:836,y:546,t:1527189075534};\\\", \\\"{x:840,y:546,t:1527189075551};\\\", \\\"{x:841,y:546,t:1527189075595};\\\", \\\"{x:841,y:548,t:1527189075603};\\\", \\\"{x:841,y:550,t:1527189075619};\\\", \\\"{x:834,y:562,t:1527189075637};\\\", \\\"{x:820,y:572,t:1527189075651};\\\", \\\"{x:797,y:584,t:1527189075668};\\\", \\\"{x:762,y:593,t:1527189075684};\\\", \\\"{x:701,y:593,t:1527189075701};\\\", \\\"{x:637,y:593,t:1527189075718};\\\", \\\"{x:560,y:587,t:1527189075734};\\\", \\\"{x:501,y:577,t:1527189075751};\\\", \\\"{x:440,y:561,t:1527189075768};\\\", \\\"{x:401,y:556,t:1527189075785};\\\", \\\"{x:380,y:551,t:1527189075801};\\\", \\\"{x:365,y:549,t:1527189075819};\\\", \\\"{x:360,y:549,t:1527189075834};\\\", \\\"{x:354,y:549,t:1527189075851};\\\", \\\"{x:342,y:547,t:1527189075869};\\\", \\\"{x:320,y:544,t:1527189075884};\\\", \\\"{x:299,y:540,t:1527189075901};\\\", \\\"{x:279,y:540,t:1527189075919};\\\", \\\"{x:257,y:540,t:1527189075935};\\\", \\\"{x:241,y:540,t:1527189075951};\\\", \\\"{x:219,y:542,t:1527189075967};\\\", \\\"{x:198,y:546,t:1527189075984};\\\", \\\"{x:189,y:549,t:1527189076002};\\\", \\\"{x:188,y:550,t:1527189076017};\\\", \\\"{x:187,y:550,t:1527189076538};\\\", \\\"{x:182,y:548,t:1527189076551};\\\", \\\"{x:177,y:546,t:1527189076569};\\\", \\\"{x:168,y:542,t:1527189076585};\\\", \\\"{x:159,y:540,t:1527189076602};\\\", \\\"{x:155,y:540,t:1527189076619};\\\", \\\"{x:152,y:538,t:1527189076635};\\\", \\\"{x:151,y:538,t:1527189076667};\\\", \\\"{x:153,y:545,t:1527189076811};\\\", \\\"{x:163,y:554,t:1527189076818};\\\", \\\"{x:187,y:583,t:1527189076836};\\\", \\\"{x:235,y:630,t:1527189076852};\\\", \\\"{x:288,y:688,t:1527189076869};\\\", \\\"{x:345,y:759,t:1527189076885};\\\", \\\"{x:412,y:822,t:1527189076902};\\\", \\\"{x:462,y:854,t:1527189076919};\\\", \\\"{x:487,y:865,t:1527189076935};\\\", \\\"{x:495,y:866,t:1527189076952};\\\", \\\"{x:495,y:864,t:1527189076994};\\\", \\\"{x:493,y:863,t:1527189077002};\\\", \\\"{x:489,y:854,t:1527189077019};\\\", \\\"{x:482,y:844,t:1527189077036};\\\", \\\"{x:477,y:836,t:1527189077052};\\\", \\\"{x:472,y:830,t:1527189077069};\\\", \\\"{x:472,y:828,t:1527189077086};\\\", \\\"{x:471,y:824,t:1527189077102};\\\", \\\"{x:469,y:817,t:1527189077119};\\\", \\\"{x:466,y:802,t:1527189077136};\\\", \\\"{x:465,y:793,t:1527189077153};\\\", \\\"{x:465,y:790,t:1527189077169};\\\", \\\"{x:467,y:784,t:1527189077186};\\\", \\\"{x:472,y:780,t:1527189077202};\\\", \\\"{x:476,y:777,t:1527189077219};\\\", \\\"{x:480,y:774,t:1527189077236};\\\", \\\"{x:482,y:771,t:1527189077253};\\\", \\\"{x:484,y:770,t:1527189077269};\\\", \\\"{x:484,y:766,t:1527189077286};\\\", \\\"{x:486,y:764,t:1527189077303};\\\", \\\"{x:487,y:759,t:1527189077320};\\\", \\\"{x:488,y:757,t:1527189077336};\\\", \\\"{x:488,y:755,t:1527189077370};\\\", \\\"{x:488,y:753,t:1527189077386};\\\", \\\"{x:488,y:750,t:1527189077403};\\\", \\\"{x:488,y:748,t:1527189077419};\\\", \\\"{x:488,y:747,t:1527189077436};\\\" ] }, { \\\"rt\\\": 19396, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 483836, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -04 PM-02 PM-C -B -12 PM-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:746,t:1527189080156};\\\", \\\"{x:515,y:749,t:1527189080174};\\\", \\\"{x:537,y:755,t:1527189080191};\\\", \\\"{x:566,y:765,t:1527189080206};\\\", \\\"{x:599,y:773,t:1527189080221};\\\", \\\"{x:631,y:780,t:1527189080238};\\\", \\\"{x:660,y:790,t:1527189080255};\\\", \\\"{x:702,y:801,t:1527189080271};\\\", \\\"{x:735,y:808,t:1527189080288};\\\", \\\"{x:759,y:813,t:1527189080305};\\\", \\\"{x:781,y:816,t:1527189080321};\\\", \\\"{x:817,y:824,t:1527189080338};\\\", \\\"{x:849,y:836,t:1527189080354};\\\", \\\"{x:911,y:865,t:1527189080371};\\\", \\\"{x:974,y:892,t:1527189080388};\\\", \\\"{x:1000,y:907,t:1527189080406};\\\", \\\"{x:1001,y:907,t:1527189080421};\\\", \\\"{x:1002,y:908,t:1527189080676};\\\", \\\"{x:1006,y:908,t:1527189080689};\\\", \\\"{x:1027,y:908,t:1527189080705};\\\", \\\"{x:1089,y:901,t:1527189080722};\\\", \\\"{x:1123,y:901,t:1527189080738};\\\", \\\"{x:1242,y:901,t:1527189080756};\\\", \\\"{x:1308,y:895,t:1527189080773};\\\", \\\"{x:1365,y:884,t:1527189080789};\\\", \\\"{x:1426,y:876,t:1527189080806};\\\", \\\"{x:1482,y:866,t:1527189080823};\\\", \\\"{x:1546,y:851,t:1527189080839};\\\", \\\"{x:1604,y:843,t:1527189080856};\\\", \\\"{x:1647,y:836,t:1527189080872};\\\", \\\"{x:1692,y:832,t:1527189080889};\\\", \\\"{x:1722,y:827,t:1527189080906};\\\", \\\"{x:1754,y:820,t:1527189080922};\\\", \\\"{x:1760,y:817,t:1527189080939};\\\", \\\"{x:1764,y:816,t:1527189080955};\\\", \\\"{x:1773,y:813,t:1527189080973};\\\", \\\"{x:1793,y:804,t:1527189080989};\\\", \\\"{x:1817,y:785,t:1527189081005};\\\", \\\"{x:1825,y:769,t:1527189081023};\\\", \\\"{x:1825,y:760,t:1527189081040};\\\", \\\"{x:1817,y:750,t:1527189081056};\\\", \\\"{x:1804,y:742,t:1527189081072};\\\", \\\"{x:1786,y:733,t:1527189081089};\\\", \\\"{x:1761,y:722,t:1527189081105};\\\", \\\"{x:1715,y:701,t:1527189081123};\\\", \\\"{x:1691,y:691,t:1527189081139};\\\", \\\"{x:1681,y:687,t:1527189081156};\\\", \\\"{x:1679,y:687,t:1527189081173};\\\", \\\"{x:1678,y:687,t:1527189081203};\\\", \\\"{x:1677,y:687,t:1527189081211};\\\", \\\"{x:1672,y:687,t:1527189081223};\\\", \\\"{x:1655,y:698,t:1527189081240};\\\", \\\"{x:1637,y:707,t:1527189081256};\\\", \\\"{x:1624,y:711,t:1527189081273};\\\", \\\"{x:1622,y:711,t:1527189081290};\\\", \\\"{x:1621,y:711,t:1527189081364};\\\", \\\"{x:1620,y:713,t:1527189081373};\\\", \\\"{x:1619,y:713,t:1527189081390};\\\", \\\"{x:1616,y:713,t:1527189081406};\\\", \\\"{x:1616,y:712,t:1527189081572};\\\", \\\"{x:1616,y:710,t:1527189081590};\\\", \\\"{x:1616,y:709,t:1527189081607};\\\", \\\"{x:1616,y:708,t:1527189081700};\\\", \\\"{x:1615,y:705,t:1527189081707};\\\", \\\"{x:1615,y:702,t:1527189081726};\\\", \\\"{x:1613,y:699,t:1527189081739};\\\", \\\"{x:1613,y:698,t:1527189081756};\\\", \\\"{x:1613,y:705,t:1527189083094};\\\", \\\"{x:1613,y:727,t:1527189083107};\\\", \\\"{x:1613,y:746,t:1527189083124};\\\", \\\"{x:1613,y:766,t:1527189083141};\\\", \\\"{x:1613,y:788,t:1527189083159};\\\", \\\"{x:1613,y:814,t:1527189083174};\\\", \\\"{x:1613,y:838,t:1527189083191};\\\", \\\"{x:1613,y:872,t:1527189083208};\\\", \\\"{x:1613,y:914,t:1527189083225};\\\", \\\"{x:1612,y:946,t:1527189083241};\\\", \\\"{x:1610,y:971,t:1527189083258};\\\", \\\"{x:1609,y:990,t:1527189083276};\\\", \\\"{x:1609,y:992,t:1527189083291};\\\", \\\"{x:1608,y:993,t:1527189083468};\\\", \\\"{x:1608,y:988,t:1527189083475};\\\", \\\"{x:1598,y:955,t:1527189083491};\\\", \\\"{x:1588,y:926,t:1527189083508};\\\", \\\"{x:1577,y:897,t:1527189083525};\\\", \\\"{x:1567,y:856,t:1527189083541};\\\", \\\"{x:1558,y:810,t:1527189083558};\\\", \\\"{x:1555,y:784,t:1527189083575};\\\", \\\"{x:1553,y:755,t:1527189083591};\\\", \\\"{x:1548,y:729,t:1527189083608};\\\", \\\"{x:1544,y:707,t:1527189083625};\\\", \\\"{x:1543,y:695,t:1527189083642};\\\", \\\"{x:1542,y:690,t:1527189083658};\\\", \\\"{x:1542,y:688,t:1527189083675};\\\", \\\"{x:1542,y:686,t:1527189083692};\\\", \\\"{x:1542,y:685,t:1527189083708};\\\", \\\"{x:1542,y:683,t:1527189083726};\\\", \\\"{x:1544,y:681,t:1527189083742};\\\", \\\"{x:1546,y:680,t:1527189083758};\\\", \\\"{x:1547,y:679,t:1527189083775};\\\", \\\"{x:1550,y:678,t:1527189083792};\\\", \\\"{x:1553,y:676,t:1527189083808};\\\", \\\"{x:1557,y:673,t:1527189083825};\\\", \\\"{x:1563,y:669,t:1527189083842};\\\", \\\"{x:1567,y:665,t:1527189083858};\\\", \\\"{x:1570,y:662,t:1527189083875};\\\", \\\"{x:1571,y:659,t:1527189083892};\\\", \\\"{x:1572,y:657,t:1527189083908};\\\", \\\"{x:1572,y:656,t:1527189083939};\\\", \\\"{x:1572,y:654,t:1527189083955};\\\", \\\"{x:1572,y:653,t:1527189083964};\\\", \\\"{x:1572,y:651,t:1527189083975};\\\", \\\"{x:1572,y:647,t:1527189083992};\\\", \\\"{x:1572,y:644,t:1527189084008};\\\", \\\"{x:1572,y:642,t:1527189084025};\\\", \\\"{x:1572,y:641,t:1527189084156};\\\", \\\"{x:1571,y:642,t:1527189084172};\\\", \\\"{x:1570,y:645,t:1527189084179};\\\", \\\"{x:1570,y:648,t:1527189084192};\\\", \\\"{x:1569,y:659,t:1527189084209};\\\", \\\"{x:1569,y:668,t:1527189084225};\\\", \\\"{x:1569,y:676,t:1527189084242};\\\", \\\"{x:1569,y:690,t:1527189084260};\\\", \\\"{x:1569,y:704,t:1527189084275};\\\", \\\"{x:1568,y:722,t:1527189084292};\\\", \\\"{x:1566,y:741,t:1527189084309};\\\", \\\"{x:1563,y:756,t:1527189084325};\\\", \\\"{x:1561,y:772,t:1527189084342};\\\", \\\"{x:1559,y:783,t:1527189084360};\\\", \\\"{x:1556,y:799,t:1527189084375};\\\", \\\"{x:1554,y:812,t:1527189084393};\\\", \\\"{x:1551,y:828,t:1527189084409};\\\", \\\"{x:1548,y:849,t:1527189084425};\\\", \\\"{x:1541,y:872,t:1527189084442};\\\", \\\"{x:1532,y:901,t:1527189084459};\\\", \\\"{x:1531,y:914,t:1527189084475};\\\", \\\"{x:1530,y:918,t:1527189084493};\\\", \\\"{x:1527,y:926,t:1527189084510};\\\", \\\"{x:1526,y:940,t:1527189084526};\\\", \\\"{x:1525,y:959,t:1527189084542};\\\", \\\"{x:1525,y:978,t:1527189084559};\\\", \\\"{x:1525,y:987,t:1527189084576};\\\", \\\"{x:1525,y:989,t:1527189084592};\\\", \\\"{x:1523,y:990,t:1527189084644};\\\", \\\"{x:1514,y:988,t:1527189084659};\\\", \\\"{x:1496,y:983,t:1527189084675};\\\", \\\"{x:1481,y:979,t:1527189084692};\\\", \\\"{x:1465,y:973,t:1527189084708};\\\", \\\"{x:1459,y:971,t:1527189084727};\\\", \\\"{x:1458,y:971,t:1527189084742};\\\", \\\"{x:1458,y:970,t:1527189084759};\\\", \\\"{x:1458,y:967,t:1527189084777};\\\", \\\"{x:1458,y:961,t:1527189084792};\\\", \\\"{x:1457,y:957,t:1527189084809};\\\", \\\"{x:1457,y:954,t:1527189084826};\\\", \\\"{x:1457,y:951,t:1527189084842};\\\", \\\"{x:1457,y:943,t:1527189084859};\\\", \\\"{x:1458,y:939,t:1527189084876};\\\", \\\"{x:1460,y:935,t:1527189084892};\\\", \\\"{x:1462,y:934,t:1527189084909};\\\", \\\"{x:1463,y:932,t:1527189084926};\\\", \\\"{x:1465,y:929,t:1527189084943};\\\", \\\"{x:1467,y:927,t:1527189084959};\\\", \\\"{x:1471,y:919,t:1527189084976};\\\", \\\"{x:1474,y:910,t:1527189084993};\\\", \\\"{x:1475,y:905,t:1527189085009};\\\", \\\"{x:1475,y:899,t:1527189085026};\\\", \\\"{x:1476,y:888,t:1527189085043};\\\", \\\"{x:1478,y:883,t:1527189085059};\\\", \\\"{x:1478,y:877,t:1527189085076};\\\", \\\"{x:1478,y:868,t:1527189085093};\\\", \\\"{x:1478,y:859,t:1527189085110};\\\", \\\"{x:1477,y:855,t:1527189085126};\\\", \\\"{x:1477,y:854,t:1527189085143};\\\", \\\"{x:1477,y:853,t:1527189085163};\\\", \\\"{x:1477,y:851,t:1527189085292};\\\", \\\"{x:1477,y:849,t:1527189085309};\\\", \\\"{x:1477,y:848,t:1527189085340};\\\", \\\"{x:1477,y:846,t:1527189085363};\\\", \\\"{x:1478,y:845,t:1527189085379};\\\", \\\"{x:1478,y:843,t:1527189085395};\\\", \\\"{x:1479,y:842,t:1527189085410};\\\", \\\"{x:1479,y:841,t:1527189085444};\\\", \\\"{x:1473,y:840,t:1527189085620};\\\", \\\"{x:1461,y:840,t:1527189085627};\\\", \\\"{x:1414,y:840,t:1527189085643};\\\", \\\"{x:1327,y:832,t:1527189085660};\\\", \\\"{x:1221,y:816,t:1527189085677};\\\", \\\"{x:1103,y:790,t:1527189085693};\\\", \\\"{x:989,y:755,t:1527189085710};\\\", \\\"{x:892,y:708,t:1527189085726};\\\", \\\"{x:825,y:678,t:1527189085743};\\\", \\\"{x:798,y:663,t:1527189085759};\\\", \\\"{x:780,y:653,t:1527189085776};\\\", \\\"{x:761,y:646,t:1527189085793};\\\", \\\"{x:747,y:641,t:1527189085810};\\\", \\\"{x:736,y:633,t:1527189085826};\\\", \\\"{x:731,y:628,t:1527189085843};\\\", \\\"{x:720,y:619,t:1527189085860};\\\", \\\"{x:710,y:613,t:1527189085876};\\\", \\\"{x:701,y:609,t:1527189085893};\\\", \\\"{x:695,y:609,t:1527189085909};\\\", \\\"{x:691,y:608,t:1527189085926};\\\", \\\"{x:687,y:609,t:1527189085986};\\\", \\\"{x:684,y:611,t:1527189085994};\\\", \\\"{x:679,y:613,t:1527189086010};\\\", \\\"{x:657,y:620,t:1527189086026};\\\", \\\"{x:654,y:620,t:1527189086044};\\\", \\\"{x:650,y:620,t:1527189086108};\\\", \\\"{x:646,y:620,t:1527189086115};\\\", \\\"{x:642,y:620,t:1527189086127};\\\", \\\"{x:631,y:618,t:1527189086144};\\\", \\\"{x:626,y:617,t:1527189086159};\\\", \\\"{x:625,y:615,t:1527189086177};\\\", \\\"{x:625,y:609,t:1527189086194};\\\", \\\"{x:625,y:605,t:1527189086210};\\\", \\\"{x:625,y:600,t:1527189086228};\\\", \\\"{x:625,y:599,t:1527189086243};\\\", \\\"{x:625,y:597,t:1527189086292};\\\", \\\"{x:624,y:595,t:1527189086315};\\\", \\\"{x:624,y:594,t:1527189086355};\\\", \\\"{x:622,y:590,t:1527189086717};\\\", \\\"{x:615,y:584,t:1527189086728};\\\", \\\"{x:611,y:581,t:1527189086743};\\\", \\\"{x:613,y:581,t:1527189087556};\\\", \\\"{x:633,y:586,t:1527189087563};\\\", \\\"{x:664,y:595,t:1527189087578};\\\", \\\"{x:731,y:605,t:1527189087594};\\\", \\\"{x:844,y:623,t:1527189087611};\\\", \\\"{x:945,y:643,t:1527189087628};\\\", \\\"{x:1026,y:654,t:1527189087645};\\\", \\\"{x:1090,y:662,t:1527189087661};\\\", \\\"{x:1126,y:667,t:1527189087678};\\\", \\\"{x:1150,y:670,t:1527189087694};\\\", \\\"{x:1159,y:671,t:1527189087712};\\\", \\\"{x:1163,y:671,t:1527189087728};\\\", \\\"{x:1167,y:671,t:1527189087744};\\\", \\\"{x:1175,y:671,t:1527189087761};\\\", \\\"{x:1185,y:668,t:1527189087778};\\\", \\\"{x:1199,y:661,t:1527189087795};\\\", \\\"{x:1217,y:653,t:1527189087812};\\\", \\\"{x:1236,y:646,t:1527189087827};\\\", \\\"{x:1252,y:640,t:1527189087845};\\\", \\\"{x:1265,y:637,t:1527189087862};\\\", \\\"{x:1278,y:635,t:1527189087878};\\\", \\\"{x:1292,y:631,t:1527189087895};\\\", \\\"{x:1308,y:630,t:1527189087913};\\\", \\\"{x:1325,y:625,t:1527189087929};\\\", \\\"{x:1349,y:623,t:1527189087945};\\\", \\\"{x:1374,y:621,t:1527189087962};\\\", \\\"{x:1389,y:621,t:1527189087978};\\\", \\\"{x:1396,y:621,t:1527189087995};\\\", \\\"{x:1397,y:621,t:1527189088020};\\\", \\\"{x:1401,y:621,t:1527189088044};\\\", \\\"{x:1405,y:621,t:1527189088051};\\\", \\\"{x:1412,y:622,t:1527189088063};\\\", \\\"{x:1426,y:628,t:1527189088078};\\\", \\\"{x:1430,y:630,t:1527189088096};\\\", \\\"{x:1432,y:630,t:1527189088112};\\\", \\\"{x:1432,y:631,t:1527189088139};\\\", \\\"{x:1433,y:631,t:1527189088203};\\\", \\\"{x:1437,y:633,t:1527189088212};\\\", \\\"{x:1450,y:636,t:1527189088228};\\\", \\\"{x:1460,y:639,t:1527189088246};\\\", \\\"{x:1465,y:640,t:1527189088262};\\\", \\\"{x:1465,y:642,t:1527189088434};\\\", \\\"{x:1463,y:647,t:1527189088445};\\\", \\\"{x:1460,y:658,t:1527189088462};\\\", \\\"{x:1454,y:670,t:1527189088478};\\\", \\\"{x:1448,y:685,t:1527189088494};\\\", \\\"{x:1445,y:699,t:1527189088511};\\\", \\\"{x:1443,y:727,t:1527189088528};\\\", \\\"{x:1443,y:769,t:1527189088545};\\\", \\\"{x:1441,y:809,t:1527189088562};\\\", \\\"{x:1440,y:855,t:1527189088579};\\\", \\\"{x:1440,y:873,t:1527189088595};\\\", \\\"{x:1439,y:886,t:1527189088612};\\\", \\\"{x:1439,y:902,t:1527189088629};\\\", \\\"{x:1439,y:925,t:1527189088645};\\\", \\\"{x:1439,y:952,t:1527189088662};\\\", \\\"{x:1439,y:975,t:1527189088679};\\\", \\\"{x:1439,y:989,t:1527189088696};\\\", \\\"{x:1439,y:992,t:1527189088712};\\\", \\\"{x:1442,y:983,t:1527189088883};\\\", \\\"{x:1443,y:974,t:1527189088896};\\\", \\\"{x:1447,y:955,t:1527189088912};\\\", \\\"{x:1449,y:933,t:1527189088929};\\\", \\\"{x:1449,y:898,t:1527189088953};\\\", \\\"{x:1449,y:763,t:1527189088993};\\\", \\\"{x:1449,y:719,t:1527189088994};\\\", \\\"{x:1449,y:660,t:1527189089011};\\\", \\\"{x:1449,y:621,t:1527189089029};\\\", \\\"{x:1449,y:602,t:1527189089045};\\\", \\\"{x:1449,y:588,t:1527189089062};\\\", \\\"{x:1449,y:582,t:1527189089079};\\\", \\\"{x:1449,y:575,t:1527189089095};\\\", \\\"{x:1447,y:572,t:1527189089112};\\\", \\\"{x:1446,y:571,t:1527189089129};\\\", \\\"{x:1445,y:569,t:1527189089145};\\\", \\\"{x:1444,y:568,t:1527189089219};\\\", \\\"{x:1442,y:573,t:1527189089229};\\\", \\\"{x:1429,y:602,t:1527189089245};\\\", \\\"{x:1418,y:635,t:1527189089262};\\\", \\\"{x:1406,y:677,t:1527189089279};\\\", \\\"{x:1402,y:705,t:1527189089294};\\\", \\\"{x:1402,y:724,t:1527189089311};\\\", \\\"{x:1402,y:759,t:1527189089328};\\\", \\\"{x:1400,y:813,t:1527189089345};\\\", \\\"{x:1400,y:866,t:1527189089362};\\\", \\\"{x:1394,y:926,t:1527189089378};\\\", \\\"{x:1392,y:940,t:1527189089396};\\\", \\\"{x:1392,y:942,t:1527189089411};\\\", \\\"{x:1392,y:943,t:1527189089429};\\\", \\\"{x:1390,y:945,t:1527189089445};\\\", \\\"{x:1390,y:946,t:1527189089483};\\\", \\\"{x:1390,y:947,t:1527189089524};\\\", \\\"{x:1389,y:947,t:1527189089531};\\\", \\\"{x:1386,y:946,t:1527189089546};\\\", \\\"{x:1386,y:944,t:1527189089563};\\\", \\\"{x:1382,y:934,t:1527189089580};\\\", \\\"{x:1379,y:924,t:1527189089596};\\\", \\\"{x:1377,y:916,t:1527189089612};\\\", \\\"{x:1377,y:911,t:1527189089630};\\\", \\\"{x:1377,y:910,t:1527189089647};\\\", \\\"{x:1377,y:909,t:1527189089691};\\\", \\\"{x:1377,y:908,t:1527189089716};\\\", \\\"{x:1377,y:907,t:1527189089812};\\\", \\\"{x:1380,y:912,t:1527189089829};\\\", \\\"{x:1383,y:920,t:1527189089846};\\\", \\\"{x:1384,y:927,t:1527189089863};\\\", \\\"{x:1384,y:934,t:1527189089879};\\\", \\\"{x:1384,y:943,t:1527189089895};\\\", \\\"{x:1384,y:950,t:1527189089911};\\\", \\\"{x:1384,y:952,t:1527189089928};\\\", \\\"{x:1384,y:953,t:1527189089954};\\\", \\\"{x:1384,y:949,t:1527189090115};\\\", \\\"{x:1384,y:944,t:1527189090129};\\\", \\\"{x:1384,y:940,t:1527189090146};\\\", \\\"{x:1384,y:937,t:1527189090162};\\\", \\\"{x:1384,y:935,t:1527189090179};\\\", \\\"{x:1384,y:934,t:1527189090235};\\\", \\\"{x:1384,y:932,t:1527189090246};\\\", \\\"{x:1384,y:931,t:1527189090263};\\\", \\\"{x:1384,y:930,t:1527189090279};\\\", \\\"{x:1384,y:929,t:1527189090296};\\\", \\\"{x:1384,y:928,t:1527189090313};\\\", \\\"{x:1384,y:927,t:1527189090387};\\\", \\\"{x:1384,y:926,t:1527189090396};\\\", \\\"{x:1384,y:924,t:1527189090414};\\\", \\\"{x:1384,y:922,t:1527189090429};\\\", \\\"{x:1386,y:918,t:1527189090446};\\\", \\\"{x:1387,y:914,t:1527189090464};\\\", \\\"{x:1388,y:911,t:1527189090479};\\\", \\\"{x:1388,y:908,t:1527189090497};\\\", \\\"{x:1389,y:908,t:1527189090514};\\\", \\\"{x:1390,y:906,t:1527189090529};\\\", \\\"{x:1390,y:905,t:1527189090547};\\\", \\\"{x:1390,y:904,t:1527189092412};\\\", \\\"{x:1393,y:900,t:1527189092419};\\\", \\\"{x:1396,y:896,t:1527189092430};\\\", \\\"{x:1399,y:892,t:1527189092447};\\\", \\\"{x:1401,y:890,t:1527189092464};\\\", \\\"{x:1402,y:889,t:1527189092481};\\\", \\\"{x:1402,y:888,t:1527189092497};\\\", \\\"{x:1402,y:887,t:1527189092524};\\\", \\\"{x:1402,y:886,t:1527189092531};\\\", \\\"{x:1402,y:884,t:1527189092548};\\\", \\\"{x:1402,y:876,t:1527189092564};\\\", \\\"{x:1402,y:870,t:1527189092580};\\\", \\\"{x:1400,y:865,t:1527189092597};\\\", \\\"{x:1398,y:861,t:1527189092614};\\\", \\\"{x:1395,y:855,t:1527189092631};\\\", \\\"{x:1391,y:847,t:1527189092647};\\\", \\\"{x:1387,y:842,t:1527189092664};\\\", \\\"{x:1383,y:835,t:1527189092680};\\\", \\\"{x:1377,y:828,t:1527189092697};\\\", \\\"{x:1374,y:824,t:1527189092714};\\\", \\\"{x:1371,y:821,t:1527189092731};\\\", \\\"{x:1369,y:817,t:1527189092748};\\\", \\\"{x:1368,y:814,t:1527189092765};\\\", \\\"{x:1364,y:809,t:1527189092781};\\\", \\\"{x:1361,y:803,t:1527189092797};\\\", \\\"{x:1356,y:796,t:1527189092815};\\\", \\\"{x:1354,y:791,t:1527189092831};\\\", \\\"{x:1352,y:789,t:1527189092848};\\\", \\\"{x:1352,y:787,t:1527189092864};\\\", \\\"{x:1351,y:785,t:1527189092891};\\\", \\\"{x:1351,y:784,t:1527189092907};\\\", \\\"{x:1350,y:783,t:1527189092915};\\\", \\\"{x:1350,y:782,t:1527189092939};\\\", \\\"{x:1349,y:780,t:1527189092948};\\\", \\\"{x:1349,y:778,t:1527189093003};\\\", \\\"{x:1348,y:778,t:1527189093015};\\\", \\\"{x:1348,y:777,t:1527189093044};\\\", \\\"{x:1348,y:776,t:1527189093067};\\\", \\\"{x:1348,y:775,t:1527189093083};\\\", \\\"{x:1348,y:774,t:1527189093107};\\\", \\\"{x:1347,y:773,t:1527189093123};\\\", \\\"{x:1347,y:772,t:1527189093131};\\\", \\\"{x:1346,y:771,t:1527189093147};\\\", \\\"{x:1345,y:769,t:1527189093179};\\\", \\\"{x:1345,y:768,t:1527189093204};\\\", \\\"{x:1345,y:767,t:1527189093882};\\\", \\\"{x:1344,y:767,t:1527189093897};\\\", \\\"{x:1342,y:779,t:1527189093914};\\\", \\\"{x:1342,y:801,t:1527189093931};\\\", \\\"{x:1342,y:813,t:1527189093947};\\\", \\\"{x:1342,y:824,t:1527189093964};\\\", \\\"{x:1342,y:834,t:1527189093981};\\\", \\\"{x:1342,y:843,t:1527189093997};\\\", \\\"{x:1340,y:858,t:1527189094014};\\\", \\\"{x:1340,y:877,t:1527189094032};\\\", \\\"{x:1338,y:890,t:1527189094048};\\\", \\\"{x:1338,y:900,t:1527189094065};\\\", \\\"{x:1338,y:912,t:1527189094085};\\\", \\\"{x:1339,y:928,t:1527189094102};\\\", \\\"{x:1339,y:945,t:1527189094119};\\\", \\\"{x:1339,y:965,t:1527189094135};\\\", \\\"{x:1339,y:972,t:1527189094152};\\\", \\\"{x:1339,y:974,t:1527189094168};\\\", \\\"{x:1339,y:975,t:1527189094185};\\\", \\\"{x:1339,y:976,t:1527189094207};\\\", \\\"{x:1340,y:976,t:1527189094384};\\\", \\\"{x:1340,y:969,t:1527189094391};\\\", \\\"{x:1340,y:961,t:1527189094403};\\\", \\\"{x:1340,y:945,t:1527189094419};\\\", \\\"{x:1340,y:925,t:1527189094435};\\\", \\\"{x:1340,y:908,t:1527189094452};\\\", \\\"{x:1340,y:882,t:1527189094468};\\\", \\\"{x:1337,y:860,t:1527189094485};\\\", \\\"{x:1336,y:838,t:1527189094503};\\\", \\\"{x:1334,y:821,t:1527189094518};\\\", \\\"{x:1331,y:807,t:1527189094535};\\\", \\\"{x:1331,y:802,t:1527189094553};\\\", \\\"{x:1330,y:799,t:1527189094569};\\\", \\\"{x:1330,y:798,t:1527189094591};\\\", \\\"{x:1330,y:797,t:1527189094603};\\\", \\\"{x:1330,y:796,t:1527189094619};\\\", \\\"{x:1330,y:794,t:1527189094636};\\\", \\\"{x:1330,y:791,t:1527189094653};\\\", \\\"{x:1330,y:787,t:1527189094668};\\\", \\\"{x:1330,y:782,t:1527189094685};\\\", \\\"{x:1330,y:779,t:1527189094702};\\\", \\\"{x:1330,y:775,t:1527189094718};\\\", \\\"{x:1332,y:769,t:1527189094735};\\\", \\\"{x:1333,y:763,t:1527189094753};\\\", \\\"{x:1336,y:754,t:1527189094769};\\\", \\\"{x:1340,y:741,t:1527189094786};\\\", \\\"{x:1342,y:733,t:1527189094803};\\\", \\\"{x:1344,y:725,t:1527189094818};\\\", \\\"{x:1345,y:721,t:1527189094836};\\\", \\\"{x:1346,y:717,t:1527189094852};\\\", \\\"{x:1347,y:713,t:1527189094868};\\\", \\\"{x:1349,y:709,t:1527189094886};\\\", \\\"{x:1350,y:705,t:1527189094902};\\\", \\\"{x:1350,y:701,t:1527189094918};\\\", \\\"{x:1352,y:698,t:1527189094935};\\\", \\\"{x:1352,y:696,t:1527189094952};\\\", \\\"{x:1352,y:695,t:1527189094968};\\\", \\\"{x:1351,y:694,t:1527189095535};\\\", \\\"{x:1339,y:697,t:1527189095554};\\\", \\\"{x:1327,y:702,t:1527189095569};\\\", \\\"{x:1311,y:707,t:1527189095586};\\\", \\\"{x:1298,y:712,t:1527189095603};\\\", \\\"{x:1281,y:718,t:1527189095619};\\\", \\\"{x:1265,y:722,t:1527189095635};\\\", \\\"{x:1242,y:728,t:1527189095653};\\\", \\\"{x:1227,y:730,t:1527189095669};\\\", \\\"{x:1225,y:730,t:1527189095943};\\\", \\\"{x:1206,y:726,t:1527189095953};\\\", \\\"{x:1136,y:718,t:1527189095970};\\\", \\\"{x:1078,y:709,t:1527189095987};\\\", \\\"{x:1046,y:700,t:1527189096003};\\\", \\\"{x:1014,y:690,t:1527189096020};\\\", \\\"{x:995,y:685,t:1527189096036};\\\", \\\"{x:984,y:680,t:1527189096052};\\\", \\\"{x:980,y:678,t:1527189096070};\\\", \\\"{x:974,y:675,t:1527189096085};\\\", \\\"{x:959,y:669,t:1527189096102};\\\", \\\"{x:924,y:660,t:1527189096118};\\\", \\\"{x:893,y:654,t:1527189096136};\\\", \\\"{x:866,y:650,t:1527189096152};\\\", \\\"{x:851,y:648,t:1527189096169};\\\", \\\"{x:832,y:642,t:1527189096186};\\\", \\\"{x:816,y:636,t:1527189096203};\\\", \\\"{x:806,y:631,t:1527189096221};\\\", \\\"{x:794,y:627,t:1527189096236};\\\", \\\"{x:787,y:625,t:1527189096251};\\\", \\\"{x:779,y:622,t:1527189096271};\\\", \\\"{x:767,y:618,t:1527189096289};\\\", \\\"{x:748,y:617,t:1527189096305};\\\", \\\"{x:729,y:613,t:1527189096321};\\\", \\\"{x:717,y:608,t:1527189096339};\\\", \\\"{x:713,y:605,t:1527189096356};\\\", \\\"{x:713,y:603,t:1527189096371};\\\", \\\"{x:714,y:597,t:1527189096389};\\\", \\\"{x:718,y:595,t:1527189096406};\\\", \\\"{x:718,y:594,t:1527189096422};\\\", \\\"{x:720,y:593,t:1527189096447};\\\", \\\"{x:725,y:592,t:1527189096456};\\\", \\\"{x:738,y:585,t:1527189096472};\\\", \\\"{x:753,y:579,t:1527189096489};\\\", \\\"{x:765,y:572,t:1527189096506};\\\", \\\"{x:772,y:567,t:1527189096522};\\\", \\\"{x:773,y:566,t:1527189096538};\\\", \\\"{x:773,y:565,t:1527189096559};\\\", \\\"{x:771,y:564,t:1527189096572};\\\", \\\"{x:770,y:562,t:1527189096590};\\\", \\\"{x:770,y:561,t:1527189096614};\\\", \\\"{x:772,y:556,t:1527189096622};\\\", \\\"{x:779,y:545,t:1527189096640};\\\", \\\"{x:785,y:534,t:1527189096656};\\\", \\\"{x:786,y:526,t:1527189096673};\\\", \\\"{x:787,y:520,t:1527189096689};\\\", \\\"{x:792,y:510,t:1527189096706};\\\", \\\"{x:794,y:503,t:1527189096723};\\\", \\\"{x:795,y:502,t:1527189096739};\\\", \\\"{x:796,y:501,t:1527189096756};\\\", \\\"{x:801,y:500,t:1527189097271};\\\", \\\"{x:803,y:500,t:1527189097279};\\\", \\\"{x:810,y:498,t:1527189097290};\\\", \\\"{x:822,y:494,t:1527189097307};\\\", \\\"{x:827,y:491,t:1527189097324};\\\", \\\"{x:830,y:490,t:1527189097340};\\\", \\\"{x:831,y:490,t:1527189097479};\\\", \\\"{x:833,y:490,t:1527189097535};\\\", \\\"{x:834,y:491,t:1527189097879};\\\", \\\"{x:834,y:493,t:1527189097890};\\\", \\\"{x:836,y:501,t:1527189097907};\\\", \\\"{x:836,y:510,t:1527189097925};\\\", \\\"{x:831,y:526,t:1527189097942};\\\", \\\"{x:821,y:547,t:1527189097957};\\\", \\\"{x:788,y:588,t:1527189097974};\\\", \\\"{x:763,y:609,t:1527189097990};\\\", \\\"{x:743,y:625,t:1527189098007};\\\", \\\"{x:722,y:638,t:1527189098024};\\\", \\\"{x:699,y:650,t:1527189098041};\\\", \\\"{x:682,y:657,t:1527189098057};\\\", \\\"{x:664,y:659,t:1527189098073};\\\", \\\"{x:646,y:661,t:1527189098091};\\\", \\\"{x:633,y:664,t:1527189098107};\\\", \\\"{x:623,y:665,t:1527189098124};\\\", \\\"{x:617,y:668,t:1527189098141};\\\", \\\"{x:614,y:669,t:1527189098157};\\\", \\\"{x:612,y:669,t:1527189098174};\\\", \\\"{x:606,y:673,t:1527189098190};\\\", \\\"{x:597,y:679,t:1527189098207};\\\", \\\"{x:588,y:689,t:1527189098224};\\\", \\\"{x:581,y:704,t:1527189098241};\\\", \\\"{x:577,y:717,t:1527189098257};\\\", \\\"{x:572,y:729,t:1527189098274};\\\", \\\"{x:571,y:733,t:1527189098291};\\\", \\\"{x:570,y:735,t:1527189098307};\\\", \\\"{x:569,y:736,t:1527189098324};\\\", \\\"{x:565,y:738,t:1527189098341};\\\", \\\"{x:562,y:739,t:1527189098358};\\\" ] }, { \\\"rt\\\": 25964, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 511098, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -F -G -A -E -11 AM-J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:567,y:737,t:1527189103650};\\\", \\\"{x:718,y:698,t:1527189103667};\\\", \\\"{x:846,y:674,t:1527189103683};\\\", \\\"{x:913,y:672,t:1527189103695};\\\", \\\"{x:945,y:672,t:1527189103712};\\\", \\\"{x:953,y:672,t:1527189103728};\\\", \\\"{x:956,y:672,t:1527189103745};\\\", \\\"{x:961,y:672,t:1527189103762};\\\", \\\"{x:972,y:674,t:1527189103778};\\\", \\\"{x:1001,y:680,t:1527189103795};\\\", \\\"{x:1019,y:683,t:1527189103812};\\\", \\\"{x:1026,y:685,t:1527189103828};\\\", \\\"{x:1029,y:686,t:1527189103846};\\\", \\\"{x:1036,y:689,t:1527189103862};\\\", \\\"{x:1049,y:702,t:1527189103878};\\\", \\\"{x:1080,y:728,t:1527189103896};\\\", \\\"{x:1125,y:751,t:1527189103912};\\\", \\\"{x:1159,y:765,t:1527189103928};\\\", \\\"{x:1174,y:769,t:1527189103945};\\\", \\\"{x:1185,y:772,t:1527189103963};\\\", \\\"{x:1189,y:775,t:1527189103979};\\\", \\\"{x:1196,y:783,t:1527189103995};\\\", \\\"{x:1225,y:815,t:1527189104012};\\\", \\\"{x:1259,y:844,t:1527189104030};\\\", \\\"{x:1287,y:867,t:1527189104045};\\\", \\\"{x:1317,y:874,t:1527189104063};\\\", \\\"{x:1324,y:874,t:1527189104079};\\\", \\\"{x:1327,y:872,t:1527189104095};\\\", \\\"{x:1328,y:872,t:1527189104119};\\\", \\\"{x:1329,y:872,t:1527189104130};\\\", \\\"{x:1334,y:872,t:1527189104146};\\\", \\\"{x:1345,y:875,t:1527189104163};\\\", \\\"{x:1355,y:877,t:1527189104179};\\\", \\\"{x:1360,y:877,t:1527189104195};\\\", \\\"{x:1361,y:876,t:1527189104212};\\\", \\\"{x:1361,y:874,t:1527189104269};\\\", \\\"{x:1361,y:873,t:1527189104294};\\\", \\\"{x:1361,y:872,t:1527189104310};\\\", \\\"{x:1361,y:871,t:1527189104326};\\\", \\\"{x:1362,y:869,t:1527189104342};\\\", \\\"{x:1364,y:868,t:1527189104350};\\\", \\\"{x:1366,y:867,t:1527189104366};\\\", \\\"{x:1367,y:866,t:1527189104406};\\\", \\\"{x:1367,y:865,t:1527189104414};\\\", \\\"{x:1368,y:864,t:1527189104429};\\\", \\\"{x:1373,y:863,t:1527189104446};\\\", \\\"{x:1382,y:858,t:1527189104462};\\\", \\\"{x:1385,y:857,t:1527189104480};\\\", \\\"{x:1386,y:856,t:1527189104496};\\\", \\\"{x:1388,y:856,t:1527189104512};\\\", \\\"{x:1392,y:855,t:1527189104530};\\\", \\\"{x:1410,y:853,t:1527189104547};\\\", \\\"{x:1429,y:853,t:1527189104563};\\\", \\\"{x:1446,y:852,t:1527189104579};\\\", \\\"{x:1452,y:851,t:1527189104597};\\\", \\\"{x:1455,y:850,t:1527189104613};\\\", \\\"{x:1456,y:850,t:1527189104680};\\\", \\\"{x:1457,y:850,t:1527189104697};\\\", \\\"{x:1458,y:850,t:1527189104719};\\\", \\\"{x:1459,y:848,t:1527189104729};\\\", \\\"{x:1461,y:845,t:1527189104746};\\\", \\\"{x:1462,y:841,t:1527189104763};\\\", \\\"{x:1463,y:837,t:1527189104779};\\\", \\\"{x:1467,y:831,t:1527189104797};\\\", \\\"{x:1470,y:827,t:1527189104813};\\\", \\\"{x:1474,y:822,t:1527189104829};\\\", \\\"{x:1478,y:817,t:1527189104847};\\\", \\\"{x:1480,y:814,t:1527189104862};\\\", \\\"{x:1481,y:812,t:1527189104879};\\\", \\\"{x:1481,y:811,t:1527189104896};\\\", \\\"{x:1481,y:808,t:1527189104914};\\\", \\\"{x:1482,y:804,t:1527189104930};\\\", \\\"{x:1484,y:801,t:1527189104946};\\\", \\\"{x:1485,y:798,t:1527189104964};\\\", \\\"{x:1486,y:795,t:1527189104979};\\\", \\\"{x:1491,y:788,t:1527189104997};\\\", \\\"{x:1491,y:785,t:1527189105014};\\\", \\\"{x:1492,y:785,t:1527189105029};\\\", \\\"{x:1496,y:782,t:1527189105207};\\\", \\\"{x:1500,y:780,t:1527189105215};\\\", \\\"{x:1502,y:780,t:1527189105230};\\\", \\\"{x:1502,y:779,t:1527189105246};\\\", \\\"{x:1502,y:784,t:1527189106111};\\\", \\\"{x:1502,y:791,t:1527189106118};\\\", \\\"{x:1502,y:796,t:1527189106131};\\\", \\\"{x:1502,y:807,t:1527189106148};\\\", \\\"{x:1502,y:819,t:1527189106164};\\\", \\\"{x:1502,y:834,t:1527189106181};\\\", \\\"{x:1502,y:851,t:1527189106198};\\\", \\\"{x:1500,y:879,t:1527189106214};\\\", \\\"{x:1498,y:892,t:1527189106230};\\\", \\\"{x:1496,y:900,t:1527189106248};\\\", \\\"{x:1495,y:902,t:1527189106265};\\\", \\\"{x:1495,y:903,t:1527189106295};\\\", \\\"{x:1495,y:904,t:1527189106303};\\\", \\\"{x:1493,y:905,t:1527189106327};\\\", \\\"{x:1493,y:906,t:1527189106335};\\\", \\\"{x:1491,y:908,t:1527189106348};\\\", \\\"{x:1489,y:909,t:1527189106365};\\\", \\\"{x:1485,y:911,t:1527189106381};\\\", \\\"{x:1479,y:913,t:1527189106398};\\\", \\\"{x:1464,y:915,t:1527189106415};\\\", \\\"{x:1449,y:917,t:1527189106431};\\\", \\\"{x:1438,y:918,t:1527189106448};\\\", \\\"{x:1433,y:919,t:1527189106465};\\\", \\\"{x:1432,y:919,t:1527189106480};\\\", \\\"{x:1429,y:919,t:1527189106498};\\\", \\\"{x:1428,y:919,t:1527189106519};\\\", \\\"{x:1426,y:919,t:1527189106551};\\\", \\\"{x:1425,y:919,t:1527189106599};\\\", \\\"{x:1423,y:919,t:1527189106623};\\\", \\\"{x:1422,y:919,t:1527189106631};\\\", \\\"{x:1419,y:919,t:1527189106648};\\\", \\\"{x:1413,y:916,t:1527189106664};\\\", \\\"{x:1409,y:915,t:1527189106682};\\\", \\\"{x:1404,y:912,t:1527189106697};\\\", \\\"{x:1400,y:912,t:1527189106714};\\\", \\\"{x:1399,y:912,t:1527189106732};\\\", \\\"{x:1397,y:912,t:1527189106748};\\\", \\\"{x:1396,y:912,t:1527189106765};\\\", \\\"{x:1395,y:911,t:1527189106783};\\\", \\\"{x:1394,y:911,t:1527189106798};\\\", \\\"{x:1393,y:911,t:1527189106815};\\\", \\\"{x:1391,y:911,t:1527189106832};\\\", \\\"{x:1389,y:909,t:1527189106847};\\\", \\\"{x:1387,y:908,t:1527189106871};\\\", \\\"{x:1386,y:908,t:1527189106887};\\\", \\\"{x:1384,y:908,t:1527189106898};\\\", \\\"{x:1383,y:907,t:1527189106915};\\\", \\\"{x:1380,y:906,t:1527189106931};\\\", \\\"{x:1379,y:905,t:1527189106948};\\\", \\\"{x:1377,y:905,t:1527189106965};\\\", \\\"{x:1377,y:904,t:1527189106991};\\\", \\\"{x:1376,y:904,t:1527189107247};\\\", \\\"{x:1374,y:904,t:1527189107265};\\\", \\\"{x:1373,y:905,t:1527189107287};\\\", \\\"{x:1366,y:901,t:1527189107583};\\\", \\\"{x:1359,y:891,t:1527189107599};\\\", \\\"{x:1351,y:881,t:1527189107615};\\\", \\\"{x:1346,y:876,t:1527189107632};\\\", \\\"{x:1341,y:866,t:1527189107649};\\\", \\\"{x:1336,y:853,t:1527189107666};\\\", \\\"{x:1331,y:845,t:1527189107682};\\\", \\\"{x:1330,y:839,t:1527189107699};\\\", \\\"{x:1328,y:835,t:1527189107716};\\\", \\\"{x:1327,y:829,t:1527189107732};\\\", \\\"{x:1327,y:820,t:1527189107749};\\\", \\\"{x:1327,y:805,t:1527189107766};\\\", \\\"{x:1327,y:799,t:1527189107782};\\\", \\\"{x:1327,y:798,t:1527189107798};\\\", \\\"{x:1327,y:796,t:1527189107815};\\\", \\\"{x:1327,y:795,t:1527189107846};\\\", \\\"{x:1327,y:794,t:1527189107854};\\\", \\\"{x:1327,y:793,t:1527189107870};\\\", \\\"{x:1327,y:792,t:1527189107881};\\\", \\\"{x:1327,y:791,t:1527189107898};\\\", \\\"{x:1329,y:787,t:1527189107916};\\\", \\\"{x:1329,y:786,t:1527189107932};\\\", \\\"{x:1330,y:784,t:1527189107948};\\\", \\\"{x:1331,y:784,t:1527189107966};\\\", \\\"{x:1331,y:782,t:1527189107982};\\\", \\\"{x:1333,y:780,t:1527189107998};\\\", \\\"{x:1335,y:778,t:1527189108015};\\\", \\\"{x:1337,y:776,t:1527189108063};\\\", \\\"{x:1337,y:774,t:1527189108095};\\\", \\\"{x:1338,y:773,t:1527189108111};\\\", \\\"{x:1339,y:770,t:1527189108142};\\\", \\\"{x:1340,y:769,t:1527189108166};\\\", \\\"{x:1340,y:768,t:1527189108183};\\\", \\\"{x:1340,y:771,t:1527189108391};\\\", \\\"{x:1340,y:777,t:1527189108399};\\\", \\\"{x:1340,y:785,t:1527189108416};\\\", \\\"{x:1340,y:802,t:1527189108432};\\\", \\\"{x:1340,y:830,t:1527189108450};\\\", \\\"{x:1340,y:866,t:1527189108466};\\\", \\\"{x:1340,y:892,t:1527189108482};\\\", \\\"{x:1340,y:912,t:1527189108500};\\\", \\\"{x:1340,y:927,t:1527189108516};\\\", \\\"{x:1341,y:941,t:1527189108533};\\\", \\\"{x:1341,y:951,t:1527189108550};\\\", \\\"{x:1341,y:955,t:1527189108566};\\\", \\\"{x:1341,y:956,t:1527189108727};\\\", \\\"{x:1341,y:954,t:1527189108735};\\\", \\\"{x:1341,y:948,t:1527189108750};\\\", \\\"{x:1340,y:928,t:1527189108766};\\\", \\\"{x:1340,y:896,t:1527189108783};\\\", \\\"{x:1342,y:877,t:1527189108800};\\\", \\\"{x:1346,y:863,t:1527189108817};\\\", \\\"{x:1346,y:856,t:1527189108833};\\\", \\\"{x:1346,y:848,t:1527189108850};\\\", \\\"{x:1346,y:845,t:1527189108867};\\\", \\\"{x:1346,y:843,t:1527189108883};\\\", \\\"{x:1346,y:839,t:1527189108900};\\\", \\\"{x:1346,y:836,t:1527189108917};\\\", \\\"{x:1346,y:832,t:1527189108933};\\\", \\\"{x:1346,y:827,t:1527189108950};\\\", \\\"{x:1346,y:826,t:1527189108966};\\\", \\\"{x:1346,y:824,t:1527189108983};\\\", \\\"{x:1346,y:823,t:1527189109048};\\\", \\\"{x:1346,y:819,t:1527189109535};\\\", \\\"{x:1346,y:816,t:1527189109550};\\\", \\\"{x:1346,y:810,t:1527189109567};\\\", \\\"{x:1346,y:806,t:1527189109583};\\\", \\\"{x:1346,y:805,t:1527189109600};\\\", \\\"{x:1346,y:802,t:1527189109617};\\\", \\\"{x:1346,y:798,t:1527189109633};\\\", \\\"{x:1346,y:795,t:1527189109650};\\\", \\\"{x:1346,y:790,t:1527189109666};\\\", \\\"{x:1346,y:785,t:1527189109683};\\\", \\\"{x:1346,y:782,t:1527189109700};\\\", \\\"{x:1346,y:780,t:1527189109716};\\\", \\\"{x:1346,y:777,t:1527189109734};\\\", \\\"{x:1346,y:775,t:1527189109750};\\\", \\\"{x:1346,y:774,t:1527189109766};\\\", \\\"{x:1346,y:773,t:1527189109783};\\\", \\\"{x:1346,y:776,t:1527189110600};\\\", \\\"{x:1347,y:784,t:1527189110606};\\\", \\\"{x:1347,y:791,t:1527189110618};\\\", \\\"{x:1347,y:811,t:1527189110635};\\\", \\\"{x:1349,y:828,t:1527189110651};\\\", \\\"{x:1349,y:842,t:1527189110668};\\\", \\\"{x:1349,y:851,t:1527189110685};\\\", \\\"{x:1349,y:857,t:1527189110701};\\\", \\\"{x:1350,y:866,t:1527189110718};\\\", \\\"{x:1352,y:877,t:1527189110735};\\\", \\\"{x:1352,y:883,t:1527189110751};\\\", \\\"{x:1352,y:885,t:1527189110768};\\\", \\\"{x:1351,y:888,t:1527189110784};\\\", \\\"{x:1346,y:890,t:1527189110800};\\\", \\\"{x:1342,y:891,t:1527189110817};\\\", \\\"{x:1336,y:892,t:1527189110834};\\\", \\\"{x:1321,y:892,t:1527189110850};\\\", \\\"{x:1292,y:892,t:1527189110867};\\\", \\\"{x:1225,y:891,t:1527189110884};\\\", \\\"{x:1136,y:863,t:1527189110900};\\\", \\\"{x:1070,y:839,t:1527189110917};\\\", \\\"{x:1014,y:815,t:1527189110934};\\\", \\\"{x:889,y:789,t:1527189110951};\\\", \\\"{x:820,y:774,t:1527189110967};\\\", \\\"{x:767,y:759,t:1527189110984};\\\", \\\"{x:730,y:741,t:1527189111001};\\\", \\\"{x:707,y:726,t:1527189111018};\\\", \\\"{x:693,y:714,t:1527189111035};\\\", \\\"{x:682,y:700,t:1527189111052};\\\", \\\"{x:673,y:688,t:1527189111068};\\\", \\\"{x:663,y:675,t:1527189111085};\\\", \\\"{x:658,y:669,t:1527189111102};\\\", \\\"{x:656,y:666,t:1527189111118};\\\", \\\"{x:646,y:651,t:1527189111135};\\\", \\\"{x:633,y:635,t:1527189111151};\\\", \\\"{x:610,y:618,t:1527189111169};\\\", \\\"{x:583,y:605,t:1527189111185};\\\", \\\"{x:568,y:593,t:1527189111202};\\\", \\\"{x:541,y:581,t:1527189111218};\\\", \\\"{x:522,y:575,t:1527189111234};\\\", \\\"{x:507,y:570,t:1527189111251};\\\", \\\"{x:489,y:564,t:1527189111268};\\\", \\\"{x:472,y:556,t:1527189111284};\\\", \\\"{x:456,y:550,t:1527189111302};\\\", \\\"{x:432,y:540,t:1527189111318};\\\", \\\"{x:412,y:538,t:1527189111335};\\\", \\\"{x:393,y:535,t:1527189111352};\\\", \\\"{x:387,y:534,t:1527189111368};\\\", \\\"{x:385,y:534,t:1527189111386};\\\", \\\"{x:381,y:534,t:1527189111401};\\\", \\\"{x:369,y:538,t:1527189111419};\\\", \\\"{x:347,y:543,t:1527189111435};\\\", \\\"{x:319,y:550,t:1527189111451};\\\", \\\"{x:292,y:552,t:1527189111468};\\\", \\\"{x:269,y:556,t:1527189111486};\\\", \\\"{x:246,y:558,t:1527189111501};\\\", \\\"{x:211,y:562,t:1527189111518};\\\", \\\"{x:198,y:563,t:1527189111536};\\\", \\\"{x:179,y:563,t:1527189111551};\\\", \\\"{x:168,y:563,t:1527189111568};\\\", \\\"{x:161,y:562,t:1527189111586};\\\", \\\"{x:160,y:562,t:1527189111601};\\\", \\\"{x:159,y:561,t:1527189111799};\\\", \\\"{x:158,y:558,t:1527189111806};\\\", \\\"{x:157,y:553,t:1527189111820};\\\", \\\"{x:157,y:549,t:1527189111835};\\\", \\\"{x:156,y:546,t:1527189111853};\\\", \\\"{x:156,y:545,t:1527189111868};\\\", \\\"{x:155,y:544,t:1527189111886};\\\", \\\"{x:157,y:543,t:1527189112262};\\\", \\\"{x:167,y:543,t:1527189112270};\\\", \\\"{x:185,y:549,t:1527189112286};\\\", \\\"{x:272,y:574,t:1527189112304};\\\", \\\"{x:370,y:598,t:1527189112321};\\\", \\\"{x:484,y:629,t:1527189112336};\\\", \\\"{x:626,y:657,t:1527189112354};\\\", \\\"{x:763,y:685,t:1527189112371};\\\", \\\"{x:901,y:706,t:1527189112386};\\\", \\\"{x:1026,y:720,t:1527189112403};\\\", \\\"{x:1117,y:734,t:1527189112420};\\\", \\\"{x:1165,y:740,t:1527189112436};\\\", \\\"{x:1185,y:742,t:1527189112453};\\\", \\\"{x:1202,y:742,t:1527189112470};\\\", \\\"{x:1216,y:742,t:1527189112485};\\\", \\\"{x:1228,y:742,t:1527189112503};\\\", \\\"{x:1235,y:739,t:1527189112520};\\\", \\\"{x:1238,y:737,t:1527189112536};\\\", \\\"{x:1240,y:736,t:1527189112553};\\\", \\\"{x:1243,y:733,t:1527189112571};\\\", \\\"{x:1251,y:727,t:1527189112586};\\\", \\\"{x:1255,y:724,t:1527189112603};\\\", \\\"{x:1259,y:721,t:1527189112620};\\\", \\\"{x:1263,y:718,t:1527189112636};\\\", \\\"{x:1265,y:716,t:1527189112653};\\\", \\\"{x:1268,y:714,t:1527189112670};\\\", \\\"{x:1275,y:710,t:1527189112686};\\\", \\\"{x:1287,y:707,t:1527189112703};\\\", \\\"{x:1309,y:703,t:1527189112720};\\\", \\\"{x:1322,y:700,t:1527189112737};\\\", \\\"{x:1336,y:698,t:1527189112753};\\\", \\\"{x:1344,y:697,t:1527189112773};\\\", \\\"{x:1349,y:696,t:1527189112786};\\\", \\\"{x:1353,y:695,t:1527189114303};\\\", \\\"{x:1362,y:689,t:1527189114322};\\\", \\\"{x:1371,y:682,t:1527189114338};\\\", \\\"{x:1379,y:674,t:1527189114354};\\\", \\\"{x:1385,y:668,t:1527189114372};\\\", \\\"{x:1386,y:665,t:1527189114388};\\\", \\\"{x:1388,y:661,t:1527189114403};\\\", \\\"{x:1390,y:652,t:1527189114421};\\\", \\\"{x:1399,y:631,t:1527189114437};\\\", \\\"{x:1405,y:615,t:1527189114453};\\\", \\\"{x:1407,y:607,t:1527189114471};\\\", \\\"{x:1413,y:598,t:1527189114487};\\\", \\\"{x:1416,y:593,t:1527189114503};\\\", \\\"{x:1419,y:584,t:1527189114521};\\\", \\\"{x:1423,y:573,t:1527189114537};\\\", \\\"{x:1425,y:564,t:1527189114554};\\\", \\\"{x:1426,y:559,t:1527189114571};\\\", \\\"{x:1428,y:554,t:1527189114588};\\\", \\\"{x:1431,y:549,t:1527189114605};\\\", \\\"{x:1431,y:546,t:1527189114621};\\\", \\\"{x:1431,y:545,t:1527189114638};\\\", \\\"{x:1431,y:547,t:1527189115039};\\\", \\\"{x:1429,y:548,t:1527189115055};\\\", \\\"{x:1429,y:549,t:1527189115072};\\\", \\\"{x:1428,y:551,t:1527189115088};\\\", \\\"{x:1427,y:552,t:1527189115105};\\\", \\\"{x:1426,y:555,t:1527189115122};\\\", \\\"{x:1425,y:556,t:1527189115138};\\\", \\\"{x:1424,y:557,t:1527189115155};\\\", \\\"{x:1424,y:558,t:1527189115172};\\\", \\\"{x:1423,y:558,t:1527189115188};\\\", \\\"{x:1423,y:560,t:1527189115205};\\\", \\\"{x:1420,y:564,t:1527189115223};\\\", \\\"{x:1420,y:568,t:1527189115239};\\\", \\\"{x:1417,y:576,t:1527189115254};\\\", \\\"{x:1417,y:583,t:1527189115272};\\\", \\\"{x:1417,y:600,t:1527189115288};\\\", \\\"{x:1416,y:622,t:1527189115305};\\\", \\\"{x:1416,y:645,t:1527189115322};\\\", \\\"{x:1415,y:665,t:1527189115338};\\\", \\\"{x:1415,y:677,t:1527189115355};\\\", \\\"{x:1415,y:696,t:1527189115372};\\\", \\\"{x:1415,y:719,t:1527189115389};\\\", \\\"{x:1415,y:746,t:1527189115405};\\\", \\\"{x:1415,y:772,t:1527189115422};\\\", \\\"{x:1415,y:807,t:1527189115438};\\\", \\\"{x:1415,y:820,t:1527189115454};\\\", \\\"{x:1415,y:830,t:1527189115472};\\\", \\\"{x:1416,y:836,t:1527189115490};\\\", \\\"{x:1418,y:849,t:1527189115506};\\\", \\\"{x:1421,y:872,t:1527189115522};\\\", \\\"{x:1423,y:896,t:1527189115538};\\\", \\\"{x:1428,y:913,t:1527189115556};\\\", \\\"{x:1428,y:917,t:1527189115572};\\\", \\\"{x:1428,y:918,t:1527189115589};\\\", \\\"{x:1428,y:919,t:1527189115639};\\\", \\\"{x:1428,y:933,t:1527189115655};\\\", \\\"{x:1429,y:949,t:1527189115672};\\\", \\\"{x:1429,y:956,t:1527189115690};\\\", \\\"{x:1431,y:958,t:1527189115705};\\\", \\\"{x:1431,y:960,t:1527189115813};\\\", \\\"{x:1431,y:961,t:1527189115822};\\\", \\\"{x:1431,y:955,t:1527189115918};\\\", \\\"{x:1430,y:942,t:1527189115926};\\\", \\\"{x:1426,y:928,t:1527189115939};\\\", \\\"{x:1423,y:896,t:1527189115956};\\\", \\\"{x:1411,y:849,t:1527189115972};\\\", \\\"{x:1395,y:804,t:1527189115988};\\\", \\\"{x:1387,y:775,t:1527189116006};\\\", \\\"{x:1375,y:718,t:1527189116022};\\\", \\\"{x:1370,y:672,t:1527189116039};\\\", \\\"{x:1369,y:621,t:1527189116055};\\\", \\\"{x:1368,y:595,t:1527189116072};\\\", \\\"{x:1368,y:577,t:1527189116089};\\\", \\\"{x:1368,y:566,t:1527189116106};\\\", \\\"{x:1368,y:561,t:1527189116122};\\\", \\\"{x:1368,y:559,t:1527189116139};\\\", \\\"{x:1368,y:558,t:1527189116156};\\\", \\\"{x:1368,y:556,t:1527189116172};\\\", \\\"{x:1368,y:554,t:1527189116191};\\\", \\\"{x:1369,y:554,t:1527189116239};\\\", \\\"{x:1370,y:553,t:1527189116256};\\\", \\\"{x:1374,y:552,t:1527189116272};\\\", \\\"{x:1379,y:550,t:1527189116290};\\\", \\\"{x:1384,y:549,t:1527189116306};\\\", \\\"{x:1391,y:547,t:1527189116323};\\\", \\\"{x:1398,y:545,t:1527189116339};\\\", \\\"{x:1402,y:541,t:1527189116356};\\\", \\\"{x:1411,y:537,t:1527189116372};\\\", \\\"{x:1418,y:531,t:1527189116389};\\\", \\\"{x:1422,y:523,t:1527189116406};\\\", \\\"{x:1430,y:507,t:1527189116423};\\\", \\\"{x:1432,y:500,t:1527189116440};\\\", \\\"{x:1434,y:496,t:1527189116456};\\\", \\\"{x:1434,y:492,t:1527189116473};\\\", \\\"{x:1434,y:491,t:1527189116489};\\\", \\\"{x:1434,y:488,t:1527189116506};\\\", \\\"{x:1434,y:481,t:1527189116523};\\\", \\\"{x:1433,y:473,t:1527189116539};\\\", \\\"{x:1431,y:465,t:1527189116557};\\\", \\\"{x:1429,y:459,t:1527189116573};\\\", \\\"{x:1428,y:459,t:1527189116590};\\\", \\\"{x:1428,y:458,t:1527189116606};\\\", \\\"{x:1427,y:457,t:1527189116639};\\\", \\\"{x:1426,y:452,t:1527189116656};\\\", \\\"{x:1423,y:446,t:1527189116673};\\\", \\\"{x:1422,y:439,t:1527189116690};\\\", \\\"{x:1421,y:435,t:1527189116706};\\\", \\\"{x:1419,y:434,t:1527189116723};\\\", \\\"{x:1419,y:433,t:1527189116808};\\\", \\\"{x:1419,y:434,t:1527189116983};\\\", \\\"{x:1415,y:442,t:1527189116990};\\\", \\\"{x:1407,y:469,t:1527189117007};\\\", \\\"{x:1395,y:493,t:1527189117023};\\\", \\\"{x:1384,y:509,t:1527189117040};\\\", \\\"{x:1375,y:521,t:1527189117056};\\\", \\\"{x:1369,y:530,t:1527189117074};\\\", \\\"{x:1368,y:532,t:1527189117091};\\\", \\\"{x:1367,y:532,t:1527189117127};\\\", \\\"{x:1366,y:533,t:1527189117140};\\\", \\\"{x:1361,y:535,t:1527189117156};\\\", \\\"{x:1356,y:538,t:1527189117173};\\\", \\\"{x:1352,y:539,t:1527189117190};\\\", \\\"{x:1345,y:541,t:1527189117206};\\\", \\\"{x:1338,y:542,t:1527189117223};\\\", \\\"{x:1330,y:545,t:1527189117240};\\\", \\\"{x:1323,y:551,t:1527189117256};\\\", \\\"{x:1312,y:555,t:1527189117274};\\\", \\\"{x:1303,y:560,t:1527189117291};\\\", \\\"{x:1300,y:561,t:1527189117306};\\\", \\\"{x:1298,y:563,t:1527189117501};\\\", \\\"{x:1298,y:564,t:1527189117509};\\\", \\\"{x:1296,y:564,t:1527189117522};\\\", \\\"{x:1295,y:565,t:1527189117540};\\\", \\\"{x:1293,y:566,t:1527189117557};\\\", \\\"{x:1289,y:567,t:1527189117573};\\\", \\\"{x:1289,y:568,t:1527189117759};\\\", \\\"{x:1288,y:568,t:1527189117774};\\\", \\\"{x:1287,y:568,t:1527189117790};\\\", \\\"{x:1286,y:568,t:1527189117806};\\\", \\\"{x:1285,y:568,t:1527189117823};\\\", \\\"{x:1284,y:568,t:1527189117840};\\\", \\\"{x:1283,y:568,t:1527189117857};\\\", \\\"{x:1282,y:567,t:1527189118047};\\\", \\\"{x:1281,y:567,t:1527189118057};\\\", \\\"{x:1280,y:569,t:1527189118168};\\\", \\\"{x:1279,y:578,t:1527189118175};\\\", \\\"{x:1277,y:598,t:1527189118191};\\\", \\\"{x:1275,y:618,t:1527189118207};\\\", \\\"{x:1269,y:638,t:1527189118224};\\\", \\\"{x:1269,y:659,t:1527189118240};\\\", \\\"{x:1269,y:686,t:1527189118257};\\\", \\\"{x:1269,y:715,t:1527189118274};\\\", \\\"{x:1269,y:741,t:1527189118290};\\\", \\\"{x:1269,y:771,t:1527189118308};\\\", \\\"{x:1269,y:796,t:1527189118325};\\\", \\\"{x:1269,y:815,t:1527189118340};\\\", \\\"{x:1269,y:831,t:1527189118357};\\\", \\\"{x:1270,y:849,t:1527189118374};\\\", \\\"{x:1271,y:859,t:1527189118391};\\\", \\\"{x:1273,y:872,t:1527189118407};\\\", \\\"{x:1276,y:885,t:1527189118424};\\\", \\\"{x:1280,y:894,t:1527189118442};\\\", \\\"{x:1281,y:895,t:1527189118458};\\\", \\\"{x:1281,y:896,t:1527189118495};\\\", \\\"{x:1281,y:899,t:1527189118507};\\\", \\\"{x:1281,y:912,t:1527189118524};\\\", \\\"{x:1281,y:942,t:1527189118541};\\\", \\\"{x:1281,y:965,t:1527189118557};\\\", \\\"{x:1281,y:971,t:1527189118575};\\\", \\\"{x:1281,y:967,t:1527189118736};\\\", \\\"{x:1280,y:958,t:1527189118743};\\\", \\\"{x:1279,y:945,t:1527189118757};\\\", \\\"{x:1272,y:904,t:1527189118774};\\\", \\\"{x:1267,y:875,t:1527189118791};\\\", \\\"{x:1260,y:847,t:1527189118808};\\\", \\\"{x:1257,y:821,t:1527189118824};\\\", \\\"{x:1256,y:787,t:1527189118841};\\\", \\\"{x:1260,y:713,t:1527189118859};\\\", \\\"{x:1269,y:644,t:1527189118874};\\\", \\\"{x:1272,y:604,t:1527189118891};\\\", \\\"{x:1272,y:585,t:1527189118908};\\\", \\\"{x:1272,y:569,t:1527189118924};\\\", \\\"{x:1272,y:558,t:1527189118942};\\\", \\\"{x:1272,y:553,t:1527189118958};\\\", \\\"{x:1272,y:552,t:1527189118975};\\\", \\\"{x:1272,y:554,t:1527189119167};\\\", \\\"{x:1270,y:561,t:1527189119174};\\\", \\\"{x:1268,y:575,t:1527189119191};\\\", \\\"{x:1263,y:593,t:1527189119208};\\\", \\\"{x:1252,y:632,t:1527189119223};\\\", \\\"{x:1242,y:676,t:1527189119241};\\\", \\\"{x:1236,y:705,t:1527189119258};\\\", \\\"{x:1232,y:728,t:1527189119275};\\\", \\\"{x:1231,y:744,t:1527189119291};\\\", \\\"{x:1230,y:758,t:1527189119307};\\\", \\\"{x:1230,y:768,t:1527189119325};\\\", \\\"{x:1230,y:775,t:1527189119341};\\\", \\\"{x:1230,y:780,t:1527189119358};\\\", \\\"{x:1230,y:783,t:1527189119375};\\\", \\\"{x:1230,y:785,t:1527189119391};\\\", \\\"{x:1230,y:786,t:1527189119408};\\\", \\\"{x:1230,y:788,t:1527189119455};\\\", \\\"{x:1229,y:789,t:1527189119463};\\\", \\\"{x:1228,y:793,t:1527189119475};\\\", \\\"{x:1222,y:813,t:1527189119491};\\\", \\\"{x:1215,y:832,t:1527189119508};\\\", \\\"{x:1209,y:849,t:1527189119526};\\\", \\\"{x:1207,y:854,t:1527189119542};\\\", \\\"{x:1206,y:855,t:1527189119558};\\\", \\\"{x:1205,y:851,t:1527189119686};\\\", \\\"{x:1204,y:846,t:1527189119694};\\\", \\\"{x:1204,y:843,t:1527189119708};\\\", \\\"{x:1204,y:837,t:1527189119725};\\\", \\\"{x:1204,y:832,t:1527189119741};\\\", \\\"{x:1204,y:828,t:1527189119757};\\\", \\\"{x:1204,y:837,t:1527189119879};\\\", \\\"{x:1207,y:853,t:1527189119892};\\\", \\\"{x:1209,y:883,t:1527189119908};\\\", \\\"{x:1213,y:901,t:1527189119925};\\\", \\\"{x:1214,y:914,t:1527189119942};\\\", \\\"{x:1214,y:921,t:1527189119958};\\\", \\\"{x:1214,y:929,t:1527189119975};\\\", \\\"{x:1214,y:941,t:1527189119992};\\\", \\\"{x:1213,y:953,t:1527189120008};\\\", \\\"{x:1212,y:956,t:1527189120025};\\\", \\\"{x:1211,y:957,t:1527189120042};\\\", \\\"{x:1211,y:951,t:1527189120184};\\\", \\\"{x:1212,y:939,t:1527189120192};\\\", \\\"{x:1214,y:918,t:1527189120208};\\\", \\\"{x:1214,y:895,t:1527189120225};\\\", \\\"{x:1214,y:872,t:1527189120243};\\\", \\\"{x:1214,y:851,t:1527189120258};\\\", \\\"{x:1213,y:829,t:1527189120275};\\\", \\\"{x:1208,y:815,t:1527189120293};\\\", \\\"{x:1208,y:809,t:1527189120309};\\\", \\\"{x:1207,y:809,t:1527189120399};\\\", \\\"{x:1205,y:818,t:1527189120409};\\\", \\\"{x:1203,y:860,t:1527189120425};\\\", \\\"{x:1201,y:896,t:1527189120442};\\\", \\\"{x:1201,y:916,t:1527189120459};\\\", \\\"{x:1201,y:927,t:1527189120475};\\\", \\\"{x:1201,y:933,t:1527189120492};\\\", \\\"{x:1201,y:940,t:1527189120509};\\\", \\\"{x:1201,y:946,t:1527189120525};\\\", \\\"{x:1201,y:949,t:1527189120542};\\\", \\\"{x:1201,y:950,t:1527189120559};\\\", \\\"{x:1201,y:944,t:1527189120671};\\\", \\\"{x:1201,y:931,t:1527189120679};\\\", \\\"{x:1201,y:919,t:1527189120692};\\\", \\\"{x:1199,y:897,t:1527189120710};\\\", \\\"{x:1196,y:877,t:1527189120726};\\\", \\\"{x:1193,y:869,t:1527189120743};\\\", \\\"{x:1193,y:867,t:1527189120759};\\\", \\\"{x:1193,y:866,t:1527189120776};\\\", \\\"{x:1192,y:866,t:1527189120831};\\\", \\\"{x:1189,y:866,t:1527189120854};\\\", \\\"{x:1185,y:866,t:1527189120863};\\\", \\\"{x:1181,y:865,t:1527189120877};\\\", \\\"{x:1168,y:863,t:1527189120892};\\\", \\\"{x:1150,y:859,t:1527189120909};\\\", \\\"{x:1117,y:850,t:1527189120927};\\\", \\\"{x:1093,y:842,t:1527189120942};\\\", \\\"{x:1071,y:837,t:1527189120959};\\\", \\\"{x:1047,y:831,t:1527189120977};\\\", \\\"{x:1022,y:825,t:1527189120992};\\\", \\\"{x:992,y:820,t:1527189121010};\\\", \\\"{x:944,y:818,t:1527189121027};\\\", \\\"{x:856,y:809,t:1527189121042};\\\", \\\"{x:789,y:809,t:1527189121059};\\\", \\\"{x:754,y:809,t:1527189121076};\\\", \\\"{x:721,y:809,t:1527189121092};\\\", \\\"{x:692,y:809,t:1527189121109};\\\", \\\"{x:647,y:813,t:1527189121126};\\\", \\\"{x:621,y:817,t:1527189121143};\\\", \\\"{x:600,y:820,t:1527189121160};\\\", \\\"{x:586,y:822,t:1527189121176};\\\", \\\"{x:581,y:822,t:1527189121193};\\\", \\\"{x:573,y:820,t:1527189121209};\\\", \\\"{x:569,y:818,t:1527189121226};\\\", \\\"{x:568,y:817,t:1527189121243};\\\", \\\"{x:567,y:817,t:1527189121259};\\\", \\\"{x:566,y:817,t:1527189121277};\\\", \\\"{x:563,y:814,t:1527189121293};\\\", \\\"{x:556,y:806,t:1527189121309};\\\", \\\"{x:551,y:794,t:1527189121327};\\\", \\\"{x:548,y:789,t:1527189121342};\\\", \\\"{x:545,y:785,t:1527189121359};\\\", \\\"{x:544,y:784,t:1527189121439};\\\", \\\"{x:544,y:781,t:1527189121447};\\\", \\\"{x:544,y:779,t:1527189121462};\\\", \\\"{x:544,y:778,t:1527189121476};\\\", \\\"{x:543,y:777,t:1527189121493};\\\", \\\"{x:543,y:776,t:1527189121567};\\\", \\\"{x:543,y:774,t:1527189121577};\\\", \\\"{x:542,y:771,t:1527189121593};\\\", \\\"{x:542,y:768,t:1527189121608};\\\", \\\"{x:542,y:766,t:1527189121626};\\\", \\\"{x:541,y:765,t:1527189121642};\\\", \\\"{x:541,y:764,t:1527189121660};\\\", \\\"{x:541,y:761,t:1527189121676};\\\", \\\"{x:541,y:758,t:1527189121693};\\\", \\\"{x:541,y:756,t:1527189121709};\\\", \\\"{x:541,y:754,t:1527189121726};\\\", \\\"{x:541,y:753,t:1527189121743};\\\", \\\"{x:541,y:751,t:1527189121861};\\\", \\\"{x:541,y:750,t:1527189121875};\\\", \\\"{x:541,y:749,t:1527189121926};\\\", \\\"{x:541,y:746,t:1527189121943};\\\", \\\"{x:541,y:743,t:1527189121960};\\\", \\\"{x:541,y:742,t:1527189121977};\\\", \\\"{x:541,y:741,t:1527189121993};\\\", \\\"{x:541,y:740,t:1527189122010};\\\", \\\"{x:541,y:738,t:1527189122027};\\\", \\\"{x:541,y:737,t:1527189122044};\\\", \\\"{x:541,y:736,t:1527189122159};\\\", \\\"{x:539,y:735,t:1527189123134};\\\", \\\"{x:538,y:735,t:1527189123158};\\\", \\\"{x:537,y:733,t:1527189123166};\\\", \\\"{x:536,y:733,t:1527189123182};\\\", \\\"{x:535,y:733,t:1527189123198};\\\", \\\"{x:533,y:733,t:1527189124951};\\\", \\\"{x:532,y:732,t:1527189124959};\\\", \\\"{x:531,y:731,t:1527189124982};\\\", \\\"{x:530,y:731,t:1527189124990};\\\", \\\"{x:529,y:730,t:1527189125006};\\\", \\\"{x:528,y:729,t:1527189125046};\\\", \\\"{x:530,y:729,t:1527189126302};\\\", \\\"{x:534,y:729,t:1527189126314};\\\", \\\"{x:542,y:731,t:1527189126331};\\\", \\\"{x:558,y:733,t:1527189126347};\\\", \\\"{x:581,y:737,t:1527189126364};\\\", \\\"{x:603,y:742,t:1527189126380};\\\", \\\"{x:625,y:746,t:1527189126397};\\\", \\\"{x:660,y:753,t:1527189126414};\\\", \\\"{x:686,y:755,t:1527189126430};\\\", \\\"{x:709,y:760,t:1527189126447};\\\", \\\"{x:733,y:763,t:1527189126463};\\\", \\\"{x:754,y:765,t:1527189126480};\\\", \\\"{x:781,y:770,t:1527189126498};\\\", \\\"{x:798,y:774,t:1527189126513};\\\", \\\"{x:821,y:783,t:1527189126530};\\\", \\\"{x:842,y:786,t:1527189126548};\\\", \\\"{x:844,y:791,t:1527189126563};\\\" ] }, { \\\"rt\\\": 53035, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 565395, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -02 PM-02 PM-X -M -X -C -G -01 PM-01 PM-G -G -F -F -B -B -12 PM-B -11 AM-11 AM-7-11 AM-02 PM-X -G -M -M -B -B -F -B -12 PM-E -11 AM-E -E -E -E -11 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:853,y:790,t:1527189129095};\\\", \\\"{x:876,y:788,t:1527189129102};\\\", \\\"{x:902,y:784,t:1527189129116};\\\", \\\"{x:994,y:784,t:1527189129133};\\\", \\\"{x:1152,y:798,t:1527189129149};\\\", \\\"{x:1225,y:811,t:1527189129166};\\\", \\\"{x:1246,y:816,t:1527189129183};\\\", \\\"{x:1253,y:819,t:1527189129200};\\\", \\\"{x:1255,y:820,t:1527189129646};\\\", \\\"{x:1260,y:820,t:1527189129654};\\\", \\\"{x:1264,y:821,t:1527189129668};\\\", \\\"{x:1273,y:822,t:1527189129684};\\\", \\\"{x:1281,y:825,t:1527189129700};\\\", \\\"{x:1288,y:826,t:1527189129718};\\\", \\\"{x:1300,y:832,t:1527189129734};\\\", \\\"{x:1331,y:844,t:1527189129750};\\\", \\\"{x:1351,y:849,t:1527189129768};\\\", \\\"{x:1363,y:853,t:1527189129783};\\\", \\\"{x:1365,y:853,t:1527189129800};\\\", \\\"{x:1368,y:855,t:1527189129818};\\\", \\\"{x:1377,y:860,t:1527189129833};\\\", \\\"{x:1395,y:866,t:1527189129850};\\\", \\\"{x:1407,y:871,t:1527189129867};\\\", \\\"{x:1410,y:873,t:1527189129885};\\\", \\\"{x:1411,y:873,t:1527189129926};\\\", \\\"{x:1415,y:876,t:1527189129935};\\\", \\\"{x:1427,y:886,t:1527189129951};\\\", \\\"{x:1437,y:895,t:1527189129968};\\\", \\\"{x:1441,y:899,t:1527189129985};\\\", \\\"{x:1443,y:901,t:1527189130000};\\\", \\\"{x:1444,y:902,t:1527189130022};\\\", \\\"{x:1445,y:902,t:1527189130111};\\\", \\\"{x:1445,y:903,t:1527189130142};\\\", \\\"{x:1448,y:905,t:1527189130150};\\\", \\\"{x:1452,y:911,t:1527189130168};\\\", \\\"{x:1455,y:918,t:1527189130185};\\\", \\\"{x:1459,y:926,t:1527189130201};\\\", \\\"{x:1464,y:936,t:1527189130218};\\\", \\\"{x:1465,y:942,t:1527189130235};\\\", \\\"{x:1467,y:944,t:1527189130250};\\\", \\\"{x:1468,y:945,t:1527189130286};\\\", \\\"{x:1469,y:945,t:1527189130447};\\\", \\\"{x:1471,y:947,t:1527189131854};\\\", \\\"{x:1471,y:948,t:1527189131869};\\\", \\\"{x:1471,y:950,t:1527189131886};\\\", \\\"{x:1474,y:954,t:1527189131902};\\\", \\\"{x:1476,y:959,t:1527189131919};\\\", \\\"{x:1477,y:960,t:1527189131936};\\\", \\\"{x:1478,y:960,t:1527189131953};\\\", \\\"{x:1478,y:961,t:1527189131969};\\\", \\\"{x:1479,y:964,t:1527189131986};\\\", \\\"{x:1482,y:969,t:1527189132003};\\\", \\\"{x:1482,y:971,t:1527189132019};\\\", \\\"{x:1483,y:971,t:1527189132151};\\\", \\\"{x:1483,y:968,t:1527189132159};\\\", \\\"{x:1483,y:965,t:1527189132169};\\\", \\\"{x:1483,y:959,t:1527189132186};\\\", \\\"{x:1483,y:954,t:1527189132203};\\\", \\\"{x:1482,y:947,t:1527189132220};\\\", \\\"{x:1481,y:939,t:1527189132236};\\\", \\\"{x:1480,y:930,t:1527189132253};\\\", \\\"{x:1477,y:920,t:1527189132270};\\\", \\\"{x:1475,y:912,t:1527189132286};\\\", \\\"{x:1472,y:902,t:1527189132303};\\\", \\\"{x:1470,y:895,t:1527189132319};\\\", \\\"{x:1470,y:891,t:1527189132336};\\\", \\\"{x:1469,y:885,t:1527189132352};\\\", \\\"{x:1469,y:880,t:1527189132370};\\\", \\\"{x:1468,y:873,t:1527189132386};\\\", \\\"{x:1467,y:865,t:1527189132402};\\\", \\\"{x:1467,y:861,t:1527189132419};\\\", \\\"{x:1467,y:857,t:1527189132436};\\\", \\\"{x:1467,y:855,t:1527189132453};\\\", \\\"{x:1467,y:854,t:1527189132479};\\\", \\\"{x:1467,y:853,t:1527189132486};\\\", \\\"{x:1468,y:850,t:1527189132502};\\\", \\\"{x:1469,y:846,t:1527189132520};\\\", \\\"{x:1470,y:843,t:1527189132537};\\\", \\\"{x:1471,y:842,t:1527189132553};\\\", \\\"{x:1471,y:841,t:1527189132591};\\\", \\\"{x:1472,y:840,t:1527189132614};\\\", \\\"{x:1473,y:839,t:1527189132622};\\\", \\\"{x:1473,y:838,t:1527189132636};\\\", \\\"{x:1473,y:837,t:1527189132653};\\\", \\\"{x:1474,y:836,t:1527189132670};\\\", \\\"{x:1475,y:835,t:1527189132895};\\\", \\\"{x:1475,y:834,t:1527189132904};\\\", \\\"{x:1477,y:832,t:1527189132922};\\\", \\\"{x:1478,y:830,t:1527189132936};\\\", \\\"{x:1478,y:829,t:1527189132957};\\\", \\\"{x:1478,y:828,t:1527189133054};\\\", \\\"{x:1479,y:827,t:1527189133375};\\\", \\\"{x:1479,y:831,t:1527189133502};\\\", \\\"{x:1479,y:854,t:1527189133522};\\\", \\\"{x:1481,y:870,t:1527189133536};\\\", \\\"{x:1483,y:878,t:1527189133554};\\\", \\\"{x:1483,y:882,t:1527189133571};\\\", \\\"{x:1483,y:891,t:1527189133587};\\\", \\\"{x:1484,y:910,t:1527189133604};\\\", \\\"{x:1487,y:931,t:1527189133621};\\\", \\\"{x:1487,y:949,t:1527189133637};\\\", \\\"{x:1487,y:954,t:1527189133654};\\\", \\\"{x:1487,y:962,t:1527189133670};\\\", \\\"{x:1487,y:969,t:1527189133687};\\\", \\\"{x:1487,y:976,t:1527189133704};\\\", \\\"{x:1486,y:985,t:1527189133721};\\\", \\\"{x:1486,y:986,t:1527189133737};\\\", \\\"{x:1485,y:986,t:1527189133754};\\\", \\\"{x:1485,y:984,t:1527189134199};\\\", \\\"{x:1485,y:982,t:1527189134206};\\\", \\\"{x:1485,y:980,t:1527189134220};\\\", \\\"{x:1484,y:975,t:1527189134238};\\\", \\\"{x:1483,y:973,t:1527189134254};\\\", \\\"{x:1482,y:972,t:1527189134271};\\\", \\\"{x:1482,y:971,t:1527189134288};\\\", \\\"{x:1482,y:969,t:1527189134305};\\\", \\\"{x:1479,y:965,t:1527189134321};\\\", \\\"{x:1479,y:963,t:1527189134338};\\\", \\\"{x:1478,y:960,t:1527189134355};\\\", \\\"{x:1476,y:958,t:1527189134371};\\\", \\\"{x:1476,y:956,t:1527189134398};\\\", \\\"{x:1476,y:955,t:1527189134423};\\\", \\\"{x:1476,y:953,t:1527189134438};\\\", \\\"{x:1476,y:952,t:1527189134454};\\\", \\\"{x:1476,y:951,t:1527189134471};\\\", \\\"{x:1476,y:949,t:1527189134488};\\\", \\\"{x:1476,y:948,t:1527189134504};\\\", \\\"{x:1477,y:945,t:1527189134521};\\\", \\\"{x:1477,y:943,t:1527189134537};\\\", \\\"{x:1478,y:941,t:1527189134555};\\\", \\\"{x:1478,y:938,t:1527189134571};\\\", \\\"{x:1481,y:927,t:1527189134588};\\\", \\\"{x:1485,y:913,t:1527189134605};\\\", \\\"{x:1486,y:905,t:1527189134622};\\\", \\\"{x:1489,y:888,t:1527189134638};\\\", \\\"{x:1491,y:877,t:1527189134654};\\\", \\\"{x:1492,y:865,t:1527189134672};\\\", \\\"{x:1494,y:850,t:1527189134688};\\\", \\\"{x:1496,y:841,t:1527189134705};\\\", \\\"{x:1497,y:832,t:1527189134722};\\\", \\\"{x:1497,y:827,t:1527189134738};\\\", \\\"{x:1497,y:823,t:1527189134755};\\\", \\\"{x:1497,y:821,t:1527189134791};\\\", \\\"{x:1493,y:821,t:1527189134983};\\\", \\\"{x:1485,y:827,t:1527189134990};\\\", \\\"{x:1479,y:832,t:1527189135004};\\\", \\\"{x:1447,y:854,t:1527189135023};\\\", \\\"{x:1432,y:867,t:1527189135038};\\\", \\\"{x:1420,y:877,t:1527189135055};\\\", \\\"{x:1415,y:881,t:1527189135072};\\\", \\\"{x:1413,y:883,t:1527189135089};\\\", \\\"{x:1411,y:886,t:1527189135104};\\\", \\\"{x:1407,y:892,t:1527189135122};\\\", \\\"{x:1398,y:901,t:1527189135139};\\\", \\\"{x:1389,y:906,t:1527189135155};\\\", \\\"{x:1387,y:907,t:1527189135172};\\\", \\\"{x:1386,y:908,t:1527189135206};\\\", \\\"{x:1385,y:908,t:1527189135303};\\\", \\\"{x:1384,y:908,t:1527189135319};\\\", \\\"{x:1383,y:907,t:1527189135334};\\\", \\\"{x:1383,y:906,t:1527189135342};\\\", \\\"{x:1383,y:904,t:1527189135359};\\\", \\\"{x:1382,y:903,t:1527189135372};\\\", \\\"{x:1380,y:900,t:1527189135389};\\\", \\\"{x:1379,y:896,t:1527189135405};\\\", \\\"{x:1378,y:895,t:1527189135446};\\\", \\\"{x:1377,y:896,t:1527189135678};\\\", \\\"{x:1377,y:901,t:1527189135690};\\\", \\\"{x:1377,y:913,t:1527189135705};\\\", \\\"{x:1377,y:921,t:1527189135721};\\\", \\\"{x:1377,y:929,t:1527189135739};\\\", \\\"{x:1377,y:936,t:1527189135756};\\\", \\\"{x:1377,y:939,t:1527189135772};\\\", \\\"{x:1377,y:946,t:1527189135789};\\\", \\\"{x:1375,y:956,t:1527189135805};\\\", \\\"{x:1375,y:961,t:1527189135821};\\\", \\\"{x:1375,y:962,t:1527189135869};\\\", \\\"{x:1375,y:958,t:1527189136023};\\\", \\\"{x:1375,y:942,t:1527189136038};\\\", \\\"{x:1373,y:932,t:1527189136056};\\\", \\\"{x:1373,y:921,t:1527189136073};\\\", \\\"{x:1373,y:915,t:1527189136089};\\\", \\\"{x:1373,y:909,t:1527189136106};\\\", \\\"{x:1372,y:908,t:1527189136123};\\\", \\\"{x:1372,y:906,t:1527189136138};\\\", \\\"{x:1372,y:901,t:1527189136155};\\\", \\\"{x:1372,y:897,t:1527189136173};\\\", \\\"{x:1373,y:890,t:1527189136189};\\\", \\\"{x:1374,y:883,t:1527189136206};\\\", \\\"{x:1374,y:882,t:1527189136334};\\\", \\\"{x:1374,y:874,t:1527189136687};\\\", \\\"{x:1374,y:866,t:1527189136694};\\\", \\\"{x:1374,y:856,t:1527189136706};\\\", \\\"{x:1373,y:842,t:1527189136723};\\\", \\\"{x:1370,y:826,t:1527189136740};\\\", \\\"{x:1365,y:812,t:1527189136756};\\\", \\\"{x:1363,y:805,t:1527189136773};\\\", \\\"{x:1361,y:799,t:1527189136790};\\\", \\\"{x:1359,y:794,t:1527189136806};\\\", \\\"{x:1357,y:790,t:1527189136822};\\\", \\\"{x:1354,y:786,t:1527189136839};\\\", \\\"{x:1354,y:785,t:1527189136869};\\\", \\\"{x:1354,y:784,t:1527189136878};\\\", \\\"{x:1353,y:782,t:1527189136941};\\\", \\\"{x:1353,y:781,t:1527189137006};\\\", \\\"{x:1352,y:779,t:1527189137023};\\\", \\\"{x:1352,y:776,t:1527189137040};\\\", \\\"{x:1352,y:775,t:1527189137057};\\\", \\\"{x:1351,y:773,t:1527189137072};\\\", \\\"{x:1351,y:772,t:1527189137094};\\\", \\\"{x:1351,y:771,t:1527189137107};\\\", \\\"{x:1350,y:770,t:1527189137123};\\\", \\\"{x:1350,y:769,t:1527189137158};\\\", \\\"{x:1357,y:769,t:1527189137726};\\\", \\\"{x:1370,y:777,t:1527189137741};\\\", \\\"{x:1405,y:796,t:1527189137757};\\\", \\\"{x:1437,y:811,t:1527189137774};\\\", \\\"{x:1451,y:817,t:1527189137790};\\\", \\\"{x:1454,y:819,t:1527189137807};\\\", \\\"{x:1455,y:819,t:1527189137871};\\\", \\\"{x:1456,y:819,t:1527189137878};\\\", \\\"{x:1458,y:819,t:1527189137891};\\\", \\\"{x:1459,y:820,t:1527189137907};\\\", \\\"{x:1461,y:820,t:1527189137924};\\\", \\\"{x:1462,y:821,t:1527189137951};\\\", \\\"{x:1464,y:821,t:1527189138031};\\\", \\\"{x:1465,y:821,t:1527189138041};\\\", \\\"{x:1467,y:821,t:1527189138057};\\\", \\\"{x:1469,y:821,t:1527189138074};\\\", \\\"{x:1472,y:821,t:1527189138091};\\\", \\\"{x:1476,y:820,t:1527189138108};\\\", \\\"{x:1476,y:818,t:1527189138124};\\\", \\\"{x:1477,y:816,t:1527189138150};\\\", \\\"{x:1477,y:815,t:1527189138157};\\\", \\\"{x:1477,y:802,t:1527189138175};\\\", \\\"{x:1477,y:786,t:1527189138191};\\\", \\\"{x:1474,y:764,t:1527189138208};\\\", \\\"{x:1468,y:747,t:1527189138224};\\\", \\\"{x:1463,y:735,t:1527189138241};\\\", \\\"{x:1460,y:727,t:1527189138258};\\\", \\\"{x:1458,y:720,t:1527189138274};\\\", \\\"{x:1453,y:710,t:1527189138291};\\\", \\\"{x:1447,y:695,t:1527189138308};\\\", \\\"{x:1443,y:681,t:1527189138324};\\\", \\\"{x:1438,y:669,t:1527189138341};\\\", \\\"{x:1435,y:663,t:1527189138358};\\\", \\\"{x:1434,y:662,t:1527189138374};\\\", \\\"{x:1434,y:657,t:1527189138391};\\\", \\\"{x:1434,y:653,t:1527189138408};\\\", \\\"{x:1432,y:647,t:1527189138424};\\\", \\\"{x:1431,y:643,t:1527189138441};\\\", \\\"{x:1430,y:639,t:1527189138458};\\\", \\\"{x:1430,y:637,t:1527189138474};\\\", \\\"{x:1430,y:636,t:1527189138491};\\\", \\\"{x:1429,y:634,t:1527189138510};\\\", \\\"{x:1429,y:633,t:1527189138638};\\\", \\\"{x:1430,y:632,t:1527189138646};\\\", \\\"{x:1431,y:632,t:1527189138727};\\\", \\\"{x:1433,y:632,t:1527189138742};\\\", \\\"{x:1434,y:632,t:1527189138759};\\\", \\\"{x:1436,y:632,t:1527189138775};\\\", \\\"{x:1437,y:632,t:1527189138854};\\\", \\\"{x:1438,y:631,t:1527189138862};\\\", \\\"{x:1439,y:631,t:1527189138878};\\\", \\\"{x:1440,y:631,t:1527189138910};\\\", \\\"{x:1441,y:631,t:1527189139015};\\\", \\\"{x:1442,y:631,t:1527189139127};\\\", \\\"{x:1442,y:629,t:1527189139358};\\\", \\\"{x:1434,y:621,t:1527189139376};\\\", \\\"{x:1428,y:613,t:1527189139392};\\\", \\\"{x:1426,y:611,t:1527189139409};\\\", \\\"{x:1423,y:608,t:1527189139425};\\\", \\\"{x:1421,y:605,t:1527189139442};\\\", \\\"{x:1418,y:600,t:1527189139459};\\\", \\\"{x:1417,y:598,t:1527189139475};\\\", \\\"{x:1417,y:596,t:1527189139492};\\\", \\\"{x:1415,y:592,t:1527189139509};\\\", \\\"{x:1413,y:590,t:1527189139525};\\\", \\\"{x:1411,y:587,t:1527189139542};\\\", \\\"{x:1410,y:585,t:1527189139559};\\\", \\\"{x:1410,y:584,t:1527189139590};\\\", \\\"{x:1410,y:583,t:1527189139598};\\\", \\\"{x:1410,y:582,t:1527189139609};\\\", \\\"{x:1410,y:581,t:1527189139625};\\\", \\\"{x:1410,y:578,t:1527189139642};\\\", \\\"{x:1410,y:574,t:1527189139659};\\\", \\\"{x:1410,y:571,t:1527189139675};\\\", \\\"{x:1411,y:569,t:1527189139692};\\\", \\\"{x:1411,y:568,t:1527189139709};\\\", \\\"{x:1411,y:566,t:1527189139725};\\\", \\\"{x:1412,y:564,t:1527189139742};\\\", \\\"{x:1412,y:563,t:1527189139759};\\\", \\\"{x:1412,y:567,t:1527189140006};\\\", \\\"{x:1413,y:575,t:1527189140015};\\\", \\\"{x:1414,y:581,t:1527189140026};\\\", \\\"{x:1414,y:594,t:1527189140043};\\\", \\\"{x:1414,y:608,t:1527189140059};\\\", \\\"{x:1414,y:619,t:1527189140076};\\\", \\\"{x:1416,y:636,t:1527189140092};\\\", \\\"{x:1416,y:650,t:1527189140109};\\\", \\\"{x:1416,y:685,t:1527189140126};\\\", \\\"{x:1418,y:729,t:1527189140142};\\\", \\\"{x:1420,y:756,t:1527189140159};\\\", \\\"{x:1420,y:779,t:1527189140176};\\\", \\\"{x:1420,y:797,t:1527189140193};\\\", \\\"{x:1420,y:819,t:1527189140209};\\\", \\\"{x:1420,y:837,t:1527189140227};\\\", \\\"{x:1417,y:855,t:1527189140242};\\\", \\\"{x:1417,y:881,t:1527189140259};\\\", \\\"{x:1415,y:916,t:1527189140276};\\\", \\\"{x:1412,y:944,t:1527189140292};\\\", \\\"{x:1412,y:971,t:1527189140310};\\\", \\\"{x:1412,y:986,t:1527189140327};\\\", \\\"{x:1412,y:988,t:1527189140342};\\\", \\\"{x:1412,y:989,t:1527189140359};\\\", \\\"{x:1412,y:991,t:1527189140382};\\\", \\\"{x:1412,y:993,t:1527189140393};\\\", \\\"{x:1412,y:996,t:1527189140409};\\\", \\\"{x:1414,y:1004,t:1527189140426};\\\", \\\"{x:1415,y:1006,t:1527189140443};\\\", \\\"{x:1416,y:1006,t:1527189140459};\\\", \\\"{x:1416,y:1004,t:1527189140559};\\\", \\\"{x:1416,y:989,t:1527189140576};\\\", \\\"{x:1416,y:970,t:1527189140594};\\\", \\\"{x:1416,y:949,t:1527189140610};\\\", \\\"{x:1416,y:923,t:1527189140626};\\\", \\\"{x:1416,y:898,t:1527189140643};\\\", \\\"{x:1416,y:871,t:1527189140659};\\\", \\\"{x:1417,y:834,t:1527189140676};\\\", \\\"{x:1420,y:788,t:1527189140693};\\\", \\\"{x:1420,y:743,t:1527189140709};\\\", \\\"{x:1413,y:700,t:1527189140727};\\\", \\\"{x:1410,y:686,t:1527189140744};\\\", \\\"{x:1409,y:681,t:1527189140760};\\\", \\\"{x:1409,y:678,t:1527189140776};\\\", \\\"{x:1409,y:675,t:1527189140795};\\\", \\\"{x:1409,y:665,t:1527189140810};\\\", \\\"{x:1410,y:650,t:1527189140826};\\\", \\\"{x:1411,y:637,t:1527189140843};\\\", \\\"{x:1411,y:629,t:1527189140860};\\\", \\\"{x:1412,y:624,t:1527189140876};\\\", \\\"{x:1412,y:622,t:1527189140892};\\\", \\\"{x:1412,y:621,t:1527189140910};\\\", \\\"{x:1413,y:619,t:1527189140926};\\\", \\\"{x:1414,y:616,t:1527189140943};\\\", \\\"{x:1415,y:610,t:1527189140960};\\\", \\\"{x:1415,y:604,t:1527189140976};\\\", \\\"{x:1415,y:599,t:1527189140994};\\\", \\\"{x:1417,y:596,t:1527189141010};\\\", \\\"{x:1417,y:595,t:1527189141027};\\\", \\\"{x:1417,y:593,t:1527189141043};\\\", \\\"{x:1417,y:591,t:1527189141060};\\\", \\\"{x:1417,y:587,t:1527189141076};\\\", \\\"{x:1417,y:584,t:1527189141093};\\\", \\\"{x:1416,y:578,t:1527189141110};\\\", \\\"{x:1415,y:575,t:1527189141126};\\\", \\\"{x:1414,y:574,t:1527189141143};\\\", \\\"{x:1414,y:573,t:1527189141182};\\\", \\\"{x:1414,y:571,t:1527189141463};\\\", \\\"{x:1414,y:569,t:1527189141477};\\\", \\\"{x:1414,y:566,t:1527189141493};\\\", \\\"{x:1413,y:562,t:1527189141509};\\\", \\\"{x:1413,y:560,t:1527189141526};\\\", \\\"{x:1412,y:557,t:1527189141543};\\\", \\\"{x:1412,y:554,t:1527189141560};\\\", \\\"{x:1411,y:551,t:1527189141576};\\\", \\\"{x:1410,y:547,t:1527189141593};\\\", \\\"{x:1409,y:545,t:1527189141610};\\\", \\\"{x:1409,y:544,t:1527189141627};\\\", \\\"{x:1409,y:543,t:1527189141646};\\\", \\\"{x:1407,y:541,t:1527189141660};\\\", \\\"{x:1406,y:540,t:1527189141678};\\\", \\\"{x:1403,y:537,t:1527189141694};\\\", \\\"{x:1403,y:536,t:1527189141767};\\\", \\\"{x:1401,y:535,t:1527189141777};\\\", \\\"{x:1399,y:533,t:1527189141794};\\\", \\\"{x:1396,y:531,t:1527189141811};\\\", \\\"{x:1394,y:529,t:1527189141827};\\\", \\\"{x:1393,y:527,t:1527189141844};\\\", \\\"{x:1391,y:527,t:1527189141860};\\\", \\\"{x:1389,y:526,t:1527189141877};\\\", \\\"{x:1387,y:525,t:1527189141894};\\\", \\\"{x:1386,y:524,t:1527189141910};\\\", \\\"{x:1384,y:524,t:1527189141927};\\\", \\\"{x:1382,y:523,t:1527189141944};\\\", \\\"{x:1380,y:522,t:1527189141960};\\\", \\\"{x:1379,y:521,t:1527189141977};\\\", \\\"{x:1378,y:521,t:1527189141994};\\\", \\\"{x:1377,y:520,t:1527189142010};\\\", \\\"{x:1375,y:517,t:1527189142027};\\\", \\\"{x:1373,y:513,t:1527189142044};\\\", \\\"{x:1370,y:510,t:1527189142061};\\\", \\\"{x:1369,y:509,t:1527189142086};\\\", \\\"{x:1369,y:508,t:1527189142094};\\\", \\\"{x:1369,y:506,t:1527189142111};\\\", \\\"{x:1368,y:505,t:1527189142128};\\\", \\\"{x:1368,y:504,t:1527189142144};\\\", \\\"{x:1367,y:502,t:1527189142161};\\\", \\\"{x:1367,y:501,t:1527189142238};\\\", \\\"{x:1367,y:500,t:1527189142262};\\\", \\\"{x:1367,y:498,t:1527189142286};\\\", \\\"{x:1368,y:497,t:1527189142302};\\\", \\\"{x:1368,y:495,t:1527189142318};\\\", \\\"{x:1369,y:494,t:1527189142327};\\\", \\\"{x:1372,y:490,t:1527189142344};\\\", \\\"{x:1375,y:483,t:1527189142361};\\\", \\\"{x:1377,y:481,t:1527189142377};\\\", \\\"{x:1379,y:476,t:1527189142395};\\\", \\\"{x:1379,y:473,t:1527189142410};\\\", \\\"{x:1380,y:473,t:1527189142426};\\\", \\\"{x:1380,y:480,t:1527189142525};\\\", \\\"{x:1380,y:487,t:1527189142533};\\\", \\\"{x:1380,y:495,t:1527189142544};\\\", \\\"{x:1380,y:515,t:1527189142561};\\\", \\\"{x:1380,y:540,t:1527189142578};\\\", \\\"{x:1378,y:565,t:1527189142593};\\\", \\\"{x:1378,y:589,t:1527189142611};\\\", \\\"{x:1378,y:612,t:1527189142628};\\\", \\\"{x:1378,y:626,t:1527189142645};\\\", \\\"{x:1379,y:639,t:1527189142661};\\\", \\\"{x:1382,y:659,t:1527189142678};\\\", \\\"{x:1382,y:671,t:1527189142694};\\\", \\\"{x:1383,y:680,t:1527189142711};\\\", \\\"{x:1384,y:681,t:1527189142728};\\\", \\\"{x:1384,y:683,t:1527189142744};\\\", \\\"{x:1384,y:685,t:1527189142790};\\\", \\\"{x:1384,y:687,t:1527189142807};\\\", \\\"{x:1383,y:687,t:1527189142814};\\\", \\\"{x:1382,y:688,t:1527189142847};\\\", \\\"{x:1381,y:688,t:1527189142861};\\\", \\\"{x:1378,y:689,t:1527189142878};\\\", \\\"{x:1377,y:689,t:1527189142902};\\\", \\\"{x:1375,y:689,t:1527189142926};\\\", \\\"{x:1372,y:689,t:1527189142935};\\\", \\\"{x:1364,y:691,t:1527189142944};\\\", \\\"{x:1342,y:691,t:1527189142961};\\\", \\\"{x:1324,y:691,t:1527189142978};\\\", \\\"{x:1318,y:691,t:1527189142995};\\\", \\\"{x:1316,y:692,t:1527189143011};\\\", \\\"{x:1317,y:692,t:1527189143142};\\\", \\\"{x:1318,y:693,t:1527189143150};\\\", \\\"{x:1320,y:694,t:1527189143161};\\\", \\\"{x:1321,y:694,t:1527189143178};\\\", \\\"{x:1324,y:694,t:1527189143195};\\\", \\\"{x:1327,y:694,t:1527189143211};\\\", \\\"{x:1329,y:694,t:1527189143229};\\\", \\\"{x:1334,y:695,t:1527189143245};\\\", \\\"{x:1340,y:698,t:1527189143261};\\\", \\\"{x:1349,y:702,t:1527189143278};\\\", \\\"{x:1351,y:703,t:1527189143295};\\\", \\\"{x:1352,y:704,t:1527189143311};\\\", \\\"{x:1351,y:704,t:1527189143462};\\\", \\\"{x:1350,y:704,t:1527189143478};\\\", \\\"{x:1349,y:703,t:1527189143630};\\\", \\\"{x:1349,y:702,t:1527189143654};\\\", \\\"{x:1349,y:699,t:1527189143677};\\\", \\\"{x:1349,y:698,t:1527189143695};\\\", \\\"{x:1348,y:698,t:1527189144246};\\\", \\\"{x:1347,y:708,t:1527189144263};\\\", \\\"{x:1346,y:718,t:1527189144279};\\\", \\\"{x:1345,y:726,t:1527189144296};\\\", \\\"{x:1345,y:734,t:1527189144312};\\\", \\\"{x:1345,y:745,t:1527189144330};\\\", \\\"{x:1345,y:758,t:1527189144347};\\\", \\\"{x:1345,y:788,t:1527189144364};\\\", \\\"{x:1342,y:840,t:1527189144379};\\\", \\\"{x:1342,y:909,t:1527189144396};\\\", \\\"{x:1343,y:945,t:1527189144412};\\\", \\\"{x:1348,y:965,t:1527189144429};\\\", \\\"{x:1351,y:974,t:1527189144446};\\\", \\\"{x:1352,y:975,t:1527189144462};\\\", \\\"{x:1352,y:966,t:1527189144599};\\\", \\\"{x:1351,y:962,t:1527189144613};\\\", \\\"{x:1349,y:954,t:1527189144629};\\\", \\\"{x:1347,y:937,t:1527189144646};\\\", \\\"{x:1345,y:914,t:1527189144662};\\\", \\\"{x:1345,y:884,t:1527189144679};\\\", \\\"{x:1344,y:851,t:1527189144696};\\\", \\\"{x:1340,y:810,t:1527189144713};\\\", \\\"{x:1338,y:795,t:1527189144729};\\\", \\\"{x:1336,y:785,t:1527189144746};\\\", \\\"{x:1336,y:778,t:1527189144763};\\\", \\\"{x:1336,y:770,t:1527189144779};\\\", \\\"{x:1336,y:761,t:1527189144796};\\\", \\\"{x:1336,y:758,t:1527189144814};\\\", \\\"{x:1336,y:757,t:1527189144829};\\\", \\\"{x:1336,y:756,t:1527189144846};\\\", \\\"{x:1336,y:755,t:1527189144886};\\\", \\\"{x:1337,y:754,t:1527189144896};\\\", \\\"{x:1340,y:751,t:1527189144913};\\\", \\\"{x:1342,y:748,t:1527189144929};\\\", \\\"{x:1343,y:745,t:1527189144946};\\\", \\\"{x:1346,y:737,t:1527189144963};\\\", \\\"{x:1353,y:725,t:1527189144979};\\\", \\\"{x:1357,y:713,t:1527189144996};\\\", \\\"{x:1359,y:702,t:1527189145013};\\\", \\\"{x:1359,y:696,t:1527189145029};\\\", \\\"{x:1360,y:693,t:1527189145046};\\\", \\\"{x:1357,y:692,t:1527189145478};\\\", \\\"{x:1352,y:692,t:1527189145486};\\\", \\\"{x:1337,y:692,t:1527189145496};\\\", \\\"{x:1273,y:692,t:1527189145514};\\\", \\\"{x:1136,y:684,t:1527189145530};\\\", \\\"{x:980,y:671,t:1527189145546};\\\", \\\"{x:833,y:649,t:1527189145564};\\\", \\\"{x:751,y:630,t:1527189145582};\\\", \\\"{x:733,y:623,t:1527189145597};\\\", \\\"{x:732,y:623,t:1527189145613};\\\", \\\"{x:731,y:622,t:1527189145630};\\\", \\\"{x:722,y:616,t:1527189145647};\\\", \\\"{x:710,y:611,t:1527189145664};\\\", \\\"{x:702,y:605,t:1527189145680};\\\", \\\"{x:696,y:598,t:1527189145697};\\\", \\\"{x:693,y:591,t:1527189145714};\\\", \\\"{x:693,y:585,t:1527189145730};\\\", \\\"{x:693,y:582,t:1527189145746};\\\", \\\"{x:695,y:580,t:1527189145763};\\\", \\\"{x:696,y:579,t:1527189145780};\\\", \\\"{x:696,y:576,t:1527189145798};\\\", \\\"{x:691,y:569,t:1527189145815};\\\", \\\"{x:686,y:565,t:1527189145831};\\\", \\\"{x:680,y:561,t:1527189145846};\\\", \\\"{x:676,y:558,t:1527189145864};\\\", \\\"{x:675,y:557,t:1527189145881};\\\", \\\"{x:673,y:555,t:1527189145909};\\\", \\\"{x:673,y:553,t:1527189145917};\\\", \\\"{x:672,y:550,t:1527189145930};\\\", \\\"{x:672,y:539,t:1527189145946};\\\", \\\"{x:672,y:532,t:1527189145964};\\\", \\\"{x:697,y:522,t:1527189145981};\\\", \\\"{x:826,y:515,t:1527189145997};\\\", \\\"{x:901,y:515,t:1527189146014};\\\", \\\"{x:922,y:515,t:1527189146031};\\\", \\\"{x:926,y:514,t:1527189146047};\\\", \\\"{x:926,y:513,t:1527189146158};\\\", \\\"{x:922,y:513,t:1527189146166};\\\", \\\"{x:915,y:513,t:1527189146181};\\\", \\\"{x:884,y:513,t:1527189146197};\\\", \\\"{x:873,y:513,t:1527189146215};\\\", \\\"{x:870,y:513,t:1527189146231};\\\", \\\"{x:866,y:513,t:1527189146933};\\\", \\\"{x:860,y:514,t:1527189146949};\\\", \\\"{x:840,y:514,t:1527189146964};\\\", \\\"{x:824,y:514,t:1527189146981};\\\", \\\"{x:818,y:514,t:1527189146997};\\\", \\\"{x:819,y:514,t:1527189147814};\\\", \\\"{x:820,y:514,t:1527189147830};\\\", \\\"{x:822,y:514,t:1527189147910};\\\", \\\"{x:823,y:514,t:1527189147925};\\\", \\\"{x:825,y:514,t:1527189148510};\\\", \\\"{x:827,y:517,t:1527189148518};\\\", \\\"{x:829,y:521,t:1527189148533};\\\", \\\"{x:836,y:530,t:1527189148549};\\\", \\\"{x:837,y:532,t:1527189148566};\\\", \\\"{x:836,y:528,t:1527189149511};\\\", \\\"{x:836,y:526,t:1527189149519};\\\", \\\"{x:835,y:523,t:1527189149532};\\\", \\\"{x:834,y:518,t:1527189149549};\\\", \\\"{x:832,y:516,t:1527189149565};\\\", \\\"{x:833,y:516,t:1527189149998};\\\", \\\"{x:849,y:519,t:1527189150006};\\\", \\\"{x:887,y:542,t:1527189150020};\\\", \\\"{x:995,y:590,t:1527189150034};\\\", \\\"{x:1134,y:642,t:1527189150051};\\\", \\\"{x:1279,y:688,t:1527189150067};\\\", \\\"{x:1370,y:713,t:1527189150084};\\\", \\\"{x:1388,y:716,t:1527189150101};\\\", \\\"{x:1391,y:716,t:1527189150116};\\\", \\\"{x:1393,y:716,t:1527189150134};\\\", \\\"{x:1393,y:710,t:1527189150150};\\\", \\\"{x:1390,y:699,t:1527189150166};\\\", \\\"{x:1384,y:690,t:1527189150184};\\\", \\\"{x:1372,y:676,t:1527189150201};\\\", \\\"{x:1361,y:662,t:1527189150217};\\\", \\\"{x:1344,y:648,t:1527189150234};\\\", \\\"{x:1324,y:638,t:1527189150251};\\\", \\\"{x:1302,y:629,t:1527189150267};\\\", \\\"{x:1288,y:623,t:1527189150284};\\\", \\\"{x:1276,y:617,t:1527189150301};\\\", \\\"{x:1265,y:612,t:1527189150318};\\\", \\\"{x:1264,y:611,t:1527189150334};\\\", \\\"{x:1264,y:610,t:1527189150374};\\\", \\\"{x:1264,y:609,t:1527189150384};\\\", \\\"{x:1262,y:606,t:1527189150401};\\\", \\\"{x:1259,y:603,t:1527189150417};\\\", \\\"{x:1259,y:601,t:1527189150434};\\\", \\\"{x:1259,y:598,t:1527189150451};\\\", \\\"{x:1259,y:595,t:1527189150468};\\\", \\\"{x:1259,y:593,t:1527189150484};\\\", \\\"{x:1261,y:590,t:1527189150501};\\\", \\\"{x:1263,y:588,t:1527189150519};\\\", \\\"{x:1264,y:587,t:1527189150534};\\\", \\\"{x:1266,y:586,t:1527189150551};\\\", \\\"{x:1267,y:584,t:1527189150569};\\\", \\\"{x:1267,y:582,t:1527189150584};\\\", \\\"{x:1267,y:581,t:1527189150606};\\\", \\\"{x:1268,y:580,t:1527189150619};\\\", \\\"{x:1269,y:578,t:1527189150635};\\\", \\\"{x:1269,y:576,t:1527189150653};\\\", \\\"{x:1269,y:575,t:1527189150678};\\\", \\\"{x:1269,y:573,t:1527189150710};\\\", \\\"{x:1269,y:574,t:1527189150934};\\\", \\\"{x:1269,y:580,t:1527189150941};\\\", \\\"{x:1269,y:585,t:1527189150951};\\\", \\\"{x:1269,y:598,t:1527189150968};\\\", \\\"{x:1269,y:617,t:1527189150985};\\\", \\\"{x:1274,y:645,t:1527189151001};\\\", \\\"{x:1277,y:667,t:1527189151018};\\\", \\\"{x:1279,y:685,t:1527189151035};\\\", \\\"{x:1281,y:697,t:1527189151051};\\\", \\\"{x:1282,y:707,t:1527189151068};\\\", \\\"{x:1287,y:728,t:1527189151085};\\\", \\\"{x:1289,y:752,t:1527189151101};\\\", \\\"{x:1292,y:785,t:1527189151118};\\\", \\\"{x:1292,y:804,t:1527189151135};\\\", \\\"{x:1293,y:816,t:1527189151152};\\\", \\\"{x:1293,y:825,t:1527189151168};\\\", \\\"{x:1293,y:832,t:1527189151186};\\\", \\\"{x:1293,y:844,t:1527189151201};\\\", \\\"{x:1293,y:865,t:1527189151217};\\\", \\\"{x:1293,y:890,t:1527189151235};\\\", \\\"{x:1293,y:926,t:1527189151251};\\\", \\\"{x:1293,y:949,t:1527189151268};\\\", \\\"{x:1294,y:967,t:1527189151285};\\\", \\\"{x:1296,y:972,t:1527189151301};\\\", \\\"{x:1296,y:974,t:1527189151317};\\\", \\\"{x:1296,y:979,t:1527189151335};\\\", \\\"{x:1296,y:987,t:1527189151352};\\\", \\\"{x:1296,y:994,t:1527189151368};\\\", \\\"{x:1296,y:998,t:1527189151385};\\\", \\\"{x:1296,y:992,t:1527189151526};\\\", \\\"{x:1296,y:986,t:1527189151535};\\\", \\\"{x:1296,y:972,t:1527189151552};\\\", \\\"{x:1295,y:955,t:1527189151568};\\\", \\\"{x:1295,y:937,t:1527189151585};\\\", \\\"{x:1295,y:907,t:1527189151602};\\\", \\\"{x:1295,y:857,t:1527189151618};\\\", \\\"{x:1295,y:774,t:1527189151635};\\\", \\\"{x:1295,y:685,t:1527189151652};\\\", \\\"{x:1295,y:612,t:1527189151668};\\\", \\\"{x:1295,y:562,t:1527189151685};\\\", \\\"{x:1291,y:515,t:1527189151702};\\\", \\\"{x:1289,y:500,t:1527189151718};\\\", \\\"{x:1289,y:495,t:1527189151735};\\\", \\\"{x:1287,y:502,t:1527189151854};\\\", \\\"{x:1285,y:547,t:1527189151870};\\\", \\\"{x:1285,y:613,t:1527189151886};\\\", \\\"{x:1285,y:680,t:1527189151902};\\\", \\\"{x:1285,y:739,t:1527189151920};\\\", \\\"{x:1285,y:800,t:1527189151935};\\\", \\\"{x:1285,y:867,t:1527189151952};\\\", \\\"{x:1285,y:914,t:1527189151970};\\\", \\\"{x:1285,y:945,t:1527189151986};\\\", \\\"{x:1285,y:964,t:1527189152003};\\\", \\\"{x:1285,y:973,t:1527189152020};\\\", \\\"{x:1285,y:975,t:1527189152036};\\\", \\\"{x:1285,y:976,t:1527189152053};\\\", \\\"{x:1286,y:976,t:1527189152230};\\\", \\\"{x:1287,y:973,t:1527189152237};\\\", \\\"{x:1289,y:971,t:1527189152253};\\\", \\\"{x:1290,y:969,t:1527189152270};\\\", \\\"{x:1292,y:966,t:1527189152287};\\\", \\\"{x:1293,y:965,t:1527189152303};\\\", \\\"{x:1294,y:962,t:1527189152320};\\\", \\\"{x:1296,y:958,t:1527189152336};\\\", \\\"{x:1297,y:956,t:1527189152352};\\\", \\\"{x:1299,y:954,t:1527189152369};\\\", \\\"{x:1299,y:953,t:1527189152389};\\\", \\\"{x:1299,y:951,t:1527189152494};\\\", \\\"{x:1300,y:951,t:1527189155097};\\\", \\\"{x:1305,y:948,t:1527189155107};\\\", \\\"{x:1314,y:945,t:1527189155125};\\\", \\\"{x:1323,y:942,t:1527189155141};\\\", \\\"{x:1328,y:940,t:1527189155158};\\\", \\\"{x:1332,y:939,t:1527189155175};\\\", \\\"{x:1333,y:939,t:1527189155193};\\\", \\\"{x:1335,y:938,t:1527189155207};\\\", \\\"{x:1349,y:934,t:1527189155225};\\\", \\\"{x:1362,y:930,t:1527189155241};\\\", \\\"{x:1375,y:928,t:1527189155258};\\\", \\\"{x:1381,y:926,t:1527189155275};\\\", \\\"{x:1383,y:926,t:1527189155290};\\\", \\\"{x:1385,y:926,t:1527189155378};\\\", \\\"{x:1386,y:925,t:1527189155390};\\\", \\\"{x:1389,y:924,t:1527189155408};\\\", \\\"{x:1391,y:923,t:1527189155425};\\\", \\\"{x:1391,y:922,t:1527189155657};\\\", \\\"{x:1391,y:921,t:1527189155681};\\\", \\\"{x:1389,y:920,t:1527189155697};\\\", \\\"{x:1388,y:920,t:1527189155713};\\\", \\\"{x:1386,y:919,t:1527189155729};\\\", \\\"{x:1385,y:919,t:1527189155777};\\\", \\\"{x:1384,y:919,t:1527189155833};\\\", \\\"{x:1383,y:918,t:1527189155930};\\\", \\\"{x:1383,y:917,t:1527189155945};\\\", \\\"{x:1382,y:915,t:1527189156033};\\\", \\\"{x:1382,y:913,t:1527189156042};\\\", \\\"{x:1382,y:911,t:1527189156059};\\\", \\\"{x:1382,y:909,t:1527189156075};\\\", \\\"{x:1384,y:907,t:1527189156092};\\\", \\\"{x:1385,y:905,t:1527189156109};\\\", \\\"{x:1386,y:904,t:1527189156125};\\\", \\\"{x:1387,y:904,t:1527189156209};\\\", \\\"{x:1390,y:904,t:1527189156225};\\\", \\\"{x:1394,y:904,t:1527189156242};\\\", \\\"{x:1397,y:904,t:1527189156259};\\\", \\\"{x:1402,y:904,t:1527189156275};\\\", \\\"{x:1408,y:906,t:1527189156292};\\\", \\\"{x:1418,y:906,t:1527189156309};\\\", \\\"{x:1423,y:906,t:1527189156325};\\\", \\\"{x:1427,y:904,t:1527189156342};\\\", \\\"{x:1429,y:900,t:1527189156359};\\\", \\\"{x:1432,y:895,t:1527189156375};\\\", \\\"{x:1434,y:882,t:1527189156392};\\\", \\\"{x:1434,y:861,t:1527189156409};\\\", \\\"{x:1434,y:852,t:1527189156426};\\\", \\\"{x:1434,y:838,t:1527189156442};\\\", \\\"{x:1434,y:821,t:1527189156459};\\\", \\\"{x:1434,y:799,t:1527189156476};\\\", \\\"{x:1434,y:778,t:1527189156492};\\\", \\\"{x:1434,y:750,t:1527189156509};\\\", \\\"{x:1436,y:726,t:1527189156526};\\\", \\\"{x:1441,y:709,t:1527189156542};\\\", \\\"{x:1442,y:698,t:1527189156559};\\\", \\\"{x:1442,y:693,t:1527189156576};\\\", \\\"{x:1442,y:686,t:1527189156592};\\\", \\\"{x:1440,y:676,t:1527189156609};\\\", \\\"{x:1437,y:672,t:1527189156625};\\\", \\\"{x:1436,y:668,t:1527189156642};\\\", \\\"{x:1433,y:665,t:1527189156659};\\\", \\\"{x:1431,y:662,t:1527189156676};\\\", \\\"{x:1429,y:659,t:1527189156692};\\\", \\\"{x:1428,y:656,t:1527189156709};\\\", \\\"{x:1428,y:655,t:1527189156730};\\\", \\\"{x:1427,y:654,t:1527189156741};\\\", \\\"{x:1426,y:653,t:1527189156759};\\\", \\\"{x:1425,y:651,t:1527189156776};\\\", \\\"{x:1422,y:648,t:1527189156792};\\\", \\\"{x:1418,y:642,t:1527189156808};\\\", \\\"{x:1415,y:638,t:1527189156826};\\\", \\\"{x:1413,y:636,t:1527189156841};\\\", \\\"{x:1413,y:634,t:1527189156888};\\\", \\\"{x:1412,y:631,t:1527189156896};\\\", \\\"{x:1410,y:629,t:1527189156908};\\\", \\\"{x:1409,y:622,t:1527189156925};\\\", \\\"{x:1406,y:615,t:1527189156941};\\\", \\\"{x:1405,y:608,t:1527189156958};\\\", \\\"{x:1405,y:601,t:1527189156975};\\\", \\\"{x:1405,y:593,t:1527189156992};\\\", \\\"{x:1405,y:587,t:1527189157008};\\\", \\\"{x:1404,y:586,t:1527189157025};\\\", \\\"{x:1404,y:584,t:1527189157043};\\\", \\\"{x:1403,y:583,t:1527189157059};\\\", \\\"{x:1403,y:582,t:1527189157076};\\\", \\\"{x:1403,y:580,t:1527189157092};\\\", \\\"{x:1403,y:585,t:1527189157202};\\\", \\\"{x:1402,y:596,t:1527189157209};\\\", \\\"{x:1402,y:618,t:1527189157226};\\\", \\\"{x:1402,y:646,t:1527189157243};\\\", \\\"{x:1407,y:674,t:1527189157259};\\\", \\\"{x:1411,y:712,t:1527189157275};\\\", \\\"{x:1414,y:758,t:1527189157293};\\\", \\\"{x:1425,y:810,t:1527189157309};\\\", \\\"{x:1432,y:840,t:1527189157326};\\\", \\\"{x:1433,y:861,t:1527189157343};\\\", \\\"{x:1438,y:878,t:1527189157359};\\\", \\\"{x:1438,y:890,t:1527189157377};\\\", \\\"{x:1442,y:902,t:1527189157393};\\\", \\\"{x:1443,y:906,t:1527189157409};\\\", \\\"{x:1445,y:908,t:1527189157426};\\\", \\\"{x:1446,y:909,t:1527189157443};\\\", \\\"{x:1447,y:909,t:1527189157489};\\\", \\\"{x:1450,y:909,t:1527189157498};\\\", \\\"{x:1454,y:906,t:1527189157509};\\\", \\\"{x:1464,y:894,t:1527189157526};\\\", \\\"{x:1471,y:878,t:1527189157543};\\\", \\\"{x:1474,y:867,t:1527189157560};\\\", \\\"{x:1474,y:854,t:1527189157576};\\\", \\\"{x:1474,y:850,t:1527189157593};\\\", \\\"{x:1474,y:849,t:1527189157610};\\\", \\\"{x:1474,y:848,t:1527189157626};\\\", \\\"{x:1474,y:845,t:1527189157643};\\\", \\\"{x:1473,y:842,t:1527189157660};\\\", \\\"{x:1471,y:838,t:1527189157675};\\\", \\\"{x:1470,y:837,t:1527189157692};\\\", \\\"{x:1469,y:836,t:1527189157721};\\\", \\\"{x:1467,y:835,t:1527189157745};\\\", \\\"{x:1467,y:834,t:1527189157906};\\\", \\\"{x:1467,y:833,t:1527189157929};\\\", \\\"{x:1467,y:830,t:1527189157943};\\\", \\\"{x:1469,y:828,t:1527189157960};\\\", \\\"{x:1471,y:826,t:1527189157976};\\\", \\\"{x:1472,y:821,t:1527189157993};\\\", \\\"{x:1472,y:816,t:1527189158010};\\\", \\\"{x:1472,y:812,t:1527189158027};\\\", \\\"{x:1472,y:814,t:1527189158114};\\\", \\\"{x:1472,y:818,t:1527189158127};\\\", \\\"{x:1472,y:828,t:1527189158143};\\\", \\\"{x:1473,y:845,t:1527189158160};\\\", \\\"{x:1478,y:871,t:1527189158177};\\\", \\\"{x:1481,y:893,t:1527189158193};\\\", \\\"{x:1483,y:913,t:1527189158210};\\\", \\\"{x:1487,y:930,t:1527189158227};\\\", \\\"{x:1488,y:942,t:1527189158243};\\\", \\\"{x:1488,y:951,t:1527189158260};\\\", \\\"{x:1488,y:959,t:1527189158277};\\\", \\\"{x:1488,y:966,t:1527189158293};\\\", \\\"{x:1488,y:969,t:1527189158310};\\\", \\\"{x:1488,y:971,t:1527189158327};\\\", \\\"{x:1489,y:971,t:1527189158561};\\\", \\\"{x:1490,y:971,t:1527189158577};\\\", \\\"{x:1490,y:966,t:1527189158593};\\\", \\\"{x:1490,y:960,t:1527189158610};\\\", \\\"{x:1490,y:956,t:1527189158627};\\\", \\\"{x:1490,y:950,t:1527189158644};\\\", \\\"{x:1490,y:943,t:1527189158660};\\\", \\\"{x:1490,y:930,t:1527189158677};\\\", \\\"{x:1490,y:912,t:1527189158694};\\\", \\\"{x:1490,y:895,t:1527189158710};\\\", \\\"{x:1490,y:878,t:1527189158727};\\\", \\\"{x:1490,y:872,t:1527189158744};\\\", \\\"{x:1489,y:866,t:1527189158760};\\\", \\\"{x:1488,y:855,t:1527189158777};\\\", \\\"{x:1486,y:848,t:1527189158794};\\\", \\\"{x:1486,y:843,t:1527189158810};\\\", \\\"{x:1485,y:838,t:1527189158827};\\\", \\\"{x:1484,y:836,t:1527189158844};\\\", \\\"{x:1484,y:835,t:1527189158860};\\\", \\\"{x:1483,y:834,t:1527189158877};\\\", \\\"{x:1483,y:833,t:1527189158910};\\\", \\\"{x:1483,y:831,t:1527189158926};\\\", \\\"{x:1482,y:829,t:1527189158943};\\\", \\\"{x:1482,y:828,t:1527189158960};\\\", \\\"{x:1482,y:827,t:1527189158976};\\\", \\\"{x:1482,y:826,t:1527189159601};\\\", \\\"{x:1474,y:813,t:1527189159612};\\\", \\\"{x:1443,y:768,t:1527189159628};\\\", \\\"{x:1415,y:733,t:1527189159644};\\\", \\\"{x:1400,y:714,t:1527189159661};\\\", \\\"{x:1389,y:704,t:1527189159678};\\\", \\\"{x:1389,y:701,t:1527189159694};\\\", \\\"{x:1389,y:698,t:1527189159711};\\\", \\\"{x:1389,y:692,t:1527189159728};\\\", \\\"{x:1387,y:684,t:1527189159744};\\\", \\\"{x:1381,y:673,t:1527189159761};\\\", \\\"{x:1375,y:664,t:1527189159778};\\\", \\\"{x:1374,y:661,t:1527189159794};\\\", \\\"{x:1373,y:657,t:1527189159810};\\\", \\\"{x:1373,y:656,t:1527189159828};\\\", \\\"{x:1373,y:655,t:1527189159843};\\\", \\\"{x:1373,y:650,t:1527189159861};\\\", \\\"{x:1374,y:647,t:1527189159877};\\\", \\\"{x:1379,y:639,t:1527189159894};\\\", \\\"{x:1382,y:634,t:1527189159910};\\\", \\\"{x:1385,y:628,t:1527189159928};\\\", \\\"{x:1390,y:622,t:1527189159943};\\\", \\\"{x:1398,y:616,t:1527189159960};\\\", \\\"{x:1400,y:611,t:1527189159977};\\\", \\\"{x:1404,y:607,t:1527189159994};\\\", \\\"{x:1408,y:600,t:1527189160010};\\\", \\\"{x:1414,y:593,t:1527189160027};\\\", \\\"{x:1416,y:591,t:1527189160044};\\\", \\\"{x:1418,y:589,t:1527189160061};\\\", \\\"{x:1418,y:587,t:1527189160081};\\\", \\\"{x:1418,y:586,t:1527189160482};\\\", \\\"{x:1418,y:582,t:1527189160495};\\\", \\\"{x:1417,y:574,t:1527189160511};\\\", \\\"{x:1412,y:567,t:1527189160529};\\\", \\\"{x:1409,y:559,t:1527189160546};\\\", \\\"{x:1409,y:553,t:1527189160561};\\\", \\\"{x:1408,y:547,t:1527189160578};\\\", \\\"{x:1406,y:538,t:1527189160594};\\\", \\\"{x:1406,y:528,t:1527189160612};\\\", \\\"{x:1405,y:520,t:1527189160628};\\\", \\\"{x:1404,y:513,t:1527189160645};\\\", \\\"{x:1404,y:512,t:1527189160662};\\\", \\\"{x:1404,y:508,t:1527189160678};\\\", \\\"{x:1404,y:502,t:1527189160695};\\\", \\\"{x:1402,y:497,t:1527189160712};\\\", \\\"{x:1402,y:491,t:1527189160728};\\\", \\\"{x:1402,y:486,t:1527189160745};\\\", \\\"{x:1402,y:482,t:1527189160762};\\\", \\\"{x:1402,y:481,t:1527189160778};\\\", \\\"{x:1402,y:480,t:1527189160795};\\\", \\\"{x:1402,y:479,t:1527189160833};\\\", \\\"{x:1402,y:478,t:1527189160845};\\\", \\\"{x:1403,y:476,t:1527189160863};\\\", \\\"{x:1403,y:472,t:1527189160878};\\\", \\\"{x:1403,y:469,t:1527189160895};\\\", \\\"{x:1405,y:465,t:1527189160912};\\\", \\\"{x:1406,y:462,t:1527189160929};\\\", \\\"{x:1407,y:459,t:1527189160945};\\\", \\\"{x:1408,y:458,t:1527189160962};\\\", \\\"{x:1408,y:456,t:1527189160978};\\\", \\\"{x:1408,y:455,t:1527189160995};\\\", \\\"{x:1409,y:453,t:1527189161012};\\\", \\\"{x:1409,y:452,t:1527189161029};\\\", \\\"{x:1409,y:454,t:1527189161561};\\\", \\\"{x:1409,y:474,t:1527189161579};\\\", \\\"{x:1409,y:489,t:1527189161597};\\\", \\\"{x:1409,y:496,t:1527189161612};\\\", \\\"{x:1409,y:500,t:1527189161630};\\\", \\\"{x:1409,y:504,t:1527189161646};\\\", \\\"{x:1408,y:517,t:1527189161662};\\\", \\\"{x:1403,y:551,t:1527189161679};\\\", \\\"{x:1394,y:642,t:1527189161696};\\\", \\\"{x:1377,y:766,t:1527189161712};\\\", \\\"{x:1341,y:960,t:1527189161729};\\\", \\\"{x:1329,y:1033,t:1527189161746};\\\", \\\"{x:1322,y:1061,t:1527189161762};\\\", \\\"{x:1321,y:1070,t:1527189161779};\\\", \\\"{x:1320,y:1075,t:1527189161798};\\\", \\\"{x:1319,y:1080,t:1527189161812};\\\", \\\"{x:1319,y:1081,t:1527189161829};\\\", \\\"{x:1321,y:1081,t:1527189161977};\\\", \\\"{x:1324,y:1075,t:1527189161985};\\\", \\\"{x:1329,y:1065,t:1527189161997};\\\", \\\"{x:1336,y:1048,t:1527189162013};\\\", \\\"{x:1352,y:1022,t:1527189162029};\\\", \\\"{x:1368,y:994,t:1527189162046};\\\", \\\"{x:1376,y:974,t:1527189162062};\\\", \\\"{x:1377,y:961,t:1527189162079};\\\", \\\"{x:1377,y:951,t:1527189162096};\\\", \\\"{x:1377,y:937,t:1527189162112};\\\", \\\"{x:1377,y:927,t:1527189162129};\\\", \\\"{x:1377,y:922,t:1527189162146};\\\", \\\"{x:1380,y:917,t:1527189162163};\\\", \\\"{x:1381,y:915,t:1527189162179};\\\", \\\"{x:1381,y:914,t:1527189162197};\\\", \\\"{x:1382,y:913,t:1527189162213};\\\", \\\"{x:1382,y:911,t:1527189162229};\\\", \\\"{x:1382,y:910,t:1527189162249};\\\", \\\"{x:1382,y:906,t:1527189162665};\\\", \\\"{x:1382,y:903,t:1527189162680};\\\", \\\"{x:1382,y:902,t:1527189162696};\\\", \\\"{x:1382,y:899,t:1527189162713};\\\", \\\"{x:1381,y:899,t:1527189162730};\\\", \\\"{x:1381,y:898,t:1527189162801};\\\", \\\"{x:1381,y:897,t:1527189162813};\\\", \\\"{x:1381,y:896,t:1527189162857};\\\", \\\"{x:1378,y:887,t:1527189164250};\\\", \\\"{x:1372,y:872,t:1527189164265};\\\", \\\"{x:1356,y:836,t:1527189164281};\\\", \\\"{x:1351,y:821,t:1527189164297};\\\", \\\"{x:1349,y:814,t:1527189164315};\\\", \\\"{x:1347,y:809,t:1527189164332};\\\", \\\"{x:1347,y:806,t:1527189164347};\\\", \\\"{x:1347,y:800,t:1527189164364};\\\", \\\"{x:1346,y:794,t:1527189164382};\\\", \\\"{x:1344,y:790,t:1527189164397};\\\", \\\"{x:1343,y:787,t:1527189164414};\\\", \\\"{x:1341,y:783,t:1527189164431};\\\", \\\"{x:1341,y:782,t:1527189164447};\\\", \\\"{x:1341,y:781,t:1527189164464};\\\", \\\"{x:1341,y:780,t:1527189164513};\\\", \\\"{x:1341,y:779,t:1527189164531};\\\", \\\"{x:1341,y:778,t:1527189164548};\\\", \\\"{x:1341,y:777,t:1527189164564};\\\", \\\"{x:1341,y:776,t:1527189164593};\\\", \\\"{x:1341,y:775,t:1527189164625};\\\", \\\"{x:1341,y:774,t:1527189164633};\\\", \\\"{x:1341,y:773,t:1527189164657};\\\", \\\"{x:1341,y:772,t:1527189164665};\\\", \\\"{x:1341,y:771,t:1527189164689};\\\", \\\"{x:1341,y:770,t:1527189164825};\\\", \\\"{x:1341,y:769,t:1527189164914};\\\", \\\"{x:1342,y:767,t:1527189164931};\\\", \\\"{x:1344,y:766,t:1527189164949};\\\", \\\"{x:1345,y:764,t:1527189164964};\\\", \\\"{x:1345,y:763,t:1527189164981};\\\", \\\"{x:1345,y:762,t:1527189165049};\\\", \\\"{x:1345,y:761,t:1527189165064};\\\", \\\"{x:1347,y:758,t:1527189165080};\\\", \\\"{x:1347,y:756,t:1527189165162};\\\", \\\"{x:1347,y:754,t:1527189165177};\\\", \\\"{x:1347,y:752,t:1527189165185};\\\", \\\"{x:1347,y:751,t:1527189165198};\\\", \\\"{x:1347,y:745,t:1527189165214};\\\", \\\"{x:1347,y:741,t:1527189165232};\\\", \\\"{x:1347,y:738,t:1527189165249};\\\", \\\"{x:1347,y:733,t:1527189165265};\\\", \\\"{x:1347,y:727,t:1527189165282};\\\", \\\"{x:1347,y:722,t:1527189165298};\\\", \\\"{x:1347,y:718,t:1527189165315};\\\", \\\"{x:1347,y:712,t:1527189165332};\\\", \\\"{x:1347,y:709,t:1527189165348};\\\", \\\"{x:1347,y:708,t:1527189165365};\\\", \\\"{x:1347,y:707,t:1527189165417};\\\", \\\"{x:1347,y:705,t:1527189165449};\\\", \\\"{x:1347,y:704,t:1527189165481};\\\", \\\"{x:1347,y:703,t:1527189165529};\\\", \\\"{x:1347,y:702,t:1527189165546};\\\", \\\"{x:1347,y:701,t:1527189165625};\\\", \\\"{x:1347,y:700,t:1527189165753};\\\", \\\"{x:1347,y:699,t:1527189165768};\\\", \\\"{x:1347,y:698,t:1527189165833};\\\", \\\"{x:1347,y:705,t:1527189168938};\\\", \\\"{x:1347,y:709,t:1527189168950};\\\", \\\"{x:1348,y:716,t:1527189168967};\\\", \\\"{x:1348,y:720,t:1527189168985};\\\", \\\"{x:1348,y:724,t:1527189169001};\\\", \\\"{x:1348,y:727,t:1527189169017};\\\", \\\"{x:1348,y:729,t:1527189169034};\\\", \\\"{x:1348,y:734,t:1527189169050};\\\", \\\"{x:1349,y:736,t:1527189169067};\\\", \\\"{x:1351,y:739,t:1527189169084};\\\", \\\"{x:1351,y:740,t:1527189169100};\\\", \\\"{x:1351,y:741,t:1527189169117};\\\", \\\"{x:1351,y:742,t:1527189169134};\\\", \\\"{x:1351,y:744,t:1527189169161};\\\", \\\"{x:1351,y:745,t:1527189169176};\\\", \\\"{x:1351,y:747,t:1527189169185};\\\", \\\"{x:1351,y:749,t:1527189169201};\\\", \\\"{x:1351,y:751,t:1527189169217};\\\", \\\"{x:1351,y:752,t:1527189169234};\\\", \\\"{x:1351,y:753,t:1527189169251};\\\", \\\"{x:1351,y:754,t:1527189169267};\\\", \\\"{x:1351,y:756,t:1527189169284};\\\", \\\"{x:1351,y:759,t:1527189169706};\\\", \\\"{x:1351,y:763,t:1527189169717};\\\", \\\"{x:1351,y:773,t:1527189169736};\\\", \\\"{x:1351,y:787,t:1527189169751};\\\", \\\"{x:1353,y:803,t:1527189169767};\\\", \\\"{x:1353,y:820,t:1527189169784};\\\", \\\"{x:1353,y:839,t:1527189169801};\\\", \\\"{x:1353,y:853,t:1527189169817};\\\", \\\"{x:1353,y:863,t:1527189169834};\\\", \\\"{x:1353,y:876,t:1527189169851};\\\", \\\"{x:1353,y:897,t:1527189169868};\\\", \\\"{x:1353,y:912,t:1527189169884};\\\", \\\"{x:1353,y:926,t:1527189169902};\\\", \\\"{x:1353,y:935,t:1527189169918};\\\", \\\"{x:1353,y:941,t:1527189169934};\\\", \\\"{x:1353,y:943,t:1527189169952};\\\", \\\"{x:1353,y:944,t:1527189169969};\\\", \\\"{x:1355,y:950,t:1527189169985};\\\", \\\"{x:1355,y:957,t:1527189170002};\\\", \\\"{x:1355,y:963,t:1527189170018};\\\", \\\"{x:1355,y:967,t:1527189170034};\\\", \\\"{x:1355,y:969,t:1527189170052};\\\", \\\"{x:1355,y:966,t:1527189170218};\\\", \\\"{x:1353,y:952,t:1527189170235};\\\", \\\"{x:1349,y:927,t:1527189170251};\\\", \\\"{x:1344,y:888,t:1527189170269};\\\", \\\"{x:1333,y:816,t:1527189170285};\\\", \\\"{x:1323,y:772,t:1527189170301};\\\", \\\"{x:1316,y:739,t:1527189170318};\\\", \\\"{x:1312,y:716,t:1527189170334};\\\", \\\"{x:1307,y:694,t:1527189170351};\\\", \\\"{x:1301,y:664,t:1527189170369};\\\", \\\"{x:1296,y:646,t:1527189170385};\\\", \\\"{x:1286,y:624,t:1527189170401};\\\", \\\"{x:1284,y:616,t:1527189170418};\\\", \\\"{x:1282,y:613,t:1527189170434};\\\", \\\"{x:1282,y:612,t:1527189170546};\\\", \\\"{x:1282,y:611,t:1527189170569};\\\", \\\"{x:1281,y:609,t:1527189170585};\\\", \\\"{x:1280,y:606,t:1527189170601};\\\", \\\"{x:1280,y:603,t:1527189170619};\\\", \\\"{x:1280,y:599,t:1527189170635};\\\", \\\"{x:1279,y:598,t:1527189170652};\\\", \\\"{x:1279,y:597,t:1527189170669};\\\", \\\"{x:1278,y:596,t:1527189170686};\\\", \\\"{x:1277,y:594,t:1527189170701};\\\", \\\"{x:1276,y:593,t:1527189170719};\\\", \\\"{x:1276,y:590,t:1527189170735};\\\", \\\"{x:1276,y:587,t:1527189170752};\\\", \\\"{x:1276,y:586,t:1527189170769};\\\", \\\"{x:1275,y:586,t:1527189170914};\\\", \\\"{x:1275,y:584,t:1527189172489};\\\", \\\"{x:1275,y:581,t:1527189172502};\\\", \\\"{x:1275,y:579,t:1527189172519};\\\", \\\"{x:1276,y:576,t:1527189172536};\\\", \\\"{x:1276,y:574,t:1527189172553};\\\", \\\"{x:1276,y:572,t:1527189172569};\\\", \\\"{x:1276,y:571,t:1527189172587};\\\", \\\"{x:1276,y:569,t:1527189172604};\\\", \\\"{x:1276,y:568,t:1527189172619};\\\", \\\"{x:1276,y:567,t:1527189173010};\\\", \\\"{x:1276,y:566,t:1527189173021};\\\", \\\"{x:1276,y:565,t:1527189173036};\\\", \\\"{x:1276,y:564,t:1527189173097};\\\", \\\"{x:1277,y:563,t:1527189173112};\\\", \\\"{x:1278,y:563,t:1527189173353};\\\", \\\"{x:1279,y:563,t:1527189173370};\\\", \\\"{x:1279,y:562,t:1527189173488};\\\", \\\"{x:1279,y:561,t:1527189173728};\\\", \\\"{x:1280,y:561,t:1527189173736};\\\", \\\"{x:1282,y:559,t:1527189173754};\\\", \\\"{x:1282,y:558,t:1527189173809};\\\", \\\"{x:1282,y:561,t:1527189174433};\\\", \\\"{x:1282,y:562,t:1527189174441};\\\", \\\"{x:1282,y:564,t:1527189174454};\\\", \\\"{x:1282,y:565,t:1527189174480};\\\", \\\"{x:1282,y:567,t:1527189174616};\\\", \\\"{x:1282,y:569,t:1527189174625};\\\", \\\"{x:1282,y:572,t:1527189174637};\\\", \\\"{x:1283,y:581,t:1527189174655};\\\", \\\"{x:1285,y:595,t:1527189174671};\\\", \\\"{x:1288,y:612,t:1527189174688};\\\", \\\"{x:1293,y:645,t:1527189174704};\\\", \\\"{x:1296,y:666,t:1527189174721};\\\", \\\"{x:1297,y:684,t:1527189174738};\\\", \\\"{x:1299,y:700,t:1527189174754};\\\", \\\"{x:1301,y:714,t:1527189174772};\\\", \\\"{x:1301,y:725,t:1527189174787};\\\", \\\"{x:1301,y:743,t:1527189174805};\\\", \\\"{x:1301,y:770,t:1527189174821};\\\", \\\"{x:1301,y:792,t:1527189174837};\\\", \\\"{x:1301,y:807,t:1527189174855};\\\", \\\"{x:1301,y:821,t:1527189174872};\\\", \\\"{x:1300,y:831,t:1527189174888};\\\", \\\"{x:1299,y:856,t:1527189174904};\\\", \\\"{x:1299,y:874,t:1527189174921};\\\", \\\"{x:1299,y:894,t:1527189174937};\\\", \\\"{x:1299,y:916,t:1527189174954};\\\", \\\"{x:1299,y:928,t:1527189174972};\\\", \\\"{x:1299,y:939,t:1527189174988};\\\", \\\"{x:1299,y:942,t:1527189175005};\\\", \\\"{x:1299,y:943,t:1527189175022};\\\", \\\"{x:1297,y:947,t:1527189175038};\\\", \\\"{x:1297,y:953,t:1527189175054};\\\", \\\"{x:1296,y:960,t:1527189175071};\\\", \\\"{x:1295,y:968,t:1527189175088};\\\", \\\"{x:1294,y:970,t:1527189175105};\\\", \\\"{x:1294,y:965,t:1527189175226};\\\", \\\"{x:1294,y:955,t:1527189175238};\\\", \\\"{x:1294,y:936,t:1527189175255};\\\", \\\"{x:1294,y:916,t:1527189175272};\\\", \\\"{x:1294,y:878,t:1527189175289};\\\", \\\"{x:1294,y:837,t:1527189175304};\\\", \\\"{x:1295,y:786,t:1527189175321};\\\", \\\"{x:1295,y:719,t:1527189175339};\\\", \\\"{x:1291,y:645,t:1527189175354};\\\", \\\"{x:1286,y:606,t:1527189175372};\\\", \\\"{x:1285,y:588,t:1527189175389};\\\", \\\"{x:1283,y:575,t:1527189175404};\\\", \\\"{x:1281,y:564,t:1527189175422};\\\", \\\"{x:1279,y:554,t:1527189175440};\\\", \\\"{x:1279,y:546,t:1527189175454};\\\", \\\"{x:1279,y:542,t:1527189175472};\\\", \\\"{x:1279,y:536,t:1527189175489};\\\", \\\"{x:1279,y:533,t:1527189175505};\\\", \\\"{x:1279,y:532,t:1527189175522};\\\", \\\"{x:1279,y:531,t:1527189175539};\\\", \\\"{x:1279,y:536,t:1527189175633};\\\", \\\"{x:1279,y:549,t:1527189175640};\\\", \\\"{x:1279,y:564,t:1527189175656};\\\", \\\"{x:1279,y:604,t:1527189175672};\\\", \\\"{x:1281,y:664,t:1527189175689};\\\", \\\"{x:1281,y:714,t:1527189175705};\\\", \\\"{x:1281,y:767,t:1527189175722};\\\", \\\"{x:1281,y:807,t:1527189175738};\\\", \\\"{x:1281,y:835,t:1527189175756};\\\", \\\"{x:1281,y:864,t:1527189175771};\\\", \\\"{x:1282,y:888,t:1527189175789};\\\", \\\"{x:1283,y:902,t:1527189175806};\\\", \\\"{x:1283,y:909,t:1527189175822};\\\", \\\"{x:1283,y:912,t:1527189175838};\\\", \\\"{x:1285,y:914,t:1527189175855};\\\", \\\"{x:1287,y:919,t:1527189175872};\\\", \\\"{x:1292,y:925,t:1527189175888};\\\", \\\"{x:1297,y:925,t:1527189175904};\\\", \\\"{x:1297,y:931,t:1527189177841};\\\", \\\"{x:1294,y:944,t:1527189177856};\\\", \\\"{x:1292,y:951,t:1527189177873};\\\", \\\"{x:1290,y:957,t:1527189177889};\\\", \\\"{x:1288,y:961,t:1527189177907};\\\", \\\"{x:1287,y:963,t:1527189177923};\\\", \\\"{x:1286,y:967,t:1527189177939};\\\", \\\"{x:1284,y:972,t:1527189177957};\\\", \\\"{x:1283,y:974,t:1527189177973};\\\", \\\"{x:1282,y:975,t:1527189177989};\\\", \\\"{x:1281,y:977,t:1527189178006};\\\", \\\"{x:1280,y:978,t:1527189178023};\\\", \\\"{x:1279,y:980,t:1527189178040};\\\", \\\"{x:1276,y:983,t:1527189178056};\\\", \\\"{x:1274,y:984,t:1527189178074};\\\", \\\"{x:1268,y:985,t:1527189178090};\\\", \\\"{x:1261,y:985,t:1527189178107};\\\", \\\"{x:1248,y:985,t:1527189178124};\\\", \\\"{x:1224,y:983,t:1527189178140};\\\", \\\"{x:1183,y:971,t:1527189178157};\\\", \\\"{x:1113,y:948,t:1527189178174};\\\", \\\"{x:1038,y:912,t:1527189178191};\\\", \\\"{x:982,y:885,t:1527189178206};\\\", \\\"{x:961,y:872,t:1527189178223};\\\", \\\"{x:945,y:856,t:1527189178240};\\\", \\\"{x:941,y:849,t:1527189178256};\\\", \\\"{x:934,y:835,t:1527189178273};\\\", \\\"{x:924,y:812,t:1527189178290};\\\", \\\"{x:919,y:794,t:1527189178307};\\\", \\\"{x:918,y:780,t:1527189178324};\\\", \\\"{x:917,y:772,t:1527189178341};\\\", \\\"{x:916,y:768,t:1527189178356};\\\", \\\"{x:916,y:763,t:1527189178374};\\\", \\\"{x:916,y:757,t:1527189178391};\\\", \\\"{x:919,y:748,t:1527189178406};\\\", \\\"{x:920,y:746,t:1527189178423};\\\", \\\"{x:920,y:744,t:1527189178440};\\\", \\\"{x:920,y:742,t:1527189178736};\\\", \\\"{x:917,y:735,t:1527189178745};\\\", \\\"{x:913,y:729,t:1527189178758};\\\", \\\"{x:900,y:715,t:1527189178773};\\\", \\\"{x:883,y:703,t:1527189178790};\\\", \\\"{x:870,y:692,t:1527189178808};\\\", \\\"{x:850,y:680,t:1527189178823};\\\", \\\"{x:799,y:645,t:1527189178841};\\\", \\\"{x:766,y:625,t:1527189178857};\\\", \\\"{x:745,y:612,t:1527189178873};\\\", \\\"{x:737,y:608,t:1527189178891};\\\", \\\"{x:729,y:602,t:1527189178908};\\\", \\\"{x:723,y:597,t:1527189178925};\\\", \\\"{x:704,y:585,t:1527189178945};\\\", \\\"{x:689,y:577,t:1527189178961};\\\", \\\"{x:670,y:568,t:1527189178978};\\\", \\\"{x:653,y:560,t:1527189178994};\\\", \\\"{x:646,y:558,t:1527189179011};\\\", \\\"{x:643,y:558,t:1527189179072};\\\", \\\"{x:639,y:555,t:1527189179080};\\\", \\\"{x:634,y:554,t:1527189179096};\\\", \\\"{x:632,y:552,t:1527189179111};\\\", \\\"{x:629,y:546,t:1527189179128};\\\", \\\"{x:629,y:535,t:1527189179146};\\\", \\\"{x:629,y:527,t:1527189179162};\\\", \\\"{x:629,y:522,t:1527189179178};\\\", \\\"{x:629,y:519,t:1527189179196};\\\", \\\"{x:630,y:518,t:1527189179211};\\\", \\\"{x:622,y:542,t:1527189179674};\\\", \\\"{x:611,y:581,t:1527189179680};\\\", \\\"{x:603,y:619,t:1527189179695};\\\", \\\"{x:575,y:686,t:1527189179712};\\\", \\\"{x:573,y:693,t:1527189179728};\\\", \\\"{x:570,y:698,t:1527189179745};\\\", \\\"{x:567,y:703,t:1527189179762};\\\", \\\"{x:565,y:705,t:1527189179778};\\\", \\\"{x:562,y:708,t:1527189179796};\\\", \\\"{x:560,y:710,t:1527189179812};\\\", \\\"{x:559,y:711,t:1527189179828};\\\", \\\"{x:555,y:714,t:1527189179845};\\\", \\\"{x:548,y:721,t:1527189179862};\\\", \\\"{x:538,y:730,t:1527189179879};\\\", \\\"{x:524,y:739,t:1527189179896};\\\", \\\"{x:520,y:742,t:1527189179912};\\\", \\\"{x:519,y:743,t:1527189179930};\\\", \\\"{x:520,y:745,t:1527189180416};\\\", \\\"{x:526,y:750,t:1527189180429};\\\", \\\"{x:528,y:755,t:1527189180447};\\\", \\\"{x:529,y:755,t:1527189180616};\\\" ] }, { \\\"rt\\\": 61038, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 627701, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Shifts F and B start. Shift J ends, Shift I and J ends. Shift E is still going on.\\\\n\\\\nLook to the left of 12 to see what shifts are still occurring/ending, and also look at 12 to see what shifts are starting. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5001, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 633710, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7788, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 642509, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3928, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 647776, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"3Z8ZL\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"3Z8ZL\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 256, dom: 775, initialDom: 826",
  "javascriptErrors": []
}