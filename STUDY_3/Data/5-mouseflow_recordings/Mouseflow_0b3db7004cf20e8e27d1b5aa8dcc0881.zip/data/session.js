var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0b3db7004cf20e8e27d1b5aa8dcc0881",
  "created": "2018-05-25T11:12:34.8216094-07:00",
  "lastActivity": "2018-05-25T11:13:02.7083462-07:00",
  "pageViews": [
    {
      "id": "052534212945c512fb7b6c6633557df0424eb4bd",
      "startTime": "2018-05-25T11:12:34.8727109-07:00",
      "endTime": "2018-05-25T11:13:02.7083462-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 27884,
      "engagementTime": 27881,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27884,
  "engagementTime": 27881,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DFQLY",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "387bdab6893196973858e83b8d134e3e",
  "gdpr": false
}