var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6f5c8d4c05b234a87d2cbe0f627deb99",
  "created": "2018-05-29T16:16:29.8100181-07:00",
  "lastActivity": "2018-05-29T16:19:57.7150181-07:00",
  "pageViews": [
    {
      "id": "0529306293fbf0ca373114da88c4bafbd9c16e42",
      "startTime": "2018-05-29T16:16:29.8100181-07:00",
      "endTime": "2018-05-29T16:19:57.7150181-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 207905,
      "engagementTime": 199453,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 207905,
  "engagementTime": 199453,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=0CR6Z",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "544f0faa18874c3ab5c83c3b436d427f",
  "gdpr": false
}