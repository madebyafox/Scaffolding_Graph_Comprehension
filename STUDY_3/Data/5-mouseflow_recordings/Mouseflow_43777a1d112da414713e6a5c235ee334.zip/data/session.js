var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "43777a1d112da414713e6a5c235ee334",
  "created": "2018-06-01T11:10:02.7884334-07:00",
  "lastActivity": "2018-06-01T11:11:29.9725074-07:00",
  "pageViews": [
    {
      "id": "060102045773be1ce36947030b292efd70f6649d",
      "startTime": "2018-06-01T11:10:02.7884334-07:00",
      "endTime": "2018-06-01T11:11:29.9725074-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 87386,
      "engagementTime": 71530,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 87386,
  "engagementTime": 71530,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d0cd4b4b663a5dc6b02d6a6b96a5f72c",
  "gdpr": false
}