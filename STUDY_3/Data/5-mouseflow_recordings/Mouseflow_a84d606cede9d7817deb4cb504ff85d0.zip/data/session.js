var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a84d606cede9d7817deb4cb504ff85d0",
  "created": "2018-06-01T09:11:47.1209823-07:00",
  "lastActivity": "2018-06-01T09:12:09.0159823-07:00",
  "pageViews": [
    {
      "id": "06014718833f99569c4dee518758fec9cdc9680c",
      "startTime": "2018-06-01T09:11:47.1209823-07:00",
      "endTime": "2018-06-01T09:12:09.0159823-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 21895,
      "engagementTime": 9138,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 21895,
  "engagementTime": 9138,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DZD6F",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f790b14548116ad1c34b15950c1542ae",
  "gdpr": false
}