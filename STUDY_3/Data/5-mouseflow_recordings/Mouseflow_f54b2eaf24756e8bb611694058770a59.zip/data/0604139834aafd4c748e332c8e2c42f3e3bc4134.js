var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0604139834aafd4c748e332c8e2c42f3e3bc4134"] = {
  "startTime": "2018-06-04T19:17:12.9420868Z",
  "websitePageUrl": "/16",
  "visitTime": 36975,
  "engagementTime": 36725,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f54b2eaf24756e8bb611694058770a59",
    "created": "2018-06-04T19:17:12.9420868+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=9TE89",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "379237d619eb19139967188e862919f7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f54b2eaf24756e8bb611694058770a59/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 197,
      "e": 197,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 197,
      "e": 197,
      "ty": 2,
      "x": 586,
      "y": 609
    },
    {
      "t": 197,
      "e": 197,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 54845,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 582,
      "y": 615
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 564,
      "y": 638
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 531,
      "y": 675
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 48775,
      "y": 36949,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 647,
      "e": 647,
      "ty": 2,
      "x": 494,
      "y": 708
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 488,
      "y": 709
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 43492,
      "y": 38778,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 481,
      "y": 705
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 489,
      "y": 668
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 548,
      "y": 614
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 50686,
      "y": 62026,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 550,
      "y": 612
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 568,
      "y": 605
    },
    {
      "t": 1215,
      "e": 1215,
      "ty": 6,
      "x": 576,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 56082,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 603,
      "y": 590
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 56868,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3793,
      "e": 3793,
      "ty": 3,
      "x": 603,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3795,
      "e": 3795,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3943,
      "e": 3943,
      "ty": 4,
      "x": 56868,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3943,
      "e": 3943,
      "ty": 5,
      "x": 603,
      "y": 590,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4675,
      "e": 4675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 4676,
      "e": 4676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4786,
      "e": 4786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 4843,
      "e": 4843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 4843,
      "e": 4843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4931,
      "e": 4931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FO"
    },
    {
      "t": 5067,
      "e": 5067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5068,
      "e": 5068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5138,
      "e": 5138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FOL"
    },
    {
      "t": 5235,
      "e": 5235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5235,
      "e": 5235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5283,
      "e": 5283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FOLL"
    },
    {
      "t": 5371,
      "e": 5371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 5372,
      "e": 5372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5450,
      "e": 5450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 5451,
      "e": 5451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5457,
      "e": 5457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||OW"
    },
    {
      "t": 5547,
      "e": 5547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5547,
      "e": 5547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5563,
      "e": 5563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 5778,
      "e": 5778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 5787,
      "e": 5787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5787,
      "e": 5787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5930,
      "e": 5930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 5931,
      "e": 5931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5946,
      "e": 5946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||LI"
    },
    {
      "t": 6082,
      "e": 6082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 6083,
      "e": 6083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6122,
      "e": 6122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 6155,
      "e": 6155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 6156,
      "e": 6156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6226,
      "e": 6226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 6258,
      "e": 6258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7147,
      "e": 7147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7283,
      "e": 7283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FOLLOW LIN"
    },
    {
      "t": 7379,
      "e": 7379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7380,
      "e": 7380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7523,
      "e": 7523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 7563,
      "e": 7563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 7659,
      "e": 7659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7715,
      "e": 7715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 7716,
      "e": 7716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7810,
      "e": 7810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 8487,
      "e": 8487,
      "ty": 7,
      "x": 542,
      "y": 478,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 2,
      "x": 542,
      "y": 478
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 50011,
      "y": 340,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 8587,
      "e": 8587,
      "ty": 6,
      "x": 386,
      "y": 539,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 386,
      "y": 539
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 356,
      "y": 573
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 29440,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8802,
      "e": 8802,
      "ty": 2,
      "x": 365,
      "y": 591
    },
    {
      "t": 8821,
      "e": 8821,
      "ty": 7,
      "x": 380,
      "y": 620,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8855,
      "e": 8855,
      "ty": 6,
      "x": 388,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 8887,
      "e": 8887,
      "ty": 7,
      "x": 389,
      "y": 699,
      "ta": "#strategyButton"
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 389,
      "y": 699
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 2,
      "x": 390,
      "y": 710
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 33425,
      "y": 57844,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 9102,
      "e": 9102,
      "ty": 2,
      "x": 390,
      "y": 690
    },
    {
      "t": 9105,
      "e": 9105,
      "ty": 6,
      "x": 392,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 393,
      "y": 679
    },
    {
      "t": 9252,
      "e": 9252,
      "ty": 41,
      "x": 29712,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 9327,
      "e": 9327,
      "ty": 3,
      "x": 393,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 9328,
      "e": 9328,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FOLLOW LINE\n"
    },
    {
      "t": 9328,
      "e": 9328,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9328,
      "e": 9328,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 9414,
      "e": 9414,
      "ty": 4,
      "x": 29712,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 9423,
      "e": 9423,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 9424,
      "e": 9424,
      "ty": 5,
      "x": 393,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 9431,
      "e": 9431,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 9602,
      "e": 9602,
      "ty": 2,
      "x": 366,
      "y": 666
    },
    {
      "t": 9702,
      "e": 9702,
      "ty": 2,
      "x": 357,
      "y": 658
    },
    {
      "t": 9752,
      "e": 9752,
      "ty": 41,
      "x": 12018,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 9802,
      "e": 9802,
      "ty": 2,
      "x": 356,
      "y": 658
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 41,
      "x": 11984,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 10202,
      "e": 10202,
      "ty": 2,
      "x": 355,
      "y": 658
    },
    {
      "t": 10252,
      "e": 10252,
      "ty": 41,
      "x": 11949,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 2,
      "x": 354,
      "y": 657
    },
    {
      "t": 10401,
      "e": 10401,
      "ty": 2,
      "x": 351,
      "y": 657
    },
    {
      "t": 10429,
      "e": 10429,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 2,
      "x": 350,
      "y": 657
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 11777,
      "y": 35952,
      "ta": "html > body"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 2,
      "x": 349,
      "y": 657
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 11743,
      "y": 35952,
      "ta": "html > body"
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 2,
      "x": 349,
      "y": 656
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 41,
      "x": 11743,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 2,
      "x": 405,
      "y": 634
    },
    {
      "t": 11201,
      "e": 11201,
      "ty": 2,
      "x": 589,
      "y": 612
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 22625,
      "y": 33459,
      "ta": "html > body"
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 2,
      "x": 728,
      "y": 609
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 780,
      "y": 591
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 798,
      "y": 580
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 41,
      "x": 27205,
      "y": 31687,
      "ta": "html > body"
    },
    {
      "t": 11574,
      "e": 11574,
      "ty": 6,
      "x": 811,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11601,
      "e": 11601,
      "ty": 2,
      "x": 815,
      "y": 569
    },
    {
      "t": 11701,
      "e": 11701,
      "ty": 2,
      "x": 842,
      "y": 555
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 7353,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 2,
      "x": 845,
      "y": 563
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 41,
      "x": 8002,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12101,
      "e": 12101,
      "ty": 2,
      "x": 846,
      "y": 564
    },
    {
      "t": 12127,
      "e": 12127,
      "ty": 3,
      "x": 846,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12128,
      "e": 12128,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 41,
      "x": 8218,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12263,
      "e": 12263,
      "ty": 4,
      "x": 8218,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12263,
      "e": 12263,
      "ty": 5,
      "x": 846,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12499,
      "e": 12499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 12499,
      "e": 12499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12602,
      "e": 12602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 12658,
      "e": 12658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 12659,
      "e": 12659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12667,
      "e": 12667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 846,
      "y": 571
    },
    {
      "t": 12724,
      "e": 12724,
      "ty": 7,
      "x": 850,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 10598,
      "y": 9865,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 12786,
      "e": 12786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 12800,
      "e": 12800,
      "ty": 2,
      "x": 863,
      "y": 610
    },
    {
      "t": 12901,
      "e": 12901,
      "ty": 2,
      "x": 871,
      "y": 646
    },
    {
      "t": 12908,
      "e": 12908,
      "ty": 6,
      "x": 871,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 2,
      "x": 871,
      "y": 649
    },
    {
      "t": 13001,
      "e": 13001,
      "ty": 41,
      "x": 13626,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13191,
      "e": 13191,
      "ty": 3,
      "x": 871,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13193,
      "e": 13193,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 13193,
      "e": 13193,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 13194,
      "e": 13194,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13295,
      "e": 13295,
      "ty": 4,
      "x": 13626,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13295,
      "e": 13295,
      "ty": 5,
      "x": 871,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 14196,
      "e": 14196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 14307,
      "e": 14307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 14339,
      "e": 14339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 14339,
      "e": 14339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 14442,
      "e": 14442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 14571,
      "e": 14571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 14571,
      "e": 14571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 14675,
      "e": 14675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 14676,
      "e": 14676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 14682,
      "e": 14682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 14779,
      "e": 14779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 15427,
      "e": 15427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 15547,
      "e": 15547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 15860,
      "e": 15860,
      "ty": 7,
      "x": 879,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 15901,
      "e": 15901,
      "ty": 2,
      "x": 894,
      "y": 713
    },
    {
      "t": 16001,
      "e": 16001,
      "ty": 2,
      "x": 898,
      "y": 732
    },
    {
      "t": 16002,
      "e": 16002,
      "ty": 41,
      "x": 30649,
      "y": 40107,
      "ta": "html > body"
    },
    {
      "t": 16101,
      "e": 16101,
      "ty": 2,
      "x": 898,
      "y": 730
    },
    {
      "t": 16201,
      "e": 16201,
      "ty": 2,
      "x": 922,
      "y": 715
    },
    {
      "t": 16252,
      "e": 16252,
      "ty": 41,
      "x": 31579,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 16263,
      "e": 16263,
      "ty": 6,
      "x": 926,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16301,
      "e": 16301,
      "ty": 2,
      "x": 926,
      "y": 703
    },
    {
      "t": 16401,
      "e": 16401,
      "ty": 2,
      "x": 927,
      "y": 693
    },
    {
      "t": 16439,
      "e": 16439,
      "ty": 3,
      "x": 927,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16441,
      "e": 16441,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 16441,
      "e": 16441,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16441,
      "e": 16441,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16501,
      "e": 16501,
      "ty": 41,
      "x": 16017,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16526,
      "e": 16526,
      "ty": 4,
      "x": 16017,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16527,
      "e": 16527,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16527,
      "e": 16527,
      "ty": 5,
      "x": 927,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16528,
      "e": 16528,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 17001,
      "e": 17001,
      "ty": 2,
      "x": 916,
      "y": 692
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 41,
      "x": 31269,
      "y": 37891,
      "ta": "html > body"
    },
    {
      "t": 17101,
      "e": 17101,
      "ty": 2,
      "x": 819,
      "y": 679
    },
    {
      "t": 17201,
      "e": 17201,
      "ty": 2,
      "x": 703,
      "y": 664
    },
    {
      "t": 17251,
      "e": 17251,
      "ty": 41,
      "x": 21867,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 17301,
      "e": 17301,
      "ty": 2,
      "x": 567,
      "y": 663
    },
    {
      "t": 17401,
      "e": 17401,
      "ty": 2,
      "x": 411,
      "y": 663
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 2,
      "x": 343,
      "y": 663
    },
    {
      "t": 17502,
      "e": 17502,
      "ty": 41,
      "x": 11536,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 17550,
      "e": 17550,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 17601,
      "e": 17601,
      "ty": 2,
      "x": 343,
      "y": 660
    },
    {
      "t": 17702,
      "e": 17702,
      "ty": 2,
      "x": 391,
      "y": 632
    },
    {
      "t": 17751,
      "e": 17751,
      "ty": 41,
      "x": 13775,
      "y": 34124,
      "ta": "html > body"
    },
    {
      "t": 17801,
      "e": 17801,
      "ty": 2,
      "x": 428,
      "y": 614
    },
    {
      "t": 17901,
      "e": 17901,
      "ty": 2,
      "x": 501,
      "y": 577
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 2,
      "x": 721,
      "y": 524
    },
    {
      "t": 18002,
      "e": 18002,
      "ty": 41,
      "x": 24554,
      "y": 28585,
      "ta": "html > body"
    },
    {
      "t": 18101,
      "e": 18101,
      "ty": 2,
      "x": 874,
      "y": 180
    },
    {
      "t": 18205,
      "e": 18205,
      "ty": 2,
      "x": 934,
      "y": 16
    },
    {
      "t": 18255,
      "e": 18255,
      "ty": 41,
      "x": 31889,
      "y": 941,
      "ta": "html > body"
    },
    {
      "t": 18305,
      "e": 18305,
      "ty": 2,
      "x": 928,
      "y": 79
    },
    {
      "t": 18405,
      "e": 18405,
      "ty": 2,
      "x": 916,
      "y": 137
    },
    {
      "t": 18505,
      "e": 18505,
      "ty": 41,
      "x": 31269,
      "y": 7146,
      "ta": "html > body"
    },
    {
      "t": 18605,
      "e": 18605,
      "ty": 2,
      "x": 825,
      "y": 264
    },
    {
      "t": 18705,
      "e": 18705,
      "ty": 2,
      "x": 744,
      "y": 376
    },
    {
      "t": 18755,
      "e": 18755,
      "ty": 41,
      "x": 25724,
      "y": 19943,
      "ta": "html > body"
    },
    {
      "t": 18805,
      "e": 18805,
      "ty": 2,
      "x": 787,
      "y": 314
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 6,
      "x": 827,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 18905,
      "e": 18905,
      "ty": 2,
      "x": 828,
      "y": 236
    },
    {
      "t": 19006,
      "e": 19006,
      "ty": 41,
      "x": 7955,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 19105,
      "e": 19105,
      "ty": 2,
      "x": 831,
      "y": 239
    },
    {
      "t": 19255,
      "e": 19255,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 19282,
      "e": 19282,
      "ty": 7,
      "x": 837,
      "y": 253,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 19305,
      "e": 19305,
      "ty": 2,
      "x": 841,
      "y": 259
    },
    {
      "t": 19405,
      "e": 19405,
      "ty": 2,
      "x": 841,
      "y": 263
    },
    {
      "t": 19505,
      "e": 19405,
      "ty": 41,
      "x": 14911,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 19586,
      "e": 19486,
      "ty": 6,
      "x": 839,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 19605,
      "e": 19505,
      "ty": 2,
      "x": 838,
      "y": 265
    },
    {
      "t": 19705,
      "e": 19605,
      "ty": 2,
      "x": 833,
      "y": 268
    },
    {
      "t": 19755,
      "e": 19655,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20001,
      "e": 19901,
      "ty": 3,
      "x": 832,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20002,
      "e": 19902,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20005,
      "e": 19905,
      "ty": 2,
      "x": 832,
      "y": 269
    },
    {
      "t": 20005,
      "e": 19905,
      "ty": 41,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20114,
      "e": 20014,
      "ty": 4,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20114,
      "e": 20014,
      "ty": 5,
      "x": 832,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20114,
      "e": 20014,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 20364,
      "e": 20264,
      "ty": 7,
      "x": 832,
      "y": 280,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 20405,
      "e": 20305,
      "ty": 2,
      "x": 832,
      "y": 340
    },
    {
      "t": 20504,
      "e": 20404,
      "ty": 2,
      "x": 828,
      "y": 380
    },
    {
      "t": 20505,
      "e": 20405,
      "ty": 41,
      "x": 1561,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 20805,
      "e": 20705,
      "ty": 2,
      "x": 828,
      "y": 387
    },
    {
      "t": 20905,
      "e": 20805,
      "ty": 2,
      "x": 832,
      "y": 384
    },
    {
      "t": 20951,
      "e": 20851,
      "ty": 6,
      "x": 832,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 20968,
      "e": 20868,
      "ty": 7,
      "x": 833,
      "y": 307,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 20985,
      "e": 20885,
      "ty": 6,
      "x": 833,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 21005,
      "e": 20905,
      "ty": 2,
      "x": 833,
      "y": 299
    },
    {
      "t": 21005,
      "e": 20905,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 21105,
      "e": 21005,
      "ty": 2,
      "x": 833,
      "y": 297
    },
    {
      "t": 21171,
      "e": 21071,
      "ty": 7,
      "x": 835,
      "y": 305,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 21185,
      "e": 21085,
      "ty": 6,
      "x": 839,
      "y": 316,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 21201,
      "e": 21101,
      "ty": 7,
      "x": 848,
      "y": 352,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 21204,
      "e": 21104,
      "ty": 2,
      "x": 848,
      "y": 352
    },
    {
      "t": 21255,
      "e": 21155,
      "ty": 41,
      "x": 34808,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 21305,
      "e": 21205,
      "ty": 2,
      "x": 869,
      "y": 472
    },
    {
      "t": 21505,
      "e": 21405,
      "ty": 2,
      "x": 858,
      "y": 417
    },
    {
      "t": 21505,
      "e": 21405,
      "ty": 41,
      "x": 42818,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 22005,
      "e": 21905,
      "ty": 2,
      "x": 927,
      "y": 453
    },
    {
      "t": 22005,
      "e": 21905,
      "ty": 41,
      "x": 25056,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 22105,
      "e": 22005,
      "ty": 2,
      "x": 962,
      "y": 506
    },
    {
      "t": 22205,
      "e": 22105,
      "ty": 2,
      "x": 931,
      "y": 499
    },
    {
      "t": 22255,
      "e": 22155,
      "ty": 41,
      "x": 24107,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 22305,
      "e": 22205,
      "ty": 2,
      "x": 909,
      "y": 462
    },
    {
      "t": 22405,
      "e": 22305,
      "ty": 2,
      "x": 869,
      "y": 465
    },
    {
      "t": 22505,
      "e": 22405,
      "ty": 2,
      "x": 814,
      "y": 492
    },
    {
      "t": 22505,
      "e": 22405,
      "ty": 41,
      "x": 27756,
      "y": 26812,
      "ta": "html > body"
    },
    {
      "t": 22605,
      "e": 22505,
      "ty": 2,
      "x": 814,
      "y": 493
    },
    {
      "t": 22705,
      "e": 22605,
      "ty": 2,
      "x": 828,
      "y": 480
    },
    {
      "t": 22755,
      "e": 22655,
      "ty": 41,
      "x": 8010,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 22806,
      "e": 22656,
      "ty": 2,
      "x": 830,
      "y": 478
    },
    {
      "t": 22883,
      "e": 22733,
      "ty": 6,
      "x": 830,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 22905,
      "e": 22755,
      "ty": 2,
      "x": 830,
      "y": 474
    },
    {
      "t": 23005,
      "e": 22855,
      "ty": 2,
      "x": 830,
      "y": 468
    },
    {
      "t": 23005,
      "e": 22855,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23043,
      "e": 22893,
      "ty": 3,
      "x": 830,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23045,
      "e": 22895,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 23045,
      "e": 22895,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23202,
      "e": 23052,
      "ty": 4,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23202,
      "e": 23052,
      "ty": 5,
      "x": 830,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23203,
      "e": 23053,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 23405,
      "e": 23255,
      "ty": 2,
      "x": 831,
      "y": 469
    },
    {
      "t": 23470,
      "e": 23320,
      "ty": 7,
      "x": 837,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 23505,
      "e": 23355,
      "ty": 2,
      "x": 841,
      "y": 485
    },
    {
      "t": 23505,
      "e": 23355,
      "ty": 41,
      "x": 4646,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 23605,
      "e": 23455,
      "ty": 2,
      "x": 843,
      "y": 497
    },
    {
      "t": 23705,
      "e": 23555,
      "ty": 2,
      "x": 843,
      "y": 509
    },
    {
      "t": 23754,
      "e": 23604,
      "ty": 41,
      "x": 25252,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 23806,
      "e": 23656,
      "ty": 2,
      "x": 843,
      "y": 525
    },
    {
      "t": 23905,
      "e": 23755,
      "ty": 2,
      "x": 843,
      "y": 526
    },
    {
      "t": 24006,
      "e": 23856,
      "ty": 2,
      "x": 843,
      "y": 528
    },
    {
      "t": 24006,
      "e": 23856,
      "ty": 41,
      "x": 25252,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 24106,
      "e": 23956,
      "ty": 2,
      "x": 844,
      "y": 534
    },
    {
      "t": 24205,
      "e": 24055,
      "ty": 2,
      "x": 844,
      "y": 634
    },
    {
      "t": 24255,
      "e": 24105,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 24305,
      "e": 24155,
      "ty": 2,
      "x": 845,
      "y": 761
    },
    {
      "t": 24404,
      "e": 24254,
      "ty": 2,
      "x": 845,
      "y": 797
    },
    {
      "t": 24505,
      "e": 24355,
      "ty": 2,
      "x": 846,
      "y": 839
    },
    {
      "t": 24505,
      "e": 24355,
      "ty": 41,
      "x": 17316,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 24606,
      "e": 24456,
      "ty": 2,
      "x": 846,
      "y": 851
    },
    {
      "t": 24756,
      "e": 24606,
      "ty": 41,
      "x": 17316,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 24906,
      "e": 24756,
      "ty": 2,
      "x": 849,
      "y": 840
    },
    {
      "t": 25005,
      "e": 24855,
      "ty": 2,
      "x": 849,
      "y": 823
    },
    {
      "t": 25005,
      "e": 24855,
      "ty": 41,
      "x": 16277,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 25104,
      "e": 24954,
      "ty": 2,
      "x": 849,
      "y": 798
    },
    {
      "t": 25205,
      "e": 25055,
      "ty": 2,
      "x": 840,
      "y": 750
    },
    {
      "t": 25256,
      "e": 25106,
      "ty": 41,
      "x": 397,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 25306,
      "e": 25156,
      "ty": 2,
      "x": 812,
      "y": 681
    },
    {
      "t": 25405,
      "e": 25255,
      "ty": 2,
      "x": 806,
      "y": 669
    },
    {
      "t": 25506,
      "e": 25356,
      "ty": 41,
      "x": 27481,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 25756,
      "e": 25606,
      "ty": 41,
      "x": 27481,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 25805,
      "e": 25655,
      "ty": 2,
      "x": 806,
      "y": 668
    },
    {
      "t": 26205,
      "e": 26055,
      "ty": 2,
      "x": 812,
      "y": 668
    },
    {
      "t": 26255,
      "e": 26105,
      "ty": 41,
      "x": 27963,
      "y": 36839,
      "ta": "html > body"
    },
    {
      "t": 26305,
      "e": 26155,
      "ty": 2,
      "x": 826,
      "y": 682
    },
    {
      "t": 26372,
      "e": 26222,
      "ty": 6,
      "x": 833,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 26405,
      "e": 26255,
      "ty": 2,
      "x": 833,
      "y": 699
    },
    {
      "t": 26506,
      "e": 26356,
      "ty": 2,
      "x": 837,
      "y": 707
    },
    {
      "t": 26506,
      "e": 26356,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 26605,
      "e": 26455,
      "ty": 2,
      "x": 839,
      "y": 708
    },
    {
      "t": 26756,
      "e": 26606,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 27005,
      "e": 26855,
      "ty": 2,
      "x": 837,
      "y": 708
    },
    {
      "t": 27006,
      "e": 26856,
      "ty": 41,
      "x": 53325,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 27206,
      "e": 27056,
      "ty": 2,
      "x": 836,
      "y": 707
    },
    {
      "t": 27256,
      "e": 27106,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 27305,
      "e": 27155,
      "ty": 2,
      "x": 834,
      "y": 698
    },
    {
      "t": 27306,
      "e": 27156,
      "ty": 7,
      "x": 833,
      "y": 693,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 27405,
      "e": 27255,
      "ty": 2,
      "x": 833,
      "y": 692
    },
    {
      "t": 27505,
      "e": 27355,
      "ty": 41,
      "x": 2747,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 28091,
      "e": 27941,
      "ty": 6,
      "x": 830,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 28106,
      "e": 27956,
      "ty": 2,
      "x": 830,
      "y": 696
    },
    {
      "t": 28205,
      "e": 28055,
      "ty": 2,
      "x": 830,
      "y": 701
    },
    {
      "t": 28255,
      "e": 28105,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 28306,
      "e": 28156,
      "ty": 2,
      "x": 830,
      "y": 704
    },
    {
      "t": 28505,
      "e": 28355,
      "ty": 41,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 29164,
      "e": 29014,
      "ty": 3,
      "x": 830,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 29165,
      "e": 29015,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 29167,
      "e": 29018,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 29338,
      "e": 29189,
      "ty": 4,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 29338,
      "e": 29189,
      "ty": 5,
      "x": 830,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 29338,
      "e": 29189,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 30491,
      "e": 30342,
      "ty": 7,
      "x": 840,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 30505,
      "e": 30356,
      "ty": 2,
      "x": 840,
      "y": 712
    },
    {
      "t": 30505,
      "e": 30356,
      "ty": 41,
      "x": 4681,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 30605,
      "e": 30456,
      "ty": 2,
      "x": 851,
      "y": 798
    },
    {
      "t": 30705,
      "e": 30556,
      "ty": 2,
      "x": 840,
      "y": 911
    },
    {
      "t": 30755,
      "e": 30606,
      "ty": 41,
      "x": 4171,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 30805,
      "e": 30656,
      "ty": 2,
      "x": 839,
      "y": 922
    },
    {
      "t": 30959,
      "e": 30810,
      "ty": 6,
      "x": 839,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 31006,
      "e": 30857,
      "ty": 2,
      "x": 839,
      "y": 929
    },
    {
      "t": 31006,
      "e": 30857,
      "ty": 41,
      "x": 63408,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 31105,
      "e": 30956,
      "ty": 2,
      "x": 839,
      "y": 931
    },
    {
      "t": 31142,
      "e": 30993,
      "ty": 7,
      "x": 830,
      "y": 947,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 31158,
      "e": 31009,
      "ty": 6,
      "x": 826,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 31176,
      "e": 31027,
      "ty": 7,
      "x": 825,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 31205,
      "e": 31056,
      "ty": 2,
      "x": 825,
      "y": 962
    },
    {
      "t": 31256,
      "e": 31107,
      "ty": 41,
      "x": 2894,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 31419,
      "e": 31270,
      "ty": 3,
      "x": 825,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 31420,
      "e": 31271,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 31539,
      "e": 31390,
      "ty": 4,
      "x": 2894,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 31539,
      "e": 31390,
      "ty": 5,
      "x": 825,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 31539,
      "e": 31390,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 31541,
      "e": 31392,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 31643,
      "e": 31494,
      "ty": 6,
      "x": 828,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 31660,
      "e": 31511,
      "ty": 7,
      "x": 832,
      "y": 974,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 31705,
      "e": 31556,
      "ty": 2,
      "x": 835,
      "y": 979
    },
    {
      "t": 31755,
      "e": 31606,
      "ty": 41,
      "x": 21421,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 31804,
      "e": 31655,
      "ty": 2,
      "x": 849,
      "y": 998
    },
    {
      "t": 31860,
      "e": 31711,
      "ty": 6,
      "x": 855,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 31904,
      "e": 31755,
      "ty": 2,
      "x": 856,
      "y": 1008
    },
    {
      "t": 32005,
      "e": 31856,
      "ty": 2,
      "x": 857,
      "y": 1015
    },
    {
      "t": 32005,
      "e": 31856,
      "ty": 41,
      "x": 14213,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32100,
      "e": 31951,
      "ty": 3,
      "x": 858,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32100,
      "e": 31951,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 32100,
      "e": 31951,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32105,
      "e": 31956,
      "ty": 2,
      "x": 858,
      "y": 1018
    },
    {
      "t": 32202,
      "e": 32053,
      "ty": 4,
      "x": 14728,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32202,
      "e": 32053,
      "ty": 5,
      "x": 858,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32204,
      "e": 32055,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 32205,
      "e": 32056,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 32208,
      "e": 32059,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 32254,
      "e": 32105,
      "ty": 41,
      "x": 29272,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 32755,
      "e": 32606,
      "ty": 41,
      "x": 29272,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 32805,
      "e": 32656,
      "ty": 2,
      "x": 859,
      "y": 998
    },
    {
      "t": 32904,
      "e": 32755,
      "ty": 2,
      "x": 882,
      "y": 890
    },
    {
      "t": 33004,
      "e": 32855,
      "ty": 2,
      "x": 943,
      "y": 776
    },
    {
      "t": 33004,
      "e": 32855,
      "ty": 41,
      "x": 32199,
      "y": 42545,
      "ta": "html > body"
    },
    {
      "t": 33104,
      "e": 32955,
      "ty": 2,
      "x": 1033,
      "y": 714
    },
    {
      "t": 33205,
      "e": 33056,
      "ty": 2,
      "x": 1097,
      "y": 693
    },
    {
      "t": 33255,
      "e": 33106,
      "ty": 41,
      "x": 37847,
      "y": 37891,
      "ta": "html > body"
    },
    {
      "t": 33299,
      "e": 33150,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 33304,
      "e": 33155,
      "ty": 2,
      "x": 1107,
      "y": 692
    },
    {
      "t": 33404,
      "e": 33255,
      "ty": 2,
      "x": 1040,
      "y": 704
    },
    {
      "t": 33504,
      "e": 33355,
      "ty": 2,
      "x": 193,
      "y": 754
    },
    {
      "t": 33505,
      "e": 33356,
      "ty": 41,
      "x": 6370,
      "y": 41326,
      "ta": "> div.masterdiv"
    },
    {
      "t": 33605,
      "e": 33456,
      "ty": 2,
      "x": 0,
      "y": 728
    },
    {
      "t": 33705,
      "e": 33556,
      "ty": 2,
      "x": 1,
      "y": 721
    },
    {
      "t": 33755,
      "e": 33606,
      "ty": 41,
      "x": 1480,
      "y": 37780,
      "ta": "> div.masterdiv"
    },
    {
      "t": 33805,
      "e": 33656,
      "ty": 2,
      "x": 185,
      "y": 634
    },
    {
      "t": 33904,
      "e": 33755,
      "ty": 2,
      "x": 597,
      "y": 718
    },
    {
      "t": 34004,
      "e": 33855,
      "ty": 2,
      "x": 794,
      "y": 924
    },
    {
      "t": 34005,
      "e": 33856,
      "ty": 41,
      "x": 24625,
      "y": 55238,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 34105,
      "e": 33956,
      "ty": 2,
      "x": 823,
      "y": 966
    },
    {
      "t": 34204,
      "e": 34055,
      "ty": 2,
      "x": 1001,
      "y": 1013
    },
    {
      "t": 34255,
      "e": 34106,
      "ty": 41,
      "x": 39482,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 34305,
      "e": 34156,
      "ty": 2,
      "x": 1112,
      "y": 1045
    },
    {
      "t": 34405,
      "e": 34256,
      "ty": 2,
      "x": 1118,
      "y": 1062
    },
    {
      "t": 34505,
      "e": 34356,
      "ty": 2,
      "x": 1095,
      "y": 1090
    },
    {
      "t": 34505,
      "e": 34356,
      "ty": 41,
      "x": 37433,
      "y": 59939,
      "ta": "> div.masterdiv"
    },
    {
      "t": 34604,
      "e": 34455,
      "ty": 2,
      "x": 1061,
      "y": 1101
    },
    {
      "t": 34706,
      "e": 34456,
      "ty": 2,
      "x": 1038,
      "y": 1096
    },
    {
      "t": 34746,
      "e": 34496,
      "ty": 6,
      "x": 1028,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 34755,
      "e": 34505,
      "ty": 41,
      "x": 64715,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 34805,
      "e": 34555,
      "ty": 2,
      "x": 1027,
      "y": 1092
    },
    {
      "t": 34905,
      "e": 34655,
      "ty": 2,
      "x": 1012,
      "y": 1089
    },
    {
      "t": 35003,
      "e": 34753,
      "ty": 3,
      "x": 1012,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 35004,
      "e": 34754,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 35006,
      "e": 34756,
      "ty": 41,
      "x": 55977,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 35130,
      "e": 34880,
      "ty": 4,
      "x": 55977,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 35131,
      "e": 34881,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 35133,
      "e": 34883,
      "ty": 5,
      "x": 1012,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 35133,
      "e": 34883,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 36163,
      "e": 35913,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 36606,
      "e": 36356,
      "ty": 2,
      "x": 1011,
      "y": 1088
    },
    {
      "t": 36606,
      "e": 36356,
      "ty": 41,
      "x": 35733,
      "y": 32943,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 36975,
      "e": 36725,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 429651, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 429656, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 21125, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 452127, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9760, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 462892, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13457, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 477437, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8596, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 487034, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 32848, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 521279, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-H -A -A -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1068,y:975,t:1528139560541};\\\", \\\"{x:1068,y:946,t:1528139560549};\\\", \\\"{x:1068,y:896,t:1528139560562};\\\", \\\"{x:1079,y:741,t:1528139560580};\\\", \\\"{x:1084,y:714,t:1528139560595};\\\", \\\"{x:1090,y:674,t:1528139560612};\\\", \\\"{x:1090,y:663,t:1528139560631};\\\", \\\"{x:1090,y:662,t:1528139560661};\\\", \\\"{x:1090,y:661,t:1528139560708};\\\", \\\"{x:1083,y:661,t:1528139560717};\\\", \\\"{x:1075,y:660,t:1528139560730};\\\", \\\"{x:1048,y:658,t:1528139560746};\\\", \\\"{x:997,y:658,t:1528139560763};\\\", \\\"{x:883,y:658,t:1528139560781};\\\", \\\"{x:820,y:661,t:1528139560796};\\\", \\\"{x:756,y:669,t:1528139560813};\\\", \\\"{x:704,y:674,t:1528139560834};\\\", \\\"{x:659,y:674,t:1528139560845};\\\", \\\"{x:612,y:674,t:1528139560862};\\\", \\\"{x:564,y:674,t:1528139560880};\\\", \\\"{x:525,y:674,t:1528139560896};\\\", \\\"{x:498,y:674,t:1528139560913};\\\", \\\"{x:472,y:674,t:1528139560929};\\\", \\\"{x:446,y:671,t:1528139560946};\\\", \\\"{x:417,y:668,t:1528139560964};\\\", \\\"{x:406,y:664,t:1528139560979};\\\", \\\"{x:403,y:660,t:1528139560996};\\\", \\\"{x:403,y:654,t:1528139561013};\\\", \\\"{x:399,y:645,t:1528139561030};\\\", \\\"{x:398,y:634,t:1528139561047};\\\", \\\"{x:397,y:621,t:1528139561063};\\\", \\\"{x:397,y:610,t:1528139561080};\\\", \\\"{x:399,y:593,t:1528139561097};\\\", \\\"{x:402,y:581,t:1528139561114};\\\", \\\"{x:406,y:572,t:1528139561129};\\\", \\\"{x:409,y:564,t:1528139561146};\\\", \\\"{x:412,y:559,t:1528139561162};\\\", \\\"{x:415,y:556,t:1528139561179};\\\", \\\"{x:418,y:555,t:1528139561196};\\\", \\\"{x:425,y:555,t:1528139561213};\\\", \\\"{x:436,y:554,t:1528139561230};\\\", \\\"{x:451,y:552,t:1528139561246};\\\", \\\"{x:469,y:551,t:1528139561263};\\\", \\\"{x:490,y:546,t:1528139561279};\\\", \\\"{x:508,y:543,t:1528139561297};\\\", \\\"{x:529,y:540,t:1528139561314};\\\", \\\"{x:544,y:538,t:1528139561329};\\\", \\\"{x:555,y:536,t:1528139561346};\\\", \\\"{x:560,y:535,t:1528139561362};\\\", \\\"{x:564,y:535,t:1528139561379};\\\", \\\"{x:568,y:534,t:1528139561396};\\\", \\\"{x:576,y:532,t:1528139561412};\\\", \\\"{x:586,y:529,t:1528139561430};\\\", \\\"{x:601,y:525,t:1528139561446};\\\", \\\"{x:615,y:521,t:1528139561462};\\\", \\\"{x:627,y:517,t:1528139561479};\\\", \\\"{x:641,y:514,t:1528139561497};\\\", \\\"{x:650,y:512,t:1528139561512};\\\", \\\"{x:655,y:510,t:1528139561529};\\\", \\\"{x:657,y:510,t:1528139561546};\\\", \\\"{x:659,y:509,t:1528139561562};\\\", \\\"{x:662,y:508,t:1528139561579};\\\", \\\"{x:664,y:508,t:1528139561596};\\\", \\\"{x:671,y:507,t:1528139561613};\\\", \\\"{x:680,y:507,t:1528139561631};\\\", \\\"{x:691,y:507,t:1528139561647};\\\", \\\"{x:703,y:507,t:1528139561662};\\\", \\\"{x:720,y:507,t:1528139561680};\\\", \\\"{x:740,y:507,t:1528139561696};\\\", \\\"{x:770,y:507,t:1528139561713};\\\", \\\"{x:802,y:507,t:1528139561730};\\\", \\\"{x:852,y:507,t:1528139561746};\\\", \\\"{x:916,y:507,t:1528139561763};\\\", \\\"{x:1041,y:515,t:1528139561780};\\\", \\\"{x:1137,y:523,t:1528139561796};\\\", \\\"{x:1239,y:535,t:1528139561813};\\\", \\\"{x:1328,y:550,t:1528139561832};\\\", \\\"{x:1414,y:559,t:1528139561851};\\\", \\\"{x:1478,y:568,t:1528139561864};\\\", \\\"{x:1521,y:570,t:1528139561879};\\\", \\\"{x:1543,y:574,t:1528139561896};\\\", \\\"{x:1550,y:574,t:1528139561913};\\\", \\\"{x:1548,y:577,t:1528139562060};\\\", \\\"{x:1540,y:580,t:1528139562068};\\\", \\\"{x:1530,y:584,t:1528139562081};\\\", \\\"{x:1512,y:594,t:1528139562096};\\\", \\\"{x:1497,y:605,t:1528139562114};\\\", \\\"{x:1479,y:616,t:1528139562131};\\\", \\\"{x:1465,y:622,t:1528139562147};\\\", \\\"{x:1454,y:627,t:1528139562164};\\\", \\\"{x:1449,y:629,t:1528139562180};\\\", \\\"{x:1448,y:629,t:1528139562198};\\\", \\\"{x:1446,y:629,t:1528139562214};\\\", \\\"{x:1444,y:630,t:1528139562232};\\\", \\\"{x:1440,y:630,t:1528139562247};\\\", \\\"{x:1434,y:631,t:1528139562264};\\\", \\\"{x:1428,y:631,t:1528139562282};\\\", \\\"{x:1423,y:631,t:1528139562298};\\\", \\\"{x:1417,y:631,t:1528139562315};\\\", \\\"{x:1409,y:631,t:1528139562332};\\\", \\\"{x:1391,y:631,t:1528139562348};\\\", \\\"{x:1376,y:631,t:1528139562364};\\\", \\\"{x:1361,y:628,t:1528139562381};\\\", \\\"{x:1356,y:628,t:1528139562398};\\\", \\\"{x:1354,y:628,t:1528139562413};\\\", \\\"{x:1355,y:628,t:1528139562885};\\\", \\\"{x:1356,y:628,t:1528139562957};\\\", \\\"{x:1356,y:629,t:1528139563621};\\\", \\\"{x:1354,y:629,t:1528139564597};\\\", \\\"{x:1353,y:629,t:1528139564605};\\\", \\\"{x:1349,y:632,t:1528139564616};\\\", \\\"{x:1347,y:634,t:1528139564634};\\\", \\\"{x:1342,y:638,t:1528139564649};\\\", \\\"{x:1337,y:641,t:1528139564666};\\\", \\\"{x:1334,y:643,t:1528139564683};\\\", \\\"{x:1330,y:647,t:1528139564699};\\\", \\\"{x:1323,y:660,t:1528139564716};\\\", \\\"{x:1318,y:669,t:1528139564733};\\\", \\\"{x:1315,y:682,t:1528139564750};\\\", \\\"{x:1312,y:694,t:1528139564766};\\\", \\\"{x:1307,y:704,t:1528139564783};\\\", \\\"{x:1302,y:715,t:1528139564800};\\\", \\\"{x:1300,y:729,t:1528139564817};\\\", \\\"{x:1298,y:745,t:1528139564833};\\\", \\\"{x:1296,y:756,t:1528139564851};\\\", \\\"{x:1292,y:768,t:1528139564866};\\\", \\\"{x:1291,y:774,t:1528139564884};\\\", \\\"{x:1289,y:782,t:1528139564900};\\\", \\\"{x:1288,y:788,t:1528139564916};\\\", \\\"{x:1288,y:796,t:1528139564934};\\\", \\\"{x:1288,y:800,t:1528139564950};\\\", \\\"{x:1288,y:805,t:1528139564966};\\\", \\\"{x:1288,y:812,t:1528139564983};\\\", \\\"{x:1288,y:822,t:1528139565000};\\\", \\\"{x:1286,y:829,t:1528139565020};\\\", \\\"{x:1285,y:837,t:1528139565033};\\\", \\\"{x:1285,y:854,t:1528139565065};\\\", \\\"{x:1284,y:864,t:1528139565083};\\\", \\\"{x:1282,y:878,t:1528139565099};\\\", \\\"{x:1279,y:887,t:1528139565117};\\\", \\\"{x:1279,y:896,t:1528139565132};\\\", \\\"{x:1279,y:902,t:1528139565150};\\\", \\\"{x:1279,y:906,t:1528139565167};\\\", \\\"{x:1279,y:911,t:1528139565183};\\\", \\\"{x:1279,y:914,t:1528139565200};\\\", \\\"{x:1279,y:918,t:1528139565217};\\\", \\\"{x:1280,y:923,t:1528139565232};\\\", \\\"{x:1281,y:927,t:1528139565250};\\\", \\\"{x:1281,y:928,t:1528139565267};\\\", \\\"{x:1282,y:930,t:1528139565283};\\\", \\\"{x:1283,y:930,t:1528139565300};\\\", \\\"{x:1283,y:931,t:1528139565413};\\\", \\\"{x:1283,y:928,t:1528139565870};\\\", \\\"{x:1283,y:922,t:1528139565884};\\\", \\\"{x:1282,y:917,t:1528139565900};\\\", \\\"{x:1281,y:911,t:1528139565917};\\\", \\\"{x:1281,y:905,t:1528139565934};\\\", \\\"{x:1280,y:902,t:1528139565951};\\\", \\\"{x:1280,y:897,t:1528139565967};\\\", \\\"{x:1280,y:890,t:1528139565984};\\\", \\\"{x:1280,y:884,t:1528139566000};\\\", \\\"{x:1280,y:878,t:1528139566017};\\\", \\\"{x:1280,y:872,t:1528139566034};\\\", \\\"{x:1280,y:866,t:1528139566051};\\\", \\\"{x:1280,y:863,t:1528139566067};\\\", \\\"{x:1280,y:860,t:1528139566085};\\\", \\\"{x:1280,y:859,t:1528139566109};\\\", \\\"{x:1280,y:858,t:1528139566149};\\\", \\\"{x:1280,y:856,t:1528139566157};\\\", \\\"{x:1280,y:855,t:1528139566173};\\\", \\\"{x:1280,y:854,t:1528139566184};\\\", \\\"{x:1280,y:852,t:1528139566202};\\\", \\\"{x:1280,y:851,t:1528139566221};\\\", \\\"{x:1280,y:850,t:1528139566916};\\\", \\\"{x:1280,y:849,t:1528139566939};\\\", \\\"{x:1280,y:847,t:1528139566951};\\\", \\\"{x:1280,y:844,t:1528139566967};\\\", \\\"{x:1280,y:841,t:1528139566985};\\\", \\\"{x:1280,y:839,t:1528139567001};\\\", \\\"{x:1280,y:837,t:1528139567018};\\\", \\\"{x:1280,y:836,t:1528139567035};\\\", \\\"{x:1280,y:835,t:1528139567054};\\\", \\\"{x:1280,y:834,t:1528139567092};\\\", \\\"{x:1280,y:833,t:1528139567155};\\\", \\\"{x:1280,y:831,t:1528139567166};\\\", \\\"{x:1280,y:830,t:1528139567181};\\\", \\\"{x:1280,y:829,t:1528139567199};\\\", \\\"{x:1280,y:828,t:1528139567268};\\\", \\\"{x:1278,y:820,t:1528139569408};\\\", \\\"{x:1253,y:797,t:1528139569415};\\\", \\\"{x:1160,y:744,t:1528139569431};\\\", \\\"{x:931,y:653,t:1528139569453};\\\", \\\"{x:741,y:575,t:1528139569469};\\\", \\\"{x:537,y:517,t:1528139569486};\\\", \\\"{x:366,y:467,t:1528139569502};\\\", \\\"{x:222,y:428,t:1528139569520};\\\", \\\"{x:133,y:415,t:1528139569536};\\\", \\\"{x:90,y:407,t:1528139569553};\\\", \\\"{x:77,y:407,t:1528139569570};\\\", \\\"{x:76,y:407,t:1528139569587};\\\", \\\"{x:75,y:407,t:1528139569676};\\\", \\\"{x:75,y:408,t:1528139569687};\\\", \\\"{x:76,y:414,t:1528139569703};\\\", \\\"{x:87,y:430,t:1528139569720};\\\", \\\"{x:102,y:444,t:1528139569737};\\\", \\\"{x:121,y:460,t:1528139569753};\\\", \\\"{x:139,y:474,t:1528139569770};\\\", \\\"{x:164,y:492,t:1528139569787};\\\", \\\"{x:183,y:504,t:1528139569804};\\\", \\\"{x:209,y:520,t:1528139569820};\\\", \\\"{x:216,y:525,t:1528139569837};\\\", \\\"{x:219,y:528,t:1528139569853};\\\", \\\"{x:220,y:529,t:1528139569870};\\\", \\\"{x:220,y:530,t:1528139569887};\\\", \\\"{x:220,y:531,t:1528139569949};\\\", \\\"{x:221,y:533,t:1528139569957};\\\", \\\"{x:223,y:534,t:1528139569970};\\\", \\\"{x:232,y:538,t:1528139569987};\\\", \\\"{x:239,y:540,t:1528139570004};\\\", \\\"{x:242,y:540,t:1528139570020};\\\", \\\"{x:244,y:541,t:1528139570037};\\\", \\\"{x:245,y:541,t:1528139570093};\\\", \\\"{x:246,y:541,t:1528139570116};\\\", \\\"{x:248,y:541,t:1528139570125};\\\", \\\"{x:249,y:541,t:1528139570138};\\\", \\\"{x:257,y:541,t:1528139570154};\\\", \\\"{x:267,y:541,t:1528139570170};\\\", \\\"{x:282,y:541,t:1528139570188};\\\", \\\"{x:305,y:541,t:1528139570204};\\\", \\\"{x:319,y:543,t:1528139570222};\\\", \\\"{x:335,y:547,t:1528139570237};\\\", \\\"{x:348,y:550,t:1528139570254};\\\", \\\"{x:354,y:553,t:1528139570270};\\\", \\\"{x:360,y:554,t:1528139570287};\\\", \\\"{x:363,y:555,t:1528139570303};\\\", \\\"{x:364,y:557,t:1528139570320};\\\", \\\"{x:366,y:558,t:1528139570337};\\\", \\\"{x:368,y:560,t:1528139570353};\\\", \\\"{x:373,y:564,t:1528139570371};\\\", \\\"{x:381,y:567,t:1528139570388};\\\", \\\"{x:387,y:569,t:1528139570403};\\\", \\\"{x:392,y:570,t:1528139570421};\\\", \\\"{x:397,y:570,t:1528139570437};\\\", \\\"{x:401,y:570,t:1528139570453};\\\", \\\"{x:405,y:570,t:1528139570471};\\\", \\\"{x:413,y:570,t:1528139570487};\\\", \\\"{x:419,y:570,t:1528139570504};\\\", \\\"{x:427,y:570,t:1528139570520};\\\", \\\"{x:431,y:570,t:1528139570536};\\\", \\\"{x:435,y:568,t:1528139570554};\\\", \\\"{x:439,y:567,t:1528139570571};\\\", \\\"{x:442,y:566,t:1528139570587};\\\", \\\"{x:445,y:565,t:1528139570603};\\\", \\\"{x:446,y:565,t:1528139570636};\\\", \\\"{x:448,y:565,t:1528139570661};\\\", \\\"{x:449,y:565,t:1528139570671};\\\", \\\"{x:453,y:563,t:1528139570687};\\\", \\\"{x:459,y:562,t:1528139570704};\\\", \\\"{x:463,y:562,t:1528139570722};\\\", \\\"{x:468,y:562,t:1528139570737};\\\", \\\"{x:472,y:561,t:1528139570754};\\\", \\\"{x:476,y:561,t:1528139570771};\\\", \\\"{x:478,y:560,t:1528139570787};\\\", \\\"{x:481,y:559,t:1528139570804};\\\", \\\"{x:482,y:559,t:1528139571845};\\\", \\\"{x:489,y:559,t:1528139571884};\\\", \\\"{x:501,y:559,t:1528139571894};\\\", \\\"{x:520,y:561,t:1528139571904};\\\", \\\"{x:588,y:573,t:1528139571922};\\\", \\\"{x:652,y:581,t:1528139571939};\\\", \\\"{x:725,y:594,t:1528139571956};\\\", \\\"{x:854,y:624,t:1528139571972};\\\", \\\"{x:952,y:643,t:1528139571989};\\\", \\\"{x:1022,y:663,t:1528139572005};\\\", \\\"{x:1067,y:676,t:1528139572022};\\\", \\\"{x:1083,y:684,t:1528139572039};\\\", \\\"{x:1089,y:687,t:1528139572055};\\\", \\\"{x:1091,y:693,t:1528139572072};\\\", \\\"{x:1096,y:700,t:1528139572089};\\\", \\\"{x:1100,y:708,t:1528139572105};\\\", \\\"{x:1102,y:712,t:1528139572122};\\\", \\\"{x:1107,y:717,t:1528139572139};\\\", \\\"{x:1113,y:723,t:1528139572155};\\\", \\\"{x:1126,y:733,t:1528139572172};\\\", \\\"{x:1134,y:738,t:1528139572190};\\\", \\\"{x:1145,y:745,t:1528139572206};\\\", \\\"{x:1156,y:752,t:1528139572222};\\\", \\\"{x:1165,y:758,t:1528139572239};\\\", \\\"{x:1179,y:764,t:1528139572256};\\\", \\\"{x:1191,y:772,t:1528139572273};\\\", \\\"{x:1198,y:778,t:1528139572289};\\\", \\\"{x:1203,y:781,t:1528139572306};\\\", \\\"{x:1205,y:782,t:1528139572322};\\\", \\\"{x:1208,y:783,t:1528139572339};\\\", \\\"{x:1209,y:783,t:1528139572356};\\\", \\\"{x:1210,y:783,t:1528139572372};\\\", \\\"{x:1211,y:784,t:1528139572389};\\\", \\\"{x:1212,y:784,t:1528139572406};\\\", \\\"{x:1213,y:784,t:1528139572422};\\\", \\\"{x:1214,y:784,t:1528139572440};\\\", \\\"{x:1218,y:785,t:1528139572457};\\\", \\\"{x:1222,y:786,t:1528139572473};\\\", \\\"{x:1225,y:787,t:1528139572489};\\\", \\\"{x:1227,y:788,t:1528139572506};\\\", \\\"{x:1229,y:788,t:1528139572523};\\\", \\\"{x:1242,y:792,t:1528139572540};\\\", \\\"{x:1250,y:792,t:1528139572556};\\\", \\\"{x:1250,y:793,t:1528139572573};\\\", \\\"{x:1251,y:793,t:1528139572685};\\\", \\\"{x:1252,y:793,t:1528139572693};\\\", \\\"{x:1254,y:793,t:1528139572707};\\\", \\\"{x:1258,y:798,t:1528139572723};\\\", \\\"{x:1269,y:805,t:1528139572740};\\\", \\\"{x:1271,y:809,t:1528139572756};\\\", \\\"{x:1271,y:810,t:1528139572774};\\\", \\\"{x:1272,y:811,t:1528139572791};\\\", \\\"{x:1274,y:814,t:1528139572807};\\\", \\\"{x:1275,y:815,t:1528139572823};\\\", \\\"{x:1276,y:817,t:1528139572841};\\\", \\\"{x:1278,y:819,t:1528139572856};\\\", \\\"{x:1280,y:819,t:1528139572874};\\\", \\\"{x:1281,y:820,t:1528139572890};\\\", \\\"{x:1282,y:820,t:1528139572907};\\\", \\\"{x:1282,y:821,t:1528139572923};\\\", \\\"{x:1283,y:821,t:1528139572940};\\\", \\\"{x:1284,y:822,t:1528139572980};\\\", \\\"{x:1285,y:824,t:1528139573005};\\\", \\\"{x:1285,y:825,t:1528139573021};\\\", \\\"{x:1286,y:826,t:1528139573036};\\\", \\\"{x:1286,y:827,t:1528139573050};\\\", \\\"{x:1286,y:828,t:1528139573075};\\\", \\\"{x:1286,y:829,t:1528139573091};\\\", \\\"{x:1286,y:830,t:1528139573107};\\\", \\\"{x:1286,y:831,t:1528139573132};\\\", \\\"{x:1286,y:832,t:1528139573203};\\\", \\\"{x:1285,y:832,t:1528139573235};\\\", \\\"{x:1284,y:832,t:1528139573260};\\\", \\\"{x:1282,y:832,t:1528139573300};\\\", \\\"{x:1281,y:832,t:1528139573357};\\\", \\\"{x:1279,y:832,t:1528139577045};\\\", \\\"{x:1249,y:832,t:1528139586819};\\\", \\\"{x:1193,y:811,t:1528139586835};\\\", \\\"{x:1180,y:806,t:1528139586850};\\\", \\\"{x:1159,y:797,t:1528139586866};\\\", \\\"{x:1124,y:779,t:1528139586883};\\\", \\\"{x:1097,y:771,t:1528139586901};\\\", \\\"{x:1072,y:763,t:1528139586916};\\\", \\\"{x:1048,y:756,t:1528139586934};\\\", \\\"{x:1028,y:752,t:1528139586951};\\\", \\\"{x:1009,y:749,t:1528139586967};\\\", \\\"{x:991,y:745,t:1528139586984};\\\", \\\"{x:975,y:741,t:1528139587001};\\\", \\\"{x:963,y:740,t:1528139587016};\\\", \\\"{x:953,y:739,t:1528139587034};\\\", \\\"{x:945,y:739,t:1528139587051};\\\", \\\"{x:937,y:737,t:1528139587067};\\\", \\\"{x:935,y:736,t:1528139587083};\\\", \\\"{x:933,y:736,t:1528139587101};\\\", \\\"{x:930,y:736,t:1528139587118};\\\", \\\"{x:928,y:736,t:1528139587134};\\\", \\\"{x:925,y:736,t:1528139587151};\\\", \\\"{x:922,y:735,t:1528139587168};\\\", \\\"{x:917,y:733,t:1528139587183};\\\", \\\"{x:911,y:733,t:1528139587201};\\\", \\\"{x:903,y:732,t:1528139587218};\\\", \\\"{x:890,y:729,t:1528139587233};\\\", \\\"{x:867,y:726,t:1528139587251};\\\", \\\"{x:787,y:719,t:1528139587267};\\\", \\\"{x:692,y:703,t:1528139587284};\\\", \\\"{x:598,y:692,t:1528139587300};\\\", \\\"{x:505,y:674,t:1528139587319};\\\", \\\"{x:414,y:651,t:1528139587334};\\\", \\\"{x:345,y:631,t:1528139587351};\\\", \\\"{x:291,y:615,t:1528139587368};\\\", \\\"{x:259,y:606,t:1528139587385};\\\", \\\"{x:241,y:601,t:1528139587401};\\\", \\\"{x:235,y:599,t:1528139587418};\\\", \\\"{x:233,y:598,t:1528139587434};\\\", \\\"{x:232,y:598,t:1528139587508};\\\", \\\"{x:232,y:597,t:1528139587564};\\\", \\\"{x:232,y:596,t:1528139587573};\\\", \\\"{x:232,y:593,t:1528139587585};\\\", \\\"{x:241,y:589,t:1528139587602};\\\", \\\"{x:251,y:586,t:1528139587619};\\\", \\\"{x:267,y:581,t:1528139587635};\\\", \\\"{x:284,y:575,t:1528139587653};\\\", \\\"{x:303,y:570,t:1528139587668};\\\", \\\"{x:316,y:566,t:1528139587684};\\\", \\\"{x:332,y:563,t:1528139587700};\\\", \\\"{x:348,y:563,t:1528139587718};\\\", \\\"{x:369,y:563,t:1528139587735};\\\", \\\"{x:386,y:569,t:1528139587750};\\\", \\\"{x:399,y:575,t:1528139587768};\\\", \\\"{x:411,y:581,t:1528139587785};\\\", \\\"{x:418,y:587,t:1528139587801};\\\", \\\"{x:420,y:589,t:1528139587817};\\\", \\\"{x:422,y:589,t:1528139587835};\\\", \\\"{x:422,y:590,t:1528139587868};\\\", \\\"{x:423,y:590,t:1528139587885};\\\", \\\"{x:423,y:593,t:1528139587901};\\\", \\\"{x:423,y:596,t:1528139587918};\\\", \\\"{x:422,y:600,t:1528139587935};\\\", \\\"{x:415,y:605,t:1528139587952};\\\", \\\"{x:411,y:606,t:1528139587969};\\\", \\\"{x:406,y:610,t:1528139587985};\\\", \\\"{x:400,y:611,t:1528139588002};\\\", \\\"{x:395,y:612,t:1528139588018};\\\", \\\"{x:393,y:613,t:1528139588035};\\\", \\\"{x:391,y:614,t:1528139588052};\\\", \\\"{x:389,y:615,t:1528139588068};\\\", \\\"{x:385,y:616,t:1528139588147};\\\", \\\"{x:378,y:618,t:1528139588156};\\\", \\\"{x:370,y:618,t:1528139588169};\\\", \\\"{x:348,y:618,t:1528139588185};\\\", \\\"{x:321,y:618,t:1528139588202};\\\", \\\"{x:295,y:618,t:1528139588218};\\\", \\\"{x:273,y:618,t:1528139588234};\\\", \\\"{x:247,y:616,t:1528139588252};\\\", \\\"{x:233,y:614,t:1528139588268};\\\", \\\"{x:222,y:611,t:1528139588285};\\\", \\\"{x:216,y:610,t:1528139588303};\\\", \\\"{x:214,y:609,t:1528139588318};\\\", \\\"{x:214,y:608,t:1528139588404};\\\", \\\"{x:213,y:607,t:1528139588419};\\\", \\\"{x:213,y:605,t:1528139588435};\\\", \\\"{x:212,y:602,t:1528139588451};\\\", \\\"{x:212,y:601,t:1528139588469};\\\", \\\"{x:209,y:597,t:1528139588485};\\\", \\\"{x:201,y:594,t:1528139588502};\\\", \\\"{x:196,y:592,t:1528139588519};\\\", \\\"{x:192,y:589,t:1528139588534};\\\", \\\"{x:185,y:585,t:1528139588552};\\\", \\\"{x:177,y:582,t:1528139588569};\\\", \\\"{x:175,y:581,t:1528139588584};\\\", \\\"{x:175,y:580,t:1528139588691};\\\", \\\"{x:174,y:579,t:1528139588716};\\\", \\\"{x:173,y:577,t:1528139588723};\\\", \\\"{x:171,y:575,t:1528139588735};\\\", \\\"{x:169,y:571,t:1528139588753};\\\", \\\"{x:167,y:569,t:1528139588767};\\\", \\\"{x:167,y:567,t:1528139588785};\\\", \\\"{x:165,y:565,t:1528139588801};\\\", \\\"{x:165,y:564,t:1528139588820};\\\", \\\"{x:165,y:563,t:1528139588835};\\\", \\\"{x:165,y:562,t:1528139588852};\\\", \\\"{x:165,y:561,t:1528139588876};\\\", \\\"{x:165,y:560,t:1528139588908};\\\", \\\"{x:166,y:560,t:1528139589187};\\\", \\\"{x:170,y:560,t:1528139589202};\\\", \\\"{x:184,y:560,t:1528139589219};\\\", \\\"{x:208,y:560,t:1528139589235};\\\", \\\"{x:227,y:555,t:1528139589252};\\\", \\\"{x:245,y:551,t:1528139589269};\\\", \\\"{x:265,y:544,t:1528139589286};\\\", \\\"{x:288,y:537,t:1528139589303};\\\", \\\"{x:309,y:531,t:1528139589318};\\\", \\\"{x:325,y:528,t:1528139589336};\\\", \\\"{x:339,y:524,t:1528139589353};\\\", \\\"{x:355,y:523,t:1528139589369};\\\", \\\"{x:372,y:523,t:1528139589386};\\\", \\\"{x:398,y:523,t:1528139589403};\\\", \\\"{x:423,y:526,t:1528139589419};\\\", \\\"{x:473,y:534,t:1528139589435};\\\", \\\"{x:503,y:539,t:1528139589453};\\\", \\\"{x:530,y:542,t:1528139589470};\\\", \\\"{x:543,y:544,t:1528139589486};\\\", \\\"{x:550,y:545,t:1528139589503};\\\", \\\"{x:552,y:546,t:1528139589520};\\\", \\\"{x:553,y:547,t:1528139589547};\\\", \\\"{x:556,y:549,t:1528139589564};\\\", \\\"{x:564,y:555,t:1528139589572};\\\", \\\"{x:573,y:559,t:1528139589586};\\\", \\\"{x:589,y:568,t:1528139589603};\\\", \\\"{x:609,y:575,t:1528139589621};\\\", \\\"{x:618,y:576,t:1528139589636};\\\", \\\"{x:632,y:576,t:1528139589654};\\\", \\\"{x:655,y:576,t:1528139589670};\\\", \\\"{x:692,y:576,t:1528139589687};\\\", \\\"{x:751,y:576,t:1528139589704};\\\", \\\"{x:793,y:576,t:1528139589720};\\\", \\\"{x:833,y:570,t:1528139589739};\\\", \\\"{x:852,y:565,t:1528139589753};\\\", \\\"{x:866,y:563,t:1528139589770};\\\", \\\"{x:871,y:563,t:1528139589786};\\\", \\\"{x:864,y:564,t:1528139589908};\\\", \\\"{x:859,y:567,t:1528139589920};\\\", \\\"{x:848,y:571,t:1528139589936};\\\", \\\"{x:834,y:578,t:1528139589953};\\\", \\\"{x:820,y:583,t:1528139589970};\\\", \\\"{x:800,y:589,t:1528139589986};\\\", \\\"{x:782,y:595,t:1528139590003};\\\", \\\"{x:759,y:609,t:1528139590019};\\\", \\\"{x:743,y:619,t:1528139590038};\\\", \\\"{x:728,y:627,t:1528139590053};\\\", \\\"{x:712,y:635,t:1528139590071};\\\", \\\"{x:696,y:641,t:1528139590087};\\\", \\\"{x:675,y:646,t:1528139590103};\\\", \\\"{x:660,y:647,t:1528139590120};\\\", \\\"{x:642,y:650,t:1528139590138};\\\", \\\"{x:613,y:650,t:1528139590153};\\\", \\\"{x:570,y:650,t:1528139590170};\\\", \\\"{x:508,y:650,t:1528139590187};\\\", \\\"{x:445,y:646,t:1528139590204};\\\", \\\"{x:388,y:637,t:1528139590220};\\\", \\\"{x:378,y:636,t:1528139590237};\\\", \\\"{x:376,y:635,t:1528139590253};\\\", \\\"{x:377,y:637,t:1528139590364};\\\", \\\"{x:387,y:642,t:1528139590371};\\\", \\\"{x:398,y:643,t:1528139590387};\\\", \\\"{x:428,y:646,t:1528139590403};\\\", \\\"{x:490,y:646,t:1528139590420};\\\", \\\"{x:548,y:646,t:1528139590439};\\\", \\\"{x:599,y:646,t:1528139590454};\\\", \\\"{x:636,y:646,t:1528139590470};\\\", \\\"{x:669,y:646,t:1528139590487};\\\", \\\"{x:701,y:646,t:1528139590503};\\\", \\\"{x:728,y:646,t:1528139590521};\\\", \\\"{x:745,y:646,t:1528139590536};\\\", \\\"{x:760,y:646,t:1528139590553};\\\", \\\"{x:772,y:646,t:1528139590569};\\\", \\\"{x:774,y:646,t:1528139590587};\\\", \\\"{x:775,y:646,t:1528139590691};\\\", \\\"{x:778,y:646,t:1528139590724};\\\", \\\"{x:786,y:643,t:1528139590737};\\\", \\\"{x:808,y:636,t:1528139590754};\\\", \\\"{x:832,y:629,t:1528139590772};\\\", \\\"{x:848,y:625,t:1528139590788};\\\", \\\"{x:853,y:624,t:1528139590805};\\\", \\\"{x:854,y:624,t:1528139591084};\\\", \\\"{x:851,y:624,t:1528139591108};\\\", \\\"{x:841,y:624,t:1528139591117};\\\", \\\"{x:829,y:624,t:1528139591137};\\\", \\\"{x:826,y:624,t:1528139591154};\\\", \\\"{x:823,y:624,t:1528139591420};\\\", \\\"{x:782,y:629,t:1528139591438};\\\", \\\"{x:688,y:641,t:1528139591455};\\\", \\\"{x:593,y:658,t:1528139591472};\\\", \\\"{x:516,y:678,t:1528139591488};\\\", \\\"{x:455,y:703,t:1528139591505};\\\", \\\"{x:418,y:721,t:1528139591521};\\\", \\\"{x:403,y:733,t:1528139591538};\\\", \\\"{x:399,y:742,t:1528139591555};\\\", \\\"{x:398,y:745,t:1528139591571};\\\", \\\"{x:398,y:746,t:1528139591588};\\\", \\\"{x:399,y:747,t:1528139591652};\\\", \\\"{x:400,y:749,t:1528139591660};\\\", \\\"{x:404,y:751,t:1528139591672};\\\", \\\"{x:411,y:753,t:1528139591689};\\\", \\\"{x:419,y:755,t:1528139591705};\\\", \\\"{x:432,y:757,t:1528139591722};\\\", \\\"{x:446,y:757,t:1528139591739};\\\", \\\"{x:460,y:757,t:1528139591755};\\\", \\\"{x:484,y:756,t:1528139591770};\\\", \\\"{x:496,y:756,t:1528139591787};\\\", \\\"{x:502,y:756,t:1528139591804};\\\", \\\"{x:503,y:755,t:1528139591938};\\\", \\\"{x:504,y:753,t:1528139591955};\\\", \\\"{x:505,y:753,t:1528139591971};\\\", \\\"{x:503,y:753,t:1528139592070};\\\", \\\"{x:502,y:753,t:1528139592087};\\\", \\\"{x:501,y:753,t:1528139592171};\\\", \\\"{x:499,y:753,t:1528139592317};\\\", \\\"{x:495,y:755,t:1528139592324};\\\", \\\"{x:489,y:760,t:1528139592339};\\\", \\\"{x:465,y:776,t:1528139592355};\\\", \\\"{x:421,y:793,t:1528139592371};\\\", \\\"{x:280,y:833,t:1528139592389};\\\", \\\"{x:141,y:854,t:1528139592406};\\\", \\\"{x:0,y:876,t:1528139592421};\\\", \\\"{x:0,y:890,t:1528139592438};\\\", \\\"{x:0,y:882,t:1528139592459};\\\", \\\"{x:0,y:869,t:1528139592472};\\\", \\\"{x:0,y:855,t:1528139592488};\\\", \\\"{x:0,y:847,t:1528139592505};\\\", \\\"{x:0,y:835,t:1528139592522};\\\", \\\"{x:0,y:820,t:1528139592538};\\\", \\\"{x:0,y:810,t:1528139592554};\\\", \\\"{x:0,y:795,t:1528139592572};\\\", \\\"{x:0,y:776,t:1528139592588};\\\", \\\"{x:0,y:745,t:1528139592605};\\\", \\\"{x:0,y:704,t:1528139592622};\\\", \\\"{x:0,y:666,t:1528139592638};\\\", \\\"{x:0,y:641,t:1528139592655};\\\", \\\"{x:0,y:619,t:1528139592672};\\\", \\\"{x:0,y:601,t:1528139592688};\\\", \\\"{x:0,y:576,t:1528139592705};\\\", \\\"{x:0,y:542,t:1528139592722};\\\", \\\"{x:0,y:510,t:1528139592738};\\\", \\\"{x:0,y:479,t:1528139592754};\\\", \\\"{x:0,y:439,t:1528139592772};\\\", \\\"{x:0,y:415,t:1528139592789};\\\", \\\"{x:0,y:403,t:1528139592805};\\\", \\\"{x:0,y:398,t:1528139592822};\\\", \\\"{x:0,y:394,t:1528139592838};\\\", \\\"{x:0,y:393,t:1528139592876};\\\", \\\"{x:0,y:391,t:1528139592888};\\\", \\\"{x:0,y:387,t:1528139592905};\\\", \\\"{x:1,y:380,t:1528139592923};\\\", \\\"{x:4,y:371,t:1528139592938};\\\", \\\"{x:6,y:367,t:1528139592955};\\\", \\\"{x:12,y:356,t:1528139592972};\\\", \\\"{x:24,y:339,t:1528139592988};\\\", \\\"{x:39,y:322,t:1528139593005};\\\", \\\"{x:54,y:305,t:1528139593023};\\\", \\\"{x:76,y:289,t:1528139593038};\\\", \\\"{x:97,y:274,t:1528139593055};\\\", \\\"{x:264,y:213,t:1528139593106};\\\", \\\"{x:377,y:182,t:1528139593122};\\\", \\\"{x:545,y:139,t:1528139593139};\\\", \\\"{x:763,y:109,t:1528139593154};\\\", \\\"{x:1180,y:78,t:1528139593172};\\\" ] }, { \\\"rt\\\": 34113, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 556653, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -Z -Z -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:83,t:1528139593306};\\\", \\\"{x:1919,y:84,t:1528139593322};\\\", \\\"{x:1919,y:85,t:1528139593339};\\\", \\\"{x:1919,y:80,t:1528139593371};\\\", \\\"{x:1919,y:73,t:1528139593379};\\\", \\\"{x:1919,y:63,t:1528139593388};\\\", \\\"{x:1919,y:27,t:1528139593409};\\\", \\\"{x:1919,y:16,t:1528139593423};\\\", \\\"{x:1919,y:19,t:1528139593524};\\\", \\\"{x:1919,y:21,t:1528139593538};\\\", \\\"{x:1919,y:23,t:1528139593563};\\\", \\\"{x:1919,y:27,t:1528139593587};\\\", \\\"{x:1919,y:28,t:1528139593596};\\\", \\\"{x:1919,y:33,t:1528139593606};\\\", \\\"{x:1910,y:41,t:1528139593623};\\\", \\\"{x:1882,y:53,t:1528139593639};\\\", \\\"{x:1833,y:72,t:1528139593656};\\\", \\\"{x:1772,y:102,t:1528139593673};\\\", \\\"{x:1685,y:133,t:1528139593689};\\\", \\\"{x:1580,y:161,t:1528139593707};\\\", \\\"{x:1450,y:195,t:1528139593723};\\\", \\\"{x:1302,y:230,t:1528139593740};\\\", \\\"{x:1040,y:270,t:1528139593756};\\\", \\\"{x:847,y:295,t:1528139593773};\\\", \\\"{x:650,y:298,t:1528139593789};\\\", \\\"{x:474,y:298,t:1528139593807};\\\", \\\"{x:0,y:238,t:1528139593895};\\\", \\\"{x:0,y:233,t:1528139593906};\\\", \\\"{x:0,y:219,t:1528139593923};\\\", \\\"{x:0,y:217,t:1528139593940};\\\", \\\"{x:0,y:216,t:1528139593955};\\\", \\\"{x:9,y:216,t:1528139594131};\\\", \\\"{x:19,y:216,t:1528139594140};\\\", \\\"{x:44,y:216,t:1528139594156};\\\", \\\"{x:93,y:208,t:1528139594173};\\\", \\\"{x:183,y:205,t:1528139594190};\\\", \\\"{x:333,y:200,t:1528139594206};\\\", \\\"{x:545,y:200,t:1528139594223};\\\", \\\"{x:805,y:200,t:1528139594240};\\\", \\\"{x:1089,y:204,t:1528139594256};\\\", \\\"{x:1327,y:237,t:1528139594273};\\\", \\\"{x:1518,y:269,t:1528139594290};\\\", \\\"{x:1689,y:312,t:1528139594307};\\\", \\\"{x:1740,y:338,t:1528139594323};\\\", \\\"{x:1761,y:361,t:1528139594341};\\\", \\\"{x:1765,y:380,t:1528139594358};\\\", \\\"{x:1765,y:402,t:1528139594373};\\\", \\\"{x:1762,y:427,t:1528139594390};\\\", \\\"{x:1747,y:450,t:1528139594406};\\\", \\\"{x:1722,y:477,t:1528139594423};\\\", \\\"{x:1672,y:513,t:1528139594440};\\\", \\\"{x:1610,y:544,t:1528139594457};\\\", \\\"{x:1536,y:574,t:1528139594473};\\\", \\\"{x:1445,y:611,t:1528139594491};\\\", \\\"{x:1284,y:662,t:1528139594508};\\\", \\\"{x:1229,y:677,t:1528139594523};\\\", \\\"{x:1013,y:740,t:1528139594540};\\\", \\\"{x:844,y:792,t:1528139594557};\\\", \\\"{x:674,y:827,t:1528139594573};\\\", \\\"{x:522,y:849,t:1528139594590};\\\", \\\"{x:358,y:873,t:1528139594607};\\\", \\\"{x:193,y:896,t:1528139594623};\\\", \\\"{x:25,y:909,t:1528139594640};\\\", \\\"{x:0,y:924,t:1528139594658};\\\", \\\"{x:0,y:926,t:1528139594674};\\\", \\\"{x:0,y:925,t:1528139594692};\\\", \\\"{x:0,y:918,t:1528139594707};\\\", \\\"{x:0,y:910,t:1528139594724};\\\", \\\"{x:0,y:905,t:1528139594740};\\\", \\\"{x:0,y:902,t:1528139594757};\\\", \\\"{x:0,y:901,t:1528139594774};\\\", \\\"{x:0,y:898,t:1528139594791};\\\", \\\"{x:0,y:892,t:1528139594807};\\\", \\\"{x:0,y:885,t:1528139594825};\\\", \\\"{x:5,y:876,t:1528139594841};\\\", \\\"{x:18,y:862,t:1528139594857};\\\", \\\"{x:40,y:846,t:1528139594874};\\\", \\\"{x:85,y:825,t:1528139594890};\\\", \\\"{x:180,y:784,t:1528139594908};\\\", \\\"{x:279,y:746,t:1528139594924};\\\", \\\"{x:394,y:704,t:1528139594940};\\\", \\\"{x:507,y:688,t:1528139594957};\\\", \\\"{x:628,y:676,t:1528139594976};\\\", \\\"{x:756,y:674,t:1528139594990};\\\", \\\"{x:986,y:672,t:1528139595023};\\\", \\\"{x:1083,y:672,t:1528139595040};\\\", \\\"{x:1147,y:672,t:1528139595057};\\\", \\\"{x:1191,y:677,t:1528139595073};\\\", \\\"{x:1218,y:684,t:1528139595090};\\\", \\\"{x:1237,y:693,t:1528139595107};\\\", \\\"{x:1242,y:694,t:1528139595123};\\\", \\\"{x:1246,y:697,t:1528139595140};\\\", \\\"{x:1250,y:697,t:1528139595157};\\\", \\\"{x:1250,y:698,t:1528139595180};\\\", \\\"{x:1250,y:699,t:1528139595203};\\\", \\\"{x:1251,y:704,t:1528139595211};\\\", \\\"{x:1253,y:709,t:1528139595223};\\\", \\\"{x:1256,y:724,t:1528139595240};\\\", \\\"{x:1257,y:739,t:1528139595257};\\\", \\\"{x:1257,y:757,t:1528139595273};\\\", \\\"{x:1257,y:774,t:1528139595290};\\\", \\\"{x:1257,y:804,t:1528139595307};\\\", \\\"{x:1254,y:827,t:1528139595323};\\\", \\\"{x:1253,y:842,t:1528139595340};\\\", \\\"{x:1253,y:849,t:1528139595357};\\\", \\\"{x:1253,y:852,t:1528139595374};\\\", \\\"{x:1253,y:853,t:1528139595390};\\\", \\\"{x:1253,y:856,t:1528139595407};\\\", \\\"{x:1258,y:865,t:1528139595424};\\\", \\\"{x:1261,y:880,t:1528139595440};\\\", \\\"{x:1268,y:892,t:1528139595457};\\\", \\\"{x:1274,y:908,t:1528139595474};\\\", \\\"{x:1282,y:922,t:1528139595490};\\\", \\\"{x:1286,y:934,t:1528139595507};\\\", \\\"{x:1287,y:935,t:1528139595524};\\\", \\\"{x:1288,y:936,t:1528139595540};\\\", \\\"{x:1288,y:935,t:1528139596100};\\\", \\\"{x:1289,y:933,t:1528139596108};\\\", \\\"{x:1290,y:931,t:1528139596124};\\\", \\\"{x:1292,y:928,t:1528139596141};\\\", \\\"{x:1295,y:924,t:1528139596157};\\\", \\\"{x:1297,y:921,t:1528139596174};\\\", \\\"{x:1299,y:916,t:1528139596191};\\\", \\\"{x:1300,y:914,t:1528139596207};\\\", \\\"{x:1302,y:911,t:1528139596224};\\\", \\\"{x:1303,y:910,t:1528139596241};\\\", \\\"{x:1303,y:909,t:1528139596267};\\\", \\\"{x:1303,y:908,t:1528139596275};\\\", \\\"{x:1303,y:907,t:1528139596292};\\\", \\\"{x:1303,y:899,t:1528139596308};\\\", \\\"{x:1303,y:890,t:1528139596324};\\\", \\\"{x:1303,y:882,t:1528139596341};\\\", \\\"{x:1303,y:875,t:1528139596357};\\\", \\\"{x:1303,y:870,t:1528139596375};\\\", \\\"{x:1303,y:867,t:1528139596391};\\\", \\\"{x:1303,y:866,t:1528139596412};\\\", \\\"{x:1303,y:865,t:1528139596436};\\\", \\\"{x:1303,y:864,t:1528139596468};\\\", \\\"{x:1303,y:862,t:1528139596484};\\\", \\\"{x:1303,y:860,t:1528139596492};\\\", \\\"{x:1303,y:854,t:1528139596508};\\\", \\\"{x:1303,y:851,t:1528139596524};\\\", \\\"{x:1303,y:847,t:1528139596541};\\\", \\\"{x:1303,y:837,t:1528139596557};\\\", \\\"{x:1303,y:831,t:1528139596575};\\\", \\\"{x:1307,y:818,t:1528139596592};\\\", \\\"{x:1313,y:800,t:1528139596607};\\\", \\\"{x:1318,y:780,t:1528139596624};\\\", \\\"{x:1322,y:766,t:1528139596642};\\\", \\\"{x:1328,y:749,t:1528139596657};\\\", \\\"{x:1331,y:736,t:1528139596675};\\\", \\\"{x:1334,y:722,t:1528139596692};\\\", \\\"{x:1338,y:716,t:1528139596709};\\\", \\\"{x:1339,y:711,t:1528139596725};\\\", \\\"{x:1343,y:707,t:1528139596742};\\\", \\\"{x:1346,y:703,t:1528139596759};\\\", \\\"{x:1346,y:700,t:1528139596775};\\\", \\\"{x:1348,y:697,t:1528139596792};\\\", \\\"{x:1350,y:694,t:1528139596809};\\\", \\\"{x:1353,y:691,t:1528139596824};\\\", \\\"{x:1356,y:688,t:1528139596841};\\\", \\\"{x:1357,y:687,t:1528139596859};\\\", \\\"{x:1357,y:686,t:1528139596924};\\\", \\\"{x:1357,y:684,t:1528139596942};\\\", \\\"{x:1357,y:681,t:1528139596958};\\\", \\\"{x:1357,y:679,t:1528139596974};\\\", \\\"{x:1359,y:679,t:1528139597092};\\\", \\\"{x:1367,y:690,t:1528139597108};\\\", \\\"{x:1375,y:705,t:1528139597125};\\\", \\\"{x:1382,y:717,t:1528139597142};\\\", \\\"{x:1391,y:730,t:1528139597159};\\\", \\\"{x:1393,y:735,t:1528139597175};\\\", \\\"{x:1395,y:738,t:1528139597191};\\\", \\\"{x:1395,y:739,t:1528139597208};\\\", \\\"{x:1395,y:737,t:1528139597365};\\\", \\\"{x:1394,y:733,t:1528139597376};\\\", \\\"{x:1392,y:719,t:1528139597392};\\\", \\\"{x:1391,y:688,t:1528139597408};\\\", \\\"{x:1386,y:652,t:1528139597426};\\\", \\\"{x:1378,y:596,t:1528139597441};\\\", \\\"{x:1368,y:537,t:1528139597458};\\\", \\\"{x:1333,y:479,t:1528139597475};\\\", \\\"{x:1322,y:452,t:1528139597491};\\\", \\\"{x:1322,y:451,t:1528139597627};\\\", \\\"{x:1325,y:451,t:1528139597641};\\\", \\\"{x:1331,y:451,t:1528139597658};\\\", \\\"{x:1344,y:454,t:1528139597675};\\\", \\\"{x:1348,y:456,t:1528139597691};\\\", \\\"{x:1354,y:457,t:1528139597708};\\\", \\\"{x:1358,y:457,t:1528139597725};\\\", \\\"{x:1361,y:457,t:1528139597741};\\\", \\\"{x:1362,y:457,t:1528139597758};\\\", \\\"{x:1365,y:459,t:1528139597775};\\\", \\\"{x:1368,y:459,t:1528139597791};\\\", \\\"{x:1370,y:459,t:1528139597808};\\\", \\\"{x:1371,y:459,t:1528139597835};\\\", \\\"{x:1371,y:460,t:1528139597876};\\\", \\\"{x:1372,y:460,t:1528139597900};\\\", \\\"{x:1374,y:465,t:1528139597916};\\\", \\\"{x:1375,y:467,t:1528139597925};\\\", \\\"{x:1377,y:476,t:1528139597943};\\\", \\\"{x:1380,y:485,t:1528139597958};\\\", \\\"{x:1380,y:492,t:1528139597975};\\\", \\\"{x:1381,y:502,t:1528139597993};\\\", \\\"{x:1383,y:511,t:1528139598008};\\\", \\\"{x:1383,y:523,t:1528139598025};\\\", \\\"{x:1382,y:540,t:1528139598042};\\\", \\\"{x:1379,y:557,t:1528139598059};\\\", \\\"{x:1371,y:584,t:1528139598076};\\\", \\\"{x:1363,y:600,t:1528139598092};\\\", \\\"{x:1354,y:616,t:1528139598109};\\\", \\\"{x:1349,y:629,t:1528139598126};\\\", \\\"{x:1344,y:637,t:1528139598143};\\\", \\\"{x:1341,y:645,t:1528139598159};\\\", \\\"{x:1340,y:650,t:1528139598175};\\\", \\\"{x:1337,y:664,t:1528139598193};\\\", \\\"{x:1337,y:684,t:1528139598209};\\\", \\\"{x:1337,y:711,t:1528139598225};\\\", \\\"{x:1347,y:752,t:1528139598243};\\\", \\\"{x:1360,y:792,t:1528139598258};\\\", \\\"{x:1368,y:826,t:1528139598276};\\\", \\\"{x:1370,y:840,t:1528139598292};\\\", \\\"{x:1373,y:855,t:1528139598309};\\\", \\\"{x:1377,y:867,t:1528139598326};\\\", \\\"{x:1379,y:873,t:1528139598343};\\\", \\\"{x:1380,y:874,t:1528139598359};\\\", \\\"{x:1382,y:877,t:1528139598376};\\\", \\\"{x:1383,y:879,t:1528139598393};\\\", \\\"{x:1383,y:881,t:1528139598408};\\\", \\\"{x:1383,y:882,t:1528139598426};\\\", \\\"{x:1383,y:883,t:1528139598443};\\\", \\\"{x:1383,y:884,t:1528139598459};\\\", \\\"{x:1373,y:885,t:1528139598476};\\\", \\\"{x:1352,y:880,t:1528139598493};\\\", \\\"{x:1344,y:880,t:1528139598509};\\\", \\\"{x:1344,y:882,t:1528139598797};\\\", \\\"{x:1344,y:884,t:1528139598810};\\\", \\\"{x:1349,y:897,t:1528139598833};\\\", \\\"{x:1373,y:922,t:1528139598860};\\\", \\\"{x:1383,y:925,t:1528139598875};\\\", \\\"{x:1396,y:928,t:1528139598893};\\\", \\\"{x:1409,y:929,t:1528139598910};\\\", \\\"{x:1420,y:929,t:1528139598926};\\\", \\\"{x:1424,y:929,t:1528139598943};\\\", \\\"{x:1428,y:929,t:1528139598960};\\\", \\\"{x:1430,y:929,t:1528139598977};\\\", \\\"{x:1432,y:929,t:1528139598993};\\\", \\\"{x:1440,y:924,t:1528139599010};\\\", \\\"{x:1459,y:913,t:1528139599027};\\\", \\\"{x:1480,y:900,t:1528139599043};\\\", \\\"{x:1505,y:888,t:1528139599060};\\\", \\\"{x:1534,y:867,t:1528139599077};\\\", \\\"{x:1560,y:846,t:1528139599093};\\\", \\\"{x:1594,y:822,t:1528139599110};\\\", \\\"{x:1625,y:802,t:1528139599127};\\\", \\\"{x:1660,y:781,t:1528139599143};\\\", \\\"{x:1685,y:765,t:1528139599160};\\\", \\\"{x:1702,y:753,t:1528139599177};\\\", \\\"{x:1717,y:744,t:1528139599193};\\\", \\\"{x:1730,y:738,t:1528139599210};\\\", \\\"{x:1736,y:737,t:1528139599227};\\\", \\\"{x:1738,y:736,t:1528139599243};\\\", \\\"{x:1738,y:735,t:1528139599260};\\\", \\\"{x:1739,y:735,t:1528139599277};\\\", \\\"{x:1742,y:735,t:1528139599293};\\\", \\\"{x:1743,y:735,t:1528139599310};\\\", \\\"{x:1744,y:735,t:1528139599327};\\\", \\\"{x:1745,y:735,t:1528139599348};\\\", \\\"{x:1743,y:735,t:1528139599509};\\\", \\\"{x:1741,y:735,t:1528139599516};\\\", \\\"{x:1737,y:735,t:1528139599528};\\\", \\\"{x:1726,y:735,t:1528139599545};\\\", \\\"{x:1709,y:733,t:1528139599560};\\\", \\\"{x:1687,y:723,t:1528139599577};\\\", \\\"{x:1669,y:712,t:1528139599595};\\\", \\\"{x:1660,y:703,t:1528139599610};\\\", \\\"{x:1655,y:689,t:1528139599628};\\\", \\\"{x:1651,y:677,t:1528139599644};\\\", \\\"{x:1648,y:659,t:1528139599660};\\\", \\\"{x:1645,y:635,t:1528139599678};\\\", \\\"{x:1641,y:592,t:1528139599695};\\\", \\\"{x:1641,y:558,t:1528139599710};\\\", \\\"{x:1647,y:517,t:1528139599728};\\\", \\\"{x:1659,y:494,t:1528139599745};\\\", \\\"{x:1668,y:477,t:1528139599760};\\\", \\\"{x:1676,y:459,t:1528139599777};\\\", \\\"{x:1680,y:451,t:1528139599794};\\\", \\\"{x:1683,y:445,t:1528139599810};\\\", \\\"{x:1684,y:439,t:1528139599828};\\\", \\\"{x:1684,y:436,t:1528139599845};\\\", \\\"{x:1684,y:434,t:1528139599860};\\\", \\\"{x:1684,y:433,t:1528139599884};\\\", \\\"{x:1683,y:433,t:1528139599916};\\\", \\\"{x:1679,y:433,t:1528139599928};\\\", \\\"{x:1673,y:433,t:1528139599945};\\\", \\\"{x:1667,y:433,t:1528139599962};\\\", \\\"{x:1663,y:433,t:1528139599977};\\\", \\\"{x:1660,y:433,t:1528139599995};\\\", \\\"{x:1655,y:433,t:1528139600012};\\\", \\\"{x:1652,y:433,t:1528139600028};\\\", \\\"{x:1647,y:434,t:1528139600045};\\\", \\\"{x:1636,y:438,t:1528139600062};\\\", \\\"{x:1630,y:440,t:1528139600078};\\\", \\\"{x:1628,y:442,t:1528139600095};\\\", \\\"{x:1626,y:442,t:1528139600196};\\\", \\\"{x:1625,y:442,t:1528139600428};\\\", \\\"{x:1624,y:440,t:1528139600445};\\\", \\\"{x:1624,y:439,t:1528139600468};\\\", \\\"{x:1624,y:438,t:1528139600479};\\\", \\\"{x:1624,y:435,t:1528139600495};\\\", \\\"{x:1624,y:434,t:1528139600512};\\\", \\\"{x:1624,y:433,t:1528139600529};\\\", \\\"{x:1623,y:432,t:1528139600545};\\\", \\\"{x:1622,y:432,t:1528139600604};\\\", \\\"{x:1621,y:432,t:1528139600611};\\\", \\\"{x:1620,y:432,t:1528139600628};\\\", \\\"{x:1619,y:432,t:1528139600676};\\\", \\\"{x:1618,y:432,t:1528139600694};\\\", \\\"{x:1617,y:432,t:1528139600711};\\\", \\\"{x:1616,y:432,t:1528139600728};\\\", \\\"{x:1614,y:432,t:1528139600745};\\\", \\\"{x:1613,y:432,t:1528139600763};\\\", \\\"{x:1609,y:432,t:1528139624767};\\\", \\\"{x:1588,y:419,t:1528139624777};\\\", \\\"{x:1480,y:209,t:1528139624802};\\\", \\\"{x:1423,y:92,t:1528139624818};\\\", \\\"{x:1383,y:16,t:1528139624835};\\\", \\\"{x:1333,y:16,t:1528139624850};\\\", \\\"{x:1268,y:16,t:1528139624867};\\\", \\\"{x:1200,y:16,t:1528139624884};\\\", \\\"{x:1153,y:16,t:1528139624900};\\\", \\\"{x:1142,y:16,t:1528139624918};\\\", \\\"{x:1135,y:16,t:1528139624933};\\\", \\\"{x:1127,y:18,t:1528139624950};\\\", \\\"{x:1109,y:26,t:1528139624968};\\\", \\\"{x:1088,y:39,t:1528139624984};\\\", \\\"{x:1067,y:58,t:1528139625000};\\\", \\\"{x:1047,y:73,t:1528139625017};\\\", \\\"{x:1032,y:87,t:1528139625035};\\\", \\\"{x:1008,y:103,t:1528139625050};\\\", \\\"{x:982,y:118,t:1528139625068};\\\", \\\"{x:936,y:141,t:1528139625085};\\\", \\\"{x:872,y:172,t:1528139625101};\\\", \\\"{x:790,y:206,t:1528139625117};\\\", \\\"{x:672,y:263,t:1528139625134};\\\", \\\"{x:586,y:317,t:1528139625152};\\\", \\\"{x:496,y:372,t:1528139625168};\\\", \\\"{x:412,y:433,t:1528139625185};\\\", \\\"{x:336,y:492,t:1528139625202};\\\", \\\"{x:270,y:546,t:1528139625219};\\\", \\\"{x:207,y:613,t:1528139625236};\\\", \\\"{x:161,y:661,t:1528139625252};\\\", \\\"{x:133,y:696,t:1528139625268};\\\", \\\"{x:118,y:723,t:1528139625284};\\\", \\\"{x:114,y:742,t:1528139625301};\\\", \\\"{x:114,y:751,t:1528139625317};\\\", \\\"{x:115,y:753,t:1528139625335};\\\", \\\"{x:117,y:753,t:1528139625351};\\\", \\\"{x:120,y:753,t:1528139625367};\\\", \\\"{x:122,y:753,t:1528139625398};\\\", \\\"{x:124,y:752,t:1528139625406};\\\", \\\"{x:127,y:751,t:1528139625419};\\\", \\\"{x:134,y:747,t:1528139625435};\\\", \\\"{x:142,y:741,t:1528139625452};\\\", \\\"{x:151,y:733,t:1528139625468};\\\", \\\"{x:157,y:726,t:1528139625485};\\\", \\\"{x:160,y:722,t:1528139625502};\\\", \\\"{x:165,y:715,t:1528139625518};\\\", \\\"{x:168,y:708,t:1528139625535};\\\", \\\"{x:170,y:703,t:1528139625551};\\\", \\\"{x:172,y:698,t:1528139625569};\\\", \\\"{x:174,y:693,t:1528139625584};\\\", \\\"{x:176,y:690,t:1528139625602};\\\", \\\"{x:178,y:687,t:1528139625619};\\\", \\\"{x:182,y:685,t:1528139625636};\\\", \\\"{x:197,y:678,t:1528139625652};\\\", \\\"{x:216,y:670,t:1528139625668};\\\", \\\"{x:238,y:664,t:1528139625684};\\\", \\\"{x:294,y:657,t:1528139625702};\\\", \\\"{x:412,y:639,t:1528139625718};\\\", \\\"{x:479,y:630,t:1528139625735};\\\", \\\"{x:535,y:622,t:1528139625752};\\\", \\\"{x:569,y:621,t:1528139625768};\\\", \\\"{x:594,y:619,t:1528139625784};\\\", \\\"{x:604,y:619,t:1528139625801};\\\", \\\"{x:606,y:619,t:1528139625819};\\\", \\\"{x:607,y:618,t:1528139625982};\\\", \\\"{x:599,y:616,t:1528139625992};\\\", \\\"{x:570,y:611,t:1528139626001};\\\", \\\"{x:464,y:595,t:1528139626020};\\\", \\\"{x:356,y:583,t:1528139626035};\\\", \\\"{x:265,y:583,t:1528139626052};\\\", \\\"{x:217,y:583,t:1528139626068};\\\", \\\"{x:201,y:583,t:1528139626086};\\\", \\\"{x:200,y:583,t:1528139626309};\\\", \\\"{x:196,y:583,t:1528139626318};\\\", \\\"{x:181,y:590,t:1528139626336};\\\", \\\"{x:169,y:593,t:1528139626353};\\\", \\\"{x:160,y:595,t:1528139626369};\\\", \\\"{x:152,y:598,t:1528139626385};\\\", \\\"{x:152,y:599,t:1528139626725};\\\", \\\"{x:155,y:602,t:1528139626741};\\\", \\\"{x:169,y:603,t:1528139626752};\\\", \\\"{x:242,y:622,t:1528139626770};\\\", \\\"{x:366,y:652,t:1528139626786};\\\", \\\"{x:465,y:680,t:1528139626802};\\\", \\\"{x:554,y:703,t:1528139626819};\\\", \\\"{x:591,y:717,t:1528139626835};\\\", \\\"{x:603,y:721,t:1528139626852};\\\", \\\"{x:603,y:723,t:1528139627031};\\\", \\\"{x:599,y:724,t:1528139627039};\\\", \\\"{x:591,y:725,t:1528139627052};\\\", \\\"{x:565,y:726,t:1528139627069};\\\", \\\"{x:534,y:732,t:1528139627086};\\\", \\\"{x:517,y:738,t:1528139627102};\\\", \\\"{x:510,y:741,t:1528139627118};\\\", \\\"{x:510,y:742,t:1528139627223};\\\", \\\"{x:510,y:743,t:1528139627295};\\\" ] }, { \\\"rt\\\": 9518, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 567405, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -G -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:739,t:1528139629269};\\\", \\\"{x:513,y:734,t:1528139629278};\\\", \\\"{x:513,y:730,t:1528139629288};\\\", \\\"{x:515,y:719,t:1528139629305};\\\", \\\"{x:517,y:709,t:1528139629322};\\\", \\\"{x:519,y:703,t:1528139629338};\\\", \\\"{x:522,y:694,t:1528139629354};\\\", \\\"{x:527,y:685,t:1528139629373};\\\", \\\"{x:531,y:674,t:1528139629388};\\\", \\\"{x:537,y:661,t:1528139629404};\\\", \\\"{x:549,y:646,t:1528139629423};\\\", \\\"{x:556,y:639,t:1528139629438};\\\", \\\"{x:560,y:633,t:1528139629454};\\\", \\\"{x:563,y:631,t:1528139629471};\\\", \\\"{x:564,y:630,t:1528139629488};\\\", \\\"{x:565,y:629,t:1528139629505};\\\", \\\"{x:566,y:628,t:1528139629521};\\\", \\\"{x:567,y:627,t:1528139629538};\\\", \\\"{x:567,y:626,t:1528139629558};\\\", \\\"{x:567,y:625,t:1528139629572};\\\", \\\"{x:568,y:624,t:1528139629588};\\\", \\\"{x:570,y:623,t:1528139629703};\\\", \\\"{x:576,y:622,t:1528139629710};\\\", \\\"{x:579,y:619,t:1528139629722};\\\", \\\"{x:587,y:617,t:1528139629740};\\\", \\\"{x:589,y:615,t:1528139629755};\\\", \\\"{x:590,y:615,t:1528139629774};\\\", \\\"{x:591,y:615,t:1528139629839};\\\", \\\"{x:605,y:610,t:1528139629856};\\\", \\\"{x:628,y:605,t:1528139629871};\\\", \\\"{x:656,y:598,t:1528139629888};\\\", \\\"{x:686,y:591,t:1528139629905};\\\", \\\"{x:715,y:581,t:1528139629921};\\\", \\\"{x:741,y:574,t:1528139629939};\\\", \\\"{x:782,y:561,t:1528139629955};\\\", \\\"{x:823,y:551,t:1528139629972};\\\", \\\"{x:865,y:538,t:1528139629989};\\\", \\\"{x:918,y:524,t:1528139630005};\\\", \\\"{x:1011,y:512,t:1528139630022};\\\", \\\"{x:1100,y:499,t:1528139630038};\\\", \\\"{x:1200,y:485,t:1528139630055};\\\", \\\"{x:1308,y:469,t:1528139630072};\\\", \\\"{x:1419,y:455,t:1528139630089};\\\", \\\"{x:1530,y:439,t:1528139630105};\\\", \\\"{x:1635,y:425,t:1528139630122};\\\", \\\"{x:1716,y:414,t:1528139630139};\\\", \\\"{x:1769,y:406,t:1528139630156};\\\", \\\"{x:1787,y:403,t:1528139630172};\\\", \\\"{x:1792,y:402,t:1528139630189};\\\", \\\"{x:1793,y:402,t:1528139630351};\\\", \\\"{x:1793,y:408,t:1528139630358};\\\", \\\"{x:1786,y:418,t:1528139630372};\\\", \\\"{x:1776,y:432,t:1528139630389};\\\", \\\"{x:1760,y:452,t:1528139630406};\\\", \\\"{x:1753,y:461,t:1528139630422};\\\", \\\"{x:1739,y:478,t:1528139630439};\\\", \\\"{x:1732,y:487,t:1528139630456};\\\", \\\"{x:1726,y:494,t:1528139630472};\\\", \\\"{x:1719,y:501,t:1528139630489};\\\", \\\"{x:1710,y:512,t:1528139630506};\\\", \\\"{x:1703,y:519,t:1528139630522};\\\", \\\"{x:1691,y:527,t:1528139630539};\\\", \\\"{x:1682,y:532,t:1528139630556};\\\", \\\"{x:1678,y:535,t:1528139630573};\\\", \\\"{x:1669,y:539,t:1528139630589};\\\", \\\"{x:1654,y:546,t:1528139630606};\\\", \\\"{x:1633,y:555,t:1528139630623};\\\", \\\"{x:1616,y:560,t:1528139630644};\\\", \\\"{x:1599,y:566,t:1528139630657};\\\", \\\"{x:1581,y:569,t:1528139630673};\\\", \\\"{x:1555,y:576,t:1528139630688};\\\", \\\"{x:1526,y:584,t:1528139630706};\\\", \\\"{x:1498,y:589,t:1528139630722};\\\", \\\"{x:1471,y:594,t:1528139630739};\\\", \\\"{x:1454,y:599,t:1528139630756};\\\", \\\"{x:1446,y:601,t:1528139630773};\\\", \\\"{x:1440,y:602,t:1528139630788};\\\", \\\"{x:1434,y:605,t:1528139630806};\\\", \\\"{x:1432,y:605,t:1528139630822};\\\", \\\"{x:1432,y:606,t:1528139630911};\\\", \\\"{x:1434,y:607,t:1528139631279};\\\", \\\"{x:1443,y:607,t:1528139631290};\\\", \\\"{x:1458,y:607,t:1528139631307};\\\", \\\"{x:1469,y:608,t:1528139631323};\\\", \\\"{x:1476,y:610,t:1528139631340};\\\", \\\"{x:1483,y:616,t:1528139631356};\\\", \\\"{x:1491,y:627,t:1528139631374};\\\", \\\"{x:1497,y:651,t:1528139631390};\\\", \\\"{x:1497,y:677,t:1528139631407};\\\", \\\"{x:1496,y:708,t:1528139631423};\\\", \\\"{x:1490,y:735,t:1528139631441};\\\", \\\"{x:1483,y:760,t:1528139631457};\\\", \\\"{x:1478,y:771,t:1528139631473};\\\", \\\"{x:1474,y:775,t:1528139631490};\\\", \\\"{x:1474,y:777,t:1528139631506};\\\", \\\"{x:1474,y:780,t:1528139631523};\\\", \\\"{x:1475,y:784,t:1528139631540};\\\", \\\"{x:1475,y:785,t:1528139631557};\\\", \\\"{x:1475,y:787,t:1528139631573};\\\", \\\"{x:1475,y:788,t:1528139631590};\\\", \\\"{x:1476,y:789,t:1528139631727};\\\", \\\"{x:1477,y:790,t:1528139631776};\\\", \\\"{x:1472,y:793,t:1528139631790};\\\", \\\"{x:1451,y:795,t:1528139631807};\\\", \\\"{x:1428,y:795,t:1528139631824};\\\", \\\"{x:1409,y:795,t:1528139631840};\\\", \\\"{x:1399,y:795,t:1528139631857};\\\", \\\"{x:1397,y:795,t:1528139631873};\\\", \\\"{x:1396,y:795,t:1528139632024};\\\", \\\"{x:1396,y:793,t:1528139632079};\\\", \\\"{x:1396,y:792,t:1528139632090};\\\", \\\"{x:1396,y:790,t:1528139632107};\\\", \\\"{x:1396,y:785,t:1528139632125};\\\", \\\"{x:1401,y:781,t:1528139632141};\\\", \\\"{x:1409,y:777,t:1528139632157};\\\", \\\"{x:1438,y:771,t:1528139632174};\\\", \\\"{x:1464,y:769,t:1528139632189};\\\", \\\"{x:1492,y:767,t:1528139632206};\\\", \\\"{x:1523,y:767,t:1528139632223};\\\", \\\"{x:1561,y:767,t:1528139632240};\\\", \\\"{x:1591,y:767,t:1528139632257};\\\", \\\"{x:1614,y:767,t:1528139632274};\\\", \\\"{x:1633,y:767,t:1528139632290};\\\", \\\"{x:1648,y:767,t:1528139632309};\\\", \\\"{x:1660,y:767,t:1528139632325};\\\", \\\"{x:1663,y:767,t:1528139632374};\\\", \\\"{x:1660,y:767,t:1528139632454};\\\", \\\"{x:1649,y:767,t:1528139632463};\\\", \\\"{x:1635,y:768,t:1528139632474};\\\", \\\"{x:1605,y:778,t:1528139632490};\\\", \\\"{x:1580,y:785,t:1528139632507};\\\", \\\"{x:1548,y:792,t:1528139632523};\\\", \\\"{x:1514,y:804,t:1528139632541};\\\", \\\"{x:1486,y:811,t:1528139632557};\\\", \\\"{x:1451,y:821,t:1528139632574};\\\", \\\"{x:1436,y:826,t:1528139632590};\\\", \\\"{x:1421,y:829,t:1528139632607};\\\", \\\"{x:1407,y:833,t:1528139632624};\\\", \\\"{x:1391,y:836,t:1528139632641};\\\", \\\"{x:1377,y:838,t:1528139632658};\\\", \\\"{x:1370,y:840,t:1528139632674};\\\", \\\"{x:1369,y:840,t:1528139632691};\\\", \\\"{x:1367,y:840,t:1528139632768};\\\", \\\"{x:1361,y:841,t:1528139632774};\\\", \\\"{x:1345,y:843,t:1528139632791};\\\", \\\"{x:1333,y:845,t:1528139632808};\\\", \\\"{x:1323,y:846,t:1528139632824};\\\", \\\"{x:1312,y:847,t:1528139632842};\\\", \\\"{x:1302,y:847,t:1528139632858};\\\", \\\"{x:1287,y:847,t:1528139632874};\\\", \\\"{x:1265,y:847,t:1528139632891};\\\", \\\"{x:1246,y:844,t:1528139632909};\\\", \\\"{x:1226,y:841,t:1528139632924};\\\", \\\"{x:1211,y:840,t:1528139632941};\\\", \\\"{x:1204,y:837,t:1528139632958};\\\", \\\"{x:1204,y:835,t:1528139633287};\\\", \\\"{x:1208,y:831,t:1528139633294};\\\", \\\"{x:1214,y:828,t:1528139633311};\\\", \\\"{x:1219,y:827,t:1528139633325};\\\", \\\"{x:1220,y:827,t:1528139633341};\\\", \\\"{x:1221,y:826,t:1528139633358};\\\", \\\"{x:1221,y:827,t:1528139634199};\\\", \\\"{x:1221,y:828,t:1528139634230};\\\", \\\"{x:1221,y:830,t:1528139634247};\\\", \\\"{x:1213,y:830,t:1528139634932};\\\", \\\"{x:1106,y:813,t:1528139634942};\\\", \\\"{x:1047,y:806,t:1528139634957};\\\", \\\"{x:901,y:783,t:1528139634974};\\\", \\\"{x:839,y:775,t:1528139634991};\\\", \\\"{x:785,y:765,t:1528139635007};\\\", \\\"{x:757,y:758,t:1528139635024};\\\", \\\"{x:743,y:754,t:1528139635040};\\\", \\\"{x:739,y:753,t:1528139635057};\\\", \\\"{x:738,y:753,t:1528139635074};\\\", \\\"{x:735,y:753,t:1528139635091};\\\", \\\"{x:718,y:750,t:1528139635107};\\\", \\\"{x:661,y:741,t:1528139635124};\\\", \\\"{x:553,y:727,t:1528139635141};\\\", \\\"{x:447,y:711,t:1528139635157};\\\", \\\"{x:362,y:692,t:1528139635174};\\\", \\\"{x:335,y:679,t:1528139635192};\\\", \\\"{x:321,y:670,t:1528139635206};\\\", \\\"{x:306,y:659,t:1528139635225};\\\", \\\"{x:274,y:645,t:1528139635243};\\\", \\\"{x:203,y:618,t:1528139635260};\\\", \\\"{x:122,y:595,t:1528139635276};\\\", \\\"{x:79,y:582,t:1528139635293};\\\", \\\"{x:74,y:578,t:1528139635309};\\\", \\\"{x:85,y:571,t:1528139635326};\\\", \\\"{x:109,y:560,t:1528139635342};\\\", \\\"{x:145,y:544,t:1528139635360};\\\", \\\"{x:181,y:529,t:1528139635376};\\\", \\\"{x:209,y:521,t:1528139635393};\\\", \\\"{x:230,y:515,t:1528139635409};\\\", \\\"{x:239,y:515,t:1528139635426};\\\", \\\"{x:245,y:516,t:1528139635443};\\\", \\\"{x:255,y:529,t:1528139635460};\\\", \\\"{x:271,y:549,t:1528139635476};\\\", \\\"{x:290,y:572,t:1528139635493};\\\", \\\"{x:322,y:595,t:1528139635511};\\\", \\\"{x:343,y:605,t:1528139635526};\\\", \\\"{x:356,y:607,t:1528139635543};\\\", \\\"{x:361,y:607,t:1528139635560};\\\", \\\"{x:362,y:607,t:1528139635582};\\\", \\\"{x:363,y:607,t:1528139635592};\\\", \\\"{x:364,y:604,t:1528139635610};\\\", \\\"{x:366,y:601,t:1528139635625};\\\", \\\"{x:367,y:599,t:1528139635643};\\\", \\\"{x:367,y:596,t:1528139635660};\\\", \\\"{x:370,y:590,t:1528139635676};\\\", \\\"{x:370,y:586,t:1528139635693};\\\", \\\"{x:370,y:583,t:1528139635710};\\\", \\\"{x:370,y:582,t:1528139635725};\\\", \\\"{x:371,y:581,t:1528139635750};\\\", \\\"{x:373,y:578,t:1528139635767};\\\", \\\"{x:376,y:575,t:1528139635776};\\\", \\\"{x:383,y:570,t:1528139635794};\\\", \\\"{x:387,y:566,t:1528139635811};\\\", \\\"{x:390,y:563,t:1528139635826};\\\", \\\"{x:392,y:560,t:1528139635843};\\\", \\\"{x:395,y:560,t:1528139636103};\\\", \\\"{x:395,y:560,t:1528139636107};\\\", \\\"{x:403,y:563,t:1528139636126};\\\", \\\"{x:418,y:591,t:1528139636143};\\\", \\\"{x:430,y:615,t:1528139636160};\\\", \\\"{x:438,y:638,t:1528139636177};\\\", \\\"{x:445,y:656,t:1528139636193};\\\", \\\"{x:446,y:663,t:1528139636209};\\\", \\\"{x:447,y:666,t:1528139636226};\\\", \\\"{x:449,y:670,t:1528139636243};\\\", \\\"{x:453,y:675,t:1528139636260};\\\", \\\"{x:455,y:678,t:1528139636277};\\\", \\\"{x:457,y:680,t:1528139636294};\\\", \\\"{x:457,y:681,t:1528139636310};\\\", \\\"{x:457,y:684,t:1528139636350};\\\", \\\"{x:458,y:688,t:1528139636361};\\\", \\\"{x:462,y:706,t:1528139636377};\\\", \\\"{x:469,y:730,t:1528139636394};\\\", \\\"{x:477,y:754,t:1528139636411};\\\", \\\"{x:484,y:776,t:1528139636427};\\\", \\\"{x:493,y:797,t:1528139636444};\\\", \\\"{x:496,y:805,t:1528139636460};\\\", \\\"{x:498,y:809,t:1528139636476};\\\", \\\"{x:497,y:809,t:1528139636566};\\\", \\\"{x:497,y:808,t:1528139636606};\\\", \\\"{x:496,y:808,t:1528139636622};\\\", \\\"{x:495,y:806,t:1528139636638};\\\", \\\"{x:495,y:805,t:1528139636646};\\\", \\\"{x:494,y:801,t:1528139636660};\\\", \\\"{x:492,y:796,t:1528139636677};\\\", \\\"{x:490,y:789,t:1528139636694};\\\", \\\"{x:489,y:781,t:1528139636711};\\\", \\\"{x:487,y:765,t:1528139636728};\\\", \\\"{x:482,y:740,t:1528139636744};\\\", \\\"{x:466,y:705,t:1528139636761};\\\", \\\"{x:427,y:665,t:1528139636777};\\\", \\\"{x:387,y:634,t:1528139636795};\\\", \\\"{x:363,y:625,t:1528139636811};\\\", \\\"{x:352,y:618,t:1528139636827};\\\", \\\"{x:349,y:614,t:1528139636844};\\\", \\\"{x:348,y:610,t:1528139636860};\\\", \\\"{x:348,y:603,t:1528139636877};\\\", \\\"{x:348,y:598,t:1528139636894};\\\", \\\"{x:348,y:596,t:1528139636911};\\\", \\\"{x:348,y:595,t:1528139636927};\\\", \\\"{x:348,y:593,t:1528139636944};\\\", \\\"{x:348,y:589,t:1528139636961};\\\", \\\"{x:350,y:587,t:1528139636977};\\\", \\\"{x:353,y:586,t:1528139636994};\\\", \\\"{x:356,y:585,t:1528139637011};\\\", \\\"{x:358,y:584,t:1528139637027};\\\", \\\"{x:362,y:581,t:1528139637044};\\\", \\\"{x:369,y:579,t:1528139637062};\\\", \\\"{x:377,y:575,t:1528139637077};\\\", \\\"{x:388,y:569,t:1528139637094};\\\", \\\"{x:391,y:567,t:1528139637111};\\\", \\\"{x:391,y:565,t:1528139637190};\\\", \\\"{x:391,y:562,t:1528139637198};\\\", \\\"{x:393,y:557,t:1528139637211};\\\", \\\"{x:394,y:554,t:1528139637227};\\\", \\\"{x:395,y:553,t:1528139637558};\\\", \\\"{x:395,y:555,t:1528139637574};\\\", \\\"{x:398,y:562,t:1528139637582};\\\", \\\"{x:400,y:569,t:1528139637594};\\\", \\\"{x:403,y:582,t:1528139637612};\\\", \\\"{x:405,y:587,t:1528139637628};\\\", \\\"{x:405,y:589,t:1528139637644};\\\", \\\"{x:405,y:591,t:1528139637661};\\\", \\\"{x:407,y:602,t:1528139637678};\\\", \\\"{x:413,y:616,t:1528139637696};\\\", \\\"{x:424,y:635,t:1528139637711};\\\", \\\"{x:438,y:668,t:1528139637728};\\\", \\\"{x:450,y:691,t:1528139637746};\\\", \\\"{x:456,y:708,t:1528139637761};\\\", \\\"{x:465,y:722,t:1528139637778};\\\", \\\"{x:470,y:731,t:1528139637795};\\\", \\\"{x:472,y:733,t:1528139637811};\\\", \\\"{x:472,y:734,t:1528139637828};\\\", \\\"{x:473,y:734,t:1528139637870};\\\", \\\"{x:475,y:736,t:1528139637886};\\\", \\\"{x:476,y:737,t:1528139637911};\\\", \\\"{x:477,y:738,t:1528139637928};\\\", \\\"{x:478,y:739,t:1528139637944};\\\", \\\"{x:478,y:740,t:1528139637961};\\\", \\\"{x:479,y:741,t:1528139637999};\\\", \\\"{x:480,y:743,t:1528139638014};\\\", \\\"{x:480,y:745,t:1528139638030};\\\", \\\"{x:475,y:740,t:1528139638735};\\\", \\\"{x:463,y:734,t:1528139638745};\\\", \\\"{x:424,y:724,t:1528139638762};\\\", \\\"{x:363,y:708,t:1528139638778};\\\", \\\"{x:300,y:693,t:1528139638795};\\\", \\\"{x:242,y:676,t:1528139638812};\\\", \\\"{x:212,y:669,t:1528139638829};\\\", \\\"{x:204,y:666,t:1528139638846};\\\", \\\"{x:203,y:665,t:1528139638862};\\\" ] }, { \\\"rt\\\": 10233, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 578915, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:216,y:660,t:1528139640021};\\\", \\\"{x:233,y:655,t:1528139640030};\\\", \\\"{x:262,y:644,t:1528139640048};\\\", \\\"{x:292,y:631,t:1528139640063};\\\", \\\"{x:314,y:623,t:1528139640080};\\\", \\\"{x:331,y:614,t:1528139640096};\\\", \\\"{x:351,y:605,t:1528139640113};\\\", \\\"{x:375,y:593,t:1528139640131};\\\", \\\"{x:393,y:585,t:1528139640147};\\\", \\\"{x:424,y:569,t:1528139640163};\\\", \\\"{x:465,y:553,t:1528139640180};\\\", \\\"{x:504,y:544,t:1528139640197};\\\", \\\"{x:557,y:527,t:1528139640213};\\\", \\\"{x:680,y:504,t:1528139640230};\\\", \\\"{x:766,y:490,t:1528139640248};\\\", \\\"{x:869,y:472,t:1528139640263};\\\", \\\"{x:975,y:457,t:1528139640280};\\\", \\\"{x:1083,y:443,t:1528139640297};\\\", \\\"{x:1187,y:435,t:1528139640313};\\\", \\\"{x:1279,y:433,t:1528139640330};\\\", \\\"{x:1359,y:433,t:1528139640347};\\\", \\\"{x:1427,y:431,t:1528139640363};\\\", \\\"{x:1463,y:431,t:1528139640380};\\\", \\\"{x:1488,y:431,t:1528139640398};\\\", \\\"{x:1500,y:431,t:1528139640413};\\\", \\\"{x:1503,y:431,t:1528139640430};\\\", \\\"{x:1504,y:431,t:1528139640478};\\\", \\\"{x:1506,y:432,t:1528139640486};\\\", \\\"{x:1513,y:437,t:1528139640497};\\\", \\\"{x:1531,y:452,t:1528139640514};\\\", \\\"{x:1551,y:470,t:1528139640530};\\\", \\\"{x:1569,y:487,t:1528139640547};\\\", \\\"{x:1582,y:506,t:1528139640564};\\\", \\\"{x:1588,y:523,t:1528139640581};\\\", \\\"{x:1596,y:549,t:1528139640598};\\\", \\\"{x:1606,y:594,t:1528139640614};\\\", \\\"{x:1610,y:619,t:1528139640631};\\\", \\\"{x:1610,y:639,t:1528139640647};\\\", \\\"{x:1610,y:654,t:1528139640664};\\\", \\\"{x:1609,y:669,t:1528139640680};\\\", \\\"{x:1608,y:679,t:1528139640697};\\\", \\\"{x:1603,y:688,t:1528139640715};\\\", \\\"{x:1602,y:690,t:1528139640731};\\\", \\\"{x:1601,y:691,t:1528139640747};\\\", \\\"{x:1601,y:690,t:1528139640943};\\\", \\\"{x:1601,y:688,t:1528139640951};\\\", \\\"{x:1601,y:687,t:1528139640965};\\\", \\\"{x:1601,y:686,t:1528139640982};\\\", \\\"{x:1601,y:685,t:1528139641087};\\\", \\\"{x:1602,y:687,t:1528139641111};\\\", \\\"{x:1603,y:693,t:1528139641118};\\\", \\\"{x:1605,y:698,t:1528139641132};\\\", \\\"{x:1612,y:712,t:1528139641147};\\\", \\\"{x:1619,y:724,t:1528139641165};\\\", \\\"{x:1626,y:734,t:1528139641181};\\\", \\\"{x:1629,y:741,t:1528139641197};\\\", \\\"{x:1635,y:753,t:1528139641214};\\\", \\\"{x:1636,y:761,t:1528139641232};\\\", \\\"{x:1640,y:772,t:1528139641247};\\\", \\\"{x:1643,y:786,t:1528139641264};\\\", \\\"{x:1644,y:801,t:1528139641282};\\\", \\\"{x:1645,y:817,t:1528139641299};\\\", \\\"{x:1645,y:834,t:1528139641315};\\\", \\\"{x:1645,y:860,t:1528139641332};\\\", \\\"{x:1645,y:881,t:1528139641349};\\\", \\\"{x:1645,y:900,t:1528139641365};\\\", \\\"{x:1646,y:916,t:1528139641382};\\\", \\\"{x:1648,y:934,t:1528139641398};\\\", \\\"{x:1648,y:942,t:1528139641414};\\\", \\\"{x:1648,y:943,t:1528139641431};\\\", \\\"{x:1649,y:943,t:1528139641671};\\\", \\\"{x:1651,y:943,t:1528139641687};\\\", \\\"{x:1653,y:941,t:1528139641699};\\\", \\\"{x:1657,y:939,t:1528139641716};\\\", \\\"{x:1659,y:939,t:1528139641731};\\\", \\\"{x:1659,y:938,t:1528139641774};\\\", \\\"{x:1654,y:938,t:1528139641919};\\\", \\\"{x:1649,y:937,t:1528139641932};\\\", \\\"{x:1646,y:936,t:1528139641949};\\\", \\\"{x:1642,y:936,t:1528139641966};\\\", \\\"{x:1640,y:935,t:1528139641982};\\\", \\\"{x:1637,y:935,t:1528139641999};\\\", \\\"{x:1636,y:935,t:1528139642015};\\\", \\\"{x:1633,y:934,t:1528139642247};\\\", \\\"{x:1629,y:932,t:1528139642254};\\\", \\\"{x:1625,y:930,t:1528139642265};\\\", \\\"{x:1622,y:929,t:1528139642283};\\\", \\\"{x:1620,y:927,t:1528139642299};\\\", \\\"{x:1617,y:925,t:1528139642316};\\\", \\\"{x:1615,y:922,t:1528139642333};\\\", \\\"{x:1614,y:920,t:1528139642348};\\\", \\\"{x:1613,y:914,t:1528139642366};\\\", \\\"{x:1611,y:903,t:1528139642383};\\\", \\\"{x:1610,y:898,t:1528139642400};\\\", \\\"{x:1610,y:893,t:1528139642415};\\\", \\\"{x:1610,y:888,t:1528139642433};\\\", \\\"{x:1610,y:884,t:1528139642450};\\\", \\\"{x:1610,y:880,t:1528139642465};\\\", \\\"{x:1610,y:876,t:1528139642482};\\\", \\\"{x:1610,y:873,t:1528139642499};\\\", \\\"{x:1610,y:872,t:1528139642515};\\\", \\\"{x:1610,y:871,t:1528139642532};\\\", \\\"{x:1610,y:868,t:1528139642549};\\\", \\\"{x:1610,y:865,t:1528139642565};\\\", \\\"{x:1610,y:861,t:1528139642582};\\\", \\\"{x:1609,y:856,t:1528139642599};\\\", \\\"{x:1609,y:849,t:1528139642615};\\\", \\\"{x:1607,y:840,t:1528139642632};\\\", \\\"{x:1606,y:827,t:1528139642649};\\\", \\\"{x:1601,y:809,t:1528139642666};\\\", \\\"{x:1598,y:790,t:1528139642682};\\\", \\\"{x:1598,y:774,t:1528139642699};\\\", \\\"{x:1598,y:760,t:1528139642716};\\\", \\\"{x:1598,y:738,t:1528139642732};\\\", \\\"{x:1596,y:716,t:1528139642749};\\\", \\\"{x:1595,y:689,t:1528139642765};\\\", \\\"{x:1595,y:674,t:1528139642783};\\\", \\\"{x:1595,y:657,t:1528139642800};\\\", \\\"{x:1594,y:645,t:1528139642817};\\\", \\\"{x:1593,y:640,t:1528139642833};\\\", \\\"{x:1590,y:635,t:1528139642849};\\\", \\\"{x:1587,y:629,t:1528139642866};\\\", \\\"{x:1586,y:628,t:1528139642883};\\\", \\\"{x:1585,y:624,t:1528139642900};\\\", \\\"{x:1585,y:622,t:1528139642917};\\\", \\\"{x:1585,y:621,t:1528139642933};\\\", \\\"{x:1585,y:619,t:1528139642950};\\\", \\\"{x:1585,y:618,t:1528139642966};\\\", \\\"{x:1585,y:617,t:1528139642983};\\\", \\\"{x:1585,y:616,t:1528139643000};\\\", \\\"{x:1585,y:615,t:1528139643017};\\\", \\\"{x:1585,y:613,t:1528139643033};\\\", \\\"{x:1585,y:608,t:1528139643050};\\\", \\\"{x:1585,y:605,t:1528139643066};\\\", \\\"{x:1584,y:600,t:1528139643082};\\\", \\\"{x:1583,y:597,t:1528139643100};\\\", \\\"{x:1582,y:595,t:1528139643116};\\\", \\\"{x:1580,y:590,t:1528139643134};\\\", \\\"{x:1578,y:586,t:1528139643150};\\\", \\\"{x:1576,y:581,t:1528139643167};\\\", \\\"{x:1575,y:580,t:1528139643184};\\\", \\\"{x:1575,y:578,t:1528139643200};\\\", \\\"{x:1574,y:577,t:1528139643216};\\\", \\\"{x:1573,y:577,t:1528139643599};\\\", \\\"{x:1572,y:579,t:1528139643607};\\\", \\\"{x:1572,y:580,t:1528139643638};\\\", \\\"{x:1571,y:580,t:1528139643651};\\\", \\\"{x:1570,y:590,t:1528139643982};\\\", \\\"{x:1573,y:619,t:1528139644000};\\\", \\\"{x:1577,y:649,t:1528139644018};\\\", \\\"{x:1588,y:685,t:1528139644033};\\\", \\\"{x:1596,y:713,t:1528139644051};\\\", \\\"{x:1602,y:743,t:1528139644068};\\\", \\\"{x:1604,y:770,t:1528139644084};\\\", \\\"{x:1604,y:793,t:1528139644100};\\\", \\\"{x:1604,y:818,t:1528139644117};\\\", \\\"{x:1604,y:848,t:1528139644134};\\\", \\\"{x:1604,y:943,t:1528139644151};\\\", \\\"{x:1604,y:1020,t:1528139644168};\\\", \\\"{x:1604,y:1068,t:1528139644184};\\\", \\\"{x:1612,y:1094,t:1528139644200};\\\", \\\"{x:1612,y:1104,t:1528139644218};\\\", \\\"{x:1614,y:1111,t:1528139644234};\\\", \\\"{x:1614,y:1113,t:1528139644250};\\\", \\\"{x:1614,y:1114,t:1528139644268};\\\", \\\"{x:1614,y:1108,t:1528139644391};\\\", \\\"{x:1610,y:1102,t:1528139644401};\\\", \\\"{x:1608,y:1084,t:1528139644418};\\\", \\\"{x:1605,y:1059,t:1528139644435};\\\", \\\"{x:1605,y:1032,t:1528139644451};\\\", \\\"{x:1600,y:1001,t:1528139644469};\\\", \\\"{x:1600,y:974,t:1528139644485};\\\", \\\"{x:1600,y:954,t:1528139644502};\\\", \\\"{x:1600,y:936,t:1528139644517};\\\", \\\"{x:1600,y:929,t:1528139644535};\\\", \\\"{x:1600,y:928,t:1528139644655};\\\", \\\"{x:1600,y:926,t:1528139644668};\\\", \\\"{x:1602,y:918,t:1528139644685};\\\", \\\"{x:1602,y:914,t:1528139644702};\\\", \\\"{x:1605,y:904,t:1528139644717};\\\", \\\"{x:1605,y:892,t:1528139644734};\\\", \\\"{x:1605,y:885,t:1528139644752};\\\", \\\"{x:1605,y:878,t:1528139644768};\\\", \\\"{x:1605,y:873,t:1528139644785};\\\", \\\"{x:1605,y:870,t:1528139644802};\\\", \\\"{x:1605,y:867,t:1528139644817};\\\", \\\"{x:1605,y:864,t:1528139644835};\\\", \\\"{x:1605,y:862,t:1528139644852};\\\", \\\"{x:1607,y:853,t:1528139644868};\\\", \\\"{x:1610,y:844,t:1528139644884};\\\", \\\"{x:1611,y:837,t:1528139644902};\\\", \\\"{x:1612,y:827,t:1528139644919};\\\", \\\"{x:1612,y:823,t:1528139644934};\\\", \\\"{x:1612,y:819,t:1528139644952};\\\", \\\"{x:1612,y:818,t:1528139644974};\\\", \\\"{x:1612,y:817,t:1528139644985};\\\", \\\"{x:1612,y:816,t:1528139645002};\\\", \\\"{x:1612,y:815,t:1528139645022};\\\", \\\"{x:1612,y:813,t:1528139645035};\\\", \\\"{x:1612,y:810,t:1528139645052};\\\", \\\"{x:1612,y:805,t:1528139645069};\\\", \\\"{x:1612,y:801,t:1528139645085};\\\", \\\"{x:1612,y:797,t:1528139645102};\\\", \\\"{x:1610,y:792,t:1528139645118};\\\", \\\"{x:1610,y:790,t:1528139645135};\\\", \\\"{x:1610,y:786,t:1528139645152};\\\", \\\"{x:1610,y:783,t:1528139645169};\\\", \\\"{x:1609,y:780,t:1528139645185};\\\", \\\"{x:1609,y:777,t:1528139645202};\\\", \\\"{x:1608,y:773,t:1528139645219};\\\", \\\"{x:1608,y:770,t:1528139645235};\\\", \\\"{x:1608,y:769,t:1528139645254};\\\", \\\"{x:1607,y:768,t:1528139645279};\\\", \\\"{x:1607,y:767,t:1528139645335};\\\", \\\"{x:1607,y:765,t:1528139645352};\\\", \\\"{x:1606,y:764,t:1528139645369};\\\", \\\"{x:1606,y:762,t:1528139645386};\\\", \\\"{x:1606,y:760,t:1528139645402};\\\", \\\"{x:1606,y:756,t:1528139645419};\\\", \\\"{x:1606,y:751,t:1528139645436};\\\", \\\"{x:1605,y:747,t:1528139645452};\\\", \\\"{x:1603,y:744,t:1528139645469};\\\", \\\"{x:1603,y:742,t:1528139645486};\\\", \\\"{x:1603,y:738,t:1528139645502};\\\", \\\"{x:1603,y:734,t:1528139645518};\\\", \\\"{x:1603,y:732,t:1528139645536};\\\", \\\"{x:1603,y:731,t:1528139645552};\\\", \\\"{x:1603,y:729,t:1528139645569};\\\", \\\"{x:1603,y:728,t:1528139645606};\\\", \\\"{x:1603,y:727,t:1528139645638};\\\", \\\"{x:1603,y:726,t:1528139645687};\\\", \\\"{x:1603,y:725,t:1528139645735};\\\", \\\"{x:1603,y:724,t:1528139645759};\\\", \\\"{x:1603,y:723,t:1528139645769};\\\", \\\"{x:1603,y:722,t:1528139645786};\\\", \\\"{x:1603,y:721,t:1528139645803};\\\", \\\"{x:1603,y:720,t:1528139645819};\\\", \\\"{x:1603,y:719,t:1528139645835};\\\", \\\"{x:1603,y:718,t:1528139645853};\\\", \\\"{x:1603,y:717,t:1528139646351};\\\", \\\"{x:1603,y:715,t:1528139646383};\\\", \\\"{x:1603,y:713,t:1528139646391};\\\", \\\"{x:1603,y:711,t:1528139646403};\\\", \\\"{x:1603,y:707,t:1528139646420};\\\", \\\"{x:1604,y:703,t:1528139646437};\\\", \\\"{x:1606,y:698,t:1528139646453};\\\", \\\"{x:1607,y:694,t:1528139646470};\\\", \\\"{x:1611,y:686,t:1528139646487};\\\", \\\"{x:1613,y:679,t:1528139646503};\\\", \\\"{x:1617,y:670,t:1528139646520};\\\", \\\"{x:1621,y:658,t:1528139646537};\\\", \\\"{x:1625,y:648,t:1528139646553};\\\", \\\"{x:1626,y:643,t:1528139646570};\\\", \\\"{x:1626,y:639,t:1528139646587};\\\", \\\"{x:1626,y:633,t:1528139646603};\\\", \\\"{x:1626,y:625,t:1528139646619};\\\", \\\"{x:1625,y:620,t:1528139646637};\\\", \\\"{x:1619,y:610,t:1528139646653};\\\", \\\"{x:1609,y:594,t:1528139646670};\\\", \\\"{x:1587,y:577,t:1528139646686};\\\", \\\"{x:1567,y:570,t:1528139646703};\\\", \\\"{x:1548,y:565,t:1528139646719};\\\", \\\"{x:1525,y:561,t:1528139646736};\\\", \\\"{x:1480,y:552,t:1528139646753};\\\", \\\"{x:1416,y:552,t:1528139646769};\\\", \\\"{x:1324,y:552,t:1528139646787};\\\", \\\"{x:1210,y:568,t:1528139646803};\\\", \\\"{x:1110,y:581,t:1528139646819};\\\", \\\"{x:1021,y:597,t:1528139646837};\\\", \\\"{x:930,y:620,t:1528139646855};\\\", \\\"{x:835,y:659,t:1528139646870};\\\", \\\"{x:733,y:702,t:1528139646904};\\\", \\\"{x:714,y:714,t:1528139646913};\\\", \\\"{x:684,y:731,t:1528139646929};\\\", \\\"{x:657,y:743,t:1528139646946};\\\", \\\"{x:630,y:759,t:1528139646964};\\\", \\\"{x:590,y:771,t:1528139646979};\\\", \\\"{x:551,y:782,t:1528139646997};\\\", \\\"{x:506,y:796,t:1528139647013};\\\", \\\"{x:434,y:808,t:1528139647030};\\\", \\\"{x:401,y:811,t:1528139647046};\\\", \\\"{x:373,y:814,t:1528139647064};\\\", \\\"{x:347,y:814,t:1528139647081};\\\", \\\"{x:329,y:814,t:1528139647096};\\\", \\\"{x:319,y:813,t:1528139647114};\\\", \\\"{x:317,y:813,t:1528139647131};\\\", \\\"{x:316,y:805,t:1528139647148};\\\", \\\"{x:314,y:784,t:1528139647163};\\\", \\\"{x:311,y:756,t:1528139647181};\\\", \\\"{x:311,y:739,t:1528139647197};\\\", \\\"{x:311,y:720,t:1528139647214};\\\", \\\"{x:333,y:683,t:1528139647231};\\\", \\\"{x:346,y:672,t:1528139647247};\\\", \\\"{x:360,y:662,t:1528139647269};\\\", \\\"{x:365,y:659,t:1528139647285};\\\", \\\"{x:365,y:658,t:1528139647302};\\\", \\\"{x:365,y:657,t:1528139647349};\\\", \\\"{x:365,y:656,t:1528139647358};\\\", \\\"{x:365,y:653,t:1528139647370};\\\", \\\"{x:354,y:646,t:1528139647386};\\\", \\\"{x:314,y:626,t:1528139647403};\\\", \\\"{x:244,y:606,t:1528139647421};\\\", \\\"{x:172,y:597,t:1528139647435};\\\", \\\"{x:111,y:589,t:1528139647453};\\\", \\\"{x:59,y:582,t:1528139647469};\\\", \\\"{x:49,y:581,t:1528139647486};\\\", \\\"{x:43,y:579,t:1528139647503};\\\", \\\"{x:42,y:579,t:1528139647519};\\\", \\\"{x:48,y:579,t:1528139647686};\\\", \\\"{x:57,y:583,t:1528139647704};\\\", \\\"{x:69,y:590,t:1528139647719};\\\", \\\"{x:79,y:596,t:1528139647736};\\\", \\\"{x:89,y:605,t:1528139647752};\\\", \\\"{x:96,y:612,t:1528139647770};\\\", \\\"{x:99,y:617,t:1528139647786};\\\", \\\"{x:100,y:620,t:1528139647803};\\\", \\\"{x:101,y:622,t:1528139647819};\\\", \\\"{x:101,y:626,t:1528139647837};\\\", \\\"{x:101,y:628,t:1528139647853};\\\", \\\"{x:101,y:632,t:1528139647869};\\\", \\\"{x:101,y:633,t:1528139647894};\\\", \\\"{x:101,y:634,t:1528139647918};\\\", \\\"{x:101,y:637,t:1528139647942};\\\", \\\"{x:101,y:640,t:1528139647958};\\\", \\\"{x:101,y:641,t:1528139647969};\\\", \\\"{x:101,y:643,t:1528139647987};\\\", \\\"{x:101,y:651,t:1528139648004};\\\", \\\"{x:103,y:655,t:1528139648019};\\\", \\\"{x:106,y:659,t:1528139648036};\\\", \\\"{x:113,y:663,t:1528139648052};\\\", \\\"{x:120,y:664,t:1528139648069};\\\", \\\"{x:124,y:664,t:1528139648086};\\\", \\\"{x:125,y:665,t:1528139648102};\\\", \\\"{x:126,y:666,t:1528139648238};\\\", \\\"{x:127,y:666,t:1528139648295};\\\", \\\"{x:130,y:666,t:1528139648303};\\\", \\\"{x:132,y:666,t:1528139648320};\\\", \\\"{x:143,y:668,t:1528139648337};\\\", \\\"{x:150,y:670,t:1528139648355};\\\", \\\"{x:151,y:671,t:1528139648369};\\\", \\\"{x:152,y:671,t:1528139648733};\\\", \\\"{x:156,y:675,t:1528139648741};\\\", \\\"{x:167,y:680,t:1528139648753};\\\", \\\"{x:199,y:689,t:1528139648771};\\\", \\\"{x:233,y:697,t:1528139648787};\\\", \\\"{x:266,y:701,t:1528139648803};\\\", \\\"{x:310,y:711,t:1528139648820};\\\", \\\"{x:337,y:714,t:1528139648836};\\\", \\\"{x:362,y:720,t:1528139648854};\\\", \\\"{x:376,y:724,t:1528139648870};\\\", \\\"{x:392,y:728,t:1528139648887};\\\", \\\"{x:406,y:732,t:1528139648904};\\\", \\\"{x:414,y:732,t:1528139648921};\\\", \\\"{x:416,y:732,t:1528139648936};\\\", \\\"{x:417,y:733,t:1528139649143};\\\", \\\"{x:417,y:734,t:1528139649154};\\\", \\\"{x:421,y:741,t:1528139649171};\\\", \\\"{x:422,y:746,t:1528139649188};\\\", \\\"{x:433,y:760,t:1528139649204};\\\", \\\"{x:441,y:770,t:1528139649221};\\\", \\\"{x:443,y:772,t:1528139649237};\\\", \\\"{x:443,y:773,t:1528139649271};\\\", \\\"{x:445,y:772,t:1528139649318};\\\", \\\"{x:446,y:772,t:1528139649326};\\\", \\\"{x:447,y:771,t:1528139649338};\\\", \\\"{x:448,y:770,t:1528139649354};\\\", \\\"{x:449,y:770,t:1528139649371};\\\", \\\"{x:450,y:770,t:1528139649389};\\\", \\\"{x:451,y:769,t:1528139649404};\\\", \\\"{x:454,y:769,t:1528139649423};\\\", \\\"{x:457,y:769,t:1528139649438};\\\", \\\"{x:458,y:769,t:1528139649455};\\\", \\\"{x:454,y:768,t:1528139650199};\\\", \\\"{x:442,y:768,t:1528139650207};\\\", \\\"{x:401,y:763,t:1528139650222};\\\", \\\"{x:321,y:758,t:1528139650238};\\\", \\\"{x:223,y:752,t:1528139650254};\\\", \\\"{x:103,y:744,t:1528139650272};\\\", \\\"{x:0,y:735,t:1528139650288};\\\", \\\"{x:0,y:733,t:1528139650318};\\\", \\\"{x:0,y:724,t:1528139650326};\\\", \\\"{x:0,y:716,t:1528139650338};\\\", \\\"{x:0,y:699,t:1528139650355};\\\", \\\"{x:0,y:684,t:1528139650372};\\\", \\\"{x:0,y:682,t:1528139650388};\\\", \\\"{x:0,y:677,t:1528139650405};\\\", \\\"{x:0,y:667,t:1528139650422};\\\", \\\"{x:0,y:658,t:1528139650438};\\\", \\\"{x:0,y:653,t:1528139650471};\\\", \\\"{x:0,y:651,t:1528139650479};\\\", \\\"{x:0,y:647,t:1528139650489};\\\", \\\"{x:0,y:642,t:1528139650504};\\\", \\\"{x:0,y:631,t:1528139650522};\\\", \\\"{x:0,y:629,t:1528139650539};\\\", \\\"{x:0,y:628,t:1528139650555};\\\", \\\"{x:0,y:627,t:1528139650687};\\\", \\\"{x:4,y:624,t:1528139650726};\\\", \\\"{x:8,y:622,t:1528139650738};\\\", \\\"{x:22,y:617,t:1528139650755};\\\", \\\"{x:27,y:615,t:1528139650772};\\\", \\\"{x:34,y:613,t:1528139650789};\\\" ] }, { \\\"rt\\\": 44264, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 624391, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -G -G -F -I -I -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:35,y:613,t:1528139650934};\\\", \\\"{x:39,y:613,t:1528139650942};\\\", \\\"{x:44,y:613,t:1528139650956};\\\", \\\"{x:52,y:610,t:1528139650972};\\\", \\\"{x:56,y:609,t:1528139650988};\\\", \\\"{x:60,y:609,t:1528139651474};\\\", \\\"{x:73,y:605,t:1528139651488};\\\", \\\"{x:90,y:600,t:1528139651506};\\\", \\\"{x:109,y:595,t:1528139651523};\\\", \\\"{x:120,y:593,t:1528139651539};\\\", \\\"{x:131,y:589,t:1528139651555};\\\", \\\"{x:146,y:585,t:1528139651573};\\\", \\\"{x:172,y:580,t:1528139651589};\\\", \\\"{x:184,y:578,t:1528139651605};\\\", \\\"{x:196,y:576,t:1528139651622};\\\", \\\"{x:213,y:573,t:1528139651640};\\\", \\\"{x:233,y:570,t:1528139651656};\\\", \\\"{x:249,y:569,t:1528139651673};\\\", \\\"{x:261,y:568,t:1528139651690};\\\", \\\"{x:270,y:567,t:1528139651707};\\\", \\\"{x:276,y:566,t:1528139651723};\\\", \\\"{x:284,y:566,t:1528139651740};\\\", \\\"{x:294,y:564,t:1528139651755};\\\", \\\"{x:307,y:563,t:1528139651772};\\\", \\\"{x:321,y:560,t:1528139651789};\\\", \\\"{x:333,y:559,t:1528139651806};\\\", \\\"{x:348,y:559,t:1528139651823};\\\", \\\"{x:360,y:559,t:1528139651840};\\\", \\\"{x:374,y:558,t:1528139651856};\\\", \\\"{x:384,y:558,t:1528139651873};\\\", \\\"{x:398,y:558,t:1528139651889};\\\", \\\"{x:413,y:558,t:1528139651905};\\\", \\\"{x:427,y:558,t:1528139651923};\\\", \\\"{x:443,y:558,t:1528139651940};\\\", \\\"{x:458,y:558,t:1528139651956};\\\", \\\"{x:471,y:558,t:1528139651973};\\\", \\\"{x:491,y:558,t:1528139651990};\\\", \\\"{x:505,y:558,t:1528139652008};\\\", \\\"{x:520,y:558,t:1528139652022};\\\", \\\"{x:535,y:558,t:1528139652039};\\\", \\\"{x:546,y:558,t:1528139652056};\\\", \\\"{x:554,y:558,t:1528139652073};\\\", \\\"{x:559,y:558,t:1528139652089};\\\", \\\"{x:564,y:558,t:1528139652106};\\\", \\\"{x:575,y:558,t:1528139652122};\\\", \\\"{x:591,y:558,t:1528139652140};\\\", \\\"{x:612,y:556,t:1528139652157};\\\", \\\"{x:631,y:556,t:1528139652172};\\\", \\\"{x:658,y:556,t:1528139652190};\\\", \\\"{x:672,y:556,t:1528139652206};\\\", \\\"{x:677,y:556,t:1528139652223};\\\", \\\"{x:678,y:556,t:1528139652239};\\\", \\\"{x:679,y:556,t:1528139652470};\\\", \\\"{x:680,y:556,t:1528139652510};\\\", \\\"{x:681,y:556,t:1528139652523};\\\", \\\"{x:693,y:556,t:1528139652539};\\\", \\\"{x:708,y:556,t:1528139652556};\\\", \\\"{x:728,y:556,t:1528139652574};\\\", \\\"{x:739,y:556,t:1528139652590};\\\", \\\"{x:754,y:556,t:1528139652607};\\\", \\\"{x:775,y:556,t:1528139652624};\\\", \\\"{x:800,y:556,t:1528139652640};\\\", \\\"{x:824,y:556,t:1528139652657};\\\", \\\"{x:847,y:556,t:1528139652674};\\\", \\\"{x:869,y:556,t:1528139652690};\\\", \\\"{x:886,y:556,t:1528139652707};\\\", \\\"{x:902,y:556,t:1528139652724};\\\", \\\"{x:911,y:556,t:1528139652740};\\\", \\\"{x:915,y:556,t:1528139652756};\\\", \\\"{x:916,y:556,t:1528139652774};\\\", \\\"{x:918,y:556,t:1528139653199};\\\", \\\"{x:924,y:556,t:1528139653207};\\\", \\\"{x:950,y:556,t:1528139653224};\\\", \\\"{x:991,y:556,t:1528139653242};\\\", \\\"{x:1029,y:553,t:1528139653257};\\\", \\\"{x:1061,y:552,t:1528139653274};\\\", \\\"{x:1089,y:552,t:1528139653290};\\\", \\\"{x:1115,y:552,t:1528139653307};\\\", \\\"{x:1126,y:552,t:1528139653324};\\\", \\\"{x:1132,y:552,t:1528139653340};\\\", \\\"{x:1141,y:552,t:1528139653357};\\\", \\\"{x:1149,y:552,t:1528139653373};\\\", \\\"{x:1163,y:552,t:1528139653391};\\\", \\\"{x:1179,y:552,t:1528139653408};\\\", \\\"{x:1201,y:552,t:1528139653424};\\\", \\\"{x:1225,y:552,t:1528139653441};\\\", \\\"{x:1246,y:552,t:1528139653458};\\\", \\\"{x:1265,y:552,t:1528139653473};\\\", \\\"{x:1280,y:552,t:1528139653491};\\\", \\\"{x:1294,y:552,t:1528139653508};\\\", \\\"{x:1305,y:552,t:1528139653524};\\\", \\\"{x:1310,y:552,t:1528139653541};\\\", \\\"{x:1312,y:552,t:1528139653558};\\\", \\\"{x:1313,y:552,t:1528139653574};\\\", \\\"{x:1315,y:552,t:1528139653655};\\\", \\\"{x:1319,y:552,t:1528139653662};\\\", \\\"{x:1328,y:552,t:1528139653674};\\\", \\\"{x:1359,y:552,t:1528139653691};\\\", \\\"{x:1399,y:552,t:1528139653709};\\\", \\\"{x:1438,y:552,t:1528139653725};\\\", \\\"{x:1477,y:552,t:1528139653741};\\\", \\\"{x:1512,y:552,t:1528139653758};\\\", \\\"{x:1525,y:554,t:1528139653774};\\\", \\\"{x:1529,y:555,t:1528139653790};\\\", \\\"{x:1530,y:555,t:1528139654055};\\\", \\\"{x:1530,y:557,t:1528139654095};\\\", \\\"{x:1530,y:558,t:1528139654108};\\\", \\\"{x:1530,y:561,t:1528139654125};\\\", \\\"{x:1530,y:562,t:1528139654141};\\\", \\\"{x:1530,y:563,t:1528139654159};\\\", \\\"{x:1530,y:564,t:1528139654295};\\\", \\\"{x:1529,y:567,t:1528139654711};\\\", \\\"{x:1529,y:568,t:1528139654725};\\\", \\\"{x:1527,y:572,t:1528139654742};\\\", \\\"{x:1526,y:573,t:1528139654975};\\\", \\\"{x:1526,y:577,t:1528139654993};\\\", \\\"{x:1525,y:579,t:1528139655010};\\\", \\\"{x:1525,y:581,t:1528139655026};\\\", \\\"{x:1522,y:585,t:1528139655042};\\\", \\\"{x:1522,y:587,t:1528139655060};\\\", \\\"{x:1521,y:588,t:1528139655075};\\\", \\\"{x:1520,y:590,t:1528139655093};\\\", \\\"{x:1520,y:591,t:1528139655110};\\\", \\\"{x:1520,y:593,t:1528139655126};\\\", \\\"{x:1518,y:598,t:1528139655142};\\\", \\\"{x:1516,y:606,t:1528139655160};\\\", \\\"{x:1515,y:608,t:1528139655176};\\\", \\\"{x:1511,y:615,t:1528139655192};\\\", \\\"{x:1508,y:623,t:1528139655210};\\\", \\\"{x:1504,y:631,t:1528139655226};\\\", \\\"{x:1501,y:635,t:1528139655242};\\\", \\\"{x:1498,y:641,t:1528139655259};\\\", \\\"{x:1495,y:646,t:1528139655277};\\\", \\\"{x:1493,y:651,t:1528139655292};\\\", \\\"{x:1493,y:650,t:1528139655527};\\\", \\\"{x:1493,y:642,t:1528139655542};\\\", \\\"{x:1495,y:638,t:1528139655560};\\\", \\\"{x:1498,y:632,t:1528139655577};\\\", \\\"{x:1500,y:630,t:1528139655594};\\\", \\\"{x:1504,y:630,t:1528139655798};\\\", \\\"{x:1511,y:630,t:1528139655813};\\\", \\\"{x:1522,y:630,t:1528139655827};\\\", \\\"{x:1545,y:636,t:1528139655859};\\\", \\\"{x:1560,y:645,t:1528139655875};\\\", \\\"{x:1578,y:656,t:1528139655893};\\\", \\\"{x:1588,y:663,t:1528139655908};\\\", \\\"{x:1606,y:677,t:1528139655926};\\\", \\\"{x:1618,y:687,t:1528139655943};\\\", \\\"{x:1631,y:698,t:1528139655959};\\\", \\\"{x:1640,y:709,t:1528139655976};\\\", \\\"{x:1644,y:715,t:1528139655993};\\\", \\\"{x:1648,y:721,t:1528139656009};\\\", \\\"{x:1649,y:724,t:1528139656026};\\\", \\\"{x:1650,y:726,t:1528139656043};\\\", \\\"{x:1650,y:728,t:1528139656059};\\\", \\\"{x:1651,y:729,t:1528139656076};\\\", \\\"{x:1651,y:731,t:1528139656102};\\\", \\\"{x:1651,y:732,t:1528139656119};\\\", \\\"{x:1651,y:734,t:1528139656134};\\\", \\\"{x:1651,y:735,t:1528139656144};\\\", \\\"{x:1651,y:738,t:1528139656160};\\\", \\\"{x:1651,y:740,t:1528139656176};\\\", \\\"{x:1651,y:742,t:1528139656193};\\\", \\\"{x:1650,y:745,t:1528139656210};\\\", \\\"{x:1650,y:749,t:1528139656226};\\\", \\\"{x:1648,y:753,t:1528139656243};\\\", \\\"{x:1648,y:754,t:1528139656261};\\\", \\\"{x:1647,y:756,t:1528139656276};\\\", \\\"{x:1646,y:758,t:1528139656297};\\\", \\\"{x:1644,y:762,t:1528139656309};\\\", \\\"{x:1643,y:764,t:1528139656326};\\\", \\\"{x:1640,y:768,t:1528139656343};\\\", \\\"{x:1636,y:771,t:1528139656360};\\\", \\\"{x:1627,y:778,t:1528139656376};\\\", \\\"{x:1617,y:784,t:1528139656393};\\\", \\\"{x:1602,y:792,t:1528139656410};\\\", \\\"{x:1586,y:799,t:1528139656427};\\\", \\\"{x:1569,y:804,t:1528139656443};\\\", \\\"{x:1547,y:807,t:1528139656460};\\\", \\\"{x:1528,y:810,t:1528139656477};\\\", \\\"{x:1511,y:812,t:1528139656493};\\\", \\\"{x:1487,y:816,t:1528139656509};\\\", \\\"{x:1474,y:819,t:1528139656528};\\\", \\\"{x:1466,y:820,t:1528139656543};\\\", \\\"{x:1462,y:820,t:1528139656561};\\\", \\\"{x:1456,y:821,t:1528139656577};\\\", \\\"{x:1453,y:821,t:1528139656593};\\\", \\\"{x:1449,y:822,t:1528139656610};\\\", \\\"{x:1445,y:822,t:1528139656628};\\\", \\\"{x:1437,y:823,t:1528139656643};\\\", \\\"{x:1433,y:824,t:1528139656660};\\\", \\\"{x:1427,y:825,t:1528139656677};\\\", \\\"{x:1421,y:826,t:1528139656694};\\\", \\\"{x:1407,y:829,t:1528139656710};\\\", \\\"{x:1400,y:829,t:1528139656727};\\\", \\\"{x:1392,y:829,t:1528139656743};\\\", \\\"{x:1385,y:830,t:1528139656760};\\\", \\\"{x:1379,y:830,t:1528139656777};\\\", \\\"{x:1375,y:830,t:1528139656793};\\\", \\\"{x:1374,y:830,t:1528139656810};\\\", \\\"{x:1373,y:830,t:1528139656871};\\\", \\\"{x:1373,y:827,t:1528139656879};\\\", \\\"{x:1373,y:815,t:1528139656895};\\\", \\\"{x:1373,y:803,t:1528139656910};\\\", \\\"{x:1375,y:781,t:1528139656927};\\\", \\\"{x:1380,y:761,t:1528139656948};\\\", \\\"{x:1385,y:736,t:1528139656960};\\\", \\\"{x:1391,y:708,t:1528139656977};\\\", \\\"{x:1398,y:682,t:1528139656994};\\\", \\\"{x:1404,y:658,t:1528139657010};\\\", \\\"{x:1416,y:631,t:1528139657027};\\\", \\\"{x:1427,y:608,t:1528139657044};\\\", \\\"{x:1434,y:595,t:1528139657060};\\\", \\\"{x:1436,y:589,t:1528139657077};\\\", \\\"{x:1439,y:578,t:1528139657094};\\\", \\\"{x:1440,y:574,t:1528139657110};\\\", \\\"{x:1441,y:570,t:1528139657127};\\\", \\\"{x:1441,y:561,t:1528139657144};\\\", \\\"{x:1441,y:557,t:1528139657161};\\\", \\\"{x:1442,y:553,t:1528139657177};\\\", \\\"{x:1442,y:550,t:1528139657194};\\\", \\\"{x:1442,y:546,t:1528139657211};\\\", \\\"{x:1442,y:544,t:1528139657227};\\\", \\\"{x:1442,y:540,t:1528139657244};\\\", \\\"{x:1442,y:537,t:1528139657261};\\\", \\\"{x:1439,y:530,t:1528139657277};\\\", \\\"{x:1424,y:517,t:1528139657294};\\\", \\\"{x:1413,y:508,t:1528139657311};\\\", \\\"{x:1405,y:503,t:1528139657327};\\\", \\\"{x:1397,y:496,t:1528139657344};\\\", \\\"{x:1388,y:490,t:1528139657361};\\\", \\\"{x:1380,y:483,t:1528139657377};\\\", \\\"{x:1372,y:480,t:1528139657393};\\\", \\\"{x:1356,y:475,t:1528139657411};\\\", \\\"{x:1343,y:474,t:1528139657427};\\\", \\\"{x:1334,y:474,t:1528139657444};\\\", \\\"{x:1326,y:474,t:1528139657461};\\\", \\\"{x:1325,y:474,t:1528139657477};\\\", \\\"{x:1323,y:474,t:1528139657495};\\\", \\\"{x:1323,y:475,t:1528139657542};\\\", \\\"{x:1323,y:476,t:1528139657550};\\\", \\\"{x:1323,y:481,t:1528139657561};\\\", \\\"{x:1321,y:486,t:1528139657579};\\\", \\\"{x:1320,y:493,t:1528139657594};\\\", \\\"{x:1319,y:499,t:1528139657614};\\\", \\\"{x:1319,y:500,t:1528139657628};\\\", \\\"{x:1319,y:501,t:1528139657644};\\\", \\\"{x:1318,y:502,t:1528139657734};\\\", \\\"{x:1316,y:503,t:1528139657758};\\\", \\\"{x:1314,y:503,t:1528139657766};\\\", \\\"{x:1312,y:503,t:1528139657776};\\\", \\\"{x:1311,y:504,t:1528139657793};\\\", \\\"{x:1309,y:504,t:1528139657810};\\\", \\\"{x:1310,y:504,t:1528139658151};\\\", \\\"{x:1313,y:502,t:1528139658161};\\\", \\\"{x:1316,y:499,t:1528139658176};\\\", \\\"{x:1319,y:496,t:1528139658195};\\\", \\\"{x:1320,y:495,t:1528139658211};\\\", \\\"{x:1321,y:493,t:1528139658228};\\\", \\\"{x:1317,y:495,t:1528139658772};\\\", \\\"{x:1309,y:496,t:1528139658794};\\\", \\\"{x:1308,y:496,t:1528139658813};\\\", \\\"{x:1306,y:498,t:1528139658829};\\\", \\\"{x:1311,y:498,t:1528139659191};\\\", \\\"{x:1318,y:496,t:1528139659211};\\\", \\\"{x:1319,y:495,t:1528139659229};\\\", \\\"{x:1318,y:495,t:1528139659638};\\\", \\\"{x:1317,y:497,t:1528139692536};\\\", \\\"{x:1282,y:552,t:1528139692554};\\\", \\\"{x:1245,y:603,t:1528139692570};\\\", \\\"{x:1211,y:646,t:1528139692586};\\\", \\\"{x:1151,y:733,t:1528139692609};\\\", \\\"{x:1121,y:782,t:1528139692625};\\\", \\\"{x:1110,y:812,t:1528139692643};\\\", \\\"{x:1104,y:835,t:1528139692659};\\\", \\\"{x:1100,y:852,t:1528139692676};\\\", \\\"{x:1096,y:866,t:1528139692693};\\\", \\\"{x:1094,y:877,t:1528139692709};\\\", \\\"{x:1094,y:886,t:1528139692725};\\\", \\\"{x:1094,y:889,t:1528139692742};\\\", \\\"{x:1093,y:890,t:1528139692768};\\\", \\\"{x:1091,y:890,t:1528139692777};\\\", \\\"{x:1074,y:890,t:1528139692793};\\\", \\\"{x:1044,y:890,t:1528139692809};\\\", \\\"{x:974,y:869,t:1528139692826};\\\", \\\"{x:868,y:830,t:1528139692843};\\\", \\\"{x:752,y:782,t:1528139692859};\\\", \\\"{x:660,y:734,t:1528139692876};\\\", \\\"{x:606,y:692,t:1528139692894};\\\", \\\"{x:589,y:679,t:1528139692909};\\\", \\\"{x:586,y:673,t:1528139692925};\\\", \\\"{x:586,y:668,t:1528139692943};\\\", \\\"{x:588,y:663,t:1528139692959};\\\", \\\"{x:591,y:660,t:1528139692976};\\\", \\\"{x:598,y:653,t:1528139692992};\\\", \\\"{x:602,y:650,t:1528139693009};\\\", \\\"{x:607,y:645,t:1528139693025};\\\", \\\"{x:614,y:640,t:1528139693043};\\\", \\\"{x:625,y:626,t:1528139693059};\\\", \\\"{x:634,y:615,t:1528139693076};\\\", \\\"{x:636,y:606,t:1528139693092};\\\", \\\"{x:638,y:601,t:1528139693110};\\\", \\\"{x:639,y:596,t:1528139693126};\\\", \\\"{x:639,y:592,t:1528139693143};\\\", \\\"{x:639,y:589,t:1528139693159};\\\", \\\"{x:639,y:588,t:1528139693200};\\\", \\\"{x:638,y:588,t:1528139693208};\\\", \\\"{x:635,y:588,t:1528139693226};\\\", \\\"{x:633,y:588,t:1528139693242};\\\", \\\"{x:626,y:592,t:1528139693259};\\\", \\\"{x:619,y:594,t:1528139693276};\\\", \\\"{x:614,y:596,t:1528139693293};\\\", \\\"{x:609,y:597,t:1528139693310};\\\", \\\"{x:606,y:599,t:1528139693326};\\\", \\\"{x:605,y:600,t:1528139693343};\\\", \\\"{x:602,y:601,t:1528139693359};\\\", \\\"{x:600,y:601,t:1528139693375};\\\", \\\"{x:598,y:602,t:1528139693393};\\\", \\\"{x:598,y:603,t:1528139693737};\\\", \\\"{x:598,y:606,t:1528139693744};\\\", \\\"{x:599,y:607,t:1528139693760};\\\", \\\"{x:601,y:611,t:1528139693776};\\\", \\\"{x:602,y:613,t:1528139693792};\\\", \\\"{x:605,y:617,t:1528139693809};\\\", \\\"{x:606,y:618,t:1528139693832};\\\", \\\"{x:607,y:618,t:1528139693889};\\\", \\\"{x:608,y:618,t:1528139694122};\\\", \\\"{x:608,y:617,t:1528139694201};\\\", \\\"{x:608,y:616,t:1528139694211};\\\", \\\"{x:609,y:614,t:1528139694227};\\\", \\\"{x:609,y:613,t:1528139694244};\\\", \\\"{x:608,y:613,t:1528139694456};\\\", \\\"{x:602,y:616,t:1528139694465};\\\", \\\"{x:590,y:627,t:1528139694477};\\\", \\\"{x:573,y:663,t:1528139694493};\\\", \\\"{x:556,y:712,t:1528139694510};\\\", \\\"{x:548,y:749,t:1528139694527};\\\", \\\"{x:534,y:794,t:1528139694544};\\\", \\\"{x:521,y:837,t:1528139694560};\\\", \\\"{x:517,y:855,t:1528139694576};\\\", \\\"{x:516,y:865,t:1528139694594};\\\", \\\"{x:516,y:863,t:1528139694657};\\\", \\\"{x:516,y:858,t:1528139694665};\\\", \\\"{x:516,y:855,t:1528139694677};\\\", \\\"{x:519,y:846,t:1528139694694};\\\", \\\"{x:521,y:842,t:1528139694711};\\\", \\\"{x:522,y:838,t:1528139694727};\\\", \\\"{x:525,y:834,t:1528139694744};\\\", \\\"{x:530,y:826,t:1528139694760};\\\", \\\"{x:535,y:816,t:1528139694776};\\\", \\\"{x:541,y:808,t:1528139694794};\\\", \\\"{x:544,y:799,t:1528139694810};\\\", \\\"{x:547,y:789,t:1528139694827};\\\", \\\"{x:547,y:786,t:1528139694844};\\\", \\\"{x:548,y:784,t:1528139694861};\\\", \\\"{x:548,y:783,t:1528139694937};\\\", \\\"{x:548,y:780,t:1528139694952};\\\", \\\"{x:548,y:778,t:1528139694961};\\\", \\\"{x:548,y:775,t:1528139694979};\\\", \\\"{x:548,y:774,t:1528139694995};\\\", \\\"{x:549,y:772,t:1528139695241};\\\", \\\"{x:550,y:772,t:1528139695248};\\\", \\\"{x:551,y:771,t:1528139695260};\\\", \\\"{x:551,y:770,t:1528139695277};\\\", \\\"{x:555,y:768,t:1528139695293};\\\", \\\"{x:563,y:762,t:1528139695311};\\\", \\\"{x:574,y:752,t:1528139695327};\\\", \\\"{x:588,y:743,t:1528139695344};\\\", \\\"{x:595,y:734,t:1528139695361};\\\", \\\"{x:597,y:731,t:1528139695378};\\\", \\\"{x:598,y:728,t:1528139695395};\\\", \\\"{x:600,y:726,t:1528139695411};\\\", \\\"{x:601,y:723,t:1528139695428};\\\", \\\"{x:603,y:719,t:1528139695445};\\\", \\\"{x:603,y:718,t:1528139695461};\\\", \\\"{x:604,y:715,t:1528139695478};\\\", \\\"{x:605,y:711,t:1528139695495};\\\", \\\"{x:605,y:709,t:1528139695511};\\\", \\\"{x:607,y:707,t:1528139695527};\\\", \\\"{x:609,y:702,t:1528139695545};\\\", \\\"{x:610,y:700,t:1528139695561};\\\", \\\"{x:611,y:699,t:1528139695578};\\\", \\\"{x:612,y:698,t:1528139695595};\\\", \\\"{x:615,y:695,t:1528139695611};\\\", \\\"{x:620,y:692,t:1528139695627};\\\", \\\"{x:623,y:691,t:1528139695645};\\\", \\\"{x:624,y:690,t:1528139695661};\\\", \\\"{x:626,y:689,t:1528139695713};\\\", \\\"{x:629,y:686,t:1528139695728};\\\", \\\"{x:641,y:681,t:1528139695745};\\\", \\\"{x:646,y:677,t:1528139695761};\\\", \\\"{x:656,y:673,t:1528139695778};\\\", \\\"{x:669,y:666,t:1528139695795};\\\", \\\"{x:676,y:663,t:1528139695811};\\\", \\\"{x:679,y:662,t:1528139695828};\\\", \\\"{x:683,y:658,t:1528139695845};\\\", \\\"{x:686,y:656,t:1528139695862};\\\", \\\"{x:689,y:655,t:1528139695878};\\\", \\\"{x:690,y:654,t:1528139695895};\\\", \\\"{x:692,y:654,t:1528139695969};\\\", \\\"{x:694,y:653,t:1528139695977};\\\", \\\"{x:699,y:651,t:1528139695995};\\\", \\\"{x:715,y:645,t:1528139696012};\\\", \\\"{x:735,y:635,t:1528139696028};\\\", \\\"{x:764,y:624,t:1528139696045};\\\", \\\"{x:794,y:616,t:1528139696062};\\\", \\\"{x:819,y:608,t:1528139696078};\\\", \\\"{x:836,y:602,t:1528139696095};\\\", \\\"{x:844,y:597,t:1528139696112};\\\", \\\"{x:846,y:597,t:1528139696128};\\\", \\\"{x:846,y:596,t:1528139696220};\\\", \\\"{x:846,y:590,t:1528139696244};\\\", \\\"{x:845,y:584,t:1528139696262};\\\", \\\"{x:841,y:578,t:1528139696278};\\\", \\\"{x:837,y:573,t:1528139696295};\\\" ] }, { \\\"rt\\\": 5448, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 631077, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:796,y:525,t:1528139696401};\\\", \\\"{x:790,y:517,t:1528139696412};\\\", \\\"{x:779,y:502,t:1528139696428};\\\", \\\"{x:762,y:484,t:1528139696445};\\\", \\\"{x:747,y:468,t:1528139696462};\\\", \\\"{x:731,y:453,t:1528139696479};\\\", \\\"{x:711,y:436,t:1528139696505};\\\", \\\"{x:707,y:433,t:1528139696512};\\\", \\\"{x:706,y:433,t:1528139696529};\\\", \\\"{x:703,y:433,t:1528139696665};\\\", \\\"{x:695,y:433,t:1528139696679};\\\", \\\"{x:673,y:433,t:1528139696696};\\\", \\\"{x:647,y:433,t:1528139696712};\\\", \\\"{x:624,y:433,t:1528139696728};\\\", \\\"{x:620,y:433,t:1528139696746};\\\", \\\"{x:619,y:434,t:1528139696762};\\\", \\\"{x:616,y:436,t:1528139696779};\\\", \\\"{x:611,y:441,t:1528139696797};\\\", \\\"{x:589,y:484,t:1528139696891};\\\", \\\"{x:589,y:485,t:1528139696968};\\\", \\\"{x:592,y:485,t:1528139696979};\\\", \\\"{x:598,y:485,t:1528139696995};\\\", \\\"{x:600,y:485,t:1528139697013};\\\", \\\"{x:604,y:485,t:1528139697178};\\\", \\\"{x:610,y:488,t:1528139697186};\\\", \\\"{x:618,y:493,t:1528139697196};\\\", \\\"{x:629,y:502,t:1528139697213};\\\", \\\"{x:639,y:508,t:1528139697229};\\\", \\\"{x:648,y:513,t:1528139697246};\\\", \\\"{x:652,y:516,t:1528139697262};\\\", \\\"{x:653,y:516,t:1528139697279};\\\", \\\"{x:657,y:516,t:1528139697497};\\\", \\\"{x:676,y:516,t:1528139697514};\\\", \\\"{x:692,y:516,t:1528139697531};\\\", \\\"{x:714,y:516,t:1528139697548};\\\", \\\"{x:736,y:516,t:1528139697565};\\\", \\\"{x:761,y:516,t:1528139697580};\\\", \\\"{x:793,y:516,t:1528139697596};\\\", \\\"{x:849,y:522,t:1528139697613};\\\", \\\"{x:918,y:529,t:1528139697630};\\\", \\\"{x:998,y:540,t:1528139697646};\\\", \\\"{x:1085,y:553,t:1528139697663};\\\", \\\"{x:1170,y:562,t:1528139697680};\\\", \\\"{x:1251,y:575,t:1528139697696};\\\", \\\"{x:1339,y:587,t:1528139697712};\\\", \\\"{x:1384,y:592,t:1528139697730};\\\", \\\"{x:1407,y:595,t:1528139697746};\\\", \\\"{x:1426,y:598,t:1528139697763};\\\", \\\"{x:1435,y:600,t:1528139697780};\\\", \\\"{x:1438,y:600,t:1528139697796};\\\", \\\"{x:1439,y:600,t:1528139698434};\\\", \\\"{x:1440,y:600,t:1528139698465};\\\", \\\"{x:1442,y:600,t:1528139698730};\\\", \\\"{x:1441,y:600,t:1528139698748};\\\", \\\"{x:1387,y:600,t:1528139698765};\\\", \\\"{x:1290,y:600,t:1528139698780};\\\", \\\"{x:1175,y:595,t:1528139698797};\\\", \\\"{x:1048,y:595,t:1528139698815};\\\", \\\"{x:924,y:595,t:1528139698832};\\\", \\\"{x:832,y:593,t:1528139698849};\\\", \\\"{x:762,y:593,t:1528139698864};\\\", \\\"{x:707,y:591,t:1528139698882};\\\", \\\"{x:692,y:591,t:1528139698898};\\\", \\\"{x:687,y:591,t:1528139698914};\\\", \\\"{x:686,y:591,t:1528139698953};\\\", \\\"{x:682,y:589,t:1528139698965};\\\", \\\"{x:663,y:588,t:1528139698981};\\\", \\\"{x:637,y:587,t:1528139698998};\\\", \\\"{x:597,y:586,t:1528139699015};\\\", \\\"{x:554,y:586,t:1528139699031};\\\", \\\"{x:511,y:583,t:1528139699048};\\\", \\\"{x:493,y:581,t:1528139699065};\\\", \\\"{x:488,y:580,t:1528139699080};\\\", \\\"{x:489,y:579,t:1528139699176};\\\", \\\"{x:493,y:578,t:1528139699184};\\\", \\\"{x:500,y:576,t:1528139699199};\\\", \\\"{x:509,y:573,t:1528139699214};\\\", \\\"{x:516,y:570,t:1528139699231};\\\", \\\"{x:518,y:569,t:1528139699247};\\\", \\\"{x:520,y:568,t:1528139699264};\\\", \\\"{x:522,y:568,t:1528139699280};\\\", \\\"{x:526,y:566,t:1528139699297};\\\", \\\"{x:528,y:566,t:1528139699314};\\\", \\\"{x:529,y:566,t:1528139699331};\\\", \\\"{x:531,y:566,t:1528139699441};\\\", \\\"{x:536,y:566,t:1528139699448};\\\", \\\"{x:543,y:565,t:1528139699464};\\\", \\\"{x:565,y:558,t:1528139699481};\\\", \\\"{x:577,y:554,t:1528139699498};\\\", \\\"{x:582,y:553,t:1528139699514};\\\", \\\"{x:584,y:552,t:1528139699531};\\\", \\\"{x:585,y:551,t:1528139699674};\\\", \\\"{x:586,y:551,t:1528139699705};\\\", \\\"{x:587,y:548,t:1528139699715};\\\", \\\"{x:590,y:544,t:1528139699731};\\\", \\\"{x:600,y:530,t:1528139699750};\\\", \\\"{x:604,y:523,t:1528139699766};\\\", \\\"{x:608,y:517,t:1528139699781};\\\", \\\"{x:610,y:510,t:1528139699798};\\\", \\\"{x:611,y:509,t:1528139699815};\\\", \\\"{x:611,y:508,t:1528139699985};\\\", \\\"{x:633,y:506,t:1528139700165};\\\", \\\"{x:665,y:504,t:1528139700183};\\\", \\\"{x:743,y:504,t:1528139700198};\\\", \\\"{x:832,y:504,t:1528139700216};\\\", \\\"{x:904,y:504,t:1528139700232};\\\", \\\"{x:943,y:504,t:1528139700248};\\\", \\\"{x:946,y:504,t:1528139700265};\\\", \\\"{x:945,y:505,t:1528139700345};\\\", \\\"{x:945,y:506,t:1528139700352};\\\", \\\"{x:943,y:506,t:1528139700368};\\\", \\\"{x:942,y:506,t:1528139700381};\\\", \\\"{x:936,y:508,t:1528139700398};\\\", \\\"{x:925,y:511,t:1528139700415};\\\", \\\"{x:911,y:516,t:1528139700431};\\\", \\\"{x:902,y:518,t:1528139700448};\\\", \\\"{x:892,y:522,t:1528139700465};\\\", \\\"{x:884,y:525,t:1528139700483};\\\", \\\"{x:878,y:528,t:1528139700499};\\\", \\\"{x:876,y:529,t:1528139700515};\\\", \\\"{x:875,y:530,t:1528139700552};\\\", \\\"{x:873,y:530,t:1528139700565};\\\", \\\"{x:869,y:531,t:1528139700583};\\\", \\\"{x:867,y:532,t:1528139700599};\\\", \\\"{x:861,y:533,t:1528139700615};\\\", \\\"{x:849,y:534,t:1528139700632};\\\", \\\"{x:843,y:536,t:1528139700648};\\\", \\\"{x:840,y:536,t:1528139700665};\\\", \\\"{x:832,y:538,t:1528139700952};\\\", \\\"{x:811,y:545,t:1528139700966};\\\", \\\"{x:736,y:569,t:1528139700982};\\\", \\\"{x:641,y:600,t:1528139701000};\\\", \\\"{x:518,y:656,t:1528139701016};\\\", \\\"{x:461,y:687,t:1528139701032};\\\", \\\"{x:422,y:711,t:1528139701049};\\\", \\\"{x:403,y:723,t:1528139701066};\\\", \\\"{x:398,y:729,t:1528139701082};\\\", \\\"{x:395,y:734,t:1528139701099};\\\", \\\"{x:394,y:735,t:1528139701116};\\\", \\\"{x:394,y:736,t:1528139701131};\\\", \\\"{x:394,y:737,t:1528139701249};\\\", \\\"{x:395,y:738,t:1528139701266};\\\", \\\"{x:403,y:738,t:1528139701282};\\\", \\\"{x:417,y:740,t:1528139701299};\\\", \\\"{x:429,y:742,t:1528139701316};\\\", \\\"{x:434,y:742,t:1528139701332};\\\", \\\"{x:435,y:743,t:1528139701349};\\\", \\\"{x:436,y:743,t:1528139701505};\\\", \\\"{x:439,y:743,t:1528139701516};\\\", \\\"{x:448,y:743,t:1528139701533};\\\", \\\"{x:462,y:743,t:1528139701549};\\\", \\\"{x:488,y:743,t:1528139701566};\\\", \\\"{x:513,y:743,t:1528139701583};\\\", \\\"{x:531,y:744,t:1528139701600};\\\", \\\"{x:533,y:745,t:1528139701616};\\\", \\\"{x:534,y:745,t:1528139702305};\\\", \\\"{x:534,y:744,t:1528139702673};\\\", \\\"{x:535,y:744,t:1528139702683};\\\" ] }, { \\\"rt\\\": 35103, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 667539, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -F -F -F -F -B -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:743,t:1528139703206};\\\", \\\"{x:535,y:737,t:1528139704153};\\\", \\\"{x:538,y:728,t:1528139704168};\\\", \\\"{x:544,y:717,t:1528139704185};\\\", \\\"{x:550,y:707,t:1528139704201};\\\", \\\"{x:555,y:699,t:1528139704218};\\\", \\\"{x:559,y:690,t:1528139704235};\\\", \\\"{x:561,y:679,t:1528139704252};\\\", \\\"{x:570,y:667,t:1528139704269};\\\", \\\"{x:574,y:656,t:1528139704285};\\\", \\\"{x:580,y:647,t:1528139704301};\\\", \\\"{x:590,y:633,t:1528139704319};\\\", \\\"{x:598,y:620,t:1528139704336};\\\", \\\"{x:601,y:614,t:1528139704352};\\\", \\\"{x:608,y:603,t:1528139704369};\\\", \\\"{x:614,y:594,t:1528139704386};\\\", \\\"{x:618,y:588,t:1528139704403};\\\", \\\"{x:629,y:577,t:1528139704419};\\\", \\\"{x:645,y:564,t:1528139704436};\\\", \\\"{x:660,y:558,t:1528139704453};\\\", \\\"{x:673,y:550,t:1528139704470};\\\", \\\"{x:684,y:545,t:1528139704486};\\\", \\\"{x:705,y:538,t:1528139704502};\\\", \\\"{x:754,y:521,t:1528139704519};\\\", \\\"{x:796,y:511,t:1528139704536};\\\", \\\"{x:838,y:504,t:1528139704552};\\\", \\\"{x:954,y:488,t:1528139704569};\\\", \\\"{x:1039,y:480,t:1528139704585};\\\", \\\"{x:1109,y:477,t:1528139704601};\\\", \\\"{x:1179,y:477,t:1528139704619};\\\", \\\"{x:1257,y:477,t:1528139704636};\\\", \\\"{x:1337,y:477,t:1528139704651};\\\", \\\"{x:1407,y:477,t:1528139704669};\\\", \\\"{x:1465,y:477,t:1528139704685};\\\", \\\"{x:1513,y:477,t:1528139704702};\\\", \\\"{x:1556,y:477,t:1528139704718};\\\", \\\"{x:1584,y:477,t:1528139704735};\\\", \\\"{x:1602,y:477,t:1528139704752};\\\", \\\"{x:1614,y:477,t:1528139704769};\\\", \\\"{x:1615,y:477,t:1528139705561};\\\", \\\"{x:1610,y:480,t:1528139706610};\\\", \\\"{x:1603,y:482,t:1528139706617};\\\", \\\"{x:1587,y:490,t:1528139706633};\\\", \\\"{x:1573,y:498,t:1528139706649};\\\", \\\"{x:1564,y:503,t:1528139706666};\\\", \\\"{x:1557,y:508,t:1528139706683};\\\", \\\"{x:1553,y:511,t:1528139706699};\\\", \\\"{x:1551,y:513,t:1528139706715};\\\", \\\"{x:1548,y:515,t:1528139706733};\\\", \\\"{x:1546,y:518,t:1528139706749};\\\", \\\"{x:1544,y:521,t:1528139706766};\\\", \\\"{x:1543,y:524,t:1528139706783};\\\", \\\"{x:1541,y:527,t:1528139706799};\\\", \\\"{x:1539,y:529,t:1528139706816};\\\", \\\"{x:1533,y:537,t:1528139706833};\\\", \\\"{x:1530,y:544,t:1528139706849};\\\", \\\"{x:1524,y:555,t:1528139706866};\\\", \\\"{x:1518,y:564,t:1528139706883};\\\", \\\"{x:1509,y:577,t:1528139706899};\\\", \\\"{x:1496,y:588,t:1528139706916};\\\", \\\"{x:1484,y:596,t:1528139706933};\\\", \\\"{x:1471,y:602,t:1528139706949};\\\", \\\"{x:1461,y:607,t:1528139706966};\\\", \\\"{x:1454,y:610,t:1528139706982};\\\", \\\"{x:1446,y:613,t:1528139706999};\\\", \\\"{x:1435,y:615,t:1528139707016};\\\", \\\"{x:1422,y:618,t:1528139707032};\\\", \\\"{x:1404,y:618,t:1528139707049};\\\", \\\"{x:1394,y:618,t:1528139707066};\\\", \\\"{x:1389,y:618,t:1528139707082};\\\", \\\"{x:1385,y:618,t:1528139707099};\\\", \\\"{x:1382,y:618,t:1528139707116};\\\", \\\"{x:1380,y:618,t:1528139707177};\\\", \\\"{x:1377,y:618,t:1528139707185};\\\", \\\"{x:1375,y:618,t:1528139707199};\\\", \\\"{x:1366,y:618,t:1528139707215};\\\", \\\"{x:1357,y:618,t:1528139707232};\\\", \\\"{x:1347,y:618,t:1528139707249};\\\", \\\"{x:1342,y:618,t:1528139707265};\\\", \\\"{x:1338,y:618,t:1528139707282};\\\", \\\"{x:1333,y:618,t:1528139707298};\\\", \\\"{x:1330,y:618,t:1528139707315};\\\", \\\"{x:1328,y:618,t:1528139707332};\\\", \\\"{x:1327,y:618,t:1528139707402};\\\", \\\"{x:1324,y:617,t:1528139707415};\\\", \\\"{x:1311,y:617,t:1528139707432};\\\", \\\"{x:1296,y:617,t:1528139707448};\\\", \\\"{x:1267,y:617,t:1528139707465};\\\", \\\"{x:1251,y:615,t:1528139707482};\\\", \\\"{x:1246,y:615,t:1528139707498};\\\", \\\"{x:1245,y:614,t:1528139707515};\\\", \\\"{x:1245,y:616,t:1528139707626};\\\", \\\"{x:1245,y:620,t:1528139707633};\\\", \\\"{x:1245,y:626,t:1528139707648};\\\", \\\"{x:1245,y:640,t:1528139707665};\\\", \\\"{x:1245,y:646,t:1528139707681};\\\", \\\"{x:1245,y:650,t:1528139707698};\\\", \\\"{x:1245,y:653,t:1528139707715};\\\", \\\"{x:1245,y:654,t:1528139707731};\\\", \\\"{x:1245,y:655,t:1528139707748};\\\", \\\"{x:1245,y:656,t:1528139707842};\\\", \\\"{x:1245,y:658,t:1528139707849};\\\", \\\"{x:1245,y:663,t:1528139707865};\\\", \\\"{x:1245,y:668,t:1528139707881};\\\", \\\"{x:1245,y:674,t:1528139707898};\\\", \\\"{x:1245,y:680,t:1528139707914};\\\", \\\"{x:1245,y:684,t:1528139707931};\\\", \\\"{x:1245,y:687,t:1528139707948};\\\", \\\"{x:1245,y:688,t:1528139707964};\\\", \\\"{x:1245,y:690,t:1528139707981};\\\", \\\"{x:1245,y:691,t:1528139707998};\\\", \\\"{x:1245,y:693,t:1528139708014};\\\", \\\"{x:1247,y:694,t:1528139708218};\\\", \\\"{x:1250,y:695,t:1528139708230};\\\", \\\"{x:1260,y:696,t:1528139708247};\\\", \\\"{x:1271,y:699,t:1528139708265};\\\", \\\"{x:1287,y:699,t:1528139708281};\\\", \\\"{x:1305,y:699,t:1528139708296};\\\", \\\"{x:1326,y:699,t:1528139708314};\\\", \\\"{x:1347,y:699,t:1528139708331};\\\", \\\"{x:1368,y:699,t:1528139708347};\\\", \\\"{x:1382,y:699,t:1528139708363};\\\", \\\"{x:1383,y:699,t:1528139708381};\\\", \\\"{x:1383,y:698,t:1528139708546};\\\", \\\"{x:1381,y:697,t:1528139708564};\\\", \\\"{x:1379,y:697,t:1528139708580};\\\", \\\"{x:1378,y:697,t:1528139708714};\\\", \\\"{x:1376,y:697,t:1528139708786};\\\", \\\"{x:1374,y:699,t:1528139708797};\\\", \\\"{x:1372,y:700,t:1528139708813};\\\", \\\"{x:1371,y:702,t:1528139708830};\\\", \\\"{x:1369,y:704,t:1528139708846};\\\", \\\"{x:1368,y:704,t:1528139708863};\\\", \\\"{x:1367,y:705,t:1528139708880};\\\", \\\"{x:1366,y:706,t:1528139709010};\\\", \\\"{x:1365,y:707,t:1528139709017};\\\", \\\"{x:1364,y:707,t:1528139709033};\\\", \\\"{x:1362,y:709,t:1528139709046};\\\", \\\"{x:1359,y:709,t:1528139709063};\\\", \\\"{x:1356,y:710,t:1528139709080};\\\", \\\"{x:1353,y:711,t:1528139709096};\\\", \\\"{x:1352,y:711,t:1528139709113};\\\", \\\"{x:1351,y:712,t:1528139709234};\\\", \\\"{x:1351,y:711,t:1528139710441};\\\", \\\"{x:1351,y:710,t:1528139710449};\\\", \\\"{x:1351,y:708,t:1528139710462};\\\", \\\"{x:1349,y:703,t:1528139710478};\\\", \\\"{x:1348,y:700,t:1528139710495};\\\", \\\"{x:1348,y:698,t:1528139710511};\\\", \\\"{x:1347,y:695,t:1528139710527};\\\", \\\"{x:1347,y:693,t:1528139710544};\\\", \\\"{x:1347,y:691,t:1528139710561};\\\", \\\"{x:1347,y:692,t:1528139711034};\\\", \\\"{x:1347,y:693,t:1528139711121};\\\", \\\"{x:1347,y:694,t:1528139711137};\\\", \\\"{x:1347,y:695,t:1528139711202};\\\", \\\"{x:1346,y:695,t:1528139712017};\\\", \\\"{x:1339,y:696,t:1528139712026};\\\", \\\"{x:1313,y:701,t:1528139712042};\\\", \\\"{x:1287,y:701,t:1528139712059};\\\", \\\"{x:1262,y:701,t:1528139712075};\\\", \\\"{x:1239,y:701,t:1528139712092};\\\", \\\"{x:1218,y:701,t:1528139712109};\\\", \\\"{x:1197,y:701,t:1528139712125};\\\", \\\"{x:1181,y:701,t:1528139712142};\\\", \\\"{x:1168,y:701,t:1528139712159};\\\", \\\"{x:1161,y:701,t:1528139712175};\\\", \\\"{x:1159,y:701,t:1528139712192};\\\", \\\"{x:1156,y:701,t:1528139712208};\\\", \\\"{x:1154,y:701,t:1528139712225};\\\", \\\"{x:1156,y:702,t:1528139712354};\\\", \\\"{x:1160,y:702,t:1528139712361};\\\", \\\"{x:1165,y:704,t:1528139712376};\\\", \\\"{x:1172,y:704,t:1528139712392};\\\", \\\"{x:1181,y:704,t:1528139712408};\\\", \\\"{x:1197,y:704,t:1528139712425};\\\", \\\"{x:1210,y:704,t:1528139712441};\\\", \\\"{x:1219,y:704,t:1528139712459};\\\", \\\"{x:1224,y:704,t:1528139712475};\\\", \\\"{x:1226,y:704,t:1528139712491};\\\", \\\"{x:1231,y:704,t:1528139712508};\\\", \\\"{x:1238,y:705,t:1528139712525};\\\", \\\"{x:1241,y:705,t:1528139712541};\\\", \\\"{x:1242,y:705,t:1528139712633};\\\", \\\"{x:1246,y:705,t:1528139712641};\\\", \\\"{x:1253,y:705,t:1528139712658};\\\", \\\"{x:1259,y:705,t:1528139712675};\\\", \\\"{x:1269,y:703,t:1528139712691};\\\", \\\"{x:1277,y:701,t:1528139712708};\\\", \\\"{x:1279,y:700,t:1528139712724};\\\", \\\"{x:1281,y:700,t:1528139712842};\\\", \\\"{x:1289,y:698,t:1528139712857};\\\", \\\"{x:1299,y:695,t:1528139712874};\\\", \\\"{x:1308,y:695,t:1528139712890};\\\", \\\"{x:1315,y:694,t:1528139712907};\\\", \\\"{x:1317,y:694,t:1528139712924};\\\", \\\"{x:1318,y:694,t:1528139713122};\\\", \\\"{x:1321,y:694,t:1528139713129};\\\", \\\"{x:1326,y:694,t:1528139713140};\\\", \\\"{x:1337,y:694,t:1528139713157};\\\", \\\"{x:1347,y:694,t:1528139713174};\\\", \\\"{x:1352,y:694,t:1528139713190};\\\", \\\"{x:1353,y:694,t:1528139713265};\\\", \\\"{x:1353,y:695,t:1528139713297};\\\", \\\"{x:1353,y:696,t:1528139717138};\\\", \\\"{x:1353,y:697,t:1528139717233};\\\", \\\"{x:1353,y:698,t:1528139717386};\\\", \\\"{x:1353,y:702,t:1528139717402};\\\", \\\"{x:1353,y:706,t:1528139717419};\\\", \\\"{x:1353,y:710,t:1528139717434};\\\", \\\"{x:1350,y:716,t:1528139717451};\\\", \\\"{x:1350,y:729,t:1528139717468};\\\", \\\"{x:1350,y:742,t:1528139717484};\\\", \\\"{x:1350,y:750,t:1528139717501};\\\", \\\"{x:1350,y:759,t:1528139717519};\\\", \\\"{x:1349,y:765,t:1528139717534};\\\", \\\"{x:1349,y:767,t:1528139717551};\\\", \\\"{x:1350,y:767,t:1528139717921};\\\", \\\"{x:1351,y:767,t:1528139718345};\\\", \\\"{x:1350,y:767,t:1528139723064};\\\", \\\"{x:1346,y:767,t:1528139723076};\\\", \\\"{x:1341,y:767,t:1528139723094};\\\", \\\"{x:1339,y:767,t:1528139723110};\\\", \\\"{x:1338,y:767,t:1528139723329};\\\", \\\"{x:1337,y:766,t:1528139723344};\\\", \\\"{x:1336,y:766,t:1528139723359};\\\", \\\"{x:1335,y:763,t:1528139723377};\\\", \\\"{x:1335,y:762,t:1528139723393};\\\", \\\"{x:1335,y:761,t:1528139723417};\\\", \\\"{x:1335,y:760,t:1528139723642};\\\", \\\"{x:1337,y:760,t:1528139723660};\\\", \\\"{x:1338,y:760,t:1528139723676};\\\", \\\"{x:1340,y:760,t:1528139723693};\\\", \\\"{x:1342,y:760,t:1528139723709};\\\", \\\"{x:1343,y:760,t:1528139723914};\\\", \\\"{x:1344,y:759,t:1528139723977};\\\", \\\"{x:1344,y:759,t:1528139724066};\\\", \\\"{x:1345,y:758,t:1528139724257};\\\", \\\"{x:1348,y:758,t:1528139724265};\\\", \\\"{x:1353,y:758,t:1528139724276};\\\", \\\"{x:1359,y:756,t:1528139724292};\\\", \\\"{x:1360,y:756,t:1528139724309};\\\", \\\"{x:1360,y:755,t:1528139724417};\\\", \\\"{x:1360,y:754,t:1528139724449};\\\", \\\"{x:1360,y:753,t:1528139724465};\\\", \\\"{x:1360,y:752,t:1528139724475};\\\", \\\"{x:1359,y:752,t:1528139724632};\\\", \\\"{x:1358,y:751,t:1528139724648};\\\", \\\"{x:1357,y:749,t:1528139724658};\\\", \\\"{x:1355,y:745,t:1528139724674};\\\", \\\"{x:1354,y:741,t:1528139724691};\\\", \\\"{x:1352,y:736,t:1528139724707};\\\", \\\"{x:1349,y:731,t:1528139724725};\\\", \\\"{x:1348,y:728,t:1528139724741};\\\", \\\"{x:1346,y:728,t:1528139724757};\\\", \\\"{x:1345,y:728,t:1528139724784};\\\", \\\"{x:1344,y:728,t:1528139724793};\\\", \\\"{x:1343,y:728,t:1528139724808};\\\", \\\"{x:1343,y:727,t:1528139724824};\\\", \\\"{x:1342,y:727,t:1528139724945};\\\", \\\"{x:1341,y:727,t:1528139724985};\\\", \\\"{x:1340,y:727,t:1528139724993};\\\", \\\"{x:1339,y:727,t:1528139725008};\\\", \\\"{x:1338,y:727,t:1528139725033};\\\", \\\"{x:1337,y:730,t:1528139725265};\\\", \\\"{x:1342,y:739,t:1528139725274};\\\", \\\"{x:1348,y:760,t:1528139725291};\\\", \\\"{x:1351,y:771,t:1528139725309};\\\", \\\"{x:1352,y:771,t:1528139725324};\\\", \\\"{x:1352,y:772,t:1528139725341};\\\", \\\"{x:1350,y:772,t:1528139725482};\\\", \\\"{x:1348,y:772,t:1528139725491};\\\", \\\"{x:1346,y:772,t:1528139725507};\\\", \\\"{x:1342,y:771,t:1528139725524};\\\", \\\"{x:1339,y:769,t:1528139725541};\\\", \\\"{x:1331,y:766,t:1528139725557};\\\", \\\"{x:1327,y:764,t:1528139725573};\\\", \\\"{x:1321,y:763,t:1528139725591};\\\", \\\"{x:1318,y:761,t:1528139725608};\\\", \\\"{x:1317,y:760,t:1528139725624};\\\", \\\"{x:1316,y:759,t:1528139725641};\\\", \\\"{x:1316,y:757,t:1528139725674};\\\", \\\"{x:1321,y:751,t:1528139725690};\\\", \\\"{x:1326,y:750,t:1528139725707};\\\", \\\"{x:1328,y:750,t:1528139725724};\\\", \\\"{x:1334,y:750,t:1528139725740};\\\", \\\"{x:1338,y:750,t:1528139725757};\\\", \\\"{x:1339,y:750,t:1528139725777};\\\", \\\"{x:1341,y:751,t:1528139725817};\\\", \\\"{x:1341,y:752,t:1528139725906};\\\", \\\"{x:1341,y:753,t:1528139725923};\\\", \\\"{x:1342,y:761,t:1528139725940};\\\", \\\"{x:1342,y:771,t:1528139725957};\\\", \\\"{x:1342,y:775,t:1528139725973};\\\", \\\"{x:1340,y:782,t:1528139725990};\\\", \\\"{x:1338,y:787,t:1528139726007};\\\", \\\"{x:1338,y:788,t:1528139726022};\\\", \\\"{x:1338,y:789,t:1528139726114};\\\", \\\"{x:1338,y:787,t:1528139726289};\\\", \\\"{x:1338,y:783,t:1528139726306};\\\", \\\"{x:1338,y:781,t:1528139726323};\\\", \\\"{x:1339,y:780,t:1528139726340};\\\", \\\"{x:1340,y:778,t:1528139726356};\\\", \\\"{x:1340,y:777,t:1528139726373};\\\", \\\"{x:1341,y:776,t:1528139726401};\\\", \\\"{x:1341,y:773,t:1528139726465};\\\", \\\"{x:1342,y:771,t:1528139726481};\\\", \\\"{x:1342,y:770,t:1528139726489};\\\", \\\"{x:1342,y:769,t:1528139726506};\\\", \\\"{x:1343,y:767,t:1528139726523};\\\", \\\"{x:1344,y:767,t:1528139726539};\\\", \\\"{x:1344,y:766,t:1528139728369};\\\", \\\"{x:1336,y:766,t:1528139736534};\\\", \\\"{x:1301,y:766,t:1528139736546};\\\", \\\"{x:1174,y:766,t:1528139736562};\\\", \\\"{x:1030,y:766,t:1528139736579};\\\", \\\"{x:778,y:760,t:1528139736597};\\\", \\\"{x:697,y:757,t:1528139736611};\\\", \\\"{x:484,y:736,t:1528139736630};\\\", \\\"{x:387,y:724,t:1528139736645};\\\", \\\"{x:337,y:717,t:1528139736662};\\\", \\\"{x:317,y:713,t:1528139736681};\\\", \\\"{x:315,y:713,t:1528139736697};\\\", \\\"{x:314,y:713,t:1528139736724};\\\", \\\"{x:314,y:712,t:1528139736779};\\\", \\\"{x:314,y:709,t:1528139736796};\\\", \\\"{x:315,y:701,t:1528139736813};\\\", \\\"{x:318,y:693,t:1528139736830};\\\", \\\"{x:327,y:683,t:1528139736847};\\\", \\\"{x:343,y:675,t:1528139736864};\\\", \\\"{x:357,y:666,t:1528139736882};\\\", \\\"{x:366,y:661,t:1528139736896};\\\", \\\"{x:375,y:657,t:1528139736916};\\\", \\\"{x:378,y:657,t:1528139736932};\\\", \\\"{x:379,y:656,t:1528139736948};\\\", \\\"{x:380,y:656,t:1528139737248};\\\", \\\"{x:383,y:656,t:1528139737265};\\\", \\\"{x:390,y:656,t:1528139737282};\\\", \\\"{x:394,y:656,t:1528139737298};\\\", \\\"{x:401,y:660,t:1528139737315};\\\", \\\"{x:407,y:664,t:1528139737331};\\\", \\\"{x:410,y:668,t:1528139737348};\\\", \\\"{x:412,y:670,t:1528139737365};\\\", \\\"{x:414,y:671,t:1528139737382};\\\", \\\"{x:416,y:672,t:1528139737398};\\\", \\\"{x:417,y:673,t:1528139737415};\\\", \\\"{x:420,y:673,t:1528139737432};\\\", \\\"{x:425,y:676,t:1528139737448};\\\", \\\"{x:428,y:676,t:1528139737465};\\\", \\\"{x:429,y:676,t:1528139737492};\\\", \\\"{x:430,y:676,t:1528139737500};\\\", \\\"{x:438,y:676,t:1528139737515};\\\", \\\"{x:445,y:676,t:1528139737532};\\\", \\\"{x:451,y:676,t:1528139737548};\\\", \\\"{x:455,y:677,t:1528139737659};\\\", \\\"{x:459,y:678,t:1528139737667};\\\", \\\"{x:469,y:680,t:1528139737682};\\\", \\\"{x:487,y:682,t:1528139737698};\\\", \\\"{x:511,y:686,t:1528139737715};\\\", \\\"{x:516,y:687,t:1528139737732};\\\", \\\"{x:517,y:687,t:1528139737748};\\\", \\\"{x:518,y:688,t:1528139737819};\\\", \\\"{x:519,y:689,t:1528139737832};\\\", \\\"{x:519,y:690,t:1528139737852};\\\", \\\"{x:520,y:691,t:1528139737917};\\\", \\\"{x:520,y:694,t:1528139737932};\\\", \\\"{x:521,y:701,t:1528139737949};\\\", \\\"{x:521,y:715,t:1528139737965};\\\", \\\"{x:519,y:725,t:1528139737984};\\\", \\\"{x:517,y:735,t:1528139737999};\\\", \\\"{x:516,y:742,t:1528139738015};\\\", \\\"{x:515,y:746,t:1528139738032};\\\", \\\"{x:515,y:747,t:1528139738048};\\\", \\\"{x:514,y:747,t:1528139738251};\\\", \\\"{x:512,y:747,t:1528139738331};\\\", \\\"{x:510,y:747,t:1528139738596};\\\", \\\"{x:510,y:746,t:1528139738619};\\\", \\\"{x:509,y:746,t:1528139738660};\\\", \\\"{x:508,y:745,t:1528139738716};\\\" ] }, { \\\"rt\\\": 11333, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 680161, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:744,t:1528139739836};\\\", \\\"{x:507,y:743,t:1528139740661};\\\", \\\"{x:507,y:739,t:1528139740668};\\\", \\\"{x:510,y:732,t:1528139740682};\\\", \\\"{x:523,y:719,t:1528139740701};\\\", \\\"{x:539,y:709,t:1528139740716};\\\", \\\"{x:553,y:701,t:1528139740734};\\\", \\\"{x:565,y:693,t:1528139740751};\\\", \\\"{x:576,y:688,t:1528139740768};\\\", \\\"{x:585,y:684,t:1528139740785};\\\", \\\"{x:592,y:681,t:1528139740801};\\\", \\\"{x:597,y:679,t:1528139740818};\\\", \\\"{x:609,y:674,t:1528139740835};\\\", \\\"{x:616,y:672,t:1528139740851};\\\", \\\"{x:622,y:669,t:1528139740868};\\\", \\\"{x:633,y:665,t:1528139740885};\\\", \\\"{x:653,y:659,t:1528139740901};\\\", \\\"{x:673,y:651,t:1528139740918};\\\", \\\"{x:686,y:648,t:1528139740935};\\\", \\\"{x:702,y:644,t:1528139740951};\\\", \\\"{x:716,y:640,t:1528139740968};\\\", \\\"{x:728,y:636,t:1528139740985};\\\", \\\"{x:735,y:634,t:1528139741001};\\\", \\\"{x:745,y:631,t:1528139741019};\\\", \\\"{x:766,y:625,t:1528139741035};\\\", \\\"{x:795,y:619,t:1528139741051};\\\", \\\"{x:861,y:604,t:1528139741068};\\\", \\\"{x:992,y:578,t:1528139741085};\\\", \\\"{x:1172,y:547,t:1528139741101};\\\", \\\"{x:1383,y:512,t:1528139741118};\\\", \\\"{x:1618,y:474,t:1528139741135};\\\", \\\"{x:1872,y:439,t:1528139741151};\\\", \\\"{x:1919,y:406,t:1528139741168};\\\", \\\"{x:1919,y:394,t:1528139741185};\\\", \\\"{x:1919,y:389,t:1528139741201};\\\", \\\"{x:1919,y:388,t:1528139741218};\\\", \\\"{x:1919,y:389,t:1528139741444};\\\", \\\"{x:1918,y:393,t:1528139741451};\\\", \\\"{x:1907,y:400,t:1528139741469};\\\", \\\"{x:1896,y:409,t:1528139741486};\\\", \\\"{x:1885,y:416,t:1528139741501};\\\", \\\"{x:1873,y:424,t:1528139741518};\\\", \\\"{x:1868,y:428,t:1528139741535};\\\", \\\"{x:1865,y:431,t:1528139741553};\\\", \\\"{x:1860,y:433,t:1528139741569};\\\", \\\"{x:1858,y:436,t:1528139741585};\\\", \\\"{x:1857,y:436,t:1528139741602};\\\", \\\"{x:1854,y:438,t:1528139741619};\\\", \\\"{x:1848,y:441,t:1528139741635};\\\", \\\"{x:1845,y:443,t:1528139741652};\\\", \\\"{x:1840,y:446,t:1528139741669};\\\", \\\"{x:1836,y:449,t:1528139741686};\\\", \\\"{x:1834,y:451,t:1528139741702};\\\", \\\"{x:1829,y:455,t:1528139741719};\\\", \\\"{x:1826,y:456,t:1528139741736};\\\", \\\"{x:1823,y:458,t:1528139741752};\\\", \\\"{x:1820,y:459,t:1528139741769};\\\", \\\"{x:1817,y:461,t:1528139741786};\\\", \\\"{x:1813,y:463,t:1528139741803};\\\", \\\"{x:1808,y:465,t:1528139741819};\\\", \\\"{x:1796,y:468,t:1528139741836};\\\", \\\"{x:1790,y:471,t:1528139741852};\\\", \\\"{x:1778,y:475,t:1528139741869};\\\", \\\"{x:1768,y:477,t:1528139741886};\\\", \\\"{x:1759,y:480,t:1528139741903};\\\", \\\"{x:1749,y:484,t:1528139741919};\\\", \\\"{x:1743,y:486,t:1528139741935};\\\", \\\"{x:1734,y:489,t:1528139741952};\\\", \\\"{x:1715,y:497,t:1528139741970};\\\", \\\"{x:1691,y:503,t:1528139741985};\\\", \\\"{x:1666,y:510,t:1528139742003};\\\", \\\"{x:1631,y:521,t:1528139742020};\\\", \\\"{x:1606,y:528,t:1528139742035};\\\", \\\"{x:1579,y:535,t:1528139742053};\\\", \\\"{x:1558,y:542,t:1528139742069};\\\", \\\"{x:1544,y:545,t:1528139742086};\\\", \\\"{x:1534,y:549,t:1528139742103};\\\", \\\"{x:1532,y:550,t:1528139742120};\\\", \\\"{x:1530,y:552,t:1528139742136};\\\", \\\"{x:1529,y:552,t:1528139742152};\\\", \\\"{x:1529,y:554,t:1528139742220};\\\", \\\"{x:1529,y:555,t:1528139742252};\\\", \\\"{x:1528,y:561,t:1528139742270};\\\", \\\"{x:1523,y:569,t:1528139742286};\\\", \\\"{x:1520,y:575,t:1528139742303};\\\", \\\"{x:1515,y:581,t:1528139742319};\\\", \\\"{x:1513,y:586,t:1528139742335};\\\", \\\"{x:1509,y:593,t:1528139742353};\\\", \\\"{x:1508,y:596,t:1528139742370};\\\", \\\"{x:1507,y:596,t:1528139742387};\\\", \\\"{x:1507,y:598,t:1528139742402};\\\", \\\"{x:1507,y:599,t:1528139742436};\\\", \\\"{x:1505,y:602,t:1528139742453};\\\", \\\"{x:1500,y:614,t:1528139742470};\\\", \\\"{x:1498,y:619,t:1528139742487};\\\", \\\"{x:1494,y:623,t:1528139742502};\\\", \\\"{x:1491,y:625,t:1528139742520};\\\", \\\"{x:1488,y:629,t:1528139742537};\\\", \\\"{x:1484,y:634,t:1528139742553};\\\", \\\"{x:1482,y:638,t:1528139742569};\\\", \\\"{x:1479,y:643,t:1528139742587};\\\", \\\"{x:1478,y:647,t:1528139742602};\\\", \\\"{x:1476,y:659,t:1528139742620};\\\", \\\"{x:1476,y:670,t:1528139742636};\\\", \\\"{x:1473,y:680,t:1528139742653};\\\", \\\"{x:1473,y:686,t:1528139742670};\\\", \\\"{x:1472,y:688,t:1528139742687};\\\", \\\"{x:1472,y:689,t:1528139742724};\\\", \\\"{x:1472,y:691,t:1528139742741};\\\", \\\"{x:1472,y:692,t:1528139742753};\\\", \\\"{x:1473,y:693,t:1528139742772};\\\", \\\"{x:1473,y:695,t:1528139743252};\\\", \\\"{x:1473,y:696,t:1528139743271};\\\", \\\"{x:1473,y:699,t:1528139743287};\\\", \\\"{x:1473,y:700,t:1528139743316};\\\", \\\"{x:1473,y:701,t:1528139743340};\\\", \\\"{x:1473,y:702,t:1528139743364};\\\", \\\"{x:1473,y:703,t:1528139743372};\\\", \\\"{x:1473,y:704,t:1528139743388};\\\", \\\"{x:1467,y:702,t:1528139743557};\\\", \\\"{x:1452,y:692,t:1528139743571};\\\", \\\"{x:1391,y:656,t:1528139743588};\\\", \\\"{x:1365,y:641,t:1528139743604};\\\", \\\"{x:1353,y:633,t:1528139743621};\\\", \\\"{x:1349,y:629,t:1528139743638};\\\", \\\"{x:1347,y:628,t:1528139743654};\\\", \\\"{x:1347,y:626,t:1528139743677};\\\", \\\"{x:1347,y:625,t:1528139743700};\\\", \\\"{x:1347,y:623,t:1528139743708};\\\", \\\"{x:1347,y:622,t:1528139743721};\\\", \\\"{x:1348,y:617,t:1528139743738};\\\", \\\"{x:1351,y:613,t:1528139743754};\\\", \\\"{x:1354,y:608,t:1528139743771};\\\", \\\"{x:1362,y:600,t:1528139743788};\\\", \\\"{x:1367,y:596,t:1528139743804};\\\", \\\"{x:1370,y:595,t:1528139743821};\\\", \\\"{x:1373,y:594,t:1528139743838};\\\", \\\"{x:1375,y:593,t:1528139743854};\\\", \\\"{x:1380,y:591,t:1528139743871};\\\", \\\"{x:1386,y:587,t:1528139743888};\\\", \\\"{x:1398,y:586,t:1528139743904};\\\", \\\"{x:1401,y:583,t:1528139743921};\\\", \\\"{x:1402,y:583,t:1528139743948};\\\", \\\"{x:1403,y:583,t:1528139743972};\\\", \\\"{x:1410,y:581,t:1528139743988};\\\", \\\"{x:1418,y:579,t:1528139744005};\\\", \\\"{x:1423,y:577,t:1528139744021};\\\", \\\"{x:1423,y:576,t:1528139744077};\\\", \\\"{x:1423,y:574,t:1528139744213};\\\", \\\"{x:1421,y:570,t:1528139744221};\\\", \\\"{x:1414,y:560,t:1528139744240};\\\", \\\"{x:1406,y:552,t:1528139744255};\\\", \\\"{x:1400,y:547,t:1528139744271};\\\", \\\"{x:1396,y:544,t:1528139744287};\\\", \\\"{x:1402,y:544,t:1528139744461};\\\", \\\"{x:1407,y:544,t:1528139744472};\\\", \\\"{x:1416,y:544,t:1528139744488};\\\", \\\"{x:1424,y:544,t:1528139744504};\\\", \\\"{x:1428,y:545,t:1528139744522};\\\", \\\"{x:1433,y:546,t:1528139744538};\\\", \\\"{x:1435,y:547,t:1528139744555};\\\", \\\"{x:1441,y:550,t:1528139744572};\\\", \\\"{x:1445,y:553,t:1528139744588};\\\", \\\"{x:1446,y:554,t:1528139744605};\\\", \\\"{x:1447,y:554,t:1528139744622};\\\", \\\"{x:1447,y:555,t:1528139744644};\\\", \\\"{x:1447,y:558,t:1528139744660};\\\", \\\"{x:1440,y:558,t:1528139744672};\\\", \\\"{x:1398,y:558,t:1528139744688};\\\", \\\"{x:1348,y:558,t:1528139744705};\\\", \\\"{x:1300,y:558,t:1528139744722};\\\", \\\"{x:1281,y:558,t:1528139744738};\\\", \\\"{x:1280,y:558,t:1528139744754};\\\", \\\"{x:1279,y:558,t:1528139744772};\\\", \\\"{x:1279,y:556,t:1528139744789};\\\", \\\"{x:1282,y:552,t:1528139744804};\\\", \\\"{x:1307,y:549,t:1528139744823};\\\", \\\"{x:1334,y:538,t:1528139744839};\\\", \\\"{x:1359,y:530,t:1528139744855};\\\", \\\"{x:1387,y:520,t:1528139744872};\\\", \\\"{x:1406,y:515,t:1528139744889};\\\", \\\"{x:1421,y:511,t:1528139744905};\\\", \\\"{x:1430,y:510,t:1528139744921};\\\", \\\"{x:1432,y:510,t:1528139744939};\\\", \\\"{x:1433,y:510,t:1528139744964};\\\", \\\"{x:1433,y:509,t:1528139744980};\\\", \\\"{x:1434,y:509,t:1528139745061};\\\", \\\"{x:1435,y:508,t:1528139745072};\\\", \\\"{x:1436,y:507,t:1528139745189};\\\", \\\"{x:1447,y:503,t:1528139745205};\\\", \\\"{x:1454,y:501,t:1528139745222};\\\", \\\"{x:1457,y:501,t:1528139745239};\\\", \\\"{x:1456,y:501,t:1528139745541};\\\", \\\"{x:1444,y:501,t:1528139745556};\\\", \\\"{x:1433,y:501,t:1528139745572};\\\", \\\"{x:1429,y:501,t:1528139745589};\\\", \\\"{x:1434,y:501,t:1528139745765};\\\", \\\"{x:1440,y:501,t:1528139745772};\\\", \\\"{x:1448,y:501,t:1528139745789};\\\", \\\"{x:1449,y:501,t:1528139745806};\\\", \\\"{x:1446,y:504,t:1528139748476};\\\", \\\"{x:1440,y:511,t:1528139748491};\\\", \\\"{x:1402,y:540,t:1528139748508};\\\", \\\"{x:1332,y:574,t:1528139748525};\\\", \\\"{x:1218,y:607,t:1528139748542};\\\", \\\"{x:1080,y:626,t:1528139748558};\\\", \\\"{x:908,y:651,t:1528139748575};\\\", \\\"{x:754,y:668,t:1528139748592};\\\", \\\"{x:624,y:681,t:1528139748608};\\\", \\\"{x:535,y:683,t:1528139748625};\\\", \\\"{x:471,y:683,t:1528139748642};\\\", \\\"{x:428,y:686,t:1528139748657};\\\", \\\"{x:406,y:688,t:1528139748675};\\\", \\\"{x:388,y:692,t:1528139748692};\\\", \\\"{x:384,y:692,t:1528139748708};\\\", \\\"{x:374,y:695,t:1528139748725};\\\", \\\"{x:362,y:699,t:1528139748741};\\\", \\\"{x:351,y:702,t:1528139748757};\\\", \\\"{x:336,y:707,t:1528139748775};\\\", \\\"{x:328,y:709,t:1528139748792};\\\", \\\"{x:325,y:710,t:1528139748808};\\\", \\\"{x:324,y:710,t:1528139748860};\\\", \\\"{x:322,y:710,t:1528139748876};\\\", \\\"{x:323,y:707,t:1528139748948};\\\", \\\"{x:328,y:701,t:1528139748959};\\\", \\\"{x:337,y:690,t:1528139748975};\\\", \\\"{x:353,y:673,t:1528139748992};\\\", \\\"{x:365,y:665,t:1528139749011};\\\", \\\"{x:367,y:663,t:1528139749025};\\\", \\\"{x:368,y:662,t:1528139749041};\\\", \\\"{x:370,y:660,t:1528139749059};\\\", \\\"{x:375,y:653,t:1528139749075};\\\", \\\"{x:379,y:649,t:1528139749090};\\\", \\\"{x:383,y:639,t:1528139749107};\\\", \\\"{x:387,y:632,t:1528139749125};\\\", \\\"{x:387,y:631,t:1528139749142};\\\", \\\"{x:387,y:629,t:1528139749158};\\\", \\\"{x:387,y:627,t:1528139749175};\\\", \\\"{x:388,y:625,t:1528139749192};\\\", \\\"{x:388,y:616,t:1528139749207};\\\", \\\"{x:388,y:590,t:1528139749225};\\\", \\\"{x:388,y:566,t:1528139749241};\\\", \\\"{x:388,y:548,t:1528139749259};\\\", \\\"{x:388,y:536,t:1528139749274};\\\", \\\"{x:388,y:532,t:1528139749291};\\\", \\\"{x:388,y:536,t:1528139749403};\\\", \\\"{x:388,y:538,t:1528139749410};\\\", \\\"{x:388,y:541,t:1528139749424};\\\", \\\"{x:388,y:545,t:1528139749441};\\\", \\\"{x:388,y:551,t:1528139749459};\\\", \\\"{x:388,y:557,t:1528139749475};\\\", \\\"{x:388,y:566,t:1528139749492};\\\", \\\"{x:388,y:571,t:1528139749508};\\\", \\\"{x:388,y:575,t:1528139749525};\\\", \\\"{x:388,y:583,t:1528139749542};\\\", \\\"{x:388,y:587,t:1528139749559};\\\", \\\"{x:388,y:594,t:1528139749575};\\\", \\\"{x:388,y:595,t:1528139749591};\\\", \\\"{x:390,y:596,t:1528139749609};\\\", \\\"{x:390,y:593,t:1528139749725};\\\", \\\"{x:390,y:586,t:1528139749743};\\\", \\\"{x:390,y:579,t:1528139749758};\\\", \\\"{x:390,y:573,t:1528139749775};\\\", \\\"{x:388,y:565,t:1528139749792};\\\", \\\"{x:388,y:561,t:1528139749809};\\\", \\\"{x:388,y:556,t:1528139749825};\\\", \\\"{x:388,y:550,t:1528139749842};\\\", \\\"{x:388,y:545,t:1528139749858};\\\", \\\"{x:387,y:539,t:1528139749874};\\\", \\\"{x:385,y:532,t:1528139749891};\\\", \\\"{x:383,y:529,t:1528139749909};\\\", \\\"{x:383,y:528,t:1528139749924};\\\", \\\"{x:383,y:527,t:1528139749941};\\\", \\\"{x:383,y:524,t:1528139749959};\\\", \\\"{x:382,y:520,t:1528139749975};\\\", \\\"{x:380,y:516,t:1528139749992};\\\", \\\"{x:380,y:511,t:1528139750009};\\\", \\\"{x:379,y:507,t:1528139750026};\\\", \\\"{x:378,y:504,t:1528139750042};\\\", \\\"{x:378,y:503,t:1528139750099};\\\", \\\"{x:378,y:502,t:1528139750115};\\\", \\\"{x:378,y:501,t:1528139750131};\\\", \\\"{x:378,y:510,t:1528139750387};\\\", \\\"{x:383,y:526,t:1528139750396};\\\", \\\"{x:388,y:543,t:1528139750409};\\\", \\\"{x:398,y:566,t:1528139750426};\\\", \\\"{x:401,y:574,t:1528139750443};\\\", \\\"{x:406,y:588,t:1528139750458};\\\", \\\"{x:416,y:608,t:1528139750476};\\\", \\\"{x:421,y:616,t:1528139750493};\\\", \\\"{x:424,y:621,t:1528139750508};\\\", \\\"{x:429,y:631,t:1528139750526};\\\", \\\"{x:439,y:647,t:1528139750544};\\\", \\\"{x:449,y:667,t:1528139750560};\\\", \\\"{x:469,y:693,t:1528139750576};\\\", \\\"{x:485,y:711,t:1528139750593};\\\", \\\"{x:495,y:724,t:1528139750609};\\\", \\\"{x:500,y:730,t:1528139750625};\\\", \\\"{x:502,y:731,t:1528139750642};\\\", \\\"{x:502,y:732,t:1528139750668};\\\", \\\"{x:503,y:732,t:1528139750748};\\\", \\\"{x:504,y:733,t:1528139750759};\\\", \\\"{x:505,y:734,t:1528139750788};\\\" ] }, { \\\"rt\\\": 13678, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 695122, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:733,t:1528139752964};\\\", \\\"{x:505,y:721,t:1528139752984};\\\", \\\"{x:511,y:707,t:1528139752996};\\\", \\\"{x:517,y:688,t:1528139753013};\\\", \\\"{x:536,y:666,t:1528139753028};\\\", \\\"{x:572,y:634,t:1528139753044};\\\", \\\"{x:609,y:609,t:1528139753061};\\\", \\\"{x:642,y:590,t:1528139753079};\\\", \\\"{x:671,y:574,t:1528139753095};\\\", \\\"{x:691,y:563,t:1528139753111};\\\", \\\"{x:703,y:559,t:1528139753128};\\\", \\\"{x:710,y:556,t:1528139753145};\\\", \\\"{x:715,y:554,t:1528139753161};\\\", \\\"{x:720,y:553,t:1528139753178};\\\", \\\"{x:725,y:552,t:1528139753195};\\\", \\\"{x:730,y:550,t:1528139753211};\\\", \\\"{x:736,y:549,t:1528139753228};\\\", \\\"{x:737,y:548,t:1528139753245};\\\", \\\"{x:738,y:548,t:1528139753261};\\\", \\\"{x:739,y:548,t:1528139753278};\\\", \\\"{x:741,y:547,t:1528139753295};\\\", \\\"{x:743,y:547,t:1528139753311};\\\", \\\"{x:745,y:546,t:1528139753328};\\\", \\\"{x:746,y:546,t:1528139753564};\\\", \\\"{x:749,y:546,t:1528139754469};\\\", \\\"{x:758,y:546,t:1528139754479};\\\", \\\"{x:773,y:546,t:1528139754496};\\\", \\\"{x:785,y:547,t:1528139754512};\\\", \\\"{x:791,y:548,t:1528139754529};\\\", \\\"{x:797,y:548,t:1528139754546};\\\", \\\"{x:806,y:551,t:1528139754562};\\\", \\\"{x:838,y:559,t:1528139754581};\\\", \\\"{x:871,y:570,t:1528139754596};\\\", \\\"{x:927,y:586,t:1528139754612};\\\", \\\"{x:1004,y:608,t:1528139754628};\\\", \\\"{x:1074,y:630,t:1528139754645};\\\", \\\"{x:1146,y:650,t:1528139754661};\\\", \\\"{x:1221,y:670,t:1528139754678};\\\", \\\"{x:1299,y:694,t:1528139754694};\\\", \\\"{x:1371,y:716,t:1528139754711};\\\", \\\"{x:1464,y:745,t:1528139754727};\\\", \\\"{x:1562,y:781,t:1528139754743};\\\", \\\"{x:1628,y:807,t:1528139754760};\\\", \\\"{x:1655,y:820,t:1528139754778};\\\", \\\"{x:1668,y:827,t:1528139754794};\\\", \\\"{x:1673,y:830,t:1528139754811};\\\", \\\"{x:1674,y:830,t:1528139754876};\\\", \\\"{x:1673,y:830,t:1528139754956};\\\", \\\"{x:1670,y:830,t:1528139754964};\\\", \\\"{x:1668,y:830,t:1528139754978};\\\", \\\"{x:1667,y:829,t:1528139755011};\\\", \\\"{x:1660,y:825,t:1528139755028};\\\", \\\"{x:1656,y:823,t:1528139755044};\\\", \\\"{x:1655,y:822,t:1528139755061};\\\", \\\"{x:1653,y:820,t:1528139755131};\\\", \\\"{x:1647,y:817,t:1528139755144};\\\", \\\"{x:1621,y:806,t:1528139755161};\\\", \\\"{x:1567,y:790,t:1528139755178};\\\", \\\"{x:1522,y:776,t:1528139755194};\\\", \\\"{x:1502,y:771,t:1528139755212};\\\", \\\"{x:1499,y:770,t:1528139755228};\\\", \\\"{x:1498,y:770,t:1528139755244};\\\", \\\"{x:1496,y:770,t:1528139755300};\\\", \\\"{x:1495,y:770,t:1528139755311};\\\", \\\"{x:1487,y:770,t:1528139755329};\\\", \\\"{x:1478,y:770,t:1528139755345};\\\", \\\"{x:1470,y:770,t:1528139755362};\\\", \\\"{x:1461,y:770,t:1528139755378};\\\", \\\"{x:1452,y:772,t:1528139755394};\\\", \\\"{x:1448,y:773,t:1528139755411};\\\", \\\"{x:1447,y:774,t:1528139755428};\\\", \\\"{x:1445,y:774,t:1528139755499};\\\", \\\"{x:1441,y:774,t:1528139755511};\\\", \\\"{x:1431,y:777,t:1528139755528};\\\", \\\"{x:1417,y:781,t:1528139755544};\\\", \\\"{x:1401,y:784,t:1528139755561};\\\", \\\"{x:1382,y:788,t:1528139755579};\\\", \\\"{x:1363,y:793,t:1528139755594};\\\", \\\"{x:1341,y:796,t:1528139755611};\\\", \\\"{x:1331,y:798,t:1528139755628};\\\", \\\"{x:1329,y:798,t:1528139755645};\\\", \\\"{x:1328,y:798,t:1528139755772};\\\", \\\"{x:1328,y:797,t:1528139755780};\\\", \\\"{x:1328,y:795,t:1528139755795};\\\", \\\"{x:1328,y:789,t:1528139755812};\\\", \\\"{x:1328,y:786,t:1528139755828};\\\", \\\"{x:1328,y:783,t:1528139755845};\\\", \\\"{x:1328,y:777,t:1528139755861};\\\", \\\"{x:1328,y:774,t:1528139755879};\\\", \\\"{x:1329,y:772,t:1528139755894};\\\", \\\"{x:1330,y:771,t:1528139756005};\\\", \\\"{x:1331,y:769,t:1528139756020};\\\", \\\"{x:1333,y:768,t:1528139756028};\\\", \\\"{x:1337,y:765,t:1528139756045};\\\", \\\"{x:1340,y:764,t:1528139756062};\\\", \\\"{x:1344,y:762,t:1528139756081};\\\", \\\"{x:1347,y:762,t:1528139756094};\\\", \\\"{x:1348,y:762,t:1528139756110};\\\", \\\"{x:1349,y:762,t:1528139756131};\\\", \\\"{x:1345,y:762,t:1528139762780};\\\", \\\"{x:1318,y:762,t:1528139762795};\\\", \\\"{x:1226,y:767,t:1528139762811};\\\", \\\"{x:1053,y:789,t:1528139762828};\\\", \\\"{x:936,y:793,t:1528139762844};\\\", \\\"{x:806,y:793,t:1528139762860};\\\", \\\"{x:695,y:793,t:1528139762877};\\\", \\\"{x:586,y:792,t:1528139762894};\\\", \\\"{x:495,y:781,t:1528139762911};\\\", \\\"{x:445,y:773,t:1528139762928};\\\", \\\"{x:416,y:767,t:1528139762944};\\\", \\\"{x:409,y:767,t:1528139762960};\\\", \\\"{x:408,y:766,t:1528139763036};\\\", \\\"{x:408,y:765,t:1528139763044};\\\", \\\"{x:404,y:751,t:1528139763061};\\\", \\\"{x:403,y:736,t:1528139763078};\\\", \\\"{x:403,y:716,t:1528139763093};\\\", \\\"{x:405,y:695,t:1528139763111};\\\", \\\"{x:416,y:669,t:1528139763129};\\\", \\\"{x:426,y:653,t:1528139763143};\\\", \\\"{x:439,y:634,t:1528139763160};\\\", \\\"{x:447,y:627,t:1528139763169};\\\", \\\"{x:459,y:619,t:1528139763186};\\\", \\\"{x:462,y:614,t:1528139763202};\\\", \\\"{x:462,y:612,t:1528139763251};\\\", \\\"{x:460,y:611,t:1528139763267};\\\", \\\"{x:459,y:610,t:1528139763275};\\\", \\\"{x:458,y:609,t:1528139763285};\\\", \\\"{x:453,y:607,t:1528139763302};\\\", \\\"{x:440,y:602,t:1528139763320};\\\", \\\"{x:424,y:595,t:1528139763336};\\\", \\\"{x:403,y:585,t:1528139763353};\\\", \\\"{x:385,y:575,t:1528139763369};\\\", \\\"{x:374,y:563,t:1528139763387};\\\", \\\"{x:365,y:538,t:1528139763404};\\\", \\\"{x:360,y:521,t:1528139763420};\\\", \\\"{x:355,y:507,t:1528139763437};\\\", \\\"{x:350,y:495,t:1528139763452};\\\", \\\"{x:345,y:489,t:1528139763470};\\\", \\\"{x:339,y:487,t:1528139763487};\\\", \\\"{x:337,y:486,t:1528139763504};\\\", \\\"{x:336,y:485,t:1528139763519};\\\", \\\"{x:335,y:484,t:1528139763537};\\\", \\\"{x:333,y:484,t:1528139763553};\\\", \\\"{x:332,y:484,t:1528139763570};\\\", \\\"{x:332,y:485,t:1528139763643};\\\", \\\"{x:336,y:488,t:1528139763654};\\\", \\\"{x:345,y:490,t:1528139763670};\\\", \\\"{x:351,y:492,t:1528139763687};\\\", \\\"{x:355,y:493,t:1528139763703};\\\", \\\"{x:365,y:495,t:1528139763719};\\\", \\\"{x:383,y:495,t:1528139763737};\\\", \\\"{x:404,y:495,t:1528139763754};\\\", \\\"{x:424,y:495,t:1528139763769};\\\", \\\"{x:440,y:495,t:1528139763786};\\\", \\\"{x:455,y:497,t:1528139763803};\\\", \\\"{x:458,y:498,t:1528139763821};\\\", \\\"{x:459,y:498,t:1528139763868};\\\", \\\"{x:461,y:498,t:1528139763884};\\\", \\\"{x:462,y:498,t:1528139763891};\\\", \\\"{x:466,y:498,t:1528139763904};\\\", \\\"{x:484,y:498,t:1528139763921};\\\", \\\"{x:500,y:498,t:1528139763939};\\\", \\\"{x:514,y:498,t:1528139763953};\\\", \\\"{x:521,y:498,t:1528139763970};\\\", \\\"{x:526,y:499,t:1528139763986};\\\", \\\"{x:527,y:499,t:1528139764083};\\\", \\\"{x:529,y:499,t:1528139764091};\\\", \\\"{x:530,y:499,t:1528139764103};\\\", \\\"{x:542,y:501,t:1528139764121};\\\", \\\"{x:553,y:502,t:1528139764136};\\\", \\\"{x:554,y:503,t:1528139764153};\\\", \\\"{x:556,y:503,t:1528139764292};\\\", \\\"{x:559,y:503,t:1528139764316};\\\", \\\"{x:564,y:501,t:1528139764324};\\\", \\\"{x:571,y:501,t:1528139764337};\\\", \\\"{x:590,y:501,t:1528139764354};\\\", \\\"{x:608,y:501,t:1528139764371};\\\", \\\"{x:624,y:501,t:1528139764387};\\\", \\\"{x:623,y:501,t:1528139764476};\\\", \\\"{x:622,y:501,t:1528139764487};\\\", \\\"{x:621,y:501,t:1528139764564};\\\", \\\"{x:620,y:501,t:1528139764588};\\\", \\\"{x:619,y:501,t:1528139764620};\\\", \\\"{x:616,y:503,t:1528139764947};\\\", \\\"{x:612,y:505,t:1528139764955};\\\", \\\"{x:610,y:507,t:1528139764970};\\\", \\\"{x:602,y:512,t:1528139764987};\\\", \\\"{x:602,y:514,t:1528139765005};\\\", \\\"{x:601,y:516,t:1528139765020};\\\", \\\"{x:601,y:517,t:1528139765044};\\\", \\\"{x:601,y:519,t:1528139765055};\\\", \\\"{x:601,y:527,t:1528139765071};\\\", \\\"{x:599,y:541,t:1528139765087};\\\", \\\"{x:599,y:563,t:1528139765105};\\\", \\\"{x:599,y:586,t:1528139765121};\\\", \\\"{x:598,y:613,t:1528139765138};\\\", \\\"{x:598,y:654,t:1528139765155};\\\", \\\"{x:595,y:697,t:1528139765171};\\\", \\\"{x:592,y:706,t:1528139765187};\\\", \\\"{x:589,y:715,t:1528139765205};\\\", \\\"{x:585,y:727,t:1528139765221};\\\", \\\"{x:583,y:732,t:1528139765237};\\\", \\\"{x:581,y:734,t:1528139765254};\\\", \\\"{x:580,y:734,t:1528139765356};\\\", \\\"{x:578,y:734,t:1528139765428};\\\", \\\"{x:577,y:734,t:1528139765468};\\\", \\\"{x:574,y:734,t:1528139765483};\\\", \\\"{x:570,y:733,t:1528139765492};\\\", \\\"{x:567,y:733,t:1528139765504};\\\", \\\"{x:559,y:733,t:1528139765523};\\\", \\\"{x:554,y:733,t:1528139765538};\\\", \\\"{x:551,y:733,t:1528139765554};\\\", \\\"{x:550,y:733,t:1528139765635};\\\", \\\"{x:547,y:733,t:1528139765642};\\\", \\\"{x:543,y:733,t:1528139765654};\\\", \\\"{x:539,y:733,t:1528139765670};\\\", \\\"{x:537,y:733,t:1528139765688};\\\", \\\"{x:536,y:733,t:1528139765772};\\\", \\\"{x:534,y:733,t:1528139765789};\\\", \\\"{x:534,y:733,t:1528139765911};\\\" ] }, { \\\"rt\\\": 8924, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 705399, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:732,t:1528139768444};\\\", \\\"{x:533,y:732,t:1528139768458};\\\", \\\"{x:533,y:723,t:1528139768475};\\\", \\\"{x:534,y:702,t:1528139768493};\\\", \\\"{x:542,y:685,t:1528139768508};\\\", \\\"{x:549,y:672,t:1528139768524};\\\", \\\"{x:553,y:667,t:1528139768540};\\\", \\\"{x:554,y:663,t:1528139768557};\\\", \\\"{x:555,y:662,t:1528139768573};\\\", \\\"{x:555,y:661,t:1528139768591};\\\", \\\"{x:551,y:663,t:1528139774372};\\\", \\\"{x:526,y:673,t:1528139774380};\\\", \\\"{x:494,y:688,t:1528139774394};\\\", \\\"{x:398,y:714,t:1528139774412};\\\", \\\"{x:358,y:726,t:1528139774427};\\\", \\\"{x:338,y:732,t:1528139774444};\\\", \\\"{x:334,y:733,t:1528139774462};\\\", \\\"{x:334,y:730,t:1528139774636};\\\", \\\"{x:338,y:724,t:1528139774644};\\\", \\\"{x:352,y:709,t:1528139774661};\\\", \\\"{x:376,y:685,t:1528139774679};\\\", \\\"{x:388,y:664,t:1528139774697};\\\", \\\"{x:396,y:643,t:1528139774711};\\\", \\\"{x:398,y:618,t:1528139774728};\\\", \\\"{x:399,y:600,t:1528139774745};\\\", \\\"{x:399,y:588,t:1528139774762};\\\", \\\"{x:398,y:571,t:1528139774779};\\\", \\\"{x:397,y:563,t:1528139774796};\\\", \\\"{x:395,y:557,t:1528139774813};\\\", \\\"{x:395,y:551,t:1528139774829};\\\", \\\"{x:393,y:546,t:1528139774846};\\\", \\\"{x:389,y:539,t:1528139774862};\\\", \\\"{x:388,y:533,t:1528139774879};\\\", \\\"{x:387,y:531,t:1528139774896};\\\", \\\"{x:386,y:529,t:1528139774911};\\\", \\\"{x:386,y:528,t:1528139774987};\\\", \\\"{x:386,y:526,t:1528139774996};\\\", \\\"{x:386,y:523,t:1528139775013};\\\", \\\"{x:386,y:520,t:1528139775029};\\\", \\\"{x:386,y:513,t:1528139775046};\\\", \\\"{x:386,y:509,t:1528139775062};\\\", \\\"{x:386,y:508,t:1528139775079};\\\", \\\"{x:386,y:505,t:1528139775096};\\\", \\\"{x:386,y:502,t:1528139775112};\\\", \\\"{x:388,y:501,t:1528139775362};\\\", \\\"{x:396,y:501,t:1528139775378};\\\", \\\"{x:402,y:501,t:1528139775396};\\\", \\\"{x:405,y:502,t:1528139775413};\\\", \\\"{x:407,y:514,t:1528139775429};\\\", \\\"{x:416,y:534,t:1528139775446};\\\", \\\"{x:421,y:555,t:1528139775463};\\\", \\\"{x:428,y:576,t:1528139775480};\\\", \\\"{x:439,y:603,t:1528139775496};\\\", \\\"{x:452,y:636,t:1528139775513};\\\", \\\"{x:465,y:668,t:1528139775529};\\\", \\\"{x:477,y:688,t:1528139775546};\\\", \\\"{x:488,y:703,t:1528139775563};\\\", \\\"{x:488,y:704,t:1528139775763};\\\", \\\"{x:490,y:704,t:1528139775779};\\\", \\\"{x:491,y:705,t:1528139775796};\\\", \\\"{x:494,y:708,t:1528139775813};\\\", \\\"{x:497,y:713,t:1528139775830};\\\", \\\"{x:497,y:714,t:1528139775846};\\\", \\\"{x:498,y:716,t:1528139775863};\\\", \\\"{x:498,y:718,t:1528139775881};\\\", \\\"{x:498,y:722,t:1528139775897};\\\", \\\"{x:498,y:727,t:1528139775913};\\\", \\\"{x:499,y:732,t:1528139775930};\\\", \\\"{x:500,y:733,t:1528139775947};\\\" ] }, { \\\"rt\\\": 6707, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 713365, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:731,t:1528139779940};\\\", \\\"{x:498,y:721,t:1528139779954};\\\", \\\"{x:492,y:686,t:1528139779984};\\\", \\\"{x:488,y:657,t:1528139780004};\\\", \\\"{x:488,y:640,t:1528139780019};\\\", \\\"{x:488,y:631,t:1528139780032};\\\", \\\"{x:487,y:621,t:1528139780047};\\\", \\\"{x:486,y:615,t:1528139780065};\\\", \\\"{x:483,y:610,t:1528139780082};\\\", \\\"{x:483,y:609,t:1528139780291};\\\", \\\"{x:485,y:607,t:1528139780300};\\\", \\\"{x:493,y:599,t:1528139780318};\\\", \\\"{x:498,y:595,t:1528139780333};\\\", \\\"{x:501,y:589,t:1528139780350};\\\", \\\"{x:503,y:585,t:1528139780367};\\\", \\\"{x:507,y:575,t:1528139780383};\\\", \\\"{x:512,y:566,t:1528139780399};\\\", \\\"{x:519,y:554,t:1528139780417};\\\", \\\"{x:525,y:546,t:1528139780433};\\\", \\\"{x:538,y:532,t:1528139780450};\\\", \\\"{x:567,y:514,t:1528139780468};\\\", \\\"{x:589,y:503,t:1528139780482};\\\", \\\"{x:606,y:496,t:1528139780500};\\\", \\\"{x:612,y:493,t:1528139780517};\\\", \\\"{x:614,y:492,t:1528139780533};\\\", \\\"{x:609,y:492,t:1528139780652};\\\", \\\"{x:574,y:492,t:1528139780668};\\\", \\\"{x:501,y:492,t:1528139780683};\\\", \\\"{x:410,y:492,t:1528139780701};\\\", \\\"{x:343,y:492,t:1528139780717};\\\", \\\"{x:315,y:492,t:1528139780733};\\\", \\\"{x:308,y:492,t:1528139780750};\\\", \\\"{x:306,y:493,t:1528139780883};\\\", \\\"{x:301,y:499,t:1528139780900};\\\", \\\"{x:294,y:508,t:1528139780917};\\\", \\\"{x:286,y:518,t:1528139780936};\\\", \\\"{x:272,y:530,t:1528139780951};\\\", \\\"{x:256,y:539,t:1528139780967};\\\", \\\"{x:236,y:549,t:1528139780984};\\\", \\\"{x:224,y:554,t:1528139781000};\\\", \\\"{x:222,y:554,t:1528139781017};\\\", \\\"{x:222,y:552,t:1528139781107};\\\", \\\"{x:222,y:549,t:1528139781117};\\\", \\\"{x:222,y:547,t:1528139781134};\\\", \\\"{x:222,y:546,t:1528139781150};\\\", \\\"{x:222,y:545,t:1528139781196};\\\", \\\"{x:215,y:542,t:1528139781204};\\\", \\\"{x:207,y:542,t:1528139781217};\\\", \\\"{x:189,y:538,t:1528139781235};\\\", \\\"{x:178,y:536,t:1528139781250};\\\", \\\"{x:175,y:536,t:1528139781587};\\\", \\\"{x:171,y:538,t:1528139781601};\\\", \\\"{x:168,y:538,t:1528139781616};\\\", \\\"{x:168,y:539,t:1528139781632};\\\", \\\"{x:167,y:539,t:1528139781931};\\\", \\\"{x:169,y:537,t:1528139781938};\\\", \\\"{x:173,y:536,t:1528139781951};\\\", \\\"{x:177,y:535,t:1528139781968};\\\", \\\"{x:182,y:533,t:1528139781984};\\\", \\\"{x:194,y:532,t:1528139782002};\\\", \\\"{x:210,y:532,t:1528139782018};\\\", \\\"{x:237,y:532,t:1528139782034};\\\", \\\"{x:332,y:525,t:1528139782052};\\\", \\\"{x:426,y:513,t:1528139782069};\\\", \\\"{x:534,y:497,t:1528139782084};\\\", \\\"{x:631,y:486,t:1528139782102};\\\", \\\"{x:711,y:476,t:1528139782118};\\\", \\\"{x:766,y:470,t:1528139782134};\\\", \\\"{x:793,y:468,t:1528139782151};\\\", \\\"{x:803,y:468,t:1528139782168};\\\", \\\"{x:804,y:468,t:1528139782184};\\\", \\\"{x:804,y:469,t:1528139782259};\\\", \\\"{x:804,y:470,t:1528139782276};\\\", \\\"{x:801,y:472,t:1528139782285};\\\", \\\"{x:797,y:474,t:1528139782301};\\\", \\\"{x:791,y:478,t:1528139782319};\\\", \\\"{x:779,y:482,t:1528139782334};\\\", \\\"{x:771,y:486,t:1528139782351};\\\", \\\"{x:763,y:492,t:1528139782369};\\\", \\\"{x:757,y:496,t:1528139782385};\\\", \\\"{x:750,y:501,t:1528139782401};\\\", \\\"{x:740,y:508,t:1528139782418};\\\", \\\"{x:720,y:518,t:1528139782436};\\\", \\\"{x:712,y:526,t:1528139782453};\\\", \\\"{x:707,y:530,t:1528139782468};\\\", \\\"{x:703,y:537,t:1528139782485};\\\", \\\"{x:699,y:542,t:1528139782501};\\\", \\\"{x:696,y:546,t:1528139782518};\\\", \\\"{x:692,y:551,t:1528139782535};\\\", \\\"{x:691,y:552,t:1528139782551};\\\", \\\"{x:690,y:553,t:1528139782568};\\\", \\\"{x:690,y:554,t:1528139782585};\\\", \\\"{x:692,y:555,t:1528139782618};\\\", \\\"{x:714,y:556,t:1528139782635};\\\", \\\"{x:742,y:556,t:1528139782652};\\\", \\\"{x:775,y:556,t:1528139782668};\\\", \\\"{x:806,y:555,t:1528139782686};\\\", \\\"{x:830,y:553,t:1528139782702};\\\", \\\"{x:845,y:550,t:1528139782719};\\\", \\\"{x:850,y:549,t:1528139782735};\\\", \\\"{x:851,y:549,t:1528139782803};\\\", \\\"{x:851,y:548,t:1528139782884};\\\", \\\"{x:851,y:546,t:1528139782916};\\\", \\\"{x:851,y:543,t:1528139782923};\\\", \\\"{x:851,y:541,t:1528139782936};\\\", \\\"{x:849,y:535,t:1528139782952};\\\", \\\"{x:848,y:534,t:1528139782968};\\\", \\\"{x:848,y:531,t:1528139782985};\\\", \\\"{x:847,y:527,t:1528139783003};\\\", \\\"{x:846,y:524,t:1528139783019};\\\", \\\"{x:845,y:521,t:1528139783036};\\\", \\\"{x:845,y:520,t:1528139783082};\\\", \\\"{x:845,y:518,t:1528139783123};\\\", \\\"{x:844,y:516,t:1528139783136};\\\", \\\"{x:844,y:509,t:1528139783153};\\\", \\\"{x:844,y:508,t:1528139783178};\\\", \\\"{x:844,y:507,t:1528139783187};\\\", \\\"{x:844,y:506,t:1528139783202};\\\", \\\"{x:843,y:502,t:1528139783220};\\\", \\\"{x:839,y:502,t:1528139783435};\\\", \\\"{x:825,y:505,t:1528139783452};\\\", \\\"{x:806,y:516,t:1528139783469};\\\", \\\"{x:788,y:529,t:1528139783486};\\\", \\\"{x:769,y:546,t:1528139783502};\\\", \\\"{x:745,y:572,t:1528139783520};\\\", \\\"{x:719,y:591,t:1528139783537};\\\", \\\"{x:695,y:609,t:1528139783553};\\\", \\\"{x:675,y:624,t:1528139783569};\\\", \\\"{x:658,y:640,t:1528139783586};\\\", \\\"{x:648,y:650,t:1528139783602};\\\", \\\"{x:631,y:669,t:1528139783618};\\\", \\\"{x:618,y:683,t:1528139783636};\\\", \\\"{x:604,y:698,t:1528139783652};\\\", \\\"{x:592,y:711,t:1528139783670};\\\", \\\"{x:577,y:725,t:1528139783686};\\\", \\\"{x:565,y:733,t:1528139783702};\\\", \\\"{x:559,y:737,t:1528139783719};\\\", \\\"{x:553,y:741,t:1528139783736};\\\", \\\"{x:549,y:743,t:1528139783752};\\\", \\\"{x:546,y:744,t:1528139783769};\\\", \\\"{x:543,y:744,t:1528139785299};\\\", \\\"{x:543,y:741,t:1528139785307};\\\" ] }, { \\\"rt\\\": 5883, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 720569, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:456,y:448,t:1528139785455};\\\", \\\"{x:429,y:392,t:1528139785470};\\\", \\\"{x:401,y:341,t:1528139785487};\\\", \\\"{x:366,y:283,t:1528139785504};\\\", \\\"{x:325,y:225,t:1528139785520};\\\", \\\"{x:255,y:139,t:1528139785546};\\\", \\\"{x:229,y:116,t:1528139785554};\\\", \\\"{x:185,y:81,t:1528139785570};\\\", \\\"{x:136,y:50,t:1528139785587};\\\", \\\"{x:116,y:39,t:1528139785604};\\\", \\\"{x:100,y:27,t:1528139785621};\\\", \\\"{x:84,y:16,t:1528139785637};\\\", \\\"{x:69,y:16,t:1528139785654};\\\", \\\"{x:58,y:16,t:1528139785671};\\\", \\\"{x:38,y:16,t:1528139785687};\\\", \\\"{x:15,y:16,t:1528139785705};\\\", \\\"{x:0,y:16,t:1528139785722};\\\", \\\"{x:0,y:23,t:1528139785931};\\\", \\\"{x:0,y:40,t:1528139785938};\\\", \\\"{x:0,y:58,t:1528139785954};\\\", \\\"{x:0,y:85,t:1528139785970};\\\", \\\"{x:0,y:93,t:1528139785987};\\\", \\\"{x:0,y:96,t:1528139786004};\\\", \\\"{x:0,y:100,t:1528139786021};\\\", \\\"{x:121,y:40,t:1528139786171};\\\", \\\"{x:248,y:16,t:1528139786189};\\\", \\\"{x:384,y:16,t:1528139786204};\\\", \\\"{x:483,y:16,t:1528139786221};\\\", \\\"{x:617,y:16,t:1528139786238};\\\", \\\"{x:772,y:16,t:1528139786254};\\\", \\\"{x:943,y:16,t:1528139786271};\\\", \\\"{x:1096,y:21,t:1528139786288};\\\", \\\"{x:1237,y:40,t:1528139786304};\\\", \\\"{x:1362,y:59,t:1528139786321};\\\", \\\"{x:1482,y:80,t:1528139786339};\\\", \\\"{x:1604,y:101,t:1528139786355};\\\", \\\"{x:1754,y:140,t:1528139786372};\\\", \\\"{x:1829,y:164,t:1528139786389};\\\", \\\"{x:1871,y:184,t:1528139786405};\\\", \\\"{x:1890,y:195,t:1528139786421};\\\", \\\"{x:1894,y:202,t:1528139786438};\\\", \\\"{x:1895,y:208,t:1528139786454};\\\", \\\"{x:1895,y:215,t:1528139786472};\\\", \\\"{x:1895,y:221,t:1528139786488};\\\", \\\"{x:1892,y:227,t:1528139786504};\\\", \\\"{x:1885,y:233,t:1528139786522};\\\", \\\"{x:1878,y:238,t:1528139786538};\\\", \\\"{x:1875,y:240,t:1528139786554};\\\", \\\"{x:1874,y:242,t:1528139786572};\\\", \\\"{x:1873,y:243,t:1528139786668};\\\", \\\"{x:1872,y:243,t:1528139786748};\\\", \\\"{x:1872,y:244,t:1528139786756};\\\", \\\"{x:1871,y:245,t:1528139786818};\\\", \\\"{x:1870,y:245,t:1528139786842};\\\", \\\"{x:1869,y:245,t:1528139786855};\\\", \\\"{x:1868,y:246,t:1528139786871};\\\", \\\"{x:1867,y:246,t:1528139786889};\\\", \\\"{x:1865,y:247,t:1528139786905};\\\", \\\"{x:1864,y:248,t:1528139786922};\\\", \\\"{x:1863,y:248,t:1528139786947};\\\", \\\"{x:1862,y:249,t:1528139786963};\\\", \\\"{x:1861,y:249,t:1528139787042};\\\", \\\"{x:1861,y:250,t:1528139787090};\\\", \\\"{x:1858,y:250,t:1528139788676};\\\", \\\"{x:1852,y:250,t:1528139788690};\\\", \\\"{x:1827,y:250,t:1528139788708};\\\", \\\"{x:1773,y:252,t:1528139788723};\\\", \\\"{x:1733,y:252,t:1528139788740};\\\", \\\"{x:1697,y:252,t:1528139788757};\\\", \\\"{x:1649,y:252,t:1528139788774};\\\", \\\"{x:1591,y:252,t:1528139788790};\\\", \\\"{x:1521,y:252,t:1528139788807};\\\", \\\"{x:1443,y:252,t:1528139788824};\\\", \\\"{x:1376,y:252,t:1528139788841};\\\", \\\"{x:1321,y:252,t:1528139788857};\\\", \\\"{x:1270,y:252,t:1528139788874};\\\", \\\"{x:1220,y:252,t:1528139788891};\\\", \\\"{x:1159,y:252,t:1528139788907};\\\", \\\"{x:1039,y:252,t:1528139788923};\\\", \\\"{x:945,y:252,t:1528139788941};\\\", \\\"{x:831,y:252,t:1528139788957};\\\", \\\"{x:711,y:256,t:1528139788974};\\\", \\\"{x:592,y:256,t:1528139788991};\\\", \\\"{x:482,y:256,t:1528139789007};\\\", \\\"{x:381,y:276,t:1528139789024};\\\", \\\"{x:254,y:310,t:1528139789041};\\\", \\\"{x:142,y:349,t:1528139789057};\\\", \\\"{x:50,y:393,t:1528139789074};\\\", \\\"{x:0,y:437,t:1528139789091};\\\", \\\"{x:0,y:478,t:1528139789107};\\\", \\\"{x:0,y:524,t:1528139789123};\\\", \\\"{x:0,y:543,t:1528139789141};\\\", \\\"{x:0,y:553,t:1528139789157};\\\", \\\"{x:0,y:554,t:1528139789179};\\\", \\\"{x:1,y:554,t:1528139789220};\\\", \\\"{x:6,y:554,t:1528139789227};\\\", \\\"{x:10,y:554,t:1528139789241};\\\", \\\"{x:24,y:552,t:1528139789257};\\\", \\\"{x:44,y:550,t:1528139789274};\\\", \\\"{x:68,y:547,t:1528139789293};\\\", \\\"{x:102,y:546,t:1528139789306};\\\", \\\"{x:124,y:545,t:1528139789323};\\\", \\\"{x:141,y:545,t:1528139789339};\\\", \\\"{x:159,y:540,t:1528139789356};\\\", \\\"{x:173,y:539,t:1528139789373};\\\", \\\"{x:186,y:536,t:1528139789390};\\\", \\\"{x:196,y:532,t:1528139789408};\\\", \\\"{x:209,y:529,t:1528139789423};\\\", \\\"{x:221,y:524,t:1528139789441};\\\", \\\"{x:231,y:520,t:1528139789458};\\\", \\\"{x:242,y:513,t:1528139789474};\\\", \\\"{x:250,y:507,t:1528139789490};\\\", \\\"{x:252,y:506,t:1528139789507};\\\", \\\"{x:252,y:505,t:1528139789523};\\\", \\\"{x:251,y:505,t:1528139789604};\\\", \\\"{x:242,y:506,t:1528139789612};\\\", \\\"{x:224,y:507,t:1528139789623};\\\", \\\"{x:176,y:514,t:1528139789641};\\\", \\\"{x:136,y:521,t:1528139789659};\\\", \\\"{x:101,y:528,t:1528139789676};\\\", \\\"{x:92,y:530,t:1528139789691};\\\", \\\"{x:90,y:531,t:1528139789708};\\\", \\\"{x:93,y:531,t:1528139789932};\\\", \\\"{x:99,y:533,t:1528139789941};\\\", \\\"{x:107,y:536,t:1528139789956};\\\", \\\"{x:108,y:537,t:1528139789979};\\\", \\\"{x:109,y:537,t:1528139790043};\\\", \\\"{x:111,y:537,t:1528139790059};\\\", \\\"{x:114,y:537,t:1528139790074};\\\", \\\"{x:119,y:537,t:1528139790090};\\\", \\\"{x:123,y:537,t:1528139790107};\\\", \\\"{x:128,y:537,t:1528139790124};\\\", \\\"{x:130,y:537,t:1528139790139};\\\", \\\"{x:131,y:537,t:1528139790163};\\\", \\\"{x:133,y:537,t:1528139790179};\\\", \\\"{x:135,y:537,t:1528139790195};\\\", \\\"{x:138,y:537,t:1528139790207};\\\", \\\"{x:146,y:537,t:1528139790224};\\\", \\\"{x:151,y:539,t:1528139790241};\\\", \\\"{x:155,y:539,t:1528139790531};\\\", \\\"{x:171,y:539,t:1528139790542};\\\", \\\"{x:219,y:545,t:1528139790559};\\\", \\\"{x:269,y:551,t:1528139790574};\\\", \\\"{x:312,y:559,t:1528139790592};\\\", \\\"{x:336,y:567,t:1528139790609};\\\", \\\"{x:353,y:574,t:1528139790625};\\\", \\\"{x:369,y:582,t:1528139790642};\\\", \\\"{x:395,y:594,t:1528139790660};\\\", \\\"{x:404,y:601,t:1528139790675};\\\", \\\"{x:433,y:622,t:1528139790691};\\\", \\\"{x:468,y:643,t:1528139790710};\\\", \\\"{x:491,y:661,t:1528139790725};\\\", \\\"{x:510,y:674,t:1528139790742};\\\", \\\"{x:520,y:682,t:1528139790758};\\\", \\\"{x:528,y:689,t:1528139790775};\\\", \\\"{x:534,y:697,t:1528139790791};\\\", \\\"{x:541,y:705,t:1528139790809};\\\", \\\"{x:545,y:710,t:1528139790826};\\\", \\\"{x:549,y:717,t:1528139790842};\\\", \\\"{x:560,y:731,t:1528139790860};\\\", \\\"{x:566,y:741,t:1528139790875};\\\", \\\"{x:571,y:751,t:1528139790892};\\\", \\\"{x:577,y:760,t:1528139790909};\\\", \\\"{x:578,y:762,t:1528139790925};\\\", \\\"{x:578,y:764,t:1528139790942};\\\", \\\"{x:578,y:765,t:1528139791028};\\\", \\\"{x:576,y:764,t:1528139791044};\\\", \\\"{x:562,y:757,t:1528139791060};\\\", \\\"{x:541,y:747,t:1528139791076};\\\", \\\"{x:528,y:741,t:1528139791091};\\\", \\\"{x:523,y:736,t:1528139791109};\\\", \\\"{x:522,y:736,t:1528139791126};\\\" ] }, { \\\"rt\\\": 15858, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 737745, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G -Z -Z -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:734,t:1528139792656};\\\", \\\"{x:521,y:734,t:1528139792950};\\\", \\\"{x:520,y:733,t:1528139793317};\\\", \\\"{x:520,y:732,t:1528139793406};\\\", \\\"{x:520,y:727,t:1528139793422};\\\", \\\"{x:521,y:722,t:1528139793430};\\\", \\\"{x:530,y:711,t:1528139793448};\\\", \\\"{x:541,y:697,t:1528139793464};\\\", \\\"{x:554,y:686,t:1528139793479};\\\", \\\"{x:568,y:674,t:1528139793496};\\\", \\\"{x:583,y:663,t:1528139793513};\\\", \\\"{x:594,y:655,t:1528139793530};\\\", \\\"{x:606,y:649,t:1528139793547};\\\", \\\"{x:612,y:645,t:1528139793564};\\\", \\\"{x:621,y:640,t:1528139793580};\\\", \\\"{x:624,y:639,t:1528139793597};\\\", \\\"{x:627,y:637,t:1528139793614};\\\", \\\"{x:628,y:637,t:1528139793629};\\\", \\\"{x:631,y:636,t:1528139793647};\\\", \\\"{x:634,y:634,t:1528139793663};\\\", \\\"{x:644,y:629,t:1528139793680};\\\", \\\"{x:658,y:622,t:1528139793697};\\\", \\\"{x:672,y:614,t:1528139793713};\\\", \\\"{x:684,y:609,t:1528139793731};\\\", \\\"{x:688,y:607,t:1528139793746};\\\", \\\"{x:692,y:605,t:1528139793764};\\\", \\\"{x:696,y:603,t:1528139793781};\\\", \\\"{x:698,y:602,t:1528139793796};\\\", \\\"{x:700,y:602,t:1528139793814};\\\", \\\"{x:705,y:600,t:1528139793831};\\\", \\\"{x:709,y:598,t:1528139793847};\\\", \\\"{x:711,y:597,t:1528139793864};\\\", \\\"{x:714,y:595,t:1528139793881};\\\", \\\"{x:720,y:594,t:1528139793897};\\\", \\\"{x:728,y:591,t:1528139793915};\\\", \\\"{x:733,y:590,t:1528139793930};\\\", \\\"{x:743,y:586,t:1528139793948};\\\", \\\"{x:756,y:584,t:1528139793964};\\\", \\\"{x:769,y:580,t:1528139793980};\\\", \\\"{x:794,y:578,t:1528139793997};\\\", \\\"{x:816,y:574,t:1528139794013};\\\", \\\"{x:840,y:574,t:1528139794031};\\\", \\\"{x:871,y:569,t:1528139794048};\\\", \\\"{x:901,y:569,t:1528139794064};\\\", \\\"{x:928,y:568,t:1528139794081};\\\", \\\"{x:953,y:563,t:1528139794098};\\\", \\\"{x:977,y:562,t:1528139794114};\\\", \\\"{x:1002,y:562,t:1528139794131};\\\", \\\"{x:1024,y:561,t:1528139794148};\\\", \\\"{x:1046,y:561,t:1528139794164};\\\", \\\"{x:1069,y:561,t:1528139794180};\\\", \\\"{x:1098,y:559,t:1528139794198};\\\", \\\"{x:1117,y:558,t:1528139794214};\\\", \\\"{x:1137,y:556,t:1528139794231};\\\", \\\"{x:1155,y:556,t:1528139794248};\\\", \\\"{x:1171,y:554,t:1528139794264};\\\", \\\"{x:1190,y:554,t:1528139794281};\\\", \\\"{x:1209,y:554,t:1528139794298};\\\", \\\"{x:1225,y:554,t:1528139794314};\\\", \\\"{x:1239,y:554,t:1528139794331};\\\", \\\"{x:1258,y:554,t:1528139794348};\\\", \\\"{x:1278,y:554,t:1528139794365};\\\", \\\"{x:1296,y:554,t:1528139794381};\\\", \\\"{x:1322,y:554,t:1528139794397};\\\", \\\"{x:1343,y:554,t:1528139794414};\\\", \\\"{x:1364,y:554,t:1528139794431};\\\", \\\"{x:1382,y:554,t:1528139794448};\\\", \\\"{x:1397,y:553,t:1528139794465};\\\", \\\"{x:1410,y:552,t:1528139794481};\\\", \\\"{x:1420,y:550,t:1528139794498};\\\", \\\"{x:1427,y:548,t:1528139794515};\\\", \\\"{x:1433,y:548,t:1528139794531};\\\", \\\"{x:1438,y:548,t:1528139794548};\\\", \\\"{x:1446,y:545,t:1528139794565};\\\", \\\"{x:1450,y:544,t:1528139794581};\\\", \\\"{x:1464,y:543,t:1528139794598};\\\", \\\"{x:1476,y:540,t:1528139794614};\\\", \\\"{x:1486,y:540,t:1528139794631};\\\", \\\"{x:1496,y:539,t:1528139794649};\\\", \\\"{x:1502,y:539,t:1528139794665};\\\", \\\"{x:1512,y:539,t:1528139794681};\\\", \\\"{x:1523,y:539,t:1528139794699};\\\", \\\"{x:1543,y:544,t:1528139794715};\\\", \\\"{x:1565,y:552,t:1528139794731};\\\", \\\"{x:1592,y:560,t:1528139794749};\\\", \\\"{x:1617,y:575,t:1528139794766};\\\", \\\"{x:1661,y:601,t:1528139794783};\\\", \\\"{x:1680,y:614,t:1528139794798};\\\", \\\"{x:1698,y:629,t:1528139794815};\\\", \\\"{x:1708,y:640,t:1528139794832};\\\", \\\"{x:1712,y:649,t:1528139794848};\\\", \\\"{x:1714,y:658,t:1528139794865};\\\", \\\"{x:1718,y:667,t:1528139794882};\\\", \\\"{x:1719,y:675,t:1528139794898};\\\", \\\"{x:1719,y:679,t:1528139794915};\\\", \\\"{x:1719,y:683,t:1528139794932};\\\", \\\"{x:1719,y:690,t:1528139794948};\\\", \\\"{x:1719,y:693,t:1528139794965};\\\", \\\"{x:1718,y:699,t:1528139794982};\\\", \\\"{x:1716,y:702,t:1528139794998};\\\", \\\"{x:1715,y:706,t:1528139795016};\\\", \\\"{x:1710,y:710,t:1528139795032};\\\", \\\"{x:1707,y:714,t:1528139795048};\\\", \\\"{x:1701,y:717,t:1528139795065};\\\", \\\"{x:1694,y:721,t:1528139795082};\\\", \\\"{x:1685,y:726,t:1528139795098};\\\", \\\"{x:1676,y:735,t:1528139795115};\\\", \\\"{x:1665,y:748,t:1528139795132};\\\", \\\"{x:1653,y:761,t:1528139795148};\\\", \\\"{x:1637,y:777,t:1528139795165};\\\", \\\"{x:1611,y:802,t:1528139795183};\\\", \\\"{x:1595,y:817,t:1528139795198};\\\", \\\"{x:1580,y:830,t:1528139795215};\\\", \\\"{x:1568,y:841,t:1528139795232};\\\", \\\"{x:1564,y:847,t:1528139795249};\\\", \\\"{x:1562,y:849,t:1528139795265};\\\", \\\"{x:1563,y:849,t:1528139795319};\\\", \\\"{x:1565,y:847,t:1528139795333};\\\", \\\"{x:1568,y:842,t:1528139795350};\\\", \\\"{x:1572,y:831,t:1528139795365};\\\", \\\"{x:1584,y:812,t:1528139795383};\\\", \\\"{x:1592,y:798,t:1528139795399};\\\", \\\"{x:1598,y:787,t:1528139795416};\\\", \\\"{x:1603,y:777,t:1528139795432};\\\", \\\"{x:1611,y:758,t:1528139795449};\\\", \\\"{x:1618,y:745,t:1528139795465};\\\", \\\"{x:1623,y:731,t:1528139795483};\\\", \\\"{x:1627,y:720,t:1528139795499};\\\", \\\"{x:1630,y:710,t:1528139795515};\\\", \\\"{x:1631,y:707,t:1528139795532};\\\", \\\"{x:1631,y:705,t:1528139795549};\\\", \\\"{x:1632,y:704,t:1528139795566};\\\", \\\"{x:1632,y:703,t:1528139795583};\\\", \\\"{x:1632,y:702,t:1528139795791};\\\", \\\"{x:1627,y:702,t:1528139795799};\\\", \\\"{x:1616,y:710,t:1528139795816};\\\", \\\"{x:1610,y:719,t:1528139795832};\\\", \\\"{x:1608,y:722,t:1528139795849};\\\", \\\"{x:1608,y:723,t:1528139795866};\\\", \\\"{x:1609,y:723,t:1528139795991};\\\", \\\"{x:1611,y:722,t:1528139796000};\\\", \\\"{x:1616,y:717,t:1528139796016};\\\", \\\"{x:1619,y:712,t:1528139796033};\\\", \\\"{x:1619,y:706,t:1528139796049};\\\", \\\"{x:1622,y:697,t:1528139796067};\\\", \\\"{x:1623,y:694,t:1528139796083};\\\", \\\"{x:1623,y:692,t:1528139796099};\\\", \\\"{x:1623,y:691,t:1528139796116};\\\", \\\"{x:1619,y:693,t:1528139796370};\\\", \\\"{x:1618,y:696,t:1528139796382};\\\", \\\"{x:1616,y:698,t:1528139796400};\\\", \\\"{x:1616,y:699,t:1528139796416};\\\", \\\"{x:1615,y:699,t:1528139796831};\\\", \\\"{x:1615,y:698,t:1528139796878};\\\", \\\"{x:1615,y:697,t:1528139796886};\\\", \\\"{x:1615,y:696,t:1528139796900};\\\", \\\"{x:1615,y:695,t:1528139796926};\\\", \\\"{x:1615,y:694,t:1528139796934};\\\", \\\"{x:1615,y:693,t:1528139796951};\\\", \\\"{x:1615,y:692,t:1528139796967};\\\", \\\"{x:1615,y:690,t:1528139796984};\\\", \\\"{x:1615,y:689,t:1528139797006};\\\", \\\"{x:1615,y:688,t:1528139797017};\\\", \\\"{x:1615,y:687,t:1528139797033};\\\", \\\"{x:1615,y:684,t:1528139797051};\\\", \\\"{x:1615,y:682,t:1528139797068};\\\", \\\"{x:1615,y:680,t:1528139797083};\\\", \\\"{x:1615,y:677,t:1528139797101};\\\", \\\"{x:1615,y:675,t:1528139797118};\\\", \\\"{x:1616,y:672,t:1528139797133};\\\", \\\"{x:1616,y:666,t:1528139797150};\\\", \\\"{x:1617,y:659,t:1528139797167};\\\", \\\"{x:1617,y:649,t:1528139797183};\\\", \\\"{x:1620,y:636,t:1528139797200};\\\", \\\"{x:1620,y:627,t:1528139797218};\\\", \\\"{x:1620,y:618,t:1528139797234};\\\", \\\"{x:1621,y:608,t:1528139797251};\\\", \\\"{x:1622,y:601,t:1528139797267};\\\", \\\"{x:1622,y:597,t:1528139797285};\\\", \\\"{x:1622,y:594,t:1528139797301};\\\", \\\"{x:1622,y:591,t:1528139797317};\\\", \\\"{x:1622,y:590,t:1528139797335};\\\", \\\"{x:1622,y:588,t:1528139797359};\\\", \\\"{x:1622,y:587,t:1528139797390};\\\", \\\"{x:1622,y:585,t:1528139797407};\\\", \\\"{x:1622,y:582,t:1528139797418};\\\", \\\"{x:1622,y:573,t:1528139797434};\\\", \\\"{x:1622,y:568,t:1528139797450};\\\", \\\"{x:1622,y:562,t:1528139797467};\\\", \\\"{x:1622,y:556,t:1528139797484};\\\", \\\"{x:1622,y:548,t:1528139797500};\\\", \\\"{x:1622,y:541,t:1528139797517};\\\", \\\"{x:1622,y:529,t:1528139797533};\\\", \\\"{x:1622,y:521,t:1528139797550};\\\", \\\"{x:1622,y:517,t:1528139797567};\\\", \\\"{x:1622,y:514,t:1528139797584};\\\", \\\"{x:1622,y:513,t:1528139797600};\\\", \\\"{x:1622,y:515,t:1528139797847};\\\", \\\"{x:1622,y:516,t:1528139797854};\\\", \\\"{x:1622,y:519,t:1528139797867};\\\", \\\"{x:1622,y:520,t:1528139797884};\\\", \\\"{x:1622,y:522,t:1528139797902};\\\", \\\"{x:1622,y:523,t:1528139797918};\\\", \\\"{x:1622,y:525,t:1528139797999};\\\", \\\"{x:1622,y:526,t:1528139798095};\\\", \\\"{x:1622,y:528,t:1528139798102};\\\", \\\"{x:1622,y:531,t:1528139798118};\\\", \\\"{x:1622,y:538,t:1528139798134};\\\", \\\"{x:1620,y:551,t:1528139798152};\\\", \\\"{x:1619,y:567,t:1528139798168};\\\", \\\"{x:1616,y:588,t:1528139798184};\\\", \\\"{x:1613,y:607,t:1528139798202};\\\", \\\"{x:1607,y:627,t:1528139798218};\\\", \\\"{x:1603,y:640,t:1528139798235};\\\", \\\"{x:1601,y:646,t:1528139798251};\\\", \\\"{x:1600,y:644,t:1528139798407};\\\", \\\"{x:1600,y:642,t:1528139798419};\\\", \\\"{x:1600,y:636,t:1528139798435};\\\", \\\"{x:1600,y:630,t:1528139798452};\\\", \\\"{x:1601,y:622,t:1528139798469};\\\", \\\"{x:1602,y:615,t:1528139798486};\\\", \\\"{x:1602,y:606,t:1528139798501};\\\", \\\"{x:1604,y:597,t:1528139798518};\\\", \\\"{x:1604,y:593,t:1528139798534};\\\", \\\"{x:1604,y:587,t:1528139798552};\\\", \\\"{x:1604,y:581,t:1528139798569};\\\", \\\"{x:1604,y:574,t:1528139798586};\\\", \\\"{x:1604,y:566,t:1528139798602};\\\", \\\"{x:1603,y:557,t:1528139798618};\\\", \\\"{x:1603,y:547,t:1528139798636};\\\", \\\"{x:1603,y:535,t:1528139798651};\\\", \\\"{x:1603,y:525,t:1528139798669};\\\", \\\"{x:1603,y:512,t:1528139798686};\\\", \\\"{x:1605,y:501,t:1528139798701};\\\", \\\"{x:1611,y:474,t:1528139798718};\\\", \\\"{x:1612,y:465,t:1528139798735};\\\", \\\"{x:1612,y:459,t:1528139798751};\\\", \\\"{x:1612,y:454,t:1528139798769};\\\", \\\"{x:1614,y:452,t:1528139798786};\\\", \\\"{x:1614,y:451,t:1528139798802};\\\", \\\"{x:1615,y:451,t:1528139799199};\\\", \\\"{x:1617,y:451,t:1528139799206};\\\", \\\"{x:1618,y:455,t:1528139799222};\\\", \\\"{x:1618,y:465,t:1528139799236};\\\", \\\"{x:1617,y:483,t:1528139799252};\\\", \\\"{x:1614,y:505,t:1528139799268};\\\", \\\"{x:1612,y:524,t:1528139799286};\\\", \\\"{x:1606,y:558,t:1528139799302};\\\", \\\"{x:1604,y:579,t:1528139799319};\\\", \\\"{x:1604,y:602,t:1528139799335};\\\", \\\"{x:1604,y:619,t:1528139799353};\\\", \\\"{x:1600,y:633,t:1528139799370};\\\", \\\"{x:1596,y:644,t:1528139799386};\\\", \\\"{x:1593,y:655,t:1528139799402};\\\", \\\"{x:1591,y:661,t:1528139799419};\\\", \\\"{x:1590,y:667,t:1528139799435};\\\", \\\"{x:1590,y:671,t:1528139799453};\\\", \\\"{x:1590,y:675,t:1528139799469};\\\", \\\"{x:1590,y:677,t:1528139799590};\\\", \\\"{x:1590,y:681,t:1528139799602};\\\", \\\"{x:1593,y:689,t:1528139799620};\\\", \\\"{x:1597,y:698,t:1528139799635};\\\", \\\"{x:1601,y:706,t:1528139799653};\\\", \\\"{x:1604,y:711,t:1528139799670};\\\", \\\"{x:1606,y:715,t:1528139799686};\\\", \\\"{x:1608,y:717,t:1528139799703};\\\", \\\"{x:1609,y:718,t:1528139799719};\\\", \\\"{x:1610,y:718,t:1528139799737};\\\", \\\"{x:1611,y:720,t:1528139799753};\\\", \\\"{x:1612,y:717,t:1528139799927};\\\", \\\"{x:1612,y:716,t:1528139799937};\\\", \\\"{x:1612,y:711,t:1528139799952};\\\", \\\"{x:1614,y:707,t:1528139799969};\\\", \\\"{x:1614,y:706,t:1528139799986};\\\", \\\"{x:1614,y:705,t:1528139800003};\\\", \\\"{x:1614,y:704,t:1528139800020};\\\", \\\"{x:1614,y:703,t:1528139800487};\\\", \\\"{x:1614,y:707,t:1528139800895};\\\", \\\"{x:1613,y:710,t:1528139800905};\\\", \\\"{x:1607,y:722,t:1528139800920};\\\", \\\"{x:1595,y:751,t:1528139800937};\\\", \\\"{x:1571,y:809,t:1528139800954};\\\", \\\"{x:1530,y:893,t:1528139800971};\\\", \\\"{x:1481,y:995,t:1528139800987};\\\", \\\"{x:1431,y:1106,t:1528139801004};\\\", \\\"{x:1371,y:1210,t:1528139801021};\\\", \\\"{x:1329,y:1215,t:1528139801037};\\\", \\\"{x:1307,y:1215,t:1528139801053};\\\", \\\"{x:1305,y:1215,t:1528139801070};\\\", \\\"{x:1305,y:1214,t:1528139801142};\\\", \\\"{x:1305,y:1213,t:1528139801153};\\\", \\\"{x:1305,y:1201,t:1528139801170};\\\", \\\"{x:1311,y:1185,t:1528139801186};\\\", \\\"{x:1317,y:1168,t:1528139801203};\\\", \\\"{x:1328,y:1147,t:1528139801220};\\\", \\\"{x:1342,y:1126,t:1528139801236};\\\", \\\"{x:1362,y:1099,t:1528139801254};\\\", \\\"{x:1402,y:1053,t:1528139801270};\\\", \\\"{x:1424,y:1028,t:1528139801287};\\\", \\\"{x:1452,y:993,t:1528139801303};\\\", \\\"{x:1470,y:967,t:1528139801320};\\\", \\\"{x:1488,y:946,t:1528139801337};\\\", \\\"{x:1504,y:931,t:1528139801353};\\\", \\\"{x:1514,y:923,t:1528139801370};\\\", \\\"{x:1516,y:920,t:1528139801386};\\\", \\\"{x:1517,y:920,t:1528139801404};\\\", \\\"{x:1516,y:920,t:1528139801543};\\\", \\\"{x:1512,y:920,t:1528139801554};\\\", \\\"{x:1505,y:920,t:1528139801571};\\\", \\\"{x:1498,y:921,t:1528139801588};\\\", \\\"{x:1491,y:928,t:1528139801603};\\\", \\\"{x:1487,y:938,t:1528139801620};\\\", \\\"{x:1486,y:944,t:1528139801637};\\\", \\\"{x:1486,y:950,t:1528139801654};\\\", \\\"{x:1486,y:951,t:1528139801686};\\\", \\\"{x:1484,y:951,t:1528139802334};\\\", \\\"{x:1484,y:950,t:1528139802343};\\\", \\\"{x:1484,y:947,t:1528139802355};\\\", \\\"{x:1484,y:940,t:1528139802372};\\\", \\\"{x:1484,y:934,t:1528139802387};\\\", \\\"{x:1484,y:924,t:1528139802407};\\\", \\\"{x:1484,y:920,t:1528139802421};\\\", \\\"{x:1484,y:914,t:1528139802438};\\\", \\\"{x:1484,y:911,t:1528139802454};\\\", \\\"{x:1484,y:909,t:1528139802471};\\\", \\\"{x:1485,y:907,t:1528139802549};\\\", \\\"{x:1485,y:906,t:1528139802606};\\\", \\\"{x:1485,y:905,t:1528139802622};\\\", \\\"{x:1485,y:903,t:1528139802637};\\\", \\\"{x:1485,y:899,t:1528139802655};\\\", \\\"{x:1485,y:897,t:1528139802672};\\\", \\\"{x:1485,y:894,t:1528139802687};\\\", \\\"{x:1485,y:892,t:1528139802704};\\\", \\\"{x:1485,y:890,t:1528139802721};\\\", \\\"{x:1485,y:887,t:1528139802737};\\\", \\\"{x:1485,y:886,t:1528139802754};\\\", \\\"{x:1485,y:883,t:1528139802772};\\\", \\\"{x:1485,y:880,t:1528139802788};\\\", \\\"{x:1485,y:877,t:1528139802805};\\\", \\\"{x:1485,y:874,t:1528139802821};\\\", \\\"{x:1485,y:870,t:1528139802838};\\\", \\\"{x:1485,y:868,t:1528139802854};\\\", \\\"{x:1485,y:867,t:1528139802871};\\\", \\\"{x:1485,y:865,t:1528139802889};\\\", \\\"{x:1485,y:864,t:1528139802905};\\\", \\\"{x:1485,y:861,t:1528139802921};\\\", \\\"{x:1485,y:858,t:1528139802939};\\\", \\\"{x:1485,y:855,t:1528139802954};\\\", \\\"{x:1485,y:852,t:1528139802971};\\\", \\\"{x:1484,y:850,t:1528139802988};\\\", \\\"{x:1484,y:847,t:1528139803006};\\\", \\\"{x:1483,y:846,t:1528139803022};\\\", \\\"{x:1483,y:844,t:1528139803038};\\\", \\\"{x:1483,y:842,t:1528139803055};\\\", \\\"{x:1483,y:841,t:1528139803159};\\\", \\\"{x:1483,y:840,t:1528139803231};\\\", \\\"{x:1483,y:839,t:1528139803295};\\\", \\\"{x:1483,y:838,t:1528139803335};\\\", \\\"{x:1483,y:836,t:1528139803349};\\\", \\\"{x:1482,y:834,t:1528139803366};\\\", \\\"{x:1482,y:832,t:1528139803388};\\\", \\\"{x:1481,y:831,t:1528139803405};\\\", \\\"{x:1480,y:830,t:1528139803421};\\\", \\\"{x:1480,y:828,t:1528139803846};\\\", \\\"{x:1479,y:825,t:1528139803856};\\\", \\\"{x:1477,y:813,t:1528139803873};\\\", \\\"{x:1475,y:794,t:1528139803889};\\\", \\\"{x:1472,y:778,t:1528139803906};\\\", \\\"{x:1471,y:768,t:1528139803923};\\\", \\\"{x:1470,y:761,t:1528139803939};\\\", \\\"{x:1469,y:754,t:1528139803956};\\\", \\\"{x:1468,y:750,t:1528139803973};\\\", \\\"{x:1467,y:745,t:1528139803989};\\\", \\\"{x:1466,y:736,t:1528139804006};\\\", \\\"{x:1465,y:730,t:1528139804022};\\\", \\\"{x:1464,y:722,t:1528139804039};\\\", \\\"{x:1463,y:715,t:1528139804056};\\\", \\\"{x:1462,y:709,t:1528139804073};\\\", \\\"{x:1461,y:702,t:1528139804089};\\\", \\\"{x:1461,y:698,t:1528139804106};\\\", \\\"{x:1461,y:696,t:1528139804123};\\\", \\\"{x:1460,y:694,t:1528139804140};\\\", \\\"{x:1459,y:692,t:1528139804159};\\\", \\\"{x:1459,y:691,t:1528139804174};\\\", \\\"{x:1459,y:688,t:1528139804189};\\\", \\\"{x:1458,y:681,t:1528139804206};\\\", \\\"{x:1458,y:676,t:1528139804222};\\\", \\\"{x:1458,y:673,t:1528139804240};\\\", \\\"{x:1456,y:670,t:1528139804255};\\\", \\\"{x:1456,y:669,t:1528139804273};\\\", \\\"{x:1456,y:668,t:1528139804289};\\\", \\\"{x:1456,y:667,t:1528139804343};\\\", \\\"{x:1455,y:666,t:1528139804408};\\\", \\\"{x:1450,y:665,t:1528139804550};\\\", \\\"{x:1442,y:662,t:1528139804558};\\\", \\\"{x:1429,y:659,t:1528139804573};\\\", \\\"{x:1387,y:647,t:1528139804589};\\\", \\\"{x:1260,y:627,t:1528139804605};\\\", \\\"{x:1146,y:608,t:1528139804623};\\\", \\\"{x:1006,y:598,t:1528139804640};\\\", \\\"{x:861,y:589,t:1528139804657};\\\", \\\"{x:739,y:589,t:1528139804672};\\\", \\\"{x:637,y:589,t:1528139804690};\\\", \\\"{x:572,y:589,t:1528139804706};\\\", \\\"{x:525,y:589,t:1528139804722};\\\", \\\"{x:500,y:589,t:1528139804739};\\\", \\\"{x:485,y:589,t:1528139804757};\\\", \\\"{x:477,y:589,t:1528139804772};\\\", \\\"{x:475,y:590,t:1528139804789};\\\", \\\"{x:473,y:591,t:1528139804805};\\\", \\\"{x:471,y:593,t:1528139804823};\\\", \\\"{x:468,y:593,t:1528139804839};\\\", \\\"{x:464,y:594,t:1528139804857};\\\", \\\"{x:463,y:594,t:1528139804910};\\\", \\\"{x:461,y:594,t:1528139804923};\\\", \\\"{x:446,y:593,t:1528139804940};\\\", \\\"{x:417,y:584,t:1528139804957};\\\", \\\"{x:380,y:573,t:1528139804973};\\\", \\\"{x:352,y:565,t:1528139804990};\\\", \\\"{x:321,y:558,t:1528139805007};\\\", \\\"{x:304,y:554,t:1528139805024};\\\", \\\"{x:289,y:553,t:1528139805039};\\\", \\\"{x:265,y:548,t:1528139805058};\\\", \\\"{x:243,y:548,t:1528139805073};\\\", \\\"{x:218,y:548,t:1528139805089};\\\", \\\"{x:199,y:548,t:1528139805106};\\\", \\\"{x:183,y:548,t:1528139805123};\\\", \\\"{x:166,y:548,t:1528139805139};\\\", \\\"{x:155,y:548,t:1528139805156};\\\", \\\"{x:147,y:548,t:1528139805174};\\\", \\\"{x:145,y:549,t:1528139805189};\\\", \\\"{x:144,y:549,t:1528139805206};\\\", \\\"{x:143,y:549,t:1528139805262};\\\", \\\"{x:143,y:551,t:1528139805335};\\\", \\\"{x:143,y:553,t:1528139805351};\\\", \\\"{x:143,y:555,t:1528139805358};\\\", \\\"{x:143,y:557,t:1528139805375};\\\", \\\"{x:143,y:573,t:1528139805390};\\\", \\\"{x:141,y:588,t:1528139805406};\\\", \\\"{x:140,y:610,t:1528139805424};\\\", \\\"{x:140,y:630,t:1528139805440};\\\", \\\"{x:140,y:643,t:1528139805456};\\\", \\\"{x:140,y:653,t:1528139805473};\\\", \\\"{x:141,y:656,t:1528139805490};\\\", \\\"{x:143,y:656,t:1528139805662};\\\", \\\"{x:147,y:656,t:1528139805673};\\\", \\\"{x:173,y:646,t:1528139805691};\\\", \\\"{x:215,y:631,t:1528139805707};\\\", \\\"{x:250,y:618,t:1528139805723};\\\", \\\"{x:272,y:611,t:1528139805740};\\\", \\\"{x:284,y:605,t:1528139805757};\\\", \\\"{x:290,y:603,t:1528139805773};\\\", \\\"{x:295,y:600,t:1528139805790};\\\", \\\"{x:301,y:596,t:1528139805808};\\\", \\\"{x:310,y:592,t:1528139805823};\\\", \\\"{x:319,y:587,t:1528139805840};\\\", \\\"{x:326,y:583,t:1528139805857};\\\", \\\"{x:329,y:580,t:1528139805874};\\\", \\\"{x:331,y:578,t:1528139805890};\\\", \\\"{x:333,y:577,t:1528139805908};\\\", \\\"{x:337,y:569,t:1528139805923};\\\", \\\"{x:351,y:555,t:1528139805942};\\\", \\\"{x:362,y:545,t:1528139805958};\\\", \\\"{x:374,y:535,t:1528139805973};\\\", \\\"{x:378,y:532,t:1528139805990};\\\", \\\"{x:382,y:527,t:1528139806007};\\\", \\\"{x:386,y:522,t:1528139806024};\\\", \\\"{x:388,y:522,t:1528139806040};\\\", \\\"{x:388,y:521,t:1528139806057};\\\", \\\"{x:388,y:520,t:1528139806109};\\\", \\\"{x:379,y:520,t:1528139806123};\\\", \\\"{x:348,y:526,t:1528139806141};\\\", \\\"{x:316,y:526,t:1528139806157};\\\", \\\"{x:276,y:532,t:1528139806173};\\\", \\\"{x:261,y:533,t:1528139806191};\\\", \\\"{x:257,y:534,t:1528139806207};\\\", \\\"{x:256,y:535,t:1528139806223};\\\", \\\"{x:252,y:535,t:1528139806287};\\\", \\\"{x:248,y:536,t:1528139806295};\\\", \\\"{x:239,y:540,t:1528139806308};\\\", \\\"{x:216,y:549,t:1528139806324};\\\", \\\"{x:193,y:561,t:1528139806342};\\\", \\\"{x:171,y:574,t:1528139806357};\\\", \\\"{x:167,y:576,t:1528139806374};\\\", \\\"{x:165,y:577,t:1528139806390};\\\", \\\"{x:165,y:578,t:1528139806407};\\\", \\\"{x:162,y:579,t:1528139806424};\\\", \\\"{x:158,y:581,t:1528139806440};\\\", \\\"{x:157,y:582,t:1528139806457};\\\", \\\"{x:155,y:583,t:1528139806474};\\\", \\\"{x:152,y:584,t:1528139806491};\\\", \\\"{x:154,y:584,t:1528139806790};\\\", \\\"{x:159,y:584,t:1528139806797};\\\", \\\"{x:171,y:577,t:1528139806807};\\\", \\\"{x:201,y:567,t:1528139806824};\\\", \\\"{x:240,y:557,t:1528139806842};\\\", \\\"{x:262,y:552,t:1528139806858};\\\", \\\"{x:271,y:551,t:1528139806875};\\\", \\\"{x:368,y:546,t:1528139806892};\\\", \\\"{x:479,y:542,t:1528139806907};\\\", \\\"{x:546,y:535,t:1528139806925};\\\", \\\"{x:597,y:533,t:1528139806942};\\\", \\\"{x:641,y:533,t:1528139806957};\\\", \\\"{x:661,y:533,t:1528139806975};\\\", \\\"{x:662,y:533,t:1528139806992};\\\", \\\"{x:661,y:535,t:1528139807007};\\\", \\\"{x:661,y:536,t:1528139807024};\\\", \\\"{x:660,y:536,t:1528139807042};\\\", \\\"{x:658,y:536,t:1528139807058};\\\", \\\"{x:657,y:537,t:1528139807075};\\\", \\\"{x:655,y:538,t:1528139807091};\\\", \\\"{x:652,y:539,t:1528139807108};\\\", \\\"{x:651,y:539,t:1528139807124};\\\", \\\"{x:649,y:539,t:1528139807141};\\\", \\\"{x:645,y:541,t:1528139807157};\\\", \\\"{x:640,y:544,t:1528139807175};\\\", \\\"{x:637,y:546,t:1528139807191};\\\", \\\"{x:633,y:551,t:1528139807208};\\\", \\\"{x:630,y:558,t:1528139807225};\\\", \\\"{x:628,y:566,t:1528139807242};\\\", \\\"{x:622,y:579,t:1528139807258};\\\", \\\"{x:620,y:588,t:1528139807275};\\\", \\\"{x:618,y:598,t:1528139807292};\\\", \\\"{x:616,y:603,t:1528139807309};\\\", \\\"{x:616,y:602,t:1528139807535};\\\", \\\"{x:616,y:601,t:1528139807542};\\\", \\\"{x:616,y:599,t:1528139807560};\\\", \\\"{x:616,y:596,t:1528139807575};\\\", \\\"{x:616,y:593,t:1528139807592};\\\", \\\"{x:616,y:590,t:1528139807608};\\\", \\\"{x:616,y:589,t:1528139807626};\\\", \\\"{x:616,y:587,t:1528139807642};\\\", \\\"{x:616,y:586,t:1528139807659};\\\", \\\"{x:614,y:589,t:1528139807909};\\\", \\\"{x:604,y:596,t:1528139807925};\\\", \\\"{x:591,y:612,t:1528139807942};\\\", \\\"{x:578,y:631,t:1528139807958};\\\", \\\"{x:565,y:650,t:1528139807976};\\\", \\\"{x:552,y:675,t:1528139807992};\\\", \\\"{x:543,y:700,t:1528139808009};\\\", \\\"{x:534,y:720,t:1528139808026};\\\", \\\"{x:526,y:735,t:1528139808043};\\\", \\\"{x:518,y:751,t:1528139808058};\\\", \\\"{x:513,y:757,t:1528139808076};\\\", \\\"{x:513,y:759,t:1528139808093};\\\", \\\"{x:512,y:758,t:1528139808174};\\\", \\\"{x:512,y:757,t:1528139808182};\\\", \\\"{x:512,y:756,t:1528139808193};\\\", \\\"{x:512,y:752,t:1528139808209};\\\", \\\"{x:512,y:745,t:1528139808225};\\\", \\\"{x:512,y:742,t:1528139808242};\\\", \\\"{x:512,y:741,t:1528139808258};\\\", \\\"{x:512,y:739,t:1528139808275};\\\", \\\"{x:512,y:738,t:1528139808294};\\\", \\\"{x:512,y:737,t:1528139808309};\\\", \\\"{x:513,y:735,t:1528139808326};\\\", \\\"{x:514,y:734,t:1528139808342};\\\", \\\"{x:514,y:733,t:1528139808359};\\\", \\\"{x:514,y:732,t:1528139809358};\\\", \\\"{x:514,y:730,t:1528139809374};\\\", \\\"{x:514,y:729,t:1528139809382};\\\", \\\"{x:514,y:726,t:1528139809394};\\\", \\\"{x:514,y:721,t:1528139809410};\\\", \\\"{x:514,y:717,t:1528139809426};\\\", \\\"{x:514,y:713,t:1528139809443};\\\", \\\"{x:514,y:709,t:1528139809459};\\\", \\\"{x:514,y:704,t:1528139809477};\\\", \\\"{x:514,y:699,t:1528139809494};\\\", \\\"{x:514,y:695,t:1528139809510};\\\", \\\"{x:514,y:693,t:1528139809526};\\\", \\\"{x:514,y:692,t:1528139809546};\\\", \\\"{x:514,y:687,t:1528139809559};\\\", \\\"{x:514,y:679,t:1528139809576};\\\", \\\"{x:514,y:662,t:1528139809593};\\\", \\\"{x:514,y:639,t:1528139809609};\\\" ] }, { \\\"rt\\\": 16538, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 755501, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:499,t:1528139809728};\\\", \\\"{x:467,y:499,t:1528139810086};\\\", \\\"{x:473,y:499,t:1528139810798};\\\", \\\"{x:488,y:500,t:1528139810811};\\\", \\\"{x:550,y:502,t:1528139810830};\\\", \\\"{x:673,y:506,t:1528139810844};\\\", \\\"{x:809,y:510,t:1528139810861};\\\", \\\"{x:989,y:510,t:1528139810877};\\\", \\\"{x:1086,y:510,t:1528139810894};\\\", \\\"{x:1188,y:510,t:1528139810910};\\\", \\\"{x:1294,y:510,t:1528139810928};\\\", \\\"{x:1380,y:510,t:1528139810944};\\\", \\\"{x:1440,y:513,t:1528139810961};\\\", \\\"{x:1474,y:518,t:1528139810977};\\\", \\\"{x:1493,y:521,t:1528139810995};\\\", \\\"{x:1502,y:523,t:1528139811012};\\\", \\\"{x:1508,y:525,t:1528139811027};\\\", \\\"{x:1519,y:529,t:1528139811045};\\\", \\\"{x:1529,y:533,t:1528139811062};\\\", \\\"{x:1538,y:538,t:1528139811078};\\\", \\\"{x:1549,y:542,t:1528139811095};\\\", \\\"{x:1567,y:551,t:1528139811111};\\\", \\\"{x:1591,y:558,t:1528139811127};\\\", \\\"{x:1616,y:564,t:1528139811145};\\\", \\\"{x:1631,y:570,t:1528139811162};\\\", \\\"{x:1639,y:574,t:1528139811178};\\\", \\\"{x:1645,y:579,t:1528139811195};\\\", \\\"{x:1649,y:582,t:1528139811212};\\\", \\\"{x:1652,y:585,t:1528139811228};\\\", \\\"{x:1653,y:588,t:1528139811245};\\\", \\\"{x:1660,y:600,t:1528139811262};\\\", \\\"{x:1664,y:613,t:1528139811278};\\\", \\\"{x:1673,y:628,t:1528139811295};\\\", \\\"{x:1682,y:648,t:1528139811312};\\\", \\\"{x:1688,y:660,t:1528139811328};\\\", \\\"{x:1703,y:684,t:1528139811345};\\\", \\\"{x:1718,y:705,t:1528139811362};\\\", \\\"{x:1734,y:726,t:1528139811378};\\\", \\\"{x:1745,y:742,t:1528139811395};\\\", \\\"{x:1751,y:750,t:1528139811412};\\\", \\\"{x:1754,y:758,t:1528139811428};\\\", \\\"{x:1756,y:760,t:1528139811445};\\\", \\\"{x:1756,y:763,t:1528139811463};\\\", \\\"{x:1757,y:764,t:1528139811479};\\\", \\\"{x:1757,y:766,t:1528139811495};\\\", \\\"{x:1758,y:769,t:1528139811512};\\\", \\\"{x:1758,y:778,t:1528139811529};\\\", \\\"{x:1758,y:790,t:1528139811546};\\\", \\\"{x:1757,y:801,t:1528139811562};\\\", \\\"{x:1750,y:815,t:1528139811579};\\\", \\\"{x:1744,y:829,t:1528139811597};\\\", \\\"{x:1735,y:848,t:1528139811612};\\\", \\\"{x:1720,y:882,t:1528139811628};\\\", \\\"{x:1702,y:909,t:1528139811645};\\\", \\\"{x:1678,y:936,t:1528139811661};\\\", \\\"{x:1667,y:944,t:1528139811679};\\\", \\\"{x:1658,y:949,t:1528139811694};\\\", \\\"{x:1652,y:950,t:1528139811711};\\\", \\\"{x:1647,y:950,t:1528139811728};\\\", \\\"{x:1645,y:950,t:1528139811744};\\\", \\\"{x:1638,y:949,t:1528139811761};\\\", \\\"{x:1619,y:939,t:1528139811778};\\\", \\\"{x:1609,y:933,t:1528139811795};\\\", \\\"{x:1608,y:932,t:1528139811812};\\\", \\\"{x:1607,y:931,t:1528139811829};\\\", \\\"{x:1607,y:925,t:1528139811844};\\\", \\\"{x:1605,y:912,t:1528139811862};\\\", \\\"{x:1605,y:904,t:1528139811878};\\\", \\\"{x:1605,y:898,t:1528139811896};\\\", \\\"{x:1605,y:894,t:1528139811912};\\\", \\\"{x:1605,y:893,t:1528139811929};\\\", \\\"{x:1605,y:890,t:1528139811947};\\\", \\\"{x:1604,y:889,t:1528139811962};\\\", \\\"{x:1604,y:888,t:1528139811979};\\\", \\\"{x:1602,y:887,t:1528139811996};\\\", \\\"{x:1596,y:882,t:1528139812012};\\\", \\\"{x:1589,y:879,t:1528139812029};\\\", \\\"{x:1581,y:874,t:1528139812046};\\\", \\\"{x:1579,y:872,t:1528139812062};\\\", \\\"{x:1576,y:869,t:1528139812079};\\\", \\\"{x:1575,y:866,t:1528139812096};\\\", \\\"{x:1572,y:863,t:1528139812112};\\\", \\\"{x:1569,y:859,t:1528139812129};\\\", \\\"{x:1569,y:857,t:1528139812147};\\\", \\\"{x:1568,y:852,t:1528139812162};\\\", \\\"{x:1568,y:848,t:1528139812179};\\\", \\\"{x:1568,y:845,t:1528139812196};\\\", \\\"{x:1567,y:843,t:1528139812212};\\\", \\\"{x:1567,y:840,t:1528139812230};\\\", \\\"{x:1567,y:838,t:1528139812246};\\\", \\\"{x:1567,y:836,t:1528139812262};\\\", \\\"{x:1567,y:834,t:1528139812279};\\\", \\\"{x:1567,y:832,t:1528139812296};\\\", \\\"{x:1567,y:831,t:1528139812313};\\\", \\\"{x:1566,y:825,t:1528139812329};\\\", \\\"{x:1563,y:819,t:1528139812348};\\\", \\\"{x:1560,y:816,t:1528139812362};\\\", \\\"{x:1559,y:815,t:1528139812379};\\\", \\\"{x:1559,y:813,t:1528139812396};\\\", \\\"{x:1559,y:811,t:1528139812413};\\\", \\\"{x:1557,y:807,t:1528139812429};\\\", \\\"{x:1554,y:791,t:1528139812447};\\\", \\\"{x:1552,y:787,t:1528139812463};\\\", \\\"{x:1550,y:782,t:1528139812480};\\\", \\\"{x:1548,y:775,t:1528139812496};\\\", \\\"{x:1547,y:772,t:1528139812513};\\\", \\\"{x:1546,y:771,t:1528139812529};\\\", \\\"{x:1546,y:770,t:1528139812546};\\\", \\\"{x:1546,y:769,t:1528139812566};\\\", \\\"{x:1546,y:768,t:1528139812581};\\\", \\\"{x:1546,y:767,t:1528139812613};\\\", \\\"{x:1546,y:766,t:1528139812629};\\\", \\\"{x:1545,y:765,t:1528139812654};\\\", \\\"{x:1545,y:764,t:1528139812710};\\\", \\\"{x:1545,y:763,t:1528139812726};\\\", \\\"{x:1545,y:762,t:1528139812742};\\\", \\\"{x:1545,y:760,t:1528139812749};\\\", \\\"{x:1545,y:759,t:1528139812763};\\\", \\\"{x:1545,y:757,t:1528139812779};\\\", \\\"{x:1545,y:751,t:1528139812795};\\\", \\\"{x:1545,y:749,t:1528139812814};\\\", \\\"{x:1545,y:746,t:1528139812830};\\\", \\\"{x:1545,y:742,t:1528139812846};\\\", \\\"{x:1545,y:735,t:1528139812863};\\\", \\\"{x:1545,y:727,t:1528139812880};\\\", \\\"{x:1545,y:723,t:1528139812895};\\\", \\\"{x:1545,y:717,t:1528139812913};\\\", \\\"{x:1545,y:712,t:1528139812930};\\\", \\\"{x:1545,y:709,t:1528139812947};\\\", \\\"{x:1545,y:704,t:1528139812963};\\\", \\\"{x:1545,y:701,t:1528139812980};\\\", \\\"{x:1545,y:697,t:1528139812996};\\\", \\\"{x:1545,y:695,t:1528139813013};\\\", \\\"{x:1545,y:691,t:1528139813030};\\\", \\\"{x:1546,y:686,t:1528139813046};\\\", \\\"{x:1547,y:681,t:1528139813063};\\\", \\\"{x:1547,y:677,t:1528139813080};\\\", \\\"{x:1547,y:673,t:1528139813096};\\\", \\\"{x:1547,y:669,t:1528139813113};\\\", \\\"{x:1547,y:665,t:1528139813130};\\\", \\\"{x:1547,y:660,t:1528139813147};\\\", \\\"{x:1547,y:653,t:1528139813163};\\\", \\\"{x:1547,y:647,t:1528139813180};\\\", \\\"{x:1547,y:641,t:1528139813196};\\\", \\\"{x:1547,y:634,t:1528139813213};\\\", \\\"{x:1547,y:625,t:1528139813230};\\\", \\\"{x:1547,y:620,t:1528139813247};\\\", \\\"{x:1547,y:616,t:1528139813263};\\\", \\\"{x:1547,y:612,t:1528139813281};\\\", \\\"{x:1547,y:607,t:1528139813297};\\\", \\\"{x:1547,y:600,t:1528139813313};\\\", \\\"{x:1547,y:593,t:1528139813330};\\\", \\\"{x:1547,y:583,t:1528139813348};\\\", \\\"{x:1547,y:573,t:1528139813364};\\\", \\\"{x:1547,y:561,t:1528139813380};\\\", \\\"{x:1548,y:552,t:1528139813398};\\\", \\\"{x:1550,y:543,t:1528139813414};\\\", \\\"{x:1550,y:535,t:1528139813431};\\\", \\\"{x:1551,y:530,t:1528139813447};\\\", \\\"{x:1551,y:524,t:1528139813463};\\\", \\\"{x:1551,y:523,t:1528139813480};\\\", \\\"{x:1551,y:521,t:1528139813497};\\\", \\\"{x:1551,y:520,t:1528139813535};\\\", \\\"{x:1551,y:531,t:1528139813871};\\\", \\\"{x:1549,y:545,t:1528139813880};\\\", \\\"{x:1543,y:588,t:1528139813897};\\\", \\\"{x:1538,y:640,t:1528139813914};\\\", \\\"{x:1530,y:707,t:1528139813930};\\\", \\\"{x:1515,y:788,t:1528139813948};\\\", \\\"{x:1506,y:858,t:1528139813964};\\\", \\\"{x:1495,y:936,t:1528139813980};\\\", \\\"{x:1485,y:1006,t:1528139813998};\\\", \\\"{x:1470,y:1126,t:1528139814014};\\\", \\\"{x:1460,y:1188,t:1528139814031};\\\", \\\"{x:1455,y:1215,t:1528139814047};\\\", \\\"{x:1450,y:1215,t:1528139814064};\\\", \\\"{x:1449,y:1215,t:1528139814081};\\\", \\\"{x:1448,y:1215,t:1528139814098};\\\", \\\"{x:1452,y:1213,t:1528139814157};\\\", \\\"{x:1456,y:1203,t:1528139814166};\\\", \\\"{x:1463,y:1193,t:1528139814181};\\\", \\\"{x:1488,y:1156,t:1528139814197};\\\", \\\"{x:1514,y:1122,t:1528139814213};\\\", \\\"{x:1533,y:1096,t:1528139814231};\\\", \\\"{x:1547,y:1068,t:1528139814246};\\\", \\\"{x:1553,y:1048,t:1528139814264};\\\", \\\"{x:1557,y:1033,t:1528139814280};\\\", \\\"{x:1557,y:1029,t:1528139814297};\\\", \\\"{x:1557,y:1025,t:1528139814872};\\\", \\\"{x:1557,y:1023,t:1528139814882};\\\", \\\"{x:1557,y:1018,t:1528139814898};\\\", \\\"{x:1557,y:1015,t:1528139814914};\\\", \\\"{x:1557,y:1011,t:1528139814930};\\\", \\\"{x:1557,y:1009,t:1528139814948};\\\", \\\"{x:1557,y:1004,t:1528139814964};\\\", \\\"{x:1557,y:1001,t:1528139814981};\\\", \\\"{x:1557,y:995,t:1528139814998};\\\", \\\"{x:1557,y:994,t:1528139815014};\\\", \\\"{x:1557,y:990,t:1528139815031};\\\", \\\"{x:1557,y:987,t:1528139815048};\\\", \\\"{x:1557,y:981,t:1528139815064};\\\", \\\"{x:1557,y:979,t:1528139815081};\\\", \\\"{x:1557,y:977,t:1528139815098};\\\", \\\"{x:1557,y:976,t:1528139815115};\\\", \\\"{x:1557,y:974,t:1528139815132};\\\", \\\"{x:1557,y:971,t:1528139815148};\\\", \\\"{x:1557,y:970,t:1528139815166};\\\", \\\"{x:1557,y:969,t:1528139815181};\\\", \\\"{x:1557,y:967,t:1528139815199};\\\", \\\"{x:1557,y:965,t:1528139815214};\\\", \\\"{x:1557,y:964,t:1528139815231};\\\", \\\"{x:1557,y:963,t:1528139815262};\\\", \\\"{x:1557,y:962,t:1528139815279};\\\", \\\"{x:1557,y:961,t:1528139815287};\\\", \\\"{x:1557,y:960,t:1528139815302};\\\", \\\"{x:1557,y:957,t:1528139815316};\\\", \\\"{x:1557,y:954,t:1528139815331};\\\", \\\"{x:1557,y:948,t:1528139815348};\\\", \\\"{x:1557,y:941,t:1528139815365};\\\", \\\"{x:1557,y:932,t:1528139815381};\\\", \\\"{x:1557,y:922,t:1528139815399};\\\", \\\"{x:1557,y:914,t:1528139815416};\\\", \\\"{x:1557,y:906,t:1528139815431};\\\", \\\"{x:1557,y:900,t:1528139815448};\\\", \\\"{x:1557,y:896,t:1528139815465};\\\", \\\"{x:1557,y:892,t:1528139815481};\\\", \\\"{x:1557,y:889,t:1528139815498};\\\", \\\"{x:1557,y:885,t:1528139815515};\\\", \\\"{x:1559,y:883,t:1528139815531};\\\", \\\"{x:1559,y:882,t:1528139815548};\\\", \\\"{x:1559,y:879,t:1528139815565};\\\", \\\"{x:1559,y:878,t:1528139815582};\\\", \\\"{x:1559,y:876,t:1528139815598};\\\", \\\"{x:1559,y:875,t:1528139815615};\\\", \\\"{x:1559,y:873,t:1528139815632};\\\", \\\"{x:1559,y:872,t:1528139815648};\\\", \\\"{x:1559,y:870,t:1528139815666};\\\", \\\"{x:1559,y:868,t:1528139815682};\\\", \\\"{x:1558,y:863,t:1528139815697};\\\", \\\"{x:1558,y:860,t:1528139815714};\\\", \\\"{x:1558,y:858,t:1528139815732};\\\", \\\"{x:1557,y:856,t:1528139815748};\\\", \\\"{x:1557,y:855,t:1528139815765};\\\", \\\"{x:1557,y:854,t:1528139815781};\\\", \\\"{x:1557,y:853,t:1528139815797};\\\", \\\"{x:1557,y:852,t:1528139815815};\\\", \\\"{x:1557,y:851,t:1528139815832};\\\", \\\"{x:1557,y:849,t:1528139815848};\\\", \\\"{x:1557,y:848,t:1528139815865};\\\", \\\"{x:1556,y:844,t:1528139815882};\\\", \\\"{x:1556,y:842,t:1528139815898};\\\", \\\"{x:1556,y:840,t:1528139815915};\\\", \\\"{x:1556,y:837,t:1528139815932};\\\", \\\"{x:1555,y:834,t:1528139815948};\\\", \\\"{x:1554,y:832,t:1528139815965};\\\", \\\"{x:1554,y:830,t:1528139815982};\\\", \\\"{x:1554,y:829,t:1528139815998};\\\", \\\"{x:1554,y:827,t:1528139816015};\\\", \\\"{x:1553,y:826,t:1528139816039};\\\", \\\"{x:1553,y:825,t:1528139816054};\\\", \\\"{x:1553,y:824,t:1528139816066};\\\", \\\"{x:1553,y:823,t:1528139816086};\\\", \\\"{x:1553,y:822,t:1528139816099};\\\", \\\"{x:1553,y:821,t:1528139816115};\\\", \\\"{x:1553,y:819,t:1528139816132};\\\", \\\"{x:1553,y:818,t:1528139816150};\\\", \\\"{x:1553,y:817,t:1528139816175};\\\", \\\"{x:1553,y:816,t:1528139816350};\\\", \\\"{x:1553,y:815,t:1528139816366};\\\", \\\"{x:1553,y:814,t:1528139816431};\\\", \\\"{x:1553,y:813,t:1528139816455};\\\", \\\"{x:1553,y:812,t:1528139816470};\\\", \\\"{x:1553,y:811,t:1528139816486};\\\", \\\"{x:1553,y:809,t:1528139816499};\\\", \\\"{x:1553,y:808,t:1528139816517};\\\", \\\"{x:1553,y:805,t:1528139816532};\\\", \\\"{x:1553,y:801,t:1528139816549};\\\", \\\"{x:1553,y:796,t:1528139816566};\\\", \\\"{x:1553,y:791,t:1528139816581};\\\", \\\"{x:1553,y:787,t:1528139816599};\\\", \\\"{x:1553,y:783,t:1528139816615};\\\", \\\"{x:1553,y:780,t:1528139816631};\\\", \\\"{x:1553,y:777,t:1528139816649};\\\", \\\"{x:1553,y:775,t:1528139816666};\\\", \\\"{x:1553,y:774,t:1528139816682};\\\", \\\"{x:1553,y:773,t:1528139816701};\\\", \\\"{x:1552,y:773,t:1528139817023};\\\", \\\"{x:1552,y:770,t:1528139819741};\\\", \\\"{x:1552,y:767,t:1528139819751};\\\", \\\"{x:1552,y:758,t:1528139819768};\\\", \\\"{x:1552,y:749,t:1528139819784};\\\", \\\"{x:1552,y:741,t:1528139819801};\\\", \\\"{x:1553,y:734,t:1528139819818};\\\", \\\"{x:1553,y:729,t:1528139819834};\\\", \\\"{x:1553,y:726,t:1528139819851};\\\", \\\"{x:1553,y:723,t:1528139819869};\\\", \\\"{x:1553,y:722,t:1528139819885};\\\", \\\"{x:1553,y:721,t:1528139819901};\\\", \\\"{x:1553,y:720,t:1528139819918};\\\", \\\"{x:1553,y:719,t:1528139819935};\\\", \\\"{x:1553,y:718,t:1528139819958};\\\", \\\"{x:1553,y:717,t:1528139819969};\\\", \\\"{x:1553,y:715,t:1528139819985};\\\", \\\"{x:1553,y:711,t:1528139820002};\\\", \\\"{x:1553,y:706,t:1528139820018};\\\", \\\"{x:1553,y:700,t:1528139820038};\\\", \\\"{x:1553,y:691,t:1528139820052};\\\", \\\"{x:1556,y:678,t:1528139820068};\\\", \\\"{x:1557,y:662,t:1528139820086};\\\", \\\"{x:1560,y:639,t:1528139820102};\\\", \\\"{x:1561,y:624,t:1528139820118};\\\", \\\"{x:1562,y:612,t:1528139820136};\\\", \\\"{x:1563,y:602,t:1528139820152};\\\", \\\"{x:1563,y:595,t:1528139820168};\\\", \\\"{x:1564,y:589,t:1528139820185};\\\", \\\"{x:1565,y:585,t:1528139820201};\\\", \\\"{x:1565,y:581,t:1528139820218};\\\", \\\"{x:1565,y:577,t:1528139820235};\\\", \\\"{x:1565,y:573,t:1528139820252};\\\", \\\"{x:1565,y:571,t:1528139820269};\\\", \\\"{x:1565,y:567,t:1528139820286};\\\", \\\"{x:1565,y:561,t:1528139820302};\\\", \\\"{x:1564,y:558,t:1528139820318};\\\", \\\"{x:1564,y:554,t:1528139820336};\\\", \\\"{x:1564,y:550,t:1528139820352};\\\", \\\"{x:1561,y:542,t:1528139820368};\\\", \\\"{x:1560,y:534,t:1528139820386};\\\", \\\"{x:1557,y:522,t:1528139820402};\\\", \\\"{x:1555,y:508,t:1528139820418};\\\", \\\"{x:1552,y:492,t:1528139820435};\\\", \\\"{x:1550,y:477,t:1528139820452};\\\", \\\"{x:1549,y:463,t:1528139820469};\\\", \\\"{x:1546,y:446,t:1528139820485};\\\", \\\"{x:1542,y:421,t:1528139820502};\\\", \\\"{x:1541,y:406,t:1528139820519};\\\", \\\"{x:1540,y:392,t:1528139820536};\\\", \\\"{x:1539,y:378,t:1528139820552};\\\", \\\"{x:1537,y:362,t:1528139820569};\\\", \\\"{x:1535,y:348,t:1528139820585};\\\", \\\"{x:1535,y:336,t:1528139820602};\\\", \\\"{x:1535,y:328,t:1528139820619};\\\", \\\"{x:1535,y:320,t:1528139820636};\\\", \\\"{x:1535,y:315,t:1528139820652};\\\", \\\"{x:1535,y:312,t:1528139820668};\\\", \\\"{x:1531,y:312,t:1528139821150};\\\", \\\"{x:1521,y:317,t:1528139821158};\\\", \\\"{x:1508,y:326,t:1528139821169};\\\", \\\"{x:1453,y:370,t:1528139821185};\\\", \\\"{x:1364,y:435,t:1528139821202};\\\", \\\"{x:1249,y:503,t:1528139821220};\\\", \\\"{x:1104,y:576,t:1528139821235};\\\", \\\"{x:944,y:650,t:1528139821252};\\\", \\\"{x:768,y:724,t:1528139821270};\\\", \\\"{x:606,y:787,t:1528139821286};\\\", \\\"{x:413,y:860,t:1528139821302};\\\", \\\"{x:336,y:880,t:1528139821319};\\\", \\\"{x:294,y:891,t:1528139821336};\\\", \\\"{x:273,y:897,t:1528139821352};\\\", \\\"{x:264,y:898,t:1528139821369};\\\", \\\"{x:263,y:898,t:1528139821387};\\\", \\\"{x:262,y:898,t:1528139821402};\\\", \\\"{x:261,y:898,t:1528139821419};\\\", \\\"{x:260,y:898,t:1528139821438};\\\", \\\"{x:259,y:898,t:1528139821453};\\\", \\\"{x:258,y:898,t:1528139821470};\\\", \\\"{x:254,y:892,t:1528139821486};\\\", \\\"{x:252,y:878,t:1528139821502};\\\", \\\"{x:249,y:863,t:1528139821520};\\\", \\\"{x:249,y:852,t:1528139821537};\\\", \\\"{x:250,y:843,t:1528139821553};\\\", \\\"{x:253,y:833,t:1528139821570};\\\", \\\"{x:259,y:823,t:1528139821586};\\\", \\\"{x:268,y:813,t:1528139821603};\\\", \\\"{x:278,y:805,t:1528139821619};\\\", \\\"{x:288,y:799,t:1528139821636};\\\", \\\"{x:296,y:792,t:1528139821653};\\\", \\\"{x:303,y:790,t:1528139821670};\\\", \\\"{x:321,y:781,t:1528139821686};\\\", \\\"{x:335,y:771,t:1528139821702};\\\", \\\"{x:347,y:761,t:1528139821720};\\\", \\\"{x:358,y:755,t:1528139821736};\\\", \\\"{x:371,y:749,t:1528139821753};\\\", \\\"{x:386,y:741,t:1528139821770};\\\", \\\"{x:402,y:734,t:1528139821786};\\\", \\\"{x:423,y:725,t:1528139821802};\\\", \\\"{x:451,y:716,t:1528139821820};\\\", \\\"{x:489,y:701,t:1528139821836};\\\", \\\"{x:529,y:688,t:1528139821853};\\\", \\\"{x:562,y:679,t:1528139821870};\\\", \\\"{x:605,y:666,t:1528139821886};\\\", \\\"{x:619,y:663,t:1528139821903};\\\", \\\"{x:624,y:660,t:1528139821919};\\\", \\\"{x:626,y:660,t:1528139821936};\\\", \\\"{x:625,y:660,t:1528139822111};\\\", \\\"{x:619,y:660,t:1528139822119};\\\", \\\"{x:609,y:663,t:1528139822137};\\\", \\\"{x:593,y:667,t:1528139822153};\\\", \\\"{x:577,y:673,t:1528139822169};\\\", \\\"{x:559,y:678,t:1528139822186};\\\", \\\"{x:532,y:685,t:1528139822204};\\\", \\\"{x:495,y:696,t:1528139822220};\\\", \\\"{x:467,y:701,t:1528139822236};\\\", \\\"{x:448,y:704,t:1528139822254};\\\", \\\"{x:439,y:708,t:1528139822270};\\\", \\\"{x:438,y:708,t:1528139822286};\\\", \\\"{x:436,y:708,t:1528139822398};\\\", \\\"{x:433,y:708,t:1528139822406};\\\", \\\"{x:430,y:708,t:1528139822420};\\\", \\\"{x:423,y:708,t:1528139822437};\\\", \\\"{x:421,y:708,t:1528139822453};\\\", \\\"{x:420,y:708,t:1528139822470};\\\", \\\"{x:419,y:708,t:1528139822486};\\\", \\\"{x:418,y:707,t:1528139822503};\\\", \\\"{x:416,y:707,t:1528139822520};\\\", \\\"{x:405,y:701,t:1528139822536};\\\", \\\"{x:399,y:699,t:1528139822553};\\\", \\\"{x:394,y:696,t:1528139822571};\\\", \\\"{x:391,y:695,t:1528139822586};\\\", \\\"{x:393,y:695,t:1528139822887};\\\", \\\"{x:397,y:693,t:1528139822904};\\\", \\\"{x:399,y:693,t:1528139822921};\\\", \\\"{x:400,y:693,t:1528139822937};\\\", \\\"{x:401,y:693,t:1528139822974};\\\", \\\"{x:401,y:692,t:1528139823399};\\\", \\\"{x:401,y:690,t:1528139823406};\\\", \\\"{x:401,y:688,t:1528139823421};\\\", \\\"{x:401,y:684,t:1528139823438};\\\", \\\"{x:401,y:676,t:1528139823454};\\\", \\\"{x:401,y:672,t:1528139823470};\\\", \\\"{x:401,y:667,t:1528139823489};\\\", \\\"{x:401,y:666,t:1528139823504};\\\", \\\"{x:401,y:664,t:1528139823520};\\\", \\\"{x:401,y:662,t:1528139823537};\\\", \\\"{x:401,y:661,t:1528139823555};\\\", \\\"{x:401,y:659,t:1528139823571};\\\", \\\"{x:401,y:658,t:1528139823589};\\\", \\\"{x:400,y:656,t:1528139823604};\\\", \\\"{x:399,y:654,t:1528139823621};\\\", \\\"{x:398,y:651,t:1528139823638};\\\", \\\"{x:398,y:650,t:1528139823655};\\\", \\\"{x:398,y:649,t:1528139823671};\\\", \\\"{x:398,y:654,t:1528139823965};\\\", \\\"{x:400,y:662,t:1528139823973};\\\", \\\"{x:403,y:665,t:1528139823988};\\\", \\\"{x:408,y:672,t:1528139824006};\\\", \\\"{x:414,y:678,t:1528139824021};\\\", \\\"{x:421,y:689,t:1528139824038};\\\", \\\"{x:424,y:694,t:1528139824056};\\\", \\\"{x:425,y:697,t:1528139824072};\\\", \\\"{x:426,y:698,t:1528139824088};\\\", \\\"{x:427,y:701,t:1528139824105};\\\", \\\"{x:429,y:703,t:1528139824122};\\\", \\\"{x:432,y:708,t:1528139824138};\\\", \\\"{x:439,y:714,t:1528139824155};\\\", \\\"{x:442,y:717,t:1528139824172};\\\", \\\"{x:444,y:718,t:1528139824189};\\\", \\\"{x:445,y:719,t:1528139824206};\\\", \\\"{x:449,y:720,t:1528139824222};\\\", \\\"{x:454,y:723,t:1528139824239};\\\", \\\"{x:465,y:727,t:1528139824255};\\\", \\\"{x:487,y:736,t:1528139824272};\\\", \\\"{x:537,y:757,t:1528139824289};\\\", \\\"{x:601,y:776,t:1528139824306};\\\", \\\"{x:657,y:792,t:1528139824322};\\\", \\\"{x:691,y:799,t:1528139824338};\\\", \\\"{x:697,y:800,t:1528139824355};\\\", \\\"{x:698,y:801,t:1528139824374};\\\", \\\"{x:696,y:801,t:1528139824414};\\\", \\\"{x:692,y:800,t:1528139824421};\\\", \\\"{x:686,y:797,t:1528139824438};\\\", \\\"{x:681,y:793,t:1528139824455};\\\", \\\"{x:673,y:790,t:1528139824473};\\\", \\\"{x:664,y:787,t:1528139824489};\\\", \\\"{x:654,y:784,t:1528139824505};\\\", \\\"{x:648,y:782,t:1528139824523};\\\", \\\"{x:645,y:780,t:1528139824538};\\\", \\\"{x:644,y:780,t:1528139824582};\\\", \\\"{x:643,y:780,t:1528139824598};\\\", \\\"{x:642,y:780,t:1528139824606};\\\", \\\"{x:640,y:779,t:1528139824621};\\\", \\\"{x:634,y:777,t:1528139824638};\\\", \\\"{x:632,y:777,t:1528139824655};\\\", \\\"{x:629,y:776,t:1528139824673};\\\", \\\"{x:625,y:776,t:1528139824688};\\\", \\\"{x:615,y:773,t:1528139824706};\\\", \\\"{x:594,y:773,t:1528139824722};\\\", \\\"{x:578,y:775,t:1528139824740};\\\", \\\"{x:573,y:775,t:1528139824755};\\\", \\\"{x:572,y:775,t:1528139824773};\\\", \\\"{x:572,y:774,t:1528139825023};\\\", \\\"{x:572,y:773,t:1528139825040};\\\", \\\"{x:572,y:772,t:1528139825056};\\\", \\\"{x:572,y:771,t:1528139825072};\\\", \\\"{x:572,y:770,t:1528139825631};\\\", \\\"{x:572,y:766,t:1528139825640};\\\", \\\"{x:574,y:760,t:1528139825656};\\\", \\\"{x:574,y:755,t:1528139825673};\\\", \\\"{x:574,y:752,t:1528139825690};\\\", \\\"{x:569,y:751,t:1528139825966};\\\", \\\"{x:556,y:748,t:1528139825975};\\\", \\\"{x:537,y:742,t:1528139825990};\\\", \\\"{x:534,y:742,t:1528139826006};\\\", \\\"{x:532,y:744,t:1528139827046};\\\", \\\"{x:530,y:745,t:1528139827058};\\\", \\\"{x:528,y:748,t:1528139827074};\\\", \\\"{x:526,y:749,t:1528139827091};\\\", \\\"{x:525,y:752,t:1528139827107};\\\", \\\"{x:523,y:754,t:1528139827124};\\\", \\\"{x:522,y:758,t:1528139827142};\\\", \\\"{x:519,y:763,t:1528139827158};\\\", \\\"{x:516,y:770,t:1528139827174};\\\", \\\"{x:513,y:775,t:1528139827192};\\\", \\\"{x:511,y:780,t:1528139827208};\\\", \\\"{x:509,y:784,t:1528139827225};\\\", \\\"{x:507,y:787,t:1528139827242};\\\", \\\"{x:507,y:788,t:1528139827257};\\\", \\\"{x:506,y:788,t:1528139827275};\\\", \\\"{x:506,y:789,t:1528139827303};\\\" ] }, { \\\"rt\\\": 4677, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 761404, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 0.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:792,t:1528139827726};\\\", \\\"{x:503,y:793,t:1528139827741};\\\", \\\"{x:500,y:797,t:1528139827757};\\\", \\\"{x:497,y:799,t:1528139827774};\\\", \\\"{x:495,y:801,t:1528139827791};\\\", \\\"{x:493,y:802,t:1528139827808};\\\", \\\"{x:493,y:803,t:1528139827824};\\\", \\\"{x:493,y:801,t:1528139829742};\\\", \\\"{x:493,y:799,t:1528139829750};\\\", \\\"{x:494,y:798,t:1528139829765};\\\", \\\"{x:495,y:795,t:1528139829776};\\\", \\\"{x:505,y:788,t:1528139829792};\\\", \\\"{x:521,y:779,t:1528139829809};\\\", \\\"{x:535,y:771,t:1528139829826};\\\", \\\"{x:550,y:761,t:1528139829843};\\\", \\\"{x:557,y:755,t:1528139829860};\\\", \\\"{x:563,y:750,t:1528139829876};\\\", \\\"{x:566,y:746,t:1528139829893};\\\", \\\"{x:570,y:741,t:1528139829909};\\\", \\\"{x:571,y:739,t:1528139829926};\\\", \\\"{x:572,y:738,t:1528139829949};\\\", \\\"{x:574,y:735,t:1528139830030};\\\", \\\"{x:575,y:733,t:1528139830043};\\\", \\\"{x:576,y:730,t:1528139830059};\\\", \\\"{x:578,y:725,t:1528139830076};\\\", \\\"{x:582,y:716,t:1528139830093};\\\", \\\"{x:583,y:713,t:1528139830110};\\\", \\\"{x:583,y:711,t:1528139830127};\\\", \\\"{x:584,y:710,t:1528139830143};\\\", \\\"{x:584,y:709,t:1528139830214};\\\", \\\"{x:584,y:708,t:1528139830230};\\\", \\\"{x:584,y:707,t:1528139830244};\\\", \\\"{x:577,y:700,t:1528139830260};\\\", \\\"{x:571,y:693,t:1528139830277};\\\", \\\"{x:567,y:673,t:1528139830294};\\\", \\\"{x:567,y:655,t:1528139830310};\\\", \\\"{x:567,y:636,t:1528139830327};\\\", \\\"{x:567,y:616,t:1528139830344};\\\", \\\"{x:569,y:601,t:1528139830361};\\\", \\\"{x:573,y:593,t:1528139830376};\\\", \\\"{x:575,y:592,t:1528139830393};\\\", \\\"{x:576,y:591,t:1528139830410};\\\", \\\"{x:578,y:591,t:1528139830606};\\\", \\\"{x:581,y:591,t:1528139830614};\\\", \\\"{x:588,y:589,t:1528139830626};\\\", \\\"{x:600,y:584,t:1528139830644};\\\", \\\"{x:607,y:582,t:1528139830661};\\\", \\\"{x:612,y:578,t:1528139830677};\\\", \\\"{x:613,y:578,t:1528139830693};\\\", \\\"{x:608,y:582,t:1528139831112};\\\", \\\"{x:600,y:594,t:1528139831127};\\\", \\\"{x:591,y:613,t:1528139831145};\\\", \\\"{x:583,y:641,t:1528139831161};\\\", \\\"{x:571,y:684,t:1528139831178};\\\", \\\"{x:558,y:728,t:1528139831193};\\\", \\\"{x:542,y:777,t:1528139831210};\\\", \\\"{x:537,y:803,t:1528139831227};\\\", \\\"{x:536,y:818,t:1528139831244};\\\", \\\"{x:536,y:826,t:1528139831260};\\\", \\\"{x:536,y:827,t:1528139831277};\\\", \\\"{x:535,y:828,t:1528139831326};\\\", \\\"{x:534,y:827,t:1528139831334};\\\", \\\"{x:534,y:821,t:1528139831345};\\\", \\\"{x:534,y:804,t:1528139831361};\\\", \\\"{x:534,y:786,t:1528139831377};\\\", \\\"{x:534,y:765,t:1528139831395};\\\", \\\"{x:534,y:748,t:1528139831412};\\\", \\\"{x:534,y:731,t:1528139831428};\\\", \\\"{x:533,y:720,t:1528139831445};\\\", \\\"{x:531,y:712,t:1528139831461};\\\", \\\"{x:530,y:709,t:1528139831478};\\\", \\\"{x:530,y:703,t:1528139831495};\\\", \\\"{x:530,y:698,t:1528139831512};\\\", \\\"{x:533,y:693,t:1528139831527};\\\", \\\"{x:535,y:689,t:1528139831545};\\\", \\\"{x:535,y:688,t:1528139831562};\\\", \\\"{x:535,y:689,t:1528139831670};\\\", \\\"{x:531,y:700,t:1528139831678};\\\", \\\"{x:516,y:728,t:1528139831695};\\\", \\\"{x:504,y:751,t:1528139831713};\\\", \\\"{x:495,y:770,t:1528139831728};\\\", \\\"{x:491,y:782,t:1528139831745};\\\", \\\"{x:490,y:784,t:1528139831762};\\\", \\\"{x:490,y:785,t:1528139831797};\\\", \\\"{x:489,y:785,t:1528139831811};\\\", \\\"{x:488,y:784,t:1528139831828};\\\", \\\"{x:486,y:778,t:1528139831844};\\\", \\\"{x:485,y:773,t:1528139831862};\\\", \\\"{x:484,y:772,t:1528139831879};\\\", \\\"{x:484,y:771,t:1528139831917};\\\", \\\"{x:484,y:769,t:1528139831928};\\\", \\\"{x:484,y:767,t:1528139831945};\\\", \\\"{x:485,y:761,t:1528139831961};\\\", \\\"{x:488,y:757,t:1528139831978};\\\", \\\"{x:489,y:754,t:1528139831994};\\\", \\\"{x:490,y:751,t:1528139832012};\\\", \\\"{x:491,y:749,t:1528139832269};\\\", \\\"{x:496,y:746,t:1528139832279};\\\", \\\"{x:507,y:739,t:1528139832295};\\\", \\\"{x:521,y:730,t:1528139832311};\\\", \\\"{x:536,y:722,t:1528139832328};\\\", \\\"{x:552,y:713,t:1528139832344};\\\", \\\"{x:570,y:702,t:1528139832362};\\\", \\\"{x:583,y:692,t:1528139832379};\\\", \\\"{x:591,y:685,t:1528139832394};\\\", \\\"{x:594,y:682,t:1528139832412};\\\", \\\"{x:594,y:680,t:1528139832429};\\\", \\\"{x:595,y:679,t:1528139832444};\\\", \\\"{x:595,y:678,t:1528139832862};\\\", \\\"{x:595,y:664,t:1528139832878};\\\", \\\"{x:593,y:648,t:1528139832896};\\\", \\\"{x:591,y:635,t:1528139832912};\\\", \\\"{x:589,y:624,t:1528139832929};\\\", \\\"{x:588,y:617,t:1528139832945};\\\", \\\"{x:588,y:612,t:1528139832962};\\\", \\\"{x:587,y:609,t:1528139832978};\\\" ] }, { \\\"rt\\\": 9220, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 771841, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"FOLLOW LINE\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6098, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 778944, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14654, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 794622, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 1836, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 797550, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"9TE89\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"9TE89\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 76, dom: 742, initialDom: 757",
  "javascriptErrors": []
}