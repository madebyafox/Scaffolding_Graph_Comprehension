var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0521497752af219d5b08ede6976942c36368dc6f"] = {
  "startTime": "2018-05-21T17:16:49.2572599Z",
  "websitePageUrl": "/16",
  "visitTime": 70757,
  "engagementTime": 68396,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f8dfd1f898a4734cbe94466e8e000901",
    "created": "2018-05-21T17:16:48.9616295+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=YE3VQ",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "fe501befca0e0b047ba54eb2ad917c5d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f8dfd1f898a4734cbe94466e8e000901/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 736,
      "e": 736,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 736,
      "e": 736,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 737,
      "e": 737,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 738,
      "e": 738,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 758,
      "e": 758,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 814,
      "e": 814,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 7099,
      "e": 5100,
      "ty": 2,
      "x": 553,
      "y": 704
    },
    {
      "t": 7198,
      "e": 5199,
      "ty": 2,
      "x": 555,
      "y": 891
    },
    {
      "t": 7249,
      "e": 5250,
      "ty": 41,
      "x": 55632,
      "y": 53851,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7299,
      "e": 5300,
      "ty": 2,
      "x": 656,
      "y": 771
    },
    {
      "t": 7399,
      "e": 5400,
      "ty": 2,
      "x": 693,
      "y": 631
    },
    {
      "t": 7499,
      "e": 5500,
      "ty": 2,
      "x": 609,
      "y": 371
    },
    {
      "t": 7499,
      "e": 5500,
      "ty": 41,
      "x": 57543,
      "y": 22088,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7599,
      "e": 5600,
      "ty": 2,
      "x": 590,
      "y": 392
    },
    {
      "t": 7699,
      "e": 5700,
      "ty": 2,
      "x": 539,
      "y": 403
    },
    {
      "t": 7733,
      "e": 5734,
      "ty": 6,
      "x": 491,
      "y": 513,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7749,
      "e": 5750,
      "ty": 41,
      "x": 44278,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7765,
      "e": 5766,
      "ty": 7,
      "x": 482,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7799,
      "e": 5800,
      "ty": 2,
      "x": 482,
      "y": 583
    },
    {
      "t": 7899,
      "e": 5900,
      "ty": 2,
      "x": 483,
      "y": 577
    },
    {
      "t": 7916,
      "e": 5917,
      "ty": 6,
      "x": 484,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7999,
      "e": 6000,
      "ty": 2,
      "x": 484,
      "y": 530
    },
    {
      "t": 7999,
      "e": 6000,
      "ty": 41,
      "x": 43492,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8034,
      "e": 6035,
      "ty": 3,
      "x": 484,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8035,
      "e": 6036,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8129,
      "e": 6130,
      "ty": 4,
      "x": 43492,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8130,
      "e": 6131,
      "ty": 5,
      "x": 484,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9222,
      "e": 7223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9222,
      "e": 7223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9325,
      "e": 7326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "a"
    },
    {
      "t": 9332,
      "e": 7333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9333,
      "e": 7334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9445,
      "e": 7446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "an"
    },
    {
      "t": 9570,
      "e": 7571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 9571,
      "e": 7572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9629,
      "e": 7630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any"
    },
    {
      "t": 9999,
      "e": 8000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10277,
      "e": 8278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10277,
      "e": 8278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10381,
      "e": 8382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any "
    },
    {
      "t": 10661,
      "e": 8662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 10661,
      "e": 8662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10757,
      "e": 8758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 10797,
      "e": 8798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10797,
      "e": 8798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10909,
      "e": 8910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10941,
      "e": 8942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10941,
      "e": 8942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11021,
      "e": 9022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11173,
      "e": 9174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11173,
      "e": 9174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11253,
      "e": 9254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 11285,
      "e": 9286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11285,
      "e": 9286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11373,
      "e": 9374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13389,
      "e": 11390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13390,
      "e": 11391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13509,
      "e": 11510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13516,
      "e": 11517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13516,
      "e": 11517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13589,
      "e": 11590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13653,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13654,
      "e": 11655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13749,
      "e": 11750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13765,
      "e": 11766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13765,
      "e": 11766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13829,
      "e": 11830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13830,
      "e": 11831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13830,
      "e": 11831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13965,
      "e": 11966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15093,
      "e": 13094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15094,
      "e": 13095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15199,
      "e": 13200,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that a"
    },
    {
      "t": 15221,
      "e": 13222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15357,
      "e": 13358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15357,
      "e": 13358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15445,
      "e": 13446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15445,
      "e": 13446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15453,
      "e": 13454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 15589,
      "e": 13590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15981,
      "e": 13982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16053,
      "e": 14054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that ar"
    },
    {
      "t": 16157,
      "e": 14158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16213,
      "e": 14214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that a"
    },
    {
      "t": 16301,
      "e": 14302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16349,
      "e": 14350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that "
    },
    {
      "t": 17573,
      "e": 15574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17573,
      "e": 15574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17669,
      "e": 15670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17669,
      "e": 15670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17693,
      "e": 15694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17693,
      "e": 15694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17709,
      "e": 15710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pla"
    },
    {
      "t": 17773,
      "e": 15774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17813,
      "e": 15814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17902,
      "e": 15903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17902,
      "e": 15903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17957,
      "e": 15958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17981,
      "e": 15982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17981,
      "e": 15982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18061,
      "e": 16062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18373,
      "e": 16374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18437,
      "e": 16438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that plax"
    },
    {
      "t": 18549,
      "e": 16550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18580,
      "e": 16581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that pla"
    },
    {
      "t": 18677,
      "e": 16678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18717,
      "e": 16718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that pl"
    },
    {
      "t": 18813,
      "e": 16814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18893,
      "e": 16894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that p"
    },
    {
      "t": 19000,
      "e": 17001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that p"
    },
    {
      "t": 19261,
      "e": 17262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19356,
      "e": 17357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that "
    },
    {
      "t": 19998,
      "e": 17999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22829,
      "e": 20830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22829,
      "e": 20830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22940,
      "e": 20941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 22940,
      "e": 20941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22965,
      "e": 20966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pl"
    },
    {
      "t": 23045,
      "e": 21046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23068,
      "e": 21069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23068,
      "e": 21069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23197,
      "e": 21198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23396,
      "e": 21397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23453,
      "e": 21454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that pl"
    },
    {
      "t": 23549,
      "e": 21550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23597,
      "e": 21598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that p"
    },
    {
      "t": 23685,
      "e": 21686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23749,
      "e": 21750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that "
    },
    {
      "t": 23845,
      "e": 21846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23845,
      "e": 21846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23997,
      "e": 21998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24004,
      "e": 22005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24005,
      "e": 22006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24157,
      "e": 22158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24157,
      "e": 22158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24189,
      "e": 22190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 24269,
      "e": 22270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24804,
      "e": 22805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24869,
      "e": 22870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that ar"
    },
    {
      "t": 24949,
      "e": 22950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25013,
      "e": 23014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that a"
    },
    {
      "t": 25757,
      "e": 23758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25757,
      "e": 23758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25877,
      "e": 23878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25877,
      "e": 23878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25908,
      "e": 23909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 25980,
      "e": 23981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25980,
      "e": 23981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25997,
      "e": 23998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26061,
      "e": 24062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26229,
      "e": 24230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26229,
      "e": 24230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26230,
      "e": 24231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "219"
    },
    {
      "t": 26230,
      "e": 24231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26292,
      "e": 24293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26293,
      "e": 24294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26317,
      "e": 24318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p[l"
    },
    {
      "t": 26333,
      "e": 24334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26413,
      "e": 24414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26525,
      "e": 24526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26525,
      "e": 24526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26628,
      "e": 24629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26741,
      "e": 24742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26781,
      "e": 24782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are p[l"
    },
    {
      "t": 26870,
      "e": 24871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26925,
      "e": 24926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are p["
    },
    {
      "t": 27020,
      "e": 25021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27077,
      "e": 25078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are p"
    },
    {
      "t": 27200,
      "e": 25201,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are p"
    },
    {
      "t": 27445,
      "e": 25446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27445,
      "e": 25446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27524,
      "e": 25525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27781,
      "e": 25782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27781,
      "e": 25782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27885,
      "e": 25886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28045,
      "e": 26046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 28045,
      "e": 26046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28165,
      "e": 26166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28165,
      "e": 26166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28172,
      "e": 26173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ce"
    },
    {
      "t": 28309,
      "e": 26310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28309,
      "e": 26310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28333,
      "e": 26334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 28445,
      "e": 26446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28556,
      "e": 26557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28557,
      "e": 26558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28628,
      "e": 26629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28836,
      "e": 26837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 28837,
      "e": 26838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28925,
      "e": 26926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 29253,
      "e": 27254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29253,
      "e": 27254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29325,
      "e": 27326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29396,
      "e": 27397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29397,
      "e": 27398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29477,
      "e": 27478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29501,
      "e": 27502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29501,
      "e": 27502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29573,
      "e": 27574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 29693,
      "e": 27694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29693,
      "e": 27694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29733,
      "e": 27734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29733,
      "e": 27734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29789,
      "e": 27790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 29845,
      "e": 27846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29999,
      "e": 28000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30300,
      "e": 28301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30341,
      "e": 28342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed beofe"
    },
    {
      "t": 30428,
      "e": 28429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30477,
      "e": 28478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed beof"
    },
    {
      "t": 30573,
      "e": 28574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30605,
      "e": 28606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed beo"
    },
    {
      "t": 30693,
      "e": 28694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30757,
      "e": 28758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30757,
      "e": 28758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30765,
      "e": 28766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed bef"
    },
    {
      "t": 30845,
      "e": 28846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30908,
      "e": 28909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30908,
      "e": 28909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30973,
      "e": 28974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31004,
      "e": 29005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31004,
      "e": 29005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31092,
      "e": 29093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31093,
      "e": 29094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31117,
      "e": 29118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 31221,
      "e": 29222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31293,
      "e": 29294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31293,
      "e": 29294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31389,
      "e": 29390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31541,
      "e": 29542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 31541,
      "e": 29542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31629,
      "e": 29630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 31629,
      "e": 29630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31660,
      "e": 29661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 31733,
      "e": 29734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31780,
      "e": 29781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31780,
      "e": 29781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31876,
      "e": 29877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32276,
      "e": 30277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32276,
      "e": 30277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32284,
      "e": 30285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32285,
      "e": 30286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32340,
      "e": 30341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||op"
    },
    {
      "t": 32365,
      "e": 30366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32644,
      "e": 30645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32708,
      "e": 30709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed before 12 o"
    },
    {
      "t": 32797,
      "e": 30798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32844,
      "e": 30845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed before 12 "
    },
    {
      "t": 32924,
      "e": 30925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33037,
      "e": 31038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed before 12"
    },
    {
      "t": 34068,
      "e": 32069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34068,
      "e": 32069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34149,
      "e": 32150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34149,
      "e": 32150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34188,
      "e": 32189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 34260,
      "e": 32261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34356,
      "e": 32357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34357,
      "e": 32358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34476,
      "e": 32477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35838,
      "e": 33839,
      "ty": 7,
      "x": 475,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35889,
      "e": 33890,
      "ty": 6,
      "x": 452,
      "y": 622,
      "ta": "#strategyButton"
    },
    {
      "t": 35899,
      "e": 33900,
      "ty": 2,
      "x": 452,
      "y": 622
    },
    {
      "t": 35955,
      "e": 33956,
      "ty": 7,
      "x": 442,
      "y": 637,
      "ta": "#strategyButton"
    },
    {
      "t": 35999,
      "e": 34000,
      "ty": 2,
      "x": 437,
      "y": 641
    },
    {
      "t": 35999,
      "e": 34000,
      "ty": 41,
      "x": 55426,
      "y": 47359,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 36089,
      "e": 34090,
      "ty": 6,
      "x": 436,
      "y": 630,
      "ta": "#strategyButton"
    },
    {
      "t": 36099,
      "e": 34100,
      "ty": 2,
      "x": 436,
      "y": 630
    },
    {
      "t": 36198,
      "e": 34199,
      "ty": 2,
      "x": 432,
      "y": 615
    },
    {
      "t": 36200,
      "e": 34201,
      "ty": 3,
      "x": 432,
      "y": 615,
      "ta": "#strategyButton"
    },
    {
      "t": 36201,
      "e": 34202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "any dots that are placed before 12pm "
    },
    {
      "t": 36202,
      "e": 34203,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36202,
      "e": 34203,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 36249,
      "e": 34250,
      "ty": 41,
      "x": 51011,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 36321,
      "e": 34322,
      "ty": 4,
      "x": 51011,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 36329,
      "e": 34330,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 36330,
      "e": 34331,
      "ty": 5,
      "x": 432,
      "y": 615,
      "ta": "#strategyButton"
    },
    {
      "t": 36339,
      "e": 34340,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 36499,
      "e": 34500,
      "ty": 2,
      "x": 432,
      "y": 612
    },
    {
      "t": 36499,
      "e": 34500,
      "ty": 41,
      "x": 14601,
      "y": 36753,
      "ta": "html > body"
    },
    {
      "t": 37333,
      "e": 35334,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 37898,
      "e": 35899,
      "ty": 2,
      "x": 787,
      "y": 522
    },
    {
      "t": 37906,
      "e": 35907,
      "ty": 6,
      "x": 886,
      "y": 512,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37990,
      "e": 35991,
      "ty": 7,
      "x": 1115,
      "y": 512,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37999,
      "e": 36000,
      "ty": 2,
      "x": 1115,
      "y": 512
    },
    {
      "t": 37999,
      "e": 36000,
      "ty": 41,
      "x": 38122,
      "y": 30668,
      "ta": "html > body"
    },
    {
      "t": 38099,
      "e": 36100,
      "ty": 2,
      "x": 1116,
      "y": 512
    },
    {
      "t": 38175,
      "e": 36176,
      "ty": 6,
      "x": 1107,
      "y": 514,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38199,
      "e": 36200,
      "ty": 2,
      "x": 1104,
      "y": 514
    },
    {
      "t": 38249,
      "e": 36250,
      "ty": 41,
      "x": 57316,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38298,
      "e": 36299,
      "ty": 2,
      "x": 1056,
      "y": 508
    },
    {
      "t": 38385,
      "e": 36386,
      "ty": 3,
      "x": 1056,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38385,
      "e": 36386,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38488,
      "e": 36489,
      "ty": 4,
      "x": 53639,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38488,
      "e": 36489,
      "ty": 5,
      "x": 1056,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38499,
      "e": 36500,
      "ty": 41,
      "x": 53639,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39036,
      "e": 37037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 39036,
      "e": 37037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39148,
      "e": 37149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 39148,
      "e": 37149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39157,
      "e": 37158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 39225,
      "e": 37159,
      "ty": 7,
      "x": 1033,
      "y": 522,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39237,
      "e": 37171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 39248,
      "e": 37182,
      "ty": 41,
      "x": 45420,
      "y": 2114,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39299,
      "e": 37233,
      "ty": 2,
      "x": 979,
      "y": 555
    },
    {
      "t": 39399,
      "e": 37333,
      "ty": 2,
      "x": 941,
      "y": 591
    },
    {
      "t": 39408,
      "e": 37342,
      "ty": 6,
      "x": 939,
      "y": 595,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39499,
      "e": 37433,
      "ty": 2,
      "x": 935,
      "y": 603
    },
    {
      "t": 39499,
      "e": 37433,
      "ty": 41,
      "x": 27468,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39599,
      "e": 37533,
      "ty": 2,
      "x": 935,
      "y": 608
    },
    {
      "t": 39749,
      "e": 37683,
      "ty": 41,
      "x": 27468,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39793,
      "e": 37727,
      "ty": 3,
      "x": 935,
      "y": 608,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39793,
      "e": 37727,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 39793,
      "e": 37727,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39793,
      "e": 37727,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39880,
      "e": 37814,
      "ty": 4,
      "x": 27468,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39881,
      "e": 37815,
      "ty": 5,
      "x": 935,
      "y": 608,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40597,
      "e": 38531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 40821,
      "e": 38755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40885,
      "e": 38819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 40892,
      "e": 38826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 41028,
      "e": 38962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 41148,
      "e": 39082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 41148,
      "e": 39082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41260,
      "e": 39194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "c"
    },
    {
      "t": 41268,
      "e": 39202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 41268,
      "e": 39202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41284,
      "e": 39218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "cH"
    },
    {
      "t": 41340,
      "e": 39274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "cH"
    },
    {
      "t": 41380,
      "e": 39314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 41380,
      "e": 39314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41469,
      "e": 39403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 41469,
      "e": 39403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41484,
      "e": 39418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "cHIN"
    },
    {
      "t": 41588,
      "e": 39522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 41797,
      "e": 39731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 41869,
      "e": 39803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "cHI"
    },
    {
      "t": 41948,
      "e": 39882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42004,
      "e": 39938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "cH"
    },
    {
      "t": 42068,
      "e": 40002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42140,
      "e": 40074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "c"
    },
    {
      "t": 42205,
      "e": 40139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42268,
      "e": 40202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42340,
      "e": 40274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42397,
      "e": 40331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42461,
      "e": 40395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 42564,
      "e": 40498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42580,
      "e": 40514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 42668,
      "e": 40602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 42868,
      "e": 40802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 43053,
      "e": 40987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 43054,
      "e": 40988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43164,
      "e": 41098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 43172,
      "e": 41106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 43172,
      "e": 41106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43252,
      "e": 41186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CH"
    },
    {
      "t": 43268,
      "e": 41202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43269,
      "e": 41203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43276,
      "e": 41210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHi"
    },
    {
      "t": 43397,
      "e": 41331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 43397,
      "e": 41331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43413,
      "e": 41347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHin"
    },
    {
      "t": 43444,
      "e": 41378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 43444,
      "e": 41378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43500,
      "e": 41434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 43533,
      "e": 41467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 44004,
      "e": 41938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "187"
    },
    {
      "t": 44004,
      "e": 41938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44045,
      "e": 41979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||="
    },
    {
      "t": 44200,
      "e": 42134,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHina="
    },
    {
      "t": 44268,
      "e": 42202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44332,
      "e": 42266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHina"
    },
    {
      "t": 44428,
      "e": 42362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44468,
      "e": 42402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHin"
    },
    {
      "t": 44549,
      "e": 42483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44596,
      "e": 42530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CHi"
    },
    {
      "t": 44684,
      "e": 42618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 44765,
      "e": 42699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CH"
    },
    {
      "t": 45180,
      "e": 43114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 45292,
      "e": 43226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 45564,
      "e": 43498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 45564,
      "e": 43498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45652,
      "e": 43586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 45668,
      "e": 43602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 45668,
      "e": 43602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45797,
      "e": 43731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 45797,
      "e": 43731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45812,
      "e": 43746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 45892,
      "e": 43826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 45892,
      "e": 43826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45917,
      "e": 43851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 45956,
      "e": 43890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 46360,
      "e": 44294,
      "ty": 7,
      "x": 965,
      "y": 575,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46368,
      "e": 44302,
      "ty": 6,
      "x": 1021,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46380,
      "e": 44314,
      "ty": 7,
      "x": 1070,
      "y": 441,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46398,
      "e": 44332,
      "ty": 2,
      "x": 1147,
      "y": 330
    },
    {
      "t": 46498,
      "e": 44432,
      "ty": 2,
      "x": 1097,
      "y": 335
    },
    {
      "t": 46498,
      "e": 44432,
      "ty": 41,
      "x": 37502,
      "y": 19897,
      "ta": "html > body"
    },
    {
      "t": 46598,
      "e": 44532,
      "ty": 2,
      "x": 1094,
      "y": 371
    },
    {
      "t": 46698,
      "e": 44632,
      "ty": 6,
      "x": 1092,
      "y": 596,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46698,
      "e": 44632,
      "ty": 2,
      "x": 1092,
      "y": 596
    },
    {
      "t": 46748,
      "e": 44682,
      "ty": 41,
      "x": 60992,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46798,
      "e": 44732,
      "ty": 2,
      "x": 1069,
      "y": 612
    },
    {
      "t": 46814,
      "e": 44748,
      "ty": 7,
      "x": 1057,
      "y": 618,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46898,
      "e": 44832,
      "ty": 6,
      "x": 1012,
      "y": 631,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46898,
      "e": 44832,
      "ty": 2,
      "x": 1012,
      "y": 631
    },
    {
      "t": 46998,
      "e": 44932,
      "ty": 2,
      "x": 965,
      "y": 650
    },
    {
      "t": 46998,
      "e": 44932,
      "ty": 41,
      "x": 35602,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47072,
      "e": 45006,
      "ty": 3,
      "x": 965,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47073,
      "e": 45007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 47073,
      "e": 45007,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47073,
      "e": 45007,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47160,
      "e": 45094,
      "ty": 4,
      "x": 35602,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47160,
      "e": 45094,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47161,
      "e": 45095,
      "ty": 5,
      "x": 965,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47161,
      "e": 45095,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 47248,
      "e": 45182,
      "ty": 41,
      "x": 32922,
      "y": 39065,
      "ta": "html > body"
    },
    {
      "t": 47298,
      "e": 45232,
      "ty": 2,
      "x": 964,
      "y": 650
    },
    {
      "t": 47699,
      "e": 45633,
      "ty": 2,
      "x": 951,
      "y": 646
    },
    {
      "t": 47748,
      "e": 45682,
      "ty": 41,
      "x": 32233,
      "y": 38578,
      "ta": "html > body"
    },
    {
      "t": 47798,
      "e": 45732,
      "ty": 2,
      "x": 936,
      "y": 638
    },
    {
      "t": 47898,
      "e": 45832,
      "ty": 2,
      "x": 936,
      "y": 631
    },
    {
      "t": 47998,
      "e": 45932,
      "ty": 2,
      "x": 936,
      "y": 620
    },
    {
      "t": 47998,
      "e": 45932,
      "ty": 41,
      "x": 31958,
      "y": 37239,
      "ta": "html > body"
    },
    {
      "t": 48098,
      "e": 46032,
      "ty": 2,
      "x": 934,
      "y": 609
    },
    {
      "t": 48172,
      "e": 46106,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 48248,
      "e": 46032,
      "ty": 41,
      "x": 26717,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 48298,
      "e": 46082,
      "ty": 2,
      "x": 934,
      "y": 608
    },
    {
      "t": 48399,
      "e": 46183,
      "ty": 2,
      "x": 944,
      "y": 608
    },
    {
      "t": 48498,
      "e": 46282,
      "ty": 41,
      "x": 29090,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 48798,
      "e": 46582,
      "ty": 2,
      "x": 924,
      "y": 584
    },
    {
      "t": 48898,
      "e": 46682,
      "ty": 2,
      "x": 962,
      "y": 366
    },
    {
      "t": 48998,
      "e": 46782,
      "ty": 2,
      "x": 1108,
      "y": 197
    },
    {
      "t": 48998,
      "e": 46782,
      "ty": 41,
      "x": 37881,
      "y": 11500,
      "ta": "html > body"
    },
    {
      "t": 49098,
      "e": 46882,
      "ty": 2,
      "x": 1096,
      "y": 182
    },
    {
      "t": 49198,
      "e": 46982,
      "ty": 2,
      "x": 1074,
      "y": 198
    },
    {
      "t": 49248,
      "e": 47032,
      "ty": 41,
      "x": 57569,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49298,
      "e": 47082,
      "ty": 2,
      "x": 1038,
      "y": 203
    },
    {
      "t": 49398,
      "e": 47182,
      "ty": 2,
      "x": 931,
      "y": 197
    },
    {
      "t": 49499,
      "e": 47283,
      "ty": 2,
      "x": 893,
      "y": 181
    },
    {
      "t": 49499,
      "e": 47283,
      "ty": 41,
      "x": 58613,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49598,
      "e": 47382,
      "ty": 2,
      "x": 889,
      "y": 180
    },
    {
      "t": 49698,
      "e": 47482,
      "ty": 2,
      "x": 888,
      "y": 180
    },
    {
      "t": 49749,
      "e": 47533,
      "ty": 41,
      "x": 52880,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49798,
      "e": 47582,
      "ty": 2,
      "x": 886,
      "y": 196
    },
    {
      "t": 49898,
      "e": 47682,
      "ty": 2,
      "x": 889,
      "y": 234
    },
    {
      "t": 49998,
      "e": 47782,
      "ty": 2,
      "x": 903,
      "y": 277
    },
    {
      "t": 49998,
      "e": 47782,
      "ty": 41,
      "x": 19360,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 50098,
      "e": 47882,
      "ty": 2,
      "x": 903,
      "y": 275
    },
    {
      "t": 50198,
      "e": 47982,
      "ty": 2,
      "x": 908,
      "y": 258
    },
    {
      "t": 50248,
      "e": 48032,
      "ty": 41,
      "x": 28387,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50298,
      "e": 48082,
      "ty": 2,
      "x": 915,
      "y": 246
    },
    {
      "t": 50398,
      "e": 48182,
      "ty": 2,
      "x": 918,
      "y": 239
    },
    {
      "t": 50464,
      "e": 48248,
      "ty": 3,
      "x": 918,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50499,
      "e": 48283,
      "ty": 41,
      "x": 30267,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50553,
      "e": 48337,
      "ty": 4,
      "x": 30267,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50553,
      "e": 48337,
      "ty": 5,
      "x": 918,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50553,
      "e": 48337,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50553,
      "e": 48337,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 50698,
      "e": 48482,
      "ty": 2,
      "x": 936,
      "y": 318
    },
    {
      "t": 50748,
      "e": 48532,
      "ty": 41,
      "x": 34311,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 50798,
      "e": 48582,
      "ty": 2,
      "x": 975,
      "y": 443
    },
    {
      "t": 50898,
      "e": 48682,
      "ty": 2,
      "x": 976,
      "y": 444
    },
    {
      "t": 50998,
      "e": 48782,
      "ty": 41,
      "x": 36685,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 51398,
      "e": 49182,
      "ty": 2,
      "x": 976,
      "y": 423
    },
    {
      "t": 51498,
      "e": 49282,
      "ty": 2,
      "x": 974,
      "y": 383
    },
    {
      "t": 51498,
      "e": 49282,
      "ty": 41,
      "x": 36210,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 51598,
      "e": 49382,
      "ty": 2,
      "x": 973,
      "y": 381
    },
    {
      "t": 51698,
      "e": 49482,
      "ty": 2,
      "x": 973,
      "y": 380
    },
    {
      "t": 51749,
      "e": 49533,
      "ty": 41,
      "x": 36210,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 51798,
      "e": 49582,
      "ty": 2,
      "x": 986,
      "y": 356
    },
    {
      "t": 51898,
      "e": 49682,
      "ty": 2,
      "x": 999,
      "y": 344
    },
    {
      "t": 51998,
      "e": 49782,
      "ty": 41,
      "x": 42143,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 52098,
      "e": 49882,
      "ty": 2,
      "x": 1007,
      "y": 333
    },
    {
      "t": 52198,
      "e": 49982,
      "ty": 2,
      "x": 1019,
      "y": 318
    },
    {
      "t": 52248,
      "e": 50032,
      "ty": 41,
      "x": 46890,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 52398,
      "e": 50182,
      "ty": 2,
      "x": 1019,
      "y": 320
    },
    {
      "t": 52498,
      "e": 50282,
      "ty": 2,
      "x": 947,
      "y": 391
    },
    {
      "t": 52499,
      "e": 50283,
      "ty": 41,
      "x": 29802,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 52598,
      "e": 50382,
      "ty": 2,
      "x": 874,
      "y": 426
    },
    {
      "t": 52698,
      "e": 50482,
      "ty": 2,
      "x": 858,
      "y": 385
    },
    {
      "t": 52749,
      "e": 50483,
      "ty": 41,
      "x": 40476,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 52798,
      "e": 50532,
      "ty": 2,
      "x": 856,
      "y": 370
    },
    {
      "t": 52899,
      "e": 50633,
      "ty": 2,
      "x": 856,
      "y": 371
    },
    {
      "t": 52999,
      "e": 50733,
      "ty": 2,
      "x": 856,
      "y": 380
    },
    {
      "t": 52999,
      "e": 50733,
      "ty": 41,
      "x": 27619,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 53098,
      "e": 50832,
      "ty": 2,
      "x": 856,
      "y": 386
    },
    {
      "t": 53198,
      "e": 50932,
      "ty": 2,
      "x": 857,
      "y": 386
    },
    {
      "t": 53248,
      "e": 50982,
      "ty": 41,
      "x": 28418,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 53312,
      "e": 51046,
      "ty": 3,
      "x": 857,
      "y": 386,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 53312,
      "e": 51046,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 53423,
      "e": 51157,
      "ty": 4,
      "x": 28418,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 53424,
      "e": 51158,
      "ty": 5,
      "x": 857,
      "y": 386,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 53425,
      "e": 51159,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53425,
      "e": 51159,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 53598,
      "e": 51332,
      "ty": 2,
      "x": 859,
      "y": 388
    },
    {
      "t": 53698,
      "e": 51432,
      "ty": 2,
      "x": 976,
      "y": 568
    },
    {
      "t": 53748,
      "e": 51482,
      "ty": 41,
      "x": 50290,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 53798,
      "e": 51532,
      "ty": 2,
      "x": 1042,
      "y": 676
    },
    {
      "t": 53898,
      "e": 51632,
      "ty": 2,
      "x": 1044,
      "y": 679
    },
    {
      "t": 53999,
      "e": 51733,
      "ty": 41,
      "x": 55864,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 54298,
      "e": 52032,
      "ty": 2,
      "x": 1045,
      "y": 679
    },
    {
      "t": 54398,
      "e": 52132,
      "ty": 2,
      "x": 1047,
      "y": 664
    },
    {
      "t": 54498,
      "e": 52232,
      "ty": 2,
      "x": 1085,
      "y": 615
    },
    {
      "t": 54499,
      "e": 52233,
      "ty": 41,
      "x": 62553,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 54598,
      "e": 52332,
      "ty": 2,
      "x": 1086,
      "y": 613
    },
    {
      "t": 54748,
      "e": 52482,
      "ty": 41,
      "x": 62790,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 54999,
      "e": 52733,
      "ty": 2,
      "x": 1106,
      "y": 607
    },
    {
      "t": 54999,
      "e": 52733,
      "ty": 41,
      "x": 37812,
      "y": 36448,
      "ta": "html > body"
    },
    {
      "t": 55099,
      "e": 52833,
      "ty": 2,
      "x": 1200,
      "y": 592
    },
    {
      "t": 55198,
      "e": 52932,
      "ty": 2,
      "x": 1204,
      "y": 627
    },
    {
      "t": 55249,
      "e": 52983,
      "ty": 41,
      "x": 40498,
      "y": 39795,
      "ta": "html > body"
    },
    {
      "t": 55299,
      "e": 53033,
      "ty": 2,
      "x": 1131,
      "y": 733
    },
    {
      "t": 55399,
      "e": 53133,
      "ty": 2,
      "x": 1117,
      "y": 759
    },
    {
      "t": 55498,
      "e": 53232,
      "ty": 2,
      "x": 1069,
      "y": 736
    },
    {
      "t": 55498,
      "e": 53232,
      "ty": 41,
      "x": 58756,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 55598,
      "e": 53332,
      "ty": 2,
      "x": 1048,
      "y": 723
    },
    {
      "t": 55748,
      "e": 53482,
      "ty": 41,
      "x": 53772,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 56599,
      "e": 54333,
      "ty": 2,
      "x": 1001,
      "y": 807
    },
    {
      "t": 56698,
      "e": 54432,
      "ty": 2,
      "x": 979,
      "y": 826
    },
    {
      "t": 56748,
      "e": 54482,
      "ty": 41,
      "x": 32888,
      "y": 53205,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 56799,
      "e": 54533,
      "ty": 2,
      "x": 929,
      "y": 808
    },
    {
      "t": 56898,
      "e": 54632,
      "ty": 2,
      "x": 876,
      "y": 807
    },
    {
      "t": 56998,
      "e": 54732,
      "ty": 2,
      "x": 873,
      "y": 805
    },
    {
      "t": 56998,
      "e": 54732,
      "ty": 41,
      "x": 12240,
      "y": 52084,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 57099,
      "e": 54833,
      "ty": 2,
      "x": 872,
      "y": 788
    },
    {
      "t": 57198,
      "e": 54932,
      "ty": 2,
      "x": 872,
      "y": 787
    },
    {
      "t": 57249,
      "e": 54983,
      "ty": 41,
      "x": 35635,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 57498,
      "e": 55232,
      "ty": 2,
      "x": 882,
      "y": 770
    },
    {
      "t": 57499,
      "e": 55233,
      "ty": 41,
      "x": 35755,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 57598,
      "e": 55332,
      "ty": 2,
      "x": 896,
      "y": 748
    },
    {
      "t": 57699,
      "e": 55433,
      "ty": 2,
      "x": 904,
      "y": 727
    },
    {
      "t": 57750,
      "e": 55434,
      "ty": 41,
      "x": 20072,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 57798,
      "e": 55482,
      "ty": 2,
      "x": 907,
      "y": 704
    },
    {
      "t": 57898,
      "e": 55582,
      "ty": 2,
      "x": 910,
      "y": 690
    },
    {
      "t": 57998,
      "e": 55682,
      "ty": 2,
      "x": 910,
      "y": 683
    },
    {
      "t": 57999,
      "e": 55683,
      "ty": 41,
      "x": 22231,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 58098,
      "e": 55782,
      "ty": 2,
      "x": 910,
      "y": 679
    },
    {
      "t": 58198,
      "e": 55882,
      "ty": 2,
      "x": 910,
      "y": 678
    },
    {
      "t": 58248,
      "e": 55932,
      "ty": 41,
      "x": 22231,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 58299,
      "e": 55983,
      "ty": 2,
      "x": 911,
      "y": 690
    },
    {
      "t": 58399,
      "e": 56083,
      "ty": 2,
      "x": 918,
      "y": 705
    },
    {
      "t": 58499,
      "e": 56183,
      "ty": 41,
      "x": 40297,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59398,
      "e": 57082,
      "ty": 2,
      "x": 918,
      "y": 701
    },
    {
      "t": 59498,
      "e": 57182,
      "ty": 2,
      "x": 918,
      "y": 693
    },
    {
      "t": 59498,
      "e": 57182,
      "ty": 41,
      "x": 22920,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59599,
      "e": 57283,
      "ty": 2,
      "x": 918,
      "y": 692
    },
    {
      "t": 59699,
      "e": 57383,
      "ty": 2,
      "x": 919,
      "y": 690
    },
    {
      "t": 59749,
      "e": 57433,
      "ty": 41,
      "x": 23157,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 60598,
      "e": 58282,
      "ty": 2,
      "x": 925,
      "y": 657
    },
    {
      "t": 60699,
      "e": 58383,
      "ty": 2,
      "x": 925,
      "y": 648
    },
    {
      "t": 60749,
      "e": 58433,
      "ty": 41,
      "x": 26351,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60798,
      "e": 58482,
      "ty": 2,
      "x": 926,
      "y": 647
    },
    {
      "t": 60816,
      "e": 58500,
      "ty": 3,
      "x": 926,
      "y": 647,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60816,
      "e": 58500,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60912,
      "e": 58596,
      "ty": 4,
      "x": 26351,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60912,
      "e": 58596,
      "ty": 5,
      "x": 926,
      "y": 647,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60912,
      "e": 58596,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60913,
      "e": 58597,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 61398,
      "e": 59082,
      "ty": 2,
      "x": 941,
      "y": 657
    },
    {
      "t": 61498,
      "e": 59182,
      "ty": 2,
      "x": 968,
      "y": 690
    },
    {
      "t": 61498,
      "e": 59182,
      "ty": 41,
      "x": 34786,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 61599,
      "e": 59283,
      "ty": 2,
      "x": 997,
      "y": 774
    },
    {
      "t": 61699,
      "e": 59383,
      "ty": 2,
      "x": 995,
      "y": 872
    },
    {
      "t": 61748,
      "e": 59432,
      "ty": 41,
      "x": 38109,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61799,
      "e": 59483,
      "ty": 2,
      "x": 972,
      "y": 896
    },
    {
      "t": 61899,
      "e": 59583,
      "ty": 2,
      "x": 938,
      "y": 915
    },
    {
      "t": 61998,
      "e": 59682,
      "ty": 2,
      "x": 909,
      "y": 914
    },
    {
      "t": 61999,
      "e": 59683,
      "ty": 41,
      "x": 20784,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62098,
      "e": 59782,
      "ty": 2,
      "x": 870,
      "y": 895
    },
    {
      "t": 62199,
      "e": 59883,
      "ty": 2,
      "x": 870,
      "y": 871
    },
    {
      "t": 62248,
      "e": 59932,
      "ty": 41,
      "x": 12240,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 62298,
      "e": 59982,
      "ty": 2,
      "x": 874,
      "y": 865
    },
    {
      "t": 62499,
      "e": 60183,
      "ty": 2,
      "x": 882,
      "y": 892
    },
    {
      "t": 62499,
      "e": 60183,
      "ty": 41,
      "x": 14376,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 62598,
      "e": 60282,
      "ty": 2,
      "x": 883,
      "y": 906
    },
    {
      "t": 62699,
      "e": 60383,
      "ty": 2,
      "x": 883,
      "y": 911
    },
    {
      "t": 62749,
      "e": 60433,
      "ty": 41,
      "x": 49811,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62815,
      "e": 60499,
      "ty": 3,
      "x": 883,
      "y": 911,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62816,
      "e": 60500,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62896,
      "e": 60580,
      "ty": 4,
      "x": 49811,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62896,
      "e": 60580,
      "ty": 5,
      "x": 883,
      "y": 911,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62896,
      "e": 60580,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62897,
      "e": 60581,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 62999,
      "e": 60683,
      "ty": 2,
      "x": 893,
      "y": 927
    },
    {
      "t": 62999,
      "e": 60683,
      "ty": 41,
      "x": 16987,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 63045,
      "e": 60684,
      "ty": 6,
      "x": 916,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63099,
      "e": 60738,
      "ty": 2,
      "x": 926,
      "y": 974
    },
    {
      "t": 63199,
      "e": 60838,
      "ty": 2,
      "x": 927,
      "y": 975
    },
    {
      "t": 63232,
      "e": 60871,
      "ty": 3,
      "x": 927,
      "y": 975,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63232,
      "e": 60871,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63233,
      "e": 60872,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63249,
      "e": 60888,
      "ty": 41,
      "x": 50290,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63296,
      "e": 60935,
      "ty": 4,
      "x": 50290,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63296,
      "e": 60935,
      "ty": 5,
      "x": 927,
      "y": 975,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63298,
      "e": 60937,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63298,
      "e": 60937,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63300,
      "e": 60939,
      "ty": 38,
      "x": 11,
      "y": 0
    },
    {
      "t": 64620,
      "e": 62259,
      "ty": 38,
      "x": 12,
      "y": 0
    },
    {
      "t": 65230,
      "e": 62869,
      "ty": 6,
      "x": 930,
      "y": 977,
      "ta": "#start"
    },
    {
      "t": 65247,
      "e": 62886,
      "ty": 41,
      "x": 11741,
      "y": 3282,
      "ta": "#start"
    },
    {
      "t": 65297,
      "e": 62936,
      "ty": 2,
      "x": 938,
      "y": 988
    },
    {
      "t": 65397,
      "e": 63036,
      "ty": 2,
      "x": 947,
      "y": 993
    },
    {
      "t": 65498,
      "e": 63137,
      "ty": 41,
      "x": 20479,
      "y": 30267,
      "ta": "#start"
    },
    {
      "t": 67097,
      "e": 64736,
      "ty": 2,
      "x": 958,
      "y": 996
    },
    {
      "t": 67197,
      "e": 64836,
      "ty": 2,
      "x": 992,
      "y": 1009
    },
    {
      "t": 67247,
      "e": 64886,
      "ty": 41,
      "x": 45055,
      "y": 61107,
      "ta": "#start"
    },
    {
      "t": 67497,
      "e": 65136,
      "ty": 2,
      "x": 990,
      "y": 1008
    },
    {
      "t": 67497,
      "e": 65136,
      "ty": 41,
      "x": 43963,
      "y": 59180,
      "ta": "#start"
    },
    {
      "t": 67597,
      "e": 65236,
      "ty": 2,
      "x": 986,
      "y": 1007
    },
    {
      "t": 67697,
      "e": 65336,
      "ty": 2,
      "x": 977,
      "y": 1002
    },
    {
      "t": 67747,
      "e": 65386,
      "ty": 41,
      "x": 36317,
      "y": 45687,
      "ta": "#start"
    },
    {
      "t": 67797,
      "e": 65436,
      "ty": 2,
      "x": 975,
      "y": 1001
    },
    {
      "t": 67898,
      "e": 65537,
      "ty": 2,
      "x": 971,
      "y": 999
    },
    {
      "t": 67997,
      "e": 65636,
      "ty": 2,
      "x": 968,
      "y": 998
    },
    {
      "t": 67997,
      "e": 65636,
      "ty": 41,
      "x": 31948,
      "y": 39905,
      "ta": "#start"
    },
    {
      "t": 68097,
      "e": 65736,
      "ty": 2,
      "x": 966,
      "y": 992
    },
    {
      "t": 68197,
      "e": 65836,
      "ty": 2,
      "x": 966,
      "y": 990
    },
    {
      "t": 68248,
      "e": 65887,
      "ty": 41,
      "x": 30856,
      "y": 24485,
      "ta": "#start"
    },
    {
      "t": 68297,
      "e": 65936,
      "ty": 2,
      "x": 966,
      "y": 989
    },
    {
      "t": 68397,
      "e": 66036,
      "ty": 2,
      "x": 966,
      "y": 984
    },
    {
      "t": 68497,
      "e": 66136,
      "ty": 2,
      "x": 966,
      "y": 982
    },
    {
      "t": 68497,
      "e": 66136,
      "ty": 41,
      "x": 30856,
      "y": 9065,
      "ta": "#start"
    },
    {
      "t": 68542,
      "e": 66181,
      "ty": 3,
      "x": 966,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 68543,
      "e": 66182,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 68597,
      "e": 66236,
      "ty": 2,
      "x": 966,
      "y": 981
    },
    {
      "t": 68646,
      "e": 66285,
      "ty": 4,
      "x": 30856,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 68647,
      "e": 66286,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 68647,
      "e": 66286,
      "ty": 5,
      "x": 966,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 68647,
      "e": 66286,
      "ty": 38,
      "x": 13,
      "y": 0
    },
    {
      "t": 68747,
      "e": 66386,
      "ty": 41,
      "x": 32991,
      "y": 59206,
      "ta": "html > body"
    },
    {
      "t": 69668,
      "e": 67307,
      "ty": 38,
      "x": 14,
      "y": 0
    },
    {
      "t": 70278,
      "e": 67917,
      "ty": 2,
      "x": 1001,
      "y": 959
    },
    {
      "t": 70278,
      "e": 67917,
      "ty": 41,
      "x": 34881,
      "y": 32884,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 70278,
      "e": 67917,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70757,
      "e": 68396,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":6}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":8}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":7}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":9}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2307},\"parentNode\":{\"id\":2305}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2305}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2305}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2305}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2305}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2344},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2346},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2348},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2350},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2352},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2354},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2356},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2358},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2360},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2362},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2364},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2366},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2368},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2370},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2372},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2374},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2376},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2378},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2380},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2382},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2384},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2386},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2388},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2343}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2390},\"parentNode\":{\"id\":2343}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2344}},{\"nodeType\":1,\"id\":2393,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2392},\"parentNode\":{\"id\":2344}},{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2345}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2394},\"parentNode\":{\"id\":2345}},{\"nodeType\":1,\"id\":2396,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2346}},{\"nodeType\":1,\"id\":2397,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2396},\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2349}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2351}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2353}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2355}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2357}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2359}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2361}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2363}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2365}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2367}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2369}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2371}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2373}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2375}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2377}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2379}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2381}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2383}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2385}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2387}},{\"nodeType\":3,\"id\":2418,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2389}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2391}},{\"nodeType\":3,\"id\":2420,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2393}},{\"nodeType\":3,\"id\":2421,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2395}},{\"nodeType\":3,\"id\":2422,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2397}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2347}},{\"nodeType\":3,\"id\":2424,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2446},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2460},\"parentNode\":{\"id\":2436}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2462},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2464,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2438}},{\"nodeType\":1,\"id\":2465,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2464},\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"0\",\"parentNode\":{\"id\":2441}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"1\",\"parentNode\":{\"id\":2443}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"2\",\"parentNode\":{\"id\":2445}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"3\",\"parentNode\":{\"id\":2447}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"4\",\"parentNode\":{\"id\":2449}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"5\",\"parentNode\":{\"id\":2451}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"6\",\"parentNode\":{\"id\":2453}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"7\",\"parentNode\":{\"id\":2455}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"8\",\"parentNode\":{\"id\":2457}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"9\",\"parentNode\":{\"id\":2459}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"10\",\"parentNode\":{\"id\":2461}},{\"nodeType\":3,\"id\":2477,\"textContent\":\"11\",\"parentNode\":{\"id\":2463}},{\"nodeType\":3,\"id\":2478,\"textContent\":\"12\",\"parentNode\":{\"id\":2465}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2439}},{\"nodeType\":3,\"id\":2480,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2487},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2488},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2489},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2490},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2491},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2488}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2489}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2490}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2491}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2492}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2551},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2553},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2557},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2559},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2567},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2569},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2571},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2573},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2575},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2577},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2580,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2579},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2581},\"parentNode\":{\"id\":2546}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"A \",\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"B \",\"parentNode\":{\"id\":2550}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"C \",\"parentNode\":{\"id\":2552}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"D \",\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"E \",\"parentNode\":{\"id\":2556}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"F \",\"parentNode\":{\"id\":2558}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"G \",\"parentNode\":{\"id\":2560}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"H \",\"parentNode\":{\"id\":2562}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"I \",\"parentNode\":{\"id\":2564}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"J \",\"parentNode\":{\"id\":2566}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"K \",\"parentNode\":{\"id\":2568}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"L \",\"parentNode\":{\"id\":2570}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"M \",\"parentNode\":{\"id\":2572}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"N \",\"parentNode\":{\"id\":2574}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"O \",\"parentNode\":{\"id\":2576}},{\"nodeType\":3,\"id\":2598,\"textContent\":\"P \",\"parentNode\":{\"id\":2578}},{\"nodeType\":3,\"id\":2599,\"textContent\":\"Z \",\"parentNode\":{\"id\":2580}},{\"nodeType\":3,\"id\":2600,\"textContent\":\"X \",\"parentNode\":{\"id\":2582}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2316},{\"id\":2321},{\"id\":2322},{\"id\":2348},{\"id\":2349},{\"id\":2398},{\"id\":2323},{\"id\":2350},{\"id\":2351},{\"id\":2399},{\"id\":2324},{\"id\":2352},{\"id\":2353},{\"id\":2400},{\"id\":2325},{\"id\":2354},{\"id\":2355},{\"id\":2401},{\"id\":2326},{\"id\":2356},{\"id\":2357},{\"id\":2402},{\"id\":2327},{\"id\":2358},{\"id\":2359},{\"id\":2403},{\"id\":2328},{\"id\":2360},{\"id\":2361},{\"id\":2404},{\"id\":2329},{\"id\":2362},{\"id\":2363},{\"id\":2405},{\"id\":2330},{\"id\":2364},{\"id\":2365},{\"id\":2406},{\"id\":2331},{\"id\":2366},{\"id\":2367},{\"id\":2407},{\"id\":2332},{\"id\":2368},{\"id\":2369},{\"id\":2408},{\"id\":2333},{\"id\":2370},{\"id\":2371},{\"id\":2409},{\"id\":2334},{\"id\":2372},{\"id\":2373},{\"id\":2410},{\"id\":2335},{\"id\":2374},{\"id\":2375},{\"id\":2411},{\"id\":2336},{\"id\":2376},{\"id\":2377},{\"id\":2412},{\"id\":2337},{\"id\":2378},{\"id\":2379},{\"id\":2413},{\"id\":2338},{\"id\":2380},{\"id\":2381},{\"id\":2414},{\"id\":2339},{\"id\":2382},{\"id\":2383},{\"id\":2415},{\"id\":2340},{\"id\":2384},{\"id\":2385},{\"id\":2416},{\"id\":2341},{\"id\":2386},{\"id\":2387},{\"id\":2417},{\"id\":2342},{\"id\":2388},{\"id\":2389},{\"id\":2418},{\"id\":2343},{\"id\":2390},{\"id\":2391},{\"id\":2419},{\"id\":2344},{\"id\":2392},{\"id\":2393},{\"id\":2420},{\"id\":2345},{\"id\":2394},{\"id\":2395},{\"id\":2421},{\"id\":2346},{\"id\":2396},{\"id\":2397},{\"id\":2422},{\"id\":2347},{\"id\":2423},{\"id\":2424},{\"id\":2317},{\"id\":2425},{\"id\":2426},{\"id\":2440},{\"id\":2441},{\"id\":2466},{\"id\":2427},{\"id\":2442},{\"id\":2443},{\"id\":2467},{\"id\":2428},{\"id\":2444},{\"id\":2445},{\"id\":2468},{\"id\":2429},{\"id\":2446},{\"id\":2447},{\"id\":2469},{\"id\":2430},{\"id\":2448},{\"id\":2449},{\"id\":2470},{\"id\":2431},{\"id\":2450},{\"id\":2451},{\"id\":2471},{\"id\":2432},{\"id\":2452},{\"id\":2453},{\"id\":2472},{\"id\":2433},{\"id\":2454},{\"id\":2455},{\"id\":2473},{\"id\":2434},{\"id\":2456},{\"id\":2457},{\"id\":2474},{\"id\":2435},{\"id\":2458},{\"id\":2459},{\"id\":2475},{\"id\":2436},{\"id\":2460},{\"id\":2461},{\"id\":2476},{\"id\":2437},{\"id\":2462},{\"id\":2463},{\"id\":2477},{\"id\":2438},{\"id\":2464},{\"id\":2465},{\"id\":2478},{\"id\":2439},{\"id\":2479},{\"id\":2480},{\"id\":2318},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2488},{\"id\":2500},{\"id\":2489},{\"id\":2501},{\"id\":2490},{\"id\":2502},{\"id\":2491},{\"id\":2503},{\"id\":2492},{\"id\":2504},{\"id\":2319},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2320},{\"id\":2529},{\"id\":2547},{\"id\":2548},{\"id\":2583},{\"id\":2530},{\"id\":2549},{\"id\":2550},{\"id\":2584},{\"id\":2531},{\"id\":2551},{\"id\":2552},{\"id\":2585},{\"id\":2532},{\"id\":2553},{\"id\":2554},{\"id\":2586},{\"id\":2533},{\"id\":2555},{\"id\":2556},{\"id\":2587},{\"id\":2534},{\"id\":2557},{\"id\":2558},{\"id\":2588},{\"id\":2535},{\"id\":2559},{\"id\":2560},{\"id\":2589},{\"id\":2536},{\"id\":2561},{\"id\":2562},{\"id\":2590},{\"id\":2537},{\"id\":2563},{\"id\":2564},{\"id\":2591},{\"id\":2538},{\"id\":2565},{\"id\":2566},{\"id\":2592},{\"id\":2539},{\"id\":2567},{\"id\":2568},{\"id\":2593},{\"id\":2540},{\"id\":2569},{\"id\":2570},{\"id\":2594},{\"id\":2541},{\"id\":2571},{\"id\":2572},{\"id\":2595},{\"id\":2542},{\"id\":2573},{\"id\":2574},{\"id\":2596},{\"id\":2543},{\"id\":2575},{\"id\":2576},{\"id\":2597},{\"id\":2544},{\"id\":2577},{\"id\":2578},{\"id\":2598},{\"id\":2545},{\"id\":2579},{\"id\":2580},{\"id\":2599},{\"id\":2546},{\"id\":2581},{\"id\":2582},{\"id\":2600},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"nodeType\":3,\"id\":2601,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2313},{\"id\":2314},{\"nodeType\":3,\"id\":2602,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2315}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2603,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":2604,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2604},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2604}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2604}},{\"nodeType\":3,\"id\":2609,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2605}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":3,\"id\":2613,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2606}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2603},{\"id\":2604},{\"id\":2607},{\"id\":2609},{\"id\":2608},{\"id\":2605},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2606},{\"id\":2613}],[],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2614,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2623},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2616}},{\"nodeType\":3,\"id\":2626,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":3,\"id\":2630,\"textContent\":\"English\",\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2640,\"textContent\":\"*\",\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2643},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2617}},{\"nodeType\":3,\"id\":2649,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":3,\"id\":2653,\"textContent\":\"First\",\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2672,\"textContent\":\"*\",\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2675},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2618}},{\"nodeType\":3,\"id\":2681,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":3,\"id\":2685,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"*\",\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2706},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2709,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2705}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":3,\"id\":2713,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2707}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2720,\"textContent\":\"*\",\"parentNode\":{\"id\":2710}}],[],[]]}"
    },
    {
      "sequence": 11,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2614},{\"id\":2615},{\"id\":2616},{\"id\":2621},{\"id\":2626},{\"id\":2627},{\"id\":2640},{\"id\":2622},{\"id\":2628},{\"id\":2629},{\"id\":2630},{\"id\":2623},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2624},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2625},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2617},{\"id\":2641},{\"id\":2649},{\"id\":2650},{\"id\":2672},{\"id\":2642},{\"id\":2651},{\"id\":2652},{\"id\":2653},{\"id\":2643},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2644},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2645},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2646},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2647},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2648},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2618},{\"id\":2673},{\"id\":2681},{\"id\":2682},{\"id\":2704},{\"id\":2674},{\"id\":2683},{\"id\":2684},{\"id\":2685},{\"id\":2675},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2676},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2677},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2678},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2679},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2680},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2619},{\"id\":2705},{\"id\":2709},{\"id\":2710},{\"id\":2720},{\"id\":2706},{\"id\":2711},{\"id\":2712},{\"id\":2713},{\"id\":2707},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2708},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2620}],[],[],[]]}"
    },
    {
      "sequence": 12,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":2723,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2736,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" \",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2748,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2738}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" \",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2753,\"textContent\":\" \",\"parentNode\":{\"id\":2742}},{\"nodeType\":1,\"id\":2754,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2755,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2754},\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2754}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" \",\"parentNode\":{\"id\":2744}},{\"nodeType\":1,\"id\":2758,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2759,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2758},\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2758}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2748}},{\"nodeType\":3,\"id\":2765,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2750}},{\"nodeType\":3,\"id\":2766,\"textContent\":\" \",\"parentNode\":{\"id\":2728}},{\"nodeType\":1,\"id\":2767,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2766},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2768,\"textContent\":\" \",\"previousSibling\":{\"id\":2767},\"parentNode\":{\"id\":2728}},{\"nodeType\":3,\"id\":2769,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2767}}],[],[]]}"
    },
    {
      "sequence": 13,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2721},{\"id\":2723},{\"id\":2724},{\"id\":2730},{\"id\":2731},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2735},{\"id\":2732},{\"id\":2725},{\"id\":2726},{\"id\":2737},{\"id\":2738},{\"id\":2740},{\"id\":2741},{\"id\":2752},{\"id\":2742},{\"id\":2753},{\"id\":2754},{\"id\":2756},{\"id\":2755},{\"id\":2743},{\"id\":2744},{\"id\":2757},{\"id\":2758},{\"id\":2760},{\"id\":2759},{\"id\":2745},{\"id\":2746},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2747},{\"id\":2748},{\"id\":2764},{\"id\":2749},{\"id\":2750},{\"id\":2765},{\"id\":2751},{\"id\":2739},{\"id\":2727},{\"id\":2728},{\"id\":2766},{\"id\":2767},{\"id\":2769},{\"id\":2768},{\"id\":2729},{\"id\":2722}],[],[],[]]}"
    },
    {
      "sequence": 14,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2770,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":2771,\"textContent\":\"[ { \\\"rt\\\": 42351, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 42356, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 47621, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 91060, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11923, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"bravo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 103987, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7062, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 112395, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 18584, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 131981, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 39651, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 173062, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-5\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1027,y:917,t:1526922571926};\\\", \\\"{x:1019,y:859,t:1526922571934};\\\", \\\"{x:925,y:588,t:1526922571951};\\\", \\\"{x:806,y:323,t:1526922571966};\\\", \\\"{x:720,y:136,t:1526922571984};\\\", \\\"{x:670,y:25,t:1526922572001};\\\", \\\"{x:774,y:6,t:1526922572422};\\\", \\\"{x:789,y:24,t:1526922572434};\\\", \\\"{x:821,y:50,t:1526922572451};\\\", \\\"{x:853,y:71,t:1526922572468};\\\", \\\"{x:885,y:89,t:1526922572485};\\\", \\\"{x:918,y:103,t:1526922572501};\\\", \\\"{x:951,y:126,t:1526922572518};\\\", \\\"{x:972,y:150,t:1526922572534};\\\", \\\"{x:1000,y:195,t:1526922572550};\\\", \\\"{x:1026,y:255,t:1526922572568};\\\", \\\"{x:1053,y:319,t:1526922572585};\\\", \\\"{x:1073,y:368,t:1526922572601};\\\", \\\"{x:1087,y:389,t:1526922572618};\\\", \\\"{x:1101,y:403,t:1526922572635};\\\", \\\"{x:1116,y:413,t:1526922572651};\\\", \\\"{x:1130,y:420,t:1526922572668};\\\", \\\"{x:1152,y:425,t:1526922572685};\\\", \\\"{x:1202,y:429,t:1526922572701};\\\", \\\"{x:1303,y:433,t:1526922572719};\\\", \\\"{x:1348,y:433,t:1526922572735};\\\", \\\"{x:1371,y:433,t:1526922572751};\\\", \\\"{x:1381,y:431,t:1526922572768};\\\", \\\"{x:1384,y:430,t:1526922572785};\\\", \\\"{x:1384,y:428,t:1526922572807};\\\", \\\"{x:1380,y:427,t:1526922572818};\\\", \\\"{x:1361,y:426,t:1526922572834};\\\", \\\"{x:1343,y:428,t:1526922572850};\\\", \\\"{x:1341,y:429,t:1526922572867};\\\", \\\"{x:1342,y:429,t:1526922573223};\\\", \\\"{x:1342,y:430,t:1526922573255};\\\", \\\"{x:1342,y:431,t:1526922573269};\\\", \\\"{x:1342,y:438,t:1526922573286};\\\", \\\"{x:1342,y:464,t:1526922573303};\\\", \\\"{x:1342,y:489,t:1526922573319};\\\", \\\"{x:1344,y:518,t:1526922573335};\\\", \\\"{x:1350,y:546,t:1526922573352};\\\", \\\"{x:1357,y:575,t:1526922573368};\\\", \\\"{x:1367,y:607,t:1526922573386};\\\", \\\"{x:1372,y:635,t:1526922573402};\\\", \\\"{x:1373,y:653,t:1526922573419};\\\", \\\"{x:1374,y:663,t:1526922573435};\\\", \\\"{x:1374,y:676,t:1526922573452};\\\", \\\"{x:1374,y:690,t:1526922573469};\\\", \\\"{x:1375,y:707,t:1526922573485};\\\", \\\"{x:1378,y:734,t:1526922573502};\\\", \\\"{x:1378,y:744,t:1526922573518};\\\", \\\"{x:1378,y:758,t:1526922573535};\\\", \\\"{x:1377,y:773,t:1526922573552};\\\", \\\"{x:1373,y:786,t:1526922573569};\\\", \\\"{x:1368,y:800,t:1526922573584};\\\", \\\"{x:1362,y:816,t:1526922573602};\\\", \\\"{x:1356,y:829,t:1526922573619};\\\", \\\"{x:1349,y:842,t:1526922573635};\\\", \\\"{x:1340,y:853,t:1526922573651};\\\", \\\"{x:1333,y:864,t:1526922573669};\\\", \\\"{x:1326,y:875,t:1526922573685};\\\", \\\"{x:1318,y:889,t:1526922573702};\\\", \\\"{x:1315,y:893,t:1526922573719};\\\", \\\"{x:1312,y:897,t:1526922573735};\\\", \\\"{x:1310,y:901,t:1526922573752};\\\", \\\"{x:1309,y:903,t:1526922573769};\\\", \\\"{x:1309,y:906,t:1526922573785};\\\", \\\"{x:1308,y:907,t:1526922573830};\\\", \\\"{x:1307,y:908,t:1526922573838};\\\", \\\"{x:1306,y:910,t:1526922573853};\\\", \\\"{x:1302,y:915,t:1526922573869};\\\", \\\"{x:1292,y:925,t:1526922573886};\\\", \\\"{x:1286,y:931,t:1526922573902};\\\", \\\"{x:1279,y:936,t:1526922573919};\\\", \\\"{x:1279,y:937,t:1526922573936};\\\", \\\"{x:1279,y:936,t:1526922574047};\\\", \\\"{x:1279,y:935,t:1526922574055};\\\", \\\"{x:1279,y:933,t:1526922574069};\\\", \\\"{x:1284,y:924,t:1526922574087};\\\", \\\"{x:1286,y:919,t:1526922574103};\\\", \\\"{x:1287,y:914,t:1526922574120};\\\", \\\"{x:1287,y:909,t:1526922574136};\\\", \\\"{x:1287,y:906,t:1526922574152};\\\", \\\"{x:1287,y:905,t:1526922574169};\\\", \\\"{x:1287,y:903,t:1526922574186};\\\", \\\"{x:1287,y:902,t:1526922574278};\\\", \\\"{x:1287,y:900,t:1526922574294};\\\", \\\"{x:1287,y:897,t:1526922574310};\\\", \\\"{x:1285,y:895,t:1526922574319};\\\", \\\"{x:1285,y:891,t:1526922574335};\\\", \\\"{x:1284,y:888,t:1526922574353};\\\", \\\"{x:1284,y:884,t:1526922574369};\\\", \\\"{x:1284,y:878,t:1526922574386};\\\", \\\"{x:1283,y:873,t:1526922574403};\\\", \\\"{x:1281,y:866,t:1526922574419};\\\", \\\"{x:1281,y:861,t:1526922574436};\\\", \\\"{x:1281,y:858,t:1526922574452};\\\", \\\"{x:1280,y:855,t:1526922574468};\\\", \\\"{x:1278,y:851,t:1526922574486};\\\", \\\"{x:1278,y:849,t:1526922574502};\\\", \\\"{x:1277,y:848,t:1526922574534};\\\", \\\"{x:1277,y:846,t:1526922574549};\\\", \\\"{x:1277,y:845,t:1526922574566};\\\", \\\"{x:1277,y:844,t:1526922574574};\\\", \\\"{x:1277,y:843,t:1526922574585};\\\", \\\"{x:1277,y:841,t:1526922574602};\\\", \\\"{x:1277,y:840,t:1526922574619};\\\", \\\"{x:1276,y:838,t:1526922574635};\\\", \\\"{x:1276,y:836,t:1526922574653};\\\", \\\"{x:1276,y:834,t:1526922574669};\\\", \\\"{x:1275,y:833,t:1526922574686};\\\", \\\"{x:1275,y:832,t:1526922574703};\\\", \\\"{x:1275,y:830,t:1526922574719};\\\", \\\"{x:1275,y:829,t:1526922574736};\\\", \\\"{x:1275,y:826,t:1526922574753};\\\", \\\"{x:1275,y:823,t:1526922574769};\\\", \\\"{x:1275,y:818,t:1526922574786};\\\", \\\"{x:1274,y:815,t:1526922574803};\\\", \\\"{x:1274,y:809,t:1526922574819};\\\", \\\"{x:1273,y:805,t:1526922574836};\\\", \\\"{x:1273,y:802,t:1526922574853};\\\", \\\"{x:1273,y:801,t:1526922574869};\\\", \\\"{x:1273,y:798,t:1526922574886};\\\", \\\"{x:1273,y:797,t:1526922574903};\\\", \\\"{x:1273,y:796,t:1526922574920};\\\", \\\"{x:1273,y:795,t:1526922574936};\\\", \\\"{x:1273,y:793,t:1526922574952};\\\", \\\"{x:1273,y:792,t:1526922574969};\\\", \\\"{x:1273,y:791,t:1526922574986};\\\", \\\"{x:1273,y:790,t:1526922575003};\\\", \\\"{x:1273,y:788,t:1526922575020};\\\", \\\"{x:1273,y:785,t:1526922575035};\\\", \\\"{x:1273,y:781,t:1526922575053};\\\", \\\"{x:1273,y:778,t:1526922575069};\\\", \\\"{x:1273,y:776,t:1526922575085};\\\", \\\"{x:1273,y:775,t:1526922575110};\\\", \\\"{x:1273,y:774,t:1526922575120};\\\", \\\"{x:1273,y:773,t:1526922575136};\\\", \\\"{x:1273,y:772,t:1526922575153};\\\", \\\"{x:1273,y:770,t:1526922575170};\\\", \\\"{x:1273,y:769,t:1526922575190};\\\", \\\"{x:1273,y:768,t:1526922575202};\\\", \\\"{x:1273,y:767,t:1526922575220};\\\", \\\"{x:1273,y:766,t:1526922575236};\\\", \\\"{x:1273,y:765,t:1526922575382};\\\", \\\"{x:1274,y:765,t:1526922575406};\\\", \\\"{x:1275,y:766,t:1526922575420};\\\", \\\"{x:1276,y:768,t:1526922575437};\\\", \\\"{x:1277,y:771,t:1526922575453};\\\", \\\"{x:1277,y:772,t:1526922575469};\\\", \\\"{x:1277,y:773,t:1526922575486};\\\", \\\"{x:1278,y:775,t:1526922575509};\\\", \\\"{x:1279,y:777,t:1526922575525};\\\", \\\"{x:1280,y:779,t:1526922575537};\\\", \\\"{x:1280,y:783,t:1526922575553};\\\", \\\"{x:1281,y:788,t:1526922575570};\\\", \\\"{x:1282,y:797,t:1526922575587};\\\", \\\"{x:1282,y:804,t:1526922575603};\\\", \\\"{x:1283,y:813,t:1526922575620};\\\", \\\"{x:1284,y:818,t:1526922575637};\\\", \\\"{x:1284,y:825,t:1526922575653};\\\", \\\"{x:1284,y:831,t:1526922575670};\\\", \\\"{x:1284,y:835,t:1526922575687};\\\", \\\"{x:1284,y:840,t:1526922575703};\\\", \\\"{x:1284,y:846,t:1526922575720};\\\", \\\"{x:1284,y:848,t:1526922575737};\\\", \\\"{x:1284,y:853,t:1526922575754};\\\", \\\"{x:1285,y:857,t:1526922575770};\\\", \\\"{x:1285,y:861,t:1526922575787};\\\", \\\"{x:1286,y:862,t:1526922575804};\\\", \\\"{x:1288,y:865,t:1526922575820};\\\", \\\"{x:1288,y:867,t:1526922575837};\\\", \\\"{x:1290,y:868,t:1526922575854};\\\", \\\"{x:1291,y:869,t:1526922575870};\\\", \\\"{x:1291,y:871,t:1526922575887};\\\", \\\"{x:1292,y:874,t:1526922575904};\\\", \\\"{x:1292,y:880,t:1526922575920};\\\", \\\"{x:1292,y:886,t:1526922575937};\\\", \\\"{x:1292,y:892,t:1526922575954};\\\", \\\"{x:1292,y:896,t:1526922575970};\\\", \\\"{x:1292,y:901,t:1526922575987};\\\", \\\"{x:1292,y:904,t:1526922576004};\\\", \\\"{x:1292,y:907,t:1526922576020};\\\", \\\"{x:1292,y:909,t:1526922576038};\\\", \\\"{x:1292,y:910,t:1526922576055};\\\", \\\"{x:1292,y:909,t:1526922580398};\\\", \\\"{x:1290,y:905,t:1526922580407};\\\", \\\"{x:1279,y:890,t:1526922580424};\\\", \\\"{x:1263,y:870,t:1526922580439};\\\", \\\"{x:1240,y:841,t:1526922580457};\\\", \\\"{x:1207,y:797,t:1526922580473};\\\", \\\"{x:1170,y:739,t:1526922580490};\\\", \\\"{x:1131,y:684,t:1526922580507};\\\", \\\"{x:1100,y:636,t:1526922580525};\\\", \\\"{x:1079,y:601,t:1526922580540};\\\", \\\"{x:1066,y:578,t:1526922580557};\\\", \\\"{x:1056,y:561,t:1526922580574};\\\", \\\"{x:1055,y:559,t:1526922580590};\\\", \\\"{x:1055,y:558,t:1526922580607};\\\", \\\"{x:1055,y:557,t:1526922580624};\\\", \\\"{x:1055,y:558,t:1526922580958};\\\", \\\"{x:1055,y:559,t:1526922580982};\\\", \\\"{x:1055,y:560,t:1526922580998};\\\", \\\"{x:1055,y:561,t:1526922581126};\\\", \\\"{x:1056,y:562,t:1526922581544};\\\", \\\"{x:1058,y:563,t:1526922581559};\\\", \\\"{x:1059,y:564,t:1526922582752};\\\", \\\"{x:1059,y:565,t:1526922582759};\\\", \\\"{x:1062,y:569,t:1526922582776};\\\", \\\"{x:1069,y:575,t:1526922582793};\\\", \\\"{x:1079,y:580,t:1526922582809};\\\", \\\"{x:1088,y:585,t:1526922582826};\\\", \\\"{x:1098,y:591,t:1526922582842};\\\", \\\"{x:1107,y:597,t:1526922582859};\\\", \\\"{x:1114,y:601,t:1526922582876};\\\", \\\"{x:1118,y:606,t:1526922582893};\\\", \\\"{x:1122,y:610,t:1526922582910};\\\", \\\"{x:1129,y:618,t:1526922582926};\\\", \\\"{x:1148,y:642,t:1526922582943};\\\", \\\"{x:1157,y:652,t:1526922582960};\\\", \\\"{x:1162,y:660,t:1526922582976};\\\", \\\"{x:1165,y:665,t:1526922582993};\\\", \\\"{x:1166,y:667,t:1526922583010};\\\", \\\"{x:1168,y:669,t:1526922583026};\\\", \\\"{x:1172,y:676,t:1526922583042};\\\", \\\"{x:1177,y:688,t:1526922583059};\\\", \\\"{x:1182,y:698,t:1526922583075};\\\", \\\"{x:1188,y:705,t:1526922583092};\\\", \\\"{x:1191,y:709,t:1526922583109};\\\", \\\"{x:1192,y:711,t:1526922583150};\\\", \\\"{x:1192,y:712,t:1526922583263};\\\", \\\"{x:1193,y:712,t:1526922583279};\\\", \\\"{x:1194,y:713,t:1526922583303};\\\", \\\"{x:1195,y:714,t:1526922583311};\\\", \\\"{x:1197,y:717,t:1526922583327};\\\", \\\"{x:1200,y:721,t:1526922583343};\\\", \\\"{x:1206,y:729,t:1526922583360};\\\", \\\"{x:1215,y:738,t:1526922583377};\\\", \\\"{x:1221,y:746,t:1526922583393};\\\", \\\"{x:1225,y:753,t:1526922583410};\\\", \\\"{x:1228,y:760,t:1526922583427};\\\", \\\"{x:1233,y:767,t:1526922583443};\\\", \\\"{x:1237,y:775,t:1526922583459};\\\", \\\"{x:1242,y:783,t:1526922583476};\\\", \\\"{x:1247,y:790,t:1526922583493};\\\", \\\"{x:1250,y:794,t:1526922583509};\\\", \\\"{x:1252,y:798,t:1526922583526};\\\", \\\"{x:1253,y:799,t:1526922583543};\\\", \\\"{x:1254,y:801,t:1526922583559};\\\", \\\"{x:1256,y:806,t:1526922583576};\\\", \\\"{x:1257,y:812,t:1526922583592};\\\", \\\"{x:1259,y:820,t:1526922583609};\\\", \\\"{x:1259,y:824,t:1526922583627};\\\", \\\"{x:1260,y:829,t:1526922583642};\\\", \\\"{x:1260,y:835,t:1526922583659};\\\", \\\"{x:1262,y:839,t:1526922583676};\\\", \\\"{x:1262,y:844,t:1526922583692};\\\", \\\"{x:1263,y:846,t:1526922583710};\\\", \\\"{x:1266,y:856,t:1526922583726};\\\", \\\"{x:1266,y:860,t:1526922583743};\\\", \\\"{x:1267,y:863,t:1526922583760};\\\", \\\"{x:1269,y:869,t:1526922583777};\\\", \\\"{x:1271,y:878,t:1526922583793};\\\", \\\"{x:1273,y:883,t:1526922583809};\\\", \\\"{x:1277,y:891,t:1526922583827};\\\", \\\"{x:1279,y:898,t:1526922583843};\\\", \\\"{x:1283,y:901,t:1526922583860};\\\", \\\"{x:1283,y:904,t:1526922583876};\\\", \\\"{x:1284,y:905,t:1526922583894};\\\", \\\"{x:1285,y:906,t:1526922583910};\\\", \\\"{x:1286,y:907,t:1526922583991};\\\", \\\"{x:1286,y:908,t:1526922584014};\\\", \\\"{x:1286,y:909,t:1526922584027};\\\", \\\"{x:1286,y:910,t:1526922584416};\\\", \\\"{x:1285,y:910,t:1526922584427};\\\", \\\"{x:1284,y:910,t:1526922584446};\\\", \\\"{x:1283,y:910,t:1526922584461};\\\", \\\"{x:1282,y:911,t:1526922584477};\\\", \\\"{x:1280,y:911,t:1526922584494};\\\", \\\"{x:1278,y:912,t:1526922584511};\\\", \\\"{x:1277,y:912,t:1526922584687};\\\", \\\"{x:1277,y:910,t:1526922584703};\\\", \\\"{x:1274,y:906,t:1526922584711};\\\", \\\"{x:1265,y:893,t:1526922584727};\\\", \\\"{x:1241,y:868,t:1526922584744};\\\", \\\"{x:1203,y:830,t:1526922584761};\\\", \\\"{x:1130,y:774,t:1526922584778};\\\", \\\"{x:1033,y:706,t:1526922584794};\\\", \\\"{x:942,y:647,t:1526922584811};\\\", \\\"{x:863,y:589,t:1526922584828};\\\", \\\"{x:780,y:538,t:1526922584844};\\\", \\\"{x:700,y:499,t:1526922584860};\\\", \\\"{x:629,y:473,t:1526922584878};\\\", \\\"{x:551,y:465,t:1526922584896};\\\", \\\"{x:514,y:464,t:1526922584912};\\\", \\\"{x:493,y:458,t:1526922584929};\\\", \\\"{x:481,y:453,t:1526922584946};\\\", \\\"{x:465,y:448,t:1526922584962};\\\", \\\"{x:451,y:446,t:1526922584980};\\\", \\\"{x:436,y:446,t:1526922584996};\\\", \\\"{x:421,y:448,t:1526922585012};\\\", \\\"{x:411,y:453,t:1526922585030};\\\", \\\"{x:395,y:461,t:1526922585046};\\\", \\\"{x:384,y:469,t:1526922585063};\\\", \\\"{x:371,y:481,t:1526922585080};\\\", \\\"{x:356,y:491,t:1526922585097};\\\", \\\"{x:339,y:504,t:1526922585113};\\\", \\\"{x:323,y:516,t:1526922585129};\\\", \\\"{x:306,y:528,t:1526922585147};\\\", \\\"{x:300,y:533,t:1526922585164};\\\", \\\"{x:296,y:535,t:1526922585179};\\\", \\\"{x:295,y:535,t:1526922585196};\\\", \\\"{x:290,y:535,t:1526922585214};\\\", \\\"{x:280,y:537,t:1526922585229};\\\", \\\"{x:251,y:537,t:1526922585246};\\\", \\\"{x:231,y:535,t:1526922585264};\\\", \\\"{x:207,y:527,t:1526922585279};\\\", \\\"{x:193,y:519,t:1526922585296};\\\", \\\"{x:182,y:511,t:1526922585313};\\\", \\\"{x:171,y:500,t:1526922585329};\\\", \\\"{x:159,y:493,t:1526922585347};\\\", \\\"{x:154,y:492,t:1526922585363};\\\", \\\"{x:152,y:491,t:1526922585379};\\\", \\\"{x:151,y:491,t:1526922585397};\\\", \\\"{x:150,y:491,t:1526922585413};\\\", \\\"{x:142,y:491,t:1526922585430};\\\", \\\"{x:140,y:491,t:1526922585446};\\\", \\\"{x:139,y:491,t:1526922585463};\\\", \\\"{x:137,y:490,t:1526922585481};\\\", \\\"{x:137,y:488,t:1526922585497};\\\", \\\"{x:137,y:484,t:1526922585514};\\\", \\\"{x:136,y:476,t:1526922585532};\\\", \\\"{x:138,y:477,t:1526922585718};\\\", \\\"{x:138,y:478,t:1526922585730};\\\", \\\"{x:141,y:482,t:1526922585746};\\\", \\\"{x:142,y:483,t:1526922585764};\\\", \\\"{x:143,y:484,t:1526922585782};\\\", \\\"{x:144,y:485,t:1526922585806};\\\", \\\"{x:145,y:485,t:1526922586038};\\\", \\\"{x:145,y:484,t:1526922586054};\\\", \\\"{x:146,y:483,t:1526922586064};\\\", \\\"{x:147,y:482,t:1526922586080};\\\", \\\"{x:147,y:481,t:1526922586098};\\\", \\\"{x:149,y:479,t:1526922586113};\\\", \\\"{x:150,y:478,t:1526922586130};\\\", \\\"{x:151,y:477,t:1526922586149};\\\", \\\"{x:151,y:476,t:1526922586182};\\\", \\\"{x:152,y:475,t:1526922586197};\\\", \\\"{x:152,y:474,t:1526922586470};\\\", \\\"{x:154,y:475,t:1526922586480};\\\", \\\"{x:169,y:492,t:1526922586498};\\\", \\\"{x:196,y:511,t:1526922586514};\\\", \\\"{x:234,y:539,t:1526922586531};\\\", \\\"{x:293,y:573,t:1526922586548};\\\", \\\"{x:367,y:612,t:1526922586565};\\\", \\\"{x:427,y:648,t:1526922586580};\\\", \\\"{x:473,y:675,t:1526922586600};\\\", \\\"{x:515,y:702,t:1526922586614};\\\", \\\"{x:532,y:713,t:1526922586630};\\\", \\\"{x:537,y:714,t:1526922586648};\\\", \\\"{x:538,y:714,t:1526922586664};\\\", \\\"{x:539,y:714,t:1526922586693};\\\", \\\"{x:539,y:713,t:1526922586726};\\\", \\\"{x:539,y:712,t:1526922586741};\\\", \\\"{x:539,y:711,t:1526922586749};\\\", \\\"{x:539,y:710,t:1526922586765};\\\", \\\"{x:539,y:708,t:1526922586782};\\\", \\\"{x:539,y:707,t:1526922586797};\\\", \\\"{x:539,y:706,t:1526922586814};\\\", \\\"{x:539,y:705,t:1526922586832};\\\", \\\"{x:539,y:704,t:1526922586848};\\\", \\\"{x:539,y:703,t:1526922586864};\\\", \\\"{x:539,y:698,t:1526922586882};\\\", \\\"{x:539,y:694,t:1526922586898};\\\", \\\"{x:538,y:688,t:1526922586914};\\\", \\\"{x:535,y:680,t:1526922586932};\\\", \\\"{x:533,y:672,t:1526922586947};\\\", \\\"{x:530,y:664,t:1526922586965};\\\", \\\"{x:528,y:659,t:1526922586982};\\\", \\\"{x:529,y:658,t:1526922587966};\\\", \\\"{x:532,y:658,t:1526922587982};\\\", \\\"{x:556,y:648,t:1526922587999};\\\", \\\"{x:565,y:643,t:1526922588016};\\\", \\\"{x:566,y:643,t:1526922588367};\\\", \\\"{x:567,y:643,t:1526922588439};\\\", \\\"{x:569,y:642,t:1526922588448};\\\", \\\"{x:569,y:641,t:1526922588465};\\\", \\\"{x:570,y:641,t:1526922588494};\\\", \\\"{x:573,y:641,t:1526922588558};\\\", \\\"{x:574,y:641,t:1526922588565};\\\", \\\"{x:575,y:641,t:1526922588582};\\\", \\\"{x:576,y:640,t:1526922588599};\\\", \\\"{x:578,y:640,t:1526922588615};\\\", \\\"{x:579,y:640,t:1526922588632};\\\" ] }, { \\\"rt\\\": 27609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 201943, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-D -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:584,y:637,t:1526922588756};\\\", \\\"{x:586,y:637,t:1526922588859};\\\", \\\"{x:586,y:636,t:1526922588882};\\\", \\\"{x:587,y:635,t:1526922588899};\\\", \\\"{x:587,y:633,t:1526922588916};\\\", \\\"{x:587,y:632,t:1526922588932};\\\", \\\"{x:588,y:628,t:1526922588949};\\\", \\\"{x:589,y:624,t:1526922588965};\\\", \\\"{x:590,y:622,t:1526922588982};\\\", \\\"{x:590,y:618,t:1526922588999};\\\", \\\"{x:590,y:616,t:1526922589016};\\\", \\\"{x:590,y:615,t:1526922589032};\\\", \\\"{x:600,y:609,t:1526922589233};\\\", \\\"{x:609,y:604,t:1526922589249};\\\", \\\"{x:620,y:599,t:1526922589267};\\\", \\\"{x:635,y:587,t:1526922589283};\\\", \\\"{x:649,y:578,t:1526922589300};\\\", \\\"{x:664,y:567,t:1526922589316};\\\", \\\"{x:679,y:552,t:1526922589334};\\\", \\\"{x:683,y:546,t:1526922589350};\\\", \\\"{x:685,y:543,t:1526922589366};\\\", \\\"{x:686,y:541,t:1526922589382};\\\", \\\"{x:687,y:537,t:1526922589400};\\\", \\\"{x:688,y:536,t:1526922589416};\\\", \\\"{x:680,y:534,t:1526922590750};\\\", \\\"{x:657,y:526,t:1526922590769};\\\", \\\"{x:653,y:516,t:1526922590784};\\\", \\\"{x:652,y:516,t:1526922591046};\\\", \\\"{x:651,y:516,t:1526922591055};\\\", \\\"{x:650,y:516,t:1526922591067};\\\", \\\"{x:648,y:516,t:1526922591094};\\\", \\\"{x:644,y:515,t:1526922591103};\\\", \\\"{x:637,y:514,t:1526922591118};\\\", \\\"{x:619,y:506,t:1526922591134};\\\", \\\"{x:607,y:501,t:1526922591150};\\\", \\\"{x:600,y:497,t:1526922591168};\\\", \\\"{x:593,y:491,t:1526922591183};\\\", \\\"{x:591,y:488,t:1526922591200};\\\", \\\"{x:589,y:486,t:1526922591217};\\\", \\\"{x:589,y:483,t:1526922591235};\\\", \\\"{x:589,y:481,t:1526922591252};\\\", \\\"{x:593,y:474,t:1526922591267};\\\", \\\"{x:596,y:469,t:1526922591284};\\\", \\\"{x:603,y:463,t:1526922591302};\\\", \\\"{x:611,y:457,t:1526922591317};\\\", \\\"{x:619,y:452,t:1526922591335};\\\", \\\"{x:628,y:447,t:1526922591351};\\\", \\\"{x:639,y:441,t:1526922591368};\\\", \\\"{x:651,y:437,t:1526922591385};\\\", \\\"{x:662,y:437,t:1526922591401};\\\", \\\"{x:679,y:436,t:1526922591417};\\\", \\\"{x:704,y:436,t:1526922591434};\\\", \\\"{x:743,y:436,t:1526922591451};\\\", \\\"{x:820,y:446,t:1526922591469};\\\", \\\"{x:926,y:462,t:1526922591485};\\\", \\\"{x:1130,y:494,t:1526922591502};\\\", \\\"{x:1304,y:519,t:1526922591518};\\\", \\\"{x:1476,y:543,t:1526922591535};\\\", \\\"{x:1636,y:563,t:1526922591551};\\\", \\\"{x:1752,y:581,t:1526922591569};\\\", \\\"{x:1808,y:592,t:1526922591584};\\\", \\\"{x:1808,y:597,t:1526922591602};\\\", \\\"{x:1807,y:600,t:1526922591910};\\\", \\\"{x:1804,y:600,t:1526922591918};\\\", \\\"{x:1798,y:599,t:1526922591935};\\\", \\\"{x:1788,y:599,t:1526922591951};\\\", \\\"{x:1777,y:599,t:1526922591969};\\\", \\\"{x:1768,y:600,t:1526922591985};\\\", \\\"{x:1753,y:605,t:1526922592002};\\\", \\\"{x:1737,y:612,t:1526922592019};\\\", \\\"{x:1715,y:624,t:1526922592036};\\\", \\\"{x:1693,y:637,t:1526922592052};\\\", \\\"{x:1669,y:652,t:1526922592069};\\\", \\\"{x:1637,y:680,t:1526922592086};\\\", \\\"{x:1628,y:689,t:1526922592102};\\\", \\\"{x:1603,y:724,t:1526922592118};\\\", \\\"{x:1589,y:749,t:1526922592135};\\\", \\\"{x:1572,y:780,t:1526922592151};\\\", \\\"{x:1552,y:815,t:1526922592168};\\\", \\\"{x:1541,y:837,t:1526922592183};\\\", \\\"{x:1535,y:853,t:1526922592199};\\\", \\\"{x:1528,y:865,t:1526922592216};\\\", \\\"{x:1524,y:875,t:1526922592234};\\\", \\\"{x:1520,y:880,t:1526922592249};\\\", \\\"{x:1518,y:881,t:1526922592284};\\\", \\\"{x:1516,y:882,t:1526922592299};\\\", \\\"{x:1513,y:882,t:1526922592316};\\\", \\\"{x:1510,y:882,t:1526922592333};\\\", \\\"{x:1506,y:882,t:1526922592349};\\\", \\\"{x:1500,y:882,t:1526922592366};\\\", \\\"{x:1497,y:882,t:1526922592383};\\\", \\\"{x:1496,y:881,t:1526922592400};\\\", \\\"{x:1495,y:880,t:1526922592417};\\\", \\\"{x:1493,y:878,t:1526922592433};\\\", \\\"{x:1493,y:876,t:1526922592450};\\\", \\\"{x:1492,y:874,t:1526922592467};\\\", \\\"{x:1491,y:871,t:1526922592483};\\\", \\\"{x:1491,y:869,t:1526922592500};\\\", \\\"{x:1491,y:868,t:1526922592540};\\\", \\\"{x:1493,y:861,t:1526922592550};\\\", \\\"{x:1508,y:841,t:1526922592567};\\\", \\\"{x:1522,y:818,t:1526922592583};\\\", \\\"{x:1534,y:796,t:1526922592600};\\\", \\\"{x:1544,y:779,t:1526922592616};\\\", \\\"{x:1555,y:764,t:1526922592634};\\\", \\\"{x:1568,y:747,t:1526922592650};\\\", \\\"{x:1582,y:729,t:1526922592667};\\\", \\\"{x:1606,y:707,t:1526922592683};\\\", \\\"{x:1619,y:699,t:1526922592700};\\\", \\\"{x:1627,y:694,t:1526922592717};\\\", \\\"{x:1629,y:692,t:1526922592733};\\\", \\\"{x:1630,y:692,t:1526922592844};\\\", \\\"{x:1630,y:691,t:1526922592868};\\\", \\\"{x:1630,y:690,t:1526922592884};\\\", \\\"{x:1624,y:687,t:1526922592900};\\\", \\\"{x:1618,y:684,t:1526922592918};\\\", \\\"{x:1605,y:678,t:1526922592933};\\\", \\\"{x:1593,y:677,t:1526922592951};\\\", \\\"{x:1590,y:676,t:1526922592968};\\\", \\\"{x:1587,y:673,t:1526922592984};\\\", \\\"{x:1587,y:662,t:1526922593001};\\\", \\\"{x:1587,y:643,t:1526922593018};\\\", \\\"{x:1587,y:624,t:1526922593034};\\\", \\\"{x:1587,y:606,t:1526922593051};\\\", \\\"{x:1587,y:580,t:1526922593068};\\\", \\\"{x:1590,y:566,t:1526922593084};\\\", \\\"{x:1594,y:552,t:1526922593101};\\\", \\\"{x:1600,y:539,t:1526922593118};\\\", \\\"{x:1600,y:536,t:1526922593135};\\\", \\\"{x:1601,y:532,t:1526922593151};\\\", \\\"{x:1601,y:531,t:1526922593168};\\\", \\\"{x:1602,y:530,t:1526922593184};\\\", \\\"{x:1602,y:529,t:1526922593212};\\\", \\\"{x:1601,y:528,t:1526922593259};\\\", \\\"{x:1600,y:527,t:1526922593267};\\\", \\\"{x:1595,y:526,t:1526922593284};\\\", \\\"{x:1590,y:526,t:1526922593300};\\\", \\\"{x:1589,y:526,t:1526922593317};\\\", \\\"{x:1588,y:526,t:1526922593334};\\\", \\\"{x:1588,y:524,t:1526922593379};\\\", \\\"{x:1589,y:517,t:1526922593387};\\\", \\\"{x:1598,y:508,t:1526922593400};\\\", \\\"{x:1613,y:495,t:1526922593417};\\\", \\\"{x:1625,y:481,t:1526922593434};\\\", \\\"{x:1633,y:465,t:1526922593450};\\\", \\\"{x:1643,y:449,t:1526922593467};\\\", \\\"{x:1645,y:443,t:1526922593484};\\\", \\\"{x:1647,y:438,t:1526922593502};\\\", \\\"{x:1648,y:435,t:1526922593517};\\\", \\\"{x:1648,y:430,t:1526922593534};\\\", \\\"{x:1648,y:426,t:1526922593551};\\\", \\\"{x:1648,y:422,t:1526922593567};\\\", \\\"{x:1648,y:417,t:1526922593585};\\\", \\\"{x:1646,y:412,t:1526922593601};\\\", \\\"{x:1643,y:409,t:1526922593617};\\\", \\\"{x:1641,y:407,t:1526922593634};\\\", \\\"{x:1640,y:405,t:1526922593652};\\\", \\\"{x:1639,y:403,t:1526922593667};\\\", \\\"{x:1637,y:401,t:1526922593684};\\\", \\\"{x:1637,y:399,t:1526922593701};\\\", \\\"{x:1635,y:398,t:1526922593717};\\\", \\\"{x:1634,y:396,t:1526922593735};\\\", \\\"{x:1634,y:395,t:1526922593751};\\\", \\\"{x:1633,y:395,t:1526922593779};\\\", \\\"{x:1632,y:394,t:1526922593811};\\\", \\\"{x:1632,y:393,t:1526922593819};\\\", \\\"{x:1632,y:392,t:1526922593835};\\\", \\\"{x:1631,y:392,t:1526922593876};\\\", \\\"{x:1630,y:391,t:1526922593907};\\\", \\\"{x:1628,y:390,t:1526922593918};\\\", \\\"{x:1627,y:390,t:1526922593934};\\\", \\\"{x:1626,y:390,t:1526922593963};\\\", \\\"{x:1624,y:389,t:1526922593987};\\\", \\\"{x:1623,y:388,t:1526922594147};\\\", \\\"{x:1622,y:388,t:1526922594162};\\\", \\\"{x:1621,y:387,t:1526922594179};\\\", \\\"{x:1620,y:386,t:1526922594211};\\\", \\\"{x:1619,y:386,t:1526922598549};\\\", \\\"{x:1618,y:386,t:1526922598560};\\\", \\\"{x:1617,y:388,t:1526922598571};\\\", \\\"{x:1616,y:388,t:1526922598588};\\\", \\\"{x:1615,y:389,t:1526922598627};\\\", \\\"{x:1615,y:390,t:1526922598683};\\\", \\\"{x:1614,y:390,t:1526922598691};\\\", \\\"{x:1614,y:391,t:1526922598706};\\\", \\\"{x:1613,y:393,t:1526922598721};\\\", \\\"{x:1612,y:394,t:1526922598739};\\\", \\\"{x:1611,y:396,t:1526922598755};\\\", \\\"{x:1610,y:398,t:1526922598773};\\\", \\\"{x:1609,y:400,t:1526922598788};\\\", \\\"{x:1609,y:402,t:1526922598805};\\\", \\\"{x:1608,y:404,t:1526922598823};\\\", \\\"{x:1607,y:406,t:1526922598838};\\\", \\\"{x:1606,y:408,t:1526922598856};\\\", \\\"{x:1605,y:411,t:1526922598872};\\\", \\\"{x:1603,y:417,t:1526922598888};\\\", \\\"{x:1602,y:422,t:1526922598906};\\\", \\\"{x:1600,y:430,t:1526922598922};\\\", \\\"{x:1597,y:441,t:1526922598939};\\\", \\\"{x:1592,y:455,t:1526922598956};\\\", \\\"{x:1589,y:468,t:1526922598972};\\\", \\\"{x:1582,y:486,t:1526922598989};\\\", \\\"{x:1575,y:503,t:1526922599006};\\\", \\\"{x:1566,y:524,t:1526922599022};\\\", \\\"{x:1558,y:543,t:1526922599039};\\\", \\\"{x:1550,y:565,t:1526922599055};\\\", \\\"{x:1547,y:587,t:1526922599073};\\\", \\\"{x:1543,y:609,t:1526922599088};\\\", \\\"{x:1536,y:637,t:1526922599106};\\\", \\\"{x:1524,y:667,t:1526922599123};\\\", \\\"{x:1511,y:699,t:1526922599138};\\\", \\\"{x:1480,y:751,t:1526922599156};\\\", \\\"{x:1463,y:783,t:1526922599172};\\\", \\\"{x:1446,y:808,t:1526922599189};\\\", \\\"{x:1431,y:831,t:1526922599205};\\\", \\\"{x:1418,y:852,t:1526922599222};\\\", \\\"{x:1407,y:872,t:1526922599240};\\\", \\\"{x:1402,y:882,t:1526922599255};\\\", \\\"{x:1398,y:891,t:1526922599272};\\\", \\\"{x:1396,y:893,t:1526922599289};\\\", \\\"{x:1396,y:894,t:1526922599306};\\\", \\\"{x:1394,y:895,t:1526922599364};\\\", \\\"{x:1394,y:896,t:1526922599387};\\\", \\\"{x:1393,y:896,t:1526922599395};\\\", \\\"{x:1391,y:898,t:1526922599406};\\\", \\\"{x:1389,y:899,t:1526922599422};\\\", \\\"{x:1384,y:901,t:1526922599439};\\\", \\\"{x:1379,y:903,t:1526922599456};\\\", \\\"{x:1374,y:907,t:1526922599473};\\\", \\\"{x:1369,y:910,t:1526922599491};\\\", \\\"{x:1365,y:913,t:1526922599506};\\\", \\\"{x:1363,y:915,t:1526922599523};\\\", \\\"{x:1359,y:918,t:1526922599539};\\\", \\\"{x:1357,y:920,t:1526922599555};\\\", \\\"{x:1356,y:921,t:1526922599573};\\\", \\\"{x:1355,y:922,t:1526922599589};\\\", \\\"{x:1354,y:923,t:1526922599607};\\\", \\\"{x:1354,y:924,t:1526922599627};\\\", \\\"{x:1354,y:921,t:1526922602068};\\\", \\\"{x:1354,y:913,t:1526922602077};\\\", \\\"{x:1360,y:890,t:1526922602092};\\\", \\\"{x:1375,y:850,t:1526922602109};\\\", \\\"{x:1393,y:808,t:1526922602125};\\\", \\\"{x:1424,y:746,t:1526922602142};\\\", \\\"{x:1466,y:670,t:1526922602158};\\\", \\\"{x:1518,y:598,t:1526922602174};\\\", \\\"{x:1566,y:530,t:1526922602191};\\\", \\\"{x:1612,y:469,t:1526922602208};\\\", \\\"{x:1636,y:428,t:1526922602225};\\\", \\\"{x:1648,y:405,t:1526922602241};\\\", \\\"{x:1653,y:389,t:1526922602258};\\\", \\\"{x:1656,y:378,t:1526922602275};\\\", \\\"{x:1657,y:367,t:1526922602291};\\\", \\\"{x:1657,y:360,t:1526922602308};\\\", \\\"{x:1657,y:351,t:1526922602325};\\\", \\\"{x:1657,y:345,t:1526922602342};\\\", \\\"{x:1657,y:339,t:1526922602358};\\\", \\\"{x:1656,y:334,t:1526922602374};\\\", \\\"{x:1655,y:333,t:1526922602395};\\\", \\\"{x:1655,y:332,t:1526922602412};\\\", \\\"{x:1653,y:332,t:1526922602435};\\\", \\\"{x:1649,y:333,t:1526922602444};\\\", \\\"{x:1646,y:336,t:1526922602458};\\\", \\\"{x:1632,y:355,t:1526922602476};\\\", \\\"{x:1621,y:369,t:1526922602492};\\\", \\\"{x:1612,y:379,t:1526922602510};\\\", \\\"{x:1609,y:384,t:1526922602526};\\\", \\\"{x:1608,y:386,t:1526922602541};\\\", \\\"{x:1608,y:387,t:1526922602558};\\\", \\\"{x:1608,y:389,t:1526922602575};\\\", \\\"{x:1608,y:390,t:1526922602595};\\\", \\\"{x:1608,y:391,t:1526922602651};\\\", \\\"{x:1608,y:390,t:1526922602868};\\\", \\\"{x:1608,y:389,t:1526922602875};\\\", \\\"{x:1608,y:388,t:1526922602894};\\\", \\\"{x:1608,y:387,t:1526922602909};\\\", \\\"{x:1608,y:385,t:1526922602926};\\\", \\\"{x:1608,y:384,t:1526922602948};\\\", \\\"{x:1608,y:383,t:1526922602958};\\\", \\\"{x:1608,y:382,t:1526922602976};\\\", \\\"{x:1608,y:381,t:1526922603003};\\\", \\\"{x:1609,y:380,t:1526922603035};\\\", \\\"{x:1610,y:380,t:1526922606797};\\\", \\\"{x:1623,y:398,t:1526922606813};\\\", \\\"{x:1645,y:434,t:1526922606829};\\\", \\\"{x:1670,y:471,t:1526922606846};\\\", \\\"{x:1693,y:500,t:1526922606863};\\\", \\\"{x:1711,y:524,t:1526922606879};\\\", \\\"{x:1721,y:540,t:1526922606896};\\\", \\\"{x:1724,y:546,t:1526922606913};\\\", \\\"{x:1725,y:548,t:1526922606929};\\\", \\\"{x:1724,y:545,t:1526922607108};\\\", \\\"{x:1721,y:541,t:1526922607116};\\\", \\\"{x:1717,y:535,t:1526922607129};\\\", \\\"{x:1713,y:528,t:1526922607146};\\\", \\\"{x:1708,y:523,t:1526922607164};\\\", \\\"{x:1705,y:518,t:1526922607180};\\\", \\\"{x:1703,y:516,t:1526922607196};\\\", \\\"{x:1702,y:515,t:1526922607213};\\\", \\\"{x:1699,y:514,t:1526922607229};\\\", \\\"{x:1697,y:513,t:1526922607246};\\\", \\\"{x:1695,y:512,t:1526922607263};\\\", \\\"{x:1693,y:511,t:1526922607279};\\\", \\\"{x:1692,y:511,t:1526922607296};\\\", \\\"{x:1691,y:511,t:1526922607315};\\\", \\\"{x:1690,y:511,t:1526922607330};\\\", \\\"{x:1690,y:510,t:1526922607346};\\\", \\\"{x:1689,y:510,t:1526922607362};\\\", \\\"{x:1688,y:510,t:1526922607379};\\\", \\\"{x:1686,y:510,t:1526922607395};\\\", \\\"{x:1685,y:510,t:1526922607413};\\\", \\\"{x:1684,y:510,t:1526922607430};\\\", \\\"{x:1683,y:510,t:1526922607445};\\\", \\\"{x:1682,y:509,t:1526922607463};\\\", \\\"{x:1680,y:509,t:1526922607479};\\\", \\\"{x:1679,y:509,t:1526922607496};\\\", \\\"{x:1678,y:508,t:1526922607572};\\\", \\\"{x:1676,y:508,t:1526922609620};\\\", \\\"{x:1657,y:505,t:1526922609632};\\\", \\\"{x:1576,y:503,t:1526922609648};\\\", \\\"{x:1467,y:510,t:1526922609665};\\\", \\\"{x:1315,y:530,t:1526922609682};\\\", \\\"{x:1135,y:557,t:1526922609698};\\\", \\\"{x:930,y:597,t:1526922609716};\\\", \\\"{x:862,y:615,t:1526922609732};\\\", \\\"{x:842,y:630,t:1526922609748};\\\", \\\"{x:839,y:635,t:1526922609765};\\\", \\\"{x:835,y:636,t:1526922609782};\\\", \\\"{x:838,y:632,t:1526922610020};\\\", \\\"{x:839,y:631,t:1526922610032};\\\", \\\"{x:838,y:630,t:1526922610049};\\\", \\\"{x:822,y:627,t:1526922610065};\\\", \\\"{x:793,y:627,t:1526922610082};\\\", \\\"{x:734,y:627,t:1526922610100};\\\", \\\"{x:692,y:627,t:1526922610115};\\\", \\\"{x:663,y:627,t:1526922610132};\\\", \\\"{x:641,y:629,t:1526922610149};\\\", \\\"{x:627,y:632,t:1526922610165};\\\", \\\"{x:624,y:632,t:1526922610182};\\\", \\\"{x:623,y:632,t:1526922610260};\\\", \\\"{x:622,y:633,t:1526922610315};\\\", \\\"{x:627,y:633,t:1526922610947};\\\", \\\"{x:627,y:632,t:1526922611828};\\\", \\\"{x:626,y:632,t:1526922611843};\\\", \\\"{x:624,y:632,t:1526922611867};\\\", \\\"{x:618,y:631,t:1526922611883};\\\", \\\"{x:607,y:631,t:1526922611900};\\\", \\\"{x:592,y:631,t:1526922611917};\\\", \\\"{x:573,y:631,t:1526922611933};\\\", \\\"{x:550,y:631,t:1526922611950};\\\", \\\"{x:530,y:631,t:1526922611967};\\\", \\\"{x:512,y:631,t:1526922611983};\\\", \\\"{x:497,y:630,t:1526922612000};\\\", \\\"{x:477,y:627,t:1526922612017};\\\", \\\"{x:453,y:626,t:1526922612033};\\\", \\\"{x:424,y:625,t:1526922612050};\\\", \\\"{x:379,y:621,t:1526922612067};\\\", \\\"{x:350,y:621,t:1526922612083};\\\", \\\"{x:327,y:621,t:1526922612100};\\\", \\\"{x:313,y:621,t:1526922612117};\\\", \\\"{x:306,y:621,t:1526922612134};\\\", \\\"{x:305,y:621,t:1526922612150};\\\", \\\"{x:308,y:619,t:1526922612227};\\\", \\\"{x:311,y:618,t:1526922612234};\\\", \\\"{x:313,y:616,t:1526922612249};\\\", \\\"{x:330,y:598,t:1526922612267};\\\", \\\"{x:335,y:590,t:1526922612284};\\\", \\\"{x:339,y:583,t:1526922612299};\\\", \\\"{x:339,y:579,t:1526922612317};\\\", \\\"{x:339,y:572,t:1526922612331};\\\", \\\"{x:332,y:563,t:1526922612349};\\\", \\\"{x:321,y:557,t:1526922612366};\\\", \\\"{x:307,y:553,t:1526922612383};\\\", \\\"{x:286,y:552,t:1526922612398};\\\", \\\"{x:264,y:552,t:1526922612416};\\\", \\\"{x:243,y:552,t:1526922612433};\\\", \\\"{x:224,y:558,t:1526922612449};\\\", \\\"{x:210,y:564,t:1526922612466};\\\", \\\"{x:200,y:573,t:1526922612483};\\\", \\\"{x:191,y:578,t:1526922612499};\\\", \\\"{x:187,y:580,t:1526922612516};\\\", \\\"{x:184,y:582,t:1526922612532};\\\", \\\"{x:184,y:583,t:1526922612549};\\\", \\\"{x:182,y:583,t:1526922612603};\\\", \\\"{x:181,y:581,t:1526922612616};\\\", \\\"{x:180,y:580,t:1526922612633};\\\", \\\"{x:180,y:579,t:1526922612649};\\\", \\\"{x:179,y:577,t:1526922612665};\\\", \\\"{x:177,y:575,t:1526922612683};\\\", \\\"{x:177,y:572,t:1526922612699};\\\", \\\"{x:175,y:571,t:1526922612715};\\\", \\\"{x:173,y:568,t:1526922612733};\\\", \\\"{x:172,y:567,t:1526922612749};\\\", \\\"{x:169,y:565,t:1526922612766};\\\", \\\"{x:168,y:564,t:1526922612782};\\\", \\\"{x:167,y:564,t:1526922612800};\\\", \\\"{x:165,y:562,t:1526922612816};\\\", \\\"{x:164,y:561,t:1526922612832};\\\", \\\"{x:162,y:559,t:1526922612850};\\\", \\\"{x:160,y:558,t:1526922612866};\\\", \\\"{x:159,y:557,t:1526922612882};\\\", \\\"{x:158,y:556,t:1526922612900};\\\", \\\"{x:157,y:556,t:1526922612930};\\\", \\\"{x:156,y:554,t:1526922612947};\\\", \\\"{x:155,y:554,t:1526922612955};\\\", \\\"{x:155,y:553,t:1526922612966};\\\", \\\"{x:154,y:552,t:1526922612983};\\\", \\\"{x:152,y:551,t:1526922613010};\\\", \\\"{x:152,y:550,t:1526922613051};\\\", \\\"{x:152,y:549,t:1526922614043};\\\", \\\"{x:157,y:545,t:1526922614051};\\\", \\\"{x:182,y:538,t:1526922614067};\\\", \\\"{x:208,y:530,t:1526922614085};\\\", \\\"{x:232,y:523,t:1526922614102};\\\", \\\"{x:254,y:516,t:1526922614118};\\\", \\\"{x:274,y:510,t:1526922614135};\\\", \\\"{x:295,y:504,t:1526922614151};\\\", \\\"{x:320,y:496,t:1526922614167};\\\", \\\"{x:346,y:491,t:1526922614184};\\\", \\\"{x:371,y:488,t:1526922614202};\\\", \\\"{x:397,y:487,t:1526922614217};\\\", \\\"{x:421,y:487,t:1526922614234};\\\", \\\"{x:455,y:487,t:1526922614251};\\\", \\\"{x:475,y:493,t:1526922614268};\\\", \\\"{x:497,y:503,t:1526922614284};\\\", \\\"{x:518,y:517,t:1526922614302};\\\", \\\"{x:536,y:532,t:1526922614319};\\\", \\\"{x:551,y:547,t:1526922614334};\\\", \\\"{x:561,y:558,t:1526922614350};\\\", \\\"{x:569,y:570,t:1526922614368};\\\", \\\"{x:573,y:579,t:1526922614383};\\\", \\\"{x:574,y:586,t:1526922614400};\\\", \\\"{x:574,y:589,t:1526922614417};\\\", \\\"{x:573,y:595,t:1526922614433};\\\", \\\"{x:555,y:606,t:1526922614451};\\\", \\\"{x:537,y:612,t:1526922614467};\\\", \\\"{x:512,y:618,t:1526922614484};\\\", \\\"{x:491,y:622,t:1526922614501};\\\", \\\"{x:468,y:625,t:1526922614518};\\\", \\\"{x:445,y:629,t:1526922614534};\\\", \\\"{x:428,y:630,t:1526922614551};\\\", \\\"{x:411,y:631,t:1526922614568};\\\", \\\"{x:396,y:633,t:1526922614584};\\\", \\\"{x:381,y:633,t:1526922614600};\\\", \\\"{x:367,y:633,t:1526922614618};\\\", \\\"{x:352,y:633,t:1526922614634};\\\", \\\"{x:323,y:632,t:1526922614651};\\\", \\\"{x:300,y:625,t:1526922614668};\\\", \\\"{x:276,y:621,t:1526922614684};\\\", \\\"{x:252,y:615,t:1526922614701};\\\", \\\"{x:228,y:611,t:1526922614718};\\\", \\\"{x:214,y:609,t:1526922614734};\\\", \\\"{x:207,y:605,t:1526922614751};\\\", \\\"{x:202,y:601,t:1526922614768};\\\", \\\"{x:200,y:599,t:1526922614784};\\\", \\\"{x:197,y:595,t:1526922614801};\\\", \\\"{x:194,y:593,t:1526922614818};\\\", \\\"{x:191,y:591,t:1526922614835};\\\", \\\"{x:187,y:588,t:1526922614851};\\\", \\\"{x:186,y:587,t:1526922614868};\\\", \\\"{x:184,y:586,t:1526922614884};\\\", \\\"{x:182,y:585,t:1526922614901};\\\", \\\"{x:178,y:583,t:1526922614918};\\\", \\\"{x:174,y:582,t:1526922614935};\\\", \\\"{x:171,y:581,t:1526922614951};\\\", \\\"{x:168,y:581,t:1526922614969};\\\", \\\"{x:166,y:581,t:1526922614985};\\\", \\\"{x:164,y:581,t:1526922615001};\\\", \\\"{x:163,y:581,t:1526922615027};\\\", \\\"{x:162,y:581,t:1526922615044};\\\", \\\"{x:161,y:581,t:1526922615076};\\\", \\\"{x:160,y:581,t:1526922615139};\\\", \\\"{x:160,y:582,t:1526922615419};\\\", \\\"{x:171,y:592,t:1526922615436};\\\", \\\"{x:187,y:600,t:1526922615452};\\\", \\\"{x:198,y:606,t:1526922615468};\\\", \\\"{x:213,y:612,t:1526922615484};\\\", \\\"{x:230,y:617,t:1526922615501};\\\", \\\"{x:244,y:622,t:1526922615517};\\\", \\\"{x:261,y:626,t:1526922615535};\\\", \\\"{x:279,y:632,t:1526922615552};\\\", \\\"{x:301,y:641,t:1526922615568};\\\", \\\"{x:323,y:648,t:1526922615584};\\\", \\\"{x:351,y:658,t:1526922615602};\\\", \\\"{x:388,y:669,t:1526922615618};\\\", \\\"{x:415,y:678,t:1526922615635};\\\", \\\"{x:437,y:684,t:1526922615652};\\\", \\\"{x:458,y:692,t:1526922615668};\\\", \\\"{x:473,y:698,t:1526922615685};\\\", \\\"{x:485,y:705,t:1526922615702};\\\", \\\"{x:494,y:706,t:1526922615719};\\\", \\\"{x:507,y:707,t:1526922615735};\\\", \\\"{x:512,y:707,t:1526922615751};\\\", \\\"{x:515,y:707,t:1526922615769};\\\", \\\"{x:517,y:707,t:1526922615795};\\\", \\\"{x:518,y:707,t:1526922615827};\\\", \\\"{x:519,y:707,t:1526922615835};\\\", \\\"{x:523,y:704,t:1526922615852};\\\", \\\"{x:525,y:699,t:1526922615869};\\\", \\\"{x:529,y:692,t:1526922615885};\\\", \\\"{x:531,y:683,t:1526922615902};\\\", \\\"{x:533,y:678,t:1526922615921};\\\", \\\"{x:533,y:674,t:1526922615935};\\\", \\\"{x:533,y:671,t:1526922615951};\\\", \\\"{x:532,y:668,t:1526922615968};\\\", \\\"{x:532,y:666,t:1526922615984};\\\", \\\"{x:530,y:665,t:1526922616018};\\\", \\\"{x:530,y:664,t:1526922616035};\\\", \\\"{x:529,y:663,t:1526922616058};\\\" ] }, { \\\"rt\\\": 27597, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 230807, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:662,t:1526922623994};\\\", \\\"{x:567,y:657,t:1526922624002};\\\", \\\"{x:652,y:649,t:1526922624018};\\\", \\\"{x:770,y:687,t:1526922624042};\\\", \\\"{x:861,y:714,t:1526922624058};\\\", \\\"{x:958,y:723,t:1526922624075};\\\", \\\"{x:1049,y:723,t:1526922624092};\\\", \\\"{x:1124,y:723,t:1526922624108};\\\", \\\"{x:1169,y:723,t:1526922624125};\\\", \\\"{x:1198,y:723,t:1526922624142};\\\", \\\"{x:1219,y:723,t:1526922624158};\\\", \\\"{x:1230,y:721,t:1526922624176};\\\", \\\"{x:1233,y:720,t:1526922624192};\\\", \\\"{x:1232,y:720,t:1526922624251};\\\", \\\"{x:1230,y:723,t:1526922624259};\\\", \\\"{x:1226,y:739,t:1526922624276};\\\", \\\"{x:1226,y:762,t:1526922624292};\\\", \\\"{x:1226,y:785,t:1526922624308};\\\", \\\"{x:1226,y:800,t:1526922624325};\\\", \\\"{x:1224,y:810,t:1526922624343};\\\", \\\"{x:1224,y:811,t:1526922624358};\\\", \\\"{x:1224,y:812,t:1526922624376};\\\", \\\"{x:1224,y:813,t:1526922624410};\\\", \\\"{x:1224,y:814,t:1526922624426};\\\", \\\"{x:1224,y:815,t:1526922624442};\\\", \\\"{x:1224,y:812,t:1526922624531};\\\", \\\"{x:1224,y:809,t:1526922624542};\\\", \\\"{x:1224,y:800,t:1526922624560};\\\", \\\"{x:1224,y:792,t:1526922624576};\\\", \\\"{x:1223,y:787,t:1526922624592};\\\", \\\"{x:1220,y:782,t:1526922624610};\\\", \\\"{x:1220,y:779,t:1526922624626};\\\", \\\"{x:1219,y:777,t:1526922624644};\\\", \\\"{x:1219,y:776,t:1526922624659};\\\", \\\"{x:1219,y:777,t:1526922624811};\\\", \\\"{x:1219,y:780,t:1526922624826};\\\", \\\"{x:1220,y:787,t:1526922624843};\\\", \\\"{x:1221,y:791,t:1526922624858};\\\", \\\"{x:1225,y:799,t:1526922624875};\\\", \\\"{x:1229,y:807,t:1526922624892};\\\", \\\"{x:1236,y:818,t:1526922624909};\\\", \\\"{x:1241,y:825,t:1526922624927};\\\", \\\"{x:1244,y:832,t:1526922624942};\\\", \\\"{x:1248,y:837,t:1526922624959};\\\", \\\"{x:1250,y:843,t:1526922624977};\\\", \\\"{x:1253,y:846,t:1526922624992};\\\", \\\"{x:1257,y:852,t:1526922625009};\\\", \\\"{x:1260,y:858,t:1526922625026};\\\", \\\"{x:1262,y:861,t:1526922625042};\\\", \\\"{x:1264,y:865,t:1526922625059};\\\", \\\"{x:1267,y:869,t:1526922625076};\\\", \\\"{x:1268,y:872,t:1526922625093};\\\", \\\"{x:1269,y:873,t:1526922625109};\\\", \\\"{x:1272,y:876,t:1526922625126};\\\", \\\"{x:1273,y:877,t:1526922625142};\\\", \\\"{x:1274,y:878,t:1526922625159};\\\", \\\"{x:1277,y:882,t:1526922625177};\\\", \\\"{x:1278,y:884,t:1526922625193};\\\", \\\"{x:1281,y:887,t:1526922625209};\\\", \\\"{x:1285,y:894,t:1526922625227};\\\", \\\"{x:1286,y:894,t:1526922625242};\\\", \\\"{x:1289,y:899,t:1526922625259};\\\", \\\"{x:1289,y:901,t:1526922625276};\\\", \\\"{x:1289,y:902,t:1526922625427};\\\", \\\"{x:1289,y:903,t:1526922625443};\\\", \\\"{x:1289,y:904,t:1526922625467};\\\", \\\"{x:1288,y:904,t:1526922625692};\\\", \\\"{x:1288,y:903,t:1526922625707};\\\", \\\"{x:1288,y:902,t:1526922625715};\\\", \\\"{x:1288,y:901,t:1526922625727};\\\", \\\"{x:1289,y:895,t:1526922625744};\\\", \\\"{x:1293,y:889,t:1526922625760};\\\", \\\"{x:1299,y:877,t:1526922625777};\\\", \\\"{x:1307,y:865,t:1526922625794};\\\", \\\"{x:1314,y:856,t:1526922625810};\\\", \\\"{x:1322,y:844,t:1526922625827};\\\", \\\"{x:1328,y:837,t:1526922625843};\\\", \\\"{x:1332,y:829,t:1526922625860};\\\", \\\"{x:1339,y:820,t:1526922625876};\\\", \\\"{x:1344,y:814,t:1526922625893};\\\", \\\"{x:1348,y:809,t:1526922625911};\\\", \\\"{x:1353,y:800,t:1526922625927};\\\", \\\"{x:1357,y:792,t:1526922625943};\\\", \\\"{x:1361,y:785,t:1526922625961};\\\", \\\"{x:1365,y:779,t:1526922625977};\\\", \\\"{x:1369,y:772,t:1526922625994};\\\", \\\"{x:1373,y:761,t:1526922626011};\\\", \\\"{x:1376,y:753,t:1526922626027};\\\", \\\"{x:1379,y:745,t:1526922626044};\\\", \\\"{x:1382,y:739,t:1526922626061};\\\", \\\"{x:1384,y:733,t:1526922626076};\\\", \\\"{x:1386,y:728,t:1526922626093};\\\", \\\"{x:1387,y:724,t:1526922626110};\\\", \\\"{x:1390,y:719,t:1526922626126};\\\", \\\"{x:1391,y:715,t:1526922626143};\\\", \\\"{x:1393,y:710,t:1526922626160};\\\", \\\"{x:1393,y:709,t:1526922626176};\\\", \\\"{x:1393,y:707,t:1526922626193};\\\", \\\"{x:1394,y:703,t:1526922626210};\\\", \\\"{x:1394,y:701,t:1526922626226};\\\", \\\"{x:1394,y:699,t:1526922626243};\\\", \\\"{x:1394,y:698,t:1526922626261};\\\", \\\"{x:1394,y:696,t:1526922626277};\\\", \\\"{x:1393,y:696,t:1526922626435};\\\", \\\"{x:1392,y:696,t:1526922626459};\\\", \\\"{x:1390,y:697,t:1526922626467};\\\", \\\"{x:1389,y:698,t:1526922626500};\\\", \\\"{x:1389,y:699,t:1526922626515};\\\", \\\"{x:1389,y:701,t:1526922626528};\\\", \\\"{x:1387,y:701,t:1526922626547};\\\", \\\"{x:1387,y:702,t:1526922626561};\\\", \\\"{x:1387,y:703,t:1526922626578};\\\", \\\"{x:1386,y:703,t:1526922626594};\\\", \\\"{x:1385,y:704,t:1526922626610};\\\", \\\"{x:1384,y:705,t:1526922626628};\\\", \\\"{x:1384,y:706,t:1526922626660};\\\", \\\"{x:1382,y:707,t:1526922626678};\\\", \\\"{x:1382,y:708,t:1526922626694};\\\", \\\"{x:1381,y:709,t:1526922626711};\\\", \\\"{x:1381,y:710,t:1526922626727};\\\", \\\"{x:1380,y:710,t:1526922626747};\\\", \\\"{x:1379,y:711,t:1526922626771};\\\", \\\"{x:1379,y:712,t:1526922626795};\\\", \\\"{x:1378,y:712,t:1526922626827};\\\", \\\"{x:1378,y:713,t:1526922626859};\\\", \\\"{x:1378,y:715,t:1526922626971};\\\", \\\"{x:1377,y:715,t:1526922627004};\\\", \\\"{x:1377,y:716,t:1526922627340};\\\", \\\"{x:1377,y:720,t:1526922627347};\\\", \\\"{x:1377,y:725,t:1526922627361};\\\", \\\"{x:1373,y:739,t:1526922627378};\\\", \\\"{x:1370,y:748,t:1526922627395};\\\", \\\"{x:1365,y:764,t:1526922627411};\\\", \\\"{x:1364,y:772,t:1526922627428};\\\", \\\"{x:1361,y:780,t:1526922627444};\\\", \\\"{x:1356,y:790,t:1526922627461};\\\", \\\"{x:1354,y:797,t:1526922627477};\\\", \\\"{x:1350,y:804,t:1526922627494};\\\", \\\"{x:1347,y:809,t:1526922627511};\\\", \\\"{x:1342,y:815,t:1526922627527};\\\", \\\"{x:1339,y:819,t:1526922627544};\\\", \\\"{x:1335,y:825,t:1526922627561};\\\", \\\"{x:1331,y:829,t:1526922627578};\\\", \\\"{x:1326,y:839,t:1526922627594};\\\", \\\"{x:1319,y:847,t:1526922627611};\\\", \\\"{x:1314,y:853,t:1526922627627};\\\", \\\"{x:1312,y:857,t:1526922627644};\\\", \\\"{x:1309,y:860,t:1526922627661};\\\", \\\"{x:1307,y:861,t:1526922627677};\\\", \\\"{x:1305,y:866,t:1526922627695};\\\", \\\"{x:1302,y:873,t:1526922627711};\\\", \\\"{x:1299,y:878,t:1526922627727};\\\", \\\"{x:1295,y:884,t:1526922627744};\\\", \\\"{x:1292,y:888,t:1526922627762};\\\", \\\"{x:1290,y:893,t:1526922627779};\\\", \\\"{x:1287,y:895,t:1526922627795};\\\", \\\"{x:1287,y:897,t:1526922627811};\\\", \\\"{x:1285,y:902,t:1526922627828};\\\", \\\"{x:1284,y:903,t:1526922627844};\\\", \\\"{x:1284,y:904,t:1526922627867};\\\", \\\"{x:1284,y:905,t:1526922627915};\\\", \\\"{x:1283,y:906,t:1526922627932};\\\", \\\"{x:1283,y:907,t:1526922627955};\\\", \\\"{x:1283,y:908,t:1526922627964};\\\", \\\"{x:1282,y:909,t:1526922627979};\\\", \\\"{x:1281,y:909,t:1526922627995};\\\", \\\"{x:1281,y:910,t:1526922628059};\\\", \\\"{x:1280,y:909,t:1526922628867};\\\", \\\"{x:1280,y:908,t:1526922628955};\\\", \\\"{x:1280,y:907,t:1526922629003};\\\", \\\"{x:1279,y:906,t:1526922629075};\\\", \\\"{x:1279,y:905,t:1526922629148};\\\", \\\"{x:1279,y:904,t:1526922629403};\\\", \\\"{x:1280,y:904,t:1526922629412};\\\", \\\"{x:1285,y:904,t:1526922629429};\\\", \\\"{x:1289,y:904,t:1526922629446};\\\", \\\"{x:1264,y:891,t:1526922637483};\\\", \\\"{x:1189,y:834,t:1526922637490};\\\", \\\"{x:1108,y:770,t:1526922637501};\\\", \\\"{x:958,y:649,t:1526922637518};\\\", \\\"{x:841,y:562,t:1526922637535};\\\", \\\"{x:734,y:501,t:1526922637552};\\\", \\\"{x:620,y:449,t:1526922637568};\\\", \\\"{x:502,y:417,t:1526922637585};\\\", \\\"{x:348,y:396,t:1526922637603};\\\", \\\"{x:237,y:378,t:1526922637619};\\\", \\\"{x:134,y:364,t:1526922637635};\\\", \\\"{x:57,y:356,t:1526922637652};\\\", \\\"{x:22,y:354,t:1526922637670};\\\", \\\"{x:0,y:354,t:1526922637685};\\\", \\\"{x:3,y:360,t:1526922637771};\\\", \\\"{x:11,y:379,t:1526922637786};\\\", \\\"{x:41,y:428,t:1526922637803};\\\", \\\"{x:65,y:456,t:1526922637821};\\\", \\\"{x:86,y:477,t:1526922637836};\\\", \\\"{x:105,y:491,t:1526922637853};\\\", \\\"{x:115,y:504,t:1526922637869};\\\", \\\"{x:123,y:511,t:1526922637887};\\\", \\\"{x:128,y:519,t:1526922637903};\\\", \\\"{x:135,y:531,t:1526922637920};\\\", \\\"{x:140,y:543,t:1526922637937};\\\", \\\"{x:144,y:554,t:1526922637952};\\\", \\\"{x:150,y:562,t:1526922637970};\\\", \\\"{x:151,y:565,t:1526922637986};\\\", \\\"{x:152,y:565,t:1526922638043};\\\", \\\"{x:154,y:564,t:1526922638053};\\\", \\\"{x:158,y:557,t:1526922638070};\\\", \\\"{x:169,y:543,t:1526922638086};\\\", \\\"{x:180,y:529,t:1526922638104};\\\", \\\"{x:194,y:519,t:1526922638120};\\\", \\\"{x:213,y:509,t:1526922638136};\\\", \\\"{x:239,y:498,t:1526922638153};\\\", \\\"{x:280,y:488,t:1526922638171};\\\", \\\"{x:330,y:476,t:1526922638186};\\\", \\\"{x:356,y:475,t:1526922638203};\\\", \\\"{x:383,y:475,t:1526922638220};\\\", \\\"{x:407,y:477,t:1526922638237};\\\", \\\"{x:430,y:484,t:1526922638254};\\\", \\\"{x:452,y:494,t:1526922638270};\\\", \\\"{x:473,y:502,t:1526922638287};\\\", \\\"{x:490,y:510,t:1526922638303};\\\", \\\"{x:506,y:520,t:1526922638321};\\\", \\\"{x:520,y:526,t:1526922638337};\\\", \\\"{x:536,y:534,t:1526922638353};\\\", \\\"{x:549,y:539,t:1526922638369};\\\", \\\"{x:567,y:544,t:1526922638386};\\\", \\\"{x:576,y:546,t:1526922638404};\\\", \\\"{x:581,y:547,t:1526922638420};\\\", \\\"{x:589,y:550,t:1526922638436};\\\", \\\"{x:600,y:553,t:1526922638455};\\\", \\\"{x:616,y:555,t:1526922638470};\\\", \\\"{x:626,y:557,t:1526922638487};\\\", \\\"{x:627,y:558,t:1526922638503};\\\", \\\"{x:628,y:558,t:1526922638699};\\\", \\\"{x:634,y:558,t:1526922638707};\\\", \\\"{x:636,y:558,t:1526922638721};\\\", \\\"{x:638,y:558,t:1526922638736};\\\", \\\"{x:646,y:558,t:1526922638754};\\\", \\\"{x:674,y:565,t:1526922638772};\\\", \\\"{x:707,y:578,t:1526922638789};\\\", \\\"{x:770,y:602,t:1526922638805};\\\", \\\"{x:844,y:622,t:1526922638821};\\\", \\\"{x:909,y:643,t:1526922638837};\\\", \\\"{x:965,y:660,t:1526922638854};\\\", \\\"{x:1005,y:672,t:1526922638872};\\\", \\\"{x:1032,y:684,t:1526922638887};\\\", \\\"{x:1058,y:695,t:1526922638904};\\\", \\\"{x:1075,y:702,t:1526922638921};\\\", \\\"{x:1085,y:710,t:1526922638938};\\\", \\\"{x:1091,y:720,t:1526922638954};\\\", \\\"{x:1104,y:750,t:1526922638971};\\\", \\\"{x:1116,y:774,t:1526922638988};\\\", \\\"{x:1129,y:790,t:1526922639004};\\\", \\\"{x:1139,y:797,t:1526922639021};\\\", \\\"{x:1154,y:808,t:1526922639038};\\\", \\\"{x:1175,y:825,t:1526922639054};\\\", \\\"{x:1192,y:835,t:1526922639071};\\\", \\\"{x:1209,y:841,t:1526922639087};\\\", \\\"{x:1227,y:841,t:1526922639104};\\\", \\\"{x:1245,y:841,t:1526922639120};\\\", \\\"{x:1257,y:841,t:1526922639137};\\\", \\\"{x:1271,y:841,t:1526922639153};\\\", \\\"{x:1291,y:841,t:1526922639170};\\\", \\\"{x:1301,y:841,t:1526922639188};\\\", \\\"{x:1311,y:841,t:1526922639204};\\\", \\\"{x:1319,y:842,t:1526922639221};\\\", \\\"{x:1320,y:842,t:1526922639237};\\\", \\\"{x:1322,y:844,t:1526922639253};\\\", \\\"{x:1323,y:846,t:1526922639271};\\\", \\\"{x:1325,y:851,t:1526922639287};\\\", \\\"{x:1325,y:853,t:1526922639304};\\\", \\\"{x:1325,y:855,t:1526922639321};\\\", \\\"{x:1325,y:858,t:1526922639338};\\\", \\\"{x:1325,y:862,t:1526922639354};\\\", \\\"{x:1325,y:865,t:1526922639371};\\\", \\\"{x:1325,y:866,t:1526922639388};\\\", \\\"{x:1324,y:869,t:1526922639405};\\\", \\\"{x:1323,y:871,t:1526922639421};\\\", \\\"{x:1322,y:872,t:1526922639438};\\\", \\\"{x:1321,y:874,t:1526922639455};\\\", \\\"{x:1320,y:876,t:1526922639471};\\\", \\\"{x:1318,y:879,t:1526922639487};\\\", \\\"{x:1316,y:883,t:1526922639505};\\\", \\\"{x:1314,y:888,t:1526922639521};\\\", \\\"{x:1312,y:894,t:1526922639538};\\\", \\\"{x:1309,y:898,t:1526922639554};\\\", \\\"{x:1307,y:900,t:1526922639571};\\\", \\\"{x:1306,y:902,t:1526922639587};\\\", \\\"{x:1304,y:903,t:1526922639605};\\\", \\\"{x:1302,y:906,t:1526922639621};\\\", \\\"{x:1300,y:908,t:1526922639638};\\\", \\\"{x:1297,y:911,t:1526922639655};\\\", \\\"{x:1294,y:912,t:1526922639671};\\\", \\\"{x:1292,y:914,t:1526922639688};\\\", \\\"{x:1292,y:915,t:1526922639705};\\\", \\\"{x:1291,y:915,t:1526922639720};\\\", \\\"{x:1290,y:915,t:1526922639738};\\\", \\\"{x:1288,y:915,t:1526922639948};\\\", \\\"{x:1287,y:915,t:1526922639963};\\\", \\\"{x:1285,y:915,t:1526922639972};\\\", \\\"{x:1283,y:915,t:1526922639988};\\\", \\\"{x:1281,y:914,t:1526922640006};\\\", \\\"{x:1276,y:913,t:1526922640022};\\\", \\\"{x:1274,y:911,t:1526922640037};\\\", \\\"{x:1271,y:911,t:1526922640055};\\\", \\\"{x:1266,y:909,t:1526922640072};\\\", \\\"{x:1264,y:907,t:1526922640088};\\\", \\\"{x:1263,y:906,t:1526922640162};\\\", \\\"{x:1263,y:905,t:1526922640316};\\\", \\\"{x:1262,y:904,t:1526922640330};\\\", \\\"{x:1262,y:903,t:1526922640451};\\\", \\\"{x:1262,y:902,t:1526922640459};\\\", \\\"{x:1262,y:901,t:1526922640475};\\\", \\\"{x:1262,y:900,t:1526922640489};\\\", \\\"{x:1263,y:898,t:1526922640506};\\\", \\\"{x:1264,y:898,t:1526922640691};\\\", \\\"{x:1265,y:899,t:1526922640705};\\\", \\\"{x:1267,y:902,t:1526922640723};\\\", \\\"{x:1269,y:905,t:1526922640739};\\\", \\\"{x:1270,y:906,t:1526922640763};\\\", \\\"{x:1272,y:906,t:1526922640819};\\\", \\\"{x:1273,y:906,t:1526922640827};\\\", \\\"{x:1276,y:906,t:1526922640839};\\\", \\\"{x:1278,y:906,t:1526922640856};\\\", \\\"{x:1279,y:906,t:1526922640872};\\\", \\\"{x:1280,y:905,t:1526922643084};\\\", \\\"{x:1280,y:904,t:1526922643091};\\\", \\\"{x:1282,y:901,t:1526922643107};\\\", \\\"{x:1283,y:898,t:1526922643124};\\\", \\\"{x:1284,y:894,t:1526922643141};\\\", \\\"{x:1284,y:891,t:1526922643158};\\\", \\\"{x:1284,y:890,t:1526922643174};\\\", \\\"{x:1286,y:889,t:1526922643191};\\\", \\\"{x:1286,y:888,t:1526922643211};\\\", \\\"{x:1286,y:887,t:1526922643224};\\\", \\\"{x:1287,y:887,t:1526922643276};\\\", \\\"{x:1287,y:885,t:1526922643299};\\\", \\\"{x:1287,y:884,t:1526922643322};\\\", \\\"{x:1289,y:880,t:1526922643331};\\\", \\\"{x:1290,y:877,t:1526922643347};\\\", \\\"{x:1291,y:873,t:1526922643359};\\\", \\\"{x:1291,y:863,t:1526922643374};\\\", \\\"{x:1291,y:850,t:1526922643392};\\\", \\\"{x:1290,y:832,t:1526922643409};\\\", \\\"{x:1280,y:806,t:1526922643425};\\\", \\\"{x:1261,y:767,t:1526922643441};\\\", \\\"{x:1239,y:732,t:1526922643458};\\\", \\\"{x:1208,y:691,t:1526922643474};\\\", \\\"{x:1153,y:641,t:1526922643491};\\\", \\\"{x:1107,y:614,t:1526922643508};\\\", \\\"{x:1048,y:588,t:1526922643524};\\\", \\\"{x:990,y:570,t:1526922643541};\\\", \\\"{x:932,y:555,t:1526922643562};\\\", \\\"{x:876,y:547,t:1526922643574};\\\", \\\"{x:820,y:541,t:1526922643590};\\\", \\\"{x:774,y:538,t:1526922643605};\\\", \\\"{x:740,y:538,t:1526922643621};\\\", \\\"{x:715,y:538,t:1526922643639};\\\", \\\"{x:693,y:539,t:1526922643655};\\\", \\\"{x:661,y:552,t:1526922643674};\\\", \\\"{x:639,y:565,t:1526922643692};\\\", \\\"{x:618,y:576,t:1526922643708};\\\", \\\"{x:601,y:591,t:1526922643723};\\\", \\\"{x:592,y:600,t:1526922643741};\\\", \\\"{x:590,y:603,t:1526922643758};\\\", \\\"{x:590,y:604,t:1526922643778};\\\", \\\"{x:592,y:604,t:1526922643793};\\\", \\\"{x:597,y:603,t:1526922643808};\\\", \\\"{x:614,y:593,t:1526922643825};\\\", \\\"{x:637,y:580,t:1526922643841};\\\", \\\"{x:675,y:557,t:1526922643859};\\\", \\\"{x:709,y:535,t:1526922643874};\\\", \\\"{x:732,y:519,t:1526922643892};\\\", \\\"{x:752,y:504,t:1526922643907};\\\", \\\"{x:770,y:491,t:1526922643925};\\\", \\\"{x:782,y:479,t:1526922643942};\\\", \\\"{x:793,y:469,t:1526922643958};\\\", \\\"{x:796,y:465,t:1526922643974};\\\", \\\"{x:799,y:463,t:1526922643991};\\\", \\\"{x:800,y:461,t:1526922644008};\\\", \\\"{x:802,y:459,t:1526922644025};\\\", \\\"{x:804,y:459,t:1526922644040};\\\", \\\"{x:807,y:457,t:1526922644058};\\\", \\\"{x:812,y:456,t:1526922644074};\\\", \\\"{x:816,y:455,t:1526922644091};\\\", \\\"{x:817,y:455,t:1526922644108};\\\", \\\"{x:819,y:455,t:1526922644171};\\\", \\\"{x:820,y:455,t:1526922644219};\\\", \\\"{x:822,y:455,t:1526922644267};\\\", \\\"{x:824,y:456,t:1526922644282};\\\", \\\"{x:826,y:457,t:1526922644292};\\\", \\\"{x:829,y:458,t:1526922644307};\\\", \\\"{x:832,y:460,t:1526922644325};\\\", \\\"{x:834,y:461,t:1526922644342};\\\", \\\"{x:835,y:461,t:1526922644358};\\\", \\\"{x:836,y:462,t:1526922644569};\\\", \\\"{x:836,y:462,t:1526922644574};\\\", \\\"{x:836,y:475,t:1526922644591};\\\", \\\"{x:830,y:496,t:1526922644608};\\\", \\\"{x:819,y:518,t:1526922644625};\\\", \\\"{x:791,y:562,t:1526922644643};\\\", \\\"{x:763,y:592,t:1526922644658};\\\", \\\"{x:726,y:630,t:1526922644675};\\\", \\\"{x:707,y:652,t:1526922644691};\\\", \\\"{x:687,y:670,t:1526922644709};\\\", \\\"{x:670,y:683,t:1526922644725};\\\", \\\"{x:648,y:695,t:1526922644742};\\\", \\\"{x:631,y:702,t:1526922644759};\\\", \\\"{x:618,y:705,t:1526922644774};\\\", \\\"{x:604,y:707,t:1526922644792};\\\", \\\"{x:591,y:708,t:1526922644809};\\\", \\\"{x:576,y:710,t:1526922644826};\\\", \\\"{x:564,y:710,t:1526922644842};\\\", \\\"{x:553,y:710,t:1526922644859};\\\", \\\"{x:540,y:707,t:1526922644876};\\\", \\\"{x:524,y:699,t:1526922644892};\\\", \\\"{x:512,y:691,t:1526922644909};\\\", \\\"{x:505,y:685,t:1526922644926};\\\", \\\"{x:501,y:678,t:1526922644943};\\\", \\\"{x:499,y:674,t:1526922644958};\\\", \\\"{x:499,y:667,t:1526922644976};\\\", \\\"{x:499,y:659,t:1526922644992};\\\", \\\"{x:499,y:654,t:1526922645008};\\\", \\\"{x:499,y:650,t:1526922645026};\\\", \\\"{x:499,y:648,t:1526922645042};\\\", \\\"{x:498,y:648,t:1526922645290};\\\", \\\"{x:498,y:651,t:1526922645305};\\\", \\\"{x:497,y:652,t:1526922645314};\\\", \\\"{x:497,y:655,t:1526922645326};\\\", \\\"{x:497,y:657,t:1526922645342};\\\", \\\"{x:497,y:658,t:1526922645359};\\\" ] }, { \\\"rt\\\": 12025, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 244103, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:658,t:1526922649026};\\\", \\\"{x:521,y:655,t:1526922649038};\\\", \\\"{x:551,y:650,t:1526922649045};\\\", \\\"{x:638,y:643,t:1526922649062};\\\", \\\"{x:744,y:643,t:1526922649079};\\\", \\\"{x:863,y:643,t:1526922649095};\\\", \\\"{x:990,y:643,t:1526922649112};\\\", \\\"{x:1126,y:643,t:1526922649129};\\\", \\\"{x:1245,y:643,t:1526922649145};\\\", \\\"{x:1401,y:637,t:1526922649162};\\\", \\\"{x:1465,y:637,t:1526922649179};\\\", \\\"{x:1492,y:637,t:1526922649195};\\\", \\\"{x:1505,y:637,t:1526922649212};\\\", \\\"{x:1510,y:637,t:1526922649229};\\\", \\\"{x:1516,y:641,t:1526922649244};\\\", \\\"{x:1534,y:657,t:1526922649261};\\\", \\\"{x:1584,y:710,t:1526922649279};\\\", \\\"{x:1633,y:768,t:1526922649295};\\\", \\\"{x:1665,y:802,t:1526922649312};\\\", \\\"{x:1691,y:837,t:1526922649329};\\\", \\\"{x:1711,y:885,t:1526922649346};\\\", \\\"{x:1712,y:904,t:1526922649361};\\\", \\\"{x:1712,y:918,t:1526922649379};\\\", \\\"{x:1703,y:934,t:1526922649396};\\\", \\\"{x:1691,y:952,t:1526922649412};\\\", \\\"{x:1680,y:965,t:1526922649429};\\\", \\\"{x:1673,y:973,t:1526922649446};\\\", \\\"{x:1669,y:978,t:1526922649462};\\\", \\\"{x:1665,y:982,t:1526922649479};\\\", \\\"{x:1664,y:982,t:1526922649498};\\\", \\\"{x:1663,y:982,t:1526922649512};\\\", \\\"{x:1657,y:980,t:1526922649529};\\\", \\\"{x:1647,y:969,t:1526922649546};\\\", \\\"{x:1640,y:962,t:1526922649562};\\\", \\\"{x:1633,y:952,t:1526922649579};\\\", \\\"{x:1627,y:941,t:1526922649596};\\\", \\\"{x:1624,y:933,t:1526922649612};\\\", \\\"{x:1623,y:929,t:1526922649629};\\\", \\\"{x:1622,y:924,t:1526922649646};\\\", \\\"{x:1622,y:921,t:1526922649662};\\\", \\\"{x:1621,y:919,t:1526922649679};\\\", \\\"{x:1621,y:918,t:1526922649696};\\\", \\\"{x:1620,y:916,t:1526922649712};\\\", \\\"{x:1620,y:914,t:1526922649795};\\\", \\\"{x:1619,y:914,t:1526922649842};\\\", \\\"{x:1618,y:914,t:1526922649850};\\\", \\\"{x:1617,y:913,t:1526922650138};\\\", \\\"{x:1616,y:912,t:1526922650218};\\\", \\\"{x:1615,y:911,t:1526922650258};\\\", \\\"{x:1614,y:911,t:1526922650322};\\\", \\\"{x:1614,y:910,t:1526922651059};\\\", \\\"{x:1614,y:909,t:1526922651067};\\\", \\\"{x:1614,y:908,t:1526922651081};\\\", \\\"{x:1614,y:907,t:1526922651097};\\\", \\\"{x:1614,y:906,t:1526922651113};\\\", \\\"{x:1612,y:904,t:1526922651130};\\\", \\\"{x:1612,y:903,t:1526922652823};\\\", \\\"{x:1613,y:903,t:1526922652855};\\\", \\\"{x:1614,y:903,t:1526922652871};\\\", \\\"{x:1615,y:903,t:1526922652888};\\\", \\\"{x:1616,y:903,t:1526922654737};\\\", \\\"{x:1616,y:904,t:1526922654748};\\\", \\\"{x:1617,y:906,t:1526922654765};\\\", \\\"{x:1617,y:907,t:1526922654782};\\\", \\\"{x:1618,y:909,t:1526922654798};\\\", \\\"{x:1618,y:910,t:1526922654825};\\\", \\\"{x:1616,y:904,t:1526922657018};\\\", \\\"{x:1579,y:856,t:1526922657034};\\\", \\\"{x:1521,y:805,t:1526922657050};\\\", \\\"{x:1434,y:743,t:1526922657067};\\\", \\\"{x:1310,y:665,t:1526922657084};\\\", \\\"{x:1178,y:581,t:1526922657100};\\\", \\\"{x:1074,y:518,t:1526922657117};\\\", \\\"{x:993,y:478,t:1526922657134};\\\", \\\"{x:923,y:458,t:1526922657151};\\\", \\\"{x:875,y:443,t:1526922657167};\\\", \\\"{x:841,y:436,t:1526922657184};\\\", \\\"{x:836,y:436,t:1526922657199};\\\", \\\"{x:818,y:436,t:1526922657216};\\\", \\\"{x:808,y:436,t:1526922657233};\\\", \\\"{x:800,y:440,t:1526922657249};\\\", \\\"{x:793,y:445,t:1526922657267};\\\", \\\"{x:784,y:453,t:1526922657284};\\\", \\\"{x:773,y:463,t:1526922657301};\\\", \\\"{x:760,y:477,t:1526922657317};\\\", \\\"{x:749,y:492,t:1526922657334};\\\", \\\"{x:736,y:506,t:1526922657350};\\\", \\\"{x:722,y:517,t:1526922657367};\\\", \\\"{x:713,y:523,t:1526922657383};\\\", \\\"{x:696,y:531,t:1526922657400};\\\", \\\"{x:687,y:532,t:1526922657416};\\\", \\\"{x:678,y:533,t:1526922657433};\\\", \\\"{x:670,y:533,t:1526922657450};\\\", \\\"{x:661,y:529,t:1526922657466};\\\", \\\"{x:659,y:523,t:1526922657483};\\\", \\\"{x:655,y:518,t:1526922657501};\\\", \\\"{x:652,y:515,t:1526922657518};\\\", \\\"{x:645,y:508,t:1526922657534};\\\", \\\"{x:641,y:501,t:1526922657551};\\\", \\\"{x:637,y:498,t:1526922657568};\\\", \\\"{x:636,y:497,t:1526922657583};\\\", \\\"{x:635,y:497,t:1526922657632};\\\", \\\"{x:634,y:497,t:1526922657641};\\\", \\\"{x:631,y:497,t:1526922657657};\\\", \\\"{x:630,y:497,t:1526922657672};\\\", \\\"{x:627,y:498,t:1526922657683};\\\", \\\"{x:623,y:499,t:1526922657701};\\\", \\\"{x:619,y:501,t:1526922657717};\\\", \\\"{x:617,y:502,t:1526922657733};\\\", \\\"{x:614,y:504,t:1526922657750};\\\", \\\"{x:613,y:505,t:1526922657767};\\\", \\\"{x:612,y:505,t:1526922657857};\\\", \\\"{x:612,y:507,t:1526922657976};\\\", \\\"{x:611,y:509,t:1526922657989};\\\", \\\"{x:609,y:522,t:1526922658000};\\\", \\\"{x:604,y:536,t:1526922658018};\\\", \\\"{x:598,y:557,t:1526922658035};\\\", \\\"{x:593,y:578,t:1526922658051};\\\", \\\"{x:588,y:596,t:1526922658068};\\\", \\\"{x:583,y:610,t:1526922658083};\\\", \\\"{x:579,y:625,t:1526922658100};\\\", \\\"{x:575,y:638,t:1526922658117};\\\", \\\"{x:573,y:644,t:1526922658134};\\\", \\\"{x:571,y:647,t:1526922658150};\\\", \\\"{x:570,y:649,t:1526922658167};\\\", \\\"{x:569,y:651,t:1526922658183};\\\", \\\"{x:569,y:652,t:1526922658201};\\\", \\\"{x:567,y:653,t:1526922658217};\\\", \\\"{x:566,y:655,t:1526922658235};\\\", \\\"{x:564,y:656,t:1526922658251};\\\", \\\"{x:562,y:657,t:1526922658267};\\\", \\\"{x:560,y:658,t:1526922658288};\\\", \\\"{x:559,y:658,t:1526922658300};\\\", \\\"{x:557,y:658,t:1526922658317};\\\", \\\"{x:555,y:658,t:1526922658334};\\\", \\\"{x:552,y:659,t:1526922658352};\\\", \\\"{x:550,y:659,t:1526922658367};\\\", \\\"{x:549,y:659,t:1526922659073};\\\", \\\"{x:548,y:659,t:1526922659096};\\\", \\\"{x:547,y:658,t:1526922659104};\\\", \\\"{x:547,y:657,t:1526922659119};\\\", \\\"{x:548,y:655,t:1526922659225};\\\", \\\"{x:549,y:654,t:1526922659234};\\\", \\\"{x:554,y:651,t:1526922659252};\\\", \\\"{x:558,y:648,t:1526922659268};\\\", \\\"{x:561,y:646,t:1526922659285};\\\", \\\"{x:564,y:644,t:1526922659302};\\\", \\\"{x:568,y:641,t:1526922659319};\\\", \\\"{x:569,y:641,t:1526922659335};\\\", \\\"{x:570,y:640,t:1526922659351};\\\", \\\"{x:574,y:638,t:1526922659367};\\\", \\\"{x:577,y:635,t:1526922659384};\\\", \\\"{x:577,y:634,t:1526922659401};\\\", \\\"{x:578,y:633,t:1526922659418};\\\", \\\"{x:580,y:632,t:1526922659434};\\\", \\\"{x:581,y:631,t:1526922659480};\\\" ] }, { \\\"rt\\\": 52919, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 298264, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:582,y:631,t:1526922659774};\\\", \\\"{x:586,y:625,t:1526922668153};\\\", \\\"{x:583,y:601,t:1526922668173};\\\", \\\"{x:567,y:571,t:1526922668192};\\\", \\\"{x:556,y:551,t:1526922668207};\\\", \\\"{x:547,y:536,t:1526922668225};\\\", \\\"{x:539,y:521,t:1526922668242};\\\", \\\"{x:529,y:504,t:1526922668258};\\\", \\\"{x:522,y:490,t:1526922668276};\\\", \\\"{x:513,y:476,t:1526922668291};\\\", \\\"{x:503,y:463,t:1526922668309};\\\", \\\"{x:496,y:453,t:1526922668326};\\\", \\\"{x:489,y:446,t:1526922668341};\\\", \\\"{x:483,y:441,t:1526922668358};\\\", \\\"{x:474,y:436,t:1526922668375};\\\", \\\"{x:468,y:433,t:1526922668392};\\\", \\\"{x:463,y:432,t:1526922668408};\\\", \\\"{x:461,y:432,t:1526922668425};\\\", \\\"{x:459,y:432,t:1526922668448};\\\", \\\"{x:458,y:433,t:1526922668687};\\\", \\\"{x:458,y:434,t:1526922668695};\\\", \\\"{x:458,y:436,t:1526922668708};\\\", \\\"{x:458,y:438,t:1526922668725};\\\", \\\"{x:458,y:442,t:1526922668742};\\\", \\\"{x:458,y:446,t:1526922668758};\\\", \\\"{x:458,y:448,t:1526922668775};\\\", \\\"{x:458,y:450,t:1526922668791};\\\", \\\"{x:458,y:451,t:1526922668807};\\\", \\\"{x:458,y:453,t:1526922668825};\\\", \\\"{x:458,y:454,t:1526922668856};\\\", \\\"{x:458,y:455,t:1526922668872};\\\", \\\"{x:458,y:456,t:1526922668888};\\\", \\\"{x:459,y:456,t:1526922669057};\\\", \\\"{x:460,y:456,t:1526922669072};\\\", \\\"{x:461,y:456,t:1526922669080};\\\", \\\"{x:462,y:456,t:1526922669091};\\\", \\\"{x:464,y:456,t:1526922669107};\\\", \\\"{x:468,y:453,t:1526922669124};\\\", \\\"{x:472,y:451,t:1526922669141};\\\", \\\"{x:479,y:447,t:1526922669158};\\\", \\\"{x:484,y:444,t:1526922669174};\\\", \\\"{x:489,y:441,t:1526922669192};\\\", \\\"{x:491,y:441,t:1526922669207};\\\", \\\"{x:492,y:440,t:1526922669224};\\\", \\\"{x:493,y:440,t:1526922669241};\\\", \\\"{x:495,y:439,t:1526922669257};\\\", \\\"{x:496,y:438,t:1526922669280};\\\", \\\"{x:497,y:438,t:1526922669290};\\\", \\\"{x:498,y:438,t:1526922669307};\\\", \\\"{x:500,y:437,t:1526922669324};\\\", \\\"{x:501,y:437,t:1526922669376};\\\", \\\"{x:502,y:437,t:1526922669759};\\\", \\\"{x:504,y:437,t:1526922669772};\\\", \\\"{x:506,y:437,t:1526922669788};\\\", \\\"{x:510,y:437,t:1526922669805};\\\", \\\"{x:514,y:438,t:1526922669823};\\\", \\\"{x:517,y:439,t:1526922669839};\\\", \\\"{x:519,y:439,t:1526922669855};\\\", \\\"{x:521,y:439,t:1526922669872};\\\", \\\"{x:524,y:439,t:1526922669889};\\\", \\\"{x:528,y:439,t:1526922669905};\\\", \\\"{x:531,y:439,t:1526922669922};\\\", \\\"{x:535,y:440,t:1526922669939};\\\", \\\"{x:536,y:440,t:1526922669956};\\\", \\\"{x:539,y:440,t:1526922669971};\\\", \\\"{x:539,y:441,t:1526922669989};\\\", \\\"{x:541,y:441,t:1526922670006};\\\", \\\"{x:542,y:441,t:1526922670022};\\\", \\\"{x:545,y:441,t:1526922670038};\\\", \\\"{x:548,y:441,t:1526922670055};\\\", \\\"{x:552,y:441,t:1526922670072};\\\", \\\"{x:554,y:441,t:1526922670089};\\\", \\\"{x:555,y:441,t:1526922670111};\\\", \\\"{x:556,y:441,t:1526922670128};\\\", \\\"{x:557,y:441,t:1526922670144};\\\", \\\"{x:560,y:442,t:1526922670609};\\\", \\\"{x:563,y:444,t:1526922670621};\\\", \\\"{x:575,y:447,t:1526922670638};\\\", \\\"{x:593,y:451,t:1526922670655};\\\", \\\"{x:617,y:453,t:1526922670671};\\\", \\\"{x:659,y:459,t:1526922670688};\\\", \\\"{x:696,y:464,t:1526922670704};\\\", \\\"{x:727,y:464,t:1526922670721};\\\", \\\"{x:759,y:464,t:1526922670737};\\\", \\\"{x:792,y:464,t:1526922670754};\\\", \\\"{x:832,y:464,t:1526922670771};\\\", \\\"{x:868,y:464,t:1526922670787};\\\", \\\"{x:910,y:464,t:1526922670805};\\\", \\\"{x:949,y:464,t:1526922670821};\\\", \\\"{x:987,y:466,t:1526922670837};\\\", \\\"{x:1011,y:469,t:1526922670854};\\\", \\\"{x:1015,y:469,t:1526922670870};\\\", \\\"{x:1015,y:465,t:1526922671697};\\\", \\\"{x:1015,y:462,t:1526922671704};\\\", \\\"{x:1014,y:460,t:1526922671719};\\\", \\\"{x:1013,y:454,t:1526922671735};\\\", \\\"{x:1011,y:447,t:1526922671753};\\\", \\\"{x:1011,y:442,t:1526922671770};\\\", \\\"{x:1011,y:437,t:1526922671786};\\\", \\\"{x:1014,y:430,t:1526922671803};\\\", \\\"{x:1018,y:425,t:1526922671819};\\\", \\\"{x:1022,y:421,t:1526922671835};\\\", \\\"{x:1028,y:417,t:1526922671852};\\\", \\\"{x:1032,y:414,t:1526922671868};\\\", \\\"{x:1039,y:410,t:1526922671886};\\\", \\\"{x:1044,y:409,t:1526922671902};\\\", \\\"{x:1050,y:406,t:1526922671919};\\\", \\\"{x:1054,y:405,t:1526922671935};\\\", \\\"{x:1067,y:405,t:1526922671952};\\\", \\\"{x:1083,y:405,t:1526922671968};\\\", \\\"{x:1104,y:405,t:1526922671985};\\\", \\\"{x:1136,y:406,t:1526922672001};\\\", \\\"{x:1177,y:411,t:1526922672019};\\\", \\\"{x:1220,y:418,t:1526922672035};\\\", \\\"{x:1259,y:423,t:1526922672051};\\\", \\\"{x:1283,y:427,t:1526922672068};\\\", \\\"{x:1305,y:429,t:1526922672085};\\\", \\\"{x:1320,y:430,t:1526922672101};\\\", \\\"{x:1334,y:430,t:1526922672119};\\\", \\\"{x:1342,y:430,t:1526922672135};\\\", \\\"{x:1348,y:430,t:1526922672151};\\\", \\\"{x:1349,y:430,t:1526922672169};\\\", \\\"{x:1349,y:431,t:1526922672241};\\\", \\\"{x:1349,y:432,t:1526922672251};\\\", \\\"{x:1349,y:433,t:1526922672268};\\\", \\\"{x:1349,y:434,t:1526922672321};\\\", \\\"{x:1349,y:435,t:1526922672335};\\\", \\\"{x:1349,y:437,t:1526922672352};\\\", \\\"{x:1349,y:440,t:1526922672368};\\\", \\\"{x:1349,y:445,t:1526922672384};\\\", \\\"{x:1349,y:449,t:1526922672401};\\\", \\\"{x:1350,y:457,t:1526922672417};\\\", \\\"{x:1359,y:474,t:1526922672435};\\\", \\\"{x:1368,y:497,t:1526922672452};\\\", \\\"{x:1379,y:526,t:1526922672468};\\\", \\\"{x:1389,y:550,t:1526922672485};\\\", \\\"{x:1398,y:569,t:1526922672500};\\\", \\\"{x:1404,y:582,t:1526922672517};\\\", \\\"{x:1406,y:588,t:1526922672534};\\\", \\\"{x:1407,y:593,t:1526922672551};\\\", \\\"{x:1409,y:602,t:1526922672568};\\\", \\\"{x:1414,y:612,t:1526922672584};\\\", \\\"{x:1414,y:617,t:1526922672601};\\\", \\\"{x:1415,y:619,t:1526922672617};\\\", \\\"{x:1417,y:623,t:1526922672635};\\\", \\\"{x:1419,y:629,t:1526922672650};\\\", \\\"{x:1420,y:632,t:1526922672667};\\\", \\\"{x:1421,y:636,t:1526922672683};\\\", \\\"{x:1425,y:645,t:1526922672700};\\\", \\\"{x:1426,y:651,t:1526922672718};\\\", \\\"{x:1429,y:659,t:1526922672733};\\\", \\\"{x:1431,y:665,t:1526922672751};\\\", \\\"{x:1433,y:671,t:1526922672767};\\\", \\\"{x:1434,y:674,t:1526922672783};\\\", \\\"{x:1434,y:678,t:1526922672800};\\\", \\\"{x:1435,y:680,t:1526922672817};\\\", \\\"{x:1437,y:684,t:1526922672833};\\\", \\\"{x:1438,y:686,t:1526922672851};\\\", \\\"{x:1439,y:688,t:1526922672866};\\\", \\\"{x:1440,y:689,t:1526922672883};\\\", \\\"{x:1441,y:690,t:1526922672900};\\\", \\\"{x:1442,y:696,t:1526922672916};\\\", \\\"{x:1443,y:698,t:1526922672933};\\\", \\\"{x:1444,y:699,t:1526922672949};\\\", \\\"{x:1445,y:700,t:1526922672965};\\\", \\\"{x:1445,y:701,t:1526922673007};\\\", \\\"{x:1447,y:704,t:1526922673016};\\\", \\\"{x:1449,y:709,t:1526922673033};\\\", \\\"{x:1452,y:714,t:1526922673049};\\\", \\\"{x:1455,y:718,t:1526922673066};\\\", \\\"{x:1458,y:723,t:1526922673083};\\\", \\\"{x:1460,y:727,t:1526922673099};\\\", \\\"{x:1462,y:731,t:1526922673116};\\\", \\\"{x:1463,y:734,t:1526922673133};\\\", \\\"{x:1464,y:735,t:1526922673149};\\\", \\\"{x:1464,y:736,t:1526922673166};\\\", \\\"{x:1465,y:738,t:1526922673182};\\\", \\\"{x:1466,y:738,t:1526922673199};\\\", \\\"{x:1467,y:740,t:1526922673216};\\\", \\\"{x:1467,y:741,t:1526922673239};\\\", \\\"{x:1468,y:741,t:1526922673249};\\\", \\\"{x:1468,y:742,t:1526922673266};\\\", \\\"{x:1470,y:744,t:1526922673282};\\\", \\\"{x:1472,y:747,t:1526922673299};\\\", \\\"{x:1474,y:748,t:1526922673315};\\\", \\\"{x:1474,y:750,t:1526922673332};\\\", \\\"{x:1475,y:751,t:1526922673349};\\\", \\\"{x:1475,y:753,t:1526922673365};\\\", \\\"{x:1476,y:753,t:1526922673382};\\\", \\\"{x:1478,y:755,t:1526922673398};\\\", \\\"{x:1479,y:756,t:1526922673415};\\\", \\\"{x:1479,y:757,t:1526922673432};\\\", \\\"{x:1479,y:756,t:1526922673551};\\\", \\\"{x:1479,y:753,t:1526922673567};\\\", \\\"{x:1479,y:751,t:1526922673582};\\\", \\\"{x:1476,y:745,t:1526922673598};\\\", \\\"{x:1470,y:735,t:1526922673614};\\\", \\\"{x:1463,y:724,t:1526922673630};\\\", \\\"{x:1455,y:710,t:1526922673648};\\\", \\\"{x:1449,y:699,t:1526922673665};\\\", \\\"{x:1444,y:686,t:1526922673681};\\\", \\\"{x:1436,y:669,t:1526922673697};\\\", \\\"{x:1425,y:647,t:1526922673715};\\\", \\\"{x:1414,y:626,t:1526922673731};\\\", \\\"{x:1404,y:607,t:1526922673748};\\\", \\\"{x:1394,y:592,t:1526922673764};\\\", \\\"{x:1384,y:574,t:1526922673781};\\\", \\\"{x:1376,y:559,t:1526922673798};\\\", \\\"{x:1369,y:547,t:1526922673814};\\\", \\\"{x:1361,y:534,t:1526922673831};\\\", \\\"{x:1356,y:519,t:1526922673848};\\\", \\\"{x:1353,y:512,t:1526922673864};\\\", \\\"{x:1351,y:500,t:1526922673881};\\\", \\\"{x:1346,y:487,t:1526922673898};\\\", \\\"{x:1344,y:481,t:1526922673914};\\\", \\\"{x:1342,y:476,t:1526922673931};\\\", \\\"{x:1340,y:471,t:1526922673947};\\\", \\\"{x:1338,y:468,t:1526922673964};\\\", \\\"{x:1338,y:464,t:1526922673981};\\\", \\\"{x:1337,y:464,t:1526922673997};\\\", \\\"{x:1336,y:462,t:1526922674014};\\\", \\\"{x:1336,y:461,t:1526922674039};\\\", \\\"{x:1335,y:461,t:1526922674104};\\\", \\\"{x:1334,y:461,t:1526922674119};\\\", \\\"{x:1333,y:461,t:1526922674130};\\\", \\\"{x:1332,y:461,t:1526922674151};\\\", \\\"{x:1331,y:461,t:1526922674164};\\\", \\\"{x:1330,y:461,t:1526922674180};\\\", \\\"{x:1328,y:461,t:1526922674197};\\\", \\\"{x:1324,y:459,t:1526922674214};\\\", \\\"{x:1323,y:457,t:1526922674230};\\\", \\\"{x:1319,y:456,t:1526922674247};\\\", \\\"{x:1309,y:447,t:1526922674264};\\\", \\\"{x:1308,y:446,t:1526922674280};\\\", \\\"{x:1307,y:446,t:1526922674297};\\\", \\\"{x:1306,y:445,t:1526922674319};\\\", \\\"{x:1306,y:446,t:1526922674376};\\\", \\\"{x:1306,y:449,t:1526922674383};\\\", \\\"{x:1306,y:452,t:1526922674398};\\\", \\\"{x:1309,y:460,t:1526922674413};\\\", \\\"{x:1311,y:466,t:1526922674430};\\\", \\\"{x:1315,y:477,t:1526922674446};\\\", \\\"{x:1320,y:485,t:1526922674463};\\\", \\\"{x:1327,y:496,t:1526922674480};\\\", \\\"{x:1330,y:500,t:1526922674497};\\\", \\\"{x:1331,y:502,t:1526922674513};\\\", \\\"{x:1332,y:503,t:1526922674531};\\\", \\\"{x:1333,y:503,t:1526922674607};\\\", \\\"{x:1334,y:503,t:1526922674615};\\\", \\\"{x:1336,y:503,t:1526922674631};\\\", \\\"{x:1338,y:503,t:1526922674645};\\\", \\\"{x:1340,y:503,t:1526922674663};\\\", \\\"{x:1341,y:501,t:1526922674679};\\\", \\\"{x:1342,y:496,t:1526922674696};\\\", \\\"{x:1342,y:493,t:1526922674713};\\\", \\\"{x:1343,y:490,t:1526922674729};\\\", \\\"{x:1343,y:489,t:1526922674746};\\\", \\\"{x:1343,y:487,t:1526922674784};\\\", \\\"{x:1343,y:490,t:1526922674992};\\\", \\\"{x:1343,y:493,t:1526922675000};\\\", \\\"{x:1343,y:496,t:1526922675012};\\\", \\\"{x:1343,y:501,t:1526922675029};\\\", \\\"{x:1343,y:507,t:1526922675045};\\\", \\\"{x:1343,y:508,t:1526922675062};\\\", \\\"{x:1343,y:510,t:1526922675079};\\\", \\\"{x:1345,y:514,t:1526922675095};\\\", \\\"{x:1345,y:516,t:1526922675112};\\\", \\\"{x:1347,y:517,t:1526922675128};\\\", \\\"{x:1347,y:518,t:1526922675145};\\\", \\\"{x:1348,y:518,t:1526922675168};\\\", \\\"{x:1348,y:520,t:1526922675183};\\\", \\\"{x:1350,y:522,t:1526922675196};\\\", \\\"{x:1351,y:523,t:1526922675212};\\\", \\\"{x:1352,y:525,t:1526922675228};\\\", \\\"{x:1354,y:526,t:1526922675245};\\\", \\\"{x:1355,y:529,t:1526922675261};\\\", \\\"{x:1357,y:530,t:1526922675278};\\\", \\\"{x:1357,y:532,t:1526922675295};\\\", \\\"{x:1358,y:532,t:1526922675312};\\\", \\\"{x:1359,y:535,t:1526922675329};\\\", \\\"{x:1360,y:538,t:1526922675345};\\\", \\\"{x:1361,y:542,t:1526922675362};\\\", \\\"{x:1361,y:545,t:1526922675378};\\\", \\\"{x:1362,y:545,t:1526922675408};\\\", \\\"{x:1362,y:546,t:1526922675687};\\\", \\\"{x:1365,y:550,t:1526922675695};\\\", \\\"{x:1368,y:553,t:1526922675711};\\\", \\\"{x:1372,y:558,t:1526922675727};\\\", \\\"{x:1381,y:570,t:1526922675744};\\\", \\\"{x:1384,y:574,t:1526922675760};\\\", \\\"{x:1386,y:580,t:1526922675777};\\\", \\\"{x:1390,y:585,t:1526922675794};\\\", \\\"{x:1390,y:586,t:1526922675810};\\\", \\\"{x:1391,y:586,t:1526922675827};\\\", \\\"{x:1391,y:588,t:1526922675844};\\\", \\\"{x:1391,y:589,t:1526922675863};\\\", \\\"{x:1392,y:590,t:1526922675878};\\\", \\\"{x:1392,y:591,t:1526922675895};\\\", \\\"{x:1393,y:592,t:1526922675911};\\\", \\\"{x:1393,y:594,t:1526922675943};\\\", \\\"{x:1394,y:595,t:1526922675960};\\\", \\\"{x:1394,y:598,t:1526922675977};\\\", \\\"{x:1396,y:601,t:1526922675993};\\\", \\\"{x:1396,y:603,t:1526922676010};\\\", \\\"{x:1396,y:604,t:1526922676026};\\\", \\\"{x:1396,y:605,t:1526922676043};\\\", \\\"{x:1397,y:606,t:1526922676079};\\\", \\\"{x:1397,y:608,t:1526922676671};\\\", \\\"{x:1399,y:612,t:1526922676679};\\\", \\\"{x:1404,y:617,t:1526922676692};\\\", \\\"{x:1407,y:623,t:1526922676708};\\\", \\\"{x:1410,y:628,t:1526922676725};\\\", \\\"{x:1414,y:633,t:1526922676742};\\\", \\\"{x:1417,y:637,t:1526922676758};\\\", \\\"{x:1419,y:641,t:1526922676775};\\\", \\\"{x:1421,y:643,t:1526922676791};\\\", \\\"{x:1421,y:644,t:1526922676808};\\\", \\\"{x:1422,y:645,t:1526922676825};\\\", \\\"{x:1422,y:646,t:1526922676842};\\\", \\\"{x:1423,y:648,t:1526922676858};\\\", \\\"{x:1424,y:651,t:1526922676875};\\\", \\\"{x:1424,y:652,t:1526922676895};\\\", \\\"{x:1424,y:653,t:1526922676908};\\\", \\\"{x:1426,y:654,t:1526922676925};\\\", \\\"{x:1426,y:656,t:1526922676941};\\\", \\\"{x:1427,y:657,t:1526922676958};\\\", \\\"{x:1427,y:659,t:1526922676975};\\\", \\\"{x:1427,y:660,t:1526922676992};\\\", \\\"{x:1427,y:662,t:1526922677008};\\\", \\\"{x:1429,y:663,t:1526922677024};\\\", \\\"{x:1429,y:665,t:1526922677042};\\\", \\\"{x:1430,y:666,t:1526922677058};\\\", \\\"{x:1430,y:667,t:1526922677074};\\\", \\\"{x:1430,y:668,t:1526922677092};\\\", \\\"{x:1430,y:669,t:1526922677111};\\\", \\\"{x:1432,y:670,t:1526922677127};\\\", \\\"{x:1432,y:671,t:1526922677143};\\\", \\\"{x:1432,y:672,t:1526922677159};\\\", \\\"{x:1432,y:673,t:1526922677175};\\\", \\\"{x:1432,y:674,t:1526922677191};\\\", \\\"{x:1432,y:675,t:1526922677223};\\\", \\\"{x:1433,y:675,t:1526922677231};\\\", \\\"{x:1433,y:677,t:1526922677247};\\\", \\\"{x:1435,y:679,t:1526922677569};\\\", \\\"{x:1435,y:680,t:1526922677576};\\\", \\\"{x:1436,y:681,t:1526922677590};\\\", \\\"{x:1436,y:683,t:1526922677607};\\\", \\\"{x:1437,y:685,t:1526922677624};\\\", \\\"{x:1438,y:686,t:1526922677767};\\\", \\\"{x:1439,y:686,t:1526922685752};\\\", \\\"{x:1440,y:685,t:1526922685793};\\\", \\\"{x:1439,y:684,t:1526922710088};\\\", \\\"{x:1429,y:677,t:1526922710095};\\\", \\\"{x:1414,y:668,t:1526922710108};\\\", \\\"{x:1384,y:664,t:1526922710125};\\\", \\\"{x:1337,y:664,t:1526922710141};\\\", \\\"{x:1240,y:664,t:1526922710157};\\\", \\\"{x:1080,y:664,t:1526922710174};\\\", \\\"{x:818,y:708,t:1526922710190};\\\", \\\"{x:652,y:753,t:1526922710207};\\\", \\\"{x:478,y:807,t:1526922710224};\\\", \\\"{x:333,y:833,t:1526922710241};\\\", \\\"{x:230,y:853,t:1526922710256};\\\", \\\"{x:190,y:860,t:1526922710273};\\\", \\\"{x:182,y:862,t:1526922710290};\\\", \\\"{x:183,y:856,t:1526922710415};\\\", \\\"{x:195,y:843,t:1526922710423};\\\", \\\"{x:209,y:826,t:1526922710440};\\\", \\\"{x:218,y:818,t:1526922710457};\\\", \\\"{x:227,y:809,t:1526922710473};\\\", \\\"{x:240,y:792,t:1526922710490};\\\", \\\"{x:266,y:764,t:1526922710507};\\\", \\\"{x:312,y:718,t:1526922710524};\\\", \\\"{x:366,y:662,t:1526922710540};\\\", \\\"{x:409,y:617,t:1526922710557};\\\", \\\"{x:459,y:576,t:1526922710573};\\\", \\\"{x:508,y:536,t:1526922710590};\\\", \\\"{x:534,y:513,t:1526922710607};\\\", \\\"{x:539,y:496,t:1526922710623};\\\", \\\"{x:539,y:488,t:1526922710640};\\\", \\\"{x:527,y:479,t:1526922710659};\\\", \\\"{x:495,y:473,t:1526922710676};\\\", \\\"{x:429,y:460,t:1526922710693};\\\", \\\"{x:368,y:449,t:1526922710710};\\\", \\\"{x:329,y:446,t:1526922710726};\\\", \\\"{x:281,y:446,t:1526922710743};\\\", \\\"{x:252,y:449,t:1526922710759};\\\", \\\"{x:227,y:459,t:1526922710776};\\\", \\\"{x:201,y:470,t:1526922710793};\\\", \\\"{x:181,y:479,t:1526922710809};\\\", \\\"{x:169,y:486,t:1526922710827};\\\", \\\"{x:159,y:491,t:1526922710843};\\\", \\\"{x:152,y:494,t:1526922710860};\\\", \\\"{x:148,y:497,t:1526922710877};\\\", \\\"{x:146,y:502,t:1526922710894};\\\", \\\"{x:146,y:509,t:1526922710911};\\\", \\\"{x:146,y:515,t:1526922710926};\\\", \\\"{x:150,y:519,t:1526922710943};\\\", \\\"{x:167,y:523,t:1526922710960};\\\", \\\"{x:185,y:523,t:1526922710976};\\\", \\\"{x:209,y:523,t:1526922710993};\\\", \\\"{x:235,y:523,t:1526922711010};\\\", \\\"{x:283,y:523,t:1526922711027};\\\", \\\"{x:336,y:523,t:1526922711043};\\\", \\\"{x:392,y:523,t:1526922711061};\\\", \\\"{x:442,y:523,t:1526922711078};\\\", \\\"{x:484,y:523,t:1526922711093};\\\", \\\"{x:532,y:523,t:1526922711111};\\\", \\\"{x:564,y:523,t:1526922711126};\\\", \\\"{x:608,y:523,t:1526922711144};\\\", \\\"{x:621,y:524,t:1526922711160};\\\", \\\"{x:626,y:527,t:1526922711177};\\\", \\\"{x:628,y:530,t:1526922711193};\\\", \\\"{x:632,y:537,t:1526922711210};\\\", \\\"{x:639,y:545,t:1526922711228};\\\", \\\"{x:646,y:553,t:1526922711243};\\\", \\\"{x:654,y:558,t:1526922711260};\\\", \\\"{x:669,y:563,t:1526922711276};\\\", \\\"{x:687,y:569,t:1526922711293};\\\", \\\"{x:709,y:571,t:1526922711310};\\\", \\\"{x:736,y:571,t:1526922711328};\\\", \\\"{x:784,y:558,t:1526922711343};\\\", \\\"{x:817,y:543,t:1526922711359};\\\", \\\"{x:841,y:533,t:1526922711378};\\\", \\\"{x:860,y:523,t:1526922711395};\\\", \\\"{x:877,y:511,t:1526922711410};\\\", \\\"{x:888,y:504,t:1526922711427};\\\", \\\"{x:890,y:501,t:1526922711445};\\\", \\\"{x:892,y:499,t:1526922711460};\\\", \\\"{x:890,y:499,t:1526922711534};\\\", \\\"{x:885,y:501,t:1526922711544};\\\", \\\"{x:872,y:510,t:1526922711560};\\\", \\\"{x:863,y:517,t:1526922711577};\\\", \\\"{x:856,y:521,t:1526922711594};\\\", \\\"{x:853,y:524,t:1526922711609};\\\", \\\"{x:850,y:526,t:1526922711627};\\\", \\\"{x:849,y:527,t:1526922711752};\\\", \\\"{x:848,y:527,t:1526922711783};\\\", \\\"{x:845,y:531,t:1526922711991};\\\", \\\"{x:840,y:538,t:1526922711998};\\\", \\\"{x:833,y:545,t:1526922712010};\\\", \\\"{x:813,y:565,t:1526922712027};\\\", \\\"{x:786,y:585,t:1526922712044};\\\", \\\"{x:766,y:602,t:1526922712060};\\\", \\\"{x:743,y:618,t:1526922712077};\\\", \\\"{x:729,y:634,t:1526922712094};\\\", \\\"{x:712,y:659,t:1526922712110};\\\", \\\"{x:701,y:673,t:1526922712127};\\\", \\\"{x:695,y:680,t:1526922712143};\\\", \\\"{x:689,y:685,t:1526922712161};\\\", \\\"{x:681,y:690,t:1526922712177};\\\", \\\"{x:673,y:697,t:1526922712194};\\\", \\\"{x:661,y:703,t:1526922712211};\\\", \\\"{x:648,y:708,t:1526922712227};\\\", \\\"{x:635,y:711,t:1526922712244};\\\", \\\"{x:624,y:713,t:1526922712261};\\\", \\\"{x:612,y:715,t:1526922712275};\\\", \\\"{x:603,y:715,t:1526922712292};\\\", \\\"{x:588,y:715,t:1526922712309};\\\", \\\"{x:582,y:713,t:1526922712326};\\\", \\\"{x:577,y:710,t:1526922712342};\\\", \\\"{x:572,y:705,t:1526922712360};\\\", \\\"{x:566,y:697,t:1526922712377};\\\", \\\"{x:561,y:689,t:1526922712393};\\\", \\\"{x:559,y:686,t:1526922712409};\\\", \\\"{x:558,y:685,t:1526922712427};\\\", \\\"{x:557,y:685,t:1526922712442};\\\", \\\"{x:557,y:684,t:1526922712460};\\\", \\\"{x:556,y:684,t:1526922712476};\\\", \\\"{x:554,y:683,t:1526922712493};\\\", \\\"{x:553,y:683,t:1526922712510};\\\", \\\"{x:552,y:682,t:1526922712527};\\\" ] }, { \\\"rt\\\": 11359, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 310872, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:680,t:1526922715933};\\\", \\\"{x:550,y:665,t:1526922715953};\\\", \\\"{x:549,y:665,t:1526922715966};\\\", \\\"{x:550,y:664,t:1526922716685};\\\", \\\"{x:552,y:663,t:1526922716696};\\\", \\\"{x:554,y:661,t:1526922716713};\\\", \\\"{x:556,y:660,t:1526922716730};\\\", \\\"{x:559,y:658,t:1526922716746};\\\", \\\"{x:562,y:657,t:1526922716763};\\\", \\\"{x:566,y:655,t:1526922716780};\\\", \\\"{x:568,y:654,t:1526922716796};\\\", \\\"{x:569,y:654,t:1526922716829};\\\", \\\"{x:570,y:653,t:1526922717677};\\\", \\\"{x:571,y:652,t:1526922719165};\\\", \\\"{x:574,y:646,t:1526922719182};\\\", \\\"{x:591,y:630,t:1526922719199};\\\", \\\"{x:609,y:615,t:1526922719216};\\\", \\\"{x:625,y:605,t:1526922719232};\\\", \\\"{x:644,y:592,t:1526922719249};\\\", \\\"{x:663,y:581,t:1526922719266};\\\", \\\"{x:683,y:569,t:1526922719283};\\\", \\\"{x:706,y:558,t:1526922719298};\\\", \\\"{x:727,y:549,t:1526922719316};\\\", \\\"{x:748,y:540,t:1526922719331};\\\", \\\"{x:781,y:527,t:1526922719348};\\\", \\\"{x:804,y:520,t:1526922719364};\\\", \\\"{x:829,y:514,t:1526922719381};\\\", \\\"{x:853,y:509,t:1526922719399};\\\", \\\"{x:876,y:507,t:1526922719414};\\\", \\\"{x:902,y:504,t:1526922719431};\\\", \\\"{x:931,y:504,t:1526922719448};\\\", \\\"{x:955,y:501,t:1526922719464};\\\", \\\"{x:981,y:501,t:1526922719482};\\\", \\\"{x:1008,y:501,t:1526922719499};\\\", \\\"{x:1034,y:501,t:1526922719515};\\\", \\\"{x:1056,y:501,t:1526922719532};\\\", \\\"{x:1075,y:500,t:1526922719548};\\\", \\\"{x:1082,y:500,t:1526922719565};\\\", \\\"{x:1083,y:499,t:1526922719582};\\\", \\\"{x:1084,y:499,t:1526922719598};\\\", \\\"{x:1085,y:498,t:1526922719645};\\\", \\\"{x:1086,y:498,t:1526922719653};\\\", \\\"{x:1088,y:498,t:1526922719665};\\\", \\\"{x:1093,y:498,t:1526922719681};\\\", \\\"{x:1101,y:498,t:1526922719699};\\\", \\\"{x:1114,y:498,t:1526922719716};\\\", \\\"{x:1126,y:498,t:1526922719731};\\\", \\\"{x:1157,y:502,t:1526922719748};\\\", \\\"{x:1180,y:507,t:1526922719765};\\\", \\\"{x:1203,y:510,t:1526922719781};\\\", \\\"{x:1224,y:512,t:1526922719799};\\\", \\\"{x:1241,y:515,t:1526922719816};\\\", \\\"{x:1256,y:516,t:1526922719832};\\\", \\\"{x:1270,y:516,t:1526922719848};\\\", \\\"{x:1282,y:516,t:1526922719866};\\\", \\\"{x:1295,y:516,t:1526922719883};\\\", \\\"{x:1310,y:516,t:1526922719899};\\\", \\\"{x:1327,y:517,t:1526922719916};\\\", \\\"{x:1353,y:517,t:1526922719933};\\\", \\\"{x:1369,y:517,t:1526922719949};\\\", \\\"{x:1381,y:517,t:1526922719966};\\\", \\\"{x:1394,y:517,t:1526922719983};\\\", \\\"{x:1406,y:517,t:1526922719999};\\\", \\\"{x:1416,y:517,t:1526922720015};\\\", \\\"{x:1425,y:517,t:1526922720032};\\\", \\\"{x:1433,y:517,t:1526922720049};\\\", \\\"{x:1439,y:517,t:1526922720066};\\\", \\\"{x:1443,y:517,t:1526922720082};\\\", \\\"{x:1446,y:517,t:1526922720100};\\\", \\\"{x:1448,y:517,t:1526922720116};\\\", \\\"{x:1452,y:517,t:1526922720133};\\\", \\\"{x:1456,y:517,t:1526922720150};\\\", \\\"{x:1460,y:517,t:1526922720166};\\\", \\\"{x:1463,y:517,t:1526922720183};\\\", \\\"{x:1465,y:517,t:1526922720200};\\\", \\\"{x:1466,y:517,t:1526922720215};\\\", \\\"{x:1466,y:518,t:1526922720278};\\\", \\\"{x:1467,y:519,t:1526922720301};\\\", \\\"{x:1465,y:521,t:1526922720317};\\\", \\\"{x:1462,y:521,t:1526922720333};\\\", \\\"{x:1460,y:524,t:1526922720350};\\\", \\\"{x:1458,y:524,t:1526922720367};\\\", \\\"{x:1457,y:524,t:1526922720405};\\\", \\\"{x:1455,y:525,t:1526922720421};\\\", \\\"{x:1453,y:525,t:1526922720445};\\\", \\\"{x:1451,y:525,t:1526922720454};\\\", \\\"{x:1449,y:525,t:1526922720467};\\\", \\\"{x:1448,y:525,t:1526922720483};\\\", \\\"{x:1445,y:525,t:1526922720500};\\\", \\\"{x:1442,y:525,t:1526922720517};\\\", \\\"{x:1439,y:525,t:1526922721316};\\\", \\\"{x:1431,y:527,t:1526922721324};\\\", \\\"{x:1421,y:528,t:1526922721335};\\\", \\\"{x:1392,y:530,t:1526922721350};\\\", \\\"{x:1342,y:530,t:1526922721367};\\\", \\\"{x:1270,y:530,t:1526922721384};\\\", \\\"{x:1195,y:530,t:1526922721400};\\\", \\\"{x:1126,y:523,t:1526922721417};\\\", \\\"{x:1035,y:515,t:1526922721435};\\\", \\\"{x:940,y:513,t:1526922721451};\\\", \\\"{x:833,y:501,t:1526922721468};\\\", \\\"{x:739,y:494,t:1526922721484};\\\", \\\"{x:708,y:494,t:1526922721500};\\\", \\\"{x:646,y:506,t:1526922721516};\\\", \\\"{x:620,y:515,t:1526922721534};\\\", \\\"{x:599,y:529,t:1526922721550};\\\", \\\"{x:578,y:547,t:1526922721567};\\\", \\\"{x:563,y:565,t:1526922721584};\\\", \\\"{x:547,y:584,t:1526922721599};\\\", \\\"{x:535,y:598,t:1526922721617};\\\", \\\"{x:526,y:607,t:1526922721633};\\\", \\\"{x:518,y:613,t:1526922721649};\\\", \\\"{x:512,y:618,t:1526922721666};\\\", \\\"{x:505,y:620,t:1526922721683};\\\", \\\"{x:498,y:623,t:1526922721700};\\\", \\\"{x:480,y:623,t:1526922721716};\\\", \\\"{x:467,y:623,t:1526922721733};\\\", \\\"{x:447,y:616,t:1526922721750};\\\", \\\"{x:423,y:603,t:1526922721767};\\\", \\\"{x:391,y:582,t:1526922721783};\\\", \\\"{x:372,y:565,t:1526922721801};\\\", \\\"{x:355,y:547,t:1526922721817};\\\", \\\"{x:340,y:528,t:1526922721834};\\\", \\\"{x:328,y:510,t:1526922721850};\\\", \\\"{x:316,y:494,t:1526922721867};\\\", \\\"{x:313,y:487,t:1526922721883};\\\", \\\"{x:311,y:482,t:1526922721900};\\\", \\\"{x:311,y:480,t:1526922721917};\\\", \\\"{x:311,y:477,t:1526922721933};\\\", \\\"{x:311,y:475,t:1526922721951};\\\", \\\"{x:310,y:473,t:1526922721967};\\\", \\\"{x:310,y:470,t:1526922721985};\\\", \\\"{x:310,y:469,t:1526922722001};\\\", \\\"{x:309,y:469,t:1526922722037};\\\", \\\"{x:306,y:469,t:1526922722049};\\\", \\\"{x:295,y:471,t:1526922722066};\\\", \\\"{x:277,y:478,t:1526922722085};\\\", \\\"{x:243,y:494,t:1526922722102};\\\", \\\"{x:221,y:509,t:1526922722116};\\\", \\\"{x:207,y:516,t:1526922722134};\\\", \\\"{x:195,y:526,t:1526922722150};\\\", \\\"{x:188,y:532,t:1526922722166};\\\", \\\"{x:183,y:536,t:1526922722183};\\\", \\\"{x:178,y:539,t:1526922722200};\\\", \\\"{x:176,y:540,t:1526922722216};\\\", \\\"{x:175,y:541,t:1526922722233};\\\", \\\"{x:175,y:542,t:1526922722250};\\\", \\\"{x:176,y:541,t:1526922722284};\\\", \\\"{x:198,y:530,t:1526922722300};\\\", \\\"{x:225,y:522,t:1526922722316};\\\", \\\"{x:262,y:516,t:1526922722334};\\\", \\\"{x:315,y:508,t:1526922722351};\\\", \\\"{x:370,y:503,t:1526922722367};\\\", \\\"{x:430,y:497,t:1526922722383};\\\", \\\"{x:491,y:492,t:1526922722400};\\\", \\\"{x:546,y:486,t:1526922722418};\\\", \\\"{x:583,y:480,t:1526922722433};\\\", \\\"{x:612,y:476,t:1526922722450};\\\", \\\"{x:630,y:473,t:1526922722468};\\\", \\\"{x:639,y:471,t:1526922722484};\\\", \\\"{x:646,y:468,t:1526922722500};\\\", \\\"{x:648,y:467,t:1526922722518};\\\", \\\"{x:650,y:466,t:1526922722533};\\\", \\\"{x:652,y:465,t:1526922722550};\\\", \\\"{x:656,y:462,t:1526922722568};\\\", \\\"{x:658,y:459,t:1526922722583};\\\", \\\"{x:660,y:458,t:1526922722600};\\\", \\\"{x:662,y:456,t:1526922722617};\\\", \\\"{x:662,y:454,t:1526922722635};\\\", \\\"{x:662,y:453,t:1526922722660};\\\", \\\"{x:661,y:453,t:1526922722701};\\\", \\\"{x:659,y:453,t:1526922722718};\\\", \\\"{x:658,y:453,t:1526922722735};\\\", \\\"{x:654,y:453,t:1526922722752};\\\", \\\"{x:650,y:453,t:1526922722768};\\\", \\\"{x:645,y:453,t:1526922722784};\\\", \\\"{x:640,y:453,t:1526922722803};\\\", \\\"{x:634,y:454,t:1526922722819};\\\", \\\"{x:630,y:454,t:1526922722835};\\\", \\\"{x:628,y:454,t:1526922722851};\\\", \\\"{x:627,y:454,t:1526922722868};\\\", \\\"{x:626,y:454,t:1526922722885};\\\", \\\"{x:624,y:454,t:1526922722981};\\\", \\\"{x:623,y:454,t:1526922722988};\\\", \\\"{x:620,y:454,t:1526922723001};\\\", \\\"{x:618,y:454,t:1526922723018};\\\", \\\"{x:617,y:453,t:1526922723034};\\\", \\\"{x:615,y:453,t:1526922723050};\\\", \\\"{x:613,y:452,t:1526922723093};\\\", \\\"{x:609,y:453,t:1526922723268};\\\", \\\"{x:599,y:461,t:1526922723284};\\\", \\\"{x:583,y:471,t:1526922723301};\\\", \\\"{x:560,y:485,t:1526922723318};\\\", \\\"{x:531,y:505,t:1526922723335};\\\", \\\"{x:496,y:527,t:1526922723352};\\\", \\\"{x:471,y:541,t:1526922723367};\\\", \\\"{x:452,y:553,t:1526922723385};\\\", \\\"{x:435,y:566,t:1526922723401};\\\", \\\"{x:419,y:578,t:1526922723417};\\\", \\\"{x:411,y:585,t:1526922723434};\\\", \\\"{x:400,y:590,t:1526922723452};\\\", \\\"{x:380,y:597,t:1526922723468};\\\", \\\"{x:364,y:600,t:1526922723484};\\\", \\\"{x:348,y:600,t:1526922723501};\\\", \\\"{x:326,y:600,t:1526922723517};\\\", \\\"{x:303,y:600,t:1526922723534};\\\", \\\"{x:281,y:600,t:1526922723551};\\\", \\\"{x:260,y:595,t:1526922723568};\\\", \\\"{x:242,y:589,t:1526922723584};\\\", \\\"{x:226,y:580,t:1526922723603};\\\", \\\"{x:208,y:569,t:1526922723619};\\\", \\\"{x:192,y:557,t:1526922723634};\\\", \\\"{x:181,y:549,t:1526922723652};\\\", \\\"{x:172,y:542,t:1526922723668};\\\", \\\"{x:170,y:538,t:1526922723685};\\\", \\\"{x:169,y:537,t:1526922723702};\\\", \\\"{x:169,y:536,t:1526922723731};\\\", \\\"{x:169,y:535,t:1526922723740};\\\", \\\"{x:169,y:534,t:1526922723752};\\\", \\\"{x:169,y:533,t:1526922723772};\\\", \\\"{x:169,y:532,t:1526922723788};\\\", \\\"{x:170,y:532,t:1526922723802};\\\", \\\"{x:178,y:531,t:1526922723817};\\\", \\\"{x:200,y:531,t:1526922723835};\\\", \\\"{x:229,y:531,t:1526922723851};\\\", \\\"{x:306,y:531,t:1526922723869};\\\", \\\"{x:386,y:531,t:1526922723885};\\\", \\\"{x:470,y:531,t:1526922723902};\\\", \\\"{x:550,y:531,t:1526922723919};\\\", \\\"{x:624,y:527,t:1526922723935};\\\", \\\"{x:688,y:519,t:1526922723952};\\\", \\\"{x:728,y:511,t:1526922723969};\\\", \\\"{x:760,y:502,t:1526922723985};\\\", \\\"{x:787,y:499,t:1526922724002};\\\", \\\"{x:810,y:491,t:1526922724018};\\\", \\\"{x:828,y:488,t:1526922724035};\\\", \\\"{x:843,y:484,t:1526922724051};\\\", \\\"{x:872,y:482,t:1526922724068};\\\", \\\"{x:885,y:480,t:1526922724085};\\\", \\\"{x:893,y:479,t:1526922724102};\\\", \\\"{x:896,y:479,t:1526922724118};\\\", \\\"{x:897,y:479,t:1526922724134};\\\", \\\"{x:896,y:479,t:1526922724213};\\\", \\\"{x:894,y:481,t:1526922724220};\\\", \\\"{x:892,y:482,t:1526922724235};\\\", \\\"{x:889,y:484,t:1526922724252};\\\", \\\"{x:877,y:492,t:1526922724269};\\\", \\\"{x:871,y:493,t:1526922724284};\\\", \\\"{x:864,y:496,t:1526922724302};\\\", \\\"{x:860,y:497,t:1526922724318};\\\", \\\"{x:855,y:497,t:1526922724335};\\\", \\\"{x:853,y:497,t:1526922724353};\\\", \\\"{x:849,y:497,t:1526922724369};\\\", \\\"{x:847,y:497,t:1526922724389};\\\", \\\"{x:845,y:496,t:1526922724402};\\\", \\\"{x:844,y:495,t:1526922724418};\\\", \\\"{x:841,y:493,t:1526922724436};\\\", \\\"{x:839,y:491,t:1526922724452};\\\", \\\"{x:835,y:490,t:1526922724468};\\\", \\\"{x:833,y:489,t:1526922724486};\\\", \\\"{x:832,y:489,t:1526922724692};\\\", \\\"{x:829,y:494,t:1526922724702};\\\", \\\"{x:820,y:521,t:1526922724719};\\\", \\\"{x:808,y:548,t:1526922724736};\\\", \\\"{x:787,y:586,t:1526922724752};\\\", \\\"{x:761,y:627,t:1526922724768};\\\", \\\"{x:732,y:662,t:1526922724786};\\\", \\\"{x:712,y:682,t:1526922724803};\\\", \\\"{x:694,y:696,t:1526922724819};\\\", \\\"{x:681,y:708,t:1526922724836};\\\", \\\"{x:670,y:715,t:1526922724852};\\\", \\\"{x:665,y:717,t:1526922724869};\\\", \\\"{x:661,y:718,t:1526922724886};\\\", \\\"{x:656,y:720,t:1526922724902};\\\", \\\"{x:652,y:720,t:1526922724920};\\\", \\\"{x:641,y:720,t:1526922724936};\\\", \\\"{x:630,y:720,t:1526922724952};\\\", \\\"{x:615,y:720,t:1526922724969};\\\", \\\"{x:600,y:714,t:1526922724986};\\\", \\\"{x:588,y:709,t:1526922725002};\\\", \\\"{x:574,y:701,t:1526922725020};\\\", \\\"{x:564,y:693,t:1526922725036};\\\", \\\"{x:548,y:680,t:1526922725052};\\\", \\\"{x:543,y:676,t:1526922725070};\\\", \\\"{x:540,y:674,t:1526922725086};\\\", \\\"{x:537,y:674,t:1526922725103};\\\", \\\"{x:534,y:674,t:1526922725119};\\\", \\\"{x:533,y:674,t:1526922725141};\\\", \\\"{x:532,y:674,t:1526922725152};\\\", \\\"{x:531,y:675,t:1526922725908};\\\", \\\"{x:533,y:675,t:1526922725940};\\\", \\\"{x:537,y:674,t:1526922725954};\\\", \\\"{x:545,y:670,t:1526922725970};\\\", \\\"{x:554,y:667,t:1526922725986};\\\", \\\"{x:565,y:661,t:1526922726003};\\\", \\\"{x:574,y:657,t:1526922726020};\\\", \\\"{x:578,y:654,t:1526922726036};\\\" ] }, { \\\"rt\\\": 24673, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 337057, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:653,t:1526922728261};\\\", \\\"{x:578,y:645,t:1526922728272};\\\", \\\"{x:569,y:603,t:1526922728288};\\\", \\\"{x:551,y:544,t:1526922728305};\\\", \\\"{x:534,y:505,t:1526922728321};\\\", \\\"{x:522,y:478,t:1526922728339};\\\", \\\"{x:508,y:454,t:1526922728355};\\\", \\\"{x:493,y:434,t:1526922728372};\\\", \\\"{x:485,y:428,t:1526922728389};\\\", \\\"{x:477,y:424,t:1526922728405};\\\", \\\"{x:468,y:418,t:1526922728422};\\\", \\\"{x:459,y:415,t:1526922728438};\\\", \\\"{x:443,y:407,t:1526922728455};\\\", \\\"{x:422,y:398,t:1526922728472};\\\", \\\"{x:406,y:396,t:1526922728489};\\\", \\\"{x:401,y:394,t:1526922728506};\\\", \\\"{x:398,y:394,t:1526922728522};\\\", \\\"{x:396,y:394,t:1526922728548};\\\", \\\"{x:395,y:394,t:1526922728580};\\\", \\\"{x:394,y:395,t:1526922728604};\\\", \\\"{x:394,y:396,t:1526922728644};\\\", \\\"{x:394,y:397,t:1526922728656};\\\", \\\"{x:394,y:400,t:1526922728672};\\\", \\\"{x:394,y:403,t:1526922728689};\\\", \\\"{x:394,y:405,t:1526922728707};\\\", \\\"{x:394,y:409,t:1526922728722};\\\", \\\"{x:394,y:411,t:1526922728740};\\\", \\\"{x:394,y:416,t:1526922728756};\\\", \\\"{x:394,y:417,t:1526922728773};\\\", \\\"{x:394,y:419,t:1526922728789};\\\", \\\"{x:394,y:420,t:1526922728807};\\\", \\\"{x:395,y:422,t:1526922728824};\\\", \\\"{x:396,y:423,t:1526922728840};\\\", \\\"{x:397,y:426,t:1526922728857};\\\", \\\"{x:398,y:427,t:1526922728884};\\\", \\\"{x:398,y:428,t:1526922728965};\\\", \\\"{x:399,y:428,t:1526922729037};\\\", \\\"{x:401,y:429,t:1526922729061};\\\", \\\"{x:401,y:430,t:1526922729077};\\\", \\\"{x:402,y:430,t:1526922729091};\\\", \\\"{x:404,y:432,t:1526922729108};\\\", \\\"{x:409,y:434,t:1526922729126};\\\", \\\"{x:413,y:435,t:1526922729141};\\\", \\\"{x:423,y:436,t:1526922729156};\\\", \\\"{x:434,y:436,t:1526922729173};\\\", \\\"{x:444,y:436,t:1526922729190};\\\", \\\"{x:451,y:436,t:1526922729206};\\\", \\\"{x:455,y:436,t:1526922729222};\\\", \\\"{x:467,y:436,t:1526922729240};\\\", \\\"{x:479,y:436,t:1526922729256};\\\", \\\"{x:492,y:436,t:1526922729273};\\\", \\\"{x:507,y:436,t:1526922729290};\\\", \\\"{x:521,y:436,t:1526922729306};\\\", \\\"{x:532,y:436,t:1526922729323};\\\", \\\"{x:543,y:436,t:1526922729339};\\\", \\\"{x:551,y:436,t:1526922729356};\\\", \\\"{x:562,y:436,t:1526922729372};\\\", \\\"{x:573,y:436,t:1526922729390};\\\", \\\"{x:584,y:436,t:1526922729406};\\\", \\\"{x:599,y:436,t:1526922729423};\\\", \\\"{x:618,y:436,t:1526922729440};\\\", \\\"{x:636,y:436,t:1526922729456};\\\", \\\"{x:651,y:437,t:1526922729473};\\\", \\\"{x:661,y:438,t:1526922729490};\\\", \\\"{x:670,y:439,t:1526922729506};\\\", \\\"{x:675,y:440,t:1526922729523};\\\", \\\"{x:679,y:440,t:1526922729540};\\\", \\\"{x:680,y:440,t:1526922729556};\\\", \\\"{x:683,y:440,t:1526922729573};\\\", \\\"{x:685,y:441,t:1526922729590};\\\", \\\"{x:686,y:441,t:1526922729606};\\\", \\\"{x:689,y:441,t:1526922729623};\\\", \\\"{x:691,y:442,t:1526922729640};\\\", \\\"{x:694,y:444,t:1526922729657};\\\", \\\"{x:697,y:444,t:1526922729673};\\\", \\\"{x:699,y:444,t:1526922729690};\\\", \\\"{x:701,y:444,t:1526922729706};\\\", \\\"{x:703,y:445,t:1526922729723};\\\", \\\"{x:707,y:445,t:1526922730804};\\\", \\\"{x:715,y:445,t:1526922730812};\\\", \\\"{x:726,y:445,t:1526922730824};\\\", \\\"{x:750,y:445,t:1526922730841};\\\", \\\"{x:776,y:445,t:1526922730856};\\\", \\\"{x:803,y:445,t:1526922730873};\\\", \\\"{x:826,y:445,t:1526922730891};\\\", \\\"{x:844,y:445,t:1526922730907};\\\", \\\"{x:864,y:448,t:1526922730924};\\\", \\\"{x:868,y:450,t:1526922730940};\\\", \\\"{x:872,y:454,t:1526922730958};\\\", \\\"{x:875,y:456,t:1526922730973};\\\", \\\"{x:876,y:456,t:1526922731365};\\\", \\\"{x:879,y:456,t:1526922731374};\\\", \\\"{x:883,y:455,t:1526922731391};\\\", \\\"{x:889,y:451,t:1526922731408};\\\", \\\"{x:895,y:450,t:1526922731425};\\\", \\\"{x:902,y:447,t:1526922731440};\\\", \\\"{x:909,y:446,t:1526922731458};\\\", \\\"{x:914,y:445,t:1526922731475};\\\", \\\"{x:917,y:445,t:1526922731490};\\\", \\\"{x:924,y:445,t:1526922731508};\\\", \\\"{x:932,y:445,t:1526922731524};\\\", \\\"{x:948,y:445,t:1526922731541};\\\", \\\"{x:965,y:445,t:1526922731558};\\\", \\\"{x:986,y:448,t:1526922731575};\\\", \\\"{x:1007,y:450,t:1526922731591};\\\", \\\"{x:1032,y:454,t:1526922731608};\\\", \\\"{x:1060,y:459,t:1526922731625};\\\", \\\"{x:1093,y:461,t:1526922731641};\\\", \\\"{x:1128,y:467,t:1526922731658};\\\", \\\"{x:1166,y:473,t:1526922731675};\\\", \\\"{x:1198,y:476,t:1526922731690};\\\", \\\"{x:1242,y:481,t:1526922731708};\\\", \\\"{x:1270,y:486,t:1526922731725};\\\", \\\"{x:1298,y:496,t:1526922731741};\\\", \\\"{x:1324,y:503,t:1526922731758};\\\", \\\"{x:1349,y:509,t:1526922731775};\\\", \\\"{x:1377,y:515,t:1526922731791};\\\", \\\"{x:1397,y:518,t:1526922731808};\\\", \\\"{x:1408,y:520,t:1526922731825};\\\", \\\"{x:1409,y:521,t:1526922731842};\\\", \\\"{x:1409,y:522,t:1526922732269};\\\", \\\"{x:1407,y:524,t:1526922732357};\\\", \\\"{x:1405,y:526,t:1526922732366};\\\", \\\"{x:1403,y:527,t:1526922732375};\\\", \\\"{x:1397,y:532,t:1526922732392};\\\", \\\"{x:1385,y:539,t:1526922732409};\\\", \\\"{x:1372,y:549,t:1526922732426};\\\", \\\"{x:1357,y:562,t:1526922732442};\\\", \\\"{x:1344,y:574,t:1526922732460};\\\", \\\"{x:1328,y:588,t:1526922732475};\\\", \\\"{x:1305,y:609,t:1526922732492};\\\", \\\"{x:1299,y:615,t:1526922732508};\\\", \\\"{x:1298,y:615,t:1526922732541};\\\", \\\"{x:1296,y:615,t:1526922732709};\\\", \\\"{x:1288,y:610,t:1526922732725};\\\", \\\"{x:1282,y:605,t:1526922732743};\\\", \\\"{x:1277,y:600,t:1526922732760};\\\", \\\"{x:1273,y:595,t:1526922732777};\\\", \\\"{x:1269,y:589,t:1526922732793};\\\", \\\"{x:1266,y:584,t:1526922732809};\\\", \\\"{x:1263,y:578,t:1526922732826};\\\", \\\"{x:1262,y:573,t:1526922732843};\\\", \\\"{x:1260,y:570,t:1526922732859};\\\", \\\"{x:1259,y:569,t:1526922732876};\\\", \\\"{x:1259,y:568,t:1526922732973};\\\", \\\"{x:1259,y:567,t:1526922732989};\\\", \\\"{x:1259,y:566,t:1526922732997};\\\", \\\"{x:1259,y:565,t:1526922733009};\\\", \\\"{x:1261,y:564,t:1526922733026};\\\", \\\"{x:1263,y:563,t:1526922733043};\\\", \\\"{x:1269,y:563,t:1526922733059};\\\", \\\"{x:1283,y:562,t:1526922733077};\\\", \\\"{x:1296,y:562,t:1526922733093};\\\", \\\"{x:1307,y:562,t:1526922733109};\\\", \\\"{x:1319,y:562,t:1526922733126};\\\", \\\"{x:1329,y:562,t:1526922733142};\\\", \\\"{x:1339,y:562,t:1526922733158};\\\", \\\"{x:1348,y:562,t:1526922733176};\\\", \\\"{x:1352,y:562,t:1526922733192};\\\", \\\"{x:1356,y:562,t:1526922733209};\\\", \\\"{x:1361,y:562,t:1526922733225};\\\", \\\"{x:1366,y:562,t:1526922733242};\\\", \\\"{x:1376,y:563,t:1526922733259};\\\", \\\"{x:1393,y:566,t:1526922733275};\\\", \\\"{x:1402,y:568,t:1526922733292};\\\", \\\"{x:1410,y:570,t:1526922733309};\\\", \\\"{x:1415,y:572,t:1526922733326};\\\", \\\"{x:1423,y:573,t:1526922733343};\\\", \\\"{x:1428,y:575,t:1526922733359};\\\", \\\"{x:1433,y:576,t:1526922733376};\\\", \\\"{x:1435,y:576,t:1526922733393};\\\", \\\"{x:1441,y:577,t:1526922733409};\\\", \\\"{x:1446,y:578,t:1526922733427};\\\", \\\"{x:1450,y:578,t:1526922733443};\\\", \\\"{x:1458,y:578,t:1526922733460};\\\", \\\"{x:1462,y:580,t:1526922733475};\\\", \\\"{x:1464,y:581,t:1526922733493};\\\", \\\"{x:1465,y:581,t:1526922733541};\\\", \\\"{x:1466,y:581,t:1526922733564};\\\", \\\"{x:1467,y:581,t:1526922733580};\\\", \\\"{x:1465,y:581,t:1526922737493};\\\", \\\"{x:1464,y:581,t:1526922737523};\\\", \\\"{x:1463,y:582,t:1526922737572};\\\", \\\"{x:1462,y:582,t:1526922737612};\\\", \\\"{x:1461,y:582,t:1526922740612};\\\", \\\"{x:1459,y:582,t:1526922740693};\\\", \\\"{x:1459,y:583,t:1526922746316};\\\", \\\"{x:1457,y:584,t:1526922746323};\\\", \\\"{x:1447,y:586,t:1526922746336};\\\", \\\"{x:1427,y:591,t:1526922746353};\\\", \\\"{x:1409,y:595,t:1526922746370};\\\", \\\"{x:1387,y:602,t:1526922746386};\\\", \\\"{x:1369,y:608,t:1526922746403};\\\", \\\"{x:1357,y:615,t:1526922746419};\\\", \\\"{x:1351,y:619,t:1526922746436};\\\", \\\"{x:1349,y:620,t:1526922746453};\\\", \\\"{x:1348,y:621,t:1526922746469};\\\", \\\"{x:1348,y:623,t:1526922746486};\\\", \\\"{x:1348,y:625,t:1526922746515};\\\", \\\"{x:1348,y:626,t:1526922746524};\\\", \\\"{x:1348,y:628,t:1526922746536};\\\", \\\"{x:1348,y:631,t:1526922746553};\\\", \\\"{x:1349,y:633,t:1526922746570};\\\", \\\"{x:1350,y:637,t:1526922746587};\\\", \\\"{x:1351,y:639,t:1526922746603};\\\", \\\"{x:1352,y:641,t:1526922746619};\\\", \\\"{x:1352,y:642,t:1526922746644};\\\", \\\"{x:1353,y:642,t:1526922746653};\\\", \\\"{x:1354,y:643,t:1526922746676};\\\", \\\"{x:1354,y:644,t:1526922746686};\\\", \\\"{x:1354,y:645,t:1526922747035};\\\", \\\"{x:1354,y:648,t:1526922747043};\\\", \\\"{x:1354,y:649,t:1526922747053};\\\", \\\"{x:1354,y:656,t:1526922747070};\\\", \\\"{x:1356,y:671,t:1526922747087};\\\", \\\"{x:1357,y:687,t:1526922747103};\\\", \\\"{x:1359,y:696,t:1526922747120};\\\", \\\"{x:1359,y:704,t:1526922747137};\\\", \\\"{x:1359,y:712,t:1526922747153};\\\", \\\"{x:1359,y:718,t:1526922747171};\\\", \\\"{x:1359,y:721,t:1526922747187};\\\", \\\"{x:1358,y:724,t:1526922747203};\\\", \\\"{x:1356,y:726,t:1526922747220};\\\", \\\"{x:1356,y:727,t:1526922747252};\\\", \\\"{x:1355,y:727,t:1526922747301};\\\", \\\"{x:1353,y:727,t:1526922747308};\\\", \\\"{x:1353,y:726,t:1526922747321};\\\", \\\"{x:1348,y:712,t:1526922747337};\\\", \\\"{x:1344,y:695,t:1526922747354};\\\", \\\"{x:1342,y:684,t:1526922747370};\\\", \\\"{x:1342,y:674,t:1526922747387};\\\", \\\"{x:1342,y:664,t:1526922747403};\\\", \\\"{x:1342,y:662,t:1526922747420};\\\", \\\"{x:1342,y:660,t:1526922747437};\\\", \\\"{x:1343,y:660,t:1526922747500};\\\", \\\"{x:1343,y:663,t:1526922747507};\\\", \\\"{x:1343,y:667,t:1526922747520};\\\", \\\"{x:1343,y:677,t:1526922747537};\\\", \\\"{x:1343,y:684,t:1526922747554};\\\", \\\"{x:1343,y:689,t:1526922747571};\\\", \\\"{x:1341,y:694,t:1526922747587};\\\", \\\"{x:1340,y:697,t:1526922747604};\\\", \\\"{x:1339,y:697,t:1526922747660};\\\", \\\"{x:1338,y:697,t:1526922747684};\\\", \\\"{x:1338,y:695,t:1526922747692};\\\", \\\"{x:1338,y:691,t:1526922747704};\\\", \\\"{x:1338,y:683,t:1526922747720};\\\", \\\"{x:1339,y:677,t:1526922747737};\\\", \\\"{x:1340,y:676,t:1526922747755};\\\", \\\"{x:1340,y:678,t:1526922747828};\\\", \\\"{x:1341,y:679,t:1526922747837};\\\", \\\"{x:1341,y:677,t:1526922747939};\\\", \\\"{x:1341,y:672,t:1526922747954};\\\", \\\"{x:1341,y:661,t:1526922747972};\\\", \\\"{x:1341,y:641,t:1526922747988};\\\", \\\"{x:1341,y:629,t:1526922748005};\\\", \\\"{x:1338,y:618,t:1526922748022};\\\", \\\"{x:1332,y:604,t:1526922748037};\\\", \\\"{x:1319,y:591,t:1526922748054};\\\", \\\"{x:1300,y:582,t:1526922748071};\\\", \\\"{x:1272,y:581,t:1526922748087};\\\", \\\"{x:1219,y:580,t:1526922748104};\\\", \\\"{x:1128,y:580,t:1526922748121};\\\", \\\"{x:1006,y:580,t:1526922748137};\\\", \\\"{x:870,y:578,t:1526922748155};\\\", \\\"{x:843,y:572,t:1526922748171};\\\", \\\"{x:843,y:569,t:1526922748419};\\\", \\\"{x:835,y:567,t:1526922748427};\\\", \\\"{x:824,y:565,t:1526922748439};\\\", \\\"{x:795,y:563,t:1526922748454};\\\", \\\"{x:769,y:558,t:1526922748471};\\\", \\\"{x:740,y:554,t:1526922748488};\\\", \\\"{x:701,y:546,t:1526922748505};\\\", \\\"{x:656,y:538,t:1526922748522};\\\", \\\"{x:602,y:535,t:1526922748538};\\\", \\\"{x:544,y:530,t:1526922748554};\\\", \\\"{x:463,y:530,t:1526922748572};\\\", \\\"{x:424,y:530,t:1526922748588};\\\", \\\"{x:393,y:530,t:1526922748604};\\\", \\\"{x:364,y:524,t:1526922748622};\\\", \\\"{x:338,y:522,t:1526922748638};\\\", \\\"{x:313,y:517,t:1526922748655};\\\", \\\"{x:291,y:517,t:1526922748671};\\\", \\\"{x:269,y:517,t:1526922748689};\\\", \\\"{x:248,y:524,t:1526922748705};\\\", \\\"{x:237,y:529,t:1526922748722};\\\", \\\"{x:231,y:532,t:1526922748738};\\\", \\\"{x:227,y:534,t:1526922748755};\\\", \\\"{x:225,y:535,t:1526922748772};\\\", \\\"{x:224,y:535,t:1526922748788};\\\", \\\"{x:220,y:538,t:1526922748805};\\\", \\\"{x:214,y:543,t:1526922748822};\\\", \\\"{x:210,y:547,t:1526922748838};\\\", \\\"{x:207,y:552,t:1526922748856};\\\", \\\"{x:204,y:555,t:1526922748871};\\\", \\\"{x:202,y:557,t:1526922748888};\\\", \\\"{x:200,y:558,t:1526922748905};\\\", \\\"{x:199,y:559,t:1526922748921};\\\", \\\"{x:198,y:559,t:1526922748940};\\\", \\\"{x:195,y:559,t:1526922748955};\\\", \\\"{x:192,y:559,t:1526922748971};\\\", \\\"{x:185,y:549,t:1526922748988};\\\", \\\"{x:179,y:537,t:1526922749005};\\\", \\\"{x:175,y:524,t:1526922749021};\\\", \\\"{x:170,y:508,t:1526922749038};\\\", \\\"{x:164,y:495,t:1526922749056};\\\", \\\"{x:160,y:488,t:1526922749071};\\\", \\\"{x:160,y:485,t:1526922749089};\\\", \\\"{x:157,y:482,t:1526922749105};\\\", \\\"{x:157,y:481,t:1526922749163};\\\", \\\"{x:157,y:480,t:1526922749473};\\\", \\\"{x:174,y:480,t:1526922749488};\\\", \\\"{x:215,y:480,t:1526922749505};\\\", \\\"{x:291,y:480,t:1526922749523};\\\", \\\"{x:409,y:484,t:1526922749540};\\\", \\\"{x:489,y:494,t:1526922749555};\\\", \\\"{x:567,y:506,t:1526922749572};\\\", \\\"{x:628,y:515,t:1526922749589};\\\", \\\"{x:682,y:522,t:1526922749606};\\\", \\\"{x:715,y:525,t:1526922749622};\\\", \\\"{x:742,y:528,t:1526922749641};\\\", \\\"{x:763,y:528,t:1526922749655};\\\", \\\"{x:778,y:528,t:1526922749673};\\\", \\\"{x:786,y:528,t:1526922749690};\\\", \\\"{x:787,y:528,t:1526922749705};\\\", \\\"{x:787,y:531,t:1526922749875};\\\", \\\"{x:787,y:533,t:1526922749889};\\\", \\\"{x:787,y:536,t:1526922749905};\\\", \\\"{x:787,y:539,t:1526922749923};\\\", \\\"{x:790,y:542,t:1526922749940};\\\", \\\"{x:791,y:543,t:1526922749956};\\\", \\\"{x:793,y:544,t:1526922749972};\\\", \\\"{x:796,y:544,t:1526922749989};\\\", \\\"{x:798,y:544,t:1526922750006};\\\", \\\"{x:800,y:544,t:1526922750022};\\\", \\\"{x:801,y:545,t:1526922750039};\\\", \\\"{x:802,y:545,t:1526922750056};\\\", \\\"{x:803,y:545,t:1526922750072};\\\", \\\"{x:806,y:545,t:1526922750089};\\\", \\\"{x:807,y:543,t:1526922750107};\\\", \\\"{x:811,y:537,t:1526922750123};\\\", \\\"{x:816,y:526,t:1526922750139};\\\", \\\"{x:821,y:515,t:1526922750156};\\\", \\\"{x:825,y:506,t:1526922750173};\\\", \\\"{x:826,y:498,t:1526922750190};\\\", \\\"{x:831,y:487,t:1526922750206};\\\", \\\"{x:833,y:479,t:1526922750222};\\\", \\\"{x:834,y:475,t:1526922750239};\\\", \\\"{x:834,y:471,t:1526922750257};\\\", \\\"{x:834,y:466,t:1526922750272};\\\", \\\"{x:836,y:461,t:1526922750290};\\\", \\\"{x:836,y:458,t:1526922750307};\\\", \\\"{x:837,y:454,t:1526922750324};\\\", \\\"{x:838,y:450,t:1526922750339};\\\", \\\"{x:838,y:448,t:1526922750356};\\\", \\\"{x:838,y:447,t:1526922750374};\\\", \\\"{x:838,y:445,t:1526922750389};\\\", \\\"{x:839,y:444,t:1526922750406};\\\", \\\"{x:839,y:443,t:1526922750424};\\\", \\\"{x:839,y:441,t:1526922750439};\\\", \\\"{x:839,y:440,t:1526922750456};\\\", \\\"{x:839,y:439,t:1526922750473};\\\", \\\"{x:839,y:442,t:1526922750724};\\\", \\\"{x:834,y:457,t:1526922750739};\\\", \\\"{x:830,y:478,t:1526922750757};\\\", \\\"{x:824,y:510,t:1526922750773};\\\", \\\"{x:816,y:550,t:1526922750790};\\\", \\\"{x:805,y:587,t:1526922750807};\\\", \\\"{x:795,y:618,t:1526922750823};\\\", \\\"{x:783,y:646,t:1526922750839};\\\", \\\"{x:773,y:668,t:1526922750857};\\\", \\\"{x:761,y:686,t:1526922750873};\\\", \\\"{x:753,y:697,t:1526922750890};\\\", \\\"{x:738,y:715,t:1526922750908};\\\", \\\"{x:725,y:724,t:1526922750923};\\\", \\\"{x:715,y:728,t:1526922750940};\\\", \\\"{x:704,y:733,t:1526922750958};\\\", \\\"{x:694,y:736,t:1526922750974};\\\", \\\"{x:686,y:737,t:1526922750990};\\\", \\\"{x:675,y:737,t:1526922751007};\\\", \\\"{x:666,y:737,t:1526922751024};\\\", \\\"{x:654,y:736,t:1526922751041};\\\", \\\"{x:634,y:729,t:1526922751057};\\\", \\\"{x:613,y:723,t:1526922751075};\\\", \\\"{x:590,y:710,t:1526922751091};\\\", \\\"{x:576,y:701,t:1526922751108};\\\", \\\"{x:565,y:692,t:1526922751124};\\\", \\\"{x:559,y:687,t:1526922751142};\\\", \\\"{x:554,y:683,t:1526922751158};\\\", \\\"{x:552,y:680,t:1526922751174};\\\", \\\"{x:550,y:677,t:1526922751191};\\\", \\\"{x:548,y:676,t:1526922751207};\\\", \\\"{x:547,y:675,t:1526922751227};\\\" ] }, { \\\"rt\\\": 18101, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 356383, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:671,t:1526922753971};\\\", \\\"{x:546,y:654,t:1526922753991};\\\", \\\"{x:546,y:635,t:1526922753995};\\\", \\\"{x:546,y:618,t:1526922754009};\\\", \\\"{x:540,y:589,t:1526922754026};\\\", \\\"{x:527,y:558,t:1526922754042};\\\", \\\"{x:507,y:531,t:1526922754060};\\\", \\\"{x:494,y:517,t:1526922754076};\\\", \\\"{x:482,y:508,t:1526922754092};\\\", \\\"{x:474,y:503,t:1526922754109};\\\", \\\"{x:471,y:502,t:1526922754126};\\\", \\\"{x:470,y:500,t:1526922754142};\\\", \\\"{x:470,y:499,t:1526922754187};\\\", \\\"{x:470,y:498,t:1526922754195};\\\", \\\"{x:470,y:497,t:1526922754211};\\\", \\\"{x:470,y:496,t:1526922754227};\\\", \\\"{x:470,y:495,t:1526922754242};\\\", \\\"{x:469,y:493,t:1526922754259};\\\", \\\"{x:469,y:491,t:1526922754277};\\\", \\\"{x:468,y:490,t:1526922754294};\\\", \\\"{x:468,y:488,t:1526922754309};\\\", \\\"{x:467,y:487,t:1526922754326};\\\", \\\"{x:467,y:485,t:1526922754343};\\\", \\\"{x:467,y:484,t:1526922754371};\\\", \\\"{x:467,y:483,t:1526922754380};\\\", \\\"{x:467,y:482,t:1526922754723};\\\", \\\"{x:468,y:480,t:1526922754739};\\\", \\\"{x:470,y:478,t:1526922754747};\\\", \\\"{x:473,y:477,t:1526922754760};\\\", \\\"{x:479,y:474,t:1526922754778};\\\", \\\"{x:484,y:472,t:1526922754794};\\\", \\\"{x:492,y:468,t:1526922754811};\\\", \\\"{x:495,y:466,t:1526922754828};\\\", \\\"{x:496,y:465,t:1526922754843};\\\", \\\"{x:498,y:464,t:1526922754860};\\\", \\\"{x:499,y:463,t:1526922754877};\\\", \\\"{x:500,y:463,t:1526922754947};\\\", \\\"{x:501,y:462,t:1526922754959};\\\", \\\"{x:502,y:461,t:1526922755171};\\\", \\\"{x:502,y:460,t:1526922755180};\\\", \\\"{x:504,y:457,t:1526922755193};\\\", \\\"{x:504,y:455,t:1526922755211};\\\", \\\"{x:505,y:453,t:1526922755226};\\\", \\\"{x:506,y:449,t:1526922755243};\\\", \\\"{x:506,y:448,t:1526922755261};\\\", \\\"{x:506,y:446,t:1526922755276};\\\", \\\"{x:506,y:444,t:1526922755294};\\\", \\\"{x:506,y:443,t:1526922755311};\\\", \\\"{x:507,y:439,t:1526922755326};\\\", \\\"{x:508,y:437,t:1526922755343};\\\", \\\"{x:508,y:435,t:1526922755360};\\\", \\\"{x:509,y:434,t:1526922755376};\\\", \\\"{x:509,y:433,t:1526922755395};\\\", \\\"{x:510,y:432,t:1526922755411};\\\", \\\"{x:510,y:431,t:1526922755467};\\\", \\\"{x:513,y:429,t:1526922756035};\\\", \\\"{x:519,y:429,t:1526922756043};\\\", \\\"{x:535,y:427,t:1526922756060};\\\", \\\"{x:566,y:427,t:1526922756077};\\\", \\\"{x:622,y:425,t:1526922756093};\\\", \\\"{x:708,y:438,t:1526922756111};\\\", \\\"{x:831,y:458,t:1526922756128};\\\", \\\"{x:950,y:473,t:1526922756145};\\\", \\\"{x:1066,y:491,t:1526922756161};\\\", \\\"{x:1167,y:507,t:1526922756177};\\\", \\\"{x:1248,y:522,t:1526922756195};\\\", \\\"{x:1305,y:533,t:1526922756211};\\\", \\\"{x:1344,y:545,t:1526922756227};\\\", \\\"{x:1362,y:552,t:1526922756244};\\\", \\\"{x:1377,y:559,t:1526922756262};\\\", \\\"{x:1388,y:563,t:1526922756277};\\\", \\\"{x:1400,y:571,t:1526922756295};\\\", \\\"{x:1412,y:578,t:1526922756312};\\\", \\\"{x:1423,y:583,t:1526922756328};\\\", \\\"{x:1435,y:588,t:1526922756345};\\\", \\\"{x:1447,y:593,t:1526922756362};\\\", \\\"{x:1455,y:596,t:1526922756377};\\\", \\\"{x:1458,y:598,t:1526922756394};\\\", \\\"{x:1462,y:599,t:1526922756412};\\\", \\\"{x:1464,y:602,t:1526922756428};\\\", \\\"{x:1466,y:610,t:1526922756444};\\\", \\\"{x:1472,y:623,t:1526922756461};\\\", \\\"{x:1473,y:631,t:1526922756479};\\\", \\\"{x:1475,y:641,t:1526922756495};\\\", \\\"{x:1475,y:652,t:1526922756512};\\\", \\\"{x:1475,y:662,t:1526922756529};\\\", \\\"{x:1475,y:667,t:1526922756545};\\\", \\\"{x:1470,y:678,t:1526922756561};\\\", \\\"{x:1466,y:683,t:1526922756578};\\\", \\\"{x:1457,y:694,t:1526922756595};\\\", \\\"{x:1442,y:704,t:1526922756611};\\\", \\\"{x:1426,y:710,t:1526922756629};\\\", \\\"{x:1405,y:714,t:1526922756646};\\\", \\\"{x:1381,y:717,t:1526922756662};\\\", \\\"{x:1350,y:720,t:1526922756679};\\\", \\\"{x:1321,y:721,t:1526922756695};\\\", \\\"{x:1301,y:721,t:1526922756712};\\\", \\\"{x:1287,y:721,t:1526922756728};\\\", \\\"{x:1283,y:721,t:1526922756745};\\\", \\\"{x:1283,y:720,t:1526922756763};\\\", \\\"{x:1283,y:718,t:1526922756779};\\\", \\\"{x:1283,y:715,t:1526922756795};\\\", \\\"{x:1283,y:714,t:1526922756843};\\\", \\\"{x:1284,y:714,t:1526922756867};\\\", \\\"{x:1286,y:714,t:1526922756879};\\\", \\\"{x:1289,y:714,t:1526922756896};\\\", \\\"{x:1299,y:716,t:1526922756912};\\\", \\\"{x:1310,y:721,t:1526922756930};\\\", \\\"{x:1318,y:724,t:1526922756946};\\\", \\\"{x:1324,y:724,t:1526922756962};\\\", \\\"{x:1327,y:725,t:1526922756979};\\\", \\\"{x:1328,y:723,t:1526922757011};\\\", \\\"{x:1328,y:721,t:1526922757019};\\\", \\\"{x:1329,y:718,t:1526922757029};\\\", \\\"{x:1331,y:711,t:1526922757047};\\\", \\\"{x:1332,y:708,t:1526922757064};\\\", \\\"{x:1333,y:705,t:1526922757080};\\\", \\\"{x:1333,y:703,t:1526922757097};\\\", \\\"{x:1333,y:702,t:1526922757116};\\\", \\\"{x:1334,y:701,t:1526922757139};\\\", \\\"{x:1335,y:700,t:1526922757147};\\\", \\\"{x:1335,y:699,t:1526922757187};\\\", \\\"{x:1336,y:698,t:1526922757235};\\\", \\\"{x:1338,y:697,t:1526922757251};\\\", \\\"{x:1338,y:696,t:1526922757264};\\\", \\\"{x:1339,y:696,t:1526922757283};\\\", \\\"{x:1340,y:696,t:1526922757296};\\\", \\\"{x:1341,y:696,t:1526922757313};\\\", \\\"{x:1342,y:696,t:1526922757363};\\\", \\\"{x:1344,y:696,t:1526922757380};\\\", \\\"{x:1344,y:697,t:1526922757397};\\\", \\\"{x:1345,y:698,t:1526922757414};\\\", \\\"{x:1347,y:700,t:1526922757430};\\\", \\\"{x:1347,y:701,t:1526922757448};\\\", \\\"{x:1347,y:702,t:1526922757465};\\\", \\\"{x:1347,y:703,t:1526922757480};\\\", \\\"{x:1347,y:705,t:1526922757499};\\\", \\\"{x:1347,y:709,t:1526922757515};\\\", \\\"{x:1346,y:712,t:1526922757531};\\\", \\\"{x:1346,y:713,t:1526922757547};\\\", \\\"{x:1346,y:715,t:1526922757564};\\\", \\\"{x:1345,y:715,t:1526922757876};\\\", \\\"{x:1344,y:714,t:1526922757883};\\\", \\\"{x:1344,y:713,t:1526922757899};\\\", \\\"{x:1344,y:712,t:1526922757916};\\\", \\\"{x:1344,y:711,t:1526922757932};\\\", \\\"{x:1344,y:709,t:1526922757949};\\\", \\\"{x:1343,y:708,t:1526922758052};\\\", \\\"{x:1343,y:707,t:1526922758420};\\\", \\\"{x:1343,y:706,t:1526922758435};\\\", \\\"{x:1342,y:705,t:1526922765172};\\\", \\\"{x:1339,y:700,t:1526922765185};\\\", \\\"{x:1329,y:689,t:1526922765201};\\\", \\\"{x:1316,y:676,t:1526922765219};\\\", \\\"{x:1314,y:674,t:1526922765444};\\\", \\\"{x:1313,y:672,t:1526922765451};\\\", \\\"{x:1312,y:668,t:1526922765469};\\\", \\\"{x:1312,y:659,t:1526922765486};\\\", \\\"{x:1312,y:653,t:1526922765502};\\\", \\\"{x:1312,y:650,t:1526922765518};\\\", \\\"{x:1312,y:648,t:1526922765535};\\\", \\\"{x:1312,y:645,t:1526922765552};\\\", \\\"{x:1312,y:639,t:1526922765568};\\\", \\\"{x:1312,y:633,t:1526922765585};\\\", \\\"{x:1312,y:630,t:1526922765602};\\\", \\\"{x:1314,y:624,t:1526922765619};\\\", \\\"{x:1314,y:620,t:1526922765635};\\\", \\\"{x:1314,y:616,t:1526922765652};\\\", \\\"{x:1314,y:612,t:1526922765668};\\\", \\\"{x:1299,y:607,t:1526922765686};\\\", \\\"{x:1267,y:601,t:1526922765702};\\\", \\\"{x:1209,y:592,t:1526922765719};\\\", \\\"{x:1115,y:592,t:1526922765736};\\\", \\\"{x:998,y:592,t:1526922765752};\\\", \\\"{x:887,y:590,t:1526922765769};\\\", \\\"{x:784,y:576,t:1526922765787};\\\", \\\"{x:673,y:564,t:1526922765803};\\\", \\\"{x:633,y:557,t:1526922765819};\\\", \\\"{x:586,y:557,t:1526922765852};\\\", \\\"{x:578,y:559,t:1526922765869};\\\", \\\"{x:574,y:562,t:1526922765885};\\\", \\\"{x:570,y:566,t:1526922765902};\\\", \\\"{x:564,y:575,t:1526922765919};\\\", \\\"{x:557,y:588,t:1526922765935};\\\", \\\"{x:554,y:603,t:1526922765951};\\\", \\\"{x:551,y:617,t:1526922765969};\\\", \\\"{x:550,y:632,t:1526922765985};\\\", \\\"{x:550,y:646,t:1526922766002};\\\", \\\"{x:549,y:661,t:1526922766018};\\\", \\\"{x:547,y:673,t:1526922766036};\\\", \\\"{x:545,y:679,t:1526922766051};\\\", \\\"{x:544,y:682,t:1526922766068};\\\", \\\"{x:541,y:685,t:1526922766086};\\\", \\\"{x:539,y:686,t:1526922766101};\\\", \\\"{x:536,y:686,t:1526922766119};\\\", \\\"{x:529,y:686,t:1526922766136};\\\", \\\"{x:516,y:677,t:1526922766152};\\\", \\\"{x:498,y:660,t:1526922766170};\\\", \\\"{x:479,y:639,t:1526922766186};\\\", \\\"{x:462,y:620,t:1526922766201};\\\", \\\"{x:448,y:606,t:1526922766219};\\\", \\\"{x:433,y:587,t:1526922766234};\\\", \\\"{x:429,y:578,t:1526922766253};\\\", \\\"{x:425,y:572,t:1526922766269};\\\", \\\"{x:424,y:568,t:1526922766286};\\\", \\\"{x:422,y:562,t:1526922766303};\\\", \\\"{x:422,y:561,t:1526922766319};\\\", \\\"{x:418,y:565,t:1526922766827};\\\", \\\"{x:411,y:568,t:1526922766835};\\\", \\\"{x:393,y:573,t:1526922766853};\\\", \\\"{x:379,y:577,t:1526922766870};\\\", \\\"{x:364,y:579,t:1526922766886};\\\", \\\"{x:350,y:579,t:1526922766903};\\\", \\\"{x:341,y:579,t:1526922766920};\\\", \\\"{x:338,y:579,t:1526922766935};\\\", \\\"{x:337,y:579,t:1526922766953};\\\", \\\"{x:334,y:579,t:1526922766970};\\\", \\\"{x:333,y:578,t:1526922766986};\\\", \\\"{x:332,y:578,t:1526922767003};\\\", \\\"{x:330,y:576,t:1526922767027};\\\", \\\"{x:330,y:575,t:1526922767035};\\\", \\\"{x:330,y:568,t:1526922767053};\\\", \\\"{x:330,y:562,t:1526922767069};\\\", \\\"{x:333,y:553,t:1526922767085};\\\", \\\"{x:335,y:545,t:1526922767103};\\\", \\\"{x:335,y:541,t:1526922767118};\\\", \\\"{x:335,y:539,t:1526922767136};\\\", \\\"{x:333,y:535,t:1526922767153};\\\", \\\"{x:331,y:533,t:1526922767169};\\\", \\\"{x:326,y:531,t:1526922767186};\\\", \\\"{x:325,y:531,t:1526922767202};\\\", \\\"{x:320,y:531,t:1526922767220};\\\", \\\"{x:313,y:539,t:1526922767237};\\\", \\\"{x:311,y:545,t:1526922767253};\\\", \\\"{x:309,y:551,t:1526922767270};\\\", \\\"{x:315,y:556,t:1526922767287};\\\", \\\"{x:336,y:557,t:1526922767302};\\\", \\\"{x:382,y:557,t:1526922767320};\\\", \\\"{x:449,y:557,t:1526922767337};\\\", \\\"{x:537,y:550,t:1526922767353};\\\", \\\"{x:616,y:536,t:1526922767370};\\\", \\\"{x:686,y:521,t:1526922767387};\\\", \\\"{x:714,y:512,t:1526922767402};\\\", \\\"{x:733,y:506,t:1526922767420};\\\", \\\"{x:747,y:502,t:1526922767437};\\\", \\\"{x:754,y:500,t:1526922767453};\\\", \\\"{x:758,y:498,t:1526922767470};\\\", \\\"{x:759,y:498,t:1526922767486};\\\", \\\"{x:760,y:498,t:1526922767531};\\\", \\\"{x:760,y:499,t:1526922767611};\\\", \\\"{x:757,y:500,t:1526922767619};\\\", \\\"{x:746,y:500,t:1526922767636};\\\", \\\"{x:731,y:501,t:1526922767653};\\\", \\\"{x:713,y:501,t:1526922767670};\\\", \\\"{x:701,y:501,t:1526922767686};\\\", \\\"{x:692,y:501,t:1526922767703};\\\", \\\"{x:688,y:500,t:1526922767720};\\\", \\\"{x:686,y:499,t:1526922767736};\\\", \\\"{x:685,y:499,t:1526922767754};\\\", \\\"{x:684,y:499,t:1526922767770};\\\", \\\"{x:681,y:498,t:1526922767787};\\\", \\\"{x:674,y:496,t:1526922767804};\\\", \\\"{x:666,y:496,t:1526922767819};\\\", \\\"{x:660,y:496,t:1526922767836};\\\", \\\"{x:651,y:498,t:1526922767853};\\\", \\\"{x:638,y:505,t:1526922767870};\\\", \\\"{x:628,y:511,t:1526922767887};\\\", \\\"{x:620,y:518,t:1526922767904};\\\", \\\"{x:614,y:529,t:1526922767920};\\\", \\\"{x:611,y:538,t:1526922767937};\\\", \\\"{x:608,y:550,t:1526922767954};\\\", \\\"{x:607,y:563,t:1526922767970};\\\", \\\"{x:598,y:580,t:1526922767987};\\\", \\\"{x:593,y:588,t:1526922768004};\\\", \\\"{x:587,y:596,t:1526922768020};\\\", \\\"{x:579,y:604,t:1526922768036};\\\", \\\"{x:570,y:610,t:1526922768054};\\\", \\\"{x:561,y:616,t:1526922768069};\\\", \\\"{x:553,y:620,t:1526922768087};\\\", \\\"{x:546,y:621,t:1526922768102};\\\", \\\"{x:538,y:622,t:1526922768120};\\\", \\\"{x:531,y:622,t:1526922768137};\\\", \\\"{x:518,y:620,t:1526922768153};\\\", \\\"{x:504,y:613,t:1526922768169};\\\", \\\"{x:480,y:608,t:1526922768187};\\\", \\\"{x:467,y:604,t:1526922768203};\\\", \\\"{x:457,y:604,t:1526922768221};\\\", \\\"{x:451,y:604,t:1526922768238};\\\", \\\"{x:448,y:604,t:1526922768254};\\\", \\\"{x:445,y:604,t:1526922768271};\\\", \\\"{x:441,y:604,t:1526922768287};\\\", \\\"{x:438,y:605,t:1526922768304};\\\", \\\"{x:435,y:608,t:1526922768321};\\\", \\\"{x:430,y:611,t:1526922768337};\\\", \\\"{x:428,y:614,t:1526922768355};\\\", \\\"{x:427,y:615,t:1526922768371};\\\", \\\"{x:426,y:615,t:1526922768387};\\\", \\\"{x:423,y:616,t:1526922768405};\\\", \\\"{x:413,y:619,t:1526922768422};\\\", \\\"{x:398,y:621,t:1526922768439};\\\", \\\"{x:376,y:626,t:1526922768454};\\\", \\\"{x:347,y:626,t:1526922768471};\\\", \\\"{x:317,y:627,t:1526922768487};\\\", \\\"{x:292,y:627,t:1526922768504};\\\", \\\"{x:269,y:629,t:1526922768521};\\\", \\\"{x:249,y:629,t:1526922768537};\\\", \\\"{x:239,y:629,t:1526922768554};\\\", \\\"{x:237,y:629,t:1526922768619};\\\", \\\"{x:237,y:626,t:1526922768627};\\\", \\\"{x:235,y:623,t:1526922768637};\\\", \\\"{x:232,y:610,t:1526922768654};\\\", \\\"{x:230,y:596,t:1526922768671};\\\", \\\"{x:230,y:586,t:1526922768686};\\\", \\\"{x:231,y:576,t:1526922768704};\\\", \\\"{x:240,y:565,t:1526922768720};\\\", \\\"{x:254,y:557,t:1526922768737};\\\", \\\"{x:280,y:545,t:1526922768754};\\\", \\\"{x:360,y:539,t:1526922768771};\\\", \\\"{x:369,y:540,t:1526922769059};\\\", \\\"{x:386,y:541,t:1526922769071};\\\", \\\"{x:427,y:538,t:1526922769088};\\\", \\\"{x:469,y:532,t:1526922769105};\\\", \\\"{x:505,y:530,t:1526922769121};\\\", \\\"{x:534,y:530,t:1526922769137};\\\", \\\"{x:577,y:530,t:1526922769154};\\\", \\\"{x:610,y:530,t:1526922769171};\\\", \\\"{x:647,y:530,t:1526922769188};\\\", \\\"{x:689,y:530,t:1526922769204};\\\", \\\"{x:725,y:530,t:1526922769221};\\\", \\\"{x:757,y:530,t:1526922769238};\\\", \\\"{x:794,y:528,t:1526922769255};\\\", \\\"{x:825,y:524,t:1526922769270};\\\", \\\"{x:855,y:519,t:1526922769288};\\\", \\\"{x:884,y:511,t:1526922769305};\\\", \\\"{x:910,y:502,t:1526922769321};\\\", \\\"{x:932,y:493,t:1526922769337};\\\", \\\"{x:957,y:484,t:1526922769355};\\\", \\\"{x:967,y:478,t:1526922769371};\\\", \\\"{x:975,y:473,t:1526922769388};\\\", \\\"{x:976,y:472,t:1526922769405};\\\", \\\"{x:976,y:471,t:1526922769421};\\\", \\\"{x:976,y:472,t:1526922769499};\\\", \\\"{x:974,y:473,t:1526922769506};\\\", \\\"{x:968,y:475,t:1526922769520};\\\", \\\"{x:951,y:483,t:1526922769538};\\\", \\\"{x:921,y:495,t:1526922769555};\\\", \\\"{x:901,y:499,t:1526922769571};\\\", \\\"{x:886,y:500,t:1526922769588};\\\", \\\"{x:877,y:500,t:1526922769605};\\\", \\\"{x:875,y:500,t:1526922769622};\\\", \\\"{x:873,y:500,t:1526922769638};\\\", \\\"{x:870,y:493,t:1526922769655};\\\", \\\"{x:867,y:484,t:1526922769672};\\\", \\\"{x:862,y:473,t:1526922769688};\\\", \\\"{x:855,y:462,t:1526922769705};\\\", \\\"{x:845,y:450,t:1526922769722};\\\", \\\"{x:840,y:444,t:1526922769737};\\\", \\\"{x:837,y:440,t:1526922769756};\\\", \\\"{x:837,y:439,t:1526922769772};\\\", \\\"{x:836,y:439,t:1526922769827};\\\", \\\"{x:835,y:439,t:1526922769859};\\\", \\\"{x:833,y:441,t:1526922770055};\\\", \\\"{x:828,y:460,t:1526922770072};\\\", \\\"{x:816,y:484,t:1526922770089};\\\", \\\"{x:806,y:509,t:1526922770105};\\\", \\\"{x:793,y:532,t:1526922770122};\\\", \\\"{x:778,y:572,t:1526922770139};\\\", \\\"{x:757,y:612,t:1526922770156};\\\", \\\"{x:735,y:650,t:1526922770172};\\\", \\\"{x:716,y:678,t:1526922770189};\\\", \\\"{x:693,y:708,t:1526922770205};\\\", \\\"{x:673,y:730,t:1526922770222};\\\", \\\"{x:652,y:752,t:1526922770239};\\\", \\\"{x:635,y:767,t:1526922770255};\\\", \\\"{x:624,y:774,t:1526922770271};\\\", \\\"{x:609,y:782,t:1526922770288};\\\", \\\"{x:599,y:784,t:1526922770306};\\\", \\\"{x:590,y:786,t:1526922770322};\\\", \\\"{x:578,y:786,t:1526922770339};\\\", \\\"{x:566,y:781,t:1526922770356};\\\", \\\"{x:555,y:774,t:1526922770372};\\\", \\\"{x:546,y:762,t:1526922770389};\\\", \\\"{x:539,y:748,t:1526922770406};\\\", \\\"{x:532,y:738,t:1526922770423};\\\", \\\"{x:527,y:727,t:1526922770439};\\\", \\\"{x:523,y:720,t:1526922770456};\\\", \\\"{x:522,y:717,t:1526922770473};\\\", \\\"{x:521,y:714,t:1526922770489};\\\", \\\"{x:519,y:712,t:1526922770506};\\\", \\\"{x:518,y:705,t:1526922770522};\\\", \\\"{x:516,y:701,t:1526922770540};\\\", \\\"{x:514,y:697,t:1526922770555};\\\", \\\"{x:513,y:692,t:1526922770571};\\\", \\\"{x:511,y:689,t:1526922770589};\\\", \\\"{x:510,y:686,t:1526922770606};\\\", \\\"{x:509,y:683,t:1526922770623};\\\", \\\"{x:508,y:681,t:1526922770639};\\\", \\\"{x:507,y:679,t:1526922770656};\\\", \\\"{x:507,y:678,t:1526922770672};\\\" ] }, { \\\"rt\\\": 48288, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 406118, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:676,t:1526922773938};\\\", \\\"{x:511,y:672,t:1526922773955};\\\", \\\"{x:513,y:671,t:1526922773969};\\\", \\\"{x:514,y:670,t:1526922773977};\\\", \\\"{x:516,y:669,t:1526922773989};\\\", \\\"{x:520,y:668,t:1526922774006};\\\", \\\"{x:522,y:667,t:1526922774023};\\\", \\\"{x:523,y:667,t:1526922774039};\\\", \\\"{x:525,y:666,t:1526922774073};\\\", \\\"{x:532,y:665,t:1526922774089};\\\", \\\"{x:538,y:672,t:1526922774107};\\\", \\\"{x:538,y:674,t:1526922774123};\\\", \\\"{x:542,y:674,t:1526922774754};\\\", \\\"{x:543,y:674,t:1526922774762};\\\", \\\"{x:545,y:674,t:1526922774778};\\\", \\\"{x:546,y:674,t:1526922774810};\\\", \\\"{x:548,y:674,t:1526922774850};\\\", \\\"{x:549,y:674,t:1526922774898};\\\", \\\"{x:550,y:673,t:1526922774937};\\\", \\\"{x:551,y:672,t:1526922774969};\\\", \\\"{x:552,y:671,t:1526922774985};\\\", \\\"{x:552,y:670,t:1526922775017};\\\", \\\"{x:553,y:669,t:1526922775025};\\\", \\\"{x:554,y:669,t:1526922775057};\\\", \\\"{x:555,y:669,t:1526922775074};\\\", \\\"{x:555,y:668,t:1526922775121};\\\", \\\"{x:556,y:668,t:1526922775137};\\\", \\\"{x:557,y:667,t:1526922775153};\\\", \\\"{x:558,y:666,t:1526922775170};\\\", \\\"{x:560,y:665,t:1526922775185};\\\", \\\"{x:561,y:665,t:1526922775201};\\\", \\\"{x:563,y:665,t:1526922775218};\\\", \\\"{x:563,y:664,t:1526922775225};\\\", \\\"{x:565,y:663,t:1526922775241};\\\", \\\"{x:567,y:662,t:1526922775258};\\\", \\\"{x:569,y:661,t:1526922775275};\\\", \\\"{x:571,y:661,t:1526922775292};\\\", \\\"{x:572,y:660,t:1526922775307};\\\", \\\"{x:573,y:660,t:1526922775337};\\\", \\\"{x:574,y:660,t:1526922775378};\\\", \\\"{x:575,y:659,t:1526922775418};\\\", \\\"{x:576,y:658,t:1526922775434};\\\", \\\"{x:577,y:657,t:1526922775449};\\\", \\\"{x:577,y:656,t:1526922775457};\\\", \\\"{x:579,y:655,t:1526922775474};\\\", \\\"{x:582,y:652,t:1526922775491};\\\", \\\"{x:584,y:651,t:1526922775508};\\\", \\\"{x:587,y:650,t:1526922775524};\\\", \\\"{x:590,y:648,t:1526922775541};\\\", \\\"{x:595,y:646,t:1526922775558};\\\", \\\"{x:599,y:644,t:1526922775575};\\\", \\\"{x:604,y:641,t:1526922775592};\\\", \\\"{x:608,y:641,t:1526922775608};\\\", \\\"{x:609,y:640,t:1526922775625};\\\", \\\"{x:612,y:638,t:1526922775641};\\\", \\\"{x:617,y:637,t:1526922775658};\\\", \\\"{x:623,y:637,t:1526922775674};\\\", \\\"{x:632,y:636,t:1526922775691};\\\", \\\"{x:648,y:633,t:1526922775708};\\\", \\\"{x:662,y:631,t:1526922775724};\\\", \\\"{x:679,y:627,t:1526922775742};\\\", \\\"{x:680,y:626,t:1526922775758};\\\", \\\"{x:680,y:624,t:1526922775774};\\\", \\\"{x:681,y:624,t:1526922776417};\\\", \\\"{x:682,y:624,t:1526922776481};\\\", \\\"{x:684,y:623,t:1526922776493};\\\", \\\"{x:685,y:623,t:1526922776509};\\\", \\\"{x:688,y:620,t:1526922776525};\\\", \\\"{x:689,y:620,t:1526922776542};\\\", \\\"{x:691,y:619,t:1526922776558};\\\", \\\"{x:692,y:619,t:1526922776602};\\\", \\\"{x:693,y:619,t:1526922776617};\\\", \\\"{x:693,y:618,t:1526922776626};\\\", \\\"{x:694,y:618,t:1526922776642};\\\", \\\"{x:695,y:617,t:1526922776674};\\\", \\\"{x:696,y:617,t:1526922776682};\\\", \\\"{x:697,y:617,t:1526922776698};\\\", \\\"{x:698,y:617,t:1526922776722};\\\", \\\"{x:699,y:617,t:1526922776729};\\\", \\\"{x:700,y:617,t:1526922776761};\\\", \\\"{x:700,y:616,t:1526922776881};\\\", \\\"{x:701,y:615,t:1526922776896};\\\", \\\"{x:702,y:614,t:1526922776913};\\\", \\\"{x:704,y:612,t:1526922781905};\\\", \\\"{x:713,y:609,t:1526922781913};\\\", \\\"{x:750,y:597,t:1526922781929};\\\", \\\"{x:805,y:582,t:1526922781947};\\\", \\\"{x:859,y:573,t:1526922781964};\\\", \\\"{x:942,y:564,t:1526922781979};\\\", \\\"{x:1044,y:552,t:1526922781997};\\\", \\\"{x:1122,y:552,t:1526922782014};\\\", \\\"{x:1134,y:550,t:1526922782030};\\\", \\\"{x:1137,y:550,t:1526922782047};\\\", \\\"{x:1138,y:550,t:1526922785722};\\\", \\\"{x:1139,y:550,t:1526922785733};\\\", \\\"{x:1141,y:549,t:1526922785750};\\\", \\\"{x:1142,y:549,t:1526922785766};\\\", \\\"{x:1143,y:548,t:1526922785794};\\\", \\\"{x:1144,y:547,t:1526922785810};\\\", \\\"{x:1145,y:546,t:1526922785818};\\\", \\\"{x:1146,y:545,t:1526922785833};\\\", \\\"{x:1150,y:545,t:1526922785849};\\\", \\\"{x:1154,y:542,t:1526922785866};\\\", \\\"{x:1159,y:541,t:1526922785882};\\\", \\\"{x:1163,y:539,t:1526922785900};\\\", \\\"{x:1166,y:539,t:1526922785915};\\\", \\\"{x:1172,y:537,t:1526922785932};\\\", \\\"{x:1174,y:537,t:1526922785949};\\\", \\\"{x:1179,y:536,t:1526922785966};\\\", \\\"{x:1187,y:536,t:1526922785983};\\\", \\\"{x:1201,y:535,t:1526922786000};\\\", \\\"{x:1219,y:535,t:1526922786016};\\\", \\\"{x:1240,y:535,t:1526922786032};\\\", \\\"{x:1279,y:537,t:1526922786049};\\\", \\\"{x:1308,y:547,t:1526922786066};\\\", \\\"{x:1340,y:560,t:1526922786083};\\\", \\\"{x:1367,y:574,t:1526922786100};\\\", \\\"{x:1391,y:595,t:1526922786116};\\\", \\\"{x:1421,y:626,t:1526922786133};\\\", \\\"{x:1442,y:645,t:1526922786150};\\\", \\\"{x:1464,y:662,t:1526922786166};\\\", \\\"{x:1482,y:675,t:1526922786183};\\\", \\\"{x:1496,y:683,t:1526922786200};\\\", \\\"{x:1508,y:689,t:1526922786217};\\\", \\\"{x:1526,y:698,t:1526922786233};\\\", \\\"{x:1535,y:699,t:1526922786250};\\\", \\\"{x:1541,y:699,t:1526922786268};\\\", \\\"{x:1544,y:700,t:1526922786283};\\\", \\\"{x:1549,y:700,t:1526922786301};\\\", \\\"{x:1555,y:700,t:1526922786317};\\\", \\\"{x:1558,y:700,t:1526922786333};\\\", \\\"{x:1563,y:700,t:1526922786350};\\\", \\\"{x:1565,y:700,t:1526922786367};\\\", \\\"{x:1569,y:699,t:1526922786384};\\\", \\\"{x:1570,y:698,t:1526922786410};\\\", \\\"{x:1570,y:697,t:1526922786507};\\\", \\\"{x:1570,y:696,t:1526922786518};\\\", \\\"{x:1561,y:696,t:1526922786534};\\\", \\\"{x:1549,y:696,t:1526922786550};\\\", \\\"{x:1526,y:696,t:1526922786568};\\\", \\\"{x:1499,y:696,t:1526922786583};\\\", \\\"{x:1458,y:696,t:1526922786600};\\\", \\\"{x:1393,y:696,t:1526922786618};\\\", \\\"{x:1361,y:696,t:1526922786633};\\\", \\\"{x:1332,y:701,t:1526922786650};\\\", \\\"{x:1310,y:707,t:1526922786668};\\\", \\\"{x:1295,y:711,t:1526922786684};\\\", \\\"{x:1288,y:714,t:1526922786701};\\\", \\\"{x:1282,y:716,t:1526922786718};\\\", \\\"{x:1270,y:720,t:1526922786734};\\\", \\\"{x:1259,y:722,t:1526922786751};\\\", \\\"{x:1248,y:725,t:1526922786768};\\\", \\\"{x:1240,y:728,t:1526922786785};\\\", \\\"{x:1236,y:732,t:1526922786800};\\\", \\\"{x:1232,y:736,t:1526922786817};\\\", \\\"{x:1232,y:741,t:1526922786835};\\\", \\\"{x:1232,y:746,t:1526922786850};\\\", \\\"{x:1234,y:749,t:1526922786866};\\\", \\\"{x:1237,y:753,t:1526922786884};\\\", \\\"{x:1238,y:756,t:1526922786900};\\\", \\\"{x:1239,y:758,t:1526922786917};\\\", \\\"{x:1240,y:760,t:1526922786934};\\\", \\\"{x:1240,y:763,t:1526922786950};\\\", \\\"{x:1240,y:765,t:1526922786969};\\\", \\\"{x:1239,y:765,t:1526922786984};\\\", \\\"{x:1238,y:767,t:1526922787000};\\\", \\\"{x:1234,y:770,t:1526922787017};\\\", \\\"{x:1231,y:773,t:1526922787034};\\\", \\\"{x:1229,y:773,t:1526922787050};\\\", \\\"{x:1227,y:774,t:1526922787067};\\\", \\\"{x:1225,y:775,t:1526922787084};\\\", \\\"{x:1223,y:776,t:1526922787100};\\\", \\\"{x:1221,y:776,t:1526922787202};\\\", \\\"{x:1221,y:777,t:1526922787395};\\\", \\\"{x:1221,y:778,t:1526922787467};\\\", \\\"{x:1220,y:778,t:1526922787487};\\\", \\\"{x:1220,y:779,t:1526922787586};\\\", \\\"{x:1218,y:779,t:1526922787625};\\\", \\\"{x:1218,y:780,t:1526922787634};\\\", \\\"{x:1215,y:780,t:1526922787651};\\\", \\\"{x:1213,y:780,t:1526922787668};\\\", \\\"{x:1211,y:780,t:1526922787684};\\\", \\\"{x:1210,y:780,t:1526922787701};\\\", \\\"{x:1209,y:780,t:1526922787755};\\\", \\\"{x:1208,y:780,t:1526922787770};\\\", \\\"{x:1207,y:780,t:1526922787882};\\\", \\\"{x:1206,y:779,t:1526922787971};\\\", \\\"{x:1205,y:779,t:1526922787985};\\\", \\\"{x:1205,y:778,t:1526922788034};\\\", \\\"{x:1205,y:777,t:1526922788074};\\\", \\\"{x:1205,y:776,t:1526922788090};\\\", \\\"{x:1204,y:776,t:1526922788114};\\\", \\\"{x:1204,y:775,t:1526922788154};\\\", \\\"{x:1204,y:774,t:1526922788178};\\\", \\\"{x:1204,y:773,t:1526922788234};\\\", \\\"{x:1204,y:772,t:1526922788290};\\\", \\\"{x:1204,y:771,t:1526922788301};\\\", \\\"{x:1203,y:771,t:1526922788318};\\\", \\\"{x:1202,y:770,t:1526922788335};\\\", \\\"{x:1202,y:768,t:1526922788351};\\\", \\\"{x:1201,y:765,t:1526922788368};\\\", \\\"{x:1200,y:759,t:1526922788386};\\\", \\\"{x:1199,y:751,t:1526922788401};\\\", \\\"{x:1199,y:747,t:1526922788419};\\\", \\\"{x:1197,y:739,t:1526922788436};\\\", \\\"{x:1197,y:734,t:1526922788451};\\\", \\\"{x:1196,y:731,t:1526922788469};\\\", \\\"{x:1195,y:727,t:1526922788485};\\\", \\\"{x:1195,y:725,t:1526922788501};\\\", \\\"{x:1194,y:723,t:1526922788518};\\\", \\\"{x:1192,y:721,t:1526922788535};\\\", \\\"{x:1192,y:716,t:1526922788552};\\\", \\\"{x:1191,y:714,t:1526922788569};\\\", \\\"{x:1190,y:710,t:1526922788586};\\\", \\\"{x:1190,y:709,t:1526922788602};\\\", \\\"{x:1188,y:707,t:1526922788618};\\\", \\\"{x:1188,y:706,t:1526922788635};\\\", \\\"{x:1188,y:705,t:1526922788652};\\\", \\\"{x:1188,y:704,t:1526922788681};\\\", \\\"{x:1187,y:703,t:1526922789379};\\\", \\\"{x:1186,y:703,t:1526922789409};\\\", \\\"{x:1185,y:703,t:1526922789426};\\\", \\\"{x:1185,y:705,t:1526922789450};\\\", \\\"{x:1185,y:706,t:1526922789466};\\\", \\\"{x:1187,y:708,t:1526922789486};\\\", \\\"{x:1188,y:710,t:1526922789502};\\\", \\\"{x:1188,y:711,t:1526922789520};\\\", \\\"{x:1189,y:711,t:1526922789535};\\\", \\\"{x:1190,y:713,t:1526922789552};\\\", \\\"{x:1191,y:714,t:1526922789569};\\\", \\\"{x:1191,y:715,t:1526922789586};\\\", \\\"{x:1192,y:718,t:1526922789602};\\\", \\\"{x:1194,y:719,t:1526922789619};\\\", \\\"{x:1194,y:721,t:1526922789637};\\\", \\\"{x:1196,y:725,t:1526922789653};\\\", \\\"{x:1196,y:726,t:1526922789670};\\\", \\\"{x:1197,y:728,t:1526922789686};\\\", \\\"{x:1199,y:731,t:1526922789702};\\\", \\\"{x:1203,y:736,t:1526922789720};\\\", \\\"{x:1205,y:738,t:1526922789736};\\\", \\\"{x:1209,y:742,t:1526922789753};\\\", \\\"{x:1211,y:744,t:1526922789770};\\\", \\\"{x:1212,y:745,t:1526922789786};\\\", \\\"{x:1212,y:746,t:1526922789810};\\\", \\\"{x:1213,y:747,t:1526922789819};\\\", \\\"{x:1214,y:748,t:1526922789849};\\\", \\\"{x:1215,y:750,t:1526922789866};\\\", \\\"{x:1216,y:751,t:1526922789882};\\\", \\\"{x:1218,y:752,t:1526922789890};\\\", \\\"{x:1219,y:753,t:1526922789905};\\\", \\\"{x:1220,y:754,t:1526922789922};\\\", \\\"{x:1221,y:754,t:1526922789936};\\\", \\\"{x:1224,y:757,t:1526922789952};\\\", \\\"{x:1247,y:763,t:1526922789970};\\\", \\\"{x:1251,y:765,t:1526922789986};\\\", \\\"{x:1252,y:766,t:1526922790530};\\\", \\\"{x:1253,y:766,t:1526922790537};\\\", \\\"{x:1254,y:766,t:1526922790626};\\\", \\\"{x:1258,y:766,t:1526922790638};\\\", \\\"{x:1265,y:766,t:1526922790654};\\\", \\\"{x:1275,y:765,t:1526922790670};\\\", \\\"{x:1287,y:760,t:1526922790687};\\\", \\\"{x:1296,y:757,t:1526922790704};\\\", \\\"{x:1307,y:753,t:1526922790721};\\\", \\\"{x:1314,y:749,t:1526922790736};\\\", \\\"{x:1325,y:742,t:1526922790754};\\\", \\\"{x:1334,y:737,t:1526922790770};\\\", \\\"{x:1340,y:732,t:1526922790787};\\\", \\\"{x:1347,y:729,t:1526922790804};\\\", \\\"{x:1352,y:726,t:1526922790820};\\\", \\\"{x:1357,y:723,t:1526922790837};\\\", \\\"{x:1358,y:723,t:1526922790854};\\\", \\\"{x:1359,y:723,t:1526922790870};\\\", \\\"{x:1360,y:723,t:1526922790887};\\\", \\\"{x:1361,y:721,t:1526922790904};\\\", \\\"{x:1362,y:721,t:1526922791298};\\\", \\\"{x:1362,y:723,t:1526922791338};\\\", \\\"{x:1363,y:727,t:1526922791354};\\\", \\\"{x:1366,y:731,t:1526922791371};\\\", \\\"{x:1369,y:736,t:1526922791388};\\\", \\\"{x:1373,y:742,t:1526922791405};\\\", \\\"{x:1379,y:749,t:1526922791420};\\\", \\\"{x:1383,y:755,t:1526922791438};\\\", \\\"{x:1388,y:761,t:1526922791455};\\\", \\\"{x:1391,y:764,t:1526922791471};\\\", \\\"{x:1392,y:766,t:1526922791488};\\\", \\\"{x:1394,y:770,t:1526922791505};\\\", \\\"{x:1398,y:778,t:1526922791520};\\\", \\\"{x:1402,y:789,t:1526922791537};\\\", \\\"{x:1406,y:795,t:1526922791554};\\\", \\\"{x:1409,y:802,t:1526922791571};\\\", \\\"{x:1411,y:807,t:1526922791587};\\\", \\\"{x:1413,y:812,t:1526922791605};\\\", \\\"{x:1414,y:814,t:1526922791621};\\\", \\\"{x:1416,y:819,t:1526922791638};\\\", \\\"{x:1418,y:822,t:1526922791655};\\\", \\\"{x:1419,y:827,t:1526922791671};\\\", \\\"{x:1422,y:832,t:1526922791687};\\\", \\\"{x:1423,y:836,t:1526922791705};\\\", \\\"{x:1425,y:842,t:1526922791721};\\\", \\\"{x:1430,y:854,t:1526922791738};\\\", \\\"{x:1435,y:863,t:1526922791755};\\\", \\\"{x:1439,y:870,t:1526922791771};\\\", \\\"{x:1444,y:880,t:1526922791788};\\\", \\\"{x:1445,y:882,t:1526922791805};\\\", \\\"{x:1447,y:885,t:1526922791821};\\\", \\\"{x:1448,y:887,t:1526922791840};\\\", \\\"{x:1449,y:887,t:1526922791854};\\\", \\\"{x:1450,y:889,t:1526922791873};\\\", \\\"{x:1450,y:890,t:1526922791887};\\\", \\\"{x:1451,y:893,t:1526922791905};\\\", \\\"{x:1453,y:896,t:1526922791921};\\\", \\\"{x:1454,y:896,t:1526922791937};\\\", \\\"{x:1454,y:897,t:1526922791955};\\\", \\\"{x:1455,y:900,t:1526922791977};\\\", \\\"{x:1456,y:900,t:1526922791993};\\\", \\\"{x:1456,y:901,t:1526922792004};\\\", \\\"{x:1457,y:901,t:1526922792021};\\\", \\\"{x:1457,y:902,t:1526922792038};\\\", \\\"{x:1458,y:903,t:1526922792055};\\\", \\\"{x:1457,y:903,t:1526922794034};\\\", \\\"{x:1453,y:903,t:1526922794042};\\\", \\\"{x:1448,y:901,t:1526922794055};\\\", \\\"{x:1431,y:895,t:1526922794072};\\\", \\\"{x:1398,y:885,t:1526922794088};\\\", \\\"{x:1375,y:879,t:1526922794105};\\\", \\\"{x:1349,y:868,t:1526922794122};\\\", \\\"{x:1329,y:858,t:1526922794139};\\\", \\\"{x:1321,y:854,t:1526922794155};\\\", \\\"{x:1315,y:850,t:1526922794172};\\\", \\\"{x:1309,y:845,t:1526922794189};\\\", \\\"{x:1304,y:844,t:1526922794206};\\\", \\\"{x:1299,y:840,t:1526922794222};\\\", \\\"{x:1295,y:837,t:1526922794240};\\\", \\\"{x:1291,y:835,t:1526922794256};\\\", \\\"{x:1286,y:832,t:1526922794272};\\\", \\\"{x:1277,y:827,t:1526922794289};\\\", \\\"{x:1273,y:824,t:1526922794306};\\\", \\\"{x:1268,y:822,t:1526922794322};\\\", \\\"{x:1261,y:818,t:1526922794339};\\\", \\\"{x:1254,y:814,t:1526922794356};\\\", \\\"{x:1245,y:810,t:1526922794372};\\\", \\\"{x:1233,y:803,t:1526922794389};\\\", \\\"{x:1221,y:797,t:1526922794406};\\\", \\\"{x:1208,y:792,t:1526922794422};\\\", \\\"{x:1192,y:788,t:1526922794440};\\\", \\\"{x:1182,y:785,t:1526922794456};\\\", \\\"{x:1176,y:783,t:1526922794472};\\\", \\\"{x:1174,y:782,t:1526922794490};\\\", \\\"{x:1174,y:781,t:1526922794802};\\\", \\\"{x:1173,y:780,t:1526922794809};\\\", \\\"{x:1173,y:778,t:1526922794898};\\\", \\\"{x:1173,y:776,t:1526922794929};\\\", \\\"{x:1175,y:775,t:1526922794940};\\\", \\\"{x:1179,y:773,t:1526922794956};\\\", \\\"{x:1182,y:771,t:1526922794974};\\\", \\\"{x:1185,y:769,t:1526922794990};\\\", \\\"{x:1188,y:767,t:1526922795007};\\\", \\\"{x:1190,y:766,t:1526922795024};\\\", \\\"{x:1192,y:766,t:1526922795282};\\\", \\\"{x:1194,y:766,t:1526922795290};\\\", \\\"{x:1197,y:766,t:1526922795307};\\\", \\\"{x:1200,y:766,t:1526922795324};\\\", \\\"{x:1203,y:765,t:1526922795341};\\\", \\\"{x:1205,y:765,t:1526922795356};\\\", \\\"{x:1207,y:765,t:1526922795373};\\\", \\\"{x:1207,y:764,t:1526922795390};\\\", \\\"{x:1208,y:763,t:1526922795407};\\\", \\\"{x:1209,y:759,t:1526922795424};\\\", \\\"{x:1209,y:754,t:1526922795441};\\\", \\\"{x:1209,y:751,t:1526922795457};\\\", \\\"{x:1209,y:745,t:1526922795474};\\\", \\\"{x:1206,y:738,t:1526922795491};\\\", \\\"{x:1201,y:733,t:1526922795506};\\\", \\\"{x:1197,y:729,t:1526922795524};\\\", \\\"{x:1194,y:727,t:1526922795540};\\\", \\\"{x:1192,y:725,t:1526922795557};\\\", \\\"{x:1192,y:724,t:1526922795573};\\\", \\\"{x:1190,y:723,t:1526922795591};\\\", \\\"{x:1190,y:722,t:1526922795607};\\\", \\\"{x:1190,y:720,t:1526922795624};\\\", \\\"{x:1190,y:719,t:1526922795658};\\\", \\\"{x:1188,y:718,t:1526922795890};\\\", \\\"{x:1185,y:720,t:1526922795907};\\\", \\\"{x:1180,y:728,t:1526922795924};\\\", \\\"{x:1177,y:734,t:1526922795941};\\\", \\\"{x:1175,y:743,t:1526922795958};\\\", \\\"{x:1175,y:753,t:1526922795974};\\\", \\\"{x:1175,y:767,t:1526922795991};\\\", \\\"{x:1175,y:782,t:1526922796007};\\\", \\\"{x:1176,y:793,t:1526922796023};\\\", \\\"{x:1179,y:800,t:1526922796041};\\\", \\\"{x:1181,y:807,t:1526922796058};\\\", \\\"{x:1183,y:812,t:1526922796073};\\\", \\\"{x:1184,y:813,t:1526922796090};\\\", \\\"{x:1184,y:815,t:1526922796108};\\\", \\\"{x:1185,y:815,t:1526922796160};\\\", \\\"{x:1187,y:815,t:1526922796174};\\\", \\\"{x:1193,y:813,t:1526922796191};\\\", \\\"{x:1200,y:809,t:1526922796207};\\\", \\\"{x:1207,y:804,t:1526922796225};\\\", \\\"{x:1214,y:800,t:1526922796241};\\\", \\\"{x:1220,y:797,t:1526922796257};\\\", \\\"{x:1221,y:797,t:1526922796306};\\\", \\\"{x:1222,y:797,t:1526922796321};\\\", \\\"{x:1223,y:797,t:1526922796329};\\\", \\\"{x:1225,y:797,t:1526922796340};\\\", \\\"{x:1228,y:797,t:1526922796358};\\\", \\\"{x:1230,y:798,t:1526922796374};\\\", \\\"{x:1233,y:801,t:1526922796390};\\\", \\\"{x:1237,y:804,t:1526922796407};\\\", \\\"{x:1239,y:807,t:1526922796425};\\\", \\\"{x:1244,y:811,t:1526922796440};\\\", \\\"{x:1248,y:815,t:1526922796457};\\\", \\\"{x:1251,y:817,t:1526922796474};\\\", \\\"{x:1252,y:818,t:1526922796491};\\\", \\\"{x:1254,y:819,t:1526922796508};\\\", \\\"{x:1255,y:821,t:1526922796524};\\\", \\\"{x:1256,y:822,t:1526922796541};\\\", \\\"{x:1258,y:824,t:1526922796558};\\\", \\\"{x:1259,y:827,t:1526922796575};\\\", \\\"{x:1261,y:830,t:1526922796590};\\\", \\\"{x:1266,y:836,t:1526922796607};\\\", \\\"{x:1271,y:842,t:1526922796625};\\\", \\\"{x:1274,y:847,t:1526922796642};\\\", \\\"{x:1275,y:848,t:1526922796657};\\\", \\\"{x:1276,y:850,t:1526922796675};\\\", \\\"{x:1277,y:851,t:1526922796692};\\\", \\\"{x:1277,y:853,t:1526922796708};\\\", \\\"{x:1280,y:857,t:1526922796725};\\\", \\\"{x:1281,y:858,t:1526922796742};\\\", \\\"{x:1283,y:861,t:1526922796758};\\\", \\\"{x:1284,y:863,t:1526922796775};\\\", \\\"{x:1284,y:864,t:1526922796792};\\\", \\\"{x:1285,y:865,t:1526922796825};\\\", \\\"{x:1286,y:867,t:1526922796841};\\\", \\\"{x:1286,y:868,t:1526922796881};\\\", \\\"{x:1286,y:869,t:1526922796962};\\\", \\\"{x:1287,y:870,t:1526922797041};\\\", \\\"{x:1287,y:872,t:1526922797122};\\\", \\\"{x:1288,y:872,t:1526922797130};\\\", \\\"{x:1288,y:873,t:1526922797170};\\\", \\\"{x:1289,y:873,t:1526922798298};\\\", \\\"{x:1289,y:874,t:1526922798378};\\\", \\\"{x:1289,y:875,t:1526922798393};\\\", \\\"{x:1288,y:876,t:1526922798898};\\\", \\\"{x:1288,y:878,t:1526922798914};\\\", \\\"{x:1288,y:879,t:1526922798926};\\\", \\\"{x:1288,y:882,t:1526922798943};\\\", \\\"{x:1288,y:886,t:1526922798959};\\\", \\\"{x:1288,y:889,t:1526922798976};\\\", \\\"{x:1288,y:893,t:1526922798993};\\\", \\\"{x:1288,y:900,t:1526922799009};\\\", \\\"{x:1288,y:904,t:1526922799027};\\\", \\\"{x:1288,y:906,t:1526922799043};\\\", \\\"{x:1288,y:907,t:1526922799060};\\\", \\\"{x:1288,y:910,t:1526922799078};\\\", \\\"{x:1288,y:911,t:1526922799092};\\\", \\\"{x:1288,y:912,t:1526922799122};\\\", \\\"{x:1288,y:913,t:1526922799153};\\\", \\\"{x:1288,y:914,t:1526922799177};\\\", \\\"{x:1288,y:915,t:1526922799193};\\\", \\\"{x:1289,y:917,t:1526922799250};\\\", \\\"{x:1289,y:916,t:1526922802122};\\\", \\\"{x:1289,y:915,t:1526922802130};\\\", \\\"{x:1289,y:914,t:1526922805154};\\\", \\\"{x:1289,y:913,t:1526922805217};\\\", \\\"{x:1289,y:912,t:1526922807113};\\\", \\\"{x:1288,y:909,t:1526922807121};\\\", \\\"{x:1287,y:905,t:1526922807131};\\\", \\\"{x:1285,y:902,t:1526922807148};\\\", \\\"{x:1283,y:898,t:1526922807165};\\\", \\\"{x:1280,y:883,t:1526922807182};\\\", \\\"{x:1279,y:867,t:1526922807199};\\\", \\\"{x:1275,y:847,t:1526922807216};\\\", \\\"{x:1274,y:832,t:1526922807232};\\\", \\\"{x:1273,y:802,t:1526922807249};\\\", \\\"{x:1270,y:780,t:1526922807265};\\\", \\\"{x:1267,y:752,t:1526922807282};\\\", \\\"{x:1265,y:738,t:1526922807298};\\\", \\\"{x:1264,y:733,t:1526922807315};\\\", \\\"{x:1263,y:729,t:1526922807331};\\\", \\\"{x:1263,y:728,t:1526922807393};\\\", \\\"{x:1262,y:728,t:1526922807402};\\\", \\\"{x:1261,y:728,t:1526922807416};\\\", \\\"{x:1258,y:728,t:1526922807432};\\\", \\\"{x:1253,y:730,t:1526922807449};\\\", \\\"{x:1246,y:736,t:1526922807466};\\\", \\\"{x:1237,y:747,t:1526922807482};\\\", \\\"{x:1228,y:765,t:1526922807499};\\\", \\\"{x:1225,y:782,t:1526922807516};\\\", \\\"{x:1219,y:797,t:1526922807533};\\\", \\\"{x:1217,y:809,t:1526922807549};\\\", \\\"{x:1214,y:817,t:1526922807566};\\\", \\\"{x:1212,y:824,t:1526922807583};\\\", \\\"{x:1212,y:825,t:1526922807599};\\\", \\\"{x:1211,y:826,t:1526922807698};\\\", \\\"{x:1211,y:825,t:1526922807713};\\\", \\\"{x:1210,y:823,t:1526922807721};\\\", \\\"{x:1210,y:820,t:1526922807733};\\\", \\\"{x:1210,y:814,t:1526922807749};\\\", \\\"{x:1211,y:806,t:1526922807766};\\\", \\\"{x:1213,y:800,t:1526922807784};\\\", \\\"{x:1215,y:792,t:1526922807799};\\\", \\\"{x:1216,y:789,t:1526922807816};\\\", \\\"{x:1217,y:786,t:1526922807833};\\\", \\\"{x:1219,y:786,t:1526922807928};\\\", \\\"{x:1219,y:789,t:1526922807936};\\\", \\\"{x:1219,y:794,t:1526922807950};\\\", \\\"{x:1220,y:801,t:1526922807966};\\\", \\\"{x:1220,y:811,t:1526922807983};\\\", \\\"{x:1220,y:819,t:1526922808000};\\\", \\\"{x:1224,y:828,t:1526922808016};\\\", \\\"{x:1228,y:844,t:1526922808033};\\\", \\\"{x:1230,y:852,t:1526922808050};\\\", \\\"{x:1232,y:860,t:1526922808066};\\\", \\\"{x:1233,y:868,t:1526922808083};\\\", \\\"{x:1237,y:878,t:1526922808100};\\\", \\\"{x:1239,y:885,t:1526922808116};\\\", \\\"{x:1241,y:893,t:1526922808133};\\\", \\\"{x:1242,y:897,t:1526922808150};\\\", \\\"{x:1244,y:902,t:1526922808166};\\\", \\\"{x:1244,y:904,t:1526922808183};\\\", \\\"{x:1244,y:905,t:1526922808200};\\\", \\\"{x:1245,y:906,t:1526922808216};\\\", \\\"{x:1245,y:908,t:1526922808233};\\\", \\\"{x:1244,y:908,t:1526922808690};\\\", \\\"{x:1242,y:904,t:1526922808700};\\\", \\\"{x:1239,y:886,t:1526922808716};\\\", \\\"{x:1228,y:862,t:1526922808733};\\\", \\\"{x:1218,y:838,t:1526922808750};\\\", \\\"{x:1212,y:818,t:1526922808767};\\\", \\\"{x:1205,y:799,t:1526922808783};\\\", \\\"{x:1199,y:785,t:1526922808800};\\\", \\\"{x:1191,y:768,t:1526922808817};\\\", \\\"{x:1187,y:759,t:1526922808833};\\\", \\\"{x:1186,y:754,t:1526922808850};\\\", \\\"{x:1183,y:750,t:1526922808867};\\\", \\\"{x:1183,y:748,t:1526922808884};\\\", \\\"{x:1182,y:747,t:1526922808900};\\\", \\\"{x:1182,y:746,t:1526922808918};\\\", \\\"{x:1182,y:745,t:1526922808935};\\\", \\\"{x:1181,y:744,t:1526922808953};\\\", \\\"{x:1181,y:743,t:1526922808969};\\\", \\\"{x:1181,y:742,t:1526922809017};\\\", \\\"{x:1181,y:741,t:1526922809049};\\\", \\\"{x:1181,y:739,t:1526922809073};\\\", \\\"{x:1181,y:738,t:1526922809113};\\\", \\\"{x:1181,y:736,t:1526922809138};\\\", \\\"{x:1181,y:735,t:1526922809225};\\\", \\\"{x:1181,y:733,t:1526922809418};\\\", \\\"{x:1181,y:730,t:1526922809434};\\\", \\\"{x:1182,y:725,t:1526922809451};\\\", \\\"{x:1182,y:724,t:1526922809468};\\\", \\\"{x:1182,y:726,t:1526922809682};\\\", \\\"{x:1182,y:728,t:1526922809689};\\\", \\\"{x:1182,y:731,t:1526922809701};\\\", \\\"{x:1182,y:736,t:1526922809718};\\\", \\\"{x:1182,y:742,t:1526922809734};\\\", \\\"{x:1182,y:748,t:1526922809751};\\\", \\\"{x:1182,y:756,t:1526922809767};\\\", \\\"{x:1182,y:760,t:1526922809784};\\\", \\\"{x:1182,y:763,t:1526922809801};\\\", \\\"{x:1182,y:766,t:1526922809817};\\\", \\\"{x:1182,y:768,t:1526922809841};\\\", \\\"{x:1182,y:769,t:1526922809866};\\\", \\\"{x:1182,y:771,t:1526922809905};\\\", \\\"{x:1182,y:772,t:1526922809962};\\\", \\\"{x:1182,y:774,t:1526922809985};\\\", \\\"{x:1182,y:775,t:1526922810009};\\\", \\\"{x:1182,y:777,t:1526922810026};\\\", \\\"{x:1182,y:778,t:1526922810035};\\\", \\\"{x:1182,y:780,t:1526922810051};\\\", \\\"{x:1183,y:781,t:1526922810068};\\\", \\\"{x:1184,y:782,t:1526922810085};\\\", \\\"{x:1185,y:784,t:1526922810105};\\\", \\\"{x:1185,y:785,t:1526922810122};\\\", \\\"{x:1185,y:786,t:1526922810137};\\\", \\\"{x:1187,y:788,t:1526922810169};\\\", \\\"{x:1188,y:788,t:1526922810210};\\\", \\\"{x:1190,y:788,t:1526922810217};\\\", \\\"{x:1193,y:791,t:1526922810235};\\\", \\\"{x:1199,y:794,t:1526922810251};\\\", \\\"{x:1206,y:798,t:1526922810268};\\\", \\\"{x:1212,y:801,t:1526922810285};\\\", \\\"{x:1216,y:805,t:1526922810301};\\\", \\\"{x:1221,y:809,t:1526922810318};\\\", \\\"{x:1229,y:816,t:1526922810334};\\\", \\\"{x:1239,y:826,t:1526922810351};\\\", \\\"{x:1247,y:836,t:1526922810369};\\\", \\\"{x:1260,y:846,t:1526922810385};\\\", \\\"{x:1266,y:851,t:1526922810402};\\\", \\\"{x:1271,y:855,t:1526922810418};\\\", \\\"{x:1273,y:857,t:1526922810435};\\\", \\\"{x:1275,y:858,t:1526922810451};\\\", \\\"{x:1277,y:861,t:1526922810468};\\\", \\\"{x:1278,y:864,t:1526922810485};\\\", \\\"{x:1280,y:867,t:1526922810502};\\\", \\\"{x:1282,y:869,t:1526922810518};\\\", \\\"{x:1284,y:873,t:1526922810535};\\\", \\\"{x:1285,y:874,t:1526922810551};\\\", \\\"{x:1286,y:876,t:1526922810567};\\\", \\\"{x:1287,y:877,t:1526922810584};\\\", \\\"{x:1288,y:879,t:1526922810601};\\\", \\\"{x:1290,y:881,t:1526922810618};\\\", \\\"{x:1292,y:886,t:1526922810634};\\\", \\\"{x:1294,y:889,t:1526922810651};\\\", \\\"{x:1296,y:893,t:1526922810668};\\\", \\\"{x:1297,y:896,t:1526922810685};\\\", \\\"{x:1298,y:899,t:1526922810701};\\\", \\\"{x:1299,y:902,t:1526922810718};\\\", \\\"{x:1300,y:903,t:1526922810735};\\\", \\\"{x:1300,y:904,t:1526922810752};\\\", \\\"{x:1301,y:905,t:1526922810768};\\\", \\\"{x:1301,y:906,t:1526922810785};\\\", \\\"{x:1301,y:907,t:1526922810842};\\\", \\\"{x:1301,y:908,t:1526922810852};\\\", \\\"{x:1303,y:909,t:1526922810868};\\\", \\\"{x:1304,y:911,t:1526922810897};\\\", \\\"{x:1303,y:911,t:1526922811354};\\\", \\\"{x:1303,y:909,t:1526922814034};\\\", \\\"{x:1303,y:908,t:1526922814217};\\\", \\\"{x:1303,y:906,t:1526922814426};\\\", \\\"{x:1303,y:907,t:1526922817890};\\\", \\\"{x:1303,y:908,t:1526922817913};\\\", \\\"{x:1302,y:909,t:1526922818521};\\\", \\\"{x:1301,y:911,t:1526922818529};\\\", \\\"{x:1299,y:911,t:1526922818541};\\\", \\\"{x:1290,y:911,t:1526922818557};\\\", \\\"{x:1279,y:911,t:1526922818574};\\\", \\\"{x:1277,y:911,t:1526922818590};\\\", \\\"{x:1276,y:910,t:1526922818607};\\\", \\\"{x:1276,y:909,t:1526922819402};\\\", \\\"{x:1274,y:908,t:1526922819409};\\\", \\\"{x:1274,y:900,t:1526922819425};\\\", \\\"{x:1272,y:877,t:1526922819441};\\\", \\\"{x:1261,y:836,t:1526922819458};\\\", \\\"{x:1240,y:789,t:1526922819474};\\\", \\\"{x:1216,y:739,t:1526922819491};\\\", \\\"{x:1177,y:683,t:1526922819509};\\\", \\\"{x:1125,y:629,t:1526922819524};\\\", \\\"{x:1051,y:583,t:1526922819541};\\\", \\\"{x:968,y:549,t:1526922819559};\\\", \\\"{x:888,y:528,t:1526922819576};\\\", \\\"{x:809,y:512,t:1526922819591};\\\", \\\"{x:681,y:497,t:1526922819608};\\\", \\\"{x:591,y:493,t:1526922819627};\\\", \\\"{x:516,y:493,t:1526922819643};\\\", \\\"{x:457,y:493,t:1526922819660};\\\", \\\"{x:415,y:499,t:1526922819677};\\\", \\\"{x:384,y:512,t:1526922819695};\\\", \\\"{x:368,y:524,t:1526922819709};\\\", \\\"{x:360,y:535,t:1526922819727};\\\", \\\"{x:357,y:551,t:1526922819745};\\\", \\\"{x:356,y:572,t:1526922819760};\\\", \\\"{x:365,y:611,t:1526922819778};\\\", \\\"{x:382,y:637,t:1526922819795};\\\", \\\"{x:404,y:653,t:1526922819811};\\\", \\\"{x:426,y:663,t:1526922819827};\\\", \\\"{x:450,y:671,t:1526922819845};\\\", \\\"{x:488,y:676,t:1526922819876};\\\", \\\"{x:501,y:676,t:1526922819894};\\\", \\\"{x:506,y:676,t:1526922819910};\\\", \\\"{x:507,y:676,t:1526922819927};\\\", \\\"{x:508,y:677,t:1526922819944};\\\", \\\"{x:509,y:677,t:1526922819968};\\\", \\\"{x:510,y:678,t:1526922819977};\\\", \\\"{x:513,y:679,t:1526922819994};\\\", \\\"{x:515,y:681,t:1526922820010};\\\", \\\"{x:518,y:683,t:1526922820027};\\\", \\\"{x:522,y:683,t:1526922820044};\\\", \\\"{x:525,y:684,t:1526922820061};\\\" ] }, { \\\"rt\\\": 12407, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 419731, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:685,t:1526922824857};\\\", \\\"{x:529,y:685,t:1526922824864};\\\", \\\"{x:545,y:685,t:1526922824881};\\\", \\\"{x:564,y:685,t:1526922824898};\\\", \\\"{x:582,y:685,t:1526922824915};\\\", \\\"{x:583,y:685,t:1526922824931};\\\", \\\"{x:584,y:685,t:1526922825561};\\\", \\\"{x:585,y:684,t:1526922825568};\\\", \\\"{x:587,y:682,t:1526922825581};\\\", \\\"{x:591,y:681,t:1526922825598};\\\", \\\"{x:606,y:676,t:1526922825615};\\\", \\\"{x:649,y:672,t:1526922825633};\\\", \\\"{x:705,y:670,t:1526922825649};\\\", \\\"{x:786,y:670,t:1526922825665};\\\", \\\"{x:875,y:670,t:1526922825682};\\\", \\\"{x:958,y:670,t:1526922825698};\\\", \\\"{x:1039,y:670,t:1526922825716};\\\", \\\"{x:1100,y:670,t:1526922825733};\\\", \\\"{x:1140,y:670,t:1526922825749};\\\", \\\"{x:1170,y:674,t:1526922825766};\\\", \\\"{x:1190,y:677,t:1526922825782};\\\", \\\"{x:1198,y:678,t:1526922825799};\\\", \\\"{x:1201,y:680,t:1526922825816};\\\", \\\"{x:1207,y:683,t:1526922825832};\\\", \\\"{x:1214,y:686,t:1526922825849};\\\", \\\"{x:1225,y:691,t:1526922825866};\\\", \\\"{x:1240,y:697,t:1526922825883};\\\", \\\"{x:1257,y:699,t:1526922825899};\\\", \\\"{x:1273,y:701,t:1526922825915};\\\", \\\"{x:1284,y:701,t:1526922825933};\\\", \\\"{x:1291,y:701,t:1526922825948};\\\", \\\"{x:1297,y:701,t:1526922825966};\\\", \\\"{x:1303,y:701,t:1526922825983};\\\", \\\"{x:1310,y:701,t:1526922825999};\\\", \\\"{x:1319,y:700,t:1526922826016};\\\", \\\"{x:1338,y:698,t:1526922826033};\\\", \\\"{x:1349,y:698,t:1526922826049};\\\", \\\"{x:1361,y:698,t:1526922826067};\\\", \\\"{x:1370,y:698,t:1526922826083};\\\", \\\"{x:1373,y:698,t:1526922826099};\\\", \\\"{x:1374,y:698,t:1526922826225};\\\", \\\"{x:1375,y:698,t:1526922826241};\\\", \\\"{x:1377,y:698,t:1526922826249};\\\", \\\"{x:1379,y:702,t:1526922826266};\\\", \\\"{x:1382,y:708,t:1526922826283};\\\", \\\"{x:1386,y:715,t:1526922826300};\\\", \\\"{x:1394,y:726,t:1526922826316};\\\", \\\"{x:1405,y:743,t:1526922826333};\\\", \\\"{x:1415,y:760,t:1526922826349};\\\", \\\"{x:1425,y:774,t:1526922826366};\\\", \\\"{x:1434,y:785,t:1526922826383};\\\", \\\"{x:1443,y:799,t:1526922826400};\\\", \\\"{x:1447,y:809,t:1526922826416};\\\", \\\"{x:1456,y:825,t:1526922826433};\\\", \\\"{x:1463,y:835,t:1526922826450};\\\", \\\"{x:1467,y:841,t:1526922826465};\\\", \\\"{x:1471,y:848,t:1526922826482};\\\", \\\"{x:1476,y:855,t:1526922826500};\\\", \\\"{x:1479,y:860,t:1526922826516};\\\", \\\"{x:1479,y:861,t:1526922826532};\\\", \\\"{x:1480,y:862,t:1526922826550};\\\", \\\"{x:1480,y:863,t:1526922826585};\\\", \\\"{x:1482,y:864,t:1526922826600};\\\", \\\"{x:1482,y:866,t:1526922826617};\\\", \\\"{x:1483,y:869,t:1526922826633};\\\", \\\"{x:1484,y:871,t:1526922826650};\\\", \\\"{x:1485,y:873,t:1526922826667};\\\", \\\"{x:1485,y:875,t:1526922826683};\\\", \\\"{x:1486,y:878,t:1526922826700};\\\", \\\"{x:1487,y:881,t:1526922826717};\\\", \\\"{x:1487,y:882,t:1526922826733};\\\", \\\"{x:1487,y:883,t:1526922826750};\\\", \\\"{x:1488,y:883,t:1526922826767};\\\", \\\"{x:1489,y:884,t:1526922826783};\\\", \\\"{x:1490,y:884,t:1526922826801};\\\", \\\"{x:1492,y:887,t:1526922826817};\\\", \\\"{x:1492,y:888,t:1526922826832};\\\", \\\"{x:1493,y:889,t:1526922826850};\\\", \\\"{x:1493,y:890,t:1526922826867};\\\", \\\"{x:1493,y:891,t:1526922826905};\\\", \\\"{x:1493,y:893,t:1526922826953};\\\", \\\"{x:1493,y:894,t:1526922827009};\\\", \\\"{x:1493,y:896,t:1526922827041};\\\", \\\"{x:1492,y:897,t:1526922827050};\\\", \\\"{x:1491,y:899,t:1526922827067};\\\", \\\"{x:1491,y:900,t:1526922827083};\\\", \\\"{x:1491,y:903,t:1526922827100};\\\", \\\"{x:1489,y:905,t:1526922827117};\\\", \\\"{x:1487,y:906,t:1526922827456};\\\", \\\"{x:1487,y:907,t:1526922827488};\\\", \\\"{x:1487,y:908,t:1526922827520};\\\", \\\"{x:1487,y:909,t:1526922827534};\\\", \\\"{x:1487,y:910,t:1526922827560};\\\", \\\"{x:1487,y:911,t:1526922827650};\\\", \\\"{x:1487,y:912,t:1526922827658};\\\", \\\"{x:1486,y:912,t:1526922827826};\\\", \\\"{x:1485,y:912,t:1526922827834};\\\", \\\"{x:1483,y:912,t:1526922827850};\\\", \\\"{x:1482,y:912,t:1526922827867};\\\", \\\"{x:1481,y:912,t:1526922827883};\\\", \\\"{x:1479,y:909,t:1526922828546};\\\", \\\"{x:1479,y:908,t:1526922828553};\\\", \\\"{x:1479,y:906,t:1526922828568};\\\", \\\"{x:1476,y:902,t:1526922828585};\\\", \\\"{x:1475,y:899,t:1526922828601};\\\", \\\"{x:1472,y:893,t:1526922828618};\\\", \\\"{x:1471,y:891,t:1526922828635};\\\", \\\"{x:1470,y:888,t:1526922828650};\\\", \\\"{x:1468,y:885,t:1526922828667};\\\", \\\"{x:1467,y:882,t:1526922828685};\\\", \\\"{x:1466,y:881,t:1526922828704};\\\", \\\"{x:1466,y:882,t:1526922828882};\\\", \\\"{x:1466,y:883,t:1526922828889};\\\", \\\"{x:1466,y:885,t:1526922828901};\\\", \\\"{x:1467,y:887,t:1526922828918};\\\", \\\"{x:1467,y:888,t:1526922828935};\\\", \\\"{x:1467,y:889,t:1526922828952};\\\", \\\"{x:1468,y:890,t:1526922828968};\\\", \\\"{x:1468,y:891,t:1526922829009};\\\", \\\"{x:1468,y:892,t:1526922829024};\\\", \\\"{x:1469,y:894,t:1526922829035};\\\", \\\"{x:1470,y:894,t:1526922829052};\\\", \\\"{x:1470,y:895,t:1526922829068};\\\", \\\"{x:1471,y:895,t:1526922829085};\\\", \\\"{x:1471,y:896,t:1526922829102};\\\", \\\"{x:1473,y:898,t:1526922829118};\\\", \\\"{x:1473,y:899,t:1526922829135};\\\", \\\"{x:1474,y:900,t:1526922829152};\\\", \\\"{x:1474,y:901,t:1526922829168};\\\", \\\"{x:1475,y:903,t:1526922829185};\\\", \\\"{x:1475,y:904,t:1526922829201};\\\", \\\"{x:1476,y:905,t:1526922829218};\\\", \\\"{x:1476,y:904,t:1526922831184};\\\", \\\"{x:1476,y:903,t:1526922831224};\\\", \\\"{x:1474,y:903,t:1526922831235};\\\", \\\"{x:1474,y:901,t:1526922831256};\\\", \\\"{x:1473,y:900,t:1526922831270};\\\", \\\"{x:1470,y:893,t:1526922831286};\\\", \\\"{x:1461,y:881,t:1526922831303};\\\", \\\"{x:1451,y:866,t:1526922831320};\\\", \\\"{x:1425,y:831,t:1526922831336};\\\", \\\"{x:1392,y:790,t:1526922831352};\\\", \\\"{x:1351,y:741,t:1526922831370};\\\", \\\"{x:1302,y:684,t:1526922831387};\\\", \\\"{x:1257,y:631,t:1526922831403};\\\", \\\"{x:1206,y:580,t:1526922831420};\\\", \\\"{x:1162,y:544,t:1526922831437};\\\", \\\"{x:1135,y:518,t:1526922831453};\\\", \\\"{x:1121,y:499,t:1526922831469};\\\", \\\"{x:1115,y:489,t:1526922831487};\\\", \\\"{x:1112,y:483,t:1526922831503};\\\", \\\"{x:1111,y:482,t:1526922831519};\\\", \\\"{x:1110,y:478,t:1526922831536};\\\", \\\"{x:1108,y:477,t:1526922831552};\\\", \\\"{x:1107,y:475,t:1526922831569};\\\", \\\"{x:1102,y:473,t:1526922831587};\\\", \\\"{x:1097,y:473,t:1526922831603};\\\", \\\"{x:1086,y:474,t:1526922831619};\\\", \\\"{x:1062,y:483,t:1526922831637};\\\", \\\"{x:1031,y:495,t:1526922831652};\\\", \\\"{x:992,y:509,t:1526922831669};\\\", \\\"{x:953,y:520,t:1526922831687};\\\", \\\"{x:918,y:530,t:1526922831703};\\\", \\\"{x:893,y:537,t:1526922831720};\\\", \\\"{x:862,y:548,t:1526922831737};\\\", \\\"{x:844,y:556,t:1526922831753};\\\", \\\"{x:829,y:562,t:1526922831770};\\\", \\\"{x:815,y:565,t:1526922831786};\\\", \\\"{x:804,y:565,t:1526922831803};\\\", \\\"{x:790,y:565,t:1526922831820};\\\", \\\"{x:772,y:561,t:1526922831836};\\\", \\\"{x:742,y:548,t:1526922831853};\\\", \\\"{x:710,y:534,t:1526922831871};\\\", \\\"{x:678,y:515,t:1526922831886};\\\", \\\"{x:647,y:496,t:1526922831904};\\\", \\\"{x:623,y:477,t:1526922831920};\\\", \\\"{x:614,y:468,t:1526922831937};\\\", \\\"{x:608,y:460,t:1526922831954};\\\", \\\"{x:604,y:456,t:1526922831970};\\\", \\\"{x:598,y:454,t:1526922831986};\\\", \\\"{x:591,y:453,t:1526922832004};\\\", \\\"{x:582,y:454,t:1526922832020};\\\", \\\"{x:563,y:463,t:1526922832038};\\\", \\\"{x:545,y:472,t:1526922832053};\\\", \\\"{x:523,y:483,t:1526922832070};\\\", \\\"{x:507,y:494,t:1526922832087};\\\", \\\"{x:492,y:502,t:1526922832104};\\\", \\\"{x:480,y:509,t:1526922832121};\\\", \\\"{x:477,y:512,t:1526922832138};\\\", \\\"{x:468,y:517,t:1526922832153};\\\", \\\"{x:457,y:522,t:1526922832170};\\\", \\\"{x:445,y:526,t:1526922832187};\\\", \\\"{x:434,y:527,t:1526922832203};\\\", \\\"{x:425,y:529,t:1526922832220};\\\", \\\"{x:423,y:529,t:1526922832238};\\\", \\\"{x:421,y:529,t:1526922832254};\\\", \\\"{x:421,y:526,t:1526922832271};\\\", \\\"{x:427,y:517,t:1526922832286};\\\", \\\"{x:446,y:505,t:1526922832302};\\\", \\\"{x:489,y:484,t:1526922832318};\\\", \\\"{x:515,y:480,t:1526922832336};\\\", \\\"{x:535,y:476,t:1526922832351};\\\", \\\"{x:552,y:474,t:1526922832367};\\\", \\\"{x:562,y:474,t:1526922832385};\\\", \\\"{x:565,y:473,t:1526922832401};\\\", \\\"{x:567,y:473,t:1526922832418};\\\", \\\"{x:567,y:472,t:1526922832435};\\\", \\\"{x:569,y:471,t:1526922832452};\\\", \\\"{x:573,y:469,t:1526922832468};\\\", \\\"{x:578,y:467,t:1526922832485};\\\", \\\"{x:589,y:458,t:1526922832501};\\\", \\\"{x:606,y:446,t:1526922832518};\\\", \\\"{x:614,y:440,t:1526922832535};\\\", \\\"{x:615,y:439,t:1526922832552};\\\", \\\"{x:615,y:440,t:1526922832990};\\\", \\\"{x:615,y:444,t:1526922833002};\\\", \\\"{x:617,y:451,t:1526922833018};\\\", \\\"{x:620,y:462,t:1526922833035};\\\", \\\"{x:625,y:481,t:1526922833052};\\\", \\\"{x:633,y:504,t:1526922833070};\\\", \\\"{x:640,y:526,t:1526922833085};\\\", \\\"{x:642,y:567,t:1526922833103};\\\", \\\"{x:647,y:593,t:1526922833119};\\\", \\\"{x:652,y:619,t:1526922833135};\\\", \\\"{x:657,y:647,t:1526922833152};\\\", \\\"{x:657,y:665,t:1526922833169};\\\", \\\"{x:657,y:680,t:1526922833186};\\\", \\\"{x:657,y:693,t:1526922833202};\\\", \\\"{x:656,y:700,t:1526922833219};\\\", \\\"{x:656,y:706,t:1526922833236};\\\", \\\"{x:653,y:710,t:1526922833252};\\\", \\\"{x:652,y:711,t:1526922833286};\\\", \\\"{x:650,y:712,t:1526922833302};\\\", \\\"{x:646,y:713,t:1526922833320};\\\", \\\"{x:640,y:713,t:1526922833336};\\\", \\\"{x:632,y:714,t:1526922833352};\\\", \\\"{x:622,y:714,t:1526922833369};\\\", \\\"{x:611,y:714,t:1526922833386};\\\", \\\"{x:600,y:714,t:1526922833403};\\\", \\\"{x:591,y:714,t:1526922833419};\\\", \\\"{x:586,y:714,t:1526922833436};\\\", \\\"{x:584,y:714,t:1526922833453};\\\", \\\"{x:583,y:714,t:1526922833469};\\\", \\\"{x:579,y:714,t:1526922833486};\\\", \\\"{x:573,y:713,t:1526922833503};\\\", \\\"{x:568,y:712,t:1526922833520};\\\", \\\"{x:561,y:708,t:1526922833537};\\\", \\\"{x:549,y:702,t:1526922833554};\\\", \\\"{x:539,y:693,t:1526922833572};\\\", \\\"{x:533,y:684,t:1526922833586};\\\", \\\"{x:526,y:674,t:1526922833602};\\\", \\\"{x:522,y:669,t:1526922833619};\\\", \\\"{x:520,y:667,t:1526922833636};\\\", \\\"{x:520,y:665,t:1526922833654};\\\", \\\"{x:520,y:664,t:1526922833670};\\\", \\\"{x:519,y:664,t:1526922833919};\\\", \\\"{x:516,y:664,t:1526922833937};\\\", \\\"{x:515,y:668,t:1526922833955};\\\", \\\"{x:515,y:670,t:1526922833969};\\\", \\\"{x:515,y:671,t:1526922833986};\\\", \\\"{x:515,y:673,t:1526922834003};\\\" ] }, { \\\"rt\\\": 9912, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 430910, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -04 PM-03 PM-02 PM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:673,t:1526922837381};\\\", \\\"{x:521,y:672,t:1526922837389};\\\", \\\"{x:527,y:670,t:1526922837405};\\\", \\\"{x:549,y:668,t:1526922837422};\\\", \\\"{x:573,y:667,t:1526922837440};\\\", \\\"{x:604,y:667,t:1526922837456};\\\", \\\"{x:651,y:667,t:1526922837472};\\\", \\\"{x:712,y:667,t:1526922837489};\\\", \\\"{x:790,y:667,t:1526922837505};\\\", \\\"{x:860,y:656,t:1526922837522};\\\", \\\"{x:919,y:638,t:1526922837539};\\\", \\\"{x:968,y:621,t:1526922837556};\\\", \\\"{x:1018,y:598,t:1526922837572};\\\", \\\"{x:1079,y:565,t:1526922837590};\\\", \\\"{x:1122,y:544,t:1526922837605};\\\", \\\"{x:1155,y:530,t:1526922837622};\\\", \\\"{x:1179,y:519,t:1526922837639};\\\", \\\"{x:1198,y:512,t:1526922837656};\\\", \\\"{x:1211,y:504,t:1526922837672};\\\", \\\"{x:1215,y:502,t:1526922837689};\\\", \\\"{x:1220,y:499,t:1526922837706};\\\", \\\"{x:1221,y:498,t:1526922837725};\\\", \\\"{x:1222,y:498,t:1526922837739};\\\", \\\"{x:1227,y:498,t:1526922837756};\\\", \\\"{x:1251,y:513,t:1526922837773};\\\", \\\"{x:1269,y:536,t:1526922837789};\\\", \\\"{x:1347,y:626,t:1526922837806};\\\", \\\"{x:1399,y:687,t:1526922837824};\\\", \\\"{x:1454,y:739,t:1526922837840};\\\", \\\"{x:1500,y:781,t:1526922837856};\\\", \\\"{x:1528,y:814,t:1526922837873};\\\", \\\"{x:1549,y:843,t:1526922837890};\\\", \\\"{x:1559,y:860,t:1526922837907};\\\", \\\"{x:1564,y:873,t:1526922837923};\\\", \\\"{x:1566,y:886,t:1526922837941};\\\", \\\"{x:1571,y:902,t:1526922837956};\\\", \\\"{x:1575,y:921,t:1526922837973};\\\", \\\"{x:1579,y:930,t:1526922837989};\\\", \\\"{x:1581,y:940,t:1526922838006};\\\", \\\"{x:1582,y:946,t:1526922838023};\\\", \\\"{x:1582,y:948,t:1526922838040};\\\", \\\"{x:1582,y:949,t:1526922838056};\\\", \\\"{x:1582,y:950,t:1526922838074};\\\", \\\"{x:1582,y:952,t:1526922838090};\\\", \\\"{x:1582,y:953,t:1526922838107};\\\", \\\"{x:1582,y:954,t:1526922838142};\\\", \\\"{x:1581,y:954,t:1526922838166};\\\", \\\"{x:1580,y:954,t:1526922838174};\\\", \\\"{x:1576,y:954,t:1526922838190};\\\", \\\"{x:1569,y:954,t:1526922838208};\\\", \\\"{x:1563,y:953,t:1526922838224};\\\", \\\"{x:1558,y:951,t:1526922838240};\\\", \\\"{x:1555,y:950,t:1526922838257};\\\", \\\"{x:1554,y:949,t:1526922838273};\\\", \\\"{x:1554,y:948,t:1526922838293};\\\", \\\"{x:1553,y:947,t:1526922838307};\\\", \\\"{x:1553,y:945,t:1526922838324};\\\", \\\"{x:1554,y:941,t:1526922838340};\\\", \\\"{x:1566,y:935,t:1526922838357};\\\", \\\"{x:1577,y:929,t:1526922838373};\\\", \\\"{x:1592,y:926,t:1526922838390};\\\", \\\"{x:1608,y:923,t:1526922838407};\\\", \\\"{x:1622,y:922,t:1526922838424};\\\", \\\"{x:1629,y:922,t:1526922838440};\\\", \\\"{x:1630,y:922,t:1526922838457};\\\", \\\"{x:1629,y:922,t:1526922838509};\\\", \\\"{x:1626,y:922,t:1526922838525};\\\", \\\"{x:1603,y:925,t:1526922838541};\\\", \\\"{x:1579,y:928,t:1526922838558};\\\", \\\"{x:1548,y:930,t:1526922838574};\\\", \\\"{x:1517,y:930,t:1526922838592};\\\", \\\"{x:1482,y:930,t:1526922838607};\\\", \\\"{x:1446,y:930,t:1526922838625};\\\", \\\"{x:1423,y:930,t:1526922838641};\\\", \\\"{x:1404,y:930,t:1526922838657};\\\", \\\"{x:1390,y:930,t:1526922838674};\\\", \\\"{x:1378,y:930,t:1526922838692};\\\", \\\"{x:1368,y:931,t:1526922838708};\\\", \\\"{x:1355,y:931,t:1526922838724};\\\", \\\"{x:1341,y:931,t:1526922838741};\\\", \\\"{x:1333,y:931,t:1526922838757};\\\", \\\"{x:1326,y:931,t:1526922838774};\\\", \\\"{x:1319,y:931,t:1526922838791};\\\", \\\"{x:1314,y:933,t:1526922838808};\\\", \\\"{x:1312,y:934,t:1526922838824};\\\", \\\"{x:1311,y:934,t:1526922838853};\\\", \\\"{x:1310,y:933,t:1526922838934};\\\", \\\"{x:1310,y:931,t:1526922838942};\\\", \\\"{x:1312,y:925,t:1526922838958};\\\", \\\"{x:1315,y:918,t:1526922838975};\\\", \\\"{x:1316,y:913,t:1526922838991};\\\", \\\"{x:1318,y:910,t:1526922839009};\\\", \\\"{x:1318,y:908,t:1526922839026};\\\", \\\"{x:1318,y:906,t:1526922839042};\\\", \\\"{x:1319,y:903,t:1526922839058};\\\", \\\"{x:1321,y:901,t:1526922839076};\\\", \\\"{x:1322,y:900,t:1526922839091};\\\", \\\"{x:1322,y:898,t:1526922839108};\\\", \\\"{x:1323,y:897,t:1526922839126};\\\", \\\"{x:1323,y:896,t:1526922839142};\\\", \\\"{x:1324,y:896,t:1526922839190};\\\", \\\"{x:1325,y:896,t:1526922839198};\\\", \\\"{x:1327,y:896,t:1526922839214};\\\", \\\"{x:1328,y:896,t:1526922839230};\\\", \\\"{x:1331,y:897,t:1526922839242};\\\", \\\"{x:1335,y:899,t:1526922839258};\\\", \\\"{x:1338,y:900,t:1526922839275};\\\", \\\"{x:1339,y:901,t:1526922839292};\\\", \\\"{x:1341,y:901,t:1526922839310};\\\", \\\"{x:1341,y:902,t:1526922839341};\\\", \\\"{x:1342,y:903,t:1526922839359};\\\", \\\"{x:1344,y:904,t:1526922842133};\\\", \\\"{x:1347,y:904,t:1526922842147};\\\", \\\"{x:1351,y:905,t:1526922842163};\\\", \\\"{x:1357,y:908,t:1526922842180};\\\", \\\"{x:1365,y:910,t:1526922842197};\\\", \\\"{x:1365,y:911,t:1526922842213};\\\", \\\"{x:1365,y:912,t:1526922842798};\\\", \\\"{x:1364,y:912,t:1526922842844};\\\", \\\"{x:1363,y:912,t:1526922843333};\\\", \\\"{x:1362,y:912,t:1526922843869};\\\", \\\"{x:1361,y:911,t:1526922844541};\\\", \\\"{x:1354,y:907,t:1526922844781};\\\", \\\"{x:1337,y:897,t:1526922844789};\\\", \\\"{x:1310,y:884,t:1526922844801};\\\", \\\"{x:1236,y:854,t:1526922844818};\\\", \\\"{x:1128,y:824,t:1526922844834};\\\", \\\"{x:998,y:785,t:1526922844851};\\\", \\\"{x:871,y:752,t:1526922844868};\\\", \\\"{x:709,y:727,t:1526922844884};\\\", \\\"{x:617,y:714,t:1526922844900};\\\", \\\"{x:555,y:702,t:1526922844918};\\\", \\\"{x:516,y:691,t:1526922844936};\\\", \\\"{x:495,y:686,t:1526922844951};\\\", \\\"{x:489,y:684,t:1526922844961};\\\", \\\"{x:480,y:681,t:1526922844978};\\\", \\\"{x:474,y:679,t:1526922844994};\\\", \\\"{x:469,y:679,t:1526922845011};\\\", \\\"{x:464,y:679,t:1526922845028};\\\", \\\"{x:458,y:677,t:1526922845044};\\\", \\\"{x:457,y:677,t:1526922845061};\\\", \\\"{x:457,y:677,t:1526922845279};\\\" ] }, { \\\"rt\\\": 10985, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 443094, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:457,y:672,t:1526922847104};\\\", \\\"{x:458,y:669,t:1526922847115};\\\", \\\"{x:463,y:650,t:1526922847138};\\\", \\\"{x:465,y:643,t:1526922847146};\\\", \\\"{x:469,y:619,t:1526922847163};\\\", \\\"{x:475,y:598,t:1526922847181};\\\", \\\"{x:486,y:571,t:1526922847196};\\\", \\\"{x:508,y:536,t:1526922847213};\\\", \\\"{x:523,y:517,t:1526922847229};\\\", \\\"{x:537,y:504,t:1526922847247};\\\", \\\"{x:547,y:495,t:1526922847264};\\\", \\\"{x:554,y:489,t:1526922847280};\\\", \\\"{x:555,y:488,t:1526922847296};\\\", \\\"{x:557,y:488,t:1526922847837};\\\", \\\"{x:561,y:487,t:1526922847847};\\\", \\\"{x:575,y:484,t:1526922847863};\\\", \\\"{x:589,y:483,t:1526922847880};\\\", \\\"{x:607,y:479,t:1526922847897};\\\", \\\"{x:620,y:475,t:1526922847914};\\\", \\\"{x:629,y:472,t:1526922847931};\\\", \\\"{x:645,y:464,t:1526922847948};\\\", \\\"{x:659,y:458,t:1526922847964};\\\", \\\"{x:668,y:453,t:1526922847981};\\\", \\\"{x:677,y:449,t:1526922847997};\\\", \\\"{x:680,y:448,t:1526922848014};\\\", \\\"{x:681,y:447,t:1526922848030};\\\", \\\"{x:683,y:446,t:1526922848053};\\\", \\\"{x:684,y:446,t:1526922848068};\\\", \\\"{x:685,y:445,t:1526922848080};\\\", \\\"{x:692,y:444,t:1526922848097};\\\", \\\"{x:702,y:443,t:1526922848114};\\\", \\\"{x:719,y:443,t:1526922848130};\\\", \\\"{x:741,y:443,t:1526922848148};\\\", \\\"{x:766,y:449,t:1526922848164};\\\", \\\"{x:789,y:451,t:1526922848180};\\\", \\\"{x:811,y:453,t:1526922848197};\\\", \\\"{x:810,y:458,t:1526922848605};\\\", \\\"{x:801,y:457,t:1526922848614};\\\", \\\"{x:787,y:451,t:1526922848631};\\\", \\\"{x:778,y:451,t:1526922848647};\\\", \\\"{x:776,y:451,t:1526922848664};\\\", \\\"{x:778,y:452,t:1526922848853};\\\", \\\"{x:788,y:454,t:1526922848864};\\\", \\\"{x:811,y:460,t:1526922848881};\\\", \\\"{x:842,y:470,t:1526922848897};\\\", \\\"{x:884,y:489,t:1526922848915};\\\", \\\"{x:924,y:510,t:1526922848932};\\\", \\\"{x:965,y:534,t:1526922848949};\\\", \\\"{x:1004,y:560,t:1526922848964};\\\", \\\"{x:1047,y:595,t:1526922848981};\\\", \\\"{x:1081,y:630,t:1526922848998};\\\", \\\"{x:1106,y:651,t:1526922849014};\\\", \\\"{x:1127,y:669,t:1526922849031};\\\", \\\"{x:1146,y:684,t:1526922849049};\\\", \\\"{x:1169,y:702,t:1526922849065};\\\", \\\"{x:1199,y:720,t:1526922849082};\\\", \\\"{x:1223,y:732,t:1526922849099};\\\", \\\"{x:1244,y:738,t:1526922849115};\\\", \\\"{x:1265,y:744,t:1526922849131};\\\", \\\"{x:1283,y:748,t:1526922849148};\\\", \\\"{x:1298,y:748,t:1526922849164};\\\", \\\"{x:1316,y:748,t:1526922849181};\\\", \\\"{x:1324,y:745,t:1526922849199};\\\", \\\"{x:1330,y:742,t:1526922849214};\\\", \\\"{x:1336,y:734,t:1526922849232};\\\", \\\"{x:1344,y:725,t:1526922849248};\\\", \\\"{x:1352,y:718,t:1526922849264};\\\", \\\"{x:1364,y:711,t:1526922849281};\\\", \\\"{x:1374,y:703,t:1526922849298};\\\", \\\"{x:1385,y:695,t:1526922849314};\\\", \\\"{x:1392,y:687,t:1526922849331};\\\", \\\"{x:1393,y:682,t:1526922849349};\\\", \\\"{x:1394,y:678,t:1526922849364};\\\", \\\"{x:1396,y:675,t:1526922849381};\\\", \\\"{x:1396,y:672,t:1526922849398};\\\", \\\"{x:1396,y:671,t:1526922849414};\\\", \\\"{x:1396,y:668,t:1526922849431};\\\", \\\"{x:1396,y:667,t:1526922849448};\\\", \\\"{x:1395,y:664,t:1526922849464};\\\", \\\"{x:1393,y:662,t:1526922849485};\\\", \\\"{x:1393,y:661,t:1526922849501};\\\", \\\"{x:1392,y:661,t:1526922849514};\\\", \\\"{x:1390,y:658,t:1526922849531};\\\", \\\"{x:1386,y:656,t:1526922849549};\\\", \\\"{x:1379,y:654,t:1526922849564};\\\", \\\"{x:1365,y:650,t:1526922849581};\\\", \\\"{x:1360,y:649,t:1526922849598};\\\", \\\"{x:1353,y:648,t:1526922849614};\\\", \\\"{x:1349,y:646,t:1526922849632};\\\", \\\"{x:1346,y:646,t:1526922849648};\\\", \\\"{x:1345,y:645,t:1526922849665};\\\", \\\"{x:1343,y:644,t:1526922849681};\\\", \\\"{x:1343,y:643,t:1526922851629};\\\", \\\"{x:1343,y:642,t:1526922851636};\\\", \\\"{x:1343,y:640,t:1526922851649};\\\", \\\"{x:1343,y:639,t:1526922851665};\\\", \\\"{x:1343,y:637,t:1526922851685};\\\", \\\"{x:1345,y:640,t:1526922851925};\\\", \\\"{x:1347,y:643,t:1526922851949};\\\", \\\"{x:1349,y:646,t:1526922851965};\\\", \\\"{x:1351,y:651,t:1526922851983};\\\", \\\"{x:1351,y:653,t:1526922851999};\\\", \\\"{x:1353,y:659,t:1526922852016};\\\", \\\"{x:1353,y:665,t:1526922852033};\\\", \\\"{x:1353,y:669,t:1526922852049};\\\", \\\"{x:1353,y:673,t:1526922852065};\\\", \\\"{x:1353,y:676,t:1526922852082};\\\", \\\"{x:1353,y:680,t:1526922852100};\\\", \\\"{x:1353,y:683,t:1526922852115};\\\", \\\"{x:1352,y:687,t:1526922852132};\\\", \\\"{x:1351,y:691,t:1526922852149};\\\", \\\"{x:1350,y:694,t:1526922852166};\\\", \\\"{x:1349,y:696,t:1526922852183};\\\", \\\"{x:1349,y:698,t:1526922852199};\\\", \\\"{x:1348,y:701,t:1526922852215};\\\", \\\"{x:1346,y:702,t:1526922852236};\\\", \\\"{x:1346,y:703,t:1526922852249};\\\", \\\"{x:1346,y:704,t:1526922852265};\\\", \\\"{x:1346,y:705,t:1526922852285};\\\", \\\"{x:1346,y:706,t:1526922852299};\\\", \\\"{x:1345,y:707,t:1526922852316};\\\", \\\"{x:1345,y:708,t:1526922852341};\\\", \\\"{x:1345,y:709,t:1526922852348};\\\", \\\"{x:1345,y:710,t:1526922852365};\\\", \\\"{x:1344,y:710,t:1526922852383};\\\", \\\"{x:1344,y:712,t:1526922852400};\\\", \\\"{x:1344,y:714,t:1526922852416};\\\", \\\"{x:1344,y:715,t:1526922852432};\\\", \\\"{x:1344,y:716,t:1526922852449};\\\", \\\"{x:1344,y:717,t:1526922852469};\\\", \\\"{x:1344,y:718,t:1526922852549};\\\", \\\"{x:1344,y:719,t:1526922852973};\\\", \\\"{x:1343,y:719,t:1526922852982};\\\", \\\"{x:1341,y:719,t:1526922853541};\\\", \\\"{x:1340,y:719,t:1526922853564};\\\", \\\"{x:1340,y:718,t:1526922853589};\\\", \\\"{x:1340,y:717,t:1526922853599};\\\", \\\"{x:1340,y:716,t:1526922853620};\\\", \\\"{x:1340,y:714,t:1526922853637};\\\", \\\"{x:1340,y:713,t:1526922853660};\\\", \\\"{x:1340,y:711,t:1526922853685};\\\", \\\"{x:1341,y:711,t:1526922853893};\\\", \\\"{x:1342,y:711,t:1526922853901};\\\", \\\"{x:1343,y:713,t:1526922853917};\\\", \\\"{x:1343,y:717,t:1526922853933};\\\", \\\"{x:1343,y:722,t:1526922853949};\\\", \\\"{x:1344,y:729,t:1526922853966};\\\", \\\"{x:1344,y:736,t:1526922853983};\\\", \\\"{x:1344,y:742,t:1526922853999};\\\", \\\"{x:1344,y:748,t:1526922854016};\\\", \\\"{x:1345,y:753,t:1526922854033};\\\", \\\"{x:1346,y:758,t:1526922854050};\\\", \\\"{x:1347,y:762,t:1526922854067};\\\", \\\"{x:1347,y:764,t:1526922854084};\\\", \\\"{x:1347,y:766,t:1526922854100};\\\", \\\"{x:1347,y:770,t:1526922854116};\\\", \\\"{x:1348,y:772,t:1526922854141};\\\", \\\"{x:1348,y:773,t:1526922854164};\\\", \\\"{x:1348,y:775,t:1526922854181};\\\", \\\"{x:1348,y:776,t:1526922854197};\\\", \\\"{x:1348,y:778,t:1526922854213};\\\", \\\"{x:1348,y:779,t:1526922854221};\\\", \\\"{x:1348,y:780,t:1526922854234};\\\", \\\"{x:1349,y:783,t:1526922854249};\\\", \\\"{x:1349,y:786,t:1526922854266};\\\", \\\"{x:1349,y:789,t:1526922854284};\\\", \\\"{x:1349,y:791,t:1526922854299};\\\", \\\"{x:1349,y:794,t:1526922854316};\\\", \\\"{x:1350,y:796,t:1526922854333};\\\", \\\"{x:1351,y:800,t:1526922854350};\\\", \\\"{x:1351,y:802,t:1526922854366};\\\", \\\"{x:1351,y:804,t:1526922854384};\\\", \\\"{x:1351,y:805,t:1526922854400};\\\", \\\"{x:1351,y:807,t:1526922854417};\\\", \\\"{x:1351,y:808,t:1526922854433};\\\", \\\"{x:1351,y:810,t:1526922854450};\\\", \\\"{x:1351,y:811,t:1526922854466};\\\", \\\"{x:1350,y:810,t:1526922854605};\\\", \\\"{x:1350,y:809,t:1526922854617};\\\", \\\"{x:1348,y:803,t:1526922854633};\\\", \\\"{x:1345,y:795,t:1526922854650};\\\", \\\"{x:1342,y:784,t:1526922854666};\\\", \\\"{x:1339,y:772,t:1526922854683};\\\", \\\"{x:1332,y:752,t:1526922854700};\\\", \\\"{x:1330,y:740,t:1526922854716};\\\", \\\"{x:1325,y:726,t:1526922854733};\\\", \\\"{x:1320,y:711,t:1526922854750};\\\", \\\"{x:1316,y:698,t:1526922854766};\\\", \\\"{x:1309,y:685,t:1526922854783};\\\", \\\"{x:1295,y:667,t:1526922854800};\\\", \\\"{x:1273,y:648,t:1526922854817};\\\", \\\"{x:1233,y:625,t:1526922854834};\\\", \\\"{x:1173,y:592,t:1526922854851};\\\", \\\"{x:1095,y:556,t:1526922854867};\\\", \\\"{x:1012,y:529,t:1526922854884};\\\", \\\"{x:900,y:506,t:1526922854901};\\\", \\\"{x:855,y:492,t:1526922854917};\\\", \\\"{x:819,y:485,t:1526922854934};\\\", \\\"{x:793,y:480,t:1526922854950};\\\", \\\"{x:785,y:479,t:1526922854969};\\\", \\\"{x:781,y:479,t:1526922854986};\\\", \\\"{x:780,y:479,t:1526922855002};\\\", \\\"{x:779,y:479,t:1526922855028};\\\", \\\"{x:778,y:478,t:1526922855445};\\\", \\\"{x:777,y:478,t:1526922855461};\\\", \\\"{x:775,y:478,t:1526922855484};\\\", \\\"{x:771,y:479,t:1526922855493};\\\", \\\"{x:767,y:480,t:1526922855504};\\\", \\\"{x:753,y:487,t:1526922855519};\\\", \\\"{x:739,y:493,t:1526922855536};\\\", \\\"{x:719,y:500,t:1526922855554};\\\", \\\"{x:692,y:509,t:1526922855571};\\\", \\\"{x:667,y:516,t:1526922855587};\\\", \\\"{x:639,y:522,t:1526922855603};\\\", \\\"{x:617,y:526,t:1526922855619};\\\", \\\"{x:580,y:532,t:1526922855637};\\\", \\\"{x:553,y:532,t:1526922855654};\\\", \\\"{x:527,y:532,t:1526922855669};\\\", \\\"{x:502,y:525,t:1526922855686};\\\", \\\"{x:474,y:515,t:1526922855704};\\\", \\\"{x:449,y:504,t:1526922855720};\\\", \\\"{x:429,y:497,t:1526922855737};\\\", \\\"{x:412,y:492,t:1526922855753};\\\", \\\"{x:396,y:487,t:1526922855770};\\\", \\\"{x:383,y:486,t:1526922855786};\\\", \\\"{x:377,y:486,t:1526922855804};\\\", \\\"{x:372,y:486,t:1526922855821};\\\", \\\"{x:368,y:485,t:1526922855836};\\\", \\\"{x:362,y:485,t:1526922855853};\\\", \\\"{x:351,y:485,t:1526922855870};\\\", \\\"{x:339,y:487,t:1526922855887};\\\", \\\"{x:322,y:494,t:1526922855903};\\\", \\\"{x:301,y:505,t:1526922855921};\\\", \\\"{x:277,y:515,t:1526922855937};\\\", \\\"{x:256,y:521,t:1526922855954};\\\", \\\"{x:241,y:528,t:1526922855970};\\\", \\\"{x:229,y:533,t:1526922855987};\\\", \\\"{x:222,y:533,t:1526922856003};\\\", \\\"{x:213,y:533,t:1526922856021};\\\", \\\"{x:208,y:532,t:1526922856037};\\\", \\\"{x:202,y:530,t:1526922856053};\\\", \\\"{x:190,y:519,t:1526922856071};\\\", \\\"{x:181,y:508,t:1526922856087};\\\", \\\"{x:173,y:498,t:1526922856104};\\\", \\\"{x:164,y:487,t:1526922856121};\\\", \\\"{x:157,y:480,t:1526922856136};\\\", \\\"{x:154,y:478,t:1526922856153};\\\", \\\"{x:153,y:477,t:1526922856171};\\\", \\\"{x:152,y:475,t:1526922856187};\\\", \\\"{x:157,y:477,t:1526922856781};\\\", \\\"{x:165,y:482,t:1526922856789};\\\", \\\"{x:214,y:502,t:1526922856805};\\\", \\\"{x:313,y:543,t:1526922856821};\\\", \\\"{x:420,y:586,t:1526922856837};\\\", \\\"{x:524,y:631,t:1526922856855};\\\", \\\"{x:614,y:679,t:1526922856870};\\\", \\\"{x:661,y:710,t:1526922856887};\\\", \\\"{x:689,y:732,t:1526922856904};\\\", \\\"{x:700,y:747,t:1526922856920};\\\", \\\"{x:703,y:754,t:1526922856937};\\\", \\\"{x:703,y:755,t:1526922856954};\\\", \\\"{x:703,y:756,t:1526922856970};\\\", \\\"{x:703,y:757,t:1526922856987};\\\", \\\"{x:702,y:757,t:1526922857005};\\\", \\\"{x:698,y:757,t:1526922857020};\\\", \\\"{x:691,y:757,t:1526922857038};\\\", \\\"{x:677,y:757,t:1526922857054};\\\", \\\"{x:655,y:750,t:1526922857071};\\\", \\\"{x:630,y:744,t:1526922857087};\\\", \\\"{x:600,y:730,t:1526922857104};\\\", \\\"{x:584,y:723,t:1526922857121};\\\", \\\"{x:576,y:720,t:1526922857137};\\\", \\\"{x:571,y:717,t:1526922857155};\\\", \\\"{x:567,y:716,t:1526922857171};\\\", \\\"{x:564,y:716,t:1526922857188};\\\", \\\"{x:564,y:715,t:1526922857204};\\\", \\\"{x:562,y:713,t:1526922857221};\\\", \\\"{x:553,y:704,t:1526922857237};\\\", \\\"{x:544,y:695,t:1526922857255};\\\", \\\"{x:537,y:688,t:1526922857271};\\\", \\\"{x:531,y:681,t:1526922857287};\\\", \\\"{x:527,y:675,t:1526922857304};\\\", \\\"{x:527,y:671,t:1526922857322};\\\", \\\"{x:526,y:670,t:1526922857337};\\\" ] }, { \\\"rt\\\": 27569, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 471879, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\", \\\"C\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -N -Z -Z -Z -Z -04 PM-Z -04 PM-04 PM-04 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:667,t:1526922861693};\\\", \\\"{x:539,y:664,t:1526922861704};\\\", \\\"{x:605,y:664,t:1526922861721};\\\", \\\"{x:771,y:664,t:1526922861747};\\\", \\\"{x:899,y:664,t:1526922861759};\\\", \\\"{x:1043,y:664,t:1526922861774};\\\", \\\"{x:1181,y:664,t:1526922861792};\\\", \\\"{x:1322,y:664,t:1526922861809};\\\", \\\"{x:1441,y:664,t:1526922861825};\\\", \\\"{x:1557,y:664,t:1526922861841};\\\", \\\"{x:1653,y:659,t:1526922861859};\\\", \\\"{x:1740,y:653,t:1526922861875};\\\", \\\"{x:1804,y:646,t:1526922861892};\\\", \\\"{x:1872,y:640,t:1526922861908};\\\", \\\"{x:1901,y:631,t:1526922861924};\\\", \\\"{x:1918,y:622,t:1526922861942};\\\", \\\"{x:1919,y:619,t:1526922861959};\\\", \\\"{x:1919,y:618,t:1526922861974};\\\", \\\"{x:1919,y:617,t:1526922861991};\\\", \\\"{x:1919,y:612,t:1526922862008};\\\", \\\"{x:1915,y:605,t:1526922862025};\\\", \\\"{x:1908,y:598,t:1526922862041};\\\", \\\"{x:1905,y:594,t:1526922862059};\\\", \\\"{x:1903,y:594,t:1526922862074};\\\", \\\"{x:1902,y:594,t:1526922862093};\\\", \\\"{x:1901,y:594,t:1526922862117};\\\", \\\"{x:1900,y:594,t:1526922862125};\\\", \\\"{x:1890,y:587,t:1526922862142};\\\", \\\"{x:1886,y:580,t:1526922862159};\\\", \\\"{x:1882,y:574,t:1526922862175};\\\", \\\"{x:1880,y:572,t:1526922862192};\\\", \\\"{x:1878,y:569,t:1526922862209};\\\", \\\"{x:1874,y:564,t:1526922862224};\\\", \\\"{x:1873,y:562,t:1526922862242};\\\", \\\"{x:1871,y:559,t:1526922862258};\\\", \\\"{x:1866,y:557,t:1526922862275};\\\", \\\"{x:1852,y:551,t:1526922862292};\\\", \\\"{x:1820,y:537,t:1526922862309};\\\", \\\"{x:1795,y:529,t:1526922862325};\\\", \\\"{x:1758,y:512,t:1526922862341};\\\", \\\"{x:1720,y:498,t:1526922862359};\\\", \\\"{x:1697,y:490,t:1526922862375};\\\", \\\"{x:1674,y:485,t:1526922862392};\\\", \\\"{x:1661,y:485,t:1526922862409};\\\", \\\"{x:1651,y:488,t:1526922862426};\\\", \\\"{x:1643,y:495,t:1526922862442};\\\", \\\"{x:1632,y:512,t:1526922862458};\\\", \\\"{x:1623,y:537,t:1526922862476};\\\", \\\"{x:1616,y:567,t:1526922862492};\\\", \\\"{x:1610,y:607,t:1526922862508};\\\", \\\"{x:1610,y:637,t:1526922862526};\\\", \\\"{x:1612,y:664,t:1526922862542};\\\", \\\"{x:1621,y:688,t:1526922862558};\\\", \\\"{x:1631,y:712,t:1526922862575};\\\", \\\"{x:1643,y:732,t:1526922862592};\\\", \\\"{x:1652,y:747,t:1526922862608};\\\", \\\"{x:1658,y:757,t:1526922862626};\\\", \\\"{x:1662,y:765,t:1526922862642};\\\", \\\"{x:1665,y:769,t:1526922862658};\\\", \\\"{x:1667,y:770,t:1526922862675};\\\", \\\"{x:1667,y:771,t:1526922862860};\\\", \\\"{x:1665,y:771,t:1526922862875};\\\", \\\"{x:1654,y:771,t:1526922862892};\\\", \\\"{x:1647,y:771,t:1526922862908};\\\", \\\"{x:1637,y:769,t:1526922862925};\\\", \\\"{x:1630,y:766,t:1526922862943};\\\", \\\"{x:1622,y:763,t:1526922862959};\\\", \\\"{x:1614,y:758,t:1526922862975};\\\", \\\"{x:1605,y:753,t:1526922862993};\\\", \\\"{x:1600,y:749,t:1526922863008};\\\", \\\"{x:1598,y:746,t:1526922863026};\\\", \\\"{x:1594,y:741,t:1526922863043};\\\", \\\"{x:1589,y:735,t:1526922863059};\\\", \\\"{x:1584,y:724,t:1526922863076};\\\", \\\"{x:1573,y:708,t:1526922863093};\\\", \\\"{x:1558,y:692,t:1526922863109};\\\", \\\"{x:1544,y:679,t:1526922863126};\\\", \\\"{x:1528,y:666,t:1526922863142};\\\", \\\"{x:1510,y:654,t:1526922863159};\\\", \\\"{x:1496,y:641,t:1526922863176};\\\", \\\"{x:1486,y:631,t:1526922863193};\\\", \\\"{x:1482,y:625,t:1526922863208};\\\", \\\"{x:1482,y:624,t:1526922863236};\\\", \\\"{x:1482,y:623,t:1526922863244};\\\", \\\"{x:1482,y:622,t:1526922863259};\\\", \\\"{x:1482,y:620,t:1526922863276};\\\", \\\"{x:1481,y:618,t:1526922863292};\\\", \\\"{x:1480,y:614,t:1526922863310};\\\", \\\"{x:1476,y:609,t:1526922863326};\\\", \\\"{x:1470,y:601,t:1526922863342};\\\", \\\"{x:1465,y:595,t:1526922863360};\\\", \\\"{x:1457,y:589,t:1526922863375};\\\", \\\"{x:1454,y:586,t:1526922863393};\\\", \\\"{x:1452,y:585,t:1526922863410};\\\", \\\"{x:1453,y:584,t:1526922863445};\\\", \\\"{x:1455,y:582,t:1526922863460};\\\", \\\"{x:1460,y:581,t:1526922863476};\\\", \\\"{x:1469,y:579,t:1526922863492};\\\", \\\"{x:1479,y:598,t:1526922863510};\\\", \\\"{x:1493,y:622,t:1526922863525};\\\", \\\"{x:1508,y:651,t:1526922863542};\\\", \\\"{x:1536,y:691,t:1526922863560};\\\", \\\"{x:1555,y:723,t:1526922863576};\\\", \\\"{x:1566,y:748,t:1526922863593};\\\", \\\"{x:1574,y:774,t:1526922863610};\\\", \\\"{x:1585,y:796,t:1526922863626};\\\", \\\"{x:1589,y:812,t:1526922863643};\\\", \\\"{x:1590,y:823,t:1526922863660};\\\", \\\"{x:1590,y:828,t:1526922863676};\\\", \\\"{x:1589,y:832,t:1526922863692};\\\", \\\"{x:1586,y:835,t:1526922863710};\\\", \\\"{x:1586,y:837,t:1526922863726};\\\", \\\"{x:1586,y:838,t:1526922863748};\\\", \\\"{x:1586,y:839,t:1526922863764};\\\", \\\"{x:1585,y:840,t:1526922863836};\\\", \\\"{x:1588,y:841,t:1526922863844};\\\", \\\"{x:1595,y:837,t:1526922863859};\\\", \\\"{x:1623,y:822,t:1526922863876};\\\", \\\"{x:1644,y:813,t:1526922863893};\\\", \\\"{x:1657,y:806,t:1526922863909};\\\", \\\"{x:1670,y:797,t:1526922863926};\\\", \\\"{x:1677,y:792,t:1526922863943};\\\", \\\"{x:1686,y:787,t:1526922863959};\\\", \\\"{x:1689,y:784,t:1526922863977};\\\", \\\"{x:1692,y:782,t:1526922863992};\\\", \\\"{x:1693,y:781,t:1526922864010};\\\", \\\"{x:1694,y:780,t:1526922864027};\\\", \\\"{x:1694,y:781,t:1526922864108};\\\", \\\"{x:1692,y:781,t:1526922864117};\\\", \\\"{x:1682,y:781,t:1526922864127};\\\", \\\"{x:1656,y:781,t:1526922864142};\\\", \\\"{x:1609,y:781,t:1526922864159};\\\", \\\"{x:1552,y:779,t:1526922864177};\\\", \\\"{x:1488,y:771,t:1526922864193};\\\", \\\"{x:1432,y:763,t:1526922864210};\\\", \\\"{x:1388,y:759,t:1526922864227};\\\", \\\"{x:1364,y:755,t:1526922864243};\\\", \\\"{x:1347,y:755,t:1526922864260};\\\", \\\"{x:1336,y:755,t:1526922864277};\\\", \\\"{x:1334,y:755,t:1526922864293};\\\", \\\"{x:1331,y:756,t:1526922864309};\\\", \\\"{x:1329,y:757,t:1526922864327};\\\", \\\"{x:1327,y:758,t:1526922864343};\\\", \\\"{x:1324,y:760,t:1526922864360};\\\", \\\"{x:1319,y:761,t:1526922864377};\\\", \\\"{x:1316,y:763,t:1526922864394};\\\", \\\"{x:1315,y:763,t:1526922864557};\\\", \\\"{x:1316,y:763,t:1526922864589};\\\", \\\"{x:1316,y:762,t:1526922864597};\\\", \\\"{x:1317,y:762,t:1526922864610};\\\", \\\"{x:1318,y:761,t:1526922864627};\\\", \\\"{x:1320,y:760,t:1526922864644};\\\", \\\"{x:1322,y:759,t:1526922864659};\\\", \\\"{x:1325,y:759,t:1526922864676};\\\", \\\"{x:1328,y:757,t:1526922864694};\\\", \\\"{x:1329,y:756,t:1526922864710};\\\", \\\"{x:1334,y:754,t:1526922864726};\\\", \\\"{x:1340,y:752,t:1526922864744};\\\", \\\"{x:1351,y:749,t:1526922864760};\\\", \\\"{x:1369,y:749,t:1526922864777};\\\", \\\"{x:1383,y:749,t:1526922864794};\\\", \\\"{x:1401,y:749,t:1526922864810};\\\", \\\"{x:1417,y:749,t:1526922864827};\\\", \\\"{x:1439,y:749,t:1526922864844};\\\", \\\"{x:1469,y:754,t:1526922864859};\\\", \\\"{x:1504,y:762,t:1526922864877};\\\", \\\"{x:1530,y:768,t:1526922864894};\\\", \\\"{x:1551,y:771,t:1526922864911};\\\", \\\"{x:1569,y:772,t:1526922864927};\\\", \\\"{x:1581,y:772,t:1526922864944};\\\", \\\"{x:1589,y:767,t:1526922864961};\\\", \\\"{x:1595,y:750,t:1526922864976};\\\", \\\"{x:1601,y:727,t:1526922864993};\\\", \\\"{x:1606,y:706,t:1526922865011};\\\", \\\"{x:1606,y:686,t:1526922865027};\\\", \\\"{x:1606,y:671,t:1526922865044};\\\", \\\"{x:1606,y:659,t:1526922865061};\\\", \\\"{x:1606,y:658,t:1526922865077};\\\", \\\"{x:1606,y:657,t:1526922865101};\\\", \\\"{x:1606,y:655,t:1526922865277};\\\", \\\"{x:1606,y:652,t:1526922865294};\\\", \\\"{x:1607,y:647,t:1526922865310};\\\", \\\"{x:1609,y:643,t:1526922865327};\\\", \\\"{x:1609,y:640,t:1526922865344};\\\", \\\"{x:1609,y:638,t:1526922865361};\\\", \\\"{x:1610,y:636,t:1526922865378};\\\", \\\"{x:1610,y:635,t:1526922865740};\\\", \\\"{x:1610,y:634,t:1526922865764};\\\", \\\"{x:1610,y:633,t:1526922865908};\\\", \\\"{x:1611,y:633,t:1526922865916};\\\", \\\"{x:1612,y:633,t:1526922865933};\\\", \\\"{x:1613,y:634,t:1526922865956};\\\", \\\"{x:1613,y:635,t:1526922865980};\\\", \\\"{x:1614,y:635,t:1526922865994};\\\", \\\"{x:1614,y:636,t:1526922866011};\\\", \\\"{x:1614,y:637,t:1526922866027};\\\", \\\"{x:1615,y:638,t:1526922866045};\\\", \\\"{x:1615,y:640,t:1526922866215};\\\", \\\"{x:1615,y:641,t:1526922866245};\\\", \\\"{x:1615,y:643,t:1526922866261};\\\", \\\"{x:1615,y:644,t:1526922866278};\\\", \\\"{x:1615,y:645,t:1526922866565};\\\", \\\"{x:1615,y:646,t:1526922866581};\\\", \\\"{x:1615,y:647,t:1526922866595};\\\", \\\"{x:1616,y:649,t:1526922866612};\\\", \\\"{x:1617,y:650,t:1526922866645};\\\", \\\"{x:1618,y:651,t:1526922866700};\\\", \\\"{x:1618,y:652,t:1526922866733};\\\", \\\"{x:1617,y:651,t:1526922867724};\\\", \\\"{x:1616,y:651,t:1526922867732};\\\", \\\"{x:1615,y:651,t:1526922867746};\\\", \\\"{x:1614,y:648,t:1526922867762};\\\", \\\"{x:1613,y:647,t:1526922867779};\\\", \\\"{x:1612,y:645,t:1526922867796};\\\", \\\"{x:1611,y:644,t:1526922867812};\\\", \\\"{x:1611,y:643,t:1526922867829};\\\", \\\"{x:1611,y:642,t:1526922867932};\\\", \\\"{x:1611,y:643,t:1526922869700};\\\", \\\"{x:1611,y:646,t:1526922869714};\\\", \\\"{x:1612,y:651,t:1526922869730};\\\", \\\"{x:1613,y:660,t:1526922869747};\\\", \\\"{x:1614,y:668,t:1526922869763};\\\", \\\"{x:1618,y:686,t:1526922869780};\\\", \\\"{x:1627,y:724,t:1526922869797};\\\", \\\"{x:1630,y:747,t:1526922869814};\\\", \\\"{x:1634,y:772,t:1526922869830};\\\", \\\"{x:1638,y:799,t:1526922869847};\\\", \\\"{x:1642,y:823,t:1526922869864};\\\", \\\"{x:1644,y:840,t:1526922869880};\\\", \\\"{x:1646,y:850,t:1526922869897};\\\", \\\"{x:1646,y:858,t:1526922869915};\\\", \\\"{x:1646,y:862,t:1526922869931};\\\", \\\"{x:1648,y:866,t:1526922869947};\\\", \\\"{x:1648,y:870,t:1526922869964};\\\", \\\"{x:1648,y:876,t:1526922869980};\\\", \\\"{x:1643,y:890,t:1526922869997};\\\", \\\"{x:1642,y:897,t:1526922870014};\\\", \\\"{x:1640,y:903,t:1526922870030};\\\", \\\"{x:1638,y:907,t:1526922870047};\\\", \\\"{x:1637,y:911,t:1526922870064};\\\", \\\"{x:1636,y:914,t:1526922870081};\\\", \\\"{x:1635,y:916,t:1526922870097};\\\", \\\"{x:1635,y:917,t:1526922870114};\\\", \\\"{x:1634,y:918,t:1526922870133};\\\", \\\"{x:1633,y:919,t:1526922870147};\\\", \\\"{x:1632,y:919,t:1526922870164};\\\", \\\"{x:1631,y:920,t:1526922870181};\\\", \\\"{x:1629,y:920,t:1526922870197};\\\", \\\"{x:1628,y:920,t:1526922870214};\\\", \\\"{x:1627,y:920,t:1526922870236};\\\", \\\"{x:1626,y:920,t:1526922870247};\\\", \\\"{x:1625,y:920,t:1526922870264};\\\", \\\"{x:1624,y:920,t:1526922870301};\\\", \\\"{x:1623,y:920,t:1526922870314};\\\", \\\"{x:1622,y:919,t:1526922870333};\\\", \\\"{x:1621,y:918,t:1526922870357};\\\", \\\"{x:1620,y:918,t:1526922870364};\\\", \\\"{x:1619,y:916,t:1526922870380};\\\", \\\"{x:1618,y:914,t:1526922870398};\\\", \\\"{x:1617,y:914,t:1526922870413};\\\", \\\"{x:1615,y:910,t:1526922870431};\\\", \\\"{x:1614,y:909,t:1526922870453};\\\", \\\"{x:1613,y:908,t:1526922870476};\\\", \\\"{x:1613,y:907,t:1526922870500};\\\", \\\"{x:1611,y:906,t:1526922870515};\\\", \\\"{x:1610,y:905,t:1526922870645};\\\", \\\"{x:1610,y:904,t:1526922870653};\\\", \\\"{x:1610,y:903,t:1526922870664};\\\", \\\"{x:1610,y:897,t:1526922870682};\\\", \\\"{x:1610,y:891,t:1526922870698};\\\", \\\"{x:1610,y:883,t:1526922870714};\\\", \\\"{x:1610,y:876,t:1526922870731};\\\", \\\"{x:1610,y:867,t:1526922870748};\\\", \\\"{x:1610,y:860,t:1526922870764};\\\", \\\"{x:1610,y:848,t:1526922870781};\\\", \\\"{x:1610,y:839,t:1526922870798};\\\", \\\"{x:1610,y:831,t:1526922870815};\\\", \\\"{x:1610,y:822,t:1526922870831};\\\", \\\"{x:1610,y:815,t:1526922870848};\\\", \\\"{x:1610,y:809,t:1526922870864};\\\", \\\"{x:1610,y:800,t:1526922870881};\\\", \\\"{x:1612,y:791,t:1526922870898};\\\", \\\"{x:1612,y:784,t:1526922870914};\\\", \\\"{x:1612,y:777,t:1526922870931};\\\", \\\"{x:1614,y:771,t:1526922870948};\\\", \\\"{x:1614,y:759,t:1526922870965};\\\", \\\"{x:1614,y:750,t:1526922870981};\\\", \\\"{x:1614,y:739,t:1526922870998};\\\", \\\"{x:1614,y:733,t:1526922871014};\\\", \\\"{x:1614,y:729,t:1526922871032};\\\", \\\"{x:1614,y:725,t:1526922871048};\\\", \\\"{x:1614,y:719,t:1526922871065};\\\", \\\"{x:1614,y:713,t:1526922871082};\\\", \\\"{x:1614,y:706,t:1526922871098};\\\", \\\"{x:1614,y:702,t:1526922871114};\\\", \\\"{x:1614,y:697,t:1526922871131};\\\", \\\"{x:1614,y:692,t:1526922871148};\\\", \\\"{x:1612,y:684,t:1526922871165};\\\", \\\"{x:1612,y:681,t:1526922871182};\\\", \\\"{x:1612,y:677,t:1526922871198};\\\", \\\"{x:1612,y:674,t:1526922871215};\\\", \\\"{x:1612,y:671,t:1526922871231};\\\", \\\"{x:1612,y:670,t:1526922871248};\\\", \\\"{x:1612,y:669,t:1526922871266};\\\", \\\"{x:1612,y:667,t:1526922871281};\\\", \\\"{x:1612,y:664,t:1526922871298};\\\", \\\"{x:1613,y:661,t:1526922871316};\\\", \\\"{x:1613,y:657,t:1526922871331};\\\", \\\"{x:1614,y:654,t:1526922871349};\\\", \\\"{x:1616,y:648,t:1526922871365};\\\", \\\"{x:1617,y:645,t:1526922871381};\\\", \\\"{x:1617,y:644,t:1526922871398};\\\", \\\"{x:1617,y:642,t:1526922871415};\\\", \\\"{x:1617,y:641,t:1526922871431};\\\", \\\"{x:1617,y:650,t:1526922871877};\\\", \\\"{x:1617,y:658,t:1526922871885};\\\", \\\"{x:1617,y:669,t:1526922871899};\\\", \\\"{x:1615,y:694,t:1526922871916};\\\", \\\"{x:1615,y:724,t:1526922871932};\\\", \\\"{x:1615,y:755,t:1526922871948};\\\", \\\"{x:1615,y:799,t:1526922871966};\\\", \\\"{x:1615,y:830,t:1526922871982};\\\", \\\"{x:1615,y:860,t:1526922871998};\\\", \\\"{x:1615,y:884,t:1526922872016};\\\", \\\"{x:1615,y:903,t:1526922872033};\\\", \\\"{x:1615,y:916,t:1526922872049};\\\", \\\"{x:1615,y:928,t:1526922872066};\\\", \\\"{x:1615,y:936,t:1526922872083};\\\", \\\"{x:1615,y:945,t:1526922872099};\\\", \\\"{x:1614,y:952,t:1526922872116};\\\", \\\"{x:1613,y:960,t:1526922872132};\\\", \\\"{x:1612,y:970,t:1526922872148};\\\", \\\"{x:1611,y:972,t:1526922872165};\\\", \\\"{x:1611,y:969,t:1526922872236};\\\", \\\"{x:1612,y:963,t:1526922872249};\\\", \\\"{x:1616,y:948,t:1526922872265};\\\", \\\"{x:1622,y:930,t:1526922872282};\\\", \\\"{x:1627,y:910,t:1526922872300};\\\", \\\"{x:1628,y:900,t:1526922872315};\\\", \\\"{x:1628,y:893,t:1526922872332};\\\", \\\"{x:1629,y:885,t:1526922872349};\\\", \\\"{x:1629,y:883,t:1526922872365};\\\", \\\"{x:1629,y:882,t:1526922872388};\\\", \\\"{x:1629,y:881,t:1526922872548};\\\", \\\"{x:1627,y:881,t:1526922872565};\\\", \\\"{x:1616,y:894,t:1526922872582};\\\", \\\"{x:1604,y:916,t:1526922872600};\\\", \\\"{x:1589,y:940,t:1526922872615};\\\", \\\"{x:1582,y:952,t:1526922872632};\\\", \\\"{x:1580,y:959,t:1526922872649};\\\", \\\"{x:1580,y:960,t:1526922872667};\\\", \\\"{x:1580,y:959,t:1526922872724};\\\", \\\"{x:1580,y:955,t:1526922872732};\\\", \\\"{x:1580,y:946,t:1526922872750};\\\", \\\"{x:1580,y:938,t:1526922872766};\\\", \\\"{x:1580,y:931,t:1526922872782};\\\", \\\"{x:1581,y:925,t:1526922872799};\\\", \\\"{x:1581,y:918,t:1526922872816};\\\", \\\"{x:1583,y:913,t:1526922872832};\\\", \\\"{x:1584,y:909,t:1526922872849};\\\", \\\"{x:1585,y:906,t:1526922872866};\\\", \\\"{x:1585,y:903,t:1526922872882};\\\", \\\"{x:1587,y:901,t:1526922872900};\\\", \\\"{x:1587,y:899,t:1526922872916};\\\", \\\"{x:1587,y:898,t:1526922872932};\\\", \\\"{x:1587,y:899,t:1526922873132};\\\", \\\"{x:1588,y:901,t:1526922873149};\\\", \\\"{x:1588,y:903,t:1526922873166};\\\", \\\"{x:1590,y:905,t:1526922873429};\\\", \\\"{x:1591,y:908,t:1526922873436};\\\", \\\"{x:1594,y:913,t:1526922873450};\\\", \\\"{x:1599,y:921,t:1526922873466};\\\", \\\"{x:1604,y:929,t:1526922873483};\\\", \\\"{x:1608,y:933,t:1526922873500};\\\", \\\"{x:1610,y:934,t:1526922873516};\\\", \\\"{x:1612,y:934,t:1526922873548};\\\", \\\"{x:1614,y:933,t:1526922873556};\\\", \\\"{x:1615,y:933,t:1526922873565};\\\", \\\"{x:1618,y:931,t:1526922873584};\\\", \\\"{x:1620,y:929,t:1526922873599};\\\", \\\"{x:1621,y:927,t:1526922873616};\\\", \\\"{x:1621,y:925,t:1526922873633};\\\", \\\"{x:1622,y:924,t:1526922873649};\\\", \\\"{x:1622,y:923,t:1526922873668};\\\", \\\"{x:1622,y:922,t:1526922873693};\\\", \\\"{x:1622,y:921,t:1526922873789};\\\", \\\"{x:1622,y:920,t:1526922873813};\\\", \\\"{x:1620,y:919,t:1526922873829};\\\", \\\"{x:1619,y:919,t:1526922873852};\\\", \\\"{x:1618,y:918,t:1526922873884};\\\", \\\"{x:1617,y:918,t:1526922873900};\\\", \\\"{x:1617,y:914,t:1526922873916};\\\", \\\"{x:1615,y:912,t:1526922873933};\\\", \\\"{x:1615,y:911,t:1526922873950};\\\", \\\"{x:1614,y:910,t:1526922873966};\\\", \\\"{x:1614,y:909,t:1526922873983};\\\", \\\"{x:1614,y:908,t:1526922874037};\\\", \\\"{x:1613,y:907,t:1526922874085};\\\", \\\"{x:1611,y:906,t:1526922874101};\\\", \\\"{x:1611,y:905,t:1526922874133};\\\", \\\"{x:1610,y:898,t:1526922877364};\\\", \\\"{x:1607,y:887,t:1526922877373};\\\", \\\"{x:1604,y:874,t:1526922877386};\\\", \\\"{x:1599,y:833,t:1526922877402};\\\", \\\"{x:1590,y:788,t:1526922877419};\\\", \\\"{x:1584,y:753,t:1526922877436};\\\", \\\"{x:1568,y:717,t:1526922877453};\\\", \\\"{x:1522,y:658,t:1526922877470};\\\", \\\"{x:1458,y:584,t:1526922877486};\\\", \\\"{x:1376,y:520,t:1526922877503};\\\", \\\"{x:1261,y:456,t:1526922877520};\\\", \\\"{x:1108,y:368,t:1526922877535};\\\", \\\"{x:930,y:302,t:1526922877552};\\\", \\\"{x:756,y:257,t:1526922877569};\\\", \\\"{x:612,y:237,t:1526922877585};\\\", \\\"{x:518,y:237,t:1526922877602};\\\", \\\"{x:486,y:237,t:1526922877620};\\\", \\\"{x:479,y:238,t:1526922877635};\\\", \\\"{x:479,y:244,t:1526922877652};\\\", \\\"{x:480,y:252,t:1526922877669};\\\", \\\"{x:484,y:262,t:1526922877686};\\\", \\\"{x:487,y:267,t:1526922877702};\\\", \\\"{x:490,y:268,t:1526922877719};\\\", \\\"{x:489,y:272,t:1526922877748};\\\", \\\"{x:490,y:272,t:1526922877780};\\\", \\\"{x:497,y:277,t:1526922877787};\\\", \\\"{x:503,y:285,t:1526922877802};\\\", \\\"{x:493,y:297,t:1526922877819};\\\", \\\"{x:458,y:346,t:1526922877836};\\\", \\\"{x:437,y:386,t:1526922877852};\\\", \\\"{x:417,y:426,t:1526922877869};\\\", \\\"{x:386,y:480,t:1526922877887};\\\", \\\"{x:359,y:536,t:1526922877903};\\\", \\\"{x:340,y:585,t:1526922877922};\\\", \\\"{x:322,y:622,t:1526922877938};\\\", \\\"{x:316,y:640,t:1526922877955};\\\", \\\"{x:316,y:650,t:1526922877971};\\\", \\\"{x:316,y:653,t:1526922877988};\\\", \\\"{x:316,y:654,t:1526922878004};\\\", \\\"{x:320,y:654,t:1526922878021};\\\", \\\"{x:326,y:648,t:1526922878038};\\\", \\\"{x:334,y:630,t:1526922878054};\\\", \\\"{x:340,y:614,t:1526922878072};\\\", \\\"{x:350,y:594,t:1526922878088};\\\", \\\"{x:358,y:576,t:1526922878105};\\\", \\\"{x:368,y:553,t:1526922878121};\\\", \\\"{x:378,y:532,t:1526922878139};\\\", \\\"{x:389,y:513,t:1526922878154};\\\", \\\"{x:400,y:503,t:1526922878172};\\\", \\\"{x:415,y:495,t:1526922878188};\\\", \\\"{x:428,y:494,t:1526922878205};\\\", \\\"{x:443,y:494,t:1526922878221};\\\", \\\"{x:467,y:500,t:1526922878238};\\\", \\\"{x:503,y:517,t:1526922878256};\\\", \\\"{x:562,y:534,t:1526922878271};\\\", \\\"{x:646,y:550,t:1526922878289};\\\", \\\"{x:729,y:560,t:1526922878306};\\\", \\\"{x:787,y:565,t:1526922878321};\\\", \\\"{x:816,y:567,t:1526922878338};\\\", \\\"{x:824,y:567,t:1526922878355};\\\", \\\"{x:826,y:567,t:1526922878371};\\\", \\\"{x:828,y:566,t:1526922878388};\\\", \\\"{x:829,y:564,t:1526922878406};\\\", \\\"{x:829,y:562,t:1526922878421};\\\", \\\"{x:829,y:561,t:1526922878438};\\\", \\\"{x:829,y:560,t:1526922878455};\\\", \\\"{x:829,y:558,t:1526922878471};\\\", \\\"{x:829,y:554,t:1526922878488};\\\", \\\"{x:827,y:550,t:1526922878506};\\\", \\\"{x:826,y:543,t:1526922878522};\\\", \\\"{x:825,y:534,t:1526922878539};\\\", \\\"{x:823,y:524,t:1526922878556};\\\", \\\"{x:823,y:513,t:1526922878572};\\\", \\\"{x:824,y:508,t:1526922878589};\\\", \\\"{x:827,y:504,t:1526922878606};\\\", \\\"{x:828,y:502,t:1526922878622};\\\", \\\"{x:829,y:501,t:1526922878644};\\\", \\\"{x:830,y:501,t:1526922878668};\\\", \\\"{x:831,y:499,t:1526922878676};\\\", \\\"{x:832,y:499,t:1526922878689};\\\", \\\"{x:836,y:497,t:1526922878706};\\\", \\\"{x:841,y:494,t:1526922878722};\\\", \\\"{x:844,y:491,t:1526922878738};\\\", \\\"{x:848,y:488,t:1526922878755};\\\", \\\"{x:849,y:486,t:1526922878772};\\\", \\\"{x:850,y:485,t:1526922878788};\\\", \\\"{x:851,y:484,t:1526922878805};\\\", \\\"{x:852,y:483,t:1526922878822};\\\", \\\"{x:851,y:482,t:1526922879013};\\\", \\\"{x:848,y:482,t:1526922879022};\\\", \\\"{x:840,y:484,t:1526922879040};\\\", \\\"{x:835,y:485,t:1526922879055};\\\", \\\"{x:834,y:485,t:1526922879084};\\\", \\\"{x:833,y:486,t:1526922879596};\\\", \\\"{x:833,y:489,t:1526922879606};\\\", \\\"{x:833,y:498,t:1526922879623};\\\", \\\"{x:833,y:506,t:1526922879640};\\\", \\\"{x:833,y:513,t:1526922879656};\\\", \\\"{x:833,y:522,t:1526922879672};\\\", \\\"{x:833,y:531,t:1526922879689};\\\", \\\"{x:833,y:535,t:1526922879705};\\\", \\\"{x:833,y:538,t:1526922879722};\\\", \\\"{x:832,y:541,t:1526922879739};\\\", \\\"{x:832,y:545,t:1526922879756};\\\", \\\"{x:831,y:548,t:1526922879773};\\\", \\\"{x:830,y:550,t:1526922879789};\\\", \\\"{x:828,y:552,t:1526922879806};\\\", \\\"{x:824,y:554,t:1526922879823};\\\", \\\"{x:820,y:556,t:1526922879839};\\\", \\\"{x:810,y:557,t:1526922879856};\\\", \\\"{x:797,y:557,t:1526922879872};\\\", \\\"{x:785,y:557,t:1526922879889};\\\", \\\"{x:767,y:553,t:1526922879906};\\\", \\\"{x:748,y:547,t:1526922879923};\\\", \\\"{x:740,y:545,t:1526922879939};\\\", \\\"{x:740,y:544,t:1526922879956};\\\", \\\"{x:739,y:544,t:1526922879973};\\\", \\\"{x:742,y:544,t:1526922880028};\\\", \\\"{x:747,y:544,t:1526922880039};\\\", \\\"{x:771,y:542,t:1526922880056};\\\", \\\"{x:797,y:540,t:1526922880073};\\\", \\\"{x:821,y:540,t:1526922880090};\\\", \\\"{x:839,y:538,t:1526922880106};\\\", \\\"{x:848,y:537,t:1526922880123};\\\", \\\"{x:851,y:534,t:1526922880139};\\\", \\\"{x:852,y:534,t:1526922880163};\\\", \\\"{x:852,y:533,t:1526922880292};\\\", \\\"{x:852,y:532,t:1526922880306};\\\", \\\"{x:852,y:531,t:1526922880323};\\\", \\\"{x:848,y:529,t:1526922880339};\\\", \\\"{x:840,y:525,t:1526922880356};\\\", \\\"{x:836,y:523,t:1526922880373};\\\", \\\"{x:835,y:522,t:1526922880390};\\\", \\\"{x:833,y:522,t:1526922880407};\\\", \\\"{x:832,y:521,t:1526922880628};\\\", \\\"{x:827,y:521,t:1526922880640};\\\", \\\"{x:804,y:526,t:1526922880656};\\\", \\\"{x:773,y:534,t:1526922880673};\\\", \\\"{x:709,y:552,t:1526922880691};\\\", \\\"{x:626,y:563,t:1526922880706};\\\", \\\"{x:533,y:580,t:1526922880724};\\\", \\\"{x:399,y:597,t:1526922880740};\\\", \\\"{x:326,y:601,t:1526922880757};\\\", \\\"{x:270,y:601,t:1526922880774};\\\", \\\"{x:233,y:601,t:1526922880790};\\\", \\\"{x:209,y:601,t:1526922880807};\\\", \\\"{x:190,y:597,t:1526922880823};\\\", \\\"{x:176,y:590,t:1526922880841};\\\", \\\"{x:163,y:582,t:1526922880858};\\\", \\\"{x:151,y:572,t:1526922880873};\\\", \\\"{x:139,y:560,t:1526922880890};\\\", \\\"{x:130,y:548,t:1526922880907};\\\", \\\"{x:126,y:542,t:1526922880923};\\\", \\\"{x:125,y:538,t:1526922880941};\\\", \\\"{x:125,y:535,t:1526922880957};\\\", \\\"{x:125,y:533,t:1526922880973};\\\", \\\"{x:125,y:532,t:1526922880990};\\\", \\\"{x:125,y:530,t:1526922881007};\\\", \\\"{x:125,y:528,t:1526922881023};\\\", \\\"{x:125,y:526,t:1526922881040};\\\", \\\"{x:126,y:525,t:1526922881076};\\\", \\\"{x:127,y:523,t:1526922881092};\\\", \\\"{x:128,y:523,t:1526922881107};\\\", \\\"{x:128,y:522,t:1526922881124};\\\", \\\"{x:129,y:522,t:1526922881212};\\\", \\\"{x:130,y:522,t:1526922881224};\\\", \\\"{x:132,y:523,t:1526922881240};\\\", \\\"{x:135,y:524,t:1526922881257};\\\", \\\"{x:138,y:524,t:1526922881274};\\\", \\\"{x:142,y:525,t:1526922881290};\\\", \\\"{x:143,y:525,t:1526922881307};\\\", \\\"{x:144,y:525,t:1526922881331};\\\", \\\"{x:145,y:525,t:1526922881539};\\\", \\\"{x:146,y:525,t:1526922882156};\\\", \\\"{x:147,y:525,t:1526922882172};\\\", \\\"{x:148,y:525,t:1526922882180};\\\", \\\"{x:149,y:526,t:1526922882195};\\\", \\\"{x:150,y:526,t:1526922882236};\\\", \\\"{x:151,y:526,t:1526922882268};\\\", \\\"{x:151,y:527,t:1526922882292};\\\", \\\"{x:152,y:527,t:1526922882796};\\\", \\\"{x:153,y:526,t:1526922882808};\\\", \\\"{x:155,y:526,t:1526922882825};\\\", \\\"{x:157,y:526,t:1526922882841};\\\", \\\"{x:158,y:525,t:1526922882858};\\\", \\\"{x:163,y:528,t:1526922885516};\\\", \\\"{x:174,y:536,t:1526922885527};\\\", \\\"{x:196,y:551,t:1526922885544};\\\", \\\"{x:217,y:566,t:1526922885560};\\\", \\\"{x:236,y:579,t:1526922885578};\\\", \\\"{x:257,y:594,t:1526922885595};\\\", \\\"{x:272,y:605,t:1526922885611};\\\", \\\"{x:285,y:614,t:1526922885628};\\\", \\\"{x:305,y:622,t:1526922885644};\\\", \\\"{x:318,y:631,t:1526922885661};\\\", \\\"{x:332,y:638,t:1526922885678};\\\", \\\"{x:347,y:646,t:1526922885694};\\\", \\\"{x:357,y:651,t:1526922885710};\\\", \\\"{x:367,y:656,t:1526922885727};\\\", \\\"{x:377,y:660,t:1526922885744};\\\", \\\"{x:388,y:665,t:1526922885760};\\\", \\\"{x:400,y:670,t:1526922885778};\\\", \\\"{x:414,y:673,t:1526922885794};\\\", \\\"{x:430,y:677,t:1526922885810};\\\", \\\"{x:441,y:678,t:1526922885827};\\\", \\\"{x:457,y:680,t:1526922885844};\\\", \\\"{x:462,y:681,t:1526922885860};\\\", \\\"{x:468,y:682,t:1526922885877};\\\", \\\"{x:473,y:684,t:1526922885894};\\\", \\\"{x:479,y:685,t:1526922885910};\\\", \\\"{x:484,y:686,t:1526922885927};\\\", \\\"{x:492,y:688,t:1526922885944};\\\", \\\"{x:497,y:688,t:1526922885961};\\\", \\\"{x:503,y:688,t:1526922885977};\\\", \\\"{x:508,y:688,t:1526922885994};\\\", \\\"{x:511,y:688,t:1526922886012};\\\", \\\"{x:515,y:688,t:1526922886027};\\\", \\\"{x:518,y:688,t:1526922886045};\\\", \\\"{x:519,y:687,t:1526922886061};\\\" ] }, { \\\"rt\\\": 10490, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 483572, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:684,t:1526922889460};\\\", \\\"{x:529,y:677,t:1526922889468};\\\", \\\"{x:536,y:673,t:1526922889481};\\\", \\\"{x:558,y:662,t:1526922889497};\\\", \\\"{x:584,y:651,t:1526922889513};\\\", \\\"{x:608,y:644,t:1526922889530};\\\", \\\"{x:652,y:632,t:1526922889548};\\\", \\\"{x:684,y:632,t:1526922889563};\\\", \\\"{x:710,y:632,t:1526922889581};\\\", \\\"{x:734,y:641,t:1526922889597};\\\", \\\"{x:758,y:653,t:1526922889613};\\\", \\\"{x:784,y:669,t:1526922889630};\\\", \\\"{x:812,y:683,t:1526922889648};\\\", \\\"{x:847,y:703,t:1526922889663};\\\", \\\"{x:891,y:728,t:1526922889681};\\\", \\\"{x:932,y:754,t:1526922889698};\\\", \\\"{x:985,y:770,t:1526922889713};\\\", \\\"{x:1021,y:778,t:1526922889731};\\\", \\\"{x:1058,y:782,t:1526922889748};\\\", \\\"{x:1072,y:782,t:1526922889763};\\\", \\\"{x:1077,y:782,t:1526922889781};\\\", \\\"{x:1082,y:781,t:1526922889797};\\\", \\\"{x:1088,y:779,t:1526922889814};\\\", \\\"{x:1095,y:779,t:1526922889830};\\\", \\\"{x:1106,y:779,t:1526922889848};\\\", \\\"{x:1128,y:781,t:1526922889865};\\\", \\\"{x:1158,y:788,t:1526922889880};\\\", \\\"{x:1195,y:800,t:1526922889897};\\\", \\\"{x:1258,y:824,t:1526922889914};\\\", \\\"{x:1316,y:841,t:1526922889931};\\\", \\\"{x:1389,y:863,t:1526922889948};\\\", \\\"{x:1428,y:874,t:1526922889964};\\\", \\\"{x:1459,y:886,t:1526922889980};\\\", \\\"{x:1481,y:897,t:1526922889997};\\\", \\\"{x:1500,y:902,t:1526922890015};\\\", \\\"{x:1514,y:907,t:1526922890030};\\\", \\\"{x:1528,y:911,t:1526922890047};\\\", \\\"{x:1538,y:912,t:1526922890065};\\\", \\\"{x:1546,y:915,t:1526922890080};\\\", \\\"{x:1554,y:917,t:1526922890097};\\\", \\\"{x:1566,y:920,t:1526922890115};\\\", \\\"{x:1573,y:922,t:1526922890130};\\\", \\\"{x:1578,y:922,t:1526922890147};\\\", \\\"{x:1579,y:922,t:1526922890165};\\\", \\\"{x:1579,y:923,t:1526922890468};\\\", \\\"{x:1577,y:926,t:1526922890484};\\\", \\\"{x:1567,y:926,t:1526922890498};\\\", \\\"{x:1554,y:931,t:1526922890515};\\\", \\\"{x:1547,y:934,t:1526922890531};\\\", \\\"{x:1545,y:935,t:1526922890548};\\\", \\\"{x:1543,y:936,t:1526922890564};\\\", \\\"{x:1542,y:936,t:1526922890595};\\\", \\\"{x:1541,y:936,t:1526922890603};\\\", \\\"{x:1540,y:936,t:1526922890619};\\\", \\\"{x:1539,y:936,t:1526922890631};\\\", \\\"{x:1536,y:936,t:1526922890649};\\\", \\\"{x:1535,y:936,t:1526922890664};\\\", \\\"{x:1534,y:936,t:1526922890764};\\\", \\\"{x:1534,y:935,t:1526922890779};\\\", \\\"{x:1534,y:934,t:1526922890787};\\\", \\\"{x:1534,y:931,t:1526922890799};\\\", \\\"{x:1535,y:928,t:1526922890815};\\\", \\\"{x:1538,y:922,t:1526922890831};\\\", \\\"{x:1542,y:917,t:1526922890848};\\\", \\\"{x:1544,y:914,t:1526922890864};\\\", \\\"{x:1545,y:912,t:1526922890881};\\\", \\\"{x:1546,y:910,t:1526922890899};\\\", \\\"{x:1547,y:910,t:1526922891116};\\\", \\\"{x:1548,y:909,t:1526922891132};\\\", \\\"{x:1550,y:907,t:1526922891148};\\\", \\\"{x:1550,y:906,t:1526922891166};\\\", \\\"{x:1551,y:906,t:1526922891182};\\\", \\\"{x:1551,y:905,t:1526922891228};\\\", \\\"{x:1551,y:904,t:1526922893834};\\\", \\\"{x:1547,y:904,t:1526922893849};\\\", \\\"{x:1517,y:904,t:1526922893866};\\\", \\\"{x:1484,y:903,t:1526922893881};\\\", \\\"{x:1434,y:892,t:1526922893899};\\\", \\\"{x:1380,y:879,t:1526922893916};\\\", \\\"{x:1296,y:855,t:1526922893931};\\\", \\\"{x:1182,y:815,t:1526922893949};\\\", \\\"{x:1073,y:761,t:1526922893966};\\\", \\\"{x:984,y:717,t:1526922893982};\\\", \\\"{x:908,y:671,t:1526922893999};\\\", \\\"{x:839,y:629,t:1526922894016};\\\", \\\"{x:795,y:602,t:1526922894032};\\\", \\\"{x:771,y:593,t:1526922894049};\\\", \\\"{x:763,y:590,t:1526922894066};\\\", \\\"{x:761,y:590,t:1526922894146};\\\", \\\"{x:758,y:590,t:1526922894154};\\\", \\\"{x:754,y:593,t:1526922894166};\\\", \\\"{x:746,y:601,t:1526922894183};\\\", \\\"{x:740,y:610,t:1526922894199};\\\", \\\"{x:730,y:618,t:1526922894216};\\\", \\\"{x:716,y:626,t:1526922894233};\\\", \\\"{x:700,y:631,t:1526922894248};\\\", \\\"{x:667,y:639,t:1526922894266};\\\", \\\"{x:641,y:643,t:1526922894283};\\\", \\\"{x:608,y:643,t:1526922894299};\\\", \\\"{x:560,y:643,t:1526922894316};\\\", \\\"{x:505,y:639,t:1526922894333};\\\", \\\"{x:465,y:626,t:1526922894349};\\\", \\\"{x:422,y:610,t:1526922894367};\\\", \\\"{x:393,y:596,t:1526922894383};\\\", \\\"{x:377,y:589,t:1526922894399};\\\", \\\"{x:372,y:586,t:1526922894416};\\\", \\\"{x:368,y:583,t:1526922894433};\\\", \\\"{x:367,y:582,t:1526922894449};\\\", \\\"{x:366,y:582,t:1526922894514};\\\", \\\"{x:366,y:581,t:1526922894529};\\\", \\\"{x:365,y:580,t:1526922894538};\\\", \\\"{x:364,y:580,t:1526922894549};\\\", \\\"{x:362,y:578,t:1526922894567};\\\", \\\"{x:361,y:578,t:1526922894583};\\\", \\\"{x:359,y:578,t:1526922894599};\\\", \\\"{x:358,y:578,t:1526922894649};\\\", \\\"{x:358,y:580,t:1526922894666};\\\", \\\"{x:358,y:584,t:1526922894683};\\\", \\\"{x:358,y:588,t:1526922894701};\\\", \\\"{x:358,y:590,t:1526922894716};\\\", \\\"{x:358,y:592,t:1526922894733};\\\", \\\"{x:358,y:595,t:1526922894749};\\\", \\\"{x:358,y:597,t:1526922894766};\\\", \\\"{x:358,y:601,t:1526922894782};\\\", \\\"{x:358,y:604,t:1526922894800};\\\", \\\"{x:356,y:606,t:1526922894816};\\\", \\\"{x:355,y:608,t:1526922894833};\\\", \\\"{x:355,y:609,t:1526922894850};\\\", \\\"{x:356,y:609,t:1526922895193};\\\", \\\"{x:359,y:609,t:1526922895201};\\\", \\\"{x:360,y:607,t:1526922895217};\\\", \\\"{x:366,y:601,t:1526922895233};\\\", \\\"{x:384,y:591,t:1526922895250};\\\", \\\"{x:398,y:582,t:1526922895268};\\\", \\\"{x:411,y:572,t:1526922895283};\\\", \\\"{x:423,y:565,t:1526922895301};\\\", \\\"{x:435,y:558,t:1526922895317};\\\", \\\"{x:450,y:553,t:1526922895333};\\\", \\\"{x:466,y:550,t:1526922895350};\\\", \\\"{x:489,y:545,t:1526922895367};\\\", \\\"{x:509,y:542,t:1526922895383};\\\", \\\"{x:533,y:539,t:1526922895401};\\\", \\\"{x:548,y:537,t:1526922895417};\\\", \\\"{x:564,y:534,t:1526922895433};\\\", \\\"{x:577,y:529,t:1526922895450};\\\", \\\"{x:584,y:525,t:1526922895467};\\\", \\\"{x:590,y:520,t:1526922895484};\\\", \\\"{x:596,y:514,t:1526922895500};\\\", \\\"{x:600,y:511,t:1526922895517};\\\", \\\"{x:602,y:507,t:1526922895534};\\\", \\\"{x:602,y:506,t:1526922895554};\\\", \\\"{x:602,y:504,t:1526922895570};\\\", \\\"{x:602,y:503,t:1526922895584};\\\", \\\"{x:602,y:501,t:1526922895600};\\\", \\\"{x:595,y:500,t:1526922895617};\\\", \\\"{x:580,y:499,t:1526922895633};\\\", \\\"{x:557,y:499,t:1526922895650};\\\", \\\"{x:527,y:499,t:1526922895666};\\\", \\\"{x:497,y:499,t:1526922895684};\\\", \\\"{x:471,y:499,t:1526922895700};\\\", \\\"{x:449,y:501,t:1526922895717};\\\", \\\"{x:435,y:504,t:1526922895735};\\\", \\\"{x:427,y:505,t:1526922895750};\\\", \\\"{x:423,y:505,t:1526922895767};\\\", \\\"{x:418,y:505,t:1526922895784};\\\", \\\"{x:415,y:505,t:1526922895800};\\\", \\\"{x:413,y:505,t:1526922895817};\\\", \\\"{x:409,y:505,t:1526922895834};\\\", \\\"{x:402,y:506,t:1526922895850};\\\", \\\"{x:390,y:508,t:1526922895867};\\\", \\\"{x:377,y:512,t:1526922895885};\\\", \\\"{x:361,y:517,t:1526922895901};\\\", \\\"{x:340,y:526,t:1526922895917};\\\", \\\"{x:316,y:538,t:1526922895934};\\\", \\\"{x:292,y:551,t:1526922895951};\\\", \\\"{x:269,y:563,t:1526922895968};\\\", \\\"{x:255,y:572,t:1526922895984};\\\", \\\"{x:244,y:577,t:1526922896001};\\\", \\\"{x:233,y:582,t:1526922896017};\\\", \\\"{x:224,y:585,t:1526922896033};\\\", \\\"{x:221,y:586,t:1526922896052};\\\", \\\"{x:215,y:587,t:1526922896067};\\\", \\\"{x:212,y:587,t:1526922896083};\\\", \\\"{x:211,y:587,t:1526922896101};\\\", \\\"{x:210,y:587,t:1526922896117};\\\", \\\"{x:209,y:587,t:1526922896134};\\\", \\\"{x:208,y:587,t:1526922896154};\\\", \\\"{x:207,y:587,t:1526922896167};\\\", \\\"{x:204,y:587,t:1526922896184};\\\", \\\"{x:203,y:587,t:1526922896201};\\\", \\\"{x:201,y:587,t:1526922896217};\\\", \\\"{x:199,y:587,t:1526922896234};\\\", \\\"{x:198,y:587,t:1526922896251};\\\", \\\"{x:198,y:588,t:1526922896282};\\\", \\\"{x:198,y:589,t:1526922896297};\\\", \\\"{x:198,y:590,t:1526922896314};\\\", \\\"{x:198,y:591,t:1526922896321};\\\", \\\"{x:199,y:592,t:1526922896334};\\\", \\\"{x:208,y:593,t:1526922896351};\\\", \\\"{x:225,y:593,t:1526922896368};\\\", \\\"{x:252,y:593,t:1526922896384};\\\", \\\"{x:300,y:591,t:1526922896401};\\\", \\\"{x:391,y:575,t:1526922896419};\\\", \\\"{x:446,y:563,t:1526922896434};\\\", \\\"{x:496,y:548,t:1526922896451};\\\", \\\"{x:532,y:536,t:1526922896469};\\\", \\\"{x:560,y:528,t:1526922896484};\\\", \\\"{x:581,y:522,t:1526922896500};\\\", \\\"{x:592,y:517,t:1526922896518};\\\", \\\"{x:600,y:513,t:1526922896534};\\\", \\\"{x:603,y:511,t:1526922896551};\\\", \\\"{x:604,y:510,t:1526922896568};\\\", \\\"{x:605,y:509,t:1526922896595};\\\", \\\"{x:605,y:508,t:1526922896609};\\\", \\\"{x:605,y:507,t:1526922896617};\\\", \\\"{x:605,y:506,t:1526922896634};\\\", \\\"{x:607,y:504,t:1526922896650};\\\", \\\"{x:609,y:502,t:1526922896668};\\\", \\\"{x:610,y:502,t:1526922896684};\\\", \\\"{x:612,y:502,t:1526922896738};\\\", \\\"{x:614,y:502,t:1526922896751};\\\", \\\"{x:623,y:503,t:1526922896768};\\\", \\\"{x:632,y:505,t:1526922896785};\\\", \\\"{x:640,y:508,t:1526922896800};\\\", \\\"{x:644,y:511,t:1526922896819};\\\", \\\"{x:645,y:511,t:1526922896835};\\\", \\\"{x:645,y:513,t:1526922896858};\\\", \\\"{x:645,y:514,t:1526922896874};\\\", \\\"{x:645,y:516,t:1526922896889};\\\", \\\"{x:645,y:517,t:1526922896901};\\\", \\\"{x:642,y:520,t:1526922896918};\\\", \\\"{x:636,y:526,t:1526922896935};\\\", \\\"{x:626,y:530,t:1526922896951};\\\", \\\"{x:621,y:533,t:1526922896968};\\\", \\\"{x:615,y:533,t:1526922896985};\\\", \\\"{x:611,y:533,t:1526922897001};\\\", \\\"{x:610,y:533,t:1526922897034};\\\", \\\"{x:608,y:532,t:1526922897049};\\\", \\\"{x:608,y:531,t:1526922897058};\\\", \\\"{x:607,y:529,t:1526922897073};\\\", \\\"{x:607,y:528,t:1526922897085};\\\", \\\"{x:607,y:527,t:1526922897101};\\\", \\\"{x:607,y:526,t:1526922897118};\\\", \\\"{x:606,y:525,t:1526922897135};\\\", \\\"{x:606,y:524,t:1526922897242};\\\", \\\"{x:606,y:524,t:1526922897309};\\\", \\\"{x:603,y:524,t:1526922897346};\\\", \\\"{x:600,y:527,t:1526922897354};\\\", \\\"{x:595,y:531,t:1526922897368};\\\", \\\"{x:583,y:546,t:1526922897386};\\\", \\\"{x:566,y:578,t:1526922897402};\\\", \\\"{x:559,y:602,t:1526922897418};\\\", \\\"{x:550,y:632,t:1526922897435};\\\", \\\"{x:541,y:664,t:1526922897452};\\\", \\\"{x:533,y:688,t:1526922897469};\\\", \\\"{x:526,y:705,t:1526922897485};\\\", \\\"{x:523,y:713,t:1526922897502};\\\", \\\"{x:522,y:716,t:1526922897517};\\\", \\\"{x:521,y:717,t:1526922897535};\\\", \\\"{x:522,y:715,t:1526922897706};\\\", \\\"{x:522,y:712,t:1526922897722};\\\", \\\"{x:523,y:709,t:1526922897735};\\\", \\\"{x:523,y:703,t:1526922897752};\\\", \\\"{x:523,y:696,t:1526922897769};\\\", \\\"{x:523,y:692,t:1526922897785};\\\", \\\"{x:524,y:690,t:1526922897802};\\\" ] }, { \\\"rt\\\": 108954, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 593729, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-03 PM-03 PM-02 PM-01 PM-12 PM-01 PM-01 PM-02 PM-A -A -A -X -02 PM-O -O -O -X -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:701,t:1526922930266};\\\", \\\"{x:545,y:757,t:1526922930275};\\\", \\\"{x:555,y:853,t:1526922930292};\\\", \\\"{x:557,y:934,t:1526922930308};\\\", \\\"{x:557,y:985,t:1526922930328};\\\", \\\"{x:562,y:1021,t:1526922930345};\\\", \\\"{x:568,y:1055,t:1526922930361};\\\", \\\"{x:576,y:1067,t:1526922930379};\\\", \\\"{x:579,y:1072,t:1526922930395};\\\", \\\"{x:580,y:1073,t:1526922930411};\\\", \\\"{x:579,y:1076,t:1526922930466};\\\", \\\"{x:578,y:1080,t:1526922930479};\\\", \\\"{x:568,y:1087,t:1526922930494};\\\", \\\"{x:562,y:1092,t:1526922930505};\\\", \\\"{x:518,y:1091,t:1526922930601};\\\", \\\"{x:512,y:1083,t:1526922930612};\\\", \\\"{x:503,y:1065,t:1526922930629};\\\", \\\"{x:491,y:1046,t:1526922930645};\\\", \\\"{x:488,y:1038,t:1526922930662};\\\", \\\"{x:487,y:1037,t:1526922930678};\\\", \\\"{x:499,y:1025,t:1526922930729};\\\", \\\"{x:587,y:892,t:1526922930745};\\\", \\\"{x:676,y:730,t:1526922930762};\\\", \\\"{x:743,y:605,t:1526922930778};\\\", \\\"{x:776,y:533,t:1526922930795};\\\", \\\"{x:793,y:489,t:1526922930813};\\\", \\\"{x:800,y:461,t:1526922930830};\\\", \\\"{x:800,y:452,t:1526922930845};\\\", \\\"{x:800,y:450,t:1526922930862};\\\", \\\"{x:803,y:448,t:1526922930889};\\\", \\\"{x:813,y:443,t:1526922930897};\\\", \\\"{x:823,y:439,t:1526922930912};\\\", \\\"{x:848,y:436,t:1526922930929};\\\", \\\"{x:906,y:455,t:1526922930946};\\\", \\\"{x:957,y:492,t:1526922930963};\\\", \\\"{x:1011,y:534,t:1526922930979};\\\", \\\"{x:1057,y:599,t:1526922930995};\\\", \\\"{x:1108,y:691,t:1526922931012};\\\", \\\"{x:1178,y:807,t:1526922931029};\\\", \\\"{x:1266,y:937,t:1526922931046};\\\", \\\"{x:1371,y:1065,t:1526922931062};\\\", \\\"{x:1664,y:1089,t:1526922931218};\\\", \\\"{x:1660,y:1082,t:1526922931229};\\\", \\\"{x:1651,y:1066,t:1526922931246};\\\", \\\"{x:1642,y:1051,t:1526922931262};\\\", \\\"{x:1628,y:1040,t:1526922931279};\\\", \\\"{x:1603,y:1027,t:1526922931296};\\\", \\\"{x:1564,y:1000,t:1526922931313};\\\", \\\"{x:1514,y:961,t:1526922931330};\\\", \\\"{x:1495,y:931,t:1526922931347};\\\", \\\"{x:1470,y:894,t:1526922931363};\\\", \\\"{x:1454,y:868,t:1526922931379};\\\", \\\"{x:1441,y:845,t:1526922931396};\\\", \\\"{x:1431,y:830,t:1526922931412};\\\", \\\"{x:1425,y:824,t:1526922931429};\\\", \\\"{x:1420,y:820,t:1526922931447};\\\", \\\"{x:1417,y:820,t:1526922931462};\\\", \\\"{x:1416,y:820,t:1526922931480};\\\", \\\"{x:1414,y:820,t:1526922931496};\\\", \\\"{x:1413,y:820,t:1526922931513};\\\", \\\"{x:1406,y:822,t:1526922931529};\\\", \\\"{x:1404,y:835,t:1526922931547};\\\", \\\"{x:1404,y:855,t:1526922931563};\\\", \\\"{x:1409,y:874,t:1526922931579};\\\", \\\"{x:1418,y:889,t:1526922931596};\\\", \\\"{x:1427,y:898,t:1526922931613};\\\", \\\"{x:1432,y:902,t:1526922931630};\\\", \\\"{x:1437,y:906,t:1526922931646};\\\", \\\"{x:1440,y:907,t:1526922931663};\\\", \\\"{x:1442,y:908,t:1526922931680};\\\", \\\"{x:1443,y:908,t:1526922931697};\\\", \\\"{x:1445,y:908,t:1526922931713};\\\", \\\"{x:1448,y:908,t:1526922931729};\\\", \\\"{x:1454,y:906,t:1526922931746};\\\", \\\"{x:1460,y:905,t:1526922931764};\\\", \\\"{x:1467,y:902,t:1526922931780};\\\", \\\"{x:1474,y:901,t:1526922931796};\\\", \\\"{x:1480,y:901,t:1526922931814};\\\", \\\"{x:1482,y:901,t:1526922931830};\\\", \\\"{x:1484,y:901,t:1526922931846};\\\", \\\"{x:1485,y:902,t:1526922931865};\\\", \\\"{x:1485,y:903,t:1526922931880};\\\", \\\"{x:1488,y:908,t:1526922931897};\\\", \\\"{x:1492,y:917,t:1526922931913};\\\", \\\"{x:1494,y:920,t:1526922931930};\\\", \\\"{x:1494,y:921,t:1526922932001};\\\", \\\"{x:1492,y:921,t:1526922932034};\\\", \\\"{x:1491,y:922,t:1526922932047};\\\", \\\"{x:1490,y:922,t:1526922932063};\\\", \\\"{x:1489,y:922,t:1526922932081};\\\", \\\"{x:1488,y:922,t:1526922932186};\\\", \\\"{x:1486,y:922,t:1526922932249};\\\", \\\"{x:1486,y:921,t:1526922932281};\\\", \\\"{x:1485,y:920,t:1526922932297};\\\", \\\"{x:1485,y:919,t:1526922932314};\\\", \\\"{x:1485,y:918,t:1526922932330};\\\", \\\"{x:1485,y:916,t:1526922932348};\\\", \\\"{x:1484,y:915,t:1526922932363};\\\", \\\"{x:1484,y:914,t:1526922932385};\\\", \\\"{x:1484,y:913,t:1526922932401};\\\", \\\"{x:1483,y:912,t:1526922932413};\\\", \\\"{x:1483,y:911,t:1526922932430};\\\", \\\"{x:1483,y:908,t:1526922932447};\\\", \\\"{x:1482,y:907,t:1526922932463};\\\", \\\"{x:1482,y:903,t:1526922932481};\\\", \\\"{x:1482,y:900,t:1526922932497};\\\", \\\"{x:1482,y:897,t:1526922932513};\\\", \\\"{x:1482,y:895,t:1526922932545};\\\", \\\"{x:1482,y:894,t:1526922932721};\\\", \\\"{x:1482,y:891,t:1526922932730};\\\", \\\"{x:1482,y:880,t:1526922932747};\\\", \\\"{x:1481,y:870,t:1526922932764};\\\", \\\"{x:1481,y:862,t:1526922932780};\\\", \\\"{x:1480,y:854,t:1526922932797};\\\", \\\"{x:1479,y:851,t:1526922932814};\\\", \\\"{x:1479,y:848,t:1526922932830};\\\", \\\"{x:1478,y:843,t:1526922932848};\\\", \\\"{x:1478,y:841,t:1526922932865};\\\", \\\"{x:1478,y:839,t:1526922932880};\\\", \\\"{x:1478,y:838,t:1526922932898};\\\", \\\"{x:1478,y:837,t:1526922932915};\\\", \\\"{x:1478,y:831,t:1526922933498};\\\", \\\"{x:1478,y:829,t:1526922933505};\\\", \\\"{x:1478,y:825,t:1526922933514};\\\", \\\"{x:1478,y:822,t:1526922933532};\\\", \\\"{x:1477,y:817,t:1526922933548};\\\", \\\"{x:1477,y:816,t:1526922933565};\\\", \\\"{x:1477,y:813,t:1526922933582};\\\", \\\"{x:1475,y:812,t:1526922933598};\\\", \\\"{x:1475,y:811,t:1526922933615};\\\", \\\"{x:1475,y:808,t:1526922933632};\\\", \\\"{x:1474,y:807,t:1526922933666};\\\", \\\"{x:1474,y:806,t:1526922933705};\\\", \\\"{x:1474,y:805,t:1526922933716};\\\", \\\"{x:1474,y:804,t:1526922933732};\\\", \\\"{x:1474,y:802,t:1526922933749};\\\", \\\"{x:1474,y:799,t:1526922933766};\\\", \\\"{x:1474,y:797,t:1526922933785};\\\", \\\"{x:1474,y:796,t:1526922933801};\\\", \\\"{x:1474,y:795,t:1526922933825};\\\", \\\"{x:1474,y:794,t:1526922933849};\\\", \\\"{x:1473,y:791,t:1526922933865};\\\", \\\"{x:1473,y:785,t:1526922933883};\\\", \\\"{x:1473,y:781,t:1526922933899};\\\", \\\"{x:1472,y:777,t:1526922933916};\\\", \\\"{x:1471,y:775,t:1526922933932};\\\", \\\"{x:1471,y:774,t:1526922933948};\\\", \\\"{x:1471,y:771,t:1526922935385};\\\", \\\"{x:1471,y:768,t:1526922935400};\\\", \\\"{x:1472,y:760,t:1526922935417};\\\", \\\"{x:1473,y:754,t:1526922935434};\\\", \\\"{x:1473,y:749,t:1526922935450};\\\", \\\"{x:1473,y:746,t:1526922935466};\\\", \\\"{x:1473,y:743,t:1526922935484};\\\", \\\"{x:1475,y:740,t:1526922935500};\\\", \\\"{x:1475,y:735,t:1526922935517};\\\", \\\"{x:1475,y:731,t:1526922935533};\\\", \\\"{x:1476,y:724,t:1526922935550};\\\", \\\"{x:1476,y:716,t:1526922935567};\\\", \\\"{x:1476,y:707,t:1526922935583};\\\", \\\"{x:1476,y:700,t:1526922935601};\\\", \\\"{x:1476,y:693,t:1526922935617};\\\", \\\"{x:1476,y:687,t:1526922935633};\\\", \\\"{x:1479,y:681,t:1526922935651};\\\", \\\"{x:1479,y:679,t:1526922935668};\\\", \\\"{x:1479,y:676,t:1526922935684};\\\", \\\"{x:1479,y:672,t:1526922935701};\\\", \\\"{x:1480,y:668,t:1526922935717};\\\", \\\"{x:1480,y:666,t:1526922935734};\\\", \\\"{x:1481,y:663,t:1526922935751};\\\", \\\"{x:1481,y:662,t:1526922935768};\\\", \\\"{x:1481,y:659,t:1526922935784};\\\", \\\"{x:1482,y:656,t:1526922935800};\\\", \\\"{x:1482,y:652,t:1526922935817};\\\", \\\"{x:1482,y:649,t:1526922935833};\\\", \\\"{x:1483,y:647,t:1526922935850};\\\", \\\"{x:1483,y:646,t:1526922935873};\\\", \\\"{x:1483,y:645,t:1526922935897};\\\", \\\"{x:1483,y:644,t:1526922935977};\\\", \\\"{x:1483,y:643,t:1526922936873};\\\", \\\"{x:1483,y:642,t:1526922936885};\\\", \\\"{x:1483,y:640,t:1526922936901};\\\", \\\"{x:1483,y:638,t:1526922936918};\\\", \\\"{x:1483,y:634,t:1526922936935};\\\", \\\"{x:1483,y:631,t:1526922936951};\\\", \\\"{x:1483,y:627,t:1526922936969};\\\", \\\"{x:1483,y:622,t:1526922936985};\\\", \\\"{x:1483,y:617,t:1526922937001};\\\", \\\"{x:1483,y:615,t:1526922937019};\\\", \\\"{x:1483,y:612,t:1526922937035};\\\", \\\"{x:1483,y:610,t:1526922937052};\\\", \\\"{x:1483,y:608,t:1526922937068};\\\", \\\"{x:1483,y:606,t:1526922937086};\\\", \\\"{x:1483,y:602,t:1526922937102};\\\", \\\"{x:1483,y:599,t:1526922937119};\\\", \\\"{x:1483,y:595,t:1526922937135};\\\", \\\"{x:1483,y:594,t:1526922937151};\\\", \\\"{x:1483,y:592,t:1526922937169};\\\", \\\"{x:1484,y:591,t:1526922937186};\\\", \\\"{x:1484,y:589,t:1526922937202};\\\", \\\"{x:1484,y:588,t:1526922937219};\\\", \\\"{x:1484,y:586,t:1526922937236};\\\", \\\"{x:1484,y:585,t:1526922937252};\\\", \\\"{x:1484,y:584,t:1526922937269};\\\", \\\"{x:1484,y:583,t:1526922937289};\\\", \\\"{x:1485,y:581,t:1526922937305};\\\", \\\"{x:1486,y:581,t:1526922937319};\\\", \\\"{x:1486,y:580,t:1526922937336};\\\", \\\"{x:1486,y:579,t:1526922937353};\\\", \\\"{x:1487,y:578,t:1526922937368};\\\", \\\"{x:1487,y:577,t:1526922937402};\\\", \\\"{x:1489,y:575,t:1526922937433};\\\", \\\"{x:1490,y:573,t:1526922937457};\\\", \\\"{x:1490,y:572,t:1526922937473};\\\", \\\"{x:1491,y:571,t:1526922937485};\\\", \\\"{x:1493,y:568,t:1526922937503};\\\", \\\"{x:1494,y:562,t:1526922937519};\\\", \\\"{x:1495,y:559,t:1526922937535};\\\", \\\"{x:1497,y:555,t:1526922937553};\\\", \\\"{x:1498,y:551,t:1526922937569};\\\", \\\"{x:1498,y:548,t:1526922937585};\\\", \\\"{x:1499,y:546,t:1526922937603};\\\", \\\"{x:1499,y:543,t:1526922937620};\\\", \\\"{x:1499,y:540,t:1526922937636};\\\", \\\"{x:1499,y:538,t:1526922937653};\\\", \\\"{x:1499,y:534,t:1526922937670};\\\", \\\"{x:1500,y:531,t:1526922937685};\\\", \\\"{x:1500,y:528,t:1526922937703};\\\", \\\"{x:1500,y:526,t:1526922937719};\\\", \\\"{x:1500,y:524,t:1526922937735};\\\", \\\"{x:1500,y:523,t:1526922937752};\\\", \\\"{x:1500,y:522,t:1526922937769};\\\", \\\"{x:1500,y:521,t:1526922937786};\\\", \\\"{x:1500,y:520,t:1526922937809};\\\", \\\"{x:1500,y:519,t:1526922937824};\\\", \\\"{x:1500,y:518,t:1526922937835};\\\", \\\"{x:1500,y:517,t:1526922937857};\\\", \\\"{x:1499,y:515,t:1526922937873};\\\", \\\"{x:1498,y:514,t:1526922937913};\\\", \\\"{x:1498,y:513,t:1526922937953};\\\", \\\"{x:1496,y:511,t:1526922937969};\\\", \\\"{x:1496,y:510,t:1526922937987};\\\", \\\"{x:1495,y:509,t:1526922938003};\\\", \\\"{x:1494,y:508,t:1526922938020};\\\", \\\"{x:1493,y:508,t:1526922938036};\\\", \\\"{x:1493,y:507,t:1526922938052};\\\", \\\"{x:1491,y:507,t:1526922938225};\\\", \\\"{x:1489,y:507,t:1526922938241};\\\", \\\"{x:1488,y:507,t:1526922938254};\\\", \\\"{x:1486,y:507,t:1526922938269};\\\", \\\"{x:1484,y:508,t:1526922938286};\\\", \\\"{x:1482,y:509,t:1526922938303};\\\", \\\"{x:1480,y:512,t:1526922946457};\\\", \\\"{x:1482,y:523,t:1526922946465};\\\", \\\"{x:1489,y:534,t:1526922946478};\\\", \\\"{x:1510,y:570,t:1526922946495};\\\", \\\"{x:1526,y:602,t:1526922946512};\\\", \\\"{x:1539,y:633,t:1526922946529};\\\", \\\"{x:1546,y:648,t:1526922946545};\\\", \\\"{x:1549,y:658,t:1526922946562};\\\", \\\"{x:1553,y:671,t:1526922946579};\\\", \\\"{x:1559,y:688,t:1526922946595};\\\", \\\"{x:1563,y:703,t:1526922946612};\\\", \\\"{x:1568,y:717,t:1526922946629};\\\", \\\"{x:1571,y:726,t:1526922946645};\\\", \\\"{x:1575,y:742,t:1526922946662};\\\", \\\"{x:1578,y:764,t:1526922946679};\\\", \\\"{x:1582,y:789,t:1526922946694};\\\", \\\"{x:1582,y:808,t:1526922946712};\\\", \\\"{x:1579,y:834,t:1526922946728};\\\", \\\"{x:1573,y:853,t:1526922946745};\\\", \\\"{x:1566,y:872,t:1526922946762};\\\", \\\"{x:1557,y:895,t:1526922946779};\\\", \\\"{x:1550,y:913,t:1526922946795};\\\", \\\"{x:1545,y:924,t:1526922946812};\\\", \\\"{x:1538,y:938,t:1526922946829};\\\", \\\"{x:1534,y:942,t:1526922946845};\\\", \\\"{x:1532,y:943,t:1526922946862};\\\", \\\"{x:1532,y:944,t:1526922946889};\\\", \\\"{x:1532,y:945,t:1526922946921};\\\", \\\"{x:1531,y:945,t:1526922946977};\\\", \\\"{x:1531,y:944,t:1526922947065};\\\", \\\"{x:1530,y:942,t:1526922947079};\\\", \\\"{x:1529,y:935,t:1526922947096};\\\", \\\"{x:1528,y:928,t:1526922947112};\\\", \\\"{x:1526,y:918,t:1526922947129};\\\", \\\"{x:1525,y:917,t:1526922947146};\\\", \\\"{x:1525,y:915,t:1526922947163};\\\", \\\"{x:1525,y:913,t:1526922947179};\\\", \\\"{x:1523,y:910,t:1526922947196};\\\", \\\"{x:1522,y:907,t:1526922947212};\\\", \\\"{x:1520,y:903,t:1526922947229};\\\", \\\"{x:1517,y:899,t:1526922947246};\\\", \\\"{x:1515,y:896,t:1526922947263};\\\", \\\"{x:1511,y:894,t:1526922947279};\\\", \\\"{x:1510,y:892,t:1526922947296};\\\", \\\"{x:1507,y:891,t:1526922947313};\\\", \\\"{x:1505,y:891,t:1526922947329};\\\", \\\"{x:1504,y:891,t:1526922947346};\\\", \\\"{x:1502,y:891,t:1526922947363};\\\", \\\"{x:1501,y:891,t:1526922947379};\\\", \\\"{x:1500,y:891,t:1526922947396};\\\", \\\"{x:1499,y:891,t:1526922947413};\\\", \\\"{x:1498,y:891,t:1526922947429};\\\", \\\"{x:1497,y:892,t:1526922947449};\\\", \\\"{x:1497,y:893,t:1526922947529};\\\", \\\"{x:1497,y:894,t:1526922947545};\\\", \\\"{x:1497,y:897,t:1526922947563};\\\", \\\"{x:1497,y:899,t:1526922947580};\\\", \\\"{x:1498,y:902,t:1526922947596};\\\", \\\"{x:1498,y:903,t:1526922948649};\\\", \\\"{x:1498,y:905,t:1526922948664};\\\", \\\"{x:1480,y:912,t:1526922948680};\\\", \\\"{x:1463,y:917,t:1526922948697};\\\", \\\"{x:1441,y:921,t:1526922948714};\\\", \\\"{x:1418,y:923,t:1526922948731};\\\", \\\"{x:1395,y:926,t:1526922948746};\\\", \\\"{x:1376,y:926,t:1526922948764};\\\", \\\"{x:1360,y:926,t:1526922948781};\\\", \\\"{x:1353,y:926,t:1526922948798};\\\", \\\"{x:1352,y:926,t:1526922948815};\\\", \\\"{x:1352,y:925,t:1526922948841};\\\", \\\"{x:1350,y:925,t:1526922948881};\\\", \\\"{x:1346,y:925,t:1526922948898};\\\", \\\"{x:1342,y:925,t:1526922948914};\\\", \\\"{x:1338,y:923,t:1526922948931};\\\", \\\"{x:1336,y:922,t:1526922948948};\\\", \\\"{x:1335,y:922,t:1526922949001};\\\", \\\"{x:1335,y:921,t:1526922949024};\\\", \\\"{x:1335,y:920,t:1526922949033};\\\", \\\"{x:1335,y:918,t:1526922949049};\\\", \\\"{x:1335,y:917,t:1526922949064};\\\", \\\"{x:1336,y:913,t:1526922949081};\\\", \\\"{x:1339,y:907,t:1526922949098};\\\", \\\"{x:1344,y:900,t:1526922949114};\\\", \\\"{x:1348,y:896,t:1526922949131};\\\", \\\"{x:1352,y:893,t:1526922949148};\\\", \\\"{x:1355,y:889,t:1526922949165};\\\", \\\"{x:1358,y:886,t:1526922949181};\\\", \\\"{x:1362,y:880,t:1526922949198};\\\", \\\"{x:1364,y:876,t:1526922949215};\\\", \\\"{x:1369,y:868,t:1526922949231};\\\", \\\"{x:1375,y:862,t:1526922949248};\\\", \\\"{x:1381,y:855,t:1526922949265};\\\", \\\"{x:1385,y:849,t:1526922949280};\\\", \\\"{x:1389,y:843,t:1526922949298};\\\", \\\"{x:1392,y:840,t:1526922949315};\\\", \\\"{x:1394,y:836,t:1526922949331};\\\", \\\"{x:1396,y:834,t:1526922949348};\\\", \\\"{x:1398,y:830,t:1526922949365};\\\", \\\"{x:1398,y:829,t:1526922949381};\\\", \\\"{x:1398,y:827,t:1526922949398};\\\", \\\"{x:1400,y:824,t:1526922949415};\\\", \\\"{x:1401,y:824,t:1526922949537};\\\", \\\"{x:1401,y:830,t:1526922949548};\\\", \\\"{x:1401,y:842,t:1526922949565};\\\", \\\"{x:1401,y:856,t:1526922949582};\\\", \\\"{x:1402,y:870,t:1526922949598};\\\", \\\"{x:1403,y:884,t:1526922949615};\\\", \\\"{x:1406,y:894,t:1526922949632};\\\", \\\"{x:1409,y:904,t:1526922949648};\\\", \\\"{x:1414,y:919,t:1526922949665};\\\", \\\"{x:1417,y:926,t:1526922949682};\\\", \\\"{x:1418,y:931,t:1526922949698};\\\", \\\"{x:1419,y:933,t:1526922949715};\\\", \\\"{x:1420,y:934,t:1526922949732};\\\", \\\"{x:1420,y:936,t:1526922949752};\\\", \\\"{x:1420,y:935,t:1526922953327};\\\", \\\"{x:1420,y:934,t:1526922953359};\\\", \\\"{x:1420,y:933,t:1526922953527};\\\", \\\"{x:1420,y:932,t:1526922953542};\\\", \\\"{x:1420,y:931,t:1526922953567};\\\", \\\"{x:1420,y:930,t:1526922953606};\\\", \\\"{x:1420,y:929,t:1526922953617};\\\", \\\"{x:1420,y:928,t:1526922953634};\\\", \\\"{x:1420,y:927,t:1526922953650};\\\", \\\"{x:1420,y:924,t:1526922953667};\\\", \\\"{x:1420,y:920,t:1526922953684};\\\", \\\"{x:1420,y:918,t:1526922953700};\\\", \\\"{x:1420,y:916,t:1526922953717};\\\", \\\"{x:1420,y:914,t:1526922953735};\\\", \\\"{x:1420,y:911,t:1526922953750};\\\", \\\"{x:1420,y:908,t:1526922953767};\\\", \\\"{x:1420,y:906,t:1526922953784};\\\", \\\"{x:1420,y:903,t:1526922953802};\\\", \\\"{x:1423,y:900,t:1526922953817};\\\", \\\"{x:1423,y:898,t:1526922953834};\\\", \\\"{x:1423,y:897,t:1526922953852};\\\", \\\"{x:1423,y:893,t:1526922953867};\\\", \\\"{x:1423,y:891,t:1526922953884};\\\", \\\"{x:1423,y:889,t:1526922953901};\\\", \\\"{x:1424,y:886,t:1526922953918};\\\", \\\"{x:1424,y:884,t:1526922953934};\\\", \\\"{x:1424,y:880,t:1526922953951};\\\", \\\"{x:1424,y:878,t:1526922953967};\\\", \\\"{x:1425,y:875,t:1526922953985};\\\", \\\"{x:1425,y:873,t:1526922954001};\\\", \\\"{x:1425,y:872,t:1526922954018};\\\", \\\"{x:1425,y:869,t:1526922954035};\\\", \\\"{x:1427,y:865,t:1526922954051};\\\", \\\"{x:1428,y:861,t:1526922954068};\\\", \\\"{x:1428,y:857,t:1526922954085};\\\", \\\"{x:1429,y:850,t:1526922954101};\\\", \\\"{x:1430,y:843,t:1526922954118};\\\", \\\"{x:1431,y:837,t:1526922954134};\\\", \\\"{x:1432,y:830,t:1526922954151};\\\", \\\"{x:1433,y:826,t:1526922954169};\\\", \\\"{x:1434,y:823,t:1526922954184};\\\", \\\"{x:1434,y:822,t:1526922954201};\\\", \\\"{x:1434,y:823,t:1526922954311};\\\", \\\"{x:1434,y:827,t:1526922954319};\\\", \\\"{x:1435,y:830,t:1526922954335};\\\", \\\"{x:1437,y:845,t:1526922954351};\\\", \\\"{x:1437,y:849,t:1526922954368};\\\", \\\"{x:1437,y:857,t:1526922954384};\\\", \\\"{x:1437,y:863,t:1526922954402};\\\", \\\"{x:1437,y:865,t:1526922954418};\\\", \\\"{x:1437,y:871,t:1526922954435};\\\", \\\"{x:1437,y:880,t:1526922954451};\\\", \\\"{x:1439,y:894,t:1526922954468};\\\", \\\"{x:1439,y:903,t:1526922954486};\\\", \\\"{x:1440,y:907,t:1526922954502};\\\", \\\"{x:1440,y:910,t:1526922954519};\\\", \\\"{x:1440,y:911,t:1526922954535};\\\", \\\"{x:1440,y:912,t:1526922954551};\\\", \\\"{x:1440,y:913,t:1526922954568};\\\", \\\"{x:1440,y:914,t:1526922954590};\\\", \\\"{x:1440,y:916,t:1526922954601};\\\", \\\"{x:1440,y:918,t:1526922954618};\\\", \\\"{x:1439,y:920,t:1526922954635};\\\", \\\"{x:1439,y:921,t:1526922954651};\\\", \\\"{x:1439,y:924,t:1526922954668};\\\", \\\"{x:1439,y:927,t:1526922954685};\\\", \\\"{x:1441,y:934,t:1526922954701};\\\", \\\"{x:1442,y:937,t:1526922954718};\\\", \\\"{x:1444,y:938,t:1526922954735};\\\", \\\"{x:1447,y:938,t:1526922954751};\\\", \\\"{x:1449,y:938,t:1526922954768};\\\", \\\"{x:1452,y:937,t:1526922954785};\\\", \\\"{x:1456,y:932,t:1526922954802};\\\", \\\"{x:1459,y:927,t:1526922954818};\\\", \\\"{x:1463,y:920,t:1526922954835};\\\", \\\"{x:1464,y:914,t:1526922954852};\\\", \\\"{x:1468,y:908,t:1526922954868};\\\", \\\"{x:1469,y:903,t:1526922954885};\\\", \\\"{x:1471,y:900,t:1526922954902};\\\", \\\"{x:1473,y:897,t:1526922954918};\\\", \\\"{x:1476,y:895,t:1526922954935};\\\", \\\"{x:1477,y:894,t:1526922954953};\\\", \\\"{x:1480,y:893,t:1526922954968};\\\", \\\"{x:1481,y:892,t:1526922954985};\\\", \\\"{x:1484,y:892,t:1526922955002};\\\", \\\"{x:1486,y:892,t:1526922955019};\\\", \\\"{x:1488,y:891,t:1526922955036};\\\", \\\"{x:1489,y:891,t:1526922955053};\\\", \\\"{x:1490,y:891,t:1526922955069};\\\", \\\"{x:1491,y:891,t:1526922955085};\\\", \\\"{x:1492,y:892,t:1526922955102};\\\", \\\"{x:1494,y:896,t:1526922955119};\\\", \\\"{x:1495,y:900,t:1526922955136};\\\", \\\"{x:1495,y:903,t:1526922955153};\\\", \\\"{x:1495,y:906,t:1526922955169};\\\", \\\"{x:1495,y:907,t:1526922955185};\\\", \\\"{x:1495,y:908,t:1526922955295};\\\", \\\"{x:1494,y:908,t:1526922955375};\\\", \\\"{x:1493,y:908,t:1526922955431};\\\", \\\"{x:1492,y:908,t:1526922955454};\\\", \\\"{x:1491,y:908,t:1526922955486};\\\", \\\"{x:1490,y:907,t:1526922955511};\\\", \\\"{x:1489,y:906,t:1526922955583};\\\", \\\"{x:1488,y:906,t:1526922957862};\\\", \\\"{x:1488,y:904,t:1526922957871};\\\", \\\"{x:1488,y:899,t:1526922957888};\\\", \\\"{x:1488,y:891,t:1526922957905};\\\", \\\"{x:1487,y:884,t:1526922957921};\\\", \\\"{x:1487,y:880,t:1526922957938};\\\", \\\"{x:1487,y:876,t:1526922957955};\\\", \\\"{x:1487,y:874,t:1526922957972};\\\", \\\"{x:1487,y:873,t:1526922957988};\\\", \\\"{x:1487,y:871,t:1526922958005};\\\", \\\"{x:1487,y:870,t:1526922958021};\\\", \\\"{x:1487,y:868,t:1526922958038};\\\", \\\"{x:1487,y:866,t:1526922958055};\\\", \\\"{x:1487,y:864,t:1526922958072};\\\", \\\"{x:1487,y:862,t:1526922958088};\\\", \\\"{x:1487,y:861,t:1526922958105};\\\", \\\"{x:1487,y:860,t:1526922958122};\\\", \\\"{x:1487,y:857,t:1526922958138};\\\", \\\"{x:1487,y:855,t:1526922958155};\\\", \\\"{x:1488,y:852,t:1526922958172};\\\", \\\"{x:1489,y:849,t:1526922958188};\\\", \\\"{x:1489,y:848,t:1526922958205};\\\", \\\"{x:1489,y:847,t:1526922958222};\\\", \\\"{x:1490,y:843,t:1526922958238};\\\", \\\"{x:1490,y:840,t:1526922958255};\\\", \\\"{x:1491,y:837,t:1526922958272};\\\", \\\"{x:1491,y:834,t:1526922958288};\\\", \\\"{x:1492,y:830,t:1526922958305};\\\", \\\"{x:1492,y:827,t:1526922958323};\\\", \\\"{x:1492,y:823,t:1526922958339};\\\", \\\"{x:1492,y:819,t:1526922958355};\\\", \\\"{x:1492,y:814,t:1526922958372};\\\", \\\"{x:1492,y:811,t:1526922958389};\\\", \\\"{x:1492,y:806,t:1526922958406};\\\", \\\"{x:1492,y:802,t:1526922958423};\\\", \\\"{x:1492,y:795,t:1526922958439};\\\", \\\"{x:1492,y:791,t:1526922958455};\\\", \\\"{x:1492,y:789,t:1526922958472};\\\", \\\"{x:1492,y:787,t:1526922958489};\\\", \\\"{x:1492,y:785,t:1526922958505};\\\", \\\"{x:1492,y:783,t:1526922958522};\\\", \\\"{x:1492,y:781,t:1526922958539};\\\", \\\"{x:1492,y:780,t:1526922958555};\\\", \\\"{x:1492,y:776,t:1526922958572};\\\", \\\"{x:1492,y:775,t:1526922958590};\\\", \\\"{x:1492,y:774,t:1526922958606};\\\", \\\"{x:1492,y:773,t:1526922958622};\\\", \\\"{x:1492,y:772,t:1526922958639};\\\", \\\"{x:1492,y:771,t:1526922958959};\\\", \\\"{x:1491,y:770,t:1526922958982};\\\", \\\"{x:1490,y:770,t:1526922958991};\\\", \\\"{x:1490,y:769,t:1526922959031};\\\", \\\"{x:1489,y:769,t:1526922959039};\\\", \\\"{x:1488,y:768,t:1526922959655};\\\", \\\"{x:1488,y:767,t:1526922959686};\\\", \\\"{x:1488,y:766,t:1526922959727};\\\", \\\"{x:1488,y:765,t:1526922959741};\\\", \\\"{x:1488,y:764,t:1526922959758};\\\", \\\"{x:1488,y:763,t:1526922959783};\\\", \\\"{x:1488,y:762,t:1526922959790};\\\", \\\"{x:1488,y:761,t:1526922959807};\\\", \\\"{x:1488,y:759,t:1526922959823};\\\", \\\"{x:1488,y:757,t:1526922959840};\\\", \\\"{x:1488,y:754,t:1526922959858};\\\", \\\"{x:1488,y:751,t:1526922959873};\\\", \\\"{x:1488,y:749,t:1526922959890};\\\", \\\"{x:1488,y:747,t:1526922959908};\\\", \\\"{x:1488,y:743,t:1526922959923};\\\", \\\"{x:1488,y:740,t:1526922959941};\\\", \\\"{x:1488,y:734,t:1526922959957};\\\", \\\"{x:1488,y:729,t:1526922959973};\\\", \\\"{x:1488,y:717,t:1526922959991};\\\", \\\"{x:1488,y:709,t:1526922960008};\\\", \\\"{x:1488,y:705,t:1526922960023};\\\", \\\"{x:1488,y:702,t:1526922960041};\\\", \\\"{x:1488,y:699,t:1526922960058};\\\", \\\"{x:1488,y:695,t:1526922960073};\\\", \\\"{x:1488,y:692,t:1526922960090};\\\", \\\"{x:1488,y:687,t:1526922960107};\\\", \\\"{x:1488,y:684,t:1526922960125};\\\", \\\"{x:1489,y:678,t:1526922960140};\\\", \\\"{x:1490,y:672,t:1526922960158};\\\", \\\"{x:1491,y:667,t:1526922960174};\\\", \\\"{x:1491,y:662,t:1526922960191};\\\", \\\"{x:1492,y:659,t:1526922960207};\\\", \\\"{x:1492,y:658,t:1526922960225};\\\", \\\"{x:1493,y:655,t:1526922960240};\\\", \\\"{x:1493,y:653,t:1526922960257};\\\", \\\"{x:1493,y:652,t:1526922960275};\\\", \\\"{x:1493,y:650,t:1526922960291};\\\", \\\"{x:1493,y:649,t:1526922960308};\\\", \\\"{x:1493,y:648,t:1526922960324};\\\", \\\"{x:1493,y:647,t:1526922960341};\\\", \\\"{x:1493,y:646,t:1526922960358};\\\", \\\"{x:1493,y:645,t:1526922960391};\\\", \\\"{x:1493,y:644,t:1526922960408};\\\", \\\"{x:1493,y:643,t:1526922960425};\\\", \\\"{x:1493,y:640,t:1526922960441};\\\", \\\"{x:1493,y:639,t:1526922960463};\\\", \\\"{x:1493,y:638,t:1526922960475};\\\", \\\"{x:1493,y:637,t:1526922960492};\\\", \\\"{x:1493,y:635,t:1526922960508};\\\", \\\"{x:1493,y:634,t:1526922960524};\\\", \\\"{x:1492,y:634,t:1526922960542};\\\", \\\"{x:1491,y:632,t:1526922960558};\\\", \\\"{x:1491,y:631,t:1526922960574};\\\", \\\"{x:1491,y:630,t:1526922960599};\\\", \\\"{x:1490,y:629,t:1526922961206};\\\", \\\"{x:1488,y:630,t:1526922961215};\\\", \\\"{x:1487,y:633,t:1526922961226};\\\", \\\"{x:1485,y:638,t:1526922961241};\\\", \\\"{x:1484,y:642,t:1526922961258};\\\", \\\"{x:1484,y:643,t:1526922961276};\\\", \\\"{x:1484,y:645,t:1526922961292};\\\", \\\"{x:1483,y:645,t:1526922961308};\\\", \\\"{x:1482,y:646,t:1526922961325};\\\", \\\"{x:1482,y:647,t:1526922961342};\\\", \\\"{x:1482,y:648,t:1526922961358};\\\", \\\"{x:1482,y:646,t:1526922962543};\\\", \\\"{x:1482,y:645,t:1526922962567};\\\", \\\"{x:1482,y:644,t:1526922963127};\\\", \\\"{x:1481,y:643,t:1526922963143};\\\", \\\"{x:1481,y:642,t:1526922963161};\\\", \\\"{x:1483,y:642,t:1526922965559};\\\", \\\"{x:1489,y:642,t:1526922965567};\\\", \\\"{x:1495,y:642,t:1526922965580};\\\", \\\"{x:1505,y:643,t:1526922965597};\\\", \\\"{x:1513,y:643,t:1526922965613};\\\", \\\"{x:1518,y:643,t:1526922965630};\\\", \\\"{x:1523,y:643,t:1526922965647};\\\", \\\"{x:1524,y:643,t:1526922965663};\\\", \\\"{x:1527,y:643,t:1526922965680};\\\", \\\"{x:1529,y:643,t:1526922965696};\\\", \\\"{x:1531,y:643,t:1526922965713};\\\", \\\"{x:1534,y:643,t:1526922965730};\\\", \\\"{x:1537,y:643,t:1526922965747};\\\", \\\"{x:1538,y:643,t:1526922965763};\\\", \\\"{x:1540,y:643,t:1526922965779};\\\", \\\"{x:1541,y:643,t:1526922965796};\\\", \\\"{x:1543,y:643,t:1526922965813};\\\", \\\"{x:1546,y:643,t:1526922965829};\\\", \\\"{x:1548,y:643,t:1526922965846};\\\", \\\"{x:1549,y:643,t:1526922965864};\\\", \\\"{x:1552,y:643,t:1526922965880};\\\", \\\"{x:1553,y:643,t:1526922965896};\\\", \\\"{x:1556,y:643,t:1526922965913};\\\", \\\"{x:1559,y:643,t:1526922965929};\\\", \\\"{x:1560,y:643,t:1526922965950};\\\", \\\"{x:1561,y:643,t:1526922965963};\\\", \\\"{x:1561,y:644,t:1526922969254};\\\", \\\"{x:1560,y:645,t:1526922969267};\\\", \\\"{x:1555,y:646,t:1526922969284};\\\", \\\"{x:1551,y:647,t:1526922969299};\\\", \\\"{x:1548,y:647,t:1526922969316};\\\", \\\"{x:1547,y:648,t:1526922969334};\\\", \\\"{x:1544,y:648,t:1526922969350};\\\", \\\"{x:1542,y:648,t:1526922969367};\\\", \\\"{x:1540,y:648,t:1526922969383};\\\", \\\"{x:1534,y:650,t:1526922969401};\\\", \\\"{x:1532,y:650,t:1526922969417};\\\", \\\"{x:1530,y:651,t:1526922969434};\\\", \\\"{x:1525,y:651,t:1526922969451};\\\", \\\"{x:1518,y:651,t:1526922969466};\\\", \\\"{x:1512,y:652,t:1526922969484};\\\", \\\"{x:1503,y:652,t:1526922969501};\\\", \\\"{x:1491,y:654,t:1526922969517};\\\", \\\"{x:1480,y:654,t:1526922969534};\\\", \\\"{x:1465,y:654,t:1526922969550};\\\", \\\"{x:1456,y:654,t:1526922969566};\\\", \\\"{x:1450,y:654,t:1526922969584};\\\", \\\"{x:1447,y:654,t:1526922969601};\\\", \\\"{x:1444,y:654,t:1526922969616};\\\", \\\"{x:1443,y:654,t:1526922969634};\\\", \\\"{x:1442,y:654,t:1526922969678};\\\", \\\"{x:1441,y:654,t:1526922969686};\\\", \\\"{x:1440,y:654,t:1526922969701};\\\", \\\"{x:1439,y:654,t:1526922969718};\\\", \\\"{x:1437,y:653,t:1526922969735};\\\", \\\"{x:1437,y:652,t:1526922969870};\\\", \\\"{x:1437,y:651,t:1526922969884};\\\", \\\"{x:1441,y:649,t:1526922969900};\\\", \\\"{x:1444,y:648,t:1526922969917};\\\", \\\"{x:1448,y:647,t:1526922969933};\\\", \\\"{x:1451,y:646,t:1526922969950};\\\", \\\"{x:1455,y:646,t:1526922969968};\\\", \\\"{x:1461,y:646,t:1526922969985};\\\", \\\"{x:1468,y:645,t:1526922970001};\\\", \\\"{x:1474,y:645,t:1526922970018};\\\", \\\"{x:1480,y:645,t:1526922970035};\\\", \\\"{x:1484,y:645,t:1526922970051};\\\", \\\"{x:1487,y:645,t:1526922970068};\\\", \\\"{x:1488,y:645,t:1526922970084};\\\", \\\"{x:1490,y:645,t:1526922970101};\\\", \\\"{x:1491,y:645,t:1526922970118};\\\", \\\"{x:1492,y:645,t:1526922970134};\\\", \\\"{x:1493,y:645,t:1526922970158};\\\", \\\"{x:1493,y:644,t:1526922970167};\\\", \\\"{x:1492,y:644,t:1526922970760};\\\", \\\"{x:1491,y:644,t:1526922970769};\\\", \\\"{x:1489,y:645,t:1526922970800};\\\", \\\"{x:1488,y:645,t:1526922970816};\\\", \\\"{x:1487,y:646,t:1526922970823};\\\", \\\"{x:1486,y:646,t:1526922970839};\\\", \\\"{x:1484,y:647,t:1526922970853};\\\", \\\"{x:1483,y:648,t:1526922970880};\\\", \\\"{x:1482,y:648,t:1526922970895};\\\", \\\"{x:1481,y:648,t:1526922971192};\\\", \\\"{x:1480,y:648,t:1526922972846};\\\", \\\"{x:1479,y:648,t:1526922972862};\\\", \\\"{x:1478,y:648,t:1526922973071};\\\", \\\"{x:1476,y:646,t:1526922974454};\\\", \\\"{x:1476,y:644,t:1526922974463};\\\", \\\"{x:1476,y:641,t:1526922974472};\\\", \\\"{x:1475,y:638,t:1526922974489};\\\", \\\"{x:1473,y:632,t:1526922974506};\\\", \\\"{x:1472,y:627,t:1526922974522};\\\", \\\"{x:1471,y:623,t:1526922974539};\\\", \\\"{x:1470,y:619,t:1526922974556};\\\", \\\"{x:1470,y:616,t:1526922974572};\\\", \\\"{x:1470,y:614,t:1526922974589};\\\", \\\"{x:1470,y:612,t:1526922974606};\\\", \\\"{x:1467,y:609,t:1526922974622};\\\", \\\"{x:1467,y:606,t:1526922974639};\\\", \\\"{x:1467,y:604,t:1526922974656};\\\", \\\"{x:1466,y:603,t:1526922974673};\\\", \\\"{x:1466,y:602,t:1526922974688};\\\", \\\"{x:1466,y:601,t:1526922974706};\\\", \\\"{x:1466,y:599,t:1526922974723};\\\", \\\"{x:1465,y:597,t:1526922974738};\\\", \\\"{x:1465,y:595,t:1526922974756};\\\", \\\"{x:1465,y:593,t:1526922974773};\\\", \\\"{x:1465,y:592,t:1526922974788};\\\", \\\"{x:1465,y:591,t:1526922974806};\\\", \\\"{x:1468,y:597,t:1526922974974};\\\", \\\"{x:1470,y:601,t:1526922974989};\\\", \\\"{x:1475,y:612,t:1526922975006};\\\", \\\"{x:1478,y:624,t:1526922975022};\\\", \\\"{x:1480,y:633,t:1526922975040};\\\", \\\"{x:1482,y:638,t:1526922975056};\\\", \\\"{x:1483,y:642,t:1526922975072};\\\", \\\"{x:1484,y:644,t:1526922975090};\\\", \\\"{x:1484,y:645,t:1526922975106};\\\", \\\"{x:1483,y:644,t:1526922975695};\\\", \\\"{x:1483,y:637,t:1526922978927};\\\", \\\"{x:1484,y:603,t:1526922978944};\\\", \\\"{x:1480,y:570,t:1526922978960};\\\", \\\"{x:1471,y:524,t:1526922978977};\\\", \\\"{x:1459,y:484,t:1526922978994};\\\", \\\"{x:1446,y:451,t:1526922979009};\\\", \\\"{x:1434,y:427,t:1526922979027};\\\", \\\"{x:1424,y:410,t:1526922979044};\\\", \\\"{x:1419,y:397,t:1526922979060};\\\", \\\"{x:1417,y:384,t:1526922979077};\\\", \\\"{x:1414,y:367,t:1526922979094};\\\", \\\"{x:1412,y:358,t:1526922979110};\\\", \\\"{x:1410,y:352,t:1526922979127};\\\", \\\"{x:1408,y:347,t:1526922979144};\\\", \\\"{x:1406,y:344,t:1526922979159};\\\", \\\"{x:1405,y:342,t:1526922979177};\\\", \\\"{x:1405,y:343,t:1526922979294};\\\", \\\"{x:1405,y:351,t:1526922979310};\\\", \\\"{x:1408,y:363,t:1526922979327};\\\", \\\"{x:1411,y:373,t:1526922979345};\\\", \\\"{x:1413,y:379,t:1526922979361};\\\", \\\"{x:1415,y:382,t:1526922979377};\\\", \\\"{x:1416,y:384,t:1526922979395};\\\", \\\"{x:1416,y:383,t:1526922980630};\\\", \\\"{x:1416,y:381,t:1526922980646};\\\", \\\"{x:1416,y:380,t:1526922980663};\\\", \\\"{x:1416,y:379,t:1526922980686};\\\", \\\"{x:1415,y:378,t:1526922982662};\\\", \\\"{x:1415,y:381,t:1526922982934};\\\", \\\"{x:1415,y:388,t:1526922982948};\\\", \\\"{x:1416,y:399,t:1526922982964};\\\", \\\"{x:1418,y:413,t:1526922982981};\\\", \\\"{x:1427,y:442,t:1526922982998};\\\", \\\"{x:1434,y:460,t:1526922983014};\\\", \\\"{x:1439,y:479,t:1526922983032};\\\", \\\"{x:1443,y:499,t:1526922983048};\\\", \\\"{x:1448,y:523,t:1526922983064};\\\", \\\"{x:1451,y:552,t:1526922983081};\\\", \\\"{x:1456,y:587,t:1526922983098};\\\", \\\"{x:1463,y:627,t:1526922983114};\\\", \\\"{x:1465,y:660,t:1526922983131};\\\", \\\"{x:1468,y:691,t:1526922983148};\\\", \\\"{x:1470,y:718,t:1526922983164};\\\", \\\"{x:1475,y:740,t:1526922983181};\\\", \\\"{x:1479,y:772,t:1526922983198};\\\", \\\"{x:1483,y:789,t:1526922983214};\\\", \\\"{x:1484,y:803,t:1526922983231};\\\", \\\"{x:1484,y:809,t:1526922983248};\\\", \\\"{x:1484,y:821,t:1526922983265};\\\", \\\"{x:1484,y:833,t:1526922983281};\\\", \\\"{x:1484,y:841,t:1526922983298};\\\", \\\"{x:1484,y:850,t:1526922983315};\\\", \\\"{x:1484,y:861,t:1526922983331};\\\", \\\"{x:1484,y:871,t:1526922983348};\\\", \\\"{x:1483,y:881,t:1526922983365};\\\", \\\"{x:1479,y:893,t:1526922983381};\\\", \\\"{x:1477,y:903,t:1526922983398};\\\", \\\"{x:1475,y:910,t:1526922983415};\\\", \\\"{x:1475,y:914,t:1526922983432};\\\", \\\"{x:1475,y:916,t:1526922983454};\\\", \\\"{x:1475,y:917,t:1526922983470};\\\", \\\"{x:1475,y:918,t:1526922983486};\\\", \\\"{x:1475,y:919,t:1526922983845};\\\", \\\"{x:1477,y:919,t:1526922983854};\\\", \\\"{x:1479,y:918,t:1526922983865};\\\", \\\"{x:1481,y:913,t:1526922983883};\\\", \\\"{x:1484,y:906,t:1526922983899};\\\", \\\"{x:1487,y:901,t:1526922983915};\\\", \\\"{x:1488,y:898,t:1526922983932};\\\", \\\"{x:1490,y:894,t:1526922983949};\\\", \\\"{x:1491,y:890,t:1526922983965};\\\", \\\"{x:1494,y:885,t:1526922983982};\\\", \\\"{x:1495,y:883,t:1526922983999};\\\", \\\"{x:1496,y:880,t:1526922984015};\\\", \\\"{x:1496,y:878,t:1526922984032};\\\", \\\"{x:1497,y:875,t:1526922984049};\\\", \\\"{x:1498,y:869,t:1526922984065};\\\", \\\"{x:1500,y:866,t:1526922984082};\\\", \\\"{x:1501,y:862,t:1526922984099};\\\", \\\"{x:1501,y:859,t:1526922984115};\\\", \\\"{x:1501,y:855,t:1526922984132};\\\", \\\"{x:1502,y:852,t:1526922984149};\\\", \\\"{x:1502,y:848,t:1526922984165};\\\", \\\"{x:1502,y:842,t:1526922984182};\\\", \\\"{x:1502,y:839,t:1526922984199};\\\", \\\"{x:1502,y:836,t:1526922984216};\\\", \\\"{x:1502,y:834,t:1526922984232};\\\", \\\"{x:1502,y:831,t:1526922984249};\\\", \\\"{x:1502,y:828,t:1526922984266};\\\", \\\"{x:1502,y:824,t:1526922984282};\\\", \\\"{x:1502,y:821,t:1526922984299};\\\", \\\"{x:1502,y:819,t:1526922984316};\\\", \\\"{x:1502,y:817,t:1526922984333};\\\", \\\"{x:1502,y:814,t:1526922984349};\\\", \\\"{x:1502,y:810,t:1526922984366};\\\", \\\"{x:1502,y:808,t:1526922984382};\\\", \\\"{x:1502,y:806,t:1526922984399};\\\", \\\"{x:1502,y:804,t:1526922984416};\\\", \\\"{x:1501,y:801,t:1526922984432};\\\", \\\"{x:1501,y:800,t:1526922984454};\\\", \\\"{x:1501,y:799,t:1526922984466};\\\", \\\"{x:1501,y:798,t:1526922984485};\\\", \\\"{x:1501,y:796,t:1526922984509};\\\", \\\"{x:1501,y:795,t:1526922984550};\\\", \\\"{x:1501,y:793,t:1526922984574};\\\", \\\"{x:1501,y:792,t:1526922984606};\\\", \\\"{x:1501,y:790,t:1526922984622};\\\", \\\"{x:1501,y:789,t:1526922984647};\\\", \\\"{x:1501,y:787,t:1526922984686};\\\", \\\"{x:1501,y:786,t:1526922984806};\\\", \\\"{x:1501,y:785,t:1526922984816};\\\", \\\"{x:1500,y:783,t:1526922984833};\\\", \\\"{x:1500,y:782,t:1526922984849};\\\", \\\"{x:1500,y:780,t:1526922984866};\\\", \\\"{x:1500,y:778,t:1526922984883};\\\", \\\"{x:1498,y:776,t:1526922984900};\\\", \\\"{x:1498,y:774,t:1526922984916};\\\", \\\"{x:1497,y:772,t:1526922984933};\\\", \\\"{x:1496,y:769,t:1526922984950};\\\", \\\"{x:1496,y:767,t:1526922984966};\\\", \\\"{x:1496,y:766,t:1526922984990};\\\", \\\"{x:1496,y:765,t:1526922985000};\\\", \\\"{x:1496,y:764,t:1526922985016};\\\", \\\"{x:1496,y:763,t:1526922985038};\\\", \\\"{x:1496,y:762,t:1526922985050};\\\", \\\"{x:1494,y:760,t:1526922985066};\\\", \\\"{x:1494,y:759,t:1526922985109};\\\", \\\"{x:1494,y:758,t:1526922985134};\\\", \\\"{x:1494,y:757,t:1526922985150};\\\", \\\"{x:1494,y:756,t:1526922985166};\\\", \\\"{x:1494,y:754,t:1526922985190};\\\", \\\"{x:1495,y:752,t:1526922985206};\\\", \\\"{x:1495,y:751,t:1526922985222};\\\", \\\"{x:1495,y:750,t:1526922985233};\\\", \\\"{x:1495,y:747,t:1526922985250};\\\", \\\"{x:1495,y:746,t:1526922985267};\\\", \\\"{x:1496,y:744,t:1526922985284};\\\", \\\"{x:1497,y:743,t:1526922985300};\\\", \\\"{x:1497,y:742,t:1526922985317};\\\", \\\"{x:1497,y:741,t:1526922985333};\\\", \\\"{x:1498,y:740,t:1526922985350};\\\", \\\"{x:1498,y:739,t:1526922985367};\\\", \\\"{x:1498,y:738,t:1526922985383};\\\", \\\"{x:1498,y:736,t:1526922985400};\\\", \\\"{x:1498,y:735,t:1526922985417};\\\", \\\"{x:1500,y:732,t:1526922985433};\\\", \\\"{x:1501,y:731,t:1526922985450};\\\", \\\"{x:1501,y:729,t:1526922985467};\\\", \\\"{x:1501,y:728,t:1526922985483};\\\", \\\"{x:1502,y:726,t:1526922985500};\\\", \\\"{x:1502,y:725,t:1526922985518};\\\", \\\"{x:1503,y:722,t:1526922985534};\\\", \\\"{x:1504,y:722,t:1526922985550};\\\", \\\"{x:1504,y:721,t:1526922985567};\\\", \\\"{x:1504,y:720,t:1526922985584};\\\", \\\"{x:1504,y:719,t:1526922985600};\\\", \\\"{x:1505,y:718,t:1526922985617};\\\", \\\"{x:1505,y:717,t:1526922985634};\\\", \\\"{x:1506,y:715,t:1526922985650};\\\", \\\"{x:1506,y:714,t:1526922985678};\\\", \\\"{x:1506,y:713,t:1526922985693};\\\", \\\"{x:1507,y:713,t:1526922985702};\\\", \\\"{x:1507,y:712,t:1526922985734};\\\", \\\"{x:1507,y:711,t:1526922985750};\\\", \\\"{x:1508,y:710,t:1526922985767};\\\", \\\"{x:1508,y:709,t:1526922985790};\\\", \\\"{x:1509,y:707,t:1526922985806};\\\", \\\"{x:1510,y:706,t:1526922985846};\\\", \\\"{x:1510,y:705,t:1526922985878};\\\", \\\"{x:1511,y:704,t:1526922985910};\\\", \\\"{x:1512,y:703,t:1526922991606};\\\", \\\"{x:1513,y:703,t:1526922991623};\\\", \\\"{x:1513,y:704,t:1526922991641};\\\", \\\"{x:1513,y:705,t:1526922991657};\\\", \\\"{x:1513,y:706,t:1526922991691};\\\", \\\"{x:1513,y:707,t:1526922991734};\\\", \\\"{x:1513,y:708,t:1526922991766};\\\", \\\"{x:1513,y:709,t:1526922991822};\\\", \\\"{x:1512,y:716,t:1526922996470};\\\", \\\"{x:1508,y:726,t:1526922996478};\\\", \\\"{x:1499,y:748,t:1526922996495};\\\", \\\"{x:1494,y:762,t:1526922996512};\\\", \\\"{x:1488,y:776,t:1526922996528};\\\", \\\"{x:1484,y:787,t:1526922996546};\\\", \\\"{x:1479,y:803,t:1526922996561};\\\", \\\"{x:1476,y:820,t:1526922996579};\\\", \\\"{x:1472,y:839,t:1526922996596};\\\", \\\"{x:1465,y:861,t:1526922996611};\\\", \\\"{x:1460,y:876,t:1526922996628};\\\", \\\"{x:1457,y:904,t:1526922996645};\\\", \\\"{x:1454,y:920,t:1526922996661};\\\", \\\"{x:1453,y:930,t:1526922996678};\\\", \\\"{x:1452,y:934,t:1526922996696};\\\", \\\"{x:1452,y:935,t:1526922996711};\\\", \\\"{x:1451,y:936,t:1526922996766};\\\", \\\"{x:1450,y:936,t:1526922996781};\\\", \\\"{x:1448,y:936,t:1526922996798};\\\", \\\"{x:1448,y:935,t:1526922996812};\\\", \\\"{x:1448,y:929,t:1526922996829};\\\", \\\"{x:1448,y:922,t:1526922996845};\\\", \\\"{x:1448,y:911,t:1526922996862};\\\", \\\"{x:1448,y:903,t:1526922996879};\\\", \\\"{x:1451,y:894,t:1526922996895};\\\", \\\"{x:1453,y:887,t:1526922996913};\\\", \\\"{x:1454,y:879,t:1526922996928};\\\", \\\"{x:1456,y:874,t:1526922996945};\\\", \\\"{x:1457,y:870,t:1526922996962};\\\", \\\"{x:1459,y:867,t:1526922996979};\\\", \\\"{x:1459,y:866,t:1526922996995};\\\", \\\"{x:1460,y:865,t:1526922997014};\\\", \\\"{x:1460,y:864,t:1526922997038};\\\", \\\"{x:1460,y:863,t:1526922997062};\\\", \\\"{x:1461,y:862,t:1526922997150};\\\", \\\"{x:1463,y:862,t:1526922997162};\\\", \\\"{x:1466,y:867,t:1526922997179};\\\", \\\"{x:1468,y:872,t:1526922997195};\\\", \\\"{x:1472,y:880,t:1526922997212};\\\", \\\"{x:1476,y:891,t:1526922997229};\\\", \\\"{x:1477,y:896,t:1526922997245};\\\", \\\"{x:1479,y:900,t:1526922997262};\\\", \\\"{x:1479,y:901,t:1526922997280};\\\", \\\"{x:1478,y:901,t:1526922997358};\\\", \\\"{x:1477,y:901,t:1526922997366};\\\", \\\"{x:1476,y:901,t:1526922997382};\\\", \\\"{x:1475,y:901,t:1526922997395};\\\", \\\"{x:1473,y:899,t:1526922997413};\\\", \\\"{x:1473,y:897,t:1526922997430};\\\", \\\"{x:1472,y:894,t:1526922997445};\\\", \\\"{x:1472,y:890,t:1526922997462};\\\", \\\"{x:1472,y:886,t:1526922997480};\\\", \\\"{x:1472,y:882,t:1526922997496};\\\", \\\"{x:1472,y:876,t:1526922997513};\\\", \\\"{x:1472,y:871,t:1526922997530};\\\", \\\"{x:1472,y:866,t:1526922997546};\\\", \\\"{x:1472,y:860,t:1526922997563};\\\", \\\"{x:1472,y:855,t:1526922997580};\\\", \\\"{x:1472,y:851,t:1526922997596};\\\", \\\"{x:1472,y:846,t:1526922997613};\\\", \\\"{x:1473,y:839,t:1526922997629};\\\", \\\"{x:1474,y:834,t:1526922997646};\\\", \\\"{x:1474,y:829,t:1526922997662};\\\", \\\"{x:1475,y:824,t:1526922997680};\\\", \\\"{x:1477,y:818,t:1526922997696};\\\", \\\"{x:1478,y:816,t:1526922997713};\\\", \\\"{x:1478,y:812,t:1526922997730};\\\", \\\"{x:1479,y:808,t:1526922997746};\\\", \\\"{x:1480,y:803,t:1526922997762};\\\", \\\"{x:1480,y:798,t:1526922997779};\\\", \\\"{x:1481,y:795,t:1526922997796};\\\", \\\"{x:1482,y:790,t:1526922997813};\\\", \\\"{x:1482,y:787,t:1526922997829};\\\", \\\"{x:1484,y:783,t:1526922997847};\\\", \\\"{x:1484,y:781,t:1526922997863};\\\", \\\"{x:1484,y:779,t:1526922997880};\\\", \\\"{x:1484,y:777,t:1526922997896};\\\", \\\"{x:1484,y:775,t:1526922997913};\\\", \\\"{x:1484,y:773,t:1526922997929};\\\", \\\"{x:1484,y:772,t:1526922997947};\\\", \\\"{x:1485,y:770,t:1526922997964};\\\", \\\"{x:1485,y:769,t:1526922997980};\\\", \\\"{x:1486,y:767,t:1526922997997};\\\", \\\"{x:1486,y:765,t:1526922998030};\\\", \\\"{x:1486,y:764,t:1526922998053};\\\", \\\"{x:1486,y:762,t:1526922998086};\\\", \\\"{x:1487,y:760,t:1526922998102};\\\", \\\"{x:1487,y:759,t:1526922998133};\\\", \\\"{x:1487,y:758,t:1526922998149};\\\", \\\"{x:1488,y:757,t:1526922998164};\\\", \\\"{x:1488,y:756,t:1526922998180};\\\", \\\"{x:1488,y:754,t:1526922998197};\\\", \\\"{x:1488,y:751,t:1526922998214};\\\", \\\"{x:1488,y:749,t:1526922998230};\\\", \\\"{x:1488,y:747,t:1526922998247};\\\", \\\"{x:1488,y:746,t:1526922998264};\\\", \\\"{x:1488,y:744,t:1526922998280};\\\", \\\"{x:1488,y:743,t:1526922998296};\\\", \\\"{x:1488,y:741,t:1526922998313};\\\", \\\"{x:1488,y:740,t:1526922998331};\\\", \\\"{x:1488,y:739,t:1526922998346};\\\", \\\"{x:1488,y:737,t:1526922998363};\\\", \\\"{x:1488,y:736,t:1526922998382};\\\", \\\"{x:1488,y:735,t:1526922998397};\\\", \\\"{x:1488,y:733,t:1526922998413};\\\", \\\"{x:1488,y:731,t:1526922998431};\\\", \\\"{x:1488,y:730,t:1526922998448};\\\", \\\"{x:1488,y:728,t:1526922998464};\\\", \\\"{x:1488,y:727,t:1526922998481};\\\", \\\"{x:1488,y:726,t:1526922998498};\\\", \\\"{x:1488,y:725,t:1526922998514};\\\", \\\"{x:1488,y:724,t:1526922998531};\\\", \\\"{x:1488,y:722,t:1526922998547};\\\", \\\"{x:1488,y:721,t:1526922998563};\\\", \\\"{x:1488,y:719,t:1526922998581};\\\", \\\"{x:1488,y:717,t:1526922998598};\\\", \\\"{x:1488,y:716,t:1526922998614};\\\", \\\"{x:1488,y:715,t:1526922998631};\\\", \\\"{x:1488,y:714,t:1526922998648};\\\", \\\"{x:1488,y:713,t:1526922998664};\\\", \\\"{x:1488,y:712,t:1526922998680};\\\", \\\"{x:1488,y:711,t:1526922998698};\\\", \\\"{x:1488,y:710,t:1526922998714};\\\", \\\"{x:1487,y:709,t:1526922998731};\\\", \\\"{x:1487,y:708,t:1526922998750};\\\", \\\"{x:1487,y:707,t:1526922998774};\\\", \\\"{x:1489,y:709,t:1526923001790};\\\", \\\"{x:1500,y:712,t:1526923001801};\\\", \\\"{x:1553,y:722,t:1526923001817};\\\", \\\"{x:1555,y:726,t:1526923001834};\\\", \\\"{x:1557,y:726,t:1526923002126};\\\", \\\"{x:1557,y:725,t:1526923002134};\\\", \\\"{x:1539,y:718,t:1526923002150};\\\", \\\"{x:1513,y:711,t:1526923002167};\\\", \\\"{x:1485,y:702,t:1526923002185};\\\", \\\"{x:1461,y:690,t:1526923002201};\\\", \\\"{x:1425,y:678,t:1526923002218};\\\", \\\"{x:1340,y:659,t:1526923002235};\\\", \\\"{x:1246,y:646,t:1526923002251};\\\", \\\"{x:1130,y:634,t:1526923002268};\\\", \\\"{x:991,y:608,t:1526923002285};\\\", \\\"{x:848,y:597,t:1526923002301};\\\", \\\"{x:717,y:600,t:1526923002317};\\\", \\\"{x:687,y:605,t:1526923002334};\\\", \\\"{x:683,y:601,t:1526923002351};\\\", \\\"{x:683,y:586,t:1526923002368};\\\", \\\"{x:680,y:546,t:1526923002385};\\\", \\\"{x:662,y:502,t:1526923002401};\\\", \\\"{x:637,y:447,t:1526923002418};\\\", \\\"{x:599,y:374,t:1526923002435};\\\", \\\"{x:566,y:324,t:1526923002451};\\\", \\\"{x:552,y:301,t:1526923002468};\\\", \\\"{x:543,y:299,t:1526923002484};\\\", \\\"{x:534,y:299,t:1526923002500};\\\", \\\"{x:517,y:313,t:1526923002518};\\\", \\\"{x:507,y:335,t:1526923002535};\\\", \\\"{x:499,y:358,t:1526923002551};\\\", \\\"{x:496,y:380,t:1526923002568};\\\", \\\"{x:493,y:399,t:1526923002585};\\\", \\\"{x:492,y:420,t:1526923002602};\\\", \\\"{x:492,y:439,t:1526923002618};\\\", \\\"{x:492,y:461,t:1526923002636};\\\", \\\"{x:492,y:488,t:1526923002652};\\\", \\\"{x:498,y:524,t:1526923002669};\\\", \\\"{x:512,y:562,t:1526923002685};\\\", \\\"{x:529,y:611,t:1526923002702};\\\", \\\"{x:533,y:634,t:1526923002718};\\\", \\\"{x:533,y:648,t:1526923002735};\\\", \\\"{x:533,y:653,t:1526923002752};\\\", \\\"{x:534,y:655,t:1526923002768};\\\", \\\"{x:535,y:657,t:1526923003110};\\\", \\\"{x:536,y:657,t:1526923003117};\\\", \\\"{x:558,y:629,t:1526923003133};\\\", \\\"{x:602,y:574,t:1526923003151};\\\", \\\"{x:651,y:526,t:1526923003167};\\\", \\\"{x:691,y:495,t:1526923003186};\\\", \\\"{x:716,y:478,t:1526923003203};\\\", \\\"{x:730,y:467,t:1526923003219};\\\", \\\"{x:739,y:462,t:1526923003234};\\\", \\\"{x:742,y:460,t:1526923003252};\\\", \\\"{x:745,y:459,t:1526923003269};\\\", \\\"{x:746,y:458,t:1526923003285};\\\", \\\"{x:750,y:457,t:1526923003302};\\\", \\\"{x:751,y:457,t:1526923003317};\\\", \\\"{x:752,y:456,t:1526923003334};\\\", \\\"{x:753,y:456,t:1526923003422};\\\", \\\"{x:754,y:456,t:1526923003435};\\\", \\\"{x:756,y:456,t:1526923003494};\\\", \\\"{x:757,y:456,t:1526923003501};\\\", \\\"{x:761,y:461,t:1526923003518};\\\", \\\"{x:768,y:471,t:1526923003535};\\\", \\\"{x:775,y:480,t:1526923003551};\\\", \\\"{x:784,y:487,t:1526923003568};\\\", \\\"{x:791,y:491,t:1526923003586};\\\", \\\"{x:797,y:492,t:1526923003601};\\\", \\\"{x:801,y:494,t:1526923003619};\\\", \\\"{x:802,y:495,t:1526923003646};\\\", \\\"{x:804,y:496,t:1526923003654};\\\", \\\"{x:806,y:496,t:1526923003669};\\\", \\\"{x:818,y:502,t:1526923003686};\\\", \\\"{x:828,y:504,t:1526923003702};\\\", \\\"{x:834,y:504,t:1526923003719};\\\", \\\"{x:838,y:504,t:1526923003735};\\\", \\\"{x:839,y:504,t:1526923003752};\\\", \\\"{x:840,y:504,t:1526923003768};\\\", \\\"{x:843,y:504,t:1526923003786};\\\", \\\"{x:844,y:503,t:1526923003803};\\\", \\\"{x:849,y:500,t:1526923003820};\\\", \\\"{x:853,y:499,t:1526923003836};\\\", \\\"{x:856,y:497,t:1526923003852};\\\", \\\"{x:857,y:496,t:1526923003870};\\\", \\\"{x:854,y:496,t:1526923004030};\\\", \\\"{x:852,y:497,t:1526923004038};\\\", \\\"{x:847,y:498,t:1526923004053};\\\", \\\"{x:840,y:501,t:1526923004070};\\\", \\\"{x:839,y:501,t:1526923004087};\\\", \\\"{x:838,y:501,t:1526923004198};\\\", \\\"{x:838,y:500,t:1526923004213};\\\", \\\"{x:838,y:499,t:1526923004221};\\\", \\\"{x:839,y:498,t:1526923004237};\\\", \\\"{x:841,y:496,t:1526923004254};\\\", \\\"{x:842,y:495,t:1526923004270};\\\", \\\"{x:843,y:495,t:1526923004438};\\\", \\\"{x:847,y:495,t:1526923004454};\\\", \\\"{x:848,y:496,t:1526923004471};\\\", \\\"{x:849,y:496,t:1526923004488};\\\", \\\"{x:848,y:498,t:1526923005126};\\\", \\\"{x:845,y:498,t:1526923005136};\\\", \\\"{x:840,y:500,t:1526923005154};\\\", \\\"{x:822,y:500,t:1526923005170};\\\", \\\"{x:797,y:500,t:1526923005187};\\\", \\\"{x:767,y:500,t:1526923005204};\\\", \\\"{x:720,y:500,t:1526923005220};\\\", \\\"{x:664,y:500,t:1526923005237};\\\", \\\"{x:591,y:500,t:1526923005253};\\\", \\\"{x:558,y:500,t:1526923005270};\\\", \\\"{x:532,y:501,t:1526923005287};\\\", \\\"{x:512,y:503,t:1526923005304};\\\", \\\"{x:495,y:505,t:1526923005320};\\\", \\\"{x:481,y:508,t:1526923005337};\\\", \\\"{x:471,y:509,t:1526923005353};\\\", \\\"{x:459,y:512,t:1526923005370};\\\", \\\"{x:445,y:515,t:1526923005386};\\\", \\\"{x:425,y:518,t:1526923005404};\\\", \\\"{x:403,y:521,t:1526923005419};\\\", \\\"{x:382,y:525,t:1526923005437};\\\", \\\"{x:347,y:528,t:1526923005453};\\\", \\\"{x:326,y:531,t:1526923005471};\\\", \\\"{x:303,y:531,t:1526923005487};\\\", \\\"{x:283,y:531,t:1526923005504};\\\", \\\"{x:262,y:531,t:1526923005521};\\\", \\\"{x:243,y:531,t:1526923005537};\\\", \\\"{x:225,y:531,t:1526923005554};\\\", \\\"{x:213,y:530,t:1526923005570};\\\", \\\"{x:206,y:528,t:1526923005587};\\\", \\\"{x:202,y:526,t:1526923005604};\\\", \\\"{x:201,y:526,t:1526923005620};\\\", \\\"{x:200,y:526,t:1526923005670};\\\", \\\"{x:199,y:529,t:1526923005686};\\\", \\\"{x:198,y:540,t:1526923005704};\\\", \\\"{x:198,y:552,t:1526923005720};\\\", \\\"{x:200,y:567,t:1526923005737};\\\", \\\"{x:206,y:579,t:1526923005753};\\\", \\\"{x:213,y:591,t:1526923005770};\\\", \\\"{x:219,y:599,t:1526923005787};\\\", \\\"{x:220,y:604,t:1526923005804};\\\", \\\"{x:223,y:608,t:1526923005821};\\\", \\\"{x:223,y:612,t:1526923005836};\\\", \\\"{x:222,y:616,t:1526923005854};\\\", \\\"{x:220,y:617,t:1526923005871};\\\", \\\"{x:217,y:619,t:1526923005887};\\\", \\\"{x:216,y:619,t:1526923005904};\\\", \\\"{x:215,y:619,t:1526923005920};\\\", \\\"{x:214,y:619,t:1526923005937};\\\", \\\"{x:213,y:615,t:1526923005954};\\\", \\\"{x:227,y:597,t:1526923005971};\\\", \\\"{x:258,y:569,t:1526923005990};\\\", \\\"{x:308,y:536,t:1526923006005};\\\", \\\"{x:367,y:504,t:1526923006021};\\\", \\\"{x:403,y:489,t:1526923006037};\\\", \\\"{x:439,y:475,t:1526923006054};\\\", \\\"{x:456,y:471,t:1526923006071};\\\", \\\"{x:463,y:471,t:1526923006088};\\\", \\\"{x:464,y:471,t:1526923006104};\\\", \\\"{x:466,y:471,t:1526923006121};\\\", \\\"{x:470,y:474,t:1526923006138};\\\", \\\"{x:479,y:480,t:1526923006155};\\\", \\\"{x:493,y:485,t:1526923006171};\\\", \\\"{x:515,y:487,t:1526923006188};\\\", \\\"{x:536,y:488,t:1526923006204};\\\", \\\"{x:552,y:488,t:1526923006220};\\\", \\\"{x:567,y:490,t:1526923006237};\\\", \\\"{x:573,y:490,t:1526923006253};\\\", \\\"{x:584,y:488,t:1526923006271};\\\", \\\"{x:594,y:484,t:1526923006288};\\\", \\\"{x:609,y:480,t:1526923006305};\\\", \\\"{x:618,y:478,t:1526923006322};\\\", \\\"{x:627,y:478,t:1526923006338};\\\", \\\"{x:637,y:478,t:1526923006354};\\\", \\\"{x:646,y:481,t:1526923006371};\\\", \\\"{x:651,y:486,t:1526923006388};\\\", \\\"{x:657,y:494,t:1526923006404};\\\", \\\"{x:660,y:499,t:1526923006421};\\\", \\\"{x:662,y:506,t:1526923006438};\\\", \\\"{x:662,y:509,t:1526923006454};\\\", \\\"{x:660,y:513,t:1526923006471};\\\", \\\"{x:647,y:514,t:1526923006487};\\\", \\\"{x:632,y:514,t:1526923006503};\\\", \\\"{x:612,y:512,t:1526923006521};\\\", \\\"{x:602,y:507,t:1526923006538};\\\", \\\"{x:597,y:504,t:1526923006555};\\\", \\\"{x:596,y:502,t:1526923006572};\\\", \\\"{x:596,y:498,t:1526923006588};\\\", \\\"{x:596,y:494,t:1526923006605};\\\", \\\"{x:599,y:491,t:1526923006621};\\\", \\\"{x:603,y:486,t:1526923006638};\\\", \\\"{x:606,y:482,t:1526923006656};\\\", \\\"{x:607,y:481,t:1526923006671};\\\", \\\"{x:608,y:481,t:1526923006759};\\\", \\\"{x:609,y:481,t:1526923006782};\\\", \\\"{x:611,y:483,t:1526923006789};\\\", \\\"{x:613,y:488,t:1526923006805};\\\", \\\"{x:620,y:511,t:1526923006822};\\\", \\\"{x:626,y:524,t:1526923006838};\\\", \\\"{x:629,y:528,t:1526923006855};\\\", \\\"{x:631,y:530,t:1526923006871};\\\", \\\"{x:631,y:529,t:1526923006965};\\\", \\\"{x:631,y:528,t:1526923006974};\\\", \\\"{x:631,y:527,t:1526923006990};\\\", \\\"{x:631,y:525,t:1526923007005};\\\", \\\"{x:631,y:522,t:1526923007023};\\\", \\\"{x:629,y:519,t:1526923007037};\\\", \\\"{x:628,y:516,t:1526923007055};\\\", \\\"{x:627,y:512,t:1526923007072};\\\", \\\"{x:626,y:509,t:1526923007088};\\\", \\\"{x:625,y:507,t:1526923007105};\\\", \\\"{x:625,y:505,t:1526923007122};\\\", \\\"{x:624,y:504,t:1526923007138};\\\", \\\"{x:624,y:503,t:1526923007173};\\\", \\\"{x:624,y:506,t:1526923007414};\\\", \\\"{x:620,y:514,t:1526923007422};\\\", \\\"{x:618,y:528,t:1526923007439};\\\", \\\"{x:612,y:549,t:1526923007455};\\\", \\\"{x:606,y:568,t:1526923007473};\\\", \\\"{x:603,y:586,t:1526923007489};\\\", \\\"{x:601,y:602,t:1526923007505};\\\", \\\"{x:597,y:624,t:1526923007522};\\\", \\\"{x:596,y:639,t:1526923007539};\\\", \\\"{x:597,y:648,t:1526923007555};\\\", \\\"{x:597,y:654,t:1526923007572};\\\", \\\"{x:597,y:659,t:1526923007589};\\\", \\\"{x:597,y:663,t:1526923007605};\\\", \\\"{x:594,y:675,t:1526923007621};\\\", \\\"{x:591,y:681,t:1526923007639};\\\", \\\"{x:589,y:685,t:1526923007655};\\\", \\\"{x:588,y:688,t:1526923007672};\\\", \\\"{x:588,y:690,t:1526923007689};\\\", \\\"{x:587,y:692,t:1526923007706};\\\", \\\"{x:586,y:694,t:1526923007722};\\\", \\\"{x:584,y:695,t:1526923007739};\\\", \\\"{x:581,y:696,t:1526923007756};\\\", \\\"{x:580,y:696,t:1526923007772};\\\", \\\"{x:578,y:697,t:1526923007814};\\\", \\\"{x:575,y:698,t:1526923007822};\\\", \\\"{x:569,y:699,t:1526923007839};\\\", \\\"{x:568,y:699,t:1526923007856};\\\", \\\"{x:563,y:699,t:1526923007872};\\\", \\\"{x:561,y:699,t:1526923007889};\\\", \\\"{x:558,y:699,t:1526923007909};\\\", \\\"{x:557,y:699,t:1526923007925};\\\", \\\"{x:556,y:701,t:1526923007939};\\\", \\\"{x:555,y:701,t:1526923007956};\\\", \\\"{x:554,y:701,t:1526923007990};\\\" ] }, { \\\"rt\\\": 35646, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 631069, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"any dots that are placed before 12pm \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9828, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 641900, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 15127, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 658037, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 4028, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 663386, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"YE3VQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":6,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":7,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":8,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":9,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":12,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":13,\"textContent\":\" \"},{\"nodeType\":8,\"id\":14},{\"nodeType\":3,\"id\":15,\"textContent\":\" \"},{\"nodeType\":1,\"id\":16,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":17,\"textContent\":\" \"},{\"nodeType\":1,\"id\":18,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":19,\"textContent\":\" \"},{\"nodeType\":1,\"id\":20,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":1,\"id\":22,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":25,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":26,\"textContent\":\" \"},{\"nodeType\":8,\"id\":27},{\"nodeType\":3,\"id\":28,\"textContent\":\" \"},{\"nodeType\":1,\"id\":29,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":30,\"textContent\":\" \"},{\"nodeType\":1,\"id\":31,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":32,\"textContent\":\" \"},{\"nodeType\":1,\"id\":33,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":34,\"textContent\":\" \"},{\"nodeType\":1,\"id\":35,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":36,\"textContent\":\" \"},{\"nodeType\":1,\"id\":37,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":38,\"textContent\":\" \"},{\"nodeType\":1,\"id\":39,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":40,\"textContent\":\" \"},{\"nodeType\":1,\"id\":41,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":42,\"textContent\":\" \"},{\"nodeType\":8,\"id\":43},{\"nodeType\":3,\"id\":44,\"textContent\":\" \"},{\"nodeType\":1,\"id\":45,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":46,\"textContent\":\" \"},{\"nodeType\":8,\"id\":47},{\"nodeType\":3,\"id\":48,\"textContent\":\" \"},{\"nodeType\":8,\"id\":49},{\"nodeType\":3,\"id\":50,\"textContent\":\" \"},{\"nodeType\":1,\"id\":51,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":1,\"id\":53,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":56,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":57,\"textContent\":\" \"},{\"nodeType\":8,\"id\":58},{\"nodeType\":3,\"id\":59,\"textContent\":\" \"},{\"nodeType\":1,\"id\":60,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":61,\"textContent\":\" \"},{\"nodeType\":1,\"id\":62,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \"},{\"nodeType\":8,\"id\":64},{\"nodeType\":3,\"id\":65,\"textContent\":\" \"},{\"nodeType\":1,\"id\":66,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":67,\"textContent\":\" \"},{\"nodeType\":1,\"id\":68,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":69,\"textContent\":\" \"},{\"nodeType\":1,\"id\":70,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":71,\"textContent\":\" \"},{\"nodeType\":1,\"id\":72,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":73,\"textContent\":\" \"},{\"nodeType\":1,\"id\":74,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\"YE3VQ\"}]},{\"nodeType\":3,\"id\":82,\"textContent\":\" \"},{\"nodeType\":1,\"id\":83,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":84,\"textContent\":\" \"},{\"nodeType\":8,\"id\":85},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"},{\"nodeType\":1,\"id\":87,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":88,\"textContent\":\" \"},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":90,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":92,\"textContent\":\" \"},{\"nodeType\":8,\"id\":93},{\"nodeType\":3,\"id\":94,\"textContent\":\" \"},{\"nodeType\":8,\"id\":95},{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":102,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":107,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":110,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":112,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":115,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":118,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":120,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":123,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":126,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":128,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":131,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":134,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":136,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":139,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":142,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":144,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":147,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":150,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":155,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":158,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":159,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":163,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":166,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":167,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":168,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":171,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":174,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":175,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":179,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":182,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":183,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":184,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":187,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":190,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":191,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":192,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":195,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":198,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":199,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":203,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":206,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":207,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":211,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":214,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":215,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":219,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":220,\"textContent\":\" \"},{\"nodeType\":1,\"id\":221,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":222,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":224,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":225,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":226,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":236,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":239,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":240,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":241,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":244,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":247,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":248,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":249,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":252,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":255,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":256,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":257,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":260,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":263,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":264,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":265,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":268,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":271,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":272,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":273,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":276,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":279,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":280,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":281,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":284,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":287,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":288,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":289,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":292,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":295,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":296,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":297,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":300,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":303,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":305,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":308,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":311,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":312,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":313,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":316,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":319,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":320,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":321,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":324,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":327,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":328,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":329,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":332,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":335,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":336,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":337,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":340,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":343,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":344,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":345,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":348,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":349,\"textContent\":\" \"},{\"nodeType\":1,\"id\":350,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":351,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":354,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":355,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":360,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":365,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":368,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":369,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":370,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":373,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":376,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":378,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":381,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":384,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":386,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":389,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":392,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":394,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":397,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":400,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":402,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":405,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":408,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":410,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":413,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":416,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":418,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":421,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":424,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":426,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":429,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":432,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":434,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":437,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":440,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":442,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":445,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":448,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":449,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":450,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":453,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":456,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":457,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":458,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":461,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":464,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":465,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":466,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":469,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":472,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":473,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":474,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":477,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":478,\"textContent\":\" \"},{\"nodeType\":1,\"id\":479,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":480,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":482,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":483,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":484,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":489,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":492,\"textContent\":\" \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":494,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":497,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":499,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":500,\"textContent\":\" \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":502,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":505,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":507,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":510,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":513,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":515,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":518,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":521,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":523,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":526,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":529,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":530,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":531,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":534,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":537,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":538,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":539,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":542,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":545,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":546,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":547,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":550,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":553,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":554,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":555,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":558,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":561,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":562,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":563,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":566,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":569,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":570,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":571,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":574,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":577,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":578,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":579,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":582,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":585,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":586,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":587,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":590,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":593,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":594,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":595,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":598,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":601,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":602,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":603,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":606,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":607,\"textContent\":\" \"},{\"nodeType\":1,\"id\":608,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":609,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":612,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":613,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":614,\"textContent\":\" \"},{\"nodeType\":1,\"id\":615,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":619,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":620,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":625,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":628,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":629,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":630,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":633,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":636,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":637,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":638,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":641,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":644,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":645,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":646,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":652,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":653,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":654,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":660,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":661,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":662,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":665,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":668,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":669,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":670,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":676,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":677,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":678,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":679,\"textContent\":\" \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":684,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":685,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":686,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":687,\"textContent\":\" \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":692,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":694,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":695,\"textContent\":\" \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":697,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":700,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":702,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":703,\"textContent\":\" \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":705,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":708,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":710,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":711,\"textContent\":\" \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":713,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":716,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":718,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":719,\"textContent\":\" \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":721,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":724,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":726,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":727,\"textContent\":\" \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":729,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":732,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":734,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":735,\"textContent\":\" \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":737,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":738,\"textContent\":\" \"},{\"nodeType\":1,\"id\":739,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":740,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":742,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":743,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":744,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":749,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":754,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":757,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":758,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":759,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":760,\"textContent\":\" \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":762,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":765,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":766,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":767,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":768,\"textContent\":\" \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":770,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":773,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":775,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":776,\"textContent\":\" \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":778,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":781,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":783,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":784,\"textContent\":\" \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":786,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":789,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":791,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":792,\"textContent\":\" \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":794,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":797,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":799,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":800,\"textContent\":\" \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":802,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":805,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":807,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":808,\"textContent\":\" \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":810,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":813,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":815,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":818,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":821,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":823,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":824,\"textContent\":\" \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":826,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":829,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":831,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":832,\"textContent\":\" \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":834,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":837,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":839,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":840,\"textContent\":\" \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":842,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":845,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":847,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":850,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":853,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":854,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":855,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":856,\"textContent\":\" \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":858,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":861,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":862,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":863,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":864,\"textContent\":\" \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":866,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":869,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":870,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":871,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":872,\"textContent\":\" \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":874,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":877,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":878,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":879,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":880,\"textContent\":\" \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":882,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":885,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":886,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":887,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":888,\"textContent\":\" \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":890,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":891,\"textContent\":\" \"},{\"nodeType\":1,\"id\":892,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":893,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":895,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":896,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":897,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":902,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":905,\"textContent\":\" \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":907,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":910,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":912,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":913,\"textContent\":\" \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":915,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":918,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":920,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":921,\"textContent\":\" \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":923,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":926,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":928,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":931,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":934,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":935,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":936,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":937,\"textContent\":\" \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":939,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":942,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":943,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":944,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":945,\"textContent\":\" \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":947,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":950,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":951,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":952,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":953,\"textContent\":\" \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":955,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":958,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":959,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":960,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":961,\"textContent\":\" \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":963,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":966,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":967,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":968,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":971,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":974,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":975,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":976,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":977,\"textContent\":\" \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":979,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":982,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":983,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":984,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":985,\"textContent\":\" \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":987,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":990,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":991,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":992,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":993,\"textContent\":\" \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":995,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":998,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":999,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1000,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1001,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1003,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1006,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1007,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1008,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1009,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1011,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1014,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1015,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1017,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1019,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1022,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1023,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1025,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1027,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1030,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1031,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1033,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1035,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1038,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1039,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1041,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1043,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1045,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1046,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1049,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1050,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1055,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1058,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1060,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1063,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1064,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1065,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1066,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1068,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1071,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1072,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1073,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1074,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1076,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1079,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1080,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1081,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1082,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1084,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1087,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1088,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1089,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1090,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1092,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1095,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1096,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1098,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1100,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1103,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1104,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1108,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1111,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1112,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1116,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1119,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1120,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1124,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1127,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1132,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1135,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1140,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1143,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1148,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1151,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1152,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1156,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1159,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1160,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1164,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1167,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1172,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1175,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1176,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1177,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1180,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1183,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1184,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1185,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1188,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1191,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1192,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1193,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1196,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1198,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1199,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1202,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1203,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1208,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1213,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1216,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1218,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1221,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1224,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1226,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1229,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1232,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1234,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1235,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1237,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1240,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1242,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1243,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1245,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1248,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1249,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1253,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1256,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1257,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1258,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1259,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1261,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1264,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1266,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1267,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1269,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1272,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1274,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1277,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1280,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1281,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1282,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1283,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1285,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1288,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1289,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1290,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1293,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1296,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1297,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1298,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1299,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1301,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1304,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1305,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1306,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1307,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1309,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1312,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1313,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1314,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1315,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1317,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1320,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1321,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1322,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1323,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1325,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1328,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1329,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1330,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1331,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1333,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1336,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1337,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1338,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1339,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1341,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1344,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1345,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1346,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1347,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1349,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1351,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1352,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1355,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1356,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1361,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1364,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1366,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1369,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1370,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1371,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1372,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1374,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1377,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1378,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1379,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1382,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1385,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1386,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1387,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1390,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1393,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1394,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1395,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1398,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1401,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1402,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1403,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1406,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1409,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1410,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1411,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1414,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1417,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1418,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1419,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1422,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1425,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1426,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1427,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1430,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1433,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1434,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1435,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1436,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1438,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1441,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1442,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1443,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1444,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1446,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1449,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1450,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1451,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1452,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1454,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1457,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1458,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1459,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1460,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1462,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1465,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1466,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1467,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1468,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1470,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1473,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1474,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1475,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1476,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1478,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1481,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1482,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1483,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1484,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1486,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1489,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1490,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1491,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1492,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1494,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1497,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1498,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1499,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1500,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1502,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1504,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1505,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1508,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1509,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1514,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1517,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1519,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1522,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1523,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1524,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1525,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1527,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1530,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1531,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1532,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1533,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1535,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1538,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1539,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1540,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1541,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1543,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1546,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1547,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1548,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1549,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1551,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1554,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1555,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1557,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1559,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1562,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1563,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1565,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1567,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1570,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1571,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1572,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1573,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1575,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1578,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1579,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1580,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1581,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1583,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1586,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1587,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1588,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1589,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1591,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1594,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1595,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1596,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1597,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1599,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1602,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1603,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1604,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1607,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1610,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1611,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1612,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1613,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1615,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1618,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1619,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1620,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1626,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1627,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1628,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1634,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1635,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1636,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1639,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1642,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1643,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1644,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1647,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1650,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1651,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1652,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1658,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1661,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1662,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1667,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1675,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1676,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1677,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1680,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1683,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1684,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1685,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1688,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1691,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1692,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1693,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1699,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1700,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1701,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1707,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1708,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1709,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1715,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1717,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1723,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1725,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1728,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1731,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1732,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1733,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1736,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1739,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1740,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1741,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1744,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1747,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1748,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1749,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1752,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1755,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1756,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1757,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1760,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1763,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1764,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1765,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1768,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1771,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1772,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1773,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1776,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1779,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1780,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1781,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1784,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1787,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1788,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1789,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1792,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1795,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1796,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1797,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1800,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1803,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1804,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1805,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1808,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1810,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1811,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1814,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1815,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1820,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1825,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1828,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1829,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1830,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1833,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1836,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1837,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1838,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1841,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1844,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1845,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1846,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1849,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1852,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1853,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1854,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1857,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1860,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1861,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1862,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1865,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1868,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1869,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1870,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1873,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1876,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1877,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1878,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1881,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1884,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1885,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1886,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1889,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1892,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1893,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1894,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1897,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1900,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1901,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1902,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1905,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1908,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1909,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1910,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1913,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1916,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1917,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1918,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1921,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1924,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1925,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1926,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1929,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1932,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1933,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1934,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1937,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1940,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1941,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1942,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1945,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1948,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1949,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1950,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1953,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1956,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1957,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1958,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1961,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1963,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1964,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1967,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1968,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1973,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1978,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1981,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1982,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1983,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1986,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1989,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1990,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1991,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1994,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1997,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1998,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1999,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2002,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2005,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2006,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2007,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2010,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2013,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2014,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2015,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2018,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2021,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2022,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2023,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2026,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2029,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2030,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2031,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2034,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2037,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2038,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2039,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2042,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2045,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2046,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2047,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2050,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2053,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2054,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2055,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2058,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2061,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2062,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2063,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2066,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2069,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2070,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2071,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2074,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2077,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2078,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2079,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2082,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2085,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2086,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2087,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2090,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2093,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2094,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2095,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2098,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2101,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2102,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2103,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2106,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2109,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2110,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2111,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2114,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2116,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2117,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2120,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2121,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2128,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2131,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2133,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2136,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2137,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2138,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2139,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2141,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2144,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2145,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2146,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2147,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2149,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2152,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2153,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2154,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2155,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2157,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2160,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2161,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2162,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2163,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2165,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2168,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2169,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2170,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2173,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2176,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2177,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2178,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2181,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2184,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2185,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2186,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2189,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2192,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2193,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2194,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2197,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2200,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2201,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2202,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2205,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2208,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2209,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2210,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2213,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2216,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2217,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2218,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2221,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2224,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2225,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2226,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2229,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2232,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2233,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2234,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2235,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2237,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2240,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2241,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2242,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2243,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2245,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2248,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2249,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2250,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2251,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2253,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2256,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2257,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2258,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2259,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2261,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2264,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2266,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2267,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2269,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2271,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2272,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2276,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2283,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2287},{\"nodeType\":3,\"id\":2288,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2289},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2293,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2294,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2296,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2297,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2298,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2299,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2300,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2301},{\"nodeType\":3,\"id\":2302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2303,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2309,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2310},{\"nodeType\":3,\"id\":2311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2312,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2314,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2315,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 157, dom: 1096, initialDom: 1178",
  "javascriptErrors": []
}