var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "57362849e3557aaf12f94f78dc13fd69",
  "created": "2018-05-18T11:30:06.5489918-07:00",
  "lastActivity": "2018-05-18T11:31:34.4959918-07:00",
  "pageViews": [
    {
      "id": "051807061a0acb8e4e70275f10291ec7fe72a7ef",
      "startTime": "2018-05-18T11:30:06.5489918-07:00",
      "endTime": "2018-05-18T11:31:34.4959918-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 87947,
      "engagementTime": 74848,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 87947,
  "engagementTime": 74848,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.45",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JDT07",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "73e2c21b7ac590338b50e3eb4cfde2ca",
  "gdpr": false
}