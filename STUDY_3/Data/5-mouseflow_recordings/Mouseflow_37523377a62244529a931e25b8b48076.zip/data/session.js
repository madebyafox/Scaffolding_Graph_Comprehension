var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "37523377a62244529a931e25b8b48076",
  "created": "2018-05-16T11:02:07.6433265-07:00",
  "lastActivity": "2018-05-16T11:03:50.6763265-07:00",
  "pageViews": [
    {
      "id": "05160776a2cfbcb93aaebfe34237006097191f03",
      "startTime": "2018-05-16T11:02:07.6433265-07:00",
      "endTime": "2018-05-16T11:03:50.6763265-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 103033,
      "engagementTime": 69831,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 103033,
  "engagementTime": 69831,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "17b5ecba3c92e555bd9a208f0b0f5d12",
  "gdpr": false
}