var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4fbd0a9277da7f9ef9d4d1d87e785764",
  "created": "2018-05-22T16:10:24.694137-07:00",
  "lastActivity": "2018-05-22T16:10:35.3286009-07:00",
  "pageViews": [
    {
      "id": "052225227cff6bda67d9396ebce735b77e0bd0f3",
      "startTime": "2018-05-22T16:10:25.1301533-07:00",
      "endTime": "2018-05-22T16:10:35.3286009-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 10335,
      "engagementTime": 10335,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10335,
  "engagementTime": 10335,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=0QG7J",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "324c226d05c6cd1bca804c54824f0339",
  "gdpr": false
}