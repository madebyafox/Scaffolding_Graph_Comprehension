var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05290362e6eabea732aa4f69a079e43011e49e97"] = {
  "startTime": "2018-05-29T19:17:03.6324813Z",
  "websitePageUrl": "/16",
  "visitTime": 411118,
  "engagementTime": 197382,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5dce297f0913c659c070f394a36b4cd4",
    "created": "2018-05-29T19:17:03.6324813+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=NVKL3",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "114be84b0848f5a5428805668110257e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5dce297f0913c659c070f394a36b4cd4/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1499,
      "e": 1499,
      "ty": 2,
      "x": 462,
      "y": 654
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 41019,
      "y": 35786,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 449,
      "y": 606
    },
    {
      "t": 1616,
      "e": 1616,
      "ty": 6,
      "x": 447,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 444,
      "y": 585
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 38995,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1799,
      "e": 1799,
      "ty": 2,
      "x": 444,
      "y": 577
    },
    {
      "t": 1856,
      "e": 1856,
      "ty": 3,
      "x": 444,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1857,
      "e": 1857,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 444,
      "y": 576
    },
    {
      "t": 1950,
      "e": 1950,
      "ty": 4,
      "x": 38995,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1951,
      "e": 1951,
      "ty": 5,
      "x": 444,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 38995,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2166,
      "e": 2166,
      "ty": 7,
      "x": 458,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 488,
      "y": 688
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 51698,
      "y": 46367,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 584,
      "y": 903
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 594,
      "y": 923
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 55857,
      "y": 50688,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 594,
      "y": 916
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 55857,
      "y": 49635,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 594,
      "y": 898
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 594,
      "y": 895
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 55857,
      "y": 49137,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 594,
      "y": 894
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 55857,
      "y": 49082,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 10000,
      "e": 8750,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12821,
      "e": 8750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12972,
      "e": 8901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12972,
      "e": 8901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13099,
      "e": 9028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 13123,
      "e": 9052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 13259,
      "e": 9188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13260,
      "e": 9189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13323,
      "e": 9252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 13346,
      "e": 9275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13347,
      "e": 9276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13435,
      "e": 9364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 13532,
      "e": 9461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13532,
      "e": 9461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13546,
      "e": 9475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 13611,
      "e": 9540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13611,
      "e": 9540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13638,
      "e": 9567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13801,
      "e": 9730,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The e"
    },
    {
      "t": 14348,
      "e": 10277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 14348,
      "e": 10277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14459,
      "e": 10388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14459,
      "e": 10388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14466,
      "e": 10395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 14540,
      "e": 10469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14564,
      "e": 10493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14564,
      "e": 10493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14651,
      "e": 10580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 14691,
      "e": 10620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14691,
      "e": 10620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14756,
      "e": 10685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14756,
      "e": 10685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14827,
      "e": 10756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 14899,
      "e": 10828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14996,
      "e": 10925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14996,
      "e": 10925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15099,
      "e": 11028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15731,
      "e": 11660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15733,
      "e": 11662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15867,
      "e": 11796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15955,
      "e": 11884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15956,
      "e": 11885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16075,
      "e": 12004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16099,
      "e": 12028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16099,
      "e": 12028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16196,
      "e": 12125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16828,
      "e": 12757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 16829,
      "e": 12758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16931,
      "e": 12860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 16931,
      "e": 12860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16971,
      "e": 12900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 17059,
      "e": 12988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17108,
      "e": 13037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17108,
      "e": 13037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17196,
      "e": 13125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17372,
      "e": 13301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17372,
      "e": 13301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17532,
      "e": 13461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 17532,
      "e": 13461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17571,
      "e": 13500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 17668,
      "e": 13597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17931,
      "e": 13860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18012,
      "e": 13941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 o"
    },
    {
      "t": 18059,
      "e": 13988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18147,
      "e": 14076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 "
    },
    {
      "t": 18668,
      "e": 14597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18668,
      "e": 14597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18748,
      "e": 14677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18748,
      "e": 14677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18818,
      "e": 14747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 18851,
      "e": 14780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18956,
      "e": 14885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18956,
      "e": 14885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19027,
      "e": 14956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19172,
      "e": 15101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 19174,
      "e": 15103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19267,
      "e": 15196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19267,
      "e": 15196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19363,
      "e": 15292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 19372,
      "e": 15301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19387,
      "e": 15316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19387,
      "e": 15316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19475,
      "e": 15404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19587,
      "e": 15516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19588,
      "e": 15517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19658,
      "e": 15587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19755,
      "e": 15684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 19756,
      "e": 15685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19811,
      "e": 15740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19811,
      "e": 15740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19827,
      "e": 15756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||be"
    },
    {
      "t": 19883,
      "e": 15812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19931,
      "e": 15860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19931,
      "e": 15860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19999,
      "e": 15928,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20019,
      "e": 15948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20115,
      "e": 16044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20117,
      "e": 16046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20187,
      "e": 16116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20283,
      "e": 16212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20283,
      "e": 16212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20387,
      "e": 16316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20460,
      "e": 16389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20461,
      "e": 16390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20538,
      "e": 16467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20619,
      "e": 16548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20619,
      "e": 16548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20691,
      "e": 16620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20692,
      "e": 16621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20747,
      "e": 16676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 20779,
      "e": 16708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20804,
      "e": 16733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20804,
      "e": 16733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20891,
      "e": 16820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 21002,
      "e": 16931,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determ"
    },
    {
      "t": 21011,
      "e": 16940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21012,
      "e": 16941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21106,
      "e": 17035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21107,
      "e": 17036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21178,
      "e": 17107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 21227,
      "e": 17156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21228,
      "e": 17157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21259,
      "e": 17188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21275,
      "e": 17204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21387,
      "e": 17316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21388,
      "e": 17317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21483,
      "e": 17412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21492,
      "e": 17421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21492,
      "e": 17421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21570,
      "e": 17499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30003,
      "e": 22499,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33631,
      "e": 22499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33632,
      "e": 22500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33702,
      "e": 22570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33804,
      "e": 22672,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined n"
    },
    {
      "t": 34239,
      "e": 23107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34351,
      "e": 23219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined "
    },
    {
      "t": 37926,
      "e": 26794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 37927,
      "e": 26795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38015,
      "e": 26883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 38078,
      "e": 26946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38079,
      "e": 26947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38183,
      "e": 27051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 38374,
      "e": 27242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38375,
      "e": 27243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38446,
      "e": 27314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40003,
      "e": 28871,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40927,
      "e": 29795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40927,
      "e": 29795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41071,
      "e": 29939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41847,
      "e": 30715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41982,
      "e": 30850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by "
    },
    {
      "t": 44719,
      "e": 33587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44719,
      "e": 33587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44750,
      "e": 33618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44789,
      "e": 33657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44790,
      "e": 33658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44869,
      "e": 33737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44926,
      "e": 33794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44926,
      "e": 33794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45006,
      "e": 33874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45078,
      "e": 33946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45078,
      "e": 33946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45158,
      "e": 34026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45398,
      "e": 34266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 45399,
      "e": 34267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45495,
      "e": 34363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 45614,
      "e": 34482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45615,
      "e": 34483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45710,
      "e": 34578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45741,
      "e": 34609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45741,
      "e": 34609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45822,
      "e": 34690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45878,
      "e": 34746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45879,
      "e": 34747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45951,
      "e": 34819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45951,
      "e": 34819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45958,
      "e": 34826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 46062,
      "e": 34930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46085,
      "e": 34953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46086,
      "e": 34954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46166,
      "e": 35034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46511,
      "e": 35379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 46511,
      "e": 35379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46623,
      "e": 35491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 47022,
      "e": 35890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47024,
      "e": 35892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47142,
      "e": 36010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47174,
      "e": 36042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47174,
      "e": 36042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47286,
      "e": 36154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 47343,
      "e": 36211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 47343,
      "e": 36211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47430,
      "e": 36298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 47477,
      "e": 36345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47478,
      "e": 36346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47575,
      "e": 36443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47575,
      "e": 36443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47589,
      "e": 36457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||is"
    },
    {
      "t": 47679,
      "e": 36547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47975,
      "e": 36843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48045,
      "e": 36913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y aci"
    },
    {
      "t": 48125,
      "e": 36993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48165,
      "e": 37033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y ac"
    },
    {
      "t": 48215,
      "e": 37083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48293,
      "e": 37161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y a"
    },
    {
      "t": 48342,
      "e": 37210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 48342,
      "e": 37210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48462,
      "e": 37330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 48518,
      "e": 37386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48519,
      "e": 37387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48614,
      "e": 37482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 48631,
      "e": 37499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48631,
      "e": 37499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48725,
      "e": 37593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48991,
      "e": 37859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 48991,
      "e": 37859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49070,
      "e": 37938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 49271,
      "e": 38139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49271,
      "e": 38139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49365,
      "e": 38233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49462,
      "e": 38330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49463,
      "e": 38331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49559,
      "e": 38427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49665,
      "e": 38533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 49666,
      "e": 38534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49750,
      "e": 38618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 49894,
      "e": 38762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49895,
      "e": 38763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49981,
      "e": 38849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49982,
      "e": 38850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50003,
      "e": 38871,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50070,
      "e": 38938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 50085,
      "e": 38953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50094,
      "e": 38962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 50094,
      "e": 38962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50189,
      "e": 39057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 50222,
      "e": 39090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50222,
      "e": 39090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50285,
      "e": 39153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50390,
      "e": 39258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 50391,
      "e": 39259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50445,
      "e": 39313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 50446,
      "e": 39314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50461,
      "e": 39329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 50557,
      "e": 39425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50718,
      "e": 39586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50719,
      "e": 39587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50798,
      "e": 39666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51087,
      "e": 39955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51149,
      "e": 40017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along wi"
    },
    {
      "t": 51270,
      "e": 40138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51270,
      "e": 40138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51358,
      "e": 40226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51375,
      "e": 40243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51375,
      "e": 40243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51446,
      "e": 40314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51574,
      "e": 40442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51576,
      "e": 40444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51629,
      "e": 40497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51661,
      "e": 40529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51661,
      "e": 40529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51734,
      "e": 40602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51782,
      "e": 40650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51783,
      "e": 40651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51861,
      "e": 40729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 51877,
      "e": 40745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51877,
      "e": 40745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51958,
      "e": 40826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51997,
      "e": 40865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51997,
      "e": 40865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52070,
      "e": 40938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52173,
      "e": 41041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 52174,
      "e": 41042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52254,
      "e": 41122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 52358,
      "e": 41226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52359,
      "e": 41227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52422,
      "e": 41290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52567,
      "e": 41435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52568,
      "e": 41436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52645,
      "e": 41513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 52814,
      "e": 41682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52816,
      "e": 41684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52894,
      "e": 41762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53004,
      "e": 41872,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plot"
    },
    {
      "t": 53006,
      "e": 41874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53006,
      "e": 41874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53118,
      "e": 41986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53119,
      "e": 41987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53142,
      "e": 42010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 53214,
      "e": 42082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53318,
      "e": 42186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 53318,
      "e": 42186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53422,
      "e": 42290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 53446,
      "e": 42314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53447,
      "e": 42315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53534,
      "e": 42402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53662,
      "e": 42530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53662,
      "e": 42530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53759,
      "e": 42627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53871,
      "e": 42739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 53871,
      "e": 42739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53981,
      "e": 42849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 54126,
      "e": 42994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54127,
      "e": 42995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54190,
      "e": 43058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54190,
      "e": 43058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54262,
      "e": 43130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 54302,
      "e": 43170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54303,
      "e": 43171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54318,
      "e": 43186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54350,
      "e": 43218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54351,
      "e": 43219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54398,
      "e": 43266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 54454,
      "e": 43322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54623,
      "e": 43491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 54623,
      "e": 43491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54709,
      "e": 43577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 55095,
      "e": 43963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55096,
      "e": 43964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55173,
      "e": 44041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60003,
      "e": 48871,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 87264,
      "e": 49041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 87367,
      "e": 49144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 87367,
      "e": 49144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87473,
      "e": 49250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 87481,
      "e": 49258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87586,
      "e": 49363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 87586,
      "e": 49363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87665,
      "e": 49442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 87697,
      "e": 49474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 87697,
      "e": 49474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87769,
      "e": 49546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 87802,
      "e": 49579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87802,
      "e": 49579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87881,
      "e": 49658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87985,
      "e": 49762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 87986,
      "e": 49763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88065,
      "e": 49842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 88194,
      "e": 49971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 88194,
      "e": 49971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88281,
      "e": 50058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 88417,
      "e": 50194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 88418,
      "e": 50195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88489,
      "e": 50266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 88489,
      "e": 50266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88553,
      "e": 50330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 88577,
      "e": 50354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 88578,
      "e": 50355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88601,
      "e": 50378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 88626,
      "e": 50403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 88626,
      "e": 50403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88657,
      "e": 50434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 88721,
      "e": 50498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 88810,
      "e": 50587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88811,
      "e": 50588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88897,
      "e": 50674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89008,
      "e": 50785,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points "
    },
    {
      "t": 89906,
      "e": 51683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89906,
      "e": 51683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89993,
      "e": 51770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 90017,
      "e": 51794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 90017,
      "e": 51794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90097,
      "e": 51874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 90161,
      "e": 51938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 90162,
      "e": 51939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90274,
      "e": 52051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 90275,
      "e": 52052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90281,
      "e": 52058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 90352,
      "e": 52129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90400,
      "e": 52177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90401,
      "e": 52178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90553,
      "e": 52330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90706,
      "e": 52483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 90707,
      "e": 52484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90824,
      "e": 52601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 90873,
      "e": 52650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 90874,
      "e": 52651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90961,
      "e": 52738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90962,
      "e": 52739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91025,
      "e": 52802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 91074,
      "e": 52851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91089,
      "e": 52866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91091,
      "e": 52868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91207,
      "e": 52984,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are "
    },
    {
      "t": 91225,
      "e": 53002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91498,
      "e": 53275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 91499,
      "e": 53276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91578,
      "e": 53355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 91602,
      "e": 53379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91603,
      "e": 53380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91690,
      "e": 53467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 91761,
      "e": 53538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 91763,
      "e": 53540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91833,
      "e": 53610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 91833,
      "e": 53610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91873,
      "e": 53650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 91929,
      "e": 53706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 92042,
      "e": 53819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 92042,
      "e": 53819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92120,
      "e": 53897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 92258,
      "e": 54035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 92258,
      "e": 54035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92353,
      "e": 54130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 92441,
      "e": 54218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 92441,
      "e": 54218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92546,
      "e": 54323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 92585,
      "e": 54362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 92586,
      "e": 54363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92672,
      "e": 54449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 92720,
      "e": 54497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 92722,
      "e": 54499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92833,
      "e": 54610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93033,
      "e": 54810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93034,
      "e": 54811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93145,
      "e": 54922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 93354,
      "e": 55131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 93354,
      "e": 55131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93425,
      "e": 55202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 93505,
      "e": 55282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 93506,
      "e": 55283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93610,
      "e": 55285,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly abo"
    },
    {
      "t": 93612,
      "e": 55287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 93625,
      "e": 55300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 93625,
      "e": 55300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93704,
      "e": 55379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 93705,
      "e": 55380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93752,
      "e": 55427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ce"
    },
    {
      "t": 93777,
      "e": 55452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93777,
      "e": 55452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93800,
      "e": 55475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93865,
      "e": 55540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94274,
      "e": 55949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94361,
      "e": 56036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly aboce"
    },
    {
      "t": 94417,
      "e": 56092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94545,
      "e": 56220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 94545,
      "e": 56220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94569,
      "e": 56244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly abocv"
    },
    {
      "t": 94617,
      "e": 56292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 94618,
      "e": 56293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94665,
      "e": 56340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 94730,
      "e": 56405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 94898,
      "e": 56573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94953,
      "e": 56628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly abocv"
    },
    {
      "t": 95016,
      "e": 56691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 95080,
      "e": 56755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly aboc"
    },
    {
      "t": 95129,
      "e": 56804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 95201,
      "e": 56876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly abo"
    },
    {
      "t": 95217,
      "e": 56892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 95218,
      "e": 56893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95282,
      "e": 56957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95283,
      "e": 56958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95329,
      "e": 57004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 95369,
      "e": 57044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95506,
      "e": 57181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95506,
      "e": 57181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95608,
      "e": 57182,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above "
    },
    {
      "t": 95608,
      "e": 57182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 97666,
      "e": 59240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 97667,
      "e": 59241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97729,
      "e": 59303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 97769,
      "e": 59343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 97769,
      "e": 59343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97857,
      "e": 59431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 97889,
      "e": 59463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97890,
      "e": 59464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97978,
      "e": 59552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 98009,
      "e": 59583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98010,
      "e": 59584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98137,
      "e": 59711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 98433,
      "e": 60007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 98434,
      "e": 60008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98593,
      "e": 60167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 98625,
      "e": 60199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 98626,
      "e": 60200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98713,
      "e": 60287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 99418,
      "e": 60992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 99418,
      "e": 60992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99424,
      "e": 60998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 99424,
      "e": 60998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99488,
      "e": 61062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 99561,
      "e": 61135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 99561,
      "e": 61135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99593,
      "e": 61167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 99681,
      "e": 61255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100025,
      "e": 61599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 100026,
      "e": 61600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100097,
      "e": 61671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 100208,
      "e": 61782,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12pom "
    },
    {
      "t": 100385,
      "e": 61959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 100449,
      "e": 62023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12pom"
    },
    {
      "t": 100497,
      "e": 62071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 100552,
      "e": 62126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12po"
    },
    {
      "t": 100609,
      "e": 62183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 100673,
      "e": 62247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12p"
    },
    {
      "t": 100810,
      "e": 62248,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12p"
    },
    {
      "t": 100832,
      "e": 62270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 100832,
      "e": 62270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100953,
      "e": 62391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 101097,
      "e": 62535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101098,
      "e": 62536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101113,
      "e": 62551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 101113,
      "e": 62551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101144,
      "e": 62582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| n"
    },
    {
      "t": 101161,
      "e": 62599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 102154,
      "e": 63592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102225,
      "e": 63663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12pm "
    },
    {
      "t": 102289,
      "e": 63727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102353,
      "e": 63791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12pm"
    },
    {
      "t": 102402,
      "e": 63840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102466,
      "e": 63904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12p"
    },
    {
      "t": 102514,
      "e": 63952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 102592,
      "e": 64030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12"
    },
    {
      "t": 102721,
      "e": 64159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 102721,
      "e": 64159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102801,
      "e": 64239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103105,
      "e": 64543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 103107,
      "e": 64545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103201,
      "e": 64639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 103201,
      "e": 64639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103265,
      "e": 64703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 103338,
      "e": 64776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 103465,
      "e": 64903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103465,
      "e": 64903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103585,
      "e": 65023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103850,
      "e": 65288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 103851,
      "e": 65289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103945,
      "e": 65383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 103968,
      "e": 65406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 103969,
      "e": 65407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104081,
      "e": 65519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 104177,
      "e": 65615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 104178,
      "e": 65616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104265,
      "e": 65703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 104280,
      "e": 65718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 104281,
      "e": 65719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104402,
      "e": 65840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 104641,
      "e": 66079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104642,
      "e": 66080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104736,
      "e": 66174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 104946,
      "e": 66175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 104948,
      "e": 66177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105040,
      "e": 66269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 105040,
      "e": 66269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105072,
      "e": 66301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 105113,
      "e": 66342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105202,
      "e": 66431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105203,
      "e": 66432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105264,
      "e": 66493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 105313,
      "e": 66542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 105313,
      "e": 66542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105385,
      "e": 66614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 105401,
      "e": 66630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 105401,
      "e": 66630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105465,
      "e": 66694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 105490,
      "e": 66719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 105490,
      "e": 66719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105561,
      "e": 66790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 105568,
      "e": 66797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 105568,
      "e": 66797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105665,
      "e": 66894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 106098,
      "e": 67327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 106098,
      "e": 67327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106106,
      "e": 67335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 106106,
      "e": 67335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106169,
      "e": 67398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||zx"
    },
    {
      "t": 106176,
      "e": 67405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 106594,
      "e": 67823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 106648,
      "e": 67877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the z"
    },
    {
      "t": 106705,
      "e": 67934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 106777,
      "e": 68006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the "
    },
    {
      "t": 106793,
      "e": 68022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 106793,
      "e": 68022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106898,
      "e": 68127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 107017,
      "e": 68246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 107018,
      "e": 68247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107129,
      "e": 68358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 107321,
      "e": 68550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 107322,
      "e": 68551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107418,
      "e": 68647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 107690,
      "e": 68919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 107692,
      "e": 68921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107808,
      "e": 69037,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x ax"
    },
    {
      "t": 107833,
      "e": 69062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 107857,
      "e": 69086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 107858,
      "e": 69087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107954,
      "e": 69183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 108001,
      "e": 69230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 108002,
      "e": 69231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108049,
      "e": 69278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 108049,
      "e": 69278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108089,
      "e": 69318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 108105,
      "e": 69334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 108210,
      "e": 69335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axids"
    },
    {
      "t": 108553,
      "e": 69678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 108600,
      "e": 69725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axid"
    },
    {
      "t": 108665,
      "e": 69790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 108712,
      "e": 69837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 108712,
      "e": 69837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108721,
      "e": 69846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis"
    },
    {
      "t": 108817,
      "e": 69942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 108953,
      "e": 70078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 108954,
      "e": 70079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109041,
      "e": 70166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 109137,
      "e": 70262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 109137,
      "e": 70262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109241,
      "e": 70366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 109418,
      "e": 70543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 109419,
      "e": 70544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109529,
      "e": 70654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 109529,
      "e": 70654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109584,
      "e": 70709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 109641,
      "e": 70766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 109667,
      "e": 70792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 109668,
      "e": 70793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109761,
      "e": 70886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 109801,
      "e": 70926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 109801,
      "e": 70926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109897,
      "e": 71022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 109937,
      "e": 71062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 109938,
      "e": 71063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110001,
      "e": 71126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 110041,
      "e": 71166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 110041,
      "e": 71166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110137,
      "e": 71262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 110145,
      "e": 71270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 110145,
      "e": 71270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110241,
      "e": 71366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 110297,
      "e": 71422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 110298,
      "e": 71423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110360,
      "e": 71485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 110441,
      "e": 71566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 110441,
      "e": 71566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110505,
      "e": 71630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 110545,
      "e": 71670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 110546,
      "e": 71671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110632,
      "e": 71757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 110697,
      "e": 71822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 110698,
      "e": 71823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110793,
      "e": 71918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 110793,
      "e": 71918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 110794,
      "e": 71919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110881,
      "e": 72006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 110881,
      "e": 72006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110936,
      "e": 72061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 111001,
      "e": 72126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 111056,
      "e": 72181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111057,
      "e": 72182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111121,
      "e": 72246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111153,
      "e": 72278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 111153,
      "e": 72278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111233,
      "e": 72358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 111273,
      "e": 72398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 111274,
      "e": 72399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111297,
      "e": 72422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 111297,
      "e": 72422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111337,
      "e": 72462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 111408,
      "e": 72533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 111433,
      "e": 72558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 111433,
      "e": 72558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111497,
      "e": 72622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 111545,
      "e": 72670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111545,
      "e": 72670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111625,
      "e": 72750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111641,
      "e": 72766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 111643,
      "e": 72767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111729,
      "e": 72853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 111801,
      "e": 72925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 111802,
      "e": 72926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111896,
      "e": 73020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 112025,
      "e": 73149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 112026,
      "e": 73150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112080,
      "e": 73204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 112208,
      "e": 73332,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that ats"
    },
    {
      "t": 112338,
      "e": 73462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 112400,
      "e": 73524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that at"
    },
    {
      "t": 112457,
      "e": 73581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 112513,
      "e": 73637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that a"
    },
    {
      "t": 112554,
      "e": 73678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 112617,
      "e": 73741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 112617,
      "e": 73741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112624,
      "e": 73748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that s"
    },
    {
      "t": 112696,
      "e": 73820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 112761,
      "e": 73885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 112761,
      "e": 73885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112849,
      "e": 73973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 112961,
      "e": 74085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 112962,
      "e": 74086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113048,
      "e": 74172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 113106,
      "e": 74230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 113106,
      "e": 74230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113168,
      "e": 74292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 113377,
      "e": 74501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 113378,
      "e": 74502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113457,
      "e": 74581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 113529,
      "e": 74653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113529,
      "e": 74653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113601,
      "e": 74725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 113657,
      "e": 74781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 113658,
      "e": 74782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113752,
      "e": 74876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 113761,
      "e": 74885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 113761,
      "e": 74885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113873,
      "e": 74997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 113898,
      "e": 74998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113900,
      "e": 75000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113985,
      "e": 75085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 114137,
      "e": 75237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 114138,
      "e": 75238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114225,
      "e": 75325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "51"
    },
    {
      "t": 114225,
      "e": 75325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114288,
      "e": 75388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||13"
    },
    {
      "t": 114353,
      "e": 75453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114753,
      "e": 75853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 114832,
      "e": 75932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 114832,
      "e": 75932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114841,
      "e": 75941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that start at 12"
    },
    {
      "t": 114945,
      "e": 76045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 116897,
      "e": 77997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116898,
      "e": 77998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117001,
      "e": 78101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117130,
      "e": 78230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 117130,
      "e": 78230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117224,
      "e": 78324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 117225,
      "e": 78325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117288,
      "e": 78388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 117353,
      "e": 78453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 117673,
      "e": 78773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 117674,
      "e": 78774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117786,
      "e": 78886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 120006,
      "e": 81106,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 121106,
      "e": 82206,
      "ty": 2,
      "x": 593,
      "y": 875
    },
    {
      "t": 121206,
      "e": 82306,
      "ty": 2,
      "x": 593,
      "y": 792
    },
    {
      "t": 121257,
      "e": 82357,
      "ty": 41,
      "x": 54845,
      "y": 41824,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 121307,
      "e": 82407,
      "ty": 2,
      "x": 574,
      "y": 741
    },
    {
      "t": 121506,
      "e": 82606,
      "ty": 2,
      "x": 572,
      "y": 717
    },
    {
      "t": 121507,
      "e": 82607,
      "ty": 41,
      "x": 53384,
      "y": 39276,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 121607,
      "e": 82707,
      "ty": 2,
      "x": 570,
      "y": 711
    },
    {
      "t": 121757,
      "e": 82857,
      "ty": 41,
      "x": 53159,
      "y": 38944,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 122206,
      "e": 83306,
      "ty": 2,
      "x": 537,
      "y": 706
    },
    {
      "t": 122257,
      "e": 83357,
      "ty": 41,
      "x": 48213,
      "y": 38556,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 122306,
      "e": 83406,
      "ty": 2,
      "x": 500,
      "y": 696
    },
    {
      "t": 122338,
      "e": 83438,
      "ty": 6,
      "x": 454,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 122407,
      "e": 83507,
      "ty": 2,
      "x": 427,
      "y": 677
    },
    {
      "t": 122507,
      "e": 83607,
      "ty": 2,
      "x": 423,
      "y": 671
    },
    {
      "t": 122507,
      "e": 83607,
      "ty": 41,
      "x": 46096,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 122607,
      "e": 83707,
      "ty": 2,
      "x": 431,
      "y": 665
    },
    {
      "t": 122707,
      "e": 83807,
      "ty": 2,
      "x": 438,
      "y": 665
    },
    {
      "t": 122756,
      "e": 83856,
      "ty": 41,
      "x": 61387,
      "y": 21714,
      "ta": "#strategyButton"
    },
    {
      "t": 122787,
      "e": 83887,
      "ty": 7,
      "x": 459,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 122807,
      "e": 83907,
      "ty": 2,
      "x": 462,
      "y": 667
    },
    {
      "t": 122907,
      "e": 84007,
      "ty": 2,
      "x": 478,
      "y": 667
    },
    {
      "t": 123006,
      "e": 84106,
      "ty": 2,
      "x": 479,
      "y": 668
    },
    {
      "t": 123006,
      "e": 84106,
      "ty": 41,
      "x": 42930,
      "y": 36562,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 123107,
      "e": 84207,
      "ty": 2,
      "x": 470,
      "y": 668
    },
    {
      "t": 123206,
      "e": 84306,
      "ty": 2,
      "x": 460,
      "y": 667
    },
    {
      "t": 123235,
      "e": 84335,
      "ty": 6,
      "x": 458,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 123257,
      "e": 84357,
      "ty": 41,
      "x": 64664,
      "y": 21714,
      "ta": "#strategyButton"
    },
    {
      "t": 123306,
      "e": 84406,
      "ty": 2,
      "x": 454,
      "y": 666
    },
    {
      "t": 123406,
      "e": 84506,
      "ty": 2,
      "x": 447,
      "y": 667
    },
    {
      "t": 123507,
      "e": 84607,
      "ty": 2,
      "x": 443,
      "y": 668
    },
    {
      "t": 123507,
      "e": 84607,
      "ty": 41,
      "x": 57018,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 123606,
      "e": 84706,
      "ty": 2,
      "x": 442,
      "y": 669
    },
    {
      "t": 123707,
      "e": 84807,
      "ty": 2,
      "x": 438,
      "y": 672
    },
    {
      "t": 123756,
      "e": 84856,
      "ty": 41,
      "x": 54288,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 123806,
      "e": 84906,
      "ty": 2,
      "x": 437,
      "y": 672
    },
    {
      "t": 123906,
      "e": 85006,
      "ty": 2,
      "x": 434,
      "y": 672
    },
    {
      "t": 123935,
      "e": 85035,
      "ty": 3,
      "x": 434,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 123936,
      "e": 85036,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that start at 12 pm."
    },
    {
      "t": 123937,
      "e": 85037,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123937,
      "e": 85037,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 123996,
      "e": 85096,
      "ty": 4,
      "x": 52103,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 124006,
      "e": 85106,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 124008,
      "e": 85108,
      "ty": 5,
      "x": 434,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 124014,
      "e": 85114,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 124015,
      "e": 85115,
      "ty": 41,
      "x": 14670,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 125015,
      "e": 86115,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 125756,
      "e": 86856,
      "ty": 41,
      "x": 17081,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 125807,
      "e": 86907,
      "ty": 2,
      "x": 658,
      "y": 624
    },
    {
      "t": 125906,
      "e": 87006,
      "ty": 2,
      "x": 820,
      "y": 613
    },
    {
      "t": 126006,
      "e": 87106,
      "ty": 2,
      "x": 843,
      "y": 600
    },
    {
      "t": 126006,
      "e": 87106,
      "ty": 41,
      "x": 7570,
      "y": 11979,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 126106,
      "e": 87206,
      "ty": 2,
      "x": 856,
      "y": 588
    },
    {
      "t": 126207,
      "e": 87307,
      "ty": 6,
      "x": 862,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126208,
      "e": 87308,
      "ty": 2,
      "x": 862,
      "y": 574
    },
    {
      "t": 126257,
      "e": 87357,
      "ty": 41,
      "x": 12328,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126306,
      "e": 87406,
      "ty": 2,
      "x": 866,
      "y": 564
    },
    {
      "t": 126366,
      "e": 87466,
      "ty": 3,
      "x": 866,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126367,
      "e": 87467,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126429,
      "e": 87529,
      "ty": 4,
      "x": 12544,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126429,
      "e": 87529,
      "ty": 5,
      "x": 866,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126506,
      "e": 87606,
      "ty": 41,
      "x": 12544,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126806,
      "e": 87906,
      "ty": 2,
      "x": 866,
      "y": 563
    },
    {
      "t": 126907,
      "e": 88007,
      "ty": 2,
      "x": 872,
      "y": 565
    },
    {
      "t": 127007,
      "e": 88107,
      "ty": 2,
      "x": 879,
      "y": 572
    },
    {
      "t": 127007,
      "e": 88107,
      "ty": 41,
      "x": 15356,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127024,
      "e": 88124,
      "ty": 7,
      "x": 881,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127107,
      "e": 88207,
      "ty": 2,
      "x": 885,
      "y": 588
    },
    {
      "t": 127207,
      "e": 88307,
      "ty": 2,
      "x": 924,
      "y": 646
    },
    {
      "t": 127223,
      "e": 88323,
      "ty": 6,
      "x": 933,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 127257,
      "e": 88357,
      "ty": 41,
      "x": 28117,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 127273,
      "e": 88373,
      "ty": 7,
      "x": 946,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 127290,
      "e": 88390,
      "ty": 6,
      "x": 953,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 127306,
      "e": 88406,
      "ty": 2,
      "x": 953,
      "y": 677
    },
    {
      "t": 127323,
      "e": 88423,
      "ty": 7,
      "x": 1025,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 127407,
      "e": 88507,
      "ty": 2,
      "x": 1268,
      "y": 748
    },
    {
      "t": 127507,
      "e": 88607,
      "ty": 2,
      "x": 1295,
      "y": 750
    },
    {
      "t": 127507,
      "e": 88607,
      "ty": 41,
      "x": 44321,
      "y": 41104,
      "ta": "html > body"
    },
    {
      "t": 127607,
      "e": 88707,
      "ty": 2,
      "x": 1257,
      "y": 758
    },
    {
      "t": 127707,
      "e": 88807,
      "ty": 2,
      "x": 987,
      "y": 780
    },
    {
      "t": 127757,
      "e": 88857,
      "ty": 41,
      "x": 33714,
      "y": 42766,
      "ta": "html > body"
    },
    {
      "t": 127806,
      "e": 88906,
      "ty": 2,
      "x": 986,
      "y": 780
    },
    {
      "t": 127906,
      "e": 89006,
      "ty": 2,
      "x": 983,
      "y": 786
    },
    {
      "t": 128006,
      "e": 89106,
      "ty": 2,
      "x": 982,
      "y": 791
    },
    {
      "t": 128007,
      "e": 89107,
      "ty": 41,
      "x": 33542,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 128106,
      "e": 89206,
      "ty": 2,
      "x": 982,
      "y": 797
    },
    {
      "t": 128206,
      "e": 89306,
      "ty": 2,
      "x": 983,
      "y": 801
    },
    {
      "t": 128257,
      "e": 89357,
      "ty": 41,
      "x": 33576,
      "y": 43930,
      "ta": "html > body"
    },
    {
      "t": 128406,
      "e": 89506,
      "ty": 2,
      "x": 991,
      "y": 803
    },
    {
      "t": 128506,
      "e": 89606,
      "ty": 2,
      "x": 992,
      "y": 804
    },
    {
      "t": 128507,
      "e": 89607,
      "ty": 41,
      "x": 33886,
      "y": 44096,
      "ta": "html > body"
    },
    {
      "t": 129207,
      "e": 90307,
      "ty": 2,
      "x": 992,
      "y": 798
    },
    {
      "t": 129257,
      "e": 90357,
      "ty": 41,
      "x": 33886,
      "y": 43597,
      "ta": "html > body"
    },
    {
      "t": 129307,
      "e": 90407,
      "ty": 2,
      "x": 992,
      "y": 795
    },
    {
      "t": 129406,
      "e": 90506,
      "ty": 2,
      "x": 992,
      "y": 794
    },
    {
      "t": 129507,
      "e": 90607,
      "ty": 41,
      "x": 33886,
      "y": 43542,
      "ta": "html > body"
    },
    {
      "t": 130006,
      "e": 91106,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130207,
      "e": 91307,
      "ty": 2,
      "x": 991,
      "y": 795
    },
    {
      "t": 130257,
      "e": 91357,
      "ty": 41,
      "x": 33852,
      "y": 43597,
      "ta": "html > body"
    },
    {
      "t": 130707,
      "e": 91807,
      "ty": 2,
      "x": 990,
      "y": 796
    },
    {
      "t": 130757,
      "e": 91857,
      "ty": 41,
      "x": 33817,
      "y": 43653,
      "ta": "html > body"
    },
    {
      "t": 131107,
      "e": 92207,
      "ty": 2,
      "x": 987,
      "y": 797
    },
    {
      "t": 131206,
      "e": 92306,
      "ty": 2,
      "x": 983,
      "y": 808
    },
    {
      "t": 131257,
      "e": 92357,
      "ty": 41,
      "x": 33542,
      "y": 44539,
      "ta": "html > body"
    },
    {
      "t": 131307,
      "e": 92407,
      "ty": 2,
      "x": 982,
      "y": 814
    },
    {
      "t": 131407,
      "e": 92507,
      "ty": 2,
      "x": 982,
      "y": 816
    },
    {
      "t": 131507,
      "e": 92607,
      "ty": 2,
      "x": 982,
      "y": 817
    },
    {
      "t": 131507,
      "e": 92607,
      "ty": 41,
      "x": 33542,
      "y": 44816,
      "ta": "html > body"
    },
    {
      "t": 131607,
      "e": 92707,
      "ty": 2,
      "x": 982,
      "y": 819
    },
    {
      "t": 131707,
      "e": 92807,
      "ty": 2,
      "x": 981,
      "y": 827
    },
    {
      "t": 131757,
      "e": 92857,
      "ty": 41,
      "x": 33507,
      "y": 46090,
      "ta": "html > body"
    },
    {
      "t": 131807,
      "e": 92907,
      "ty": 2,
      "x": 981,
      "y": 851
    },
    {
      "t": 131907,
      "e": 93007,
      "ty": 2,
      "x": 981,
      "y": 870
    },
    {
      "t": 132007,
      "e": 93107,
      "ty": 2,
      "x": 981,
      "y": 894
    },
    {
      "t": 132007,
      "e": 93107,
      "ty": 41,
      "x": 33507,
      "y": 49082,
      "ta": "html > body"
    },
    {
      "t": 132107,
      "e": 93207,
      "ty": 2,
      "x": 978,
      "y": 917
    },
    {
      "t": 132207,
      "e": 93307,
      "ty": 2,
      "x": 972,
      "y": 935
    },
    {
      "t": 132257,
      "e": 93357,
      "ty": 41,
      "x": 33197,
      "y": 51353,
      "ta": "html > body"
    },
    {
      "t": 132307,
      "e": 93407,
      "ty": 2,
      "x": 972,
      "y": 936
    },
    {
      "t": 132508,
      "e": 93608,
      "ty": 41,
      "x": 33197,
      "y": 51408,
      "ta": "html > body"
    },
    {
      "t": 140006,
      "e": 98608,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 155565,
      "e": 98608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 155566,
      "e": 98609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 155668,
      "e": 98711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 155692,
      "e": 98735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 155693,
      "e": 98736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 155771,
      "e": 98814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 158509,
      "e": 101552,
      "ty": 2,
      "x": 985,
      "y": 940
    },
    {
      "t": 158509,
      "e": 101552,
      "ty": 41,
      "x": 33645,
      "y": 51630,
      "ta": "html > body"
    },
    {
      "t": 158609,
      "e": 101652,
      "ty": 2,
      "x": 1021,
      "y": 969
    },
    {
      "t": 158759,
      "e": 101802,
      "ty": 41,
      "x": 34885,
      "y": 53236,
      "ta": "html > body"
    },
    {
      "t": 159609,
      "e": 102652,
      "ty": 2,
      "x": 1015,
      "y": 973
    },
    {
      "t": 159760,
      "e": 102803,
      "ty": 41,
      "x": 34678,
      "y": 53458,
      "ta": "html > body"
    },
    {
      "t": 160009,
      "e": 103052,
      "ty": 2,
      "x": 1011,
      "y": 973
    },
    {
      "t": 160009,
      "e": 103052,
      "ty": 41,
      "x": 34541,
      "y": 53458,
      "ta": "html > body"
    },
    {
      "t": 160109,
      "e": 103152,
      "ty": 2,
      "x": 964,
      "y": 848
    },
    {
      "t": 160187,
      "e": 103230,
      "ty": 6,
      "x": 942,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 160203,
      "e": 103246,
      "ty": 7,
      "x": 940,
      "y": 662,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 160204,
      "e": 103247,
      "ty": 6,
      "x": 940,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160210,
      "e": 103253,
      "ty": 2,
      "x": 940,
      "y": 662
    },
    {
      "t": 160236,
      "e": 103279,
      "ty": 7,
      "x": 937,
      "y": 643,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160260,
      "e": 103303,
      "ty": 41,
      "x": 27901,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 160309,
      "e": 103352,
      "ty": 2,
      "x": 937,
      "y": 630
    },
    {
      "t": 160409,
      "e": 103452,
      "ty": 2,
      "x": 940,
      "y": 631
    },
    {
      "t": 160510,
      "e": 103553,
      "ty": 2,
      "x": 952,
      "y": 642
    },
    {
      "t": 160510,
      "e": 103553,
      "ty": 41,
      "x": 31145,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 160610,
      "e": 103653,
      "ty": 2,
      "x": 954,
      "y": 644
    },
    {
      "t": 160657,
      "e": 103700,
      "ty": 6,
      "x": 954,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160709,
      "e": 103752,
      "ty": 2,
      "x": 955,
      "y": 650
    },
    {
      "t": 160760,
      "e": 103803,
      "ty": 41,
      "x": 31794,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160809,
      "e": 103852,
      "ty": 2,
      "x": 954,
      "y": 656
    },
    {
      "t": 160909,
      "e": 103952,
      "ty": 2,
      "x": 954,
      "y": 657
    },
    {
      "t": 160953,
      "e": 103996,
      "ty": 3,
      "x": 954,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160954,
      "e": 103997,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 160954,
      "e": 103997,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160954,
      "e": 103997,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161009,
      "e": 104052,
      "ty": 41,
      "x": 31577,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161015,
      "e": 104058,
      "ty": 4,
      "x": 31577,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161016,
      "e": 104059,
      "ty": 5,
      "x": 954,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161204,
      "e": 104247,
      "ty": 7,
      "x": 1002,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161205,
      "e": 104248,
      "ty": 6,
      "x": 1002,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161209,
      "e": 104252,
      "ty": 2,
      "x": 1002,
      "y": 685
    },
    {
      "t": 161221,
      "e": 104264,
      "ty": 7,
      "x": 1025,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161259,
      "e": 104302,
      "ty": 41,
      "x": 38501,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 161309,
      "e": 104352,
      "ty": 2,
      "x": 1258,
      "y": 933
    },
    {
      "t": 161410,
      "e": 104453,
      "ty": 2,
      "x": 1264,
      "y": 1046
    },
    {
      "t": 161509,
      "e": 104552,
      "ty": 2,
      "x": 1201,
      "y": 1081
    },
    {
      "t": 161509,
      "e": 104552,
      "ty": 41,
      "x": 41084,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 161610,
      "e": 104653,
      "ty": 2,
      "x": 1121,
      "y": 1043
    },
    {
      "t": 161709,
      "e": 104752,
      "ty": 2,
      "x": 1111,
      "y": 1018
    },
    {
      "t": 161759,
      "e": 104802,
      "ty": 41,
      "x": 37984,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 161809,
      "e": 104852,
      "ty": 2,
      "x": 1111,
      "y": 1017
    },
    {
      "t": 170010,
      "e": 109852,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170035,
      "e": 109852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 170228,
      "e": 110045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 170229,
      "e": 110046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170331,
      "e": 110148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 170339,
      "e": 110156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 171636,
      "e": 111453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 171637,
      "e": 111454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171715,
      "e": 111532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 171837,
      "e": 111654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 171837,
      "e": 111654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171915,
      "e": 111732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 171915,
      "e": 111732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171931,
      "e": 111748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 172003,
      "e": 111820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 172003,
      "e": 111820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172043,
      "e": 111860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 172075,
      "e": 111892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 172188,
      "e": 112005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 172189,
      "e": 112006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172260,
      "e": 112077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 172291,
      "e": 112108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 172291,
      "e": 112108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172379,
      "e": 112196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 172387,
      "e": 112204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 172476,
      "e": 112293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 172477,
      "e": 112294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172515,
      "e": 112332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 172580,
      "e": 112397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 172724,
      "e": 112541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 172724,
      "e": 112541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172836,
      "e": 112653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 172924,
      "e": 112741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 172924,
      "e": 112741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173019,
      "e": 112836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 173083,
      "e": 112900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 173084,
      "e": 112901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173210,
      "e": 113027,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stat"
    },
    {
      "t": 173324,
      "e": 113141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 173324,
      "e": 113141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173492,
      "e": 113309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||te"
    },
    {
      "t": 173515,
      "e": 113332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 173515,
      "e": 113332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173563,
      "e": 113380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 173659,
      "e": 113476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 173723,
      "e": 113540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 173724,
      "e": 113541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173811,
      "e": 113628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 173956,
      "e": 113773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 173957,
      "e": 113774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174068,
      "e": 113885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 174069,
      "e": 113886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174075,
      "e": 113892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||of"
    },
    {
      "t": 174171,
      "e": 113988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 174179,
      "e": 113996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 174179,
      "e": 113996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174252,
      "e": 114069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 174276,
      "e": 114093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 174348,
      "e": 114165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 174348,
      "e": 114165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174395,
      "e": 114212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 174451,
      "e": 114268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 174491,
      "e": 114308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 174491,
      "e": 114308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174580,
      "e": 114397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 174628,
      "e": 114445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 174629,
      "e": 114446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174723,
      "e": 114540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 174724,
      "e": 114541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174779,
      "e": 114596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 174827,
      "e": 114644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 174859,
      "e": 114676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 174859,
      "e": 114676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 174972,
      "e": 114789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 174996,
      "e": 114813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 174996,
      "e": 114813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 175075,
      "e": 114892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 175076,
      "e": 114893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 175139,
      "e": 114956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ca"
    },
    {
      "t": 175179,
      "e": 114996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 176209,
      "e": 116026,
      "ty": 2,
      "x": 1103,
      "y": 925
    },
    {
      "t": 176259,
      "e": 116076,
      "ty": 41,
      "x": 37364,
      "y": 48915,
      "ta": "html > body"
    },
    {
      "t": 176309,
      "e": 116126,
      "ty": 2,
      "x": 1086,
      "y": 873
    },
    {
      "t": 176409,
      "e": 116226,
      "ty": 2,
      "x": 1057,
      "y": 828
    },
    {
      "t": 176509,
      "e": 116326,
      "ty": 2,
      "x": 1021,
      "y": 777
    },
    {
      "t": 176509,
      "e": 116326,
      "ty": 41,
      "x": 34885,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 176609,
      "e": 116426,
      "ty": 2,
      "x": 999,
      "y": 736
    },
    {
      "t": 176635,
      "e": 116452,
      "ty": 6,
      "x": 971,
      "y": 703,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 176709,
      "e": 116526,
      "ty": 2,
      "x": 949,
      "y": 686
    },
    {
      "t": 176759,
      "e": 116576,
      "ty": 41,
      "x": 27355,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 177509,
      "e": 117326,
      "ty": 2,
      "x": 948,
      "y": 686
    },
    {
      "t": 177509,
      "e": 117326,
      "ty": 41,
      "x": 26840,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 177709,
      "e": 117526,
      "ty": 2,
      "x": 948,
      "y": 687
    },
    {
      "t": 177759,
      "e": 117576,
      "ty": 41,
      "x": 26840,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 177809,
      "e": 117626,
      "ty": 2,
      "x": 948,
      "y": 688
    },
    {
      "t": 178009,
      "e": 117826,
      "ty": 41,
      "x": 26840,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178109,
      "e": 117926,
      "ty": 2,
      "x": 949,
      "y": 689
    },
    {
      "t": 178209,
      "e": 118026,
      "ty": 2,
      "x": 956,
      "y": 691
    },
    {
      "t": 178260,
      "e": 118077,
      "ty": 41,
      "x": 32509,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178309,
      "e": 118126,
      "ty": 2,
      "x": 961,
      "y": 691
    },
    {
      "t": 178409,
      "e": 118226,
      "ty": 2,
      "x": 962,
      "y": 691
    },
    {
      "t": 178509,
      "e": 118326,
      "ty": 41,
      "x": 34055,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178777,
      "e": 118594,
      "ty": 3,
      "x": 962,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178778,
      "e": 118595,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 178778,
      "e": 118595,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 178778,
      "e": 118595,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178831,
      "e": 118648,
      "ty": 4,
      "x": 34055,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178831,
      "e": 118648,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178832,
      "e": 118649,
      "ty": 5,
      "x": 962,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 178833,
      "e": 118650,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 179210,
      "e": 119027,
      "ty": 2,
      "x": 1001,
      "y": 736
    },
    {
      "t": 179259,
      "e": 119076,
      "ty": 41,
      "x": 35780,
      "y": 42766,
      "ta": "html > body"
    },
    {
      "t": 179309,
      "e": 119126,
      "ty": 2,
      "x": 1102,
      "y": 808
    },
    {
      "t": 179409,
      "e": 119226,
      "ty": 2,
      "x": 1135,
      "y": 824
    },
    {
      "t": 179509,
      "e": 119326,
      "ty": 41,
      "x": 38811,
      "y": 45204,
      "ta": "html > body"
    },
    {
      "t": 179846,
      "e": 119663,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 180009,
      "e": 119826,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180760,
      "e": 120577,
      "ty": 41,
      "x": 38673,
      "y": 45204,
      "ta": "html > body"
    },
    {
      "t": 180810,
      "e": 120627,
      "ty": 2,
      "x": 1110,
      "y": 745
    },
    {
      "t": 180909,
      "e": 120726,
      "ty": 2,
      "x": 1153,
      "y": 579
    },
    {
      "t": 181010,
      "e": 120827,
      "ty": 2,
      "x": 1163,
      "y": 489
    },
    {
      "t": 181010,
      "e": 120827,
      "ty": 41,
      "x": 39775,
      "y": 26646,
      "ta": "html > body"
    },
    {
      "t": 181109,
      "e": 120926,
      "ty": 2,
      "x": 1112,
      "y": 388
    },
    {
      "t": 181209,
      "e": 121026,
      "ty": 2,
      "x": 1041,
      "y": 340
    },
    {
      "t": 181260,
      "e": 121077,
      "ty": 41,
      "x": 42143,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 181309,
      "e": 121126,
      "ty": 2,
      "x": 960,
      "y": 310
    },
    {
      "t": 181410,
      "e": 121227,
      "ty": 2,
      "x": 917,
      "y": 281
    },
    {
      "t": 181509,
      "e": 121326,
      "ty": 2,
      "x": 905,
      "y": 269
    },
    {
      "t": 181510,
      "e": 121327,
      "ty": 41,
      "x": 63654,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 181609,
      "e": 121426,
      "ty": 2,
      "x": 887,
      "y": 258
    },
    {
      "t": 181709,
      "e": 121526,
      "ty": 2,
      "x": 854,
      "y": 247
    },
    {
      "t": 181759,
      "e": 121576,
      "ty": 41,
      "x": 21763,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 181809,
      "e": 121626,
      "ty": 2,
      "x": 842,
      "y": 242
    },
    {
      "t": 181871,
      "e": 121688,
      "ty": 6,
      "x": 838,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 181909,
      "e": 121726,
      "ty": 2,
      "x": 836,
      "y": 237
    },
    {
      "t": 182009,
      "e": 121826,
      "ty": 2,
      "x": 831,
      "y": 235
    },
    {
      "t": 182010,
      "e": 121827,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182033,
      "e": 121850,
      "ty": 3,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182034,
      "e": 121851,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182095,
      "e": 121912,
      "ty": 4,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182095,
      "e": 121912,
      "ty": 5,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182095,
      "e": 121912,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 182259,
      "e": 122076,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182288,
      "e": 122105,
      "ty": 7,
      "x": 828,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 182310,
      "e": 122127,
      "ty": 2,
      "x": 828,
      "y": 251
    },
    {
      "t": 182338,
      "e": 122155,
      "ty": 6,
      "x": 828,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 182355,
      "e": 122172,
      "ty": 7,
      "x": 830,
      "y": 277,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 182371,
      "e": 122188,
      "ty": 6,
      "x": 834,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 182387,
      "e": 122204,
      "ty": 7,
      "x": 840,
      "y": 303,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 182409,
      "e": 122226,
      "ty": 2,
      "x": 848,
      "y": 318
    },
    {
      "t": 182510,
      "e": 122327,
      "ty": 2,
      "x": 944,
      "y": 404
    },
    {
      "t": 182510,
      "e": 122327,
      "ty": 41,
      "x": 29090,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 182610,
      "e": 122427,
      "ty": 2,
      "x": 979,
      "y": 423
    },
    {
      "t": 182710,
      "e": 122527,
      "ty": 2,
      "x": 982,
      "y": 427
    },
    {
      "t": 182760,
      "e": 122577,
      "ty": 41,
      "x": 38583,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 182810,
      "e": 122627,
      "ty": 2,
      "x": 984,
      "y": 435
    },
    {
      "t": 182910,
      "e": 122727,
      "ty": 2,
      "x": 986,
      "y": 437
    },
    {
      "t": 183010,
      "e": 122827,
      "ty": 41,
      "x": 39058,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 183109,
      "e": 122926,
      "ty": 2,
      "x": 984,
      "y": 440
    },
    {
      "t": 183209,
      "e": 123026,
      "ty": 2,
      "x": 972,
      "y": 435
    },
    {
      "t": 183260,
      "e": 123077,
      "ty": 41,
      "x": 32650,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 183310,
      "e": 123127,
      "ty": 2,
      "x": 955,
      "y": 412
    },
    {
      "t": 183410,
      "e": 123227,
      "ty": 2,
      "x": 949,
      "y": 391
    },
    {
      "t": 183510,
      "e": 123327,
      "ty": 2,
      "x": 949,
      "y": 378
    },
    {
      "t": 183510,
      "e": 123327,
      "ty": 41,
      "x": 30277,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 183610,
      "e": 123427,
      "ty": 2,
      "x": 959,
      "y": 374
    },
    {
      "t": 183710,
      "e": 123527,
      "ty": 2,
      "x": 997,
      "y": 379
    },
    {
      "t": 183760,
      "e": 123577,
      "ty": 41,
      "x": 43330,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 183809,
      "e": 123626,
      "ty": 2,
      "x": 1004,
      "y": 388
    },
    {
      "t": 183909,
      "e": 123726,
      "ty": 2,
      "x": 947,
      "y": 421
    },
    {
      "t": 184010,
      "e": 123827,
      "ty": 2,
      "x": 924,
      "y": 437
    },
    {
      "t": 184010,
      "e": 123827,
      "ty": 41,
      "x": 24344,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 184110,
      "e": 123927,
      "ty": 2,
      "x": 923,
      "y": 455
    },
    {
      "t": 184209,
      "e": 124026,
      "ty": 2,
      "x": 935,
      "y": 468
    },
    {
      "t": 184259,
      "e": 124076,
      "ty": 41,
      "x": 28853,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 184309,
      "e": 124126,
      "ty": 2,
      "x": 949,
      "y": 478
    },
    {
      "t": 184410,
      "e": 124227,
      "ty": 2,
      "x": 955,
      "y": 485
    },
    {
      "t": 184510,
      "e": 124327,
      "ty": 2,
      "x": 958,
      "y": 489
    },
    {
      "t": 184511,
      "e": 124328,
      "ty": 41,
      "x": 32413,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 184609,
      "e": 124426,
      "ty": 2,
      "x": 958,
      "y": 490
    },
    {
      "t": 184760,
      "e": 124577,
      "ty": 41,
      "x": 32413,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 184909,
      "e": 124726,
      "ty": 2,
      "x": 957,
      "y": 489
    },
    {
      "t": 185009,
      "e": 124826,
      "ty": 2,
      "x": 953,
      "y": 477
    },
    {
      "t": 185009,
      "e": 124826,
      "ty": 41,
      "x": 31226,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 185109,
      "e": 124926,
      "ty": 2,
      "x": 953,
      "y": 472
    },
    {
      "t": 185210,
      "e": 125027,
      "ty": 2,
      "x": 953,
      "y": 471
    },
    {
      "t": 185260,
      "e": 125077,
      "ty": 41,
      "x": 31226,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 186709,
      "e": 126526,
      "ty": 2,
      "x": 952,
      "y": 470
    },
    {
      "t": 186760,
      "e": 126577,
      "ty": 41,
      "x": 30752,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 186809,
      "e": 126626,
      "ty": 2,
      "x": 950,
      "y": 470
    },
    {
      "t": 186909,
      "e": 126726,
      "ty": 2,
      "x": 889,
      "y": 455
    },
    {
      "t": 187010,
      "e": 126827,
      "ty": 2,
      "x": 867,
      "y": 452
    },
    {
      "t": 187010,
      "e": 126827,
      "ty": 41,
      "x": 36405,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 187109,
      "e": 126926,
      "ty": 2,
      "x": 840,
      "y": 448
    },
    {
      "t": 187125,
      "e": 126942,
      "ty": 6,
      "x": 839,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187210,
      "e": 127027,
      "ty": 2,
      "x": 835,
      "y": 445
    },
    {
      "t": 187262,
      "e": 127079,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187310,
      "e": 127127,
      "ty": 2,
      "x": 832,
      "y": 443
    },
    {
      "t": 187328,
      "e": 127145,
      "ty": 3,
      "x": 832,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187329,
      "e": 127146,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 187330,
      "e": 127147,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187407,
      "e": 127224,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187408,
      "e": 127225,
      "ty": 5,
      "x": 832,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187408,
      "e": 127225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 187593,
      "e": 127410,
      "ty": 7,
      "x": 849,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 187611,
      "e": 127428,
      "ty": 2,
      "x": 905,
      "y": 450
    },
    {
      "t": 187710,
      "e": 127527,
      "ty": 2,
      "x": 1167,
      "y": 487
    },
    {
      "t": 187760,
      "e": 127577,
      "ty": 41,
      "x": 41772,
      "y": 27144,
      "ta": "html > body"
    },
    {
      "t": 187809,
      "e": 127626,
      "ty": 2,
      "x": 1226,
      "y": 501
    },
    {
      "t": 187910,
      "e": 127727,
      "ty": 2,
      "x": 1233,
      "y": 519
    },
    {
      "t": 188009,
      "e": 127826,
      "ty": 2,
      "x": 1233,
      "y": 535
    },
    {
      "t": 188010,
      "e": 127827,
      "ty": 41,
      "x": 42186,
      "y": 29194,
      "ta": "html > body"
    },
    {
      "t": 188109,
      "e": 127926,
      "ty": 2,
      "x": 1231,
      "y": 564
    },
    {
      "t": 188210,
      "e": 128027,
      "ty": 2,
      "x": 1213,
      "y": 607
    },
    {
      "t": 188260,
      "e": 128077,
      "ty": 41,
      "x": 41187,
      "y": 33903,
      "ta": "html > body"
    },
    {
      "t": 188310,
      "e": 128127,
      "ty": 2,
      "x": 1194,
      "y": 635
    },
    {
      "t": 188410,
      "e": 128227,
      "ty": 2,
      "x": 1178,
      "y": 657
    },
    {
      "t": 188509,
      "e": 128326,
      "ty": 2,
      "x": 1167,
      "y": 679
    },
    {
      "t": 188510,
      "e": 128327,
      "ty": 41,
      "x": 39913,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 188609,
      "e": 128426,
      "ty": 2,
      "x": 1144,
      "y": 711
    },
    {
      "t": 188710,
      "e": 128527,
      "ty": 2,
      "x": 1138,
      "y": 723
    },
    {
      "t": 188760,
      "e": 128577,
      "ty": 41,
      "x": 38914,
      "y": 39609,
      "ta": "html > body"
    },
    {
      "t": 189260,
      "e": 129077,
      "ty": 41,
      "x": 38914,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 189310,
      "e": 129127,
      "ty": 2,
      "x": 1138,
      "y": 726
    },
    {
      "t": 189510,
      "e": 129327,
      "ty": 2,
      "x": 1138,
      "y": 727
    },
    {
      "t": 189510,
      "e": 129327,
      "ty": 41,
      "x": 38914,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 189610,
      "e": 129427,
      "ty": 2,
      "x": 1138,
      "y": 729
    },
    {
      "t": 189710,
      "e": 129527,
      "ty": 2,
      "x": 1138,
      "y": 731
    },
    {
      "t": 189760,
      "e": 129577,
      "ty": 41,
      "x": 38914,
      "y": 40052,
      "ta": "html > body"
    },
    {
      "t": 189809,
      "e": 129626,
      "ty": 2,
      "x": 1138,
      "y": 732
    },
    {
      "t": 189910,
      "e": 129727,
      "ty": 2,
      "x": 1137,
      "y": 734
    },
    {
      "t": 190010,
      "e": 129827,
      "ty": 2,
      "x": 1137,
      "y": 735
    },
    {
      "t": 190010,
      "e": 129827,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 190012,
      "e": 129829,
      "ty": 41,
      "x": 38880,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 190110,
      "e": 129927,
      "ty": 2,
      "x": 1136,
      "y": 739
    },
    {
      "t": 190209,
      "e": 130026,
      "ty": 2,
      "x": 1134,
      "y": 744
    },
    {
      "t": 190260,
      "e": 130077,
      "ty": 41,
      "x": 38776,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 190310,
      "e": 130127,
      "ty": 2,
      "x": 1134,
      "y": 748
    },
    {
      "t": 190409,
      "e": 130226,
      "ty": 2,
      "x": 1134,
      "y": 749
    },
    {
      "t": 190509,
      "e": 130326,
      "ty": 2,
      "x": 1133,
      "y": 750
    },
    {
      "t": 190510,
      "e": 130327,
      "ty": 41,
      "x": 38742,
      "y": 41104,
      "ta": "html > body"
    },
    {
      "t": 190610,
      "e": 130427,
      "ty": 2,
      "x": 1133,
      "y": 752
    },
    {
      "t": 190710,
      "e": 130527,
      "ty": 2,
      "x": 1133,
      "y": 754
    },
    {
      "t": 190760,
      "e": 130577,
      "ty": 41,
      "x": 38708,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 190809,
      "e": 130626,
      "ty": 2,
      "x": 1132,
      "y": 754
    },
    {
      "t": 191110,
      "e": 130927,
      "ty": 2,
      "x": 1130,
      "y": 761
    },
    {
      "t": 191210,
      "e": 131027,
      "ty": 2,
      "x": 1129,
      "y": 763
    },
    {
      "t": 191260,
      "e": 131077,
      "ty": 41,
      "x": 38604,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 191410,
      "e": 131227,
      "ty": 2,
      "x": 1127,
      "y": 772
    },
    {
      "t": 191509,
      "e": 131326,
      "ty": 2,
      "x": 1127,
      "y": 777
    },
    {
      "t": 191511,
      "e": 131328,
      "ty": 41,
      "x": 38535,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 191610,
      "e": 131427,
      "ty": 2,
      "x": 1127,
      "y": 778
    },
    {
      "t": 191760,
      "e": 131577,
      "ty": 41,
      "x": 38535,
      "y": 42655,
      "ta": "html > body"
    },
    {
      "t": 191910,
      "e": 131727,
      "ty": 2,
      "x": 1124,
      "y": 785
    },
    {
      "t": 192009,
      "e": 131826,
      "ty": 2,
      "x": 1117,
      "y": 793
    },
    {
      "t": 192011,
      "e": 131828,
      "ty": 41,
      "x": 38191,
      "y": 43486,
      "ta": "html > body"
    },
    {
      "t": 192110,
      "e": 131927,
      "ty": 2,
      "x": 1107,
      "y": 808
    },
    {
      "t": 192210,
      "e": 132027,
      "ty": 2,
      "x": 1104,
      "y": 812
    },
    {
      "t": 192260,
      "e": 132077,
      "ty": 41,
      "x": 37674,
      "y": 44650,
      "ta": "html > body"
    },
    {
      "t": 192310,
      "e": 132127,
      "ty": 2,
      "x": 1098,
      "y": 817
    },
    {
      "t": 192410,
      "e": 132227,
      "ty": 2,
      "x": 1078,
      "y": 825
    },
    {
      "t": 192510,
      "e": 132327,
      "ty": 2,
      "x": 1020,
      "y": 844
    },
    {
      "t": 192510,
      "e": 132327,
      "ty": 41,
      "x": 47127,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 192610,
      "e": 132427,
      "ty": 2,
      "x": 1005,
      "y": 847
    },
    {
      "t": 192709,
      "e": 132526,
      "ty": 2,
      "x": 998,
      "y": 849
    },
    {
      "t": 192760,
      "e": 132577,
      "ty": 41,
      "x": 41431,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 192810,
      "e": 132627,
      "ty": 2,
      "x": 994,
      "y": 849
    },
    {
      "t": 193009,
      "e": 132826,
      "ty": 41,
      "x": 40957,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 193508,
      "e": 133325,
      "ty": 2,
      "x": 995,
      "y": 836
    },
    {
      "t": 193509,
      "e": 133326,
      "ty": 41,
      "x": 41194,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 193609,
      "e": 133426,
      "ty": 2,
      "x": 995,
      "y": 824
    },
    {
      "t": 193759,
      "e": 133576,
      "ty": 41,
      "x": 41194,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 194909,
      "e": 134726,
      "ty": 2,
      "x": 995,
      "y": 825
    },
    {
      "t": 195009,
      "e": 134826,
      "ty": 2,
      "x": 994,
      "y": 831
    },
    {
      "t": 195010,
      "e": 134827,
      "ty": 41,
      "x": 40957,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 195409,
      "e": 135226,
      "ty": 2,
      "x": 985,
      "y": 857
    },
    {
      "t": 195509,
      "e": 135326,
      "ty": 2,
      "x": 978,
      "y": 885
    },
    {
      "t": 195510,
      "e": 135327,
      "ty": 41,
      "x": 37159,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 195609,
      "e": 135426,
      "ty": 2,
      "x": 967,
      "y": 924
    },
    {
      "t": 195709,
      "e": 135526,
      "ty": 2,
      "x": 938,
      "y": 953
    },
    {
      "t": 195759,
      "e": 135576,
      "ty": 41,
      "x": 21971,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 195809,
      "e": 135626,
      "ty": 2,
      "x": 877,
      "y": 947
    },
    {
      "t": 195909,
      "e": 135726,
      "ty": 2,
      "x": 843,
      "y": 940
    },
    {
      "t": 195945,
      "e": 135762,
      "ty": 6,
      "x": 839,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196009,
      "e": 135826,
      "ty": 2,
      "x": 835,
      "y": 938
    },
    {
      "t": 196009,
      "e": 135826,
      "ty": 41,
      "x": 43243,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196109,
      "e": 135926,
      "ty": 2,
      "x": 833,
      "y": 937
    },
    {
      "t": 196129,
      "e": 135946,
      "ty": 3,
      "x": 833,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196130,
      "e": 135947,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 196130,
      "e": 135947,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196191,
      "e": 136008,
      "ty": 4,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196191,
      "e": 136008,
      "ty": 5,
      "x": 833,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196191,
      "e": 136008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 196259,
      "e": 136076,
      "ty": 41,
      "x": 33161,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196312,
      "e": 136129,
      "ty": 7,
      "x": 843,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 196409,
      "e": 136226,
      "ty": 2,
      "x": 1104,
      "y": 898
    },
    {
      "t": 196509,
      "e": 136326,
      "ty": 2,
      "x": 1118,
      "y": 895
    },
    {
      "t": 196509,
      "e": 136326,
      "ty": 41,
      "x": 38225,
      "y": 49137,
      "ta": "html > body"
    },
    {
      "t": 197209,
      "e": 137026,
      "ty": 2,
      "x": 1119,
      "y": 896
    },
    {
      "t": 197259,
      "e": 137076,
      "ty": 41,
      "x": 57569,
      "y": 20668,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 197309,
      "e": 137126,
      "ty": 2,
      "x": 855,
      "y": 917
    },
    {
      "t": 197409,
      "e": 137226,
      "ty": 2,
      "x": 724,
      "y": 917
    },
    {
      "t": 197509,
      "e": 137326,
      "ty": 2,
      "x": 721,
      "y": 917
    },
    {
      "t": 197509,
      "e": 137326,
      "ty": 41,
      "x": 24554,
      "y": 50356,
      "ta": "html > body"
    },
    {
      "t": 197609,
      "e": 137426,
      "ty": 2,
      "x": 720,
      "y": 917
    },
    {
      "t": 197759,
      "e": 137576,
      "ty": 41,
      "x": 24519,
      "y": 50356,
      "ta": "html > body"
    },
    {
      "t": 200009,
      "e": 139826,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 202760,
      "e": 142576,
      "ty": 41,
      "x": 24519,
      "y": 50411,
      "ta": "html > body"
    },
    {
      "t": 202809,
      "e": 142625,
      "ty": 2,
      "x": 720,
      "y": 918
    },
    {
      "t": 203409,
      "e": 143225,
      "ty": 2,
      "x": 720,
      "y": 919
    },
    {
      "t": 203510,
      "e": 143326,
      "ty": 41,
      "x": 24519,
      "y": 50466,
      "ta": "html > body"
    },
    {
      "t": 206710,
      "e": 146526,
      "ty": 2,
      "x": 724,
      "y": 932
    },
    {
      "t": 206760,
      "e": 146576,
      "ty": 41,
      "x": 24657,
      "y": 51242,
      "ta": "html > body"
    },
    {
      "t": 206809,
      "e": 146625,
      "ty": 2,
      "x": 724,
      "y": 933
    },
    {
      "t": 207610,
      "e": 147426,
      "ty": 2,
      "x": 725,
      "y": 934
    },
    {
      "t": 207763,
      "e": 147579,
      "ty": 41,
      "x": 24691,
      "y": 51297,
      "ta": "html > body"
    },
    {
      "t": 208013,
      "e": 147829,
      "ty": 2,
      "x": 728,
      "y": 934
    },
    {
      "t": 208014,
      "e": 147830,
      "ty": 41,
      "x": 24795,
      "y": 51297,
      "ta": "html > body"
    },
    {
      "t": 208112,
      "e": 147928,
      "ty": 2,
      "x": 730,
      "y": 934
    },
    {
      "t": 208263,
      "e": 148079,
      "ty": 41,
      "x": 24864,
      "y": 51297,
      "ta": "html > body"
    },
    {
      "t": 208413,
      "e": 148229,
      "ty": 2,
      "x": 730,
      "y": 935
    },
    {
      "t": 208513,
      "e": 148329,
      "ty": 2,
      "x": 731,
      "y": 935
    },
    {
      "t": 208513,
      "e": 148329,
      "ty": 41,
      "x": 24898,
      "y": 51353,
      "ta": "html > body"
    },
    {
      "t": 208612,
      "e": 148428,
      "ty": 2,
      "x": 731,
      "y": 936
    },
    {
      "t": 208713,
      "e": 148529,
      "ty": 2,
      "x": 733,
      "y": 936
    },
    {
      "t": 208763,
      "e": 148579,
      "ty": 41,
      "x": 25001,
      "y": 51408,
      "ta": "html > body"
    },
    {
      "t": 208812,
      "e": 148628,
      "ty": 2,
      "x": 736,
      "y": 938
    },
    {
      "t": 208913,
      "e": 148729,
      "ty": 2,
      "x": 738,
      "y": 941
    },
    {
      "t": 209013,
      "e": 148829,
      "ty": 2,
      "x": 740,
      "y": 943
    },
    {
      "t": 209013,
      "e": 148829,
      "ty": 41,
      "x": 25208,
      "y": 51796,
      "ta": "html > body"
    },
    {
      "t": 209112,
      "e": 148928,
      "ty": 2,
      "x": 741,
      "y": 948
    },
    {
      "t": 209213,
      "e": 149029,
      "ty": 2,
      "x": 743,
      "y": 952
    },
    {
      "t": 209263,
      "e": 149079,
      "ty": 41,
      "x": 25311,
      "y": 52350,
      "ta": "html > body"
    },
    {
      "t": 209313,
      "e": 149129,
      "ty": 2,
      "x": 743,
      "y": 954
    },
    {
      "t": 209513,
      "e": 149329,
      "ty": 41,
      "x": 25311,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 209613,
      "e": 149429,
      "ty": 2,
      "x": 744,
      "y": 954
    },
    {
      "t": 209763,
      "e": 149579,
      "ty": 41,
      "x": 25346,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 210013,
      "e": 149829,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 211712,
      "e": 151528,
      "ty": 2,
      "x": 745,
      "y": 955
    },
    {
      "t": 211763,
      "e": 151579,
      "ty": 41,
      "x": 25483,
      "y": 52461,
      "ta": "html > body"
    },
    {
      "t": 211813,
      "e": 151629,
      "ty": 2,
      "x": 749,
      "y": 955
    },
    {
      "t": 211913,
      "e": 151729,
      "ty": 2,
      "x": 751,
      "y": 955
    },
    {
      "t": 212014,
      "e": 151830,
      "ty": 41,
      "x": 25587,
      "y": 52461,
      "ta": "html > body"
    },
    {
      "t": 213012,
      "e": 152828,
      "ty": 2,
      "x": 755,
      "y": 958
    },
    {
      "t": 213012,
      "e": 152828,
      "ty": 41,
      "x": 25724,
      "y": 52627,
      "ta": "html > body"
    },
    {
      "t": 213112,
      "e": 152928,
      "ty": 2,
      "x": 757,
      "y": 958
    },
    {
      "t": 213212,
      "e": 153028,
      "ty": 2,
      "x": 758,
      "y": 959
    },
    {
      "t": 213263,
      "e": 153079,
      "ty": 41,
      "x": 25931,
      "y": 52904,
      "ta": "html > body"
    },
    {
      "t": 213312,
      "e": 153128,
      "ty": 2,
      "x": 762,
      "y": 968
    },
    {
      "t": 213412,
      "e": 153228,
      "ty": 2,
      "x": 762,
      "y": 978
    },
    {
      "t": 213512,
      "e": 153328,
      "ty": 2,
      "x": 762,
      "y": 979
    },
    {
      "t": 213513,
      "e": 153329,
      "ty": 41,
      "x": 25966,
      "y": 53790,
      "ta": "html > body"
    },
    {
      "t": 213612,
      "e": 153428,
      "ty": 2,
      "x": 762,
      "y": 988
    },
    {
      "t": 213712,
      "e": 153528,
      "ty": 2,
      "x": 762,
      "y": 998
    },
    {
      "t": 213762,
      "e": 153578,
      "ty": 41,
      "x": 25966,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 214011,
      "e": 153827,
      "ty": 2,
      "x": 762,
      "y": 1000
    },
    {
      "t": 214012,
      "e": 153828,
      "ty": 41,
      "x": 25966,
      "y": 54954,
      "ta": "html > body"
    },
    {
      "t": 214112,
      "e": 153928,
      "ty": 2,
      "x": 762,
      "y": 1003
    },
    {
      "t": 214212,
      "e": 154028,
      "ty": 2,
      "x": 762,
      "y": 1004
    },
    {
      "t": 214262,
      "e": 154078,
      "ty": 41,
      "x": 25966,
      "y": 55231,
      "ta": "html > body"
    },
    {
      "t": 214312,
      "e": 154128,
      "ty": 2,
      "x": 762,
      "y": 1005
    },
    {
      "t": 214411,
      "e": 154227,
      "ty": 2,
      "x": 762,
      "y": 1007
    },
    {
      "t": 214512,
      "e": 154328,
      "ty": 2,
      "x": 762,
      "y": 1012
    },
    {
      "t": 214512,
      "e": 154328,
      "ty": 41,
      "x": 25966,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 214612,
      "e": 154428,
      "ty": 2,
      "x": 762,
      "y": 1013
    },
    {
      "t": 214712,
      "e": 154528,
      "ty": 2,
      "x": 762,
      "y": 1015
    },
    {
      "t": 214763,
      "e": 154579,
      "ty": 41,
      "x": 25966,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 215012,
      "e": 154828,
      "ty": 2,
      "x": 762,
      "y": 1016
    },
    {
      "t": 215012,
      "e": 154828,
      "ty": 41,
      "x": 25966,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 215212,
      "e": 155028,
      "ty": 2,
      "x": 762,
      "y": 1018
    },
    {
      "t": 215262,
      "e": 155078,
      "ty": 41,
      "x": 25966,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 215412,
      "e": 155228,
      "ty": 2,
      "x": 762,
      "y": 1019
    },
    {
      "t": 215512,
      "e": 155328,
      "ty": 2,
      "x": 762,
      "y": 1021
    },
    {
      "t": 215512,
      "e": 155328,
      "ty": 41,
      "x": 25966,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 215612,
      "e": 155428,
      "ty": 2,
      "x": 762,
      "y": 1024
    },
    {
      "t": 215712,
      "e": 155528,
      "ty": 2,
      "x": 763,
      "y": 1024
    },
    {
      "t": 215763,
      "e": 155579,
      "ty": 41,
      "x": 26034,
      "y": 56339,
      "ta": "html > body"
    },
    {
      "t": 215812,
      "e": 155628,
      "ty": 2,
      "x": 764,
      "y": 1026
    },
    {
      "t": 215912,
      "e": 155728,
      "ty": 2,
      "x": 765,
      "y": 1027
    },
    {
      "t": 216012,
      "e": 155828,
      "ty": 2,
      "x": 765,
      "y": 1029
    },
    {
      "t": 216012,
      "e": 155828,
      "ty": 41,
      "x": 26069,
      "y": 56560,
      "ta": "html > body"
    },
    {
      "t": 216112,
      "e": 155928,
      "ty": 2,
      "x": 766,
      "y": 1030
    },
    {
      "t": 216212,
      "e": 156028,
      "ty": 2,
      "x": 766,
      "y": 1031
    },
    {
      "t": 216263,
      "e": 156079,
      "ty": 41,
      "x": 26103,
      "y": 56671,
      "ta": "html > body"
    },
    {
      "t": 216312,
      "e": 156128,
      "ty": 2,
      "x": 766,
      "y": 1032
    },
    {
      "t": 216412,
      "e": 156228,
      "ty": 2,
      "x": 767,
      "y": 1034
    },
    {
      "t": 216512,
      "e": 156328,
      "ty": 2,
      "x": 768,
      "y": 1036
    },
    {
      "t": 216513,
      "e": 156329,
      "ty": 41,
      "x": 26172,
      "y": 56948,
      "ta": "html > body"
    },
    {
      "t": 216763,
      "e": 156579,
      "ty": 41,
      "x": 26172,
      "y": 57003,
      "ta": "html > body"
    },
    {
      "t": 216812,
      "e": 156628,
      "ty": 2,
      "x": 768,
      "y": 1037
    },
    {
      "t": 217612,
      "e": 157428,
      "ty": 2,
      "x": 768,
      "y": 1040
    },
    {
      "t": 217712,
      "e": 157528,
      "ty": 2,
      "x": 769,
      "y": 1043
    },
    {
      "t": 217763,
      "e": 157579,
      "ty": 41,
      "x": 26207,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 217912,
      "e": 157728,
      "ty": 2,
      "x": 770,
      "y": 1043
    },
    {
      "t": 218013,
      "e": 157829,
      "ty": 41,
      "x": 26241,
      "y": 57336,
      "ta": "html > body"
    },
    {
      "t": 220012,
      "e": 159828,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 220112,
      "e": 159928,
      "ty": 2,
      "x": 743,
      "y": 1033
    },
    {
      "t": 220213,
      "e": 160029,
      "ty": 2,
      "x": 730,
      "y": 999
    },
    {
      "t": 220262,
      "e": 160078,
      "ty": 41,
      "x": 24864,
      "y": 54732,
      "ta": "html > body"
    },
    {
      "t": 220312,
      "e": 160128,
      "ty": 2,
      "x": 728,
      "y": 994
    },
    {
      "t": 220412,
      "e": 160228,
      "ty": 2,
      "x": 726,
      "y": 994
    },
    {
      "t": 220512,
      "e": 160328,
      "ty": 41,
      "x": 24726,
      "y": 54621,
      "ta": "html > body"
    },
    {
      "t": 227763,
      "e": 165328,
      "ty": 41,
      "x": 24760,
      "y": 54510,
      "ta": "html > body"
    },
    {
      "t": 227812,
      "e": 165377,
      "ty": 2,
      "x": 772,
      "y": 948
    },
    {
      "t": 227912,
      "e": 165477,
      "ty": 2,
      "x": 785,
      "y": 919
    },
    {
      "t": 228012,
      "e": 165577,
      "ty": 2,
      "x": 787,
      "y": 901
    },
    {
      "t": 228013,
      "e": 165578,
      "ty": 41,
      "x": 26826,
      "y": 49469,
      "ta": "html > body"
    },
    {
      "t": 228112,
      "e": 165677,
      "ty": 2,
      "x": 775,
      "y": 889
    },
    {
      "t": 228212,
      "e": 165777,
      "ty": 2,
      "x": 747,
      "y": 919
    },
    {
      "t": 228263,
      "e": 165828,
      "ty": 41,
      "x": 25105,
      "y": 51353,
      "ta": "html > body"
    },
    {
      "t": 228313,
      "e": 165878,
      "ty": 2,
      "x": 731,
      "y": 946
    },
    {
      "t": 228413,
      "e": 165978,
      "ty": 2,
      "x": 726,
      "y": 957
    },
    {
      "t": 228513,
      "e": 166078,
      "ty": 41,
      "x": 24726,
      "y": 52572,
      "ta": "html > body"
    },
    {
      "t": 229313,
      "e": 166878,
      "ty": 2,
      "x": 724,
      "y": 957
    },
    {
      "t": 229413,
      "e": 166978,
      "ty": 2,
      "x": 720,
      "y": 956
    },
    {
      "t": 229512,
      "e": 167077,
      "ty": 2,
      "x": 713,
      "y": 959
    },
    {
      "t": 229513,
      "e": 167078,
      "ty": 41,
      "x": 24278,
      "y": 52682,
      "ta": "html > body"
    },
    {
      "t": 229613,
      "e": 167178,
      "ty": 2,
      "x": 712,
      "y": 961
    },
    {
      "t": 229763,
      "e": 167328,
      "ty": 41,
      "x": 24244,
      "y": 52793,
      "ta": "html > body"
    },
    {
      "t": 230012,
      "e": 167577,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 231113,
      "e": 168678,
      "ty": 2,
      "x": 712,
      "y": 962
    },
    {
      "t": 231264,
      "e": 168829,
      "ty": 41,
      "x": 24244,
      "y": 52849,
      "ta": "html > body"
    },
    {
      "t": 231313,
      "e": 168878,
      "ty": 2,
      "x": 713,
      "y": 963
    },
    {
      "t": 231413,
      "e": 168978,
      "ty": 2,
      "x": 714,
      "y": 964
    },
    {
      "t": 231513,
      "e": 169078,
      "ty": 2,
      "x": 715,
      "y": 964
    },
    {
      "t": 231513,
      "e": 169078,
      "ty": 41,
      "x": 24347,
      "y": 52959,
      "ta": "html > body"
    },
    {
      "t": 231613,
      "e": 169178,
      "ty": 2,
      "x": 716,
      "y": 964
    },
    {
      "t": 231713,
      "e": 169278,
      "ty": 2,
      "x": 716,
      "y": 965
    },
    {
      "t": 231763,
      "e": 169328,
      "ty": 41,
      "x": 24381,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 231913,
      "e": 169478,
      "ty": 2,
      "x": 716,
      "y": 968
    },
    {
      "t": 232013,
      "e": 169578,
      "ty": 2,
      "x": 716,
      "y": 971
    },
    {
      "t": 232014,
      "e": 169579,
      "ty": 41,
      "x": 24381,
      "y": 53347,
      "ta": "html > body"
    },
    {
      "t": 232113,
      "e": 169678,
      "ty": 2,
      "x": 716,
      "y": 974
    },
    {
      "t": 232213,
      "e": 169778,
      "ty": 2,
      "x": 716,
      "y": 976
    },
    {
      "t": 232263,
      "e": 169828,
      "ty": 41,
      "x": 24381,
      "y": 53624,
      "ta": "html > body"
    },
    {
      "t": 232312,
      "e": 169877,
      "ty": 2,
      "x": 716,
      "y": 977
    },
    {
      "t": 232513,
      "e": 170078,
      "ty": 2,
      "x": 716,
      "y": 978
    },
    {
      "t": 232513,
      "e": 170078,
      "ty": 41,
      "x": 24381,
      "y": 53735,
      "ta": "html > body"
    },
    {
      "t": 232812,
      "e": 170377,
      "ty": 2,
      "x": 716,
      "y": 979
    },
    {
      "t": 233013,
      "e": 170578,
      "ty": 41,
      "x": 24381,
      "y": 53790,
      "ta": "html > body"
    },
    {
      "t": 233312,
      "e": 170877,
      "ty": 2,
      "x": 716,
      "y": 980
    },
    {
      "t": 233512,
      "e": 171077,
      "ty": 41,
      "x": 24381,
      "y": 53846,
      "ta": "html > body"
    },
    {
      "t": 233712,
      "e": 171277,
      "ty": 2,
      "x": 738,
      "y": 965
    },
    {
      "t": 233762,
      "e": 171327,
      "ty": 41,
      "x": 25346,
      "y": 52793,
      "ta": "html > body"
    },
    {
      "t": 233812,
      "e": 171377,
      "ty": 2,
      "x": 745,
      "y": 961
    },
    {
      "t": 233912,
      "e": 171477,
      "ty": 2,
      "x": 748,
      "y": 960
    },
    {
      "t": 234012,
      "e": 171577,
      "ty": 2,
      "x": 760,
      "y": 943
    },
    {
      "t": 234012,
      "e": 171577,
      "ty": 41,
      "x": 25897,
      "y": 51796,
      "ta": "html > body"
    },
    {
      "t": 234112,
      "e": 171677,
      "ty": 2,
      "x": 772,
      "y": 858
    },
    {
      "t": 234212,
      "e": 171777,
      "ty": 2,
      "x": 781,
      "y": 805
    },
    {
      "t": 234263,
      "e": 171828,
      "ty": 41,
      "x": 26895,
      "y": 42711,
      "ta": "html > body"
    },
    {
      "t": 234312,
      "e": 171877,
      "ty": 2,
      "x": 802,
      "y": 748
    },
    {
      "t": 234412,
      "e": 171977,
      "ty": 2,
      "x": 817,
      "y": 711
    },
    {
      "t": 234511,
      "e": 172076,
      "ty": 2,
      "x": 824,
      "y": 695
    },
    {
      "t": 234512,
      "e": 172077,
      "ty": 41,
      "x": 649,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 234612,
      "e": 172177,
      "ty": 2,
      "x": 825,
      "y": 693
    },
    {
      "t": 234666,
      "e": 172231,
      "ty": 6,
      "x": 831,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 234712,
      "e": 172277,
      "ty": 2,
      "x": 833,
      "y": 698
    },
    {
      "t": 234762,
      "e": 172327,
      "ty": 41,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 234813,
      "e": 172378,
      "ty": 2,
      "x": 835,
      "y": 700
    },
    {
      "t": 234912,
      "e": 172477,
      "ty": 2,
      "x": 838,
      "y": 702
    },
    {
      "t": 234948,
      "e": 172513,
      "ty": 3,
      "x": 838,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 234950,
      "e": 172515,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 234950,
      "e": 172515,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 235003,
      "e": 172568,
      "ty": 4,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 235004,
      "e": 172569,
      "ty": 5,
      "x": 838,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 235004,
      "e": 172569,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 235012,
      "e": 172577,
      "ty": 2,
      "x": 838,
      "y": 703
    },
    {
      "t": 235012,
      "e": 172577,
      "ty": 41,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 235112,
      "e": 172677,
      "ty": 2,
      "x": 838,
      "y": 708
    },
    {
      "t": 235114,
      "e": 172679,
      "ty": 7,
      "x": 838,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 235212,
      "e": 172777,
      "ty": 2,
      "x": 843,
      "y": 729
    },
    {
      "t": 235262,
      "e": 172827,
      "ty": 41,
      "x": 14427,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 235312,
      "e": 172877,
      "ty": 2,
      "x": 902,
      "y": 776
    },
    {
      "t": 235411,
      "e": 172976,
      "ty": 2,
      "x": 1024,
      "y": 820
    },
    {
      "t": 235512,
      "e": 173077,
      "ty": 2,
      "x": 1078,
      "y": 849
    },
    {
      "t": 235512,
      "e": 173077,
      "ty": 41,
      "x": 60892,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 235612,
      "e": 173177,
      "ty": 2,
      "x": 1109,
      "y": 875
    },
    {
      "t": 235712,
      "e": 173277,
      "ty": 2,
      "x": 1120,
      "y": 890
    },
    {
      "t": 235762,
      "e": 173327,
      "ty": 41,
      "x": 38363,
      "y": 48971,
      "ta": "html > body"
    },
    {
      "t": 235812,
      "e": 173377,
      "ty": 2,
      "x": 1125,
      "y": 896
    },
    {
      "t": 235912,
      "e": 173477,
      "ty": 2,
      "x": 1141,
      "y": 918
    },
    {
      "t": 236012,
      "e": 173577,
      "ty": 2,
      "x": 1143,
      "y": 926
    },
    {
      "t": 236013,
      "e": 173578,
      "ty": 41,
      "x": 39086,
      "y": 50854,
      "ta": "html > body"
    },
    {
      "t": 236112,
      "e": 173677,
      "ty": 2,
      "x": 1149,
      "y": 949
    },
    {
      "t": 236212,
      "e": 173777,
      "ty": 2,
      "x": 1150,
      "y": 965
    },
    {
      "t": 236262,
      "e": 173827,
      "ty": 41,
      "x": 39327,
      "y": 53236,
      "ta": "html > body"
    },
    {
      "t": 236312,
      "e": 173877,
      "ty": 2,
      "x": 1150,
      "y": 971
    },
    {
      "t": 236412,
      "e": 173977,
      "ty": 2,
      "x": 1150,
      "y": 973
    },
    {
      "t": 236513,
      "e": 174078,
      "ty": 41,
      "x": 39327,
      "y": 53458,
      "ta": "html > body"
    },
    {
      "t": 236712,
      "e": 174277,
      "ty": 2,
      "x": 1148,
      "y": 972
    },
    {
      "t": 236762,
      "e": 174327,
      "ty": 41,
      "x": 39396,
      "y": 53292,
      "ta": "html > body"
    },
    {
      "t": 236812,
      "e": 174377,
      "ty": 2,
      "x": 1153,
      "y": 966
    },
    {
      "t": 236912,
      "e": 174477,
      "ty": 2,
      "x": 1151,
      "y": 965
    },
    {
      "t": 237012,
      "e": 174577,
      "ty": 41,
      "x": 39362,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 239012,
      "e": 176577,
      "ty": 2,
      "x": 1148,
      "y": 965
    },
    {
      "t": 239013,
      "e": 176578,
      "ty": 41,
      "x": 39259,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 239112,
      "e": 176677,
      "ty": 2,
      "x": 1142,
      "y": 975
    },
    {
      "t": 239262,
      "e": 176827,
      "ty": 41,
      "x": 39052,
      "y": 53569,
      "ta": "html > body"
    },
    {
      "t": 239512,
      "e": 177077,
      "ty": 2,
      "x": 1140,
      "y": 976
    },
    {
      "t": 239512,
      "e": 177077,
      "ty": 41,
      "x": 38983,
      "y": 53624,
      "ta": "html > body"
    },
    {
      "t": 239613,
      "e": 177178,
      "ty": 2,
      "x": 1139,
      "y": 976
    },
    {
      "t": 239763,
      "e": 177328,
      "ty": 41,
      "x": 38949,
      "y": 53624,
      "ta": "html > body"
    },
    {
      "t": 240012,
      "e": 177577,
      "ty": 2,
      "x": 1138,
      "y": 976
    },
    {
      "t": 240012,
      "e": 177577,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 240015,
      "e": 177580,
      "ty": 41,
      "x": 38914,
      "y": 53624,
      "ta": "html > body"
    },
    {
      "t": 240213,
      "e": 177778,
      "ty": 2,
      "x": 1137,
      "y": 973
    },
    {
      "t": 240263,
      "e": 177828,
      "ty": 41,
      "x": 38880,
      "y": 53292,
      "ta": "html > body"
    },
    {
      "t": 240313,
      "e": 177878,
      "ty": 2,
      "x": 1137,
      "y": 970
    },
    {
      "t": 240413,
      "e": 177978,
      "ty": 2,
      "x": 1137,
      "y": 964
    },
    {
      "t": 240513,
      "e": 178078,
      "ty": 2,
      "x": 1135,
      "y": 961
    },
    {
      "t": 240513,
      "e": 178078,
      "ty": 41,
      "x": 38811,
      "y": 52793,
      "ta": "html > body"
    },
    {
      "t": 240612,
      "e": 178177,
      "ty": 2,
      "x": 1131,
      "y": 950
    },
    {
      "t": 240712,
      "e": 178277,
      "ty": 2,
      "x": 1126,
      "y": 944
    },
    {
      "t": 240762,
      "e": 178327,
      "ty": 41,
      "x": 38501,
      "y": 51851,
      "ta": "html > body"
    },
    {
      "t": 241212,
      "e": 178777,
      "ty": 2,
      "x": 1113,
      "y": 938
    },
    {
      "t": 241263,
      "e": 178828,
      "ty": 41,
      "x": 37812,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 241312,
      "e": 178877,
      "ty": 2,
      "x": 1106,
      "y": 937
    },
    {
      "t": 241413,
      "e": 178978,
      "ty": 2,
      "x": 1104,
      "y": 937
    },
    {
      "t": 241513,
      "e": 179078,
      "ty": 2,
      "x": 1098,
      "y": 937
    },
    {
      "t": 241513,
      "e": 179078,
      "ty": 41,
      "x": 37537,
      "y": 51464,
      "ta": "html > body"
    },
    {
      "t": 241612,
      "e": 179177,
      "ty": 2,
      "x": 1089,
      "y": 940
    },
    {
      "t": 241712,
      "e": 179277,
      "ty": 2,
      "x": 1088,
      "y": 941
    },
    {
      "t": 241762,
      "e": 179327,
      "ty": 41,
      "x": 62790,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 241812,
      "e": 179377,
      "ty": 2,
      "x": 1086,
      "y": 941
    },
    {
      "t": 241912,
      "e": 179477,
      "ty": 2,
      "x": 1085,
      "y": 941
    },
    {
      "t": 242012,
      "e": 179577,
      "ty": 41,
      "x": 62553,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 242112,
      "e": 179677,
      "ty": 2,
      "x": 1072,
      "y": 940
    },
    {
      "t": 242213,
      "e": 179778,
      "ty": 2,
      "x": 1065,
      "y": 939
    },
    {
      "t": 242263,
      "e": 179828,
      "ty": 41,
      "x": 57332,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 242312,
      "e": 179877,
      "ty": 2,
      "x": 1063,
      "y": 939
    },
    {
      "t": 242412,
      "e": 179977,
      "ty": 2,
      "x": 1062,
      "y": 939
    },
    {
      "t": 242513,
      "e": 180078,
      "ty": 2,
      "x": 1061,
      "y": 942
    },
    {
      "t": 242513,
      "e": 180078,
      "ty": 41,
      "x": 56857,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 242613,
      "e": 180178,
      "ty": 2,
      "x": 1059,
      "y": 950
    },
    {
      "t": 242712,
      "e": 180277,
      "ty": 2,
      "x": 1054,
      "y": 955
    },
    {
      "t": 242762,
      "e": 180327,
      "ty": 41,
      "x": 54959,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 242812,
      "e": 180377,
      "ty": 2,
      "x": 1051,
      "y": 957
    },
    {
      "t": 242912,
      "e": 180477,
      "ty": 2,
      "x": 1050,
      "y": 959
    },
    {
      "t": 243013,
      "e": 180578,
      "ty": 2,
      "x": 1049,
      "y": 959
    },
    {
      "t": 243013,
      "e": 180578,
      "ty": 41,
      "x": 54009,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 243612,
      "e": 181177,
      "ty": 2,
      "x": 1047,
      "y": 960
    },
    {
      "t": 243762,
      "e": 181327,
      "ty": 41,
      "x": 53535,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 243813,
      "e": 181378,
      "ty": 2,
      "x": 1044,
      "y": 960
    },
    {
      "t": 243913,
      "e": 181478,
      "ty": 2,
      "x": 1041,
      "y": 961
    },
    {
      "t": 244013,
      "e": 181578,
      "ty": 2,
      "x": 1038,
      "y": 962
    },
    {
      "t": 244013,
      "e": 181578,
      "ty": 41,
      "x": 51399,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 244112,
      "e": 181677,
      "ty": 2,
      "x": 1037,
      "y": 962
    },
    {
      "t": 244213,
      "e": 181778,
      "ty": 2,
      "x": 1035,
      "y": 962
    },
    {
      "t": 244262,
      "e": 181827,
      "ty": 41,
      "x": 50450,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 244312,
      "e": 181877,
      "ty": 2,
      "x": 1032,
      "y": 962
    },
    {
      "t": 244412,
      "e": 181977,
      "ty": 2,
      "x": 1031,
      "y": 963
    },
    {
      "t": 244512,
      "e": 182077,
      "ty": 2,
      "x": 1030,
      "y": 967
    },
    {
      "t": 244512,
      "e": 182077,
      "ty": 41,
      "x": 49500,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 244612,
      "e": 182177,
      "ty": 2,
      "x": 1029,
      "y": 968
    },
    {
      "t": 244712,
      "e": 182277,
      "ty": 2,
      "x": 1029,
      "y": 971
    },
    {
      "t": 244763,
      "e": 182328,
      "ty": 41,
      "x": 49263,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 244912,
      "e": 182477,
      "ty": 2,
      "x": 1028,
      "y": 973
    },
    {
      "t": 245012,
      "e": 182577,
      "ty": 2,
      "x": 1028,
      "y": 976
    },
    {
      "t": 245013,
      "e": 182578,
      "ty": 41,
      "x": 49026,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 245112,
      "e": 182677,
      "ty": 2,
      "x": 1029,
      "y": 977
    },
    {
      "t": 245263,
      "e": 182828,
      "ty": 41,
      "x": 49263,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 246512,
      "e": 184077,
      "ty": 2,
      "x": 1022,
      "y": 987
    },
    {
      "t": 246513,
      "e": 184078,
      "ty": 41,
      "x": 47602,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 246613,
      "e": 184178,
      "ty": 2,
      "x": 1011,
      "y": 994
    },
    {
      "t": 246712,
      "e": 184277,
      "ty": 2,
      "x": 986,
      "y": 1005
    },
    {
      "t": 246762,
      "e": 184327,
      "ty": 41,
      "x": 35973,
      "y": 63367,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 246813,
      "e": 184378,
      "ty": 2,
      "x": 957,
      "y": 1013
    },
    {
      "t": 246818,
      "e": 184383,
      "ty": 6,
      "x": 952,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 246912,
      "e": 184477,
      "ty": 2,
      "x": 940,
      "y": 1017
    },
    {
      "t": 247013,
      "e": 184578,
      "ty": 2,
      "x": 928,
      "y": 1020
    },
    {
      "t": 247013,
      "e": 184578,
      "ty": 41,
      "x": 50806,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247115,
      "e": 184680,
      "ty": 3,
      "x": 928,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247116,
      "e": 184681,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 247116,
      "e": 184681,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247178,
      "e": 184743,
      "ty": 4,
      "x": 50806,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247178,
      "e": 184743,
      "ty": 5,
      "x": 928,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247180,
      "e": 184745,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 247181,
      "e": 184746,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 247182,
      "e": 184747,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 247613,
      "e": 185178,
      "ty": 2,
      "x": 928,
      "y": 1021
    },
    {
      "t": 247713,
      "e": 185278,
      "ty": 2,
      "x": 945,
      "y": 1022
    },
    {
      "t": 247762,
      "e": 185327,
      "ty": 41,
      "x": 32681,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 247813,
      "e": 185378,
      "ty": 2,
      "x": 989,
      "y": 1016
    },
    {
      "t": 247913,
      "e": 185478,
      "ty": 2,
      "x": 1009,
      "y": 1010
    },
    {
      "t": 248012,
      "e": 185577,
      "ty": 2,
      "x": 1010,
      "y": 1010
    },
    {
      "t": 248013,
      "e": 185578,
      "ty": 41,
      "x": 34506,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 248554,
      "e": 186119,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 249113,
      "e": 186678,
      "ty": 2,
      "x": 1012,
      "y": 1007
    },
    {
      "t": 249213,
      "e": 186778,
      "ty": 2,
      "x": 1012,
      "y": 1004
    },
    {
      "t": 249263,
      "e": 186828,
      "ty": 41,
      "x": 35350,
      "y": 60778,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 249313,
      "e": 186878,
      "ty": 2,
      "x": 1012,
      "y": 1003
    },
    {
      "t": 249413,
      "e": 186978,
      "ty": 2,
      "x": 1011,
      "y": 995
    },
    {
      "t": 249512,
      "e": 187077,
      "ty": 2,
      "x": 1011,
      "y": 984
    },
    {
      "t": 249513,
      "e": 187078,
      "ty": 41,
      "x": 35301,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 249612,
      "e": 187177,
      "ty": 2,
      "x": 1008,
      "y": 977
    },
    {
      "t": 249713,
      "e": 187278,
      "ty": 2,
      "x": 1006,
      "y": 972
    },
    {
      "t": 249763,
      "e": 187328,
      "ty": 41,
      "x": 35055,
      "y": 58562,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 249913,
      "e": 187478,
      "ty": 2,
      "x": 1005,
      "y": 976
    },
    {
      "t": 250013,
      "e": 187578,
      "ty": 2,
      "x": 1003,
      "y": 979
    },
    {
      "t": 250013,
      "e": 187578,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 250016,
      "e": 187581,
      "ty": 41,
      "x": 34907,
      "y": 59047,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 250113,
      "e": 187678,
      "ty": 2,
      "x": 1002,
      "y": 980
    },
    {
      "t": 250212,
      "e": 187777,
      "ty": 2,
      "x": 1000,
      "y": 981
    },
    {
      "t": 250263,
      "e": 187828,
      "ty": 41,
      "x": 34759,
      "y": 59185,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 250313,
      "e": 187878,
      "ty": 2,
      "x": 1000,
      "y": 982
    },
    {
      "t": 250513,
      "e": 188078,
      "ty": 2,
      "x": 999,
      "y": 983
    },
    {
      "t": 250513,
      "e": 188078,
      "ty": 41,
      "x": 34710,
      "y": 59324,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 250613,
      "e": 188178,
      "ty": 2,
      "x": 998,
      "y": 985
    },
    {
      "t": 250763,
      "e": 188328,
      "ty": 41,
      "x": 34661,
      "y": 59462,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 251013,
      "e": 188578,
      "ty": 2,
      "x": 998,
      "y": 969
    },
    {
      "t": 251014,
      "e": 188579,
      "ty": 41,
      "x": 34661,
      "y": 58354,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 260012,
      "e": 193579,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 407315,
      "e": 193579,
      "ty": 2,
      "x": 998,
      "y": 968
    },
    {
      "t": 407516,
      "e": 193780,
      "ty": 41,
      "x": 34661,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 407716,
      "e": 193980,
      "ty": 2,
      "x": 990,
      "y": 974
    },
    {
      "t": 407765,
      "e": 194029,
      "ty": 41,
      "x": 33038,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 407815,
      "e": 194079,
      "ty": 2,
      "x": 960,
      "y": 1044
    },
    {
      "t": 407915,
      "e": 194179,
      "ty": 2,
      "x": 962,
      "y": 1071
    },
    {
      "t": 407920,
      "e": 194184,
      "ty": 6,
      "x": 964,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 408015,
      "e": 194279,
      "ty": 2,
      "x": 971,
      "y": 1093
    },
    {
      "t": 408015,
      "e": 194279,
      "ty": 41,
      "x": 33586,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 408116,
      "e": 194380,
      "ty": 2,
      "x": 973,
      "y": 1097
    },
    {
      "t": 408174,
      "e": 194438,
      "ty": 3,
      "x": 973,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 408175,
      "e": 194439,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 408260,
      "e": 194524,
      "ty": 4,
      "x": 34678,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 408260,
      "e": 194524,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 408260,
      "e": 194524,
      "ty": 5,
      "x": 973,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 408260,
      "e": 194524,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 408266,
      "e": 194530,
      "ty": 41,
      "x": 33232,
      "y": 60327,
      "ta": "html > body"
    },
    {
      "t": 409299,
      "e": 195563,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 410149,
      "e": 196413,
      "ty": 41,
      "x": 31485,
      "y": 32832,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 410149,
      "e": 196413,
      "ty": 2,
      "x": 920,
      "y": 905
    },
    {
      "t": 410219,
      "e": 196483,
      "ty": 2,
      "x": 921,
      "y": 905
    },
    {
      "t": 410266,
      "e": 196530,
      "ty": 41,
      "x": 31517,
      "y": 32832,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 410516,
      "e": 196780,
      "ty": 2,
      "x": 922,
      "y": 905
    },
    {
      "t": 410516,
      "e": 196780,
      "ty": 41,
      "x": 31549,
      "y": 32832,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 410615,
      "e": 196879,
      "ty": 2,
      "x": 923,
      "y": 906
    },
    {
      "t": 410715,
      "e": 196979,
      "ty": 2,
      "x": 924,
      "y": 907
    },
    {
      "t": 410765,
      "e": 197029,
      "ty": 41,
      "x": 31614,
      "y": 32833,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 410816,
      "e": 197080,
      "ty": 2,
      "x": 924,
      "y": 912
    },
    {
      "t": 411015,
      "e": 197279,
      "ty": 2,
      "x": 924,
      "y": 913
    },
    {
      "t": 411016,
      "e": 197280,
      "ty": 41,
      "x": 31614,
      "y": 32834,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 411118,
      "e": 197382,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120018, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120025, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 25203, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 146560, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 20248, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"papa\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 167815, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 28788, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 197769, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 21587, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 220358, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14150, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 235901, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:979,y:962,t:1527620772809};\\\", \\\"{x:966,y:950,t:1527620772840};\\\", \\\"{x:958,y:940,t:1527620773025};\\\", \\\"{x:956,y:938,t:1527620774087};\\\", \\\"{x:953,y:935,t:1527620774099};\\\", \\\"{x:947,y:932,t:1527620774116};\\\", \\\"{x:942,y:930,t:1527620774133};\\\", \\\"{x:937,y:928,t:1527620774149};\\\", \\\"{x:929,y:923,t:1527620774166};\\\", \\\"{x:917,y:918,t:1527620774182};\\\", \\\"{x:905,y:911,t:1527620774198};\\\", \\\"{x:891,y:906,t:1527620774215};\\\", \\\"{x:879,y:901,t:1527620774232};\\\", \\\"{x:862,y:894,t:1527620774249};\\\", \\\"{x:853,y:890,t:1527620774266};\\\", \\\"{x:849,y:888,t:1527620774283};\\\", \\\"{x:846,y:886,t:1527620774299};\\\", \\\"{x:842,y:883,t:1527620774315};\\\", \\\"{x:840,y:882,t:1527620774332};\\\", \\\"{x:839,y:881,t:1527620774350};\\\", \\\"{x:839,y:880,t:1527620774366};\\\", \\\"{x:839,y:879,t:1527620774390};\\\", \\\"{x:838,y:877,t:1527620775335};\\\", \\\"{x:820,y:853,t:1527620775349};\\\", \\\"{x:802,y:767,t:1527620775367};\\\", \\\"{x:803,y:764,t:1527620775384};\\\", \\\"{x:805,y:764,t:1527620776231};\\\", \\\"{x:810,y:768,t:1527620776241};\\\", \\\"{x:814,y:770,t:1527620776250};\\\", \\\"{x:825,y:775,t:1527620776266};\\\", \\\"{x:842,y:786,t:1527620776283};\\\", \\\"{x:867,y:794,t:1527620776300};\\\", \\\"{x:899,y:800,t:1527620776316};\\\", \\\"{x:932,y:806,t:1527620776333};\\\", \\\"{x:965,y:807,t:1527620776349};\\\", \\\"{x:988,y:807,t:1527620776367};\\\", \\\"{x:1019,y:807,t:1527620776383};\\\", \\\"{x:1057,y:810,t:1527620776400};\\\", \\\"{x:1088,y:811,t:1527620776416};\\\", \\\"{x:1107,y:813,t:1527620776434};\\\", \\\"{x:1120,y:816,t:1527620776451};\\\", \\\"{x:1133,y:819,t:1527620776468};\\\", \\\"{x:1144,y:822,t:1527620776483};\\\", \\\"{x:1149,y:825,t:1527620776501};\\\", \\\"{x:1149,y:827,t:1527620776534};\\\", \\\"{x:1149,y:832,t:1527620776550};\\\", \\\"{x:1149,y:840,t:1527620776568};\\\", \\\"{x:1149,y:843,t:1527620776584};\\\", \\\"{x:1151,y:847,t:1527620776601};\\\", \\\"{x:1153,y:851,t:1527620776617};\\\", \\\"{x:1157,y:855,t:1527620776634};\\\", \\\"{x:1166,y:869,t:1527620776650};\\\", \\\"{x:1184,y:886,t:1527620776668};\\\", \\\"{x:1195,y:893,t:1527620776684};\\\", \\\"{x:1198,y:894,t:1527620776701};\\\", \\\"{x:1201,y:898,t:1527620776718};\\\", \\\"{x:1206,y:903,t:1527620776734};\\\", \\\"{x:1213,y:909,t:1527620776751};\\\", \\\"{x:1228,y:913,t:1527620776767};\\\", \\\"{x:1241,y:916,t:1527620776783};\\\", \\\"{x:1250,y:918,t:1527620776801};\\\", \\\"{x:1256,y:918,t:1527620776818};\\\", \\\"{x:1259,y:918,t:1527620776834};\\\", \\\"{x:1267,y:917,t:1527620776851};\\\", \\\"{x:1272,y:914,t:1527620776868};\\\", \\\"{x:1282,y:911,t:1527620776884};\\\", \\\"{x:1285,y:909,t:1527620776901};\\\", \\\"{x:1288,y:908,t:1527620776918};\\\", \\\"{x:1289,y:906,t:1527620776934};\\\", \\\"{x:1289,y:904,t:1527620776951};\\\", \\\"{x:1289,y:903,t:1527620776974};\\\", \\\"{x:1289,y:902,t:1527620777007};\\\", \\\"{x:1289,y:901,t:1527620777018};\\\", \\\"{x:1290,y:898,t:1527620777035};\\\", \\\"{x:1290,y:894,t:1527620777051};\\\", \\\"{x:1290,y:891,t:1527620777068};\\\", \\\"{x:1290,y:890,t:1527620777085};\\\", \\\"{x:1290,y:887,t:1527620777101};\\\", \\\"{x:1290,y:884,t:1527620777118};\\\", \\\"{x:1290,y:876,t:1527620777135};\\\", \\\"{x:1290,y:873,t:1527620777151};\\\", \\\"{x:1290,y:870,t:1527620777168};\\\", \\\"{x:1290,y:867,t:1527620777185};\\\", \\\"{x:1290,y:866,t:1527620777201};\\\", \\\"{x:1290,y:864,t:1527620777262};\\\", \\\"{x:1288,y:864,t:1527620777270};\\\", \\\"{x:1282,y:863,t:1527620777284};\\\", \\\"{x:1256,y:863,t:1527620777300};\\\", \\\"{x:1218,y:861,t:1527620777317};\\\", \\\"{x:1159,y:860,t:1527620777333};\\\", \\\"{x:1126,y:857,t:1527620777350};\\\", \\\"{x:1083,y:854,t:1527620777367};\\\", \\\"{x:1045,y:848,t:1527620777384};\\\", \\\"{x:1017,y:841,t:1527620777400};\\\", \\\"{x:993,y:835,t:1527620777417};\\\", \\\"{x:978,y:827,t:1527620777434};\\\", \\\"{x:955,y:820,t:1527620777451};\\\", \\\"{x:945,y:817,t:1527620777467};\\\", \\\"{x:935,y:812,t:1527620777485};\\\", \\\"{x:929,y:808,t:1527620777502};\\\", \\\"{x:925,y:807,t:1527620777518};\\\", \\\"{x:918,y:803,t:1527620777534};\\\", \\\"{x:909,y:794,t:1527620777552};\\\", \\\"{x:897,y:788,t:1527620777567};\\\", \\\"{x:890,y:785,t:1527620777585};\\\", \\\"{x:849,y:770,t:1527620777602};\\\", \\\"{x:788,y:755,t:1527620777618};\\\", \\\"{x:720,y:739,t:1527620777635};\\\", \\\"{x:641,y:713,t:1527620777652};\\\", \\\"{x:581,y:687,t:1527620777668};\\\", \\\"{x:540,y:671,t:1527620777685};\\\", \\\"{x:504,y:649,t:1527620777704};\\\", \\\"{x:494,y:642,t:1527620777719};\\\", \\\"{x:459,y:618,t:1527620777734};\\\", \\\"{x:418,y:597,t:1527620777752};\\\", \\\"{x:373,y:572,t:1527620777769};\\\", \\\"{x:326,y:552,t:1527620777785};\\\", \\\"{x:306,y:543,t:1527620777801};\\\", \\\"{x:289,y:533,t:1527620777818};\\\", \\\"{x:279,y:524,t:1527620777835};\\\", \\\"{x:276,y:520,t:1527620777851};\\\", \\\"{x:275,y:516,t:1527620777868};\\\", \\\"{x:274,y:513,t:1527620777885};\\\", \\\"{x:273,y:509,t:1527620777902};\\\", \\\"{x:271,y:499,t:1527620777918};\\\", \\\"{x:271,y:490,t:1527620777935};\\\", \\\"{x:274,y:482,t:1527620777951};\\\", \\\"{x:280,y:479,t:1527620777969};\\\", \\\"{x:286,y:479,t:1527620777985};\\\", \\\"{x:289,y:478,t:1527620778003};\\\", \\\"{x:292,y:478,t:1527620778018};\\\", \\\"{x:299,y:481,t:1527620778035};\\\", \\\"{x:307,y:485,t:1527620778052};\\\", \\\"{x:318,y:492,t:1527620778068};\\\", \\\"{x:327,y:499,t:1527620778085};\\\", \\\"{x:332,y:503,t:1527620778103};\\\", \\\"{x:335,y:506,t:1527620778119};\\\", \\\"{x:338,y:508,t:1527620778136};\\\", \\\"{x:341,y:513,t:1527620778152};\\\", \\\"{x:342,y:514,t:1527620778168};\\\", \\\"{x:344,y:516,t:1527620778198};\\\", \\\"{x:344,y:517,t:1527620778206};\\\", \\\"{x:346,y:519,t:1527620778219};\\\", \\\"{x:347,y:519,t:1527620778236};\\\", \\\"{x:351,y:521,t:1527620778252};\\\", \\\"{x:355,y:521,t:1527620778268};\\\", \\\"{x:359,y:521,t:1527620778286};\\\", \\\"{x:366,y:521,t:1527620778302};\\\", \\\"{x:372,y:522,t:1527620778319};\\\", \\\"{x:376,y:522,t:1527620778336};\\\", \\\"{x:377,y:522,t:1527620778353};\\\", \\\"{x:379,y:522,t:1527620778374};\\\", \\\"{x:380,y:522,t:1527620778385};\\\", \\\"{x:382,y:522,t:1527620778402};\\\", \\\"{x:383,y:522,t:1527620778422};\\\", \\\"{x:384,y:523,t:1527620778662};\\\", \\\"{x:385,y:524,t:1527620778670};\\\", \\\"{x:387,y:526,t:1527620778686};\\\", \\\"{x:389,y:528,t:1527620778703};\\\", \\\"{x:393,y:533,t:1527620778720};\\\", \\\"{x:398,y:540,t:1527620778738};\\\", \\\"{x:403,y:545,t:1527620778754};\\\", \\\"{x:411,y:550,t:1527620778770};\\\", \\\"{x:418,y:553,t:1527620778786};\\\", \\\"{x:422,y:554,t:1527620778802};\\\", \\\"{x:430,y:556,t:1527620778819};\\\", \\\"{x:434,y:558,t:1527620778835};\\\", \\\"{x:444,y:561,t:1527620778852};\\\", \\\"{x:458,y:567,t:1527620778869};\\\", \\\"{x:479,y:576,t:1527620778886};\\\", \\\"{x:541,y:602,t:1527620778903};\\\", \\\"{x:594,y:626,t:1527620778920};\\\", \\\"{x:644,y:648,t:1527620778936};\\\", \\\"{x:671,y:660,t:1527620778953};\\\", \\\"{x:700,y:673,t:1527620778969};\\\", \\\"{x:720,y:685,t:1527620778986};\\\", \\\"{x:733,y:692,t:1527620779002};\\\", \\\"{x:744,y:701,t:1527620779020};\\\", \\\"{x:759,y:712,t:1527620779036};\\\", \\\"{x:777,y:726,t:1527620779053};\\\", \\\"{x:791,y:737,t:1527620779070};\\\", \\\"{x:812,y:751,t:1527620779086};\\\", \\\"{x:819,y:757,t:1527620779104};\\\", \\\"{x:827,y:762,t:1527620779119};\\\", \\\"{x:835,y:769,t:1527620779137};\\\", \\\"{x:839,y:773,t:1527620779153};\\\", \\\"{x:842,y:776,t:1527620779169};\\\", \\\"{x:844,y:777,t:1527620779187};\\\", \\\"{x:846,y:777,t:1527620779203};\\\", \\\"{x:847,y:777,t:1527620779221};\\\", \\\"{x:847,y:778,t:1527620779236};\\\", \\\"{x:848,y:779,t:1527620780367};\\\", \\\"{x:850,y:780,t:1527620780527};\\\", \\\"{x:850,y:781,t:1527620780542};\\\", \\\"{x:851,y:781,t:1527620780566};\\\", \\\"{x:851,y:782,t:1527620780575};\\\", \\\"{x:852,y:782,t:1527620780590};\\\", \\\"{x:853,y:784,t:1527620780607};\\\", \\\"{x:854,y:784,t:1527620780630};\\\", \\\"{x:854,y:785,t:1527620780646};\\\", \\\"{x:855,y:785,t:1527620780662};\\\", \\\"{x:855,y:786,t:1527620780678};\\\", \\\"{x:857,y:787,t:1527620780690};\\\", \\\"{x:859,y:788,t:1527620780707};\\\", \\\"{x:864,y:792,t:1527620780724};\\\", \\\"{x:872,y:794,t:1527620780741};\\\", \\\"{x:886,y:796,t:1527620780756};\\\", \\\"{x:906,y:800,t:1527620780773};\\\", \\\"{x:923,y:806,t:1527620780790};\\\", \\\"{x:944,y:810,t:1527620780806};\\\", \\\"{x:962,y:812,t:1527620780823};\\\", \\\"{x:976,y:813,t:1527620780840};\\\", \\\"{x:986,y:816,t:1527620780856};\\\", \\\"{x:990,y:817,t:1527620780874};\\\", \\\"{x:993,y:818,t:1527620780891};\\\", \\\"{x:997,y:819,t:1527620780907};\\\", \\\"{x:1002,y:821,t:1527620780924};\\\", \\\"{x:1011,y:823,t:1527620780940};\\\", \\\"{x:1022,y:826,t:1527620780958};\\\", \\\"{x:1038,y:830,t:1527620780974};\\\", \\\"{x:1051,y:833,t:1527620780991};\\\", \\\"{x:1070,y:836,t:1527620781008};\\\", \\\"{x:1096,y:841,t:1527620781024};\\\", \\\"{x:1112,y:844,t:1527620781041};\\\", \\\"{x:1126,y:846,t:1527620781057};\\\", \\\"{x:1129,y:846,t:1527620781074};\\\", \\\"{x:1130,y:846,t:1527620781094};\\\", \\\"{x:1131,y:848,t:1527620781108};\\\", \\\"{x:1132,y:848,t:1527620781125};\\\", \\\"{x:1136,y:848,t:1527620781141};\\\", \\\"{x:1139,y:848,t:1527620781158};\\\", \\\"{x:1144,y:848,t:1527620781177};\\\", \\\"{x:1152,y:848,t:1527620781192};\\\", \\\"{x:1171,y:845,t:1527620781208};\\\", \\\"{x:1188,y:841,t:1527620781224};\\\", \\\"{x:1199,y:838,t:1527620781241};\\\", \\\"{x:1212,y:835,t:1527620781259};\\\", \\\"{x:1220,y:835,t:1527620781275};\\\", \\\"{x:1230,y:834,t:1527620781291};\\\", \\\"{x:1237,y:833,t:1527620781307};\\\", \\\"{x:1242,y:832,t:1527620781324};\\\", \\\"{x:1249,y:831,t:1527620781341};\\\", \\\"{x:1252,y:831,t:1527620781358};\\\", \\\"{x:1257,y:831,t:1527620781375};\\\", \\\"{x:1265,y:831,t:1527620781392};\\\", \\\"{x:1273,y:831,t:1527620781409};\\\", \\\"{x:1276,y:831,t:1527620781426};\\\", \\\"{x:1278,y:831,t:1527620781442};\\\", \\\"{x:1279,y:831,t:1527620781459};\\\", \\\"{x:1280,y:831,t:1527620781493};\\\", \\\"{x:1281,y:831,t:1527620781510};\\\", \\\"{x:1282,y:831,t:1527620781525};\\\", \\\"{x:1283,y:831,t:1527620781558};\\\", \\\"{x:1284,y:831,t:1527620781862};\\\", \\\"{x:1285,y:831,t:1527620782631};\\\", \\\"{x:1286,y:831,t:1527620782790};\\\", \\\"{x:1286,y:832,t:1527620783847};\\\", \\\"{x:1286,y:833,t:1527620783961};\\\", \\\"{x:1286,y:834,t:1527620783983};\\\", \\\"{x:1285,y:835,t:1527620784007};\\\", \\\"{x:1284,y:836,t:1527620784031};\\\", \\\"{x:1284,y:837,t:1527620784063};\\\", \\\"{x:1283,y:838,t:1527620784103};\\\", \\\"{x:1282,y:838,t:1527620784567};\\\", \\\"{x:1281,y:838,t:1527620784599};\\\", \\\"{x:1280,y:838,t:1527620784631};\\\", \\\"{x:1279,y:838,t:1527620784861};\\\", \\\"{x:1272,y:838,t:1527620786015};\\\", \\\"{x:1256,y:840,t:1527620786023};\\\", \\\"{x:1232,y:843,t:1527620786036};\\\", \\\"{x:1155,y:850,t:1527620786052};\\\", \\\"{x:1044,y:852,t:1527620786070};\\\", \\\"{x:883,y:852,t:1527620786087};\\\", \\\"{x:797,y:852,t:1527620786102};\\\", \\\"{x:728,y:852,t:1527620786120};\\\", \\\"{x:674,y:852,t:1527620786136};\\\", \\\"{x:619,y:852,t:1527620786152};\\\", \\\"{x:575,y:849,t:1527620786169};\\\", \\\"{x:536,y:845,t:1527620786187};\\\", \\\"{x:495,y:835,t:1527620786202};\\\", \\\"{x:464,y:821,t:1527620786219};\\\", \\\"{x:441,y:808,t:1527620786236};\\\", \\\"{x:426,y:801,t:1527620786254};\\\", \\\"{x:416,y:793,t:1527620786269};\\\", \\\"{x:413,y:780,t:1527620786287};\\\", \\\"{x:413,y:772,t:1527620786303};\\\", \\\"{x:413,y:768,t:1527620786320};\\\", \\\"{x:416,y:763,t:1527620786337};\\\", \\\"{x:418,y:761,t:1527620786353};\\\", \\\"{x:422,y:757,t:1527620786370};\\\", \\\"{x:430,y:752,t:1527620786386};\\\", \\\"{x:439,y:748,t:1527620786403};\\\", \\\"{x:450,y:747,t:1527620786420};\\\", \\\"{x:459,y:744,t:1527620786436};\\\", \\\"{x:465,y:742,t:1527620786453};\\\", \\\"{x:476,y:739,t:1527620786470};\\\", \\\"{x:484,y:736,t:1527620786486};\\\", \\\"{x:487,y:736,t:1527620786503};\\\", \\\"{x:490,y:734,t:1527620786521};\\\", \\\"{x:493,y:734,t:1527620786537};\\\", \\\"{x:496,y:732,t:1527620786553};\\\", \\\"{x:498,y:732,t:1527620786570};\\\", \\\"{x:502,y:732,t:1527620786592};\\\", \\\"{x:503,y:731,t:1527620786608};\\\", \\\"{x:505,y:731,t:1527620786626};\\\", \\\"{x:506,y:731,t:1527620786643};\\\", \\\"{x:508,y:729,t:1527620786658};\\\", \\\"{x:511,y:729,t:1527620786676};\\\", \\\"{x:511,y:728,t:1527620786692};\\\", \\\"{x:513,y:727,t:1527620786718};\\\", \\\"{x:513,y:726,t:1527620786734};\\\", \\\"{x:514,y:725,t:1527620786758};\\\", \\\"{x:515,y:725,t:1527620786782};\\\", \\\"{x:516,y:724,t:1527620786798};\\\", \\\"{x:517,y:723,t:1527620787231};\\\", \\\"{x:518,y:723,t:1527620787243};\\\", \\\"{x:519,y:724,t:1527620787260};\\\", \\\"{x:521,y:726,t:1527620787276};\\\", \\\"{x:522,y:727,t:1527620787294};\\\", \\\"{x:525,y:729,t:1527620787310};\\\", \\\"{x:525,y:731,t:1527620787326};\\\", \\\"{x:527,y:733,t:1527620787344};\\\", \\\"{x:527,y:735,t:1527620787360};\\\", \\\"{x:529,y:737,t:1527620787376};\\\", \\\"{x:531,y:739,t:1527620787394};\\\", \\\"{x:534,y:740,t:1527620787410};\\\", \\\"{x:537,y:742,t:1527620787426};\\\", \\\"{x:538,y:742,t:1527620787455};\\\", \\\"{x:540,y:743,t:1527620787462};\\\", \\\"{x:541,y:743,t:1527620787476};\\\", \\\"{x:542,y:743,t:1527620787493};\\\", \\\"{x:547,y:745,t:1527620787510};\\\", \\\"{x:549,y:746,t:1527620787526};\\\", \\\"{x:550,y:746,t:1527620787543};\\\", \\\"{x:551,y:747,t:1527620787567};\\\", \\\"{x:553,y:747,t:1527620787606};\\\", \\\"{x:555,y:746,t:1527620787614};\\\", \\\"{x:557,y:746,t:1527620787627};\\\", \\\"{x:559,y:746,t:1527620787644};\\\", \\\"{x:560,y:745,t:1527620787660};\\\", \\\"{x:562,y:745,t:1527620787677};\\\", \\\"{x:567,y:745,t:1527620787693};\\\", \\\"{x:574,y:744,t:1527620787711};\\\", \\\"{x:585,y:742,t:1527620787727};\\\", \\\"{x:605,y:742,t:1527620787743};\\\", \\\"{x:621,y:742,t:1527620787761};\\\", \\\"{x:634,y:742,t:1527620787778};\\\", \\\"{x:644,y:742,t:1527620787793};\\\", \\\"{x:653,y:742,t:1527620787810};\\\", \\\"{x:661,y:742,t:1527620787827};\\\", \\\"{x:665,y:742,t:1527620787844};\\\", \\\"{x:670,y:742,t:1527620787860};\\\", \\\"{x:672,y:742,t:1527620787878};\\\", \\\"{x:675,y:742,t:1527620787893};\\\", \\\"{x:680,y:745,t:1527620787910};\\\", \\\"{x:682,y:745,t:1527620787927};\\\", \\\"{x:682,y:746,t:1527620787943};\\\", \\\"{x:684,y:748,t:1527620788022};\\\", \\\"{x:684,y:749,t:1527620788037};\\\", \\\"{x:685,y:751,t:1527620788053};\\\" ] }, { \\\"rt\\\": 20035, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 257190, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:685,y:752,t:1527620788207};\\\", \\\"{x:686,y:752,t:1527620788232};\\\", \\\"{x:687,y:750,t:1527620789093};\\\", \\\"{x:688,y:750,t:1527620789111};\\\", \\\"{x:689,y:749,t:1527620789128};\\\", \\\"{x:690,y:748,t:1527620789144};\\\", \\\"{x:692,y:747,t:1527620789161};\\\", \\\"{x:693,y:747,t:1527620789177};\\\", \\\"{x:694,y:746,t:1527620789194};\\\", \\\"{x:695,y:745,t:1527620789211};\\\", \\\"{x:696,y:744,t:1527620789227};\\\", \\\"{x:698,y:744,t:1527620789243};\\\", \\\"{x:699,y:742,t:1527620789261};\\\", \\\"{x:703,y:741,t:1527620789277};\\\", \\\"{x:706,y:739,t:1527620789293};\\\", \\\"{x:709,y:738,t:1527620789311};\\\", \\\"{x:711,y:737,t:1527620789327};\\\", \\\"{x:712,y:737,t:1527620789344};\\\", \\\"{x:713,y:736,t:1527620789361};\\\", \\\"{x:715,y:735,t:1527620789378};\\\", \\\"{x:718,y:734,t:1527620789395};\\\", \\\"{x:723,y:732,t:1527620789411};\\\", \\\"{x:731,y:730,t:1527620789428};\\\", \\\"{x:744,y:727,t:1527620789445};\\\", \\\"{x:749,y:726,t:1527620789461};\\\", \\\"{x:754,y:725,t:1527620789477};\\\", \\\"{x:757,y:724,t:1527620789494};\\\", \\\"{x:760,y:723,t:1527620789510};\\\", \\\"{x:767,y:721,t:1527620789528};\\\", \\\"{x:776,y:719,t:1527620789544};\\\", \\\"{x:783,y:719,t:1527620789561};\\\", \\\"{x:789,y:718,t:1527620789578};\\\", \\\"{x:792,y:718,t:1527620789594};\\\", \\\"{x:793,y:718,t:1527620789611};\\\", \\\"{x:794,y:718,t:1527620789628};\\\", \\\"{x:794,y:717,t:1527620789645};\\\", \\\"{x:795,y:717,t:1527620789743};\\\", \\\"{x:796,y:718,t:1527620789758};\\\", \\\"{x:797,y:719,t:1527620789766};\\\", \\\"{x:798,y:720,t:1527620789778};\\\", \\\"{x:799,y:723,t:1527620789794};\\\", \\\"{x:801,y:726,t:1527620789811};\\\", \\\"{x:803,y:733,t:1527620789828};\\\", \\\"{x:806,y:738,t:1527620789845};\\\", \\\"{x:810,y:753,t:1527620789861};\\\", \\\"{x:812,y:759,t:1527620789878};\\\", \\\"{x:816,y:766,t:1527620789895};\\\", \\\"{x:819,y:771,t:1527620789912};\\\", \\\"{x:822,y:776,t:1527620789928};\\\", \\\"{x:825,y:781,t:1527620789945};\\\", \\\"{x:828,y:784,t:1527620789962};\\\", \\\"{x:831,y:789,t:1527620789978};\\\", \\\"{x:836,y:794,t:1527620789995};\\\", \\\"{x:841,y:797,t:1527620790012};\\\", \\\"{x:847,y:800,t:1527620790028};\\\", \\\"{x:851,y:801,t:1527620790045};\\\", \\\"{x:854,y:803,t:1527620790063};\\\", \\\"{x:855,y:804,t:1527620790086};\\\", \\\"{x:856,y:804,t:1527620790095};\\\", \\\"{x:857,y:804,t:1527620790112};\\\", \\\"{x:858,y:805,t:1527620790128};\\\", \\\"{x:859,y:806,t:1527620790151};\\\", \\\"{x:859,y:807,t:1527620790162};\\\", \\\"{x:860,y:807,t:1527620790191};\\\", \\\"{x:861,y:808,t:1527620790198};\\\", \\\"{x:862,y:809,t:1527620790230};\\\", \\\"{x:862,y:810,t:1527620790245};\\\", \\\"{x:863,y:810,t:1527620790262};\\\", \\\"{x:863,y:811,t:1527620790279};\\\", \\\"{x:863,y:812,t:1527620790326};\\\", \\\"{x:864,y:812,t:1527620790334};\\\", \\\"{x:865,y:813,t:1527620790625};\\\", \\\"{x:866,y:813,t:1527620790705};\\\", \\\"{x:867,y:814,t:1527620791097};\\\", \\\"{x:867,y:815,t:1527620791113};\\\", \\\"{x:867,y:817,t:1527620791129};\\\", \\\"{x:867,y:818,t:1527620791145};\\\", \\\"{x:867,y:820,t:1527620791153};\\\", \\\"{x:867,y:822,t:1527620791169};\\\", \\\"{x:867,y:823,t:1527620791182};\\\", \\\"{x:867,y:825,t:1527620791199};\\\", \\\"{x:867,y:827,t:1527620791215};\\\", \\\"{x:867,y:830,t:1527620791232};\\\", \\\"{x:867,y:831,t:1527620791249};\\\", \\\"{x:867,y:832,t:1527620791273};\\\", \\\"{x:867,y:833,t:1527620791289};\\\", \\\"{x:868,y:834,t:1527620791299};\\\", \\\"{x:869,y:834,t:1527620791316};\\\", \\\"{x:871,y:834,t:1527620791332};\\\", \\\"{x:873,y:836,t:1527620791348};\\\", \\\"{x:874,y:837,t:1527620791365};\\\", \\\"{x:875,y:837,t:1527620791382};\\\", \\\"{x:877,y:837,t:1527620791399};\\\", \\\"{x:878,y:838,t:1527620791416};\\\", \\\"{x:879,y:838,t:1527620791432};\\\", \\\"{x:880,y:839,t:1527620791449};\\\", \\\"{x:881,y:840,t:1527620791465};\\\", \\\"{x:882,y:840,t:1527620791505};\\\", \\\"{x:884,y:841,t:1527620791516};\\\", \\\"{x:888,y:844,t:1527620791532};\\\", \\\"{x:892,y:847,t:1527620791549};\\\", \\\"{x:896,y:849,t:1527620791566};\\\", \\\"{x:900,y:851,t:1527620791582};\\\", \\\"{x:905,y:853,t:1527620791599};\\\", \\\"{x:914,y:855,t:1527620791616};\\\", \\\"{x:918,y:857,t:1527620791632};\\\", \\\"{x:923,y:859,t:1527620791648};\\\", \\\"{x:923,y:860,t:1527620791666};\\\", \\\"{x:924,y:860,t:1527620791682};\\\", \\\"{x:925,y:860,t:1527620791712};\\\", \\\"{x:926,y:861,t:1527620791768};\\\", \\\"{x:926,y:862,t:1527620791808};\\\", \\\"{x:926,y:863,t:1527620791881};\\\", \\\"{x:926,y:864,t:1527620791897};\\\", \\\"{x:926,y:865,t:1527620791921};\\\", \\\"{x:926,y:866,t:1527620791933};\\\", \\\"{x:926,y:867,t:1527620791949};\\\", \\\"{x:926,y:868,t:1527620792161};\\\", \\\"{x:926,y:869,t:1527620792169};\\\", \\\"{x:925,y:869,t:1527620792200};\\\", \\\"{x:924,y:869,t:1527620792216};\\\", \\\"{x:921,y:871,t:1527620792233};\\\", \\\"{x:917,y:871,t:1527620792249};\\\", \\\"{x:909,y:871,t:1527620792266};\\\", \\\"{x:892,y:868,t:1527620792283};\\\", \\\"{x:860,y:858,t:1527620792299};\\\", \\\"{x:816,y:840,t:1527620792316};\\\", \\\"{x:776,y:821,t:1527620792333};\\\", \\\"{x:721,y:789,t:1527620792350};\\\", \\\"{x:678,y:764,t:1527620792366};\\\", \\\"{x:658,y:749,t:1527620792383};\\\", \\\"{x:646,y:736,t:1527620792400};\\\", \\\"{x:640,y:723,t:1527620792416};\\\", \\\"{x:630,y:701,t:1527620792433};\\\", \\\"{x:624,y:685,t:1527620792449};\\\", \\\"{x:613,y:671,t:1527620792466};\\\", \\\"{x:602,y:659,t:1527620792483};\\\", \\\"{x:586,y:646,t:1527620792501};\\\", \\\"{x:566,y:637,t:1527620792515};\\\", \\\"{x:543,y:629,t:1527620792532};\\\", \\\"{x:520,y:622,t:1527620792550};\\\", \\\"{x:498,y:615,t:1527620792567};\\\", \\\"{x:482,y:611,t:1527620792583};\\\", \\\"{x:461,y:603,t:1527620792600};\\\", \\\"{x:431,y:591,t:1527620792616};\\\", \\\"{x:408,y:581,t:1527620792633};\\\", \\\"{x:394,y:574,t:1527620792650};\\\", \\\"{x:387,y:569,t:1527620792667};\\\", \\\"{x:381,y:565,t:1527620792682};\\\", \\\"{x:378,y:561,t:1527620792699};\\\", \\\"{x:368,y:554,t:1527620792717};\\\", \\\"{x:360,y:550,t:1527620792733};\\\", \\\"{x:349,y:547,t:1527620792750};\\\", \\\"{x:342,y:544,t:1527620792766};\\\", \\\"{x:339,y:543,t:1527620792785};\\\", \\\"{x:336,y:543,t:1527620792799};\\\", \\\"{x:326,y:543,t:1527620792816};\\\", \\\"{x:315,y:543,t:1527620792834};\\\", \\\"{x:297,y:543,t:1527620792850};\\\", \\\"{x:288,y:543,t:1527620792866};\\\", \\\"{x:284,y:543,t:1527620792884};\\\", \\\"{x:283,y:543,t:1527620792905};\\\", \\\"{x:280,y:543,t:1527620792917};\\\", \\\"{x:271,y:543,t:1527620792933};\\\", \\\"{x:258,y:543,t:1527620792950};\\\", \\\"{x:251,y:544,t:1527620792969};\\\", \\\"{x:248,y:546,t:1527620792983};\\\", \\\"{x:247,y:546,t:1527620792999};\\\", \\\"{x:245,y:547,t:1527620793016};\\\", \\\"{x:242,y:550,t:1527620793034};\\\", \\\"{x:240,y:552,t:1527620793050};\\\", \\\"{x:237,y:554,t:1527620793067};\\\", \\\"{x:231,y:559,t:1527620793084};\\\", \\\"{x:225,y:564,t:1527620793099};\\\", \\\"{x:215,y:569,t:1527620793117};\\\", \\\"{x:206,y:574,t:1527620793133};\\\", \\\"{x:202,y:577,t:1527620793150};\\\", \\\"{x:196,y:580,t:1527620793167};\\\", \\\"{x:194,y:582,t:1527620793184};\\\", \\\"{x:190,y:585,t:1527620793200};\\\", \\\"{x:185,y:591,t:1527620793217};\\\", \\\"{x:182,y:594,t:1527620793233};\\\", \\\"{x:180,y:598,t:1527620793250};\\\", \\\"{x:180,y:600,t:1527620793267};\\\", \\\"{x:179,y:604,t:1527620793284};\\\", \\\"{x:177,y:607,t:1527620793301};\\\", \\\"{x:176,y:611,t:1527620793316};\\\", \\\"{x:174,y:614,t:1527620793334};\\\", \\\"{x:171,y:618,t:1527620793351};\\\", \\\"{x:170,y:621,t:1527620793367};\\\", \\\"{x:168,y:622,t:1527620793384};\\\", \\\"{x:164,y:625,t:1527620793400};\\\", \\\"{x:163,y:626,t:1527620793416};\\\", \\\"{x:160,y:628,t:1527620793433};\\\", \\\"{x:159,y:629,t:1527620793451};\\\", \\\"{x:158,y:629,t:1527620793467};\\\", \\\"{x:157,y:630,t:1527620793484};\\\", \\\"{x:157,y:631,t:1527620793728};\\\", \\\"{x:157,y:633,t:1527620793736};\\\", \\\"{x:157,y:635,t:1527620793750};\\\", \\\"{x:160,y:639,t:1527620793768};\\\", \\\"{x:166,y:645,t:1527620793783};\\\", \\\"{x:182,y:657,t:1527620793801};\\\", \\\"{x:198,y:667,t:1527620793818};\\\", \\\"{x:217,y:678,t:1527620793833};\\\", \\\"{x:243,y:692,t:1527620793850};\\\", \\\"{x:268,y:709,t:1527620793867};\\\", \\\"{x:312,y:728,t:1527620793883};\\\", \\\"{x:368,y:744,t:1527620793901};\\\", \\\"{x:435,y:761,t:1527620793918};\\\", \\\"{x:515,y:784,t:1527620793933};\\\", \\\"{x:617,y:798,t:1527620793950};\\\", \\\"{x:762,y:819,t:1527620793968};\\\", \\\"{x:934,y:826,t:1527620793984};\\\", \\\"{x:1199,y:826,t:1527620794001};\\\", \\\"{x:1398,y:822,t:1527620794017};\\\", \\\"{x:1596,y:808,t:1527620794033};\\\", \\\"{x:1761,y:791,t:1527620794051};\\\", \\\"{x:1881,y:770,t:1527620794068};\\\", \\\"{x:1919,y:750,t:1527620794085};\\\", \\\"{x:1919,y:739,t:1527620794101};\\\", \\\"{x:1919,y:731,t:1527620794118};\\\", \\\"{x:1917,y:716,t:1527620794134};\\\", \\\"{x:1900,y:695,t:1527620794152};\\\", \\\"{x:1885,y:681,t:1527620794168};\\\", \\\"{x:1874,y:665,t:1527620794185};\\\", \\\"{x:1870,y:651,t:1527620794201};\\\", \\\"{x:1865,y:630,t:1527620794218};\\\", \\\"{x:1846,y:604,t:1527620794235};\\\", \\\"{x:1806,y:576,t:1527620794251};\\\", \\\"{x:1732,y:547,t:1527620794268};\\\", \\\"{x:1648,y:516,t:1527620794285};\\\", \\\"{x:1589,y:497,t:1527620794301};\\\", \\\"{x:1552,y:480,t:1527620794318};\\\", \\\"{x:1545,y:476,t:1527620794335};\\\", \\\"{x:1545,y:474,t:1527620794351};\\\", \\\"{x:1545,y:469,t:1527620794368};\\\", \\\"{x:1542,y:464,t:1527620794384};\\\", \\\"{x:1540,y:461,t:1527620794402};\\\", \\\"{x:1539,y:458,t:1527620794418};\\\", \\\"{x:1539,y:455,t:1527620794435};\\\", \\\"{x:1539,y:454,t:1527620794452};\\\", \\\"{x:1539,y:452,t:1527620794468};\\\", \\\"{x:1539,y:451,t:1527620794485};\\\", \\\"{x:1543,y:450,t:1527620794502};\\\", \\\"{x:1552,y:449,t:1527620794519};\\\", \\\"{x:1563,y:447,t:1527620794535};\\\", \\\"{x:1572,y:446,t:1527620794552};\\\", \\\"{x:1577,y:444,t:1527620794568};\\\", \\\"{x:1578,y:443,t:1527620794586};\\\", \\\"{x:1580,y:443,t:1527620794602};\\\", \\\"{x:1581,y:442,t:1527620794618};\\\", \\\"{x:1584,y:442,t:1527620794635};\\\", \\\"{x:1586,y:440,t:1527620794653};\\\", \\\"{x:1587,y:440,t:1527620794669};\\\", \\\"{x:1588,y:440,t:1527620794685};\\\", \\\"{x:1589,y:440,t:1527620794705};\\\", \\\"{x:1590,y:440,t:1527620794720};\\\", \\\"{x:1591,y:440,t:1527620794770};\\\", \\\"{x:1593,y:439,t:1527620794785};\\\", \\\"{x:1598,y:439,t:1527620794802};\\\", \\\"{x:1601,y:438,t:1527620794819};\\\", \\\"{x:1604,y:438,t:1527620794835};\\\", \\\"{x:1606,y:437,t:1527620794853};\\\", \\\"{x:1607,y:437,t:1527620794869};\\\", \\\"{x:1609,y:437,t:1527620794885};\\\", \\\"{x:1613,y:437,t:1527620794903};\\\", \\\"{x:1616,y:437,t:1527620794919};\\\", \\\"{x:1617,y:437,t:1527620794935};\\\", \\\"{x:1618,y:437,t:1527620794977};\\\", \\\"{x:1619,y:437,t:1527620794994};\\\", \\\"{x:1620,y:437,t:1527620795074};\\\", \\\"{x:1621,y:437,t:1527620795089};\\\", \\\"{x:1621,y:439,t:1527620795161};\\\", \\\"{x:1620,y:439,t:1527620798457};\\\", \\\"{x:1619,y:439,t:1527620798473};\\\", \\\"{x:1618,y:440,t:1527620798489};\\\", \\\"{x:1617,y:441,t:1527620798529};\\\", \\\"{x:1617,y:442,t:1527620798553};\\\", \\\"{x:1617,y:443,t:1527620798561};\\\", \\\"{x:1617,y:445,t:1527620798573};\\\", \\\"{x:1617,y:446,t:1527620798588};\\\", \\\"{x:1617,y:452,t:1527620798606};\\\", \\\"{x:1617,y:457,t:1527620798623};\\\", \\\"{x:1617,y:461,t:1527620798638};\\\", \\\"{x:1616,y:468,t:1527620798655};\\\", \\\"{x:1615,y:473,t:1527620798672};\\\", \\\"{x:1614,y:481,t:1527620798688};\\\", \\\"{x:1612,y:484,t:1527620798705};\\\", \\\"{x:1611,y:487,t:1527620798723};\\\", \\\"{x:1610,y:491,t:1527620798739};\\\", \\\"{x:1608,y:494,t:1527620798756};\\\", \\\"{x:1608,y:498,t:1527620798772};\\\", \\\"{x:1607,y:504,t:1527620798789};\\\", \\\"{x:1606,y:509,t:1527620798805};\\\", \\\"{x:1606,y:514,t:1527620798823};\\\", \\\"{x:1606,y:517,t:1527620798839};\\\", \\\"{x:1606,y:521,t:1527620798856};\\\", \\\"{x:1606,y:524,t:1527620798872};\\\", \\\"{x:1606,y:525,t:1527620798889};\\\", \\\"{x:1606,y:526,t:1527620798905};\\\", \\\"{x:1606,y:527,t:1527620798923};\\\", \\\"{x:1606,y:529,t:1527620799065};\\\", \\\"{x:1607,y:530,t:1527620799089};\\\", \\\"{x:1608,y:531,t:1527620799113};\\\", \\\"{x:1609,y:532,t:1527620799123};\\\", \\\"{x:1609,y:534,t:1527620799140};\\\", \\\"{x:1611,y:536,t:1527620799156};\\\", \\\"{x:1613,y:541,t:1527620799172};\\\", \\\"{x:1613,y:542,t:1527620799189};\\\", \\\"{x:1615,y:544,t:1527620799206};\\\", \\\"{x:1615,y:546,t:1527620799222};\\\", \\\"{x:1617,y:547,t:1527620799239};\\\", \\\"{x:1617,y:549,t:1527620799255};\\\", \\\"{x:1617,y:550,t:1527620799272};\\\", \\\"{x:1618,y:551,t:1527620799290};\\\", \\\"{x:1619,y:551,t:1527620799313};\\\", \\\"{x:1619,y:552,t:1527620799323};\\\", \\\"{x:1619,y:553,t:1527620799345};\\\", \\\"{x:1619,y:555,t:1527620799377};\\\", \\\"{x:1619,y:556,t:1527620799417};\\\", \\\"{x:1619,y:558,t:1527620799481};\\\", \\\"{x:1619,y:559,t:1527620799545};\\\", \\\"{x:1620,y:559,t:1527620799577};\\\", \\\"{x:1620,y:561,t:1527620799826};\\\", \\\"{x:1620,y:563,t:1527620800226};\\\", \\\"{x:1620,y:564,t:1527620800329};\\\", \\\"{x:1619,y:564,t:1527620800345};\\\", \\\"{x:1618,y:564,t:1527620800376};\\\", \\\"{x:1617,y:565,t:1527620800458};\\\", \\\"{x:1616,y:566,t:1527620800489};\\\", \\\"{x:1615,y:566,t:1527620800497};\\\", \\\"{x:1614,y:566,t:1527620800577};\\\", \\\"{x:1613,y:566,t:1527620800968};\\\", \\\"{x:1613,y:565,t:1527620801602};\\\", \\\"{x:1613,y:564,t:1527620801801};\\\", \\\"{x:1610,y:565,t:1527620804018};\\\", \\\"{x:1599,y:567,t:1527620804030};\\\", \\\"{x:1583,y:571,t:1527620804044};\\\", \\\"{x:1564,y:573,t:1527620804060};\\\", \\\"{x:1540,y:577,t:1527620804077};\\\", \\\"{x:1514,y:582,t:1527620804093};\\\", \\\"{x:1482,y:590,t:1527620804110};\\\", \\\"{x:1437,y:603,t:1527620804127};\\\", \\\"{x:1388,y:614,t:1527620804144};\\\", \\\"{x:1325,y:626,t:1527620804160};\\\", \\\"{x:1216,y:640,t:1527620804177};\\\", \\\"{x:1154,y:648,t:1527620804194};\\\", \\\"{x:1087,y:660,t:1527620804210};\\\", \\\"{x:1020,y:669,t:1527620804228};\\\", \\\"{x:975,y:676,t:1527620804243};\\\", \\\"{x:932,y:683,t:1527620804259};\\\", \\\"{x:905,y:687,t:1527620804277};\\\", \\\"{x:883,y:690,t:1527620804294};\\\", \\\"{x:867,y:694,t:1527620804310};\\\", \\\"{x:851,y:697,t:1527620804326};\\\", \\\"{x:834,y:701,t:1527620804344};\\\", \\\"{x:800,y:709,t:1527620804361};\\\", \\\"{x:773,y:716,t:1527620804377};\\\", \\\"{x:751,y:719,t:1527620804394};\\\", \\\"{x:738,y:723,t:1527620804411};\\\", \\\"{x:732,y:724,t:1527620804427};\\\", \\\"{x:729,y:727,t:1527620804444};\\\", \\\"{x:724,y:728,t:1527620804460};\\\", \\\"{x:718,y:730,t:1527620804477};\\\", \\\"{x:714,y:732,t:1527620804494};\\\", \\\"{x:709,y:734,t:1527620804511};\\\", \\\"{x:708,y:734,t:1527620804526};\\\", \\\"{x:708,y:735,t:1527620804785};\\\", \\\"{x:709,y:735,t:1527620804874};\\\", \\\"{x:710,y:737,t:1527620804905};\\\", \\\"{x:711,y:737,t:1527620805105};\\\", \\\"{x:712,y:737,t:1527620805233};\\\", \\\"{x:713,y:737,t:1527620805265};\\\", \\\"{x:714,y:737,t:1527620805280};\\\", \\\"{x:716,y:737,t:1527620805305};\\\", \\\"{x:716,y:738,t:1527620805321};\\\", \\\"{x:718,y:738,t:1527620806008};\\\", \\\"{x:718,y:739,t:1527620807074};\\\", \\\"{x:719,y:739,t:1527620807169};\\\", \\\"{x:719,y:740,t:1527620807185};\\\", \\\"{x:718,y:740,t:1527620807196};\\\", \\\"{x:713,y:740,t:1527620807212};\\\", \\\"{x:706,y:738,t:1527620807230};\\\", \\\"{x:697,y:736,t:1527620807246};\\\", \\\"{x:690,y:734,t:1527620807262};\\\", \\\"{x:684,y:731,t:1527620807280};\\\", \\\"{x:677,y:728,t:1527620807295};\\\", \\\"{x:650,y:721,t:1527620807312};\\\", \\\"{x:625,y:714,t:1527620807329};\\\", \\\"{x:590,y:709,t:1527620807346};\\\", \\\"{x:554,y:705,t:1527620807364};\\\", \\\"{x:527,y:703,t:1527620807379};\\\", \\\"{x:507,y:702,t:1527620807395};\\\", \\\"{x:498,y:702,t:1527620807411};\\\", \\\"{x:486,y:702,t:1527620807428};\\\", \\\"{x:475,y:702,t:1527620807445};\\\", \\\"{x:468,y:702,t:1527620807461};\\\", \\\"{x:464,y:702,t:1527620807478};\\\", \\\"{x:464,y:703,t:1527620807496};\\\", \\\"{x:465,y:704,t:1527620807511};\\\", \\\"{x:474,y:710,t:1527620807528};\\\", \\\"{x:482,y:716,t:1527620807545};\\\", \\\"{x:492,y:723,t:1527620807561};\\\", \\\"{x:499,y:727,t:1527620807578};\\\", \\\"{x:504,y:730,t:1527620807595};\\\", \\\"{x:507,y:732,t:1527620807612};\\\", \\\"{x:508,y:732,t:1527620807697};\\\", \\\"{x:509,y:732,t:1527620807761};\\\", \\\"{x:509,y:731,t:1527620807778};\\\", \\\"{x:510,y:730,t:1527620807796};\\\", \\\"{x:511,y:729,t:1527620807812};\\\", \\\"{x:511,y:727,t:1527620807828};\\\", \\\"{x:511,y:725,t:1527620807846};\\\", \\\"{x:512,y:724,t:1527620807862};\\\", \\\"{x:513,y:724,t:1527620808577};\\\", \\\"{x:514,y:724,t:1527620808592};\\\", \\\"{x:516,y:724,t:1527620808633};\\\", \\\"{x:519,y:725,t:1527620808665};\\\", \\\"{x:521,y:725,t:1527620808680};\\\", \\\"{x:531,y:728,t:1527620808697};\\\", \\\"{x:535,y:729,t:1527620808712};\\\", \\\"{x:540,y:732,t:1527620808729};\\\", \\\"{x:544,y:733,t:1527620808747};\\\", \\\"{x:545,y:734,t:1527620808763};\\\", \\\"{x:547,y:736,t:1527620808779};\\\", \\\"{x:550,y:736,t:1527620808797};\\\", \\\"{x:551,y:737,t:1527620808812};\\\", \\\"{x:553,y:738,t:1527620808829};\\\", \\\"{x:554,y:738,t:1527620808847};\\\", \\\"{x:555,y:739,t:1527620808863};\\\", \\\"{x:556,y:739,t:1527620808879};\\\", \\\"{x:557,y:741,t:1527620808896};\\\", \\\"{x:559,y:742,t:1527620808913};\\\", \\\"{x:560,y:743,t:1527620808936};\\\", \\\"{x:560,y:744,t:1527620808952};\\\", \\\"{x:561,y:745,t:1527620808968};\\\", \\\"{x:563,y:747,t:1527620808993};\\\", \\\"{x:563,y:748,t:1527620809008};\\\", \\\"{x:564,y:749,t:1527620809025};\\\", \\\"{x:565,y:749,t:1527620809041};\\\", \\\"{x:566,y:749,t:1527620809048};\\\", \\\"{x:567,y:749,t:1527620809073};\\\", \\\"{x:569,y:750,t:1527620809080};\\\", \\\"{x:570,y:751,t:1527620809096};\\\", \\\"{x:572,y:752,t:1527620809128};\\\", \\\"{x:573,y:752,t:1527620809288};\\\" ] }, { \\\"rt\\\": 40272, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 298729, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"I\\\", \\\"O\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -A -A -C -C -C -A -O -O -Z -Z -01 PM-12 PM-11 AM-10 AM-09 AM-08 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:574,y:753,t:1527620809672};\\\", \\\"{x:574,y:754,t:1527620809958};\\\", \\\"{x:574,y:755,t:1527620810080};\\\", \\\"{x:574,y:756,t:1527620810129};\\\", \\\"{x:575,y:756,t:1527620810985};\\\", \\\"{x:576,y:756,t:1527620810997};\\\", \\\"{x:581,y:756,t:1527620811015};\\\", \\\"{x:582,y:756,t:1527620811032};\\\", \\\"{x:585,y:756,t:1527620811048};\\\", \\\"{x:586,y:756,t:1527620811064};\\\", \\\"{x:589,y:755,t:1527620811082};\\\", \\\"{x:591,y:754,t:1527620811098};\\\", \\\"{x:592,y:753,t:1527620811115};\\\", \\\"{x:593,y:753,t:1527620811132};\\\", \\\"{x:593,y:751,t:1527620811149};\\\", \\\"{x:596,y:748,t:1527620811164};\\\", \\\"{x:599,y:744,t:1527620811182};\\\", \\\"{x:600,y:741,t:1527620811199};\\\", \\\"{x:602,y:739,t:1527620811215};\\\", \\\"{x:602,y:737,t:1527620811232};\\\", \\\"{x:604,y:734,t:1527620811249};\\\", \\\"{x:605,y:733,t:1527620811265};\\\", \\\"{x:606,y:733,t:1527620811282};\\\", \\\"{x:606,y:732,t:1527620811337};\\\", \\\"{x:607,y:731,t:1527620811497};\\\", \\\"{x:608,y:731,t:1527620811545};\\\", \\\"{x:609,y:731,t:1527620811560};\\\", \\\"{x:611,y:731,t:1527620811568};\\\", \\\"{x:612,y:730,t:1527620811582};\\\", \\\"{x:614,y:728,t:1527620811599};\\\", \\\"{x:615,y:727,t:1527620811616};\\\", \\\"{x:618,y:723,t:1527620811631};\\\", \\\"{x:623,y:718,t:1527620811648};\\\", \\\"{x:631,y:713,t:1527620811666};\\\", \\\"{x:640,y:710,t:1527620811681};\\\", \\\"{x:651,y:705,t:1527620811699};\\\", \\\"{x:654,y:701,t:1527620811715};\\\", \\\"{x:659,y:697,t:1527620811731};\\\", \\\"{x:663,y:695,t:1527620811749};\\\", \\\"{x:664,y:694,t:1527620811765};\\\", \\\"{x:665,y:693,t:1527620811782};\\\", \\\"{x:666,y:693,t:1527620811897};\\\", \\\"{x:667,y:693,t:1527620811913};\\\", \\\"{x:667,y:694,t:1527620811937};\\\", \\\"{x:667,y:695,t:1527620811949};\\\", \\\"{x:667,y:696,t:1527620811969};\\\", \\\"{x:667,y:697,t:1527620811982};\\\", \\\"{x:668,y:698,t:1527620811999};\\\", \\\"{x:668,y:700,t:1527620812016};\\\", \\\"{x:668,y:701,t:1527620812041};\\\", \\\"{x:668,y:703,t:1527620812097};\\\", \\\"{x:668,y:704,t:1527620812121};\\\", \\\"{x:668,y:706,t:1527620812136};\\\", \\\"{x:668,y:707,t:1527620812152};\\\", \\\"{x:668,y:708,t:1527620812166};\\\", \\\"{x:668,y:709,t:1527620812182};\\\", \\\"{x:667,y:710,t:1527620812199};\\\", \\\"{x:667,y:712,t:1527620812215};\\\", \\\"{x:667,y:713,t:1527620812240};\\\", \\\"{x:667,y:715,t:1527620812272};\\\", \\\"{x:666,y:716,t:1527620812296};\\\", \\\"{x:666,y:717,t:1527620812345};\\\", \\\"{x:666,y:718,t:1527620812360};\\\", \\\"{x:666,y:719,t:1527620812385};\\\", \\\"{x:666,y:720,t:1527620812400};\\\", \\\"{x:666,y:721,t:1527620812415};\\\", \\\"{x:666,y:722,t:1527620812433};\\\", \\\"{x:666,y:724,t:1527620812450};\\\", \\\"{x:666,y:726,t:1527620812466};\\\", \\\"{x:666,y:728,t:1527620812483};\\\", \\\"{x:666,y:730,t:1527620812499};\\\", \\\"{x:666,y:731,t:1527620812516};\\\", \\\"{x:666,y:734,t:1527620812533};\\\", \\\"{x:666,y:735,t:1527620812550};\\\", \\\"{x:666,y:736,t:1527620812566};\\\", \\\"{x:666,y:737,t:1527620812609};\\\", \\\"{x:667,y:737,t:1527620812673};\\\", \\\"{x:668,y:737,t:1527620812897};\\\", \\\"{x:669,y:737,t:1527620812961};\\\", \\\"{x:670,y:737,t:1527620812968};\\\", \\\"{x:671,y:737,t:1527620812985};\\\", \\\"{x:672,y:737,t:1527620813040};\\\", \\\"{x:673,y:737,t:1527620813080};\\\", \\\"{x:674,y:737,t:1527620813193};\\\", \\\"{x:675,y:737,t:1527620813657};\\\", \\\"{x:676,y:737,t:1527620813681};\\\", \\\"{x:677,y:737,t:1527620813729};\\\", \\\"{x:679,y:737,t:1527620813801};\\\", \\\"{x:680,y:737,t:1527620813929};\\\", \\\"{x:682,y:738,t:1527620814025};\\\", \\\"{x:683,y:738,t:1527620814064};\\\", \\\"{x:684,y:738,t:1527620814096};\\\", \\\"{x:685,y:738,t:1527620814121};\\\", \\\"{x:686,y:738,t:1527620814153};\\\", \\\"{x:687,y:738,t:1527620814201};\\\", \\\"{x:688,y:738,t:1527620814217};\\\", \\\"{x:690,y:740,t:1527620814234};\\\", \\\"{x:691,y:740,t:1527620814257};\\\", \\\"{x:692,y:740,t:1527620814273};\\\", \\\"{x:693,y:740,t:1527620814289};\\\", \\\"{x:694,y:740,t:1527620814345};\\\", \\\"{x:695,y:740,t:1527620814352};\\\", \\\"{x:696,y:740,t:1527620814385};\\\", \\\"{x:697,y:741,t:1527620814409};\\\", \\\"{x:698,y:741,t:1527620814441};\\\", \\\"{x:699,y:741,t:1527620814456};\\\", \\\"{x:699,y:742,t:1527620814472};\\\", \\\"{x:700,y:742,t:1527620814497};\\\", \\\"{x:701,y:742,t:1527620814513};\\\", \\\"{x:702,y:742,t:1527620814529};\\\", \\\"{x:703,y:742,t:1527620814545};\\\", \\\"{x:703,y:743,t:1527620814568};\\\", \\\"{x:705,y:743,t:1527620814585};\\\", \\\"{x:707,y:743,t:1527620814608};\\\", \\\"{x:708,y:743,t:1527620814625};\\\", \\\"{x:709,y:743,t:1527620814641};\\\", \\\"{x:710,y:743,t:1527620814651};\\\", \\\"{x:715,y:743,t:1527620814668};\\\", \\\"{x:723,y:743,t:1527620814685};\\\", \\\"{x:737,y:743,t:1527620814701};\\\", \\\"{x:759,y:743,t:1527620814718};\\\", \\\"{x:787,y:743,t:1527620814735};\\\", \\\"{x:833,y:743,t:1527620814751};\\\", \\\"{x:906,y:743,t:1527620814768};\\\", \\\"{x:1009,y:743,t:1527620814785};\\\", \\\"{x:1060,y:745,t:1527620814801};\\\", \\\"{x:1099,y:750,t:1527620814819};\\\", \\\"{x:1120,y:754,t:1527620814836};\\\", \\\"{x:1126,y:756,t:1527620814851};\\\", \\\"{x:1131,y:760,t:1527620814868};\\\", \\\"{x:1135,y:766,t:1527620814886};\\\", \\\"{x:1137,y:772,t:1527620814901};\\\", \\\"{x:1140,y:778,t:1527620814918};\\\", \\\"{x:1148,y:786,t:1527620814934};\\\", \\\"{x:1161,y:796,t:1527620814950};\\\", \\\"{x:1182,y:808,t:1527620814967};\\\", \\\"{x:1214,y:825,t:1527620814985};\\\", \\\"{x:1228,y:830,t:1527620815001};\\\", \\\"{x:1238,y:835,t:1527620815017};\\\", \\\"{x:1242,y:837,t:1527620815035};\\\", \\\"{x:1243,y:838,t:1527620815050};\\\", \\\"{x:1245,y:838,t:1527620815068};\\\", \\\"{x:1247,y:840,t:1527620815085};\\\", \\\"{x:1246,y:842,t:1527620815209};\\\", \\\"{x:1245,y:842,t:1527620815219};\\\", \\\"{x:1242,y:842,t:1527620815235};\\\", \\\"{x:1239,y:843,t:1527620815252};\\\", \\\"{x:1233,y:844,t:1527620815269};\\\", \\\"{x:1229,y:844,t:1527620815285};\\\", \\\"{x:1226,y:844,t:1527620815302};\\\", \\\"{x:1224,y:843,t:1527620815317};\\\", \\\"{x:1222,y:843,t:1527620815334};\\\", \\\"{x:1221,y:842,t:1527620815352};\\\", \\\"{x:1220,y:841,t:1527620815368};\\\", \\\"{x:1218,y:840,t:1527620815385};\\\", \\\"{x:1217,y:840,t:1527620815402};\\\", \\\"{x:1216,y:840,t:1527620815418};\\\", \\\"{x:1215,y:838,t:1527620815435};\\\", \\\"{x:1214,y:837,t:1527620815452};\\\", \\\"{x:1213,y:836,t:1527620815490};\\\", \\\"{x:1213,y:835,t:1527620815502};\\\", \\\"{x:1212,y:833,t:1527620815561};\\\", \\\"{x:1213,y:833,t:1527620816065};\\\", \\\"{x:1214,y:833,t:1527620816073};\\\", \\\"{x:1216,y:833,t:1527620816090};\\\", \\\"{x:1217,y:833,t:1527620816104};\\\", \\\"{x:1218,y:833,t:1527620816119};\\\", \\\"{x:1219,y:834,t:1527620816137};\\\", \\\"{x:1220,y:834,t:1527620816152};\\\", \\\"{x:1222,y:834,t:1527620816169};\\\", \\\"{x:1225,y:834,t:1527620816186};\\\", \\\"{x:1227,y:834,t:1527620816209};\\\", \\\"{x:1228,y:834,t:1527620816233};\\\", \\\"{x:1230,y:834,t:1527620816257};\\\", \\\"{x:1228,y:833,t:1527620816617};\\\", \\\"{x:1227,y:833,t:1527620816649};\\\", \\\"{x:1226,y:833,t:1527620816665};\\\", \\\"{x:1225,y:833,t:1527620816680};\\\", \\\"{x:1224,y:833,t:1527620816889};\\\", \\\"{x:1224,y:834,t:1527620816961};\\\", \\\"{x:1223,y:833,t:1527620818001};\\\", \\\"{x:1222,y:833,t:1527620818065};\\\", \\\"{x:1221,y:833,t:1527620818081};\\\", \\\"{x:1220,y:833,t:1527620818112};\\\", \\\"{x:1219,y:831,t:1527620818128};\\\", \\\"{x:1218,y:831,t:1527620818154};\\\", \\\"{x:1217,y:831,t:1527620818170};\\\", \\\"{x:1216,y:831,t:1527620818201};\\\", \\\"{x:1215,y:832,t:1527620819328};\\\", \\\"{x:1215,y:834,t:1527620819338};\\\", \\\"{x:1215,y:836,t:1527620819355};\\\", \\\"{x:1215,y:837,t:1527620819371};\\\", \\\"{x:1215,y:838,t:1527620819424};\\\", \\\"{x:1216,y:837,t:1527620819448};\\\", \\\"{x:1216,y:835,t:1527620819456};\\\", \\\"{x:1216,y:834,t:1527620819471};\\\", \\\"{x:1220,y:827,t:1527620819489};\\\", \\\"{x:1221,y:825,t:1527620819505};\\\", \\\"{x:1225,y:822,t:1527620819521};\\\", \\\"{x:1226,y:822,t:1527620819553};\\\", \\\"{x:1227,y:822,t:1527620819569};\\\", \\\"{x:1228,y:822,t:1527620819577};\\\", \\\"{x:1229,y:822,t:1527620819609};\\\", \\\"{x:1230,y:822,t:1527620819633};\\\", \\\"{x:1231,y:822,t:1527620819641};\\\", \\\"{x:1232,y:822,t:1527620819657};\\\", \\\"{x:1234,y:822,t:1527620819672};\\\", \\\"{x:1238,y:822,t:1527620819689};\\\", \\\"{x:1241,y:822,t:1527620819706};\\\", \\\"{x:1244,y:822,t:1527620819722};\\\", \\\"{x:1245,y:822,t:1527620819744};\\\", \\\"{x:1247,y:822,t:1527620819761};\\\", \\\"{x:1248,y:822,t:1527620819772};\\\", \\\"{x:1251,y:822,t:1527620819788};\\\", \\\"{x:1254,y:822,t:1527620819805};\\\", \\\"{x:1255,y:822,t:1527620819822};\\\", \\\"{x:1258,y:822,t:1527620819838};\\\", \\\"{x:1259,y:822,t:1527620819855};\\\", \\\"{x:1261,y:822,t:1527620819872};\\\", \\\"{x:1263,y:822,t:1527620819890};\\\", \\\"{x:1265,y:822,t:1527620819905};\\\", \\\"{x:1267,y:822,t:1527620819922};\\\", \\\"{x:1271,y:823,t:1527620819938};\\\", \\\"{x:1274,y:824,t:1527620819955};\\\", \\\"{x:1275,y:825,t:1527620819973};\\\", \\\"{x:1277,y:826,t:1527620819990};\\\", \\\"{x:1277,y:827,t:1527620820005};\\\", \\\"{x:1278,y:827,t:1527620820022};\\\", \\\"{x:1280,y:828,t:1527620820040};\\\", \\\"{x:1281,y:829,t:1527620820057};\\\", \\\"{x:1281,y:830,t:1527620820090};\\\", \\\"{x:1282,y:832,t:1527620820106};\\\", \\\"{x:1282,y:833,t:1527620820137};\\\", \\\"{x:1282,y:834,t:1527620820160};\\\", \\\"{x:1283,y:835,t:1527620820401};\\\", \\\"{x:1283,y:836,t:1527620820434};\\\", \\\"{x:1282,y:836,t:1527620820553};\\\", \\\"{x:1281,y:836,t:1527620820768};\\\", \\\"{x:1280,y:836,t:1527620820784};\\\", \\\"{x:1280,y:835,t:1527620824160};\\\", \\\"{x:1281,y:834,t:1527620824480};\\\", \\\"{x:1280,y:834,t:1527620827994};\\\", \\\"{x:1279,y:834,t:1527620828008};\\\", \\\"{x:1278,y:834,t:1527620828016};\\\", \\\"{x:1277,y:834,t:1527620828033};\\\", \\\"{x:1276,y:834,t:1527620828082};\\\", \\\"{x:1276,y:833,t:1527620828096};\\\", \\\"{x:1275,y:833,t:1527620828112};\\\", \\\"{x:1274,y:833,t:1527620828321};\\\", \\\"{x:1273,y:833,t:1527620828328};\\\", \\\"{x:1269,y:833,t:1527620828345};\\\", \\\"{x:1257,y:833,t:1527620828362};\\\", \\\"{x:1238,y:833,t:1527620828379};\\\", \\\"{x:1216,y:832,t:1527620828396};\\\", \\\"{x:1189,y:830,t:1527620828413};\\\", \\\"{x:1158,y:824,t:1527620828429};\\\", \\\"{x:1057,y:806,t:1527620828446};\\\", \\\"{x:928,y:774,t:1527620828462};\\\", \\\"{x:788,y:744,t:1527620828478};\\\", \\\"{x:639,y:709,t:1527620828496};\\\", \\\"{x:460,y:676,t:1527620828512};\\\", \\\"{x:365,y:663,t:1527620828529};\\\", \\\"{x:298,y:652,t:1527620828546};\\\", \\\"{x:242,y:646,t:1527620828563};\\\", \\\"{x:197,y:639,t:1527620828578};\\\", \\\"{x:168,y:635,t:1527620828595};\\\", \\\"{x:147,y:631,t:1527620828613};\\\", \\\"{x:131,y:626,t:1527620828629};\\\", \\\"{x:114,y:620,t:1527620828645};\\\", \\\"{x:95,y:612,t:1527620828663};\\\", \\\"{x:83,y:605,t:1527620828680};\\\", \\\"{x:77,y:600,t:1527620828695};\\\", \\\"{x:65,y:592,t:1527620828712};\\\", \\\"{x:63,y:590,t:1527620828730};\\\", \\\"{x:63,y:587,t:1527620828747};\\\", \\\"{x:63,y:585,t:1527620828762};\\\", \\\"{x:63,y:581,t:1527620828780};\\\", \\\"{x:63,y:580,t:1527620828796};\\\", \\\"{x:63,y:578,t:1527620828812};\\\", \\\"{x:68,y:575,t:1527620828830};\\\", \\\"{x:79,y:574,t:1527620828846};\\\", \\\"{x:97,y:573,t:1527620828862};\\\", \\\"{x:113,y:573,t:1527620828879};\\\", \\\"{x:128,y:573,t:1527620828895};\\\", \\\"{x:162,y:573,t:1527620828912};\\\", \\\"{x:185,y:573,t:1527620828930};\\\", \\\"{x:204,y:573,t:1527620828945};\\\", \\\"{x:215,y:573,t:1527620828963};\\\", \\\"{x:223,y:573,t:1527620828979};\\\", \\\"{x:226,y:573,t:1527620828996};\\\", \\\"{x:228,y:573,t:1527620829013};\\\", \\\"{x:231,y:573,t:1527620829030};\\\", \\\"{x:235,y:573,t:1527620829046};\\\", \\\"{x:241,y:573,t:1527620829062};\\\", \\\"{x:253,y:575,t:1527620829081};\\\", \\\"{x:266,y:578,t:1527620829096};\\\", \\\"{x:269,y:579,t:1527620829113};\\\", \\\"{x:271,y:579,t:1527620829130};\\\", \\\"{x:272,y:580,t:1527620829147};\\\", \\\"{x:274,y:580,t:1527620829163};\\\", \\\"{x:278,y:581,t:1527620829180};\\\", \\\"{x:289,y:585,t:1527620829198};\\\", \\\"{x:300,y:588,t:1527620829213};\\\", \\\"{x:312,y:590,t:1527620829229};\\\", \\\"{x:326,y:593,t:1527620829246};\\\", \\\"{x:347,y:599,t:1527620829262};\\\", \\\"{x:381,y:608,t:1527620829280};\\\", \\\"{x:453,y:620,t:1527620829296};\\\", \\\"{x:487,y:623,t:1527620829312};\\\", \\\"{x:509,y:627,t:1527620829330};\\\", \\\"{x:523,y:629,t:1527620829346};\\\", \\\"{x:540,y:632,t:1527620829363};\\\", \\\"{x:553,y:632,t:1527620829380};\\\", \\\"{x:561,y:632,t:1527620829396};\\\", \\\"{x:565,y:632,t:1527620829413};\\\", \\\"{x:567,y:632,t:1527620829429};\\\", \\\"{x:569,y:632,t:1527620829446};\\\", \\\"{x:570,y:632,t:1527620829472};\\\", \\\"{x:572,y:632,t:1527620829479};\\\", \\\"{x:575,y:632,t:1527620829496};\\\", \\\"{x:579,y:631,t:1527620829514};\\\", \\\"{x:580,y:631,t:1527620829530};\\\", \\\"{x:581,y:630,t:1527620829585};\\\", \\\"{x:581,y:629,t:1527620829600};\\\", \\\"{x:574,y:625,t:1527620829614};\\\", \\\"{x:545,y:616,t:1527620829632};\\\", \\\"{x:509,y:606,t:1527620829648};\\\", \\\"{x:488,y:600,t:1527620829664};\\\", \\\"{x:472,y:594,t:1527620829680};\\\", \\\"{x:467,y:589,t:1527620829696};\\\", \\\"{x:462,y:583,t:1527620829713};\\\", \\\"{x:449,y:572,t:1527620829729};\\\", \\\"{x:429,y:560,t:1527620829746};\\\", \\\"{x:413,y:553,t:1527620829764};\\\", \\\"{x:406,y:549,t:1527620829779};\\\", \\\"{x:405,y:547,t:1527620829796};\\\", \\\"{x:405,y:544,t:1527620829813};\\\", \\\"{x:405,y:543,t:1527620829830};\\\", \\\"{x:402,y:539,t:1527620829847};\\\", \\\"{x:402,y:537,t:1527620829863};\\\", \\\"{x:401,y:533,t:1527620829881};\\\", \\\"{x:399,y:531,t:1527620829896};\\\", \\\"{x:399,y:530,t:1527620829914};\\\", \\\"{x:398,y:529,t:1527620829930};\\\", \\\"{x:397,y:529,t:1527620829952};\\\", \\\"{x:396,y:528,t:1527620829963};\\\", \\\"{x:395,y:526,t:1527620829981};\\\", \\\"{x:394,y:526,t:1527620829997};\\\", \\\"{x:394,y:525,t:1527620830013};\\\", \\\"{x:393,y:524,t:1527620830032};\\\", \\\"{x:397,y:524,t:1527620830473};\\\", \\\"{x:404,y:525,t:1527620830481};\\\", \\\"{x:419,y:529,t:1527620830498};\\\", \\\"{x:438,y:535,t:1527620830513};\\\", \\\"{x:455,y:538,t:1527620830531};\\\", \\\"{x:469,y:542,t:1527620830547};\\\", \\\"{x:478,y:545,t:1527620830564};\\\", \\\"{x:487,y:547,t:1527620830581};\\\", \\\"{x:498,y:550,t:1527620830598};\\\", \\\"{x:506,y:552,t:1527620830614};\\\", \\\"{x:511,y:554,t:1527620830630};\\\", \\\"{x:515,y:555,t:1527620830648};\\\", \\\"{x:519,y:558,t:1527620830663};\\\", \\\"{x:524,y:559,t:1527620830680};\\\", \\\"{x:531,y:563,t:1527620830698};\\\", \\\"{x:536,y:565,t:1527620830713};\\\", \\\"{x:540,y:566,t:1527620830731};\\\", \\\"{x:544,y:569,t:1527620830747};\\\", \\\"{x:547,y:571,t:1527620830765};\\\", \\\"{x:553,y:574,t:1527620830780};\\\", \\\"{x:556,y:575,t:1527620830798};\\\", \\\"{x:558,y:576,t:1527620830814};\\\", \\\"{x:560,y:577,t:1527620830830};\\\", \\\"{x:563,y:578,t:1527620830848};\\\", \\\"{x:564,y:579,t:1527620830865};\\\", \\\"{x:566,y:581,t:1527620830880};\\\", \\\"{x:567,y:581,t:1527620830897};\\\", \\\"{x:568,y:583,t:1527620830915};\\\", \\\"{x:569,y:583,t:1527620830931};\\\", \\\"{x:570,y:584,t:1527620830953};\\\", \\\"{x:570,y:585,t:1527620831025};\\\", \\\"{x:570,y:586,t:1527620831057};\\\", \\\"{x:570,y:587,t:1527620831081};\\\", \\\"{x:570,y:588,t:1527620831097};\\\", \\\"{x:571,y:589,t:1527620831115};\\\", \\\"{x:571,y:590,t:1527620831144};\\\", \\\"{x:571,y:591,t:1527620831153};\\\", \\\"{x:571,y:592,t:1527620831177};\\\", \\\"{x:571,y:593,t:1527620831216};\\\", \\\"{x:571,y:594,t:1527620831232};\\\", \\\"{x:571,y:595,t:1527620831248};\\\", \\\"{x:571,y:596,t:1527620831264};\\\", \\\"{x:571,y:598,t:1527620831281};\\\", \\\"{x:571,y:599,t:1527620831305};\\\", \\\"{x:571,y:600,t:1527620831321};\\\", \\\"{x:571,y:601,t:1527620831352};\\\", \\\"{x:571,y:602,t:1527620831368};\\\", \\\"{x:571,y:603,t:1527620831382};\\\", \\\"{x:571,y:604,t:1527620831397};\\\", \\\"{x:570,y:606,t:1527620831415};\\\", \\\"{x:570,y:607,t:1527620831433};\\\", \\\"{x:569,y:608,t:1527620831448};\\\", \\\"{x:569,y:609,t:1527620831481};\\\", \\\"{x:569,y:610,t:1527620831497};\\\", \\\"{x:569,y:612,t:1527620831544};\\\", \\\"{x:569,y:613,t:1527620831624};\\\", \\\"{x:569,y:616,t:1527620831664};\\\", \\\"{x:569,y:617,t:1527620831696};\\\", \\\"{x:569,y:618,t:1527620831711};\\\", \\\"{x:569,y:619,t:1527620831720};\\\", \\\"{x:569,y:620,t:1527620831760};\\\", \\\"{x:569,y:621,t:1527620831799};\\\", \\\"{x:569,y:622,t:1527620831824};\\\", \\\"{x:569,y:624,t:1527620831847};\\\", \\\"{x:569,y:625,t:1527620831872};\\\", \\\"{x:570,y:627,t:1527620831912};\\\", \\\"{x:570,y:628,t:1527620831953};\\\", \\\"{x:571,y:629,t:1527620831984};\\\", \\\"{x:571,y:630,t:1527620832008};\\\", \\\"{x:573,y:630,t:1527620832049};\\\", \\\"{x:573,y:631,t:1527620832081};\\\", \\\"{x:574,y:631,t:1527620832105};\\\", \\\"{x:575,y:632,t:1527620832152};\\\", \\\"{x:575,y:633,t:1527620832185};\\\", \\\"{x:576,y:633,t:1527620832201};\\\", \\\"{x:577,y:633,t:1527620832216};\\\", \\\"{x:578,y:633,t:1527620832232};\\\", \\\"{x:581,y:633,t:1527620832249};\\\", \\\"{x:584,y:633,t:1527620832265};\\\", \\\"{x:587,y:633,t:1527620832282};\\\", \\\"{x:591,y:633,t:1527620832299};\\\", \\\"{x:595,y:630,t:1527620832316};\\\", \\\"{x:605,y:625,t:1527620832333};\\\", \\\"{x:609,y:620,t:1527620832348};\\\", \\\"{x:615,y:613,t:1527620832366};\\\", \\\"{x:619,y:607,t:1527620832382};\\\", \\\"{x:623,y:601,t:1527620832398};\\\", \\\"{x:627,y:595,t:1527620832415};\\\", \\\"{x:631,y:584,t:1527620832432};\\\", \\\"{x:634,y:578,t:1527620832449};\\\", \\\"{x:638,y:568,t:1527620832466};\\\", \\\"{x:646,y:560,t:1527620832483};\\\", \\\"{x:656,y:552,t:1527620832498};\\\", \\\"{x:668,y:545,t:1527620832515};\\\", \\\"{x:684,y:538,t:1527620832533};\\\", \\\"{x:697,y:533,t:1527620832549};\\\", \\\"{x:711,y:529,t:1527620832566};\\\", \\\"{x:721,y:526,t:1527620832582};\\\", \\\"{x:724,y:524,t:1527620832599};\\\", \\\"{x:725,y:524,t:1527620832616};\\\", \\\"{x:727,y:523,t:1527620832633};\\\", \\\"{x:730,y:523,t:1527620832649};\\\", \\\"{x:734,y:523,t:1527620832666};\\\", \\\"{x:744,y:524,t:1527620832682};\\\", \\\"{x:748,y:524,t:1527620832699};\\\", \\\"{x:755,y:524,t:1527620832716};\\\", \\\"{x:762,y:526,t:1527620832731};\\\", \\\"{x:768,y:526,t:1527620832749};\\\", \\\"{x:774,y:526,t:1527620832765};\\\", \\\"{x:777,y:526,t:1527620832782};\\\", \\\"{x:781,y:526,t:1527620832799};\\\", \\\"{x:784,y:526,t:1527620832815};\\\", \\\"{x:785,y:526,t:1527620832831};\\\", \\\"{x:788,y:526,t:1527620832848};\\\", \\\"{x:791,y:526,t:1527620832866};\\\", \\\"{x:794,y:526,t:1527620832882};\\\", \\\"{x:796,y:527,t:1527620832899};\\\", \\\"{x:798,y:527,t:1527620832916};\\\", \\\"{x:801,y:527,t:1527620832932};\\\", \\\"{x:802,y:527,t:1527620832949};\\\", \\\"{x:805,y:526,t:1527620832966};\\\", \\\"{x:808,y:526,t:1527620832982};\\\", \\\"{x:812,y:526,t:1527620832999};\\\", \\\"{x:816,y:525,t:1527620833016};\\\", \\\"{x:818,y:525,t:1527620833032};\\\", \\\"{x:819,y:524,t:1527620833049};\\\", \\\"{x:820,y:523,t:1527620833065};\\\", \\\"{x:821,y:523,t:1527620833090};\\\", \\\"{x:822,y:523,t:1527620833208};\\\", \\\"{x:824,y:523,t:1527620833216};\\\", \\\"{x:825,y:523,t:1527620833232};\\\", \\\"{x:820,y:523,t:1527620833433};\\\", \\\"{x:802,y:523,t:1527620833449};\\\", \\\"{x:789,y:523,t:1527620833467};\\\", \\\"{x:782,y:523,t:1527620833482};\\\", \\\"{x:780,y:523,t:1527620833499};\\\", \\\"{x:776,y:523,t:1527620833517};\\\", \\\"{x:769,y:523,t:1527620833532};\\\", \\\"{x:763,y:523,t:1527620833550};\\\", \\\"{x:760,y:523,t:1527620833567};\\\", \\\"{x:762,y:523,t:1527620833632};\\\", \\\"{x:768,y:523,t:1527620833650};\\\", \\\"{x:790,y:523,t:1527620833667};\\\", \\\"{x:820,y:523,t:1527620833682};\\\", \\\"{x:846,y:523,t:1527620833701};\\\", \\\"{x:855,y:523,t:1527620833716};\\\", \\\"{x:857,y:523,t:1527620833733};\\\", \\\"{x:858,y:523,t:1527620833775};\\\", \\\"{x:860,y:523,t:1527620833808};\\\", \\\"{x:859,y:523,t:1527620833944};\\\", \\\"{x:858,y:523,t:1527620833952};\\\", \\\"{x:857,y:523,t:1527620833967};\\\", \\\"{x:851,y:523,t:1527620833984};\\\", \\\"{x:850,y:524,t:1527620834000};\\\", \\\"{x:846,y:524,t:1527620834016};\\\", \\\"{x:843,y:525,t:1527620834034};\\\", \\\"{x:839,y:525,t:1527620834050};\\\", \\\"{x:836,y:525,t:1527620834067};\\\", \\\"{x:831,y:525,t:1527620834084};\\\", \\\"{x:826,y:527,t:1527620834099};\\\", \\\"{x:822,y:527,t:1527620834117};\\\", \\\"{x:819,y:527,t:1527620834134};\\\", \\\"{x:812,y:528,t:1527620834150};\\\", \\\"{x:807,y:529,t:1527620834167};\\\", \\\"{x:801,y:530,t:1527620834184};\\\", \\\"{x:798,y:532,t:1527620834200};\\\", \\\"{x:791,y:535,t:1527620834217};\\\", \\\"{x:783,y:537,t:1527620834235};\\\", \\\"{x:773,y:541,t:1527620834251};\\\", \\\"{x:764,y:544,t:1527620834267};\\\", \\\"{x:761,y:545,t:1527620834284};\\\", \\\"{x:760,y:545,t:1527620834312};\\\", \\\"{x:759,y:545,t:1527620834320};\\\", \\\"{x:756,y:546,t:1527620834334};\\\", \\\"{x:749,y:548,t:1527620834351};\\\", \\\"{x:743,y:549,t:1527620834367};\\\", \\\"{x:738,y:549,t:1527620834384};\\\", \\\"{x:735,y:549,t:1527620834400};\\\", \\\"{x:732,y:549,t:1527620834417};\\\", \\\"{x:727,y:549,t:1527620834434};\\\", \\\"{x:720,y:549,t:1527620834452};\\\", \\\"{x:712,y:549,t:1527620834467};\\\", \\\"{x:700,y:549,t:1527620834484};\\\", \\\"{x:689,y:547,t:1527620834500};\\\", \\\"{x:682,y:547,t:1527620834517};\\\", \\\"{x:675,y:544,t:1527620834534};\\\", \\\"{x:673,y:543,t:1527620834552};\\\", \\\"{x:671,y:543,t:1527620834567};\\\", \\\"{x:663,y:542,t:1527620834585};\\\", \\\"{x:652,y:540,t:1527620834601};\\\", \\\"{x:644,y:539,t:1527620834618};\\\", \\\"{x:638,y:538,t:1527620834634};\\\", \\\"{x:635,y:536,t:1527620834652};\\\", \\\"{x:634,y:535,t:1527620834667};\\\", \\\"{x:629,y:532,t:1527620834684};\\\", \\\"{x:627,y:531,t:1527620834701};\\\", \\\"{x:624,y:529,t:1527620834719};\\\", \\\"{x:620,y:526,t:1527620834735};\\\", \\\"{x:618,y:525,t:1527620834751};\\\", \\\"{x:617,y:524,t:1527620834768};\\\", \\\"{x:617,y:523,t:1527620834792};\\\", \\\"{x:616,y:523,t:1527620834911};\\\", \\\"{x:616,y:523,t:1527620834916};\\\", \\\"{x:614,y:523,t:1527620834992};\\\", \\\"{x:612,y:523,t:1527620835000};\\\", \\\"{x:607,y:525,t:1527620835018};\\\", \\\"{x:602,y:525,t:1527620835034};\\\", \\\"{x:595,y:527,t:1527620835050};\\\", \\\"{x:586,y:530,t:1527620835067};\\\", \\\"{x:574,y:533,t:1527620835085};\\\", \\\"{x:561,y:537,t:1527620835101};\\\", \\\"{x:547,y:541,t:1527620835118};\\\", \\\"{x:531,y:543,t:1527620835134};\\\", \\\"{x:522,y:547,t:1527620835151};\\\", \\\"{x:502,y:553,t:1527620835168};\\\", \\\"{x:483,y:558,t:1527620835185};\\\", \\\"{x:457,y:564,t:1527620835201};\\\", \\\"{x:429,y:570,t:1527620835218};\\\", \\\"{x:403,y:575,t:1527620835235};\\\", \\\"{x:377,y:581,t:1527620835250};\\\", \\\"{x:352,y:586,t:1527620835269};\\\", \\\"{x:330,y:591,t:1527620835285};\\\", \\\"{x:309,y:594,t:1527620835301};\\\", \\\"{x:298,y:595,t:1527620835318};\\\", \\\"{x:285,y:596,t:1527620835335};\\\", \\\"{x:276,y:597,t:1527620835351};\\\", \\\"{x:268,y:597,t:1527620835370};\\\", \\\"{x:264,y:597,t:1527620835385};\\\", \\\"{x:261,y:597,t:1527620835400};\\\", \\\"{x:258,y:598,t:1527620835417};\\\", \\\"{x:251,y:600,t:1527620835435};\\\", \\\"{x:245,y:603,t:1527620835452};\\\", \\\"{x:236,y:606,t:1527620835468};\\\", \\\"{x:228,y:609,t:1527620835485};\\\", \\\"{x:219,y:610,t:1527620835502};\\\", \\\"{x:210,y:614,t:1527620835519};\\\", \\\"{x:201,y:615,t:1527620835535};\\\", \\\"{x:197,y:616,t:1527620835550};\\\", \\\"{x:194,y:618,t:1527620835568};\\\", \\\"{x:192,y:618,t:1527620835584};\\\", \\\"{x:187,y:618,t:1527620835601};\\\", \\\"{x:183,y:618,t:1527620835618};\\\", \\\"{x:181,y:618,t:1527620835635};\\\", \\\"{x:180,y:618,t:1527620835657};\\\", \\\"{x:187,y:616,t:1527620835672};\\\", \\\"{x:205,y:611,t:1527620835686};\\\", \\\"{x:252,y:607,t:1527620835701};\\\", \\\"{x:295,y:602,t:1527620835718};\\\", \\\"{x:324,y:602,t:1527620835734};\\\", \\\"{x:352,y:602,t:1527620835752};\\\", \\\"{x:362,y:602,t:1527620835768};\\\", \\\"{x:365,y:602,t:1527620835784};\\\", \\\"{x:366,y:602,t:1527620835802};\\\", \\\"{x:368,y:604,t:1527620835818};\\\", \\\"{x:369,y:607,t:1527620835835};\\\", \\\"{x:371,y:612,t:1527620835851};\\\", \\\"{x:375,y:617,t:1527620835868};\\\", \\\"{x:380,y:619,t:1527620835884};\\\", \\\"{x:384,y:621,t:1527620835902};\\\", \\\"{x:390,y:621,t:1527620835917};\\\", \\\"{x:410,y:621,t:1527620835935};\\\", \\\"{x:453,y:621,t:1527620835952};\\\", \\\"{x:476,y:623,t:1527620835968};\\\", \\\"{x:499,y:626,t:1527620835986};\\\", \\\"{x:506,y:625,t:1527620836001};\\\", \\\"{x:514,y:624,t:1527620836018};\\\", \\\"{x:516,y:623,t:1527620836034};\\\", \\\"{x:522,y:623,t:1527620836052};\\\", \\\"{x:527,y:621,t:1527620836068};\\\", \\\"{x:531,y:621,t:1527620836085};\\\", \\\"{x:538,y:620,t:1527620836102};\\\", \\\"{x:547,y:620,t:1527620836119};\\\", \\\"{x:561,y:620,t:1527620836135};\\\", \\\"{x:583,y:620,t:1527620836152};\\\", \\\"{x:597,y:620,t:1527620836168};\\\", \\\"{x:612,y:620,t:1527620836185};\\\", \\\"{x:626,y:620,t:1527620836202};\\\", \\\"{x:643,y:620,t:1527620836219};\\\", \\\"{x:655,y:620,t:1527620836235};\\\", \\\"{x:657,y:620,t:1527620836252};\\\", \\\"{x:657,y:619,t:1527620836270};\\\", \\\"{x:657,y:618,t:1527620836296};\\\", \\\"{x:656,y:618,t:1527620836319};\\\", \\\"{x:652,y:618,t:1527620836335};\\\", \\\"{x:611,y:618,t:1527620836351};\\\", \\\"{x:554,y:615,t:1527620836368};\\\", \\\"{x:470,y:602,t:1527620836385};\\\", \\\"{x:384,y:589,t:1527620836402};\\\", \\\"{x:302,y:574,t:1527620836419};\\\", \\\"{x:243,y:564,t:1527620836436};\\\", \\\"{x:205,y:556,t:1527620836451};\\\", \\\"{x:184,y:550,t:1527620836469};\\\", \\\"{x:163,y:544,t:1527620836485};\\\", \\\"{x:142,y:539,t:1527620836502};\\\", \\\"{x:124,y:535,t:1527620836520};\\\", \\\"{x:95,y:533,t:1527620836535};\\\", \\\"{x:90,y:533,t:1527620836552};\\\", \\\"{x:91,y:533,t:1527620836648};\\\", \\\"{x:93,y:535,t:1527620836664};\\\", \\\"{x:97,y:536,t:1527620836672};\\\", \\\"{x:100,y:539,t:1527620836687};\\\", \\\"{x:110,y:544,t:1527620836703};\\\", \\\"{x:119,y:547,t:1527620836719};\\\", \\\"{x:129,y:550,t:1527620836734};\\\", \\\"{x:140,y:553,t:1527620836751};\\\", \\\"{x:145,y:554,t:1527620836768};\\\", \\\"{x:147,y:555,t:1527620836785};\\\", \\\"{x:148,y:556,t:1527620836801};\\\", \\\"{x:150,y:556,t:1527620836819};\\\", \\\"{x:151,y:557,t:1527620836835};\\\", \\\"{x:152,y:558,t:1527620836852};\\\", \\\"{x:153,y:559,t:1527620836869};\\\", \\\"{x:154,y:559,t:1527620837039};\\\", \\\"{x:154,y:560,t:1527620837080};\\\", \\\"{x:154,y:561,t:1527620837088};\\\", \\\"{x:154,y:562,t:1527620837103};\\\", \\\"{x:154,y:564,t:1527620837119};\\\", \\\"{x:154,y:571,t:1527620837136};\\\", \\\"{x:154,y:577,t:1527620837154};\\\", \\\"{x:155,y:584,t:1527620837170};\\\", \\\"{x:159,y:592,t:1527620837186};\\\", \\\"{x:162,y:599,t:1527620837203};\\\", \\\"{x:164,y:606,t:1527620837219};\\\", \\\"{x:165,y:614,t:1527620837237};\\\", \\\"{x:168,y:623,t:1527620837253};\\\", \\\"{x:169,y:631,t:1527620837270};\\\", \\\"{x:174,y:641,t:1527620837286};\\\", \\\"{x:177,y:649,t:1527620837303};\\\", \\\"{x:186,y:663,t:1527620837320};\\\", \\\"{x:192,y:675,t:1527620837336};\\\", \\\"{x:196,y:682,t:1527620837353};\\\", \\\"{x:201,y:694,t:1527620837369};\\\", \\\"{x:209,y:706,t:1527620837386};\\\", \\\"{x:217,y:720,t:1527620837403};\\\", \\\"{x:223,y:730,t:1527620837420};\\\", \\\"{x:227,y:740,t:1527620837436};\\\", \\\"{x:232,y:748,t:1527620837453};\\\", \\\"{x:240,y:760,t:1527620837470};\\\", \\\"{x:244,y:766,t:1527620837486};\\\", \\\"{x:247,y:771,t:1527620837503};\\\", \\\"{x:251,y:776,t:1527620837521};\\\", \\\"{x:253,y:778,t:1527620837541};\\\", \\\"{x:254,y:781,t:1527620837552};\\\", \\\"{x:255,y:783,t:1527620837570};\\\", \\\"{x:258,y:785,t:1527620837585};\\\", \\\"{x:260,y:788,t:1527620837603};\\\", \\\"{x:261,y:789,t:1527620837620};\\\", \\\"{x:264,y:792,t:1527620837635};\\\", \\\"{x:265,y:793,t:1527620837655};\\\", \\\"{x:265,y:794,t:1527620837696};\\\", \\\"{x:266,y:794,t:1527620837712};\\\", \\\"{x:266,y:795,t:1527620837720};\\\", \\\"{x:268,y:797,t:1527620837735};\\\", \\\"{x:269,y:798,t:1527620837753};\\\", \\\"{x:271,y:800,t:1527620837770};\\\", \\\"{x:274,y:801,t:1527620837786};\\\", \\\"{x:275,y:802,t:1527620837803};\\\", \\\"{x:278,y:802,t:1527620837820};\\\", \\\"{x:286,y:803,t:1527620837836};\\\", \\\"{x:298,y:803,t:1527620837853};\\\", \\\"{x:320,y:805,t:1527620837871};\\\", \\\"{x:353,y:805,t:1527620837887};\\\", \\\"{x:415,y:805,t:1527620837904};\\\", \\\"{x:525,y:812,t:1527620837921};\\\", \\\"{x:656,y:818,t:1527620837936};\\\", \\\"{x:820,y:823,t:1527620837953};\\\", \\\"{x:961,y:823,t:1527620837971};\\\", \\\"{x:1069,y:823,t:1527620837987};\\\", \\\"{x:1141,y:823,t:1527620838003};\\\", \\\"{x:1174,y:824,t:1527620838020};\\\", \\\"{x:1187,y:826,t:1527620838038};\\\", \\\"{x:1189,y:826,t:1527620838053};\\\", \\\"{x:1191,y:829,t:1527620838071};\\\", \\\"{x:1194,y:838,t:1527620838088};\\\", \\\"{x:1200,y:858,t:1527620838103};\\\", \\\"{x:1211,y:888,t:1527620838121};\\\", \\\"{x:1217,y:897,t:1527620838137};\\\", \\\"{x:1223,y:904,t:1527620838153};\\\", \\\"{x:1238,y:911,t:1527620838171};\\\", \\\"{x:1264,y:914,t:1527620838187};\\\", \\\"{x:1302,y:914,t:1527620838203};\\\", \\\"{x:1322,y:914,t:1527620838220};\\\", \\\"{x:1336,y:912,t:1527620838237};\\\", \\\"{x:1339,y:909,t:1527620838253};\\\", \\\"{x:1338,y:900,t:1527620838270};\\\", \\\"{x:1321,y:885,t:1527620838288};\\\", \\\"{x:1297,y:868,t:1527620838303};\\\", \\\"{x:1268,y:854,t:1527620838320};\\\", \\\"{x:1259,y:851,t:1527620838337};\\\", \\\"{x:1251,y:847,t:1527620838353};\\\", \\\"{x:1244,y:844,t:1527620838370};\\\", \\\"{x:1240,y:842,t:1527620838386};\\\", \\\"{x:1239,y:842,t:1527620838416};\\\", \\\"{x:1238,y:842,t:1527620838423};\\\", \\\"{x:1238,y:840,t:1527620838481};\\\", \\\"{x:1238,y:838,t:1527620838489};\\\", \\\"{x:1239,y:837,t:1527620838503};\\\", \\\"{x:1241,y:833,t:1527620838521};\\\", \\\"{x:1241,y:832,t:1527620838544};\\\", \\\"{x:1241,y:833,t:1527620838649};\\\", \\\"{x:1242,y:833,t:1527620838657};\\\", \\\"{x:1243,y:835,t:1527620838673};\\\", \\\"{x:1243,y:836,t:1527620838690};\\\", \\\"{x:1243,y:838,t:1527620838704};\\\", \\\"{x:1243,y:839,t:1527620838720};\\\", \\\"{x:1243,y:841,t:1527620838737};\\\", \\\"{x:1238,y:845,t:1527620838755};\\\", \\\"{x:1236,y:847,t:1527620838771};\\\", \\\"{x:1233,y:849,t:1527620838788};\\\", \\\"{x:1232,y:850,t:1527620838804};\\\", \\\"{x:1231,y:850,t:1527620838825};\\\", \\\"{x:1230,y:850,t:1527620838838};\\\", \\\"{x:1230,y:851,t:1527620838855};\\\", \\\"{x:1227,y:851,t:1527620838881};\\\", \\\"{x:1226,y:851,t:1527620838890};\\\", \\\"{x:1221,y:851,t:1527620838905};\\\", \\\"{x:1215,y:849,t:1527620838920};\\\", \\\"{x:1207,y:845,t:1527620838937};\\\", \\\"{x:1203,y:843,t:1527620838955};\\\", \\\"{x:1201,y:840,t:1527620838970};\\\", \\\"{x:1201,y:836,t:1527620838988};\\\", \\\"{x:1200,y:833,t:1527620839004};\\\", \\\"{x:1199,y:830,t:1527620839021};\\\", \\\"{x:1199,y:828,t:1527620839037};\\\", \\\"{x:1199,y:827,t:1527620839055};\\\", \\\"{x:1199,y:826,t:1527620840113};\\\", \\\"{x:1201,y:826,t:1527620840137};\\\", \\\"{x:1202,y:826,t:1527620840153};\\\", \\\"{x:1203,y:826,t:1527620840161};\\\", \\\"{x:1205,y:824,t:1527620840171};\\\", \\\"{x:1207,y:824,t:1527620840189};\\\", \\\"{x:1208,y:824,t:1527620840205};\\\", \\\"{x:1209,y:824,t:1527620840489};\\\", \\\"{x:1210,y:824,t:1527620840561};\\\", \\\"{x:1211,y:824,t:1527620840593};\\\", \\\"{x:1212,y:824,t:1527620840616};\\\", \\\"{x:1214,y:824,t:1527620840625};\\\", \\\"{x:1214,y:825,t:1527620840640};\\\", \\\"{x:1216,y:825,t:1527620840655};\\\", \\\"{x:1217,y:825,t:1527620840673};\\\", \\\"{x:1219,y:825,t:1527620840721};\\\", \\\"{x:1220,y:825,t:1527620840739};\\\", \\\"{x:1222,y:825,t:1527620840761};\\\", \\\"{x:1223,y:825,t:1527620840777};\\\", \\\"{x:1225,y:825,t:1527620840788};\\\", \\\"{x:1227,y:826,t:1527620840805};\\\", \\\"{x:1233,y:827,t:1527620840820};\\\", \\\"{x:1242,y:828,t:1527620840838};\\\", \\\"{x:1246,y:828,t:1527620840855};\\\", \\\"{x:1249,y:829,t:1527620840871};\\\", \\\"{x:1252,y:830,t:1527620840888};\\\", \\\"{x:1254,y:831,t:1527620840905};\\\", \\\"{x:1259,y:832,t:1527620840921};\\\", \\\"{x:1263,y:832,t:1527620840938};\\\", \\\"{x:1268,y:834,t:1527620840956};\\\", \\\"{x:1270,y:834,t:1527620840971};\\\", \\\"{x:1271,y:834,t:1527620841016};\\\", \\\"{x:1273,y:834,t:1527620841049};\\\", \\\"{x:1274,y:834,t:1527620841057};\\\", \\\"{x:1275,y:834,t:1527620841080};\\\", \\\"{x:1276,y:834,t:1527620841097};\\\", \\\"{x:1277,y:834,t:1527620841137};\\\", \\\"{x:1279,y:834,t:1527620841156};\\\", \\\"{x:1280,y:834,t:1527620841171};\\\", \\\"{x:1281,y:835,t:1527620841189};\\\", \\\"{x:1282,y:835,t:1527620841233};\\\", \\\"{x:1284,y:835,t:1527620841410};\\\", \\\"{x:1286,y:833,t:1527620841423};\\\", \\\"{x:1288,y:826,t:1527620841439};\\\", \\\"{x:1289,y:813,t:1527620841456};\\\", \\\"{x:1289,y:798,t:1527620841473};\\\", \\\"{x:1289,y:783,t:1527620841490};\\\", \\\"{x:1289,y:763,t:1527620841505};\\\", \\\"{x:1291,y:751,t:1527620841523};\\\", \\\"{x:1292,y:737,t:1527620841539};\\\", \\\"{x:1297,y:722,t:1527620841556};\\\", \\\"{x:1302,y:710,t:1527620841572};\\\", \\\"{x:1307,y:693,t:1527620841589};\\\", \\\"{x:1311,y:681,t:1527620841606};\\\", \\\"{x:1314,y:672,t:1527620841623};\\\", \\\"{x:1316,y:667,t:1527620841638};\\\", \\\"{x:1318,y:659,t:1527620841655};\\\", \\\"{x:1319,y:650,t:1527620841673};\\\", \\\"{x:1319,y:642,t:1527620841690};\\\", \\\"{x:1319,y:634,t:1527620841706};\\\", \\\"{x:1319,y:630,t:1527620841723};\\\", \\\"{x:1319,y:626,t:1527620841738};\\\", \\\"{x:1318,y:624,t:1527620841756};\\\", \\\"{x:1315,y:620,t:1527620841772};\\\", \\\"{x:1315,y:617,t:1527620841787};\\\", \\\"{x:1315,y:613,t:1527620841805};\\\", \\\"{x:1315,y:609,t:1527620841822};\\\", \\\"{x:1315,y:603,t:1527620841838};\\\", \\\"{x:1314,y:600,t:1527620841855};\\\", \\\"{x:1312,y:595,t:1527620841872};\\\", \\\"{x:1312,y:592,t:1527620841889};\\\", \\\"{x:1312,y:587,t:1527620841905};\\\", \\\"{x:1312,y:579,t:1527620841922};\\\", \\\"{x:1311,y:569,t:1527620841939};\\\", \\\"{x:1311,y:555,t:1527620841955};\\\", \\\"{x:1310,y:541,t:1527620841972};\\\", \\\"{x:1307,y:530,t:1527620841989};\\\", \\\"{x:1306,y:521,t:1527620842005};\\\", \\\"{x:1306,y:515,t:1527620842023};\\\", \\\"{x:1306,y:510,t:1527620842039};\\\", \\\"{x:1306,y:508,t:1527620842055};\\\", \\\"{x:1306,y:507,t:1527620842073};\\\", \\\"{x:1308,y:509,t:1527620842129};\\\", \\\"{x:1312,y:517,t:1527620842140};\\\", \\\"{x:1321,y:536,t:1527620842155};\\\", \\\"{x:1326,y:556,t:1527620842172};\\\", \\\"{x:1332,y:578,t:1527620842190};\\\", \\\"{x:1337,y:602,t:1527620842205};\\\", \\\"{x:1343,y:625,t:1527620842222};\\\", \\\"{x:1345,y:651,t:1527620842240};\\\", \\\"{x:1348,y:683,t:1527620842256};\\\", \\\"{x:1349,y:745,t:1527620842272};\\\", \\\"{x:1349,y:779,t:1527620842290};\\\", \\\"{x:1349,y:804,t:1527620842305};\\\", \\\"{x:1349,y:827,t:1527620842322};\\\", \\\"{x:1349,y:842,t:1527620842339};\\\", \\\"{x:1349,y:850,t:1527620842355};\\\", \\\"{x:1349,y:857,t:1527620842372};\\\", \\\"{x:1349,y:861,t:1527620842389};\\\", \\\"{x:1348,y:867,t:1527620842405};\\\", \\\"{x:1348,y:871,t:1527620842423};\\\", \\\"{x:1348,y:874,t:1527620842439};\\\", \\\"{x:1348,y:875,t:1527620842455};\\\", \\\"{x:1348,y:879,t:1527620842472};\\\", \\\"{x:1348,y:885,t:1527620842489};\\\", \\\"{x:1348,y:890,t:1527620842507};\\\", \\\"{x:1348,y:901,t:1527620842522};\\\", \\\"{x:1349,y:910,t:1527620842540};\\\", \\\"{x:1349,y:913,t:1527620842556};\\\", \\\"{x:1351,y:917,t:1527620842572};\\\", \\\"{x:1352,y:921,t:1527620842590};\\\", \\\"{x:1353,y:923,t:1527620842606};\\\", \\\"{x:1356,y:928,t:1527620842623};\\\", \\\"{x:1359,y:937,t:1527620842640};\\\", \\\"{x:1369,y:950,t:1527620842657};\\\", \\\"{x:1378,y:957,t:1527620842673};\\\", \\\"{x:1382,y:960,t:1527620842689};\\\", \\\"{x:1384,y:962,t:1527620842706};\\\", \\\"{x:1389,y:964,t:1527620842722};\\\", \\\"{x:1394,y:965,t:1527620842740};\\\", \\\"{x:1404,y:966,t:1527620842757};\\\", \\\"{x:1413,y:968,t:1527620842772};\\\", \\\"{x:1419,y:969,t:1527620842790};\\\", \\\"{x:1423,y:971,t:1527620842806};\\\", \\\"{x:1426,y:973,t:1527620842823};\\\", \\\"{x:1426,y:975,t:1527620842864};\\\", \\\"{x:1425,y:977,t:1527620842880};\\\", \\\"{x:1424,y:979,t:1527620842889};\\\", \\\"{x:1419,y:980,t:1527620842907};\\\", \\\"{x:1414,y:981,t:1527620842922};\\\", \\\"{x:1407,y:981,t:1527620842940};\\\", \\\"{x:1398,y:983,t:1527620842957};\\\", \\\"{x:1388,y:983,t:1527620842974};\\\", \\\"{x:1380,y:983,t:1527620842990};\\\", \\\"{x:1371,y:981,t:1527620843007};\\\", \\\"{x:1364,y:980,t:1527620843023};\\\", \\\"{x:1358,y:980,t:1527620843039};\\\", \\\"{x:1343,y:980,t:1527620843056};\\\", \\\"{x:1332,y:980,t:1527620843072};\\\", \\\"{x:1319,y:982,t:1527620843090};\\\", \\\"{x:1304,y:982,t:1527620843107};\\\", \\\"{x:1285,y:982,t:1527620843123};\\\", \\\"{x:1259,y:982,t:1527620843141};\\\", \\\"{x:1220,y:982,t:1527620843157};\\\", \\\"{x:1181,y:982,t:1527620843174};\\\", \\\"{x:1142,y:982,t:1527620843190};\\\", \\\"{x:1090,y:978,t:1527620843207};\\\", \\\"{x:1039,y:970,t:1527620843224};\\\", \\\"{x:994,y:963,t:1527620843240};\\\", \\\"{x:957,y:959,t:1527620843257};\\\", \\\"{x:939,y:955,t:1527620843273};\\\", \\\"{x:929,y:950,t:1527620843289};\\\", \\\"{x:924,y:944,t:1527620843307};\\\", \\\"{x:917,y:929,t:1527620843324};\\\", \\\"{x:909,y:902,t:1527620843339};\\\", \\\"{x:897,y:870,t:1527620843357};\\\", \\\"{x:880,y:848,t:1527620843373};\\\", \\\"{x:868,y:832,t:1527620843389};\\\", \\\"{x:855,y:814,t:1527620843407};\\\", \\\"{x:843,y:797,t:1527620843423};\\\", \\\"{x:831,y:784,t:1527620843440};\\\", \\\"{x:814,y:763,t:1527620843456};\\\", \\\"{x:800,y:752,t:1527620843474};\\\", \\\"{x:796,y:747,t:1527620843489};\\\", \\\"{x:794,y:746,t:1527620843507};\\\", \\\"{x:793,y:744,t:1527620843524};\\\", \\\"{x:791,y:743,t:1527620843545};\\\", \\\"{x:789,y:742,t:1527620843568};\\\", \\\"{x:790,y:742,t:1527620844801};\\\", \\\"{x:792,y:742,t:1527620844865};\\\", \\\"{x:793,y:743,t:1527620844890};\\\", \\\"{x:794,y:743,t:1527620845039};\\\", \\\"{x:795,y:743,t:1527620845112};\\\", \\\"{x:796,y:744,t:1527620845123};\\\", \\\"{x:796,y:745,t:1527620845321};\\\", \\\"{x:797,y:745,t:1527620845497};\\\", \\\"{x:798,y:745,t:1527620846713};\\\", \\\"{x:799,y:746,t:1527620846728};\\\", \\\"{x:799,y:747,t:1527620846872};\\\", \\\"{x:799,y:748,t:1527620846920};\\\", \\\"{x:799,y:749,t:1527620846960};\\\", \\\"{x:799,y:750,t:1527620847040};\\\", \\\"{x:799,y:751,t:1527620847056};\\\", \\\"{x:799,y:752,t:1527620847080};\\\", \\\"{x:799,y:753,t:1527620847136};\\\", \\\"{x:799,y:754,t:1527620847160};\\\", \\\"{x:799,y:755,t:1527620847176};\\\", \\\"{x:799,y:756,t:1527620847209};\\\", \\\"{x:799,y:757,t:1527620847240};\\\", \\\"{x:799,y:758,t:1527620847265};\\\", \\\"{x:798,y:760,t:1527620847296};\\\", \\\"{x:798,y:761,t:1527620847336};\\\", \\\"{x:798,y:762,t:1527620847352};\\\", \\\"{x:796,y:763,t:1527620847369};\\\", \\\"{x:795,y:764,t:1527620847408};\\\", \\\"{x:795,y:765,t:1527620847426};\\\", \\\"{x:795,y:766,t:1527620847442};\\\", \\\"{x:794,y:766,t:1527620847459};\\\", \\\"{x:794,y:767,t:1527620847476};\\\", \\\"{x:793,y:767,t:1527620847492};\\\", \\\"{x:793,y:768,t:1527620847509};\\\", \\\"{x:792,y:769,t:1527620847525};\\\", \\\"{x:791,y:769,t:1527620847544};\\\", \\\"{x:791,y:771,t:1527620847601};\\\", \\\"{x:790,y:772,t:1527620847657};\\\", \\\"{x:789,y:772,t:1527620847681};\\\", \\\"{x:788,y:773,t:1527620848297};\\\", \\\"{x:787,y:773,t:1527620849000};\\\", \\\"{x:786,y:774,t:1527620849009};\\\", \\\"{x:784,y:775,t:1527620849025};\\\", \\\"{x:781,y:776,t:1527620849042};\\\", \\\"{x:777,y:776,t:1527620849059};\\\", \\\"{x:767,y:780,t:1527620849076};\\\", \\\"{x:759,y:781,t:1527620849092};\\\", \\\"{x:751,y:785,t:1527620849110};\\\", \\\"{x:747,y:785,t:1527620849127};\\\", \\\"{x:742,y:787,t:1527620849142};\\\", \\\"{x:739,y:788,t:1527620849159};\\\", \\\"{x:733,y:788,t:1527620849176};\\\", \\\"{x:730,y:788,t:1527620849193};\\\", \\\"{x:723,y:788,t:1527620849209};\\\", \\\"{x:715,y:788,t:1527620849226};\\\", \\\"{x:706,y:787,t:1527620849242};\\\", \\\"{x:698,y:783,t:1527620849259};\\\", \\\"{x:687,y:778,t:1527620849277};\\\", \\\"{x:674,y:773,t:1527620849292};\\\", \\\"{x:657,y:767,t:1527620849310};\\\", \\\"{x:633,y:761,t:1527620849326};\\\", \\\"{x:603,y:753,t:1527620849342};\\\", \\\"{x:581,y:747,t:1527620849359};\\\", \\\"{x:558,y:740,t:1527620849376};\\\", \\\"{x:546,y:735,t:1527620849393};\\\", \\\"{x:538,y:732,t:1527620849409};\\\", \\\"{x:529,y:729,t:1527620849426};\\\", \\\"{x:524,y:726,t:1527620849444};\\\", \\\"{x:521,y:724,t:1527620849461};\\\", \\\"{x:516,y:721,t:1527620849478};\\\", \\\"{x:514,y:720,t:1527620849496};\\\", \\\"{x:509,y:718,t:1527620849512};\\\", \\\"{x:506,y:717,t:1527620849528};\\\", \\\"{x:504,y:717,t:1527620849546};\\\", \\\"{x:503,y:716,t:1527620849592};\\\", \\\"{x:505,y:718,t:1527620850072};\\\", \\\"{x:505,y:719,t:1527620850080};\\\", \\\"{x:506,y:721,t:1527620850096};\\\", \\\"{x:506,y:722,t:1527620850112};\\\", \\\"{x:506,y:724,t:1527620850129};\\\", \\\"{x:506,y:727,t:1527620850146};\\\", \\\"{x:506,y:732,t:1527620850164};\\\", \\\"{x:506,y:738,t:1527620850179};\\\", \\\"{x:506,y:745,t:1527620850196};\\\", \\\"{x:506,y:748,t:1527620850213};\\\", \\\"{x:506,y:751,t:1527620850230};\\\", \\\"{x:507,y:752,t:1527620850246};\\\", \\\"{x:507,y:753,t:1527620850264};\\\", \\\"{x:507,y:754,t:1527620850279};\\\", \\\"{x:507,y:756,t:1527620850297};\\\", \\\"{x:507,y:758,t:1527620850313};\\\", \\\"{x:507,y:763,t:1527620850329};\\\", \\\"{x:507,y:767,t:1527620850347};\\\", \\\"{x:507,y:770,t:1527620850363};\\\", \\\"{x:506,y:772,t:1527620850379};\\\", \\\"{x:506,y:773,t:1527620850396};\\\", \\\"{x:505,y:775,t:1527620850413};\\\", \\\"{x:504,y:775,t:1527620850430};\\\", \\\"{x:502,y:777,t:1527620850446};\\\", \\\"{x:499,y:780,t:1527620850463};\\\", \\\"{x:499,y:781,t:1527620850480};\\\", \\\"{x:497,y:782,t:1527620850496};\\\", \\\"{x:497,y:783,t:1527620850513};\\\", \\\"{x:497,y:784,t:1527620850532};\\\", \\\"{x:496,y:786,t:1527620850549};\\\", \\\"{x:496,y:785,t:1527620850834};\\\", \\\"{x:497,y:784,t:1527620850859};\\\" ] }, { \\\"rt\\\": 11169, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 311135, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-04 PM-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:777,t:1527620851020};\\\", \\\"{x:509,y:775,t:1527620851049};\\\", \\\"{x:510,y:775,t:1527620851053};\\\", \\\"{x:511,y:774,t:1527620851067};\\\", \\\"{x:513,y:772,t:1527620851084};\\\", \\\"{x:513,y:771,t:1527620851101};\\\", \\\"{x:514,y:770,t:1527620851127};\\\", \\\"{x:516,y:769,t:1527620851179};\\\", \\\"{x:516,y:768,t:1527620851876};\\\", \\\"{x:513,y:761,t:1527620851885};\\\", \\\"{x:502,y:744,t:1527620851901};\\\", \\\"{x:500,y:740,t:1527620851918};\\\", \\\"{x:496,y:737,t:1527620851934};\\\", \\\"{x:495,y:733,t:1527620851952};\\\", \\\"{x:493,y:730,t:1527620851968};\\\", \\\"{x:493,y:729,t:1527620851985};\\\", \\\"{x:493,y:727,t:1527620852002};\\\", \\\"{x:493,y:725,t:1527620852018};\\\", \\\"{x:494,y:719,t:1527620852035};\\\", \\\"{x:494,y:714,t:1527620852052};\\\", \\\"{x:495,y:706,t:1527620852068};\\\", \\\"{x:497,y:697,t:1527620852086};\\\", \\\"{x:498,y:690,t:1527620852102};\\\", \\\"{x:499,y:688,t:1527620852118};\\\", \\\"{x:500,y:688,t:1527620852135};\\\", \\\"{x:501,y:688,t:1527620852180};\\\", \\\"{x:501,y:687,t:1527620852188};\\\", \\\"{x:501,y:686,t:1527620853924};\\\", \\\"{x:501,y:685,t:1527620853936};\\\", \\\"{x:501,y:682,t:1527620853954};\\\", \\\"{x:501,y:679,t:1527620853970};\\\", \\\"{x:501,y:677,t:1527620853987};\\\", \\\"{x:501,y:674,t:1527620854003};\\\", \\\"{x:501,y:672,t:1527620854020};\\\", \\\"{x:501,y:671,t:1527620854036};\\\", \\\"{x:501,y:669,t:1527620854054};\\\", \\\"{x:501,y:668,t:1527620854071};\\\", \\\"{x:501,y:667,t:1527620854100};\\\", \\\"{x:501,y:666,t:1527620854108};\\\", \\\"{x:501,y:665,t:1527620854132};\\\", \\\"{x:501,y:664,t:1527620854148};\\\", \\\"{x:501,y:663,t:1527620854164};\\\", \\\"{x:501,y:662,t:1527620854180};\\\", \\\"{x:502,y:660,t:1527620854197};\\\", \\\"{x:502,y:659,t:1527620854212};\\\", \\\"{x:502,y:658,t:1527620854220};\\\", \\\"{x:502,y:657,t:1527620854237};\\\", \\\"{x:503,y:653,t:1527620854254};\\\", \\\"{x:504,y:651,t:1527620854270};\\\", \\\"{x:504,y:648,t:1527620854288};\\\", \\\"{x:505,y:646,t:1527620854303};\\\", \\\"{x:505,y:645,t:1527620854320};\\\", \\\"{x:506,y:644,t:1527620854337};\\\", \\\"{x:506,y:643,t:1527620854396};\\\", \\\"{x:507,y:643,t:1527620854403};\\\", \\\"{x:509,y:642,t:1527620854420};\\\", \\\"{x:510,y:642,t:1527620854437};\\\", \\\"{x:514,y:642,t:1527620854453};\\\", \\\"{x:519,y:642,t:1527620854470};\\\", \\\"{x:530,y:642,t:1527620854488};\\\", \\\"{x:545,y:642,t:1527620854503};\\\", \\\"{x:561,y:643,t:1527620854521};\\\", \\\"{x:573,y:645,t:1527620854538};\\\", \\\"{x:592,y:647,t:1527620854553};\\\", \\\"{x:615,y:652,t:1527620854572};\\\", \\\"{x:656,y:657,t:1527620854587};\\\", \\\"{x:684,y:661,t:1527620854603};\\\", \\\"{x:709,y:669,t:1527620854621};\\\", \\\"{x:730,y:671,t:1527620854637};\\\", \\\"{x:745,y:674,t:1527620854653};\\\", \\\"{x:757,y:676,t:1527620854670};\\\", \\\"{x:766,y:677,t:1527620854688};\\\", \\\"{x:771,y:679,t:1527620854703};\\\", \\\"{x:778,y:683,t:1527620854720};\\\", \\\"{x:785,y:689,t:1527620854737};\\\", \\\"{x:794,y:700,t:1527620854753};\\\", \\\"{x:803,y:714,t:1527620854770};\\\", \\\"{x:817,y:745,t:1527620854787};\\\", \\\"{x:830,y:773,t:1527620854803};\\\", \\\"{x:859,y:813,t:1527620854820};\\\", \\\"{x:907,y:849,t:1527620854837};\\\", \\\"{x:988,y:883,t:1527620854854};\\\", \\\"{x:1088,y:913,t:1527620854871};\\\", \\\"{x:1220,y:945,t:1527620854887};\\\", \\\"{x:1359,y:970,t:1527620854905};\\\", \\\"{x:1487,y:994,t:1527620854921};\\\", \\\"{x:1630,y:1026,t:1527620854938};\\\", \\\"{x:1773,y:1063,t:1527620854955};\\\", \\\"{x:1919,y:1102,t:1527620854971};\\\", \\\"{x:1919,y:1146,t:1527620854988};\\\", \\\"{x:1919,y:1167,t:1527620855004};\\\", \\\"{x:1919,y:1185,t:1527620855020};\\\", \\\"{x:1919,y:1191,t:1527620855037};\\\", \\\"{x:1919,y:1193,t:1527620855054};\\\", \\\"{x:1915,y:1190,t:1527620855091};\\\", \\\"{x:1908,y:1186,t:1527620855104};\\\", \\\"{x:1885,y:1172,t:1527620855121};\\\", \\\"{x:1853,y:1159,t:1527620855137};\\\", \\\"{x:1827,y:1151,t:1527620855155};\\\", \\\"{x:1803,y:1145,t:1527620855170};\\\", \\\"{x:1766,y:1134,t:1527620855188};\\\", \\\"{x:1742,y:1130,t:1527620855204};\\\", \\\"{x:1721,y:1127,t:1527620855221};\\\", \\\"{x:1699,y:1123,t:1527620855237};\\\", \\\"{x:1680,y:1121,t:1527620855254};\\\", \\\"{x:1662,y:1118,t:1527620855271};\\\", \\\"{x:1650,y:1115,t:1527620855287};\\\", \\\"{x:1645,y:1113,t:1527620855305};\\\", \\\"{x:1644,y:1112,t:1527620855321};\\\", \\\"{x:1644,y:1106,t:1527620855337};\\\", \\\"{x:1644,y:1098,t:1527620855354};\\\", \\\"{x:1637,y:1073,t:1527620855371};\\\", \\\"{x:1630,y:1053,t:1527620855387};\\\", \\\"{x:1628,y:1038,t:1527620855404};\\\", \\\"{x:1626,y:1025,t:1527620855421};\\\", \\\"{x:1626,y:1012,t:1527620855437};\\\", \\\"{x:1621,y:993,t:1527620855454};\\\", \\\"{x:1609,y:978,t:1527620855472};\\\", \\\"{x:1595,y:965,t:1527620855488};\\\", \\\"{x:1586,y:958,t:1527620855505};\\\", \\\"{x:1580,y:952,t:1527620855522};\\\", \\\"{x:1579,y:951,t:1527620855539};\\\", \\\"{x:1579,y:949,t:1527620855555};\\\", \\\"{x:1579,y:946,t:1527620855572};\\\", \\\"{x:1578,y:942,t:1527620855588};\\\", \\\"{x:1577,y:940,t:1527620855605};\\\", \\\"{x:1577,y:939,t:1527620855622};\\\", \\\"{x:1577,y:938,t:1527620855638};\\\", \\\"{x:1580,y:936,t:1527620855654};\\\", \\\"{x:1597,y:938,t:1527620855672};\\\", \\\"{x:1607,y:943,t:1527620855688};\\\", \\\"{x:1614,y:946,t:1527620855705};\\\", \\\"{x:1619,y:947,t:1527620855722};\\\", \\\"{x:1620,y:947,t:1527620855738};\\\", \\\"{x:1622,y:948,t:1527620855796};\\\", \\\"{x:1622,y:949,t:1527620855805};\\\", \\\"{x:1622,y:950,t:1527620855869};\\\", \\\"{x:1621,y:950,t:1527620855877};\\\", \\\"{x:1619,y:950,t:1527620855889};\\\", \\\"{x:1618,y:952,t:1527620855904};\\\", \\\"{x:1618,y:953,t:1527620855921};\\\", \\\"{x:1618,y:955,t:1527620855939};\\\", \\\"{x:1618,y:956,t:1527620855955};\\\", \\\"{x:1617,y:958,t:1527620855972};\\\", \\\"{x:1617,y:956,t:1527620856117};\\\", \\\"{x:1617,y:955,t:1527620856124};\\\", \\\"{x:1617,y:953,t:1527620856139};\\\", \\\"{x:1615,y:945,t:1527620856156};\\\", \\\"{x:1613,y:940,t:1527620856172};\\\", \\\"{x:1612,y:936,t:1527620856189};\\\", \\\"{x:1611,y:932,t:1527620856206};\\\", \\\"{x:1610,y:929,t:1527620856222};\\\", \\\"{x:1610,y:923,t:1527620856239};\\\", \\\"{x:1610,y:917,t:1527620856256};\\\", \\\"{x:1610,y:910,t:1527620856272};\\\", \\\"{x:1610,y:900,t:1527620856289};\\\", \\\"{x:1610,y:890,t:1527620856306};\\\", \\\"{x:1610,y:883,t:1527620856322};\\\", \\\"{x:1610,y:878,t:1527620856339};\\\", \\\"{x:1611,y:868,t:1527620856356};\\\", \\\"{x:1611,y:863,t:1527620856372};\\\", \\\"{x:1611,y:858,t:1527620856389};\\\", \\\"{x:1612,y:853,t:1527620856406};\\\", \\\"{x:1613,y:848,t:1527620856423};\\\", \\\"{x:1615,y:844,t:1527620856439};\\\", \\\"{x:1615,y:840,t:1527620856456};\\\", \\\"{x:1615,y:836,t:1527620856473};\\\", \\\"{x:1616,y:829,t:1527620856489};\\\", \\\"{x:1617,y:825,t:1527620856506};\\\", \\\"{x:1617,y:821,t:1527620856523};\\\", \\\"{x:1618,y:816,t:1527620856539};\\\", \\\"{x:1618,y:811,t:1527620856556};\\\", \\\"{x:1618,y:807,t:1527620856572};\\\", \\\"{x:1618,y:803,t:1527620856589};\\\", \\\"{x:1618,y:800,t:1527620856606};\\\", \\\"{x:1618,y:797,t:1527620856623};\\\", \\\"{x:1618,y:793,t:1527620856639};\\\", \\\"{x:1618,y:789,t:1527620856656};\\\", \\\"{x:1618,y:786,t:1527620856673};\\\", \\\"{x:1618,y:783,t:1527620856689};\\\", \\\"{x:1617,y:779,t:1527620856706};\\\", \\\"{x:1615,y:773,t:1527620856723};\\\", \\\"{x:1615,y:768,t:1527620856739};\\\", \\\"{x:1614,y:760,t:1527620856755};\\\", \\\"{x:1613,y:755,t:1527620856773};\\\", \\\"{x:1611,y:749,t:1527620856790};\\\", \\\"{x:1610,y:745,t:1527620856806};\\\", \\\"{x:1609,y:740,t:1527620856822};\\\", \\\"{x:1607,y:736,t:1527620856839};\\\", \\\"{x:1607,y:733,t:1527620856856};\\\", \\\"{x:1607,y:730,t:1527620856872};\\\", \\\"{x:1606,y:726,t:1527620856890};\\\", \\\"{x:1606,y:723,t:1527620856905};\\\", \\\"{x:1604,y:719,t:1527620856922};\\\", \\\"{x:1603,y:712,t:1527620856940};\\\", \\\"{x:1603,y:704,t:1527620856955};\\\", \\\"{x:1603,y:698,t:1527620856973};\\\", \\\"{x:1603,y:691,t:1527620856989};\\\", \\\"{x:1603,y:683,t:1527620857005};\\\", \\\"{x:1603,y:675,t:1527620857022};\\\", \\\"{x:1603,y:670,t:1527620857040};\\\", \\\"{x:1603,y:664,t:1527620857056};\\\", \\\"{x:1603,y:660,t:1527620857072};\\\", \\\"{x:1603,y:655,t:1527620857089};\\\", \\\"{x:1603,y:651,t:1527620857106};\\\", \\\"{x:1603,y:648,t:1527620857123};\\\", \\\"{x:1603,y:643,t:1527620857139};\\\", \\\"{x:1602,y:639,t:1527620857155};\\\", \\\"{x:1602,y:638,t:1527620857172};\\\", \\\"{x:1602,y:635,t:1527620857189};\\\", \\\"{x:1602,y:632,t:1527620857206};\\\", \\\"{x:1602,y:629,t:1527620857223};\\\", \\\"{x:1602,y:625,t:1527620857240};\\\", \\\"{x:1602,y:622,t:1527620857256};\\\", \\\"{x:1602,y:618,t:1527620857272};\\\", \\\"{x:1602,y:615,t:1527620857289};\\\", \\\"{x:1602,y:611,t:1527620857306};\\\", \\\"{x:1602,y:607,t:1527620857322};\\\", \\\"{x:1602,y:601,t:1527620857339};\\\", \\\"{x:1602,y:597,t:1527620857356};\\\", \\\"{x:1602,y:595,t:1527620857373};\\\", \\\"{x:1602,y:591,t:1527620857390};\\\", \\\"{x:1602,y:588,t:1527620857407};\\\", \\\"{x:1602,y:587,t:1527620857423};\\\", \\\"{x:1602,y:584,t:1527620857440};\\\", \\\"{x:1603,y:580,t:1527620857458};\\\", \\\"{x:1604,y:579,t:1527620857473};\\\", \\\"{x:1605,y:575,t:1527620857490};\\\", \\\"{x:1605,y:573,t:1527620857507};\\\", \\\"{x:1605,y:571,t:1527620857522};\\\", \\\"{x:1605,y:567,t:1527620857540};\\\", \\\"{x:1605,y:564,t:1527620857556};\\\", \\\"{x:1607,y:562,t:1527620857573};\\\", \\\"{x:1607,y:560,t:1527620857590};\\\", \\\"{x:1607,y:559,t:1527620857607};\\\", \\\"{x:1607,y:557,t:1527620857623};\\\", \\\"{x:1608,y:555,t:1527620857641};\\\", \\\"{x:1609,y:553,t:1527620857657};\\\", \\\"{x:1609,y:551,t:1527620857675};\\\", \\\"{x:1609,y:549,t:1527620857690};\\\", \\\"{x:1610,y:547,t:1527620857707};\\\", \\\"{x:1611,y:545,t:1527620857724};\\\", \\\"{x:1611,y:544,t:1527620857740};\\\", \\\"{x:1611,y:543,t:1527620857758};\\\", \\\"{x:1611,y:541,t:1527620857774};\\\", \\\"{x:1611,y:540,t:1527620857837};\\\", \\\"{x:1608,y:540,t:1527620857845};\\\", \\\"{x:1604,y:540,t:1527620857857};\\\", \\\"{x:1593,y:540,t:1527620857874};\\\", \\\"{x:1570,y:540,t:1527620857890};\\\", \\\"{x:1526,y:545,t:1527620857907};\\\", \\\"{x:1408,y:561,t:1527620857925};\\\", \\\"{x:1312,y:569,t:1527620857940};\\\", \\\"{x:1224,y:579,t:1527620857957};\\\", \\\"{x:1162,y:582,t:1527620857974};\\\", \\\"{x:1126,y:583,t:1527620857990};\\\", \\\"{x:1091,y:587,t:1527620858007};\\\", \\\"{x:1053,y:591,t:1527620858024};\\\", \\\"{x:1002,y:600,t:1527620858041};\\\", \\\"{x:921,y:612,t:1527620858058};\\\", \\\"{x:830,y:623,t:1527620858075};\\\", \\\"{x:726,y:645,t:1527620858090};\\\", \\\"{x:622,y:665,t:1527620858106};\\\", \\\"{x:473,y:693,t:1527620858124};\\\", \\\"{x:382,y:714,t:1527620858140};\\\", \\\"{x:311,y:730,t:1527620858157};\\\", \\\"{x:288,y:734,t:1527620858174};\\\", \\\"{x:275,y:735,t:1527620858191};\\\", \\\"{x:271,y:735,t:1527620858206};\\\", \\\"{x:269,y:735,t:1527620858223};\\\", \\\"{x:267,y:734,t:1527620858241};\\\", \\\"{x:264,y:730,t:1527620858256};\\\", \\\"{x:261,y:723,t:1527620858274};\\\", \\\"{x:259,y:715,t:1527620858291};\\\", \\\"{x:258,y:709,t:1527620858307};\\\", \\\"{x:258,y:702,t:1527620858323};\\\", \\\"{x:258,y:697,t:1527620858341};\\\", \\\"{x:267,y:689,t:1527620858357};\\\", \\\"{x:276,y:683,t:1527620858374};\\\", \\\"{x:285,y:675,t:1527620858391};\\\", \\\"{x:290,y:667,t:1527620858407};\\\", \\\"{x:293,y:657,t:1527620858423};\\\", \\\"{x:297,y:647,t:1527620858442};\\\", \\\"{x:303,y:640,t:1527620858457};\\\", \\\"{x:312,y:633,t:1527620858472};\\\", \\\"{x:321,y:628,t:1527620858489};\\\", \\\"{x:328,y:623,t:1527620858507};\\\", \\\"{x:331,y:619,t:1527620858523};\\\", \\\"{x:333,y:613,t:1527620858539};\\\", \\\"{x:333,y:609,t:1527620858557};\\\", \\\"{x:333,y:604,t:1527620858574};\\\", \\\"{x:336,y:601,t:1527620858591};\\\", \\\"{x:340,y:597,t:1527620858607};\\\", \\\"{x:343,y:594,t:1527620858624};\\\", \\\"{x:347,y:590,t:1527620858640};\\\", \\\"{x:352,y:587,t:1527620858657};\\\", \\\"{x:353,y:586,t:1527620858674};\\\", \\\"{x:353,y:582,t:1527620858691};\\\", \\\"{x:355,y:577,t:1527620858708};\\\", \\\"{x:356,y:575,t:1527620858724};\\\", \\\"{x:357,y:574,t:1527620858742};\\\", \\\"{x:357,y:573,t:1527620858763};\\\", \\\"{x:355,y:571,t:1527620858773};\\\", \\\"{x:342,y:570,t:1527620858791};\\\", \\\"{x:332,y:569,t:1527620858806};\\\", \\\"{x:317,y:566,t:1527620858823};\\\", \\\"{x:300,y:563,t:1527620858840};\\\", \\\"{x:286,y:561,t:1527620858857};\\\", \\\"{x:276,y:561,t:1527620858873};\\\", \\\"{x:270,y:561,t:1527620858892};\\\", \\\"{x:260,y:560,t:1527620858907};\\\", \\\"{x:257,y:560,t:1527620858924};\\\", \\\"{x:253,y:560,t:1527620858941};\\\", \\\"{x:251,y:560,t:1527620858957};\\\", \\\"{x:249,y:560,t:1527620858975};\\\", \\\"{x:246,y:560,t:1527620858991};\\\", \\\"{x:243,y:560,t:1527620859008};\\\", \\\"{x:236,y:560,t:1527620859025};\\\", \\\"{x:220,y:559,t:1527620859040};\\\", \\\"{x:201,y:556,t:1527620859058};\\\", \\\"{x:192,y:555,t:1527620859075};\\\", \\\"{x:188,y:555,t:1527620859092};\\\", \\\"{x:187,y:555,t:1527620859116};\\\", \\\"{x:187,y:557,t:1527620859132};\\\", \\\"{x:186,y:559,t:1527620859141};\\\", \\\"{x:177,y:568,t:1527620859158};\\\", \\\"{x:166,y:578,t:1527620859175};\\\", \\\"{x:157,y:587,t:1527620859192};\\\", \\\"{x:154,y:592,t:1527620859207};\\\", \\\"{x:154,y:594,t:1527620859251};\\\", \\\"{x:154,y:595,t:1527620859275};\\\", \\\"{x:154,y:597,t:1527620859291};\\\", \\\"{x:154,y:598,t:1527620859307};\\\", \\\"{x:154,y:599,t:1527620859332};\\\", \\\"{x:154,y:600,t:1527620859428};\\\", \\\"{x:156,y:601,t:1527620859441};\\\", \\\"{x:157,y:604,t:1527620859457};\\\", \\\"{x:158,y:608,t:1527620859474};\\\", \\\"{x:158,y:618,t:1527620859492};\\\", \\\"{x:158,y:622,t:1527620859508};\\\", \\\"{x:159,y:626,t:1527620859524};\\\", \\\"{x:160,y:628,t:1527620859540};\\\", \\\"{x:161,y:629,t:1527620859867};\\\", \\\"{x:162,y:629,t:1527620859892};\\\", \\\"{x:167,y:629,t:1527620859908};\\\", \\\"{x:175,y:629,t:1527620859924};\\\", \\\"{x:187,y:628,t:1527620859942};\\\", \\\"{x:199,y:625,t:1527620859960};\\\", \\\"{x:215,y:623,t:1527620859975};\\\", \\\"{x:231,y:622,t:1527620859992};\\\", \\\"{x:247,y:619,t:1527620860009};\\\", \\\"{x:261,y:617,t:1527620860024};\\\", \\\"{x:278,y:614,t:1527620860042};\\\", \\\"{x:301,y:612,t:1527620860059};\\\", \\\"{x:340,y:606,t:1527620860075};\\\", \\\"{x:413,y:599,t:1527620860092};\\\", \\\"{x:474,y:590,t:1527620860109};\\\", \\\"{x:535,y:582,t:1527620860126};\\\", \\\"{x:591,y:574,t:1527620860143};\\\", \\\"{x:639,y:566,t:1527620860158};\\\", \\\"{x:666,y:563,t:1527620860175};\\\", \\\"{x:687,y:560,t:1527620860191};\\\", \\\"{x:700,y:558,t:1527620860208};\\\", \\\"{x:712,y:558,t:1527620860225};\\\", \\\"{x:724,y:557,t:1527620860242};\\\", \\\"{x:735,y:557,t:1527620860259};\\\", \\\"{x:746,y:557,t:1527620860275};\\\", \\\"{x:752,y:556,t:1527620860291};\\\", \\\"{x:757,y:556,t:1527620860308};\\\", \\\"{x:762,y:554,t:1527620860325};\\\", \\\"{x:769,y:554,t:1527620860341};\\\", \\\"{x:772,y:553,t:1527620860359};\\\", \\\"{x:777,y:551,t:1527620860376};\\\", \\\"{x:780,y:550,t:1527620860392};\\\", \\\"{x:783,y:549,t:1527620860409};\\\", \\\"{x:793,y:548,t:1527620860425};\\\", \\\"{x:802,y:546,t:1527620860442};\\\", \\\"{x:808,y:545,t:1527620860459};\\\", \\\"{x:809,y:545,t:1527620860532};\\\", \\\"{x:805,y:545,t:1527620860572};\\\", \\\"{x:800,y:545,t:1527620860580};\\\", \\\"{x:790,y:545,t:1527620860591};\\\", \\\"{x:767,y:545,t:1527620860609};\\\", \\\"{x:750,y:545,t:1527620860625};\\\", \\\"{x:737,y:547,t:1527620860642};\\\", \\\"{x:721,y:551,t:1527620860660};\\\", \\\"{x:689,y:561,t:1527620860675};\\\", \\\"{x:670,y:566,t:1527620860691};\\\", \\\"{x:653,y:570,t:1527620860708};\\\", \\\"{x:647,y:573,t:1527620860725};\\\", \\\"{x:650,y:573,t:1527620860771};\\\", \\\"{x:656,y:573,t:1527620860779};\\\", \\\"{x:663,y:573,t:1527620860792};\\\", \\\"{x:682,y:573,t:1527620860809};\\\", \\\"{x:706,y:573,t:1527620860826};\\\", \\\"{x:728,y:573,t:1527620860843};\\\", \\\"{x:748,y:573,t:1527620860859};\\\", \\\"{x:773,y:573,t:1527620860876};\\\", \\\"{x:783,y:574,t:1527620860892};\\\", \\\"{x:789,y:576,t:1527620860909};\\\", \\\"{x:793,y:577,t:1527620860926};\\\", \\\"{x:797,y:579,t:1527620860942};\\\", \\\"{x:798,y:580,t:1527620860959};\\\", \\\"{x:800,y:582,t:1527620860989};\\\", \\\"{x:801,y:584,t:1527620860995};\\\", \\\"{x:804,y:587,t:1527620861008};\\\", \\\"{x:808,y:591,t:1527620861025};\\\", \\\"{x:810,y:592,t:1527620861041};\\\", \\\"{x:811,y:592,t:1527620861058};\\\", \\\"{x:813,y:593,t:1527620861091};\\\", \\\"{x:816,y:594,t:1527620861099};\\\", \\\"{x:818,y:596,t:1527620861109};\\\", \\\"{x:823,y:599,t:1527620861126};\\\", \\\"{x:826,y:600,t:1527620861143};\\\", \\\"{x:827,y:601,t:1527620861159};\\\", \\\"{x:828,y:601,t:1527620861175};\\\", \\\"{x:828,y:602,t:1527620861355};\\\", \\\"{x:828,y:604,t:1527620861363};\\\", \\\"{x:828,y:605,t:1527620861375};\\\", \\\"{x:825,y:610,t:1527620861393};\\\", \\\"{x:820,y:616,t:1527620861410};\\\", \\\"{x:812,y:626,t:1527620861426};\\\", \\\"{x:806,y:634,t:1527620861443};\\\", \\\"{x:793,y:646,t:1527620861459};\\\", \\\"{x:786,y:652,t:1527620861475};\\\", \\\"{x:777,y:660,t:1527620861492};\\\", \\\"{x:769,y:667,t:1527620861509};\\\", \\\"{x:757,y:679,t:1527620861526};\\\", \\\"{x:745,y:690,t:1527620861543};\\\", \\\"{x:732,y:702,t:1527620861560};\\\", \\\"{x:716,y:712,t:1527620861576};\\\", \\\"{x:697,y:722,t:1527620861593};\\\", \\\"{x:677,y:729,t:1527620861610};\\\", \\\"{x:652,y:736,t:1527620861628};\\\", \\\"{x:646,y:738,t:1527620861643};\\\", \\\"{x:633,y:739,t:1527620861659};\\\", \\\"{x:626,y:739,t:1527620861676};\\\", \\\"{x:618,y:739,t:1527620861693};\\\", \\\"{x:611,y:739,t:1527620861710};\\\", \\\"{x:600,y:740,t:1527620861727};\\\", \\\"{x:590,y:742,t:1527620861743};\\\", \\\"{x:584,y:742,t:1527620861760};\\\", \\\"{x:575,y:742,t:1527620861777};\\\", \\\"{x:566,y:742,t:1527620861792};\\\", \\\"{x:553,y:742,t:1527620861810};\\\", \\\"{x:533,y:738,t:1527620861826};\\\", \\\"{x:527,y:736,t:1527620861843};\\\", \\\"{x:524,y:736,t:1527620861859};\\\", \\\"{x:523,y:735,t:1527620861891};\\\", \\\"{x:522,y:734,t:1527620861909};\\\", \\\"{x:521,y:731,t:1527620861927};\\\", \\\"{x:520,y:728,t:1527620861943};\\\", \\\"{x:519,y:725,t:1527620861959};\\\", \\\"{x:518,y:723,t:1527620861977};\\\", \\\"{x:518,y:720,t:1527620861993};\\\", \\\"{x:517,y:720,t:1527620862009};\\\", \\\"{x:517,y:719,t:1527620862027};\\\", \\\"{x:516,y:718,t:1527620862044};\\\", \\\"{x:516,y:717,t:1527620862093};\\\", \\\"{x:516,y:715,t:1527620862404};\\\", \\\"{x:515,y:715,t:1527620862468};\\\", \\\"{x:511,y:715,t:1527620862909};\\\", \\\"{x:491,y:726,t:1527620862916};\\\", \\\"{x:481,y:736,t:1527620862927};\\\", \\\"{x:472,y:752,t:1527620862944};\\\", \\\"{x:465,y:769,t:1527620862961};\\\", \\\"{x:463,y:773,t:1527620862978};\\\" ] }, { \\\"rt\\\": 79104, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 391461, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -K -I -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:466,y:769,t:1527620864212};\\\", \\\"{x:481,y:752,t:1527620864227};\\\", \\\"{x:499,y:739,t:1527620864245};\\\", \\\"{x:513,y:731,t:1527620864262};\\\", \\\"{x:529,y:726,t:1527620864277};\\\", \\\"{x:547,y:723,t:1527620864295};\\\", \\\"{x:579,y:721,t:1527620864312};\\\", \\\"{x:609,y:721,t:1527620864328};\\\", \\\"{x:641,y:721,t:1527620864344};\\\", \\\"{x:659,y:721,t:1527620864361};\\\", \\\"{x:668,y:724,t:1527620864378};\\\", \\\"{x:673,y:728,t:1527620864394};\\\", \\\"{x:686,y:741,t:1527620864412};\\\", \\\"{x:694,y:759,t:1527620864429};\\\", \\\"{x:702,y:775,t:1527620864445};\\\", \\\"{x:710,y:799,t:1527620864461};\\\", \\\"{x:721,y:838,t:1527620864479};\\\", \\\"{x:727,y:865,t:1527620864495};\\\", \\\"{x:732,y:892,t:1527620864512};\\\", \\\"{x:738,y:926,t:1527620864528};\\\", \\\"{x:749,y:962,t:1527620864545};\\\", \\\"{x:752,y:986,t:1527620864562};\\\", \\\"{x:760,y:1007,t:1527620864579};\\\", \\\"{x:765,y:1028,t:1527620864594};\\\", \\\"{x:777,y:1054,t:1527620864612};\\\", \\\"{x:781,y:1061,t:1527620864629};\\\", \\\"{x:783,y:1067,t:1527620864645};\\\", \\\"{x:786,y:1072,t:1527620864663};\\\", \\\"{x:786,y:1076,t:1527620864679};\\\", \\\"{x:789,y:1079,t:1527620864695};\\\", \\\"{x:789,y:1080,t:1527620864723};\\\", \\\"{x:790,y:1080,t:1527620864980};\\\", \\\"{x:791,y:1080,t:1527620865013};\\\", \\\"{x:792,y:1080,t:1527620865108};\\\", \\\"{x:792,y:1078,t:1527620865157};\\\", \\\"{x:792,y:1077,t:1527620865180};\\\", \\\"{x:792,y:1076,t:1527620865196};\\\", \\\"{x:792,y:1074,t:1527620865228};\\\", \\\"{x:792,y:1073,t:1527620865244};\\\", \\\"{x:792,y:1072,t:1527620865268};\\\", \\\"{x:792,y:1071,t:1527620865284};\\\", \\\"{x:792,y:1070,t:1527620865296};\\\", \\\"{x:792,y:1069,t:1527620865324};\\\", \\\"{x:792,y:1068,t:1527620865332};\\\", \\\"{x:792,y:1067,t:1527620865355};\\\", \\\"{x:792,y:1066,t:1527620865395};\\\", \\\"{x:792,y:1065,t:1527620865427};\\\", \\\"{x:792,y:1064,t:1527620865443};\\\", \\\"{x:792,y:1063,t:1527620865467};\\\", \\\"{x:792,y:1062,t:1527620865484};\\\", \\\"{x:792,y:1061,t:1527620865499};\\\", \\\"{x:792,y:1060,t:1527620865515};\\\", \\\"{x:792,y:1059,t:1527620865528};\\\", \\\"{x:792,y:1057,t:1527620865546};\\\", \\\"{x:793,y:1056,t:1527620865562};\\\", \\\"{x:794,y:1054,t:1527620865579};\\\", \\\"{x:794,y:1052,t:1527620865644};\\\", \\\"{x:794,y:1051,t:1527620865692};\\\", \\\"{x:795,y:1050,t:1527620865708};\\\", \\\"{x:795,y:1049,t:1527620865724};\\\", \\\"{x:795,y:1048,t:1527620865732};\\\", \\\"{x:795,y:1044,t:1527620865746};\\\", \\\"{x:796,y:1040,t:1527620865763};\\\", \\\"{x:797,y:1028,t:1527620865780};\\\", \\\"{x:797,y:1021,t:1527620865796};\\\", \\\"{x:797,y:1013,t:1527620865813};\\\", \\\"{x:797,y:1006,t:1527620865830};\\\", \\\"{x:796,y:999,t:1527620865847};\\\", \\\"{x:795,y:994,t:1527620865863};\\\", \\\"{x:793,y:990,t:1527620865881};\\\", \\\"{x:793,y:988,t:1527620865896};\\\", \\\"{x:793,y:986,t:1527620865913};\\\", \\\"{x:792,y:985,t:1527620865930};\\\", \\\"{x:792,y:984,t:1527620865947};\\\", \\\"{x:792,y:983,t:1527620865964};\\\", \\\"{x:792,y:982,t:1527620866011};\\\", \\\"{x:793,y:981,t:1527620866116};\\\", \\\"{x:793,y:980,t:1527620866621};\\\", \\\"{x:792,y:979,t:1527620866636};\\\", \\\"{x:790,y:977,t:1527620866647};\\\", \\\"{x:784,y:972,t:1527620866665};\\\", \\\"{x:769,y:955,t:1527620866681};\\\", \\\"{x:744,y:935,t:1527620866697};\\\", \\\"{x:710,y:903,t:1527620866714};\\\", \\\"{x:665,y:859,t:1527620866730};\\\", \\\"{x:639,y:837,t:1527620866748};\\\", \\\"{x:625,y:819,t:1527620866764};\\\", \\\"{x:621,y:812,t:1527620866780};\\\", \\\"{x:620,y:809,t:1527620866797};\\\", \\\"{x:617,y:804,t:1527620866814};\\\", \\\"{x:617,y:801,t:1527620866830};\\\", \\\"{x:613,y:795,t:1527620866846};\\\", \\\"{x:607,y:783,t:1527620866864};\\\", \\\"{x:601,y:768,t:1527620866879};\\\", \\\"{x:591,y:752,t:1527620866897};\\\", \\\"{x:585,y:738,t:1527620866914};\\\", \\\"{x:580,y:729,t:1527620866930};\\\", \\\"{x:577,y:717,t:1527620866947};\\\", \\\"{x:563,y:674,t:1527620866964};\\\", \\\"{x:556,y:643,t:1527620866982};\\\", \\\"{x:551,y:621,t:1527620866997};\\\", \\\"{x:548,y:599,t:1527620867013};\\\", \\\"{x:541,y:576,t:1527620867031};\\\", \\\"{x:540,y:562,t:1527620867047};\\\", \\\"{x:537,y:550,t:1527620867064};\\\", \\\"{x:536,y:536,t:1527620867080};\\\", \\\"{x:534,y:520,t:1527620867097};\\\", \\\"{x:532,y:513,t:1527620867114};\\\", \\\"{x:532,y:506,t:1527620867131};\\\", \\\"{x:531,y:502,t:1527620867146};\\\", \\\"{x:530,y:498,t:1527620867164};\\\", \\\"{x:529,y:497,t:1527620867619};\\\", \\\"{x:506,y:493,t:1527620867631};\\\", \\\"{x:443,y:467,t:1527620867648};\\\", \\\"{x:424,y:465,t:1527620867663};\\\", \\\"{x:410,y:462,t:1527620867681};\\\", \\\"{x:403,y:460,t:1527620867698};\\\", \\\"{x:401,y:459,t:1527620867714};\\\", \\\"{x:398,y:459,t:1527620867731};\\\", \\\"{x:395,y:459,t:1527620867748};\\\", \\\"{x:393,y:459,t:1527620867770};\\\", \\\"{x:391,y:459,t:1527620867781};\\\", \\\"{x:390,y:459,t:1527620867798};\\\", \\\"{x:388,y:460,t:1527620867815};\\\", \\\"{x:387,y:461,t:1527620867831};\\\", \\\"{x:387,y:463,t:1527620867859};\\\", \\\"{x:387,y:464,t:1527620867916};\\\", \\\"{x:387,y:465,t:1527620867940};\\\", \\\"{x:387,y:466,t:1527620867948};\\\", \\\"{x:387,y:467,t:1527620867966};\\\", \\\"{x:389,y:469,t:1527620867981};\\\", \\\"{x:389,y:470,t:1527620867998};\\\", \\\"{x:390,y:470,t:1527620868015};\\\", \\\"{x:392,y:472,t:1527620868036};\\\", \\\"{x:392,y:473,t:1527620868052};\\\", \\\"{x:393,y:474,t:1527620868065};\\\", \\\"{x:394,y:474,t:1527620868081};\\\", \\\"{x:396,y:476,t:1527620868098};\\\", \\\"{x:398,y:476,t:1527620868116};\\\", \\\"{x:402,y:476,t:1527620868132};\\\", \\\"{x:413,y:476,t:1527620868148};\\\", \\\"{x:419,y:476,t:1527620868165};\\\", \\\"{x:424,y:476,t:1527620868181};\\\", \\\"{x:426,y:476,t:1527620868198};\\\", \\\"{x:428,y:476,t:1527620868215};\\\", \\\"{x:429,y:476,t:1527620868233};\\\", \\\"{x:431,y:476,t:1527620868268};\\\", \\\"{x:432,y:476,t:1527620868564};\\\", \\\"{x:432,y:477,t:1527620868582};\\\", \\\"{x:432,y:478,t:1527620868620};\\\", \\\"{x:432,y:479,t:1527620868644};\\\", \\\"{x:430,y:478,t:1527620868772};\\\", \\\"{x:429,y:477,t:1527620868782};\\\", \\\"{x:427,y:476,t:1527620868800};\\\", \\\"{x:425,y:475,t:1527620868815};\\\", \\\"{x:424,y:475,t:1527620868833};\\\", \\\"{x:422,y:474,t:1527620868852};\\\", \\\"{x:420,y:472,t:1527620868884};\\\", \\\"{x:421,y:471,t:1527620869109};\\\", \\\"{x:422,y:471,t:1527620869116};\\\", \\\"{x:427,y:470,t:1527620869132};\\\", \\\"{x:431,y:469,t:1527620869150};\\\", \\\"{x:434,y:468,t:1527620869166};\\\", \\\"{x:439,y:468,t:1527620869183};\\\", \\\"{x:443,y:468,t:1527620869200};\\\", \\\"{x:446,y:467,t:1527620869216};\\\", \\\"{x:450,y:467,t:1527620869233};\\\", \\\"{x:452,y:467,t:1527620869249};\\\", \\\"{x:453,y:467,t:1527620869266};\\\", \\\"{x:455,y:467,t:1527620869283};\\\", \\\"{x:458,y:465,t:1527620869299};\\\", \\\"{x:467,y:465,t:1527620869316};\\\", \\\"{x:474,y:465,t:1527620869332};\\\", \\\"{x:479,y:465,t:1527620869349};\\\", \\\"{x:485,y:465,t:1527620869367};\\\", \\\"{x:489,y:464,t:1527620869383};\\\", \\\"{x:492,y:464,t:1527620869400};\\\", \\\"{x:496,y:464,t:1527620869417};\\\", \\\"{x:499,y:463,t:1527620869433};\\\", \\\"{x:501,y:463,t:1527620869449};\\\", \\\"{x:504,y:462,t:1527620869466};\\\", \\\"{x:506,y:462,t:1527620869483};\\\", \\\"{x:509,y:461,t:1527620869500};\\\", \\\"{x:514,y:460,t:1527620869516};\\\", \\\"{x:515,y:459,t:1527620869534};\\\", \\\"{x:516,y:458,t:1527620869550};\\\", \\\"{x:517,y:458,t:1527620869566};\\\", \\\"{x:519,y:458,t:1527620869583};\\\", \\\"{x:520,y:458,t:1527620869600};\\\", \\\"{x:521,y:458,t:1527620869620};\\\", \\\"{x:522,y:458,t:1527620869636};\\\", \\\"{x:523,y:458,t:1527620869652};\\\", \\\"{x:524,y:458,t:1527620869789};\\\", \\\"{x:524,y:460,t:1527620869844};\\\", \\\"{x:524,y:462,t:1527620869860};\\\", \\\"{x:523,y:463,t:1527620869884};\\\", \\\"{x:522,y:464,t:1527620869900};\\\", \\\"{x:521,y:465,t:1527620869917};\\\", \\\"{x:519,y:467,t:1527620869934};\\\", \\\"{x:519,y:468,t:1527620869950};\\\", \\\"{x:517,y:469,t:1527620869966};\\\", \\\"{x:517,y:470,t:1527620869983};\\\", \\\"{x:517,y:471,t:1527620870020};\\\", \\\"{x:516,y:472,t:1527620870036};\\\", \\\"{x:516,y:473,t:1527620870052};\\\", \\\"{x:516,y:474,t:1527620870076};\\\", \\\"{x:516,y:475,t:1527620870084};\\\", \\\"{x:516,y:476,t:1527620870108};\\\", \\\"{x:516,y:477,t:1527620870148};\\\", \\\"{x:517,y:477,t:1527620870188};\\\", \\\"{x:519,y:477,t:1527620870212};\\\", \\\"{x:520,y:479,t:1527620870227};\\\", \\\"{x:521,y:479,t:1527620870244};\\\", \\\"{x:522,y:479,t:1527620870252};\\\", \\\"{x:524,y:479,t:1527620870268};\\\", \\\"{x:526,y:479,t:1527620870284};\\\", \\\"{x:529,y:479,t:1527620870300};\\\", \\\"{x:532,y:479,t:1527620870318};\\\", \\\"{x:534,y:479,t:1527620870334};\\\", \\\"{x:536,y:479,t:1527620870350};\\\", \\\"{x:538,y:479,t:1527620870368};\\\", \\\"{x:541,y:479,t:1527620870383};\\\", \\\"{x:543,y:479,t:1527620870401};\\\", \\\"{x:546,y:479,t:1527620870417};\\\", \\\"{x:548,y:479,t:1527620870433};\\\", \\\"{x:551,y:479,t:1527620870451};\\\", \\\"{x:555,y:479,t:1527620870468};\\\", \\\"{x:556,y:479,t:1527620870483};\\\", \\\"{x:558,y:479,t:1527620870500};\\\", \\\"{x:561,y:479,t:1527620870518};\\\", \\\"{x:562,y:479,t:1527620870533};\\\", \\\"{x:565,y:479,t:1527620870551};\\\", \\\"{x:568,y:479,t:1527620870567};\\\", \\\"{x:571,y:479,t:1527620870583};\\\", \\\"{x:572,y:479,t:1527620870600};\\\", \\\"{x:576,y:479,t:1527620870617};\\\", \\\"{x:578,y:479,t:1527620870634};\\\", \\\"{x:581,y:480,t:1527620870651};\\\", \\\"{x:585,y:480,t:1527620870668};\\\", \\\"{x:587,y:480,t:1527620870684};\\\", \\\"{x:590,y:481,t:1527620870701};\\\", \\\"{x:592,y:481,t:1527620870718};\\\", \\\"{x:595,y:482,t:1527620870734};\\\", \\\"{x:597,y:482,t:1527620870750};\\\", \\\"{x:598,y:482,t:1527620870767};\\\", \\\"{x:601,y:483,t:1527620870784};\\\", \\\"{x:603,y:483,t:1527620870803};\\\", \\\"{x:605,y:483,t:1527620870817};\\\", \\\"{x:607,y:483,t:1527620870833};\\\", \\\"{x:609,y:483,t:1527620870850};\\\", \\\"{x:613,y:483,t:1527620870867};\\\", \\\"{x:616,y:483,t:1527620870884};\\\", \\\"{x:618,y:483,t:1527620870900};\\\", \\\"{x:620,y:483,t:1527620870917};\\\", \\\"{x:623,y:483,t:1527620870934};\\\", \\\"{x:624,y:483,t:1527620870950};\\\", \\\"{x:626,y:483,t:1527620870967};\\\", \\\"{x:629,y:483,t:1527620870985};\\\", \\\"{x:631,y:483,t:1527620871000};\\\", \\\"{x:632,y:483,t:1527620871018};\\\", \\\"{x:633,y:483,t:1527620871035};\\\", \\\"{x:635,y:483,t:1527620871051};\\\", \\\"{x:638,y:483,t:1527620871067};\\\", \\\"{x:639,y:483,t:1527620871084};\\\", \\\"{x:641,y:483,t:1527620871115};\\\", \\\"{x:642,y:483,t:1527620871148};\\\", \\\"{x:644,y:483,t:1527620871188};\\\", \\\"{x:645,y:483,t:1527620871268};\\\", \\\"{x:646,y:483,t:1527620871532};\\\", \\\"{x:646,y:484,t:1527620872356};\\\", \\\"{x:646,y:485,t:1527620872468};\\\", \\\"{x:645,y:486,t:1527620872516};\\\", \\\"{x:644,y:486,t:1527620872556};\\\", \\\"{x:642,y:486,t:1527620872580};\\\", \\\"{x:642,y:487,t:1527620872588};\\\", \\\"{x:640,y:488,t:1527620872604};\\\", \\\"{x:640,y:489,t:1527620872619};\\\", \\\"{x:639,y:489,t:1527620872635};\\\", \\\"{x:637,y:489,t:1527620872653};\\\", \\\"{x:636,y:489,t:1527620872668};\\\", \\\"{x:633,y:492,t:1527620872686};\\\", \\\"{x:630,y:492,t:1527620872703};\\\", \\\"{x:624,y:494,t:1527620872718};\\\", \\\"{x:619,y:495,t:1527620872736};\\\", \\\"{x:606,y:498,t:1527620872762};\\\", \\\"{x:590,y:503,t:1527620872785};\\\", \\\"{x:584,y:506,t:1527620872787};\\\", \\\"{x:578,y:507,t:1527620872802};\\\", \\\"{x:559,y:511,t:1527620872819};\\\", \\\"{x:552,y:511,t:1527620872834};\\\", \\\"{x:547,y:511,t:1527620872852};\\\", \\\"{x:540,y:511,t:1527620872869};\\\", \\\"{x:536,y:511,t:1527620872884};\\\", \\\"{x:532,y:512,t:1527620872902};\\\", \\\"{x:527,y:512,t:1527620872919};\\\", \\\"{x:524,y:513,t:1527620872935};\\\", \\\"{x:523,y:513,t:1527620872955};\\\", \\\"{x:522,y:513,t:1527620872980};\\\", \\\"{x:521,y:513,t:1527620872995};\\\", \\\"{x:520,y:513,t:1527620873044};\\\", \\\"{x:519,y:513,t:1527620873092};\\\", \\\"{x:519,y:512,t:1527620873148};\\\", \\\"{x:519,y:511,t:1527620873164};\\\", \\\"{x:518,y:510,t:1527620873196};\\\", \\\"{x:518,y:509,t:1527620873228};\\\", \\\"{x:518,y:508,t:1527620873251};\\\", \\\"{x:518,y:507,t:1527620873307};\\\", \\\"{x:518,y:506,t:1527620873396};\\\", \\\"{x:518,y:505,t:1527620874228};\\\", \\\"{x:519,y:505,t:1527620874237};\\\", \\\"{x:522,y:505,t:1527620874254};\\\", \\\"{x:525,y:505,t:1527620874270};\\\", \\\"{x:529,y:504,t:1527620874286};\\\", \\\"{x:535,y:504,t:1527620874303};\\\", \\\"{x:539,y:503,t:1527620874320};\\\", \\\"{x:542,y:502,t:1527620874336};\\\", \\\"{x:546,y:502,t:1527620874353};\\\", \\\"{x:551,y:501,t:1527620874370};\\\", \\\"{x:559,y:501,t:1527620874387};\\\", \\\"{x:563,y:501,t:1527620874403};\\\", \\\"{x:565,y:501,t:1527620874420};\\\", \\\"{x:566,y:501,t:1527620874437};\\\", \\\"{x:567,y:501,t:1527620874467};\\\", \\\"{x:568,y:501,t:1527620874539};\\\", \\\"{x:569,y:501,t:1527620874979};\\\", \\\"{x:570,y:501,t:1527620875019};\\\", \\\"{x:571,y:501,t:1527620875091};\\\", \\\"{x:572,y:501,t:1527620875171};\\\", \\\"{x:573,y:501,t:1527620875219};\\\", \\\"{x:574,y:501,t:1527620875235};\\\", \\\"{x:575,y:501,t:1527620875283};\\\", \\\"{x:576,y:501,t:1527620875307};\\\", \\\"{x:577,y:501,t:1527620875332};\\\", \\\"{x:578,y:501,t:1527620875340};\\\", \\\"{x:579,y:501,t:1527620875355};\\\", \\\"{x:581,y:501,t:1527620875371};\\\", \\\"{x:583,y:502,t:1527620875395};\\\", \\\"{x:584,y:502,t:1527620875404};\\\", \\\"{x:586,y:503,t:1527620875421};\\\", \\\"{x:595,y:505,t:1527620875438};\\\", \\\"{x:610,y:509,t:1527620875455};\\\", \\\"{x:625,y:512,t:1527620875471};\\\", \\\"{x:634,y:514,t:1527620875487};\\\", \\\"{x:646,y:519,t:1527620875504};\\\", \\\"{x:659,y:521,t:1527620875523};\\\", \\\"{x:666,y:524,t:1527620875537};\\\", \\\"{x:674,y:525,t:1527620875554};\\\", \\\"{x:685,y:529,t:1527620875571};\\\", \\\"{x:687,y:530,t:1527620875587};\\\", \\\"{x:689,y:530,t:1527620875604};\\\", \\\"{x:692,y:532,t:1527620875621};\\\", \\\"{x:693,y:532,t:1527620875637};\\\", \\\"{x:695,y:532,t:1527620875654};\\\", \\\"{x:698,y:533,t:1527620875671};\\\", \\\"{x:700,y:535,t:1527620875687};\\\", \\\"{x:701,y:535,t:1527620875705};\\\", \\\"{x:702,y:536,t:1527620875721};\\\", \\\"{x:703,y:536,t:1527620875748};\\\", \\\"{x:703,y:537,t:1527620875756};\\\", \\\"{x:704,y:537,t:1527620875788};\\\", \\\"{x:706,y:539,t:1527620875805};\\\", \\\"{x:708,y:540,t:1527620875821};\\\", \\\"{x:709,y:542,t:1527620875838};\\\", \\\"{x:712,y:543,t:1527620875854};\\\", \\\"{x:713,y:544,t:1527620875871};\\\", \\\"{x:714,y:545,t:1527620875888};\\\", \\\"{x:717,y:546,t:1527620875904};\\\", \\\"{x:720,y:548,t:1527620875921};\\\", \\\"{x:723,y:549,t:1527620875937};\\\", \\\"{x:726,y:551,t:1527620875955};\\\", \\\"{x:729,y:553,t:1527620875971};\\\", \\\"{x:731,y:555,t:1527620875987};\\\", \\\"{x:732,y:556,t:1527620876004};\\\", \\\"{x:733,y:557,t:1527620876021};\\\", \\\"{x:733,y:558,t:1527620876038};\\\", \\\"{x:733,y:559,t:1527620876055};\\\", \\\"{x:734,y:559,t:1527620876071};\\\", \\\"{x:735,y:560,t:1527620876099};\\\", \\\"{x:735,y:561,t:1527620876188};\\\", \\\"{x:735,y:562,t:1527620876204};\\\", \\\"{x:734,y:562,t:1527620876243};\\\", \\\"{x:734,y:563,t:1527620876254};\\\", \\\"{x:733,y:564,t:1527620876283};\\\", \\\"{x:732,y:564,t:1527620876300};\\\", \\\"{x:731,y:564,t:1527620876307};\\\", \\\"{x:730,y:565,t:1527620876322};\\\", \\\"{x:727,y:567,t:1527620876338};\\\", \\\"{x:726,y:567,t:1527620876355};\\\", \\\"{x:722,y:568,t:1527620876373};\\\", \\\"{x:719,y:568,t:1527620876388};\\\", \\\"{x:715,y:569,t:1527620876405};\\\", \\\"{x:711,y:569,t:1527620876421};\\\", \\\"{x:708,y:570,t:1527620876438};\\\", \\\"{x:706,y:571,t:1527620876456};\\\", \\\"{x:705,y:571,t:1527620876472};\\\", \\\"{x:704,y:571,t:1527620876489};\\\", \\\"{x:702,y:572,t:1527620876507};\\\", \\\"{x:701,y:573,t:1527620876524};\\\", \\\"{x:700,y:573,t:1527620876538};\\\", \\\"{x:698,y:576,t:1527620876556};\\\", \\\"{x:698,y:579,t:1527620876572};\\\", \\\"{x:695,y:583,t:1527620876589};\\\", \\\"{x:695,y:588,t:1527620876605};\\\", \\\"{x:695,y:592,t:1527620876623};\\\", \\\"{x:695,y:598,t:1527620876638};\\\", \\\"{x:696,y:604,t:1527620876655};\\\", \\\"{x:699,y:610,t:1527620876672};\\\", \\\"{x:701,y:615,t:1527620876688};\\\", \\\"{x:707,y:622,t:1527620876706};\\\", \\\"{x:715,y:630,t:1527620876722};\\\", \\\"{x:724,y:638,t:1527620876739};\\\", \\\"{x:740,y:655,t:1527620876755};\\\", \\\"{x:753,y:670,t:1527620876772};\\\", \\\"{x:775,y:687,t:1527620876789};\\\", \\\"{x:816,y:711,t:1527620876805};\\\", \\\"{x:885,y:742,t:1527620876821};\\\", \\\"{x:975,y:775,t:1527620876839};\\\", \\\"{x:1075,y:805,t:1527620876856};\\\", \\\"{x:1166,y:828,t:1527620876871};\\\", \\\"{x:1248,y:845,t:1527620876888};\\\", \\\"{x:1315,y:856,t:1527620876906};\\\", \\\"{x:1366,y:863,t:1527620876922};\\\", \\\"{x:1411,y:871,t:1527620876939};\\\", \\\"{x:1475,y:875,t:1527620876956};\\\", \\\"{x:1512,y:876,t:1527620876972};\\\", \\\"{x:1552,y:877,t:1527620876989};\\\", \\\"{x:1585,y:879,t:1527620877006};\\\", \\\"{x:1606,y:879,t:1527620877022};\\\", \\\"{x:1615,y:879,t:1527620877039};\\\", \\\"{x:1619,y:878,t:1527620877055};\\\", \\\"{x:1622,y:876,t:1527620877071};\\\", \\\"{x:1624,y:872,t:1527620877089};\\\", \\\"{x:1627,y:869,t:1527620877106};\\\", \\\"{x:1629,y:863,t:1527620877122};\\\", \\\"{x:1629,y:857,t:1527620877138};\\\", \\\"{x:1629,y:844,t:1527620877156};\\\", \\\"{x:1624,y:832,t:1527620877172};\\\", \\\"{x:1619,y:819,t:1527620877189};\\\", \\\"{x:1612,y:803,t:1527620877206};\\\", \\\"{x:1603,y:788,t:1527620877222};\\\", \\\"{x:1598,y:775,t:1527620877239};\\\", \\\"{x:1591,y:764,t:1527620877256};\\\", \\\"{x:1587,y:755,t:1527620877273};\\\", \\\"{x:1584,y:751,t:1527620877289};\\\", \\\"{x:1579,y:744,t:1527620877306};\\\", \\\"{x:1578,y:738,t:1527620877323};\\\", \\\"{x:1570,y:728,t:1527620877339};\\\", \\\"{x:1562,y:715,t:1527620877356};\\\", \\\"{x:1558,y:711,t:1527620877372};\\\", \\\"{x:1554,y:704,t:1527620877389};\\\", \\\"{x:1548,y:697,t:1527620877406};\\\", \\\"{x:1545,y:693,t:1527620877423};\\\", \\\"{x:1544,y:690,t:1527620877439};\\\", \\\"{x:1541,y:686,t:1527620877456};\\\", \\\"{x:1537,y:680,t:1527620877473};\\\", \\\"{x:1535,y:676,t:1527620877489};\\\", \\\"{x:1533,y:674,t:1527620877506};\\\", \\\"{x:1530,y:671,t:1527620877523};\\\", \\\"{x:1527,y:667,t:1527620877539};\\\", \\\"{x:1526,y:666,t:1527620877556};\\\", \\\"{x:1524,y:664,t:1527620877573};\\\", \\\"{x:1523,y:663,t:1527620877589};\\\", \\\"{x:1522,y:661,t:1527620877606};\\\", \\\"{x:1521,y:661,t:1527620877644};\\\", \\\"{x:1520,y:660,t:1527620877716};\\\", \\\"{x:1520,y:659,t:1527620878563};\\\", \\\"{x:1519,y:658,t:1527620878572};\\\", \\\"{x:1519,y:657,t:1527620878612};\\\", \\\"{x:1518,y:656,t:1527620878623};\\\", \\\"{x:1518,y:655,t:1527620878640};\\\", \\\"{x:1517,y:653,t:1527620878656};\\\", \\\"{x:1516,y:652,t:1527620878673};\\\", \\\"{x:1516,y:651,t:1527620878692};\\\", \\\"{x:1515,y:650,t:1527620878707};\\\", \\\"{x:1515,y:649,t:1527620878723};\\\", \\\"{x:1515,y:648,t:1527620878740};\\\", \\\"{x:1515,y:647,t:1527620878764};\\\", \\\"{x:1515,y:646,t:1527620878773};\\\", \\\"{x:1514,y:646,t:1527620878790};\\\", \\\"{x:1514,y:644,t:1527620878806};\\\", \\\"{x:1514,y:643,t:1527620878823};\\\", \\\"{x:1513,y:641,t:1527620878840};\\\", \\\"{x:1513,y:640,t:1527620878857};\\\", \\\"{x:1513,y:638,t:1527620878873};\\\", \\\"{x:1512,y:636,t:1527620878890};\\\", \\\"{x:1512,y:634,t:1527620878909};\\\", \\\"{x:1512,y:633,t:1527620878923};\\\", \\\"{x:1511,y:631,t:1527620878940};\\\", \\\"{x:1511,y:630,t:1527620878957};\\\", \\\"{x:1511,y:626,t:1527620878973};\\\", \\\"{x:1511,y:624,t:1527620878991};\\\", \\\"{x:1511,y:623,t:1527620879011};\\\", \\\"{x:1511,y:622,t:1527620879023};\\\", \\\"{x:1511,y:621,t:1527620879040};\\\", \\\"{x:1511,y:620,t:1527620879075};\\\", \\\"{x:1512,y:621,t:1527620879491};\\\", \\\"{x:1512,y:622,t:1527620879523};\\\", \\\"{x:1512,y:623,t:1527620879564};\\\", \\\"{x:1512,y:624,t:1527620879693};\\\", \\\"{x:1512,y:626,t:1527620880165};\\\", \\\"{x:1512,y:627,t:1527620880174};\\\", \\\"{x:1514,y:631,t:1527620880190};\\\", \\\"{x:1517,y:634,t:1527620880207};\\\", \\\"{x:1520,y:638,t:1527620880225};\\\", \\\"{x:1523,y:642,t:1527620880241};\\\", \\\"{x:1526,y:645,t:1527620880257};\\\", \\\"{x:1528,y:646,t:1527620880274};\\\", \\\"{x:1531,y:649,t:1527620880292};\\\", \\\"{x:1532,y:650,t:1527620880307};\\\", \\\"{x:1534,y:652,t:1527620880325};\\\", \\\"{x:1535,y:655,t:1527620880341};\\\", \\\"{x:1537,y:659,t:1527620880358};\\\", \\\"{x:1537,y:662,t:1527620880374};\\\", \\\"{x:1540,y:666,t:1527620880392};\\\", \\\"{x:1541,y:671,t:1527620880407};\\\", \\\"{x:1544,y:676,t:1527620880424};\\\", \\\"{x:1545,y:683,t:1527620880441};\\\", \\\"{x:1548,y:690,t:1527620880458};\\\", \\\"{x:1551,y:697,t:1527620880474};\\\", \\\"{x:1554,y:704,t:1527620880491};\\\", \\\"{x:1556,y:710,t:1527620880507};\\\", \\\"{x:1558,y:713,t:1527620880524};\\\", \\\"{x:1558,y:717,t:1527620880541};\\\", \\\"{x:1561,y:721,t:1527620880559};\\\", \\\"{x:1564,y:727,t:1527620880575};\\\", \\\"{x:1565,y:732,t:1527620880591};\\\", \\\"{x:1568,y:737,t:1527620880608};\\\", \\\"{x:1570,y:743,t:1527620880624};\\\", \\\"{x:1573,y:747,t:1527620880641};\\\", \\\"{x:1576,y:751,t:1527620880658};\\\", \\\"{x:1577,y:755,t:1527620880674};\\\", \\\"{x:1579,y:757,t:1527620880691};\\\", \\\"{x:1580,y:759,t:1527620880707};\\\", \\\"{x:1583,y:761,t:1527620880724};\\\", \\\"{x:1584,y:763,t:1527620880740};\\\", \\\"{x:1585,y:763,t:1527620880757};\\\", \\\"{x:1587,y:765,t:1527620880774};\\\", \\\"{x:1588,y:766,t:1527620880791};\\\", \\\"{x:1590,y:767,t:1527620880807};\\\", \\\"{x:1591,y:767,t:1527620880824};\\\", \\\"{x:1592,y:769,t:1527620880841};\\\", \\\"{x:1593,y:769,t:1527620880858};\\\", \\\"{x:1594,y:770,t:1527620880874};\\\", \\\"{x:1595,y:770,t:1527620880892};\\\", \\\"{x:1596,y:771,t:1527620880996};\\\", \\\"{x:1595,y:772,t:1527620881100};\\\", \\\"{x:1585,y:770,t:1527620881109};\\\", \\\"{x:1553,y:757,t:1527620881125};\\\", \\\"{x:1484,y:726,t:1527620881142};\\\", \\\"{x:1429,y:703,t:1527620881159};\\\", \\\"{x:1367,y:671,t:1527620881174};\\\", \\\"{x:1332,y:651,t:1527620881191};\\\", \\\"{x:1301,y:625,t:1527620881208};\\\", \\\"{x:1289,y:609,t:1527620881225};\\\", \\\"{x:1284,y:596,t:1527620881242};\\\", \\\"{x:1282,y:584,t:1527620881258};\\\", \\\"{x:1282,y:576,t:1527620881276};\\\", \\\"{x:1282,y:573,t:1527620881291};\\\", \\\"{x:1282,y:571,t:1527620881308};\\\", \\\"{x:1282,y:568,t:1527620881325};\\\", \\\"{x:1282,y:566,t:1527620881341};\\\", \\\"{x:1283,y:563,t:1527620881358};\\\", \\\"{x:1283,y:559,t:1527620881376};\\\", \\\"{x:1285,y:555,t:1527620881391};\\\", \\\"{x:1288,y:551,t:1527620881409};\\\", \\\"{x:1292,y:546,t:1527620881425};\\\", \\\"{x:1296,y:539,t:1527620881441};\\\", \\\"{x:1297,y:536,t:1527620881459};\\\", \\\"{x:1299,y:530,t:1527620881475};\\\", \\\"{x:1301,y:523,t:1527620881492};\\\", \\\"{x:1305,y:515,t:1527620881508};\\\", \\\"{x:1307,y:512,t:1527620881525};\\\", \\\"{x:1308,y:510,t:1527620881541};\\\", \\\"{x:1308,y:509,t:1527620881558};\\\", \\\"{x:1310,y:507,t:1527620881576};\\\", \\\"{x:1310,y:506,t:1527620881592};\\\", \\\"{x:1310,y:504,t:1527620881608};\\\", \\\"{x:1310,y:502,t:1527620881625};\\\", \\\"{x:1311,y:501,t:1527620881642};\\\", \\\"{x:1311,y:500,t:1527620881658};\\\", \\\"{x:1311,y:499,t:1527620881748};\\\", \\\"{x:1311,y:498,t:1527620881763};\\\", \\\"{x:1311,y:497,t:1527620881787};\\\", \\\"{x:1312,y:497,t:1527620882044};\\\", \\\"{x:1312,y:496,t:1527620882500};\\\", \\\"{x:1313,y:495,t:1527620882516};\\\", \\\"{x:1313,y:494,t:1527620883132};\\\", \\\"{x:1313,y:493,t:1527620883652};\\\", \\\"{x:1313,y:492,t:1527620883796};\\\", \\\"{x:1314,y:492,t:1527620884949};\\\", \\\"{x:1316,y:493,t:1527620885165};\\\", \\\"{x:1316,y:494,t:1527620885197};\\\", \\\"{x:1316,y:496,t:1527620885212};\\\", \\\"{x:1316,y:497,t:1527620891500};\\\", \\\"{x:1316,y:498,t:1527620891532};\\\", \\\"{x:1317,y:498,t:1527620892244};\\\", \\\"{x:1318,y:498,t:1527620892260};\\\", \\\"{x:1320,y:496,t:1527620892291};\\\", \\\"{x:1321,y:495,t:1527620892301};\\\", \\\"{x:1322,y:495,t:1527620892315};\\\", \\\"{x:1324,y:493,t:1527620892330};\\\", \\\"{x:1325,y:492,t:1527620893045};\\\", \\\"{x:1326,y:492,t:1527620893052};\\\", \\\"{x:1329,y:493,t:1527620894300};\\\", \\\"{x:1335,y:494,t:1527620894315};\\\", \\\"{x:1338,y:495,t:1527620894332};\\\", \\\"{x:1338,y:497,t:1527620894644};\\\", \\\"{x:1336,y:499,t:1527620894692};\\\", \\\"{x:1335,y:499,t:1527620894700};\\\", \\\"{x:1330,y:500,t:1527620894716};\\\", \\\"{x:1328,y:501,t:1527620894732};\\\", \\\"{x:1327,y:502,t:1527620894756};\\\", \\\"{x:1326,y:502,t:1527620894796};\\\", \\\"{x:1325,y:502,t:1527620894803};\\\", \\\"{x:1324,y:502,t:1527620894820};\\\", \\\"{x:1323,y:502,t:1527620894836};\\\", \\\"{x:1321,y:501,t:1527620894849};\\\", \\\"{x:1319,y:500,t:1527620894876};\\\", \\\"{x:1320,y:500,t:1527620895053};\\\", \\\"{x:1321,y:500,t:1527620895108};\\\", \\\"{x:1322,y:500,t:1527620895156};\\\", \\\"{x:1322,y:501,t:1527620895205};\\\", \\\"{x:1322,y:502,t:1527620895220};\\\", \\\"{x:1322,y:504,t:1527620895233};\\\", \\\"{x:1322,y:506,t:1527620895252};\\\", \\\"{x:1322,y:507,t:1527620895265};\\\", \\\"{x:1322,y:510,t:1527620895283};\\\", \\\"{x:1322,y:514,t:1527620895299};\\\", \\\"{x:1322,y:524,t:1527620895316};\\\", \\\"{x:1320,y:531,t:1527620895333};\\\", \\\"{x:1318,y:537,t:1527620895349};\\\", \\\"{x:1317,y:541,t:1527620895366};\\\", \\\"{x:1316,y:543,t:1527620895383};\\\", \\\"{x:1315,y:548,t:1527620895399};\\\", \\\"{x:1312,y:551,t:1527620895416};\\\", \\\"{x:1312,y:553,t:1527620895433};\\\", \\\"{x:1311,y:554,t:1527620895449};\\\", \\\"{x:1311,y:556,t:1527620895466};\\\", \\\"{x:1311,y:558,t:1527620895483};\\\", \\\"{x:1311,y:559,t:1527620895499};\\\", \\\"{x:1311,y:562,t:1527620895515};\\\", \\\"{x:1311,y:565,t:1527620895532};\\\", \\\"{x:1310,y:567,t:1527620895549};\\\", \\\"{x:1310,y:568,t:1527620895572};\\\", \\\"{x:1310,y:570,t:1527620895583};\\\", \\\"{x:1309,y:571,t:1527620895709};\\\", \\\"{x:1308,y:571,t:1527620895732};\\\", \\\"{x:1308,y:570,t:1527620895750};\\\", \\\"{x:1307,y:567,t:1527620895766};\\\", \\\"{x:1306,y:565,t:1527620895787};\\\", \\\"{x:1306,y:564,t:1527620895799};\\\", \\\"{x:1306,y:560,t:1527620895815};\\\", \\\"{x:1305,y:554,t:1527620895833};\\\", \\\"{x:1305,y:549,t:1527620895849};\\\", \\\"{x:1303,y:544,t:1527620895865};\\\", \\\"{x:1303,y:540,t:1527620895882};\\\", \\\"{x:1302,y:535,t:1527620895900};\\\", \\\"{x:1302,y:531,t:1527620895915};\\\", \\\"{x:1301,y:528,t:1527620895933};\\\", \\\"{x:1301,y:525,t:1527620895950};\\\", \\\"{x:1301,y:521,t:1527620895966};\\\", \\\"{x:1301,y:516,t:1527620895983};\\\", \\\"{x:1301,y:511,t:1527620896000};\\\", \\\"{x:1301,y:507,t:1527620896015};\\\", \\\"{x:1302,y:505,t:1527620896032};\\\", \\\"{x:1303,y:503,t:1527620896049};\\\", \\\"{x:1303,y:502,t:1527620896066};\\\", \\\"{x:1303,y:500,t:1527620896082};\\\", \\\"{x:1305,y:496,t:1527620896100};\\\", \\\"{x:1305,y:494,t:1527620896115};\\\", \\\"{x:1306,y:493,t:1527620896132};\\\", \\\"{x:1307,y:492,t:1527620896149};\\\", \\\"{x:1306,y:492,t:1527620896243};\\\", \\\"{x:1303,y:492,t:1527620896251};\\\", \\\"{x:1301,y:492,t:1527620896267};\\\", \\\"{x:1296,y:492,t:1527620896283};\\\", \\\"{x:1294,y:492,t:1527620896299};\\\", \\\"{x:1293,y:492,t:1527620896317};\\\", \\\"{x:1295,y:492,t:1527620896476};\\\", \\\"{x:1298,y:492,t:1527620896492};\\\", \\\"{x:1299,y:492,t:1527620896500};\\\", \\\"{x:1305,y:492,t:1527620896517};\\\", \\\"{x:1311,y:492,t:1527620896533};\\\", \\\"{x:1314,y:492,t:1527620896549};\\\", \\\"{x:1317,y:492,t:1527620896567};\\\", \\\"{x:1318,y:492,t:1527620896588};\\\", \\\"{x:1319,y:492,t:1527620896611};\\\", \\\"{x:1320,y:492,t:1527620896627};\\\", \\\"{x:1321,y:493,t:1527620896659};\\\", \\\"{x:1321,y:494,t:1527620896924};\\\", \\\"{x:1321,y:496,t:1527620896933};\\\", \\\"{x:1312,y:502,t:1527620896950};\\\", \\\"{x:1297,y:513,t:1527620896966};\\\", \\\"{x:1273,y:531,t:1527620896983};\\\", \\\"{x:1237,y:561,t:1527620896999};\\\", \\\"{x:1199,y:593,t:1527620897016};\\\", \\\"{x:1180,y:613,t:1527620897033};\\\", \\\"{x:1166,y:632,t:1527620897050};\\\", \\\"{x:1134,y:651,t:1527620897066};\\\", \\\"{x:1080,y:697,t:1527620897083};\\\", \\\"{x:1064,y:713,t:1527620897100};\\\", \\\"{x:1055,y:724,t:1527620897116};\\\", \\\"{x:1052,y:729,t:1527620897133};\\\", \\\"{x:1051,y:730,t:1527620897150};\\\", \\\"{x:1051,y:733,t:1527620897166};\\\", \\\"{x:1051,y:735,t:1527620897195};\\\", \\\"{x:1051,y:736,t:1527620897220};\\\", \\\"{x:1053,y:736,t:1527620897308};\\\", \\\"{x:1054,y:736,t:1527620897324};\\\", \\\"{x:1056,y:735,t:1527620897334};\\\", \\\"{x:1064,y:731,t:1527620897350};\\\", \\\"{x:1070,y:728,t:1527620897367};\\\", \\\"{x:1075,y:726,t:1527620897384};\\\", \\\"{x:1077,y:726,t:1527620897400};\\\", \\\"{x:1080,y:726,t:1527620897417};\\\", \\\"{x:1083,y:726,t:1527620897433};\\\", \\\"{x:1087,y:726,t:1527620897450};\\\", \\\"{x:1093,y:726,t:1527620897467};\\\", \\\"{x:1097,y:726,t:1527620897483};\\\", \\\"{x:1099,y:724,t:1527620897500};\\\", \\\"{x:1100,y:724,t:1527620897516};\\\", \\\"{x:1102,y:724,t:1527620897534};\\\", \\\"{x:1107,y:724,t:1527620897551};\\\", \\\"{x:1112,y:724,t:1527620897566};\\\", \\\"{x:1121,y:723,t:1527620897584};\\\", \\\"{x:1127,y:723,t:1527620897601};\\\", \\\"{x:1132,y:722,t:1527620897617};\\\", \\\"{x:1138,y:720,t:1527620897634};\\\", \\\"{x:1142,y:720,t:1527620897650};\\\", \\\"{x:1151,y:720,t:1527620897667};\\\", \\\"{x:1173,y:720,t:1527620897684};\\\", \\\"{x:1193,y:720,t:1527620897700};\\\", \\\"{x:1215,y:720,t:1527620897717};\\\", \\\"{x:1234,y:720,t:1527620897734};\\\", \\\"{x:1249,y:720,t:1527620897751};\\\", \\\"{x:1264,y:720,t:1527620897767};\\\", \\\"{x:1275,y:720,t:1527620897784};\\\", \\\"{x:1284,y:720,t:1527620897801};\\\", \\\"{x:1290,y:720,t:1527620897817};\\\", \\\"{x:1295,y:720,t:1527620897834};\\\", \\\"{x:1301,y:720,t:1527620897851};\\\", \\\"{x:1305,y:720,t:1527620897867};\\\", \\\"{x:1308,y:720,t:1527620897884};\\\", \\\"{x:1310,y:720,t:1527620897916};\\\", \\\"{x:1312,y:720,t:1527620897934};\\\", \\\"{x:1315,y:720,t:1527620897951};\\\", \\\"{x:1316,y:720,t:1527620897967};\\\", \\\"{x:1318,y:720,t:1527620897996};\\\", \\\"{x:1318,y:721,t:1527620898004};\\\", \\\"{x:1319,y:722,t:1527620898017};\\\", \\\"{x:1321,y:723,t:1527620898034};\\\", \\\"{x:1324,y:724,t:1527620898051};\\\", \\\"{x:1325,y:724,t:1527620898067};\\\", \\\"{x:1326,y:726,t:1527620898084};\\\", \\\"{x:1327,y:726,t:1527620898101};\\\", \\\"{x:1329,y:727,t:1527620898117};\\\", \\\"{x:1331,y:727,t:1527620898140};\\\", \\\"{x:1331,y:728,t:1527620898151};\\\", \\\"{x:1332,y:729,t:1527620898167};\\\", \\\"{x:1334,y:730,t:1527620898244};\\\", \\\"{x:1334,y:731,t:1527620898276};\\\", \\\"{x:1334,y:732,t:1527620898300};\\\", \\\"{x:1335,y:734,t:1527620898339};\\\", \\\"{x:1335,y:735,t:1527620898363};\\\", \\\"{x:1335,y:736,t:1527620898420};\\\", \\\"{x:1335,y:737,t:1527620898564};\\\", \\\"{x:1335,y:738,t:1527620898667};\\\", \\\"{x:1334,y:738,t:1527620900565};\\\", \\\"{x:1333,y:738,t:1527620901187};\\\", \\\"{x:1332,y:738,t:1527620901252};\\\", \\\"{x:1331,y:738,t:1527620902460};\\\", \\\"{x:1329,y:739,t:1527620902476};\\\", \\\"{x:1328,y:740,t:1527620902516};\\\", \\\"{x:1327,y:741,t:1527620902540};\\\", \\\"{x:1327,y:742,t:1527620902564};\\\", \\\"{x:1326,y:742,t:1527620902596};\\\", \\\"{x:1326,y:743,t:1527620902652};\\\", \\\"{x:1326,y:744,t:1527620903164};\\\", \\\"{x:1328,y:744,t:1527620903323};\\\", \\\"{x:1329,y:744,t:1527620903637};\\\", \\\"{x:1328,y:744,t:1527620904067};\\\", \\\"{x:1326,y:744,t:1527620904075};\\\", \\\"{x:1324,y:744,t:1527620904087};\\\", \\\"{x:1321,y:744,t:1527620904104};\\\", \\\"{x:1318,y:743,t:1527620904121};\\\", \\\"{x:1314,y:743,t:1527620904137};\\\", \\\"{x:1305,y:743,t:1527620904154};\\\", \\\"{x:1294,y:743,t:1527620904170};\\\", \\\"{x:1288,y:743,t:1527620904187};\\\", \\\"{x:1275,y:743,t:1527620904204};\\\", \\\"{x:1269,y:743,t:1527620904222};\\\", \\\"{x:1265,y:743,t:1527620904237};\\\", \\\"{x:1264,y:743,t:1527620904255};\\\", \\\"{x:1263,y:743,t:1527620904271};\\\", \\\"{x:1262,y:743,t:1527620904288};\\\", \\\"{x:1261,y:742,t:1527620904316};\\\", \\\"{x:1260,y:741,t:1527620904348};\\\", \\\"{x:1260,y:740,t:1527620904516};\\\", \\\"{x:1260,y:739,t:1527620904540};\\\", \\\"{x:1260,y:738,t:1527620904563};\\\", \\\"{x:1260,y:737,t:1527620904604};\\\", \\\"{x:1260,y:736,t:1527620904622};\\\", \\\"{x:1261,y:735,t:1527620904638};\\\", \\\"{x:1262,y:734,t:1527620904654};\\\", \\\"{x:1262,y:733,t:1527620904685};\\\", \\\"{x:1263,y:732,t:1527620904692};\\\", \\\"{x:1264,y:730,t:1527620904821};\\\", \\\"{x:1265,y:729,t:1527620905146};\\\", \\\"{x:1266,y:728,t:1527620905171};\\\", \\\"{x:1267,y:726,t:1527620905187};\\\", \\\"{x:1269,y:725,t:1527620905204};\\\", \\\"{x:1270,y:724,t:1527620905221};\\\", \\\"{x:1272,y:722,t:1527620905238};\\\", \\\"{x:1274,y:721,t:1527620905259};\\\", \\\"{x:1275,y:721,t:1527620905274};\\\", \\\"{x:1277,y:721,t:1527620905288};\\\", \\\"{x:1280,y:719,t:1527620905304};\\\", \\\"{x:1281,y:718,t:1527620905321};\\\", \\\"{x:1283,y:718,t:1527620905338};\\\", \\\"{x:1284,y:718,t:1527620905509};\\\", \\\"{x:1284,y:719,t:1527620905524};\\\", \\\"{x:1284,y:720,t:1527620905564};\\\", \\\"{x:1284,y:721,t:1527620905797};\\\", \\\"{x:1283,y:722,t:1527620905844};\\\", \\\"{x:1283,y:723,t:1527620906027};\\\", \\\"{x:1283,y:724,t:1527620906108};\\\", \\\"{x:1283,y:725,t:1527620906164};\\\", \\\"{x:1283,y:726,t:1527620906260};\\\", \\\"{x:1283,y:727,t:1527620906308};\\\", \\\"{x:1283,y:728,t:1527620906340};\\\", \\\"{x:1283,y:729,t:1527620906380};\\\", \\\"{x:1283,y:730,t:1527620906404};\\\", \\\"{x:1283,y:731,t:1527620906420};\\\", \\\"{x:1282,y:731,t:1527620906428};\\\", \\\"{x:1281,y:732,t:1527620906444};\\\", \\\"{x:1281,y:733,t:1527620906483};\\\", \\\"{x:1281,y:734,t:1527620906516};\\\", \\\"{x:1280,y:734,t:1527620906524};\\\", \\\"{x:1280,y:735,t:1527620906572};\\\", \\\"{x:1280,y:736,t:1527620906595};\\\", \\\"{x:1280,y:737,t:1527620906627};\\\", \\\"{x:1280,y:738,t:1527620906691};\\\", \\\"{x:1280,y:739,t:1527620906829};\\\", \\\"{x:1280,y:740,t:1527620906908};\\\", \\\"{x:1280,y:741,t:1527620907044};\\\", \\\"{x:1278,y:742,t:1527620907076};\\\", \\\"{x:1278,y:743,t:1527620907228};\\\", \\\"{x:1278,y:744,t:1527620907325};\\\", \\\"{x:1278,y:745,t:1527620907380};\\\", \\\"{x:1278,y:746,t:1527620907420};\\\", \\\"{x:1278,y:747,t:1527620907517};\\\", \\\"{x:1279,y:749,t:1527620907556};\\\", \\\"{x:1280,y:749,t:1527620907588};\\\", \\\"{x:1281,y:749,t:1527620907660};\\\", \\\"{x:1283,y:749,t:1527620908084};\\\", \\\"{x:1284,y:749,t:1527620908389};\\\", \\\"{x:1284,y:750,t:1527620908407};\\\", \\\"{x:1286,y:750,t:1527620908492};\\\", \\\"{x:1287,y:750,t:1527620908532};\\\", \\\"{x:1288,y:751,t:1527620909789};\\\", \\\"{x:1289,y:752,t:1527620910155};\\\", \\\"{x:1290,y:752,t:1527620910236};\\\", \\\"{x:1290,y:753,t:1527620910252};\\\", \\\"{x:1292,y:754,t:1527620910284};\\\", \\\"{x:1293,y:754,t:1527620910356};\\\", \\\"{x:1294,y:755,t:1527620910380};\\\", \\\"{x:1295,y:755,t:1527620910420};\\\", \\\"{x:1296,y:756,t:1527620910524};\\\", \\\"{x:1298,y:756,t:1527620910910};\\\", \\\"{x:1299,y:756,t:1527620910959};\\\", \\\"{x:1300,y:756,t:1527620911023};\\\", \\\"{x:1301,y:756,t:1527620911223};\\\", \\\"{x:1302,y:756,t:1527620911255};\\\", \\\"{x:1302,y:757,t:1527620911358};\\\", \\\"{x:1302,y:758,t:1527620911382};\\\", \\\"{x:1302,y:759,t:1527620911454};\\\", \\\"{x:1302,y:760,t:1527620911462};\\\", \\\"{x:1302,y:761,t:1527620911583};\\\", \\\"{x:1301,y:762,t:1527620911631};\\\", \\\"{x:1301,y:763,t:1527620911870};\\\", \\\"{x:1299,y:764,t:1527620911878};\\\", \\\"{x:1298,y:765,t:1527620911958};\\\", \\\"{x:1298,y:766,t:1527620912015};\\\", \\\"{x:1297,y:767,t:1527620912054};\\\", \\\"{x:1296,y:767,t:1527620912254};\\\", \\\"{x:1295,y:767,t:1527620912718};\\\", \\\"{x:1295,y:765,t:1527620913751};\\\", \\\"{x:1295,y:764,t:1527620913822};\\\", \\\"{x:1295,y:763,t:1527620914221};\\\", \\\"{x:1293,y:763,t:1527620915679};\\\", \\\"{x:1292,y:759,t:1527620915702};\\\", \\\"{x:1292,y:756,t:1527620915713};\\\", \\\"{x:1291,y:754,t:1527620917582};\\\", \\\"{x:1291,y:753,t:1527620917638};\\\", \\\"{x:1290,y:753,t:1527620917687};\\\", \\\"{x:1290,y:752,t:1527620917710};\\\", \\\"{x:1289,y:750,t:1527620917719};\\\", \\\"{x:1289,y:748,t:1527620917790};\\\", \\\"{x:1288,y:748,t:1527620917798};\\\", \\\"{x:1288,y:747,t:1527620917838};\\\", \\\"{x:1287,y:747,t:1527620917886};\\\", \\\"{x:1287,y:745,t:1527620917926};\\\", \\\"{x:1287,y:744,t:1527620917958};\\\", \\\"{x:1286,y:743,t:1527620917966};\\\", \\\"{x:1285,y:743,t:1527620919143};\\\", \\\"{x:1282,y:743,t:1527620919150};\\\", \\\"{x:1276,y:743,t:1527620919166};\\\", \\\"{x:1268,y:743,t:1527620919181};\\\", \\\"{x:1243,y:740,t:1527620919198};\\\", \\\"{x:1204,y:734,t:1527620919216};\\\", \\\"{x:1146,y:726,t:1527620919231};\\\", \\\"{x:1051,y:711,t:1527620919248};\\\", \\\"{x:951,y:697,t:1527620919265};\\\", \\\"{x:859,y:684,t:1527620919281};\\\", \\\"{x:784,y:673,t:1527620919299};\\\", \\\"{x:732,y:661,t:1527620919316};\\\", \\\"{x:713,y:655,t:1527620919332};\\\", \\\"{x:705,y:651,t:1527620919347};\\\", \\\"{x:704,y:650,t:1527620919365};\\\", \\\"{x:703,y:648,t:1527620919389};\\\", \\\"{x:701,y:648,t:1527620919397};\\\", \\\"{x:697,y:648,t:1527620919407};\\\", \\\"{x:684,y:647,t:1527620919424};\\\", \\\"{x:674,y:646,t:1527620919441};\\\", \\\"{x:664,y:644,t:1527620919456};\\\", \\\"{x:653,y:643,t:1527620919473};\\\", \\\"{x:640,y:642,t:1527620919491};\\\", \\\"{x:628,y:639,t:1527620919507};\\\", \\\"{x:618,y:638,t:1527620919525};\\\", \\\"{x:614,y:637,t:1527620919541};\\\", \\\"{x:612,y:637,t:1527620919559};\\\", \\\"{x:610,y:637,t:1527620919576};\\\", \\\"{x:609,y:637,t:1527620919591};\\\", \\\"{x:608,y:637,t:1527620919609};\\\", \\\"{x:606,y:637,t:1527620919626};\\\", \\\"{x:604,y:637,t:1527620919642};\\\", \\\"{x:604,y:636,t:1527620919660};\\\", \\\"{x:603,y:636,t:1527620919677};\\\", \\\"{x:601,y:635,t:1527620920190};\\\", \\\"{x:595,y:629,t:1527620920200};\\\", \\\"{x:590,y:624,t:1527620920209};\\\", \\\"{x:580,y:618,t:1527620920226};\\\", \\\"{x:573,y:612,t:1527620920243};\\\", \\\"{x:567,y:606,t:1527620920259};\\\", \\\"{x:559,y:599,t:1527620920276};\\\", \\\"{x:546,y:590,t:1527620920293};\\\", \\\"{x:524,y:578,t:1527620920310};\\\", \\\"{x:515,y:575,t:1527620920326};\\\", \\\"{x:506,y:571,t:1527620920342};\\\", \\\"{x:491,y:568,t:1527620920360};\\\", \\\"{x:477,y:565,t:1527620920375};\\\", \\\"{x:464,y:563,t:1527620920393};\\\", \\\"{x:452,y:563,t:1527620920410};\\\", \\\"{x:434,y:563,t:1527620920426};\\\", \\\"{x:407,y:563,t:1527620920444};\\\", \\\"{x:380,y:563,t:1527620920460};\\\", \\\"{x:363,y:563,t:1527620920476};\\\", \\\"{x:354,y:563,t:1527620920493};\\\", \\\"{x:342,y:563,t:1527620920509};\\\", \\\"{x:332,y:563,t:1527620920525};\\\", \\\"{x:315,y:563,t:1527620920543};\\\", \\\"{x:299,y:563,t:1527620920560};\\\", \\\"{x:282,y:563,t:1527620920576};\\\", \\\"{x:268,y:563,t:1527620920595};\\\", \\\"{x:258,y:563,t:1527620920610};\\\", \\\"{x:248,y:563,t:1527620920626};\\\", \\\"{x:240,y:563,t:1527620920642};\\\", \\\"{x:236,y:563,t:1527620920660};\\\", \\\"{x:233,y:563,t:1527620920675};\\\", \\\"{x:230,y:564,t:1527620920692};\\\", \\\"{x:227,y:565,t:1527620920709};\\\", \\\"{x:227,y:566,t:1527620920734};\\\", \\\"{x:231,y:566,t:1527620920749};\\\", \\\"{x:239,y:567,t:1527620920760};\\\", \\\"{x:261,y:570,t:1527620920776};\\\", \\\"{x:293,y:570,t:1527620920795};\\\", \\\"{x:323,y:570,t:1527620920810};\\\", \\\"{x:359,y:570,t:1527620920826};\\\", \\\"{x:383,y:570,t:1527620920844};\\\", \\\"{x:396,y:570,t:1527620920860};\\\", \\\"{x:399,y:570,t:1527620920876};\\\", \\\"{x:400,y:570,t:1527620920917};\\\", \\\"{x:400,y:571,t:1527620921006};\\\", \\\"{x:400,y:572,t:1527620921455};\\\", \\\"{x:401,y:572,t:1527620921462};\\\", \\\"{x:405,y:572,t:1527620921478};\\\", \\\"{x:415,y:572,t:1527620921494};\\\", \\\"{x:423,y:572,t:1527620921511};\\\", \\\"{x:436,y:572,t:1527620921527};\\\", \\\"{x:445,y:572,t:1527620921544};\\\", \\\"{x:459,y:572,t:1527620921561};\\\", \\\"{x:476,y:572,t:1527620921577};\\\", \\\"{x:492,y:572,t:1527620921594};\\\", \\\"{x:513,y:572,t:1527620921612};\\\", \\\"{x:530,y:572,t:1527620921627};\\\", \\\"{x:544,y:572,t:1527620921644};\\\", \\\"{x:562,y:572,t:1527620921661};\\\", \\\"{x:567,y:572,t:1527620921677};\\\", \\\"{x:570,y:572,t:1527620921694};\\\", \\\"{x:574,y:573,t:1527620921711};\\\", \\\"{x:574,y:575,t:1527620921742};\\\", \\\"{x:574,y:576,t:1527620921766};\\\", \\\"{x:574,y:578,t:1527620921777};\\\", \\\"{x:569,y:581,t:1527620921794};\\\", \\\"{x:559,y:583,t:1527620921811};\\\", \\\"{x:541,y:586,t:1527620921827};\\\", \\\"{x:524,y:587,t:1527620921844};\\\", \\\"{x:516,y:589,t:1527620921862};\\\", \\\"{x:512,y:591,t:1527620921877};\\\", \\\"{x:505,y:591,t:1527620921894};\\\", \\\"{x:500,y:591,t:1527620921911};\\\", \\\"{x:492,y:591,t:1527620921927};\\\", \\\"{x:482,y:592,t:1527620921944};\\\", \\\"{x:469,y:593,t:1527620921961};\\\", \\\"{x:454,y:593,t:1527620921977};\\\", \\\"{x:438,y:593,t:1527620921993};\\\", \\\"{x:419,y:593,t:1527620922011};\\\", \\\"{x:403,y:595,t:1527620922028};\\\", \\\"{x:392,y:596,t:1527620922044};\\\", \\\"{x:383,y:599,t:1527620922061};\\\", \\\"{x:381,y:600,t:1527620922077};\\\", \\\"{x:381,y:601,t:1527620922094};\\\", \\\"{x:382,y:603,t:1527620922111};\\\", \\\"{x:383,y:604,t:1527620922128};\\\", \\\"{x:383,y:606,t:1527620922144};\\\", \\\"{x:384,y:610,t:1527620922161};\\\", \\\"{x:386,y:614,t:1527620922178};\\\", \\\"{x:389,y:621,t:1527620922194};\\\", \\\"{x:392,y:624,t:1527620922212};\\\", \\\"{x:393,y:626,t:1527620922228};\\\", \\\"{x:394,y:628,t:1527620922244};\\\", \\\"{x:396,y:629,t:1527620922261};\\\", \\\"{x:397,y:631,t:1527620922278};\\\", \\\"{x:397,y:632,t:1527620922294};\\\", \\\"{x:397,y:633,t:1527620922317};\\\", \\\"{x:397,y:634,t:1527620922333};\\\", \\\"{x:397,y:635,t:1527620922357};\\\", \\\"{x:397,y:636,t:1527620922381};\\\", \\\"{x:397,y:637,t:1527620922394};\\\", \\\"{x:397,y:638,t:1527620922413};\\\", \\\"{x:397,y:639,t:1527620922428};\\\", \\\"{x:395,y:641,t:1527620922445};\\\", \\\"{x:394,y:643,t:1527620922461};\\\", \\\"{x:394,y:644,t:1527620922478};\\\", \\\"{x:394,y:646,t:1527620922495};\\\", \\\"{x:393,y:647,t:1527620922517};\\\", \\\"{x:393,y:648,t:1527620922660};\\\", \\\"{x:391,y:650,t:1527620922678};\\\", \\\"{x:392,y:651,t:1527620922822};\\\", \\\"{x:392,y:652,t:1527620922853};\\\", \\\"{x:394,y:654,t:1527620922878};\\\", \\\"{x:394,y:655,t:1527620922896};\\\", \\\"{x:394,y:656,t:1527620922911};\\\", \\\"{x:395,y:659,t:1527620922929};\\\", \\\"{x:395,y:661,t:1527620922945};\\\", \\\"{x:397,y:666,t:1527620922963};\\\", \\\"{x:398,y:669,t:1527620922978};\\\", \\\"{x:399,y:677,t:1527620922995};\\\", \\\"{x:402,y:686,t:1527620923012};\\\", \\\"{x:405,y:694,t:1527620923029};\\\", \\\"{x:406,y:698,t:1527620923045};\\\", \\\"{x:407,y:701,t:1527620923062};\\\", \\\"{x:408,y:705,t:1527620923079};\\\", \\\"{x:408,y:708,t:1527620923095};\\\", \\\"{x:408,y:711,t:1527620923112};\\\", \\\"{x:408,y:713,t:1527620923130};\\\", \\\"{x:408,y:715,t:1527620923145};\\\", \\\"{x:408,y:718,t:1527620923162};\\\", \\\"{x:408,y:720,t:1527620923179};\\\", \\\"{x:408,y:723,t:1527620923195};\\\", \\\"{x:408,y:724,t:1527620923212};\\\", \\\"{x:408,y:727,t:1527620923229};\\\", \\\"{x:409,y:728,t:1527620923245};\\\", \\\"{x:410,y:729,t:1527620923262};\\\", \\\"{x:410,y:731,t:1527620923285};\\\", \\\"{x:410,y:733,t:1527620923317};\\\", \\\"{x:411,y:733,t:1527620923329};\\\", \\\"{x:412,y:734,t:1527620923445};\\\", \\\"{x:412,y:735,t:1527620923463};\\\", \\\"{x:412,y:736,t:1527620923565};\\\", \\\"{x:412,y:737,t:1527620923749};\\\", \\\"{x:412,y:738,t:1527620925406};\\\", \\\"{x:413,y:738,t:1527620925518};\\\", \\\"{x:414,y:738,t:1527620925622};\\\", \\\"{x:413,y:738,t:1527620925950};\\\", \\\"{x:412,y:738,t:1527620925982};\\\", \\\"{x:410,y:738,t:1527620926022};\\\", \\\"{x:409,y:738,t:1527620926038};\\\", \\\"{x:408,y:738,t:1527620926054};\\\", \\\"{x:406,y:738,t:1527620926070};\\\", \\\"{x:406,y:737,t:1527620926094};\\\", \\\"{x:405,y:737,t:1527620926102};\\\", \\\"{x:403,y:737,t:1527620926118};\\\", \\\"{x:402,y:737,t:1527620926134};\\\", \\\"{x:401,y:737,t:1527620926150};\\\", \\\"{x:400,y:737,t:1527620926168};\\\", \\\"{x:399,y:737,t:1527620926185};\\\", \\\"{x:397,y:737,t:1527620926200};\\\", \\\"{x:395,y:737,t:1527620926230};\\\", \\\"{x:394,y:737,t:1527620926294};\\\", \\\"{x:393,y:737,t:1527620926366};\\\", \\\"{x:392,y:737,t:1527620926407};\\\", \\\"{x:391,y:737,t:1527620926438};\\\", \\\"{x:391,y:738,t:1527620926478};\\\", \\\"{x:390,y:739,t:1527620926559};\\\", \\\"{x:389,y:739,t:1527620926670};\\\", \\\"{x:388,y:739,t:1527620926853};\\\", \\\"{x:388,y:740,t:1527620927895};\\\", \\\"{x:390,y:742,t:1527620927958};\\\", \\\"{x:391,y:744,t:1527620927974};\\\", \\\"{x:391,y:745,t:1527620927998};\\\", \\\"{x:391,y:746,t:1527620928006};\\\", \\\"{x:391,y:747,t:1527620928021};\\\", \\\"{x:391,y:749,t:1527620928462};\\\", \\\"{x:392,y:749,t:1527620928486};\\\", \\\"{x:392,y:750,t:1527620928502};\\\", \\\"{x:393,y:751,t:1527620928518};\\\", \\\"{x:394,y:752,t:1527620928542};\\\", \\\"{x:394,y:753,t:1527620928613};\\\", \\\"{x:394,y:755,t:1527620929262};\\\", \\\"{x:394,y:756,t:1527620933502};\\\", \\\"{x:394,y:758,t:1527620933966};\\\", \\\"{x:394,y:759,t:1527620934102};\\\", \\\"{x:394,y:760,t:1527620934158};\\\", \\\"{x:393,y:762,t:1527620934318};\\\", \\\"{x:393,y:764,t:1527620934455};\\\", \\\"{x:393,y:766,t:1527620934574};\\\", \\\"{x:393,y:767,t:1527620934790};\\\", \\\"{x:393,y:768,t:1527620934862};\\\", \\\"{x:393,y:769,t:1527620935150};\\\", \\\"{x:393,y:770,t:1527620935166};\\\", \\\"{x:393,y:771,t:1527620935182};\\\", \\\"{x:393,y:773,t:1527620935199};\\\", \\\"{x:394,y:775,t:1527620935222};\\\", \\\"{x:395,y:776,t:1527620935238};\\\", \\\"{x:395,y:777,t:1527620935249};\\\", \\\"{x:395,y:778,t:1527620935302};\\\", \\\"{x:395,y:779,t:1527620935325};\\\", \\\"{x:395,y:780,t:1527620935446};\\\", \\\"{x:396,y:781,t:1527620935494};\\\", \\\"{x:397,y:782,t:1527620935535};\\\", \\\"{x:398,y:783,t:1527620935695};\\\", \\\"{x:398,y:784,t:1527620935758};\\\", \\\"{x:399,y:784,t:1527620935782};\\\", \\\"{x:400,y:784,t:1527620935870};\\\", \\\"{x:400,y:785,t:1527620935910};\\\", \\\"{x:402,y:785,t:1527620935942};\\\", \\\"{x:403,y:786,t:1527620935958};\\\", \\\"{x:403,y:787,t:1527620936015};\\\", \\\"{x:405,y:787,t:1527620936175};\\\", \\\"{x:405,y:788,t:1527620936879};\\\", \\\"{x:404,y:789,t:1527620937447};\\\", \\\"{x:403,y:790,t:1527620937759};\\\", \\\"{x:403,y:791,t:1527620937886};\\\", \\\"{x:402,y:791,t:1527620938038};\\\", \\\"{x:401,y:792,t:1527620938134};\\\", \\\"{x:401,y:793,t:1527620938446};\\\", \\\"{x:400,y:793,t:1527620938454};\\\", \\\"{x:400,y:794,t:1527620938622};\\\", \\\"{x:400,y:795,t:1527620938783};\\\", \\\"{x:399,y:795,t:1527620938814};\\\", \\\"{x:399,y:796,t:1527620938990};\\\", \\\"{x:399,y:797,t:1527620940406};\\\", \\\"{x:399,y:798,t:1527620940438};\\\", \\\"{x:399,y:799,t:1527620940613};\\\", \\\"{x:400,y:799,t:1527620940701};\\\", \\\"{x:402,y:799,t:1527620940733};\\\", \\\"{x:403,y:799,t:1527620940757};\\\", \\\"{x:405,y:799,t:1527620940774};\\\", \\\"{x:406,y:799,t:1527620940806};\\\", \\\"{x:407,y:799,t:1527620940846};\\\", \\\"{x:408,y:799,t:1527620940894};\\\", \\\"{x:409,y:798,t:1527620941278};\\\", \\\"{x:410,y:796,t:1527620941351};\\\", \\\"{x:411,y:795,t:1527620941406};\\\", \\\"{x:412,y:794,t:1527620941542};\\\", \\\"{x:413,y:794,t:1527620941566};\\\", \\\"{x:415,y:794,t:1527620941576};\\\", \\\"{x:419,y:794,t:1527620941592};\\\", \\\"{x:425,y:794,t:1527620941610};\\\", \\\"{x:431,y:794,t:1527620941627};\\\", \\\"{x:437,y:794,t:1527620941643};\\\", \\\"{x:443,y:794,t:1527620941660};\\\", \\\"{x:448,y:794,t:1527620941676};\\\", \\\"{x:451,y:794,t:1527620941693};\\\", \\\"{x:455,y:794,t:1527620941709};\\\", \\\"{x:458,y:794,t:1527620941726};\\\", \\\"{x:459,y:794,t:1527620941744};\\\", \\\"{x:461,y:793,t:1527620941759};\\\", \\\"{x:462,y:792,t:1527620941776};\\\", \\\"{x:463,y:791,t:1527620941813};\\\", \\\"{x:464,y:790,t:1527620941830};\\\", \\\"{x:465,y:790,t:1527620941843};\\\", \\\"{x:466,y:789,t:1527620941858};\\\", \\\"{x:468,y:788,t:1527620941876};\\\", \\\"{x:470,y:786,t:1527620941893};\\\", \\\"{x:472,y:785,t:1527620941909};\\\", \\\"{x:476,y:782,t:1527620941926};\\\", \\\"{x:479,y:781,t:1527620941943};\\\", \\\"{x:486,y:778,t:1527620941959};\\\", \\\"{x:491,y:776,t:1527620941976};\\\", \\\"{x:502,y:771,t:1527620941993};\\\", \\\"{x:511,y:768,t:1527620942010};\\\", \\\"{x:520,y:763,t:1527620942026};\\\", \\\"{x:524,y:761,t:1527620942043};\\\", \\\"{x:526,y:759,t:1527620942060};\\\", \\\"{x:527,y:758,t:1527620942076};\\\", \\\"{x:527,y:757,t:1527620942093};\\\", \\\"{x:531,y:753,t:1527620942110};\\\", \\\"{x:533,y:751,t:1527620942127};\\\", \\\"{x:535,y:749,t:1527620942145};\\\", \\\"{x:537,y:747,t:1527620942160};\\\", \\\"{x:539,y:745,t:1527620942177};\\\", \\\"{x:541,y:742,t:1527620942191};\\\", \\\"{x:543,y:739,t:1527620942207};\\\", \\\"{x:545,y:738,t:1527620942225};\\\", \\\"{x:546,y:736,t:1527620942240};\\\", \\\"{x:547,y:736,t:1527620942258};\\\", \\\"{x:549,y:735,t:1527620942275};\\\", \\\"{x:550,y:734,t:1527620942292};\\\", \\\"{x:551,y:734,t:1527620942308};\\\", \\\"{x:550,y:734,t:1527620943021};\\\", \\\"{x:549,y:734,t:1527620943501};\\\", \\\"{x:549,y:735,t:1527620943733};\\\", \\\"{x:548,y:736,t:1527620943838};\\\" ] }, { \\\"rt\\\": 8826, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 401861, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:736,t:1527620944092};\\\", \\\"{x:547,y:737,t:1527620944118};\\\", \\\"{x:547,y:738,t:1527620944128};\\\", \\\"{x:546,y:739,t:1527620944145};\\\", \\\"{x:545,y:741,t:1527620944261};\\\", \\\"{x:544,y:742,t:1527620944309};\\\", \\\"{x:544,y:743,t:1527620944341};\\\", \\\"{x:544,y:744,t:1527620944349};\\\", \\\"{x:544,y:745,t:1527620944362};\\\", \\\"{x:544,y:746,t:1527620944379};\\\", \\\"{x:544,y:748,t:1527620944396};\\\", \\\"{x:544,y:749,t:1527620944412};\\\", \\\"{x:544,y:751,t:1527620944429};\\\", \\\"{x:544,y:752,t:1527620944477};\\\", \\\"{x:544,y:753,t:1527620944493};\\\", \\\"{x:544,y:754,t:1527620944509};\\\", \\\"{x:544,y:755,t:1527620944551};\\\", \\\"{x:544,y:756,t:1527620944574};\\\", \\\"{x:544,y:757,t:1527620944613};\\\", \\\"{x:544,y:758,t:1527620944791};\\\", \\\"{x:545,y:758,t:1527620945207};\\\", \\\"{x:545,y:759,t:1527620945238};\\\", \\\"{x:546,y:760,t:1527620945295};\\\", \\\"{x:546,y:761,t:1527620945398};\\\", \\\"{x:547,y:761,t:1527620945413};\\\", \\\"{x:547,y:762,t:1527620945494};\\\", \\\"{x:547,y:763,t:1527620945550};\\\", \\\"{x:547,y:764,t:1527620945565};\\\", \\\"{x:547,y:765,t:1527620945590};\\\", \\\"{x:547,y:766,t:1527620945622};\\\", \\\"{x:547,y:767,t:1527620945638};\\\", \\\"{x:547,y:768,t:1527620945654};\\\", \\\"{x:547,y:769,t:1527620945678};\\\", \\\"{x:547,y:770,t:1527620945710};\\\", \\\"{x:547,y:772,t:1527620945726};\\\", \\\"{x:547,y:773,t:1527620945829};\\\", \\\"{x:547,y:774,t:1527620945901};\\\", \\\"{x:547,y:775,t:1527620945974};\\\", \\\"{x:547,y:776,t:1527620946014};\\\", \\\"{x:547,y:778,t:1527620946030};\\\", \\\"{x:547,y:780,t:1527620946047};\\\", \\\"{x:547,y:782,t:1527620946064};\\\", \\\"{x:547,y:784,t:1527620946094};\\\", \\\"{x:548,y:785,t:1527620946126};\\\", \\\"{x:548,y:787,t:1527620946174};\\\", \\\"{x:548,y:788,t:1527620946294};\\\", \\\"{x:548,y:790,t:1527620946415};\\\", \\\"{x:547,y:787,t:1527620946782};\\\", \\\"{x:547,y:771,t:1527620946798};\\\", \\\"{x:550,y:751,t:1527620946815};\\\", \\\"{x:558,y:726,t:1527620946832};\\\", \\\"{x:565,y:704,t:1527620946848};\\\", \\\"{x:570,y:693,t:1527620946864};\\\", \\\"{x:574,y:677,t:1527620946881};\\\", \\\"{x:577,y:651,t:1527620946898};\\\", \\\"{x:579,y:628,t:1527620946915};\\\", \\\"{x:579,y:612,t:1527620946931};\\\", \\\"{x:579,y:598,t:1527620946949};\\\", \\\"{x:575,y:587,t:1527620946964};\\\", \\\"{x:570,y:576,t:1527620946981};\\\", \\\"{x:567,y:571,t:1527620946997};\\\", \\\"{x:563,y:567,t:1527620947014};\\\", \\\"{x:560,y:564,t:1527620947031};\\\", \\\"{x:558,y:563,t:1527620947047};\\\", \\\"{x:557,y:563,t:1527620947069};\\\", \\\"{x:556,y:562,t:1527620947082};\\\", \\\"{x:555,y:560,t:1527620947101};\\\", \\\"{x:556,y:560,t:1527620947302};\\\", \\\"{x:559,y:561,t:1527620947314};\\\", \\\"{x:566,y:564,t:1527620947332};\\\", \\\"{x:572,y:567,t:1527620947347};\\\", \\\"{x:586,y:573,t:1527620947365};\\\", \\\"{x:593,y:578,t:1527620947381};\\\", \\\"{x:603,y:584,t:1527620947398};\\\", \\\"{x:616,y:590,t:1527620947416};\\\", \\\"{x:624,y:593,t:1527620947431};\\\", \\\"{x:635,y:598,t:1527620947448};\\\", \\\"{x:650,y:605,t:1527620947466};\\\", \\\"{x:667,y:614,t:1527620947481};\\\", \\\"{x:675,y:619,t:1527620947498};\\\", \\\"{x:684,y:624,t:1527620947515};\\\", \\\"{x:688,y:628,t:1527620947531};\\\", \\\"{x:694,y:635,t:1527620947548};\\\", \\\"{x:698,y:644,t:1527620947565};\\\", \\\"{x:700,y:652,t:1527620947581};\\\", \\\"{x:701,y:661,t:1527620947598};\\\", \\\"{x:705,y:671,t:1527620947615};\\\", \\\"{x:707,y:681,t:1527620947632};\\\", \\\"{x:710,y:690,t:1527620947649};\\\", \\\"{x:711,y:697,t:1527620947665};\\\", \\\"{x:712,y:701,t:1527620947682};\\\", \\\"{x:715,y:706,t:1527620947699};\\\", \\\"{x:720,y:714,t:1527620947715};\\\", \\\"{x:723,y:718,t:1527620947732};\\\", \\\"{x:727,y:724,t:1527620947748};\\\", \\\"{x:735,y:732,t:1527620947765};\\\", \\\"{x:745,y:738,t:1527620947782};\\\", \\\"{x:753,y:743,t:1527620947798};\\\", \\\"{x:763,y:747,t:1527620947816};\\\", \\\"{x:776,y:753,t:1527620947832};\\\", \\\"{x:781,y:754,t:1527620947849};\\\", \\\"{x:784,y:754,t:1527620947865};\\\", \\\"{x:785,y:754,t:1527620947883};\\\", \\\"{x:785,y:756,t:1527620948487};\\\", \\\"{x:788,y:756,t:1527620948500};\\\", \\\"{x:794,y:756,t:1527620948517};\\\", \\\"{x:799,y:756,t:1527620948533};\\\", \\\"{x:807,y:756,t:1527620948550};\\\", \\\"{x:823,y:755,t:1527620948566};\\\", \\\"{x:847,y:755,t:1527620948583};\\\", \\\"{x:891,y:755,t:1527620948600};\\\", \\\"{x:958,y:753,t:1527620948616};\\\", \\\"{x:1044,y:753,t:1527620948633};\\\", \\\"{x:1100,y:753,t:1527620948650};\\\", \\\"{x:1145,y:746,t:1527620948667};\\\", \\\"{x:1169,y:743,t:1527620948683};\\\", \\\"{x:1182,y:738,t:1527620948699};\\\", \\\"{x:1197,y:731,t:1527620948717};\\\", \\\"{x:1210,y:723,t:1527620948733};\\\", \\\"{x:1226,y:710,t:1527620948750};\\\", \\\"{x:1234,y:701,t:1527620948766};\\\", \\\"{x:1242,y:691,t:1527620948784};\\\", \\\"{x:1244,y:685,t:1527620948799};\\\", \\\"{x:1247,y:676,t:1527620948817};\\\", \\\"{x:1247,y:665,t:1527620948832};\\\", \\\"{x:1247,y:654,t:1527620948850};\\\", \\\"{x:1247,y:641,t:1527620948867};\\\", \\\"{x:1247,y:632,t:1527620948884};\\\", \\\"{x:1241,y:620,t:1527620948900};\\\", \\\"{x:1236,y:612,t:1527620948917};\\\", \\\"{x:1231,y:605,t:1527620948933};\\\", \\\"{x:1226,y:598,t:1527620948950};\\\", \\\"{x:1217,y:591,t:1527620948967};\\\", \\\"{x:1210,y:587,t:1527620948984};\\\", \\\"{x:1202,y:582,t:1527620948999};\\\", \\\"{x:1191,y:575,t:1527620949017};\\\", \\\"{x:1181,y:569,t:1527620949033};\\\", \\\"{x:1172,y:563,t:1527620949050};\\\", \\\"{x:1156,y:557,t:1527620949067};\\\", \\\"{x:1146,y:552,t:1527620949084};\\\", \\\"{x:1142,y:550,t:1527620949100};\\\", \\\"{x:1141,y:550,t:1527620949190};\\\", \\\"{x:1139,y:550,t:1527620949239};\\\", \\\"{x:1139,y:551,t:1527620949250};\\\", \\\"{x:1138,y:553,t:1527620949267};\\\", \\\"{x:1136,y:556,t:1527620949284};\\\", \\\"{x:1133,y:559,t:1527620949301};\\\", \\\"{x:1131,y:563,t:1527620949317};\\\", \\\"{x:1128,y:565,t:1527620949334};\\\", \\\"{x:1124,y:568,t:1527620949350};\\\", \\\"{x:1117,y:571,t:1527620949367};\\\", \\\"{x:1111,y:572,t:1527620949384};\\\", \\\"{x:1106,y:573,t:1527620949401};\\\", \\\"{x:1098,y:576,t:1527620949417};\\\", \\\"{x:1090,y:577,t:1527620949433};\\\", \\\"{x:1077,y:580,t:1527620949451};\\\", \\\"{x:1063,y:582,t:1527620949467};\\\", \\\"{x:1044,y:586,t:1527620949484};\\\", \\\"{x:1019,y:588,t:1527620949502};\\\", \\\"{x:977,y:588,t:1527620949517};\\\", \\\"{x:944,y:589,t:1527620949535};\\\", \\\"{x:931,y:593,t:1527620949550};\\\", \\\"{x:914,y:595,t:1527620949566};\\\", \\\"{x:900,y:595,t:1527620949583};\\\", \\\"{x:882,y:597,t:1527620949598};\\\", \\\"{x:865,y:600,t:1527620949615};\\\", \\\"{x:859,y:600,t:1527620949632};\\\", \\\"{x:852,y:600,t:1527620949648};\\\", \\\"{x:843,y:600,t:1527620949665};\\\", \\\"{x:819,y:598,t:1527620949682};\\\", \\\"{x:791,y:589,t:1527620949698};\\\", \\\"{x:767,y:583,t:1527620949715};\\\", \\\"{x:743,y:580,t:1527620949733};\\\", \\\"{x:734,y:578,t:1527620949750};\\\", \\\"{x:725,y:578,t:1527620949766};\\\", \\\"{x:711,y:577,t:1527620949785};\\\", \\\"{x:694,y:575,t:1527620949801};\\\", \\\"{x:680,y:573,t:1527620949817};\\\", \\\"{x:665,y:570,t:1527620949834};\\\", \\\"{x:649,y:567,t:1527620949851};\\\", \\\"{x:639,y:564,t:1527620949867};\\\", \\\"{x:625,y:563,t:1527620949884};\\\", \\\"{x:602,y:558,t:1527620949901};\\\", \\\"{x:581,y:555,t:1527620949917};\\\", \\\"{x:545,y:547,t:1527620949934};\\\", \\\"{x:523,y:544,t:1527620949950};\\\", \\\"{x:507,y:541,t:1527620949967};\\\", \\\"{x:493,y:540,t:1527620949986};\\\", \\\"{x:476,y:536,t:1527620950000};\\\", \\\"{x:458,y:533,t:1527620950018};\\\", \\\"{x:447,y:529,t:1527620950034};\\\", \\\"{x:444,y:527,t:1527620950051};\\\", \\\"{x:443,y:526,t:1527620950068};\\\", \\\"{x:447,y:522,t:1527620950085};\\\", \\\"{x:480,y:511,t:1527620950101};\\\", \\\"{x:521,y:503,t:1527620950117};\\\", \\\"{x:571,y:495,t:1527620950133};\\\", \\\"{x:592,y:494,t:1527620950150};\\\", \\\"{x:609,y:494,t:1527620950168};\\\", \\\"{x:619,y:494,t:1527620950183};\\\", \\\"{x:630,y:494,t:1527620950200};\\\", \\\"{x:640,y:494,t:1527620950218};\\\", \\\"{x:644,y:496,t:1527620950235};\\\", \\\"{x:646,y:496,t:1527620950250};\\\", \\\"{x:647,y:496,t:1527620950309};\\\", \\\"{x:647,y:497,t:1527620950334};\\\", \\\"{x:645,y:499,t:1527620950351};\\\", \\\"{x:639,y:501,t:1527620950367};\\\", \\\"{x:632,y:504,t:1527620950384};\\\", \\\"{x:626,y:505,t:1527620950400};\\\", \\\"{x:619,y:508,t:1527620950418};\\\", \\\"{x:617,y:508,t:1527620950434};\\\", \\\"{x:616,y:508,t:1527620950451};\\\", \\\"{x:614,y:508,t:1527620950468};\\\", \\\"{x:612,y:508,t:1527620950485};\\\", \\\"{x:611,y:508,t:1527620950500};\\\", \\\"{x:609,y:508,t:1527620950518};\\\", \\\"{x:608,y:508,t:1527620950534};\\\", \\\"{x:610,y:508,t:1527620950806};\\\", \\\"{x:614,y:508,t:1527620950818};\\\", \\\"{x:625,y:508,t:1527620950835};\\\", \\\"{x:639,y:508,t:1527620950851};\\\", \\\"{x:656,y:508,t:1527620950869};\\\", \\\"{x:675,y:508,t:1527620950885};\\\", \\\"{x:702,y:509,t:1527620950901};\\\", \\\"{x:718,y:512,t:1527620950917};\\\", \\\"{x:733,y:514,t:1527620950935};\\\", \\\"{x:742,y:516,t:1527620950952};\\\", \\\"{x:752,y:518,t:1527620950968};\\\", \\\"{x:764,y:522,t:1527620950984};\\\", \\\"{x:775,y:524,t:1527620951002};\\\", \\\"{x:785,y:528,t:1527620951017};\\\", \\\"{x:792,y:531,t:1527620951035};\\\", \\\"{x:797,y:533,t:1527620951051};\\\", \\\"{x:799,y:534,t:1527620951068};\\\", \\\"{x:800,y:535,t:1527620951085};\\\", \\\"{x:800,y:537,t:1527620951102};\\\", \\\"{x:792,y:540,t:1527620951118};\\\", \\\"{x:773,y:543,t:1527620951135};\\\", \\\"{x:747,y:546,t:1527620951152};\\\", \\\"{x:725,y:548,t:1527620951167};\\\", \\\"{x:704,y:548,t:1527620951185};\\\", \\\"{x:693,y:549,t:1527620951201};\\\", \\\"{x:686,y:549,t:1527620951217};\\\", \\\"{x:679,y:549,t:1527620951234};\\\", \\\"{x:673,y:549,t:1527620951251};\\\", \\\"{x:672,y:549,t:1527620951267};\\\", \\\"{x:671,y:549,t:1527620951285};\\\", \\\"{x:670,y:549,t:1527620951326};\\\", \\\"{x:671,y:548,t:1527620951334};\\\", \\\"{x:687,y:546,t:1527620951352};\\\", \\\"{x:710,y:544,t:1527620951369};\\\", \\\"{x:736,y:544,t:1527620951386};\\\", \\\"{x:759,y:544,t:1527620951401};\\\", \\\"{x:779,y:544,t:1527620951418};\\\", \\\"{x:793,y:544,t:1527620951434};\\\", \\\"{x:802,y:544,t:1527620951451};\\\", \\\"{x:806,y:544,t:1527620951469};\\\", \\\"{x:808,y:544,t:1527620951484};\\\", \\\"{x:809,y:544,t:1527620951542};\\\", \\\"{x:810,y:544,t:1527620951565};\\\", \\\"{x:811,y:544,t:1527620951589};\\\", \\\"{x:812,y:544,t:1527620951630};\\\", \\\"{x:813,y:544,t:1527620951654};\\\", \\\"{x:814,y:544,t:1527620951670};\\\", \\\"{x:815,y:544,t:1527620951686};\\\", \\\"{x:818,y:544,t:1527620951702};\\\", \\\"{x:823,y:544,t:1527620951718};\\\", \\\"{x:829,y:544,t:1527620951737};\\\", \\\"{x:832,y:544,t:1527620951752};\\\", \\\"{x:833,y:544,t:1527620951789};\\\", \\\"{x:833,y:546,t:1527620952037};\\\", \\\"{x:833,y:547,t:1527620952053};\\\", \\\"{x:833,y:550,t:1527620952069};\\\", \\\"{x:827,y:558,t:1527620952085};\\\", \\\"{x:823,y:563,t:1527620952102};\\\", \\\"{x:820,y:567,t:1527620952119};\\\", \\\"{x:818,y:571,t:1527620952135};\\\", \\\"{x:811,y:577,t:1527620952151};\\\", \\\"{x:804,y:583,t:1527620952168};\\\", \\\"{x:795,y:589,t:1527620952185};\\\", \\\"{x:789,y:594,t:1527620952202};\\\", \\\"{x:780,y:601,t:1527620952219};\\\", \\\"{x:769,y:608,t:1527620952235};\\\", \\\"{x:754,y:617,t:1527620952252};\\\", \\\"{x:736,y:627,t:1527620952268};\\\", \\\"{x:715,y:639,t:1527620952285};\\\", \\\"{x:701,y:647,t:1527620952302};\\\", \\\"{x:687,y:654,t:1527620952318};\\\", \\\"{x:671,y:661,t:1527620952336};\\\", \\\"{x:659,y:665,t:1527620952353};\\\", \\\"{x:644,y:669,t:1527620952369};\\\", \\\"{x:635,y:672,t:1527620952386};\\\", \\\"{x:626,y:676,t:1527620952403};\\\", \\\"{x:617,y:679,t:1527620952418};\\\", \\\"{x:611,y:682,t:1527620952436};\\\", \\\"{x:605,y:684,t:1527620952453};\\\", \\\"{x:599,y:688,t:1527620952470};\\\", \\\"{x:591,y:693,t:1527620952486};\\\", \\\"{x:588,y:697,t:1527620952502};\\\", \\\"{x:585,y:700,t:1527620952518};\\\", \\\"{x:580,y:703,t:1527620952536};\\\", \\\"{x:578,y:705,t:1527620952553};\\\", \\\"{x:576,y:706,t:1527620952568};\\\", \\\"{x:573,y:710,t:1527620952586};\\\", \\\"{x:567,y:716,t:1527620952603};\\\", \\\"{x:563,y:721,t:1527620952618};\\\", \\\"{x:561,y:722,t:1527620952636};\\\", \\\"{x:558,y:725,t:1527620952653};\\\", \\\"{x:556,y:726,t:1527620952669};\\\", \\\"{x:553,y:728,t:1527620952686};\\\", \\\"{x:552,y:729,t:1527620952702};\\\", \\\"{x:548,y:731,t:1527620952720};\\\", \\\"{x:546,y:732,t:1527620952736};\\\", \\\"{x:544,y:734,t:1527620952753};\\\", \\\"{x:543,y:735,t:1527620952769};\\\", \\\"{x:541,y:736,t:1527620952785};\\\", \\\"{x:540,y:736,t:1527620952821};\\\", \\\"{x:540,y:737,t:1527620952938};\\\", \\\"{x:540,y:738,t:1527620953133};\\\", \\\"{x:540,y:740,t:1527620953462};\\\", \\\"{x:540,y:741,t:1527620953470};\\\", \\\"{x:540,y:743,t:1527620953487};\\\", \\\"{x:540,y:746,t:1527620953504};\\\", \\\"{x:540,y:751,t:1527620953519};\\\", \\\"{x:541,y:754,t:1527620953537};\\\", \\\"{x:544,y:762,t:1527620953554};\\\", \\\"{x:546,y:768,t:1527620953570};\\\", \\\"{x:549,y:772,t:1527620953587};\\\", \\\"{x:552,y:778,t:1527620953604};\\\", \\\"{x:553,y:782,t:1527620953620};\\\", \\\"{x:554,y:785,t:1527620953636};\\\", \\\"{x:556,y:791,t:1527620953654};\\\", \\\"{x:557,y:795,t:1527620953669};\\\", \\\"{x:559,y:800,t:1527620953687};\\\", \\\"{x:560,y:801,t:1527620953703};\\\", \\\"{x:561,y:804,t:1527620953720};\\\", \\\"{x:562,y:805,t:1527620953821};\\\", \\\"{x:563,y:806,t:1527620953837};\\\", \\\"{x:565,y:806,t:1527620953869};\\\", \\\"{x:567,y:805,t:1527620953877};\\\", \\\"{x:568,y:803,t:1527620953894};\\\", \\\"{x:569,y:802,t:1527620953904};\\\", \\\"{x:570,y:800,t:1527620953921};\\\", \\\"{x:571,y:797,t:1527620953947};\\\", \\\"{x:573,y:795,t:1527620953953};\\\", \\\"{x:575,y:794,t:1527620953971};\\\", \\\"{x:577,y:791,t:1527620953986};\\\", \\\"{x:580,y:785,t:1527620954003};\\\", \\\"{x:586,y:778,t:1527620954021};\\\" ] }, { \\\"rt\\\": 31771, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 434902, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:621,y:723,t:1527620954191};\\\", \\\"{x:622,y:721,t:1527620954204};\\\", \\\"{x:622,y:720,t:1527620954220};\\\", \\\"{x:624,y:718,t:1527620954236};\\\", \\\"{x:625,y:715,t:1527620954253};\\\", \\\"{x:626,y:712,t:1527620954357};\\\", \\\"{x:626,y:711,t:1527620954389};\\\", \\\"{x:626,y:710,t:1527620954461};\\\", \\\"{x:626,y:711,t:1527620954584};\\\", \\\"{x:625,y:712,t:1527620954598};\\\", \\\"{x:625,y:714,t:1527620954613};\\\", \\\"{x:625,y:715,t:1527620954620};\\\", \\\"{x:624,y:718,t:1527620954638};\\\", \\\"{x:624,y:725,t:1527620954653};\\\", \\\"{x:624,y:731,t:1527620954670};\\\", \\\"{x:625,y:737,t:1527620954687};\\\", \\\"{x:625,y:742,t:1527620954703};\\\", \\\"{x:625,y:746,t:1527620954721};\\\", \\\"{x:625,y:749,t:1527620954738};\\\", \\\"{x:625,y:750,t:1527620954797};\\\", \\\"{x:625,y:751,t:1527620954910};\\\", \\\"{x:625,y:752,t:1527620954925};\\\", \\\"{x:625,y:753,t:1527620954950};\\\", \\\"{x:623,y:753,t:1527620955478};\\\", \\\"{x:622,y:753,t:1527620955526};\\\", \\\"{x:622,y:754,t:1527620955574};\\\", \\\"{x:622,y:755,t:1527620955597};\\\", \\\"{x:621,y:756,t:1527620955613};\\\", \\\"{x:620,y:758,t:1527620955638};\\\", \\\"{x:619,y:759,t:1527620955685};\\\", \\\"{x:618,y:760,t:1527620955710};\\\", \\\"{x:616,y:761,t:1527620955734};\\\", \\\"{x:615,y:761,t:1527620956503};\\\", \\\"{x:614,y:761,t:1527620956509};\\\", \\\"{x:613,y:759,t:1527620956522};\\\", \\\"{x:611,y:754,t:1527620956539};\\\", \\\"{x:608,y:747,t:1527620956556};\\\", \\\"{x:607,y:741,t:1527620956572};\\\", \\\"{x:604,y:733,t:1527620956589};\\\", \\\"{x:602,y:728,t:1527620956605};\\\", \\\"{x:599,y:723,t:1527620956621};\\\", \\\"{x:595,y:718,t:1527620956639};\\\", \\\"{x:593,y:714,t:1527620956655};\\\", \\\"{x:590,y:711,t:1527620956671};\\\", \\\"{x:589,y:709,t:1527620956688};\\\", \\\"{x:588,y:707,t:1527620956706};\\\", \\\"{x:586,y:705,t:1527620956722};\\\", \\\"{x:585,y:704,t:1527620956782};\\\", \\\"{x:585,y:702,t:1527620956868};\\\", \\\"{x:585,y:701,t:1527620956917};\\\", \\\"{x:585,y:699,t:1527620956965};\\\", \\\"{x:585,y:698,t:1527620956989};\\\", \\\"{x:585,y:697,t:1527620957094};\\\", \\\"{x:586,y:697,t:1527620957294};\\\", \\\"{x:587,y:696,t:1527620957306};\\\", \\\"{x:594,y:694,t:1527620957323};\\\", \\\"{x:603,y:689,t:1527620957341};\\\", \\\"{x:612,y:686,t:1527620957357};\\\", \\\"{x:618,y:682,t:1527620957373};\\\", \\\"{x:624,y:679,t:1527620957390};\\\", \\\"{x:628,y:677,t:1527620957406};\\\", \\\"{x:629,y:677,t:1527620957422};\\\", \\\"{x:631,y:676,t:1527620957440};\\\", \\\"{x:631,y:675,t:1527620957456};\\\", \\\"{x:633,y:675,t:1527620957473};\\\", \\\"{x:634,y:675,t:1527620957670};\\\", \\\"{x:629,y:673,t:1527620958854};\\\", \\\"{x:627,y:673,t:1527620958862};\\\", \\\"{x:625,y:671,t:1527620958874};\\\", \\\"{x:620,y:666,t:1527620958891};\\\", \\\"{x:610,y:661,t:1527620958907};\\\", \\\"{x:594,y:652,t:1527620958924};\\\", \\\"{x:567,y:642,t:1527620958941};\\\", \\\"{x:546,y:635,t:1527620958958};\\\", \\\"{x:519,y:627,t:1527620958975};\\\", \\\"{x:497,y:617,t:1527620958992};\\\", \\\"{x:476,y:609,t:1527620959007};\\\", \\\"{x:462,y:602,t:1527620959024};\\\", \\\"{x:446,y:595,t:1527620959041};\\\", \\\"{x:439,y:591,t:1527620959058};\\\", \\\"{x:434,y:588,t:1527620959074};\\\", \\\"{x:432,y:586,t:1527620959090};\\\", \\\"{x:430,y:585,t:1527620959108};\\\", \\\"{x:430,y:584,t:1527620959124};\\\", \\\"{x:430,y:583,t:1527620959238};\\\", \\\"{x:430,y:581,t:1527620959270};\\\", \\\"{x:430,y:580,t:1527620959277};\\\", \\\"{x:430,y:578,t:1527620959291};\\\", \\\"{x:431,y:577,t:1527620959308};\\\", \\\"{x:432,y:571,t:1527620959326};\\\", \\\"{x:432,y:568,t:1527620959341};\\\", \\\"{x:432,y:563,t:1527620959358};\\\", \\\"{x:432,y:556,t:1527620959376};\\\", \\\"{x:432,y:551,t:1527620959391};\\\", \\\"{x:430,y:543,t:1527620959408};\\\", \\\"{x:430,y:534,t:1527620959425};\\\", \\\"{x:426,y:525,t:1527620959440};\\\", \\\"{x:424,y:518,t:1527620959458};\\\", \\\"{x:422,y:515,t:1527620959475};\\\", \\\"{x:419,y:511,t:1527620959491};\\\", \\\"{x:417,y:508,t:1527620959507};\\\", \\\"{x:413,y:500,t:1527620959525};\\\", \\\"{x:411,y:498,t:1527620959541};\\\", \\\"{x:410,y:496,t:1527620959558};\\\", \\\"{x:410,y:495,t:1527620959597};\\\", \\\"{x:409,y:495,t:1527620959608};\\\", \\\"{x:408,y:494,t:1527620959624};\\\", \\\"{x:408,y:493,t:1527620959660};\\\", \\\"{x:408,y:492,t:1527620959674};\\\", \\\"{x:408,y:491,t:1527620959693};\\\", \\\"{x:408,y:490,t:1527620959708};\\\", \\\"{x:408,y:489,t:1527620959725};\\\", \\\"{x:408,y:487,t:1527620959741};\\\", \\\"{x:408,y:486,t:1527620959758};\\\", \\\"{x:408,y:484,t:1527620959789};\\\", \\\"{x:408,y:483,t:1527620959813};\\\", \\\"{x:408,y:482,t:1527620959829};\\\", \\\"{x:408,y:481,t:1527620959842};\\\", \\\"{x:408,y:480,t:1527620959858};\\\", \\\"{x:408,y:479,t:1527620959875};\\\", \\\"{x:408,y:478,t:1527620959892};\\\", \\\"{x:408,y:477,t:1527620959908};\\\", \\\"{x:408,y:475,t:1527620959933};\\\", \\\"{x:409,y:474,t:1527620959990};\\\", \\\"{x:410,y:473,t:1527620961398};\\\", \\\"{x:413,y:473,t:1527620961421};\\\", \\\"{x:419,y:473,t:1527620961429};\\\", \\\"{x:429,y:473,t:1527620961442};\\\", \\\"{x:448,y:473,t:1527620961459};\\\", \\\"{x:471,y:473,t:1527620961476};\\\", \\\"{x:493,y:473,t:1527620961492};\\\", \\\"{x:525,y:473,t:1527620961510};\\\", \\\"{x:542,y:473,t:1527620961525};\\\", \\\"{x:553,y:473,t:1527620961542};\\\", \\\"{x:560,y:475,t:1527620961559};\\\", \\\"{x:564,y:475,t:1527620961576};\\\", \\\"{x:566,y:475,t:1527620961593};\\\", \\\"{x:570,y:475,t:1527620961609};\\\", \\\"{x:575,y:475,t:1527620961626};\\\", \\\"{x:578,y:475,t:1527620961643};\\\", \\\"{x:580,y:475,t:1527620961659};\\\", \\\"{x:581,y:475,t:1527620961677};\\\", \\\"{x:585,y:475,t:1527620961692};\\\", \\\"{x:589,y:475,t:1527620961709};\\\", \\\"{x:590,y:475,t:1527620961726};\\\", \\\"{x:591,y:475,t:1527620961749};\\\", \\\"{x:592,y:475,t:1527620961799};\\\", \\\"{x:594,y:475,t:1527620961813};\\\", \\\"{x:595,y:475,t:1527620961830};\\\", \\\"{x:597,y:474,t:1527620961843};\\\", \\\"{x:600,y:472,t:1527620961859};\\\", \\\"{x:603,y:472,t:1527620961876};\\\", \\\"{x:610,y:468,t:1527620961894};\\\", \\\"{x:616,y:468,t:1527620961910};\\\", \\\"{x:626,y:466,t:1527620961927};\\\", \\\"{x:636,y:464,t:1527620961943};\\\", \\\"{x:648,y:463,t:1527620961959};\\\", \\\"{x:657,y:461,t:1527620961976};\\\", \\\"{x:664,y:460,t:1527620961993};\\\", \\\"{x:669,y:459,t:1527620962009};\\\", \\\"{x:670,y:458,t:1527620962026};\\\", \\\"{x:672,y:458,t:1527620962043};\\\", \\\"{x:674,y:458,t:1527620962058};\\\", \\\"{x:676,y:457,t:1527620962076};\\\", \\\"{x:680,y:457,t:1527620962093};\\\", \\\"{x:680,y:456,t:1527620962182};\\\", \\\"{x:682,y:456,t:1527620962566};\\\", \\\"{x:683,y:456,t:1527620962576};\\\", \\\"{x:690,y:456,t:1527620962593};\\\", \\\"{x:699,y:456,t:1527620962611};\\\", \\\"{x:713,y:456,t:1527620962626};\\\", \\\"{x:727,y:456,t:1527620962643};\\\", \\\"{x:738,y:456,t:1527620962660};\\\", \\\"{x:746,y:456,t:1527620962676};\\\", \\\"{x:753,y:455,t:1527620962694};\\\", \\\"{x:754,y:455,t:1527620962718};\\\", \\\"{x:755,y:455,t:1527620962726};\\\", \\\"{x:756,y:455,t:1527620962743};\\\", \\\"{x:757,y:455,t:1527620963862};\\\", \\\"{x:763,y:455,t:1527620963878};\\\", \\\"{x:768,y:455,t:1527620963893};\\\", \\\"{x:775,y:455,t:1527620963910};\\\", \\\"{x:780,y:456,t:1527620963927};\\\", \\\"{x:783,y:457,t:1527620963944};\\\", \\\"{x:786,y:458,t:1527620963960};\\\", \\\"{x:790,y:460,t:1527620963977};\\\", \\\"{x:795,y:462,t:1527620963993};\\\", \\\"{x:806,y:466,t:1527620964010};\\\", \\\"{x:825,y:476,t:1527620964027};\\\", \\\"{x:848,y:485,t:1527620964043};\\\", \\\"{x:870,y:494,t:1527620964060};\\\", \\\"{x:906,y:510,t:1527620964077};\\\", \\\"{x:928,y:519,t:1527620964095};\\\", \\\"{x:951,y:527,t:1527620964112};\\\", \\\"{x:976,y:536,t:1527620964128};\\\", \\\"{x:999,y:544,t:1527620964145};\\\", \\\"{x:1025,y:552,t:1527620964162};\\\", \\\"{x:1051,y:562,t:1527620964179};\\\", \\\"{x:1073,y:572,t:1527620964195};\\\", \\\"{x:1100,y:586,t:1527620964212};\\\", \\\"{x:1136,y:606,t:1527620964229};\\\", \\\"{x:1157,y:615,t:1527620964245};\\\", \\\"{x:1172,y:624,t:1527620964262};\\\", \\\"{x:1183,y:630,t:1527620964279};\\\", \\\"{x:1186,y:632,t:1527620964295};\\\", \\\"{x:1188,y:634,t:1527620964312};\\\", \\\"{x:1190,y:636,t:1527620964329};\\\", \\\"{x:1193,y:638,t:1527620964345};\\\", \\\"{x:1196,y:643,t:1527620964362};\\\", \\\"{x:1200,y:647,t:1527620964379};\\\", \\\"{x:1203,y:650,t:1527620964396};\\\", \\\"{x:1211,y:654,t:1527620964412};\\\", \\\"{x:1226,y:662,t:1527620964429};\\\", \\\"{x:1240,y:670,t:1527620964445};\\\", \\\"{x:1252,y:675,t:1527620964462};\\\", \\\"{x:1259,y:679,t:1527620964479};\\\", \\\"{x:1265,y:680,t:1527620964496};\\\", \\\"{x:1268,y:681,t:1527620964512};\\\", \\\"{x:1268,y:682,t:1527620964529};\\\", \\\"{x:1269,y:682,t:1527620964546};\\\", \\\"{x:1269,y:683,t:1527620964565};\\\", \\\"{x:1270,y:683,t:1527620964579};\\\", \\\"{x:1271,y:684,t:1527620964613};\\\", \\\"{x:1271,y:683,t:1527620964783};\\\", \\\"{x:1271,y:682,t:1527620964797};\\\", \\\"{x:1271,y:680,t:1527620964814};\\\", \\\"{x:1271,y:679,t:1527620964830};\\\", \\\"{x:1271,y:678,t:1527620964846};\\\", \\\"{x:1272,y:676,t:1527620964864};\\\", \\\"{x:1273,y:675,t:1527620964886};\\\", \\\"{x:1273,y:674,t:1527620964909};\\\", \\\"{x:1274,y:674,t:1527620964918};\\\", \\\"{x:1275,y:673,t:1527620964942};\\\", \\\"{x:1275,y:671,t:1527620964966};\\\", \\\"{x:1276,y:670,t:1527620964981};\\\", \\\"{x:1278,y:669,t:1527620965030};\\\", \\\"{x:1277,y:668,t:1527620965229};\\\", \\\"{x:1276,y:667,t:1527620965244};\\\", \\\"{x:1275,y:667,t:1527620965252};\\\", \\\"{x:1274,y:667,t:1527620965263};\\\", \\\"{x:1267,y:666,t:1527620965280};\\\", \\\"{x:1250,y:658,t:1527620965297};\\\", \\\"{x:1233,y:653,t:1527620965314};\\\", \\\"{x:1220,y:651,t:1527620965330};\\\", \\\"{x:1204,y:647,t:1527620965347};\\\", \\\"{x:1193,y:646,t:1527620965364};\\\", \\\"{x:1179,y:643,t:1527620965380};\\\", \\\"{x:1166,y:642,t:1527620965397};\\\", \\\"{x:1160,y:642,t:1527620965414};\\\", \\\"{x:1155,y:642,t:1527620965431};\\\", \\\"{x:1151,y:642,t:1527620965447};\\\", \\\"{x:1145,y:642,t:1527620965465};\\\", \\\"{x:1142,y:642,t:1527620965481};\\\", \\\"{x:1141,y:642,t:1527620965498};\\\", \\\"{x:1137,y:642,t:1527620965514};\\\", \\\"{x:1133,y:643,t:1527620965531};\\\", \\\"{x:1127,y:643,t:1527620965548};\\\", \\\"{x:1121,y:643,t:1527620965564};\\\", \\\"{x:1112,y:637,t:1527620965581};\\\", \\\"{x:1101,y:632,t:1527620965598};\\\", \\\"{x:1094,y:631,t:1527620965615};\\\", \\\"{x:1088,y:629,t:1527620965631};\\\", \\\"{x:1086,y:628,t:1527620965648};\\\", \\\"{x:1084,y:628,t:1527620965665};\\\", \\\"{x:1085,y:628,t:1527620965742};\\\", \\\"{x:1087,y:627,t:1527620965749};\\\", \\\"{x:1090,y:625,t:1527620965764};\\\", \\\"{x:1102,y:623,t:1527620965782};\\\", \\\"{x:1113,y:623,t:1527620965799};\\\", \\\"{x:1126,y:623,t:1527620965814};\\\", \\\"{x:1140,y:623,t:1527620965832};\\\", \\\"{x:1154,y:623,t:1527620965848};\\\", \\\"{x:1169,y:623,t:1527620965866};\\\", \\\"{x:1183,y:623,t:1527620965882};\\\", \\\"{x:1193,y:623,t:1527620965899};\\\", \\\"{x:1199,y:623,t:1527620965916};\\\", \\\"{x:1204,y:623,t:1527620965932};\\\", \\\"{x:1210,y:623,t:1527620965949};\\\", \\\"{x:1228,y:623,t:1527620965966};\\\", \\\"{x:1237,y:623,t:1527620965982};\\\", \\\"{x:1249,y:623,t:1527620965999};\\\", \\\"{x:1263,y:623,t:1527620966016};\\\", \\\"{x:1285,y:623,t:1527620966033};\\\", \\\"{x:1295,y:623,t:1527620966049};\\\", \\\"{x:1306,y:623,t:1527620966066};\\\", \\\"{x:1310,y:623,t:1527620966083};\\\", \\\"{x:1330,y:623,t:1527620966099};\\\", \\\"{x:1338,y:623,t:1527620966115};\\\", \\\"{x:1352,y:623,t:1527620966133};\\\", \\\"{x:1372,y:624,t:1527620966150};\\\", \\\"{x:1379,y:625,t:1527620966166};\\\", \\\"{x:1389,y:626,t:1527620966182};\\\", \\\"{x:1400,y:627,t:1527620966199};\\\", \\\"{x:1407,y:628,t:1527620966216};\\\", \\\"{x:1408,y:629,t:1527620966233};\\\", \\\"{x:1413,y:629,t:1527620966250};\\\", \\\"{x:1418,y:630,t:1527620966266};\\\", \\\"{x:1423,y:631,t:1527620966284};\\\", \\\"{x:1428,y:631,t:1527620966300};\\\", \\\"{x:1436,y:631,t:1527620966316};\\\", \\\"{x:1442,y:631,t:1527620966336};\\\", \\\"{x:1446,y:631,t:1527620966349};\\\", \\\"{x:1452,y:632,t:1527620966365};\\\", \\\"{x:1464,y:633,t:1527620966383};\\\", \\\"{x:1479,y:634,t:1527620966399};\\\", \\\"{x:1494,y:634,t:1527620966415};\\\", \\\"{x:1509,y:634,t:1527620966433};\\\", \\\"{x:1524,y:634,t:1527620966450};\\\", \\\"{x:1534,y:634,t:1527620966466};\\\", \\\"{x:1539,y:634,t:1527620966482};\\\", \\\"{x:1540,y:634,t:1527620966499};\\\", \\\"{x:1541,y:634,t:1527620966516};\\\", \\\"{x:1542,y:634,t:1527620966613};\\\", \\\"{x:1543,y:634,t:1527620966669};\\\", \\\"{x:1544,y:634,t:1527620967758};\\\", \\\"{x:1543,y:634,t:1527620967806};\\\", \\\"{x:1543,y:633,t:1527620967838};\\\", \\\"{x:1543,y:632,t:1527620967862};\\\", \\\"{x:1543,y:631,t:1527620967902};\\\", \\\"{x:1543,y:630,t:1527620968031};\\\", \\\"{x:1543,y:629,t:1527620968103};\\\", \\\"{x:1543,y:628,t:1527620969534};\\\", \\\"{x:1542,y:628,t:1527620969591};\\\", \\\"{x:1541,y:627,t:1527620969726};\\\", \\\"{x:1540,y:627,t:1527620969975};\\\", \\\"{x:1538,y:627,t:1527620978850};\\\", \\\"{x:1503,y:623,t:1527620978857};\\\", \\\"{x:1395,y:611,t:1527620978874};\\\", \\\"{x:1298,y:611,t:1527620978890};\\\", \\\"{x:1198,y:611,t:1527620978908};\\\", \\\"{x:1065,y:611,t:1527620978923};\\\", \\\"{x:922,y:611,t:1527620978941};\\\", \\\"{x:811,y:611,t:1527620978957};\\\", \\\"{x:747,y:611,t:1527620978974};\\\", \\\"{x:707,y:611,t:1527620978987};\\\", \\\"{x:683,y:611,t:1527620979004};\\\", \\\"{x:675,y:610,t:1527620979020};\\\", \\\"{x:674,y:610,t:1527620979037};\\\", \\\"{x:673,y:609,t:1527620979072};\\\", \\\"{x:672,y:609,t:1527620979087};\\\", \\\"{x:672,y:608,t:1527620979104};\\\", \\\"{x:672,y:603,t:1527620979121};\\\", \\\"{x:674,y:596,t:1527620979138};\\\", \\\"{x:682,y:579,t:1527620979155};\\\", \\\"{x:693,y:551,t:1527620979177};\\\", \\\"{x:694,y:539,t:1527620979193};\\\", \\\"{x:694,y:528,t:1527620979211};\\\", \\\"{x:694,y:516,t:1527620979228};\\\", \\\"{x:692,y:511,t:1527620979244};\\\", \\\"{x:692,y:507,t:1527620979261};\\\", \\\"{x:692,y:506,t:1527620979277};\\\", \\\"{x:692,y:504,t:1527620979294};\\\", \\\"{x:692,y:503,t:1527620979311};\\\", \\\"{x:692,y:502,t:1527620979327};\\\", \\\"{x:692,y:500,t:1527620979344};\\\", \\\"{x:692,y:499,t:1527620979362};\\\", \\\"{x:689,y:497,t:1527620979377};\\\", \\\"{x:686,y:495,t:1527620979394};\\\", \\\"{x:683,y:495,t:1527620979412};\\\", \\\"{x:679,y:495,t:1527620979427};\\\", \\\"{x:668,y:496,t:1527620979445};\\\", \\\"{x:650,y:498,t:1527620979461};\\\", \\\"{x:626,y:501,t:1527620979478};\\\", \\\"{x:604,y:506,t:1527620979494};\\\", \\\"{x:582,y:508,t:1527620979512};\\\", \\\"{x:559,y:511,t:1527620979527};\\\", \\\"{x:531,y:514,t:1527620979544};\\\", \\\"{x:511,y:518,t:1527620979561};\\\", \\\"{x:495,y:520,t:1527620979577};\\\", \\\"{x:482,y:523,t:1527620979594};\\\", \\\"{x:470,y:525,t:1527620979611};\\\", \\\"{x:464,y:527,t:1527620979626};\\\", \\\"{x:457,y:531,t:1527620979644};\\\", \\\"{x:452,y:531,t:1527620979661};\\\", \\\"{x:443,y:533,t:1527620979678};\\\", \\\"{x:434,y:536,t:1527620979694};\\\", \\\"{x:425,y:539,t:1527620979711};\\\", \\\"{x:414,y:545,t:1527620979729};\\\", \\\"{x:408,y:550,t:1527620979744};\\\", \\\"{x:403,y:555,t:1527620979761};\\\", \\\"{x:400,y:559,t:1527620979778};\\\", \\\"{x:397,y:562,t:1527620979794};\\\", \\\"{x:395,y:565,t:1527620979812};\\\", \\\"{x:394,y:568,t:1527620979828};\\\", \\\"{x:391,y:572,t:1527620979844};\\\", \\\"{x:388,y:576,t:1527620979860};\\\", \\\"{x:385,y:580,t:1527620979877};\\\", \\\"{x:381,y:584,t:1527620979894};\\\", \\\"{x:375,y:589,t:1527620979911};\\\", \\\"{x:365,y:596,t:1527620979929};\\\", \\\"{x:358,y:599,t:1527620979944};\\\", \\\"{x:351,y:602,t:1527620979961};\\\", \\\"{x:344,y:604,t:1527620979978};\\\", \\\"{x:337,y:605,t:1527620979994};\\\", \\\"{x:330,y:606,t:1527620980010};\\\", \\\"{x:323,y:606,t:1527620980028};\\\", \\\"{x:315,y:606,t:1527620980043};\\\", \\\"{x:300,y:606,t:1527620980061};\\\", \\\"{x:294,y:606,t:1527620980078};\\\", \\\"{x:287,y:606,t:1527620980094};\\\", \\\"{x:280,y:606,t:1527620980111};\\\", \\\"{x:271,y:604,t:1527620980128};\\\", \\\"{x:261,y:604,t:1527620980145};\\\", \\\"{x:250,y:604,t:1527620980161};\\\", \\\"{x:245,y:604,t:1527620980178};\\\", \\\"{x:237,y:604,t:1527620980195};\\\", \\\"{x:229,y:606,t:1527620980211};\\\", \\\"{x:218,y:610,t:1527620980228};\\\", \\\"{x:209,y:614,t:1527620980245};\\\", \\\"{x:203,y:617,t:1527620980261};\\\", \\\"{x:201,y:618,t:1527620980278};\\\", \\\"{x:201,y:619,t:1527620980295};\\\", \\\"{x:200,y:620,t:1527620980311};\\\", \\\"{x:200,y:621,t:1527620980329};\\\", \\\"{x:201,y:621,t:1527620980360};\\\", \\\"{x:206,y:622,t:1527620980379};\\\", \\\"{x:219,y:622,t:1527620980396};\\\", \\\"{x:239,y:622,t:1527620980411};\\\", \\\"{x:268,y:622,t:1527620980429};\\\", \\\"{x:313,y:622,t:1527620980447};\\\", \\\"{x:370,y:622,t:1527620980462};\\\", \\\"{x:445,y:622,t:1527620980478};\\\", \\\"{x:506,y:622,t:1527620980496};\\\", \\\"{x:547,y:619,t:1527620980511};\\\", \\\"{x:589,y:619,t:1527620980528};\\\", \\\"{x:615,y:619,t:1527620980545};\\\", \\\"{x:626,y:619,t:1527620980562};\\\", \\\"{x:632,y:618,t:1527620980578};\\\", \\\"{x:635,y:618,t:1527620980594};\\\", \\\"{x:639,y:618,t:1527620980611};\\\", \\\"{x:649,y:619,t:1527620980628};\\\", \\\"{x:668,y:619,t:1527620980645};\\\", \\\"{x:685,y:619,t:1527620980661};\\\", \\\"{x:689,y:619,t:1527620980678};\\\", \\\"{x:692,y:618,t:1527620980695};\\\", \\\"{x:692,y:616,t:1527620980712};\\\", \\\"{x:693,y:614,t:1527620980728};\\\", \\\"{x:698,y:608,t:1527620980745};\\\", \\\"{x:707,y:598,t:1527620980763};\\\", \\\"{x:713,y:590,t:1527620980780};\\\", \\\"{x:725,y:581,t:1527620980796};\\\", \\\"{x:734,y:576,t:1527620980812};\\\", \\\"{x:745,y:571,t:1527620980828};\\\", \\\"{x:761,y:566,t:1527620980845};\\\", \\\"{x:783,y:560,t:1527620980863};\\\", \\\"{x:806,y:557,t:1527620980878};\\\", \\\"{x:825,y:552,t:1527620980896};\\\", \\\"{x:844,y:546,t:1527620980912};\\\", \\\"{x:850,y:546,t:1527620980928};\\\", \\\"{x:857,y:545,t:1527620980945};\\\", \\\"{x:863,y:545,t:1527620980962};\\\", \\\"{x:866,y:545,t:1527620980979};\\\", \\\"{x:868,y:545,t:1527620980995};\\\", \\\"{x:869,y:545,t:1527620981049};\\\", \\\"{x:869,y:544,t:1527620981062};\\\", \\\"{x:870,y:542,t:1527620981082};\\\", \\\"{x:870,y:540,t:1527620981095};\\\", \\\"{x:872,y:537,t:1527620981112};\\\", \\\"{x:872,y:535,t:1527620981129};\\\", \\\"{x:872,y:533,t:1527620981146};\\\", \\\"{x:872,y:530,t:1527620981162};\\\", \\\"{x:872,y:527,t:1527620981178};\\\", \\\"{x:871,y:526,t:1527620981196};\\\", \\\"{x:871,y:524,t:1527620981214};\\\", \\\"{x:869,y:521,t:1527620981229};\\\", \\\"{x:867,y:519,t:1527620981245};\\\", \\\"{x:862,y:517,t:1527620981262};\\\", \\\"{x:854,y:516,t:1527620981279};\\\", \\\"{x:846,y:514,t:1527620981295};\\\", \\\"{x:839,y:512,t:1527620981312};\\\", \\\"{x:836,y:511,t:1527620981329};\\\", \\\"{x:834,y:511,t:1527620981345};\\\", \\\"{x:833,y:510,t:1527620981369};\\\", \\\"{x:832,y:510,t:1527620981680};\\\", \\\"{x:814,y:510,t:1527620981696};\\\", \\\"{x:787,y:510,t:1527620981712};\\\", \\\"{x:755,y:510,t:1527620981728};\\\", \\\"{x:712,y:510,t:1527620981747};\\\", \\\"{x:673,y:510,t:1527620981762};\\\", \\\"{x:637,y:507,t:1527620981780};\\\", \\\"{x:607,y:507,t:1527620981796};\\\", \\\"{x:584,y:507,t:1527620981813};\\\", \\\"{x:561,y:507,t:1527620981829};\\\", \\\"{x:535,y:507,t:1527620981847};\\\", \\\"{x:510,y:507,t:1527620981863};\\\", \\\"{x:484,y:507,t:1527620981880};\\\", \\\"{x:455,y:507,t:1527620981896};\\\", \\\"{x:444,y:507,t:1527620981912};\\\", \\\"{x:442,y:507,t:1527620981929};\\\", \\\"{x:440,y:507,t:1527620981985};\\\", \\\"{x:439,y:507,t:1527620982001};\\\", \\\"{x:438,y:507,t:1527620982013};\\\", \\\"{x:432,y:507,t:1527620982029};\\\", \\\"{x:419,y:507,t:1527620982046};\\\", \\\"{x:411,y:507,t:1527620982064};\\\", \\\"{x:400,y:507,t:1527620982079};\\\", \\\"{x:383,y:507,t:1527620982096};\\\", \\\"{x:372,y:507,t:1527620982113};\\\", \\\"{x:363,y:508,t:1527620982128};\\\", \\\"{x:354,y:510,t:1527620982146};\\\", \\\"{x:350,y:512,t:1527620982163};\\\", \\\"{x:348,y:512,t:1527620982179};\\\", \\\"{x:344,y:513,t:1527620982196};\\\", \\\"{x:341,y:515,t:1527620982213};\\\", \\\"{x:341,y:516,t:1527620982229};\\\", \\\"{x:341,y:517,t:1527620982247};\\\", \\\"{x:341,y:518,t:1527620982263};\\\", \\\"{x:341,y:519,t:1527620982279};\\\", \\\"{x:349,y:520,t:1527620982296};\\\", \\\"{x:365,y:520,t:1527620982314};\\\", \\\"{x:390,y:520,t:1527620982330};\\\", \\\"{x:423,y:520,t:1527620982346};\\\", \\\"{x:462,y:520,t:1527620982363};\\\", \\\"{x:491,y:520,t:1527620982380};\\\", \\\"{x:514,y:520,t:1527620982396};\\\", \\\"{x:528,y:520,t:1527620982413};\\\", \\\"{x:535,y:520,t:1527620982430};\\\", \\\"{x:537,y:520,t:1527620982446};\\\", \\\"{x:538,y:520,t:1527620982463};\\\", \\\"{x:536,y:522,t:1527620982512};\\\", \\\"{x:525,y:523,t:1527620982520};\\\", \\\"{x:513,y:526,t:1527620982530};\\\", \\\"{x:483,y:526,t:1527620982547};\\\", \\\"{x:443,y:527,t:1527620982563};\\\", \\\"{x:401,y:527,t:1527620982580};\\\", \\\"{x:367,y:527,t:1527620982596};\\\", \\\"{x:337,y:527,t:1527620982613};\\\", \\\"{x:314,y:527,t:1527620982630};\\\", \\\"{x:297,y:527,t:1527620982646};\\\", \\\"{x:284,y:527,t:1527620982663};\\\", \\\"{x:262,y:527,t:1527620982680};\\\", \\\"{x:245,y:527,t:1527620982695};\\\", \\\"{x:231,y:527,t:1527620982713};\\\", \\\"{x:219,y:527,t:1527620982731};\\\", \\\"{x:209,y:527,t:1527620982747};\\\", \\\"{x:202,y:529,t:1527620982763};\\\", \\\"{x:198,y:529,t:1527620982780};\\\", \\\"{x:196,y:529,t:1527620982808};\\\", \\\"{x:195,y:529,t:1527620982816};\\\", \\\"{x:193,y:529,t:1527620982830};\\\", \\\"{x:188,y:529,t:1527620982847};\\\", \\\"{x:183,y:531,t:1527620982863};\\\", \\\"{x:181,y:531,t:1527620982880};\\\", \\\"{x:180,y:531,t:1527620982921};\\\", \\\"{x:179,y:532,t:1527620982969};\\\", \\\"{x:178,y:532,t:1527620983192};\\\", \\\"{x:182,y:533,t:1527620983417};\\\", \\\"{x:185,y:536,t:1527620983430};\\\", \\\"{x:198,y:542,t:1527620983449};\\\", \\\"{x:210,y:548,t:1527620983464};\\\", \\\"{x:215,y:552,t:1527620983480};\\\", \\\"{x:218,y:556,t:1527620983497};\\\", \\\"{x:221,y:561,t:1527620983514};\\\", \\\"{x:223,y:564,t:1527620983532};\\\", \\\"{x:227,y:568,t:1527620983547};\\\", \\\"{x:227,y:571,t:1527620983564};\\\", \\\"{x:229,y:573,t:1527620983580};\\\", \\\"{x:230,y:575,t:1527620983597};\\\", \\\"{x:233,y:578,t:1527620983614};\\\", \\\"{x:234,y:580,t:1527620983630};\\\", \\\"{x:235,y:582,t:1527620983647};\\\", \\\"{x:237,y:586,t:1527620983664};\\\", \\\"{x:239,y:589,t:1527620983681};\\\", \\\"{x:240,y:591,t:1527620983697};\\\", \\\"{x:240,y:592,t:1527620983714};\\\", \\\"{x:240,y:594,t:1527620983732};\\\", \\\"{x:241,y:595,t:1527620983747};\\\", \\\"{x:241,y:597,t:1527620983764};\\\", \\\"{x:242,y:599,t:1527620983781};\\\", \\\"{x:242,y:601,t:1527620983797};\\\", \\\"{x:243,y:603,t:1527620983814};\\\", \\\"{x:244,y:606,t:1527620983830};\\\", \\\"{x:246,y:609,t:1527620983847};\\\", \\\"{x:247,y:611,t:1527620983864};\\\", \\\"{x:247,y:612,t:1527620983881};\\\", \\\"{x:249,y:614,t:1527620983897};\\\", \\\"{x:250,y:616,t:1527620983914};\\\", \\\"{x:251,y:618,t:1527620983931};\\\", \\\"{x:253,y:621,t:1527620983947};\\\", \\\"{x:253,y:624,t:1527620983964};\\\", \\\"{x:253,y:625,t:1527620983981};\\\", \\\"{x:254,y:626,t:1527620983997};\\\", \\\"{x:254,y:627,t:1527620984014};\\\", \\\"{x:255,y:627,t:1527620984030};\\\", \\\"{x:255,y:628,t:1527620984079};\\\", \\\"{x:256,y:628,t:1527620984399};\\\", \\\"{x:258,y:628,t:1527620984414};\\\", \\\"{x:258,y:629,t:1527620984431};\\\", \\\"{x:259,y:629,t:1527620984448};\\\", \\\"{x:260,y:629,t:1527620984464};\\\", \\\"{x:261,y:629,t:1527620984528};\\\", \\\"{x:263,y:629,t:1527620984679};\\\", \\\"{x:264,y:629,t:1527620984687};\\\", \\\"{x:265,y:629,t:1527620984698};\\\", \\\"{x:268,y:630,t:1527620984714};\\\", \\\"{x:271,y:630,t:1527620984731};\\\", \\\"{x:273,y:630,t:1527620984748};\\\", \\\"{x:275,y:630,t:1527620984765};\\\", \\\"{x:278,y:630,t:1527620984781};\\\", \\\"{x:280,y:630,t:1527620984797};\\\", \\\"{x:281,y:630,t:1527620984814};\\\", \\\"{x:280,y:631,t:1527620984991};\\\", \\\"{x:280,y:633,t:1527620985016};\\\", \\\"{x:279,y:634,t:1527620985031};\\\", \\\"{x:278,y:639,t:1527620985048};\\\", \\\"{x:278,y:645,t:1527620985065};\\\", \\\"{x:278,y:652,t:1527620985082};\\\", \\\"{x:278,y:657,t:1527620985098};\\\", \\\"{x:278,y:660,t:1527620985115};\\\", \\\"{x:278,y:663,t:1527620985132};\\\", \\\"{x:279,y:666,t:1527620985148};\\\", \\\"{x:279,y:667,t:1527620985165};\\\", \\\"{x:279,y:669,t:1527620985182};\\\", \\\"{x:280,y:673,t:1527620985199};\\\", \\\"{x:282,y:676,t:1527620985215};\\\", \\\"{x:286,y:680,t:1527620985231};\\\", \\\"{x:289,y:682,t:1527620985249};\\\", \\\"{x:292,y:685,t:1527620985265};\\\", \\\"{x:294,y:687,t:1527620985282};\\\", \\\"{x:299,y:692,t:1527620985299};\\\", \\\"{x:310,y:701,t:1527620985315};\\\", \\\"{x:325,y:709,t:1527620985332};\\\", \\\"{x:341,y:718,t:1527620985349};\\\", \\\"{x:352,y:723,t:1527620985365};\\\", \\\"{x:367,y:729,t:1527620985382};\\\", \\\"{x:385,y:733,t:1527620985399};\\\", \\\"{x:406,y:737,t:1527620985415};\\\", \\\"{x:412,y:737,t:1527620985432};\\\", \\\"{x:419,y:737,t:1527620985449};\\\", \\\"{x:426,y:737,t:1527620985466};\\\", \\\"{x:433,y:737,t:1527620985481};\\\", \\\"{x:440,y:737,t:1527620985499};\\\", \\\"{x:448,y:737,t:1527620985516};\\\", \\\"{x:458,y:737,t:1527620985532};\\\", \\\"{x:468,y:737,t:1527620985549};\\\", \\\"{x:479,y:737,t:1527620985565};\\\", \\\"{x:490,y:738,t:1527620985582};\\\", \\\"{x:500,y:739,t:1527620985599};\\\", \\\"{x:512,y:742,t:1527620985615};\\\", \\\"{x:520,y:743,t:1527620985632};\\\", \\\"{x:525,y:745,t:1527620985649};\\\", \\\"{x:529,y:746,t:1527620985666};\\\", \\\"{x:533,y:748,t:1527620985682};\\\", \\\"{x:534,y:749,t:1527620985703};\\\", \\\"{x:535,y:750,t:1527620985720};\\\", \\\"{x:536,y:750,t:1527620985732};\\\", \\\"{x:537,y:750,t:1527620985760};\\\", \\\"{x:538,y:751,t:1527620985768};\\\", \\\"{x:538,y:750,t:1527620986072};\\\", \\\"{x:538,y:749,t:1527620986082};\\\", \\\"{x:538,y:748,t:1527620986127};\\\", \\\"{x:538,y:747,t:1527620986136};\\\", \\\"{x:538,y:746,t:1527620986149};\\\", \\\"{x:538,y:745,t:1527620986168};\\\", \\\"{x:538,y:744,t:1527620986183};\\\", \\\"{x:538,y:743,t:1527620986199};\\\", \\\"{x:538,y:741,t:1527620986215};\\\", \\\"{x:538,y:740,t:1527620986239};\\\", \\\"{x:538,y:738,t:1527620986256};\\\", \\\"{x:537,y:737,t:1527620986295};\\\", \\\"{x:538,y:737,t:1527620986480};\\\", \\\"{x:539,y:737,t:1527620986519};\\\", \\\"{x:541,y:737,t:1527620986552};\\\", \\\"{x:542,y:738,t:1527620986592};\\\", \\\"{x:543,y:739,t:1527620986623};\\\", \\\"{x:544,y:741,t:1527620986639};\\\", \\\"{x:545,y:742,t:1527620986655};\\\", \\\"{x:546,y:742,t:1527620986720};\\\", \\\"{x:547,y:742,t:1527620986880};\\\", \\\"{x:548,y:742,t:1527620986888};\\\", \\\"{x:547,y:741,t:1527620987003};\\\", \\\"{x:545,y:739,t:1527620987017};\\\", \\\"{x:541,y:738,t:1527620987033};\\\", \\\"{x:538,y:737,t:1527620987050};\\\", \\\"{x:535,y:737,t:1527620987067};\\\" ] }, { \\\"rt\\\": 49973, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 486258, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:727,t:1527620987343};\\\", \\\"{x:525,y:725,t:1527620988728};\\\", \\\"{x:525,y:723,t:1527620988746};\\\", \\\"{x:524,y:722,t:1527620988752};\\\", \\\"{x:523,y:721,t:1527620988769};\\\", \\\"{x:518,y:721,t:1527620988784};\\\", \\\"{x:508,y:721,t:1527620988801};\\\", \\\"{x:493,y:721,t:1527620988819};\\\", \\\"{x:475,y:723,t:1527620988834};\\\", \\\"{x:460,y:723,t:1527620988852};\\\", \\\"{x:444,y:727,t:1527620988869};\\\", \\\"{x:426,y:733,t:1527620988884};\\\", \\\"{x:396,y:739,t:1527620988902};\\\", \\\"{x:354,y:739,t:1527620988918};\\\", \\\"{x:310,y:737,t:1527620988936};\\\", \\\"{x:276,y:731,t:1527620988951};\\\", \\\"{x:238,y:720,t:1527620988968};\\\", \\\"{x:222,y:714,t:1527620988985};\\\", \\\"{x:211,y:709,t:1527620989001};\\\", \\\"{x:207,y:706,t:1527620989018};\\\", \\\"{x:206,y:705,t:1527620989035};\\\", \\\"{x:206,y:704,t:1527620989056};\\\", \\\"{x:206,y:703,t:1527620989069};\\\", \\\"{x:206,y:702,t:1527620989085};\\\", \\\"{x:208,y:699,t:1527620989101};\\\", \\\"{x:209,y:699,t:1527620989118};\\\", \\\"{x:209,y:698,t:1527620989135};\\\", \\\"{x:210,y:697,t:1527620989151};\\\", \\\"{x:212,y:696,t:1527620989169};\\\", \\\"{x:214,y:696,t:1527620989185};\\\", \\\"{x:215,y:696,t:1527620989208};\\\", \\\"{x:216,y:696,t:1527620989224};\\\", \\\"{x:217,y:696,t:1527620989240};\\\", \\\"{x:218,y:696,t:1527620989256};\\\", \\\"{x:219,y:696,t:1527620989268};\\\", \\\"{x:223,y:696,t:1527620989286};\\\", \\\"{x:227,y:697,t:1527620989301};\\\", \\\"{x:230,y:699,t:1527620989318};\\\", \\\"{x:236,y:701,t:1527620989335};\\\", \\\"{x:238,y:703,t:1527620989351};\\\", \\\"{x:241,y:704,t:1527620989368};\\\", \\\"{x:243,y:705,t:1527620989385};\\\", \\\"{x:244,y:706,t:1527620989402};\\\", \\\"{x:245,y:707,t:1527620989418};\\\", \\\"{x:246,y:707,t:1527620989480};\\\", \\\"{x:246,y:708,t:1527620989513};\\\", \\\"{x:246,y:709,t:1527620989625};\\\", \\\"{x:245,y:709,t:1527620989636};\\\", \\\"{x:240,y:709,t:1527620989653};\\\", \\\"{x:239,y:709,t:1527620989668};\\\", \\\"{x:238,y:709,t:1527620989936};\\\", \\\"{x:268,y:693,t:1527620989953};\\\", \\\"{x:315,y:680,t:1527620989969};\\\", \\\"{x:354,y:669,t:1527620989986};\\\", \\\"{x:396,y:656,t:1527620990003};\\\", \\\"{x:432,y:647,t:1527620990019};\\\", \\\"{x:449,y:640,t:1527620990036};\\\", \\\"{x:459,y:636,t:1527620990052};\\\", \\\"{x:465,y:632,t:1527620990069};\\\", \\\"{x:468,y:629,t:1527620990086};\\\", \\\"{x:470,y:629,t:1527620990102};\\\", \\\"{x:470,y:628,t:1527620990120};\\\", \\\"{x:471,y:628,t:1527620990136};\\\", \\\"{x:472,y:628,t:1527620990153};\\\", \\\"{x:473,y:628,t:1527620990169};\\\", \\\"{x:474,y:628,t:1527620990216};\\\", \\\"{x:475,y:628,t:1527620990224};\\\", \\\"{x:476,y:628,t:1527620990239};\\\", \\\"{x:478,y:628,t:1527620990263};\\\", \\\"{x:479,y:628,t:1527620990272};\\\", \\\"{x:481,y:628,t:1527620990286};\\\", \\\"{x:484,y:628,t:1527620990302};\\\", \\\"{x:493,y:628,t:1527620990320};\\\", \\\"{x:504,y:630,t:1527620990336};\\\", \\\"{x:509,y:631,t:1527620990352};\\\", \\\"{x:514,y:631,t:1527620990369};\\\", \\\"{x:522,y:631,t:1527620990385};\\\", \\\"{x:537,y:631,t:1527620990402};\\\", \\\"{x:544,y:631,t:1527620990419};\\\", \\\"{x:550,y:631,t:1527620990435};\\\", \\\"{x:551,y:631,t:1527620990452};\\\", \\\"{x:553,y:631,t:1527620990469};\\\", \\\"{x:553,y:632,t:1527620990576};\\\", \\\"{x:552,y:633,t:1527620990792};\\\", \\\"{x:548,y:633,t:1527620990803};\\\", \\\"{x:544,y:633,t:1527620990819};\\\", \\\"{x:543,y:633,t:1527620990848};\\\", \\\"{x:544,y:633,t:1527620991223};\\\", \\\"{x:545,y:633,t:1527620991239};\\\", \\\"{x:547,y:633,t:1527620991255};\\\", \\\"{x:549,y:633,t:1527620991272};\\\", \\\"{x:551,y:632,t:1527620991288};\\\", \\\"{x:555,y:632,t:1527620991304};\\\", \\\"{x:561,y:628,t:1527620991321};\\\", \\\"{x:565,y:626,t:1527620991337};\\\", \\\"{x:573,y:621,t:1527620991354};\\\", \\\"{x:585,y:616,t:1527620991370};\\\", \\\"{x:604,y:609,t:1527620991387};\\\", \\\"{x:619,y:604,t:1527620991404};\\\", \\\"{x:633,y:598,t:1527620991421};\\\", \\\"{x:643,y:594,t:1527620991437};\\\", \\\"{x:654,y:590,t:1527620991454};\\\", \\\"{x:665,y:586,t:1527620991471};\\\", \\\"{x:681,y:585,t:1527620991486};\\\", \\\"{x:707,y:583,t:1527620991503};\\\", \\\"{x:759,y:583,t:1527620991520};\\\", \\\"{x:799,y:577,t:1527620991537};\\\", \\\"{x:829,y:577,t:1527620991553};\\\", \\\"{x:854,y:577,t:1527620991571};\\\", \\\"{x:875,y:577,t:1527620991587};\\\", \\\"{x:895,y:577,t:1527620991603};\\\", \\\"{x:912,y:576,t:1527620991620};\\\", \\\"{x:923,y:574,t:1527620991637};\\\", \\\"{x:933,y:574,t:1527620991653};\\\", \\\"{x:942,y:574,t:1527620991670};\\\", \\\"{x:950,y:573,t:1527620991687};\\\", \\\"{x:961,y:572,t:1527620991704};\\\", \\\"{x:990,y:571,t:1527620991721};\\\", \\\"{x:1017,y:571,t:1527620991737};\\\", \\\"{x:1049,y:571,t:1527620991754};\\\", \\\"{x:1097,y:571,t:1527620991771};\\\", \\\"{x:1136,y:571,t:1527620991788};\\\", \\\"{x:1162,y:571,t:1527620991805};\\\", \\\"{x:1182,y:571,t:1527620991821};\\\", \\\"{x:1201,y:571,t:1527620991837};\\\", \\\"{x:1211,y:571,t:1527620991855};\\\", \\\"{x:1214,y:571,t:1527620991871};\\\", \\\"{x:1214,y:570,t:1527620992680};\\\", \\\"{x:1214,y:569,t:1527620992695};\\\", \\\"{x:1214,y:567,t:1527620992706};\\\", \\\"{x:1213,y:564,t:1527620992722};\\\", \\\"{x:1211,y:560,t:1527620992740};\\\", \\\"{x:1210,y:555,t:1527620992755};\\\", \\\"{x:1209,y:551,t:1527620992772};\\\", \\\"{x:1208,y:547,t:1527620992789};\\\", \\\"{x:1206,y:543,t:1527620992806};\\\", \\\"{x:1205,y:538,t:1527620992822};\\\", \\\"{x:1204,y:536,t:1527620992839};\\\", \\\"{x:1203,y:530,t:1527620992856};\\\", \\\"{x:1202,y:529,t:1527620992873};\\\", \\\"{x:1202,y:527,t:1527620992889};\\\", \\\"{x:1200,y:526,t:1527620992906};\\\", \\\"{x:1200,y:525,t:1527620993336};\\\", \\\"{x:1200,y:524,t:1527620993392};\\\", \\\"{x:1200,y:523,t:1527620993488};\\\", \\\"{x:1200,y:522,t:1527620993535};\\\", \\\"{x:1200,y:521,t:1527620993600};\\\", \\\"{x:1201,y:520,t:1527620993616};\\\", \\\"{x:1202,y:520,t:1527620993640};\\\", \\\"{x:1203,y:520,t:1527620993655};\\\", \\\"{x:1204,y:520,t:1527620993664};\\\", \\\"{x:1205,y:520,t:1527620993675};\\\", \\\"{x:1207,y:519,t:1527620993690};\\\", \\\"{x:1209,y:518,t:1527620993707};\\\", \\\"{x:1210,y:518,t:1527620993725};\\\", \\\"{x:1213,y:517,t:1527620993742};\\\", \\\"{x:1214,y:517,t:1527620993760};\\\", \\\"{x:1215,y:517,t:1527620993775};\\\", \\\"{x:1216,y:517,t:1527620993792};\\\", \\\"{x:1218,y:517,t:1527620993808};\\\", \\\"{x:1219,y:517,t:1527620993825};\\\", \\\"{x:1220,y:518,t:1527620993848};\\\", \\\"{x:1221,y:519,t:1527620993863};\\\", \\\"{x:1222,y:520,t:1527620993880};\\\", \\\"{x:1224,y:520,t:1527620993896};\\\", \\\"{x:1226,y:521,t:1527620993907};\\\", \\\"{x:1230,y:523,t:1527620993924};\\\", \\\"{x:1232,y:523,t:1527620993942};\\\", \\\"{x:1233,y:524,t:1527620993959};\\\", \\\"{x:1237,y:526,t:1527620993975};\\\", \\\"{x:1239,y:527,t:1527620993992};\\\", \\\"{x:1241,y:529,t:1527620994007};\\\", \\\"{x:1243,y:530,t:1527620994024};\\\", \\\"{x:1247,y:533,t:1527620994041};\\\", \\\"{x:1249,y:534,t:1527620994058};\\\", \\\"{x:1251,y:536,t:1527620994075};\\\", \\\"{x:1252,y:537,t:1527620994091};\\\", \\\"{x:1253,y:537,t:1527620994109};\\\", \\\"{x:1255,y:539,t:1527620994125};\\\", \\\"{x:1256,y:540,t:1527620994142};\\\", \\\"{x:1258,y:542,t:1527620994159};\\\", \\\"{x:1259,y:544,t:1527620994176};\\\", \\\"{x:1259,y:545,t:1527620994208};\\\", \\\"{x:1260,y:546,t:1527620994256};\\\", \\\"{x:1260,y:547,t:1527620994304};\\\", \\\"{x:1260,y:548,t:1527620994336};\\\", \\\"{x:1260,y:549,t:1527620994440};\\\", \\\"{x:1260,y:550,t:1527620994480};\\\", \\\"{x:1260,y:551,t:1527620994496};\\\", \\\"{x:1260,y:552,t:1527620994536};\\\", \\\"{x:1260,y:553,t:1527620994560};\\\", \\\"{x:1260,y:554,t:1527620994575};\\\", \\\"{x:1260,y:555,t:1527620994624};\\\", \\\"{x:1259,y:555,t:1527620994656};\\\", \\\"{x:1256,y:555,t:1527620994680};\\\", \\\"{x:1255,y:555,t:1527620994693};\\\", \\\"{x:1250,y:554,t:1527620994709};\\\", \\\"{x:1245,y:552,t:1527620994727};\\\", \\\"{x:1238,y:549,t:1527620994743};\\\", \\\"{x:1224,y:544,t:1527620994760};\\\", \\\"{x:1208,y:541,t:1527620994776};\\\", \\\"{x:1190,y:539,t:1527620994793};\\\", \\\"{x:1165,y:535,t:1527620994810};\\\", \\\"{x:1130,y:529,t:1527620994827};\\\", \\\"{x:1096,y:524,t:1527620994843};\\\", \\\"{x:1065,y:520,t:1527620994860};\\\", \\\"{x:1038,y:514,t:1527620994877};\\\", \\\"{x:1019,y:508,t:1527620994893};\\\", \\\"{x:1008,y:503,t:1527620994909};\\\", \\\"{x:998,y:500,t:1527620994926};\\\", \\\"{x:991,y:495,t:1527620994944};\\\", \\\"{x:990,y:494,t:1527620994968};\\\", \\\"{x:990,y:493,t:1527620995040};\\\", \\\"{x:991,y:493,t:1527620995048};\\\", \\\"{x:993,y:493,t:1527620995061};\\\", \\\"{x:998,y:493,t:1527620995077};\\\", \\\"{x:1002,y:493,t:1527620995093};\\\", \\\"{x:1010,y:493,t:1527620995111};\\\", \\\"{x:1016,y:493,t:1527620995127};\\\", \\\"{x:1031,y:493,t:1527620995143};\\\", \\\"{x:1050,y:491,t:1527620995161};\\\", \\\"{x:1068,y:491,t:1527620995176};\\\", \\\"{x:1084,y:491,t:1527620995194};\\\", \\\"{x:1091,y:491,t:1527620995211};\\\", \\\"{x:1094,y:491,t:1527620995228};\\\", \\\"{x:1095,y:491,t:1527620995244};\\\", \\\"{x:1097,y:491,t:1527620995271};\\\", \\\"{x:1098,y:491,t:1527620995311};\\\", \\\"{x:1098,y:492,t:1527620995496};\\\", \\\"{x:1098,y:493,t:1527620995536};\\\", \\\"{x:1098,y:494,t:1527620995552};\\\", \\\"{x:1098,y:495,t:1527620995584};\\\", \\\"{x:1098,y:496,t:1527620995600};\\\", \\\"{x:1098,y:497,t:1527620995615};\\\", \\\"{x:1098,y:498,t:1527620995639};\\\", \\\"{x:1098,y:499,t:1527620995671};\\\", \\\"{x:1098,y:500,t:1527620995704};\\\", \\\"{x:1100,y:500,t:1527620996024};\\\", \\\"{x:1101,y:500,t:1527620996032};\\\", \\\"{x:1103,y:500,t:1527620996045};\\\", \\\"{x:1106,y:500,t:1527620996061};\\\", \\\"{x:1111,y:500,t:1527620996078};\\\", \\\"{x:1117,y:500,t:1527620996095};\\\", \\\"{x:1122,y:500,t:1527620996112};\\\", \\\"{x:1127,y:500,t:1527620996128};\\\", \\\"{x:1130,y:500,t:1527620996146};\\\", \\\"{x:1134,y:499,t:1527620996163};\\\", \\\"{x:1138,y:498,t:1527620996178};\\\", \\\"{x:1143,y:496,t:1527620996195};\\\", \\\"{x:1147,y:496,t:1527620996213};\\\", \\\"{x:1151,y:496,t:1527620996229};\\\", \\\"{x:1157,y:496,t:1527620996245};\\\", \\\"{x:1163,y:494,t:1527620996262};\\\", \\\"{x:1172,y:493,t:1527620996280};\\\", \\\"{x:1178,y:492,t:1527620996295};\\\", \\\"{x:1182,y:492,t:1527620996313};\\\", \\\"{x:1186,y:490,t:1527620996330};\\\", \\\"{x:1190,y:490,t:1527620996346};\\\", \\\"{x:1194,y:490,t:1527620996363};\\\", \\\"{x:1201,y:490,t:1527620996379};\\\", \\\"{x:1209,y:490,t:1527620996396};\\\", \\\"{x:1214,y:489,t:1527620996412};\\\", \\\"{x:1218,y:489,t:1527620996429};\\\", \\\"{x:1219,y:489,t:1527620996445};\\\", \\\"{x:1220,y:489,t:1527620996463};\\\", \\\"{x:1223,y:489,t:1527620996480};\\\", \\\"{x:1225,y:489,t:1527620996496};\\\", \\\"{x:1227,y:489,t:1527620996513};\\\", \\\"{x:1229,y:489,t:1527620996530};\\\", \\\"{x:1232,y:489,t:1527620996546};\\\", \\\"{x:1234,y:489,t:1527620996563};\\\", \\\"{x:1239,y:489,t:1527620996579};\\\", \\\"{x:1242,y:489,t:1527620996597};\\\", \\\"{x:1246,y:489,t:1527620996613};\\\", \\\"{x:1249,y:489,t:1527620996630};\\\", \\\"{x:1251,y:489,t:1527620996646};\\\", \\\"{x:1257,y:489,t:1527620996663};\\\", \\\"{x:1263,y:490,t:1527620996679};\\\", \\\"{x:1268,y:490,t:1527620996696};\\\", \\\"{x:1272,y:491,t:1527620996714};\\\", \\\"{x:1276,y:491,t:1527620996730};\\\", \\\"{x:1279,y:491,t:1527620996747};\\\", \\\"{x:1283,y:493,t:1527620996764};\\\", \\\"{x:1285,y:493,t:1527620996779};\\\", \\\"{x:1288,y:494,t:1527620996797};\\\", \\\"{x:1292,y:494,t:1527620996814};\\\", \\\"{x:1294,y:494,t:1527620996829};\\\", \\\"{x:1297,y:494,t:1527620996846};\\\", \\\"{x:1302,y:495,t:1527620996863};\\\", \\\"{x:1306,y:496,t:1527620996880};\\\", \\\"{x:1311,y:498,t:1527620996896};\\\", \\\"{x:1314,y:498,t:1527620996913};\\\", \\\"{x:1318,y:499,t:1527620996930};\\\", \\\"{x:1320,y:499,t:1527620996947};\\\", \\\"{x:1321,y:499,t:1527620996963};\\\", \\\"{x:1323,y:499,t:1527620996981};\\\", \\\"{x:1324,y:500,t:1527620996996};\\\", \\\"{x:1325,y:500,t:1527620997014};\\\", \\\"{x:1326,y:500,t:1527620997030};\\\", \\\"{x:1328,y:500,t:1527620997047};\\\", \\\"{x:1329,y:500,t:1527620997064};\\\", \\\"{x:1330,y:500,t:1527620997080};\\\", \\\"{x:1331,y:500,t:1527620997098};\\\", \\\"{x:1332,y:500,t:1527620997119};\\\", \\\"{x:1333,y:500,t:1527620997160};\\\", \\\"{x:1334,y:500,t:1527620997297};\\\", \\\"{x:1335,y:500,t:1527620997361};\\\", \\\"{x:1336,y:500,t:1527620997408};\\\", \\\"{x:1337,y:500,t:1527620997431};\\\", \\\"{x:1338,y:500,t:1527620997448};\\\", \\\"{x:1340,y:500,t:1527620997465};\\\", \\\"{x:1342,y:501,t:1527620997482};\\\", \\\"{x:1345,y:502,t:1527620997499};\\\", \\\"{x:1348,y:502,t:1527620997515};\\\", \\\"{x:1349,y:502,t:1527620997532};\\\", \\\"{x:1351,y:502,t:1527620997548};\\\", \\\"{x:1353,y:502,t:1527620997569};\\\", \\\"{x:1355,y:502,t:1527620997582};\\\", \\\"{x:1359,y:502,t:1527620997600};\\\", \\\"{x:1362,y:502,t:1527620997615};\\\", \\\"{x:1365,y:502,t:1527620997633};\\\", \\\"{x:1367,y:502,t:1527620997649};\\\", \\\"{x:1369,y:502,t:1527620997665};\\\", \\\"{x:1371,y:502,t:1527620997682};\\\", \\\"{x:1372,y:502,t:1527620997699};\\\", \\\"{x:1374,y:502,t:1527620997715};\\\", \\\"{x:1375,y:502,t:1527620997732};\\\", \\\"{x:1377,y:502,t:1527620997749};\\\", \\\"{x:1378,y:502,t:1527620997785};\\\", \\\"{x:1378,y:501,t:1527620998242};\\\", \\\"{x:1377,y:500,t:1527620998337};\\\", \\\"{x:1376,y:498,t:1527621031132};\\\", \\\"{x:1371,y:465,t:1527621031149};\\\", \\\"{x:1355,y:415,t:1527621031165};\\\", \\\"{x:1346,y:366,t:1527621031183};\\\", \\\"{x:1347,y:335,t:1527621031198};\\\", \\\"{x:1372,y:298,t:1527621031215};\\\", \\\"{x:1396,y:271,t:1527621031233};\\\", \\\"{x:1416,y:248,t:1527621031248};\\\", \\\"{x:1420,y:235,t:1527621031265};\\\", \\\"{x:1420,y:229,t:1527621031282};\\\", \\\"{x:1421,y:228,t:1527621031298};\\\", \\\"{x:1434,y:225,t:1527621031315};\\\", \\\"{x:1446,y:222,t:1527621031331};\\\", \\\"{x:1448,y:222,t:1527621031348};\\\", \\\"{x:1433,y:234,t:1527621031365};\\\", \\\"{x:1308,y:289,t:1527621031382};\\\", \\\"{x:1106,y:390,t:1527621031399};\\\", \\\"{x:873,y:476,t:1527621031415};\\\", \\\"{x:659,y:561,t:1527621031432};\\\", \\\"{x:537,y:618,t:1527621031450};\\\", \\\"{x:523,y:630,t:1527621031464};\\\", \\\"{x:523,y:631,t:1527621031491};\\\", \\\"{x:523,y:633,t:1527621031499};\\\", \\\"{x:523,y:632,t:1527621031522};\\\", \\\"{x:532,y:629,t:1527621031540};\\\", \\\"{x:541,y:625,t:1527621031557};\\\", \\\"{x:547,y:622,t:1527621031572};\\\", \\\"{x:556,y:612,t:1527621031589};\\\", \\\"{x:577,y:596,t:1527621031607};\\\", \\\"{x:606,y:572,t:1527621031623};\\\", \\\"{x:623,y:552,t:1527621031640};\\\", \\\"{x:632,y:536,t:1527621031657};\\\", \\\"{x:632,y:528,t:1527621031672};\\\", \\\"{x:632,y:526,t:1527621031690};\\\", \\\"{x:632,y:523,t:1527621031706};\\\", \\\"{x:631,y:523,t:1527621031723};\\\", \\\"{x:631,y:522,t:1527621031739};\\\", \\\"{x:631,y:520,t:1527621031757};\\\", \\\"{x:632,y:516,t:1527621031773};\\\", \\\"{x:632,y:515,t:1527621031789};\\\", \\\"{x:632,y:514,t:1527621031807};\\\", \\\"{x:632,y:513,t:1527621031875};\\\", \\\"{x:632,y:512,t:1527621031891};\\\", \\\"{x:632,y:511,t:1527621031906};\\\", \\\"{x:631,y:510,t:1527621031922};\\\", \\\"{x:630,y:509,t:1527621031939};\\\", \\\"{x:629,y:508,t:1527621031956};\\\", \\\"{x:629,y:507,t:1527621031972};\\\", \\\"{x:628,y:505,t:1527621032003};\\\", \\\"{x:627,y:504,t:1527621032019};\\\", \\\"{x:626,y:503,t:1527621032035};\\\", \\\"{x:625,y:503,t:1527621032051};\\\", \\\"{x:624,y:503,t:1527621032059};\\\", \\\"{x:623,y:502,t:1527621032130};\\\", \\\"{x:623,y:502,t:1527621032140};\\\", \\\"{x:623,y:501,t:1527621032291};\\\", \\\"{x:617,y:510,t:1527621032307};\\\", \\\"{x:609,y:521,t:1527621032324};\\\", \\\"{x:602,y:532,t:1527621032340};\\\", \\\"{x:595,y:544,t:1527621032356};\\\", \\\"{x:589,y:555,t:1527621032374};\\\", \\\"{x:583,y:571,t:1527621032390};\\\", \\\"{x:578,y:582,t:1527621032407};\\\", \\\"{x:574,y:593,t:1527621032424};\\\", \\\"{x:570,y:604,t:1527621032440};\\\", \\\"{x:565,y:613,t:1527621032456};\\\", \\\"{x:561,y:625,t:1527621032473};\\\", \\\"{x:558,y:633,t:1527621032490};\\\", \\\"{x:549,y:646,t:1527621032507};\\\", \\\"{x:545,y:654,t:1527621032524};\\\", \\\"{x:541,y:662,t:1527621032541};\\\", \\\"{x:537,y:673,t:1527621032556};\\\", \\\"{x:534,y:684,t:1527621032574};\\\", \\\"{x:531,y:693,t:1527621032591};\\\", \\\"{x:531,y:703,t:1527621032606};\\\", \\\"{x:528,y:717,t:1527621032623};\\\", \\\"{x:527,y:731,t:1527621032641};\\\", \\\"{x:526,y:740,t:1527621032656};\\\", \\\"{x:526,y:744,t:1527621032673};\\\", \\\"{x:526,y:752,t:1527621032689};\\\", \\\"{x:526,y:756,t:1527621032707};\\\", \\\"{x:526,y:759,t:1527621032723};\\\", \\\"{x:527,y:761,t:1527621032739};\\\", \\\"{x:527,y:762,t:1527621032756};\\\", \\\"{x:528,y:763,t:1527621033164};\\\", \\\"{x:529,y:763,t:1527621033179};\\\", \\\"{x:530,y:763,t:1527621033195};\\\", \\\"{x:530,y:764,t:1527621033211};\\\", \\\"{x:531,y:765,t:1527621033223};\\\", \\\"{x:531,y:766,t:1527621033252};\\\", \\\"{x:532,y:766,t:1527621033258};\\\", \\\"{x:538,y:768,t:1527621033274};\\\", \\\"{x:540,y:769,t:1527621033291};\\\", \\\"{x:544,y:770,t:1527621033307};\\\", \\\"{x:548,y:770,t:1527621033325};\\\", \\\"{x:550,y:772,t:1527621033340};\\\", \\\"{x:551,y:772,t:1527621034876};\\\", \\\"{x:551,y:770,t:1527621034931};\\\", \\\"{x:552,y:770,t:1527621035051};\\\", \\\"{x:554,y:770,t:1527621035059};\\\", \\\"{x:557,y:775,t:1527621035077};\\\", \\\"{x:559,y:778,t:1527621035093};\\\", \\\"{x:559,y:781,t:1527621035109};\\\", \\\"{x:561,y:784,t:1527621035126};\\\", \\\"{x:563,y:789,t:1527621035144};\\\", \\\"{x:566,y:792,t:1527621035160};\\\", \\\"{x:567,y:794,t:1527621035177};\\\", \\\"{x:568,y:795,t:1527621035194};\\\", \\\"{x:569,y:796,t:1527621035209};\\\", \\\"{x:570,y:797,t:1527621035226};\\\", \\\"{x:572,y:799,t:1527621035243};\\\", \\\"{x:573,y:800,t:1527621035259};\\\", \\\"{x:574,y:802,t:1527621035276};\\\", \\\"{x:575,y:802,t:1527621035293};\\\", \\\"{x:577,y:803,t:1527621035310};\\\", \\\"{x:577,y:804,t:1527621035331};\\\", \\\"{x:578,y:804,t:1527621035356};\\\", \\\"{x:579,y:805,t:1527621035363};\\\", \\\"{x:579,y:806,t:1527621035376};\\\", \\\"{x:580,y:806,t:1527621035460};\\\", \\\"{x:580,y:805,t:1527621036387};\\\", \\\"{x:580,y:804,t:1527621036395};\\\", \\\"{x:579,y:803,t:1527621036411};\\\", \\\"{x:577,y:801,t:1527621036427};\\\", \\\"{x:575,y:800,t:1527621036445};\\\", \\\"{x:573,y:798,t:1527621036461};\\\", \\\"{x:572,y:797,t:1527621036477};\\\", \\\"{x:571,y:795,t:1527621036494};\\\", \\\"{x:570,y:792,t:1527621036511};\\\", \\\"{x:567,y:787,t:1527621036527};\\\", \\\"{x:563,y:780,t:1527621036545};\\\", \\\"{x:561,y:773,t:1527621036562};\\\", \\\"{x:558,y:767,t:1527621036577};\\\", \\\"{x:557,y:762,t:1527621036594};\\\", \\\"{x:553,y:752,t:1527621036611};\\\", \\\"{x:551,y:747,t:1527621036626};\\\", \\\"{x:549,y:742,t:1527621036643};\\\", \\\"{x:547,y:740,t:1527621036658};\\\", \\\"{x:543,y:734,t:1527621036675};\\\", \\\"{x:541,y:731,t:1527621036690};\\\", \\\"{x:540,y:728,t:1527621036707};\\\", \\\"{x:539,y:727,t:1527621036724};\\\", \\\"{x:539,y:725,t:1527621036741};\\\", \\\"{x:539,y:724,t:1527621036757};\\\", \\\"{x:539,y:725,t:1527621037099};\\\", \\\"{x:539,y:726,t:1527621037204};\\\", \\\"{x:539,y:727,t:1527621037370};\\\", \\\"{x:538,y:727,t:1527621037378};\\\", \\\"{x:537,y:728,t:1527621037507};\\\", \\\"{x:538,y:729,t:1527621037602};\\\", \\\"{x:539,y:730,t:1527621037626};\\\", \\\"{x:540,y:731,t:1527621037641};\\\", \\\"{x:543,y:732,t:1527621037658};\\\", \\\"{x:544,y:733,t:1527621037666};\\\", \\\"{x:544,y:734,t:1527621037677};\\\", \\\"{x:546,y:736,t:1527621037693};\\\", \\\"{x:548,y:740,t:1527621037710};\\\", \\\"{x:550,y:743,t:1527621037728};\\\", \\\"{x:554,y:747,t:1527621037743};\\\", \\\"{x:555,y:751,t:1527621037761};\\\", \\\"{x:556,y:754,t:1527621037777};\\\", \\\"{x:557,y:755,t:1527621037794};\\\", \\\"{x:558,y:759,t:1527621037810};\\\", \\\"{x:560,y:761,t:1527621037828};\\\", \\\"{x:560,y:763,t:1527621037845};\\\", \\\"{x:561,y:765,t:1527621037860};\\\", \\\"{x:561,y:767,t:1527621037878};\\\", \\\"{x:561,y:768,t:1527621037895};\\\" ] }, { \\\"rt\\\": 44628, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 532089, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:561,y:769,t:1527621039924};\\\", \\\"{x:561,y:768,t:1527621042052};\\\", \\\"{x:561,y:763,t:1527621042065};\\\", \\\"{x:561,y:747,t:1527621042083};\\\", \\\"{x:561,y:730,t:1527621042098};\\\", \\\"{x:561,y:717,t:1527621042114};\\\", \\\"{x:563,y:709,t:1527621042130};\\\", \\\"{x:564,y:705,t:1527621042147};\\\", \\\"{x:564,y:703,t:1527621042165};\\\", \\\"{x:565,y:701,t:1527621042180};\\\", \\\"{x:565,y:699,t:1527621042198};\\\", \\\"{x:565,y:697,t:1527621042215};\\\", \\\"{x:565,y:696,t:1527621042231};\\\", \\\"{x:566,y:694,t:1527621042248};\\\", \\\"{x:568,y:691,t:1527621042265};\\\", \\\"{x:570,y:688,t:1527621042281};\\\", \\\"{x:571,y:688,t:1527621042298};\\\", \\\"{x:576,y:685,t:1527621042315};\\\", \\\"{x:578,y:684,t:1527621042332};\\\", \\\"{x:583,y:681,t:1527621042349};\\\", \\\"{x:587,y:677,t:1527621042365};\\\", \\\"{x:589,y:673,t:1527621042382};\\\", \\\"{x:590,y:666,t:1527621042398};\\\", \\\"{x:590,y:656,t:1527621042415};\\\", \\\"{x:590,y:642,t:1527621042433};\\\", \\\"{x:588,y:626,t:1527621042449};\\\", \\\"{x:582,y:606,t:1527621042465};\\\", \\\"{x:577,y:598,t:1527621042483};\\\", \\\"{x:574,y:594,t:1527621042498};\\\", \\\"{x:569,y:588,t:1527621042515};\\\", \\\"{x:565,y:587,t:1527621042532};\\\", \\\"{x:560,y:585,t:1527621042548};\\\", \\\"{x:557,y:583,t:1527621042565};\\\", \\\"{x:554,y:581,t:1527621042581};\\\", \\\"{x:541,y:571,t:1527621042599};\\\", \\\"{x:523,y:558,t:1527621042616};\\\", \\\"{x:515,y:553,t:1527621042631};\\\", \\\"{x:496,y:542,t:1527621042649};\\\", \\\"{x:468,y:530,t:1527621042665};\\\", \\\"{x:446,y:521,t:1527621042682};\\\", \\\"{x:415,y:511,t:1527621042698};\\\", \\\"{x:395,y:502,t:1527621042715};\\\", \\\"{x:390,y:499,t:1527621042731};\\\", \\\"{x:388,y:498,t:1527621042748};\\\", \\\"{x:384,y:495,t:1527621042764};\\\", \\\"{x:383,y:493,t:1527621042781};\\\", \\\"{x:384,y:493,t:1527621042987};\\\", \\\"{x:385,y:493,t:1527621042999};\\\", \\\"{x:387,y:493,t:1527621043016};\\\", \\\"{x:391,y:493,t:1527621043031};\\\", \\\"{x:394,y:493,t:1527621043049};\\\", \\\"{x:398,y:493,t:1527621043066};\\\", \\\"{x:403,y:493,t:1527621043081};\\\", \\\"{x:407,y:493,t:1527621043098};\\\", \\\"{x:409,y:493,t:1527621043115};\\\", \\\"{x:411,y:494,t:1527621043132};\\\", \\\"{x:413,y:494,t:1527621043148};\\\", \\\"{x:414,y:494,t:1527621043165};\\\", \\\"{x:417,y:495,t:1527621043182};\\\", \\\"{x:418,y:496,t:1527621043198};\\\", \\\"{x:421,y:497,t:1527621043216};\\\", \\\"{x:425,y:500,t:1527621043232};\\\", \\\"{x:429,y:503,t:1527621043249};\\\", \\\"{x:434,y:510,t:1527621043266};\\\", \\\"{x:438,y:516,t:1527621043282};\\\", \\\"{x:445,y:526,t:1527621043299};\\\", \\\"{x:447,y:532,t:1527621043316};\\\", \\\"{x:450,y:537,t:1527621043332};\\\", \\\"{x:452,y:542,t:1527621043349};\\\", \\\"{x:457,y:550,t:1527621043365};\\\", \\\"{x:463,y:557,t:1527621043383};\\\", \\\"{x:468,y:561,t:1527621043399};\\\", \\\"{x:474,y:568,t:1527621043416};\\\", \\\"{x:480,y:573,t:1527621043432};\\\", \\\"{x:493,y:580,t:1527621043449};\\\", \\\"{x:505,y:589,t:1527621043466};\\\", \\\"{x:511,y:596,t:1527621043483};\\\", \\\"{x:534,y:611,t:1527621043499};\\\", \\\"{x:546,y:619,t:1527621043515};\\\", \\\"{x:556,y:630,t:1527621043532};\\\", \\\"{x:565,y:638,t:1527621043550};\\\", \\\"{x:570,y:645,t:1527621043565};\\\", \\\"{x:574,y:650,t:1527621043581};\\\", \\\"{x:575,y:652,t:1527621043599};\\\", \\\"{x:578,y:655,t:1527621043616};\\\", \\\"{x:580,y:658,t:1527621043633};\\\", \\\"{x:585,y:664,t:1527621043649};\\\", \\\"{x:587,y:667,t:1527621043666};\\\", \\\"{x:596,y:675,t:1527621043683};\\\", \\\"{x:607,y:685,t:1527621043700};\\\", \\\"{x:619,y:694,t:1527621043716};\\\", \\\"{x:632,y:705,t:1527621043733};\\\", \\\"{x:644,y:714,t:1527621043750};\\\", \\\"{x:652,y:719,t:1527621043767};\\\", \\\"{x:658,y:724,t:1527621043783};\\\", \\\"{x:663,y:729,t:1527621043801};\\\", \\\"{x:668,y:734,t:1527621043817};\\\", \\\"{x:671,y:738,t:1527621043834};\\\", \\\"{x:674,y:744,t:1527621043850};\\\", \\\"{x:679,y:750,t:1527621043866};\\\", \\\"{x:682,y:754,t:1527621043884};\\\", \\\"{x:685,y:758,t:1527621043901};\\\", \\\"{x:689,y:764,t:1527621043918};\\\", \\\"{x:691,y:767,t:1527621043935};\\\", \\\"{x:693,y:770,t:1527621043951};\\\", \\\"{x:693,y:772,t:1527621043971};\\\", \\\"{x:693,y:773,t:1527621044011};\\\", \\\"{x:693,y:775,t:1527621044026};\\\", \\\"{x:693,y:776,t:1527621044042};\\\", \\\"{x:694,y:778,t:1527621044050};\\\", \\\"{x:695,y:780,t:1527621044068};\\\", \\\"{x:696,y:782,t:1527621044085};\\\", \\\"{x:697,y:783,t:1527621044101};\\\", \\\"{x:697,y:786,t:1527621044118};\\\", \\\"{x:698,y:788,t:1527621044135};\\\", \\\"{x:698,y:789,t:1527621044155};\\\", \\\"{x:698,y:790,t:1527621044170};\\\", \\\"{x:698,y:791,t:1527621044185};\\\", \\\"{x:698,y:792,t:1527621044202};\\\", \\\"{x:698,y:793,t:1527621044218};\\\", \\\"{x:698,y:794,t:1527621044235};\\\", \\\"{x:698,y:795,t:1527621044252};\\\", \\\"{x:698,y:796,t:1527621044292};\\\", \\\"{x:697,y:796,t:1527621044339};\\\", \\\"{x:696,y:796,t:1527621044371};\\\", \\\"{x:695,y:796,t:1527621044387};\\\", \\\"{x:694,y:796,t:1527621044404};\\\", \\\"{x:693,y:796,t:1527621044420};\\\", \\\"{x:692,y:796,t:1527621044459};\\\", \\\"{x:691,y:796,t:1527621044470};\\\", \\\"{x:690,y:796,t:1527621044532};\\\", \\\"{x:689,y:796,t:1527621044587};\\\", \\\"{x:688,y:796,t:1527621044635};\\\", \\\"{x:687,y:797,t:1527621044651};\\\", \\\"{x:686,y:797,t:1527621044860};\\\", \\\"{x:685,y:798,t:1527621044872};\\\", \\\"{x:684,y:799,t:1527621044899};\\\", \\\"{x:683,y:800,t:1527621044915};\\\", \\\"{x:682,y:801,t:1527621044931};\\\", \\\"{x:681,y:801,t:1527621044955};\\\", \\\"{x:680,y:802,t:1527621045388};\\\", \\\"{x:680,y:803,t:1527621045428};\\\", \\\"{x:679,y:804,t:1527621045620};\\\", \\\"{x:679,y:803,t:1527621046994};\\\", \\\"{x:679,y:802,t:1527621047018};\\\", \\\"{x:679,y:801,t:1527621047059};\\\", \\\"{x:679,y:799,t:1527621047251};\\\", \\\"{x:679,y:798,t:1527621047539};\\\", \\\"{x:678,y:798,t:1527621047796};\\\", \\\"{x:678,y:797,t:1527621047820};\\\", \\\"{x:678,y:796,t:1527621047843};\\\", \\\"{x:678,y:795,t:1527621047892};\\\", \\\"{x:678,y:794,t:1527621048012};\\\", \\\"{x:678,y:792,t:1527621048452};\\\", \\\"{x:678,y:791,t:1527621048804};\\\", \\\"{x:678,y:789,t:1527621048819};\\\", \\\"{x:677,y:787,t:1527621048827};\\\", \\\"{x:676,y:786,t:1527621048838};\\\", \\\"{x:674,y:782,t:1527621048856};\\\", \\\"{x:669,y:778,t:1527621048873};\\\", \\\"{x:663,y:772,t:1527621048889};\\\", \\\"{x:656,y:763,t:1527621048905};\\\", \\\"{x:639,y:751,t:1527621048923};\\\", \\\"{x:626,y:741,t:1527621048939};\\\", \\\"{x:614,y:732,t:1527621048956};\\\", \\\"{x:602,y:722,t:1527621048973};\\\", \\\"{x:581,y:702,t:1527621048990};\\\", \\\"{x:563,y:682,t:1527621049007};\\\", \\\"{x:549,y:665,t:1527621049023};\\\", \\\"{x:535,y:647,t:1527621049040};\\\", \\\"{x:519,y:627,t:1527621049058};\\\", \\\"{x:505,y:611,t:1527621049073};\\\", \\\"{x:495,y:599,t:1527621049090};\\\", \\\"{x:487,y:590,t:1527621049100};\\\", \\\"{x:482,y:584,t:1527621049117};\\\", \\\"{x:477,y:579,t:1527621049134};\\\", \\\"{x:475,y:577,t:1527621049150};\\\", \\\"{x:475,y:576,t:1527621049171};\\\", \\\"{x:475,y:575,t:1527621049275};\\\", \\\"{x:477,y:575,t:1527621049285};\\\", \\\"{x:485,y:577,t:1527621049300};\\\", \\\"{x:494,y:581,t:1527621049318};\\\", \\\"{x:519,y:596,t:1527621049336};\\\", \\\"{x:554,y:624,t:1527621049351};\\\", \\\"{x:589,y:652,t:1527621049370};\\\", \\\"{x:613,y:668,t:1527621049387};\\\", \\\"{x:651,y:692,t:1527621049403};\\\", \\\"{x:680,y:711,t:1527621049420};\\\", \\\"{x:704,y:729,t:1527621049438};\\\", \\\"{x:724,y:744,t:1527621049454};\\\", \\\"{x:730,y:751,t:1527621049470};\\\", \\\"{x:736,y:757,t:1527621049487};\\\", \\\"{x:737,y:757,t:1527621049504};\\\", \\\"{x:738,y:759,t:1527621049520};\\\", \\\"{x:738,y:760,t:1527621049537};\\\", \\\"{x:738,y:761,t:1527621049651};\\\", \\\"{x:736,y:762,t:1527621049700};\\\", \\\"{x:735,y:762,t:1527621049723};\\\", \\\"{x:733,y:763,t:1527621049747};\\\", \\\"{x:732,y:763,t:1527621049796};\\\", \\\"{x:731,y:763,t:1527621049828};\\\", \\\"{x:730,y:763,t:1527621049875};\\\", \\\"{x:729,y:763,t:1527621049888};\\\", \\\"{x:728,y:763,t:1527621049905};\\\", \\\"{x:727,y:763,t:1527621049939};\\\", \\\"{x:726,y:764,t:1527621049955};\\\", \\\"{x:725,y:764,t:1527621049979};\\\", \\\"{x:724,y:764,t:1527621050019};\\\", \\\"{x:723,y:764,t:1527621050043};\\\", \\\"{x:722,y:764,t:1527621050067};\\\", \\\"{x:721,y:764,t:1527621050148};\\\", \\\"{x:720,y:764,t:1527621050443};\\\", \\\"{x:720,y:765,t:1527621050556};\\\", \\\"{x:720,y:766,t:1527621050572};\\\", \\\"{x:720,y:767,t:1527621050603};\\\", \\\"{x:719,y:767,t:1527621050611};\\\", \\\"{x:719,y:768,t:1527621050691};\\\", \\\"{x:719,y:769,t:1527621052042};\\\", \\\"{x:720,y:770,t:1527621052058};\\\", \\\"{x:723,y:770,t:1527621052073};\\\", \\\"{x:729,y:773,t:1527621052089};\\\", \\\"{x:734,y:774,t:1527621052105};\\\", \\\"{x:738,y:775,t:1527621052122};\\\", \\\"{x:742,y:776,t:1527621052139};\\\", \\\"{x:747,y:779,t:1527621052156};\\\", \\\"{x:754,y:782,t:1527621052173};\\\", \\\"{x:760,y:785,t:1527621052190};\\\", \\\"{x:762,y:786,t:1527621052206};\\\", \\\"{x:766,y:787,t:1527621052222};\\\", \\\"{x:771,y:789,t:1527621052240};\\\", \\\"{x:774,y:790,t:1527621052255};\\\", \\\"{x:776,y:791,t:1527621052273};\\\", \\\"{x:779,y:792,t:1527621052290};\\\", \\\"{x:785,y:793,t:1527621052307};\\\", \\\"{x:787,y:794,t:1527621052324};\\\", \\\"{x:789,y:794,t:1527621052340};\\\", \\\"{x:791,y:796,t:1527621052357};\\\", \\\"{x:793,y:796,t:1527621052372};\\\", \\\"{x:796,y:797,t:1527621052389};\\\", \\\"{x:797,y:797,t:1527621052407};\\\", \\\"{x:798,y:798,t:1527621052427};\\\", \\\"{x:799,y:799,t:1527621052451};\\\", \\\"{x:800,y:799,t:1527621052467};\\\", \\\"{x:801,y:799,t:1527621052475};\\\", \\\"{x:802,y:800,t:1527621052499};\\\", \\\"{x:803,y:800,t:1527621052507};\\\", \\\"{x:804,y:801,t:1527621052522};\\\", \\\"{x:805,y:802,t:1527621052539};\\\", \\\"{x:806,y:802,t:1527621052556};\\\", \\\"{x:807,y:802,t:1527621052572};\\\", \\\"{x:808,y:803,t:1527621052594};\\\", \\\"{x:809,y:804,t:1527621052650};\\\", \\\"{x:810,y:805,t:1527621052723};\\\", \\\"{x:811,y:805,t:1527621052754};\\\", \\\"{x:812,y:806,t:1527621052786};\\\", \\\"{x:813,y:806,t:1527621052819};\\\", \\\"{x:813,y:807,t:1527621052850};\\\", \\\"{x:813,y:808,t:1527621052964};\\\", \\\"{x:814,y:808,t:1527621053003};\\\", \\\"{x:814,y:809,t:1527621053027};\\\", \\\"{x:814,y:810,t:1527621053043};\\\", \\\"{x:814,y:811,t:1527621053056};\\\", \\\"{x:815,y:811,t:1527621053083};\\\", \\\"{x:815,y:812,t:1527621053138};\\\", \\\"{x:815,y:813,t:1527621053226};\\\", \\\"{x:815,y:814,t:1527621053242};\\\", \\\"{x:816,y:814,t:1527621053611};\\\", \\\"{x:817,y:814,t:1527621053635};\\\", \\\"{x:818,y:814,t:1527621053667};\\\", \\\"{x:819,y:814,t:1527621053772};\\\", \\\"{x:820,y:814,t:1527621053851};\\\", \\\"{x:821,y:814,t:1527621053867};\\\", \\\"{x:822,y:814,t:1527621054012};\\\", \\\"{x:823,y:814,t:1527621054108};\\\", \\\"{x:824,y:814,t:1527621054203};\\\", \\\"{x:825,y:814,t:1527621054548};\\\", \\\"{x:826,y:814,t:1527621054580};\\\", \\\"{x:827,y:814,t:1527621054619};\\\", \\\"{x:828,y:814,t:1527621054691};\\\", \\\"{x:829,y:814,t:1527621054715};\\\", \\\"{x:830,y:814,t:1527621054748};\\\", \\\"{x:831,y:814,t:1527621054899};\\\", \\\"{x:832,y:814,t:1527621055020};\\\", \\\"{x:833,y:814,t:1527621055091};\\\", \\\"{x:835,y:813,t:1527621055195};\\\", \\\"{x:836,y:812,t:1527621055275};\\\", \\\"{x:837,y:811,t:1527621055348};\\\", \\\"{x:838,y:811,t:1527621055379};\\\", \\\"{x:840,y:810,t:1527621055395};\\\", \\\"{x:841,y:810,t:1527621055444};\\\", \\\"{x:843,y:809,t:1527621055459};\\\", \\\"{x:845,y:809,t:1527621055507};\\\", \\\"{x:846,y:809,t:1527621055571};\\\", \\\"{x:846,y:808,t:1527621055579};\\\", \\\"{x:848,y:808,t:1527621055595};\\\", \\\"{x:849,y:808,t:1527621055611};\\\", \\\"{x:851,y:808,t:1527621055626};\\\", \\\"{x:851,y:807,t:1527621055642};\\\", \\\"{x:853,y:807,t:1527621055659};\\\", \\\"{x:854,y:807,t:1527621055675};\\\", \\\"{x:855,y:807,t:1527621055746};\\\", \\\"{x:856,y:807,t:1527621055762};\\\", \\\"{x:857,y:807,t:1527621055776};\\\", \\\"{x:858,y:807,t:1527621055792};\\\", \\\"{x:859,y:807,t:1527621055808};\\\", \\\"{x:860,y:807,t:1527621055826};\\\", \\\"{x:862,y:807,t:1527621055850};\\\", \\\"{x:863,y:807,t:1527621055940};\\\", \\\"{x:864,y:807,t:1527621055971};\\\", \\\"{x:865,y:806,t:1527621056083};\\\", \\\"{x:866,y:806,t:1527621056179};\\\", \\\"{x:867,y:805,t:1527621056195};\\\", \\\"{x:868,y:804,t:1527621056235};\\\", \\\"{x:870,y:804,t:1527621056292};\\\", \\\"{x:871,y:803,t:1527621056379};\\\", \\\"{x:872,y:802,t:1527621056876};\\\", \\\"{x:872,y:801,t:1527621072436};\\\", \\\"{x:872,y:799,t:1527621072451};\\\", \\\"{x:871,y:799,t:1527621072459};\\\", \\\"{x:869,y:798,t:1527621072472};\\\", \\\"{x:867,y:797,t:1527621072489};\\\", \\\"{x:856,y:788,t:1527621072506};\\\", \\\"{x:813,y:734,t:1527621072523};\\\", \\\"{x:788,y:711,t:1527621072539};\\\", \\\"{x:771,y:698,t:1527621072556};\\\", \\\"{x:760,y:687,t:1527621072573};\\\", \\\"{x:743,y:672,t:1527621072589};\\\", \\\"{x:729,y:663,t:1527621072606};\\\", \\\"{x:723,y:658,t:1527621072623};\\\", \\\"{x:720,y:655,t:1527621072638};\\\", \\\"{x:718,y:653,t:1527621072656};\\\", \\\"{x:712,y:650,t:1527621072673};\\\", \\\"{x:687,y:642,t:1527621072689};\\\", \\\"{x:659,y:641,t:1527621072706};\\\", \\\"{x:630,y:641,t:1527621072723};\\\", \\\"{x:619,y:639,t:1527621072739};\\\", \\\"{x:562,y:620,t:1527621072757};\\\", \\\"{x:458,y:598,t:1527621072774};\\\", \\\"{x:377,y:596,t:1527621072789};\\\", \\\"{x:289,y:596,t:1527621072806};\\\", \\\"{x:241,y:596,t:1527621072824};\\\", \\\"{x:212,y:591,t:1527621072840};\\\", \\\"{x:205,y:589,t:1527621072857};\\\", \\\"{x:203,y:588,t:1527621072872};\\\", \\\"{x:201,y:587,t:1527621072890};\\\", \\\"{x:200,y:584,t:1527621072906};\\\", \\\"{x:200,y:581,t:1527621072923};\\\", \\\"{x:200,y:573,t:1527621072939};\\\", \\\"{x:214,y:561,t:1527621072957};\\\", \\\"{x:236,y:554,t:1527621072973};\\\", \\\"{x:257,y:548,t:1527621072990};\\\", \\\"{x:283,y:545,t:1527621073007};\\\", \\\"{x:296,y:543,t:1527621073022};\\\", \\\"{x:301,y:540,t:1527621073040};\\\", \\\"{x:301,y:538,t:1527621073056};\\\", \\\"{x:301,y:537,t:1527621073074};\\\", \\\"{x:301,y:536,t:1527621073090};\\\", \\\"{x:296,y:529,t:1527621073106};\\\", \\\"{x:277,y:519,t:1527621073124};\\\", \\\"{x:245,y:505,t:1527621073140};\\\", \\\"{x:219,y:500,t:1527621073157};\\\", \\\"{x:201,y:499,t:1527621073174};\\\", \\\"{x:185,y:499,t:1527621073190};\\\", \\\"{x:173,y:497,t:1527621073207};\\\", \\\"{x:168,y:495,t:1527621073223};\\\", \\\"{x:161,y:494,t:1527621073239};\\\", \\\"{x:157,y:492,t:1527621073257};\\\", \\\"{x:158,y:493,t:1527621073347};\\\", \\\"{x:163,y:496,t:1527621073357};\\\", \\\"{x:168,y:497,t:1527621073373};\\\", \\\"{x:168,y:498,t:1527621073390};\\\", \\\"{x:169,y:498,t:1527621073474};\\\", \\\"{x:169,y:498,t:1527621073478};\\\", \\\"{x:169,y:499,t:1527621073667};\\\", \\\"{x:170,y:501,t:1527621073675};\\\", \\\"{x:172,y:509,t:1527621073690};\\\", \\\"{x:175,y:521,t:1527621073707};\\\", \\\"{x:180,y:536,t:1527621073724};\\\", \\\"{x:186,y:556,t:1527621073740};\\\", \\\"{x:196,y:581,t:1527621073758};\\\", \\\"{x:216,y:620,t:1527621073774};\\\", \\\"{x:241,y:663,t:1527621073791};\\\", \\\"{x:281,y:715,t:1527621073807};\\\", \\\"{x:318,y:768,t:1527621073824};\\\", \\\"{x:365,y:825,t:1527621073840};\\\", \\\"{x:415,y:881,t:1527621073857};\\\", \\\"{x:471,y:942,t:1527621073873};\\\", \\\"{x:528,y:1013,t:1527621073890};\\\", \\\"{x:561,y:1050,t:1527621073907};\\\", \\\"{x:584,y:1076,t:1527621073924};\\\", \\\"{x:604,y:1101,t:1527621073941};\\\", \\\"{x:618,y:1126,t:1527621073957};\\\", \\\"{x:638,y:1155,t:1527621073973};\\\", \\\"{x:654,y:1173,t:1527621073991};\\\", \\\"{x:663,y:1180,t:1527621074008};\\\", \\\"{x:664,y:1182,t:1527621074023};\\\", \\\"{x:665,y:1182,t:1527621074041};\\\", \\\"{x:665,y:1174,t:1527621074628};\\\", \\\"{x:665,y:1161,t:1527621074642};\\\", \\\"{x:661,y:1092,t:1527621074659};\\\", \\\"{x:658,y:1046,t:1527621074676};\\\", \\\"{x:658,y:1014,t:1527621074693};\\\", \\\"{x:658,y:983,t:1527621074709};\\\", \\\"{x:658,y:958,t:1527621074726};\\\", \\\"{x:658,y:939,t:1527621074744};\\\", \\\"{x:658,y:924,t:1527621074760};\\\", \\\"{x:656,y:896,t:1527621074776};\\\", \\\"{x:647,y:866,t:1527621074793};\\\", \\\"{x:642,y:848,t:1527621074810};\\\", \\\"{x:639,y:833,t:1527621074827};\\\", \\\"{x:635,y:812,t:1527621074843};\\\", \\\"{x:634,y:805,t:1527621074859};\\\", \\\"{x:634,y:799,t:1527621074876};\\\", \\\"{x:632,y:793,t:1527621074892};\\\", \\\"{x:631,y:790,t:1527621074910};\\\", \\\"{x:630,y:787,t:1527621074926};\\\", \\\"{x:630,y:783,t:1527621074944};\\\", \\\"{x:629,y:782,t:1527621074960};\\\", \\\"{x:629,y:781,t:1527621074977};\\\", \\\"{x:629,y:780,t:1527621074992};\\\", \\\"{x:629,y:779,t:1527621079154};\\\", \\\"{x:629,y:778,t:1527621079418};\\\", \\\"{x:629,y:777,t:1527621079522};\\\", \\\"{x:629,y:776,t:1527621079554};\\\", \\\"{x:628,y:774,t:1527621079570};\\\", \\\"{x:626,y:771,t:1527621079586};\\\", \\\"{x:626,y:770,t:1527621079602};\\\", \\\"{x:626,y:769,t:1527621079619};\\\", \\\"{x:626,y:767,t:1527621079636};\\\", \\\"{x:625,y:766,t:1527621079653};\\\", \\\"{x:624,y:765,t:1527621079670};\\\", \\\"{x:624,y:764,t:1527621079690};\\\", \\\"{x:624,y:763,t:1527621079715};\\\", \\\"{x:624,y:762,t:1527621079722};\\\", \\\"{x:624,y:761,t:1527621079736};\\\", \\\"{x:624,y:760,t:1527621079753};\\\", \\\"{x:623,y:760,t:1527621079769};\\\", \\\"{x:623,y:759,t:1527621079787};\\\", \\\"{x:623,y:758,t:1527621079810};\\\", \\\"{x:623,y:757,t:1527621081555};\\\", \\\"{x:623,y:756,t:1527621081562};\\\", \\\"{x:622,y:755,t:1527621081573};\\\", \\\"{x:621,y:754,t:1527621081591};\\\", \\\"{x:619,y:752,t:1527621081607};\\\", \\\"{x:617,y:751,t:1527621081623};\\\", \\\"{x:614,y:748,t:1527621081640};\\\", \\\"{x:611,y:747,t:1527621081657};\\\", \\\"{x:610,y:747,t:1527621081675};\\\", \\\"{x:609,y:745,t:1527621081698};\\\", \\\"{x:608,y:745,t:1527621081714};\\\", \\\"{x:607,y:744,t:1527621081730};\\\", \\\"{x:606,y:743,t:1527621081746};\\\", \\\"{x:605,y:743,t:1527621081758};\\\", \\\"{x:604,y:742,t:1527621081775};\\\", \\\"{x:601,y:741,t:1527621081791};\\\", \\\"{x:598,y:739,t:1527621081808};\\\", \\\"{x:595,y:738,t:1527621081825};\\\", \\\"{x:592,y:737,t:1527621081842};\\\", \\\"{x:588,y:737,t:1527621081858};\\\", \\\"{x:585,y:736,t:1527621081875};\\\", \\\"{x:583,y:735,t:1527621081892};\\\", \\\"{x:581,y:734,t:1527621081908};\\\", \\\"{x:578,y:734,t:1527621081925};\\\", \\\"{x:575,y:734,t:1527621081941};\\\", \\\"{x:570,y:734,t:1527621081958};\\\", \\\"{x:567,y:732,t:1527621081975};\\\", \\\"{x:563,y:731,t:1527621081992};\\\", \\\"{x:560,y:731,t:1527621082009};\\\", \\\"{x:557,y:731,t:1527621082025};\\\", \\\"{x:555,y:730,t:1527621082047};\\\", \\\"{x:553,y:729,t:1527621082064};\\\", \\\"{x:550,y:728,t:1527621082080};\\\", \\\"{x:548,y:728,t:1527621082096};\\\", \\\"{x:546,y:728,t:1527621082114};\\\", \\\"{x:545,y:728,t:1527621082130};\\\", \\\"{x:544,y:728,t:1527621082178};\\\" ] }, { \\\"rt\\\": 98234, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 631543, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -12 PM-12 PM-F -B -B -B -B -12 PM-01 PM-02 PM-03 PM-04 PM-05 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:728,t:1527621084634};\\\", \\\"{x:539,y:738,t:1527621084649};\\\", \\\"{x:537,y:741,t:1527621084666};\\\", \\\"{x:537,y:742,t:1527621084738};\\\", \\\"{x:535,y:742,t:1527621084755};\\\", \\\"{x:534,y:742,t:1527621084767};\\\", \\\"{x:531,y:742,t:1527621084783};\\\", \\\"{x:530,y:742,t:1527621084800};\\\", \\\"{x:529,y:742,t:1527621084817};\\\", \\\"{x:501,y:723,t:1527621087676};\\\", \\\"{x:452,y:622,t:1527621087685};\\\", \\\"{x:410,y:468,t:1527621087695};\\\", \\\"{x:305,y:185,t:1527621087711};\\\", \\\"{x:191,y:0,t:1527621087735};\\\", \\\"{x:120,y:0,t:1527621087751};\\\", \\\"{x:52,y:0,t:1527621087767};\\\", \\\"{x:0,y:0,t:1527621087784};\\\", \\\"{x:0,y:3,t:1527621088020};\\\", \\\"{x:0,y:17,t:1527621088034};\\\", \\\"{x:14,y:41,t:1527621088051};\\\", \\\"{x:47,y:81,t:1527621088068};\\\", \\\"{x:96,y:132,t:1527621088084};\\\", \\\"{x:102,y:145,t:1527621088101};\\\", \\\"{x:104,y:153,t:1527621088118};\\\", \\\"{x:104,y:154,t:1527621088291};\\\", \\\"{x:102,y:156,t:1527621088301};\\\", \\\"{x:85,y:174,t:1527621088318};\\\", \\\"{x:64,y:196,t:1527621088334};\\\", \\\"{x:43,y:220,t:1527621088351};\\\", \\\"{x:5,y:281,t:1527621088369};\\\", \\\"{x:0,y:351,t:1527621088384};\\\", \\\"{x:0,y:368,t:1527621088401};\\\", \\\"{x:7,y:376,t:1527621088418};\\\", \\\"{x:16,y:388,t:1527621088435};\\\", \\\"{x:27,y:395,t:1527621088451};\\\", \\\"{x:36,y:403,t:1527621088468};\\\", \\\"{x:45,y:407,t:1527621088484};\\\", \\\"{x:45,y:408,t:1527621089114};\\\", \\\"{x:45,y:409,t:1527621089122};\\\", \\\"{x:48,y:415,t:1527621089136};\\\", \\\"{x:56,y:420,t:1527621089152};\\\", \\\"{x:91,y:439,t:1527621089168};\\\", \\\"{x:135,y:464,t:1527621089185};\\\", \\\"{x:161,y:473,t:1527621089202};\\\", \\\"{x:175,y:478,t:1527621089218};\\\", \\\"{x:191,y:484,t:1527621089235};\\\", \\\"{x:210,y:492,t:1527621089253};\\\", \\\"{x:254,y:505,t:1527621089268};\\\", \\\"{x:309,y:529,t:1527621089286};\\\", \\\"{x:349,y:543,t:1527621089303};\\\", \\\"{x:387,y:557,t:1527621089319};\\\", \\\"{x:440,y:580,t:1527621089337};\\\", \\\"{x:486,y:597,t:1527621089354};\\\", \\\"{x:544,y:614,t:1527621089370};\\\", \\\"{x:619,y:632,t:1527621089387};\\\", \\\"{x:647,y:637,t:1527621089403};\\\", \\\"{x:659,y:638,t:1527621089419};\\\", \\\"{x:661,y:638,t:1527621089436};\\\", \\\"{x:661,y:637,t:1527621089458};\\\", \\\"{x:661,y:633,t:1527621089469};\\\", \\\"{x:655,y:622,t:1527621089486};\\\", \\\"{x:646,y:609,t:1527621089504};\\\", \\\"{x:635,y:596,t:1527621089520};\\\", \\\"{x:622,y:578,t:1527621089536};\\\", \\\"{x:609,y:560,t:1527621089554};\\\", \\\"{x:595,y:541,t:1527621089570};\\\", \\\"{x:578,y:513,t:1527621089587};\\\", \\\"{x:569,y:499,t:1527621089603};\\\", \\\"{x:561,y:486,t:1527621089619};\\\", \\\"{x:553,y:475,t:1527621089636};\\\", \\\"{x:549,y:467,t:1527621089654};\\\", \\\"{x:549,y:463,t:1527621089670};\\\", \\\"{x:547,y:455,t:1527621089686};\\\", \\\"{x:546,y:450,t:1527621089703};\\\", \\\"{x:545,y:449,t:1527621089721};\\\", \\\"{x:545,y:448,t:1527621089736};\\\", \\\"{x:544,y:448,t:1527621090075};\\\", \\\"{x:543,y:448,t:1527621090171};\\\", \\\"{x:542,y:448,t:1527621090202};\\\", \\\"{x:542,y:449,t:1527621090211};\\\", \\\"{x:541,y:449,t:1527621090222};\\\", \\\"{x:539,y:450,t:1527621090238};\\\", \\\"{x:537,y:451,t:1527621090255};\\\", \\\"{x:536,y:453,t:1527621090271};\\\", \\\"{x:534,y:454,t:1527621090288};\\\", \\\"{x:533,y:456,t:1527621090304};\\\", \\\"{x:531,y:458,t:1527621090321};\\\", \\\"{x:530,y:461,t:1527621090339};\\\", \\\"{x:529,y:463,t:1527621090354};\\\", \\\"{x:528,y:465,t:1527621090371};\\\", \\\"{x:526,y:468,t:1527621090389};\\\", \\\"{x:525,y:470,t:1527621090404};\\\", \\\"{x:521,y:474,t:1527621090421};\\\", \\\"{x:518,y:478,t:1527621090439};\\\", \\\"{x:518,y:481,t:1527621090454};\\\", \\\"{x:518,y:482,t:1527621090472};\\\", \\\"{x:517,y:484,t:1527621090488};\\\", \\\"{x:516,y:486,t:1527621090506};\\\", \\\"{x:515,y:488,t:1527621090522};\\\", \\\"{x:514,y:489,t:1527621090586};\\\", \\\"{x:513,y:489,t:1527621090927};\\\", \\\"{x:512,y:489,t:1527621090939};\\\", \\\"{x:509,y:489,t:1527621090956};\\\", \\\"{x:508,y:489,t:1527621090973};\\\", \\\"{x:506,y:489,t:1527621090989};\\\", \\\"{x:505,y:489,t:1527621091006};\\\", \\\"{x:503,y:489,t:1527621091023};\\\", \\\"{x:502,y:489,t:1527621091039};\\\", \\\"{x:501,y:489,t:1527621091056};\\\", \\\"{x:500,y:489,t:1527621091078};\\\", \\\"{x:499,y:489,t:1527621091142};\\\", \\\"{x:498,y:489,t:1527621091206};\\\", \\\"{x:497,y:489,t:1527621091301};\\\", \\\"{x:496,y:489,t:1527621091406};\\\", \\\"{x:496,y:488,t:1527621091430};\\\", \\\"{x:494,y:487,t:1527621091442};\\\", \\\"{x:493,y:486,t:1527621091459};\\\", \\\"{x:490,y:484,t:1527621091475};\\\", \\\"{x:488,y:483,t:1527621091490};\\\", \\\"{x:487,y:482,t:1527621091508};\\\", \\\"{x:484,y:481,t:1527621091524};\\\", \\\"{x:483,y:481,t:1527621091541};\\\", \\\"{x:482,y:481,t:1527621091557};\\\", \\\"{x:481,y:480,t:1527621091574};\\\", \\\"{x:479,y:479,t:1527621091591};\\\", \\\"{x:478,y:478,t:1527621091613};\\\", \\\"{x:477,y:478,t:1527621091637};\\\", \\\"{x:476,y:478,t:1527621091670};\\\", \\\"{x:475,y:477,t:1527621091685};\\\", \\\"{x:473,y:476,t:1527621091701};\\\", \\\"{x:472,y:476,t:1527621091717};\\\", \\\"{x:472,y:475,t:1527621091725};\\\", \\\"{x:471,y:475,t:1527621091742};\\\", \\\"{x:469,y:475,t:1527621091798};\\\", \\\"{x:468,y:474,t:1527621091895};\\\", \\\"{x:468,y:473,t:1527621092606};\\\", \\\"{x:469,y:471,t:1527621092614};\\\", \\\"{x:472,y:470,t:1527621092626};\\\", \\\"{x:477,y:469,t:1527621092642};\\\", \\\"{x:483,y:468,t:1527621092659};\\\", \\\"{x:485,y:468,t:1527621092676};\\\", \\\"{x:487,y:468,t:1527621092692};\\\", \\\"{x:489,y:468,t:1527621092709};\\\", \\\"{x:490,y:468,t:1527621092726};\\\", \\\"{x:491,y:468,t:1527621092750};\\\", \\\"{x:492,y:468,t:1527621092775};\\\", \\\"{x:493,y:468,t:1527621093774};\\\", \\\"{x:494,y:468,t:1527621093805};\\\", \\\"{x:495,y:468,t:1527621093909};\\\", \\\"{x:498,y:468,t:1527621093933};\\\", \\\"{x:500,y:468,t:1527621093943};\\\", \\\"{x:502,y:468,t:1527621093960};\\\", \\\"{x:504,y:468,t:1527621093975};\\\", \\\"{x:507,y:468,t:1527621093993};\\\", \\\"{x:508,y:468,t:1527621094022};\\\", \\\"{x:509,y:468,t:1527621094045};\\\", \\\"{x:510,y:468,t:1527621094077};\\\", \\\"{x:511,y:468,t:1527621094118};\\\", \\\"{x:512,y:468,t:1527621094134};\\\", \\\"{x:513,y:468,t:1527621094143};\\\", \\\"{x:514,y:468,t:1527621094173};\\\", \\\"{x:515,y:468,t:1527621094182};\\\", \\\"{x:516,y:468,t:1527621094193};\\\", \\\"{x:517,y:468,t:1527621094210};\\\", \\\"{x:519,y:468,t:1527621094225};\\\", \\\"{x:521,y:468,t:1527621094242};\\\", \\\"{x:522,y:468,t:1527621094260};\\\", \\\"{x:524,y:468,t:1527621094276};\\\", \\\"{x:525,y:468,t:1527621094292};\\\", \\\"{x:527,y:468,t:1527621094309};\\\", \\\"{x:528,y:468,t:1527621094341};\\\", \\\"{x:530,y:468,t:1527621094357};\\\", \\\"{x:532,y:469,t:1527621094365};\\\", \\\"{x:533,y:469,t:1527621094389};\\\", \\\"{x:534,y:469,t:1527621094398};\\\", \\\"{x:535,y:469,t:1527621094413};\\\", \\\"{x:537,y:469,t:1527621094426};\\\", \\\"{x:538,y:469,t:1527621094445};\\\", \\\"{x:539,y:469,t:1527621094460};\\\", \\\"{x:540,y:469,t:1527621094477};\\\", \\\"{x:541,y:469,t:1527621094493};\\\", \\\"{x:544,y:470,t:1527621094510};\\\", \\\"{x:546,y:470,t:1527621094527};\\\", \\\"{x:547,y:470,t:1527621094543};\\\", \\\"{x:549,y:470,t:1527621094560};\\\", \\\"{x:550,y:470,t:1527621094577};\\\", \\\"{x:552,y:470,t:1527621094606};\\\", \\\"{x:553,y:470,t:1527621094629};\\\", \\\"{x:555,y:470,t:1527621094654};\\\", \\\"{x:556,y:470,t:1527621094686};\\\", \\\"{x:558,y:470,t:1527621094702};\\\", \\\"{x:559,y:470,t:1527621094718};\\\", \\\"{x:562,y:470,t:1527621094727};\\\", \\\"{x:564,y:470,t:1527621094743};\\\", \\\"{x:565,y:470,t:1527621094760};\\\", \\\"{x:566,y:470,t:1527621094778};\\\", \\\"{x:567,y:470,t:1527621094794};\\\", \\\"{x:568,y:470,t:1527621094810};\\\", \\\"{x:570,y:470,t:1527621094827};\\\", \\\"{x:572,y:470,t:1527621094844};\\\", \\\"{x:575,y:470,t:1527621094860};\\\", \\\"{x:578,y:470,t:1527621094877};\\\", \\\"{x:582,y:470,t:1527621094894};\\\", \\\"{x:584,y:470,t:1527621094910};\\\", \\\"{x:586,y:470,t:1527621094927};\\\", \\\"{x:587,y:470,t:1527621094944};\\\", \\\"{x:588,y:470,t:1527621094960};\\\", \\\"{x:590,y:470,t:1527621094977};\\\", \\\"{x:591,y:470,t:1527621094994};\\\", \\\"{x:593,y:470,t:1527621095011};\\\", \\\"{x:594,y:470,t:1527621095028};\\\", \\\"{x:595,y:470,t:1527621095044};\\\", \\\"{x:597,y:470,t:1527621095086};\\\", \\\"{x:598,y:470,t:1527621095118};\\\", \\\"{x:599,y:470,t:1527621095128};\\\", \\\"{x:600,y:470,t:1527621095144};\\\", \\\"{x:602,y:470,t:1527621095161};\\\", \\\"{x:603,y:470,t:1527621095178};\\\", \\\"{x:605,y:470,t:1527621095194};\\\", \\\"{x:606,y:470,t:1527621095210};\\\", \\\"{x:607,y:469,t:1527621095228};\\\", \\\"{x:608,y:469,t:1527621095244};\\\", \\\"{x:609,y:469,t:1527621095261};\\\", \\\"{x:612,y:469,t:1527621095278};\\\", \\\"{x:616,y:468,t:1527621095293};\\\", \\\"{x:618,y:468,t:1527621095317};\\\", \\\"{x:619,y:468,t:1527621095334};\\\", \\\"{x:620,y:468,t:1527621095344};\\\", \\\"{x:621,y:468,t:1527621095361};\\\", \\\"{x:623,y:468,t:1527621095377};\\\", \\\"{x:625,y:467,t:1527621095394};\\\", \\\"{x:628,y:467,t:1527621095411};\\\", \\\"{x:630,y:467,t:1527621095430};\\\", \\\"{x:632,y:466,t:1527621095445};\\\", \\\"{x:632,y:465,t:1527621095461};\\\", \\\"{x:638,y:464,t:1527621095478};\\\", \\\"{x:639,y:464,t:1527621095494};\\\", \\\"{x:641,y:464,t:1527621095511};\\\", \\\"{x:643,y:463,t:1527621095534};\\\", \\\"{x:645,y:462,t:1527621095544};\\\", \\\"{x:646,y:462,t:1527621095561};\\\", \\\"{x:649,y:462,t:1527621095577};\\\", \\\"{x:651,y:462,t:1527621095595};\\\", \\\"{x:652,y:462,t:1527621095611};\\\", \\\"{x:655,y:461,t:1527621095627};\\\", \\\"{x:656,y:461,t:1527621095678};\\\", \\\"{x:658,y:463,t:1527621095694};\\\", \\\"{x:658,y:467,t:1527621095711};\\\", \\\"{x:658,y:470,t:1527621095727};\\\", \\\"{x:658,y:477,t:1527621095744};\\\", \\\"{x:658,y:488,t:1527621095763};\\\", \\\"{x:656,y:499,t:1527621095778};\\\", \\\"{x:654,y:512,t:1527621095794};\\\", \\\"{x:653,y:531,t:1527621095812};\\\", \\\"{x:653,y:548,t:1527621095828};\\\", \\\"{x:653,y:572,t:1527621095845};\\\", \\\"{x:653,y:584,t:1527621095861};\\\", \\\"{x:653,y:591,t:1527621095877};\\\", \\\"{x:653,y:597,t:1527621095896};\\\", \\\"{x:653,y:602,t:1527621095912};\\\", \\\"{x:654,y:610,t:1527621095928};\\\", \\\"{x:655,y:615,t:1527621095945};\\\", \\\"{x:655,y:621,t:1527621095961};\\\", \\\"{x:655,y:627,t:1527621095978};\\\", \\\"{x:655,y:633,t:1527621095995};\\\", \\\"{x:657,y:640,t:1527621096012};\\\", \\\"{x:661,y:648,t:1527621096028};\\\", \\\"{x:663,y:655,t:1527621096045};\\\", \\\"{x:664,y:665,t:1527621096061};\\\", \\\"{x:664,y:675,t:1527621096077};\\\", \\\"{x:664,y:685,t:1527621096094};\\\", \\\"{x:664,y:692,t:1527621096112};\\\", \\\"{x:664,y:699,t:1527621096127};\\\", \\\"{x:664,y:704,t:1527621096145};\\\", \\\"{x:663,y:709,t:1527621096162};\\\", \\\"{x:662,y:715,t:1527621096177};\\\", \\\"{x:661,y:722,t:1527621096195};\\\", \\\"{x:658,y:731,t:1527621096212};\\\", \\\"{x:658,y:737,t:1527621096227};\\\", \\\"{x:656,y:742,t:1527621096245};\\\", \\\"{x:655,y:745,t:1527621096261};\\\", \\\"{x:654,y:748,t:1527621096278};\\\", \\\"{x:653,y:751,t:1527621096294};\\\", \\\"{x:653,y:752,t:1527621096312};\\\", \\\"{x:652,y:754,t:1527621096328};\\\", \\\"{x:651,y:755,t:1527621096345};\\\", \\\"{x:651,y:756,t:1527621096362};\\\", \\\"{x:650,y:756,t:1527621096405};\\\", \\\"{x:649,y:756,t:1527621096494};\\\", \\\"{x:648,y:756,t:1527621096526};\\\", \\\"{x:645,y:756,t:1527621096557};\\\", \\\"{x:644,y:756,t:1527621096693};\\\", \\\"{x:643,y:755,t:1527621096838};\\\", \\\"{x:642,y:754,t:1527621096902};\\\", \\\"{x:642,y:753,t:1527621097590};\\\", \\\"{x:644,y:753,t:1527621097646};\\\", \\\"{x:645,y:753,t:1527621097663};\\\", \\\"{x:661,y:753,t:1527621097679};\\\", \\\"{x:686,y:748,t:1527621097696};\\\", \\\"{x:707,y:744,t:1527621097713};\\\", \\\"{x:751,y:742,t:1527621097729};\\\", \\\"{x:810,y:742,t:1527621097746};\\\", \\\"{x:902,y:742,t:1527621097763};\\\", \\\"{x:1004,y:742,t:1527621097780};\\\", \\\"{x:1118,y:742,t:1527621097797};\\\", \\\"{x:1234,y:742,t:1527621097813};\\\", \\\"{x:1425,y:742,t:1527621097830};\\\", \\\"{x:1541,y:742,t:1527621097846};\\\", \\\"{x:1636,y:742,t:1527621097863};\\\", \\\"{x:1722,y:742,t:1527621097880};\\\", \\\"{x:1802,y:742,t:1527621097896};\\\", \\\"{x:1838,y:739,t:1527621097913};\\\", \\\"{x:1862,y:734,t:1527621097931};\\\", \\\"{x:1875,y:731,t:1527621097946};\\\", \\\"{x:1884,y:726,t:1527621097963};\\\", \\\"{x:1886,y:724,t:1527621097980};\\\", \\\"{x:1886,y:721,t:1527621097996};\\\", \\\"{x:1886,y:717,t:1527621098013};\\\", \\\"{x:1880,y:711,t:1527621098030};\\\", \\\"{x:1871,y:709,t:1527621098046};\\\", \\\"{x:1854,y:709,t:1527621098063};\\\", \\\"{x:1828,y:709,t:1527621098080};\\\", \\\"{x:1792,y:709,t:1527621098097};\\\", \\\"{x:1747,y:709,t:1527621098113};\\\", \\\"{x:1705,y:709,t:1527621098130};\\\", \\\"{x:1671,y:709,t:1527621098146};\\\", \\\"{x:1650,y:709,t:1527621098163};\\\", \\\"{x:1642,y:709,t:1527621098180};\\\", \\\"{x:1640,y:709,t:1527621098197};\\\", \\\"{x:1639,y:709,t:1527621098254};\\\", \\\"{x:1638,y:709,t:1527621098270};\\\", \\\"{x:1637,y:709,t:1527621098286};\\\", \\\"{x:1636,y:709,t:1527621098535};\\\", \\\"{x:1628,y:709,t:1527621098548};\\\", \\\"{x:1604,y:709,t:1527621098564};\\\", \\\"{x:1545,y:709,t:1527621098581};\\\", \\\"{x:1464,y:709,t:1527621098598};\\\", \\\"{x:1359,y:709,t:1527621098614};\\\", \\\"{x:1193,y:709,t:1527621098631};\\\", \\\"{x:1077,y:709,t:1527621098648};\\\", \\\"{x:960,y:709,t:1527621098664};\\\", \\\"{x:869,y:709,t:1527621098681};\\\", \\\"{x:801,y:707,t:1527621098697};\\\", \\\"{x:739,y:699,t:1527621098714};\\\", \\\"{x:705,y:692,t:1527621098730};\\\", \\\"{x:684,y:689,t:1527621098747};\\\", \\\"{x:674,y:687,t:1527621098764};\\\", \\\"{x:668,y:686,t:1527621098780};\\\", \\\"{x:662,y:686,t:1527621098797};\\\", \\\"{x:660,y:685,t:1527621098814};\\\", \\\"{x:656,y:684,t:1527621098830};\\\", \\\"{x:651,y:684,t:1527621098847};\\\", \\\"{x:641,y:683,t:1527621098865};\\\", \\\"{x:626,y:680,t:1527621098880};\\\", \\\"{x:616,y:680,t:1527621098897};\\\", \\\"{x:613,y:680,t:1527621098914};\\\", \\\"{x:612,y:680,t:1527621098998};\\\", \\\"{x:611,y:680,t:1527621099014};\\\", \\\"{x:610,y:679,t:1527621099030};\\\", \\\"{x:610,y:678,t:1527621099103};\\\", \\\"{x:610,y:677,t:1527621099118};\\\", \\\"{x:610,y:676,t:1527621099134};\\\", \\\"{x:610,y:675,t:1527621099166};\\\", \\\"{x:610,y:674,t:1527621099183};\\\", \\\"{x:610,y:673,t:1527621099197};\\\", \\\"{x:610,y:672,t:1527621099222};\\\", \\\"{x:610,y:671,t:1527621099254};\\\", \\\"{x:610,y:670,t:1527621099423};\\\", \\\"{x:612,y:670,t:1527621100358};\\\", \\\"{x:623,y:670,t:1527621100366};\\\", \\\"{x:645,y:670,t:1527621100381};\\\", \\\"{x:689,y:670,t:1527621100399};\\\", \\\"{x:774,y:674,t:1527621100415};\\\", \\\"{x:886,y:692,t:1527621100432};\\\", \\\"{x:990,y:704,t:1527621100449};\\\", \\\"{x:1093,y:716,t:1527621100465};\\\", \\\"{x:1184,y:729,t:1527621100481};\\\", \\\"{x:1265,y:740,t:1527621100498};\\\", \\\"{x:1321,y:748,t:1527621100515};\\\", \\\"{x:1361,y:755,t:1527621100532};\\\", \\\"{x:1377,y:756,t:1527621100548};\\\", \\\"{x:1382,y:757,t:1527621100566};\\\", \\\"{x:1386,y:757,t:1527621100582};\\\", \\\"{x:1389,y:757,t:1527621100599};\\\", \\\"{x:1398,y:759,t:1527621100615};\\\", \\\"{x:1406,y:759,t:1527621100631};\\\", \\\"{x:1412,y:759,t:1527621100648};\\\", \\\"{x:1417,y:759,t:1527621100665};\\\", \\\"{x:1426,y:759,t:1527621100683};\\\", \\\"{x:1438,y:758,t:1527621100699};\\\", \\\"{x:1443,y:757,t:1527621100715};\\\", \\\"{x:1447,y:755,t:1527621100732};\\\", \\\"{x:1448,y:754,t:1527621100749};\\\", \\\"{x:1448,y:752,t:1527621100774};\\\", \\\"{x:1448,y:751,t:1527621100806};\\\", \\\"{x:1448,y:750,t:1527621100816};\\\", \\\"{x:1446,y:747,t:1527621100833};\\\", \\\"{x:1443,y:744,t:1527621100849};\\\", \\\"{x:1441,y:742,t:1527621100866};\\\", \\\"{x:1439,y:741,t:1527621100883};\\\", \\\"{x:1438,y:740,t:1527621100899};\\\", \\\"{x:1433,y:736,t:1527621100915};\\\", \\\"{x:1427,y:731,t:1527621100933};\\\", \\\"{x:1412,y:722,t:1527621100948};\\\", \\\"{x:1396,y:708,t:1527621100967};\\\", \\\"{x:1393,y:706,t:1527621100982};\\\", \\\"{x:1393,y:704,t:1527621100998};\\\", \\\"{x:1393,y:703,t:1527621101021};\\\", \\\"{x:1392,y:703,t:1527621101174};\\\", \\\"{x:1391,y:702,t:1527621101183};\\\", \\\"{x:1388,y:701,t:1527621101199};\\\", \\\"{x:1383,y:699,t:1527621101216};\\\", \\\"{x:1381,y:699,t:1527621101232};\\\", \\\"{x:1377,y:698,t:1527621101248};\\\", \\\"{x:1375,y:698,t:1527621101265};\\\", \\\"{x:1374,y:698,t:1527621101283};\\\", \\\"{x:1372,y:698,t:1527621101300};\\\", \\\"{x:1370,y:698,t:1527621101316};\\\", \\\"{x:1365,y:699,t:1527621101333};\\\", \\\"{x:1360,y:703,t:1527621101350};\\\", \\\"{x:1358,y:705,t:1527621101366};\\\", \\\"{x:1356,y:706,t:1527621101422};\\\", \\\"{x:1356,y:705,t:1527621101742};\\\", \\\"{x:1356,y:704,t:1527621101750};\\\", \\\"{x:1355,y:703,t:1527621101766};\\\", \\\"{x:1355,y:701,t:1527621101791};\\\", \\\"{x:1355,y:700,t:1527621101800};\\\", \\\"{x:1355,y:697,t:1527621101817};\\\", \\\"{x:1354,y:696,t:1527621101833};\\\", \\\"{x:1354,y:694,t:1527621101850};\\\", \\\"{x:1354,y:692,t:1527621101866};\\\", \\\"{x:1353,y:691,t:1527621101883};\\\", \\\"{x:1353,y:690,t:1527621101918};\\\", \\\"{x:1353,y:691,t:1527621102246};\\\", \\\"{x:1353,y:692,t:1527621102286};\\\", \\\"{x:1353,y:693,t:1527621102342};\\\", \\\"{x:1354,y:694,t:1527621102454};\\\", \\\"{x:1355,y:694,t:1527621102519};\\\", \\\"{x:1355,y:693,t:1527621102533};\\\", \\\"{x:1357,y:690,t:1527621102550};\\\", \\\"{x:1359,y:688,t:1527621102567};\\\", \\\"{x:1359,y:686,t:1527621102584};\\\", \\\"{x:1359,y:685,t:1527621102600};\\\", \\\"{x:1359,y:683,t:1527621102616};\\\", \\\"{x:1359,y:681,t:1527621102633};\\\", \\\"{x:1359,y:678,t:1527621102649};\\\", \\\"{x:1360,y:677,t:1527621102666};\\\", \\\"{x:1360,y:676,t:1527621102684};\\\", \\\"{x:1360,y:675,t:1527621102700};\\\", \\\"{x:1360,y:674,t:1527621102750};\\\", \\\"{x:1360,y:673,t:1527621103054};\\\", \\\"{x:1360,y:672,t:1527621103127};\\\", \\\"{x:1359,y:672,t:1527621103186};\\\", \\\"{x:1358,y:672,t:1527621103201};\\\", \\\"{x:1357,y:672,t:1527621103218};\\\", \\\"{x:1356,y:672,t:1527621103287};\\\", \\\"{x:1355,y:672,t:1527621103302};\\\", \\\"{x:1354,y:672,t:1527621103365};\\\", \\\"{x:1354,y:674,t:1527621103751};\\\", \\\"{x:1354,y:675,t:1527621103768};\\\", \\\"{x:1354,y:677,t:1527621103785};\\\", \\\"{x:1354,y:678,t:1527621103801};\\\", \\\"{x:1354,y:681,t:1527621103818};\\\", \\\"{x:1354,y:683,t:1527621103835};\\\", \\\"{x:1354,y:684,t:1527621103851};\\\", \\\"{x:1354,y:687,t:1527621103868};\\\", \\\"{x:1354,y:688,t:1527621103885};\\\", \\\"{x:1354,y:690,t:1527621103902};\\\", \\\"{x:1354,y:692,t:1527621103918};\\\", \\\"{x:1356,y:694,t:1527621103934};\\\", \\\"{x:1356,y:695,t:1527621103951};\\\", \\\"{x:1356,y:696,t:1527621103968};\\\", \\\"{x:1356,y:698,t:1527621103985};\\\", \\\"{x:1356,y:699,t:1527621104001};\\\", \\\"{x:1356,y:700,t:1527621104038};\\\", \\\"{x:1356,y:701,t:1527621104070};\\\", \\\"{x:1356,y:702,t:1527621104094};\\\", \\\"{x:1356,y:703,t:1527621104150};\\\", \\\"{x:1356,y:704,t:1527621104214};\\\", \\\"{x:1356,y:705,t:1527621104237};\\\", \\\"{x:1356,y:706,t:1527621104317};\\\", \\\"{x:1354,y:706,t:1527621105062};\\\", \\\"{x:1352,y:708,t:1527621105151};\\\", \\\"{x:1351,y:708,t:1527621108279};\\\", \\\"{x:1350,y:707,t:1527621108742};\\\", \\\"{x:1350,y:706,t:1527621108755};\\\", \\\"{x:1350,y:705,t:1527621108771};\\\", \\\"{x:1350,y:704,t:1527621108806};\\\", \\\"{x:1350,y:703,t:1527621108821};\\\", \\\"{x:1350,y:702,t:1527621108839};\\\", \\\"{x:1349,y:701,t:1527621109386};\\\", \\\"{x:1348,y:701,t:1527621109429};\\\", \\\"{x:1347,y:701,t:1527621109477};\\\", \\\"{x:1346,y:701,t:1527621109488};\\\", \\\"{x:1346,y:702,t:1527621109504};\\\", \\\"{x:1346,y:703,t:1527621109526};\\\", \\\"{x:1345,y:704,t:1527621109539};\\\", \\\"{x:1345,y:705,t:1527621109590};\\\", \\\"{x:1346,y:705,t:1527621109806};\\\", \\\"{x:1348,y:705,t:1527621109822};\\\", \\\"{x:1351,y:705,t:1527621109839};\\\", \\\"{x:1352,y:705,t:1527621109855};\\\", \\\"{x:1354,y:705,t:1527621109872};\\\", \\\"{x:1355,y:705,t:1527621109943};\\\", \\\"{x:1356,y:706,t:1527621109958};\\\", \\\"{x:1356,y:707,t:1527621109984};\\\", \\\"{x:1357,y:708,t:1527621109990};\\\", \\\"{x:1357,y:709,t:1527621110102};\\\", \\\"{x:1356,y:709,t:1527621110175};\\\", \\\"{x:1356,y:710,t:1527621110189};\\\", \\\"{x:1355,y:711,t:1527621110213};\\\", \\\"{x:1354,y:711,t:1527621110237};\\\", \\\"{x:1353,y:710,t:1527621110261};\\\", \\\"{x:1352,y:710,t:1527621110309};\\\", \\\"{x:1352,y:709,t:1527621110333};\\\", \\\"{x:1352,y:711,t:1527621110846};\\\", \\\"{x:1352,y:714,t:1527621110856};\\\", \\\"{x:1352,y:722,t:1527621110874};\\\", \\\"{x:1352,y:735,t:1527621110890};\\\", \\\"{x:1352,y:750,t:1527621110906};\\\", \\\"{x:1352,y:769,t:1527621110923};\\\", \\\"{x:1352,y:787,t:1527621110940};\\\", \\\"{x:1352,y:809,t:1527621110957};\\\", \\\"{x:1352,y:832,t:1527621110973};\\\", \\\"{x:1352,y:864,t:1527621110990};\\\", \\\"{x:1352,y:885,t:1527621111006};\\\", \\\"{x:1352,y:903,t:1527621111023};\\\", \\\"{x:1352,y:915,t:1527621111041};\\\", \\\"{x:1352,y:929,t:1527621111056};\\\", \\\"{x:1352,y:939,t:1527621111074};\\\", \\\"{x:1352,y:946,t:1527621111090};\\\", \\\"{x:1352,y:950,t:1527621111106};\\\", \\\"{x:1352,y:955,t:1527621111123};\\\", \\\"{x:1352,y:957,t:1527621111140};\\\", \\\"{x:1352,y:962,t:1527621111156};\\\", \\\"{x:1352,y:967,t:1527621111173};\\\", \\\"{x:1352,y:973,t:1527621111190};\\\", \\\"{x:1352,y:975,t:1527621111206};\\\", \\\"{x:1352,y:978,t:1527621111223};\\\", \\\"{x:1352,y:979,t:1527621111240};\\\", \\\"{x:1352,y:981,t:1527621111256};\\\", \\\"{x:1351,y:982,t:1527621111272};\\\", \\\"{x:1350,y:982,t:1527621111289};\\\", \\\"{x:1350,y:983,t:1527621111317};\\\", \\\"{x:1350,y:984,t:1527621111495};\\\", \\\"{x:1350,y:985,t:1527621111518};\\\", \\\"{x:1350,y:986,t:1527621111526};\\\", \\\"{x:1350,y:987,t:1527621111542};\\\", \\\"{x:1350,y:988,t:1527621111574};\\\", \\\"{x:1350,y:989,t:1527621111590};\\\", \\\"{x:1350,y:990,t:1527621111607};\\\", \\\"{x:1350,y:991,t:1527621111623};\\\", \\\"{x:1350,y:993,t:1527621111640};\\\", \\\"{x:1350,y:994,t:1527621111677};\\\", \\\"{x:1351,y:995,t:1527621111797};\\\", \\\"{x:1351,y:993,t:1527621111862};\\\", \\\"{x:1351,y:992,t:1527621111878};\\\", \\\"{x:1351,y:990,t:1527621111890};\\\", \\\"{x:1351,y:987,t:1527621111907};\\\", \\\"{x:1351,y:985,t:1527621111924};\\\", \\\"{x:1351,y:983,t:1527621111940};\\\", \\\"{x:1351,y:980,t:1527621111957};\\\", \\\"{x:1351,y:976,t:1527621111974};\\\", \\\"{x:1351,y:973,t:1527621111990};\\\", \\\"{x:1351,y:969,t:1527621112007};\\\", \\\"{x:1351,y:966,t:1527621112024};\\\", \\\"{x:1352,y:963,t:1527621112040};\\\", \\\"{x:1352,y:962,t:1527621112058};\\\", \\\"{x:1352,y:961,t:1527621112074};\\\", \\\"{x:1352,y:959,t:1527621112090};\\\", \\\"{x:1352,y:958,t:1527621112107};\\\", \\\"{x:1352,y:956,t:1527621112125};\\\", \\\"{x:1352,y:957,t:1527621112319};\\\", \\\"{x:1352,y:958,t:1527621112335};\\\", \\\"{x:1352,y:959,t:1527621112350};\\\", \\\"{x:1352,y:960,t:1527621112414};\\\", \\\"{x:1352,y:961,t:1527621112438};\\\", \\\"{x:1352,y:962,t:1527621112798};\\\", \\\"{x:1351,y:962,t:1527621112830};\\\", \\\"{x:1351,y:961,t:1527621113062};\\\", \\\"{x:1351,y:959,t:1527621113109};\\\", \\\"{x:1351,y:958,t:1527621113133};\\\", \\\"{x:1350,y:956,t:1527621113141};\\\", \\\"{x:1350,y:951,t:1527621113157};\\\", \\\"{x:1349,y:943,t:1527621113174};\\\", \\\"{x:1347,y:934,t:1527621113191};\\\", \\\"{x:1345,y:920,t:1527621113208};\\\", \\\"{x:1342,y:904,t:1527621113225};\\\", \\\"{x:1340,y:883,t:1527621113241};\\\", \\\"{x:1337,y:865,t:1527621113258};\\\", \\\"{x:1335,y:847,t:1527621113275};\\\", \\\"{x:1335,y:830,t:1527621113293};\\\", \\\"{x:1335,y:815,t:1527621113309};\\\", \\\"{x:1335,y:793,t:1527621113325};\\\", \\\"{x:1335,y:781,t:1527621113343};\\\", \\\"{x:1335,y:772,t:1527621113359};\\\", \\\"{x:1335,y:765,t:1527621113376};\\\", \\\"{x:1335,y:761,t:1527621113393};\\\", \\\"{x:1335,y:756,t:1527621113409};\\\", \\\"{x:1335,y:753,t:1527621113426};\\\", \\\"{x:1335,y:750,t:1527621113443};\\\", \\\"{x:1335,y:748,t:1527621113459};\\\", \\\"{x:1335,y:746,t:1527621113476};\\\", \\\"{x:1335,y:744,t:1527621113493};\\\", \\\"{x:1335,y:740,t:1527621113509};\\\", \\\"{x:1335,y:739,t:1527621113525};\\\", \\\"{x:1335,y:738,t:1527621113543};\\\", \\\"{x:1335,y:737,t:1527621113558};\\\", \\\"{x:1335,y:736,t:1527621113590};\\\", \\\"{x:1335,y:735,t:1527621113605};\\\", \\\"{x:1336,y:734,t:1527621113613};\\\", \\\"{x:1336,y:733,t:1527621113629};\\\", \\\"{x:1336,y:732,t:1527621113646};\\\", \\\"{x:1336,y:731,t:1527621113659};\\\", \\\"{x:1336,y:730,t:1527621113678};\\\", \\\"{x:1336,y:729,t:1527621113693};\\\", \\\"{x:1337,y:728,t:1527621113710};\\\", \\\"{x:1338,y:726,t:1527621113733};\\\", \\\"{x:1339,y:724,t:1527621113766};\\\", \\\"{x:1339,y:723,t:1527621113782};\\\", \\\"{x:1339,y:722,t:1527621113805};\\\", \\\"{x:1340,y:721,t:1527621113821};\\\", \\\"{x:1340,y:721,t:1527621113902};\\\", \\\"{x:1341,y:721,t:1527621114245};\\\", \\\"{x:1343,y:719,t:1527621114277};\\\", \\\"{x:1343,y:718,t:1527621114293};\\\", \\\"{x:1344,y:716,t:1527621114310};\\\", \\\"{x:1345,y:714,t:1527621114327};\\\", \\\"{x:1346,y:712,t:1527621114344};\\\", \\\"{x:1346,y:709,t:1527621114360};\\\", \\\"{x:1346,y:708,t:1527621114376};\\\", \\\"{x:1346,y:705,t:1527621114393};\\\", \\\"{x:1347,y:702,t:1527621114411};\\\", \\\"{x:1348,y:701,t:1527621114427};\\\", \\\"{x:1348,y:700,t:1527621114453};\\\", \\\"{x:1348,y:699,t:1527621114469};\\\", \\\"{x:1347,y:698,t:1527621114493};\\\", \\\"{x:1347,y:696,t:1527621114517};\\\", \\\"{x:1345,y:696,t:1527621114606};\\\", \\\"{x:1345,y:701,t:1527621114869};\\\", \\\"{x:1345,y:705,t:1527621114879};\\\", \\\"{x:1345,y:718,t:1527621114895};\\\", \\\"{x:1345,y:728,t:1527621114912};\\\", \\\"{x:1345,y:743,t:1527621114927};\\\", \\\"{x:1345,y:753,t:1527621114944};\\\", \\\"{x:1345,y:766,t:1527621114960};\\\", \\\"{x:1345,y:780,t:1527621114977};\\\", \\\"{x:1345,y:793,t:1527621114994};\\\", \\\"{x:1345,y:804,t:1527621115011};\\\", \\\"{x:1346,y:811,t:1527621115027};\\\", \\\"{x:1347,y:817,t:1527621115044};\\\", \\\"{x:1347,y:820,t:1527621115060};\\\", \\\"{x:1347,y:823,t:1527621115076};\\\", \\\"{x:1347,y:827,t:1527621115094};\\\", \\\"{x:1348,y:831,t:1527621115110};\\\", \\\"{x:1349,y:833,t:1527621115127};\\\", \\\"{x:1349,y:835,t:1527621115144};\\\", \\\"{x:1349,y:836,t:1527621115160};\\\", \\\"{x:1349,y:837,t:1527621115181};\\\", \\\"{x:1349,y:839,t:1527621115193};\\\", \\\"{x:1350,y:840,t:1527621115211};\\\", \\\"{x:1350,y:846,t:1527621115226};\\\", \\\"{x:1350,y:852,t:1527621115244};\\\", \\\"{x:1350,y:860,t:1527621115261};\\\", \\\"{x:1350,y:865,t:1527621115277};\\\", \\\"{x:1350,y:868,t:1527621115294};\\\", \\\"{x:1350,y:872,t:1527621115311};\\\", \\\"{x:1350,y:875,t:1527621115327};\\\", \\\"{x:1350,y:879,t:1527621115344};\\\", \\\"{x:1350,y:885,t:1527621115361};\\\", \\\"{x:1350,y:890,t:1527621115378};\\\", \\\"{x:1350,y:893,t:1527621115394};\\\", \\\"{x:1350,y:897,t:1527621115411};\\\", \\\"{x:1350,y:900,t:1527621115428};\\\", \\\"{x:1350,y:904,t:1527621115444};\\\", \\\"{x:1350,y:907,t:1527621115461};\\\", \\\"{x:1350,y:909,t:1527621115478};\\\", \\\"{x:1350,y:912,t:1527621115493};\\\", \\\"{x:1350,y:914,t:1527621115511};\\\", \\\"{x:1350,y:915,t:1527621115528};\\\", \\\"{x:1352,y:919,t:1527621115544};\\\", \\\"{x:1352,y:920,t:1527621115561};\\\", \\\"{x:1352,y:922,t:1527621115578};\\\", \\\"{x:1352,y:923,t:1527621115597};\\\", \\\"{x:1352,y:923,t:1527621115686};\\\", \\\"{x:1353,y:923,t:1527621115997};\\\", \\\"{x:1354,y:923,t:1527621116070};\\\", \\\"{x:1354,y:922,t:1527621116781};\\\", \\\"{x:1354,y:921,t:1527621116813};\\\", \\\"{x:1354,y:920,t:1527621116893};\\\", \\\"{x:1354,y:919,t:1527621116917};\\\", \\\"{x:1354,y:918,t:1527621116950};\\\", \\\"{x:1354,y:917,t:1527621116982};\\\", \\\"{x:1354,y:916,t:1527621116997};\\\", \\\"{x:1354,y:915,t:1527621117022};\\\", \\\"{x:1354,y:914,t:1527621117054};\\\", \\\"{x:1354,y:913,t:1527621117094};\\\", \\\"{x:1354,y:912,t:1527621117166};\\\", \\\"{x:1354,y:911,t:1527621117222};\\\", \\\"{x:1354,y:910,t:1527621117270};\\\", \\\"{x:1354,y:909,t:1527621117534};\\\", \\\"{x:1354,y:908,t:1527621118445};\\\", \\\"{x:1354,y:907,t:1527621118461};\\\", \\\"{x:1354,y:906,t:1527621118494};\\\", \\\"{x:1354,y:904,t:1527621118509};\\\", \\\"{x:1354,y:903,t:1527621118534};\\\", \\\"{x:1354,y:902,t:1527621118549};\\\", \\\"{x:1354,y:901,t:1527621118559};\\\", \\\"{x:1354,y:900,t:1527621118576};\\\", \\\"{x:1354,y:899,t:1527621118593};\\\", \\\"{x:1354,y:898,t:1527621118609};\\\", \\\"{x:1353,y:896,t:1527621118626};\\\", \\\"{x:1353,y:895,t:1527621118685};\\\", \\\"{x:1353,y:894,t:1527621119984};\\\", \\\"{x:1353,y:893,t:1527621119998};\\\", \\\"{x:1352,y:892,t:1527621120009};\\\", \\\"{x:1352,y:891,t:1527621120030};\\\", \\\"{x:1352,y:890,t:1527621120046};\\\", \\\"{x:1352,y:889,t:1527621120071};\\\", \\\"{x:1352,y:888,t:1527621120094};\\\", \\\"{x:1352,y:886,t:1527621120110};\\\", \\\"{x:1352,y:885,t:1527621120126};\\\", \\\"{x:1352,y:883,t:1527621120143};\\\", \\\"{x:1352,y:881,t:1527621120159};\\\", \\\"{x:1352,y:878,t:1527621120177};\\\", \\\"{x:1352,y:873,t:1527621120193};\\\", \\\"{x:1352,y:867,t:1527621120210};\\\", \\\"{x:1352,y:865,t:1527621120227};\\\", \\\"{x:1352,y:861,t:1527621120242};\\\", \\\"{x:1352,y:858,t:1527621120260};\\\", \\\"{x:1352,y:855,t:1527621120276};\\\", \\\"{x:1352,y:854,t:1527621120293};\\\", \\\"{x:1352,y:848,t:1527621120310};\\\", \\\"{x:1351,y:844,t:1527621120326};\\\", \\\"{x:1351,y:843,t:1527621120343};\\\", \\\"{x:1351,y:841,t:1527621120360};\\\", \\\"{x:1351,y:840,t:1527621120414};\\\", \\\"{x:1350,y:840,t:1527621120526};\\\", \\\"{x:1345,y:838,t:1527621120543};\\\", \\\"{x:1343,y:837,t:1527621120560};\\\", \\\"{x:1341,y:837,t:1527621120576};\\\", \\\"{x:1340,y:836,t:1527621120592};\\\", \\\"{x:1338,y:835,t:1527621120610};\\\", \\\"{x:1338,y:833,t:1527621120626};\\\", \\\"{x:1333,y:829,t:1527621120642};\\\", \\\"{x:1326,y:821,t:1527621120659};\\\", \\\"{x:1321,y:813,t:1527621120676};\\\", \\\"{x:1312,y:803,t:1527621120693};\\\", \\\"{x:1299,y:787,t:1527621120710};\\\", \\\"{x:1291,y:776,t:1527621120726};\\\", \\\"{x:1286,y:767,t:1527621120742};\\\", \\\"{x:1285,y:761,t:1527621120760};\\\", \\\"{x:1282,y:756,t:1527621120776};\\\", \\\"{x:1281,y:753,t:1527621120793};\\\", \\\"{x:1279,y:750,t:1527621120810};\\\", \\\"{x:1279,y:748,t:1527621120825};\\\", \\\"{x:1278,y:747,t:1527621120843};\\\", \\\"{x:1278,y:746,t:1527621120859};\\\", \\\"{x:1280,y:746,t:1527621120983};\\\", \\\"{x:1284,y:746,t:1527621120993};\\\", \\\"{x:1299,y:749,t:1527621121010};\\\", \\\"{x:1309,y:751,t:1527621121025};\\\", \\\"{x:1320,y:752,t:1527621121042};\\\", \\\"{x:1325,y:753,t:1527621121059};\\\", \\\"{x:1330,y:754,t:1527621121075};\\\", \\\"{x:1336,y:755,t:1527621121092};\\\", \\\"{x:1345,y:757,t:1527621121109};\\\", \\\"{x:1350,y:761,t:1527621121125};\\\", \\\"{x:1353,y:767,t:1527621121143};\\\", \\\"{x:1354,y:775,t:1527621121159};\\\", \\\"{x:1354,y:779,t:1527621121175};\\\", \\\"{x:1354,y:782,t:1527621121192};\\\", \\\"{x:1354,y:784,t:1527621121209};\\\", \\\"{x:1356,y:789,t:1527621121225};\\\", \\\"{x:1356,y:792,t:1527621121242};\\\", \\\"{x:1356,y:800,t:1527621121258};\\\", \\\"{x:1356,y:805,t:1527621121275};\\\", \\\"{x:1356,y:808,t:1527621121292};\\\", \\\"{x:1356,y:812,t:1527621121309};\\\", \\\"{x:1356,y:814,t:1527621121325};\\\", \\\"{x:1356,y:815,t:1527621121342};\\\", \\\"{x:1357,y:818,t:1527621121359};\\\", \\\"{x:1358,y:823,t:1527621121376};\\\", \\\"{x:1358,y:829,t:1527621121392};\\\", \\\"{x:1358,y:834,t:1527621121408};\\\", \\\"{x:1358,y:840,t:1527621121425};\\\", \\\"{x:1358,y:841,t:1527621121442};\\\", \\\"{x:1358,y:844,t:1527621121458};\\\", \\\"{x:1361,y:848,t:1527621121475};\\\", \\\"{x:1361,y:852,t:1527621121492};\\\", \\\"{x:1361,y:858,t:1527621121508};\\\", \\\"{x:1361,y:867,t:1527621121525};\\\", \\\"{x:1361,y:876,t:1527621121542};\\\", \\\"{x:1361,y:884,t:1527621121558};\\\", \\\"{x:1361,y:895,t:1527621121575};\\\", \\\"{x:1361,y:904,t:1527621121592};\\\", \\\"{x:1361,y:912,t:1527621121609};\\\", \\\"{x:1361,y:919,t:1527621121625};\\\", \\\"{x:1361,y:929,t:1527621121642};\\\", \\\"{x:1360,y:935,t:1527621121658};\\\", \\\"{x:1360,y:943,t:1527621121676};\\\", \\\"{x:1359,y:949,t:1527621121692};\\\", \\\"{x:1358,y:955,t:1527621121708};\\\", \\\"{x:1358,y:965,t:1527621121725};\\\", \\\"{x:1356,y:971,t:1527621121742};\\\", \\\"{x:1356,y:973,t:1527621121759};\\\", \\\"{x:1355,y:974,t:1527621121830};\\\", \\\"{x:1353,y:974,t:1527621121861};\\\", \\\"{x:1352,y:975,t:1527621121877};\\\", \\\"{x:1351,y:975,t:1527621121892};\\\", \\\"{x:1350,y:975,t:1527621121908};\\\", \\\"{x:1349,y:975,t:1527621121925};\\\", \\\"{x:1347,y:975,t:1527621121942};\\\", \\\"{x:1346,y:975,t:1527621121957};\\\", \\\"{x:1345,y:973,t:1527621121975};\\\", \\\"{x:1345,y:972,t:1527621122021};\\\", \\\"{x:1345,y:971,t:1527621122045};\\\", \\\"{x:1345,y:970,t:1527621122061};\\\", \\\"{x:1345,y:969,t:1527621122093};\\\", \\\"{x:1345,y:968,t:1527621122125};\\\", \\\"{x:1345,y:967,t:1527621122142};\\\", \\\"{x:1346,y:966,t:1527621122158};\\\", \\\"{x:1347,y:965,t:1527621122182};\\\", \\\"{x:1348,y:965,t:1527621122254};\\\", \\\"{x:1349,y:965,t:1527621122285};\\\", \\\"{x:1350,y:965,t:1527621122293};\\\", \\\"{x:1351,y:967,t:1527621122310};\\\", \\\"{x:1353,y:967,t:1527621122326};\\\", \\\"{x:1354,y:967,t:1527621122341};\\\", \\\"{x:1356,y:967,t:1527621122358};\\\", \\\"{x:1358,y:967,t:1527621122375};\\\", \\\"{x:1359,y:967,t:1527621122392};\\\", \\\"{x:1362,y:967,t:1527621122408};\\\", \\\"{x:1365,y:967,t:1527621122425};\\\", \\\"{x:1370,y:967,t:1527621122441};\\\", \\\"{x:1373,y:967,t:1527621122458};\\\", \\\"{x:1374,y:967,t:1527621122475};\\\", \\\"{x:1376,y:967,t:1527621122492};\\\", \\\"{x:1377,y:968,t:1527621122508};\\\", \\\"{x:1379,y:968,t:1527621122525};\\\", \\\"{x:1380,y:968,t:1527621122541};\\\", \\\"{x:1382,y:969,t:1527621122559};\\\", \\\"{x:1383,y:969,t:1527621122581};\\\", \\\"{x:1384,y:969,t:1527621122597};\\\", \\\"{x:1385,y:969,t:1527621122613};\\\", \\\"{x:1387,y:969,t:1527621122629};\\\", \\\"{x:1389,y:970,t:1527621122641};\\\", \\\"{x:1391,y:971,t:1527621122658};\\\", \\\"{x:1392,y:971,t:1527621122675};\\\", \\\"{x:1394,y:971,t:1527621122701};\\\", \\\"{x:1395,y:971,t:1527621122717};\\\", \\\"{x:1397,y:971,t:1527621122733};\\\", \\\"{x:1398,y:971,t:1527621122741};\\\", \\\"{x:1401,y:971,t:1527621122758};\\\", \\\"{x:1402,y:971,t:1527621122775};\\\", \\\"{x:1404,y:971,t:1527621122791};\\\", \\\"{x:1407,y:971,t:1527621122808};\\\", \\\"{x:1409,y:971,t:1527621122825};\\\", \\\"{x:1414,y:971,t:1527621122841};\\\", \\\"{x:1416,y:971,t:1527621122858};\\\", \\\"{x:1420,y:972,t:1527621122875};\\\", \\\"{x:1423,y:972,t:1527621122891};\\\", \\\"{x:1425,y:972,t:1527621122908};\\\", \\\"{x:1432,y:972,t:1527621122925};\\\", \\\"{x:1438,y:972,t:1527621122941};\\\", \\\"{x:1446,y:973,t:1527621122958};\\\", \\\"{x:1455,y:973,t:1527621122975};\\\", \\\"{x:1461,y:973,t:1527621122991};\\\", \\\"{x:1467,y:973,t:1527621123008};\\\", \\\"{x:1476,y:973,t:1527621123025};\\\", \\\"{x:1484,y:973,t:1527621123041};\\\", \\\"{x:1495,y:975,t:1527621123058};\\\", \\\"{x:1509,y:976,t:1527621123076};\\\", \\\"{x:1526,y:976,t:1527621123092};\\\", \\\"{x:1544,y:976,t:1527621123109};\\\", \\\"{x:1572,y:976,t:1527621123126};\\\", \\\"{x:1591,y:976,t:1527621123141};\\\", \\\"{x:1608,y:976,t:1527621123158};\\\", \\\"{x:1623,y:976,t:1527621123175};\\\", \\\"{x:1635,y:976,t:1527621123191};\\\", \\\"{x:1648,y:976,t:1527621123208};\\\", \\\"{x:1655,y:976,t:1527621123226};\\\", \\\"{x:1660,y:976,t:1527621123241};\\\", \\\"{x:1665,y:976,t:1527621123258};\\\", \\\"{x:1667,y:976,t:1527621123275};\\\", \\\"{x:1668,y:975,t:1527621123301};\\\", \\\"{x:1668,y:974,t:1527621123325};\\\", \\\"{x:1668,y:970,t:1527621123341};\\\", \\\"{x:1669,y:966,t:1527621123359};\\\", \\\"{x:1669,y:962,t:1527621123374};\\\", \\\"{x:1666,y:957,t:1527621123391};\\\", \\\"{x:1666,y:956,t:1527621123408};\\\", \\\"{x:1664,y:956,t:1527621123425};\\\", \\\"{x:1663,y:956,t:1527621123441};\\\", \\\"{x:1660,y:958,t:1527621123459};\\\", \\\"{x:1656,y:961,t:1527621123475};\\\", \\\"{x:1651,y:964,t:1527621123491};\\\", \\\"{x:1649,y:965,t:1527621123508};\\\", \\\"{x:1646,y:966,t:1527621123524};\\\", \\\"{x:1642,y:966,t:1527621123541};\\\", \\\"{x:1640,y:966,t:1527621123558};\\\", \\\"{x:1636,y:966,t:1527621123574};\\\", \\\"{x:1635,y:966,t:1527621123591};\\\", \\\"{x:1634,y:966,t:1527621123608};\\\", \\\"{x:1632,y:966,t:1527621123625};\\\", \\\"{x:1629,y:966,t:1527621123642};\\\", \\\"{x:1625,y:966,t:1527621123659};\\\", \\\"{x:1618,y:966,t:1527621123674};\\\", \\\"{x:1615,y:966,t:1527621123692};\\\", \\\"{x:1610,y:966,t:1527621123709};\\\", \\\"{x:1608,y:965,t:1527621123724};\\\", \\\"{x:1606,y:965,t:1527621123741};\\\", \\\"{x:1606,y:964,t:1527621123894};\\\", \\\"{x:1606,y:963,t:1527621123949};\\\", \\\"{x:1607,y:963,t:1527621123997};\\\", \\\"{x:1608,y:963,t:1527621124013};\\\", \\\"{x:1609,y:963,t:1527621124029};\\\", \\\"{x:1610,y:963,t:1527621124061};\\\", \\\"{x:1611,y:963,t:1527621124085};\\\", \\\"{x:1612,y:963,t:1527621124125};\\\", \\\"{x:1613,y:963,t:1527621124165};\\\", \\\"{x:1614,y:962,t:1527621124269};\\\", \\\"{x:1615,y:962,t:1527621124341};\\\", \\\"{x:1616,y:961,t:1527621125585};\\\", \\\"{x:1617,y:961,t:1527621127775};\\\", \\\"{x:1619,y:961,t:1527621127791};\\\", \\\"{x:1620,y:961,t:1527621127837};\\\", \\\"{x:1621,y:961,t:1527621127845};\\\", \\\"{x:1622,y:962,t:1527621127861};\\\", \\\"{x:1623,y:962,t:1527621128607};\\\", \\\"{x:1620,y:962,t:1527621137654};\\\", \\\"{x:1614,y:962,t:1527621137671};\\\", \\\"{x:1606,y:963,t:1527621137688};\\\", \\\"{x:1603,y:963,t:1527621137704};\\\", \\\"{x:1606,y:964,t:1527621137798};\\\", \\\"{x:1607,y:964,t:1527621137805};\\\", \\\"{x:1608,y:964,t:1527621137821};\\\", \\\"{x:1609,y:965,t:1527621137838};\\\", \\\"{x:1610,y:966,t:1527621137854};\\\", \\\"{x:1611,y:966,t:1527621137871};\\\", \\\"{x:1612,y:966,t:1527621137887};\\\", \\\"{x:1613,y:966,t:1527621137942};\\\", \\\"{x:1614,y:966,t:1527621137991};\\\", \\\"{x:1615,y:966,t:1527621138198};\\\", \\\"{x:1613,y:965,t:1527621143399};\\\", \\\"{x:1611,y:963,t:1527621143407};\\\", \\\"{x:1607,y:959,t:1527621143420};\\\", \\\"{x:1589,y:950,t:1527621143437};\\\", \\\"{x:1558,y:941,t:1527621143453};\\\", \\\"{x:1439,y:907,t:1527621143470};\\\", \\\"{x:1339,y:879,t:1527621143486};\\\", \\\"{x:1212,y:843,t:1527621143503};\\\", \\\"{x:1086,y:820,t:1527621143520};\\\", \\\"{x:982,y:794,t:1527621143536};\\\", \\\"{x:877,y:764,t:1527621143553};\\\", \\\"{x:798,y:737,t:1527621143570};\\\", \\\"{x:715,y:713,t:1527621143586};\\\", \\\"{x:646,y:685,t:1527621143603};\\\", \\\"{x:608,y:668,t:1527621143619};\\\", \\\"{x:582,y:659,t:1527621143636};\\\", \\\"{x:560,y:649,t:1527621143653};\\\", \\\"{x:531,y:637,t:1527621143670};\\\", \\\"{x:516,y:629,t:1527621143687};\\\", \\\"{x:503,y:622,t:1527621143702};\\\", \\\"{x:487,y:611,t:1527621143720};\\\", \\\"{x:466,y:600,t:1527621143733};\\\", \\\"{x:448,y:592,t:1527621143751};\\\", \\\"{x:444,y:591,t:1527621143767};\\\", \\\"{x:445,y:590,t:1527621143821};\\\", \\\"{x:446,y:590,t:1527621143837};\\\", \\\"{x:449,y:590,t:1527621143850};\\\", \\\"{x:456,y:590,t:1527621143867};\\\", \\\"{x:475,y:593,t:1527621143883};\\\", \\\"{x:501,y:595,t:1527621143901};\\\", \\\"{x:541,y:599,t:1527621143917};\\\", \\\"{x:572,y:599,t:1527621143934};\\\", \\\"{x:599,y:599,t:1527621143951};\\\", \\\"{x:616,y:599,t:1527621143968};\\\", \\\"{x:621,y:599,t:1527621143984};\\\", \\\"{x:622,y:599,t:1527621144000};\\\", \\\"{x:622,y:598,t:1527621144053};\\\", \\\"{x:622,y:597,t:1527621144068};\\\", \\\"{x:622,y:596,t:1527621144085};\\\", \\\"{x:622,y:595,t:1527621144101};\\\", \\\"{x:622,y:594,t:1527621144117};\\\", \\\"{x:622,y:593,t:1527621144136};\\\", \\\"{x:622,y:591,t:1527621144150};\\\", \\\"{x:621,y:589,t:1527621144167};\\\", \\\"{x:620,y:587,t:1527621144197};\\\", \\\"{x:620,y:586,t:1527621144213};\\\", \\\"{x:620,y:585,t:1527621144221};\\\", \\\"{x:620,y:584,t:1527621144234};\\\", \\\"{x:622,y:584,t:1527621144823};\\\", \\\"{x:659,y:592,t:1527621144835};\\\", \\\"{x:770,y:625,t:1527621144853};\\\", \\\"{x:888,y:656,t:1527621144868};\\\", \\\"{x:1028,y:689,t:1527621144884};\\\", \\\"{x:1253,y:739,t:1527621144901};\\\", \\\"{x:1383,y:775,t:1527621144918};\\\", \\\"{x:1503,y:815,t:1527621144935};\\\", \\\"{x:1609,y:854,t:1527621144951};\\\", \\\"{x:1702,y:885,t:1527621144968};\\\", \\\"{x:1753,y:903,t:1527621144984};\\\", \\\"{x:1782,y:914,t:1527621145001};\\\", \\\"{x:1802,y:925,t:1527621145018};\\\", \\\"{x:1814,y:932,t:1527621145035};\\\", \\\"{x:1822,y:936,t:1527621145052};\\\", \\\"{x:1827,y:940,t:1527621145069};\\\", \\\"{x:1835,y:944,t:1527621145085};\\\", \\\"{x:1841,y:948,t:1527621145101};\\\", \\\"{x:1840,y:948,t:1527621145126};\\\", \\\"{x:1833,y:948,t:1527621145135};\\\", \\\"{x:1794,y:948,t:1527621145152};\\\", \\\"{x:1749,y:948,t:1527621145169};\\\", \\\"{x:1717,y:947,t:1527621145185};\\\", \\\"{x:1680,y:947,t:1527621145202};\\\", \\\"{x:1639,y:944,t:1527621145219};\\\", \\\"{x:1612,y:941,t:1527621145235};\\\", \\\"{x:1597,y:939,t:1527621145252};\\\", \\\"{x:1591,y:938,t:1527621145269};\\\", \\\"{x:1588,y:937,t:1527621145285};\\\", \\\"{x:1587,y:937,t:1527621145309};\\\", \\\"{x:1586,y:937,t:1527621145318};\\\", \\\"{x:1586,y:939,t:1527621145335};\\\", \\\"{x:1586,y:941,t:1527621145351};\\\", \\\"{x:1586,y:945,t:1527621145368};\\\", \\\"{x:1586,y:946,t:1527621145384};\\\", \\\"{x:1586,y:949,t:1527621145401};\\\", \\\"{x:1586,y:952,t:1527621145418};\\\", \\\"{x:1586,y:953,t:1527621145435};\\\", \\\"{x:1585,y:953,t:1527621145452};\\\", \\\"{x:1585,y:955,t:1527621145469};\\\", \\\"{x:1584,y:955,t:1527621145486};\\\", \\\"{x:1584,y:956,t:1527621145502};\\\", \\\"{x:1581,y:958,t:1527621145519};\\\", \\\"{x:1577,y:958,t:1527621145536};\\\", \\\"{x:1571,y:958,t:1527621145551};\\\", \\\"{x:1567,y:958,t:1527621145569};\\\", \\\"{x:1566,y:958,t:1527621145585};\\\", \\\"{x:1564,y:959,t:1527621145602};\\\", \\\"{x:1563,y:959,t:1527621145636};\\\", \\\"{x:1560,y:959,t:1527621145651};\\\", \\\"{x:1555,y:959,t:1527621145668};\\\", \\\"{x:1552,y:959,t:1527621145685};\\\", \\\"{x:1552,y:960,t:1527621145838};\\\", \\\"{x:1553,y:961,t:1527621145853};\\\", \\\"{x:1553,y:962,t:1527621145925};\\\", \\\"{x:1555,y:963,t:1527621145935};\\\", \\\"{x:1559,y:967,t:1527621145951};\\\", \\\"{x:1564,y:967,t:1527621145969};\\\", \\\"{x:1567,y:968,t:1527621145985};\\\", \\\"{x:1572,y:968,t:1527621146001};\\\", \\\"{x:1574,y:968,t:1527621146018};\\\", \\\"{x:1577,y:968,t:1527621146035};\\\", \\\"{x:1579,y:968,t:1527621146052};\\\", \\\"{x:1586,y:968,t:1527621146069};\\\", \\\"{x:1593,y:968,t:1527621146086};\\\", \\\"{x:1596,y:968,t:1527621146102};\\\", \\\"{x:1598,y:968,t:1527621146119};\\\", \\\"{x:1599,y:968,t:1527621146136};\\\", \\\"{x:1600,y:968,t:1527621146153};\\\", \\\"{x:1603,y:968,t:1527621146169};\\\", \\\"{x:1606,y:967,t:1527621146186};\\\", \\\"{x:1609,y:967,t:1527621146202};\\\", \\\"{x:1612,y:967,t:1527621146219};\\\", \\\"{x:1613,y:966,t:1527621146236};\\\", \\\"{x:1615,y:965,t:1527621146292};\\\", \\\"{x:1616,y:965,t:1527621146317};\\\", \\\"{x:1616,y:964,t:1527621146349};\\\", \\\"{x:1616,y:963,t:1527621181794};\\\", \\\"{x:1598,y:958,t:1527621181811};\\\", \\\"{x:1547,y:953,t:1527621181827};\\\", \\\"{x:1460,y:938,t:1527621181844};\\\", \\\"{x:1373,y:921,t:1527621181861};\\\", \\\"{x:1276,y:905,t:1527621181877};\\\", \\\"{x:1179,y:880,t:1527621181895};\\\", \\\"{x:1105,y:862,t:1527621181911};\\\", \\\"{x:1032,y:840,t:1527621181928};\\\", \\\"{x:967,y:818,t:1527621181945};\\\", \\\"{x:931,y:803,t:1527621181960};\\\", \\\"{x:903,y:793,t:1527621181978};\\\", \\\"{x:880,y:782,t:1527621181994};\\\", \\\"{x:843,y:768,t:1527621182011};\\\", \\\"{x:807,y:759,t:1527621182027};\\\", \\\"{x:771,y:745,t:1527621182044};\\\", \\\"{x:721,y:730,t:1527621182060};\\\", \\\"{x:684,y:719,t:1527621182077};\\\", \\\"{x:651,y:710,t:1527621182094};\\\", \\\"{x:620,y:701,t:1527621182110};\\\", \\\"{x:597,y:694,t:1527621182127};\\\", \\\"{x:583,y:692,t:1527621182143};\\\", \\\"{x:580,y:692,t:1527621182160};\\\", \\\"{x:574,y:692,t:1527621182177};\\\", \\\"{x:563,y:692,t:1527621182194};\\\", \\\"{x:551,y:692,t:1527621182210};\\\", \\\"{x:537,y:692,t:1527621182227};\\\", \\\"{x:530,y:692,t:1527621182244};\\\", \\\"{x:529,y:692,t:1527621182260};\\\", \\\"{x:529,y:693,t:1527621182280};\\\", \\\"{x:529,y:694,t:1527621182294};\\\", \\\"{x:529,y:700,t:1527621182311};\\\", \\\"{x:529,y:705,t:1527621182327};\\\", \\\"{x:529,y:709,t:1527621182344};\\\", \\\"{x:530,y:713,t:1527621182361};\\\", \\\"{x:533,y:719,t:1527621182378};\\\", \\\"{x:535,y:723,t:1527621182395};\\\", \\\"{x:538,y:727,t:1527621182411};\\\", \\\"{x:538,y:728,t:1527621182427};\\\", \\\"{x:538,y:730,t:1527621182463};\\\", \\\"{x:539,y:730,t:1527621182480};\\\", \\\"{x:539,y:731,t:1527621182512};\\\", \\\"{x:540,y:731,t:1527621183153};\\\", \\\"{x:541,y:731,t:1527621183385};\\\", \\\"{x:544,y:730,t:1527621183403};\\\", \\\"{x:547,y:730,t:1527621183418};\\\", \\\"{x:548,y:729,t:1527621183436};\\\", \\\"{x:549,y:728,t:1527621183452};\\\", \\\"{x:550,y:726,t:1527621183472};\\\", \\\"{x:550,y:724,t:1527621183496};\\\", \\\"{x:550,y:723,t:1527621183512};\\\", \\\"{x:550,y:722,t:1527621183520};\\\", \\\"{x:551,y:721,t:1527621183535};\\\", \\\"{x:551,y:719,t:1527621183552};\\\", \\\"{x:551,y:718,t:1527621183569};\\\", \\\"{x:551,y:717,t:1527621183592};\\\", \\\"{x:552,y:715,t:1527621183602};\\\", \\\"{x:557,y:700,t:1527621183672};\\\", \\\"{x:557,y:697,t:1527621183688};\\\", \\\"{x:558,y:695,t:1527621183703};\\\", \\\"{x:558,y:694,t:1527621183727};\\\", \\\"{x:558,y:693,t:1527621183752};\\\", \\\"{x:558,y:692,t:1527621183767};\\\", \\\"{x:558,y:691,t:1527621183815};\\\", \\\"{x:558,y:689,t:1527621183847};\\\", \\\"{x:559,y:686,t:1527621183856};\\\", \\\"{x:559,y:683,t:1527621183869};\\\", \\\"{x:563,y:673,t:1527621183886};\\\", \\\"{x:567,y:666,t:1527621183902};\\\", \\\"{x:571,y:661,t:1527621183919};\\\", \\\"{x:574,y:653,t:1527621183935};\\\", \\\"{x:574,y:647,t:1527621183952};\\\", \\\"{x:575,y:642,t:1527621183969};\\\", \\\"{x:576,y:636,t:1527621183986};\\\" ] }, { \\\"rt\\\": 10846, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 643949, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:613,t:1527621184164};\\\", \\\"{x:579,y:613,t:1527621185008};\\\", \\\"{x:581,y:613,t:1527621185024};\\\", \\\"{x:581,y:611,t:1527621185037};\\\", \\\"{x:585,y:611,t:1527621185054};\\\", \\\"{x:603,y:611,t:1527621185071};\\\", \\\"{x:626,y:611,t:1527621185088};\\\", \\\"{x:637,y:612,t:1527621185103};\\\", \\\"{x:686,y:623,t:1527621185120};\\\", \\\"{x:707,y:631,t:1527621185137};\\\", \\\"{x:723,y:640,t:1527621185154};\\\", \\\"{x:733,y:647,t:1527621185170};\\\", \\\"{x:739,y:653,t:1527621185187};\\\", \\\"{x:743,y:659,t:1527621185203};\\\", \\\"{x:744,y:662,t:1527621185220};\\\", \\\"{x:746,y:666,t:1527621185237};\\\", \\\"{x:746,y:669,t:1527621185253};\\\", \\\"{x:747,y:675,t:1527621185271};\\\", \\\"{x:747,y:677,t:1527621185287};\\\", \\\"{x:747,y:680,t:1527621185303};\\\", \\\"{x:747,y:681,t:1527621185328};\\\", \\\"{x:747,y:682,t:1527621185441};\\\", \\\"{x:746,y:682,t:1527621185697};\\\", \\\"{x:745,y:683,t:1527621185920};\\\", \\\"{x:745,y:686,t:1527621185992};\\\", \\\"{x:745,y:687,t:1527621186004};\\\", \\\"{x:745,y:691,t:1527621186021};\\\", \\\"{x:745,y:692,t:1527621186037};\\\", \\\"{x:745,y:693,t:1527621186080};\\\", \\\"{x:745,y:694,t:1527621186120};\\\", \\\"{x:745,y:695,t:1527621186177};\\\", \\\"{x:744,y:696,t:1527621186233};\\\", \\\"{x:743,y:696,t:1527621186273};\\\", \\\"{x:741,y:696,t:1527621186297};\\\", \\\"{x:738,y:695,t:1527621186304};\\\", \\\"{x:728,y:691,t:1527621186321};\\\", \\\"{x:726,y:690,t:1527621186339};\\\", \\\"{x:725,y:689,t:1527621186355};\\\", \\\"{x:724,y:689,t:1527621186371};\\\", \\\"{x:724,y:688,t:1527621186409};\\\", \\\"{x:723,y:688,t:1527621186424};\\\", \\\"{x:722,y:687,t:1527621186456};\\\", \\\"{x:721,y:687,t:1527621186545};\\\", \\\"{x:720,y:686,t:1527621186720};\\\", \\\"{x:719,y:686,t:1527621186744};\\\", \\\"{x:718,y:686,t:1527621186776};\\\", \\\"{x:717,y:685,t:1527621187033};\\\", \\\"{x:715,y:685,t:1527621187113};\\\", \\\"{x:714,y:685,t:1527621187289};\\\", \\\"{x:713,y:685,t:1527621187320};\\\", \\\"{x:712,y:685,t:1527621187353};\\\", \\\"{x:711,y:685,t:1527621187456};\\\", \\\"{x:710,y:684,t:1527621187672};\\\", \\\"{x:709,y:684,t:1527621188145};\\\", \\\"{x:708,y:684,t:1527621188457};\\\", \\\"{x:700,y:683,t:1527621188473};\\\", \\\"{x:684,y:676,t:1527621188490};\\\", \\\"{x:672,y:673,t:1527621188507};\\\", \\\"{x:663,y:669,t:1527621188523};\\\", \\\"{x:654,y:665,t:1527621188540};\\\", \\\"{x:647,y:664,t:1527621188556};\\\", \\\"{x:644,y:663,t:1527621188574};\\\", \\\"{x:643,y:662,t:1527621188633};\\\", \\\"{x:642,y:661,t:1527621188968};\\\", \\\"{x:641,y:660,t:1527621188976};\\\", \\\"{x:638,y:659,t:1527621188992};\\\", \\\"{x:637,y:659,t:1527621189007};\\\", \\\"{x:634,y:654,t:1527621189024};\\\", \\\"{x:630,y:645,t:1527621189040};\\\", \\\"{x:625,y:632,t:1527621189057};\\\", \\\"{x:619,y:620,t:1527621189075};\\\", \\\"{x:615,y:611,t:1527621189091};\\\", \\\"{x:614,y:608,t:1527621189106};\\\", \\\"{x:614,y:603,t:1527621189124};\\\", \\\"{x:611,y:599,t:1527621189140};\\\", \\\"{x:611,y:597,t:1527621189157};\\\", \\\"{x:611,y:594,t:1527621189173};\\\", \\\"{x:609,y:591,t:1527621189191};\\\", \\\"{x:606,y:589,t:1527621189207};\\\", \\\"{x:593,y:585,t:1527621189224};\\\", \\\"{x:574,y:583,t:1527621189240};\\\", \\\"{x:550,y:581,t:1527621189256};\\\", \\\"{x:528,y:579,t:1527621189273};\\\", \\\"{x:506,y:575,t:1527621189290};\\\", \\\"{x:486,y:573,t:1527621189307};\\\", \\\"{x:471,y:569,t:1527621189324};\\\", \\\"{x:461,y:568,t:1527621189340};\\\", \\\"{x:451,y:565,t:1527621189358};\\\", \\\"{x:443,y:563,t:1527621189374};\\\", \\\"{x:437,y:559,t:1527621189391};\\\", \\\"{x:431,y:556,t:1527621189408};\\\", \\\"{x:422,y:553,t:1527621189424};\\\", \\\"{x:408,y:552,t:1527621189440};\\\", \\\"{x:387,y:547,t:1527621189458};\\\", \\\"{x:362,y:543,t:1527621189474};\\\", \\\"{x:345,y:541,t:1527621189490};\\\", \\\"{x:331,y:540,t:1527621189506};\\\", \\\"{x:324,y:540,t:1527621189524};\\\", \\\"{x:320,y:539,t:1527621189540};\\\", \\\"{x:317,y:537,t:1527621189557};\\\", \\\"{x:314,y:536,t:1527621189574};\\\", \\\"{x:305,y:536,t:1527621189590};\\\", \\\"{x:301,y:536,t:1527621189606};\\\", \\\"{x:295,y:536,t:1527621189623};\\\", \\\"{x:294,y:536,t:1527621189640};\\\", \\\"{x:291,y:536,t:1527621189657};\\\", \\\"{x:286,y:536,t:1527621189673};\\\", \\\"{x:280,y:537,t:1527621189691};\\\", \\\"{x:274,y:538,t:1527621189706};\\\", \\\"{x:267,y:542,t:1527621189726};\\\", \\\"{x:263,y:544,t:1527621189740};\\\", \\\"{x:255,y:547,t:1527621189756};\\\", \\\"{x:251,y:548,t:1527621189773};\\\", \\\"{x:246,y:550,t:1527621189790};\\\", \\\"{x:241,y:553,t:1527621189806};\\\", \\\"{x:239,y:556,t:1527621189824};\\\", \\\"{x:238,y:559,t:1527621189839};\\\", \\\"{x:236,y:562,t:1527621189858};\\\", \\\"{x:233,y:565,t:1527621189875};\\\", \\\"{x:231,y:568,t:1527621189890};\\\", \\\"{x:227,y:572,t:1527621189907};\\\", \\\"{x:223,y:576,t:1527621189925};\\\", \\\"{x:219,y:579,t:1527621189941};\\\", \\\"{x:215,y:583,t:1527621189958};\\\", \\\"{x:212,y:585,t:1527621189975};\\\", \\\"{x:208,y:587,t:1527621189990};\\\", \\\"{x:202,y:591,t:1527621190008};\\\", \\\"{x:199,y:592,t:1527621190024};\\\", \\\"{x:196,y:594,t:1527621190043};\\\", \\\"{x:194,y:595,t:1527621190057};\\\", \\\"{x:190,y:595,t:1527621190074};\\\", \\\"{x:186,y:595,t:1527621190090};\\\", \\\"{x:184,y:595,t:1527621190107};\\\", \\\"{x:179,y:593,t:1527621190125};\\\", \\\"{x:171,y:588,t:1527621190140};\\\", \\\"{x:159,y:581,t:1527621190157};\\\", \\\"{x:150,y:579,t:1527621190175};\\\", \\\"{x:145,y:576,t:1527621190190};\\\", \\\"{x:142,y:574,t:1527621190207};\\\", \\\"{x:140,y:571,t:1527621190225};\\\", \\\"{x:140,y:570,t:1527621190241};\\\", \\\"{x:138,y:569,t:1527621190258};\\\", \\\"{x:138,y:568,t:1527621190274};\\\", \\\"{x:138,y:566,t:1527621190292};\\\", \\\"{x:138,y:564,t:1527621190307};\\\", \\\"{x:138,y:563,t:1527621190324};\\\", \\\"{x:138,y:560,t:1527621190342};\\\", \\\"{x:138,y:558,t:1527621190358};\\\", \\\"{x:138,y:557,t:1527621190374};\\\", \\\"{x:138,y:556,t:1527621190391};\\\", \\\"{x:138,y:555,t:1527621190408};\\\", \\\"{x:138,y:553,t:1527621190424};\\\", \\\"{x:139,y:552,t:1527621190441};\\\", \\\"{x:140,y:550,t:1527621190458};\\\", \\\"{x:141,y:549,t:1527621190475};\\\", \\\"{x:142,y:547,t:1527621190492};\\\", \\\"{x:142,y:546,t:1527621190545};\\\", \\\"{x:144,y:545,t:1527621190600};\\\", \\\"{x:145,y:544,t:1527621190711};\\\", \\\"{x:145,y:544,t:1527621190744};\\\", \\\"{x:146,y:544,t:1527621190784};\\\", \\\"{x:148,y:544,t:1527621190792};\\\", \\\"{x:150,y:544,t:1527621190809};\\\", \\\"{x:151,y:544,t:1527621190824};\\\", \\\"{x:156,y:544,t:1527621190841};\\\", \\\"{x:166,y:544,t:1527621190859};\\\", \\\"{x:177,y:543,t:1527621190875};\\\", \\\"{x:192,y:543,t:1527621190892};\\\", \\\"{x:214,y:538,t:1527621190909};\\\", \\\"{x:234,y:536,t:1527621190925};\\\", \\\"{x:256,y:533,t:1527621190942};\\\", \\\"{x:288,y:532,t:1527621190960};\\\", \\\"{x:327,y:532,t:1527621190975};\\\", \\\"{x:411,y:532,t:1527621190992};\\\", \\\"{x:464,y:532,t:1527621191009};\\\", \\\"{x:499,y:532,t:1527621191026};\\\", \\\"{x:523,y:532,t:1527621191041};\\\", \\\"{x:545,y:532,t:1527621191058};\\\", \\\"{x:561,y:532,t:1527621191074};\\\", \\\"{x:576,y:532,t:1527621191092};\\\", \\\"{x:584,y:532,t:1527621191109};\\\", \\\"{x:588,y:531,t:1527621191125};\\\", \\\"{x:591,y:530,t:1527621191142};\\\", \\\"{x:592,y:529,t:1527621191160};\\\", \\\"{x:591,y:529,t:1527621191321};\\\", \\\"{x:590,y:529,t:1527621191345};\\\", \\\"{x:586,y:528,t:1527621191521};\\\", \\\"{x:572,y:526,t:1527621191529};\\\", \\\"{x:557,y:524,t:1527621191544};\\\", \\\"{x:508,y:521,t:1527621191559};\\\", \\\"{x:455,y:516,t:1527621191576};\\\", \\\"{x:423,y:514,t:1527621191592};\\\", \\\"{x:405,y:514,t:1527621191609};\\\", \\\"{x:390,y:512,t:1527621191626};\\\", \\\"{x:373,y:512,t:1527621191643};\\\", \\\"{x:365,y:512,t:1527621191658};\\\", \\\"{x:357,y:512,t:1527621191675};\\\", \\\"{x:349,y:513,t:1527621191693};\\\", \\\"{x:342,y:514,t:1527621191708};\\\", \\\"{x:326,y:516,t:1527621191726};\\\", \\\"{x:311,y:518,t:1527621191743};\\\", \\\"{x:294,y:521,t:1527621191759};\\\", \\\"{x:280,y:523,t:1527621191776};\\\", \\\"{x:270,y:524,t:1527621191792};\\\", \\\"{x:256,y:528,t:1527621191809};\\\", \\\"{x:241,y:531,t:1527621191826};\\\", \\\"{x:226,y:533,t:1527621191842};\\\", \\\"{x:210,y:536,t:1527621191858};\\\", \\\"{x:195,y:538,t:1527621191876};\\\", \\\"{x:185,y:539,t:1527621191894};\\\", \\\"{x:176,y:541,t:1527621191909};\\\", \\\"{x:173,y:542,t:1527621191925};\\\", \\\"{x:171,y:542,t:1527621191943};\\\", \\\"{x:170,y:542,t:1527621191984};\\\", \\\"{x:172,y:542,t:1527621192480};\\\", \\\"{x:173,y:542,t:1527621192537};\\\", \\\"{x:175,y:542,t:1527621192568};\\\", \\\"{x:177,y:542,t:1527621192592};\\\", \\\"{x:178,y:542,t:1527621192609};\\\", \\\"{x:179,y:544,t:1527621192626};\\\", \\\"{x:180,y:545,t:1527621192643};\\\", \\\"{x:182,y:547,t:1527621192660};\\\", \\\"{x:184,y:548,t:1527621192677};\\\", \\\"{x:187,y:551,t:1527621192693};\\\", \\\"{x:190,y:553,t:1527621192709};\\\", \\\"{x:192,y:556,t:1527621192727};\\\", \\\"{x:193,y:556,t:1527621192742};\\\", \\\"{x:196,y:559,t:1527621192759};\\\", \\\"{x:200,y:562,t:1527621192777};\\\", \\\"{x:203,y:563,t:1527621192793};\\\", \\\"{x:206,y:566,t:1527621192809};\\\", \\\"{x:207,y:567,t:1527621192826};\\\", \\\"{x:209,y:569,t:1527621192843};\\\", \\\"{x:210,y:570,t:1527621192860};\\\", \\\"{x:212,y:570,t:1527621192876};\\\", \\\"{x:212,y:572,t:1527621192894};\\\", \\\"{x:212,y:573,t:1527621192909};\\\", \\\"{x:214,y:578,t:1527621192926};\\\", \\\"{x:217,y:585,t:1527621192944};\\\", \\\"{x:219,y:588,t:1527621192959};\\\", \\\"{x:221,y:590,t:1527621192976};\\\", \\\"{x:221,y:592,t:1527621192994};\\\", \\\"{x:221,y:595,t:1527621193011};\\\", \\\"{x:223,y:597,t:1527621193027};\\\", \\\"{x:223,y:599,t:1527621193043};\\\", \\\"{x:226,y:601,t:1527621193060};\\\", \\\"{x:230,y:604,t:1527621193076};\\\", \\\"{x:235,y:607,t:1527621193093};\\\", \\\"{x:240,y:608,t:1527621193110};\\\", \\\"{x:245,y:608,t:1527621193126};\\\", \\\"{x:258,y:608,t:1527621193144};\\\", \\\"{x:269,y:608,t:1527621193160};\\\", \\\"{x:283,y:608,t:1527621193178};\\\", \\\"{x:298,y:607,t:1527621193193};\\\", \\\"{x:315,y:606,t:1527621193209};\\\", \\\"{x:336,y:605,t:1527621193226};\\\", \\\"{x:357,y:602,t:1527621193244};\\\", \\\"{x:380,y:600,t:1527621193261};\\\", \\\"{x:408,y:600,t:1527621193276};\\\", \\\"{x:435,y:600,t:1527621193293};\\\", \\\"{x:458,y:600,t:1527621193311};\\\", \\\"{x:479,y:600,t:1527621193327};\\\", \\\"{x:515,y:600,t:1527621193344};\\\", \\\"{x:543,y:600,t:1527621193360};\\\", \\\"{x:577,y:600,t:1527621193376};\\\", \\\"{x:621,y:600,t:1527621193394};\\\", \\\"{x:663,y:600,t:1527621193411};\\\", \\\"{x:703,y:600,t:1527621193426};\\\", \\\"{x:731,y:600,t:1527621193444};\\\", \\\"{x:756,y:600,t:1527621193461};\\\", \\\"{x:776,y:600,t:1527621193476};\\\", \\\"{x:792,y:600,t:1527621193494};\\\", \\\"{x:802,y:600,t:1527621193511};\\\", \\\"{x:811,y:600,t:1527621193527};\\\", \\\"{x:818,y:600,t:1527621193545};\\\", \\\"{x:820,y:600,t:1527621193561};\\\", \\\"{x:822,y:600,t:1527621193608};\\\", \\\"{x:823,y:600,t:1527621193624};\\\", \\\"{x:824,y:599,t:1527621193632};\\\", \\\"{x:825,y:598,t:1527621193648};\\\", \\\"{x:826,y:596,t:1527621193661};\\\", \\\"{x:829,y:593,t:1527621193678};\\\", \\\"{x:833,y:590,t:1527621193693};\\\", \\\"{x:836,y:585,t:1527621193710};\\\", \\\"{x:839,y:580,t:1527621193726};\\\", \\\"{x:844,y:570,t:1527621193744};\\\", \\\"{x:848,y:564,t:1527621193761};\\\", \\\"{x:858,y:551,t:1527621193779};\\\", \\\"{x:868,y:538,t:1527621193793};\\\", \\\"{x:876,y:526,t:1527621193811};\\\", \\\"{x:881,y:515,t:1527621193829};\\\", \\\"{x:885,y:505,t:1527621193843};\\\", \\\"{x:885,y:499,t:1527621193860};\\\", \\\"{x:883,y:493,t:1527621193877};\\\", \\\"{x:880,y:489,t:1527621193894};\\\", \\\"{x:879,y:488,t:1527621193911};\\\", \\\"{x:874,y:487,t:1527621193927};\\\", \\\"{x:871,y:487,t:1527621193944};\\\", \\\"{x:867,y:487,t:1527621193960};\\\", \\\"{x:863,y:487,t:1527621193977};\\\", \\\"{x:860,y:489,t:1527621193994};\\\", \\\"{x:858,y:491,t:1527621194012};\\\", \\\"{x:855,y:494,t:1527621194027};\\\", \\\"{x:854,y:496,t:1527621194044};\\\", \\\"{x:853,y:498,t:1527621194061};\\\", \\\"{x:852,y:499,t:1527621194077};\\\", \\\"{x:851,y:499,t:1527621194094};\\\", \\\"{x:851,y:500,t:1527621194136};\\\", \\\"{x:850,y:500,t:1527621194224};\\\", \\\"{x:850,y:500,t:1527621194235};\\\", \\\"{x:849,y:500,t:1527621194244};\\\", \\\"{x:847,y:501,t:1527621194264};\\\", \\\"{x:846,y:503,t:1527621194279};\\\", \\\"{x:845,y:503,t:1527621194294};\\\", \\\"{x:844,y:506,t:1527621194311};\\\", \\\"{x:837,y:514,t:1527621194327};\\\", \\\"{x:824,y:524,t:1527621194346};\\\", \\\"{x:819,y:530,t:1527621194361};\\\", \\\"{x:812,y:539,t:1527621194378};\\\", \\\"{x:805,y:547,t:1527621194394};\\\", \\\"{x:798,y:556,t:1527621194411};\\\", \\\"{x:789,y:567,t:1527621194428};\\\", \\\"{x:774,y:580,t:1527621194445};\\\", \\\"{x:751,y:595,t:1527621194462};\\\", \\\"{x:727,y:608,t:1527621194479};\\\", \\\"{x:703,y:622,t:1527621194495};\\\", \\\"{x:673,y:636,t:1527621194511};\\\", \\\"{x:648,y:655,t:1527621194528};\\\", \\\"{x:634,y:664,t:1527621194545};\\\", \\\"{x:625,y:672,t:1527621194561};\\\", \\\"{x:613,y:680,t:1527621194577};\\\", \\\"{x:600,y:686,t:1527621194595};\\\", \\\"{x:589,y:694,t:1527621194612};\\\", \\\"{x:579,y:701,t:1527621194627};\\\", \\\"{x:569,y:708,t:1527621194645};\\\", \\\"{x:562,y:714,t:1527621194663};\\\", \\\"{x:556,y:719,t:1527621194678};\\\", \\\"{x:550,y:724,t:1527621194696};\\\", \\\"{x:542,y:731,t:1527621194712};\\\", \\\"{x:539,y:734,t:1527621194728};\\\", \\\"{x:537,y:735,t:1527621194745};\\\", \\\"{x:536,y:736,t:1527621194762};\\\", \\\"{x:533,y:737,t:1527621194779};\\\", \\\"{x:531,y:738,t:1527621194795};\\\", \\\"{x:527,y:739,t:1527621194812};\\\", \\\"{x:526,y:739,t:1527621194832};\\\", \\\"{x:527,y:737,t:1527621195384};\\\", \\\"{x:528,y:734,t:1527621195400};\\\", \\\"{x:530,y:734,t:1527621195412};\\\", \\\"{x:530,y:733,t:1527621195480};\\\", \\\"{x:531,y:733,t:1527621195495};\\\", \\\"{x:533,y:733,t:1527621195512};\\\", \\\"{x:534,y:734,t:1527621195529};\\\" ] }, { \\\"rt\\\": 7793, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 652980, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:733,t:1527621196724};\\\", \\\"{x:537,y:733,t:1527621196733};\\\", \\\"{x:538,y:732,t:1527621197417};\\\", \\\"{x:543,y:731,t:1527621197432};\\\", \\\"{x:547,y:731,t:1527621197448};\\\", \\\"{x:561,y:729,t:1527621197464};\\\", \\\"{x:563,y:729,t:1527621197480};\\\", \\\"{x:571,y:728,t:1527621197498};\\\", \\\"{x:576,y:728,t:1527621197513};\\\", \\\"{x:577,y:728,t:1527621197530};\\\", \\\"{x:578,y:727,t:1527621197615};\\\", \\\"{x:579,y:727,t:1527621197648};\\\", \\\"{x:581,y:727,t:1527621197663};\\\", \\\"{x:582,y:727,t:1527621197680};\\\", \\\"{x:582,y:726,t:1527621197721};\\\", \\\"{x:584,y:726,t:1527621197777};\\\", \\\"{x:585,y:726,t:1527621197824};\\\", \\\"{x:586,y:726,t:1527621197832};\\\", \\\"{x:587,y:726,t:1527621197847};\\\", \\\"{x:589,y:726,t:1527621197865};\\\", \\\"{x:590,y:726,t:1527621197881};\\\", \\\"{x:592,y:726,t:1527621197897};\\\", \\\"{x:593,y:726,t:1527621197914};\\\", \\\"{x:594,y:726,t:1527621198033};\\\", \\\"{x:595,y:726,t:1527621198047};\\\", \\\"{x:600,y:725,t:1527621198064};\\\", \\\"{x:604,y:725,t:1527621198080};\\\", \\\"{x:609,y:725,t:1527621198097};\\\", \\\"{x:616,y:725,t:1527621198114};\\\", \\\"{x:620,y:725,t:1527621198131};\\\", \\\"{x:622,y:725,t:1527621198147};\\\", \\\"{x:625,y:725,t:1527621198165};\\\", \\\"{x:626,y:725,t:1527621198181};\\\", \\\"{x:627,y:725,t:1527621198201};\\\", \\\"{x:628,y:725,t:1527621198216};\\\", \\\"{x:629,y:725,t:1527621198230};\\\", \\\"{x:630,y:725,t:1527621198250};\\\", \\\"{x:631,y:725,t:1527621198352};\\\", \\\"{x:631,y:726,t:1527621198385};\\\", \\\"{x:630,y:727,t:1527621198408};\\\", \\\"{x:629,y:727,t:1527621198432};\\\", \\\"{x:628,y:729,t:1527621198450};\\\", \\\"{x:627,y:729,t:1527621198480};\\\", \\\"{x:626,y:729,t:1527621198520};\\\", \\\"{x:625,y:730,t:1527621198553};\\\", \\\"{x:625,y:731,t:1527621198650};\\\", \\\"{x:626,y:731,t:1527621198672};\\\", \\\"{x:625,y:732,t:1527621199289};\\\", \\\"{x:624,y:732,t:1527621199377};\\\", \\\"{x:624,y:733,t:1527621199384};\\\", \\\"{x:624,y:734,t:1527621199520};\\\", \\\"{x:624,y:735,t:1527621199531};\\\", \\\"{x:624,y:736,t:1527621199552};\\\", \\\"{x:624,y:737,t:1527621199577};\\\", \\\"{x:623,y:738,t:1527621199584};\\\", \\\"{x:621,y:739,t:1527621199865};\\\", \\\"{x:620,y:739,t:1527621199913};\\\", \\\"{x:619,y:739,t:1527621199928};\\\", \\\"{x:618,y:739,t:1527621199961};\\\", \\\"{x:617,y:738,t:1527621201896};\\\", \\\"{x:616,y:737,t:1527621201912};\\\", \\\"{x:616,y:736,t:1527621201928};\\\", \\\"{x:616,y:733,t:1527621201945};\\\", \\\"{x:616,y:731,t:1527621201952};\\\", \\\"{x:616,y:730,t:1527621201966};\\\", \\\"{x:616,y:729,t:1527621201992};\\\", \\\"{x:616,y:728,t:1527621202016};\\\", \\\"{x:616,y:727,t:1527621202050};\\\", \\\"{x:616,y:726,t:1527621202072};\\\", \\\"{x:615,y:725,t:1527621202083};\\\", \\\"{x:614,y:724,t:1527621202100};\\\", \\\"{x:611,y:721,t:1527621202116};\\\", \\\"{x:608,y:719,t:1527621202133};\\\", \\\"{x:608,y:718,t:1527621202149};\\\", \\\"{x:606,y:716,t:1527621202165};\\\", \\\"{x:606,y:715,t:1527621202182};\\\", \\\"{x:605,y:714,t:1527621202199};\\\", \\\"{x:604,y:712,t:1527621202217};\\\", \\\"{x:603,y:710,t:1527621202240};\\\", \\\"{x:603,y:708,t:1527621202250};\\\", \\\"{x:603,y:706,t:1527621202266};\\\", \\\"{x:601,y:702,t:1527621202283};\\\", \\\"{x:600,y:700,t:1527621202299};\\\", \\\"{x:599,y:698,t:1527621202316};\\\", \\\"{x:596,y:695,t:1527621202332};\\\", \\\"{x:591,y:692,t:1527621202349};\\\", \\\"{x:584,y:689,t:1527621202366};\\\", \\\"{x:579,y:686,t:1527621202383};\\\", \\\"{x:572,y:682,t:1527621202399};\\\", \\\"{x:566,y:680,t:1527621202416};\\\", \\\"{x:557,y:676,t:1527621202432};\\\", \\\"{x:545,y:671,t:1527621202450};\\\", \\\"{x:537,y:664,t:1527621202467};\\\", \\\"{x:526,y:654,t:1527621202482};\\\", \\\"{x:516,y:645,t:1527621202499};\\\", \\\"{x:508,y:635,t:1527621202516};\\\", \\\"{x:500,y:625,t:1527621202534};\\\", \\\"{x:495,y:616,t:1527621202550};\\\", \\\"{x:488,y:602,t:1527621202566};\\\", \\\"{x:474,y:580,t:1527621202584};\\\", \\\"{x:466,y:569,t:1527621202601};\\\", \\\"{x:457,y:559,t:1527621202619};\\\", \\\"{x:440,y:550,t:1527621202634};\\\", \\\"{x:414,y:539,t:1527621202651};\\\", \\\"{x:386,y:530,t:1527621202668};\\\", \\\"{x:368,y:526,t:1527621202684};\\\", \\\"{x:354,y:525,t:1527621202701};\\\", \\\"{x:336,y:525,t:1527621202718};\\\", \\\"{x:313,y:525,t:1527621202733};\\\", \\\"{x:292,y:523,t:1527621202752};\\\", \\\"{x:271,y:520,t:1527621202768};\\\", \\\"{x:263,y:520,t:1527621202784};\\\", \\\"{x:250,y:520,t:1527621202801};\\\", \\\"{x:240,y:520,t:1527621202818};\\\", \\\"{x:233,y:520,t:1527621202834};\\\", \\\"{x:228,y:521,t:1527621202851};\\\", \\\"{x:219,y:524,t:1527621202868};\\\", \\\"{x:211,y:526,t:1527621202887};\\\", \\\"{x:199,y:529,t:1527621202901};\\\", \\\"{x:192,y:530,t:1527621202918};\\\", \\\"{x:188,y:530,t:1527621202936};\\\", \\\"{x:184,y:530,t:1527621202951};\\\", \\\"{x:181,y:531,t:1527621202968};\\\", \\\"{x:179,y:532,t:1527621202985};\\\", \\\"{x:176,y:534,t:1527621203001};\\\", \\\"{x:171,y:535,t:1527621203018};\\\", \\\"{x:164,y:536,t:1527621203035};\\\", \\\"{x:159,y:537,t:1527621203051};\\\", \\\"{x:156,y:537,t:1527621203068};\\\", \\\"{x:154,y:538,t:1527621203085};\\\", \\\"{x:153,y:538,t:1527621203112};\\\", \\\"{x:152,y:538,t:1527621203185};\\\", \\\"{x:152,y:538,t:1527621203220};\\\", \\\"{x:151,y:539,t:1527621203248};\\\", \\\"{x:151,y:540,t:1527621203320};\\\", \\\"{x:151,y:544,t:1527621203335};\\\", \\\"{x:150,y:554,t:1527621203352};\\\", \\\"{x:152,y:563,t:1527621203369};\\\", \\\"{x:156,y:570,t:1527621203386};\\\", \\\"{x:162,y:580,t:1527621203402};\\\", \\\"{x:169,y:588,t:1527621203418};\\\", \\\"{x:181,y:605,t:1527621203436};\\\", \\\"{x:199,y:623,t:1527621203453};\\\", \\\"{x:221,y:642,t:1527621203469};\\\", \\\"{x:261,y:669,t:1527621203485};\\\", \\\"{x:290,y:690,t:1527621203502};\\\", \\\"{x:318,y:708,t:1527621203518};\\\", \\\"{x:341,y:721,t:1527621203535};\\\", \\\"{x:381,y:736,t:1527621203552};\\\", \\\"{x:410,y:745,t:1527621203568};\\\", \\\"{x:434,y:750,t:1527621203585};\\\", \\\"{x:464,y:755,t:1527621203602};\\\", \\\"{x:492,y:756,t:1527621203618};\\\", \\\"{x:511,y:756,t:1527621203635};\\\", \\\"{x:526,y:756,t:1527621203651};\\\", \\\"{x:531,y:756,t:1527621203668};\\\", \\\"{x:532,y:756,t:1527621203685};\\\", \\\"{x:533,y:756,t:1527621203728};\\\", \\\"{x:534,y:756,t:1527621203776};\\\", \\\"{x:534,y:755,t:1527621203792};\\\", \\\"{x:534,y:752,t:1527621203809};\\\", \\\"{x:534,y:750,t:1527621203818};\\\", \\\"{x:535,y:746,t:1527621203835};\\\", \\\"{x:536,y:744,t:1527621203852};\\\", \\\"{x:536,y:743,t:1527621203869};\\\", \\\"{x:536,y:742,t:1527621203885};\\\", \\\"{x:536,y:741,t:1527621203902};\\\", \\\"{x:537,y:739,t:1527621204393};\\\", \\\"{x:538,y:739,t:1527621204408};\\\", \\\"{x:539,y:739,t:1527621204424};\\\", \\\"{x:540,y:739,t:1527621204721};\\\", \\\"{x:539,y:739,t:1527621205143};\\\" ] }, { \\\"rt\\\": 43237, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 697490, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z -04 PM-04 PM-X -02 PM-03 PM-04 PM-04 PM-X -B -12 PM-F -B -12 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:748,t:1527621205311};\\\", \\\"{x:529,y:750,t:1527621205359};\\\", \\\"{x:528,y:751,t:1527621205370};\\\", \\\"{x:526,y:754,t:1527621205402};\\\", \\\"{x:524,y:755,t:1527621205420};\\\", \\\"{x:523,y:756,t:1527621205436};\\\", \\\"{x:522,y:757,t:1527621205454};\\\", \\\"{x:521,y:758,t:1527621205470};\\\", \\\"{x:518,y:759,t:1527621205486};\\\", \\\"{x:517,y:760,t:1527621205504};\\\", \\\"{x:516,y:761,t:1527621205520};\\\", \\\"{x:515,y:763,t:1527621205584};\\\", \\\"{x:515,y:765,t:1527621205912};\\\", \\\"{x:515,y:764,t:1527621206441};\\\", \\\"{x:515,y:762,t:1527621206489};\\\", \\\"{x:515,y:761,t:1527621206536};\\\", \\\"{x:514,y:760,t:1527621206584};\\\", \\\"{x:514,y:759,t:1527621206617};\\\", \\\"{x:513,y:758,t:1527621206704};\\\", \\\"{x:511,y:755,t:1527621206896};\\\", \\\"{x:511,y:756,t:1527621207561};\\\", \\\"{x:511,y:757,t:1527621207571};\\\", \\\"{x:512,y:760,t:1527621207589};\\\", \\\"{x:514,y:763,t:1527621207605};\\\", \\\"{x:514,y:764,t:1527621207622};\\\", \\\"{x:516,y:765,t:1527621207639};\\\", \\\"{x:518,y:766,t:1527621207656};\\\", \\\"{x:518,y:767,t:1527621207673};\\\", \\\"{x:519,y:767,t:1527621207689};\\\", \\\"{x:520,y:767,t:1527621207712};\\\", \\\"{x:520,y:768,t:1527621207721};\\\", \\\"{x:521,y:769,t:1527621207739};\\\", \\\"{x:522,y:771,t:1527621207755};\\\", \\\"{x:524,y:774,t:1527621207772};\\\", \\\"{x:525,y:778,t:1527621207789};\\\", \\\"{x:526,y:781,t:1527621207806};\\\", \\\"{x:528,y:784,t:1527621207821};\\\", \\\"{x:531,y:789,t:1527621207839};\\\", \\\"{x:533,y:794,t:1527621207856};\\\", \\\"{x:534,y:797,t:1527621207873};\\\", \\\"{x:535,y:801,t:1527621207888};\\\", \\\"{x:537,y:803,t:1527621207906};\\\", \\\"{x:538,y:806,t:1527621207922};\\\", \\\"{x:539,y:807,t:1527621207938};\\\", \\\"{x:540,y:809,t:1527621207956};\\\", \\\"{x:540,y:810,t:1527621207993};\\\", \\\"{x:541,y:811,t:1527621208032};\\\", \\\"{x:542,y:811,t:1527621209224};\\\", \\\"{x:543,y:810,t:1527621209248};\\\", \\\"{x:545,y:809,t:1527621209273};\\\", \\\"{x:547,y:809,t:1527621209296};\\\", \\\"{x:549,y:807,t:1527621209307};\\\", \\\"{x:552,y:806,t:1527621209323};\\\", \\\"{x:557,y:803,t:1527621209340};\\\", \\\"{x:563,y:801,t:1527621209357};\\\", \\\"{x:573,y:797,t:1527621209373};\\\", \\\"{x:581,y:793,t:1527621209390};\\\", \\\"{x:591,y:790,t:1527621209406};\\\", \\\"{x:608,y:789,t:1527621209423};\\\", \\\"{x:638,y:788,t:1527621209440};\\\", \\\"{x:670,y:788,t:1527621209456};\\\", \\\"{x:705,y:789,t:1527621209474};\\\", \\\"{x:751,y:798,t:1527621209490};\\\", \\\"{x:811,y:810,t:1527621209507};\\\", \\\"{x:865,y:821,t:1527621209524};\\\", \\\"{x:904,y:830,t:1527621209540};\\\", \\\"{x:931,y:835,t:1527621209556};\\\", \\\"{x:955,y:841,t:1527621209573};\\\", \\\"{x:973,y:846,t:1527621209590};\\\", \\\"{x:987,y:850,t:1527621209607};\\\", \\\"{x:1001,y:855,t:1527621209624};\\\", \\\"{x:1007,y:856,t:1527621209640};\\\", \\\"{x:1016,y:859,t:1527621209656};\\\", \\\"{x:1022,y:861,t:1527621209674};\\\", \\\"{x:1027,y:863,t:1527621209690};\\\", \\\"{x:1030,y:864,t:1527621209707};\\\", \\\"{x:1031,y:864,t:1527621209977};\\\", \\\"{x:1032,y:866,t:1527621210041};\\\", \\\"{x:1033,y:866,t:1527621210097};\\\", \\\"{x:1036,y:866,t:1527621210107};\\\", \\\"{x:1042,y:866,t:1527621210124};\\\", \\\"{x:1056,y:866,t:1527621210141};\\\", \\\"{x:1061,y:867,t:1527621210157};\\\", \\\"{x:1063,y:867,t:1527621210174};\\\", \\\"{x:1067,y:867,t:1527621210191};\\\", \\\"{x:1075,y:867,t:1527621210208};\\\", \\\"{x:1102,y:866,t:1527621210224};\\\", \\\"{x:1129,y:865,t:1527621210241};\\\", \\\"{x:1155,y:860,t:1527621210257};\\\", \\\"{x:1178,y:856,t:1527621210275};\\\", \\\"{x:1199,y:854,t:1527621210291};\\\", \\\"{x:1220,y:851,t:1527621210307};\\\", \\\"{x:1241,y:848,t:1527621210324};\\\", \\\"{x:1260,y:848,t:1527621210341};\\\", \\\"{x:1279,y:848,t:1527621210357};\\\", \\\"{x:1298,y:848,t:1527621210374};\\\", \\\"{x:1313,y:847,t:1527621210391};\\\", \\\"{x:1326,y:844,t:1527621210407};\\\", \\\"{x:1342,y:843,t:1527621210424};\\\", \\\"{x:1349,y:842,t:1527621210441};\\\", \\\"{x:1350,y:842,t:1527621210457};\\\", \\\"{x:1352,y:841,t:1527621210474};\\\", \\\"{x:1353,y:841,t:1527621210492};\\\", \\\"{x:1354,y:841,t:1527621210520};\\\", \\\"{x:1355,y:841,t:1527621210536};\\\", \\\"{x:1356,y:841,t:1527621210544};\\\", \\\"{x:1357,y:841,t:1527621210558};\\\", \\\"{x:1360,y:841,t:1527621210574};\\\", \\\"{x:1368,y:841,t:1527621210592};\\\", \\\"{x:1376,y:841,t:1527621210609};\\\", \\\"{x:1383,y:841,t:1527621210624};\\\", \\\"{x:1390,y:841,t:1527621210642};\\\", \\\"{x:1400,y:841,t:1527621210658};\\\", \\\"{x:1410,y:841,t:1527621210675};\\\", \\\"{x:1421,y:841,t:1527621210691};\\\", \\\"{x:1426,y:840,t:1527621210708};\\\", \\\"{x:1430,y:840,t:1527621210724};\\\", \\\"{x:1433,y:839,t:1527621210741};\\\", \\\"{x:1436,y:839,t:1527621210758};\\\", \\\"{x:1438,y:837,t:1527621210774};\\\", \\\"{x:1442,y:837,t:1527621210791};\\\", \\\"{x:1444,y:837,t:1527621210808};\\\", \\\"{x:1446,y:837,t:1527621210824};\\\", \\\"{x:1447,y:837,t:1527621211116};\\\", \\\"{x:1447,y:836,t:1527621211128};\\\", \\\"{x:1448,y:836,t:1527621211144};\\\", \\\"{x:1450,y:834,t:1527621211161};\\\", \\\"{x:1452,y:832,t:1527621211178};\\\", \\\"{x:1456,y:830,t:1527621211194};\\\", \\\"{x:1461,y:827,t:1527621211212};\\\", \\\"{x:1466,y:822,t:1527621211228};\\\", \\\"{x:1480,y:813,t:1527621211244};\\\", \\\"{x:1496,y:802,t:1527621211263};\\\", \\\"{x:1518,y:790,t:1527621211278};\\\", \\\"{x:1546,y:775,t:1527621211294};\\\", \\\"{x:1571,y:762,t:1527621211311};\\\", \\\"{x:1589,y:750,t:1527621211328};\\\", \\\"{x:1597,y:742,t:1527621211344};\\\", \\\"{x:1603,y:736,t:1527621211361};\\\", \\\"{x:1606,y:733,t:1527621211379};\\\", \\\"{x:1610,y:730,t:1527621211394};\\\", \\\"{x:1613,y:726,t:1527621211411};\\\", \\\"{x:1614,y:726,t:1527621211428};\\\", \\\"{x:1614,y:725,t:1527621211451};\\\", \\\"{x:1614,y:724,t:1527621211461};\\\", \\\"{x:1614,y:723,t:1527621211478};\\\", \\\"{x:1615,y:723,t:1527621211495};\\\", \\\"{x:1615,y:721,t:1527621211511};\\\", \\\"{x:1617,y:719,t:1527621211528};\\\", \\\"{x:1617,y:718,t:1527621211545};\\\", \\\"{x:1618,y:715,t:1527621211561};\\\", \\\"{x:1618,y:713,t:1527621211578};\\\", \\\"{x:1619,y:710,t:1527621211596};\\\", \\\"{x:1620,y:708,t:1527621211611};\\\", \\\"{x:1620,y:707,t:1527621211636};\\\", \\\"{x:1620,y:706,t:1527621211645};\\\", \\\"{x:1620,y:705,t:1527621211661};\\\", \\\"{x:1620,y:704,t:1527621211678};\\\", \\\"{x:1620,y:703,t:1527621211695};\\\", \\\"{x:1620,y:702,t:1527621211712};\\\", \\\"{x:1620,y:700,t:1527621211728};\\\", \\\"{x:1620,y:699,t:1527621211755};\\\", \\\"{x:1620,y:697,t:1527621211799};\\\", \\\"{x:1619,y:696,t:1527621211827};\\\", \\\"{x:1618,y:696,t:1527621211907};\\\", \\\"{x:1617,y:696,t:1527621211988};\\\", \\\"{x:1616,y:696,t:1527621213252};\\\", \\\"{x:1616,y:698,t:1527621213277};\\\", \\\"{x:1616,y:700,t:1527621213284};\\\", \\\"{x:1616,y:702,t:1527621213296};\\\", \\\"{x:1616,y:706,t:1527621213313};\\\", \\\"{x:1616,y:710,t:1527621213330};\\\", \\\"{x:1616,y:712,t:1527621213346};\\\", \\\"{x:1616,y:720,t:1527621213364};\\\", \\\"{x:1616,y:726,t:1527621213379};\\\", \\\"{x:1616,y:739,t:1527621213397};\\\", \\\"{x:1616,y:752,t:1527621213414};\\\", \\\"{x:1616,y:763,t:1527621213430};\\\", \\\"{x:1616,y:777,t:1527621213446};\\\", \\\"{x:1616,y:787,t:1527621213463};\\\", \\\"{x:1616,y:795,t:1527621213479};\\\", \\\"{x:1616,y:805,t:1527621213496};\\\", \\\"{x:1616,y:816,t:1527621213513};\\\", \\\"{x:1616,y:827,t:1527621213529};\\\", \\\"{x:1616,y:837,t:1527621213546};\\\", \\\"{x:1616,y:849,t:1527621213564};\\\", \\\"{x:1616,y:856,t:1527621213579};\\\", \\\"{x:1616,y:862,t:1527621213597};\\\", \\\"{x:1615,y:872,t:1527621213614};\\\", \\\"{x:1615,y:883,t:1527621213629};\\\", \\\"{x:1615,y:897,t:1527621213646};\\\", \\\"{x:1620,y:911,t:1527621213664};\\\", \\\"{x:1624,y:923,t:1527621213679};\\\", \\\"{x:1624,y:929,t:1527621213697};\\\", \\\"{x:1625,y:935,t:1527621213713};\\\", \\\"{x:1625,y:942,t:1527621213730};\\\", \\\"{x:1625,y:946,t:1527621213747};\\\", \\\"{x:1625,y:954,t:1527621213763};\\\", \\\"{x:1625,y:961,t:1527621213780};\\\", \\\"{x:1625,y:964,t:1527621213797};\\\", \\\"{x:1625,y:967,t:1527621213814};\\\", \\\"{x:1625,y:969,t:1527621213829};\\\", \\\"{x:1625,y:970,t:1527621213847};\\\", \\\"{x:1625,y:971,t:1527621213863};\\\", \\\"{x:1625,y:972,t:1527621213880};\\\", \\\"{x:1625,y:973,t:1527621213896};\\\", \\\"{x:1625,y:974,t:1527621213913};\\\", \\\"{x:1624,y:974,t:1527621214004};\\\", \\\"{x:1623,y:974,t:1527621214013};\\\", \\\"{x:1621,y:973,t:1527621214059};\\\", \\\"{x:1621,y:971,t:1527621214099};\\\", \\\"{x:1621,y:970,t:1527621214147};\\\", \\\"{x:1620,y:969,t:1527621214195};\\\", \\\"{x:1620,y:968,t:1527621214214};\\\", \\\"{x:1619,y:967,t:1527621214243};\\\", \\\"{x:1618,y:967,t:1527621214268};\\\", \\\"{x:1618,y:966,t:1527621214292};\\\", \\\"{x:1616,y:965,t:1527621214307};\\\", \\\"{x:1615,y:963,t:1527621214323};\\\", \\\"{x:1614,y:963,t:1527621214332};\\\", \\\"{x:1614,y:962,t:1527621214347};\\\", \\\"{x:1613,y:961,t:1527621214364};\\\", \\\"{x:1612,y:961,t:1527621215756};\\\", \\\"{x:1612,y:962,t:1527621215779};\\\", \\\"{x:1612,y:964,t:1527621215788};\\\", \\\"{x:1611,y:965,t:1527621215804};\\\", \\\"{x:1611,y:967,t:1527621215814};\\\", \\\"{x:1611,y:968,t:1527621215832};\\\", \\\"{x:1611,y:970,t:1527621215849};\\\", \\\"{x:1611,y:972,t:1527621215865};\\\", \\\"{x:1611,y:973,t:1527621215882};\\\", \\\"{x:1610,y:974,t:1527621215898};\\\", \\\"{x:1610,y:975,t:1527621215915};\\\", \\\"{x:1610,y:976,t:1527621215931};\\\", \\\"{x:1610,y:977,t:1527621216004};\\\", \\\"{x:1610,y:978,t:1527621216077};\\\", \\\"{x:1612,y:977,t:1527621216492};\\\", \\\"{x:1613,y:976,t:1527621216515};\\\", \\\"{x:1614,y:976,t:1527621216540};\\\", \\\"{x:1615,y:975,t:1527621216549};\\\", \\\"{x:1616,y:974,t:1527621216580};\\\", \\\"{x:1617,y:973,t:1527621216611};\\\", \\\"{x:1618,y:973,t:1527621216644};\\\", \\\"{x:1617,y:973,t:1527621219763};\\\", \\\"{x:1614,y:972,t:1527621219772};\\\", \\\"{x:1599,y:966,t:1527621219785};\\\", \\\"{x:1538,y:949,t:1527621219801};\\\", \\\"{x:1457,y:923,t:1527621219818};\\\", \\\"{x:1321,y:882,t:1527621219835};\\\", \\\"{x:1178,y:843,t:1527621219851};\\\", \\\"{x:957,y:782,t:1527621219867};\\\", \\\"{x:829,y:741,t:1527621219884};\\\", \\\"{x:718,y:708,t:1527621219901};\\\", \\\"{x:615,y:678,t:1527621219917};\\\", \\\"{x:529,y:649,t:1527621219934};\\\", \\\"{x:470,y:633,t:1527621219951};\\\", \\\"{x:433,y:620,t:1527621219969};\\\", \\\"{x:402,y:613,t:1527621219984};\\\", \\\"{x:385,y:609,t:1527621220000};\\\", \\\"{x:372,y:606,t:1527621220016};\\\", \\\"{x:357,y:598,t:1527621220033};\\\", \\\"{x:339,y:587,t:1527621220050};\\\", \\\"{x:313,y:574,t:1527621220068};\\\", \\\"{x:301,y:569,t:1527621220085};\\\", \\\"{x:299,y:567,t:1527621220100};\\\", \\\"{x:299,y:566,t:1527621220118};\\\", \\\"{x:298,y:565,t:1527621220135};\\\", \\\"{x:298,y:564,t:1527621220151};\\\", \\\"{x:298,y:563,t:1527621220170};\\\", \\\"{x:297,y:563,t:1527621220227};\\\", \\\"{x:296,y:563,t:1527621220234};\\\", \\\"{x:290,y:563,t:1527621220251};\\\", \\\"{x:280,y:566,t:1527621220268};\\\", \\\"{x:277,y:569,t:1527621220284};\\\", \\\"{x:275,y:571,t:1527621220301};\\\", \\\"{x:273,y:573,t:1527621220318};\\\", \\\"{x:270,y:575,t:1527621220336};\\\", \\\"{x:268,y:576,t:1527621220351};\\\", \\\"{x:265,y:578,t:1527621220368};\\\", \\\"{x:260,y:579,t:1527621220384};\\\", \\\"{x:256,y:583,t:1527621220401};\\\", \\\"{x:253,y:584,t:1527621220418};\\\", \\\"{x:252,y:585,t:1527621220434};\\\", \\\"{x:245,y:589,t:1527621220451};\\\", \\\"{x:237,y:592,t:1527621220468};\\\", \\\"{x:226,y:594,t:1527621220484};\\\", \\\"{x:216,y:597,t:1527621220501};\\\", \\\"{x:208,y:600,t:1527621220518};\\\", \\\"{x:200,y:603,t:1527621220536};\\\", \\\"{x:192,y:604,t:1527621220552};\\\", \\\"{x:181,y:608,t:1527621220570};\\\", \\\"{x:176,y:610,t:1527621220585};\\\", \\\"{x:167,y:612,t:1527621220603};\\\", \\\"{x:158,y:616,t:1527621220619};\\\", \\\"{x:154,y:618,t:1527621220636};\\\", \\\"{x:153,y:618,t:1527621220652};\\\", \\\"{x:153,y:619,t:1527621220730};\\\", \\\"{x:157,y:619,t:1527621220738};\\\", \\\"{x:166,y:618,t:1527621220752};\\\", \\\"{x:205,y:612,t:1527621220770};\\\", \\\"{x:266,y:612,t:1527621220786};\\\", \\\"{x:378,y:612,t:1527621220802};\\\", \\\"{x:444,y:612,t:1527621220819};\\\", \\\"{x:484,y:612,t:1527621220835};\\\", \\\"{x:505,y:612,t:1527621220853};\\\", \\\"{x:524,y:612,t:1527621220869};\\\", \\\"{x:536,y:612,t:1527621220885};\\\", \\\"{x:545,y:612,t:1527621220901};\\\", \\\"{x:558,y:612,t:1527621220919};\\\", \\\"{x:574,y:612,t:1527621220936};\\\", \\\"{x:591,y:608,t:1527621220953};\\\", \\\"{x:603,y:606,t:1527621220970};\\\", \\\"{x:608,y:602,t:1527621220986};\\\", \\\"{x:613,y:599,t:1527621221002};\\\", \\\"{x:633,y:594,t:1527621221019};\\\", \\\"{x:646,y:588,t:1527621221037};\\\", \\\"{x:657,y:582,t:1527621221052};\\\", \\\"{x:660,y:579,t:1527621221069};\\\", \\\"{x:660,y:576,t:1527621221086};\\\", \\\"{x:659,y:567,t:1527621221103};\\\", \\\"{x:651,y:562,t:1527621221119};\\\", \\\"{x:642,y:554,t:1527621221137};\\\", \\\"{x:638,y:550,t:1527621221152};\\\", \\\"{x:631,y:545,t:1527621221169};\\\", \\\"{x:627,y:542,t:1527621221186};\\\", \\\"{x:625,y:541,t:1527621221202};\\\", \\\"{x:622,y:540,t:1527621221219};\\\", \\\"{x:621,y:540,t:1527621221316};\\\", \\\"{x:619,y:541,t:1527621221323};\\\", \\\"{x:618,y:543,t:1527621221336};\\\", \\\"{x:618,y:549,t:1527621221354};\\\", \\\"{x:618,y:553,t:1527621221370};\\\", \\\"{x:618,y:555,t:1527621221386};\\\", \\\"{x:618,y:558,t:1527621221402};\\\", \\\"{x:618,y:560,t:1527621221419};\\\", \\\"{x:618,y:562,t:1527621221436};\\\", \\\"{x:618,y:563,t:1527621221454};\\\", \\\"{x:618,y:565,t:1527621221469};\\\", \\\"{x:618,y:566,t:1527621221486};\\\", \\\"{x:616,y:569,t:1527621221504};\\\", \\\"{x:616,y:570,t:1527621221519};\\\", \\\"{x:615,y:572,t:1527621221536};\\\", \\\"{x:616,y:573,t:1527621221835};\\\", \\\"{x:616,y:575,t:1527621221859};\\\", \\\"{x:617,y:577,t:1527621221871};\\\", \\\"{x:619,y:581,t:1527621221886};\\\", \\\"{x:620,y:584,t:1527621221904};\\\", \\\"{x:624,y:590,t:1527621221921};\\\", \\\"{x:631,y:597,t:1527621221937};\\\", \\\"{x:640,y:604,t:1527621221955};\\\", \\\"{x:646,y:609,t:1527621221970};\\\", \\\"{x:665,y:621,t:1527621221986};\\\", \\\"{x:680,y:632,t:1527621222003};\\\", \\\"{x:700,y:643,t:1527621222020};\\\", \\\"{x:726,y:656,t:1527621222036};\\\", \\\"{x:753,y:672,t:1527621222053};\\\", \\\"{x:779,y:683,t:1527621222070};\\\", \\\"{x:807,y:695,t:1527621222087};\\\", \\\"{x:836,y:704,t:1527621222103};\\\", \\\"{x:874,y:718,t:1527621222120};\\\", \\\"{x:908,y:729,t:1527621222137};\\\", \\\"{x:950,y:740,t:1527621222153};\\\", \\\"{x:997,y:754,t:1527621222170};\\\", \\\"{x:1080,y:775,t:1527621222187};\\\", \\\"{x:1133,y:783,t:1527621222204};\\\", \\\"{x:1184,y:791,t:1527621222221};\\\", \\\"{x:1229,y:798,t:1527621222238};\\\", \\\"{x:1276,y:804,t:1527621222254};\\\", \\\"{x:1304,y:808,t:1527621222271};\\\", \\\"{x:1332,y:812,t:1527621222287};\\\", \\\"{x:1350,y:815,t:1527621222304};\\\", \\\"{x:1362,y:817,t:1527621222320};\\\", \\\"{x:1377,y:817,t:1527621222338};\\\", \\\"{x:1390,y:817,t:1527621222354};\\\", \\\"{x:1409,y:817,t:1527621222371};\\\", \\\"{x:1420,y:817,t:1527621222387};\\\", \\\"{x:1429,y:817,t:1527621222404};\\\", \\\"{x:1437,y:816,t:1527621222421};\\\", \\\"{x:1443,y:815,t:1527621222437};\\\", \\\"{x:1449,y:815,t:1527621222454};\\\", \\\"{x:1456,y:813,t:1527621222472};\\\", \\\"{x:1461,y:812,t:1527621222487};\\\", \\\"{x:1464,y:812,t:1527621222504};\\\", \\\"{x:1466,y:812,t:1527621222522};\\\", \\\"{x:1470,y:812,t:1527621222538};\\\", \\\"{x:1475,y:812,t:1527621222554};\\\", \\\"{x:1483,y:815,t:1527621222571};\\\", \\\"{x:1486,y:817,t:1527621222588};\\\", \\\"{x:1486,y:819,t:1527621222605};\\\", \\\"{x:1487,y:824,t:1527621222622};\\\", \\\"{x:1489,y:830,t:1527621222639};\\\", \\\"{x:1490,y:836,t:1527621222655};\\\", \\\"{x:1491,y:840,t:1527621222672};\\\", \\\"{x:1491,y:842,t:1527621222688};\\\", \\\"{x:1491,y:843,t:1527621222772};\\\", \\\"{x:1490,y:843,t:1527621222789};\\\", \\\"{x:1487,y:843,t:1527621222805};\\\", \\\"{x:1484,y:843,t:1527621222821};\\\", \\\"{x:1482,y:842,t:1527621222908};\\\", \\\"{x:1482,y:841,t:1527621222922};\\\", \\\"{x:1481,y:841,t:1527621222939};\\\", \\\"{x:1481,y:840,t:1527621222956};\\\", \\\"{x:1482,y:842,t:1527621223292};\\\", \\\"{x:1482,y:845,t:1527621223306};\\\", \\\"{x:1484,y:849,t:1527621223323};\\\", \\\"{x:1485,y:854,t:1527621223339};\\\", \\\"{x:1485,y:857,t:1527621223357};\\\", \\\"{x:1485,y:859,t:1527621223373};\\\", \\\"{x:1485,y:860,t:1527621223390};\\\", \\\"{x:1485,y:862,t:1527621223407};\\\", \\\"{x:1484,y:864,t:1527621223423};\\\", \\\"{x:1484,y:865,t:1527621223439};\\\", \\\"{x:1483,y:867,t:1527621223456};\\\", \\\"{x:1482,y:869,t:1527621223473};\\\", \\\"{x:1482,y:871,t:1527621223490};\\\", \\\"{x:1480,y:874,t:1527621223506};\\\", \\\"{x:1480,y:877,t:1527621223522};\\\", \\\"{x:1479,y:880,t:1527621223540};\\\", \\\"{x:1479,y:887,t:1527621223556};\\\", \\\"{x:1479,y:891,t:1527621223574};\\\", \\\"{x:1479,y:897,t:1527621223589};\\\", \\\"{x:1479,y:902,t:1527621223606};\\\", \\\"{x:1482,y:906,t:1527621223623};\\\", \\\"{x:1485,y:912,t:1527621223639};\\\", \\\"{x:1489,y:915,t:1527621223656};\\\", \\\"{x:1496,y:922,t:1527621223673};\\\", \\\"{x:1502,y:927,t:1527621223690};\\\", \\\"{x:1506,y:930,t:1527621223707};\\\", \\\"{x:1508,y:932,t:1527621223723};\\\", \\\"{x:1509,y:932,t:1527621223748};\\\", \\\"{x:1509,y:933,t:1527621223757};\\\", \\\"{x:1517,y:935,t:1527621223773};\\\", \\\"{x:1523,y:937,t:1527621223790};\\\", \\\"{x:1530,y:939,t:1527621223807};\\\", \\\"{x:1537,y:939,t:1527621223824};\\\", \\\"{x:1539,y:939,t:1527621223841};\\\", \\\"{x:1540,y:939,t:1527621223857};\\\", \\\"{x:1541,y:940,t:1527621223876};\\\", \\\"{x:1541,y:941,t:1527621223907};\\\", \\\"{x:1541,y:942,t:1527621223939};\\\", \\\"{x:1539,y:945,t:1527621223958};\\\", \\\"{x:1537,y:946,t:1527621223974};\\\", \\\"{x:1536,y:947,t:1527621223991};\\\", \\\"{x:1535,y:948,t:1527621224011};\\\", \\\"{x:1533,y:948,t:1527621224027};\\\", \\\"{x:1529,y:948,t:1527621224040};\\\", \\\"{x:1520,y:948,t:1527621224058};\\\", \\\"{x:1513,y:951,t:1527621224076};\\\", \\\"{x:1511,y:953,t:1527621224091};\\\", \\\"{x:1509,y:955,t:1527621224107};\\\", \\\"{x:1507,y:955,t:1527621224125};\\\", \\\"{x:1506,y:957,t:1527621224141};\\\", \\\"{x:1506,y:958,t:1527621224157};\\\", \\\"{x:1505,y:961,t:1527621224175};\\\", \\\"{x:1502,y:963,t:1527621224191};\\\", \\\"{x:1499,y:966,t:1527621224208};\\\", \\\"{x:1494,y:969,t:1527621224225};\\\", \\\"{x:1488,y:972,t:1527621224241};\\\", \\\"{x:1484,y:974,t:1527621224258};\\\", \\\"{x:1478,y:977,t:1527621224276};\\\", \\\"{x:1477,y:978,t:1527621224292};\\\", \\\"{x:1477,y:979,t:1527621224308};\\\", \\\"{x:1476,y:979,t:1527621224325};\\\", \\\"{x:1476,y:980,t:1527621224371};\\\", \\\"{x:1475,y:980,t:1527621224404};\\\", \\\"{x:1475,y:979,t:1527621224548};\\\", \\\"{x:1475,y:977,t:1527621224563};\\\", \\\"{x:1475,y:976,t:1527621224575};\\\", \\\"{x:1475,y:975,t:1527621224595};\\\", \\\"{x:1475,y:973,t:1527621224609};\\\", \\\"{x:1476,y:973,t:1527621224626};\\\", \\\"{x:1476,y:972,t:1527621224643};\\\", \\\"{x:1476,y:971,t:1527621224659};\\\", \\\"{x:1476,y:968,t:1527621224676};\\\", \\\"{x:1477,y:967,t:1527621224692};\\\", \\\"{x:1478,y:965,t:1527621224724};\\\", \\\"{x:1478,y:964,t:1527621224772};\\\", \\\"{x:1478,y:963,t:1527621224780};\\\", \\\"{x:1478,y:961,t:1527621224796};\\\", \\\"{x:1479,y:961,t:1527621224809};\\\", \\\"{x:1479,y:960,t:1527621224844};\\\", \\\"{x:1480,y:960,t:1527621225258};\\\", \\\"{x:1482,y:960,t:1527621225276};\\\", \\\"{x:1483,y:961,t:1527621225282};\\\", \\\"{x:1488,y:962,t:1527621225293};\\\", \\\"{x:1499,y:966,t:1527621225310};\\\", \\\"{x:1509,y:967,t:1527621225326};\\\", \\\"{x:1518,y:968,t:1527621225343};\\\", \\\"{x:1528,y:970,t:1527621225360};\\\", \\\"{x:1538,y:971,t:1527621225377};\\\", \\\"{x:1547,y:971,t:1527621225394};\\\", \\\"{x:1553,y:972,t:1527621225409};\\\", \\\"{x:1565,y:972,t:1527621225427};\\\", \\\"{x:1575,y:974,t:1527621225444};\\\", \\\"{x:1582,y:974,t:1527621225460};\\\", \\\"{x:1588,y:974,t:1527621225476};\\\", \\\"{x:1596,y:974,t:1527621225494};\\\", \\\"{x:1603,y:975,t:1527621225510};\\\", \\\"{x:1608,y:975,t:1527621225526};\\\", \\\"{x:1612,y:975,t:1527621225544};\\\", \\\"{x:1615,y:975,t:1527621225561};\\\", \\\"{x:1617,y:975,t:1527621225577};\\\", \\\"{x:1618,y:975,t:1527621225620};\\\", \\\"{x:1619,y:974,t:1527621225651};\\\", \\\"{x:1620,y:974,t:1527621225660};\\\", \\\"{x:1620,y:973,t:1527621225677};\\\", \\\"{x:1621,y:972,t:1527621225694};\\\", \\\"{x:1622,y:971,t:1527621225723};\\\", \\\"{x:1622,y:970,t:1527621226020};\\\", \\\"{x:1622,y:969,t:1527621226060};\\\", \\\"{x:1622,y:968,t:1527621226116};\\\", \\\"{x:1621,y:968,t:1527621226420};\\\", \\\"{x:1621,y:969,t:1527621228244};\\\", \\\"{x:1620,y:969,t:1527621228268};\\\", \\\"{x:1619,y:970,t:1527621228307};\\\", \\\"{x:1619,y:971,t:1527621228363};\\\", \\\"{x:1619,y:972,t:1527621228419};\\\", \\\"{x:1618,y:972,t:1527621228492};\\\", \\\"{x:1617,y:972,t:1527621229379};\\\", \\\"{x:1616,y:971,t:1527621229428};\\\", \\\"{x:1615,y:970,t:1527621229580};\\\", \\\"{x:1615,y:969,t:1527621230380};\\\", \\\"{x:1614,y:968,t:1527621230444};\\\", \\\"{x:1613,y:968,t:1527621230532};\\\", \\\"{x:1612,y:967,t:1527621230548};\\\", \\\"{x:1612,y:966,t:1527621230556};\\\", \\\"{x:1612,y:965,t:1527621230570};\\\", \\\"{x:1611,y:964,t:1527621230586};\\\", \\\"{x:1609,y:961,t:1527621230604};\\\", \\\"{x:1609,y:960,t:1527621230620};\\\", \\\"{x:1607,y:957,t:1527621230637};\\\", \\\"{x:1606,y:955,t:1527621230653};\\\", \\\"{x:1606,y:954,t:1527621230676};\\\", \\\"{x:1606,y:953,t:1527621230700};\\\", \\\"{x:1606,y:952,t:1527621230707};\\\", \\\"{x:1605,y:951,t:1527621230720};\\\", \\\"{x:1604,y:950,t:1527621230737};\\\", \\\"{x:1603,y:947,t:1527621230754};\\\", \\\"{x:1601,y:943,t:1527621230770};\\\", \\\"{x:1591,y:930,t:1527621230787};\\\", \\\"{x:1582,y:917,t:1527621230803};\\\", \\\"{x:1570,y:903,t:1527621230820};\\\", \\\"{x:1551,y:886,t:1527621230837};\\\", \\\"{x:1533,y:872,t:1527621230854};\\\", \\\"{x:1521,y:860,t:1527621230870};\\\", \\\"{x:1505,y:848,t:1527621230887};\\\", \\\"{x:1492,y:836,t:1527621230904};\\\", \\\"{x:1478,y:827,t:1527621230920};\\\", \\\"{x:1472,y:823,t:1527621230938};\\\", \\\"{x:1471,y:822,t:1527621230955};\\\", \\\"{x:1466,y:819,t:1527621230971};\\\", \\\"{x:1453,y:809,t:1527621230988};\\\", \\\"{x:1434,y:800,t:1527621231004};\\\", \\\"{x:1429,y:799,t:1527621231020};\\\", \\\"{x:1428,y:799,t:1527621231042};\\\", \\\"{x:1427,y:799,t:1527621231054};\\\", \\\"{x:1424,y:798,t:1527621231071};\\\", \\\"{x:1421,y:797,t:1527621231086};\\\", \\\"{x:1412,y:794,t:1527621231104};\\\", \\\"{x:1395,y:789,t:1527621231121};\\\", \\\"{x:1371,y:783,t:1527621231137};\\\", \\\"{x:1350,y:779,t:1527621231154};\\\", \\\"{x:1341,y:778,t:1527621231170};\\\", \\\"{x:1340,y:777,t:1527621231188};\\\", \\\"{x:1339,y:777,t:1527621231227};\\\", \\\"{x:1338,y:776,t:1527621231238};\\\", \\\"{x:1337,y:775,t:1527621231254};\\\", \\\"{x:1336,y:775,t:1527621231271};\\\", \\\"{x:1335,y:774,t:1527621231288};\\\", \\\"{x:1334,y:773,t:1527621231331};\\\", \\\"{x:1333,y:772,t:1527621231339};\\\", \\\"{x:1332,y:772,t:1527621231355};\\\", \\\"{x:1330,y:770,t:1527621231372};\\\", \\\"{x:1330,y:769,t:1527621231564};\\\", \\\"{x:1332,y:768,t:1527621231595};\\\", \\\"{x:1335,y:767,t:1527621231605};\\\", \\\"{x:1340,y:766,t:1527621231622};\\\", \\\"{x:1348,y:763,t:1527621231639};\\\", \\\"{x:1355,y:761,t:1527621231656};\\\", \\\"{x:1361,y:761,t:1527621231672};\\\", \\\"{x:1365,y:759,t:1527621231687};\\\", \\\"{x:1365,y:758,t:1527621231707};\\\", \\\"{x:1366,y:758,t:1527621231723};\\\", \\\"{x:1367,y:758,t:1527621231755};\\\", \\\"{x:1368,y:758,t:1527621231786};\\\", \\\"{x:1369,y:758,t:1527621231803};\\\", \\\"{x:1371,y:758,t:1527621231859};\\\", \\\"{x:1371,y:759,t:1527621231907};\\\", \\\"{x:1371,y:760,t:1527621231972};\\\", \\\"{x:1369,y:761,t:1527621232020};\\\", \\\"{x:1369,y:762,t:1527621232035};\\\", \\\"{x:1368,y:762,t:1527621232044};\\\", \\\"{x:1367,y:763,t:1527621232060};\\\", \\\"{x:1366,y:763,t:1527621232072};\\\", \\\"{x:1364,y:764,t:1527621232089};\\\", \\\"{x:1362,y:765,t:1527621232106};\\\", \\\"{x:1362,y:766,t:1527621232123};\\\", \\\"{x:1361,y:767,t:1527621232139};\\\", \\\"{x:1360,y:768,t:1527621232170};\\\", \\\"{x:1359,y:768,t:1527621232202};\\\", \\\"{x:1359,y:770,t:1527621232235};\\\", \\\"{x:1358,y:772,t:1527621232300};\\\", \\\"{x:1358,y:773,t:1527621232332};\\\", \\\"{x:1358,y:774,t:1527621232339};\\\", \\\"{x:1358,y:778,t:1527621232356};\\\", \\\"{x:1358,y:784,t:1527621232373};\\\", \\\"{x:1357,y:792,t:1527621232390};\\\", \\\"{x:1356,y:802,t:1527621232406};\\\", \\\"{x:1355,y:814,t:1527621232423};\\\", \\\"{x:1353,y:822,t:1527621232441};\\\", \\\"{x:1352,y:831,t:1527621232456};\\\", \\\"{x:1348,y:846,t:1527621232473};\\\", \\\"{x:1346,y:853,t:1527621232490};\\\", \\\"{x:1343,y:865,t:1527621232507};\\\", \\\"{x:1342,y:870,t:1527621232523};\\\", \\\"{x:1339,y:874,t:1527621232540};\\\", \\\"{x:1339,y:877,t:1527621232557};\\\", \\\"{x:1339,y:880,t:1527621232573};\\\", \\\"{x:1340,y:883,t:1527621232590};\\\", \\\"{x:1340,y:885,t:1527621232607};\\\", \\\"{x:1340,y:887,t:1527621232623};\\\", \\\"{x:1341,y:893,t:1527621232640};\\\", \\\"{x:1343,y:897,t:1527621232657};\\\", \\\"{x:1344,y:901,t:1527621232674};\\\", \\\"{x:1346,y:905,t:1527621232691};\\\", \\\"{x:1347,y:910,t:1527621232707};\\\", \\\"{x:1349,y:917,t:1527621232723};\\\", \\\"{x:1350,y:920,t:1527621232740};\\\", \\\"{x:1352,y:924,t:1527621232757};\\\", \\\"{x:1353,y:926,t:1527621232774};\\\", \\\"{x:1354,y:929,t:1527621232791};\\\", \\\"{x:1354,y:931,t:1527621232808};\\\", \\\"{x:1354,y:935,t:1527621232825};\\\", \\\"{x:1355,y:938,t:1527621232842};\\\", \\\"{x:1355,y:940,t:1527621232857};\\\", \\\"{x:1355,y:944,t:1527621232874};\\\", \\\"{x:1355,y:948,t:1527621232891};\\\", \\\"{x:1355,y:953,t:1527621232908};\\\", \\\"{x:1355,y:955,t:1527621232924};\\\", \\\"{x:1357,y:960,t:1527621232941};\\\", \\\"{x:1357,y:961,t:1527621232957};\\\", \\\"{x:1357,y:963,t:1527621232974};\\\", \\\"{x:1357,y:965,t:1527621232992};\\\", \\\"{x:1357,y:968,t:1527621233009};\\\", \\\"{x:1357,y:969,t:1527621233024};\\\", \\\"{x:1357,y:972,t:1527621233041};\\\", \\\"{x:1357,y:973,t:1527621233059};\\\", \\\"{x:1357,y:975,t:1527621233091};\\\", \\\"{x:1357,y:976,t:1527621233124};\\\", \\\"{x:1356,y:976,t:1527621233141};\\\", \\\"{x:1355,y:976,t:1527621233204};\\\", \\\"{x:1354,y:976,t:1527621233412};\\\", \\\"{x:1352,y:976,t:1527621233427};\\\", \\\"{x:1351,y:976,t:1527621233442};\\\", \\\"{x:1349,y:976,t:1527621233467};\\\", \\\"{x:1348,y:976,t:1527621233483};\\\", \\\"{x:1347,y:976,t:1527621233492};\\\", \\\"{x:1346,y:976,t:1527621233604};\\\", \\\"{x:1345,y:976,t:1527621233683};\\\", \\\"{x:1345,y:975,t:1527621234403};\\\", \\\"{x:1345,y:972,t:1527621234419};\\\", \\\"{x:1344,y:970,t:1527621234428};\\\", \\\"{x:1343,y:965,t:1527621234444};\\\", \\\"{x:1343,y:951,t:1527621234460};\\\", \\\"{x:1343,y:937,t:1527621234477};\\\", \\\"{x:1340,y:921,t:1527621234494};\\\", \\\"{x:1339,y:896,t:1527621234511};\\\", \\\"{x:1338,y:873,t:1527621234528};\\\", \\\"{x:1337,y:850,t:1527621234544};\\\", \\\"{x:1337,y:839,t:1527621234560};\\\", \\\"{x:1337,y:831,t:1527621234577};\\\", \\\"{x:1337,y:826,t:1527621234595};\\\", \\\"{x:1337,y:819,t:1527621234611};\\\", \\\"{x:1335,y:809,t:1527621234628};\\\", \\\"{x:1335,y:803,t:1527621234645};\\\", \\\"{x:1335,y:801,t:1527621234661};\\\", \\\"{x:1335,y:797,t:1527621234678};\\\", \\\"{x:1335,y:794,t:1527621234695};\\\", \\\"{x:1335,y:788,t:1527621234711};\\\", \\\"{x:1335,y:778,t:1527621234727};\\\", \\\"{x:1335,y:772,t:1527621234745};\\\", \\\"{x:1335,y:763,t:1527621234761};\\\", \\\"{x:1335,y:756,t:1527621234778};\\\", \\\"{x:1335,y:747,t:1527621234795};\\\", \\\"{x:1335,y:741,t:1527621234811};\\\", \\\"{x:1335,y:737,t:1527621234827};\\\", \\\"{x:1335,y:733,t:1527621234845};\\\", \\\"{x:1335,y:729,t:1527621234861};\\\", \\\"{x:1335,y:726,t:1527621234879};\\\", \\\"{x:1335,y:722,t:1527621234895};\\\", \\\"{x:1335,y:719,t:1527621234911};\\\", \\\"{x:1335,y:717,t:1527621234928};\\\", \\\"{x:1335,y:716,t:1527621234945};\\\", \\\"{x:1335,y:715,t:1527621234962};\\\", \\\"{x:1335,y:713,t:1527621234979};\\\", \\\"{x:1335,y:712,t:1527621234994};\\\", \\\"{x:1335,y:710,t:1527621235012};\\\", \\\"{x:1336,y:709,t:1527621235028};\\\", \\\"{x:1337,y:708,t:1527621235068};\\\", \\\"{x:1337,y:707,t:1527621235106};\\\", \\\"{x:1338,y:707,t:1527621235123};\\\", \\\"{x:1338,y:706,t:1527621235178};\\\", \\\"{x:1339,y:705,t:1527621235234};\\\", \\\"{x:1340,y:704,t:1527621235251};\\\", \\\"{x:1341,y:703,t:1527621235299};\\\", \\\"{x:1341,y:702,t:1527621235395};\\\", \\\"{x:1343,y:702,t:1527621235467};\\\", \\\"{x:1344,y:701,t:1527621235499};\\\", \\\"{x:1346,y:701,t:1527621235531};\\\", \\\"{x:1347,y:700,t:1527621235562};\\\", \\\"{x:1349,y:700,t:1527621235595};\\\", \\\"{x:1350,y:700,t:1527621238075};\\\", \\\"{x:1350,y:701,t:1527621238083};\\\", \\\"{x:1350,y:712,t:1527621238100};\\\", \\\"{x:1350,y:723,t:1527621238117};\\\", \\\"{x:1349,y:740,t:1527621238134};\\\", \\\"{x:1344,y:765,t:1527621238151};\\\", \\\"{x:1342,y:788,t:1527621238167};\\\", \\\"{x:1339,y:810,t:1527621238184};\\\", \\\"{x:1334,y:834,t:1527621238200};\\\", \\\"{x:1333,y:848,t:1527621238217};\\\", \\\"{x:1333,y:858,t:1527621238234};\\\", \\\"{x:1333,y:867,t:1527621238251};\\\", \\\"{x:1333,y:880,t:1527621238267};\\\", \\\"{x:1333,y:886,t:1527621238285};\\\", \\\"{x:1333,y:893,t:1527621238301};\\\", \\\"{x:1331,y:904,t:1527621238318};\\\", \\\"{x:1329,y:913,t:1527621238335};\\\", \\\"{x:1329,y:921,t:1527621238351};\\\", \\\"{x:1329,y:926,t:1527621238368};\\\", \\\"{x:1329,y:931,t:1527621238385};\\\", \\\"{x:1329,y:933,t:1527621238402};\\\", \\\"{x:1330,y:939,t:1527621238418};\\\", \\\"{x:1330,y:942,t:1527621238434};\\\", \\\"{x:1333,y:948,t:1527621238451};\\\", \\\"{x:1333,y:953,t:1527621238468};\\\", \\\"{x:1334,y:958,t:1527621238485};\\\", \\\"{x:1336,y:962,t:1527621238501};\\\", \\\"{x:1338,y:967,t:1527621238519};\\\", \\\"{x:1338,y:969,t:1527621238534};\\\", \\\"{x:1339,y:970,t:1527621238551};\\\", \\\"{x:1340,y:972,t:1527621238569};\\\", \\\"{x:1340,y:973,t:1527621238584};\\\", \\\"{x:1341,y:974,t:1527621238602};\\\", \\\"{x:1342,y:975,t:1527621238619};\\\", \\\"{x:1343,y:976,t:1527621238683};\\\", \\\"{x:1344,y:976,t:1527621238770};\\\", \\\"{x:1345,y:976,t:1527621238785};\\\", \\\"{x:1346,y:976,t:1527621238900};\\\", \\\"{x:1346,y:975,t:1527621238923};\\\", \\\"{x:1347,y:975,t:1527621238947};\\\", \\\"{x:1349,y:975,t:1527621238971};\\\", \\\"{x:1349,y:974,t:1527621238985};\\\", \\\"{x:1351,y:973,t:1527621239003};\\\", \\\"{x:1361,y:970,t:1527621239019};\\\", \\\"{x:1370,y:968,t:1527621239036};\\\", \\\"{x:1379,y:966,t:1527621239052};\\\", \\\"{x:1386,y:962,t:1527621239070};\\\", \\\"{x:1391,y:960,t:1527621239086};\\\", \\\"{x:1393,y:959,t:1527621239102};\\\", \\\"{x:1396,y:959,t:1527621239120};\\\", \\\"{x:1400,y:958,t:1527621239136};\\\", \\\"{x:1402,y:957,t:1527621239153};\\\", \\\"{x:1406,y:956,t:1527621239169};\\\", \\\"{x:1408,y:956,t:1527621239186};\\\", \\\"{x:1411,y:956,t:1527621239203};\\\", \\\"{x:1413,y:956,t:1527621239252};\\\", \\\"{x:1414,y:956,t:1527621239323};\\\", \\\"{x:1415,y:957,t:1527621239444};\\\", \\\"{x:1416,y:957,t:1527621239483};\\\", \\\"{x:1417,y:957,t:1527621239491};\\\", \\\"{x:1419,y:957,t:1527621239508};\\\", \\\"{x:1421,y:957,t:1527621239520};\\\", \\\"{x:1426,y:957,t:1527621239537};\\\", \\\"{x:1429,y:957,t:1527621239554};\\\", \\\"{x:1433,y:957,t:1527621239569};\\\", \\\"{x:1436,y:957,t:1527621239586};\\\", \\\"{x:1440,y:957,t:1527621239604};\\\", \\\"{x:1441,y:957,t:1527621239620};\\\", \\\"{x:1443,y:957,t:1527621239637};\\\", \\\"{x:1444,y:957,t:1527621239653};\\\", \\\"{x:1446,y:957,t:1527621239671};\\\", \\\"{x:1447,y:957,t:1527621239686};\\\", \\\"{x:1449,y:957,t:1527621239704};\\\", \\\"{x:1450,y:957,t:1527621239721};\\\", \\\"{x:1452,y:958,t:1527621239737};\\\", \\\"{x:1454,y:958,t:1527621239754};\\\", \\\"{x:1455,y:959,t:1527621239771};\\\", \\\"{x:1455,y:960,t:1527621239788};\\\", \\\"{x:1456,y:960,t:1527621239804};\\\", \\\"{x:1458,y:960,t:1527621239851};\\\", \\\"{x:1459,y:961,t:1527621239915};\\\", \\\"{x:1460,y:962,t:1527621239947};\\\", \\\"{x:1461,y:962,t:1527621239963};\\\", \\\"{x:1462,y:963,t:1527621239988};\\\", \\\"{x:1464,y:963,t:1527621240005};\\\", \\\"{x:1469,y:963,t:1527621240021};\\\", \\\"{x:1478,y:966,t:1527621240038};\\\", \\\"{x:1486,y:966,t:1527621240055};\\\", \\\"{x:1492,y:967,t:1527621240071};\\\", \\\"{x:1497,y:968,t:1527621240088};\\\", \\\"{x:1500,y:968,t:1527621240105};\\\", \\\"{x:1505,y:968,t:1527621240121};\\\", \\\"{x:1509,y:968,t:1527621240138};\\\", \\\"{x:1515,y:968,t:1527621240155};\\\", \\\"{x:1523,y:968,t:1527621240172};\\\", \\\"{x:1526,y:968,t:1527621240188};\\\", \\\"{x:1531,y:968,t:1527621240205};\\\", \\\"{x:1534,y:969,t:1527621240222};\\\", \\\"{x:1537,y:971,t:1527621240238};\\\", \\\"{x:1538,y:971,t:1527621240255};\\\", \\\"{x:1539,y:971,t:1527621240272};\\\", \\\"{x:1540,y:971,t:1527621240299};\\\", \\\"{x:1541,y:971,t:1527621240308};\\\", \\\"{x:1542,y:972,t:1527621240323};\\\", \\\"{x:1543,y:972,t:1527621240355};\\\", \\\"{x:1544,y:972,t:1527621240420};\\\", \\\"{x:1545,y:972,t:1527621240435};\\\", \\\"{x:1547,y:972,t:1527621240443};\\\", \\\"{x:1548,y:972,t:1527621240455};\\\", \\\"{x:1551,y:973,t:1527621240472};\\\", \\\"{x:1557,y:973,t:1527621240488};\\\", \\\"{x:1563,y:973,t:1527621240506};\\\", \\\"{x:1569,y:973,t:1527621240522};\\\", \\\"{x:1574,y:974,t:1527621240539};\\\", \\\"{x:1586,y:977,t:1527621240555};\\\", \\\"{x:1595,y:977,t:1527621240572};\\\", \\\"{x:1605,y:979,t:1527621240588};\\\", \\\"{x:1612,y:979,t:1527621240605};\\\", \\\"{x:1617,y:979,t:1527621240622};\\\", \\\"{x:1623,y:979,t:1527621240639};\\\", \\\"{x:1624,y:979,t:1527621240656};\\\", \\\"{x:1627,y:979,t:1527621240672};\\\", \\\"{x:1628,y:979,t:1527621240716};\\\", \\\"{x:1629,y:979,t:1527621240747};\\\", \\\"{x:1630,y:979,t:1527621240860};\\\", \\\"{x:1629,y:978,t:1527621240971};\\\", \\\"{x:1628,y:977,t:1527621240990};\\\", \\\"{x:1626,y:976,t:1527621241005};\\\", \\\"{x:1626,y:975,t:1527621241059};\\\", \\\"{x:1625,y:975,t:1527621241091};\\\", \\\"{x:1625,y:974,t:1527621241396};\\\", \\\"{x:1624,y:974,t:1527621242956};\\\", \\\"{x:1623,y:974,t:1527621242995};\\\", \\\"{x:1621,y:974,t:1527621243010};\\\", \\\"{x:1618,y:974,t:1527621243027};\\\", \\\"{x:1617,y:974,t:1527621243043};\\\", \\\"{x:1616,y:973,t:1527621243060};\\\", \\\"{x:1615,y:972,t:1527621243131};\\\", \\\"{x:1614,y:972,t:1527621243155};\\\", \\\"{x:1613,y:971,t:1527621243268};\\\", \\\"{x:1612,y:971,t:1527621243395};\\\", \\\"{x:1608,y:968,t:1527621243411};\\\", \\\"{x:1591,y:957,t:1527621243427};\\\", \\\"{x:1550,y:938,t:1527621243444};\\\", \\\"{x:1456,y:896,t:1527621243461};\\\", \\\"{x:1343,y:850,t:1527621243478};\\\", \\\"{x:1241,y:805,t:1527621243494};\\\", \\\"{x:1146,y:755,t:1527621243511};\\\", \\\"{x:1029,y:717,t:1527621243528};\\\", \\\"{x:924,y:687,t:1527621243544};\\\", \\\"{x:838,y:664,t:1527621243561};\\\", \\\"{x:793,y:649,t:1527621243578};\\\", \\\"{x:749,y:630,t:1527621243597};\\\", \\\"{x:743,y:627,t:1527621243610};\\\", \\\"{x:739,y:622,t:1527621243627};\\\", \\\"{x:733,y:614,t:1527621243646};\\\", \\\"{x:720,y:604,t:1527621243664};\\\", \\\"{x:697,y:592,t:1527621243680};\\\", \\\"{x:653,y:576,t:1527621243704};\\\", \\\"{x:623,y:569,t:1527621243722};\\\", \\\"{x:607,y:566,t:1527621243737};\\\", \\\"{x:596,y:565,t:1527621243754};\\\", \\\"{x:591,y:564,t:1527621243771};\\\", \\\"{x:585,y:562,t:1527621243787};\\\", \\\"{x:581,y:561,t:1527621243804};\\\", \\\"{x:578,y:561,t:1527621243821};\\\", \\\"{x:577,y:561,t:1527621243858};\\\", \\\"{x:576,y:561,t:1527621243871};\\\", \\\"{x:571,y:561,t:1527621243888};\\\", \\\"{x:562,y:562,t:1527621243904};\\\", \\\"{x:548,y:564,t:1527621243922};\\\", \\\"{x:526,y:567,t:1527621243939};\\\", \\\"{x:519,y:567,t:1527621243955};\\\", \\\"{x:516,y:567,t:1527621243970};\\\", \\\"{x:511,y:567,t:1527621243987};\\\", \\\"{x:504,y:567,t:1527621244004};\\\", \\\"{x:486,y:567,t:1527621244023};\\\", \\\"{x:459,y:567,t:1527621244038};\\\", \\\"{x:423,y:567,t:1527621244055};\\\", \\\"{x:381,y:567,t:1527621244072};\\\", \\\"{x:339,y:567,t:1527621244088};\\\", \\\"{x:307,y:567,t:1527621244104};\\\", \\\"{x:278,y:565,t:1527621244121};\\\", \\\"{x:248,y:559,t:1527621244138};\\\", \\\"{x:233,y:556,t:1527621244154};\\\", \\\"{x:225,y:556,t:1527621244171};\\\", \\\"{x:220,y:556,t:1527621244188};\\\", \\\"{x:216,y:556,t:1527621244204};\\\", \\\"{x:210,y:556,t:1527621244221};\\\", \\\"{x:202,y:556,t:1527621244238};\\\", \\\"{x:197,y:556,t:1527621244254};\\\", \\\"{x:196,y:556,t:1527621244271};\\\", \\\"{x:194,y:556,t:1527621244289};\\\", \\\"{x:193,y:557,t:1527621244304};\\\", \\\"{x:192,y:559,t:1527621244321};\\\", \\\"{x:188,y:560,t:1527621244338};\\\", \\\"{x:186,y:565,t:1527621244356};\\\", \\\"{x:186,y:571,t:1527621244371};\\\", \\\"{x:187,y:583,t:1527621244388};\\\", \\\"{x:188,y:593,t:1527621244405};\\\", \\\"{x:189,y:601,t:1527621244422};\\\", \\\"{x:189,y:607,t:1527621244438};\\\", \\\"{x:189,y:610,t:1527621244454};\\\", \\\"{x:192,y:615,t:1527621244471};\\\", \\\"{x:194,y:618,t:1527621244489};\\\", \\\"{x:197,y:624,t:1527621244505};\\\", \\\"{x:201,y:629,t:1527621244521};\\\", \\\"{x:205,y:632,t:1527621244539};\\\", \\\"{x:205,y:633,t:1527621244556};\\\", \\\"{x:207,y:633,t:1527621244618};\\\", \\\"{x:210,y:633,t:1527621244627};\\\", \\\"{x:215,y:633,t:1527621244638};\\\", \\\"{x:233,y:633,t:1527621244655};\\\", \\\"{x:257,y:626,t:1527621244672};\\\", \\\"{x:297,y:619,t:1527621244689};\\\", \\\"{x:322,y:612,t:1527621244705};\\\", \\\"{x:350,y:601,t:1527621244722};\\\", \\\"{x:369,y:596,t:1527621244739};\\\", \\\"{x:375,y:594,t:1527621244756};\\\", \\\"{x:382,y:590,t:1527621244773};\\\", \\\"{x:385,y:589,t:1527621244789};\\\", \\\"{x:387,y:588,t:1527621244805};\\\", \\\"{x:387,y:587,t:1527621244822};\\\", \\\"{x:389,y:587,t:1527621244838};\\\", \\\"{x:390,y:586,t:1527621244855};\\\", \\\"{x:393,y:583,t:1527621244872};\\\", \\\"{x:395,y:580,t:1527621244888};\\\", \\\"{x:399,y:575,t:1527621244905};\\\", \\\"{x:418,y:566,t:1527621244922};\\\", \\\"{x:454,y:557,t:1527621244939};\\\", \\\"{x:493,y:557,t:1527621244955};\\\", \\\"{x:544,y:557,t:1527621244972};\\\", \\\"{x:594,y:556,t:1527621244989};\\\", \\\"{x:636,y:556,t:1527621245005};\\\", \\\"{x:668,y:556,t:1527621245023};\\\", \\\"{x:685,y:556,t:1527621245038};\\\", \\\"{x:691,y:556,t:1527621245056};\\\", \\\"{x:692,y:556,t:1527621245072};\\\", \\\"{x:693,y:555,t:1527621245203};\\\", \\\"{x:696,y:555,t:1527621245210};\\\", \\\"{x:703,y:555,t:1527621245222};\\\", \\\"{x:725,y:555,t:1527621245239};\\\", \\\"{x:748,y:555,t:1527621245255};\\\", \\\"{x:765,y:555,t:1527621245273};\\\", \\\"{x:780,y:554,t:1527621245289};\\\", \\\"{x:788,y:552,t:1527621245305};\\\", \\\"{x:792,y:552,t:1527621245322};\\\", \\\"{x:796,y:552,t:1527621245338};\\\", \\\"{x:809,y:553,t:1527621245355};\\\", \\\"{x:823,y:554,t:1527621245372};\\\", \\\"{x:831,y:554,t:1527621245390};\\\", \\\"{x:835,y:552,t:1527621245406};\\\", \\\"{x:836,y:549,t:1527621245423};\\\", \\\"{x:837,y:542,t:1527621245439};\\\", \\\"{x:837,y:536,t:1527621245455};\\\", \\\"{x:837,y:533,t:1527621245472};\\\", \\\"{x:837,y:530,t:1527621245490};\\\", \\\"{x:837,y:527,t:1527621245505};\\\", \\\"{x:837,y:523,t:1527621245522};\\\", \\\"{x:837,y:519,t:1527621245540};\\\", \\\"{x:837,y:516,t:1527621245556};\\\", \\\"{x:837,y:513,t:1527621245573};\\\", \\\"{x:837,y:510,t:1527621245589};\\\", \\\"{x:837,y:509,t:1527621245610};\\\", \\\"{x:837,y:508,t:1527621245651};\\\", \\\"{x:837,y:513,t:1527621246044};\\\", \\\"{x:837,y:515,t:1527621246057};\\\", \\\"{x:838,y:521,t:1527621246073};\\\", \\\"{x:840,y:531,t:1527621246090};\\\", \\\"{x:842,y:549,t:1527621246106};\\\", \\\"{x:842,y:557,t:1527621246122};\\\", \\\"{x:844,y:564,t:1527621246139};\\\", \\\"{x:845,y:572,t:1527621246157};\\\", \\\"{x:845,y:580,t:1527621246172};\\\", \\\"{x:845,y:586,t:1527621246189};\\\", \\\"{x:845,y:595,t:1527621246207};\\\", \\\"{x:843,y:604,t:1527621246224};\\\", \\\"{x:838,y:614,t:1527621246239};\\\", \\\"{x:830,y:625,t:1527621246256};\\\", \\\"{x:823,y:638,t:1527621246273};\\\", \\\"{x:810,y:653,t:1527621246290};\\\", \\\"{x:804,y:659,t:1527621246307};\\\", \\\"{x:797,y:665,t:1527621246323};\\\", \\\"{x:790,y:672,t:1527621246340};\\\", \\\"{x:785,y:678,t:1527621246356};\\\", \\\"{x:779,y:683,t:1527621246374};\\\", \\\"{x:774,y:689,t:1527621246389};\\\", \\\"{x:771,y:692,t:1527621246406};\\\", \\\"{x:770,y:693,t:1527621246423};\\\", \\\"{x:768,y:694,t:1527621246440};\\\", \\\"{x:766,y:696,t:1527621246456};\\\", \\\"{x:764,y:697,t:1527621246473};\\\", \\\"{x:761,y:699,t:1527621246489};\\\", \\\"{x:754,y:703,t:1527621246507};\\\", \\\"{x:753,y:704,t:1527621246523};\\\", \\\"{x:754,y:703,t:1527621246827};\\\", \\\"{x:755,y:701,t:1527621246841};\\\", \\\"{x:757,y:697,t:1527621246857};\\\", \\\"{x:758,y:690,t:1527621246873};\\\", \\\"{x:763,y:665,t:1527621246892};\\\", \\\"{x:762,y:666,t:1527621247844};\\\", \\\"{x:761,y:674,t:1527621247858};\\\", \\\"{x:749,y:684,t:1527621247877};\\\", \\\"{x:742,y:685,t:1527621247891};\\\", \\\"{x:737,y:687,t:1527621247908};\\\", \\\"{x:734,y:688,t:1527621247925};\\\", \\\"{x:732,y:689,t:1527621247942};\\\", \\\"{x:725,y:693,t:1527621247957};\\\", \\\"{x:718,y:695,t:1527621247974};\\\", \\\"{x:709,y:700,t:1527621247992};\\\", \\\"{x:696,y:705,t:1527621248008};\\\", \\\"{x:681,y:709,t:1527621248025};\\\", \\\"{x:672,y:712,t:1527621248042};\\\", \\\"{x:663,y:716,t:1527621248058};\\\", \\\"{x:649,y:721,t:1527621248076};\\\", \\\"{x:642,y:725,t:1527621248091};\\\", \\\"{x:638,y:726,t:1527621248108};\\\", \\\"{x:635,y:728,t:1527621248125};\\\", \\\"{x:633,y:729,t:1527621248142};\\\", \\\"{x:628,y:729,t:1527621248158};\\\", \\\"{x:617,y:730,t:1527621248175};\\\", \\\"{x:603,y:730,t:1527621248192};\\\", \\\"{x:594,y:730,t:1527621248208};\\\", \\\"{x:584,y:730,t:1527621248225};\\\", \\\"{x:578,y:730,t:1527621248242};\\\", \\\"{x:572,y:730,t:1527621248258};\\\", \\\"{x:561,y:732,t:1527621248277};\\\", \\\"{x:555,y:732,t:1527621248292};\\\", \\\"{x:548,y:732,t:1527621248308};\\\", \\\"{x:542,y:732,t:1527621248324};\\\", \\\"{x:539,y:732,t:1527621248341};\\\", \\\"{x:538,y:732,t:1527621248358};\\\", \\\"{x:536,y:732,t:1527621248375};\\\", \\\"{x:535,y:732,t:1527621249139};\\\", \\\"{x:535,y:730,t:1527621249211};\\\", \\\"{x:535,y:729,t:1527621249235};\\\", \\\"{x:535,y:727,t:1527621249243};\\\", \\\"{x:535,y:725,t:1527621249258};\\\", \\\"{x:535,y:724,t:1527621249275};\\\", \\\"{x:535,y:723,t:1527621249293};\\\", \\\"{x:535,y:722,t:1527621249309};\\\", \\\"{x:535,y:721,t:1527621249326};\\\", \\\"{x:535,y:720,t:1527621249388};\\\" ] }, { \\\"rt\\\": 78663, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 777379, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-04 PM-F -F -F -B -12 PM-12 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:719,t:1527621250412};\\\", \\\"{x:537,y:719,t:1527621250428};\\\", \\\"{x:538,y:718,t:1527621250458};\\\", \\\"{x:538,y:717,t:1527621250491};\\\", \\\"{x:539,y:717,t:1527621250499};\\\", \\\"{x:540,y:716,t:1527621250510};\\\", \\\"{x:542,y:714,t:1527621250526};\\\", \\\"{x:544,y:712,t:1527621250547};\\\", \\\"{x:546,y:710,t:1527621250603};\\\", \\\"{x:547,y:709,t:1527621250611};\\\", \\\"{x:552,y:708,t:1527621250627};\\\", \\\"{x:557,y:707,t:1527621250644};\\\", \\\"{x:564,y:705,t:1527621250660};\\\", \\\"{x:571,y:703,t:1527621250677};\\\", \\\"{x:574,y:702,t:1527621250694};\\\", \\\"{x:574,y:701,t:1527621250710};\\\", \\\"{x:575,y:701,t:1527621250727};\\\", \\\"{x:577,y:701,t:1527621250744};\\\", \\\"{x:578,y:701,t:1527621250760};\\\", \\\"{x:579,y:701,t:1527621250787};\\\", \\\"{x:579,y:700,t:1527621251491};\\\", \\\"{x:579,y:699,t:1527621251499};\\\", \\\"{x:582,y:698,t:1527621251675};\\\", \\\"{x:585,y:695,t:1527621251691};\\\", \\\"{x:586,y:695,t:1527621251699};\\\", \\\"{x:589,y:692,t:1527621251711};\\\", \\\"{x:595,y:691,t:1527621251728};\\\", \\\"{x:598,y:689,t:1527621251745};\\\", \\\"{x:601,y:688,t:1527621251761};\\\", \\\"{x:605,y:687,t:1527621251778};\\\", \\\"{x:613,y:685,t:1527621251795};\\\", \\\"{x:621,y:685,t:1527621251811};\\\", \\\"{x:632,y:684,t:1527621251829};\\\", \\\"{x:642,y:683,t:1527621251844};\\\", \\\"{x:651,y:683,t:1527621251861};\\\", \\\"{x:661,y:683,t:1527621251878};\\\", \\\"{x:674,y:683,t:1527621251895};\\\", \\\"{x:691,y:683,t:1527621251911};\\\", \\\"{x:713,y:683,t:1527621251928};\\\", \\\"{x:734,y:683,t:1527621251945};\\\", \\\"{x:756,y:683,t:1527621251961};\\\", \\\"{x:772,y:683,t:1527621251978};\\\", \\\"{x:792,y:683,t:1527621251995};\\\", \\\"{x:803,y:683,t:1527621252011};\\\", \\\"{x:809,y:683,t:1527621252028};\\\", \\\"{x:812,y:683,t:1527621252045};\\\", \\\"{x:813,y:683,t:1527621252075};\\\", \\\"{x:814,y:685,t:1527621252107};\\\", \\\"{x:814,y:686,t:1527621252123};\\\", \\\"{x:814,y:687,t:1527621252138};\\\", \\\"{x:814,y:689,t:1527621252146};\\\", \\\"{x:814,y:690,t:1527621252161};\\\", \\\"{x:811,y:695,t:1527621252178};\\\", \\\"{x:806,y:701,t:1527621252194};\\\", \\\"{x:803,y:703,t:1527621252210};\\\", \\\"{x:801,y:705,t:1527621252227};\\\", \\\"{x:799,y:707,t:1527621252244};\\\", \\\"{x:798,y:707,t:1527621252266};\\\", \\\"{x:797,y:708,t:1527621252283};\\\", \\\"{x:796,y:708,t:1527621252314};\\\", \\\"{x:795,y:708,t:1527621252339};\\\", \\\"{x:794,y:708,t:1527621252380};\\\", \\\"{x:793,y:708,t:1527621252411};\\\", \\\"{x:792,y:708,t:1527621252443};\\\", \\\"{x:791,y:708,t:1527621252508};\\\", \\\"{x:792,y:708,t:1527621252787};\\\", \\\"{x:794,y:708,t:1527621252795};\\\", \\\"{x:802,y:708,t:1527621252812};\\\", \\\"{x:812,y:707,t:1527621252829};\\\", \\\"{x:819,y:707,t:1527621252845};\\\", \\\"{x:830,y:706,t:1527621252862};\\\", \\\"{x:846,y:703,t:1527621252879};\\\", \\\"{x:858,y:701,t:1527621252895};\\\", \\\"{x:868,y:701,t:1527621252912};\\\", \\\"{x:878,y:701,t:1527621252929};\\\", \\\"{x:887,y:701,t:1527621252945};\\\", \\\"{x:894,y:701,t:1527621252962};\\\", \\\"{x:901,y:701,t:1527621252980};\\\", \\\"{x:910,y:701,t:1527621252995};\\\", \\\"{x:919,y:705,t:1527621253012};\\\", \\\"{x:934,y:711,t:1527621253029};\\\", \\\"{x:953,y:717,t:1527621253045};\\\", \\\"{x:980,y:725,t:1527621253062};\\\", \\\"{x:1006,y:737,t:1527621253080};\\\", \\\"{x:1030,y:750,t:1527621253095};\\\", \\\"{x:1048,y:761,t:1527621253112};\\\", \\\"{x:1066,y:774,t:1527621253130};\\\", \\\"{x:1076,y:785,t:1527621253145};\\\", \\\"{x:1083,y:800,t:1527621253162};\\\", \\\"{x:1087,y:822,t:1527621253180};\\\", \\\"{x:1087,y:835,t:1527621253195};\\\", \\\"{x:1085,y:846,t:1527621253212};\\\", \\\"{x:1076,y:856,t:1527621253229};\\\", \\\"{x:1069,y:869,t:1527621253246};\\\", \\\"{x:1059,y:885,t:1527621253263};\\\", \\\"{x:1050,y:901,t:1527621253279};\\\", \\\"{x:1048,y:908,t:1527621253296};\\\", \\\"{x:1048,y:911,t:1527621253312};\\\", \\\"{x:1049,y:918,t:1527621253329};\\\", \\\"{x:1050,y:921,t:1527621253346};\\\", \\\"{x:1051,y:923,t:1527621253362};\\\", \\\"{x:1051,y:925,t:1527621253387};\\\", \\\"{x:1053,y:925,t:1527621253396};\\\", \\\"{x:1056,y:929,t:1527621253427};\\\", \\\"{x:1058,y:929,t:1527621253435};\\\", \\\"{x:1060,y:930,t:1527621253483};\\\", \\\"{x:1067,y:931,t:1527621253497};\\\", \\\"{x:1087,y:940,t:1527621253513};\\\", \\\"{x:1121,y:951,t:1527621253529};\\\", \\\"{x:1151,y:959,t:1527621253546};\\\", \\\"{x:1194,y:968,t:1527621253563};\\\", \\\"{x:1251,y:973,t:1527621253579};\\\", \\\"{x:1278,y:973,t:1527621253597};\\\", \\\"{x:1314,y:973,t:1527621253613};\\\", \\\"{x:1350,y:973,t:1527621253629};\\\", \\\"{x:1381,y:973,t:1527621253647};\\\", \\\"{x:1403,y:973,t:1527621253663};\\\", \\\"{x:1419,y:973,t:1527621253679};\\\", \\\"{x:1437,y:972,t:1527621253697};\\\", \\\"{x:1447,y:971,t:1527621253713};\\\", \\\"{x:1454,y:971,t:1527621253729};\\\", \\\"{x:1470,y:971,t:1527621253746};\\\", \\\"{x:1504,y:971,t:1527621253763};\\\", \\\"{x:1519,y:971,t:1527621253781};\\\", \\\"{x:1533,y:973,t:1527621253796};\\\", \\\"{x:1541,y:974,t:1527621253814};\\\", \\\"{x:1545,y:975,t:1527621253829};\\\", \\\"{x:1546,y:975,t:1527621255027};\\\", \\\"{x:1547,y:975,t:1527621255035};\\\", \\\"{x:1548,y:975,t:1527621255048};\\\", \\\"{x:1550,y:975,t:1527621255067};\\\", \\\"{x:1552,y:974,t:1527621255080};\\\", \\\"{x:1555,y:973,t:1527621255097};\\\", \\\"{x:1559,y:971,t:1527621255114};\\\", \\\"{x:1562,y:969,t:1527621255131};\\\", \\\"{x:1566,y:967,t:1527621255148};\\\", \\\"{x:1568,y:966,t:1527621255164};\\\", \\\"{x:1569,y:966,t:1527621255195};\\\", \\\"{x:1572,y:966,t:1527621255202};\\\", \\\"{x:1577,y:966,t:1527621255214};\\\", \\\"{x:1594,y:973,t:1527621255230};\\\", \\\"{x:1610,y:978,t:1527621255247};\\\", \\\"{x:1622,y:981,t:1527621255263};\\\", \\\"{x:1627,y:984,t:1527621255279};\\\", \\\"{x:1629,y:985,t:1527621255296};\\\", \\\"{x:1630,y:986,t:1527621255322};\\\", \\\"{x:1628,y:986,t:1527621255419};\\\", \\\"{x:1626,y:986,t:1527621255431};\\\", \\\"{x:1624,y:984,t:1527621255447};\\\", \\\"{x:1620,y:982,t:1527621255464};\\\", \\\"{x:1610,y:979,t:1527621255481};\\\", \\\"{x:1590,y:973,t:1527621255498};\\\", \\\"{x:1570,y:971,t:1527621255514};\\\", \\\"{x:1554,y:968,t:1527621255531};\\\", \\\"{x:1551,y:968,t:1527621255548};\\\", \\\"{x:1550,y:968,t:1527621255565};\\\", \\\"{x:1549,y:967,t:1527621255747};\\\", \\\"{x:1549,y:966,t:1527621255787};\\\", \\\"{x:1549,y:965,t:1527621255797};\\\", \\\"{x:1549,y:964,t:1527621255827};\\\", \\\"{x:1549,y:963,t:1527621255835};\\\", \\\"{x:1549,y:962,t:1527621255847};\\\", \\\"{x:1549,y:961,t:1527621255883};\\\", \\\"{x:1549,y:960,t:1527621255907};\\\", \\\"{x:1549,y:959,t:1527621255932};\\\", \\\"{x:1549,y:958,t:1527621255987};\\\", \\\"{x:1549,y:957,t:1527621256011};\\\", \\\"{x:1549,y:956,t:1527621256019};\\\", \\\"{x:1548,y:956,t:1527621256099};\\\", \\\"{x:1547,y:956,t:1527621256796};\\\", \\\"{x:1546,y:957,t:1527621256875};\\\", \\\"{x:1545,y:957,t:1527621256981};\\\", \\\"{x:1546,y:959,t:1527621260475};\\\", \\\"{x:1547,y:959,t:1527621260485};\\\", \\\"{x:1548,y:960,t:1527621260507};\\\", \\\"{x:1550,y:960,t:1527621260539};\\\", \\\"{x:1551,y:961,t:1527621260724};\\\", \\\"{x:1551,y:962,t:1527621265756};\\\", \\\"{x:1551,y:963,t:1527621265788};\\\", \\\"{x:1550,y:964,t:1527621266283};\\\", \\\"{x:1533,y:962,t:1527621304912};\\\", \\\"{x:1429,y:946,t:1527621304924};\\\", \\\"{x:1184,y:920,t:1527621304940};\\\", \\\"{x:990,y:913,t:1527621304957};\\\", \\\"{x:807,y:913,t:1527621304974};\\\", \\\"{x:691,y:913,t:1527621304989};\\\", \\\"{x:590,y:909,t:1527621305006};\\\", \\\"{x:527,y:903,t:1527621305024};\\\", \\\"{x:496,y:898,t:1527621305040};\\\", \\\"{x:483,y:896,t:1527621305057};\\\", \\\"{x:481,y:894,t:1527621305073};\\\", \\\"{x:481,y:885,t:1527621305090};\\\", \\\"{x:485,y:867,t:1527621305107};\\\", \\\"{x:485,y:847,t:1527621305124};\\\", \\\"{x:474,y:819,t:1527621305140};\\\", \\\"{x:415,y:766,t:1527621305156};\\\", \\\"{x:280,y:683,t:1527621305174};\\\", \\\"{x:222,y:628,t:1527621305191};\\\", \\\"{x:162,y:560,t:1527621305206};\\\", \\\"{x:94,y:492,t:1527621305224};\\\", \\\"{x:21,y:434,t:1527621305241};\\\", \\\"{x:0,y:388,t:1527621305257};\\\", \\\"{x:0,y:355,t:1527621305274};\\\", \\\"{x:0,y:338,t:1527621305290};\\\", \\\"{x:0,y:334,t:1527621305307};\\\", \\\"{x:0,y:332,t:1527621305324};\\\", \\\"{x:1,y:332,t:1527621305373};\\\", \\\"{x:3,y:332,t:1527621305381};\\\", \\\"{x:5,y:333,t:1527621305390};\\\", \\\"{x:13,y:338,t:1527621305408};\\\", \\\"{x:24,y:348,t:1527621305424};\\\", \\\"{x:42,y:367,t:1527621305440};\\\", \\\"{x:60,y:387,t:1527621305458};\\\", \\\"{x:73,y:409,t:1527621305475};\\\", \\\"{x:79,y:429,t:1527621305491};\\\", \\\"{x:84,y:448,t:1527621305508};\\\", \\\"{x:93,y:471,t:1527621305525};\\\", \\\"{x:106,y:492,t:1527621305541};\\\", \\\"{x:128,y:519,t:1527621305557};\\\", \\\"{x:139,y:531,t:1527621305575};\\\", \\\"{x:139,y:532,t:1527621305591};\\\", \\\"{x:140,y:533,t:1527621305607};\\\", \\\"{x:141,y:533,t:1527621305645};\\\", \\\"{x:141,y:534,t:1527621305657};\\\", \\\"{x:140,y:534,t:1527621305734};\\\", \\\"{x:140,y:533,t:1527621305741};\\\", \\\"{x:140,y:532,t:1527621305757};\\\", \\\"{x:139,y:531,t:1527621305783};\\\", \\\"{x:138,y:530,t:1527621305870};\\\", \\\"{x:138,y:530,t:1527621305911};\\\", \\\"{x:139,y:530,t:1527621306158};\\\", \\\"{x:140,y:532,t:1527621306183};\\\", \\\"{x:141,y:535,t:1527621306192};\\\", \\\"{x:146,y:539,t:1527621306209};\\\", \\\"{x:153,y:544,t:1527621306225};\\\", \\\"{x:162,y:548,t:1527621306241};\\\", \\\"{x:165,y:550,t:1527621306258};\\\", \\\"{x:167,y:551,t:1527621306275};\\\", \\\"{x:168,y:552,t:1527621306293};\\\", \\\"{x:169,y:553,t:1527621306309};\\\", \\\"{x:170,y:554,t:1527621306324};\\\", \\\"{x:173,y:555,t:1527621306341};\\\", \\\"{x:172,y:553,t:1527621306613};\\\", \\\"{x:172,y:552,t:1527621306637};\\\", \\\"{x:172,y:551,t:1527621306678};\\\", \\\"{x:172,y:550,t:1527621306709};\\\", \\\"{x:172,y:549,t:1527621306727};\\\", \\\"{x:171,y:547,t:1527621306742};\\\", \\\"{x:170,y:546,t:1527621306758};\\\", \\\"{x:169,y:545,t:1527621306775};\\\", \\\"{x:169,y:544,t:1527621307086};\\\", \\\"{x:170,y:544,t:1527621307110};\\\", \\\"{x:172,y:544,t:1527621307125};\\\", \\\"{x:175,y:544,t:1527621307143};\\\", \\\"{x:178,y:544,t:1527621307159};\\\", \\\"{x:182,y:544,t:1527621307175};\\\", \\\"{x:189,y:544,t:1527621307192};\\\", \\\"{x:190,y:544,t:1527621307208};\\\", \\\"{x:191,y:544,t:1527621307225};\\\", \\\"{x:193,y:544,t:1527621307243};\\\", \\\"{x:197,y:544,t:1527621307259};\\\", \\\"{x:200,y:544,t:1527621307275};\\\", \\\"{x:207,y:544,t:1527621307293};\\\", \\\"{x:237,y:557,t:1527621307310};\\\", \\\"{x:270,y:572,t:1527621307327};\\\", \\\"{x:302,y:581,t:1527621307343};\\\", \\\"{x:344,y:592,t:1527621307359};\\\", \\\"{x:389,y:605,t:1527621307377};\\\", \\\"{x:439,y:618,t:1527621307393};\\\", \\\"{x:520,y:644,t:1527621307409};\\\", \\\"{x:607,y:663,t:1527621307426};\\\", \\\"{x:716,y:679,t:1527621307443};\\\", \\\"{x:834,y:694,t:1527621307460};\\\", \\\"{x:938,y:712,t:1527621307475};\\\", \\\"{x:1021,y:723,t:1527621307492};\\\", \\\"{x:1071,y:730,t:1527621307508};\\\", \\\"{x:1114,y:741,t:1527621307526};\\\", \\\"{x:1123,y:743,t:1527621307542};\\\", \\\"{x:1124,y:745,t:1527621307559};\\\", \\\"{x:1125,y:745,t:1527621307926};\\\", \\\"{x:1134,y:751,t:1527621307942};\\\", \\\"{x:1155,y:759,t:1527621307959};\\\", \\\"{x:1186,y:768,t:1527621307976};\\\", \\\"{x:1228,y:782,t:1527621307992};\\\", \\\"{x:1267,y:793,t:1527621308009};\\\", \\\"{x:1298,y:798,t:1527621308026};\\\", \\\"{x:1322,y:802,t:1527621308043};\\\", \\\"{x:1344,y:805,t:1527621308059};\\\", \\\"{x:1365,y:809,t:1527621308076};\\\", \\\"{x:1375,y:811,t:1527621308092};\\\", \\\"{x:1383,y:812,t:1527621308109};\\\", \\\"{x:1389,y:813,t:1527621308126};\\\", \\\"{x:1391,y:813,t:1527621308142};\\\", \\\"{x:1392,y:813,t:1527621308254};\\\", \\\"{x:1390,y:811,t:1527621308262};\\\", \\\"{x:1389,y:804,t:1527621308275};\\\", \\\"{x:1387,y:798,t:1527621308292};\\\", \\\"{x:1386,y:794,t:1527621308309};\\\", \\\"{x:1386,y:791,t:1527621308325};\\\", \\\"{x:1384,y:787,t:1527621308342};\\\", \\\"{x:1383,y:785,t:1527621308359};\\\", \\\"{x:1382,y:782,t:1527621308375};\\\", \\\"{x:1379,y:778,t:1527621308392};\\\", \\\"{x:1376,y:772,t:1527621308409};\\\", \\\"{x:1374,y:769,t:1527621308425};\\\", \\\"{x:1371,y:764,t:1527621308442};\\\", \\\"{x:1368,y:759,t:1527621308459};\\\", \\\"{x:1368,y:753,t:1527621308475};\\\", \\\"{x:1367,y:747,t:1527621308492};\\\", \\\"{x:1367,y:745,t:1527621308509};\\\", \\\"{x:1364,y:740,t:1527621308525};\\\", \\\"{x:1361,y:734,t:1527621308541};\\\", \\\"{x:1361,y:732,t:1527621308559};\\\", \\\"{x:1361,y:729,t:1527621308575};\\\", \\\"{x:1360,y:729,t:1527621308592};\\\", \\\"{x:1360,y:728,t:1527621308614};\\\", \\\"{x:1360,y:726,t:1527621308910};\\\", \\\"{x:1360,y:725,t:1527621308925};\\\", \\\"{x:1359,y:721,t:1527621308942};\\\", \\\"{x:1357,y:717,t:1527621308958};\\\", \\\"{x:1356,y:713,t:1527621308975};\\\", \\\"{x:1356,y:710,t:1527621308993};\\\", \\\"{x:1354,y:707,t:1527621309008};\\\", \\\"{x:1352,y:703,t:1527621309025};\\\", \\\"{x:1350,y:700,t:1527621309044};\\\", \\\"{x:1349,y:697,t:1527621309058};\\\", \\\"{x:1347,y:694,t:1527621309074};\\\", \\\"{x:1346,y:692,t:1527621309090};\\\", \\\"{x:1345,y:691,t:1527621309108};\\\", \\\"{x:1345,y:693,t:1527621309623};\\\", \\\"{x:1345,y:694,t:1527621309658};\\\", \\\"{x:1345,y:696,t:1527621309710};\\\", \\\"{x:1345,y:697,t:1527621309766};\\\", \\\"{x:1345,y:699,t:1527621309790};\\\", \\\"{x:1345,y:700,t:1527621309806};\\\", \\\"{x:1345,y:702,t:1527621309823};\\\", \\\"{x:1345,y:706,t:1527621309841};\\\", \\\"{x:1345,y:717,t:1527621309856};\\\", \\\"{x:1345,y:732,t:1527621309874};\\\", \\\"{x:1345,y:751,t:1527621309891};\\\", \\\"{x:1345,y:771,t:1527621309906};\\\", \\\"{x:1345,y:790,t:1527621309923};\\\", \\\"{x:1345,y:811,t:1527621309941};\\\", \\\"{x:1345,y:833,t:1527621309957};\\\", \\\"{x:1345,y:867,t:1527621309974};\\\", \\\"{x:1345,y:887,t:1527621309990};\\\", \\\"{x:1345,y:906,t:1527621310006};\\\", \\\"{x:1348,y:923,t:1527621310024};\\\", \\\"{x:1350,y:937,t:1527621310041};\\\", \\\"{x:1350,y:944,t:1527621310057};\\\", \\\"{x:1350,y:950,t:1527621310073};\\\", \\\"{x:1350,y:960,t:1527621310089};\\\", \\\"{x:1350,y:970,t:1527621310107};\\\", \\\"{x:1350,y:981,t:1527621310124};\\\", \\\"{x:1350,y:992,t:1527621310140};\\\", \\\"{x:1350,y:999,t:1527621310156};\\\", \\\"{x:1350,y:1008,t:1527621310174};\\\", \\\"{x:1350,y:1013,t:1527621310190};\\\", \\\"{x:1350,y:1016,t:1527621310206};\\\", \\\"{x:1349,y:1019,t:1527621310224};\\\", \\\"{x:1349,y:1020,t:1527621310240};\\\", \\\"{x:1349,y:1018,t:1527621310406};\\\", \\\"{x:1349,y:1017,t:1527621310424};\\\", \\\"{x:1348,y:1016,t:1527621310440};\\\", \\\"{x:1348,y:1015,t:1527621310457};\\\", \\\"{x:1348,y:1014,t:1527621310475};\\\", \\\"{x:1348,y:1013,t:1527621310494};\\\", \\\"{x:1348,y:1012,t:1527621310518};\\\", \\\"{x:1348,y:1011,t:1527621310526};\\\", \\\"{x:1348,y:1009,t:1527621310542};\\\", \\\"{x:1348,y:1008,t:1527621310557};\\\", \\\"{x:1348,y:1002,t:1527621310573};\\\", \\\"{x:1350,y:990,t:1527621310590};\\\", \\\"{x:1353,y:983,t:1527621310608};\\\", \\\"{x:1353,y:977,t:1527621310623};\\\", \\\"{x:1353,y:971,t:1527621310640};\\\", \\\"{x:1354,y:966,t:1527621310658};\\\", \\\"{x:1355,y:964,t:1527621310673};\\\", \\\"{x:1355,y:959,t:1527621310691};\\\", \\\"{x:1355,y:958,t:1527621310707};\\\", \\\"{x:1356,y:956,t:1527621310723};\\\", \\\"{x:1357,y:955,t:1527621313799};\\\", \\\"{x:1360,y:955,t:1527621313805};\\\", \\\"{x:1361,y:955,t:1527621313821};\\\", \\\"{x:1362,y:955,t:1527621313838};\\\", \\\"{x:1363,y:955,t:1527621314951};\\\", \\\"{x:1363,y:956,t:1527621315726};\\\", \\\"{x:1363,y:957,t:1527621319718};\\\", \\\"{x:1363,y:958,t:1527621320150};\\\", \\\"{x:1362,y:959,t:1527621320278};\\\", \\\"{x:1361,y:961,t:1527621320310};\\\", \\\"{x:1360,y:961,t:1527621320350};\\\", \\\"{x:1360,y:962,t:1527621320399};\\\", \\\"{x:1360,y:963,t:1527621320416};\\\", \\\"{x:1359,y:965,t:1527621320433};\\\", \\\"{x:1358,y:966,t:1527621320478};\\\", \\\"{x:1358,y:967,t:1527621320518};\\\", \\\"{x:1357,y:967,t:1527621320591};\\\", \\\"{x:1357,y:968,t:1527621322766};\\\", \\\"{x:1358,y:968,t:1527621322854};\\\", \\\"{x:1358,y:969,t:1527621322864};\\\", \\\"{x:1359,y:969,t:1527621323606};\\\", \\\"{x:1360,y:969,t:1527621323629};\\\", \\\"{x:1361,y:969,t:1527621323678};\\\", \\\"{x:1362,y:969,t:1527621323694};\\\", \\\"{x:1363,y:969,t:1527621323774};\\\", \\\"{x:1364,y:969,t:1527621323789};\\\", \\\"{x:1365,y:969,t:1527621323814};\\\", \\\"{x:1366,y:969,t:1527621323854};\\\", \\\"{x:1367,y:969,t:1527621323869};\\\", \\\"{x:1368,y:968,t:1527621323902};\\\", \\\"{x:1369,y:968,t:1527621323925};\\\", \\\"{x:1370,y:968,t:1527621323934};\\\", \\\"{x:1370,y:967,t:1527621323950};\\\", \\\"{x:1371,y:967,t:1527621323963};\\\", \\\"{x:1372,y:967,t:1527621323979};\\\", \\\"{x:1373,y:966,t:1527621323996};\\\", \\\"{x:1374,y:966,t:1527621324012};\\\", \\\"{x:1376,y:965,t:1527621324045};\\\", \\\"{x:1376,y:966,t:1527621324398};\\\", \\\"{x:1375,y:968,t:1527621324412};\\\", \\\"{x:1374,y:968,t:1527621324429};\\\", \\\"{x:1373,y:970,t:1527621324446};\\\", \\\"{x:1373,y:971,t:1527621324462};\\\", \\\"{x:1373,y:972,t:1527621324479};\\\", \\\"{x:1372,y:972,t:1527621324495};\\\", \\\"{x:1372,y:973,t:1527621324525};\\\", \\\"{x:1372,y:974,t:1527621324575};\\\", \\\"{x:1372,y:975,t:1527621324598};\\\", \\\"{x:1372,y:976,t:1527621324612};\\\", \\\"{x:1372,y:977,t:1527621324629};\\\", \\\"{x:1373,y:980,t:1527621324646};\\\", \\\"{x:1375,y:982,t:1527621324662};\\\", \\\"{x:1376,y:984,t:1527621324679};\\\", \\\"{x:1379,y:986,t:1527621324695};\\\", \\\"{x:1380,y:988,t:1527621324711};\\\", \\\"{x:1381,y:988,t:1527621324729};\\\", \\\"{x:1382,y:991,t:1527621324745};\\\", \\\"{x:1383,y:992,t:1527621324762};\\\", \\\"{x:1384,y:993,t:1527621324779};\\\", \\\"{x:1384,y:994,t:1527621324795};\\\", \\\"{x:1385,y:996,t:1527621324812};\\\", \\\"{x:1385,y:997,t:1527621324829};\\\", \\\"{x:1385,y:998,t:1527621324845};\\\", \\\"{x:1385,y:999,t:1527621324862};\\\", \\\"{x:1385,y:1000,t:1527621324879};\\\", \\\"{x:1385,y:1003,t:1527621324895};\\\", \\\"{x:1385,y:1004,t:1527621324912};\\\", \\\"{x:1385,y:1005,t:1527621324958};\\\", \\\"{x:1384,y:1006,t:1527621324966};\\\", \\\"{x:1383,y:1006,t:1527621324998};\\\", \\\"{x:1383,y:1007,t:1527621325022};\\\", \\\"{x:1383,y:1008,t:1527621325029};\\\", \\\"{x:1382,y:1009,t:1527621325045};\\\", \\\"{x:1381,y:1011,t:1527621325062};\\\", \\\"{x:1380,y:1011,t:1527621325078};\\\", \\\"{x:1380,y:1012,t:1527621325095};\\\", \\\"{x:1379,y:1013,t:1527621325112};\\\", \\\"{x:1378,y:1014,t:1527621325156};\\\", \\\"{x:1376,y:1014,t:1527621325910};\\\", \\\"{x:1373,y:1013,t:1527621325928};\\\", \\\"{x:1361,y:1008,t:1527621325944};\\\", \\\"{x:1341,y:999,t:1527621325961};\\\", \\\"{x:1321,y:989,t:1527621325978};\\\", \\\"{x:1290,y:978,t:1527621325994};\\\", \\\"{x:1242,y:964,t:1527621326011};\\\", \\\"{x:1194,y:949,t:1527621326027};\\\", \\\"{x:1129,y:926,t:1527621326044};\\\", \\\"{x:1060,y:908,t:1527621326061};\\\", \\\"{x:969,y:885,t:1527621326077};\\\", \\\"{x:920,y:874,t:1527621326093};\\\", \\\"{x:876,y:862,t:1527621326110};\\\", \\\"{x:848,y:859,t:1527621326127};\\\", \\\"{x:828,y:854,t:1527621326143};\\\", \\\"{x:817,y:849,t:1527621326160};\\\", \\\"{x:806,y:844,t:1527621326177};\\\", \\\"{x:795,y:838,t:1527621326193};\\\", \\\"{x:783,y:830,t:1527621326210};\\\", \\\"{x:767,y:818,t:1527621326227};\\\", \\\"{x:742,y:804,t:1527621326244};\\\", \\\"{x:714,y:791,t:1527621326260};\\\", \\\"{x:679,y:776,t:1527621326276};\\\", \\\"{x:623,y:754,t:1527621326294};\\\", \\\"{x:579,y:742,t:1527621326310};\\\", \\\"{x:527,y:731,t:1527621326327};\\\", \\\"{x:463,y:721,t:1527621326343};\\\", \\\"{x:421,y:715,t:1527621326361};\\\", \\\"{x:397,y:712,t:1527621326375};\\\", \\\"{x:386,y:710,t:1527621326391};\\\", \\\"{x:380,y:709,t:1527621326409};\\\", \\\"{x:377,y:706,t:1527621326424};\\\", \\\"{x:378,y:706,t:1527621326509};\\\", \\\"{x:381,y:707,t:1527621326524};\\\", \\\"{x:385,y:708,t:1527621326541};\\\", \\\"{x:390,y:710,t:1527621326559};\\\", \\\"{x:393,y:712,t:1527621326574};\\\", \\\"{x:399,y:714,t:1527621326591};\\\", \\\"{x:408,y:717,t:1527621326608};\\\", \\\"{x:417,y:720,t:1527621326625};\\\", \\\"{x:423,y:720,t:1527621326642};\\\", \\\"{x:426,y:720,t:1527621326659};\\\", \\\"{x:431,y:720,t:1527621326675};\\\", \\\"{x:434,y:720,t:1527621326691};\\\", \\\"{x:437,y:720,t:1527621326709};\\\", \\\"{x:439,y:720,t:1527621326726};\\\", \\\"{x:440,y:720,t:1527621326742};\\\", \\\"{x:442,y:721,t:1527621326758};\\\", \\\"{x:443,y:721,t:1527621326776};\\\", \\\"{x:446,y:722,t:1527621326792};\\\", \\\"{x:447,y:722,t:1527621326810};\\\", \\\"{x:451,y:723,t:1527621326826};\\\", \\\"{x:455,y:724,t:1527621326841};\\\", \\\"{x:460,y:725,t:1527621326858};\\\", \\\"{x:465,y:728,t:1527621326874};\\\", \\\"{x:474,y:731,t:1527621326891};\\\", \\\"{x:483,y:733,t:1527621326908};\\\", \\\"{x:489,y:736,t:1527621326924};\\\", \\\"{x:497,y:739,t:1527621326942};\\\", \\\"{x:500,y:740,t:1527621326959};\\\", \\\"{x:506,y:743,t:1527621326974};\\\", \\\"{x:513,y:747,t:1527621326992};\\\", \\\"{x:517,y:748,t:1527621327008};\\\", \\\"{x:519,y:749,t:1527621327025};\\\", \\\"{x:523,y:751,t:1527621327042};\\\", \\\"{x:527,y:753,t:1527621327059};\\\", \\\"{x:530,y:754,t:1527621327076};\\\", \\\"{x:535,y:756,t:1527621327092};\\\", \\\"{x:539,y:757,t:1527621327109};\\\", \\\"{x:540,y:758,t:1527621327125};\\\", \\\"{x:540,y:759,t:1527621327142};\\\", \\\"{x:541,y:759,t:1527621328006};\\\", \\\"{x:541,y:757,t:1527621328030};\\\", \\\"{x:540,y:756,t:1527621328062};\\\", \\\"{x:540,y:755,t:1527621328086};\\\", \\\"{x:538,y:754,t:1527621328094};\\\", \\\"{x:537,y:752,t:1527621328108};\\\", \\\"{x:537,y:751,t:1527621328125};\\\", \\\"{x:536,y:749,t:1527621328143};\\\", \\\"{x:535,y:746,t:1527621328159};\\\", \\\"{x:535,y:745,t:1527621328181};\\\", \\\"{x:535,y:744,t:1527621328192};\\\", \\\"{x:534,y:743,t:1527621328209};\\\", \\\"{x:534,y:742,t:1527621328261};\\\", \\\"{x:534,y:741,t:1527621328318};\\\" ] }, { \\\"rt\\\": 93006, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 871881, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:743,t:1527621330292};\\\", \\\"{x:530,y:748,t:1527621330301};\\\", \\\"{x:526,y:749,t:1527621330312};\\\", \\\"{x:518,y:756,t:1527621330327};\\\", \\\"{x:515,y:759,t:1527621330344};\\\", \\\"{x:509,y:763,t:1527621330362};\\\", \\\"{x:507,y:766,t:1527621330378};\\\", \\\"{x:504,y:769,t:1527621330395};\\\", \\\"{x:503,y:772,t:1527621330412};\\\", \\\"{x:502,y:775,t:1527621330427};\\\", \\\"{x:501,y:778,t:1527621330444};\\\", \\\"{x:501,y:780,t:1527621330460};\\\", \\\"{x:501,y:782,t:1527621330478};\\\", \\\"{x:501,y:785,t:1527621330495};\\\", \\\"{x:501,y:791,t:1527621330511};\\\", \\\"{x:501,y:797,t:1527621330527};\\\", \\\"{x:501,y:802,t:1527621330544};\\\", \\\"{x:501,y:806,t:1527621330560};\\\", \\\"{x:502,y:812,t:1527621330577};\\\", \\\"{x:505,y:821,t:1527621330595};\\\", \\\"{x:509,y:825,t:1527621330610};\\\", \\\"{x:516,y:834,t:1527621330627};\\\", \\\"{x:529,y:851,t:1527621330645};\\\", \\\"{x:530,y:856,t:1527621330661};\\\", \\\"{x:534,y:860,t:1527621330677};\\\", \\\"{x:538,y:864,t:1527621330694};\\\", \\\"{x:538,y:866,t:1527621330711};\\\", \\\"{x:539,y:866,t:1527621330750};\\\", \\\"{x:540,y:866,t:1527621330774};\\\", \\\"{x:541,y:866,t:1527621330782};\\\", \\\"{x:543,y:868,t:1527621330795};\\\", \\\"{x:548,y:871,t:1527621330811};\\\", \\\"{x:549,y:872,t:1527621330828};\\\", \\\"{x:550,y:872,t:1527621330845};\\\", \\\"{x:554,y:872,t:1527621330860};\\\", \\\"{x:562,y:871,t:1527621330878};\\\", \\\"{x:576,y:862,t:1527621330895};\\\", \\\"{x:586,y:847,t:1527621330911};\\\", \\\"{x:608,y:824,t:1527621330928};\\\", \\\"{x:629,y:795,t:1527621330945};\\\", \\\"{x:642,y:772,t:1527621330961};\\\", \\\"{x:648,y:747,t:1527621330978};\\\", \\\"{x:649,y:728,t:1527621330995};\\\", \\\"{x:650,y:724,t:1527621331011};\\\", \\\"{x:652,y:722,t:1527621331028};\\\", \\\"{x:654,y:722,t:1527621331045};\\\", \\\"{x:657,y:721,t:1527621331062};\\\", \\\"{x:657,y:719,t:1527621331077};\\\", \\\"{x:657,y:717,t:1527621331095};\\\", \\\"{x:657,y:715,t:1527621331224};\\\", \\\"{x:658,y:715,t:1527621331232};\\\", \\\"{x:659,y:714,t:1527621331594};\\\", \\\"{x:658,y:714,t:1527621331713};\\\", \\\"{x:656,y:713,t:1527621331721};\\\", \\\"{x:655,y:712,t:1527621331737};\\\", \\\"{x:653,y:710,t:1527621331748};\\\", \\\"{x:653,y:712,t:1527621331898};\\\", \\\"{x:653,y:713,t:1527621331969};\\\", \\\"{x:652,y:715,t:1527621331985};\\\", \\\"{x:651,y:715,t:1527621331998};\\\", \\\"{x:651,y:716,t:1527621332015};\\\", \\\"{x:650,y:716,t:1527621332065};\\\", \\\"{x:648,y:716,t:1527621332217};\\\", \\\"{x:647,y:716,t:1527621332231};\\\", \\\"{x:646,y:716,t:1527621332272};\\\", \\\"{x:644,y:716,t:1527621332281};\\\", \\\"{x:643,y:716,t:1527621332298};\\\", \\\"{x:642,y:716,t:1527621332315};\\\", \\\"{x:641,y:716,t:1527621332332};\\\", \\\"{x:641,y:714,t:1527621332353};\\\", \\\"{x:641,y:713,t:1527621332364};\\\", \\\"{x:641,y:711,t:1527621332381};\\\", \\\"{x:641,y:710,t:1527621332398};\\\", \\\"{x:642,y:708,t:1527621332415};\\\", \\\"{x:644,y:706,t:1527621332432};\\\", \\\"{x:646,y:702,t:1527621332448};\\\", \\\"{x:648,y:700,t:1527621332465};\\\", \\\"{x:648,y:699,t:1527621332481};\\\", \\\"{x:648,y:698,t:1527621332499};\\\", \\\"{x:649,y:697,t:1527621333081};\\\", \\\"{x:651,y:697,t:1527621333098};\\\", \\\"{x:666,y:695,t:1527621333114};\\\", \\\"{x:693,y:695,t:1527621333131};\\\", \\\"{x:725,y:695,t:1527621333148};\\\", \\\"{x:778,y:695,t:1527621333164};\\\", \\\"{x:840,y:695,t:1527621333182};\\\", \\\"{x:923,y:695,t:1527621333199};\\\", \\\"{x:997,y:699,t:1527621333214};\\\", \\\"{x:1048,y:707,t:1527621333232};\\\", \\\"{x:1084,y:712,t:1527621333249};\\\", \\\"{x:1095,y:713,t:1527621333265};\\\", \\\"{x:1098,y:714,t:1527621333282};\\\", \\\"{x:1099,y:714,t:1527621333299};\\\", \\\"{x:1100,y:718,t:1527621333738};\\\", \\\"{x:1100,y:723,t:1527621333748};\\\", \\\"{x:1103,y:735,t:1527621333765};\\\", \\\"{x:1107,y:755,t:1527621333782};\\\", \\\"{x:1111,y:777,t:1527621333799};\\\", \\\"{x:1117,y:801,t:1527621333816};\\\", \\\"{x:1124,y:824,t:1527621333832};\\\", \\\"{x:1132,y:855,t:1527621333848};\\\", \\\"{x:1138,y:878,t:1527621333864};\\\", \\\"{x:1140,y:896,t:1527621333882};\\\", \\\"{x:1142,y:916,t:1527621333899};\\\", \\\"{x:1145,y:938,t:1527621333915};\\\", \\\"{x:1146,y:955,t:1527621333932};\\\", \\\"{x:1148,y:967,t:1527621333948};\\\", \\\"{x:1149,y:978,t:1527621333966};\\\", \\\"{x:1150,y:985,t:1527621333982};\\\", \\\"{x:1152,y:992,t:1527621333999};\\\", \\\"{x:1154,y:999,t:1527621334016};\\\", \\\"{x:1157,y:1009,t:1527621334032};\\\", \\\"{x:1164,y:1023,t:1527621334049};\\\", \\\"{x:1171,y:1032,t:1527621334065};\\\", \\\"{x:1180,y:1041,t:1527621334082};\\\", \\\"{x:1192,y:1049,t:1527621334099};\\\", \\\"{x:1208,y:1059,t:1527621334116};\\\", \\\"{x:1230,y:1068,t:1527621334132};\\\", \\\"{x:1253,y:1076,t:1527621334148};\\\", \\\"{x:1276,y:1080,t:1527621334165};\\\", \\\"{x:1299,y:1083,t:1527621334181};\\\", \\\"{x:1321,y:1086,t:1527621334198};\\\", \\\"{x:1328,y:1086,t:1527621334215};\\\", \\\"{x:1331,y:1086,t:1527621334231};\\\", \\\"{x:1332,y:1086,t:1527621334248};\\\", \\\"{x:1333,y:1085,t:1527621334449};\\\", \\\"{x:1334,y:1085,t:1527621334464};\\\", \\\"{x:1335,y:1083,t:1527621334481};\\\", \\\"{x:1338,y:1080,t:1527621334498};\\\", \\\"{x:1343,y:1076,t:1527621334515};\\\", \\\"{x:1346,y:1074,t:1527621334532};\\\", \\\"{x:1350,y:1071,t:1527621334548};\\\", \\\"{x:1356,y:1068,t:1527621334565};\\\", \\\"{x:1361,y:1063,t:1527621334581};\\\", \\\"{x:1370,y:1058,t:1527621334599};\\\", \\\"{x:1375,y:1054,t:1527621334615};\\\", \\\"{x:1385,y:1051,t:1527621334632};\\\", \\\"{x:1408,y:1043,t:1527621334649};\\\", \\\"{x:1419,y:1039,t:1527621334664};\\\", \\\"{x:1423,y:1039,t:1527621334681};\\\", \\\"{x:1426,y:1037,t:1527621334698};\\\", \\\"{x:1428,y:1036,t:1527621334715};\\\", \\\"{x:1433,y:1036,t:1527621334732};\\\", \\\"{x:1439,y:1033,t:1527621334749};\\\", \\\"{x:1447,y:1032,t:1527621334766};\\\", \\\"{x:1457,y:1028,t:1527621334782};\\\", \\\"{x:1459,y:1027,t:1527621334798};\\\", \\\"{x:1464,y:1024,t:1527621334816};\\\", \\\"{x:1472,y:1019,t:1527621334832};\\\", \\\"{x:1480,y:1014,t:1527621334848};\\\", \\\"{x:1482,y:1011,t:1527621334865};\\\", \\\"{x:1484,y:1009,t:1527621334882};\\\", \\\"{x:1485,y:1006,t:1527621334898};\\\", \\\"{x:1487,y:1000,t:1527621334915};\\\", \\\"{x:1492,y:994,t:1527621334932};\\\", \\\"{x:1496,y:985,t:1527621334949};\\\", \\\"{x:1501,y:979,t:1527621334966};\\\", \\\"{x:1501,y:976,t:1527621334981};\\\", \\\"{x:1501,y:973,t:1527621334999};\\\", \\\"{x:1502,y:972,t:1527621335016};\\\", \\\"{x:1503,y:970,t:1527621335032};\\\", \\\"{x:1503,y:969,t:1527621335049};\\\", \\\"{x:1503,y:968,t:1527621335417};\\\", \\\"{x:1502,y:968,t:1527621335441};\\\", \\\"{x:1501,y:967,t:1527621335449};\\\", \\\"{x:1500,y:966,t:1527621335473};\\\", \\\"{x:1499,y:966,t:1527621335481};\\\", \\\"{x:1498,y:966,t:1527621335498};\\\", \\\"{x:1497,y:965,t:1527621335516};\\\", \\\"{x:1494,y:964,t:1527621335532};\\\", \\\"{x:1492,y:963,t:1527621335549};\\\", \\\"{x:1486,y:961,t:1527621335567};\\\", \\\"{x:1482,y:959,t:1527621335581};\\\", \\\"{x:1480,y:959,t:1527621335599};\\\", \\\"{x:1479,y:959,t:1527621335615};\\\", \\\"{x:1478,y:959,t:1527621335632};\\\", \\\"{x:1476,y:958,t:1527621335648};\\\", \\\"{x:1475,y:958,t:1527621335673};\\\", \\\"{x:1474,y:957,t:1527621335817};\\\", \\\"{x:1475,y:956,t:1527621335841};\\\", \\\"{x:1476,y:956,t:1527621335849};\\\", \\\"{x:1480,y:956,t:1527621335865};\\\", \\\"{x:1483,y:955,t:1527621335882};\\\", \\\"{x:1487,y:955,t:1527621335899};\\\", \\\"{x:1492,y:955,t:1527621335916};\\\", \\\"{x:1494,y:955,t:1527621335932};\\\", \\\"{x:1494,y:956,t:1527621336153};\\\", \\\"{x:1494,y:957,t:1527621336185};\\\", \\\"{x:1494,y:958,t:1527621336209};\\\", \\\"{x:1494,y:959,t:1527621336217};\\\", \\\"{x:1493,y:959,t:1527621336241};\\\", \\\"{x:1492,y:959,t:1527621336248};\\\", \\\"{x:1491,y:959,t:1527621336297};\\\", \\\"{x:1490,y:960,t:1527621336377};\\\", \\\"{x:1489,y:960,t:1527621336890};\\\", \\\"{x:1488,y:961,t:1527621336905};\\\", \\\"{x:1488,y:962,t:1527621336921};\\\", \\\"{x:1488,y:963,t:1527621336932};\\\", \\\"{x:1488,y:964,t:1527621336948};\\\", \\\"{x:1487,y:966,t:1527621336966};\\\", \\\"{x:1487,y:967,t:1527621336982};\\\", \\\"{x:1486,y:969,t:1527621336999};\\\", \\\"{x:1486,y:970,t:1527621337089};\\\", \\\"{x:1486,y:971,t:1527621337105};\\\", \\\"{x:1486,y:972,t:1527621337116};\\\", \\\"{x:1487,y:971,t:1527621356105};\\\", \\\"{x:1488,y:970,t:1527621356129};\\\", \\\"{x:1488,y:969,t:1527621356193};\\\", \\\"{x:1488,y:971,t:1527621356369};\\\", \\\"{x:1488,y:973,t:1527621356384};\\\", \\\"{x:1487,y:975,t:1527621356402};\\\", \\\"{x:1487,y:976,t:1527621356425};\\\", \\\"{x:1487,y:977,t:1527621356435};\\\", \\\"{x:1487,y:978,t:1527621356452};\\\", \\\"{x:1487,y:980,t:1527621356468};\\\", \\\"{x:1487,y:981,t:1527621356485};\\\", \\\"{x:1487,y:982,t:1527621356501};\\\", \\\"{x:1487,y:983,t:1527621356518};\\\", \\\"{x:1486,y:984,t:1527621356601};\\\", \\\"{x:1485,y:984,t:1527621356777};\\\", \\\"{x:1485,y:983,t:1527621356816};\\\", \\\"{x:1485,y:982,t:1527621356849};\\\", \\\"{x:1484,y:981,t:1527621356873};\\\", \\\"{x:1484,y:980,t:1527621356885};\\\", \\\"{x:1484,y:979,t:1527621356905};\\\", \\\"{x:1484,y:978,t:1527621356929};\\\", \\\"{x:1484,y:977,t:1527621356944};\\\", \\\"{x:1484,y:976,t:1527621356960};\\\", \\\"{x:1484,y:975,t:1527621356977};\\\", \\\"{x:1484,y:974,t:1527621356984};\\\", \\\"{x:1484,y:973,t:1527621357002};\\\", \\\"{x:1483,y:971,t:1527621357024};\\\", \\\"{x:1483,y:970,t:1527621357041};\\\", \\\"{x:1483,y:969,t:1527621357056};\\\", \\\"{x:1483,y:968,t:1527621357069};\\\", \\\"{x:1482,y:966,t:1527621357084};\\\", \\\"{x:1482,y:964,t:1527621357101};\\\", \\\"{x:1482,y:963,t:1527621357118};\\\", \\\"{x:1482,y:962,t:1527621357135};\\\", \\\"{x:1482,y:961,t:1527621357152};\\\", \\\"{x:1481,y:960,t:1527621357169};\\\", \\\"{x:1481,y:959,t:1527621357200};\\\", \\\"{x:1481,y:958,t:1527621357208};\\\", \\\"{x:1481,y:957,t:1527621357248};\\\", \\\"{x:1480,y:957,t:1527621357256};\\\", \\\"{x:1480,y:956,t:1527621357280};\\\", \\\"{x:1479,y:956,t:1527621357345};\\\", \\\"{x:1478,y:956,t:1527621358122};\\\", \\\"{x:1479,y:956,t:1527621358425};\\\", \\\"{x:1480,y:956,t:1527621358464};\\\", \\\"{x:1481,y:956,t:1527621358489};\\\", \\\"{x:1482,y:956,t:1527621358521};\\\", \\\"{x:1482,y:957,t:1527621358569};\\\", \\\"{x:1483,y:959,t:1527621358585};\\\", \\\"{x:1483,y:960,t:1527621358602};\\\", \\\"{x:1483,y:962,t:1527621358619};\\\", \\\"{x:1483,y:963,t:1527621358635};\\\", \\\"{x:1483,y:964,t:1527621358664};\\\", \\\"{x:1483,y:965,t:1527621358681};\\\", \\\"{x:1484,y:966,t:1527621358696};\\\", \\\"{x:1485,y:967,t:1527621358745};\\\", \\\"{x:1475,y:968,t:1527621369337};\\\", \\\"{x:1430,y:954,t:1527621369354};\\\", \\\"{x:1331,y:894,t:1527621369370};\\\", \\\"{x:1221,y:831,t:1527621369387};\\\", \\\"{x:1104,y:764,t:1527621369404};\\\", \\\"{x:950,y:674,t:1527621369421};\\\", \\\"{x:812,y:587,t:1527621369438};\\\", \\\"{x:652,y:482,t:1527621369454};\\\", \\\"{x:482,y:386,t:1527621369470};\\\", \\\"{x:302,y:293,t:1527621369479};\\\", \\\"{x:144,y:207,t:1527621369495};\\\", \\\"{x:36,y:135,t:1527621369513};\\\", \\\"{x:0,y:63,t:1527621369530};\\\", \\\"{x:0,y:10,t:1527621369546};\\\", \\\"{x:0,y:1,t:1527621369563};\\\", \\\"{x:0,y:5,t:1527621369600};\\\", \\\"{x:0,y:11,t:1527621369613};\\\", \\\"{x:0,y:30,t:1527621369630};\\\", \\\"{x:0,y:49,t:1527621369647};\\\", \\\"{x:0,y:78,t:1527621369663};\\\", \\\"{x:20,y:143,t:1527621369680};\\\", \\\"{x:56,y:209,t:1527621369695};\\\", \\\"{x:107,y:269,t:1527621369713};\\\", \\\"{x:151,y:309,t:1527621369730};\\\", \\\"{x:190,y:341,t:1527621369747};\\\", \\\"{x:204,y:347,t:1527621369763};\\\", \\\"{x:205,y:349,t:1527621369849};\\\", \\\"{x:205,y:352,t:1527621369864};\\\", \\\"{x:207,y:365,t:1527621369880};\\\", \\\"{x:209,y:378,t:1527621369896};\\\", \\\"{x:213,y:391,t:1527621369913};\\\", \\\"{x:220,y:409,t:1527621369930};\\\", \\\"{x:231,y:428,t:1527621369948};\\\", \\\"{x:245,y:446,t:1527621369964};\\\", \\\"{x:260,y:462,t:1527621369980};\\\", \\\"{x:265,y:466,t:1527621369997};\\\", \\\"{x:270,y:470,t:1527621370014};\\\", \\\"{x:291,y:478,t:1527621370031};\\\", \\\"{x:344,y:486,t:1527621370047};\\\", \\\"{x:459,y:501,t:1527621370065};\\\", \\\"{x:550,y:510,t:1527621370080};\\\", \\\"{x:636,y:525,t:1527621370097};\\\", \\\"{x:684,y:531,t:1527621370114};\\\", \\\"{x:707,y:531,t:1527621370129};\\\", \\\"{x:724,y:532,t:1527621370147};\\\", \\\"{x:727,y:533,t:1527621370163};\\\", \\\"{x:728,y:533,t:1527621370179};\\\", \\\"{x:729,y:533,t:1527621370264};\\\", \\\"{x:729,y:534,t:1527621370288};\\\", \\\"{x:729,y:535,t:1527621370304};\\\", \\\"{x:727,y:536,t:1527621370320};\\\", \\\"{x:725,y:536,t:1527621370344};\\\", \\\"{x:724,y:536,t:1527621370352};\\\", \\\"{x:721,y:536,t:1527621370364};\\\", \\\"{x:714,y:536,t:1527621370380};\\\", \\\"{x:706,y:536,t:1527621370397};\\\", \\\"{x:696,y:536,t:1527621370414};\\\", \\\"{x:689,y:536,t:1527621370430};\\\", \\\"{x:681,y:536,t:1527621370447};\\\", \\\"{x:671,y:534,t:1527621370464};\\\", \\\"{x:667,y:533,t:1527621370480};\\\", \\\"{x:664,y:533,t:1527621370497};\\\", \\\"{x:663,y:533,t:1527621370515};\\\", \\\"{x:662,y:534,t:1527621370553};\\\", \\\"{x:667,y:536,t:1527621370564};\\\", \\\"{x:696,y:541,t:1527621370581};\\\", \\\"{x:733,y:541,t:1527621370599};\\\", \\\"{x:769,y:538,t:1527621370614};\\\", \\\"{x:792,y:536,t:1527621370631};\\\", \\\"{x:803,y:533,t:1527621370647};\\\", \\\"{x:805,y:532,t:1527621370663};\\\", \\\"{x:806,y:531,t:1527621370744};\\\", \\\"{x:806,y:530,t:1527621370760};\\\", \\\"{x:806,y:527,t:1527621370768};\\\", \\\"{x:806,y:526,t:1527621370780};\\\", \\\"{x:806,y:523,t:1527621370797};\\\", \\\"{x:810,y:518,t:1527621370814};\\\", \\\"{x:813,y:515,t:1527621370831};\\\", \\\"{x:816,y:514,t:1527621370847};\\\", \\\"{x:816,y:513,t:1527621370896};\\\", \\\"{x:817,y:513,t:1527621370904};\\\", \\\"{x:818,y:513,t:1527621370928};\\\", \\\"{x:819,y:513,t:1527621370936};\\\", \\\"{x:820,y:512,t:1527621370948};\\\", \\\"{x:822,y:512,t:1527621370965};\\\", \\\"{x:824,y:516,t:1527621371209};\\\", \\\"{x:824,y:523,t:1527621371216};\\\", \\\"{x:820,y:549,t:1527621371234};\\\", \\\"{x:808,y:581,t:1527621371249};\\\", \\\"{x:792,y:624,t:1527621371264};\\\", \\\"{x:784,y:675,t:1527621371281};\\\", \\\"{x:783,y:715,t:1527621371298};\\\", \\\"{x:783,y:742,t:1527621371314};\\\", \\\"{x:783,y:769,t:1527621371330};\\\", \\\"{x:784,y:791,t:1527621371347};\\\", \\\"{x:784,y:809,t:1527621371364};\\\", \\\"{x:785,y:819,t:1527621371381};\\\", \\\"{x:785,y:822,t:1527621371397};\\\", \\\"{x:786,y:824,t:1527621371415};\\\", \\\"{x:786,y:825,t:1527621371432};\\\", \\\"{x:786,y:826,t:1527621371464};\\\", \\\"{x:787,y:826,t:1527621371472};\\\", \\\"{x:789,y:823,t:1527621371482};\\\", \\\"{x:792,y:811,t:1527621371498};\\\", \\\"{x:794,y:795,t:1527621371515};\\\", \\\"{x:800,y:751,t:1527621371532};\\\", \\\"{x:807,y:685,t:1527621371550};\\\", \\\"{x:810,y:626,t:1527621371566};\\\", \\\"{x:810,y:586,t:1527621371582};\\\", \\\"{x:810,y:565,t:1527621371598};\\\", \\\"{x:810,y:552,t:1527621371615};\\\", \\\"{x:810,y:545,t:1527621371630};\\\", \\\"{x:810,y:541,t:1527621371647};\\\", \\\"{x:810,y:540,t:1527621371664};\\\", \\\"{x:810,y:538,t:1527621371681};\\\", \\\"{x:811,y:537,t:1527621371698};\\\", \\\"{x:817,y:531,t:1527621371715};\\\", \\\"{x:822,y:524,t:1527621371731};\\\", \\\"{x:831,y:516,t:1527621371748};\\\", \\\"{x:833,y:514,t:1527621371765};\\\", \\\"{x:834,y:514,t:1527621371800};\\\", \\\"{x:835,y:514,t:1527621371816};\\\", \\\"{x:836,y:514,t:1527621371831};\\\", \\\"{x:838,y:514,t:1527621371848};\\\", \\\"{x:840,y:514,t:1527621371866};\\\", \\\"{x:841,y:514,t:1527621371888};\\\", \\\"{x:842,y:515,t:1527621372112};\\\", \\\"{x:841,y:521,t:1527621372120};\\\", \\\"{x:840,y:528,t:1527621372132};\\\", \\\"{x:835,y:544,t:1527621372148};\\\", \\\"{x:833,y:554,t:1527621372165};\\\", \\\"{x:831,y:563,t:1527621372182};\\\", \\\"{x:830,y:572,t:1527621372198};\\\", \\\"{x:830,y:583,t:1527621372215};\\\", \\\"{x:828,y:604,t:1527621372232};\\\", \\\"{x:820,y:625,t:1527621372249};\\\", \\\"{x:811,y:652,t:1527621372265};\\\", \\\"{x:793,y:692,t:1527621372282};\\\", \\\"{x:773,y:736,t:1527621372299};\\\", \\\"{x:741,y:788,t:1527621372315};\\\", \\\"{x:709,y:841,t:1527621372331};\\\", \\\"{x:680,y:883,t:1527621372349};\\\", \\\"{x:667,y:902,t:1527621372365};\\\", \\\"{x:665,y:906,t:1527621372382};\\\", \\\"{x:654,y:897,t:1527621418244};\\\", \\\"{x:583,y:756,t:1527621418259};\\\", \\\"{x:502,y:623,t:1527621418278};\\\", \\\"{x:452,y:554,t:1527621418292};\\\", \\\"{x:432,y:532,t:1527621418318};\\\", \\\"{x:426,y:529,t:1527621418335};\\\", \\\"{x:409,y:521,t:1527621418351};\\\", \\\"{x:375,y:510,t:1527621418372};\\\", \\\"{x:356,y:506,t:1527621418389};\\\", \\\"{x:352,y:506,t:1527621418404};\\\", \\\"{x:351,y:506,t:1527621418422};\\\", \\\"{x:350,y:506,t:1527621418438};\\\", \\\"{x:349,y:506,t:1527621418457};\\\", \\\"{x:346,y:506,t:1527621418472};\\\", \\\"{x:340,y:517,t:1527621418489};\\\", \\\"{x:340,y:530,t:1527621418505};\\\", \\\"{x:323,y:553,t:1527621418523};\\\", \\\"{x:316,y:562,t:1527621418539};\\\", \\\"{x:313,y:571,t:1527621418555};\\\", \\\"{x:312,y:576,t:1527621418572};\\\", \\\"{x:310,y:582,t:1527621418590};\\\", \\\"{x:310,y:587,t:1527621418605};\\\", \\\"{x:310,y:588,t:1527621418667};\\\", \\\"{x:311,y:588,t:1527621418683};\\\", \\\"{x:311,y:589,t:1527621418691};\\\", \\\"{x:313,y:590,t:1527621418707};\\\", \\\"{x:318,y:591,t:1527621418722};\\\", \\\"{x:336,y:591,t:1527621418739};\\\", \\\"{x:344,y:591,t:1527621418756};\\\", \\\"{x:359,y:587,t:1527621418773};\\\", \\\"{x:376,y:583,t:1527621418790};\\\", \\\"{x:391,y:577,t:1527621418806};\\\", \\\"{x:407,y:572,t:1527621418822};\\\", \\\"{x:440,y:567,t:1527621418839};\\\", \\\"{x:487,y:565,t:1527621418855};\\\", \\\"{x:532,y:556,t:1527621418872};\\\", \\\"{x:564,y:551,t:1527621418889};\\\", \\\"{x:577,y:545,t:1527621418906};\\\", \\\"{x:578,y:544,t:1527621418922};\\\", \\\"{x:579,y:541,t:1527621418939};\\\", \\\"{x:580,y:539,t:1527621418956};\\\", \\\"{x:582,y:536,t:1527621418973};\\\", \\\"{x:587,y:530,t:1527621418989};\\\", \\\"{x:595,y:525,t:1527621419005};\\\", \\\"{x:605,y:520,t:1527621419022};\\\", \\\"{x:611,y:517,t:1527621419039};\\\", \\\"{x:613,y:516,t:1527621419055};\\\", \\\"{x:613,y:515,t:1527621419074};\\\", \\\"{x:613,y:514,t:1527621419139};\\\", \\\"{x:613,y:513,t:1527621419162};\\\", \\\"{x:613,y:516,t:1527621421923};\\\", \\\"{x:612,y:524,t:1527621421941};\\\", \\\"{x:607,y:535,t:1527621421960};\\\", \\\"{x:596,y:550,t:1527621421976};\\\", \\\"{x:564,y:590,t:1527621422009};\\\", \\\"{x:545,y:609,t:1527621422025};\\\", \\\"{x:526,y:626,t:1527621422041};\\\", \\\"{x:497,y:651,t:1527621422058};\\\", \\\"{x:483,y:669,t:1527621422075};\\\", \\\"{x:472,y:683,t:1527621422092};\\\", \\\"{x:470,y:692,t:1527621422108};\\\", \\\"{x:468,y:696,t:1527621422125};\\\", \\\"{x:468,y:698,t:1527621422140};\\\", \\\"{x:468,y:699,t:1527621422158};\\\", \\\"{x:468,y:701,t:1527621422175};\\\", \\\"{x:472,y:703,t:1527621422191};\\\", \\\"{x:475,y:704,t:1527621422208};\\\", \\\"{x:480,y:708,t:1527621422224};\\\", \\\"{x:484,y:712,t:1527621422241};\\\", \\\"{x:491,y:722,t:1527621422259};\\\", \\\"{x:496,y:733,t:1527621422275};\\\", \\\"{x:501,y:747,t:1527621422292};\\\", \\\"{x:507,y:758,t:1527621422308};\\\", \\\"{x:512,y:769,t:1527621422326};\\\", \\\"{x:516,y:777,t:1527621422342};\\\", \\\"{x:516,y:781,t:1527621422358};\\\", \\\"{x:517,y:783,t:1527621422375};\\\", \\\"{x:517,y:784,t:1527621422392};\\\", \\\"{x:517,y:785,t:1527621422408};\\\", \\\"{x:516,y:785,t:1527621422474};\\\", \\\"{x:516,y:785,t:1527621422490};\\\", \\\"{x:515,y:785,t:1527621422523};\\\", \\\"{x:515,y:784,t:1527621422547};\\\", \\\"{x:515,y:782,t:1527621422558};\\\", \\\"{x:515,y:778,t:1527621422575};\\\", \\\"{x:515,y:775,t:1527621422592};\\\", \\\"{x:515,y:773,t:1527621422609};\\\", \\\"{x:515,y:772,t:1527621422625};\\\", \\\"{x:515,y:769,t:1527621422642};\\\", \\\"{x:515,y:768,t:1527621422660};\\\", \\\"{x:515,y:765,t:1527621422675};\\\", \\\"{x:515,y:764,t:1527621422698};\\\", \\\"{x:515,y:763,t:1527621422708};\\\", \\\"{x:516,y:761,t:1527621422725};\\\", \\\"{x:516,y:760,t:1527621422795};\\\", \\\"{x:516,y:759,t:1527621422808};\\\", \\\"{x:516,y:758,t:1527621422825};\\\" ] }, { \\\"rt\\\": 123519, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 996902, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The events at 12 pm can be determined by the x and y axis, along with the plotted points. The points that are directly above the 12 pm mark on the x axis are the events that start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 53818, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1051726, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 67336, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1120075, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 159716, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1281154, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"NVKL3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"papa\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"NVKL3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 304, dom: 808, initialDom: 871",
  "javascriptErrors": []
}