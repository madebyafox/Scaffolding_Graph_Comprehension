var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052555459e31570da92f037a00c0f07deeaf0785"] = {
  "startTime": "2018-05-25T18:13:00.7945921Z",
  "websitePageUrl": "/",
  "visitTime": 75744,
  "engagementTime": 73147,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "b867df85a8e22987753e853fbed414f3",
    "created": "2018-05-25T18:13:00.7863455+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ca8995de80fed2871b812be3989d7f84",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b867df85a8e22987753e853fbed414f3/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 685,
      "y": 585
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 675,
      "y": 541
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 47929,
      "y": 33912,
      "ta": "html > body"
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 625,
      "y": 503
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 527,
      "y": 476
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 33989,
      "y": 29777,
      "ta": "html > body"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 444,
      "y": 476
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 339,
      "y": 479
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 219,
      "y": 428
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 15162,
      "y": 26723,
      "ta": "html > body"
    },
    {
      "t": 4539,
      "e": 4539,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 810,
      "y": 186
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 27619,
      "y": 10831,
      "ta": "html > body"
    },
    {
      "t": 4779,
      "e": 4779,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 829,
      "y": 185
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 948,
      "y": 221
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 967,
      "y": 226
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 33177,
      "y": 6512,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 33231,
      "y": 6512,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 968,
      "y": 226
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 969,
      "y": 226
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 33286,
      "y": 6512,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 972,
      "y": 224
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 974,
      "y": 221
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 33559,
      "y": 5939,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 975,
      "y": 219
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 975,
      "y": 218
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 33613,
      "y": 5857,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 36999,
      "y": 11345,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1076,
      "y": 364
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1116,
      "y": 439
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1118,
      "y": 443
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 41423,
      "y": 24288,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1113,
      "y": 443
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1030,
      "y": 502
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 34924,
      "y": 32644,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 994,
      "y": 558
    },
    {
      "t": 7848,
      "e": 7848,
      "ty": 3,
      "x": 994,
      "y": 558,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 994,
      "y": 560
    },
    {
      "t": 7991,
      "e": 7991,
      "ty": 4,
      "x": 34651,
      "y": 33873,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7991,
      "e": 7991,
      "ty": 5,
      "x": 994,
      "y": 560,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 34651,
      "y": 33873,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 34651,
      "y": 34037,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 994,
      "y": 574
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 983,
      "y": 647
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 970,
      "y": 713
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 33340,
      "y": 46406,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 965,
      "y": 787
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 964,
      "y": 822
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 32849,
      "y": 56810,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 961,
      "y": 840
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 961,
      "y": 832
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 971,
      "y": 808
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 33395,
      "y": 54189,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 972,
      "y": 806
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 973,
      "y": 805
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 33668,
      "y": 53042,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 979,
      "y": 788
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 2,
      "x": 986,
      "y": 770
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 34214,
      "y": 51076,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 987,
      "y": 769
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 34269,
      "y": 50994,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 2,
      "x": 988,
      "y": 766
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 41,
      "x": 34323,
      "y": 50748,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10701,
      "e": 10701,
      "ty": 2,
      "x": 987,
      "y": 765
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 34050,
      "y": 50666,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10801,
      "e": 10801,
      "ty": 2,
      "x": 981,
      "y": 763
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 33941,
      "y": 50502,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16301,
      "e": 16001,
      "ty": 2,
      "x": 980,
      "y": 759
    },
    {
      "t": 16402,
      "e": 16102,
      "ty": 2,
      "x": 982,
      "y": 753
    },
    {
      "t": 16501,
      "e": 16201,
      "ty": 2,
      "x": 982,
      "y": 752
    },
    {
      "t": 16501,
      "e": 16201,
      "ty": 41,
      "x": 33996,
      "y": 49601,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16601,
      "e": 16301,
      "ty": 2,
      "x": 982,
      "y": 751
    },
    {
      "t": 16752,
      "e": 16452,
      "ty": 41,
      "x": 33996,
      "y": 49519,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16801,
      "e": 16501,
      "ty": 2,
      "x": 982,
      "y": 750
    },
    {
      "t": 16901,
      "e": 16601,
      "ty": 2,
      "x": 985,
      "y": 735
    },
    {
      "t": 17001,
      "e": 16701,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 17002,
      "e": 16702,
      "ty": 2,
      "x": 985,
      "y": 801
    },
    {
      "t": 17002,
      "e": 16702,
      "ty": 41,
      "x": 34160,
      "y": 49274,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17701,
      "e": 17401,
      "ty": 2,
      "x": 988,
      "y": 810
    },
    {
      "t": 17751,
      "e": 17451,
      "ty": 41,
      "x": 34979,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17802,
      "e": 17502,
      "ty": 2,
      "x": 1006,
      "y": 875
    },
    {
      "t": 17901,
      "e": 17601,
      "ty": 2,
      "x": 1006,
      "y": 892
    },
    {
      "t": 18002,
      "e": 17702,
      "ty": 41,
      "x": 35306,
      "y": 56728,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18030,
      "e": 17730,
      "ty": 3,
      "x": 1006,
      "y": 892,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18191,
      "e": 17891,
      "ty": 4,
      "x": 35306,
      "y": 56728,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18191,
      "e": 17891,
      "ty": 5,
      "x": 1006,
      "y": 892,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18401,
      "e": 18101,
      "ty": 2,
      "x": 1006,
      "y": 885
    },
    {
      "t": 18500,
      "e": 18200,
      "ty": 2,
      "x": 1007,
      "y": 869
    },
    {
      "t": 18500,
      "e": 18200,
      "ty": 41,
      "x": 35361,
      "y": 54844,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18601,
      "e": 18301,
      "ty": 2,
      "x": 1015,
      "y": 823
    },
    {
      "t": 18752,
      "e": 18452,
      "ty": 41,
      "x": 35798,
      "y": 51076,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19001,
      "e": 18701,
      "ty": 2,
      "x": 1015,
      "y": 821
    },
    {
      "t": 19001,
      "e": 18701,
      "ty": 41,
      "x": 35798,
      "y": 50912,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19102,
      "e": 18802,
      "ty": 2,
      "x": 1016,
      "y": 820
    },
    {
      "t": 19251,
      "e": 18951,
      "ty": 41,
      "x": 35743,
      "y": 50994,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19301,
      "e": 19001,
      "ty": 2,
      "x": 1009,
      "y": 827
    },
    {
      "t": 19401,
      "e": 19101,
      "ty": 2,
      "x": 1005,
      "y": 830
    },
    {
      "t": 19501,
      "e": 19201,
      "ty": 41,
      "x": 35252,
      "y": 51649,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19901,
      "e": 19601,
      "ty": 2,
      "x": 1001,
      "y": 828
    },
    {
      "t": 20002,
      "e": 19702,
      "ty": 2,
      "x": 996,
      "y": 824
    },
    {
      "t": 20002,
      "e": 19702,
      "ty": 41,
      "x": 34760,
      "y": 51158,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20002,
      "e": 19702,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21401,
      "e": 21101,
      "ty": 2,
      "x": 984,
      "y": 821
    },
    {
      "t": 21501,
      "e": 21201,
      "ty": 2,
      "x": 980,
      "y": 821
    },
    {
      "t": 21502,
      "e": 21202,
      "ty": 41,
      "x": 33887,
      "y": 50912,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 21601,
      "e": 21301,
      "ty": 2,
      "x": 990,
      "y": 867
    },
    {
      "t": 21702,
      "e": 21402,
      "ty": 2,
      "x": 995,
      "y": 877
    },
    {
      "t": 21752,
      "e": 21452,
      "ty": 41,
      "x": 34706,
      "y": 55499,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22101,
      "e": 21801,
      "ty": 2,
      "x": 995,
      "y": 872
    },
    {
      "t": 22252,
      "e": 21952,
      "ty": 41,
      "x": 34706,
      "y": 55090,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22402,
      "e": 22102,
      "ty": 2,
      "x": 983,
      "y": 849
    },
    {
      "t": 22431,
      "e": 22131,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 22501,
      "e": 22201,
      "ty": 2,
      "x": 939,
      "y": 837
    },
    {
      "t": 22501,
      "e": 22201,
      "ty": 41,
      "x": 32061,
      "y": 45924,
      "ta": "html > body"
    },
    {
      "t": 22601,
      "e": 22301,
      "ty": 2,
      "x": 934,
      "y": 837
    },
    {
      "t": 22751,
      "e": 22451,
      "ty": 41,
      "x": 31889,
      "y": 45924,
      "ta": "html > body"
    },
    {
      "t": 22801,
      "e": 22501,
      "ty": 2,
      "x": 934,
      "y": 836
    },
    {
      "t": 22901,
      "e": 22601,
      "ty": 2,
      "x": 934,
      "y": 835
    },
    {
      "t": 23002,
      "e": 22702,
      "ty": 41,
      "x": 31889,
      "y": 45813,
      "ta": "html > body"
    },
    {
      "t": 23516,
      "e": 23216,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 29501,
      "e": 27702,
      "ty": 2,
      "x": 1113,
      "y": 774
    },
    {
      "t": 29501,
      "e": 27702,
      "ty": 41,
      "x": 40319,
      "y": 47286,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 29600,
      "e": 27801,
      "ty": 2,
      "x": 1111,
      "y": 798
    },
    {
      "t": 29701,
      "e": 27902,
      "ty": 2,
      "x": 1075,
      "y": 816
    },
    {
      "t": 29751,
      "e": 27952,
      "ty": 41,
      "x": 37170,
      "y": 15231,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 29800,
      "e": 28001,
      "ty": 2,
      "x": 1017,
      "y": 894
    },
    {
      "t": 29900,
      "e": 28101,
      "ty": 2,
      "x": 1012,
      "y": 903
    },
    {
      "t": 30001,
      "e": 28202,
      "ty": 2,
      "x": 1010,
      "y": 906
    },
    {
      "t": 30001,
      "e": 28202,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30003,
      "e": 28204,
      "ty": 41,
      "x": 35251,
      "y": 2295,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 30101,
      "e": 28302,
      "ty": 2,
      "x": 1010,
      "y": 917
    },
    {
      "t": 30201,
      "e": 28402,
      "ty": 2,
      "x": 1010,
      "y": 919
    },
    {
      "t": 30230,
      "e": 28431,
      "ty": 3,
      "x": 1010,
      "y": 919,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 30251,
      "e": 28452,
      "ty": 41,
      "x": 43372,
      "y": 32814,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 30350,
      "e": 28551,
      "ty": 4,
      "x": 43372,
      "y": 32814,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 30350,
      "e": 28551,
      "ty": 5,
      "x": 1010,
      "y": 919,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 30351,
      "e": 28552,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 30354,
      "e": 28555,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 30500,
      "e": 28701,
      "ty": 2,
      "x": 1011,
      "y": 945
    },
    {
      "t": 30500,
      "e": 28701,
      "ty": 41,
      "x": 35301,
      "y": 56692,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 30600,
      "e": 28801,
      "ty": 2,
      "x": 1021,
      "y": 1015
    },
    {
      "t": 30701,
      "e": 28902,
      "ty": 2,
      "x": 1024,
      "y": 1040
    },
    {
      "t": 30750,
      "e": 28951,
      "ty": 41,
      "x": 35891,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 30801,
      "e": 29002,
      "ty": 2,
      "x": 1020,
      "y": 1053
    },
    {
      "t": 30876,
      "e": 29077,
      "ty": 6,
      "x": 1015,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 30901,
      "e": 29102,
      "ty": 2,
      "x": 1015,
      "y": 1074
    },
    {
      "t": 31001,
      "e": 29202,
      "ty": 2,
      "x": 1014,
      "y": 1082
    },
    {
      "t": 31001,
      "e": 29202,
      "ty": 41,
      "x": 57070,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 31100,
      "e": 29301,
      "ty": 2,
      "x": 1012,
      "y": 1086
    },
    {
      "t": 31119,
      "e": 29320,
      "ty": 3,
      "x": 1012,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 31121,
      "e": 29322,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 31122,
      "e": 29323,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 31246,
      "e": 29447,
      "ty": 4,
      "x": 55977,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 31248,
      "e": 29449,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 31248,
      "e": 29449,
      "ty": 5,
      "x": 1012,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 31248,
      "e": 29449,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 31251,
      "e": 29452,
      "ty": 41,
      "x": 34575,
      "y": 59718,
      "ta": "html > body"
    },
    {
      "t": 32001,
      "e": 30202,
      "ty": 2,
      "x": 1025,
      "y": 1054
    },
    {
      "t": 32001,
      "e": 30202,
      "ty": 41,
      "x": 35023,
      "y": 57945,
      "ta": "html > body"
    },
    {
      "t": 32101,
      "e": 30302,
      "ty": 2,
      "x": 1028,
      "y": 1050
    },
    {
      "t": 32254,
      "e": 30455,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 32260,
      "e": 30461,
      "ty": 41,
      "x": 35126,
      "y": 57723,
      "ta": "html > body"
    },
    {
      "t": 33201,
      "e": 31402,
      "ty": 2,
      "x": 1031,
      "y": 1050
    },
    {
      "t": 33251,
      "e": 31452,
      "ty": 41,
      "x": 35264,
      "y": 57003,
      "ta": "html > body"
    },
    {
      "t": 33301,
      "e": 31502,
      "ty": 2,
      "x": 1037,
      "y": 983
    },
    {
      "t": 33401,
      "e": 31602,
      "ty": 2,
      "x": 1012,
      "y": 852
    },
    {
      "t": 33501,
      "e": 31702,
      "ty": 2,
      "x": 971,
      "y": 774
    },
    {
      "t": 33501,
      "e": 31702,
      "ty": 41,
      "x": 33163,
      "y": 42434,
      "ta": "html > body"
    },
    {
      "t": 33580,
      "e": 31781,
      "ty": 6,
      "x": 959,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33601,
      "e": 31802,
      "ty": 2,
      "x": 959,
      "y": 725
    },
    {
      "t": 33629,
      "e": 31830,
      "ty": 7,
      "x": 959,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 33629,
      "e": 31830,
      "ty": 6,
      "x": 959,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33662,
      "e": 31863,
      "ty": 7,
      "x": 966,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33700,
      "e": 31901,
      "ty": 2,
      "x": 973,
      "y": 646
    },
    {
      "t": 33750,
      "e": 31951,
      "ty": 41,
      "x": 36985,
      "y": 10570,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 33800,
      "e": 32001,
      "ty": 2,
      "x": 986,
      "y": 617
    },
    {
      "t": 33830,
      "e": 32031,
      "ty": 6,
      "x": 991,
      "y": 601,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33900,
      "e": 32101,
      "ty": 2,
      "x": 997,
      "y": 595
    },
    {
      "t": 34001,
      "e": 32202,
      "ty": 2,
      "x": 1003,
      "y": 586
    },
    {
      "t": 34001,
      "e": 32202,
      "ty": 41,
      "x": 42175,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34054,
      "e": 32255,
      "ty": 3,
      "x": 1003,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34055,
      "e": 32256,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34158,
      "e": 32359,
      "ty": 4,
      "x": 42175,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34158,
      "e": 32359,
      "ty": 5,
      "x": 1003,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35080,
      "e": 33281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 35272,
      "e": 33473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 37519,
      "e": 35720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 37519,
      "e": 35720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37639,
      "e": 35840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 38024,
      "e": 36225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 38024,
      "e": 36225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38135,
      "e": 36336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NO"
    },
    {
      "t": 38671,
      "e": 36872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 38671,
      "e": 36872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38799,
      "e": 37000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOV"
    },
    {
      "t": 38823,
      "e": 37024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 38823,
      "e": 37024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38975,
      "e": 37176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVE"
    },
    {
      "t": 39031,
      "e": 37232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 39033,
      "e": 37234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39150,
      "e": 37351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||M"
    },
    {
      "t": 39279,
      "e": 37480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 39279,
      "e": 37480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39368,
      "e": 37569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||B"
    },
    {
      "t": 39407,
      "e": 37608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 39408,
      "e": 37609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39519,
      "e": 37720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 39599,
      "e": 37800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 39599,
      "e": 37800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39679,
      "e": 37880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 40001,
      "e": 38202,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 41352,
      "e": 39553,
      "ty": 7,
      "x": 1005,
      "y": 626,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41401,
      "e": 39602,
      "ty": 2,
      "x": 1007,
      "y": 640
    },
    {
      "t": 41500,
      "e": 39701,
      "ty": 2,
      "x": 1007,
      "y": 646
    },
    {
      "t": 41501,
      "e": 39702,
      "ty": 41,
      "x": 43041,
      "y": 30426,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 41601,
      "e": 39802,
      "ty": 2,
      "x": 989,
      "y": 672
    },
    {
      "t": 41680,
      "e": 39881,
      "ty": 6,
      "x": 988,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41701,
      "e": 39902,
      "ty": 2,
      "x": 988,
      "y": 683
    },
    {
      "t": 41735,
      "e": 39936,
      "ty": 7,
      "x": 982,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41751,
      "e": 39952,
      "ty": 41,
      "x": 37633,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41801,
      "e": 40002,
      "ty": 2,
      "x": 982,
      "y": 701
    },
    {
      "t": 41901,
      "e": 40102,
      "ty": 2,
      "x": 982,
      "y": 702
    },
    {
      "t": 41951,
      "e": 40152,
      "ty": 3,
      "x": 982,
      "y": 702,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41952,
      "e": 40153,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "NOVEMBER"
    },
    {
      "t": 41952,
      "e": 40153,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42001,
      "e": 40202,
      "ty": 41,
      "x": 37633,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 42013,
      "e": 40214,
      "ty": 4,
      "x": 37633,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 42013,
      "e": 40214,
      "ty": 5,
      "x": 982,
      "y": 702,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 42201,
      "e": 40402,
      "ty": 2,
      "x": 982,
      "y": 703
    },
    {
      "t": 42236,
      "e": 40437,
      "ty": 6,
      "x": 985,
      "y": 697,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42251,
      "e": 40452,
      "ty": 41,
      "x": 38282,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42301,
      "e": 40502,
      "ty": 2,
      "x": 986,
      "y": 696
    },
    {
      "t": 42462,
      "e": 40663,
      "ty": 3,
      "x": 986,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42464,
      "e": 40665,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42502,
      "e": 40703,
      "ty": 41,
      "x": 38499,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42574,
      "e": 40775,
      "ty": 4,
      "x": 38499,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42575,
      "e": 40776,
      "ty": 5,
      "x": 986,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43927,
      "e": 42128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 43928,
      "e": 42129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44030,
      "e": 42231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 44151,
      "e": 42352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 44151,
      "e": 42352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44262,
      "e": 42463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 44303,
      "e": 42504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 44303,
      "e": 42504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44405,
      "e": 42606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 44423,
      "e": 42624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 44591,
      "e": 42792,
      "ty": 7,
      "x": 986,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44601,
      "e": 42802,
      "ty": 2,
      "x": 986,
      "y": 702
    },
    {
      "t": 44621,
      "e": 42822,
      "ty": 6,
      "x": 986,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44701,
      "e": 42902,
      "ty": 2,
      "x": 986,
      "y": 720
    },
    {
      "t": 44751,
      "e": 42952,
      "ty": 41,
      "x": 46425,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44801,
      "e": 43002,
      "ty": 2,
      "x": 986,
      "y": 735
    },
    {
      "t": 45001,
      "e": 43202,
      "ty": 41,
      "x": 46425,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45118,
      "e": 43319,
      "ty": 3,
      "x": 986,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45119,
      "e": 43320,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 45119,
      "e": 43320,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45119,
      "e": 43320,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45230,
      "e": 43431,
      "ty": 4,
      "x": 46425,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45230,
      "e": 43431,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45230,
      "e": 43431,
      "ty": 5,
      "x": 986,
      "y": 735,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45231,
      "e": 43432,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46323,
      "e": 44524,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 46351,
      "e": 44552,
      "ty": 6,
      "x": 986,
      "y": 735,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 47401,
      "e": 45602,
      "ty": 2,
      "x": 982,
      "y": 732
    },
    {
      "t": 47502,
      "e": 45703,
      "ty": 2,
      "x": 981,
      "y": 732
    },
    {
      "t": 47502,
      "e": 45703,
      "ty": 41,
      "x": 32879,
      "y": 11739,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 47601,
      "e": 45802,
      "ty": 2,
      "x": 980,
      "y": 733
    },
    {
      "t": 47701,
      "e": 45902,
      "ty": 2,
      "x": 979,
      "y": 734
    },
    {
      "t": 47751,
      "e": 45952,
      "ty": 41,
      "x": 32778,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 47801,
      "e": 46002,
      "ty": 2,
      "x": 977,
      "y": 735
    },
    {
      "t": 47901,
      "e": 46102,
      "ty": 2,
      "x": 977,
      "y": 736
    },
    {
      "t": 48001,
      "e": 46202,
      "ty": 2,
      "x": 976,
      "y": 736
    },
    {
      "t": 48002,
      "e": 46203,
      "ty": 41,
      "x": 32626,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 48402,
      "e": 46603,
      "ty": 2,
      "x": 974,
      "y": 737
    },
    {
      "t": 48501,
      "e": 46702,
      "ty": 2,
      "x": 974,
      "y": 738
    },
    {
      "t": 48502,
      "e": 46703,
      "ty": 41,
      "x": 32525,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 49702,
      "e": 47903,
      "ty": 2,
      "x": 980,
      "y": 751
    },
    {
      "t": 49743,
      "e": 47944,
      "ty": 7,
      "x": 981,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 49743,
      "e": 47944,
      "ty": 6,
      "x": 981,
      "y": 755,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 49752,
      "e": 47953,
      "ty": 41,
      "x": 32879,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 49801,
      "e": 48002,
      "ty": 2,
      "x": 983,
      "y": 770
    },
    {
      "t": 49825,
      "e": 48026,
      "ty": 7,
      "x": 994,
      "y": 793,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 49901,
      "e": 48102,
      "ty": 2,
      "x": 1015,
      "y": 828
    },
    {
      "t": 50001,
      "e": 48202,
      "ty": 2,
      "x": 1026,
      "y": 834
    },
    {
      "t": 50002,
      "e": 48203,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50002,
      "e": 48203,
      "ty": 41,
      "x": 36039,
      "y": 49006,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 55800,
      "e": 53203,
      "ty": 2,
      "x": 1047,
      "y": 825
    },
    {
      "t": 55846,
      "e": 53249,
      "ty": 6,
      "x": 1207,
      "y": 745,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55864,
      "e": 53267,
      "ty": 7,
      "x": 1280,
      "y": 721,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55864,
      "e": 53267,
      "ty": 6,
      "x": 1280,
      "y": 721,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 55901,
      "e": 53304,
      "ty": 2,
      "x": 1365,
      "y": 701
    },
    {
      "t": 55914,
      "e": 53317,
      "ty": 7,
      "x": 1383,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 55914,
      "e": 53317,
      "ty": 6,
      "x": 1383,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 56000,
      "e": 53403,
      "ty": 2,
      "x": 1419,
      "y": 685
    },
    {
      "t": 56001,
      "e": 53404,
      "ty": 41,
      "x": 55070,
      "y": 32804,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 56096,
      "e": 53499,
      "ty": 7,
      "x": 1413,
      "y": 670,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 56101,
      "e": 53504,
      "ty": 2,
      "x": 1413,
      "y": 670
    },
    {
      "t": 56200,
      "e": 53603,
      "ty": 2,
      "x": 1395,
      "y": 545
    },
    {
      "t": 56250,
      "e": 53653,
      "ty": 41,
      "x": 54192,
      "y": 25809,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 56300,
      "e": 53703,
      "ty": 2,
      "x": 1395,
      "y": 530
    },
    {
      "t": 56401,
      "e": 53804,
      "ty": 2,
      "x": 1394,
      "y": 526
    },
    {
      "t": 56500,
      "e": 53903,
      "ty": 2,
      "x": 1368,
      "y": 516
    },
    {
      "t": 56501,
      "e": 53904,
      "ty": 41,
      "x": 52864,
      "y": 18584,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 56601,
      "e": 54004,
      "ty": 2,
      "x": 1292,
      "y": 554
    },
    {
      "t": 56701,
      "e": 54104,
      "ty": 2,
      "x": 1215,
      "y": 635
    },
    {
      "t": 56750,
      "e": 54153,
      "ty": 41,
      "x": 44894,
      "y": 42166,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 56801,
      "e": 54204,
      "ty": 2,
      "x": 1186,
      "y": 652
    },
    {
      "t": 56901,
      "e": 54304,
      "ty": 2,
      "x": 1111,
      "y": 662
    },
    {
      "t": 56948,
      "e": 54351,
      "ty": 6,
      "x": 1084,
      "y": 672,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 57000,
      "e": 54403,
      "ty": 2,
      "x": 1050,
      "y": 692
    },
    {
      "t": 57001,
      "e": 54404,
      "ty": 41,
      "x": 36375,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 57014,
      "e": 54417,
      "ty": 7,
      "x": 1043,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 57014,
      "e": 54417,
      "ty": 6,
      "x": 1043,
      "y": 700,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 57081,
      "e": 54484,
      "ty": 7,
      "x": 1016,
      "y": 736,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 57082,
      "e": 54485,
      "ty": 6,
      "x": 1016,
      "y": 736,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 57101,
      "e": 54504,
      "ty": 2,
      "x": 1011,
      "y": 747
    },
    {
      "t": 57114,
      "e": 54517,
      "ty": 7,
      "x": 1009,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 57114,
      "e": 54517,
      "ty": 6,
      "x": 1009,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 57147,
      "e": 54550,
      "ty": 7,
      "x": 1002,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 57201,
      "e": 54604,
      "ty": 2,
      "x": 994,
      "y": 814
    },
    {
      "t": 57250,
      "e": 54653,
      "ty": 41,
      "x": 33825,
      "y": 50806,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57300,
      "e": 54703,
      "ty": 2,
      "x": 969,
      "y": 891
    },
    {
      "t": 57401,
      "e": 54804,
      "ty": 2,
      "x": 964,
      "y": 933
    },
    {
      "t": 57501,
      "e": 54904,
      "ty": 2,
      "x": 994,
      "y": 993
    },
    {
      "t": 57501,
      "e": 54904,
      "ty": 41,
      "x": 34464,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57600,
      "e": 55003,
      "ty": 2,
      "x": 1009,
      "y": 1024
    },
    {
      "t": 57701,
      "e": 55104,
      "ty": 2,
      "x": 1009,
      "y": 1030
    },
    {
      "t": 57751,
      "e": 55154,
      "ty": 41,
      "x": 35005,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57800,
      "e": 55203,
      "ty": 2,
      "x": 1005,
      "y": 1057
    },
    {
      "t": 57836,
      "e": 55239,
      "ty": 6,
      "x": 1002,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 57899,
      "e": 55302,
      "ty": 7,
      "x": 993,
      "y": 1118,
      "ta": "#start"
    },
    {
      "t": 57901,
      "e": 55304,
      "ty": 2,
      "x": 993,
      "y": 1118
    },
    {
      "t": 58000,
      "e": 55403,
      "ty": 2,
      "x": 988,
      "y": 1133
    },
    {
      "t": 58000,
      "e": 55403,
      "ty": 41,
      "x": 46108,
      "y": 33412,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 58100,
      "e": 55503,
      "ty": 2,
      "x": 984,
      "y": 1124
    },
    {
      "t": 58182,
      "e": 55585,
      "ty": 6,
      "x": 989,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 58200,
      "e": 55603,
      "ty": 2,
      "x": 991,
      "y": 1100
    },
    {
      "t": 58250,
      "e": 55653,
      "ty": 41,
      "x": 45055,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 58301,
      "e": 55704,
      "ty": 2,
      "x": 992,
      "y": 1096
    },
    {
      "t": 58401,
      "e": 55804,
      "ty": 2,
      "x": 994,
      "y": 1094
    },
    {
      "t": 58501,
      "e": 55904,
      "ty": 41,
      "x": 46147,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 58647,
      "e": 56050,
      "ty": 3,
      "x": 994,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 58648,
      "e": 56051,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 58797,
      "e": 56200,
      "ty": 4,
      "x": 46147,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 58798,
      "e": 56201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 58799,
      "e": 56202,
      "ty": 5,
      "x": 994,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 58800,
      "e": 56203,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 59499,
      "e": 56902,
      "ty": 2,
      "x": 1404,
      "y": 930
    },
    {
      "t": 59499,
      "e": 56902,
      "ty": 41,
      "x": 48075,
      "y": 51076,
      "ta": "html > body"
    },
    {
      "t": 59599,
      "e": 57002,
      "ty": 2,
      "x": 1738,
      "y": 856
    },
    {
      "t": 59699,
      "e": 57102,
      "ty": 2,
      "x": 1735,
      "y": 851
    },
    {
      "t": 59749,
      "e": 57152,
      "ty": 41,
      "x": 52104,
      "y": 44096,
      "ta": "html > body"
    },
    {
      "t": 59799,
      "e": 57202,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 59801,
      "e": 57204,
      "ty": 2,
      "x": 1187,
      "y": 712
    },
    {
      "t": 59899,
      "e": 57302,
      "ty": 2,
      "x": 1083,
      "y": 671
    },
    {
      "t": 59999,
      "e": 57402,
      "ty": 41,
      "x": 38762,
      "y": 40804,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 59999,
      "e": 57402,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60899,
      "e": 58302,
      "ty": 2,
      "x": 1082,
      "y": 671
    },
    {
      "t": 61000,
      "e": 58403,
      "ty": 41,
      "x": 33568,
      "y": 36222,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 61000,
      "e": 58403,
      "ty": 2,
      "x": 976,
      "y": 612
    },
    {
      "t": 61100,
      "e": 58503,
      "ty": 2,
      "x": 878,
      "y": 570
    },
    {
      "t": 61199,
      "e": 58602,
      "ty": 2,
      "x": 743,
      "y": 535
    },
    {
      "t": 61250,
      "e": 58653,
      "ty": 41,
      "x": 19976,
      "y": 29079,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 61299,
      "e": 58702,
      "ty": 2,
      "x": 630,
      "y": 503
    },
    {
      "t": 61399,
      "e": 58802,
      "ty": 2,
      "x": 598,
      "y": 494
    },
    {
      "t": 61500,
      "e": 58903,
      "ty": 2,
      "x": 531,
      "y": 453
    },
    {
      "t": 61500,
      "e": 58903,
      "ty": 41,
      "x": 11966,
      "y": 23876,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 61600,
      "e": 59003,
      "ty": 2,
      "x": 527,
      "y": 450
    },
    {
      "t": 61699,
      "e": 59102,
      "ty": 2,
      "x": 562,
      "y": 443
    },
    {
      "t": 61750,
      "e": 59153,
      "ty": 41,
      "x": 18374,
      "y": 24963,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 61799,
      "e": 59202,
      "ty": 2,
      "x": 733,
      "y": 484
    },
    {
      "t": 61900,
      "e": 59303,
      "ty": 2,
      "x": 745,
      "y": 485
    },
    {
      "t": 61999,
      "e": 59402,
      "ty": 2,
      "x": 790,
      "y": 493
    },
    {
      "t": 62000,
      "e": 59403,
      "ty": 41,
      "x": 24539,
      "y": 26982,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62099,
      "e": 59502,
      "ty": 2,
      "x": 885,
      "y": 516
    },
    {
      "t": 62200,
      "e": 59603,
      "ty": 2,
      "x": 898,
      "y": 519
    },
    {
      "t": 62249,
      "e": 59652,
      "ty": 41,
      "x": 29976,
      "y": 29001,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62299,
      "e": 59702,
      "ty": 2,
      "x": 911,
      "y": 523
    },
    {
      "t": 62399,
      "e": 59802,
      "ty": 2,
      "x": 962,
      "y": 535
    },
    {
      "t": 62499,
      "e": 59902,
      "ty": 2,
      "x": 1036,
      "y": 555
    },
    {
      "t": 62499,
      "e": 59902,
      "ty": 41,
      "x": 36481,
      "y": 31796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62599,
      "e": 60002,
      "ty": 2,
      "x": 1065,
      "y": 561
    },
    {
      "t": 62699,
      "e": 60102,
      "ty": 2,
      "x": 1087,
      "y": 564
    },
    {
      "t": 62749,
      "e": 60152,
      "ty": 41,
      "x": 39393,
      "y": 32651,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62800,
      "e": 60203,
      "ty": 2,
      "x": 1108,
      "y": 569
    },
    {
      "t": 62899,
      "e": 60302,
      "ty": 2,
      "x": 1125,
      "y": 573
    },
    {
      "t": 63000,
      "e": 60403,
      "ty": 41,
      "x": 40801,
      "y": 33194,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 63099,
      "e": 60502,
      "ty": 2,
      "x": 1122,
      "y": 573
    },
    {
      "t": 63250,
      "e": 60653,
      "ty": 41,
      "x": 40655,
      "y": 33194,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 65099,
      "e": 62502,
      "ty": 2,
      "x": 1132,
      "y": 575
    },
    {
      "t": 65199,
      "e": 62602,
      "ty": 2,
      "x": 1134,
      "y": 576
    },
    {
      "t": 65250,
      "e": 62653,
      "ty": 41,
      "x": 41384,
      "y": 33505,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 65299,
      "e": 62702,
      "ty": 2,
      "x": 1139,
      "y": 578
    },
    {
      "t": 65400,
      "e": 62803,
      "ty": 2,
      "x": 1142,
      "y": 580
    },
    {
      "t": 65500,
      "e": 62903,
      "ty": 2,
      "x": 1144,
      "y": 580
    },
    {
      "t": 65500,
      "e": 62903,
      "ty": 41,
      "x": 41723,
      "y": 33738,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 65599,
      "e": 63002,
      "ty": 2,
      "x": 1145,
      "y": 580
    },
    {
      "t": 65700,
      "e": 63103,
      "ty": 2,
      "x": 1146,
      "y": 581
    },
    {
      "t": 65750,
      "e": 63153,
      "ty": 41,
      "x": 41821,
      "y": 33815,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 66400,
      "e": 63803,
      "ty": 2,
      "x": 1147,
      "y": 582
    },
    {
      "t": 66499,
      "e": 63902,
      "ty": 2,
      "x": 1147,
      "y": 583
    },
    {
      "t": 66499,
      "e": 63902,
      "ty": 41,
      "x": 41869,
      "y": 33971,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 67399,
      "e": 64802,
      "ty": 2,
      "x": 1147,
      "y": 584
    },
    {
      "t": 67500,
      "e": 64903,
      "ty": 2,
      "x": 1108,
      "y": 584
    },
    {
      "t": 67500,
      "e": 64903,
      "ty": 41,
      "x": 39976,
      "y": 34048,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 67599,
      "e": 65002,
      "ty": 2,
      "x": 1077,
      "y": 607
    },
    {
      "t": 67699,
      "e": 65102,
      "ty": 2,
      "x": 1053,
      "y": 693
    },
    {
      "t": 67750,
      "e": 65153,
      "ty": 41,
      "x": 36966,
      "y": 47248,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 67799,
      "e": 65202,
      "ty": 2,
      "x": 1040,
      "y": 779
    },
    {
      "t": 67900,
      "e": 65303,
      "ty": 2,
      "x": 1030,
      "y": 825
    },
    {
      "t": 67999,
      "e": 65402,
      "ty": 2,
      "x": 1016,
      "y": 869
    },
    {
      "t": 67999,
      "e": 65402,
      "ty": 41,
      "x": 35510,
      "y": 56178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 68099,
      "e": 65502,
      "ty": 2,
      "x": 1013,
      "y": 884
    },
    {
      "t": 68200,
      "e": 65603,
      "ty": 2,
      "x": 1012,
      "y": 887
    },
    {
      "t": 68250,
      "e": 65653,
      "ty": 41,
      "x": 35267,
      "y": 57576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 68300,
      "e": 65703,
      "ty": 2,
      "x": 1011,
      "y": 887
    },
    {
      "t": 68399,
      "e": 65802,
      "ty": 2,
      "x": 1009,
      "y": 887
    },
    {
      "t": 68499,
      "e": 65902,
      "ty": 2,
      "x": 1008,
      "y": 886
    },
    {
      "t": 68500,
      "e": 65903,
      "ty": 41,
      "x": 35121,
      "y": 57498,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 68999,
      "e": 66402,
      "ty": 2,
      "x": 1007,
      "y": 886
    },
    {
      "t": 68999,
      "e": 66402,
      "ty": 41,
      "x": 35073,
      "y": 57498,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 69199,
      "e": 66602,
      "ty": 2,
      "x": 997,
      "y": 879
    },
    {
      "t": 69249,
      "e": 66652,
      "ty": 41,
      "x": 34587,
      "y": 56954,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 70000,
      "e": 67403,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70600,
      "e": 68003,
      "ty": 2,
      "x": 997,
      "y": 878
    },
    {
      "t": 70750,
      "e": 68153,
      "ty": 41,
      "x": 34587,
      "y": 56877,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 72300,
      "e": 69703,
      "ty": 2,
      "x": 998,
      "y": 877
    },
    {
      "t": 72400,
      "e": 69803,
      "ty": 2,
      "x": 1007,
      "y": 881
    },
    {
      "t": 72499,
      "e": 69902,
      "ty": 2,
      "x": 1040,
      "y": 892
    },
    {
      "t": 72501,
      "e": 69904,
      "ty": 41,
      "x": 36675,
      "y": 57964,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 72599,
      "e": 70002,
      "ty": 2,
      "x": 1112,
      "y": 904
    },
    {
      "t": 72700,
      "e": 70103,
      "ty": 2,
      "x": 1162,
      "y": 916
    },
    {
      "t": 72750,
      "e": 70153,
      "ty": 41,
      "x": 42743,
      "y": 59905,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 72800,
      "e": 70203,
      "ty": 2,
      "x": 1167,
      "y": 919
    },
    {
      "t": 72899,
      "e": 70302,
      "ty": 2,
      "x": 1170,
      "y": 920
    },
    {
      "t": 73000,
      "e": 70403,
      "ty": 2,
      "x": 1186,
      "y": 912
    },
    {
      "t": 73000,
      "e": 70403,
      "ty": 41,
      "x": 43762,
      "y": 59517,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 73099,
      "e": 70502,
      "ty": 2,
      "x": 1350,
      "y": 866
    },
    {
      "t": 73200,
      "e": 70603,
      "ty": 2,
      "x": 1467,
      "y": 860
    },
    {
      "t": 73250,
      "e": 70653,
      "ty": 41,
      "x": 57452,
      "y": 55324,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 73299,
      "e": 70702,
      "ty": 2,
      "x": 1459,
      "y": 853
    },
    {
      "t": 73400,
      "e": 70803,
      "ty": 2,
      "x": 1395,
      "y": 831
    },
    {
      "t": 73500,
      "e": 70903,
      "ty": 2,
      "x": 1368,
      "y": 826
    },
    {
      "t": 73500,
      "e": 70903,
      "ty": 41,
      "x": 52597,
      "y": 52839,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 73600,
      "e": 71003,
      "ty": 2,
      "x": 1235,
      "y": 811
    },
    {
      "t": 73700,
      "e": 71103,
      "ty": 2,
      "x": 1143,
      "y": 871
    },
    {
      "t": 73749,
      "e": 71152,
      "ty": 41,
      "x": 41675,
      "y": 57886,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 73800,
      "e": 71203,
      "ty": 2,
      "x": 1142,
      "y": 930
    },
    {
      "t": 73900,
      "e": 71303,
      "ty": 2,
      "x": 1121,
      "y": 990
    },
    {
      "t": 74000,
      "e": 71403,
      "ty": 2,
      "x": 1082,
      "y": 1017
    },
    {
      "t": 74000,
      "e": 71403,
      "ty": 41,
      "x": 36986,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 74100,
      "e": 71503,
      "ty": 2,
      "x": 1073,
      "y": 1018
    },
    {
      "t": 74199,
      "e": 71602,
      "ty": 2,
      "x": 1071,
      "y": 998
    },
    {
      "t": 74250,
      "e": 71653,
      "ty": 41,
      "x": 36607,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 74742,
      "e": 72145,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 75744,
      "e": 73147,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 271, dom: 817, initialDom: 1194",
  "javascriptErrors": []
}