var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05241665a2dc5f251f73b306b1a2621d3cf35765"] = {
  "startTime": "2018-05-24T19:15:16.6536865Z",
  "websitePageUrl": "/16",
  "visitTime": 77806,
  "engagementTime": 77254,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "8b40860556a4c18bd900649e393737c1",
    "created": "2018-05-24T19:15:16.6536865+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ZB1L5",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d270ea940c645aea4f7733c57bbbce49",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8b40860556a4c18bd900649e393737c1/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 651,
      "e": 651,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 838,
      "y": 705
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 2185,
      "y": 40108,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 808,
      "y": 696
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 803,
      "y": 692
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 791,
      "y": 683
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 353,
      "y": 39034,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 766,
      "y": 653
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 739,
      "y": 620
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 2692,
      "y": 33300,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 707,
      "y": 591
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 688,
      "y": 578
    },
    {
      "t": 2433,
      "e": 2433,
      "ty": 6,
      "x": 680,
      "y": 576,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 647,
      "y": 568
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 61814,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 637,
      "y": 564
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 60690,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6795,
      "e": 6795,
      "ty": 3,
      "x": 637,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6796,
      "e": 6796,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6913,
      "e": 6913,
      "ty": 4,
      "x": 60690,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6913,
      "e": 6913,
      "ty": 5,
      "x": 637,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9878,
      "e": 9878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10045,
      "e": 10045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10045,
      "e": 10045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10133,
      "e": 10133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 10221,
      "e": 10221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 10285,
      "e": 10285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10285,
      "e": 10285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 10453,
      "e": 10453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10454,
      "e": 10454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10461,
      "e": 10461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 10603,
      "e": 10603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 10621,
      "e": 10621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 10623,
      "e": 10623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10645,
      "e": 10645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find"
    },
    {
      "t": 10749,
      "e": 10749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12342,
      "e": 12342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12342,
      "e": 12342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13254,
      "e": 13254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 13255,
      "e": 13255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13390,
      "e": 13390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 13390,
      "e": 13390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13493,
      "e": 13493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 13565,
      "e": 13565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13614,
      "e": 13614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13615,
      "e": 13615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13725,
      "e": 13725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15478,
      "e": 15478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 15678,
      "e": 15678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15679,
      "e": 15679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15801,
      "e": 15801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 P"
    },
    {
      "t": 15862,
      "e": 15862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 15886,
      "e": 15886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16510,
      "e": 16510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16574,
      "e": 16574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16575,
      "e": 16575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16733,
      "e": 16733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 16741,
      "e": 16741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16781,
      "e": 16781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16782,
      "e": 16782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16901,
      "e": 16901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17271,
      "e": 17271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17271,
      "e": 17271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17373,
      "e": 17373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17469,
      "e": 17469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17470,
      "e": 17470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17590,
      "e": 17590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17591,
      "e": 17591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17646,
      "e": 17646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 17742,
      "e": 17742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17782,
      "e": 17782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17782,
      "e": 17782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17845,
      "e": 17845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17845,
      "e": 17845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17885,
      "e": 17885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 17981,
      "e": 17981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17982,
      "e": 17982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18037,
      "e": 18037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18037,
      "e": 18037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18061,
      "e": 18061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 18086,
      "e": 18086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18190,
      "e": 18190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18382,
      "e": 18382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18383,
      "e": 18383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18654,
      "e": 18654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18654,
      "e": 18654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18789,
      "e": 18789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18790,
      "e": 18790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18798,
      "e": 18798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||or"
    },
    {
      "t": 18917,
      "e": 18917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18917,
      "e": 18917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18941,
      "e": 18941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19054,
      "e": 19054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19262,
      "e": 19262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 19263,
      "e": 19263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19402,
      "e": 19402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horiz"
    },
    {
      "t": 19453,
      "e": 19453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 19613,
      "e": 19613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19613,
      "e": 19613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19741,
      "e": 19741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19742,
      "e": 19742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19765,
      "e": 19765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 19878,
      "e": 19878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19879,
      "e": 19879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19901,
      "e": 19901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizont"
    },
    {
      "t": 20013,
      "e": 20013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20013,
      "e": 20013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20037,
      "e": 20037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20141,
      "e": 20141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20141,
      "e": 20141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20230,
      "e": 20230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20270,
      "e": 20270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20270,
      "e": 20270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20340,
      "e": 20340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20405,
      "e": 20405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20594,
      "e": 20594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20594,
      "e": 20594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20682,
      "e": 20682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20778,
      "e": 20778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20778,
      "e": 20778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20953,
      "e": 20953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20953,
      "e": 20953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21034,
      "e": 21034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21034,
      "e": 21034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21056,
      "e": 21056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line"
    },
    {
      "t": 21209,
      "e": 21209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21210,
      "e": 21210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21241,
      "e": 21241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21337,
      "e": 21337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21554,
      "e": 21554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21554,
      "e": 21554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21658,
      "e": 21658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21659,
      "e": 21659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21681,
      "e": 21681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 21785,
      "e": 21785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21802,
      "e": 21802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21803,
      "e": 21803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21937,
      "e": 21937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21937,
      "e": 21937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21969,
      "e": 21969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 22042,
      "e": 22042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22266,
      "e": 22266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22267,
      "e": 22267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22377,
      "e": 22377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22377,
      "e": 22377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22417,
      "e": 22417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 22521,
      "e": 22521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22521,
      "e": 22521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22569,
      "e": 22569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22666,
      "e": 22666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23002,
      "e": 23002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23177,
      "e": 23177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23186,
      "e": 23186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23186,
      "e": 23186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23288,
      "e": 23288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23417,
      "e": 23417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23417,
      "e": 23417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23561,
      "e": 23561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23858,
      "e": 23858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23858,
      "e": 23858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24006,
      "e": 24006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go stra"
    },
    {
      "t": 24009,
      "e": 24009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24010,
      "e": 24010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24016,
      "e": 24016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ai"
    },
    {
      "t": 24106,
      "e": 24106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24106,
      "e": 24106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24146,
      "e": 24146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 24226,
      "e": 24226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24242,
      "e": 24242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24242,
      "e": 24242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24336,
      "e": 24336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24336,
      "e": 24336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24369,
      "e": 24369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 24441,
      "e": 24441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24441,
      "e": 24441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24490,
      "e": 24490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24585,
      "e": 24585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24633,
      "e": 24633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 24633,
      "e": 24633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24785,
      "e": 24785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24787,
      "e": 24787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24793,
      "e": 24793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 24921,
      "e": 24921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24921,
      "e": 24921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24969,
      "e": 24969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25057,
      "e": 25057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25058,
      "e": 25058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25059,
      "e": 25059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25184,
      "e": 25184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25186,
      "e": 25186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25226,
      "e": 25226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 25298,
      "e": 25298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25299,
      "e": 25299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25336,
      "e": 25336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25441,
      "e": 25441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25441,
      "e": 25441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25441,
      "e": 25441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25552,
      "e": 25552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25553,
      "e": 25553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25584,
      "e": 25584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 25625,
      "e": 25625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25737,
      "e": 25737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25740,
      "e": 25740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25809,
      "e": 25809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25810,
      "e": 25810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25857,
      "e": 25857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 25945,
      "e": 25945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26025,
      "e": 26025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26026,
      "e": 26026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26089,
      "e": 26089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26089,
      "e": 26089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26153,
      "e": 26153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||if"
    },
    {
      "t": 26217,
      "e": 26217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26225,
      "e": 26225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26225,
      "e": 26225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26345,
      "e": 26345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26347,
      "e": 26347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26353,
      "e": 26353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 26433,
      "e": 26433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26433,
      "e": 26433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26448,
      "e": 26448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26529,
      "e": 26529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26531,
      "e": 26530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26561,
      "e": 26560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26633,
      "e": 26632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26633,
      "e": 26632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26657,
      "e": 26656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 26777,
      "e": 26776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26778,
      "e": 26777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26801,
      "e": 26800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26897,
      "e": 26896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26897,
      "e": 26896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26913,
      "e": 26912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27009,
      "e": 27008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27025,
      "e": 27024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27026,
      "e": 27025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27145,
      "e": 27144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27147,
      "e": 27146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27193,
      "e": 27192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 27201,
      "e": 27200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27201,
      "e": 27200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27305,
      "e": 27304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27330,
      "e": 27329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27331,
      "e": 27330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27393,
      "e": 27392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27449,
      "e": 27448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27584,
      "e": 27583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27584,
      "e": 27583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27745,
      "e": 27744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27881,
      "e": 27880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27882,
      "e": 27881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27985,
      "e": 27984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28209,
      "e": 28208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28213,
      "e": 28212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28305,
      "e": 28304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28305,
      "e": 28304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28328,
      "e": 28327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 28416,
      "e": 28415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28450,
      "e": 28449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28450,
      "e": 28449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28585,
      "e": 28584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28634,
      "e": 28633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28634,
      "e": 28633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28762,
      "e": 28761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28890,
      "e": 28889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28891,
      "e": 28890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28976,
      "e": 28975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29049,
      "e": 29048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29049,
      "e": 29048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29121,
      "e": 29120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29121,
      "e": 29120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29177,
      "e": 29176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 29265,
      "e": 29264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29265,
      "e": 29264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29266,
      "e": 29265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29378,
      "e": 29377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29378,
      "e": 29377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29408,
      "e": 29407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 29465,
      "e": 29464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29465,
      "e": 29464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29504,
      "e": 29503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29552,
      "e": 29551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29554,
      "e": 29553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29593,
      "e": 29592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29609,
      "e": 29608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29609,
      "e": 29608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29697,
      "e": 29696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 29737,
      "e": 29736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29738,
      "e": 29737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29792,
      "e": 29791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29817,
      "e": 29816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29817,
      "e": 29816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29897,
      "e": 29896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29953,
      "e": 29952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29977,
      "e": 29976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29978,
      "e": 29977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30104,
      "e": 30103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30577,
      "e": 30576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30697,
      "e": 30696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that "
    },
    {
      "t": 30889,
      "e": 30888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30890,
      "e": 30889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31006,
      "e": 31005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that i"
    },
    {
      "t": 31009,
      "e": 31008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31041,
      "e": 31040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31041,
      "e": 31040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31146,
      "e": 31145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31146,
      "e": 31145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31160,
      "e": 31159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 31265,
      "e": 31264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31265,
      "e": 31264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31265,
      "e": 31264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31377,
      "e": 31376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31442,
      "e": 31441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 31443,
      "e": 31442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31569,
      "e": 31568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 31577,
      "e": 31576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31577,
      "e": 31576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31745,
      "e": 31744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31753,
      "e": 31752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31755,
      "e": 31754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31848,
      "e": 31847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31849,
      "e": 31848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31929,
      "e": 31928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 32033,
      "e": 32032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33793,
      "e": 33792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33794,
      "e": 33793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33961,
      "e": 33960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34289,
      "e": 34288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34290,
      "e": 34289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34409,
      "e": 34291,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate a"
    },
    {
      "t": 34480,
      "e": 34362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34913,
      "e": 34795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34914,
      "e": 34796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35041,
      "e": 34923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35048,
      "e": 34930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 35049,
      "e": 34931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35145,
      "e": 35027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 35449,
      "e": 35331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35601,
      "e": 35483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate a "
    },
    {
      "t": 35721,
      "e": 35603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35849,
      "e": 35731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate a"
    },
    {
      "t": 36025,
      "e": 35907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36026,
      "e": 35908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36153,
      "e": 36035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36153,
      "e": 36035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36177,
      "e": 36059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 36257,
      "e": 36139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36258,
      "e": 36140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36313,
      "e": 36195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36393,
      "e": 36275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36465,
      "e": 36347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 36466,
      "e": 36348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36568,
      "e": 36450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 36576,
      "e": 36458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36577,
      "e": 36459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36713,
      "e": 36595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36721,
      "e": 36603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36723,
      "e": 36605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36816,
      "e": 36698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36817,
      "e": 36699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36841,
      "e": 36723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 36921,
      "e": 36803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36922,
      "e": 36804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36929,
      "e": 36811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37025,
      "e": 36907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37049,
      "e": 36931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37050,
      "e": 36932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37113,
      "e": 36995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37114,
      "e": 36996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37178,
      "e": 37060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 37217,
      "e": 37099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37218,
      "e": 37100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37273,
      "e": 37155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 37361,
      "e": 37243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37362,
      "e": 37244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37385,
      "e": 37267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37433,
      "e": 37315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37473,
      "e": 37355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37569,
      "e": 37451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate an event tha"
    },
    {
      "t": 37609,
      "e": 37491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37807,
      "e": 37689,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate an event th"
    },
    {
      "t": 38108,
      "e": 37990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38142,
      "e": 38024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38174,
      "e": 38056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38207,
      "e": 38089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38241,
      "e": 38123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38273,
      "e": 38155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38306,
      "e": 38188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38339,
      "e": 38221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38373,
      "e": 38255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38406,
      "e": 38288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38438,
      "e": 38320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38471,
      "e": 38320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38504,
      "e": 38353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38537,
      "e": 38386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38544,
      "e": 38393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indica"
    },
    {
      "t": 39217,
      "e": 39066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39218,
      "e": 39067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39337,
      "e": 39186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39337,
      "e": 39186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39409,
      "e": 39258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 39448,
      "e": 39297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39450,
      "e": 39299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39456,
      "e": 39305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39553,
      "e": 39402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39569,
      "e": 39418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39570,
      "e": 39419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39641,
      "e": 39490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39753,
      "e": 39602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 39754,
      "e": 39603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39824,
      "e": 39673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 39913,
      "e": 39762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39913,
      "e": 39762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40025,
      "e": 39874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40033,
      "e": 39882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40033,
      "e": 39882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40105,
      "e": 39954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40106,
      "e": 39955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40168,
      "e": 40017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 40264,
      "e": 40113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40264,
      "e": 40113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40273,
      "e": 40122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40392,
      "e": 40241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40393,
      "e": 40242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40401,
      "e": 40250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40473,
      "e": 40322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40473,
      "e": 40322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40473,
      "e": 40322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40569,
      "e": 40418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40569,
      "e": 40418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40592,
      "e": 40441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 40649,
      "e": 40498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40649,
      "e": 40498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40713,
      "e": 40562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40737,
      "e": 40586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40737,
      "e": 40586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40785,
      "e": 40634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40801,
      "e": 40650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40801,
      "e": 40650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40865,
      "e": 40714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40913,
      "e": 40762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41129,
      "e": 40978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41130,
      "e": 40979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41241,
      "e": 41090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41241,
      "e": 41090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41265,
      "e": 41114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 41345,
      "e": 41194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41378,
      "e": 41227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41378,
      "e": 41227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41465,
      "e": 41314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41465,
      "e": 41314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41586,
      "e": 41435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 41609,
      "e": 41458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41714,
      "e": 41563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41714,
      "e": 41563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41897,
      "e": 41746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41986,
      "e": 41835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41986,
      "e": 41835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42097,
      "e": 41946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42169,
      "e": 42018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42169,
      "e": 42018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42274,
      "e": 42123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42274,
      "e": 42123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42336,
      "e": 42185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 42401,
      "e": 42250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42401,
      "e": 42250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42465,
      "e": 42314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42504,
      "e": 42353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42593,
      "e": 42442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 42594,
      "e": 42443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42713,
      "e": 42562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 42713,
      "e": 42562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42825,
      "e": 42674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 42826,
      "e": 42675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42826,
      "e": 42675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42865,
      "e": 42714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42963,
      "e": 42812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42977,
      "e": 42826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42977,
      "e": 42826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43209,
      "e": 43058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 43210,
      "e": 43059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43225,
      "e": 43074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 43361,
      "e": 43210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44297,
      "e": 44146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 44298,
      "e": 44147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44401,
      "e": 44250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 45404,
      "e": 45253,
      "ty": 2,
      "x": 612,
      "y": 576
    },
    {
      "t": 45455,
      "e": 45304,
      "ty": 7,
      "x": 559,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45504,
      "e": 45353,
      "ty": 2,
      "x": 523,
      "y": 621
    },
    {
      "t": 45505,
      "e": 45354,
      "ty": 41,
      "x": 47876,
      "y": 65201,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 45604,
      "e": 45453,
      "ty": 2,
      "x": 462,
      "y": 641
    },
    {
      "t": 45655,
      "e": 45504,
      "ty": 6,
      "x": 454,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 45704,
      "e": 45553,
      "ty": 2,
      "x": 448,
      "y": 663
    },
    {
      "t": 45754,
      "e": 45603,
      "ty": 41,
      "x": 56472,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 45804,
      "e": 45653,
      "ty": 2,
      "x": 429,
      "y": 675
    },
    {
      "t": 45904,
      "e": 45753,
      "ty": 2,
      "x": 414,
      "y": 680
    },
    {
      "t": 45910,
      "e": 45759,
      "ty": 3,
      "x": 414,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 45912,
      "e": 45760,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate events that start at 12 pm."
    },
    {
      "t": 45914,
      "e": 45762,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45916,
      "e": 45764,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 45964,
      "e": 45812,
      "ty": 4,
      "x": 41181,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 45974,
      "e": 45822,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 45975,
      "e": 45823,
      "ty": 5,
      "x": 414,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 45983,
      "e": 45831,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 46004,
      "e": 45852,
      "ty": 41,
      "x": 13981,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 46982,
      "e": 46830,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 47604,
      "e": 47452,
      "ty": 2,
      "x": 758,
      "y": 613
    },
    {
      "t": 47705,
      "e": 47553,
      "ty": 2,
      "x": 924,
      "y": 596
    },
    {
      "t": 47754,
      "e": 47602,
      "ty": 41,
      "x": 25305,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 47805,
      "e": 47653,
      "ty": 2,
      "x": 933,
      "y": 590
    },
    {
      "t": 47904,
      "e": 47752,
      "ty": 2,
      "x": 933,
      "y": 586
    },
    {
      "t": 47956,
      "e": 47804,
      "ty": 6,
      "x": 928,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48004,
      "e": 47852,
      "ty": 2,
      "x": 924,
      "y": 567
    },
    {
      "t": 48004,
      "e": 47852,
      "ty": 41,
      "x": 25089,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48104,
      "e": 47952,
      "ty": 2,
      "x": 924,
      "y": 565
    },
    {
      "t": 48142,
      "e": 47990,
      "ty": 3,
      "x": 924,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48143,
      "e": 47991,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48237,
      "e": 48085,
      "ty": 4,
      "x": 25089,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48237,
      "e": 48085,
      "ty": 5,
      "x": 924,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48255,
      "e": 48103,
      "ty": 41,
      "x": 25089,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48985,
      "e": 48833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 48986,
      "e": 48834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49089,
      "e": 48937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 49178,
      "e": 49026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 49178,
      "e": 49026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49264,
      "e": 49112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49797,
      "e": 49645,
      "ty": 7,
      "x": 933,
      "y": 584,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49804,
      "e": 49652,
      "ty": 2,
      "x": 933,
      "y": 584
    },
    {
      "t": 49904,
      "e": 49752,
      "ty": 2,
      "x": 944,
      "y": 617
    },
    {
      "t": 50004,
      "e": 49852,
      "ty": 2,
      "x": 944,
      "y": 639
    },
    {
      "t": 50005,
      "e": 49853,
      "ty": 41,
      "x": 29415,
      "y": 39461,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 50058,
      "e": 49906,
      "ty": 6,
      "x": 944,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50104,
      "e": 49952,
      "ty": 2,
      "x": 944,
      "y": 649
    },
    {
      "t": 50204,
      "e": 50052,
      "ty": 2,
      "x": 944,
      "y": 650
    },
    {
      "t": 50237,
      "e": 50085,
      "ty": 3,
      "x": 944,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50239,
      "e": 50087,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 50240,
      "e": 50088,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50240,
      "e": 50088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50255,
      "e": 50103,
      "ty": 41,
      "x": 29415,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50317,
      "e": 50165,
      "ty": 4,
      "x": 29415,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50317,
      "e": 50165,
      "ty": 5,
      "x": 944,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51066,
      "e": 50914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 51201,
      "e": 51049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 51202,
      "e": 51050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51321,
      "e": 51169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 51345,
      "e": 51193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 51345,
      "e": 51193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51465,
      "e": 51313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 51466,
      "e": 51314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51561,
      "e": 51409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 51593,
      "e": 51441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 51633,
      "e": 51481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 52505,
      "e": 52353,
      "ty": 2,
      "x": 933,
      "y": 651
    },
    {
      "t": 52505,
      "e": 52353,
      "ty": 41,
      "x": 27035,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52544,
      "e": 52392,
      "ty": 7,
      "x": 942,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52561,
      "e": 52409,
      "ty": 6,
      "x": 945,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52604,
      "e": 52452,
      "ty": 2,
      "x": 949,
      "y": 690
    },
    {
      "t": 52704,
      "e": 52552,
      "ty": 2,
      "x": 953,
      "y": 702
    },
    {
      "t": 52754,
      "e": 52602,
      "ty": 41,
      "x": 29417,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52918,
      "e": 52766,
      "ty": 3,
      "x": 953,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52919,
      "e": 52767,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 52919,
      "e": 52767,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52920,
      "e": 52768,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52997,
      "e": 52845,
      "ty": 4,
      "x": 29417,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 52999,
      "e": 52847,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53000,
      "e": 52848,
      "ty": 5,
      "x": 953,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53001,
      "e": 52849,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 54021,
      "e": 53869,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 54604,
      "e": 54452,
      "ty": 2,
      "x": 984,
      "y": 692
    },
    {
      "t": 54755,
      "e": 54603,
      "ty": 41,
      "x": 38583,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 55005,
      "e": 54853,
      "ty": 2,
      "x": 940,
      "y": 624
    },
    {
      "t": 55005,
      "e": 54853,
      "ty": 41,
      "x": 28141,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 55079,
      "e": 54927,
      "ty": 6,
      "x": 832,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55096,
      "e": 54944,
      "ty": 7,
      "x": 810,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55105,
      "e": 54953,
      "ty": 2,
      "x": 810,
      "y": 408
    },
    {
      "t": 55205,
      "e": 55053,
      "ty": 2,
      "x": 763,
      "y": 297
    },
    {
      "t": 55254,
      "e": 55102,
      "ty": 41,
      "x": 26689,
      "y": 14292,
      "ta": "html > body"
    },
    {
      "t": 55305,
      "e": 55153,
      "ty": 2,
      "x": 823,
      "y": 251
    },
    {
      "t": 55404,
      "e": 55252,
      "ty": 2,
      "x": 834,
      "y": 246
    },
    {
      "t": 55505,
      "e": 55353,
      "ty": 2,
      "x": 834,
      "y": 245
    },
    {
      "t": 55506,
      "e": 55354,
      "ty": 41,
      "x": 10299,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55510,
      "e": 55358,
      "ty": 6,
      "x": 834,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55605,
      "e": 55453,
      "ty": 3,
      "x": 834,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55605,
      "e": 55453,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55606,
      "e": 55454,
      "ty": 2,
      "x": 834,
      "y": 244
    },
    {
      "t": 55693,
      "e": 55541,
      "ty": 4,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55693,
      "e": 55541,
      "ty": 5,
      "x": 834,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55694,
      "e": 55542,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 55755,
      "e": 55603,
      "ty": 41,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 55804,
      "e": 55652,
      "ty": 2,
      "x": 834,
      "y": 241
    },
    {
      "t": 56005,
      "e": 55853,
      "ty": 2,
      "x": 834,
      "y": 240
    },
    {
      "t": 56005,
      "e": 55853,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56030,
      "e": 55878,
      "ty": 7,
      "x": 844,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56104,
      "e": 55952,
      "ty": 2,
      "x": 877,
      "y": 315
    },
    {
      "t": 56204,
      "e": 56052,
      "ty": 2,
      "x": 885,
      "y": 373
    },
    {
      "t": 56254,
      "e": 56102,
      "ty": 41,
      "x": 15088,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 56305,
      "e": 56153,
      "ty": 2,
      "x": 885,
      "y": 419
    },
    {
      "t": 56404,
      "e": 56252,
      "ty": 2,
      "x": 877,
      "y": 444
    },
    {
      "t": 56504,
      "e": 56352,
      "ty": 2,
      "x": 872,
      "y": 456
    },
    {
      "t": 56504,
      "e": 56352,
      "ty": 41,
      "x": 12003,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 56605,
      "e": 56453,
      "ty": 2,
      "x": 868,
      "y": 460
    },
    {
      "t": 56754,
      "e": 56602,
      "ty": 41,
      "x": 11054,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 57404,
      "e": 57252,
      "ty": 2,
      "x": 865,
      "y": 460
    },
    {
      "t": 57497,
      "e": 57345,
      "ty": 6,
      "x": 839,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57504,
      "e": 57352,
      "ty": 2,
      "x": 839,
      "y": 444
    },
    {
      "t": 57505,
      "e": 57353,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57605,
      "e": 57453,
      "ty": 2,
      "x": 831,
      "y": 440
    },
    {
      "t": 57705,
      "e": 57553,
      "ty": 2,
      "x": 830,
      "y": 440
    },
    {
      "t": 57755,
      "e": 57603,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57799,
      "e": 57647,
      "ty": 7,
      "x": 825,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57805,
      "e": 57653,
      "ty": 2,
      "x": 825,
      "y": 437
    },
    {
      "t": 57904,
      "e": 57752,
      "ty": 2,
      "x": 824,
      "y": 413
    },
    {
      "t": 58004,
      "e": 57852,
      "ty": 2,
      "x": 825,
      "y": 408
    },
    {
      "t": 58005,
      "e": 57853,
      "ty": 41,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58294,
      "e": 58142,
      "ty": 3,
      "x": 825,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58295,
      "e": 58143,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 58356,
      "e": 58204,
      "ty": 4,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58356,
      "e": 58204,
      "ty": 5,
      "x": 825,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 58357,
      "e": 58205,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58358,
      "e": 58206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 58558,
      "e": 58406,
      "ty": 6,
      "x": 826,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58598,
      "e": 58446,
      "ty": 7,
      "x": 851,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 58604,
      "e": 58452,
      "ty": 2,
      "x": 851,
      "y": 425
    },
    {
      "t": 58705,
      "e": 58553,
      "ty": 2,
      "x": 910,
      "y": 510
    },
    {
      "t": 58755,
      "e": 58603,
      "ty": 41,
      "x": 25056,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 58804,
      "e": 58652,
      "ty": 2,
      "x": 943,
      "y": 579
    },
    {
      "t": 58905,
      "e": 58753,
      "ty": 2,
      "x": 948,
      "y": 616
    },
    {
      "t": 59004,
      "e": 58852,
      "ty": 2,
      "x": 948,
      "y": 645
    },
    {
      "t": 59005,
      "e": 58853,
      "ty": 41,
      "x": 30040,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 59104,
      "e": 58952,
      "ty": 2,
      "x": 948,
      "y": 653
    },
    {
      "t": 59255,
      "e": 59103,
      "ty": 41,
      "x": 30040,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 59604,
      "e": 59452,
      "ty": 2,
      "x": 915,
      "y": 665
    },
    {
      "t": 59705,
      "e": 59553,
      "ty": 2,
      "x": 898,
      "y": 675
    },
    {
      "t": 59754,
      "e": 59602,
      "ty": 41,
      "x": 17876,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 59804,
      "e": 59652,
      "ty": 2,
      "x": 880,
      "y": 681
    },
    {
      "t": 59905,
      "e": 59753,
      "ty": 2,
      "x": 871,
      "y": 687
    },
    {
      "t": 60004,
      "e": 59852,
      "ty": 2,
      "x": 867,
      "y": 691
    },
    {
      "t": 60004,
      "e": 59852,
      "ty": 41,
      "x": 10816,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 60105,
      "e": 59953,
      "ty": 2,
      "x": 861,
      "y": 694
    },
    {
      "t": 60205,
      "e": 60053,
      "ty": 2,
      "x": 860,
      "y": 696
    },
    {
      "t": 60256,
      "e": 60054,
      "ty": 41,
      "x": 9217,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60305,
      "e": 60103,
      "ty": 2,
      "x": 857,
      "y": 699
    },
    {
      "t": 60505,
      "e": 60303,
      "ty": 41,
      "x": 8965,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60905,
      "e": 60703,
      "ty": 2,
      "x": 855,
      "y": 699
    },
    {
      "t": 61005,
      "e": 60803,
      "ty": 2,
      "x": 855,
      "y": 696
    },
    {
      "t": 61006,
      "e": 60804,
      "ty": 41,
      "x": 8461,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61404,
      "e": 61202,
      "ty": 2,
      "x": 854,
      "y": 692
    },
    {
      "t": 61505,
      "e": 61303,
      "ty": 2,
      "x": 854,
      "y": 689
    },
    {
      "t": 61506,
      "e": 61304,
      "ty": 41,
      "x": 7731,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 61605,
      "e": 61403,
      "ty": 2,
      "x": 854,
      "y": 685
    },
    {
      "t": 61705,
      "e": 61503,
      "ty": 2,
      "x": 852,
      "y": 683
    },
    {
      "t": 61755,
      "e": 61553,
      "ty": 41,
      "x": 8210,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 61804,
      "e": 61602,
      "ty": 2,
      "x": 850,
      "y": 682
    },
    {
      "t": 62004,
      "e": 61802,
      "ty": 2,
      "x": 845,
      "y": 695
    },
    {
      "t": 62004,
      "e": 61802,
      "ty": 41,
      "x": 5941,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62052,
      "e": 61850,
      "ty": 6,
      "x": 839,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62105,
      "e": 61903,
      "ty": 2,
      "x": 833,
      "y": 703
    },
    {
      "t": 62205,
      "e": 62003,
      "ty": 2,
      "x": 829,
      "y": 704
    },
    {
      "t": 62255,
      "e": 62053,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62405,
      "e": 62203,
      "ty": 2,
      "x": 837,
      "y": 700
    },
    {
      "t": 62505,
      "e": 62303,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62662,
      "e": 62460,
      "ty": 3,
      "x": 837,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62663,
      "e": 62461,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 62663,
      "e": 62461,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62780,
      "e": 62578,
      "ty": 4,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62780,
      "e": 62578,
      "ty": 5,
      "x": 837,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62781,
      "e": 62579,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 63205,
      "e": 63003,
      "ty": 2,
      "x": 839,
      "y": 703
    },
    {
      "t": 63219,
      "e": 63017,
      "ty": 7,
      "x": 841,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63254,
      "e": 63052,
      "ty": 41,
      "x": 5689,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63304,
      "e": 63102,
      "ty": 2,
      "x": 844,
      "y": 711
    },
    {
      "t": 63404,
      "e": 63202,
      "ty": 2,
      "x": 868,
      "y": 730
    },
    {
      "t": 63504,
      "e": 63302,
      "ty": 2,
      "x": 937,
      "y": 826
    },
    {
      "t": 63504,
      "e": 63302,
      "ty": 41,
      "x": 27429,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 63605,
      "e": 63403,
      "ty": 2,
      "x": 967,
      "y": 943
    },
    {
      "t": 63704,
      "e": 63502,
      "ty": 2,
      "x": 963,
      "y": 956
    },
    {
      "t": 63754,
      "e": 63552,
      "ty": 41,
      "x": 31226,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 63804,
      "e": 63602,
      "ty": 2,
      "x": 949,
      "y": 962
    },
    {
      "t": 63904,
      "e": 63702,
      "ty": 2,
      "x": 946,
      "y": 964
    },
    {
      "t": 64005,
      "e": 63803,
      "ty": 41,
      "x": 29565,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 64104,
      "e": 63902,
      "ty": 2,
      "x": 947,
      "y": 962
    },
    {
      "t": 64205,
      "e": 64003,
      "ty": 2,
      "x": 949,
      "y": 961
    },
    {
      "t": 64255,
      "e": 64053,
      "ty": 41,
      "x": 30277,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 64505,
      "e": 64303,
      "ty": 2,
      "x": 941,
      "y": 961
    },
    {
      "t": 64505,
      "e": 64303,
      "ty": 41,
      "x": 28378,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 64604,
      "e": 64402,
      "ty": 2,
      "x": 899,
      "y": 962
    },
    {
      "t": 64704,
      "e": 64502,
      "ty": 2,
      "x": 858,
      "y": 952
    },
    {
      "t": 64754,
      "e": 64552,
      "ty": 41,
      "x": 7968,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 64804,
      "e": 64602,
      "ty": 2,
      "x": 851,
      "y": 959
    },
    {
      "t": 64887,
      "e": 64685,
      "ty": 6,
      "x": 839,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64904,
      "e": 64702,
      "ty": 2,
      "x": 838,
      "y": 964
    },
    {
      "t": 65004,
      "e": 64802,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 65004,
      "e": 64802,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65221,
      "e": 65019,
      "ty": 3,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65222,
      "e": 65020,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65223,
      "e": 65021,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65316,
      "e": 65114,
      "ty": 4,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65316,
      "e": 65114,
      "ty": 5,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65317,
      "e": 65115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 65537,
      "e": 65335,
      "ty": 7,
      "x": 840,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65604,
      "e": 65402,
      "ty": 2,
      "x": 879,
      "y": 982
    },
    {
      "t": 65704,
      "e": 65502,
      "ty": 2,
      "x": 905,
      "y": 1000
    },
    {
      "t": 65721,
      "e": 65519,
      "ty": 6,
      "x": 908,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65754,
      "e": 65552,
      "ty": 41,
      "x": 42044,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65805,
      "e": 65603,
      "ty": 2,
      "x": 916,
      "y": 1018
    },
    {
      "t": 65905,
      "e": 65703,
      "ty": 2,
      "x": 917,
      "y": 1019
    },
    {
      "t": 65982,
      "e": 65780,
      "ty": 3,
      "x": 917,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65983,
      "e": 65781,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65983,
      "e": 65781,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66004,
      "e": 65802,
      "ty": 41,
      "x": 45136,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66045,
      "e": 65843,
      "ty": 4,
      "x": 45136,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66045,
      "e": 65843,
      "ty": 5,
      "x": 917,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66052,
      "e": 65850,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66053,
      "e": 65851,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66056,
      "e": 65854,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 67411,
      "e": 67209,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 68404,
      "e": 68202,
      "ty": 2,
      "x": 917,
      "y": 1018
    },
    {
      "t": 68505,
      "e": 68303,
      "ty": 2,
      "x": 910,
      "y": 1013
    },
    {
      "t": 68505,
      "e": 68303,
      "ty": 41,
      "x": 30332,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68604,
      "e": 68402,
      "ty": 2,
      "x": 908,
      "y": 1011
    },
    {
      "t": 68755,
      "e": 68553,
      "ty": 41,
      "x": 30233,
      "y": 61263,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70005,
      "e": 69803,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74105,
      "e": 73553,
      "ty": 2,
      "x": 911,
      "y": 1028
    },
    {
      "t": 74204,
      "e": 73652,
      "ty": 2,
      "x": 934,
      "y": 1060
    },
    {
      "t": 74255,
      "e": 73703,
      "ty": 41,
      "x": 31857,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74286,
      "e": 73734,
      "ty": 6,
      "x": 941,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 74305,
      "e": 73753,
      "ty": 2,
      "x": 941,
      "y": 1073
    },
    {
      "t": 74404,
      "e": 73852,
      "ty": 2,
      "x": 948,
      "y": 1086
    },
    {
      "t": 74504,
      "e": 73952,
      "ty": 41,
      "x": 21025,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 74604,
      "e": 74052,
      "ty": 2,
      "x": 949,
      "y": 1086
    },
    {
      "t": 74754,
      "e": 74202,
      "ty": 41,
      "x": 21571,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 75246,
      "e": 74694,
      "ty": 3,
      "x": 949,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 75248,
      "e": 74696,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75325,
      "e": 74773,
      "ty": 4,
      "x": 21571,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 75326,
      "e": 74774,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75328,
      "e": 74776,
      "ty": 5,
      "x": 949,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 75329,
      "e": 74777,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 76360,
      "e": 75808,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 77755,
      "e": 77203,
      "ty": 41,
      "x": 32360,
      "y": 32881,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 77804,
      "e": 77252,
      "ty": 2,
      "x": 947,
      "y": 1082
    },
    {
      "t": 77806,
      "e": 77254,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":3,\"id\":2447,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2446}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"1\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2463}},{\"nodeType\":1,\"id\":2465,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2466,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"3\",\"parentNode\":{\"id\":2466}},{\"nodeType\":1,\"id\":2468,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"4\",\"parentNode\":{\"id\":2469}},{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2472,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"5\",\"parentNode\":{\"id\":2472}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"6\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2479,\"textContent\":\"7\",\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2482,\"textContent\":\"8\",\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2437}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2485,\"textContent\":\"9\",\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2439}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2488,\"textContent\":\"10\",\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2441}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2491,\"textContent\":\"11\",\"parentNode\":{\"id\":2490}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2443}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2494,\"textContent\":\"12\",\"parentNode\":{\"id\":2493}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2445}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2448}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2449}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2450}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2451}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2452}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2453}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2454}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2455}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2456}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2457}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2458}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2459}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2543}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2544}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2578},\"parentNode\":{\"id\":2546}},{\"nodeType\":1,\"id\":2580,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2581,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2580},\"parentNode\":{\"id\":2547}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2582},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2584,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2549}},{\"nodeType\":1,\"id\":2585,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2584},\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"A \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"B \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"C \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"D \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"E \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"F \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"G \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"H \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"I \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"J \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"K \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"L \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2598,\"textContent\":\"M \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2599,\"textContent\":\"N \",\"parentNode\":{\"id\":2577}},{\"nodeType\":3,\"id\":2600,\"textContent\":\"O \",\"parentNode\":{\"id\":2579}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"P \",\"parentNode\":{\"id\":2581}},{\"nodeType\":3,\"id\":2602,\"textContent\":\"Z \",\"parentNode\":{\"id\":2583}},{\"nodeType\":3,\"id\":2603,\"textContent\":\"X \",\"parentNode\":{\"id\":2585}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2446},{\"id\":2447},{\"id\":2422},{\"id\":2460},{\"id\":2461},{\"id\":2423},{\"id\":2462},{\"id\":2424},{\"id\":2463},{\"id\":2464},{\"id\":2425},{\"id\":2465},{\"id\":2426},{\"id\":2466},{\"id\":2467},{\"id\":2427},{\"id\":2468},{\"id\":2428},{\"id\":2469},{\"id\":2470},{\"id\":2429},{\"id\":2471},{\"id\":2430},{\"id\":2472},{\"id\":2473},{\"id\":2431},{\"id\":2474},{\"id\":2432},{\"id\":2475},{\"id\":2476},{\"id\":2433},{\"id\":2477},{\"id\":2434},{\"id\":2478},{\"id\":2479},{\"id\":2435},{\"id\":2480},{\"id\":2436},{\"id\":2481},{\"id\":2482},{\"id\":2437},{\"id\":2483},{\"id\":2438},{\"id\":2484},{\"id\":2485},{\"id\":2439},{\"id\":2486},{\"id\":2440},{\"id\":2487},{\"id\":2488},{\"id\":2441},{\"id\":2489},{\"id\":2442},{\"id\":2490},{\"id\":2491},{\"id\":2443},{\"id\":2492},{\"id\":2444},{\"id\":2493},{\"id\":2494},{\"id\":2445},{\"id\":2495},{\"id\":2313},{\"id\":2448},{\"id\":2496},{\"id\":2449},{\"id\":2497},{\"id\":2450},{\"id\":2498},{\"id\":2451},{\"id\":2499},{\"id\":2452},{\"id\":2500},{\"id\":2453},{\"id\":2501},{\"id\":2454},{\"id\":2502},{\"id\":2455},{\"id\":2503},{\"id\":2456},{\"id\":2504},{\"id\":2457},{\"id\":2505},{\"id\":2458},{\"id\":2506},{\"id\":2459},{\"id\":2507},{\"id\":2314},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2315},{\"id\":2532},{\"id\":2550},{\"id\":2551},{\"id\":2586},{\"id\":2533},{\"id\":2552},{\"id\":2553},{\"id\":2587},{\"id\":2534},{\"id\":2554},{\"id\":2555},{\"id\":2588},{\"id\":2535},{\"id\":2556},{\"id\":2557},{\"id\":2589},{\"id\":2536},{\"id\":2558},{\"id\":2559},{\"id\":2590},{\"id\":2537},{\"id\":2560},{\"id\":2561},{\"id\":2591},{\"id\":2538},{\"id\":2562},{\"id\":2563},{\"id\":2592},{\"id\":2539},{\"id\":2564},{\"id\":2565},{\"id\":2593},{\"id\":2540},{\"id\":2566},{\"id\":2567},{\"id\":2594},{\"id\":2541},{\"id\":2568},{\"id\":2569},{\"id\":2595},{\"id\":2542},{\"id\":2570},{\"id\":2571},{\"id\":2596},{\"id\":2543},{\"id\":2572},{\"id\":2573},{\"id\":2597},{\"id\":2544},{\"id\":2574},{\"id\":2575},{\"id\":2598},{\"id\":2545},{\"id\":2576},{\"id\":2577},{\"id\":2599},{\"id\":2546},{\"id\":2578},{\"id\":2579},{\"id\":2600},{\"id\":2547},{\"id\":2580},{\"id\":2581},{\"id\":2601},{\"id\":2548},{\"id\":2582},{\"id\":2583},{\"id\":2602},{\"id\":2549},{\"id\":2584},{\"id\":2585},{\"id\":2603},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 64008, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 64015, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 3405, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 68759, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 8986, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 78751, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 29546, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 109381, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14757, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 125139, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 18294, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 145066, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-01 PM-12 PM-11 AM-11 AM-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:961,y:1017,t:1527188748577};\\\", \\\"{x:968,y:1015,t:1527188748590};\\\", \\\"{x:990,y:1013,t:1527188748607};\\\", \\\"{x:1021,y:1008,t:1527188748624};\\\", \\\"{x:1037,y:1007,t:1527188748640};\\\", \\\"{x:1047,y:1006,t:1527188748658};\\\", \\\"{x:1056,y:1004,t:1527188748675};\\\", \\\"{x:1071,y:1002,t:1527188748690};\\\", \\\"{x:1087,y:999,t:1527188748708};\\\", \\\"{x:1100,y:998,t:1527188748724};\\\", \\\"{x:1116,y:997,t:1527188748740};\\\", \\\"{x:1131,y:996,t:1527188748757};\\\", \\\"{x:1147,y:996,t:1527188748775};\\\", \\\"{x:1166,y:996,t:1527188748790};\\\", \\\"{x:1186,y:996,t:1527188748808};\\\", \\\"{x:1216,y:996,t:1527188748824};\\\", \\\"{x:1231,y:996,t:1527188748840};\\\", \\\"{x:1247,y:996,t:1527188748857};\\\", \\\"{x:1262,y:996,t:1527188748875};\\\", \\\"{x:1277,y:996,t:1527188748892};\\\", \\\"{x:1290,y:996,t:1527188748907};\\\", \\\"{x:1301,y:996,t:1527188748924};\\\", \\\"{x:1312,y:996,t:1527188748941};\\\", \\\"{x:1323,y:996,t:1527188748957};\\\", \\\"{x:1332,y:996,t:1527188748975};\\\", \\\"{x:1341,y:996,t:1527188748992};\\\", \\\"{x:1350,y:996,t:1527188749007};\\\", \\\"{x:1369,y:996,t:1527188749024};\\\", \\\"{x:1387,y:996,t:1527188749042};\\\", \\\"{x:1409,y:996,t:1527188749058};\\\", \\\"{x:1425,y:996,t:1527188749074};\\\", \\\"{x:1442,y:994,t:1527188749092};\\\", \\\"{x:1457,y:992,t:1527188749108};\\\", \\\"{x:1466,y:991,t:1527188749124};\\\", \\\"{x:1470,y:989,t:1527188749142};\\\", \\\"{x:1473,y:988,t:1527188749158};\\\", \\\"{x:1474,y:988,t:1527188749184};\\\", \\\"{x:1475,y:988,t:1527188749208};\\\", \\\"{x:1476,y:988,t:1527188749224};\\\", \\\"{x:1479,y:988,t:1527188749248};\\\", \\\"{x:1479,y:987,t:1527188749258};\\\", \\\"{x:1480,y:987,t:1527188749274};\\\", \\\"{x:1481,y:986,t:1527188749292};\\\", \\\"{x:1483,y:985,t:1527188749328};\\\", \\\"{x:1484,y:983,t:1527188749400};\\\", \\\"{x:1485,y:981,t:1527188749424};\\\", \\\"{x:1485,y:980,t:1527188749442};\\\", \\\"{x:1486,y:978,t:1527188749458};\\\", \\\"{x:1486,y:977,t:1527188749489};\\\", \\\"{x:1486,y:976,t:1527188749505};\\\", \\\"{x:1487,y:975,t:1527188749512};\\\", \\\"{x:1487,y:974,t:1527188749525};\\\", \\\"{x:1487,y:972,t:1527188749541};\\\", \\\"{x:1487,y:970,t:1527188749559};\\\", \\\"{x:1489,y:970,t:1527188749575};\\\", \\\"{x:1489,y:969,t:1527188749591};\\\", \\\"{x:1490,y:969,t:1527188749616};\\\", \\\"{x:1490,y:967,t:1527188749664};\\\", \\\"{x:1489,y:967,t:1527188750425};\\\", \\\"{x:1487,y:967,t:1527188750432};\\\", \\\"{x:1485,y:967,t:1527188750448};\\\", \\\"{x:1484,y:967,t:1527188750459};\\\", \\\"{x:1482,y:967,t:1527188750476};\\\", \\\"{x:1479,y:968,t:1527188750493};\\\", \\\"{x:1474,y:970,t:1527188750509};\\\", \\\"{x:1470,y:970,t:1527188750526};\\\", \\\"{x:1465,y:971,t:1527188750543};\\\", \\\"{x:1459,y:972,t:1527188750559};\\\", \\\"{x:1450,y:973,t:1527188750576};\\\", \\\"{x:1433,y:975,t:1527188750592};\\\", \\\"{x:1421,y:976,t:1527188750609};\\\", \\\"{x:1410,y:976,t:1527188750626};\\\", \\\"{x:1395,y:976,t:1527188750643};\\\", \\\"{x:1380,y:976,t:1527188750659};\\\", \\\"{x:1366,y:976,t:1527188750676};\\\", \\\"{x:1351,y:976,t:1527188750693};\\\", \\\"{x:1336,y:978,t:1527188750708};\\\", \\\"{x:1322,y:978,t:1527188750726};\\\", \\\"{x:1310,y:978,t:1527188750742};\\\", \\\"{x:1300,y:978,t:1527188750758};\\\", \\\"{x:1290,y:978,t:1527188750776};\\\", \\\"{x:1288,y:978,t:1527188750793};\\\", \\\"{x:1287,y:978,t:1527188750809};\\\", \\\"{x:1286,y:978,t:1527188750968};\\\", \\\"{x:1286,y:976,t:1527188750984};\\\", \\\"{x:1287,y:975,t:1527188750993};\\\", \\\"{x:1287,y:973,t:1527188751010};\\\", \\\"{x:1287,y:972,t:1527188751025};\\\", \\\"{x:1289,y:971,t:1527188751043};\\\", \\\"{x:1290,y:970,t:1527188751060};\\\", \\\"{x:1290,y:969,t:1527188751096};\\\", \\\"{x:1290,y:967,t:1527188751386};\\\", \\\"{x:1290,y:966,t:1527188751401};\\\", \\\"{x:1290,y:964,t:1527188751466};\\\", \\\"{x:1290,y:963,t:1527188751714};\\\", \\\"{x:1290,y:961,t:1527188751730};\\\", \\\"{x:1290,y:960,t:1527188751752};\\\", \\\"{x:1290,y:958,t:1527188751777};\\\", \\\"{x:1290,y:957,t:1527188751906};\\\", \\\"{x:1290,y:955,t:1527188752000};\\\", \\\"{x:1290,y:954,t:1527188752057};\\\", \\\"{x:1289,y:954,t:1527188752073};\\\", \\\"{x:1289,y:952,t:1527188752121};\\\", \\\"{x:1289,y:951,t:1527188752170};\\\", \\\"{x:1288,y:950,t:1527188752178};\\\", \\\"{x:1288,y:949,t:1527188752218};\\\", \\\"{x:1288,y:948,t:1527188752314};\\\", \\\"{x:1287,y:947,t:1527188752328};\\\", \\\"{x:1286,y:947,t:1527188752344};\\\", \\\"{x:1286,y:946,t:1527188754361};\\\", \\\"{x:1286,y:945,t:1527188754376};\\\", \\\"{x:1285,y:944,t:1527188754392};\\\", \\\"{x:1285,y:943,t:1527188754992};\\\", \\\"{x:1285,y:942,t:1527188755025};\\\", \\\"{x:1285,y:941,t:1527188755049};\\\", \\\"{x:1285,y:940,t:1527188755169};\\\", \\\"{x:1285,y:943,t:1527188755913};\\\", \\\"{x:1285,y:950,t:1527188755930};\\\", \\\"{x:1286,y:956,t:1527188755946};\\\", \\\"{x:1287,y:960,t:1527188755964};\\\", \\\"{x:1288,y:965,t:1527188755981};\\\", \\\"{x:1290,y:968,t:1527188755996};\\\", \\\"{x:1290,y:969,t:1527188756013};\\\", \\\"{x:1290,y:970,t:1527188756048};\\\", \\\"{x:1290,y:972,t:1527188756063};\\\", \\\"{x:1290,y:973,t:1527188756080};\\\", \\\"{x:1290,y:974,t:1527188756096};\\\", \\\"{x:1290,y:975,t:1527188756113};\\\", \\\"{x:1289,y:975,t:1527188756257};\\\", \\\"{x:1287,y:973,t:1527188756265};\\\", \\\"{x:1286,y:972,t:1527188756280};\\\", \\\"{x:1282,y:966,t:1527188756297};\\\", \\\"{x:1277,y:961,t:1527188756314};\\\", \\\"{x:1273,y:957,t:1527188756331};\\\", \\\"{x:1271,y:955,t:1527188756347};\\\", \\\"{x:1272,y:955,t:1527188756714};\\\", \\\"{x:1273,y:955,t:1527188756794};\\\", \\\"{x:1273,y:956,t:1527188756809};\\\", \\\"{x:1274,y:956,t:1527188756834};\\\", \\\"{x:1275,y:957,t:1527188756850};\\\", \\\"{x:1276,y:958,t:1527188756946};\\\", \\\"{x:1276,y:957,t:1527188757953};\\\", \\\"{x:1276,y:954,t:1527188757965};\\\", \\\"{x:1276,y:945,t:1527188757983};\\\", \\\"{x:1273,y:940,t:1527188757999};\\\", \\\"{x:1273,y:936,t:1527188758015};\\\", \\\"{x:1272,y:930,t:1527188758032};\\\", \\\"{x:1269,y:921,t:1527188758049};\\\", \\\"{x:1268,y:918,t:1527188758065};\\\", \\\"{x:1267,y:910,t:1527188758082};\\\", \\\"{x:1267,y:904,t:1527188758099};\\\", \\\"{x:1265,y:899,t:1527188758115};\\\", \\\"{x:1265,y:893,t:1527188758132};\\\", \\\"{x:1265,y:889,t:1527188758148};\\\", \\\"{x:1265,y:882,t:1527188758165};\\\", \\\"{x:1264,y:876,t:1527188758181};\\\", \\\"{x:1264,y:870,t:1527188758199};\\\", \\\"{x:1263,y:866,t:1527188758215};\\\", \\\"{x:1263,y:861,t:1527188758231};\\\", \\\"{x:1263,y:858,t:1527188758248};\\\", \\\"{x:1263,y:850,t:1527188758265};\\\", \\\"{x:1263,y:842,t:1527188758282};\\\", \\\"{x:1263,y:840,t:1527188758299};\\\", \\\"{x:1263,y:837,t:1527188758316};\\\", \\\"{x:1263,y:834,t:1527188758332};\\\", \\\"{x:1263,y:832,t:1527188758348};\\\", \\\"{x:1263,y:830,t:1527188758366};\\\", \\\"{x:1264,y:829,t:1527188758381};\\\", \\\"{x:1265,y:827,t:1527188758399};\\\", \\\"{x:1266,y:825,t:1527188758416};\\\", \\\"{x:1267,y:824,t:1527188758432};\\\", \\\"{x:1268,y:823,t:1527188758449};\\\", \\\"{x:1271,y:820,t:1527188758466};\\\", \\\"{x:1273,y:820,t:1527188758546};\\\", \\\"{x:1274,y:820,t:1527188758610};\\\", \\\"{x:1276,y:820,t:1527188758634};\\\", \\\"{x:1276,y:821,t:1527188758649};\\\", \\\"{x:1277,y:823,t:1527188758665};\\\", \\\"{x:1277,y:824,t:1527188758690};\\\", \\\"{x:1277,y:825,t:1527188758700};\\\", \\\"{x:1277,y:826,t:1527188758719};\\\", \\\"{x:1277,y:827,t:1527188758749};\\\", \\\"{x:1277,y:829,t:1527188758765};\\\", \\\"{x:1277,y:830,t:1527188758782};\\\", \\\"{x:1278,y:832,t:1527188758798};\\\", \\\"{x:1278,y:833,t:1527188758824};\\\", \\\"{x:1278,y:834,t:1527188758848};\\\", \\\"{x:1279,y:835,t:1527188758865};\\\", \\\"{x:1280,y:836,t:1527188758898};\\\", \\\"{x:1280,y:837,t:1527188758938};\\\", \\\"{x:1281,y:838,t:1527188758953};\\\", \\\"{x:1282,y:839,t:1527188758977};\\\", \\\"{x:1282,y:840,t:1527188758985};\\\", \\\"{x:1282,y:839,t:1527188759338};\\\", \\\"{x:1281,y:837,t:1527188759350};\\\", \\\"{x:1279,y:833,t:1527188759366};\\\", \\\"{x:1278,y:831,t:1527188759383};\\\", \\\"{x:1278,y:830,t:1527188759400};\\\", \\\"{x:1275,y:830,t:1527188759795};\\\", \\\"{x:1265,y:827,t:1527188759802};\\\", \\\"{x:1228,y:826,t:1527188759817};\\\", \\\"{x:1151,y:817,t:1527188759834};\\\", \\\"{x:1040,y:803,t:1527188759850};\\\", \\\"{x:894,y:788,t:1527188759867};\\\", \\\"{x:750,y:766,t:1527188759883};\\\", \\\"{x:606,y:745,t:1527188759900};\\\", \\\"{x:479,y:728,t:1527188759919};\\\", \\\"{x:378,y:710,t:1527188759933};\\\", \\\"{x:303,y:686,t:1527188759949};\\\", \\\"{x:253,y:674,t:1527188759967};\\\", \\\"{x:210,y:652,t:1527188759984};\\\", \\\"{x:198,y:644,t:1527188760001};\\\", \\\"{x:193,y:636,t:1527188760018};\\\", \\\"{x:191,y:630,t:1527188760034};\\\", \\\"{x:190,y:625,t:1527188760050};\\\", \\\"{x:188,y:617,t:1527188760068};\\\", \\\"{x:184,y:607,t:1527188760085};\\\", \\\"{x:184,y:601,t:1527188760100};\\\", \\\"{x:184,y:598,t:1527188760117};\\\", \\\"{x:184,y:592,t:1527188760135};\\\", \\\"{x:184,y:590,t:1527188760151};\\\", \\\"{x:186,y:583,t:1527188760168};\\\", \\\"{x:200,y:574,t:1527188760185};\\\", \\\"{x:214,y:569,t:1527188760200};\\\", \\\"{x:232,y:560,t:1527188760218};\\\", \\\"{x:249,y:552,t:1527188760234};\\\", \\\"{x:270,y:543,t:1527188760251};\\\", \\\"{x:294,y:537,t:1527188760267};\\\", \\\"{x:315,y:533,t:1527188760286};\\\", \\\"{x:335,y:531,t:1527188760301};\\\", \\\"{x:351,y:528,t:1527188760317};\\\", \\\"{x:361,y:527,t:1527188760335};\\\", \\\"{x:365,y:526,t:1527188760351};\\\", \\\"{x:368,y:526,t:1527188760367};\\\", \\\"{x:369,y:526,t:1527188760578};\\\", \\\"{x:369,y:525,t:1527188760593};\\\", \\\"{x:370,y:525,t:1527188760602};\\\", \\\"{x:371,y:524,t:1527188760618};\\\", \\\"{x:372,y:523,t:1527188760635};\\\", \\\"{x:373,y:523,t:1527188760652};\\\", \\\"{x:374,y:523,t:1527188760670};\\\", \\\"{x:375,y:523,t:1527188760684};\\\", \\\"{x:377,y:521,t:1527188760702};\\\", \\\"{x:379,y:521,t:1527188760992};\\\", \\\"{x:382,y:522,t:1527188761001};\\\", \\\"{x:386,y:528,t:1527188761018};\\\", \\\"{x:390,y:537,t:1527188761034};\\\", \\\"{x:400,y:549,t:1527188761052};\\\", \\\"{x:410,y:565,t:1527188761069};\\\", \\\"{x:422,y:579,t:1527188761085};\\\", \\\"{x:434,y:593,t:1527188761102};\\\", \\\"{x:449,y:609,t:1527188761118};\\\", \\\"{x:464,y:626,t:1527188761135};\\\", \\\"{x:476,y:645,t:1527188761152};\\\", \\\"{x:503,y:683,t:1527188761169};\\\", \\\"{x:516,y:698,t:1527188761185};\\\", \\\"{x:522,y:707,t:1527188761202};\\\", \\\"{x:527,y:715,t:1527188761218};\\\", \\\"{x:530,y:718,t:1527188761235};\\\", \\\"{x:530,y:719,t:1527188761251};\\\", \\\"{x:530,y:720,t:1527188761346};\\\", \\\"{x:530,y:721,t:1527188761361};\\\" ] }, { \\\"rt\\\": 9439, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 155755, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:723,t:1527188765970};\\\", \\\"{x:548,y:726,t:1527188765977};\\\", \\\"{x:560,y:727,t:1527188765989};\\\", \\\"{x:588,y:733,t:1527188766006};\\\", \\\"{x:618,y:738,t:1527188766023};\\\", \\\"{x:657,y:743,t:1527188766038};\\\", \\\"{x:698,y:748,t:1527188766055};\\\", \\\"{x:770,y:760,t:1527188766072};\\\", \\\"{x:824,y:768,t:1527188766088};\\\", \\\"{x:864,y:770,t:1527188766105};\\\", \\\"{x:901,y:776,t:1527188766121};\\\", \\\"{x:928,y:780,t:1527188766138};\\\", \\\"{x:956,y:783,t:1527188766155};\\\", \\\"{x:981,y:787,t:1527188766173};\\\", \\\"{x:1003,y:790,t:1527188766189};\\\", \\\"{x:1026,y:794,t:1527188766206};\\\", \\\"{x:1051,y:798,t:1527188766222};\\\", \\\"{x:1076,y:802,t:1527188766239};\\\", \\\"{x:1103,y:805,t:1527188766255};\\\", \\\"{x:1151,y:810,t:1527188766273};\\\", \\\"{x:1182,y:815,t:1527188766288};\\\", \\\"{x:1220,y:817,t:1527188766306};\\\", \\\"{x:1258,y:822,t:1527188766322};\\\", \\\"{x:1300,y:827,t:1527188766339};\\\", \\\"{x:1337,y:828,t:1527188766356};\\\", \\\"{x:1367,y:828,t:1527188766372};\\\", \\\"{x:1396,y:829,t:1527188766388};\\\", \\\"{x:1424,y:829,t:1527188766405};\\\", \\\"{x:1448,y:829,t:1527188766423};\\\", \\\"{x:1470,y:829,t:1527188766439};\\\", \\\"{x:1487,y:829,t:1527188766456};\\\", \\\"{x:1502,y:828,t:1527188766473};\\\", \\\"{x:1510,y:825,t:1527188766489};\\\", \\\"{x:1515,y:822,t:1527188766506};\\\", \\\"{x:1518,y:820,t:1527188766523};\\\", \\\"{x:1521,y:818,t:1527188766540};\\\", \\\"{x:1523,y:815,t:1527188766555};\\\", \\\"{x:1527,y:811,t:1527188766573};\\\", \\\"{x:1532,y:802,t:1527188766590};\\\", \\\"{x:1535,y:797,t:1527188766606};\\\", \\\"{x:1535,y:792,t:1527188766623};\\\", \\\"{x:1536,y:785,t:1527188766640};\\\", \\\"{x:1536,y:780,t:1527188766656};\\\", \\\"{x:1527,y:766,t:1527188766673};\\\", \\\"{x:1519,y:760,t:1527188766690};\\\", \\\"{x:1507,y:755,t:1527188766706};\\\", \\\"{x:1502,y:748,t:1527188766723};\\\", \\\"{x:1501,y:748,t:1527188766740};\\\", \\\"{x:1501,y:747,t:1527188767434};\\\", \\\"{x:1500,y:744,t:1527188767441};\\\", \\\"{x:1500,y:741,t:1527188767457};\\\", \\\"{x:1499,y:737,t:1527188767473};\\\", \\\"{x:1499,y:731,t:1527188767491};\\\", \\\"{x:1499,y:719,t:1527188767507};\\\", \\\"{x:1499,y:711,t:1527188767524};\\\", \\\"{x:1502,y:700,t:1527188767540};\\\", \\\"{x:1508,y:688,t:1527188767558};\\\", \\\"{x:1517,y:673,t:1527188767575};\\\", \\\"{x:1525,y:654,t:1527188767590};\\\", \\\"{x:1535,y:636,t:1527188767607};\\\", \\\"{x:1547,y:619,t:1527188767624};\\\", \\\"{x:1556,y:608,t:1527188767640};\\\", \\\"{x:1565,y:590,t:1527188767657};\\\", \\\"{x:1571,y:579,t:1527188767673};\\\", \\\"{x:1576,y:570,t:1527188767691};\\\", \\\"{x:1581,y:559,t:1527188767708};\\\", \\\"{x:1586,y:550,t:1527188767724};\\\", \\\"{x:1590,y:539,t:1527188767741};\\\", \\\"{x:1590,y:533,t:1527188767757};\\\", \\\"{x:1593,y:520,t:1527188767774};\\\", \\\"{x:1593,y:511,t:1527188767791};\\\", \\\"{x:1593,y:506,t:1527188767807};\\\", \\\"{x:1593,y:502,t:1527188767824};\\\", \\\"{x:1593,y:497,t:1527188767840};\\\", \\\"{x:1594,y:489,t:1527188767857};\\\", \\\"{x:1594,y:485,t:1527188767874};\\\", \\\"{x:1594,y:482,t:1527188767891};\\\", \\\"{x:1594,y:479,t:1527188767907};\\\", \\\"{x:1595,y:476,t:1527188767924};\\\", \\\"{x:1595,y:473,t:1527188767941};\\\", \\\"{x:1595,y:470,t:1527188767957};\\\", \\\"{x:1596,y:466,t:1527188767975};\\\", \\\"{x:1597,y:463,t:1527188767992};\\\", \\\"{x:1599,y:460,t:1527188768008};\\\", \\\"{x:1601,y:456,t:1527188768024};\\\", \\\"{x:1604,y:450,t:1527188768041};\\\", \\\"{x:1610,y:444,t:1527188768058};\\\", \\\"{x:1612,y:440,t:1527188768074};\\\", \\\"{x:1617,y:433,t:1527188768094};\\\", \\\"{x:1619,y:428,t:1527188768106};\\\", \\\"{x:1621,y:425,t:1527188768124};\\\", \\\"{x:1625,y:419,t:1527188768141};\\\", \\\"{x:1625,y:417,t:1527188768157};\\\", \\\"{x:1625,y:420,t:1527188768370};\\\", \\\"{x:1625,y:423,t:1527188768377};\\\", \\\"{x:1625,y:425,t:1527188768391};\\\", \\\"{x:1625,y:428,t:1527188768407};\\\", \\\"{x:1625,y:434,t:1527188768425};\\\", \\\"{x:1625,y:443,t:1527188768442};\\\", \\\"{x:1625,y:456,t:1527188768458};\\\", \\\"{x:1625,y:464,t:1527188768474};\\\", \\\"{x:1624,y:469,t:1527188768491};\\\", \\\"{x:1624,y:478,t:1527188768508};\\\", \\\"{x:1624,y:487,t:1527188768524};\\\", \\\"{x:1624,y:500,t:1527188768541};\\\", \\\"{x:1624,y:510,t:1527188768558};\\\", \\\"{x:1624,y:525,t:1527188768574};\\\", \\\"{x:1624,y:540,t:1527188768591};\\\", \\\"{x:1625,y:556,t:1527188768608};\\\", \\\"{x:1627,y:574,t:1527188768624};\\\", \\\"{x:1627,y:596,t:1527188768641};\\\", \\\"{x:1627,y:613,t:1527188768657};\\\", \\\"{x:1627,y:632,t:1527188768674};\\\", \\\"{x:1628,y:650,t:1527188768692};\\\", \\\"{x:1632,y:669,t:1527188768709};\\\", \\\"{x:1637,y:685,t:1527188768724};\\\", \\\"{x:1641,y:701,t:1527188768741};\\\", \\\"{x:1643,y:718,t:1527188768758};\\\", \\\"{x:1645,y:729,t:1527188768774};\\\", \\\"{x:1652,y:742,t:1527188768791};\\\", \\\"{x:1657,y:756,t:1527188768809};\\\", \\\"{x:1665,y:774,t:1527188768825};\\\", \\\"{x:1672,y:788,t:1527188768841};\\\", \\\"{x:1677,y:800,t:1527188768859};\\\", \\\"{x:1682,y:811,t:1527188768874};\\\", \\\"{x:1684,y:820,t:1527188768892};\\\", \\\"{x:1687,y:826,t:1527188768908};\\\", \\\"{x:1688,y:833,t:1527188768925};\\\", \\\"{x:1688,y:835,t:1527188768941};\\\", \\\"{x:1688,y:839,t:1527188768958};\\\", \\\"{x:1676,y:842,t:1527188768976};\\\", \\\"{x:1647,y:843,t:1527188768991};\\\", \\\"{x:1579,y:840,t:1527188769008};\\\", \\\"{x:1429,y:825,t:1527188769025};\\\", \\\"{x:1321,y:807,t:1527188769042};\\\", \\\"{x:1211,y:780,t:1527188769058};\\\", \\\"{x:1086,y:747,t:1527188769076};\\\", \\\"{x:970,y:713,t:1527188769092};\\\", \\\"{x:879,y:674,t:1527188769108};\\\", \\\"{x:818,y:648,t:1527188769125};\\\", \\\"{x:780,y:624,t:1527188769142};\\\", \\\"{x:752,y:612,t:1527188769160};\\\", \\\"{x:731,y:603,t:1527188769174};\\\", \\\"{x:720,y:596,t:1527188769191};\\\", \\\"{x:713,y:589,t:1527188769208};\\\", \\\"{x:708,y:587,t:1527188769225};\\\", \\\"{x:708,y:586,t:1527188769242};\\\", \\\"{x:707,y:585,t:1527188769288};\\\", \\\"{x:705,y:585,t:1527188769313};\\\", \\\"{x:702,y:585,t:1527188769325};\\\", \\\"{x:695,y:585,t:1527188769342};\\\", \\\"{x:690,y:585,t:1527188769357};\\\", \\\"{x:685,y:585,t:1527188769375};\\\", \\\"{x:674,y:590,t:1527188769392};\\\", \\\"{x:658,y:595,t:1527188769408};\\\", \\\"{x:628,y:602,t:1527188769425};\\\", \\\"{x:603,y:604,t:1527188769442};\\\", \\\"{x:581,y:607,t:1527188769458};\\\", \\\"{x:555,y:607,t:1527188769473};\\\", \\\"{x:533,y:606,t:1527188769492};\\\", \\\"{x:520,y:606,t:1527188769507};\\\", \\\"{x:512,y:606,t:1527188769524};\\\", \\\"{x:496,y:605,t:1527188769543};\\\", \\\"{x:480,y:605,t:1527188769559};\\\", \\\"{x:469,y:605,t:1527188769574};\\\", \\\"{x:464,y:605,t:1527188769592};\\\", \\\"{x:452,y:605,t:1527188769608};\\\", \\\"{x:435,y:602,t:1527188769624};\\\", \\\"{x:426,y:599,t:1527188769642};\\\", \\\"{x:421,y:597,t:1527188769658};\\\", \\\"{x:414,y:594,t:1527188769675};\\\", \\\"{x:408,y:592,t:1527188769692};\\\", \\\"{x:399,y:591,t:1527188769708};\\\", \\\"{x:386,y:590,t:1527188769725};\\\", \\\"{x:370,y:590,t:1527188769742};\\\", \\\"{x:348,y:587,t:1527188769758};\\\", \\\"{x:320,y:587,t:1527188769775};\\\", \\\"{x:291,y:586,t:1527188769792};\\\", \\\"{x:258,y:583,t:1527188769809};\\\", \\\"{x:240,y:583,t:1527188769824};\\\", \\\"{x:216,y:582,t:1527188769842};\\\", \\\"{x:190,y:581,t:1527188769860};\\\", \\\"{x:167,y:581,t:1527188769876};\\\", \\\"{x:151,y:581,t:1527188769892};\\\", \\\"{x:142,y:581,t:1527188769908};\\\", \\\"{x:132,y:581,t:1527188769926};\\\", \\\"{x:126,y:581,t:1527188769942};\\\", \\\"{x:122,y:587,t:1527188769959};\\\", \\\"{x:121,y:591,t:1527188769975};\\\", \\\"{x:121,y:595,t:1527188769991};\\\", \\\"{x:121,y:608,t:1527188770008};\\\", \\\"{x:121,y:613,t:1527188770026};\\\", \\\"{x:121,y:617,t:1527188770042};\\\", \\\"{x:121,y:619,t:1527188770064};\\\", \\\"{x:122,y:620,t:1527188770081};\\\", \\\"{x:123,y:622,t:1527188770092};\\\", \\\"{x:127,y:623,t:1527188770108};\\\", \\\"{x:128,y:624,t:1527188770126};\\\", \\\"{x:129,y:625,t:1527188770141};\\\", \\\"{x:136,y:629,t:1527188770158};\\\", \\\"{x:143,y:633,t:1527188770176};\\\", \\\"{x:147,y:635,t:1527188770192};\\\", \\\"{x:150,y:638,t:1527188770209};\\\", \\\"{x:152,y:638,t:1527188770226};\\\", \\\"{x:153,y:638,t:1527188770241};\\\", \\\"{x:154,y:638,t:1527188770328};\\\", \\\"{x:158,y:638,t:1527188770584};\\\", \\\"{x:167,y:638,t:1527188770592};\\\", \\\"{x:192,y:641,t:1527188770609};\\\", \\\"{x:241,y:648,t:1527188770625};\\\", \\\"{x:300,y:656,t:1527188770643};\\\", \\\"{x:353,y:664,t:1527188770660};\\\", \\\"{x:388,y:671,t:1527188770676};\\\", \\\"{x:421,y:674,t:1527188770692};\\\", \\\"{x:446,y:680,t:1527188770710};\\\", \\\"{x:468,y:684,t:1527188770725};\\\", \\\"{x:482,y:685,t:1527188770743};\\\", \\\"{x:493,y:688,t:1527188770760};\\\", \\\"{x:501,y:690,t:1527188770775};\\\", \\\"{x:509,y:692,t:1527188770793};\\\", \\\"{x:512,y:692,t:1527188770810};\\\", \\\"{x:513,y:692,t:1527188770826};\\\", \\\"{x:514,y:693,t:1527188770849};\\\", \\\"{x:514,y:694,t:1527188770890};\\\", \\\"{x:514,y:695,t:1527188770905};\\\", \\\"{x:514,y:697,t:1527188770921};\\\", \\\"{x:514,y:698,t:1527188770928};\\\", \\\"{x:514,y:699,t:1527188770943};\\\", \\\"{x:514,y:702,t:1527188770960};\\\", \\\"{x:514,y:706,t:1527188770976};\\\", \\\"{x:514,y:708,t:1527188770992};\\\", \\\"{x:514,y:712,t:1527188771010};\\\", \\\"{x:514,y:715,t:1527188771026};\\\", \\\"{x:514,y:716,t:1527188771043};\\\", \\\"{x:514,y:717,t:1527188771097};\\\", \\\"{x:514,y:718,t:1527188771121};\\\", \\\"{x:514,y:719,t:1527188771177};\\\", \\\"{x:514,y:720,t:1527188771193};\\\", \\\"{x:514,y:721,t:1527188771211};\\\", \\\"{x:514,y:722,t:1527188771241};\\\", \\\"{x:514,y:723,t:1527188771289};\\\", \\\"{x:513,y:723,t:1527188772025};\\\" ] }, { \\\"rt\\\": 22276, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 179328, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -C -C -C -A -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:724,t:1527188776240};\\\", \\\"{x:513,y:724,t:1527188776272};\\\", \\\"{x:516,y:724,t:1527188776281};\\\", \\\"{x:533,y:724,t:1527188776298};\\\", \\\"{x:559,y:724,t:1527188776315};\\\", \\\"{x:593,y:723,t:1527188776332};\\\", \\\"{x:643,y:723,t:1527188776348};\\\", \\\"{x:705,y:723,t:1527188776364};\\\", \\\"{x:763,y:723,t:1527188776380};\\\", \\\"{x:830,y:723,t:1527188776397};\\\", \\\"{x:908,y:721,t:1527188776414};\\\", \\\"{x:975,y:715,t:1527188776431};\\\", \\\"{x:1050,y:704,t:1527188776447};\\\", \\\"{x:1145,y:694,t:1527188776464};\\\", \\\"{x:1202,y:689,t:1527188776480};\\\", \\\"{x:1247,y:683,t:1527188776496};\\\", \\\"{x:1284,y:676,t:1527188776513};\\\", \\\"{x:1309,y:674,t:1527188776530};\\\", \\\"{x:1328,y:671,t:1527188776547};\\\", \\\"{x:1344,y:669,t:1527188776564};\\\", \\\"{x:1357,y:666,t:1527188776580};\\\", \\\"{x:1368,y:665,t:1527188776597};\\\", \\\"{x:1380,y:662,t:1527188776614};\\\", \\\"{x:1389,y:659,t:1527188776631};\\\", \\\"{x:1399,y:655,t:1527188776647};\\\", \\\"{x:1411,y:653,t:1527188776664};\\\", \\\"{x:1415,y:652,t:1527188776680};\\\", \\\"{x:1418,y:651,t:1527188776697};\\\", \\\"{x:1419,y:651,t:1527188776744};\\\", \\\"{x:1419,y:650,t:1527188776825};\\\", \\\"{x:1418,y:650,t:1527188777488};\\\", \\\"{x:1416,y:650,t:1527188778296};\\\", \\\"{x:1415,y:650,t:1527188778304};\\\", \\\"{x:1413,y:650,t:1527188778315};\\\", \\\"{x:1411,y:650,t:1527188778333};\\\", \\\"{x:1408,y:650,t:1527188778349};\\\", \\\"{x:1402,y:647,t:1527188778365};\\\", \\\"{x:1397,y:643,t:1527188778382};\\\", \\\"{x:1391,y:638,t:1527188778399};\\\", \\\"{x:1385,y:632,t:1527188778415};\\\", \\\"{x:1380,y:623,t:1527188778433};\\\", \\\"{x:1376,y:615,t:1527188778449};\\\", \\\"{x:1372,y:608,t:1527188778465};\\\", \\\"{x:1371,y:605,t:1527188778482};\\\", \\\"{x:1370,y:603,t:1527188778499};\\\", \\\"{x:1370,y:600,t:1527188778515};\\\", \\\"{x:1370,y:598,t:1527188778532};\\\", \\\"{x:1370,y:596,t:1527188778549};\\\", \\\"{x:1370,y:593,t:1527188778565};\\\", \\\"{x:1370,y:592,t:1527188778582};\\\", \\\"{x:1370,y:590,t:1527188778599};\\\", \\\"{x:1370,y:588,t:1527188778632};\\\", \\\"{x:1372,y:588,t:1527188778665};\\\", \\\"{x:1372,y:589,t:1527188778873};\\\", \\\"{x:1372,y:590,t:1527188778882};\\\", \\\"{x:1374,y:594,t:1527188778899};\\\", \\\"{x:1375,y:596,t:1527188778916};\\\", \\\"{x:1376,y:600,t:1527188778932};\\\", \\\"{x:1376,y:601,t:1527188778949};\\\", \\\"{x:1376,y:605,t:1527188778966};\\\", \\\"{x:1376,y:611,t:1527188778982};\\\", \\\"{x:1376,y:614,t:1527188779000};\\\", \\\"{x:1376,y:619,t:1527188779016};\\\", \\\"{x:1376,y:622,t:1527188779032};\\\", \\\"{x:1376,y:625,t:1527188779049};\\\", \\\"{x:1377,y:630,t:1527188779066};\\\", \\\"{x:1378,y:636,t:1527188779082};\\\", \\\"{x:1379,y:641,t:1527188779099};\\\", \\\"{x:1380,y:647,t:1527188779116};\\\", \\\"{x:1381,y:652,t:1527188779132};\\\", \\\"{x:1383,y:660,t:1527188779149};\\\", \\\"{x:1386,y:668,t:1527188779166};\\\", \\\"{x:1387,y:674,t:1527188779183};\\\", \\\"{x:1390,y:683,t:1527188779200};\\\", \\\"{x:1393,y:696,t:1527188779216};\\\", \\\"{x:1395,y:703,t:1527188779233};\\\", \\\"{x:1397,y:711,t:1527188779249};\\\", \\\"{x:1399,y:715,t:1527188779266};\\\", \\\"{x:1400,y:719,t:1527188779283};\\\", \\\"{x:1401,y:722,t:1527188779299};\\\", \\\"{x:1402,y:725,t:1527188779316};\\\", \\\"{x:1402,y:727,t:1527188779333};\\\", \\\"{x:1402,y:730,t:1527188779349};\\\", \\\"{x:1402,y:732,t:1527188779366};\\\", \\\"{x:1402,y:735,t:1527188779384};\\\", \\\"{x:1402,y:737,t:1527188779399};\\\", \\\"{x:1402,y:739,t:1527188779416};\\\", \\\"{x:1402,y:740,t:1527188779440};\\\", \\\"{x:1402,y:741,t:1527188779449};\\\", \\\"{x:1402,y:742,t:1527188779466};\\\", \\\"{x:1402,y:743,t:1527188779483};\\\", \\\"{x:1401,y:746,t:1527188779499};\\\", \\\"{x:1399,y:748,t:1527188779516};\\\", \\\"{x:1394,y:754,t:1527188779533};\\\", \\\"{x:1380,y:761,t:1527188779551};\\\", \\\"{x:1364,y:773,t:1527188779566};\\\", \\\"{x:1344,y:785,t:1527188779583};\\\", \\\"{x:1296,y:805,t:1527188779600};\\\", \\\"{x:1255,y:821,t:1527188779616};\\\", \\\"{x:1225,y:834,t:1527188779633};\\\", \\\"{x:1201,y:840,t:1527188779650};\\\", \\\"{x:1183,y:844,t:1527188779666};\\\", \\\"{x:1168,y:848,t:1527188779683};\\\", \\\"{x:1158,y:850,t:1527188779700};\\\", \\\"{x:1155,y:851,t:1527188779716};\\\", \\\"{x:1151,y:852,t:1527188779733};\\\", \\\"{x:1150,y:852,t:1527188779750};\\\", \\\"{x:1154,y:849,t:1527188779864};\\\", \\\"{x:1159,y:847,t:1527188779872};\\\", \\\"{x:1165,y:846,t:1527188779883};\\\", \\\"{x:1177,y:841,t:1527188779900};\\\", \\\"{x:1194,y:836,t:1527188779916};\\\", \\\"{x:1205,y:833,t:1527188779933};\\\", \\\"{x:1210,y:831,t:1527188779950};\\\", \\\"{x:1213,y:829,t:1527188779967};\\\", \\\"{x:1216,y:829,t:1527188779983};\\\", \\\"{x:1225,y:826,t:1527188780000};\\\", \\\"{x:1228,y:825,t:1527188780017};\\\", \\\"{x:1230,y:824,t:1527188780033};\\\", \\\"{x:1232,y:824,t:1527188780051};\\\", \\\"{x:1231,y:824,t:1527188780217};\\\", \\\"{x:1227,y:824,t:1527188780233};\\\", \\\"{x:1224,y:824,t:1527188780250};\\\", \\\"{x:1221,y:824,t:1527188780267};\\\", \\\"{x:1219,y:824,t:1527188780283};\\\", \\\"{x:1218,y:824,t:1527188780300};\\\", \\\"{x:1217,y:824,t:1527188780317};\\\", \\\"{x:1216,y:824,t:1527188780333};\\\", \\\"{x:1215,y:824,t:1527188780350};\\\", \\\"{x:1214,y:824,t:1527188780544};\\\", \\\"{x:1214,y:825,t:1527188780945};\\\", \\\"{x:1214,y:826,t:1527188780967};\\\", \\\"{x:1215,y:826,t:1527188781416};\\\", \\\"{x:1216,y:827,t:1527188781464};\\\", \\\"{x:1217,y:829,t:1527188786520};\\\", \\\"{x:1219,y:830,t:1527188786528};\\\", \\\"{x:1223,y:830,t:1527188786538};\\\", \\\"{x:1232,y:830,t:1527188786555};\\\", \\\"{x:1238,y:830,t:1527188786571};\\\", \\\"{x:1242,y:830,t:1527188786588};\\\", \\\"{x:1243,y:830,t:1527188786606};\\\", \\\"{x:1244,y:830,t:1527188786622};\\\", \\\"{x:1245,y:830,t:1527188786638};\\\", \\\"{x:1246,y:830,t:1527188786656};\\\", \\\"{x:1247,y:830,t:1527188786672};\\\", \\\"{x:1249,y:830,t:1527188786689};\\\", \\\"{x:1251,y:831,t:1527188786706};\\\", \\\"{x:1255,y:832,t:1527188786722};\\\", \\\"{x:1259,y:832,t:1527188786738};\\\", \\\"{x:1265,y:832,t:1527188786755};\\\", \\\"{x:1271,y:832,t:1527188786772};\\\", \\\"{x:1277,y:832,t:1527188786788};\\\", \\\"{x:1281,y:833,t:1527188786806};\\\", \\\"{x:1282,y:833,t:1527188786822};\\\", \\\"{x:1283,y:833,t:1527188786838};\\\", \\\"{x:1285,y:834,t:1527188786855};\\\", \\\"{x:1287,y:834,t:1527188786873};\\\", \\\"{x:1288,y:834,t:1527188786889};\\\", \\\"{x:1288,y:835,t:1527188786906};\\\", \\\"{x:1292,y:836,t:1527188786923};\\\", \\\"{x:1298,y:838,t:1527188786939};\\\", \\\"{x:1304,y:839,t:1527188786955};\\\", \\\"{x:1311,y:840,t:1527188786972};\\\", \\\"{x:1321,y:841,t:1527188786988};\\\", \\\"{x:1333,y:843,t:1527188787005};\\\", \\\"{x:1344,y:844,t:1527188787022};\\\", \\\"{x:1352,y:845,t:1527188787039};\\\", \\\"{x:1360,y:845,t:1527188787056};\\\", \\\"{x:1369,y:845,t:1527188787073};\\\", \\\"{x:1374,y:845,t:1527188787089};\\\", \\\"{x:1376,y:845,t:1527188787105};\\\", \\\"{x:1377,y:844,t:1527188787209};\\\", \\\"{x:1377,y:843,t:1527188787222};\\\", \\\"{x:1373,y:838,t:1527188787239};\\\", \\\"{x:1370,y:836,t:1527188787256};\\\", \\\"{x:1364,y:833,t:1527188787272};\\\", \\\"{x:1359,y:832,t:1527188787290};\\\", \\\"{x:1356,y:831,t:1527188787305};\\\", \\\"{x:1354,y:830,t:1527188787323};\\\", \\\"{x:1353,y:830,t:1527188787344};\\\", \\\"{x:1352,y:829,t:1527188787361};\\\", \\\"{x:1351,y:829,t:1527188787376};\\\", \\\"{x:1350,y:829,t:1527188787401};\\\", \\\"{x:1348,y:829,t:1527188787417};\\\", \\\"{x:1347,y:829,t:1527188787440};\\\", \\\"{x:1346,y:829,t:1527188787456};\\\", \\\"{x:1345,y:829,t:1527188787560};\\\", \\\"{x:1345,y:832,t:1527188790120};\\\", \\\"{x:1345,y:834,t:1527188790128};\\\", \\\"{x:1345,y:836,t:1527188790142};\\\", \\\"{x:1345,y:840,t:1527188790159};\\\", \\\"{x:1345,y:842,t:1527188790175};\\\", \\\"{x:1345,y:844,t:1527188790192};\\\", \\\"{x:1346,y:851,t:1527188790208};\\\", \\\"{x:1346,y:855,t:1527188790225};\\\", \\\"{x:1347,y:859,t:1527188790241};\\\", \\\"{x:1348,y:862,t:1527188790259};\\\", \\\"{x:1348,y:866,t:1527188790275};\\\", \\\"{x:1349,y:869,t:1527188790291};\\\", \\\"{x:1350,y:874,t:1527188790309};\\\", \\\"{x:1351,y:879,t:1527188790324};\\\", \\\"{x:1352,y:882,t:1527188790341};\\\", \\\"{x:1352,y:883,t:1527188790359};\\\", \\\"{x:1352,y:885,t:1527188790375};\\\", \\\"{x:1352,y:886,t:1527188790408};\\\", \\\"{x:1353,y:888,t:1527188790440};\\\", \\\"{x:1353,y:889,t:1527188790456};\\\", \\\"{x:1353,y:890,t:1527188790472};\\\", \\\"{x:1353,y:891,t:1527188790480};\\\", \\\"{x:1353,y:892,t:1527188790492};\\\", \\\"{x:1353,y:895,t:1527188790509};\\\", \\\"{x:1353,y:898,t:1527188790524};\\\", \\\"{x:1352,y:899,t:1527188790541};\\\", \\\"{x:1352,y:901,t:1527188790569};\\\", \\\"{x:1352,y:902,t:1527188790625};\\\", \\\"{x:1351,y:902,t:1527188790633};\\\", \\\"{x:1350,y:902,t:1527188790825};\\\", \\\"{x:1348,y:902,t:1527188790874};\\\", \\\"{x:1348,y:901,t:1527188790897};\\\", \\\"{x:1347,y:900,t:1527188790944};\\\", \\\"{x:1347,y:899,t:1527188790959};\\\", \\\"{x:1342,y:896,t:1527188790976};\\\", \\\"{x:1331,y:889,t:1527188790992};\\\", \\\"{x:1290,y:874,t:1527188791008};\\\", \\\"{x:1245,y:861,t:1527188791026};\\\", \\\"{x:1171,y:843,t:1527188791042};\\\", \\\"{x:1085,y:822,t:1527188791059};\\\", \\\"{x:986,y:796,t:1527188791076};\\\", \\\"{x:900,y:769,t:1527188791092};\\\", \\\"{x:825,y:749,t:1527188791109};\\\", \\\"{x:764,y:730,t:1527188791126};\\\", \\\"{x:708,y:714,t:1527188791142};\\\", \\\"{x:673,y:702,t:1527188791158};\\\", \\\"{x:648,y:694,t:1527188791176};\\\", \\\"{x:625,y:684,t:1527188791192};\\\", \\\"{x:614,y:681,t:1527188791208};\\\", \\\"{x:606,y:677,t:1527188791225};\\\", \\\"{x:595,y:674,t:1527188791243};\\\", \\\"{x:578,y:670,t:1527188791258};\\\", \\\"{x:557,y:665,t:1527188791276};\\\", \\\"{x:533,y:660,t:1527188791293};\\\", \\\"{x:511,y:654,t:1527188791309};\\\", \\\"{x:480,y:648,t:1527188791326};\\\", \\\"{x:450,y:644,t:1527188791343};\\\", \\\"{x:428,y:641,t:1527188791358};\\\", \\\"{x:418,y:638,t:1527188791375};\\\", \\\"{x:415,y:637,t:1527188791392};\\\", \\\"{x:415,y:636,t:1527188791408};\\\", \\\"{x:418,y:634,t:1527188791425};\\\", \\\"{x:432,y:633,t:1527188791442};\\\", \\\"{x:449,y:633,t:1527188791460};\\\", \\\"{x:470,y:633,t:1527188791476};\\\", \\\"{x:489,y:633,t:1527188791492};\\\", \\\"{x:509,y:633,t:1527188791510};\\\", \\\"{x:524,y:633,t:1527188791525};\\\", \\\"{x:538,y:633,t:1527188791542};\\\", \\\"{x:549,y:633,t:1527188791560};\\\", \\\"{x:554,y:633,t:1527188791575};\\\", \\\"{x:555,y:633,t:1527188791592};\\\", \\\"{x:553,y:633,t:1527188793272};\\\", \\\"{x:548,y:633,t:1527188793280};\\\", \\\"{x:541,y:633,t:1527188793293};\\\", \\\"{x:522,y:633,t:1527188793311};\\\", \\\"{x:499,y:633,t:1527188793327};\\\", \\\"{x:485,y:633,t:1527188793344};\\\", \\\"{x:467,y:633,t:1527188793361};\\\", \\\"{x:448,y:633,t:1527188793377};\\\", \\\"{x:428,y:633,t:1527188793394};\\\", \\\"{x:414,y:633,t:1527188793411};\\\", \\\"{x:400,y:632,t:1527188793426};\\\", \\\"{x:389,y:632,t:1527188793444};\\\", \\\"{x:380,y:630,t:1527188793461};\\\", \\\"{x:372,y:630,t:1527188793478};\\\", \\\"{x:367,y:629,t:1527188793495};\\\", \\\"{x:361,y:628,t:1527188793511};\\\", \\\"{x:357,y:626,t:1527188793528};\\\", \\\"{x:349,y:626,t:1527188793544};\\\", \\\"{x:338,y:624,t:1527188793561};\\\", \\\"{x:325,y:621,t:1527188793577};\\\", \\\"{x:310,y:620,t:1527188793595};\\\", \\\"{x:291,y:616,t:1527188793611};\\\", \\\"{x:269,y:613,t:1527188793627};\\\", \\\"{x:243,y:608,t:1527188793645};\\\", \\\"{x:219,y:600,t:1527188793660};\\\", \\\"{x:198,y:593,t:1527188793677};\\\", \\\"{x:179,y:588,t:1527188793695};\\\", \\\"{x:163,y:582,t:1527188793711};\\\", \\\"{x:151,y:576,t:1527188793729};\\\", \\\"{x:141,y:571,t:1527188793744};\\\", \\\"{x:138,y:568,t:1527188793760};\\\", \\\"{x:138,y:567,t:1527188793778};\\\", \\\"{x:138,y:566,t:1527188793795};\\\", \\\"{x:139,y:565,t:1527188793811};\\\", \\\"{x:139,y:564,t:1527188793865};\\\", \\\"{x:140,y:563,t:1527188793878};\\\", \\\"{x:142,y:562,t:1527188793896};\\\", \\\"{x:143,y:561,t:1527188793920};\\\", \\\"{x:144,y:560,t:1527188793945};\\\", \\\"{x:146,y:559,t:1527188793969};\\\", \\\"{x:146,y:558,t:1527188793978};\\\", \\\"{x:147,y:558,t:1527188793995};\\\", \\\"{x:148,y:556,t:1527188794012};\\\", \\\"{x:151,y:556,t:1527188794314};\\\", \\\"{x:155,y:556,t:1527188794327};\\\", \\\"{x:182,y:560,t:1527188794345};\\\", \\\"{x:201,y:565,t:1527188794362};\\\", \\\"{x:226,y:576,t:1527188794378};\\\", \\\"{x:245,y:586,t:1527188794396};\\\", \\\"{x:273,y:594,t:1527188794412};\\\", \\\"{x:288,y:600,t:1527188794429};\\\", \\\"{x:304,y:605,t:1527188794445};\\\", \\\"{x:316,y:608,t:1527188794462};\\\", \\\"{x:325,y:612,t:1527188794479};\\\", \\\"{x:334,y:617,t:1527188794495};\\\", \\\"{x:350,y:624,t:1527188794513};\\\", \\\"{x:362,y:629,t:1527188794528};\\\", \\\"{x:369,y:632,t:1527188794545};\\\", \\\"{x:374,y:635,t:1527188794562};\\\", \\\"{x:372,y:635,t:1527188794690};\\\", \\\"{x:368,y:635,t:1527188794697};\\\", \\\"{x:358,y:633,t:1527188794712};\\\", \\\"{x:342,y:625,t:1527188794728};\\\", \\\"{x:321,y:618,t:1527188794746};\\\", \\\"{x:290,y:605,t:1527188794762};\\\", \\\"{x:269,y:599,t:1527188794779};\\\", \\\"{x:251,y:594,t:1527188794795};\\\", \\\"{x:240,y:590,t:1527188794812};\\\", \\\"{x:228,y:588,t:1527188794828};\\\", \\\"{x:224,y:586,t:1527188794846};\\\", \\\"{x:224,y:584,t:1527188794920};\\\", \\\"{x:223,y:583,t:1527188794936};\\\", \\\"{x:223,y:582,t:1527188794946};\\\", \\\"{x:220,y:581,t:1527188794962};\\\", \\\"{x:217,y:580,t:1527188794978};\\\", \\\"{x:214,y:579,t:1527188794995};\\\", \\\"{x:209,y:578,t:1527188795012};\\\", \\\"{x:203,y:578,t:1527188795029};\\\", \\\"{x:198,y:576,t:1527188795046};\\\", \\\"{x:194,y:575,t:1527188795062};\\\", \\\"{x:186,y:573,t:1527188795080};\\\", \\\"{x:182,y:572,t:1527188795096};\\\", \\\"{x:180,y:571,t:1527188795112};\\\", \\\"{x:179,y:571,t:1527188795129};\\\", \\\"{x:177,y:569,t:1527188795146};\\\", \\\"{x:176,y:568,t:1527188795163};\\\", \\\"{x:173,y:566,t:1527188795179};\\\", \\\"{x:170,y:564,t:1527188795196};\\\", \\\"{x:168,y:562,t:1527188795212};\\\", \\\"{x:165,y:561,t:1527188795229};\\\", \\\"{x:163,y:559,t:1527188795246};\\\", \\\"{x:163,y:558,t:1527188795264};\\\", \\\"{x:166,y:558,t:1527188795769};\\\", \\\"{x:170,y:558,t:1527188795780};\\\", \\\"{x:184,y:561,t:1527188795796};\\\", \\\"{x:203,y:566,t:1527188795814};\\\", \\\"{x:227,y:578,t:1527188795831};\\\", \\\"{x:255,y:590,t:1527188795848};\\\", \\\"{x:285,y:604,t:1527188795864};\\\", \\\"{x:325,y:623,t:1527188795881};\\\", \\\"{x:336,y:627,t:1527188795896};\\\", \\\"{x:366,y:639,t:1527188795913};\\\", \\\"{x:381,y:646,t:1527188795930};\\\", \\\"{x:393,y:651,t:1527188795946};\\\", \\\"{x:402,y:654,t:1527188795963};\\\", \\\"{x:413,y:659,t:1527188795980};\\\", \\\"{x:427,y:663,t:1527188795996};\\\", \\\"{x:439,y:667,t:1527188796013};\\\", \\\"{x:448,y:669,t:1527188796029};\\\", \\\"{x:460,y:673,t:1527188796046};\\\", \\\"{x:471,y:677,t:1527188796063};\\\", \\\"{x:480,y:679,t:1527188796079};\\\", \\\"{x:487,y:683,t:1527188796097};\\\", \\\"{x:490,y:685,t:1527188796112};\\\", \\\"{x:492,y:686,t:1527188796129};\\\", \\\"{x:493,y:687,t:1527188796185};\\\", \\\"{x:493,y:688,t:1527188796225};\\\", \\\"{x:493,y:689,t:1527188796241};\\\", \\\"{x:493,y:690,t:1527188796248};\\\", \\\"{x:493,y:691,t:1527188796265};\\\", \\\"{x:493,y:692,t:1527188796280};\\\", \\\"{x:495,y:694,t:1527188796296};\\\", \\\"{x:495,y:698,t:1527188796313};\\\", \\\"{x:495,y:700,t:1527188796329};\\\", \\\"{x:495,y:701,t:1527188796347};\\\", \\\"{x:495,y:704,t:1527188796362};\\\", \\\"{x:495,y:705,t:1527188796380};\\\", \\\"{x:495,y:706,t:1527188796398};\\\", \\\"{x:495,y:707,t:1527188796414};\\\", \\\"{x:495,y:709,t:1527188796430};\\\", \\\"{x:495,y:707,t:1527188798378};\\\", \\\"{x:495,y:706,t:1527188798387};\\\", \\\"{x:495,y:704,t:1527188798403};\\\" ] }, { \\\"rt\\\": 50729, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 231516, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -12 PM-Z -Z -F -F -H -01 PM-H -H -H -U -U -B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:700,t:1527188798771};\\\", \\\"{x:494,y:698,t:1527188798899};\\\", \\\"{x:494,y:697,t:1527188798972};\\\", \\\"{x:494,y:695,t:1527188799083};\\\", \\\"{x:494,y:693,t:1527188799091};\\\", \\\"{x:494,y:692,t:1527188799107};\\\", \\\"{x:494,y:691,t:1527188799117};\\\", \\\"{x:493,y:688,t:1527188799134};\\\", \\\"{x:493,y:687,t:1527188799163};\\\", \\\"{x:493,y:685,t:1527188799458};\\\", \\\"{x:493,y:682,t:1527188799468};\\\", \\\"{x:496,y:678,t:1527188799484};\\\", \\\"{x:500,y:672,t:1527188799502};\\\", \\\"{x:505,y:664,t:1527188799519};\\\", \\\"{x:519,y:651,t:1527188799535};\\\", \\\"{x:525,y:644,t:1527188799552};\\\", \\\"{x:527,y:642,t:1527188799569};\\\", \\\"{x:527,y:641,t:1527188799994};\\\", \\\"{x:527,y:640,t:1527188800035};\\\", \\\"{x:527,y:638,t:1527188800051};\\\", \\\"{x:527,y:637,t:1527188800090};\\\", \\\"{x:527,y:635,t:1527188800107};\\\", \\\"{x:530,y:634,t:1527188800119};\\\", \\\"{x:534,y:633,t:1527188800136};\\\", \\\"{x:538,y:631,t:1527188800152};\\\", \\\"{x:547,y:629,t:1527188800169};\\\", \\\"{x:558,y:625,t:1527188800186};\\\", \\\"{x:568,y:624,t:1527188800202};\\\", \\\"{x:589,y:619,t:1527188800218};\\\", \\\"{x:605,y:616,t:1527188800236};\\\", \\\"{x:620,y:615,t:1527188800253};\\\", \\\"{x:643,y:612,t:1527188800269};\\\", \\\"{x:668,y:609,t:1527188800286};\\\", \\\"{x:695,y:604,t:1527188800302};\\\", \\\"{x:723,y:602,t:1527188800318};\\\", \\\"{x:750,y:602,t:1527188800336};\\\", \\\"{x:776,y:602,t:1527188800353};\\\", \\\"{x:795,y:602,t:1527188800369};\\\", \\\"{x:814,y:602,t:1527188800386};\\\", \\\"{x:838,y:602,t:1527188800403};\\\", \\\"{x:854,y:602,t:1527188800420};\\\", \\\"{x:867,y:602,t:1527188800436};\\\", \\\"{x:884,y:602,t:1527188800452};\\\", \\\"{x:903,y:602,t:1527188800468};\\\", \\\"{x:919,y:602,t:1527188800485};\\\", \\\"{x:941,y:602,t:1527188800503};\\\", \\\"{x:965,y:602,t:1527188800519};\\\", \\\"{x:1001,y:605,t:1527188800536};\\\", \\\"{x:1037,y:609,t:1527188800553};\\\", \\\"{x:1066,y:612,t:1527188800570};\\\", \\\"{x:1095,y:617,t:1527188800585};\\\", \\\"{x:1152,y:632,t:1527188800603};\\\", \\\"{x:1198,y:642,t:1527188800620};\\\", \\\"{x:1234,y:652,t:1527188800636};\\\", \\\"{x:1273,y:661,t:1527188800653};\\\", \\\"{x:1305,y:668,t:1527188800670};\\\", \\\"{x:1342,y:674,t:1527188800685};\\\", \\\"{x:1372,y:680,t:1527188800703};\\\", \\\"{x:1399,y:685,t:1527188800720};\\\", \\\"{x:1423,y:687,t:1527188800736};\\\", \\\"{x:1446,y:692,t:1527188800752};\\\", \\\"{x:1470,y:695,t:1527188800770};\\\", \\\"{x:1494,y:697,t:1527188800785};\\\", \\\"{x:1523,y:703,t:1527188800803};\\\", \\\"{x:1540,y:704,t:1527188800819};\\\", \\\"{x:1554,y:707,t:1527188800835};\\\", \\\"{x:1564,y:708,t:1527188800853};\\\", \\\"{x:1570,y:709,t:1527188800870};\\\", \\\"{x:1571,y:709,t:1527188800885};\\\", \\\"{x:1572,y:709,t:1527188800902};\\\", \\\"{x:1573,y:709,t:1527188800994};\\\", \\\"{x:1574,y:708,t:1527188801011};\\\", \\\"{x:1575,y:707,t:1527188801020};\\\", \\\"{x:1576,y:706,t:1527188801036};\\\", \\\"{x:1578,y:703,t:1527188801053};\\\", \\\"{x:1580,y:701,t:1527188801070};\\\", \\\"{x:1581,y:697,t:1527188801086};\\\", \\\"{x:1583,y:693,t:1527188801102};\\\", \\\"{x:1585,y:687,t:1527188801120};\\\", \\\"{x:1586,y:683,t:1527188801135};\\\", \\\"{x:1587,y:681,t:1527188801152};\\\", \\\"{x:1587,y:679,t:1527188801170};\\\", \\\"{x:1587,y:676,t:1527188801186};\\\", \\\"{x:1587,y:673,t:1527188801202};\\\", \\\"{x:1587,y:672,t:1527188801220};\\\", \\\"{x:1587,y:669,t:1527188801237};\\\", \\\"{x:1587,y:668,t:1527188801258};\\\", \\\"{x:1587,y:667,t:1527188801491};\\\", \\\"{x:1586,y:667,t:1527188801503};\\\", \\\"{x:1586,y:666,t:1527188801520};\\\", \\\"{x:1585,y:665,t:1527188801537};\\\", \\\"{x:1584,y:664,t:1527188801553};\\\", \\\"{x:1582,y:662,t:1527188801579};\\\", \\\"{x:1581,y:661,t:1527188801603};\\\", \\\"{x:1580,y:661,t:1527188801634};\\\", \\\"{x:1579,y:660,t:1527188801643};\\\", \\\"{x:1579,y:659,t:1527188801659};\\\", \\\"{x:1578,y:659,t:1527188801683};\\\", \\\"{x:1577,y:659,t:1527188801690};\\\", \\\"{x:1576,y:659,t:1527188801707};\\\", \\\"{x:1574,y:657,t:1527188801723};\\\", \\\"{x:1573,y:657,t:1527188801736};\\\", \\\"{x:1572,y:657,t:1527188801755};\\\", \\\"{x:1569,y:656,t:1527188801771};\\\", \\\"{x:1568,y:656,t:1527188801787};\\\", \\\"{x:1566,y:655,t:1527188801803};\\\", \\\"{x:1562,y:654,t:1527188801820};\\\", \\\"{x:1560,y:654,t:1527188801837};\\\", \\\"{x:1559,y:654,t:1527188801854};\\\", \\\"{x:1557,y:654,t:1527188801870};\\\", \\\"{x:1557,y:653,t:1527188801887};\\\", \\\"{x:1556,y:653,t:1527188801915};\\\", \\\"{x:1555,y:653,t:1527188801931};\\\", \\\"{x:1554,y:653,t:1527188801954};\\\", \\\"{x:1553,y:653,t:1527188802027};\\\", \\\"{x:1552,y:653,t:1527188802051};\\\", \\\"{x:1551,y:653,t:1527188802074};\\\", \\\"{x:1550,y:654,t:1527188802099};\\\", \\\"{x:1549,y:655,t:1527188802106};\\\", \\\"{x:1549,y:657,t:1527188802120};\\\", \\\"{x:1547,y:663,t:1527188802137};\\\", \\\"{x:1547,y:674,t:1527188802154};\\\", \\\"{x:1547,y:684,t:1527188802170};\\\", \\\"{x:1547,y:706,t:1527188802186};\\\", \\\"{x:1548,y:729,t:1527188802204};\\\", \\\"{x:1553,y:751,t:1527188802220};\\\", \\\"{x:1559,y:770,t:1527188802237};\\\", \\\"{x:1568,y:788,t:1527188802253};\\\", \\\"{x:1576,y:808,t:1527188802270};\\\", \\\"{x:1580,y:824,t:1527188802287};\\\", \\\"{x:1584,y:837,t:1527188802304};\\\", \\\"{x:1591,y:854,t:1527188802320};\\\", \\\"{x:1596,y:869,t:1527188802336};\\\", \\\"{x:1598,y:880,t:1527188802354};\\\", \\\"{x:1603,y:895,t:1527188802370};\\\", \\\"{x:1607,y:909,t:1527188802386};\\\", \\\"{x:1608,y:916,t:1527188802404};\\\", \\\"{x:1609,y:918,t:1527188802421};\\\", \\\"{x:1609,y:920,t:1527188802437};\\\", \\\"{x:1609,y:921,t:1527188802453};\\\", \\\"{x:1609,y:923,t:1527188802471};\\\", \\\"{x:1609,y:924,t:1527188802487};\\\", \\\"{x:1609,y:926,t:1527188802504};\\\", \\\"{x:1609,y:927,t:1527188802521};\\\", \\\"{x:1609,y:928,t:1527188802536};\\\", \\\"{x:1609,y:929,t:1527188802554};\\\", \\\"{x:1609,y:930,t:1527188802906};\\\", \\\"{x:1608,y:930,t:1527188802987};\\\", \\\"{x:1607,y:929,t:1527188803027};\\\", \\\"{x:1606,y:928,t:1527188803059};\\\", \\\"{x:1606,y:926,t:1527188803163};\\\", \\\"{x:1605,y:926,t:1527188803171};\\\", \\\"{x:1605,y:925,t:1527188803267};\\\", \\\"{x:1604,y:925,t:1527188803298};\\\", \\\"{x:1603,y:924,t:1527188803371};\\\", \\\"{x:1603,y:923,t:1527188803491};\\\", \\\"{x:1602,y:922,t:1527188803770};\\\", \\\"{x:1599,y:920,t:1527188803788};\\\", \\\"{x:1593,y:918,t:1527188803805};\\\", \\\"{x:1591,y:917,t:1527188803821};\\\", \\\"{x:1589,y:915,t:1527188803838};\\\", \\\"{x:1590,y:915,t:1527188805019};\\\", \\\"{x:1592,y:916,t:1527188805043};\\\", \\\"{x:1593,y:917,t:1527188805055};\\\", \\\"{x:1595,y:919,t:1527188805072};\\\", \\\"{x:1597,y:922,t:1527188805089};\\\", \\\"{x:1600,y:929,t:1527188805105};\\\", \\\"{x:1602,y:933,t:1527188805122};\\\", \\\"{x:1605,y:937,t:1527188805139};\\\", \\\"{x:1607,y:940,t:1527188805155};\\\", \\\"{x:1608,y:941,t:1527188805171};\\\", \\\"{x:1608,y:943,t:1527188805189};\\\", \\\"{x:1610,y:945,t:1527188805205};\\\", \\\"{x:1611,y:947,t:1527188805222};\\\", \\\"{x:1612,y:950,t:1527188805239};\\\", \\\"{x:1613,y:953,t:1527188805256};\\\", \\\"{x:1615,y:956,t:1527188805272};\\\", \\\"{x:1615,y:957,t:1527188805289};\\\", \\\"{x:1615,y:958,t:1527188805305};\\\", \\\"{x:1615,y:959,t:1527188805330};\\\", \\\"{x:1615,y:960,t:1527188805347};\\\", \\\"{x:1615,y:961,t:1527188805363};\\\", \\\"{x:1615,y:962,t:1527188805372};\\\", \\\"{x:1615,y:963,t:1527188805389};\\\", \\\"{x:1615,y:964,t:1527188805410};\\\", \\\"{x:1609,y:965,t:1527188812453};\\\", \\\"{x:1593,y:965,t:1527188812461};\\\", \\\"{x:1559,y:965,t:1527188812477};\\\", \\\"{x:1522,y:965,t:1527188812494};\\\", \\\"{x:1484,y:962,t:1527188812511};\\\", \\\"{x:1458,y:958,t:1527188812526};\\\", \\\"{x:1441,y:955,t:1527188812543};\\\", \\\"{x:1431,y:954,t:1527188812560};\\\", \\\"{x:1425,y:953,t:1527188812577};\\\", \\\"{x:1418,y:952,t:1527188812593};\\\", \\\"{x:1409,y:951,t:1527188812611};\\\", \\\"{x:1406,y:950,t:1527188812627};\\\", \\\"{x:1393,y:948,t:1527188812643};\\\", \\\"{x:1385,y:946,t:1527188812660};\\\", \\\"{x:1376,y:941,t:1527188812676};\\\", \\\"{x:1368,y:938,t:1527188812693};\\\", \\\"{x:1355,y:930,t:1527188812710};\\\", \\\"{x:1343,y:921,t:1527188812726};\\\", \\\"{x:1332,y:915,t:1527188812744};\\\", \\\"{x:1320,y:906,t:1527188812761};\\\", \\\"{x:1303,y:894,t:1527188812777};\\\", \\\"{x:1290,y:883,t:1527188812794};\\\", \\\"{x:1282,y:877,t:1527188812810};\\\", \\\"{x:1272,y:870,t:1527188812827};\\\", \\\"{x:1266,y:863,t:1527188812843};\\\", \\\"{x:1264,y:859,t:1527188812860};\\\", \\\"{x:1260,y:855,t:1527188812878};\\\", \\\"{x:1256,y:849,t:1527188812894};\\\", \\\"{x:1252,y:843,t:1527188812911};\\\", \\\"{x:1247,y:835,t:1527188812928};\\\", \\\"{x:1244,y:831,t:1527188812944};\\\", \\\"{x:1243,y:831,t:1527188812961};\\\", \\\"{x:1241,y:828,t:1527188812978};\\\", \\\"{x:1239,y:826,t:1527188812994};\\\", \\\"{x:1238,y:824,t:1527188813011};\\\", \\\"{x:1237,y:823,t:1527188813027};\\\", \\\"{x:1237,y:822,t:1527188813067};\\\", \\\"{x:1238,y:822,t:1527188813164};\\\", \\\"{x:1241,y:822,t:1527188813178};\\\", \\\"{x:1247,y:822,t:1527188813194};\\\", \\\"{x:1252,y:822,t:1527188813211};\\\", \\\"{x:1256,y:822,t:1527188813227};\\\", \\\"{x:1258,y:822,t:1527188813244};\\\", \\\"{x:1259,y:822,t:1527188813261};\\\", \\\"{x:1260,y:823,t:1527188813291};\\\", \\\"{x:1260,y:824,t:1527188813307};\\\", \\\"{x:1262,y:825,t:1527188813316};\\\", \\\"{x:1262,y:826,t:1527188813332};\\\", \\\"{x:1262,y:827,t:1527188813344};\\\", \\\"{x:1262,y:830,t:1527188813362};\\\", \\\"{x:1262,y:831,t:1527188813380};\\\", \\\"{x:1262,y:833,t:1527188813403};\\\", \\\"{x:1262,y:834,t:1527188813418};\\\", \\\"{x:1263,y:836,t:1527188813443};\\\", \\\"{x:1263,y:837,t:1527188813474};\\\", \\\"{x:1265,y:837,t:1527188813787};\\\", \\\"{x:1266,y:837,t:1527188813820};\\\", \\\"{x:1268,y:838,t:1527188813835};\\\", \\\"{x:1268,y:839,t:1527188813845};\\\", \\\"{x:1269,y:839,t:1527188813861};\\\", \\\"{x:1270,y:840,t:1527188813877};\\\", \\\"{x:1271,y:840,t:1527188813895};\\\", \\\"{x:1272,y:841,t:1527188813911};\\\", \\\"{x:1273,y:842,t:1527188813927};\\\", \\\"{x:1274,y:842,t:1527188815692};\\\", \\\"{x:1277,y:842,t:1527188815699};\\\", \\\"{x:1277,y:841,t:1527188815723};\\\", \\\"{x:1278,y:841,t:1527188815748};\\\", \\\"{x:1278,y:840,t:1527188815763};\\\", \\\"{x:1279,y:839,t:1527188816588};\\\", \\\"{x:1280,y:839,t:1527188816604};\\\", \\\"{x:1281,y:839,t:1527188816613};\\\", \\\"{x:1283,y:839,t:1527188816630};\\\", \\\"{x:1286,y:838,t:1527188816646};\\\", \\\"{x:1287,y:838,t:1527188816663};\\\", \\\"{x:1288,y:838,t:1527188816680};\\\", \\\"{x:1290,y:838,t:1527188816696};\\\", \\\"{x:1292,y:838,t:1527188816713};\\\", \\\"{x:1294,y:838,t:1527188816730};\\\", \\\"{x:1298,y:838,t:1527188816746};\\\", \\\"{x:1305,y:838,t:1527188816763};\\\", \\\"{x:1311,y:841,t:1527188816779};\\\", \\\"{x:1316,y:843,t:1527188816796};\\\", \\\"{x:1323,y:846,t:1527188816813};\\\", \\\"{x:1328,y:849,t:1527188816830};\\\", \\\"{x:1337,y:853,t:1527188816846};\\\", \\\"{x:1342,y:854,t:1527188816863};\\\", \\\"{x:1348,y:857,t:1527188816880};\\\", \\\"{x:1353,y:859,t:1527188816896};\\\", \\\"{x:1355,y:860,t:1527188816912};\\\", \\\"{x:1358,y:862,t:1527188816930};\\\", \\\"{x:1361,y:865,t:1527188816946};\\\", \\\"{x:1364,y:866,t:1527188816962};\\\", \\\"{x:1364,y:867,t:1527188816980};\\\", \\\"{x:1364,y:866,t:1527188817132};\\\", \\\"{x:1364,y:863,t:1527188817148};\\\", \\\"{x:1363,y:856,t:1527188817164};\\\", \\\"{x:1362,y:851,t:1527188817181};\\\", \\\"{x:1361,y:844,t:1527188817197};\\\", \\\"{x:1361,y:835,t:1527188817213};\\\", \\\"{x:1360,y:821,t:1527188817230};\\\", \\\"{x:1356,y:804,t:1527188817247};\\\", \\\"{x:1353,y:790,t:1527188817263};\\\", \\\"{x:1351,y:780,t:1527188817280};\\\", \\\"{x:1349,y:772,t:1527188817297};\\\", \\\"{x:1346,y:759,t:1527188817313};\\\", \\\"{x:1338,y:745,t:1527188817330};\\\", \\\"{x:1331,y:728,t:1527188817348};\\\", \\\"{x:1326,y:717,t:1527188817364};\\\", \\\"{x:1321,y:705,t:1527188817380};\\\", \\\"{x:1318,y:697,t:1527188817397};\\\", \\\"{x:1314,y:688,t:1527188817413};\\\", \\\"{x:1312,y:681,t:1527188817430};\\\", \\\"{x:1306,y:670,t:1527188817448};\\\", \\\"{x:1304,y:661,t:1527188817464};\\\", \\\"{x:1303,y:657,t:1527188817480};\\\", \\\"{x:1302,y:650,t:1527188817497};\\\", \\\"{x:1299,y:643,t:1527188817513};\\\", \\\"{x:1299,y:640,t:1527188817531};\\\", \\\"{x:1299,y:635,t:1527188817548};\\\", \\\"{x:1300,y:632,t:1527188817563};\\\", \\\"{x:1304,y:627,t:1527188817580};\\\", \\\"{x:1304,y:626,t:1527188817597};\\\", \\\"{x:1305,y:625,t:1527188817614};\\\", \\\"{x:1306,y:623,t:1527188817630};\\\", \\\"{x:1307,y:623,t:1527188817648};\\\", \\\"{x:1307,y:622,t:1527188817665};\\\", \\\"{x:1308,y:621,t:1527188817819};\\\", \\\"{x:1309,y:621,t:1527188817835};\\\", \\\"{x:1310,y:621,t:1527188817859};\\\", \\\"{x:1312,y:621,t:1527188817915};\\\", \\\"{x:1313,y:621,t:1527188817931};\\\", \\\"{x:1314,y:622,t:1527188817955};\\\", \\\"{x:1314,y:623,t:1527188817971};\\\", \\\"{x:1314,y:625,t:1527188818001};\\\", \\\"{x:1315,y:627,t:1527188818013};\\\", \\\"{x:1316,y:628,t:1527188818029};\\\", \\\"{x:1316,y:629,t:1527188818046};\\\", \\\"{x:1317,y:630,t:1527188818063};\\\", \\\"{x:1317,y:631,t:1527188818080};\\\", \\\"{x:1317,y:632,t:1527188818147};\\\", \\\"{x:1317,y:633,t:1527188818211};\\\", \\\"{x:1316,y:633,t:1527188818611};\\\", \\\"{x:1316,y:634,t:1527188818619};\\\", \\\"{x:1315,y:634,t:1527188819059};\\\", \\\"{x:1314,y:634,t:1527188819140};\\\", \\\"{x:1313,y:639,t:1527188821622};\\\", \\\"{x:1314,y:646,t:1527188821632};\\\", \\\"{x:1319,y:659,t:1527188821650};\\\", \\\"{x:1326,y:678,t:1527188821667};\\\", \\\"{x:1336,y:717,t:1527188821684};\\\", \\\"{x:1347,y:759,t:1527188821699};\\\", \\\"{x:1359,y:845,t:1527188821716};\\\", \\\"{x:1366,y:898,t:1527188821733};\\\", \\\"{x:1372,y:924,t:1527188821749};\\\", \\\"{x:1374,y:946,t:1527188821766};\\\", \\\"{x:1377,y:962,t:1527188821783};\\\", \\\"{x:1377,y:971,t:1527188821799};\\\", \\\"{x:1377,y:979,t:1527188821816};\\\", \\\"{x:1377,y:988,t:1527188821832};\\\", \\\"{x:1377,y:991,t:1527188821849};\\\", \\\"{x:1377,y:992,t:1527188821866};\\\", \\\"{x:1377,y:993,t:1527188821883};\\\", \\\"{x:1377,y:994,t:1527188821931};\\\", \\\"{x:1376,y:994,t:1527188821939};\\\", \\\"{x:1373,y:992,t:1527188821949};\\\", \\\"{x:1364,y:985,t:1527188821966};\\\", \\\"{x:1357,y:974,t:1527188821983};\\\", \\\"{x:1351,y:956,t:1527188822000};\\\", \\\"{x:1346,y:946,t:1527188822016};\\\", \\\"{x:1343,y:938,t:1527188822034};\\\", \\\"{x:1342,y:931,t:1527188822049};\\\", \\\"{x:1342,y:927,t:1527188822066};\\\", \\\"{x:1342,y:921,t:1527188822083};\\\", \\\"{x:1342,y:918,t:1527188822099};\\\", \\\"{x:1342,y:913,t:1527188822116};\\\", \\\"{x:1344,y:910,t:1527188822134};\\\", \\\"{x:1345,y:905,t:1527188822150};\\\", \\\"{x:1346,y:903,t:1527188822167};\\\", \\\"{x:1346,y:902,t:1527188822184};\\\", \\\"{x:1348,y:900,t:1527188822217};\\\", \\\"{x:1348,y:899,t:1527188822233};\\\", \\\"{x:1349,y:897,t:1527188822250};\\\", \\\"{x:1350,y:895,t:1527188822266};\\\", \\\"{x:1351,y:893,t:1527188822283};\\\", \\\"{x:1350,y:892,t:1527188825275};\\\", \\\"{x:1349,y:892,t:1527188825286};\\\", \\\"{x:1348,y:888,t:1527188825302};\\\", \\\"{x:1347,y:883,t:1527188825318};\\\", \\\"{x:1346,y:879,t:1527188825335};\\\", \\\"{x:1346,y:874,t:1527188825352};\\\", \\\"{x:1346,y:871,t:1527188825368};\\\", \\\"{x:1346,y:866,t:1527188825385};\\\", \\\"{x:1346,y:864,t:1527188825401};\\\", \\\"{x:1346,y:859,t:1527188825419};\\\", \\\"{x:1346,y:852,t:1527188825435};\\\", \\\"{x:1346,y:845,t:1527188825451};\\\", \\\"{x:1346,y:839,t:1527188825468};\\\", \\\"{x:1346,y:830,t:1527188825486};\\\", \\\"{x:1347,y:824,t:1527188825502};\\\", \\\"{x:1347,y:816,t:1527188825518};\\\", \\\"{x:1348,y:810,t:1527188825536};\\\", \\\"{x:1348,y:807,t:1527188825552};\\\", \\\"{x:1349,y:803,t:1527188825569};\\\", \\\"{x:1349,y:800,t:1527188825586};\\\", \\\"{x:1349,y:799,t:1527188825602};\\\", \\\"{x:1349,y:796,t:1527188825652};\\\", \\\"{x:1347,y:792,t:1527188825669};\\\", \\\"{x:1346,y:789,t:1527188825685};\\\", \\\"{x:1344,y:786,t:1527188825702};\\\", \\\"{x:1343,y:784,t:1527188825719};\\\", \\\"{x:1343,y:782,t:1527188825735};\\\", \\\"{x:1341,y:780,t:1527188825753};\\\", \\\"{x:1341,y:778,t:1527188825859};\\\", \\\"{x:1341,y:777,t:1527188825868};\\\", \\\"{x:1341,y:774,t:1527188825886};\\\", \\\"{x:1341,y:771,t:1527188825903};\\\", \\\"{x:1341,y:768,t:1527188825918};\\\", \\\"{x:1341,y:766,t:1527188825936};\\\", \\\"{x:1341,y:765,t:1527188825952};\\\", \\\"{x:1341,y:764,t:1527188826012};\\\", \\\"{x:1341,y:763,t:1527188826020};\\\", \\\"{x:1341,y:762,t:1527188826035};\\\", \\\"{x:1341,y:761,t:1527188826084};\\\", \\\"{x:1342,y:760,t:1527188826091};\\\", \\\"{x:1342,y:759,t:1527188826115};\\\", \\\"{x:1343,y:758,t:1527188826131};\\\", \\\"{x:1343,y:757,t:1527188826155};\\\", \\\"{x:1344,y:756,t:1527188826180};\\\", \\\"{x:1344,y:755,t:1527188826555};\\\", \\\"{x:1345,y:749,t:1527188826569};\\\", \\\"{x:1345,y:740,t:1527188826586};\\\", \\\"{x:1345,y:734,t:1527188826603};\\\", \\\"{x:1345,y:726,t:1527188826619};\\\", \\\"{x:1345,y:724,t:1527188826635};\\\", \\\"{x:1345,y:720,t:1527188826653};\\\", \\\"{x:1345,y:717,t:1527188826670};\\\", \\\"{x:1344,y:713,t:1527188826686};\\\", \\\"{x:1344,y:709,t:1527188826703};\\\", \\\"{x:1344,y:708,t:1527188826719};\\\", \\\"{x:1343,y:706,t:1527188826735};\\\", \\\"{x:1343,y:703,t:1527188826753};\\\", \\\"{x:1342,y:701,t:1527188826769};\\\", \\\"{x:1342,y:700,t:1527188826786};\\\", \\\"{x:1341,y:698,t:1527188826802};\\\", \\\"{x:1341,y:697,t:1527188826835};\\\", \\\"{x:1341,y:695,t:1527188826883};\\\", \\\"{x:1342,y:695,t:1527188829731};\\\", \\\"{x:1345,y:698,t:1527188829739};\\\", \\\"{x:1348,y:703,t:1527188829754};\\\", \\\"{x:1353,y:710,t:1527188829770};\\\", \\\"{x:1356,y:714,t:1527188829787};\\\", \\\"{x:1358,y:718,t:1527188829804};\\\", \\\"{x:1360,y:722,t:1527188829821};\\\", \\\"{x:1362,y:726,t:1527188829837};\\\", \\\"{x:1364,y:730,t:1527188829854};\\\", \\\"{x:1366,y:734,t:1527188829871};\\\", \\\"{x:1369,y:737,t:1527188829888};\\\", \\\"{x:1370,y:741,t:1527188829904};\\\", \\\"{x:1371,y:742,t:1527188829921};\\\", \\\"{x:1372,y:743,t:1527188829938};\\\", \\\"{x:1373,y:748,t:1527188829954};\\\", \\\"{x:1378,y:751,t:1527188829971};\\\", \\\"{x:1383,y:755,t:1527188829987};\\\", \\\"{x:1384,y:758,t:1527188830005};\\\", \\\"{x:1387,y:760,t:1527188830022};\\\", \\\"{x:1388,y:762,t:1527188830037};\\\", \\\"{x:1390,y:763,t:1527188830054};\\\", \\\"{x:1392,y:764,t:1527188830071};\\\", \\\"{x:1393,y:764,t:1527188830088};\\\", \\\"{x:1393,y:765,t:1527188830131};\\\", \\\"{x:1393,y:766,t:1527188830139};\\\", \\\"{x:1394,y:768,t:1527188830154};\\\", \\\"{x:1395,y:769,t:1527188830172};\\\", \\\"{x:1396,y:771,t:1527188830187};\\\", \\\"{x:1396,y:772,t:1527188830204};\\\", \\\"{x:1397,y:775,t:1527188830222};\\\", \\\"{x:1398,y:775,t:1527188830237};\\\", \\\"{x:1398,y:777,t:1527188830255};\\\", \\\"{x:1398,y:778,t:1527188830715};\\\", \\\"{x:1398,y:777,t:1527188830876};\\\", \\\"{x:1397,y:777,t:1527188830889};\\\", \\\"{x:1396,y:775,t:1527188830905};\\\", \\\"{x:1396,y:774,t:1527188830922};\\\", \\\"{x:1395,y:774,t:1527188830939};\\\", \\\"{x:1395,y:773,t:1527188830964};\\\", \\\"{x:1394,y:772,t:1527188830979};\\\", \\\"{x:1393,y:771,t:1527188831028};\\\", \\\"{x:1392,y:770,t:1527188831051};\\\", \\\"{x:1392,y:769,t:1527188831092};\\\", \\\"{x:1391,y:768,t:1527188831107};\\\", \\\"{x:1391,y:767,t:1527188831131};\\\", \\\"{x:1391,y:766,t:1527188831140};\\\", \\\"{x:1391,y:765,t:1527188831156};\\\", \\\"{x:1391,y:762,t:1527188831172};\\\", \\\"{x:1391,y:761,t:1527188831189};\\\", \\\"{x:1391,y:759,t:1527188831206};\\\", \\\"{x:1391,y:757,t:1527188831222};\\\", \\\"{x:1393,y:751,t:1527188831238};\\\", \\\"{x:1397,y:743,t:1527188831256};\\\", \\\"{x:1400,y:733,t:1527188831272};\\\", \\\"{x:1404,y:713,t:1527188831289};\\\", \\\"{x:1412,y:694,t:1527188831306};\\\", \\\"{x:1416,y:679,t:1527188831322};\\\", \\\"{x:1420,y:666,t:1527188831339};\\\", \\\"{x:1421,y:651,t:1527188831356};\\\", \\\"{x:1421,y:637,t:1527188831372};\\\", \\\"{x:1421,y:618,t:1527188831388};\\\", \\\"{x:1421,y:608,t:1527188831406};\\\", \\\"{x:1421,y:604,t:1527188831422};\\\", \\\"{x:1420,y:600,t:1527188831439};\\\", \\\"{x:1418,y:597,t:1527188831456};\\\", \\\"{x:1416,y:595,t:1527188831472};\\\", \\\"{x:1416,y:594,t:1527188831489};\\\", \\\"{x:1415,y:594,t:1527188831515};\\\", \\\"{x:1414,y:593,t:1527188831524};\\\", \\\"{x:1414,y:591,t:1527188831555};\\\", \\\"{x:1414,y:590,t:1527188831573};\\\", \\\"{x:1414,y:587,t:1527188831589};\\\", \\\"{x:1413,y:584,t:1527188831606};\\\", \\\"{x:1413,y:580,t:1527188831623};\\\", \\\"{x:1413,y:576,t:1527188831638};\\\", \\\"{x:1413,y:574,t:1527188831656};\\\", \\\"{x:1413,y:571,t:1527188831673};\\\", \\\"{x:1413,y:570,t:1527188831708};\\\", \\\"{x:1413,y:568,t:1527188831723};\\\", \\\"{x:1413,y:565,t:1527188831739};\\\", \\\"{x:1413,y:563,t:1527188831756};\\\", \\\"{x:1413,y:562,t:1527188831773};\\\", \\\"{x:1413,y:563,t:1527188833252};\\\", \\\"{x:1413,y:564,t:1527188833260};\\\", \\\"{x:1413,y:565,t:1527188833274};\\\", \\\"{x:1413,y:567,t:1527188833290};\\\", \\\"{x:1414,y:571,t:1527188833308};\\\", \\\"{x:1415,y:578,t:1527188833324};\\\", \\\"{x:1416,y:585,t:1527188833341};\\\", \\\"{x:1417,y:593,t:1527188833357};\\\", \\\"{x:1418,y:598,t:1527188833374};\\\", \\\"{x:1419,y:603,t:1527188833390};\\\", \\\"{x:1420,y:610,t:1527188833408};\\\", \\\"{x:1420,y:614,t:1527188833424};\\\", \\\"{x:1420,y:618,t:1527188833440};\\\", \\\"{x:1420,y:621,t:1527188833457};\\\", \\\"{x:1420,y:624,t:1527188833474};\\\", \\\"{x:1420,y:626,t:1527188833490};\\\", \\\"{x:1420,y:628,t:1527188833507};\\\", \\\"{x:1420,y:630,t:1527188833524};\\\", \\\"{x:1420,y:632,t:1527188833541};\\\", \\\"{x:1420,y:634,t:1527188833557};\\\", \\\"{x:1420,y:637,t:1527188833574};\\\", \\\"{x:1420,y:641,t:1527188833591};\\\", \\\"{x:1419,y:646,t:1527188833607};\\\", \\\"{x:1417,y:653,t:1527188833624};\\\", \\\"{x:1415,y:661,t:1527188833640};\\\", \\\"{x:1414,y:673,t:1527188833657};\\\", \\\"{x:1412,y:683,t:1527188833674};\\\", \\\"{x:1410,y:701,t:1527188833690};\\\", \\\"{x:1406,y:728,t:1527188833707};\\\", \\\"{x:1404,y:750,t:1527188833724};\\\", \\\"{x:1402,y:769,t:1527188833740};\\\", \\\"{x:1402,y:796,t:1527188833757};\\\", \\\"{x:1402,y:820,t:1527188833774};\\\", \\\"{x:1401,y:834,t:1527188833790};\\\", \\\"{x:1401,y:848,t:1527188833807};\\\", \\\"{x:1401,y:867,t:1527188833824};\\\", \\\"{x:1401,y:882,t:1527188833841};\\\", \\\"{x:1402,y:890,t:1527188833857};\\\", \\\"{x:1406,y:898,t:1527188833875};\\\", \\\"{x:1413,y:917,t:1527188833892};\\\", \\\"{x:1416,y:926,t:1527188833907};\\\", \\\"{x:1418,y:932,t:1527188833924};\\\", \\\"{x:1421,y:937,t:1527188833942};\\\", \\\"{x:1422,y:943,t:1527188833957};\\\", \\\"{x:1422,y:947,t:1527188833974};\\\", \\\"{x:1423,y:949,t:1527188833992};\\\", \\\"{x:1424,y:950,t:1527188834007};\\\", \\\"{x:1424,y:953,t:1527188834024};\\\", \\\"{x:1424,y:956,t:1527188834041};\\\", \\\"{x:1424,y:957,t:1527188834057};\\\", \\\"{x:1424,y:959,t:1527188834212};\\\", \\\"{x:1424,y:961,t:1527188834224};\\\", \\\"{x:1424,y:964,t:1527188834241};\\\", \\\"{x:1423,y:967,t:1527188834258};\\\", \\\"{x:1423,y:970,t:1527188834274};\\\", \\\"{x:1420,y:975,t:1527188834291};\\\", \\\"{x:1420,y:977,t:1527188834307};\\\", \\\"{x:1420,y:978,t:1527188834324};\\\", \\\"{x:1419,y:978,t:1527188834347};\\\", \\\"{x:1419,y:979,t:1527188834364};\\\", \\\"{x:1417,y:978,t:1527188835044};\\\", \\\"{x:1417,y:977,t:1527188835058};\\\", \\\"{x:1417,y:975,t:1527188835075};\\\", \\\"{x:1417,y:973,t:1527188835090};\\\", \\\"{x:1417,y:967,t:1527188835108};\\\", \\\"{x:1417,y:962,t:1527188835125};\\\", \\\"{x:1417,y:957,t:1527188835142};\\\", \\\"{x:1417,y:953,t:1527188835158};\\\", \\\"{x:1417,y:949,t:1527188835175};\\\", \\\"{x:1417,y:941,t:1527188835191};\\\", \\\"{x:1417,y:936,t:1527188835208};\\\", \\\"{x:1417,y:928,t:1527188835225};\\\", \\\"{x:1417,y:924,t:1527188835241};\\\", \\\"{x:1418,y:917,t:1527188835258};\\\", \\\"{x:1418,y:902,t:1527188835275};\\\", \\\"{x:1418,y:894,t:1527188835291};\\\", \\\"{x:1419,y:885,t:1527188835308};\\\", \\\"{x:1421,y:873,t:1527188835325};\\\", \\\"{x:1422,y:867,t:1527188835342};\\\", \\\"{x:1422,y:853,t:1527188835358};\\\", \\\"{x:1422,y:844,t:1527188835375};\\\", \\\"{x:1422,y:830,t:1527188835391};\\\", \\\"{x:1423,y:816,t:1527188835408};\\\", \\\"{x:1424,y:798,t:1527188835425};\\\", \\\"{x:1427,y:776,t:1527188835441};\\\", \\\"{x:1427,y:766,t:1527188835458};\\\", \\\"{x:1427,y:756,t:1527188835476};\\\", \\\"{x:1428,y:742,t:1527188835491};\\\", \\\"{x:1429,y:728,t:1527188835508};\\\", \\\"{x:1429,y:713,t:1527188835525};\\\", \\\"{x:1429,y:703,t:1527188835542};\\\", \\\"{x:1429,y:695,t:1527188835558};\\\", \\\"{x:1429,y:685,t:1527188835575};\\\", \\\"{x:1426,y:670,t:1527188835592};\\\", \\\"{x:1421,y:650,t:1527188835608};\\\", \\\"{x:1417,y:622,t:1527188835625};\\\", \\\"{x:1415,y:601,t:1527188835642};\\\", \\\"{x:1414,y:589,t:1527188835658};\\\", \\\"{x:1413,y:576,t:1527188835675};\\\", \\\"{x:1413,y:566,t:1527188835691};\\\", \\\"{x:1413,y:559,t:1527188835708};\\\", \\\"{x:1411,y:553,t:1527188835725};\\\", \\\"{x:1411,y:550,t:1527188835742};\\\", \\\"{x:1410,y:548,t:1527188835758};\\\", \\\"{x:1410,y:547,t:1527188835775};\\\", \\\"{x:1410,y:545,t:1527188835792};\\\", \\\"{x:1411,y:549,t:1527188836235};\\\", \\\"{x:1413,y:553,t:1527188836243};\\\", \\\"{x:1420,y:564,t:1527188836260};\\\", \\\"{x:1426,y:573,t:1527188836276};\\\", \\\"{x:1431,y:585,t:1527188836292};\\\", \\\"{x:1437,y:599,t:1527188836309};\\\", \\\"{x:1441,y:614,t:1527188836325};\\\", \\\"{x:1447,y:636,t:1527188836342};\\\", \\\"{x:1458,y:668,t:1527188836359};\\\", \\\"{x:1468,y:701,t:1527188836375};\\\", \\\"{x:1482,y:732,t:1527188836392};\\\", \\\"{x:1491,y:760,t:1527188836409};\\\", \\\"{x:1502,y:791,t:1527188836425};\\\", \\\"{x:1518,y:832,t:1527188836442};\\\", \\\"{x:1538,y:880,t:1527188836459};\\\", \\\"{x:1549,y:897,t:1527188836475};\\\", \\\"{x:1554,y:906,t:1527188836492};\\\", \\\"{x:1556,y:911,t:1527188836509};\\\", \\\"{x:1557,y:912,t:1527188836525};\\\", \\\"{x:1557,y:913,t:1527188836595};\\\", \\\"{x:1556,y:913,t:1527188836609};\\\", \\\"{x:1547,y:911,t:1527188836625};\\\", \\\"{x:1534,y:902,t:1527188836642};\\\", \\\"{x:1518,y:896,t:1527188836659};\\\", \\\"{x:1507,y:889,t:1527188836676};\\\", \\\"{x:1498,y:883,t:1527188836692};\\\", \\\"{x:1495,y:882,t:1527188836710};\\\", \\\"{x:1494,y:882,t:1527188836725};\\\", \\\"{x:1494,y:881,t:1527188836755};\\\", \\\"{x:1492,y:879,t:1527188836771};\\\", \\\"{x:1490,y:877,t:1527188836779};\\\", \\\"{x:1489,y:876,t:1527188836792};\\\", \\\"{x:1486,y:875,t:1527188836809};\\\", \\\"{x:1483,y:872,t:1527188836826};\\\", \\\"{x:1480,y:867,t:1527188836842};\\\", \\\"{x:1479,y:865,t:1527188836859};\\\", \\\"{x:1478,y:865,t:1527188836876};\\\", \\\"{x:1476,y:863,t:1527188836893};\\\", \\\"{x:1476,y:862,t:1527188836909};\\\", \\\"{x:1475,y:861,t:1527188836926};\\\", \\\"{x:1475,y:860,t:1527188836942};\\\", \\\"{x:1475,y:859,t:1527188836963};\\\", \\\"{x:1474,y:856,t:1527188837011};\\\", \\\"{x:1474,y:855,t:1527188837035};\\\", \\\"{x:1474,y:854,t:1527188837043};\\\", \\\"{x:1474,y:852,t:1527188837059};\\\", \\\"{x:1474,y:851,t:1527188837076};\\\", \\\"{x:1474,y:850,t:1527188837092};\\\", \\\"{x:1474,y:849,t:1527188837116};\\\", \\\"{x:1474,y:847,t:1527188837131};\\\", \\\"{x:1474,y:846,t:1527188837148};\\\", \\\"{x:1474,y:845,t:1527188837163};\\\", \\\"{x:1474,y:844,t:1527188837212};\\\", \\\"{x:1474,y:843,t:1527188837260};\\\", \\\"{x:1474,y:841,t:1527188837277};\\\", \\\"{x:1475,y:841,t:1527188837293};\\\", \\\"{x:1475,y:839,t:1527188837310};\\\", \\\"{x:1476,y:838,t:1527188837326};\\\", \\\"{x:1477,y:837,t:1527188837343};\\\", \\\"{x:1478,y:837,t:1527188837360};\\\", \\\"{x:1478,y:836,t:1527188837379};\\\", \\\"{x:1480,y:836,t:1527188837393};\\\", \\\"{x:1481,y:835,t:1527188837410};\\\", \\\"{x:1482,y:834,t:1527188837451};\\\", \\\"{x:1483,y:834,t:1527188837491};\\\", \\\"{x:1484,y:834,t:1527188837523};\\\", \\\"{x:1485,y:834,t:1527188837620};\\\", \\\"{x:1485,y:833,t:1527188837643};\\\", \\\"{x:1485,y:832,t:1527188837835};\\\", \\\"{x:1485,y:831,t:1527188837851};\\\", \\\"{x:1484,y:831,t:1527188837867};\\\", \\\"{x:1483,y:831,t:1527188837876};\\\", \\\"{x:1482,y:831,t:1527188837893};\\\", \\\"{x:1481,y:831,t:1527188837910};\\\", \\\"{x:1480,y:830,t:1527188837926};\\\", \\\"{x:1479,y:830,t:1527188838003};\\\", \\\"{x:1478,y:829,t:1527188838059};\\\", \\\"{x:1474,y:827,t:1527188839619};\\\", \\\"{x:1465,y:824,t:1527188839627};\\\", \\\"{x:1449,y:816,t:1527188839644};\\\", \\\"{x:1421,y:806,t:1527188839661};\\\", \\\"{x:1380,y:795,t:1527188839677};\\\", \\\"{x:1324,y:787,t:1527188839694};\\\", \\\"{x:1252,y:779,t:1527188839711};\\\", \\\"{x:1171,y:766,t:1527188839726};\\\", \\\"{x:1098,y:755,t:1527188839744};\\\", \\\"{x:1020,y:744,t:1527188839760};\\\", \\\"{x:939,y:729,t:1527188839777};\\\", \\\"{x:864,y:720,t:1527188839793};\\\", \\\"{x:779,y:707,t:1527188839810};\\\", \\\"{x:728,y:700,t:1527188839827};\\\", \\\"{x:703,y:695,t:1527188839844};\\\", \\\"{x:679,y:692,t:1527188839861};\\\", \\\"{x:664,y:689,t:1527188839877};\\\", \\\"{x:656,y:687,t:1527188839894};\\\", \\\"{x:651,y:686,t:1527188839911};\\\", \\\"{x:646,y:686,t:1527188839927};\\\", \\\"{x:644,y:685,t:1527188839944};\\\", \\\"{x:642,y:685,t:1527188839961};\\\", \\\"{x:636,y:683,t:1527188839976};\\\", \\\"{x:634,y:681,t:1527188839994};\\\", \\\"{x:628,y:672,t:1527188840010};\\\", \\\"{x:626,y:666,t:1527188840027};\\\", \\\"{x:624,y:660,t:1527188840044};\\\", \\\"{x:624,y:653,t:1527188840061};\\\", \\\"{x:624,y:641,t:1527188840077};\\\", \\\"{x:624,y:626,t:1527188840093};\\\", \\\"{x:624,y:615,t:1527188840111};\\\", \\\"{x:622,y:607,t:1527188840133};\\\", \\\"{x:620,y:604,t:1527188840150};\\\", \\\"{x:619,y:600,t:1527188840167};\\\", \\\"{x:618,y:600,t:1527188840184};\\\", \\\"{x:617,y:597,t:1527188840201};\\\", \\\"{x:616,y:596,t:1527188840234};\\\", \\\"{x:619,y:596,t:1527188840811};\\\", \\\"{x:622,y:596,t:1527188840819};\\\", \\\"{x:632,y:596,t:1527188840836};\\\", \\\"{x:649,y:599,t:1527188840853};\\\", \\\"{x:677,y:608,t:1527188840869};\\\", \\\"{x:728,y:622,t:1527188840886};\\\", \\\"{x:800,y:641,t:1527188840902};\\\", \\\"{x:883,y:666,t:1527188840919};\\\", \\\"{x:986,y:698,t:1527188840936};\\\", \\\"{x:1096,y:727,t:1527188840951};\\\", \\\"{x:1209,y:758,t:1527188840969};\\\", \\\"{x:1310,y:790,t:1527188840986};\\\", \\\"{x:1375,y:804,t:1527188841001};\\\", \\\"{x:1438,y:812,t:1527188841019};\\\", \\\"{x:1455,y:815,t:1527188841036};\\\", \\\"{x:1458,y:815,t:1527188841052};\\\", \\\"{x:1458,y:816,t:1527188841220};\\\", \\\"{x:1458,y:818,t:1527188841283};\\\", \\\"{x:1458,y:821,t:1527188841291};\\\", \\\"{x:1458,y:822,t:1527188841302};\\\", \\\"{x:1458,y:825,t:1527188841319};\\\", \\\"{x:1458,y:827,t:1527188841336};\\\", \\\"{x:1459,y:828,t:1527188841352};\\\", \\\"{x:1460,y:829,t:1527188841369};\\\", \\\"{x:1461,y:830,t:1527188841386};\\\", \\\"{x:1465,y:830,t:1527188841403};\\\", \\\"{x:1471,y:830,t:1527188841419};\\\", \\\"{x:1477,y:830,t:1527188841436};\\\", \\\"{x:1482,y:830,t:1527188841453};\\\", \\\"{x:1488,y:830,t:1527188841470};\\\", \\\"{x:1490,y:830,t:1527188841486};\\\", \\\"{x:1491,y:830,t:1527188841503};\\\", \\\"{x:1492,y:830,t:1527188841595};\\\", \\\"{x:1493,y:830,t:1527188841603};\\\", \\\"{x:1494,y:830,t:1527188841636};\\\", \\\"{x:1494,y:829,t:1527188842652};\\\", \\\"{x:1494,y:825,t:1527188842660};\\\", \\\"{x:1494,y:820,t:1527188842671};\\\", \\\"{x:1494,y:809,t:1527188842688};\\\", \\\"{x:1495,y:797,t:1527188842704};\\\", \\\"{x:1495,y:785,t:1527188842720};\\\", \\\"{x:1495,y:776,t:1527188842738};\\\", \\\"{x:1495,y:762,t:1527188842754};\\\", \\\"{x:1495,y:748,t:1527188842770};\\\", \\\"{x:1497,y:736,t:1527188842787};\\\", \\\"{x:1497,y:731,t:1527188842804};\\\", \\\"{x:1497,y:724,t:1527188842821};\\\", \\\"{x:1500,y:707,t:1527188842837};\\\", \\\"{x:1503,y:699,t:1527188842853};\\\", \\\"{x:1504,y:693,t:1527188842870};\\\", \\\"{x:1507,y:685,t:1527188842888};\\\", \\\"{x:1509,y:676,t:1527188842904};\\\", \\\"{x:1511,y:672,t:1527188842921};\\\", \\\"{x:1511,y:669,t:1527188842937};\\\", \\\"{x:1511,y:667,t:1527188842954};\\\", \\\"{x:1514,y:662,t:1527188842971};\\\", \\\"{x:1515,y:658,t:1527188842987};\\\", \\\"{x:1515,y:657,t:1527188843003};\\\", \\\"{x:1515,y:655,t:1527188843021};\\\", \\\"{x:1515,y:654,t:1527188843037};\\\", \\\"{x:1516,y:652,t:1527188843067};\\\", \\\"{x:1516,y:650,t:1527188843083};\\\", \\\"{x:1517,y:649,t:1527188843091};\\\", \\\"{x:1517,y:648,t:1527188843104};\\\", \\\"{x:1518,y:647,t:1527188843121};\\\", \\\"{x:1519,y:646,t:1527188843139};\\\", \\\"{x:1519,y:645,t:1527188843196};\\\", \\\"{x:1520,y:647,t:1527188843323};\\\", \\\"{x:1520,y:649,t:1527188843338};\\\", \\\"{x:1520,y:660,t:1527188843354};\\\", \\\"{x:1520,y:676,t:1527188843370};\\\", \\\"{x:1520,y:704,t:1527188843387};\\\", \\\"{x:1520,y:720,t:1527188843404};\\\", \\\"{x:1520,y:735,t:1527188843419};\\\", \\\"{x:1520,y:754,t:1527188843437};\\\", \\\"{x:1520,y:772,t:1527188843454};\\\", \\\"{x:1520,y:791,t:1527188843470};\\\", \\\"{x:1520,y:802,t:1527188843487};\\\", \\\"{x:1520,y:811,t:1527188843504};\\\", \\\"{x:1520,y:822,t:1527188843520};\\\", \\\"{x:1520,y:828,t:1527188843537};\\\", \\\"{x:1520,y:835,t:1527188843554};\\\", \\\"{x:1520,y:841,t:1527188843570};\\\", \\\"{x:1523,y:847,t:1527188843587};\\\", \\\"{x:1525,y:850,t:1527188843604};\\\", \\\"{x:1528,y:852,t:1527188843620};\\\", \\\"{x:1540,y:854,t:1527188843638};\\\", \\\"{x:1566,y:854,t:1527188843654};\\\", \\\"{x:1599,y:854,t:1527188843670};\\\", \\\"{x:1639,y:854,t:1527188843687};\\\", \\\"{x:1678,y:854,t:1527188843704};\\\", \\\"{x:1705,y:854,t:1527188843722};\\\", \\\"{x:1726,y:854,t:1527188843737};\\\", \\\"{x:1738,y:852,t:1527188843755};\\\", \\\"{x:1745,y:849,t:1527188843771};\\\", \\\"{x:1745,y:847,t:1527188843787};\\\", \\\"{x:1745,y:846,t:1527188843804};\\\", \\\"{x:1745,y:842,t:1527188843822};\\\", \\\"{x:1745,y:840,t:1527188843837};\\\", \\\"{x:1745,y:837,t:1527188843854};\\\", \\\"{x:1745,y:834,t:1527188843871};\\\", \\\"{x:1745,y:832,t:1527188843887};\\\", \\\"{x:1740,y:829,t:1527188843905};\\\", \\\"{x:1733,y:828,t:1527188843921};\\\", \\\"{x:1724,y:826,t:1527188843937};\\\", \\\"{x:1719,y:826,t:1527188843954};\\\", \\\"{x:1710,y:826,t:1527188843971};\\\", \\\"{x:1704,y:825,t:1527188843988};\\\", \\\"{x:1700,y:825,t:1527188844005};\\\", \\\"{x:1697,y:825,t:1527188844021};\\\", \\\"{x:1696,y:825,t:1527188844038};\\\", \\\"{x:1694,y:825,t:1527188844054};\\\", \\\"{x:1693,y:825,t:1527188844075};\\\", \\\"{x:1692,y:825,t:1527188844091};\\\", \\\"{x:1691,y:825,t:1527188844104};\\\", \\\"{x:1690,y:826,t:1527188844121};\\\", \\\"{x:1688,y:826,t:1527188844137};\\\", \\\"{x:1686,y:828,t:1527188844154};\\\", \\\"{x:1685,y:828,t:1527188844171};\\\", \\\"{x:1684,y:828,t:1527188844203};\\\", \\\"{x:1683,y:829,t:1527188844211};\\\", \\\"{x:1676,y:830,t:1527188845300};\\\", \\\"{x:1667,y:832,t:1527188845308};\\\", \\\"{x:1653,y:833,t:1527188845322};\\\", \\\"{x:1598,y:835,t:1527188845339};\\\", \\\"{x:1458,y:841,t:1527188845355};\\\", \\\"{x:1361,y:841,t:1527188845372};\\\", \\\"{x:1264,y:841,t:1527188845389};\\\", \\\"{x:1173,y:841,t:1527188845405};\\\", \\\"{x:1078,y:841,t:1527188845423};\\\", \\\"{x:984,y:841,t:1527188845439};\\\", \\\"{x:904,y:841,t:1527188845456};\\\", \\\"{x:869,y:841,t:1527188845472};\\\", \\\"{x:838,y:841,t:1527188845488};\\\", \\\"{x:796,y:841,t:1527188845506};\\\", \\\"{x:751,y:841,t:1527188845522};\\\", \\\"{x:723,y:839,t:1527188845537};\\\", \\\"{x:693,y:835,t:1527188845555};\\\", \\\"{x:674,y:833,t:1527188845572};\\\", \\\"{x:653,y:829,t:1527188845587};\\\", \\\"{x:634,y:823,t:1527188845605};\\\", \\\"{x:615,y:817,t:1527188845621};\\\", \\\"{x:590,y:811,t:1527188845638};\\\", \\\"{x:566,y:800,t:1527188845655};\\\", \\\"{x:541,y:791,t:1527188845672};\\\", \\\"{x:514,y:778,t:1527188845688};\\\", \\\"{x:479,y:757,t:1527188845705};\\\", \\\"{x:455,y:746,t:1527188845722};\\\", \\\"{x:442,y:739,t:1527188845739};\\\", \\\"{x:427,y:726,t:1527188845755};\\\", \\\"{x:423,y:722,t:1527188845772};\\\", \\\"{x:422,y:722,t:1527188845788};\\\", \\\"{x:422,y:721,t:1527188845805};\\\", \\\"{x:422,y:720,t:1527188845826};\\\", \\\"{x:423,y:718,t:1527188845838};\\\", \\\"{x:425,y:718,t:1527188845856};\\\", \\\"{x:434,y:717,t:1527188845873};\\\", \\\"{x:447,y:715,t:1527188845890};\\\", \\\"{x:464,y:715,t:1527188845905};\\\", \\\"{x:496,y:715,t:1527188845921};\\\", \\\"{x:504,y:717,t:1527188845938};\\\", \\\"{x:522,y:720,t:1527188845955};\\\", \\\"{x:523,y:721,t:1527188850451};\\\", \\\"{x:531,y:724,t:1527188850461};\\\", \\\"{x:559,y:730,t:1527188850477};\\\", \\\"{x:597,y:739,t:1527188850494};\\\", \\\"{x:700,y:763,t:1527188850524};\\\", \\\"{x:725,y:769,t:1527188850530};\\\", \\\"{x:749,y:772,t:1527188850543};\\\", \\\"{x:787,y:780,t:1527188850560};\\\", \\\"{x:825,y:790,t:1527188850576};\\\", \\\"{x:860,y:800,t:1527188850593};\\\", \\\"{x:902,y:812,t:1527188850610};\\\" ] }, { \\\"rt\\\": 110835, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 343571, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O -I -I -I -I -O -O -O -O -I -I -O -O -Z -Z -Z -F -F -2-U -U -H -H -H -01 PM-7-I -I -O -12 PM-01 PM-02 PM-01 PM-02 PM-03 PM-04 PM-2-01 PM-02 PM-03 PM-01 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:994,y:844,t:1527188850719};\\\", \\\"{x:994,y:845,t:1527188850727};\\\", \\\"{x:1000,y:849,t:1527188857124};\\\", \\\"{x:1015,y:855,t:1527188857132};\\\", \\\"{x:1039,y:865,t:1527188857148};\\\", \\\"{x:1069,y:874,t:1527188857166};\\\", \\\"{x:1103,y:884,t:1527188857181};\\\", \\\"{x:1138,y:894,t:1527188857199};\\\", \\\"{x:1156,y:898,t:1527188857215};\\\", \\\"{x:1168,y:899,t:1527188857231};\\\", \\\"{x:1175,y:901,t:1527188857248};\\\", \\\"{x:1183,y:901,t:1527188857266};\\\", \\\"{x:1191,y:903,t:1527188857282};\\\", \\\"{x:1209,y:905,t:1527188857298};\\\", \\\"{x:1224,y:907,t:1527188857319};\\\", \\\"{x:1246,y:907,t:1527188857335};\\\", \\\"{x:1267,y:907,t:1527188857351};\\\", \\\"{x:1286,y:907,t:1527188857369};\\\", \\\"{x:1303,y:907,t:1527188857385};\\\", \\\"{x:1318,y:907,t:1527188857401};\\\", \\\"{x:1332,y:906,t:1527188857419};\\\", \\\"{x:1349,y:901,t:1527188857436};\\\", \\\"{x:1365,y:895,t:1527188857452};\\\", \\\"{x:1376,y:888,t:1527188857469};\\\", \\\"{x:1394,y:874,t:1527188857485};\\\", \\\"{x:1411,y:861,t:1527188857501};\\\", \\\"{x:1429,y:846,t:1527188857519};\\\", \\\"{x:1443,y:835,t:1527188857536};\\\", \\\"{x:1447,y:826,t:1527188857552};\\\", \\\"{x:1448,y:819,t:1527188857569};\\\", \\\"{x:1448,y:816,t:1527188857585};\\\", \\\"{x:1444,y:812,t:1527188857602};\\\", \\\"{x:1440,y:808,t:1527188857618};\\\", \\\"{x:1429,y:805,t:1527188857635};\\\", \\\"{x:1421,y:802,t:1527188857652};\\\", \\\"{x:1420,y:802,t:1527188857669};\\\", \\\"{x:1419,y:802,t:1527188857685};\\\", \\\"{x:1419,y:801,t:1527188858127};\\\", \\\"{x:1419,y:798,t:1527188858136};\\\", \\\"{x:1413,y:788,t:1527188858153};\\\", \\\"{x:1408,y:781,t:1527188858168};\\\", \\\"{x:1405,y:775,t:1527188858186};\\\", \\\"{x:1403,y:770,t:1527188858203};\\\", \\\"{x:1400,y:765,t:1527188858219};\\\", \\\"{x:1399,y:761,t:1527188858235};\\\", \\\"{x:1398,y:758,t:1527188858252};\\\", \\\"{x:1396,y:754,t:1527188858268};\\\", \\\"{x:1396,y:750,t:1527188858286};\\\", \\\"{x:1394,y:747,t:1527188858303};\\\", \\\"{x:1394,y:745,t:1527188858319};\\\", \\\"{x:1394,y:744,t:1527188858336};\\\", \\\"{x:1393,y:743,t:1527188858358};\\\", \\\"{x:1393,y:741,t:1527188858390};\\\", \\\"{x:1393,y:740,t:1527188858414};\\\", \\\"{x:1392,y:739,t:1527188858430};\\\", \\\"{x:1392,y:738,t:1527188858503};\\\", \\\"{x:1390,y:738,t:1527188859126};\\\", \\\"{x:1386,y:732,t:1527188859138};\\\", \\\"{x:1373,y:714,t:1527188859153};\\\", \\\"{x:1362,y:697,t:1527188859171};\\\", \\\"{x:1348,y:676,t:1527188859188};\\\", \\\"{x:1333,y:657,t:1527188859203};\\\", \\\"{x:1323,y:645,t:1527188859220};\\\", \\\"{x:1314,y:632,t:1527188859238};\\\", \\\"{x:1305,y:620,t:1527188859255};\\\", \\\"{x:1300,y:610,t:1527188859270};\\\", \\\"{x:1295,y:602,t:1527188859287};\\\", \\\"{x:1290,y:595,t:1527188859305};\\\", \\\"{x:1285,y:587,t:1527188859320};\\\", \\\"{x:1283,y:582,t:1527188859337};\\\", \\\"{x:1281,y:576,t:1527188859355};\\\", \\\"{x:1281,y:572,t:1527188859370};\\\", \\\"{x:1281,y:564,t:1527188859387};\\\", \\\"{x:1281,y:551,t:1527188859404};\\\", \\\"{x:1281,y:546,t:1527188859420};\\\", \\\"{x:1284,y:538,t:1527188859437};\\\", \\\"{x:1293,y:525,t:1527188859454};\\\", \\\"{x:1299,y:517,t:1527188859470};\\\", \\\"{x:1303,y:512,t:1527188859487};\\\", \\\"{x:1307,y:506,t:1527188859504};\\\", \\\"{x:1310,y:502,t:1527188859519};\\\", \\\"{x:1313,y:497,t:1527188859537};\\\", \\\"{x:1315,y:493,t:1527188859554};\\\", \\\"{x:1315,y:491,t:1527188859570};\\\", \\\"{x:1317,y:487,t:1527188859587};\\\", \\\"{x:1318,y:486,t:1527188859604};\\\", \\\"{x:1320,y:484,t:1527188859620};\\\", \\\"{x:1319,y:484,t:1527188859751};\\\", \\\"{x:1317,y:485,t:1527188859766};\\\", \\\"{x:1316,y:485,t:1527188859782};\\\", \\\"{x:1315,y:486,t:1527188859822};\\\", \\\"{x:1314,y:486,t:1527188859838};\\\", \\\"{x:1313,y:487,t:1527188859855};\\\", \\\"{x:1312,y:487,t:1527188859878};\\\", \\\"{x:1311,y:487,t:1527188859894};\\\", \\\"{x:1311,y:488,t:1527188859904};\\\", \\\"{x:1310,y:489,t:1527188859926};\\\", \\\"{x:1310,y:490,t:1527188859959};\\\", \\\"{x:1310,y:491,t:1527188859971};\\\", \\\"{x:1310,y:492,t:1527188859991};\\\", \\\"{x:1310,y:493,t:1527188860005};\\\", \\\"{x:1310,y:494,t:1527188860021};\\\", \\\"{x:1310,y:495,t:1527188860037};\\\", \\\"{x:1311,y:496,t:1527188860054};\\\", \\\"{x:1312,y:497,t:1527188860071};\\\", \\\"{x:1312,y:498,t:1527188860094};\\\", \\\"{x:1313,y:499,t:1527188860430};\\\", \\\"{x:1314,y:499,t:1527188860446};\\\", \\\"{x:1315,y:500,t:1527188860454};\\\", \\\"{x:1316,y:500,t:1527188860471};\\\", \\\"{x:1318,y:501,t:1527188860489};\\\", \\\"{x:1319,y:502,t:1527188860505};\\\", \\\"{x:1320,y:503,t:1527188860526};\\\", \\\"{x:1319,y:503,t:1527188861743};\\\", \\\"{x:1318,y:503,t:1527188861755};\\\", \\\"{x:1317,y:502,t:1527188861772};\\\", \\\"{x:1316,y:501,t:1527188861790};\\\", \\\"{x:1316,y:503,t:1527188861936};\\\", \\\"{x:1316,y:504,t:1527188861942};\\\", \\\"{x:1314,y:508,t:1527188861956};\\\", \\\"{x:1314,y:511,t:1527188861972};\\\", \\\"{x:1314,y:515,t:1527188861989};\\\", \\\"{x:1314,y:525,t:1527188862006};\\\", \\\"{x:1314,y:529,t:1527188862023};\\\", \\\"{x:1314,y:533,t:1527188862040};\\\", \\\"{x:1313,y:535,t:1527188862056};\\\", \\\"{x:1313,y:537,t:1527188862072};\\\", \\\"{x:1313,y:540,t:1527188862090};\\\", \\\"{x:1313,y:544,t:1527188862106};\\\", \\\"{x:1313,y:552,t:1527188862122};\\\", \\\"{x:1313,y:563,t:1527188862139};\\\", \\\"{x:1313,y:573,t:1527188862156};\\\", \\\"{x:1313,y:581,t:1527188862172};\\\", \\\"{x:1313,y:589,t:1527188862189};\\\", \\\"{x:1313,y:596,t:1527188862206};\\\", \\\"{x:1313,y:599,t:1527188862222};\\\", \\\"{x:1313,y:606,t:1527188862239};\\\", \\\"{x:1313,y:612,t:1527188862256};\\\", \\\"{x:1313,y:616,t:1527188862272};\\\", \\\"{x:1313,y:619,t:1527188862289};\\\", \\\"{x:1313,y:621,t:1527188862306};\\\", \\\"{x:1313,y:625,t:1527188862324};\\\", \\\"{x:1313,y:627,t:1527188862339};\\\", \\\"{x:1313,y:629,t:1527188862357};\\\", \\\"{x:1313,y:632,t:1527188862373};\\\", \\\"{x:1313,y:633,t:1527188862389};\\\", \\\"{x:1313,y:634,t:1527188862406};\\\", \\\"{x:1313,y:635,t:1527188862423};\\\", \\\"{x:1313,y:638,t:1527188862440};\\\", \\\"{x:1313,y:642,t:1527188862457};\\\", \\\"{x:1313,y:646,t:1527188862473};\\\", \\\"{x:1313,y:650,t:1527188862490};\\\", \\\"{x:1313,y:652,t:1527188862507};\\\", \\\"{x:1313,y:658,t:1527188862524};\\\", \\\"{x:1313,y:665,t:1527188862539};\\\", \\\"{x:1313,y:673,t:1527188862556};\\\", \\\"{x:1313,y:680,t:1527188862573};\\\", \\\"{x:1313,y:689,t:1527188862588};\\\", \\\"{x:1313,y:705,t:1527188862606};\\\", \\\"{x:1312,y:717,t:1527188862623};\\\", \\\"{x:1310,y:726,t:1527188862639};\\\", \\\"{x:1309,y:739,t:1527188862656};\\\", \\\"{x:1306,y:755,t:1527188862673};\\\", \\\"{x:1304,y:765,t:1527188862689};\\\", \\\"{x:1302,y:773,t:1527188862706};\\\", \\\"{x:1302,y:777,t:1527188862723};\\\", \\\"{x:1302,y:783,t:1527188862739};\\\", \\\"{x:1302,y:789,t:1527188862756};\\\", \\\"{x:1302,y:793,t:1527188862773};\\\", \\\"{x:1302,y:802,t:1527188862789};\\\", \\\"{x:1302,y:809,t:1527188862806};\\\", \\\"{x:1303,y:815,t:1527188862823};\\\", \\\"{x:1306,y:824,t:1527188862840};\\\", \\\"{x:1308,y:829,t:1527188862856};\\\", \\\"{x:1309,y:833,t:1527188862873};\\\", \\\"{x:1310,y:839,t:1527188862890};\\\", \\\"{x:1313,y:847,t:1527188862906};\\\", \\\"{x:1315,y:853,t:1527188862923};\\\", \\\"{x:1315,y:859,t:1527188862941};\\\", \\\"{x:1316,y:865,t:1527188862956};\\\", \\\"{x:1318,y:878,t:1527188862974};\\\", \\\"{x:1323,y:901,t:1527188862990};\\\", \\\"{x:1326,y:910,t:1527188863007};\\\", \\\"{x:1329,y:918,t:1527188863024};\\\", \\\"{x:1329,y:922,t:1527188863041};\\\", \\\"{x:1330,y:925,t:1527188863056};\\\", \\\"{x:1330,y:927,t:1527188863074};\\\", \\\"{x:1330,y:928,t:1527188863090};\\\", \\\"{x:1330,y:930,t:1527188863107};\\\", \\\"{x:1330,y:933,t:1527188863123};\\\", \\\"{x:1330,y:938,t:1527188863140};\\\", \\\"{x:1330,y:941,t:1527188863157};\\\", \\\"{x:1330,y:943,t:1527188863174};\\\", \\\"{x:1330,y:946,t:1527188863190};\\\", \\\"{x:1330,y:948,t:1527188863208};\\\", \\\"{x:1330,y:951,t:1527188863224};\\\", \\\"{x:1329,y:954,t:1527188863240};\\\", \\\"{x:1327,y:956,t:1527188863258};\\\", \\\"{x:1326,y:960,t:1527188863273};\\\", \\\"{x:1326,y:962,t:1527188863290};\\\", \\\"{x:1324,y:966,t:1527188863308};\\\", \\\"{x:1324,y:968,t:1527188863323};\\\", \\\"{x:1324,y:969,t:1527188863340};\\\", \\\"{x:1322,y:972,t:1527188863357};\\\", \\\"{x:1321,y:974,t:1527188863372};\\\", \\\"{x:1320,y:976,t:1527188863390};\\\", \\\"{x:1319,y:978,t:1527188863414};\\\", \\\"{x:1318,y:978,t:1527188863486};\\\", \\\"{x:1317,y:978,t:1527188863494};\\\", \\\"{x:1317,y:977,t:1527188863518};\\\", \\\"{x:1317,y:976,t:1527188863534};\\\", \\\"{x:1317,y:974,t:1527188863550};\\\", \\\"{x:1317,y:973,t:1527188863566};\\\", \\\"{x:1316,y:973,t:1527188863574};\\\", \\\"{x:1316,y:972,t:1527188863591};\\\", \\\"{x:1316,y:970,t:1527188863607};\\\", \\\"{x:1316,y:969,t:1527188863624};\\\", \\\"{x:1316,y:968,t:1527188863640};\\\", \\\"{x:1316,y:966,t:1527188863657};\\\", \\\"{x:1316,y:965,t:1527188863687};\\\", \\\"{x:1316,y:964,t:1527188863694};\\\", \\\"{x:1316,y:963,t:1527188863718};\\\", \\\"{x:1316,y:962,t:1527188863759};\\\", \\\"{x:1316,y:961,t:1527188863790};\\\", \\\"{x:1316,y:960,t:1527188863870};\\\", \\\"{x:1316,y:959,t:1527188863886};\\\", \\\"{x:1316,y:958,t:1527188863894};\\\", \\\"{x:1316,y:957,t:1527188863908};\\\", \\\"{x:1315,y:954,t:1527188863924};\\\", \\\"{x:1315,y:952,t:1527188863940};\\\", \\\"{x:1314,y:951,t:1527188863957};\\\", \\\"{x:1314,y:947,t:1527188863974};\\\", \\\"{x:1314,y:942,t:1527188863991};\\\", \\\"{x:1314,y:937,t:1527188864008};\\\", \\\"{x:1314,y:930,t:1527188864025};\\\", \\\"{x:1314,y:925,t:1527188864041};\\\", \\\"{x:1314,y:914,t:1527188864057};\\\", \\\"{x:1314,y:892,t:1527188864075};\\\", \\\"{x:1314,y:870,t:1527188864090};\\\", \\\"{x:1314,y:851,t:1527188864108};\\\", \\\"{x:1314,y:829,t:1527188864125};\\\", \\\"{x:1314,y:804,t:1527188864141};\\\", \\\"{x:1314,y:779,t:1527188864158};\\\", \\\"{x:1314,y:747,t:1527188864174};\\\", \\\"{x:1314,y:731,t:1527188864192};\\\", \\\"{x:1314,y:711,t:1527188864208};\\\", \\\"{x:1313,y:689,t:1527188864225};\\\", \\\"{x:1313,y:669,t:1527188864242};\\\", \\\"{x:1313,y:654,t:1527188864258};\\\", \\\"{x:1313,y:642,t:1527188864275};\\\", \\\"{x:1313,y:630,t:1527188864292};\\\", \\\"{x:1313,y:615,t:1527188864309};\\\", \\\"{x:1312,y:601,t:1527188864326};\\\", \\\"{x:1310,y:591,t:1527188864342};\\\", \\\"{x:1309,y:578,t:1527188864358};\\\", \\\"{x:1308,y:569,t:1527188864374};\\\", \\\"{x:1308,y:559,t:1527188864392};\\\", \\\"{x:1306,y:549,t:1527188864408};\\\", \\\"{x:1302,y:539,t:1527188864424};\\\", \\\"{x:1300,y:533,t:1527188864442};\\\", \\\"{x:1297,y:525,t:1527188864458};\\\", \\\"{x:1294,y:516,t:1527188864474};\\\", \\\"{x:1292,y:509,t:1527188864492};\\\", \\\"{x:1292,y:508,t:1527188864507};\\\", \\\"{x:1292,y:505,t:1527188864525};\\\", \\\"{x:1292,y:501,t:1527188864541};\\\", \\\"{x:1293,y:499,t:1527188864558};\\\", \\\"{x:1293,y:498,t:1527188864574};\\\", \\\"{x:1294,y:496,t:1527188864591};\\\", \\\"{x:1295,y:495,t:1527188864629};\\\", \\\"{x:1296,y:494,t:1527188864641};\\\", \\\"{x:1298,y:493,t:1527188864658};\\\", \\\"{x:1303,y:492,t:1527188864675};\\\", \\\"{x:1305,y:491,t:1527188864692};\\\", \\\"{x:1306,y:491,t:1527188864725};\\\", \\\"{x:1308,y:491,t:1527188864750};\\\", \\\"{x:1309,y:491,t:1527188864766};\\\", \\\"{x:1311,y:491,t:1527188864783};\\\", \\\"{x:1312,y:491,t:1527188864806};\\\", \\\"{x:1314,y:491,t:1527188864823};\\\", \\\"{x:1315,y:491,t:1527188864842};\\\", \\\"{x:1316,y:492,t:1527188864934};\\\", \\\"{x:1317,y:493,t:1527188864958};\\\", \\\"{x:1318,y:493,t:1527188864999};\\\", \\\"{x:1318,y:494,t:1527188866582};\\\", \\\"{x:1318,y:495,t:1527188866593};\\\", \\\"{x:1318,y:496,t:1527188866614};\\\", \\\"{x:1317,y:496,t:1527188866627};\\\", \\\"{x:1316,y:497,t:1527188871654};\\\", \\\"{x:1316,y:498,t:1527188871670};\\\", \\\"{x:1315,y:498,t:1527188871702};\\\", \\\"{x:1314,y:498,t:1527188871713};\\\", \\\"{x:1314,y:499,t:1527188884062};\\\", \\\"{x:1314,y:500,t:1527188884073};\\\", \\\"{x:1314,y:503,t:1527188884090};\\\", \\\"{x:1314,y:505,t:1527188884106};\\\", \\\"{x:1314,y:506,t:1527188884125};\\\", \\\"{x:1315,y:506,t:1527188884140};\\\", \\\"{x:1315,y:508,t:1527188884164};\\\", \\\"{x:1315,y:510,t:1527188884181};\\\", \\\"{x:1315,y:512,t:1527188884190};\\\", \\\"{x:1315,y:516,t:1527188884207};\\\", \\\"{x:1316,y:522,t:1527188884223};\\\", \\\"{x:1319,y:534,t:1527188884240};\\\", \\\"{x:1321,y:543,t:1527188884257};\\\", \\\"{x:1326,y:560,t:1527188884273};\\\", \\\"{x:1333,y:580,t:1527188884290};\\\", \\\"{x:1343,y:604,t:1527188884307};\\\", \\\"{x:1356,y:637,t:1527188884323};\\\", \\\"{x:1365,y:659,t:1527188884340};\\\", \\\"{x:1378,y:699,t:1527188884357};\\\", \\\"{x:1393,y:755,t:1527188884373};\\\", \\\"{x:1402,y:800,t:1527188884390};\\\", \\\"{x:1409,y:827,t:1527188884407};\\\", \\\"{x:1414,y:846,t:1527188884424};\\\", \\\"{x:1418,y:861,t:1527188884440};\\\", \\\"{x:1419,y:868,t:1527188884457};\\\", \\\"{x:1420,y:873,t:1527188884474};\\\", \\\"{x:1420,y:877,t:1527188884490};\\\", \\\"{x:1420,y:881,t:1527188884507};\\\", \\\"{x:1420,y:882,t:1527188884525};\\\", \\\"{x:1420,y:883,t:1527188884598};\\\", \\\"{x:1419,y:883,t:1527188884615};\\\", \\\"{x:1416,y:883,t:1527188884625};\\\", \\\"{x:1408,y:877,t:1527188884641};\\\", \\\"{x:1399,y:867,t:1527188884657};\\\", \\\"{x:1385,y:852,t:1527188884674};\\\", \\\"{x:1376,y:838,t:1527188884690};\\\", \\\"{x:1364,y:819,t:1527188884707};\\\", \\\"{x:1351,y:796,t:1527188884725};\\\", \\\"{x:1343,y:774,t:1527188884740};\\\", \\\"{x:1336,y:752,t:1527188884757};\\\", \\\"{x:1326,y:723,t:1527188884774};\\\", \\\"{x:1320,y:698,t:1527188884791};\\\", \\\"{x:1315,y:673,t:1527188884807};\\\", \\\"{x:1311,y:653,t:1527188884825};\\\", \\\"{x:1311,y:644,t:1527188884841};\\\", \\\"{x:1311,y:629,t:1527188884858};\\\", \\\"{x:1312,y:609,t:1527188884875};\\\", \\\"{x:1313,y:597,t:1527188884891};\\\", \\\"{x:1314,y:589,t:1527188884907};\\\", \\\"{x:1316,y:584,t:1527188884925};\\\", \\\"{x:1317,y:578,t:1527188884941};\\\", \\\"{x:1318,y:572,t:1527188884958};\\\", \\\"{x:1319,y:567,t:1527188884974};\\\", \\\"{x:1320,y:563,t:1527188884992};\\\", \\\"{x:1321,y:556,t:1527188885008};\\\", \\\"{x:1321,y:553,t:1527188885024};\\\", \\\"{x:1321,y:552,t:1527188885042};\\\", \\\"{x:1322,y:549,t:1527188885057};\\\", \\\"{x:1322,y:548,t:1527188885078};\\\", \\\"{x:1322,y:546,t:1527188885091};\\\", \\\"{x:1320,y:545,t:1527188885107};\\\", \\\"{x:1316,y:542,t:1527188885124};\\\", \\\"{x:1313,y:540,t:1527188885142};\\\", \\\"{x:1313,y:539,t:1527188885157};\\\", \\\"{x:1311,y:539,t:1527188885174};\\\", \\\"{x:1310,y:538,t:1527188885191};\\\", \\\"{x:1310,y:536,t:1527188885207};\\\", \\\"{x:1309,y:536,t:1527188885224};\\\", \\\"{x:1309,y:534,t:1527188885241};\\\", \\\"{x:1308,y:532,t:1527188885258};\\\", \\\"{x:1308,y:531,t:1527188885275};\\\", \\\"{x:1308,y:530,t:1527188885291};\\\", \\\"{x:1308,y:529,t:1527188885308};\\\", \\\"{x:1308,y:528,t:1527188885326};\\\", \\\"{x:1308,y:530,t:1527188885662};\\\", \\\"{x:1309,y:535,t:1527188885674};\\\", \\\"{x:1312,y:542,t:1527188885692};\\\", \\\"{x:1313,y:549,t:1527188885709};\\\", \\\"{x:1316,y:556,t:1527188885725};\\\", \\\"{x:1319,y:569,t:1527188885742};\\\", \\\"{x:1322,y:577,t:1527188885758};\\\", \\\"{x:1325,y:586,t:1527188885775};\\\", \\\"{x:1326,y:590,t:1527188885791};\\\", \\\"{x:1329,y:596,t:1527188885808};\\\", \\\"{x:1330,y:601,t:1527188885825};\\\", \\\"{x:1330,y:604,t:1527188885841};\\\", \\\"{x:1332,y:607,t:1527188885858};\\\", \\\"{x:1332,y:608,t:1527188885876};\\\", \\\"{x:1333,y:610,t:1527188885892};\\\", \\\"{x:1333,y:611,t:1527188885909};\\\", \\\"{x:1333,y:614,t:1527188885925};\\\", \\\"{x:1333,y:615,t:1527188885942};\\\", \\\"{x:1333,y:617,t:1527188885958};\\\", \\\"{x:1333,y:618,t:1527188885982};\\\", \\\"{x:1333,y:619,t:1527188885991};\\\", \\\"{x:1333,y:620,t:1527188886008};\\\", \\\"{x:1332,y:623,t:1527188886025};\\\", \\\"{x:1329,y:626,t:1527188886042};\\\", \\\"{x:1326,y:628,t:1527188886059};\\\", \\\"{x:1324,y:629,t:1527188886076};\\\", \\\"{x:1322,y:630,t:1527188886092};\\\", \\\"{x:1320,y:631,t:1527188886108};\\\", \\\"{x:1319,y:631,t:1527188886125};\\\", \\\"{x:1318,y:631,t:1527188886165};\\\", \\\"{x:1316,y:632,t:1527188886181};\\\", \\\"{x:1315,y:633,t:1527188886205};\\\", \\\"{x:1314,y:633,t:1527188886221};\\\", \\\"{x:1313,y:633,t:1527188886245};\\\", \\\"{x:1313,y:634,t:1527188886727};\\\", \\\"{x:1314,y:634,t:1527188887222};\\\", \\\"{x:1315,y:634,t:1527188887238};\\\", \\\"{x:1317,y:633,t:1527188887318};\\\", \\\"{x:1320,y:633,t:1527188887327};\\\", \\\"{x:1334,y:638,t:1527188887343};\\\", \\\"{x:1345,y:648,t:1527188887360};\\\", \\\"{x:1360,y:659,t:1527188887377};\\\", \\\"{x:1373,y:670,t:1527188887393};\\\", \\\"{x:1384,y:680,t:1527188887410};\\\", \\\"{x:1392,y:691,t:1527188887426};\\\", \\\"{x:1394,y:700,t:1527188887442};\\\", \\\"{x:1399,y:711,t:1527188887459};\\\", \\\"{x:1401,y:721,t:1527188887477};\\\", \\\"{x:1405,y:733,t:1527188887492};\\\", \\\"{x:1406,y:743,t:1527188887510};\\\", \\\"{x:1406,y:752,t:1527188887527};\\\", \\\"{x:1406,y:760,t:1527188887542};\\\", \\\"{x:1404,y:770,t:1527188887560};\\\", \\\"{x:1398,y:785,t:1527188887577};\\\", \\\"{x:1391,y:795,t:1527188887594};\\\", \\\"{x:1389,y:800,t:1527188887610};\\\", \\\"{x:1386,y:803,t:1527188887627};\\\", \\\"{x:1384,y:807,t:1527188887644};\\\", \\\"{x:1380,y:812,t:1527188887660};\\\", \\\"{x:1377,y:817,t:1527188887676};\\\", \\\"{x:1371,y:823,t:1527188887694};\\\", \\\"{x:1370,y:826,t:1527188887710};\\\", \\\"{x:1367,y:831,t:1527188887727};\\\", \\\"{x:1363,y:838,t:1527188887744};\\\", \\\"{x:1359,y:846,t:1527188887760};\\\", \\\"{x:1354,y:856,t:1527188887777};\\\", \\\"{x:1352,y:861,t:1527188887794};\\\", \\\"{x:1350,y:869,t:1527188887810};\\\", \\\"{x:1349,y:875,t:1527188887827};\\\", \\\"{x:1348,y:878,t:1527188887844};\\\", \\\"{x:1348,y:883,t:1527188887860};\\\", \\\"{x:1348,y:887,t:1527188887877};\\\", \\\"{x:1348,y:891,t:1527188887894};\\\", \\\"{x:1347,y:894,t:1527188887911};\\\", \\\"{x:1346,y:896,t:1527188887927};\\\", \\\"{x:1346,y:897,t:1527188887944};\\\", \\\"{x:1346,y:898,t:1527188887960};\\\", \\\"{x:1346,y:899,t:1527188887977};\\\", \\\"{x:1346,y:900,t:1527188887993};\\\", \\\"{x:1346,y:902,t:1527188888030};\\\", \\\"{x:1346,y:903,t:1527188888055};\\\", \\\"{x:1346,y:904,t:1527188888086};\\\", \\\"{x:1347,y:905,t:1527188888094};\\\", \\\"{x:1347,y:904,t:1527188888318};\\\", \\\"{x:1347,y:902,t:1527188888494};\\\", \\\"{x:1347,y:901,t:1527188888527};\\\", \\\"{x:1347,y:900,t:1527188888558};\\\", \\\"{x:1347,y:899,t:1527188888574};\\\", \\\"{x:1347,y:898,t:1527188889494};\\\", \\\"{x:1348,y:898,t:1527188889750};\\\", \\\"{x:1348,y:897,t:1527188889761};\\\", \\\"{x:1349,y:897,t:1527188889779};\\\", \\\"{x:1352,y:897,t:1527188889795};\\\", \\\"{x:1355,y:897,t:1527188889813};\\\", \\\"{x:1356,y:897,t:1527188889829};\\\", \\\"{x:1358,y:897,t:1527188889845};\\\", \\\"{x:1361,y:897,t:1527188889862};\\\", \\\"{x:1362,y:897,t:1527188889878};\\\", \\\"{x:1364,y:897,t:1527188889895};\\\", \\\"{x:1366,y:897,t:1527188889912};\\\", \\\"{x:1368,y:897,t:1527188889929};\\\", \\\"{x:1371,y:897,t:1527188889945};\\\", \\\"{x:1375,y:897,t:1527188889962};\\\", \\\"{x:1379,y:897,t:1527188889979};\\\", \\\"{x:1383,y:897,t:1527188889996};\\\", \\\"{x:1385,y:897,t:1527188890012};\\\", \\\"{x:1386,y:897,t:1527188890029};\\\", \\\"{x:1387,y:897,t:1527188890054};\\\", \\\"{x:1388,y:897,t:1527188890062};\\\", \\\"{x:1389,y:897,t:1527188890102};\\\", \\\"{x:1390,y:897,t:1527188890134};\\\", \\\"{x:1390,y:898,t:1527188890279};\\\", \\\"{x:1390,y:900,t:1527188890296};\\\", \\\"{x:1390,y:901,t:1527188890351};\\\", \\\"{x:1389,y:901,t:1527188890511};\\\", \\\"{x:1389,y:900,t:1527188890518};\\\", \\\"{x:1388,y:899,t:1527188890532};\\\", \\\"{x:1387,y:892,t:1527188890545};\\\", \\\"{x:1385,y:884,t:1527188890561};\\\", \\\"{x:1384,y:874,t:1527188890579};\\\", \\\"{x:1383,y:860,t:1527188890595};\\\", \\\"{x:1383,y:845,t:1527188890612};\\\", \\\"{x:1383,y:834,t:1527188890629};\\\", \\\"{x:1383,y:811,t:1527188890645};\\\", \\\"{x:1383,y:805,t:1527188890662};\\\", \\\"{x:1383,y:799,t:1527188890678};\\\", \\\"{x:1383,y:796,t:1527188890695};\\\", \\\"{x:1383,y:792,t:1527188890712};\\\", \\\"{x:1382,y:789,t:1527188890728};\\\", \\\"{x:1382,y:785,t:1527188890746};\\\", \\\"{x:1382,y:782,t:1527188890763};\\\", \\\"{x:1382,y:777,t:1527188890778};\\\", \\\"{x:1380,y:773,t:1527188890796};\\\", \\\"{x:1380,y:771,t:1527188890813};\\\", \\\"{x:1380,y:768,t:1527188890829};\\\", \\\"{x:1379,y:765,t:1527188890846};\\\", \\\"{x:1378,y:763,t:1527188890862};\\\", \\\"{x:1377,y:762,t:1527188890878};\\\", \\\"{x:1377,y:761,t:1527188890918};\\\", \\\"{x:1377,y:760,t:1527188891110};\\\", \\\"{x:1378,y:760,t:1527188891126};\\\", \\\"{x:1379,y:760,t:1527188891141};\\\", \\\"{x:1380,y:760,t:1527188891318};\\\", \\\"{x:1381,y:760,t:1527188891350};\\\", \\\"{x:1382,y:761,t:1527188898726};\\\", \\\"{x:1384,y:764,t:1527188898741};\\\", \\\"{x:1384,y:765,t:1527188898933};\\\", \\\"{x:1385,y:766,t:1527188898941};\\\", \\\"{x:1385,y:767,t:1527188898957};\\\", \\\"{x:1386,y:768,t:1527188898969};\\\", \\\"{x:1387,y:769,t:1527188898989};\\\", \\\"{x:1387,y:770,t:1527188899002};\\\", \\\"{x:1387,y:771,t:1527188899045};\\\", \\\"{x:1387,y:772,t:1527188899053};\\\", \\\"{x:1387,y:773,t:1527188899077};\\\", \\\"{x:1387,y:772,t:1527188899662};\\\", \\\"{x:1387,y:771,t:1527188899670};\\\", \\\"{x:1387,y:769,t:1527188899686};\\\", \\\"{x:1386,y:768,t:1527188899704};\\\", \\\"{x:1386,y:767,t:1527188899719};\\\", \\\"{x:1384,y:766,t:1527188900063};\\\", \\\"{x:1376,y:764,t:1527188900069};\\\", \\\"{x:1341,y:758,t:1527188900088};\\\", \\\"{x:1280,y:749,t:1527188900103};\\\", \\\"{x:1183,y:735,t:1527188900121};\\\", \\\"{x:1074,y:715,t:1527188900136};\\\", \\\"{x:973,y:693,t:1527188900154};\\\", \\\"{x:887,y:666,t:1527188900170};\\\", \\\"{x:815,y:649,t:1527188900187};\\\", \\\"{x:766,y:631,t:1527188900203};\\\", \\\"{x:717,y:612,t:1527188900222};\\\", \\\"{x:687,y:602,t:1527188900236};\\\", \\\"{x:664,y:592,t:1527188900253};\\\", \\\"{x:646,y:583,t:1527188900263};\\\", \\\"{x:617,y:574,t:1527188900280};\\\", \\\"{x:587,y:566,t:1527188900297};\\\", \\\"{x:542,y:557,t:1527188900320};\\\", \\\"{x:505,y:552,t:1527188900337};\\\", \\\"{x:468,y:551,t:1527188900354};\\\", \\\"{x:436,y:550,t:1527188900371};\\\", \\\"{x:415,y:550,t:1527188900387};\\\", \\\"{x:400,y:550,t:1527188900404};\\\", \\\"{x:386,y:550,t:1527188900420};\\\", \\\"{x:376,y:550,t:1527188900437};\\\", \\\"{x:368,y:550,t:1527188900452};\\\", \\\"{x:366,y:551,t:1527188900470};\\\", \\\"{x:365,y:553,t:1527188900487};\\\", \\\"{x:363,y:554,t:1527188900504};\\\", \\\"{x:360,y:556,t:1527188900521};\\\", \\\"{x:359,y:558,t:1527188900537};\\\", \\\"{x:358,y:559,t:1527188900573};\\\", \\\"{x:358,y:560,t:1527188900589};\\\", \\\"{x:358,y:561,t:1527188900604};\\\", \\\"{x:360,y:565,t:1527188900620};\\\", \\\"{x:366,y:565,t:1527188900637};\\\", \\\"{x:373,y:568,t:1527188900653};\\\", \\\"{x:379,y:569,t:1527188900671};\\\", \\\"{x:388,y:569,t:1527188900687};\\\", \\\"{x:395,y:570,t:1527188900703};\\\", \\\"{x:399,y:570,t:1527188900721};\\\", \\\"{x:400,y:571,t:1527188900737};\\\", \\\"{x:409,y:574,t:1527188901478};\\\", \\\"{x:432,y:580,t:1527188901489};\\\", \\\"{x:486,y:596,t:1527188901505};\\\", \\\"{x:555,y:615,t:1527188901521};\\\", \\\"{x:633,y:637,t:1527188901538};\\\", \\\"{x:719,y:662,t:1527188901555};\\\", \\\"{x:816,y:692,t:1527188901571};\\\", \\\"{x:906,y:725,t:1527188901587};\\\", \\\"{x:1017,y:768,t:1527188901605};\\\", \\\"{x:1067,y:790,t:1527188901620};\\\", \\\"{x:1094,y:804,t:1527188901637};\\\", \\\"{x:1108,y:814,t:1527188901655};\\\", \\\"{x:1115,y:822,t:1527188901671};\\\", \\\"{x:1118,y:826,t:1527188901688};\\\", \\\"{x:1121,y:829,t:1527188901705};\\\", \\\"{x:1122,y:831,t:1527188901721};\\\", \\\"{x:1122,y:832,t:1527188901738};\\\", \\\"{x:1125,y:835,t:1527188901755};\\\", \\\"{x:1128,y:839,t:1527188901771};\\\", \\\"{x:1131,y:843,t:1527188901788};\\\", \\\"{x:1138,y:848,t:1527188901805};\\\", \\\"{x:1142,y:849,t:1527188901822};\\\", \\\"{x:1161,y:856,t:1527188901838};\\\", \\\"{x:1179,y:862,t:1527188901855};\\\", \\\"{x:1195,y:864,t:1527188901871};\\\", \\\"{x:1213,y:867,t:1527188901888};\\\", \\\"{x:1235,y:870,t:1527188901905};\\\", \\\"{x:1256,y:874,t:1527188901921};\\\", \\\"{x:1278,y:876,t:1527188901938};\\\", \\\"{x:1299,y:880,t:1527188901955};\\\", \\\"{x:1317,y:883,t:1527188901972};\\\", \\\"{x:1332,y:886,t:1527188901988};\\\", \\\"{x:1342,y:886,t:1527188902005};\\\", \\\"{x:1353,y:888,t:1527188902021};\\\", \\\"{x:1355,y:889,t:1527188902038};\\\", \\\"{x:1357,y:889,t:1527188902221};\\\", \\\"{x:1358,y:889,t:1527188902326};\\\", \\\"{x:1359,y:889,t:1527188902350};\\\", \\\"{x:1360,y:889,t:1527188902366};\\\", \\\"{x:1361,y:889,t:1527188902486};\\\", \\\"{x:1361,y:888,t:1527188902494};\\\", \\\"{x:1363,y:888,t:1527188902506};\\\", \\\"{x:1365,y:886,t:1527188902523};\\\", \\\"{x:1367,y:886,t:1527188902539};\\\", \\\"{x:1370,y:886,t:1527188902555};\\\", \\\"{x:1374,y:886,t:1527188902572};\\\", \\\"{x:1378,y:886,t:1527188902588};\\\", \\\"{x:1381,y:886,t:1527188902605};\\\", \\\"{x:1382,y:886,t:1527188902622};\\\", \\\"{x:1384,y:886,t:1527188902639};\\\", \\\"{x:1385,y:886,t:1527188902656};\\\", \\\"{x:1389,y:886,t:1527188902672};\\\", \\\"{x:1392,y:886,t:1527188902689};\\\", \\\"{x:1395,y:886,t:1527188902706};\\\", \\\"{x:1397,y:886,t:1527188902723};\\\", \\\"{x:1398,y:885,t:1527188902739};\\\", \\\"{x:1402,y:883,t:1527188902755};\\\", \\\"{x:1404,y:882,t:1527188902773};\\\", \\\"{x:1405,y:881,t:1527188902788};\\\", \\\"{x:1406,y:879,t:1527188902805};\\\", \\\"{x:1407,y:879,t:1527188902822};\\\", \\\"{x:1408,y:877,t:1527188902870};\\\", \\\"{x:1410,y:876,t:1527188903157};\\\", \\\"{x:1411,y:874,t:1527188903172};\\\", \\\"{x:1412,y:872,t:1527188903188};\\\", \\\"{x:1415,y:869,t:1527188903205};\\\", \\\"{x:1416,y:868,t:1527188903223};\\\", \\\"{x:1417,y:868,t:1527188903245};\\\", \\\"{x:1418,y:868,t:1527188903407};\\\", \\\"{x:1419,y:868,t:1527188903422};\\\", \\\"{x:1420,y:868,t:1527188903446};\\\", \\\"{x:1421,y:868,t:1527188903470};\\\", \\\"{x:1422,y:868,t:1527188903478};\\\", \\\"{x:1424,y:868,t:1527188903488};\\\", \\\"{x:1428,y:869,t:1527188903506};\\\", \\\"{x:1432,y:871,t:1527188903523};\\\", \\\"{x:1437,y:873,t:1527188903539};\\\", \\\"{x:1442,y:874,t:1527188903556};\\\", \\\"{x:1452,y:877,t:1527188903572};\\\", \\\"{x:1459,y:878,t:1527188903589};\\\", \\\"{x:1462,y:879,t:1527188903605};\\\", \\\"{x:1464,y:879,t:1527188903623};\\\", \\\"{x:1466,y:879,t:1527188903640};\\\", \\\"{x:1469,y:879,t:1527188903655};\\\", \\\"{x:1472,y:879,t:1527188903673};\\\", \\\"{x:1477,y:878,t:1527188903690};\\\", \\\"{x:1483,y:876,t:1527188903706};\\\", \\\"{x:1493,y:871,t:1527188903722};\\\", \\\"{x:1506,y:865,t:1527188903740};\\\", \\\"{x:1510,y:863,t:1527188903755};\\\", \\\"{x:1514,y:859,t:1527188903773};\\\", \\\"{x:1516,y:857,t:1527188903790};\\\", \\\"{x:1517,y:854,t:1527188903806};\\\", \\\"{x:1517,y:851,t:1527188903822};\\\", \\\"{x:1517,y:847,t:1527188903840};\\\", \\\"{x:1517,y:843,t:1527188903856};\\\", \\\"{x:1511,y:832,t:1527188903873};\\\", \\\"{x:1506,y:824,t:1527188903890};\\\", \\\"{x:1501,y:818,t:1527188903906};\\\", \\\"{x:1498,y:814,t:1527188903923};\\\", \\\"{x:1494,y:811,t:1527188903939};\\\", \\\"{x:1490,y:808,t:1527188903955};\\\", \\\"{x:1488,y:807,t:1527188903972};\\\", \\\"{x:1487,y:807,t:1527188904045};\\\", \\\"{x:1485,y:807,t:1527188904126};\\\", \\\"{x:1484,y:807,t:1527188904158};\\\", \\\"{x:1482,y:807,t:1527188904174};\\\", \\\"{x:1480,y:807,t:1527188904190};\\\", \\\"{x:1478,y:808,t:1527188904205};\\\", \\\"{x:1475,y:809,t:1527188904223};\\\", \\\"{x:1474,y:810,t:1527188904240};\\\", \\\"{x:1474,y:811,t:1527188904256};\\\", \\\"{x:1473,y:812,t:1527188904294};\\\", \\\"{x:1473,y:813,t:1527188904311};\\\", \\\"{x:1473,y:814,t:1527188904334};\\\", \\\"{x:1473,y:815,t:1527188904358};\\\", \\\"{x:1472,y:816,t:1527188904391};\\\", \\\"{x:1472,y:817,t:1527188904446};\\\", \\\"{x:1472,y:818,t:1527188904510};\\\", \\\"{x:1472,y:819,t:1527188904523};\\\", \\\"{x:1472,y:820,t:1527188904540};\\\", \\\"{x:1472,y:821,t:1527188904574};\\\", \\\"{x:1474,y:823,t:1527188904590};\\\", \\\"{x:1474,y:824,t:1527188904622};\\\", \\\"{x:1475,y:824,t:1527188904654};\\\", \\\"{x:1476,y:826,t:1527188904710};\\\", \\\"{x:1477,y:827,t:1527188904726};\\\", \\\"{x:1477,y:828,t:1527188904757};\\\", \\\"{x:1478,y:829,t:1527188904773};\\\", \\\"{x:1479,y:829,t:1527188904806};\\\", \\\"{x:1480,y:830,t:1527188904823};\\\", \\\"{x:1481,y:831,t:1527188904854};\\\", \\\"{x:1482,y:831,t:1527188904862};\\\", \\\"{x:1484,y:832,t:1527188904872};\\\", \\\"{x:1484,y:833,t:1527188904890};\\\", \\\"{x:1486,y:834,t:1527188904907};\\\", \\\"{x:1488,y:834,t:1527188904923};\\\", \\\"{x:1489,y:834,t:1527188904939};\\\", \\\"{x:1491,y:835,t:1527188905134};\\\", \\\"{x:1491,y:836,t:1527188905142};\\\", \\\"{x:1493,y:837,t:1527188905158};\\\", \\\"{x:1494,y:837,t:1527188905174};\\\", \\\"{x:1496,y:838,t:1527188905189};\\\", \\\"{x:1496,y:839,t:1527188905206};\\\", \\\"{x:1497,y:840,t:1527188905238};\\\", \\\"{x:1498,y:840,t:1527188905287};\\\", \\\"{x:1499,y:840,t:1527188905318};\\\", \\\"{x:1499,y:841,t:1527188905326};\\\", \\\"{x:1500,y:842,t:1527188905349};\\\", \\\"{x:1500,y:843,t:1527188905381};\\\", \\\"{x:1501,y:845,t:1527188905405};\\\", \\\"{x:1502,y:846,t:1527188905429};\\\", \\\"{x:1503,y:847,t:1527188905453};\\\", \\\"{x:1503,y:848,t:1527188905478};\\\", \\\"{x:1504,y:849,t:1527188905489};\\\", \\\"{x:1505,y:850,t:1527188905506};\\\", \\\"{x:1506,y:851,t:1527188905526};\\\", \\\"{x:1507,y:852,t:1527188905541};\\\", \\\"{x:1507,y:854,t:1527188905557};\\\", \\\"{x:1508,y:855,t:1527188905574};\\\", \\\"{x:1509,y:857,t:1527188905614};\\\", \\\"{x:1509,y:858,t:1527188905638};\\\", \\\"{x:1510,y:858,t:1527188905654};\\\", \\\"{x:1511,y:860,t:1527188905695};\\\", \\\"{x:1511,y:861,t:1527188906038};\\\", \\\"{x:1511,y:863,t:1527188906078};\\\", \\\"{x:1512,y:863,t:1527188906166};\\\", \\\"{x:1512,y:864,t:1527188906262};\\\", \\\"{x:1512,y:866,t:1527188906301};\\\", \\\"{x:1512,y:867,t:1527188906316};\\\", \\\"{x:1512,y:868,t:1527188906333};\\\", \\\"{x:1513,y:870,t:1527188906341};\\\", \\\"{x:1513,y:871,t:1527188906373};\\\", \\\"{x:1514,y:872,t:1527188906390};\\\", \\\"{x:1515,y:873,t:1527188906406};\\\", \\\"{x:1515,y:874,t:1527188906423};\\\", \\\"{x:1515,y:875,t:1527188906453};\\\", \\\"{x:1515,y:876,t:1527188906469};\\\", \\\"{x:1516,y:876,t:1527188907118};\\\", \\\"{x:1516,y:873,t:1527188907134};\\\", \\\"{x:1516,y:871,t:1527188907141};\\\", \\\"{x:1513,y:867,t:1527188907156};\\\", \\\"{x:1509,y:860,t:1527188907173};\\\", \\\"{x:1509,y:858,t:1527188907191};\\\", \\\"{x:1506,y:854,t:1527188907207};\\\", \\\"{x:1505,y:851,t:1527188907224};\\\", \\\"{x:1503,y:848,t:1527188907240};\\\", \\\"{x:1501,y:843,t:1527188907256};\\\", \\\"{x:1498,y:839,t:1527188907273};\\\", \\\"{x:1496,y:834,t:1527188907291};\\\", \\\"{x:1493,y:830,t:1527188907306};\\\", \\\"{x:1490,y:825,t:1527188907323};\\\", \\\"{x:1487,y:819,t:1527188907340};\\\", \\\"{x:1482,y:811,t:1527188907356};\\\", \\\"{x:1476,y:800,t:1527188907374};\\\", \\\"{x:1472,y:792,t:1527188907391};\\\", \\\"{x:1462,y:779,t:1527188907408};\\\", \\\"{x:1456,y:765,t:1527188907423};\\\", \\\"{x:1449,y:749,t:1527188907441};\\\", \\\"{x:1444,y:736,t:1527188907457};\\\", \\\"{x:1437,y:722,t:1527188907473};\\\", \\\"{x:1428,y:705,t:1527188907490};\\\", \\\"{x:1414,y:686,t:1527188907507};\\\", \\\"{x:1403,y:671,t:1527188907524};\\\", \\\"{x:1393,y:656,t:1527188907541};\\\", \\\"{x:1384,y:641,t:1527188907557};\\\", \\\"{x:1380,y:633,t:1527188907573};\\\", \\\"{x:1378,y:624,t:1527188907591};\\\", \\\"{x:1375,y:614,t:1527188907608};\\\", \\\"{x:1375,y:602,t:1527188907623};\\\", \\\"{x:1375,y:588,t:1527188907641};\\\", \\\"{x:1375,y:578,t:1527188907657};\\\", \\\"{x:1375,y:570,t:1527188907673};\\\", \\\"{x:1375,y:567,t:1527188907690};\\\", \\\"{x:1377,y:564,t:1527188907707};\\\", \\\"{x:1379,y:563,t:1527188907723};\\\", \\\"{x:1381,y:563,t:1527188907741};\\\", \\\"{x:1381,y:562,t:1527188907757};\\\", \\\"{x:1382,y:562,t:1527188907773};\\\", \\\"{x:1386,y:562,t:1527188907790};\\\", \\\"{x:1393,y:561,t:1527188907807};\\\", \\\"{x:1399,y:560,t:1527188907823};\\\", \\\"{x:1403,y:559,t:1527188907841};\\\", \\\"{x:1407,y:559,t:1527188907857};\\\", \\\"{x:1410,y:559,t:1527188907874};\\\", \\\"{x:1413,y:559,t:1527188907891};\\\", \\\"{x:1417,y:557,t:1527188907908};\\\", \\\"{x:1418,y:557,t:1527188907923};\\\", \\\"{x:1419,y:557,t:1527188907942};\\\", \\\"{x:1420,y:557,t:1527188907957};\\\", \\\"{x:1422,y:557,t:1527188907981};\\\", \\\"{x:1423,y:558,t:1527188908054};\\\", \\\"{x:1424,y:559,t:1527188908078};\\\", \\\"{x:1424,y:560,t:1527188908118};\\\", \\\"{x:1424,y:562,t:1527188908174};\\\", \\\"{x:1425,y:562,t:1527188908191};\\\", \\\"{x:1425,y:563,t:1527188908208};\\\", \\\"{x:1426,y:563,t:1527188908224};\\\", \\\"{x:1426,y:565,t:1527188908254};\\\", \\\"{x:1427,y:566,t:1527188908285};\\\", \\\"{x:1427,y:568,t:1527188913702};\\\", \\\"{x:1427,y:569,t:1527188913718};\\\", \\\"{x:1427,y:570,t:1527188913734};\\\", \\\"{x:1426,y:570,t:1527188913799};\\\", \\\"{x:1425,y:570,t:1527188913822};\\\", \\\"{x:1424,y:570,t:1527188913863};\\\", \\\"{x:1422,y:569,t:1527188913886};\\\", \\\"{x:1420,y:568,t:1527188913901};\\\", \\\"{x:1419,y:568,t:1527188913910};\\\", \\\"{x:1417,y:568,t:1527188913934};\\\", \\\"{x:1416,y:568,t:1527188913943};\\\", \\\"{x:1414,y:568,t:1527188913959};\\\", \\\"{x:1412,y:568,t:1527188913976};\\\", \\\"{x:1410,y:568,t:1527188913994};\\\", \\\"{x:1409,y:568,t:1527188914010};\\\", \\\"{x:1406,y:568,t:1527188914026};\\\", \\\"{x:1405,y:568,t:1527188914043};\\\", \\\"{x:1404,y:568,t:1527188914060};\\\", \\\"{x:1403,y:568,t:1527188914076};\\\", \\\"{x:1403,y:567,t:1527188914270};\\\", \\\"{x:1404,y:566,t:1527188914286};\\\", \\\"{x:1405,y:566,t:1527188914318};\\\", \\\"{x:1406,y:566,t:1527188914350};\\\", \\\"{x:1407,y:565,t:1527188914366};\\\", \\\"{x:1408,y:565,t:1527188914478};\\\", \\\"{x:1408,y:567,t:1527188914493};\\\", \\\"{x:1410,y:580,t:1527188914510};\\\", \\\"{x:1410,y:588,t:1527188914528};\\\", \\\"{x:1415,y:601,t:1527188914543};\\\", \\\"{x:1421,y:626,t:1527188914560};\\\", \\\"{x:1425,y:642,t:1527188914577};\\\", \\\"{x:1429,y:663,t:1527188914593};\\\", \\\"{x:1429,y:683,t:1527188914610};\\\", \\\"{x:1430,y:701,t:1527188914627};\\\", \\\"{x:1430,y:720,t:1527188914643};\\\", \\\"{x:1431,y:742,t:1527188914660};\\\", \\\"{x:1434,y:767,t:1527188914677};\\\", \\\"{x:1438,y:792,t:1527188914693};\\\", \\\"{x:1438,y:815,t:1527188914710};\\\", \\\"{x:1438,y:830,t:1527188914727};\\\", \\\"{x:1438,y:844,t:1527188914744};\\\", \\\"{x:1441,y:857,t:1527188914761};\\\", \\\"{x:1441,y:863,t:1527188914777};\\\", \\\"{x:1441,y:870,t:1527188914793};\\\", \\\"{x:1441,y:878,t:1527188914811};\\\", \\\"{x:1442,y:889,t:1527188914827};\\\", \\\"{x:1444,y:900,t:1527188914843};\\\", \\\"{x:1445,y:905,t:1527188914861};\\\", \\\"{x:1445,y:910,t:1527188914877};\\\", \\\"{x:1445,y:915,t:1527188914893};\\\", \\\"{x:1445,y:921,t:1527188914910};\\\", \\\"{x:1443,y:926,t:1527188914927};\\\", \\\"{x:1441,y:931,t:1527188914943};\\\", \\\"{x:1438,y:936,t:1527188914960};\\\", \\\"{x:1436,y:939,t:1527188914978};\\\", \\\"{x:1433,y:944,t:1527188914993};\\\", \\\"{x:1432,y:948,t:1527188915010};\\\", \\\"{x:1430,y:952,t:1527188915028};\\\", \\\"{x:1429,y:955,t:1527188915043};\\\", \\\"{x:1428,y:957,t:1527188915060};\\\", \\\"{x:1426,y:961,t:1527188915077};\\\", \\\"{x:1426,y:963,t:1527188915094};\\\", \\\"{x:1423,y:967,t:1527188915110};\\\", \\\"{x:1422,y:967,t:1527188915127};\\\", \\\"{x:1422,y:968,t:1527188915149};\\\", \\\"{x:1421,y:969,t:1527188915197};\\\", \\\"{x:1420,y:970,t:1527188915229};\\\", \\\"{x:1419,y:970,t:1527188915269};\\\", \\\"{x:1418,y:970,t:1527188915293};\\\", \\\"{x:1417,y:970,t:1527188915422};\\\", \\\"{x:1418,y:970,t:1527188916229};\\\", \\\"{x:1422,y:970,t:1527188916243};\\\", \\\"{x:1431,y:969,t:1527188916260};\\\", \\\"{x:1453,y:967,t:1527188916277};\\\", \\\"{x:1464,y:967,t:1527188916293};\\\", \\\"{x:1471,y:967,t:1527188916309};\\\", \\\"{x:1475,y:967,t:1527188916327};\\\", \\\"{x:1480,y:967,t:1527188916344};\\\", \\\"{x:1486,y:967,t:1527188916360};\\\", \\\"{x:1492,y:967,t:1527188916376};\\\", \\\"{x:1499,y:967,t:1527188916394};\\\", \\\"{x:1506,y:967,t:1527188916410};\\\", \\\"{x:1513,y:967,t:1527188916427};\\\", \\\"{x:1519,y:967,t:1527188916444};\\\", \\\"{x:1523,y:967,t:1527188916460};\\\", \\\"{x:1525,y:967,t:1527188916477};\\\", \\\"{x:1528,y:967,t:1527188916493};\\\", \\\"{x:1531,y:967,t:1527188916511};\\\", \\\"{x:1534,y:966,t:1527188916527};\\\", \\\"{x:1536,y:965,t:1527188916544};\\\", \\\"{x:1538,y:965,t:1527188916561};\\\", \\\"{x:1539,y:965,t:1527188916581};\\\", \\\"{x:1540,y:965,t:1527188916598};\\\", \\\"{x:1541,y:964,t:1527188916612};\\\", \\\"{x:1542,y:963,t:1527188916627};\\\", \\\"{x:1544,y:962,t:1527188916654};\\\", \\\"{x:1546,y:962,t:1527188916678};\\\", \\\"{x:1546,y:961,t:1527188916709};\\\", \\\"{x:1547,y:960,t:1527188916727};\\\", \\\"{x:1548,y:960,t:1527188916744};\\\", \\\"{x:1549,y:959,t:1527188916766};\\\", \\\"{x:1549,y:958,t:1527188917174};\\\", \\\"{x:1550,y:957,t:1527188917254};\\\", \\\"{x:1551,y:957,t:1527188917278};\\\", \\\"{x:1552,y:956,t:1527188917294};\\\", \\\"{x:1553,y:956,t:1527188917312};\\\", \\\"{x:1554,y:956,t:1527188917337};\\\", \\\"{x:1555,y:956,t:1527188917348};\\\", \\\"{x:1556,y:954,t:1527188917365};\\\", \\\"{x:1557,y:954,t:1527188917384};\\\", \\\"{x:1558,y:954,t:1527188917400};\\\", \\\"{x:1559,y:954,t:1527188917425};\\\", \\\"{x:1559,y:953,t:1527188917432};\\\", \\\"{x:1559,y:950,t:1527188918570};\\\", \\\"{x:1551,y:945,t:1527188918582};\\\", \\\"{x:1518,y:931,t:1527188918599};\\\", \\\"{x:1430,y:894,t:1527188918614};\\\", \\\"{x:1326,y:856,t:1527188918632};\\\", \\\"{x:1237,y:832,t:1527188918649};\\\", \\\"{x:1178,y:814,t:1527188918665};\\\", \\\"{x:1110,y:790,t:1527188918681};\\\", \\\"{x:1071,y:773,t:1527188918699};\\\", \\\"{x:1036,y:753,t:1527188918714};\\\", \\\"{x:1008,y:735,t:1527188918733};\\\", \\\"{x:971,y:711,t:1527188918750};\\\", \\\"{x:916,y:676,t:1527188918765};\\\", \\\"{x:855,y:646,t:1527188918782};\\\", \\\"{x:800,y:627,t:1527188918798};\\\", \\\"{x:741,y:606,t:1527188918816};\\\", \\\"{x:680,y:591,t:1527188918833};\\\", \\\"{x:592,y:578,t:1527188918873};\\\", \\\"{x:581,y:574,t:1527188918888};\\\", \\\"{x:566,y:572,t:1527188918905};\\\", \\\"{x:561,y:570,t:1527188918923};\\\", \\\"{x:553,y:569,t:1527188918938};\\\", \\\"{x:546,y:568,t:1527188918955};\\\", \\\"{x:540,y:567,t:1527188918972};\\\", \\\"{x:541,y:567,t:1527188919024};\\\", \\\"{x:542,y:567,t:1527188919038};\\\", \\\"{x:556,y:569,t:1527188919055};\\\", \\\"{x:571,y:573,t:1527188919073};\\\", \\\"{x:595,y:576,t:1527188919088};\\\", \\\"{x:608,y:578,t:1527188919106};\\\", \\\"{x:613,y:579,t:1527188919122};\\\", \\\"{x:614,y:579,t:1527188919139};\\\", \\\"{x:618,y:579,t:1527188919576};\\\", \\\"{x:629,y:579,t:1527188919590};\\\", \\\"{x:671,y:586,t:1527188919607};\\\", \\\"{x:735,y:595,t:1527188919623};\\\", \\\"{x:826,y:606,t:1527188919640};\\\", \\\"{x:991,y:616,t:1527188919657};\\\", \\\"{x:1047,y:618,t:1527188919672};\\\", \\\"{x:1208,y:618,t:1527188919689};\\\", \\\"{x:1294,y:618,t:1527188919706};\\\", \\\"{x:1352,y:618,t:1527188919723};\\\", \\\"{x:1390,y:618,t:1527188919739};\\\", \\\"{x:1415,y:618,t:1527188919756};\\\", \\\"{x:1429,y:618,t:1527188919773};\\\", \\\"{x:1437,y:618,t:1527188919789};\\\", \\\"{x:1439,y:618,t:1527188919807};\\\", \\\"{x:1439,y:617,t:1527188919823};\\\", \\\"{x:1440,y:617,t:1527188919839};\\\", \\\"{x:1441,y:616,t:1527188919857};\\\", \\\"{x:1442,y:615,t:1527188919923};\\\", \\\"{x:1440,y:612,t:1527188921122};\\\", \\\"{x:1437,y:608,t:1527188921129};\\\", \\\"{x:1434,y:605,t:1527188921141};\\\", \\\"{x:1426,y:598,t:1527188921157};\\\", \\\"{x:1417,y:593,t:1527188921175};\\\", \\\"{x:1413,y:590,t:1527188921190};\\\", \\\"{x:1410,y:588,t:1527188921207};\\\", \\\"{x:1409,y:587,t:1527188921225};\\\", \\\"{x:1407,y:585,t:1527188921241};\\\", \\\"{x:1402,y:580,t:1527188921258};\\\", \\\"{x:1399,y:576,t:1527188921275};\\\", \\\"{x:1395,y:572,t:1527188921290};\\\", \\\"{x:1391,y:567,t:1527188921308};\\\", \\\"{x:1386,y:563,t:1527188921325};\\\", \\\"{x:1382,y:560,t:1527188921341};\\\", \\\"{x:1378,y:557,t:1527188921358};\\\", \\\"{x:1374,y:553,t:1527188921375};\\\", \\\"{x:1370,y:550,t:1527188921392};\\\", \\\"{x:1367,y:548,t:1527188921408};\\\", \\\"{x:1364,y:546,t:1527188921425};\\\", \\\"{x:1361,y:545,t:1527188921440};\\\", \\\"{x:1358,y:544,t:1527188921458};\\\", \\\"{x:1354,y:540,t:1527188921475};\\\", \\\"{x:1351,y:538,t:1527188921492};\\\", \\\"{x:1346,y:535,t:1527188921508};\\\", \\\"{x:1337,y:531,t:1527188921524};\\\", \\\"{x:1324,y:525,t:1527188921541};\\\", \\\"{x:1310,y:516,t:1527188921558};\\\", \\\"{x:1297,y:509,t:1527188921574};\\\", \\\"{x:1289,y:505,t:1527188921592};\\\", \\\"{x:1287,y:504,t:1527188921608};\\\", \\\"{x:1286,y:503,t:1527188921625};\\\", \\\"{x:1285,y:502,t:1527188921666};\\\", \\\"{x:1287,y:502,t:1527188921761};\\\", \\\"{x:1289,y:502,t:1527188921778};\\\", \\\"{x:1290,y:502,t:1527188921792};\\\", \\\"{x:1293,y:502,t:1527188921808};\\\", \\\"{x:1300,y:502,t:1527188921825};\\\", \\\"{x:1301,y:502,t:1527188921842};\\\", \\\"{x:1302,y:502,t:1527188922122};\\\", \\\"{x:1303,y:502,t:1527188922145};\\\", \\\"{x:1305,y:502,t:1527188922602};\\\", \\\"{x:1307,y:502,t:1527188922617};\\\", \\\"{x:1308,y:502,t:1527188922626};\\\", \\\"{x:1309,y:502,t:1527188922649};\\\", \\\"{x:1310,y:502,t:1527188922672};\\\", \\\"{x:1311,y:502,t:1527188922978};\\\", \\\"{x:1315,y:504,t:1527188922994};\\\", \\\"{x:1319,y:506,t:1527188923010};\\\", \\\"{x:1324,y:509,t:1527188923027};\\\", \\\"{x:1330,y:512,t:1527188923043};\\\", \\\"{x:1334,y:515,t:1527188923060};\\\", \\\"{x:1341,y:519,t:1527188923076};\\\", \\\"{x:1352,y:525,t:1527188923093};\\\", \\\"{x:1359,y:528,t:1527188923110};\\\", \\\"{x:1365,y:532,t:1527188923127};\\\", \\\"{x:1374,y:539,t:1527188923142};\\\", \\\"{x:1381,y:544,t:1527188923160};\\\", \\\"{x:1384,y:546,t:1527188923175};\\\", \\\"{x:1386,y:547,t:1527188923192};\\\", \\\"{x:1387,y:547,t:1527188923209};\\\", \\\"{x:1387,y:548,t:1527188923225};\\\", \\\"{x:1388,y:549,t:1527188923242};\\\", \\\"{x:1390,y:550,t:1527188923296};\\\", \\\"{x:1390,y:551,t:1527188923627};\\\", \\\"{x:1391,y:552,t:1527188923643};\\\", \\\"{x:1393,y:553,t:1527188923660};\\\", \\\"{x:1395,y:554,t:1527188923677};\\\", \\\"{x:1395,y:555,t:1527188923693};\\\", \\\"{x:1396,y:555,t:1527188923710};\\\", \\\"{x:1397,y:555,t:1527188923729};\\\", \\\"{x:1395,y:555,t:1527188924426};\\\", \\\"{x:1385,y:551,t:1527188924444};\\\", \\\"{x:1370,y:541,t:1527188924461};\\\", \\\"{x:1356,y:533,t:1527188924477};\\\", \\\"{x:1345,y:525,t:1527188924494};\\\", \\\"{x:1333,y:516,t:1527188924511};\\\", \\\"{x:1326,y:511,t:1527188924527};\\\", \\\"{x:1324,y:508,t:1527188924544};\\\", \\\"{x:1321,y:504,t:1527188924561};\\\", \\\"{x:1320,y:501,t:1527188924577};\\\", \\\"{x:1317,y:499,t:1527188924595};\\\", \\\"{x:1316,y:498,t:1527188924611};\\\", \\\"{x:1315,y:497,t:1527188924682};\\\", \\\"{x:1314,y:498,t:1527188924694};\\\", \\\"{x:1313,y:498,t:1527188924711};\\\", \\\"{x:1312,y:498,t:1527188924737};\\\", \\\"{x:1312,y:499,t:1527188924817};\\\", \\\"{x:1311,y:500,t:1527188924833};\\\", \\\"{x:1311,y:501,t:1527188924844};\\\", \\\"{x:1311,y:505,t:1527188924862};\\\", \\\"{x:1311,y:511,t:1527188924879};\\\", \\\"{x:1311,y:520,t:1527188924894};\\\", \\\"{x:1311,y:526,t:1527188924911};\\\", \\\"{x:1314,y:535,t:1527188924928};\\\", \\\"{x:1317,y:547,t:1527188924944};\\\", \\\"{x:1321,y:560,t:1527188924961};\\\", \\\"{x:1322,y:568,t:1527188924977};\\\", \\\"{x:1323,y:578,t:1527188924994};\\\", \\\"{x:1325,y:588,t:1527188925011};\\\", \\\"{x:1326,y:597,t:1527188925028};\\\", \\\"{x:1327,y:611,t:1527188925044};\\\", \\\"{x:1329,y:627,t:1527188925061};\\\", \\\"{x:1331,y:634,t:1527188925078};\\\", \\\"{x:1331,y:641,t:1527188925094};\\\", \\\"{x:1331,y:649,t:1527188925111};\\\", \\\"{x:1331,y:660,t:1527188925128};\\\", \\\"{x:1331,y:677,t:1527188925145};\\\", \\\"{x:1331,y:688,t:1527188925161};\\\", \\\"{x:1330,y:699,t:1527188925178};\\\", \\\"{x:1328,y:708,t:1527188925195};\\\", \\\"{x:1325,y:717,t:1527188925211};\\\", \\\"{x:1324,y:726,t:1527188925228};\\\", \\\"{x:1324,y:734,t:1527188925245};\\\", \\\"{x:1322,y:742,t:1527188925261};\\\", \\\"{x:1321,y:751,t:1527188925278};\\\", \\\"{x:1320,y:758,t:1527188925295};\\\", \\\"{x:1319,y:767,t:1527188925311};\\\", \\\"{x:1317,y:773,t:1527188925328};\\\", \\\"{x:1315,y:786,t:1527188925345};\\\", \\\"{x:1312,y:800,t:1527188925361};\\\", \\\"{x:1311,y:810,t:1527188925378};\\\", \\\"{x:1310,y:818,t:1527188925395};\\\", \\\"{x:1308,y:826,t:1527188925411};\\\", \\\"{x:1302,y:838,t:1527188925428};\\\", \\\"{x:1301,y:846,t:1527188925445};\\\", \\\"{x:1301,y:850,t:1527188925461};\\\", \\\"{x:1299,y:854,t:1527188925478};\\\", \\\"{x:1299,y:856,t:1527188925495};\\\", \\\"{x:1299,y:861,t:1527188925512};\\\", \\\"{x:1299,y:871,t:1527188925528};\\\", \\\"{x:1299,y:880,t:1527188925545};\\\", \\\"{x:1301,y:885,t:1527188925561};\\\", \\\"{x:1303,y:891,t:1527188925578};\\\", \\\"{x:1304,y:897,t:1527188925595};\\\", \\\"{x:1307,y:904,t:1527188925612};\\\", \\\"{x:1309,y:911,t:1527188925628};\\\", \\\"{x:1309,y:916,t:1527188925645};\\\", \\\"{x:1311,y:920,t:1527188925663};\\\", \\\"{x:1311,y:922,t:1527188925678};\\\", \\\"{x:1311,y:924,t:1527188925695};\\\", \\\"{x:1311,y:927,t:1527188925712};\\\", \\\"{x:1311,y:930,t:1527188925728};\\\", \\\"{x:1311,y:933,t:1527188925745};\\\", \\\"{x:1311,y:936,t:1527188925761};\\\", \\\"{x:1311,y:938,t:1527188925778};\\\", \\\"{x:1312,y:940,t:1527188925795};\\\", \\\"{x:1312,y:942,t:1527188925812};\\\", \\\"{x:1313,y:943,t:1527188925828};\\\", \\\"{x:1313,y:945,t:1527188925845};\\\", \\\"{x:1314,y:946,t:1527188925890};\\\", \\\"{x:1314,y:948,t:1527188925970};\\\", \\\"{x:1314,y:949,t:1527188926002};\\\", \\\"{x:1314,y:950,t:1527188926025};\\\", \\\"{x:1314,y:951,t:1527188926041};\\\", \\\"{x:1314,y:952,t:1527188926049};\\\", \\\"{x:1314,y:953,t:1527188926065};\\\", \\\"{x:1314,y:954,t:1527188926079};\\\", \\\"{x:1314,y:955,t:1527188926095};\\\", \\\"{x:1314,y:956,t:1527188926112};\\\", \\\"{x:1314,y:958,t:1527188926129};\\\", \\\"{x:1314,y:959,t:1527188926160};\\\", \\\"{x:1314,y:960,t:1527188926185};\\\", \\\"{x:1314,y:961,t:1527188926201};\\\", \\\"{x:1313,y:961,t:1527188926225};\\\", \\\"{x:1313,y:962,t:1527188926249};\\\", \\\"{x:1311,y:964,t:1527188926954};\\\", \\\"{x:1310,y:965,t:1527188926977};\\\", \\\"{x:1309,y:966,t:1527188926985};\\\", \\\"{x:1309,y:967,t:1527188927001};\\\", \\\"{x:1308,y:967,t:1527188927017};\\\", \\\"{x:1308,y:968,t:1527188927114};\\\", \\\"{x:1307,y:968,t:1527188927146};\\\", \\\"{x:1306,y:968,t:1527188927201};\\\", \\\"{x:1305,y:968,t:1527188927225};\\\", \\\"{x:1305,y:967,t:1527188927234};\\\", \\\"{x:1304,y:965,t:1527188927246};\\\", \\\"{x:1303,y:960,t:1527188927263};\\\", \\\"{x:1302,y:957,t:1527188927280};\\\", \\\"{x:1301,y:953,t:1527188927297};\\\", \\\"{x:1300,y:942,t:1527188927314};\\\", \\\"{x:1296,y:932,t:1527188927329};\\\", \\\"{x:1296,y:931,t:1527188927346};\\\", \\\"{x:1295,y:930,t:1527188927378};\\\", \\\"{x:1293,y:930,t:1527188927393};\\\", \\\"{x:1292,y:930,t:1527188927402};\\\", \\\"{x:1290,y:930,t:1527188927413};\\\", \\\"{x:1282,y:931,t:1527188927430};\\\", \\\"{x:1273,y:936,t:1527188927446};\\\", \\\"{x:1272,y:937,t:1527188927463};\\\", \\\"{x:1271,y:938,t:1527188927480};\\\", \\\"{x:1270,y:940,t:1527188927496};\\\", \\\"{x:1270,y:938,t:1527188927602};\\\", \\\"{x:1270,y:935,t:1527188927613};\\\", \\\"{x:1272,y:927,t:1527188927630};\\\", \\\"{x:1275,y:907,t:1527188927648};\\\", \\\"{x:1275,y:883,t:1527188927663};\\\", \\\"{x:1275,y:856,t:1527188927680};\\\", \\\"{x:1275,y:822,t:1527188927697};\\\", \\\"{x:1275,y:796,t:1527188927713};\\\", \\\"{x:1275,y:775,t:1527188927730};\\\", \\\"{x:1275,y:756,t:1527188927747};\\\", \\\"{x:1275,y:736,t:1527188927764};\\\", \\\"{x:1276,y:711,t:1527188927780};\\\", \\\"{x:1276,y:692,t:1527188927798};\\\", \\\"{x:1276,y:676,t:1527188927813};\\\", \\\"{x:1276,y:663,t:1527188927830};\\\", \\\"{x:1277,y:651,t:1527188927847};\\\", \\\"{x:1280,y:637,t:1527188927863};\\\", \\\"{x:1282,y:623,t:1527188927880};\\\", \\\"{x:1287,y:604,t:1527188927897};\\\", \\\"{x:1291,y:597,t:1527188927913};\\\", \\\"{x:1294,y:591,t:1527188927930};\\\", \\\"{x:1298,y:582,t:1527188927948};\\\", \\\"{x:1301,y:572,t:1527188927964};\\\", \\\"{x:1305,y:561,t:1527188927980};\\\", \\\"{x:1313,y:549,t:1527188927997};\\\", \\\"{x:1319,y:536,t:1527188928014};\\\", \\\"{x:1324,y:521,t:1527188928031};\\\", \\\"{x:1324,y:513,t:1527188928047};\\\", \\\"{x:1325,y:505,t:1527188928065};\\\", \\\"{x:1325,y:500,t:1527188928081};\\\", \\\"{x:1325,y:489,t:1527188928097};\\\", \\\"{x:1324,y:484,t:1527188928113};\\\", \\\"{x:1323,y:482,t:1527188928130};\\\", \\\"{x:1323,y:481,t:1527188928148};\\\", \\\"{x:1322,y:482,t:1527188928209};\\\", \\\"{x:1319,y:486,t:1527188928216};\\\", \\\"{x:1316,y:491,t:1527188928230};\\\", \\\"{x:1311,y:502,t:1527188928247};\\\", \\\"{x:1306,y:511,t:1527188928264};\\\", \\\"{x:1305,y:517,t:1527188928280};\\\", \\\"{x:1304,y:532,t:1527188928296};\\\", \\\"{x:1304,y:540,t:1527188928313};\\\", \\\"{x:1303,y:550,t:1527188928330};\\\", \\\"{x:1301,y:558,t:1527188928347};\\\", \\\"{x:1300,y:570,t:1527188928363};\\\", \\\"{x:1300,y:579,t:1527188928380};\\\", \\\"{x:1297,y:592,t:1527188928396};\\\", \\\"{x:1295,y:603,t:1527188928414};\\\", \\\"{x:1295,y:612,t:1527188928430};\\\", \\\"{x:1295,y:621,t:1527188928447};\\\", \\\"{x:1295,y:634,t:1527188928464};\\\", \\\"{x:1297,y:647,t:1527188928481};\\\", \\\"{x:1298,y:653,t:1527188928497};\\\", \\\"{x:1302,y:660,t:1527188928514};\\\", \\\"{x:1304,y:666,t:1527188928532};\\\", \\\"{x:1309,y:676,t:1527188928547};\\\", \\\"{x:1313,y:687,t:1527188928563};\\\", \\\"{x:1317,y:697,t:1527188928580};\\\", \\\"{x:1321,y:707,t:1527188928597};\\\", \\\"{x:1324,y:715,t:1527188928614};\\\", \\\"{x:1325,y:722,t:1527188928631};\\\", \\\"{x:1325,y:730,t:1527188928647};\\\", \\\"{x:1326,y:743,t:1527188928663};\\\", \\\"{x:1329,y:757,t:1527188928681};\\\", \\\"{x:1329,y:762,t:1527188928697};\\\", \\\"{x:1329,y:766,t:1527188928714};\\\", \\\"{x:1329,y:769,t:1527188928731};\\\", \\\"{x:1329,y:771,t:1527188928747};\\\", \\\"{x:1329,y:775,t:1527188928764};\\\", \\\"{x:1329,y:778,t:1527188928782};\\\", \\\"{x:1328,y:780,t:1527188928798};\\\", \\\"{x:1327,y:781,t:1527188928814};\\\", \\\"{x:1327,y:783,t:1527188928831};\\\", \\\"{x:1325,y:785,t:1527188928847};\\\", \\\"{x:1325,y:786,t:1527188928874};\\\", \\\"{x:1325,y:787,t:1527188929066};\\\", \\\"{x:1324,y:789,t:1527188929081};\\\", \\\"{x:1324,y:791,t:1527188929098};\\\", \\\"{x:1324,y:795,t:1527188929114};\\\", \\\"{x:1324,y:797,t:1527188929133};\\\", \\\"{x:1324,y:799,t:1527188929149};\\\", \\\"{x:1324,y:800,t:1527188929164};\\\", \\\"{x:1324,y:801,t:1527188929182};\\\", \\\"{x:1324,y:803,t:1527188929199};\\\", \\\"{x:1324,y:805,t:1527188929214};\\\", \\\"{x:1324,y:807,t:1527188929231};\\\", \\\"{x:1324,y:808,t:1527188929248};\\\", \\\"{x:1324,y:810,t:1527188929266};\\\", \\\"{x:1324,y:811,t:1527188929505};\\\", \\\"{x:1325,y:811,t:1527188931265};\\\", \\\"{x:1325,y:813,t:1527188931284};\\\", \\\"{x:1326,y:819,t:1527188931299};\\\", \\\"{x:1330,y:823,t:1527188931316};\\\", \\\"{x:1338,y:830,t:1527188931333};\\\", \\\"{x:1355,y:841,t:1527188931350};\\\", \\\"{x:1385,y:855,t:1527188931367};\\\", \\\"{x:1411,y:872,t:1527188931384};\\\", \\\"{x:1434,y:886,t:1527188931400};\\\", \\\"{x:1454,y:899,t:1527188931417};\\\", \\\"{x:1471,y:910,t:1527188931433};\\\", \\\"{x:1478,y:914,t:1527188931451};\\\", \\\"{x:1482,y:917,t:1527188933082};\\\", \\\"{x:1491,y:920,t:1527188933089};\\\", \\\"{x:1501,y:924,t:1527188933102};\\\", \\\"{x:1525,y:931,t:1527188933119};\\\", \\\"{x:1544,y:937,t:1527188933134};\\\", \\\"{x:1556,y:944,t:1527188933152};\\\", \\\"{x:1564,y:946,t:1527188933169};\\\", \\\"{x:1568,y:947,t:1527188933184};\\\", \\\"{x:1568,y:948,t:1527188933202};\\\", \\\"{x:1567,y:948,t:1527188933314};\\\", \\\"{x:1564,y:948,t:1527188933321};\\\", \\\"{x:1558,y:948,t:1527188933334};\\\", \\\"{x:1547,y:948,t:1527188933351};\\\", \\\"{x:1539,y:948,t:1527188933368};\\\", \\\"{x:1527,y:942,t:1527188933384};\\\", \\\"{x:1518,y:935,t:1527188933401};\\\", \\\"{x:1517,y:932,t:1527188933418};\\\", \\\"{x:1516,y:929,t:1527188933435};\\\", \\\"{x:1514,y:924,t:1527188933451};\\\", \\\"{x:1514,y:916,t:1527188933468};\\\", \\\"{x:1511,y:910,t:1527188933485};\\\", \\\"{x:1510,y:906,t:1527188933501};\\\", \\\"{x:1510,y:903,t:1527188933519};\\\", \\\"{x:1510,y:901,t:1527188933535};\\\", \\\"{x:1509,y:900,t:1527188933551};\\\", \\\"{x:1509,y:898,t:1527188933569};\\\", \\\"{x:1509,y:897,t:1527188933593};\\\", \\\"{x:1508,y:897,t:1527188935402};\\\", \\\"{x:1507,y:897,t:1527188935409};\\\", \\\"{x:1505,y:897,t:1527188935419};\\\", \\\"{x:1503,y:895,t:1527188935437};\\\", \\\"{x:1502,y:894,t:1527188935454};\\\", \\\"{x:1501,y:893,t:1527188935471};\\\", \\\"{x:1500,y:893,t:1527188937338};\\\", \\\"{x:1481,y:883,t:1527188937354};\\\", \\\"{x:1435,y:856,t:1527188937372};\\\", \\\"{x:1369,y:801,t:1527188937388};\\\", \\\"{x:1307,y:727,t:1527188937404};\\\", \\\"{x:1267,y:674,t:1527188937421};\\\", \\\"{x:1250,y:640,t:1527188937438};\\\", \\\"{x:1246,y:617,t:1527188937454};\\\", \\\"{x:1246,y:602,t:1527188937471};\\\", \\\"{x:1251,y:593,t:1527188937488};\\\", \\\"{x:1256,y:588,t:1527188937504};\\\", \\\"{x:1259,y:583,t:1527188937522};\\\", \\\"{x:1261,y:579,t:1527188937538};\\\", \\\"{x:1264,y:573,t:1527188937555};\\\", \\\"{x:1267,y:566,t:1527188937571};\\\", \\\"{x:1270,y:557,t:1527188937588};\\\", \\\"{x:1276,y:547,t:1527188937605};\\\", \\\"{x:1281,y:543,t:1527188937621};\\\", \\\"{x:1287,y:538,t:1527188937639};\\\", \\\"{x:1291,y:535,t:1527188937656};\\\", \\\"{x:1295,y:529,t:1527188937672};\\\", \\\"{x:1299,y:523,t:1527188937688};\\\", \\\"{x:1300,y:520,t:1527188937705};\\\", \\\"{x:1301,y:515,t:1527188937722};\\\", \\\"{x:1301,y:512,t:1527188937739};\\\", \\\"{x:1301,y:510,t:1527188937755};\\\", \\\"{x:1301,y:508,t:1527188937777};\\\", \\\"{x:1303,y:513,t:1527188937873};\\\", \\\"{x:1304,y:521,t:1527188937889};\\\", \\\"{x:1310,y:562,t:1527188937905};\\\", \\\"{x:1314,y:595,t:1527188937923};\\\", \\\"{x:1318,y:634,t:1527188937939};\\\", \\\"{x:1322,y:672,t:1527188937956};\\\", \\\"{x:1324,y:700,t:1527188937972};\\\", \\\"{x:1327,y:717,t:1527188937988};\\\", \\\"{x:1329,y:732,t:1527188938005};\\\", \\\"{x:1331,y:747,t:1527188938022};\\\", \\\"{x:1332,y:761,t:1527188938038};\\\", \\\"{x:1332,y:776,t:1527188938055};\\\", \\\"{x:1332,y:796,t:1527188938073};\\\", \\\"{x:1332,y:811,t:1527188938088};\\\", \\\"{x:1333,y:826,t:1527188938105};\\\", \\\"{x:1336,y:837,t:1527188938122};\\\", \\\"{x:1336,y:844,t:1527188938139};\\\", \\\"{x:1336,y:852,t:1527188938156};\\\", \\\"{x:1336,y:863,t:1527188938173};\\\", \\\"{x:1335,y:876,t:1527188938188};\\\", \\\"{x:1334,y:886,t:1527188938206};\\\", \\\"{x:1332,y:894,t:1527188938222};\\\", \\\"{x:1332,y:898,t:1527188938238};\\\", \\\"{x:1332,y:903,t:1527188938256};\\\", \\\"{x:1332,y:919,t:1527188938273};\\\", \\\"{x:1332,y:930,t:1527188938289};\\\", \\\"{x:1332,y:944,t:1527188938306};\\\", \\\"{x:1331,y:954,t:1527188938323};\\\", \\\"{x:1329,y:964,t:1527188938339};\\\", \\\"{x:1328,y:974,t:1527188938356};\\\", \\\"{x:1327,y:978,t:1527188938373};\\\", \\\"{x:1326,y:981,t:1527188938389};\\\", \\\"{x:1325,y:983,t:1527188938406};\\\", \\\"{x:1324,y:983,t:1527188938522};\\\", \\\"{x:1324,y:980,t:1527188938539};\\\", \\\"{x:1322,y:976,t:1527188938555};\\\", \\\"{x:1320,y:971,t:1527188938573};\\\", \\\"{x:1318,y:968,t:1527188938590};\\\", \\\"{x:1317,y:966,t:1527188938606};\\\", \\\"{x:1317,y:965,t:1527188940568};\\\", \\\"{x:1319,y:964,t:1527188940624};\\\", \\\"{x:1324,y:964,t:1527188940640};\\\", \\\"{x:1332,y:964,t:1527188940657};\\\", \\\"{x:1341,y:964,t:1527188940674};\\\", \\\"{x:1350,y:964,t:1527188940690};\\\", \\\"{x:1358,y:964,t:1527188940707};\\\", \\\"{x:1366,y:964,t:1527188940725};\\\", \\\"{x:1374,y:963,t:1527188940742};\\\", \\\"{x:1384,y:963,t:1527188940758};\\\", \\\"{x:1399,y:963,t:1527188940775};\\\", \\\"{x:1414,y:963,t:1527188940791};\\\", \\\"{x:1429,y:963,t:1527188940808};\\\", \\\"{x:1447,y:963,t:1527188940824};\\\", \\\"{x:1457,y:959,t:1527188940841};\\\", \\\"{x:1465,y:955,t:1527188940857};\\\", \\\"{x:1470,y:950,t:1527188940875};\\\", \\\"{x:1474,y:940,t:1527188940891};\\\", \\\"{x:1480,y:928,t:1527188940907};\\\", \\\"{x:1484,y:918,t:1527188940925};\\\", \\\"{x:1486,y:906,t:1527188940941};\\\", \\\"{x:1488,y:897,t:1527188940957};\\\", \\\"{x:1488,y:889,t:1527188940974};\\\", \\\"{x:1489,y:884,t:1527188940991};\\\", \\\"{x:1489,y:881,t:1527188941007};\\\", \\\"{x:1489,y:878,t:1527188941025};\\\", \\\"{x:1489,y:876,t:1527188941041};\\\", \\\"{x:1489,y:875,t:1527188941058};\\\", \\\"{x:1489,y:874,t:1527188941074};\\\", \\\"{x:1488,y:871,t:1527188941092};\\\", \\\"{x:1488,y:868,t:1527188941108};\\\", \\\"{x:1485,y:860,t:1527188941125};\\\", \\\"{x:1483,y:854,t:1527188941142};\\\", \\\"{x:1479,y:841,t:1527188941157};\\\", \\\"{x:1475,y:831,t:1527188941174};\\\", \\\"{x:1472,y:816,t:1527188941192};\\\", \\\"{x:1465,y:796,t:1527188941209};\\\", \\\"{x:1463,y:786,t:1527188941224};\\\", \\\"{x:1461,y:778,t:1527188941241};\\\", \\\"{x:1460,y:775,t:1527188941259};\\\", \\\"{x:1460,y:776,t:1527188941442};\\\", \\\"{x:1460,y:777,t:1527188941459};\\\", \\\"{x:1460,y:778,t:1527188941538};\\\", \\\"{x:1460,y:779,t:1527188941569};\\\", \\\"{x:1460,y:780,t:1527188941584};\\\", \\\"{x:1460,y:781,t:1527188941625};\\\", \\\"{x:1460,y:782,t:1527188941642};\\\", \\\"{x:1460,y:783,t:1527188941658};\\\", \\\"{x:1460,y:784,t:1527188941675};\\\", \\\"{x:1460,y:785,t:1527188941691};\\\", \\\"{x:1460,y:786,t:1527188941709};\\\", \\\"{x:1460,y:788,t:1527188941726};\\\", \\\"{x:1460,y:792,t:1527188941742};\\\", \\\"{x:1461,y:796,t:1527188941759};\\\", \\\"{x:1462,y:801,t:1527188941776};\\\", \\\"{x:1463,y:806,t:1527188941792};\\\", \\\"{x:1464,y:813,t:1527188941809};\\\", \\\"{x:1464,y:820,t:1527188941825};\\\", \\\"{x:1464,y:826,t:1527188941841};\\\", \\\"{x:1464,y:830,t:1527188941859};\\\", \\\"{x:1464,y:833,t:1527188941876};\\\", \\\"{x:1464,y:835,t:1527188941891};\\\", \\\"{x:1464,y:837,t:1527188941909};\\\", \\\"{x:1463,y:836,t:1527188942105};\\\", \\\"{x:1462,y:836,t:1527188942121};\\\", \\\"{x:1461,y:835,t:1527188942130};\\\", \\\"{x:1459,y:833,t:1527188942143};\\\", \\\"{x:1457,y:832,t:1527188942159};\\\", \\\"{x:1454,y:829,t:1527188942176};\\\", \\\"{x:1449,y:819,t:1527188942193};\\\", \\\"{x:1445,y:804,t:1527188942209};\\\", \\\"{x:1436,y:782,t:1527188942226};\\\", \\\"{x:1433,y:771,t:1527188942243};\\\", \\\"{x:1431,y:761,t:1527188942259};\\\", \\\"{x:1429,y:748,t:1527188942275};\\\", \\\"{x:1428,y:738,t:1527188942293};\\\", \\\"{x:1428,y:729,t:1527188942308};\\\", \\\"{x:1428,y:718,t:1527188942326};\\\", \\\"{x:1428,y:711,t:1527188942343};\\\", \\\"{x:1427,y:702,t:1527188942359};\\\", \\\"{x:1427,y:694,t:1527188942376};\\\", \\\"{x:1425,y:677,t:1527188942393};\\\", \\\"{x:1424,y:664,t:1527188942409};\\\", \\\"{x:1424,y:651,t:1527188942426};\\\", \\\"{x:1423,y:638,t:1527188942443};\\\", \\\"{x:1422,y:630,t:1527188942460};\\\", \\\"{x:1419,y:624,t:1527188942477};\\\", \\\"{x:1416,y:614,t:1527188942493};\\\", \\\"{x:1414,y:601,t:1527188942510};\\\", \\\"{x:1410,y:594,t:1527188942526};\\\", \\\"{x:1409,y:589,t:1527188942543};\\\", \\\"{x:1407,y:584,t:1527188942560};\\\", \\\"{x:1405,y:578,t:1527188942576};\\\", \\\"{x:1401,y:568,t:1527188942593};\\\", \\\"{x:1399,y:566,t:1527188942609};\\\", \\\"{x:1398,y:561,t:1527188942626};\\\", \\\"{x:1395,y:556,t:1527188942643};\\\", \\\"{x:1396,y:556,t:1527188942802};\\\", \\\"{x:1396,y:557,t:1527188942810};\\\", \\\"{x:1398,y:559,t:1527188942827};\\\", \\\"{x:1400,y:562,t:1527188942843};\\\", \\\"{x:1402,y:564,t:1527188942860};\\\", \\\"{x:1402,y:565,t:1527188942877};\\\", \\\"{x:1403,y:569,t:1527188942893};\\\", \\\"{x:1405,y:573,t:1527188942910};\\\", \\\"{x:1407,y:580,t:1527188942927};\\\", \\\"{x:1411,y:588,t:1527188942943};\\\", \\\"{x:1411,y:593,t:1527188942960};\\\", \\\"{x:1414,y:604,t:1527188942977};\\\", \\\"{x:1415,y:615,t:1527188942994};\\\", \\\"{x:1416,y:628,t:1527188943010};\\\", \\\"{x:1419,y:638,t:1527188943027};\\\", \\\"{x:1419,y:645,t:1527188943043};\\\", \\\"{x:1420,y:653,t:1527188943060};\\\", \\\"{x:1423,y:666,t:1527188943077};\\\", \\\"{x:1425,y:678,t:1527188943093};\\\", \\\"{x:1427,y:688,t:1527188943110};\\\", \\\"{x:1427,y:692,t:1527188943127};\\\", \\\"{x:1428,y:697,t:1527188943142};\\\", \\\"{x:1429,y:703,t:1527188943159};\\\", \\\"{x:1430,y:714,t:1527188943176};\\\", \\\"{x:1432,y:722,t:1527188943193};\\\", \\\"{x:1432,y:725,t:1527188943209};\\\", \\\"{x:1433,y:731,t:1527188943227};\\\", \\\"{x:1433,y:735,t:1527188943244};\\\", \\\"{x:1433,y:741,t:1527188943259};\\\", \\\"{x:1433,y:744,t:1527188943276};\\\", \\\"{x:1433,y:745,t:1527188943293};\\\", \\\"{x:1433,y:746,t:1527188943310};\\\", \\\"{x:1432,y:746,t:1527188943425};\\\", \\\"{x:1429,y:746,t:1527188943444};\\\", \\\"{x:1428,y:744,t:1527188943460};\\\", \\\"{x:1427,y:743,t:1527188943553};\\\", \\\"{x:1425,y:743,t:1527188943578};\\\", \\\"{x:1424,y:745,t:1527188943594};\\\", \\\"{x:1423,y:746,t:1527188943610};\\\", \\\"{x:1422,y:747,t:1527188943627};\\\", \\\"{x:1422,y:748,t:1527188943645};\\\", \\\"{x:1420,y:751,t:1527188943661};\\\", \\\"{x:1420,y:756,t:1527188943677};\\\", \\\"{x:1420,y:759,t:1527188943694};\\\", \\\"{x:1420,y:763,t:1527188943711};\\\", \\\"{x:1420,y:769,t:1527188943727};\\\", \\\"{x:1420,y:774,t:1527188943744};\\\", \\\"{x:1420,y:784,t:1527188943761};\\\", \\\"{x:1420,y:793,t:1527188943777};\\\", \\\"{x:1421,y:802,t:1527188943794};\\\", \\\"{x:1422,y:811,t:1527188943811};\\\", \\\"{x:1424,y:822,t:1527188943827};\\\", \\\"{x:1425,y:830,t:1527188943844};\\\", \\\"{x:1428,y:836,t:1527188943861};\\\", \\\"{x:1429,y:842,t:1527188943877};\\\", \\\"{x:1429,y:852,t:1527188943894};\\\", \\\"{x:1429,y:870,t:1527188943911};\\\", \\\"{x:1430,y:886,t:1527188943927};\\\", \\\"{x:1431,y:892,t:1527188943944};\\\", \\\"{x:1433,y:894,t:1527188943962};\\\", \\\"{x:1434,y:895,t:1527188944073};\\\", \\\"{x:1434,y:898,t:1527188944082};\\\", \\\"{x:1434,y:901,t:1527188944094};\\\", \\\"{x:1436,y:916,t:1527188944112};\\\", \\\"{x:1437,y:930,t:1527188944128};\\\", \\\"{x:1438,y:937,t:1527188944144};\\\", \\\"{x:1438,y:944,t:1527188944161};\\\", \\\"{x:1438,y:946,t:1527188944178};\\\", \\\"{x:1438,y:947,t:1527188944194};\\\", \\\"{x:1438,y:948,t:1527188944217};\\\", \\\"{x:1437,y:949,t:1527188944234};\\\", \\\"{x:1435,y:949,t:1527188944257};\\\", \\\"{x:1434,y:949,t:1527188944265};\\\", \\\"{x:1431,y:950,t:1527188944278};\\\", \\\"{x:1426,y:953,t:1527188944294};\\\", \\\"{x:1424,y:954,t:1527188944311};\\\", \\\"{x:1423,y:954,t:1527188944328};\\\", \\\"{x:1422,y:954,t:1527188944344};\\\", \\\"{x:1419,y:957,t:1527188944361};\\\", \\\"{x:1416,y:962,t:1527188944378};\\\", \\\"{x:1414,y:965,t:1527188944395};\\\", \\\"{x:1412,y:967,t:1527188944412};\\\", \\\"{x:1412,y:968,t:1527188944428};\\\", \\\"{x:1411,y:969,t:1527188944450};\\\", \\\"{x:1412,y:969,t:1527188946114};\\\", \\\"{x:1414,y:969,t:1527188946401};\\\", \\\"{x:1415,y:969,t:1527188946417};\\\", \\\"{x:1416,y:969,t:1527188946433};\\\", \\\"{x:1417,y:968,t:1527188946466};\\\", \\\"{x:1419,y:968,t:1527188946479};\\\", \\\"{x:1428,y:966,t:1527188946496};\\\", \\\"{x:1439,y:963,t:1527188946514};\\\", \\\"{x:1443,y:961,t:1527188946530};\\\", \\\"{x:1445,y:961,t:1527188946547};\\\", \\\"{x:1448,y:960,t:1527188946564};\\\", \\\"{x:1452,y:959,t:1527188946580};\\\", \\\"{x:1457,y:958,t:1527188946597};\\\", \\\"{x:1460,y:957,t:1527188946613};\\\", \\\"{x:1460,y:956,t:1527188946689};\\\", \\\"{x:1461,y:956,t:1527188946697};\\\", \\\"{x:1461,y:955,t:1527188946729};\\\", \\\"{x:1462,y:955,t:1527188947433};\\\", \\\"{x:1464,y:955,t:1527188947447};\\\", \\\"{x:1466,y:955,t:1527188947464};\\\", \\\"{x:1467,y:955,t:1527188947480};\\\", \\\"{x:1468,y:955,t:1527188947513};\\\", \\\"{x:1468,y:957,t:1527188948457};\\\", \\\"{x:1468,y:960,t:1527188948465};\\\", \\\"{x:1468,y:964,t:1527188948481};\\\", \\\"{x:1468,y:967,t:1527188948499};\\\", \\\"{x:1468,y:968,t:1527188948514};\\\", \\\"{x:1468,y:969,t:1527188948554};\\\", \\\"{x:1469,y:970,t:1527188948572};\\\", \\\"{x:1469,y:971,t:1527188948673};\\\", \\\"{x:1470,y:971,t:1527188948681};\\\", \\\"{x:1468,y:971,t:1527188948834};\\\", \\\"{x:1464,y:971,t:1527188948848};\\\", \\\"{x:1447,y:971,t:1527188948866};\\\", \\\"{x:1431,y:971,t:1527188948881};\\\", \\\"{x:1411,y:971,t:1527188948898};\\\", \\\"{x:1397,y:971,t:1527188948915};\\\", \\\"{x:1390,y:971,t:1527188948931};\\\", \\\"{x:1389,y:971,t:1527188949002};\\\", \\\"{x:1389,y:970,t:1527188949032};\\\", \\\"{x:1389,y:969,t:1527188949145};\\\", \\\"{x:1390,y:968,t:1527188949162};\\\", \\\"{x:1392,y:967,t:1527188949177};\\\", \\\"{x:1393,y:967,t:1527188949185};\\\", \\\"{x:1395,y:966,t:1527188949198};\\\", \\\"{x:1400,y:965,t:1527188949215};\\\", \\\"{x:1405,y:964,t:1527188949233};\\\", \\\"{x:1409,y:963,t:1527188949248};\\\", \\\"{x:1412,y:963,t:1527188949265};\\\", \\\"{x:1413,y:963,t:1527188949283};\\\", \\\"{x:1414,y:963,t:1527188949305};\\\", \\\"{x:1415,y:963,t:1527188949316};\\\", \\\"{x:1417,y:963,t:1527188949333};\\\", \\\"{x:1420,y:963,t:1527188949348};\\\", \\\"{x:1421,y:963,t:1527188949365};\\\", \\\"{x:1422,y:963,t:1527188949382};\\\", \\\"{x:1423,y:963,t:1527188949399};\\\", \\\"{x:1426,y:963,t:1527188949415};\\\", \\\"{x:1430,y:963,t:1527188949432};\\\", \\\"{x:1438,y:963,t:1527188949449};\\\", \\\"{x:1444,y:963,t:1527188949465};\\\", \\\"{x:1449,y:963,t:1527188949482};\\\", \\\"{x:1453,y:963,t:1527188949500};\\\", \\\"{x:1459,y:963,t:1527188949515};\\\", \\\"{x:1462,y:963,t:1527188949534};\\\", \\\"{x:1466,y:963,t:1527188949550};\\\", \\\"{x:1474,y:964,t:1527188949565};\\\", \\\"{x:1479,y:965,t:1527188949583};\\\", \\\"{x:1482,y:965,t:1527188949599};\\\", \\\"{x:1485,y:967,t:1527188949616};\\\", \\\"{x:1489,y:969,t:1527188949632};\\\", \\\"{x:1497,y:976,t:1527188949649};\\\", \\\"{x:1500,y:978,t:1527188949665};\\\", \\\"{x:1502,y:981,t:1527188949683};\\\", \\\"{x:1503,y:983,t:1527188949699};\\\", \\\"{x:1503,y:985,t:1527188949715};\\\", \\\"{x:1503,y:986,t:1527188949733};\\\", \\\"{x:1504,y:986,t:1527188949809};\\\", \\\"{x:1505,y:986,t:1527188949817};\\\", \\\"{x:1508,y:983,t:1527188949832};\\\", \\\"{x:1515,y:977,t:1527188949849};\\\", \\\"{x:1521,y:973,t:1527188949866};\\\", \\\"{x:1526,y:970,t:1527188949883};\\\", \\\"{x:1533,y:965,t:1527188949899};\\\", \\\"{x:1537,y:964,t:1527188949916};\\\", \\\"{x:1540,y:964,t:1527188949933};\\\", \\\"{x:1542,y:964,t:1527188949949};\\\", \\\"{x:1546,y:963,t:1527188949966};\\\", \\\"{x:1548,y:963,t:1527188949983};\\\", \\\"{x:1551,y:963,t:1527188949999};\\\", \\\"{x:1553,y:963,t:1527188950017};\\\", \\\"{x:1555,y:964,t:1527188950032};\\\", \\\"{x:1559,y:968,t:1527188950049};\\\", \\\"{x:1559,y:971,t:1527188950067};\\\", \\\"{x:1561,y:975,t:1527188950082};\\\", \\\"{x:1561,y:976,t:1527188950099};\\\", \\\"{x:1561,y:977,t:1527188950116};\\\", \\\"{x:1561,y:978,t:1527188950161};\\\", \\\"{x:1564,y:978,t:1527188950169};\\\", \\\"{x:1565,y:978,t:1527188950183};\\\", \\\"{x:1571,y:978,t:1527188950200};\\\", \\\"{x:1580,y:976,t:1527188950216};\\\", \\\"{x:1600,y:972,t:1527188950233};\\\", \\\"{x:1610,y:971,t:1527188950249};\\\", \\\"{x:1617,y:971,t:1527188950266};\\\", \\\"{x:1621,y:971,t:1527188950282};\\\", \\\"{x:1623,y:971,t:1527188950299};\\\", \\\"{x:1627,y:973,t:1527188950316};\\\", \\\"{x:1629,y:974,t:1527188950334};\\\", \\\"{x:1630,y:974,t:1527188950349};\\\", \\\"{x:1623,y:969,t:1527188950393};\\\", \\\"{x:1613,y:959,t:1527188950401};\\\", \\\"{x:1595,y:947,t:1527188950416};\\\", \\\"{x:1456,y:853,t:1527188950433};\\\", \\\"{x:1314,y:771,t:1527188950450};\\\", \\\"{x:1161,y:690,t:1527188950466};\\\", \\\"{x:1018,y:637,t:1527188950484};\\\", \\\"{x:905,y:607,t:1527188950501};\\\", \\\"{x:814,y:584,t:1527188950517};\\\", \\\"{x:750,y:564,t:1527188950533};\\\", \\\"{x:728,y:559,t:1527188950548};\\\", \\\"{x:725,y:559,t:1527188950565};\\\", \\\"{x:725,y:558,t:1527188950581};\\\", \\\"{x:725,y:560,t:1527188950689};\\\", \\\"{x:725,y:561,t:1527188950698};\\\", \\\"{x:723,y:564,t:1527188950715};\\\", \\\"{x:721,y:565,t:1527188950732};\\\", \\\"{x:713,y:568,t:1527188950747};\\\", \\\"{x:702,y:569,t:1527188950765};\\\", \\\"{x:688,y:570,t:1527188950782};\\\", \\\"{x:672,y:570,t:1527188950799};\\\", \\\"{x:653,y:570,t:1527188950815};\\\", \\\"{x:635,y:570,t:1527188950833};\\\", \\\"{x:607,y:563,t:1527188950848};\\\", \\\"{x:593,y:559,t:1527188950865};\\\", \\\"{x:586,y:557,t:1527188950882};\\\", \\\"{x:584,y:557,t:1527188950897};\\\", \\\"{x:583,y:557,t:1527188950915};\\\", \\\"{x:582,y:557,t:1527188950960};\\\", \\\"{x:582,y:558,t:1527188951090};\\\", \\\"{x:584,y:560,t:1527188951120};\\\", \\\"{x:587,y:561,t:1527188951131};\\\", \\\"{x:594,y:564,t:1527188951147};\\\", \\\"{x:601,y:568,t:1527188951166};\\\", \\\"{x:603,y:568,t:1527188951181};\\\", \\\"{x:604,y:568,t:1527188951198};\\\", \\\"{x:605,y:568,t:1527188951214};\\\", \\\"{x:608,y:568,t:1527188951232};\\\", \\\"{x:610,y:568,t:1527188951249};\\\", \\\"{x:611,y:568,t:1527188951265};\\\", \\\"{x:612,y:568,t:1527188951297};\\\", \\\"{x:617,y:568,t:1527188951465};\\\", \\\"{x:618,y:568,t:1527188951488};\\\", \\\"{x:620,y:568,t:1527188951553};\\\", \\\"{x:621,y:568,t:1527188951565};\\\", \\\"{x:623,y:568,t:1527188951584};\\\", \\\"{x:625,y:569,t:1527188951599};\\\", \\\"{x:631,y:572,t:1527188951615};\\\", \\\"{x:638,y:577,t:1527188951632};\\\", \\\"{x:663,y:590,t:1527188951649};\\\", \\\"{x:697,y:607,t:1527188951665};\\\", \\\"{x:745,y:631,t:1527188951682};\\\", \\\"{x:815,y:668,t:1527188951698};\\\", \\\"{x:905,y:718,t:1527188951715};\\\", \\\"{x:1001,y:773,t:1527188951732};\\\", \\\"{x:1113,y:834,t:1527188951750};\\\", \\\"{x:1211,y:887,t:1527188951767};\\\", \\\"{x:1307,y:942,t:1527188951782};\\\", \\\"{x:1402,y:995,t:1527188951799};\\\", \\\"{x:1478,y:1032,t:1527188951816};\\\", \\\"{x:1498,y:1041,t:1527188951832};\\\", \\\"{x:1512,y:1049,t:1527188951849};\\\", \\\"{x:1507,y:1047,t:1527188951905};\\\", \\\"{x:1502,y:1043,t:1527188951916};\\\", \\\"{x:1492,y:1035,t:1527188951932};\\\", \\\"{x:1488,y:1031,t:1527188951950};\\\", \\\"{x:1481,y:1024,t:1527188951967};\\\", \\\"{x:1469,y:1012,t:1527188951982};\\\", \\\"{x:1450,y:998,t:1527188951999};\\\", \\\"{x:1436,y:989,t:1527188952016};\\\", \\\"{x:1426,y:982,t:1527188952038};\\\", \\\"{x:1411,y:968,t:1527188952048};\\\", \\\"{x:1400,y:959,t:1527188952065};\\\", \\\"{x:1394,y:953,t:1527188952082};\\\", \\\"{x:1389,y:949,t:1527188952099};\\\", \\\"{x:1384,y:944,t:1527188952116};\\\", \\\"{x:1381,y:941,t:1527188952132};\\\", \\\"{x:1381,y:940,t:1527188952249};\\\", \\\"{x:1383,y:940,t:1527188952267};\\\", \\\"{x:1387,y:940,t:1527188952283};\\\", \\\"{x:1391,y:940,t:1527188952299};\\\", \\\"{x:1400,y:940,t:1527188952316};\\\", \\\"{x:1410,y:937,t:1527188952333};\\\", \\\"{x:1417,y:936,t:1527188952349};\\\", \\\"{x:1427,y:935,t:1527188952366};\\\", \\\"{x:1439,y:933,t:1527188952383};\\\", \\\"{x:1445,y:931,t:1527188952399};\\\", \\\"{x:1449,y:929,t:1527188952417};\\\", \\\"{x:1453,y:925,t:1527188952433};\\\", \\\"{x:1454,y:923,t:1527188952449};\\\", \\\"{x:1456,y:917,t:1527188952467};\\\", \\\"{x:1459,y:909,t:1527188952483};\\\", \\\"{x:1459,y:900,t:1527188952500};\\\", \\\"{x:1459,y:891,t:1527188952516};\\\", \\\"{x:1459,y:879,t:1527188952533};\\\", \\\"{x:1458,y:864,t:1527188952550};\\\", \\\"{x:1452,y:842,t:1527188952566};\\\", \\\"{x:1445,y:817,t:1527188952583};\\\", \\\"{x:1443,y:807,t:1527188952601};\\\", \\\"{x:1442,y:805,t:1527188952617};\\\", \\\"{x:1442,y:804,t:1527188952633};\\\", \\\"{x:1441,y:804,t:1527188952697};\\\", \\\"{x:1439,y:811,t:1527188952705};\\\", \\\"{x:1436,y:821,t:1527188952716};\\\", \\\"{x:1432,y:840,t:1527188952733};\\\", \\\"{x:1429,y:850,t:1527188952751};\\\", \\\"{x:1428,y:864,t:1527188952767};\\\", \\\"{x:1428,y:880,t:1527188952783};\\\", \\\"{x:1428,y:895,t:1527188952801};\\\", \\\"{x:1428,y:906,t:1527188952816};\\\", \\\"{x:1426,y:914,t:1527188952834};\\\", \\\"{x:1426,y:919,t:1527188952850};\\\", \\\"{x:1425,y:926,t:1527188952867};\\\", \\\"{x:1424,y:929,t:1527188952883};\\\", \\\"{x:1423,y:931,t:1527188952901};\\\", \\\"{x:1423,y:933,t:1527188952918};\\\", \\\"{x:1421,y:937,t:1527188952933};\\\", \\\"{x:1421,y:942,t:1527188952950};\\\", \\\"{x:1421,y:948,t:1527188952967};\\\", \\\"{x:1420,y:952,t:1527188952984};\\\", \\\"{x:1420,y:955,t:1527188953000};\\\", \\\"{x:1420,y:959,t:1527188953017};\\\", \\\"{x:1420,y:960,t:1527188953034};\\\", \\\"{x:1420,y:962,t:1527188953065};\\\", \\\"{x:1420,y:963,t:1527188953089};\\\", \\\"{x:1420,y:965,t:1527188953105};\\\", \\\"{x:1421,y:965,t:1527188953177};\\\", \\\"{x:1425,y:961,t:1527188953186};\\\", \\\"{x:1427,y:955,t:1527188953201};\\\", \\\"{x:1438,y:939,t:1527188953217};\\\", \\\"{x:1441,y:936,t:1527188953234};\\\", \\\"{x:1443,y:934,t:1527188953250};\\\", \\\"{x:1445,y:934,t:1527188953267};\\\", \\\"{x:1447,y:934,t:1527188953285};\\\", \\\"{x:1453,y:934,t:1527188953301};\\\", \\\"{x:1456,y:934,t:1527188953317};\\\", \\\"{x:1464,y:938,t:1527188953334};\\\", \\\"{x:1477,y:945,t:1527188953351};\\\", \\\"{x:1488,y:951,t:1527188953367};\\\", \\\"{x:1493,y:955,t:1527188953385};\\\", \\\"{x:1495,y:958,t:1527188953400};\\\", \\\"{x:1497,y:965,t:1527188953417};\\\", \\\"{x:1498,y:968,t:1527188953434};\\\", \\\"{x:1499,y:971,t:1527188953451};\\\", \\\"{x:1499,y:972,t:1527188953467};\\\", \\\"{x:1499,y:975,t:1527188953485};\\\", \\\"{x:1499,y:976,t:1527188953501};\\\", \\\"{x:1499,y:978,t:1527188953518};\\\", \\\"{x:1499,y:980,t:1527188953535};\\\", \\\"{x:1499,y:981,t:1527188953551};\\\", \\\"{x:1499,y:979,t:1527188953617};\\\", \\\"{x:1499,y:975,t:1527188953634};\\\", \\\"{x:1499,y:969,t:1527188953652};\\\", \\\"{x:1503,y:965,t:1527188953668};\\\", \\\"{x:1507,y:961,t:1527188953684};\\\", \\\"{x:1515,y:957,t:1527188953702};\\\", \\\"{x:1520,y:956,t:1527188953717};\\\", \\\"{x:1527,y:954,t:1527188953734};\\\", \\\"{x:1530,y:954,t:1527188953751};\\\", \\\"{x:1534,y:954,t:1527188953766};\\\", \\\"{x:1537,y:954,t:1527188953784};\\\", \\\"{x:1540,y:955,t:1527188953801};\\\", \\\"{x:1543,y:957,t:1527188953817};\\\", \\\"{x:1545,y:961,t:1527188953834};\\\", \\\"{x:1548,y:965,t:1527188953851};\\\", \\\"{x:1549,y:968,t:1527188953867};\\\", \\\"{x:1550,y:971,t:1527188953884};\\\", \\\"{x:1550,y:975,t:1527188953901};\\\", \\\"{x:1550,y:977,t:1527188953917};\\\", \\\"{x:1550,y:979,t:1527188953934};\\\", \\\"{x:1550,y:977,t:1527188954081};\\\", \\\"{x:1547,y:975,t:1527188954089};\\\", \\\"{x:1542,y:973,t:1527188954105};\\\", \\\"{x:1539,y:972,t:1527188954119};\\\", \\\"{x:1530,y:970,t:1527188954135};\\\", \\\"{x:1526,y:969,t:1527188954152};\\\", \\\"{x:1522,y:969,t:1527188954169};\\\", \\\"{x:1521,y:969,t:1527188954185};\\\", \\\"{x:1517,y:968,t:1527188954201};\\\", \\\"{x:1513,y:968,t:1527188954219};\\\", \\\"{x:1509,y:968,t:1527188954235};\\\", \\\"{x:1503,y:968,t:1527188954252};\\\", \\\"{x:1494,y:967,t:1527188954268};\\\", \\\"{x:1482,y:967,t:1527188954285};\\\", \\\"{x:1471,y:967,t:1527188954302};\\\", \\\"{x:1465,y:967,t:1527188954319};\\\", \\\"{x:1461,y:967,t:1527188954335};\\\", \\\"{x:1458,y:967,t:1527188954352};\\\", \\\"{x:1458,y:966,t:1527188954369};\\\", \\\"{x:1457,y:966,t:1527188954385};\\\", \\\"{x:1453,y:966,t:1527188954402};\\\", \\\"{x:1449,y:966,t:1527188954419};\\\", \\\"{x:1445,y:967,t:1527188954436};\\\", \\\"{x:1444,y:967,t:1527188954451};\\\", \\\"{x:1442,y:968,t:1527188954469};\\\", \\\"{x:1442,y:969,t:1527188954486};\\\", \\\"{x:1441,y:969,t:1527188954689};\\\", \\\"{x:1438,y:970,t:1527188954701};\\\", \\\"{x:1428,y:973,t:1527188954719};\\\", \\\"{x:1417,y:977,t:1527188954735};\\\", \\\"{x:1409,y:978,t:1527188954752};\\\", \\\"{x:1403,y:979,t:1527188954768};\\\", \\\"{x:1401,y:980,t:1527188954785};\\\", \\\"{x:1402,y:980,t:1527188954890};\\\", \\\"{x:1404,y:980,t:1527188954902};\\\", \\\"{x:1407,y:979,t:1527188954919};\\\", \\\"{x:1409,y:979,t:1527188954935};\\\", \\\"{x:1410,y:978,t:1527188954952};\\\", \\\"{x:1412,y:977,t:1527188954968};\\\", \\\"{x:1413,y:976,t:1527188954985};\\\", \\\"{x:1415,y:976,t:1527188955002};\\\", \\\"{x:1417,y:975,t:1527188955025};\\\", \\\"{x:1418,y:975,t:1527188955049};\\\", \\\"{x:1418,y:974,t:1527188955073};\\\", \\\"{x:1419,y:974,t:1527188955086};\\\", \\\"{x:1420,y:974,t:1527188955105};\\\", \\\"{x:1421,y:974,t:1527188955119};\\\", \\\"{x:1422,y:974,t:1527188955136};\\\", \\\"{x:1424,y:974,t:1527188955153};\\\", \\\"{x:1424,y:973,t:1527188955210};\\\", \\\"{x:1425,y:973,t:1527188955505};\\\", \\\"{x:1426,y:973,t:1527188955519};\\\", \\\"{x:1429,y:970,t:1527188955536};\\\", \\\"{x:1434,y:968,t:1527188955553};\\\", \\\"{x:1440,y:965,t:1527188955570};\\\", \\\"{x:1443,y:964,t:1527188955586};\\\", \\\"{x:1446,y:964,t:1527188955602};\\\", \\\"{x:1451,y:962,t:1527188955620};\\\", \\\"{x:1458,y:962,t:1527188955637};\\\", \\\"{x:1464,y:962,t:1527188955653};\\\", \\\"{x:1469,y:962,t:1527188955670};\\\", \\\"{x:1472,y:962,t:1527188955687};\\\", \\\"{x:1474,y:962,t:1527188955702};\\\", \\\"{x:1475,y:962,t:1527188955720};\\\", \\\"{x:1477,y:962,t:1527188955737};\\\", \\\"{x:1480,y:964,t:1527188955752};\\\", \\\"{x:1481,y:965,t:1527188955777};\\\", \\\"{x:1481,y:967,t:1527188955817};\\\", \\\"{x:1480,y:968,t:1527188955858};\\\", \\\"{x:1479,y:968,t:1527188955873};\\\", \\\"{x:1478,y:968,t:1527188955889};\\\", \\\"{x:1477,y:968,t:1527188955913};\\\", \\\"{x:1477,y:967,t:1527188956026};\\\", \\\"{x:1478,y:967,t:1527188956037};\\\", \\\"{x:1481,y:965,t:1527188956053};\\\", \\\"{x:1485,y:964,t:1527188956070};\\\", \\\"{x:1491,y:963,t:1527188956086};\\\", \\\"{x:1493,y:961,t:1527188956104};\\\", \\\"{x:1496,y:961,t:1527188956120};\\\", \\\"{x:1502,y:961,t:1527188956137};\\\", \\\"{x:1506,y:961,t:1527188956153};\\\", \\\"{x:1508,y:961,t:1527188956170};\\\", \\\"{x:1508,y:962,t:1527188956225};\\\", \\\"{x:1509,y:964,t:1527188956240};\\\", \\\"{x:1510,y:966,t:1527188956264};\\\", \\\"{x:1510,y:967,t:1527188956280};\\\", \\\"{x:1511,y:967,t:1527188956368};\\\", \\\"{x:1512,y:967,t:1527188956392};\\\", \\\"{x:1514,y:967,t:1527188956403};\\\", \\\"{x:1518,y:967,t:1527188956420};\\\", \\\"{x:1526,y:966,t:1527188956436};\\\", \\\"{x:1534,y:963,t:1527188956453};\\\", \\\"{x:1539,y:962,t:1527188956470};\\\", \\\"{x:1543,y:962,t:1527188956486};\\\", \\\"{x:1547,y:959,t:1527188956503};\\\", \\\"{x:1551,y:959,t:1527188956520};\\\", \\\"{x:1553,y:960,t:1527188956536};\\\", \\\"{x:1555,y:961,t:1527188956553};\\\", \\\"{x:1557,y:962,t:1527188956570};\\\", \\\"{x:1560,y:963,t:1527188956586};\\\", \\\"{x:1561,y:964,t:1527188956603};\\\", \\\"{x:1564,y:965,t:1527188956620};\\\", \\\"{x:1565,y:966,t:1527188956637};\\\", \\\"{x:1566,y:966,t:1527188956653};\\\", \\\"{x:1567,y:966,t:1527188956671};\\\", \\\"{x:1568,y:967,t:1527188956686};\\\", \\\"{x:1569,y:968,t:1527188956703};\\\", \\\"{x:1570,y:969,t:1527188956736};\\\", \\\"{x:1571,y:969,t:1527188956777};\\\", \\\"{x:1572,y:969,t:1527188956809};\\\", \\\"{x:1573,y:969,t:1527188956841};\\\", \\\"{x:1574,y:969,t:1527188956874};\\\", \\\"{x:1575,y:969,t:1527188956977};\\\", \\\"{x:1574,y:970,t:1527188957362};\\\", \\\"{x:1572,y:970,t:1527188957371};\\\", \\\"{x:1567,y:971,t:1527188957388};\\\", \\\"{x:1562,y:972,t:1527188957405};\\\", \\\"{x:1562,y:973,t:1527188957421};\\\", \\\"{x:1561,y:973,t:1527188957438};\\\", \\\"{x:1559,y:973,t:1527188957689};\\\", \\\"{x:1554,y:973,t:1527188957705};\\\", \\\"{x:1545,y:973,t:1527188957721};\\\", \\\"{x:1531,y:973,t:1527188957737};\\\", \\\"{x:1518,y:973,t:1527188957754};\\\", \\\"{x:1507,y:973,t:1527188957771};\\\", \\\"{x:1503,y:973,t:1527188957787};\\\", \\\"{x:1500,y:973,t:1527188957805};\\\", \\\"{x:1499,y:973,t:1527188957825};\\\", \\\"{x:1498,y:973,t:1527188957840};\\\", \\\"{x:1496,y:973,t:1527188957865};\\\", \\\"{x:1495,y:973,t:1527188957872};\\\", \\\"{x:1494,y:973,t:1527188957889};\\\", \\\"{x:1490,y:973,t:1527188957905};\\\", \\\"{x:1485,y:973,t:1527188957921};\\\", \\\"{x:1479,y:973,t:1527188957939};\\\", \\\"{x:1473,y:973,t:1527188957955};\\\", \\\"{x:1467,y:973,t:1527188957971};\\\", \\\"{x:1461,y:973,t:1527188957988};\\\", \\\"{x:1458,y:973,t:1527188958004};\\\", \\\"{x:1457,y:973,t:1527188958224};\\\", \\\"{x:1457,y:972,t:1527188958240};\\\", \\\"{x:1457,y:970,t:1527188958255};\\\", \\\"{x:1456,y:965,t:1527188958271};\\\", \\\"{x:1451,y:947,t:1527188958288};\\\", \\\"{x:1449,y:938,t:1527188958305};\\\", \\\"{x:1448,y:930,t:1527188958321};\\\", \\\"{x:1448,y:924,t:1527188958338};\\\", \\\"{x:1448,y:909,t:1527188958355};\\\", \\\"{x:1448,y:887,t:1527188958371};\\\", \\\"{x:1447,y:865,t:1527188958388};\\\", \\\"{x:1444,y:849,t:1527188958405};\\\", \\\"{x:1444,y:827,t:1527188958421};\\\", \\\"{x:1444,y:800,t:1527188958438};\\\", \\\"{x:1442,y:779,t:1527188958455};\\\", \\\"{x:1439,y:763,t:1527188958472};\\\", \\\"{x:1438,y:741,t:1527188958488};\\\", \\\"{x:1435,y:726,t:1527188958506};\\\", \\\"{x:1432,y:713,t:1527188958521};\\\", \\\"{x:1432,y:704,t:1527188958538};\\\", \\\"{x:1432,y:697,t:1527188958555};\\\", \\\"{x:1431,y:686,t:1527188958571};\\\", \\\"{x:1430,y:677,t:1527188958588};\\\", \\\"{x:1429,y:676,t:1527188958605};\\\", \\\"{x:1429,y:677,t:1527188958656};\\\", \\\"{x:1427,y:704,t:1527188958672};\\\", \\\"{x:1427,y:729,t:1527188958688};\\\", \\\"{x:1427,y:756,t:1527188958705};\\\", \\\"{x:1427,y:780,t:1527188958722};\\\", \\\"{x:1427,y:799,t:1527188958738};\\\", \\\"{x:1430,y:820,t:1527188958755};\\\", \\\"{x:1432,y:832,t:1527188958772};\\\", \\\"{x:1436,y:842,t:1527188958788};\\\", \\\"{x:1436,y:846,t:1527188958805};\\\", \\\"{x:1437,y:849,t:1527188958822};\\\", \\\"{x:1438,y:849,t:1527188958838};\\\", \\\"{x:1438,y:850,t:1527188958855};\\\", \\\"{x:1437,y:854,t:1527188960960};\\\", \\\"{x:1426,y:856,t:1527188960975};\\\", \\\"{x:1384,y:868,t:1527188960990};\\\", \\\"{x:1307,y:886,t:1527188961007};\\\", \\\"{x:1124,y:890,t:1527188961024};\\\", \\\"{x:977,y:890,t:1527188961040};\\\", \\\"{x:837,y:880,t:1527188961057};\\\", \\\"{x:699,y:859,t:1527188961074};\\\", \\\"{x:587,y:841,t:1527188961090};\\\", \\\"{x:525,y:829,t:1527188961107};\\\", \\\"{x:505,y:821,t:1527188961124};\\\", \\\"{x:498,y:815,t:1527188961140};\\\", \\\"{x:497,y:810,t:1527188961157};\\\", \\\"{x:497,y:804,t:1527188961175};\\\", \\\"{x:497,y:800,t:1527188961190};\\\", \\\"{x:498,y:792,t:1527188961207};\\\", \\\"{x:499,y:769,t:1527188961224};\\\", \\\"{x:498,y:753,t:1527188961240};\\\", \\\"{x:497,y:744,t:1527188961257};\\\", \\\"{x:497,y:739,t:1527188961274};\\\", \\\"{x:497,y:736,t:1527188961290};\\\", \\\"{x:498,y:736,t:1527188961312};\\\", \\\"{x:499,y:735,t:1527188961319};\\\", \\\"{x:501,y:735,t:1527188961337};\\\", \\\"{x:502,y:735,t:1527188961353};\\\", \\\"{x:503,y:735,t:1527188961376};\\\", \\\"{x:504,y:735,t:1527188961386};\\\", \\\"{x:505,y:735,t:1527188961407};\\\", \\\"{x:506,y:735,t:1527188961506};\\\", \\\"{x:506,y:735,t:1527188961572};\\\", \\\"{x:506,y:733,t:1527188961809};\\\", \\\"{x:504,y:733,t:1527188961823};\\\", \\\"{x:496,y:728,t:1527188961840};\\\", \\\"{x:494,y:728,t:1527188962040};\\\", \\\"{x:490,y:728,t:1527188962080};\\\", \\\"{x:486,y:727,t:1527188962091};\\\", \\\"{x:474,y:723,t:1527188962107};\\\", \\\"{x:449,y:718,t:1527188962123};\\\", \\\"{x:429,y:712,t:1527188962140};\\\", \\\"{x:417,y:707,t:1527188962158};\\\", \\\"{x:409,y:702,t:1527188962173};\\\", \\\"{x:406,y:699,t:1527188962190};\\\", \\\"{x:405,y:698,t:1527188962207};\\\", \\\"{x:404,y:697,t:1527188962223};\\\", \\\"{x:404,y:694,t:1527188962239};\\\", \\\"{x:404,y:693,t:1527188962258};\\\", \\\"{x:404,y:692,t:1527188962273};\\\", \\\"{x:403,y:689,t:1527188962290};\\\", \\\"{x:403,y:687,t:1527188962307};\\\", \\\"{x:403,y:686,t:1527188962323};\\\", \\\"{x:403,y:684,t:1527188962340};\\\", \\\"{x:403,y:683,t:1527188962368};\\\" ] }, { \\\"rt\\\": 9372, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 354489, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:411,y:682,t:1527188965192};\\\", \\\"{x:475,y:695,t:1527188965210};\\\", \\\"{x:574,y:714,t:1527188965227};\\\", \\\"{x:698,y:731,t:1527188965243};\\\", \\\"{x:837,y:750,t:1527188965260};\\\", \\\"{x:977,y:767,t:1527188965276};\\\", \\\"{x:1091,y:767,t:1527188965293};\\\", \\\"{x:1177,y:766,t:1527188965310};\\\", \\\"{x:1230,y:754,t:1527188965327};\\\", \\\"{x:1248,y:745,t:1527188965344};\\\", \\\"{x:1253,y:738,t:1527188965360};\\\", \\\"{x:1253,y:724,t:1527188965376};\\\", \\\"{x:1253,y:708,t:1527188965394};\\\", \\\"{x:1250,y:687,t:1527188965409};\\\", \\\"{x:1247,y:666,t:1527188965427};\\\", \\\"{x:1247,y:656,t:1527188965444};\\\", \\\"{x:1249,y:646,t:1527188965460};\\\", \\\"{x:1249,y:632,t:1527188965477};\\\", \\\"{x:1249,y:620,t:1527188965494};\\\", \\\"{x:1248,y:613,t:1527188965509};\\\", \\\"{x:1246,y:609,t:1527188965527};\\\", \\\"{x:1246,y:606,t:1527188965543};\\\", \\\"{x:1244,y:602,t:1527188965559};\\\", \\\"{x:1244,y:601,t:1527188965576};\\\", \\\"{x:1244,y:599,t:1527188965608};\\\", \\\"{x:1244,y:598,t:1527188965616};\\\", \\\"{x:1244,y:597,t:1527188965648};\\\", \\\"{x:1245,y:594,t:1527188965664};\\\", \\\"{x:1246,y:593,t:1527188965676};\\\", \\\"{x:1248,y:592,t:1527188965693};\\\", \\\"{x:1248,y:590,t:1527188965709};\\\", \\\"{x:1249,y:589,t:1527188965727};\\\", \\\"{x:1251,y:587,t:1527188965744};\\\", \\\"{x:1258,y:582,t:1527188965760};\\\", \\\"{x:1265,y:579,t:1527188965776};\\\", \\\"{x:1267,y:577,t:1527188965793};\\\", \\\"{x:1269,y:576,t:1527188965811};\\\", \\\"{x:1269,y:575,t:1527188965832};\\\", \\\"{x:1269,y:573,t:1527188965847};\\\", \\\"{x:1270,y:571,t:1527188965860};\\\", \\\"{x:1271,y:570,t:1527188965876};\\\", \\\"{x:1271,y:569,t:1527188965893};\\\", \\\"{x:1271,y:568,t:1527188965911};\\\", \\\"{x:1271,y:567,t:1527188965968};\\\", \\\"{x:1271,y:566,t:1527188966000};\\\", \\\"{x:1273,y:566,t:1527188966015};\\\", \\\"{x:1274,y:566,t:1527188966026};\\\", \\\"{x:1278,y:566,t:1527188966043};\\\", \\\"{x:1281,y:566,t:1527188966060};\\\", \\\"{x:1283,y:566,t:1527188966120};\\\", \\\"{x:1283,y:565,t:1527188966512};\\\", \\\"{x:1283,y:564,t:1527188966527};\\\", \\\"{x:1280,y:563,t:1527188966832};\\\", \\\"{x:1272,y:563,t:1527188966845};\\\", \\\"{x:1252,y:568,t:1527188966861};\\\", \\\"{x:1219,y:577,t:1527188966878};\\\", \\\"{x:1171,y:592,t:1527188966895};\\\", \\\"{x:1116,y:607,t:1527188966911};\\\", \\\"{x:1050,y:624,t:1527188966927};\\\", \\\"{x:960,y:632,t:1527188966944};\\\", \\\"{x:907,y:632,t:1527188966960};\\\", \\\"{x:862,y:632,t:1527188966978};\\\", \\\"{x:820,y:632,t:1527188966995};\\\", \\\"{x:789,y:632,t:1527188967010};\\\", \\\"{x:751,y:631,t:1527188967027};\\\", \\\"{x:711,y:624,t:1527188967045};\\\", \\\"{x:672,y:618,t:1527188967060};\\\", \\\"{x:637,y:612,t:1527188967078};\\\", \\\"{x:608,y:610,t:1527188967093};\\\", \\\"{x:572,y:602,t:1527188967111};\\\", \\\"{x:545,y:598,t:1527188967128};\\\", \\\"{x:532,y:594,t:1527188967145};\\\", \\\"{x:530,y:593,t:1527188967162};\\\", \\\"{x:528,y:591,t:1527188967177};\\\", \\\"{x:533,y:585,t:1527188967194};\\\", \\\"{x:549,y:575,t:1527188967211};\\\", \\\"{x:564,y:565,t:1527188967227};\\\", \\\"{x:580,y:553,t:1527188967245};\\\", \\\"{x:594,y:543,t:1527188967261};\\\", \\\"{x:607,y:537,t:1527188967277};\\\", \\\"{x:613,y:532,t:1527188967294};\\\", \\\"{x:617,y:530,t:1527188967311};\\\", \\\"{x:618,y:529,t:1527188967327};\\\", \\\"{x:619,y:526,t:1527188967345};\\\", \\\"{x:619,y:524,t:1527188967362};\\\", \\\"{x:619,y:523,t:1527188967379};\\\", \\\"{x:619,y:521,t:1527188967395};\\\", \\\"{x:619,y:518,t:1527188967412};\\\", \\\"{x:619,y:517,t:1527188967429};\\\", \\\"{x:619,y:514,t:1527188967445};\\\", \\\"{x:619,y:512,t:1527188967462};\\\", \\\"{x:619,y:510,t:1527188967478};\\\", \\\"{x:619,y:509,t:1527188967494};\\\", \\\"{x:619,y:506,t:1527188967511};\\\", \\\"{x:619,y:503,t:1527188967527};\\\", \\\"{x:618,y:502,t:1527188967545};\\\", \\\"{x:625,y:502,t:1527188967872};\\\", \\\"{x:634,y:502,t:1527188967879};\\\", \\\"{x:645,y:503,t:1527188967896};\\\", \\\"{x:667,y:505,t:1527188967911};\\\", \\\"{x:707,y:516,t:1527188967928};\\\", \\\"{x:752,y:529,t:1527188967946};\\\", \\\"{x:781,y:535,t:1527188967961};\\\", \\\"{x:805,y:542,t:1527188967978};\\\", \\\"{x:824,y:551,t:1527188967995};\\\", \\\"{x:839,y:558,t:1527188968011};\\\", \\\"{x:847,y:563,t:1527188968029};\\\", \\\"{x:852,y:567,t:1527188968046};\\\", \\\"{x:855,y:569,t:1527188968061};\\\", \\\"{x:859,y:573,t:1527188968078};\\\", \\\"{x:861,y:575,t:1527188968095};\\\", \\\"{x:863,y:577,t:1527188968112};\\\", \\\"{x:859,y:576,t:1527188968224};\\\", \\\"{x:855,y:574,t:1527188968232};\\\", \\\"{x:851,y:571,t:1527188968246};\\\", \\\"{x:844,y:567,t:1527188968263};\\\", \\\"{x:838,y:563,t:1527188968280};\\\", \\\"{x:834,y:561,t:1527188968296};\\\", \\\"{x:834,y:560,t:1527188968312};\\\", \\\"{x:834,y:559,t:1527188968425};\\\", \\\"{x:834,y:558,t:1527188968433};\\\", \\\"{x:834,y:557,t:1527188968446};\\\", \\\"{x:834,y:555,t:1527188968464};\\\", \\\"{x:835,y:550,t:1527188968479};\\\", \\\"{x:836,y:546,t:1527188968496};\\\", \\\"{x:836,y:542,t:1527188968512};\\\", \\\"{x:836,y:541,t:1527188969080};\\\", \\\"{x:837,y:543,t:1527188969096};\\\", \\\"{x:837,y:550,t:1527188969113};\\\", \\\"{x:837,y:564,t:1527188969130};\\\", \\\"{x:837,y:575,t:1527188969147};\\\", \\\"{x:837,y:585,t:1527188969163};\\\", \\\"{x:835,y:593,t:1527188969180};\\\", \\\"{x:833,y:601,t:1527188969197};\\\", \\\"{x:832,y:610,t:1527188969213};\\\", \\\"{x:830,y:613,t:1527188969230};\\\", \\\"{x:829,y:617,t:1527188969246};\\\", \\\"{x:826,y:623,t:1527188969263};\\\", \\\"{x:823,y:627,t:1527188969281};\\\", \\\"{x:816,y:638,t:1527188969296};\\\", \\\"{x:812,y:645,t:1527188969312};\\\", \\\"{x:809,y:649,t:1527188969330};\\\", \\\"{x:804,y:655,t:1527188969346};\\\", \\\"{x:798,y:659,t:1527188969362};\\\", \\\"{x:793,y:662,t:1527188969379};\\\", \\\"{x:788,y:666,t:1527188969396};\\\", \\\"{x:783,y:671,t:1527188969413};\\\", \\\"{x:781,y:673,t:1527188969430};\\\", \\\"{x:779,y:674,t:1527188969445};\\\", \\\"{x:776,y:677,t:1527188969463};\\\", \\\"{x:774,y:678,t:1527188969479};\\\", \\\"{x:771,y:680,t:1527188969496};\\\", \\\"{x:768,y:683,t:1527188969512};\\\", \\\"{x:766,y:685,t:1527188969529};\\\", \\\"{x:763,y:687,t:1527188969546};\\\", \\\"{x:759,y:690,t:1527188969563};\\\", \\\"{x:755,y:692,t:1527188969578};\\\", \\\"{x:750,y:696,t:1527188969596};\\\", \\\"{x:745,y:700,t:1527188969613};\\\", \\\"{x:740,y:703,t:1527188969629};\\\", \\\"{x:734,y:707,t:1527188969645};\\\", \\\"{x:729,y:710,t:1527188969662};\\\", \\\"{x:721,y:714,t:1527188969678};\\\", \\\"{x:717,y:716,t:1527188969696};\\\", \\\"{x:709,y:720,t:1527188969712};\\\", \\\"{x:703,y:723,t:1527188969728};\\\", \\\"{x:697,y:724,t:1527188969746};\\\", \\\"{x:691,y:726,t:1527188969762};\\\", \\\"{x:689,y:727,t:1527188969779};\\\", \\\"{x:686,y:727,t:1527188969796};\\\", \\\"{x:683,y:728,t:1527188969812};\\\", \\\"{x:679,y:729,t:1527188969829};\\\", \\\"{x:678,y:729,t:1527188969846};\\\", \\\"{x:677,y:729,t:1527188969862};\\\", \\\"{x:676,y:729,t:1527188969889};\\\", \\\"{x:675,y:729,t:1527188969897};\\\", \\\"{x:674,y:730,t:1527188969912};\\\", \\\"{x:671,y:730,t:1527188969930};\\\", \\\"{x:670,y:730,t:1527188969946};\\\", \\\"{x:667,y:731,t:1527188969962};\\\", \\\"{x:664,y:731,t:1527188969979};\\\", \\\"{x:662,y:731,t:1527188969995};\\\", \\\"{x:660,y:731,t:1527188970012};\\\", \\\"{x:657,y:731,t:1527188970029};\\\", \\\"{x:654,y:731,t:1527188970045};\\\", \\\"{x:651,y:731,t:1527188970062};\\\", \\\"{x:648,y:731,t:1527188970079};\\\", \\\"{x:645,y:731,t:1527188970095};\\\", \\\"{x:643,y:731,t:1527188970112};\\\", \\\"{x:637,y:731,t:1527188970128};\\\", \\\"{x:630,y:731,t:1527188970145};\\\", \\\"{x:621,y:729,t:1527188970162};\\\", \\\"{x:612,y:728,t:1527188970179};\\\", \\\"{x:603,y:727,t:1527188970195};\\\", \\\"{x:596,y:725,t:1527188970212};\\\", \\\"{x:589,y:725,t:1527188970228};\\\", \\\"{x:583,y:724,t:1527188970245};\\\", \\\"{x:578,y:723,t:1527188970262};\\\", \\\"{x:571,y:721,t:1527188970278};\\\", \\\"{x:566,y:721,t:1527188970295};\\\", \\\"{x:565,y:721,t:1527188970312};\\\", \\\"{x:564,y:721,t:1527188970328};\\\", \\\"{x:563,y:721,t:1527188970345};\\\", \\\"{x:561,y:721,t:1527188970364};\\\", \\\"{x:558,y:722,t:1527188970378};\\\", \\\"{x:556,y:723,t:1527188970397};\\\", \\\"{x:555,y:724,t:1527188970413};\\\", \\\"{x:555,y:727,t:1527188970432};\\\", \\\"{x:554,y:728,t:1527188970448};\\\", \\\"{x:553,y:729,t:1527188970464};\\\", \\\"{x:552,y:731,t:1527188970480};\\\", \\\"{x:551,y:731,t:1527188970498};\\\", \\\"{x:548,y:732,t:1527188970514};\\\", \\\"{x:545,y:734,t:1527188970530};\\\", \\\"{x:544,y:735,t:1527188970548};\\\", \\\"{x:543,y:735,t:1527188970564};\\\", \\\"{x:542,y:735,t:1527188970624};\\\" ] }, { \\\"rt\\\": 21775, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 377501, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:735,t:1527188976385};\\\", \\\"{x:580,y:734,t:1527188976404};\\\", \\\"{x:633,y:734,t:1527188976419};\\\", \\\"{x:722,y:734,t:1527188976436};\\\", \\\"{x:830,y:734,t:1527188976452};\\\", \\\"{x:938,y:734,t:1527188976469};\\\", \\\"{x:1053,y:737,t:1527188976485};\\\", \\\"{x:1154,y:742,t:1527188976502};\\\", \\\"{x:1234,y:742,t:1527188976519};\\\", \\\"{x:1290,y:742,t:1527188976535};\\\", \\\"{x:1333,y:740,t:1527188976552};\\\", \\\"{x:1350,y:735,t:1527188976569};\\\", \\\"{x:1364,y:726,t:1527188976585};\\\", \\\"{x:1371,y:719,t:1527188976602};\\\", \\\"{x:1377,y:710,t:1527188976619};\\\", \\\"{x:1383,y:694,t:1527188976635};\\\", \\\"{x:1388,y:685,t:1527188976652};\\\", \\\"{x:1393,y:671,t:1527188976669};\\\", \\\"{x:1396,y:659,t:1527188976686};\\\", \\\"{x:1397,y:649,t:1527188976702};\\\", \\\"{x:1397,y:641,t:1527188976719};\\\", \\\"{x:1394,y:627,t:1527188976737};\\\", \\\"{x:1390,y:617,t:1527188976752};\\\", \\\"{x:1381,y:607,t:1527188976769};\\\", \\\"{x:1368,y:598,t:1527188976787};\\\", \\\"{x:1360,y:592,t:1527188976802};\\\", \\\"{x:1348,y:586,t:1527188976819};\\\", \\\"{x:1337,y:581,t:1527188976837};\\\", \\\"{x:1331,y:579,t:1527188976852};\\\", \\\"{x:1326,y:576,t:1527188976869};\\\", \\\"{x:1322,y:574,t:1527188976886};\\\", \\\"{x:1320,y:573,t:1527188976902};\\\", \\\"{x:1316,y:571,t:1527188976920};\\\", \\\"{x:1315,y:571,t:1527188976960};\\\", \\\"{x:1314,y:572,t:1527188977009};\\\", \\\"{x:1314,y:573,t:1527188977020};\\\", \\\"{x:1314,y:575,t:1527188977037};\\\", \\\"{x:1314,y:577,t:1527188977053};\\\", \\\"{x:1313,y:580,t:1527188977069};\\\", \\\"{x:1313,y:584,t:1527188977086};\\\", \\\"{x:1313,y:588,t:1527188977102};\\\", \\\"{x:1313,y:594,t:1527188977120};\\\", \\\"{x:1313,y:601,t:1527188977136};\\\", \\\"{x:1314,y:609,t:1527188977153};\\\", \\\"{x:1316,y:614,t:1527188977169};\\\", \\\"{x:1319,y:619,t:1527188977187};\\\", \\\"{x:1323,y:623,t:1527188977204};\\\", \\\"{x:1330,y:631,t:1527188977220};\\\", \\\"{x:1341,y:637,t:1527188977236};\\\", \\\"{x:1349,y:641,t:1527188977254};\\\", \\\"{x:1359,y:642,t:1527188977270};\\\", \\\"{x:1375,y:646,t:1527188977287};\\\", \\\"{x:1390,y:648,t:1527188977304};\\\", \\\"{x:1400,y:649,t:1527188977320};\\\", \\\"{x:1414,y:651,t:1527188977340};\\\", \\\"{x:1421,y:651,t:1527188977356};\\\", \\\"{x:1427,y:651,t:1527188977373};\\\", \\\"{x:1433,y:649,t:1527188977390};\\\", \\\"{x:1437,y:649,t:1527188977407};\\\", \\\"{x:1437,y:648,t:1527188977423};\\\", \\\"{x:1438,y:648,t:1527188977445};\\\", \\\"{x:1439,y:647,t:1527188977457};\\\", \\\"{x:1440,y:647,t:1527188977473};\\\", \\\"{x:1440,y:646,t:1527188977490};\\\", \\\"{x:1442,y:644,t:1527188977507};\\\", \\\"{x:1444,y:641,t:1527188977523};\\\", \\\"{x:1446,y:637,t:1527188977540};\\\", \\\"{x:1448,y:633,t:1527188977559};\\\", \\\"{x:1450,y:631,t:1527188977573};\\\", \\\"{x:1451,y:631,t:1527188977589};\\\", \\\"{x:1452,y:629,t:1527188977606};\\\", \\\"{x:1453,y:627,t:1527188977623};\\\", \\\"{x:1452,y:627,t:1527188979093};\\\", \\\"{x:1451,y:627,t:1527188979108};\\\", \\\"{x:1450,y:627,t:1527188979124};\\\", \\\"{x:1447,y:627,t:1527188981284};\\\", \\\"{x:1446,y:627,t:1527188981293};\\\", \\\"{x:1442,y:627,t:1527188981309};\\\", \\\"{x:1440,y:628,t:1527188981325};\\\", \\\"{x:1437,y:629,t:1527188981343};\\\", \\\"{x:1435,y:629,t:1527188981360};\\\", \\\"{x:1431,y:629,t:1527188981375};\\\", \\\"{x:1426,y:630,t:1527188981393};\\\", \\\"{x:1420,y:631,t:1527188981410};\\\", \\\"{x:1416,y:631,t:1527188981425};\\\", \\\"{x:1410,y:631,t:1527188981442};\\\", \\\"{x:1405,y:631,t:1527188981460};\\\", \\\"{x:1402,y:631,t:1527188981476};\\\", \\\"{x:1397,y:631,t:1527188981492};\\\", \\\"{x:1391,y:632,t:1527188981510};\\\", \\\"{x:1387,y:633,t:1527188981526};\\\", \\\"{x:1382,y:633,t:1527188981543};\\\", \\\"{x:1378,y:634,t:1527188981559};\\\", \\\"{x:1374,y:634,t:1527188981577};\\\", \\\"{x:1369,y:635,t:1527188981593};\\\", \\\"{x:1366,y:636,t:1527188981610};\\\", \\\"{x:1362,y:636,t:1527188981627};\\\", \\\"{x:1359,y:636,t:1527188981643};\\\", \\\"{x:1353,y:636,t:1527188981660};\\\", \\\"{x:1351,y:636,t:1527188981677};\\\", \\\"{x:1349,y:636,t:1527188981693};\\\", \\\"{x:1348,y:636,t:1527188981716};\\\", \\\"{x:1354,y:636,t:1527188982420};\\\", \\\"{x:1363,y:636,t:1527188982428};\\\", \\\"{x:1384,y:636,t:1527188982444};\\\", \\\"{x:1405,y:636,t:1527188982460};\\\", \\\"{x:1426,y:636,t:1527188982477};\\\", \\\"{x:1446,y:636,t:1527188982494};\\\", \\\"{x:1465,y:636,t:1527188982511};\\\", \\\"{x:1479,y:636,t:1527188982527};\\\", \\\"{x:1489,y:636,t:1527188982544};\\\", \\\"{x:1494,y:636,t:1527188982560};\\\", \\\"{x:1498,y:636,t:1527188982576};\\\", \\\"{x:1500,y:636,t:1527188982593};\\\", \\\"{x:1501,y:636,t:1527188982732};\\\", \\\"{x:1503,y:636,t:1527188982744};\\\", \\\"{x:1507,y:635,t:1527188982761};\\\", \\\"{x:1511,y:634,t:1527188982777};\\\", \\\"{x:1516,y:634,t:1527188982795};\\\", \\\"{x:1519,y:634,t:1527188982811};\\\", \\\"{x:1522,y:634,t:1527188982827};\\\", \\\"{x:1528,y:634,t:1527188982844};\\\", \\\"{x:1533,y:632,t:1527188982861};\\\", \\\"{x:1541,y:632,t:1527188982877};\\\", \\\"{x:1548,y:632,t:1527188982894};\\\", \\\"{x:1555,y:631,t:1527188982911};\\\", \\\"{x:1562,y:631,t:1527188982928};\\\", \\\"{x:1567,y:631,t:1527188982944};\\\", \\\"{x:1569,y:631,t:1527188982961};\\\", \\\"{x:1570,y:631,t:1527188982978};\\\", \\\"{x:1571,y:631,t:1527188982994};\\\", \\\"{x:1567,y:631,t:1527188983492};\\\", \\\"{x:1561,y:631,t:1527188983500};\\\", \\\"{x:1553,y:631,t:1527188983511};\\\", \\\"{x:1539,y:631,t:1527188983528};\\\", \\\"{x:1529,y:631,t:1527188983545};\\\", \\\"{x:1522,y:632,t:1527188983561};\\\", \\\"{x:1517,y:632,t:1527188983577};\\\", \\\"{x:1510,y:632,t:1527188983595};\\\", \\\"{x:1504,y:633,t:1527188983610};\\\", \\\"{x:1492,y:635,t:1527188983627};\\\", \\\"{x:1483,y:637,t:1527188983645};\\\", \\\"{x:1473,y:637,t:1527188983660};\\\", \\\"{x:1464,y:639,t:1527188983677};\\\", \\\"{x:1459,y:641,t:1527188983694};\\\", \\\"{x:1455,y:641,t:1527188983711};\\\", \\\"{x:1452,y:641,t:1527188983727};\\\", \\\"{x:1451,y:641,t:1527188983745};\\\", \\\"{x:1450,y:642,t:1527188983771};\\\", \\\"{x:1448,y:643,t:1527188983788};\\\", \\\"{x:1447,y:644,t:1527188983796};\\\", \\\"{x:1446,y:645,t:1527188983820};\\\", \\\"{x:1445,y:646,t:1527188983859};\\\", \\\"{x:1444,y:646,t:1527188983868};\\\", \\\"{x:1443,y:647,t:1527188983877};\\\", \\\"{x:1439,y:650,t:1527188983895};\\\", \\\"{x:1435,y:652,t:1527188983912};\\\", \\\"{x:1430,y:656,t:1527188983927};\\\", \\\"{x:1418,y:667,t:1527188983945};\\\", \\\"{x:1400,y:680,t:1527188983962};\\\", \\\"{x:1382,y:691,t:1527188983978};\\\", \\\"{x:1370,y:697,t:1527188983995};\\\", \\\"{x:1356,y:703,t:1527188984011};\\\", \\\"{x:1350,y:705,t:1527188984028};\\\", \\\"{x:1347,y:707,t:1527188984045};\\\", \\\"{x:1347,y:706,t:1527188984197};\\\", \\\"{x:1347,y:702,t:1527188984212};\\\", \\\"{x:1347,y:700,t:1527188984228};\\\", \\\"{x:1347,y:699,t:1527188984245};\\\", \\\"{x:1347,y:697,t:1527188984276};\\\", \\\"{x:1347,y:696,t:1527188984292};\\\", \\\"{x:1347,y:694,t:1527188984324};\\\", \\\"{x:1347,y:693,t:1527188984372};\\\", \\\"{x:1347,y:698,t:1527188987611};\\\", \\\"{x:1347,y:700,t:1527188987619};\\\", \\\"{x:1347,y:702,t:1527188987631};\\\", \\\"{x:1347,y:708,t:1527188987649};\\\", \\\"{x:1347,y:713,t:1527188987663};\\\", \\\"{x:1348,y:716,t:1527188987681};\\\", \\\"{x:1348,y:717,t:1527188987699};\\\", \\\"{x:1349,y:718,t:1527188987715};\\\", \\\"{x:1349,y:719,t:1527188987731};\\\", \\\"{x:1350,y:723,t:1527188987748};\\\", \\\"{x:1350,y:726,t:1527188987765};\\\", \\\"{x:1350,y:729,t:1527188987781};\\\", \\\"{x:1352,y:732,t:1527188987798};\\\", \\\"{x:1353,y:736,t:1527188987815};\\\", \\\"{x:1355,y:742,t:1527188987831};\\\", \\\"{x:1356,y:746,t:1527188987849};\\\", \\\"{x:1357,y:750,t:1527188987865};\\\", \\\"{x:1358,y:753,t:1527188987881};\\\", \\\"{x:1359,y:757,t:1527188987898};\\\", \\\"{x:1360,y:760,t:1527188987915};\\\", \\\"{x:1360,y:764,t:1527188987931};\\\", \\\"{x:1362,y:772,t:1527188987948};\\\", \\\"{x:1363,y:776,t:1527188987965};\\\", \\\"{x:1363,y:780,t:1527188987982};\\\", \\\"{x:1363,y:784,t:1527188987998};\\\", \\\"{x:1361,y:787,t:1527188988015};\\\", \\\"{x:1358,y:790,t:1527188988031};\\\", \\\"{x:1357,y:792,t:1527188988048};\\\", \\\"{x:1356,y:792,t:1527188988065};\\\", \\\"{x:1355,y:794,t:1527188988081};\\\", \\\"{x:1354,y:795,t:1527188988098};\\\", \\\"{x:1354,y:796,t:1527188988124};\\\", \\\"{x:1354,y:797,t:1527188988140};\\\", \\\"{x:1354,y:798,t:1527188988180};\\\", \\\"{x:1358,y:797,t:1527188988188};\\\", \\\"{x:1360,y:796,t:1527188988199};\\\", \\\"{x:1361,y:797,t:1527188988556};\\\", \\\"{x:1361,y:798,t:1527188988612};\\\", \\\"{x:1360,y:798,t:1527188989340};\\\", \\\"{x:1359,y:798,t:1527188989349};\\\", \\\"{x:1358,y:798,t:1527188989371};\\\", \\\"{x:1357,y:798,t:1527188989387};\\\", \\\"{x:1356,y:798,t:1527188989399};\\\", \\\"{x:1355,y:798,t:1527188989416};\\\", \\\"{x:1354,y:798,t:1527188989431};\\\", \\\"{x:1352,y:797,t:1527188989449};\\\", \\\"{x:1351,y:796,t:1527188989492};\\\", \\\"{x:1350,y:796,t:1527188989531};\\\", \\\"{x:1349,y:796,t:1527188989556};\\\", \\\"{x:1348,y:796,t:1527188989566};\\\", \\\"{x:1347,y:796,t:1527188989583};\\\", \\\"{x:1344,y:795,t:1527188990035};\\\", \\\"{x:1342,y:794,t:1527188990049};\\\", \\\"{x:1334,y:792,t:1527188990066};\\\", \\\"{x:1315,y:787,t:1527188990083};\\\", \\\"{x:1294,y:781,t:1527188990099};\\\", \\\"{x:1269,y:775,t:1527188990116};\\\", \\\"{x:1234,y:766,t:1527188990133};\\\", \\\"{x:1194,y:759,t:1527188990150};\\\", \\\"{x:1151,y:752,t:1527188990166};\\\", \\\"{x:1115,y:748,t:1527188990182};\\\", \\\"{x:1071,y:736,t:1527188990200};\\\", \\\"{x:1030,y:727,t:1527188990216};\\\", \\\"{x:1002,y:716,t:1527188990233};\\\", \\\"{x:969,y:711,t:1527188990251};\\\", \\\"{x:944,y:706,t:1527188990266};\\\", \\\"{x:920,y:702,t:1527188990284};\\\", \\\"{x:883,y:694,t:1527188990300};\\\", \\\"{x:859,y:691,t:1527188990316};\\\", \\\"{x:838,y:687,t:1527188990333};\\\", \\\"{x:813,y:680,t:1527188990350};\\\", \\\"{x:791,y:672,t:1527188990366};\\\", \\\"{x:765,y:665,t:1527188990383};\\\", \\\"{x:742,y:659,t:1527188990400};\\\", \\\"{x:718,y:652,t:1527188990416};\\\", \\\"{x:694,y:646,t:1527188990433};\\\", \\\"{x:667,y:640,t:1527188990451};\\\", \\\"{x:632,y:634,t:1527188990467};\\\", \\\"{x:601,y:625,t:1527188990484};\\\", \\\"{x:566,y:614,t:1527188990500};\\\", \\\"{x:548,y:606,t:1527188990517};\\\", \\\"{x:530,y:595,t:1527188990533};\\\", \\\"{x:518,y:586,t:1527188990550};\\\", \\\"{x:512,y:580,t:1527188990566};\\\", \\\"{x:510,y:575,t:1527188990583};\\\", \\\"{x:507,y:572,t:1527188990600};\\\", \\\"{x:505,y:569,t:1527188990616};\\\", \\\"{x:501,y:565,t:1527188990633};\\\", \\\"{x:499,y:561,t:1527188990650};\\\", \\\"{x:496,y:558,t:1527188990665};\\\", \\\"{x:496,y:553,t:1527188990683};\\\", \\\"{x:496,y:552,t:1527188990700};\\\", \\\"{x:496,y:548,t:1527188990717};\\\", \\\"{x:496,y:545,t:1527188990734};\\\", \\\"{x:501,y:542,t:1527188990751};\\\", \\\"{x:518,y:542,t:1527188990767};\\\", \\\"{x:538,y:539,t:1527188990784};\\\", \\\"{x:563,y:536,t:1527188990800};\\\", \\\"{x:589,y:536,t:1527188990817};\\\", \\\"{x:612,y:536,t:1527188990834};\\\", \\\"{x:639,y:536,t:1527188990851};\\\", \\\"{x:652,y:536,t:1527188990868};\\\", \\\"{x:657,y:536,t:1527188990883};\\\", \\\"{x:660,y:536,t:1527188990900};\\\", \\\"{x:661,y:536,t:1527188991068};\\\", \\\"{x:661,y:535,t:1527188991148};\\\", \\\"{x:662,y:535,t:1527188991196};\\\", \\\"{x:666,y:533,t:1527188991203};\\\", \\\"{x:673,y:532,t:1527188991217};\\\", \\\"{x:699,y:532,t:1527188991234};\\\", \\\"{x:772,y:526,t:1527188991251};\\\", \\\"{x:821,y:521,t:1527188991267};\\\", \\\"{x:850,y:519,t:1527188991284};\\\", \\\"{x:872,y:518,t:1527188991301};\\\", \\\"{x:878,y:518,t:1527188991316};\\\", \\\"{x:879,y:517,t:1527188991372};\\\", \\\"{x:879,y:516,t:1527188991411};\\\", \\\"{x:879,y:515,t:1527188991460};\\\", \\\"{x:879,y:514,t:1527188991468};\\\", \\\"{x:879,y:513,t:1527188991484};\\\", \\\"{x:878,y:513,t:1527188991501};\\\", \\\"{x:878,y:512,t:1527188991517};\\\", \\\"{x:878,y:511,t:1527188991534};\\\", \\\"{x:877,y:509,t:1527188991550};\\\", \\\"{x:874,y:509,t:1527188991567};\\\", \\\"{x:868,y:508,t:1527188991584};\\\", \\\"{x:865,y:507,t:1527188991601};\\\", \\\"{x:859,y:505,t:1527188991617};\\\", \\\"{x:853,y:503,t:1527188991634};\\\", \\\"{x:845,y:501,t:1527188991651};\\\", \\\"{x:843,y:500,t:1527188991668};\\\", \\\"{x:840,y:500,t:1527188991963};\\\", \\\"{x:831,y:500,t:1527188991971};\\\", \\\"{x:816,y:500,t:1527188991985};\\\", \\\"{x:785,y:500,t:1527188992000};\\\", \\\"{x:730,y:504,t:1527188992017};\\\", \\\"{x:650,y:510,t:1527188992036};\\\", \\\"{x:608,y:510,t:1527188992051};\\\", \\\"{x:566,y:510,t:1527188992068};\\\", \\\"{x:537,y:510,t:1527188992085};\\\", \\\"{x:514,y:510,t:1527188992101};\\\", \\\"{x:494,y:510,t:1527188992120};\\\", \\\"{x:471,y:510,t:1527188992135};\\\", \\\"{x:450,y:510,t:1527188992151};\\\", \\\"{x:441,y:511,t:1527188992168};\\\", \\\"{x:439,y:512,t:1527188992185};\\\", \\\"{x:435,y:513,t:1527188992202};\\\", \\\"{x:429,y:516,t:1527188992218};\\\", \\\"{x:426,y:519,t:1527188992235};\\\", \\\"{x:418,y:526,t:1527188992252};\\\", \\\"{x:406,y:533,t:1527188992268};\\\", \\\"{x:397,y:539,t:1527188992285};\\\", \\\"{x:397,y:545,t:1527188992301};\\\", \\\"{x:399,y:548,t:1527188992318};\\\", \\\"{x:406,y:551,t:1527188992335};\\\", \\\"{x:413,y:553,t:1527188992352};\\\", \\\"{x:405,y:553,t:1527188992564};\\\", \\\"{x:372,y:553,t:1527188992571};\\\", \\\"{x:356,y:550,t:1527188992586};\\\", \\\"{x:330,y:548,t:1527188992604};\\\", \\\"{x:325,y:547,t:1527188992619};\\\", \\\"{x:324,y:547,t:1527188992644};\\\", \\\"{x:322,y:547,t:1527188992660};\\\", \\\"{x:321,y:547,t:1527188992669};\\\", \\\"{x:316,y:547,t:1527188992686};\\\", \\\"{x:307,y:546,t:1527188992703};\\\", \\\"{x:301,y:546,t:1527188992720};\\\", \\\"{x:298,y:545,t:1527188992737};\\\", \\\"{x:296,y:545,t:1527188992772};\\\", \\\"{x:295,y:544,t:1527188992787};\\\", \\\"{x:286,y:543,t:1527188992804};\\\", \\\"{x:277,y:542,t:1527188992820};\\\", \\\"{x:260,y:541,t:1527188992839};\\\", \\\"{x:238,y:537,t:1527188992853};\\\", \\\"{x:220,y:535,t:1527188992869};\\\", \\\"{x:212,y:534,t:1527188992885};\\\", \\\"{x:207,y:533,t:1527188992902};\\\", \\\"{x:205,y:533,t:1527188992918};\\\", \\\"{x:204,y:532,t:1527188992935};\\\", \\\"{x:203,y:532,t:1527188992952};\\\", \\\"{x:201,y:532,t:1527188992979};\\\", \\\"{x:200,y:532,t:1527188993611};\\\", \\\"{x:200,y:533,t:1527188993619};\\\", \\\"{x:210,y:536,t:1527188993636};\\\", \\\"{x:225,y:541,t:1527188993652};\\\", \\\"{x:234,y:544,t:1527188993668};\\\", \\\"{x:253,y:556,t:1527188993686};\\\", \\\"{x:277,y:590,t:1527188993702};\\\", \\\"{x:305,y:615,t:1527188993720};\\\", \\\"{x:324,y:626,t:1527188993736};\\\", \\\"{x:334,y:633,t:1527188993753};\\\", \\\"{x:344,y:645,t:1527188993769};\\\", \\\"{x:357,y:655,t:1527188993785};\\\", \\\"{x:370,y:663,t:1527188993802};\\\", \\\"{x:381,y:673,t:1527188993819};\\\", \\\"{x:386,y:677,t:1527188993836};\\\", \\\"{x:409,y:688,t:1527188993852};\\\", \\\"{x:428,y:702,t:1527188993869};\\\", \\\"{x:438,y:713,t:1527188993886};\\\", \\\"{x:450,y:725,t:1527188993903};\\\", \\\"{x:458,y:735,t:1527188993919};\\\", \\\"{x:464,y:742,t:1527188993935};\\\", \\\"{x:467,y:746,t:1527188993952};\\\", \\\"{x:468,y:746,t:1527188993971};\\\", \\\"{x:468,y:745,t:1527188994011};\\\", \\\"{x:467,y:738,t:1527188994019};\\\", \\\"{x:452,y:722,t:1527188994036};\\\", \\\"{x:429,y:700,t:1527188994053};\\\", \\\"{x:393,y:683,t:1527188994070};\\\", \\\"{x:358,y:671,t:1527188994086};\\\", \\\"{x:314,y:651,t:1527188994103};\\\", \\\"{x:283,y:637,t:1527188994119};\\\", \\\"{x:264,y:628,t:1527188994136};\\\", \\\"{x:257,y:623,t:1527188994153};\\\", \\\"{x:252,y:618,t:1527188994170};\\\", \\\"{x:246,y:612,t:1527188994186};\\\", \\\"{x:232,y:597,t:1527188994203};\\\", \\\"{x:217,y:582,t:1527188994220};\\\", \\\"{x:194,y:565,t:1527188994236};\\\", \\\"{x:178,y:556,t:1527188994254};\\\", \\\"{x:171,y:551,t:1527188994269};\\\", \\\"{x:168,y:549,t:1527188994286};\\\", \\\"{x:165,y:544,t:1527188994303};\\\", \\\"{x:164,y:543,t:1527188994320};\\\", \\\"{x:163,y:540,t:1527188994336};\\\", \\\"{x:161,y:537,t:1527188994352};\\\", \\\"{x:161,y:536,t:1527188994370};\\\", \\\"{x:160,y:536,t:1527188994386};\\\", \\\"{x:161,y:538,t:1527188994699};\\\", \\\"{x:175,y:551,t:1527188994708};\\\", \\\"{x:193,y:564,t:1527188994721};\\\", \\\"{x:237,y:592,t:1527188994737};\\\", \\\"{x:273,y:613,t:1527188994754};\\\", \\\"{x:317,y:644,t:1527188994771};\\\", \\\"{x:361,y:670,t:1527188994787};\\\", \\\"{x:379,y:681,t:1527188994804};\\\", \\\"{x:393,y:690,t:1527188994820};\\\", \\\"{x:408,y:700,t:1527188994837};\\\", \\\"{x:422,y:708,t:1527188994853};\\\", \\\"{x:436,y:715,t:1527188994870};\\\", \\\"{x:453,y:724,t:1527188994888};\\\", \\\"{x:471,y:734,t:1527188994903};\\\", \\\"{x:489,y:746,t:1527188994920};\\\", \\\"{x:503,y:755,t:1527188994938};\\\", \\\"{x:515,y:760,t:1527188994954};\\\", \\\"{x:521,y:763,t:1527188994970};\\\", \\\"{x:526,y:765,t:1527188994986};\\\", \\\"{x:528,y:766,t:1527188995003};\\\", \\\"{x:529,y:767,t:1527188995020};\\\", \\\"{x:529,y:762,t:1527188995116};\\\", \\\"{x:529,y:756,t:1527188995123};\\\", \\\"{x:529,y:752,t:1527188995140};\\\", \\\"{x:528,y:745,t:1527188995155};\\\", \\\"{x:527,y:741,t:1527188995170};\\\", \\\"{x:525,y:735,t:1527188995188};\\\", \\\"{x:523,y:734,t:1527188995203};\\\" ] }, { \\\"rt\\\": 44323, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 423070, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -F -B -E -E -E -11 AM-E -G -B -B -B -B -J -J -J -I -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:733,t:1527188998227};\\\", \\\"{x:587,y:733,t:1527188998243};\\\", \\\"{x:631,y:733,t:1527188998256};\\\", \\\"{x:723,y:729,t:1527188998273};\\\", \\\"{x:832,y:729,t:1527188998289};\\\", \\\"{x:940,y:729,t:1527188998306};\\\", \\\"{x:1095,y:713,t:1527188998323};\\\", \\\"{x:1168,y:701,t:1527188998339};\\\", \\\"{x:1206,y:694,t:1527188998356};\\\", \\\"{x:1223,y:689,t:1527188998373};\\\", \\\"{x:1235,y:682,t:1527188998389};\\\", \\\"{x:1245,y:674,t:1527188998406};\\\", \\\"{x:1248,y:670,t:1527188998424};\\\", \\\"{x:1250,y:665,t:1527188998439};\\\", \\\"{x:1254,y:656,t:1527188998456};\\\", \\\"{x:1259,y:645,t:1527188998474};\\\", \\\"{x:1262,y:633,t:1527188998490};\\\", \\\"{x:1263,y:623,t:1527188998506};\\\", \\\"{x:1265,y:614,t:1527188998523};\\\", \\\"{x:1268,y:610,t:1527188998539};\\\", \\\"{x:1273,y:603,t:1527188998556};\\\", \\\"{x:1277,y:597,t:1527188998574};\\\", \\\"{x:1280,y:594,t:1527188998590};\\\", \\\"{x:1282,y:591,t:1527188998607};\\\", \\\"{x:1283,y:590,t:1527188998624};\\\", \\\"{x:1284,y:587,t:1527188998640};\\\", \\\"{x:1287,y:582,t:1527188998656};\\\", \\\"{x:1291,y:577,t:1527188998674};\\\", \\\"{x:1295,y:572,t:1527188998691};\\\", \\\"{x:1296,y:570,t:1527188998707};\\\", \\\"{x:1297,y:567,t:1527188998724};\\\", \\\"{x:1297,y:566,t:1527188998740};\\\", \\\"{x:1297,y:563,t:1527188998756};\\\", \\\"{x:1297,y:559,t:1527188998774};\\\", \\\"{x:1297,y:557,t:1527188998790};\\\", \\\"{x:1297,y:554,t:1527188998807};\\\", \\\"{x:1296,y:552,t:1527188998823};\\\", \\\"{x:1295,y:550,t:1527188998841};\\\", \\\"{x:1294,y:548,t:1527188998856};\\\", \\\"{x:1294,y:547,t:1527188998883};\\\", \\\"{x:1291,y:548,t:1527189002269};\\\", \\\"{x:1287,y:550,t:1527189002276};\\\", \\\"{x:1283,y:552,t:1527189002293};\\\", \\\"{x:1280,y:555,t:1527189002310};\\\", \\\"{x:1278,y:556,t:1527189002326};\\\", \\\"{x:1277,y:559,t:1527189002346};\\\", \\\"{x:1277,y:560,t:1527189002359};\\\", \\\"{x:1276,y:561,t:1527189002375};\\\", \\\"{x:1276,y:563,t:1527189002394};\\\", \\\"{x:1276,y:564,t:1527189002435};\\\", \\\"{x:1279,y:568,t:1527189002740};\\\", \\\"{x:1281,y:571,t:1527189002749};\\\", \\\"{x:1284,y:573,t:1527189002760};\\\", \\\"{x:1293,y:581,t:1527189002777};\\\", \\\"{x:1299,y:586,t:1527189002792};\\\", \\\"{x:1304,y:590,t:1527189002810};\\\", \\\"{x:1309,y:595,t:1527189002826};\\\", \\\"{x:1312,y:602,t:1527189002843};\\\", \\\"{x:1318,y:614,t:1527189002860};\\\", \\\"{x:1324,y:630,t:1527189002877};\\\", \\\"{x:1330,y:646,t:1527189002893};\\\", \\\"{x:1335,y:663,t:1527189002909};\\\", \\\"{x:1342,y:679,t:1527189002926};\\\", \\\"{x:1346,y:690,t:1527189002943};\\\", \\\"{x:1351,y:705,t:1527189002959};\\\", \\\"{x:1354,y:716,t:1527189002976};\\\", \\\"{x:1359,y:727,t:1527189002993};\\\", \\\"{x:1360,y:732,t:1527189003009};\\\", \\\"{x:1362,y:736,t:1527189003027};\\\", \\\"{x:1363,y:742,t:1527189003043};\\\", \\\"{x:1364,y:747,t:1527189003060};\\\", \\\"{x:1365,y:751,t:1527189003077};\\\", \\\"{x:1366,y:758,t:1527189003094};\\\", \\\"{x:1367,y:760,t:1527189003110};\\\", \\\"{x:1368,y:763,t:1527189003126};\\\", \\\"{x:1368,y:764,t:1527189003144};\\\", \\\"{x:1368,y:765,t:1527189003171};\\\", \\\"{x:1368,y:767,t:1527189003195};\\\", \\\"{x:1368,y:768,t:1527189003212};\\\", \\\"{x:1367,y:768,t:1527189003277};\\\", \\\"{x:1366,y:768,t:1527189003294};\\\", \\\"{x:1361,y:768,t:1527189003310};\\\", \\\"{x:1354,y:768,t:1527189003327};\\\", \\\"{x:1349,y:766,t:1527189003344};\\\", \\\"{x:1344,y:765,t:1527189003360};\\\", \\\"{x:1342,y:765,t:1527189003377};\\\", \\\"{x:1341,y:765,t:1527189003394};\\\", \\\"{x:1340,y:765,t:1527189003453};\\\", \\\"{x:1338,y:763,t:1527189003581};\\\", \\\"{x:1337,y:761,t:1527189003604};\\\", \\\"{x:1336,y:759,t:1527189003612};\\\", \\\"{x:1335,y:758,t:1527189003627};\\\", \\\"{x:1334,y:756,t:1527189003644};\\\", \\\"{x:1334,y:755,t:1527189003661};\\\", \\\"{x:1334,y:754,t:1527189003677};\\\", \\\"{x:1334,y:753,t:1527189003924};\\\", \\\"{x:1334,y:752,t:1527189004332};\\\", \\\"{x:1334,y:749,t:1527189004345};\\\", \\\"{x:1332,y:746,t:1527189004361};\\\", \\\"{x:1331,y:741,t:1527189004378};\\\", \\\"{x:1329,y:736,t:1527189004395};\\\", \\\"{x:1327,y:728,t:1527189004411};\\\", \\\"{x:1318,y:708,t:1527189004427};\\\", \\\"{x:1312,y:688,t:1527189004445};\\\", \\\"{x:1305,y:674,t:1527189004461};\\\", \\\"{x:1299,y:662,t:1527189004479};\\\", \\\"{x:1293,y:653,t:1527189004495};\\\", \\\"{x:1285,y:639,t:1527189004511};\\\", \\\"{x:1280,y:630,t:1527189004529};\\\", \\\"{x:1274,y:620,t:1527189004546};\\\", \\\"{x:1271,y:615,t:1527189004561};\\\", \\\"{x:1267,y:608,t:1527189004578};\\\", \\\"{x:1265,y:602,t:1527189004595};\\\", \\\"{x:1263,y:599,t:1527189004612};\\\", \\\"{x:1262,y:595,t:1527189004628};\\\", \\\"{x:1261,y:593,t:1527189004645};\\\", \\\"{x:1260,y:590,t:1527189004661};\\\", \\\"{x:1260,y:588,t:1527189004678};\\\", \\\"{x:1260,y:587,t:1527189004695};\\\", \\\"{x:1260,y:583,t:1527189004711};\\\", \\\"{x:1260,y:581,t:1527189004729};\\\", \\\"{x:1260,y:579,t:1527189004745};\\\", \\\"{x:1260,y:577,t:1527189004761};\\\", \\\"{x:1260,y:576,t:1527189004778};\\\", \\\"{x:1264,y:570,t:1527189004796};\\\", \\\"{x:1264,y:569,t:1527189004811};\\\", \\\"{x:1267,y:563,t:1527189004828};\\\", \\\"{x:1269,y:561,t:1527189004846};\\\", \\\"{x:1270,y:560,t:1527189004863};\\\", \\\"{x:1270,y:559,t:1527189004892};\\\", \\\"{x:1271,y:558,t:1527189004924};\\\", \\\"{x:1272,y:558,t:1527189004940};\\\", \\\"{x:1273,y:558,t:1527189004951};\\\", \\\"{x:1274,y:558,t:1527189004979};\\\", \\\"{x:1275,y:558,t:1527189004995};\\\", \\\"{x:1276,y:558,t:1527189005011};\\\", \\\"{x:1277,y:558,t:1527189005043};\\\", \\\"{x:1278,y:558,t:1527189005051};\\\", \\\"{x:1279,y:558,t:1527189005062};\\\", \\\"{x:1281,y:558,t:1527189005078};\\\", \\\"{x:1283,y:559,t:1527189005095};\\\", \\\"{x:1285,y:560,t:1527189005112};\\\", \\\"{x:1286,y:560,t:1527189005148};\\\", \\\"{x:1287,y:560,t:1527189005925};\\\", \\\"{x:1286,y:562,t:1527189005940};\\\", \\\"{x:1284,y:564,t:1527189005963};\\\", \\\"{x:1281,y:566,t:1527189005979};\\\", \\\"{x:1280,y:567,t:1527189005996};\\\", \\\"{x:1278,y:567,t:1527189014484};\\\", \\\"{x:1278,y:566,t:1527189014500};\\\", \\\"{x:1278,y:564,t:1527189014507};\\\", \\\"{x:1277,y:562,t:1527189014519};\\\", \\\"{x:1277,y:560,t:1527189014539};\\\", \\\"{x:1276,y:560,t:1527189014552};\\\", \\\"{x:1276,y:559,t:1527189014568};\\\", \\\"{x:1276,y:560,t:1527189014868};\\\", \\\"{x:1276,y:562,t:1527189014885};\\\", \\\"{x:1276,y:563,t:1527189014908};\\\", \\\"{x:1276,y:564,t:1527189016715};\\\", \\\"{x:1278,y:567,t:1527189016722};\\\", \\\"{x:1279,y:570,t:1527189016737};\\\", \\\"{x:1280,y:574,t:1527189016753};\\\", \\\"{x:1280,y:575,t:1527189016770};\\\", \\\"{x:1280,y:577,t:1527189016916};\\\", \\\"{x:1281,y:580,t:1527189016923};\\\", \\\"{x:1282,y:583,t:1527189016939};\\\", \\\"{x:1283,y:585,t:1527189016954};\\\", \\\"{x:1284,y:588,t:1527189016970};\\\", \\\"{x:1285,y:594,t:1527189016988};\\\", \\\"{x:1285,y:596,t:1527189017003};\\\", \\\"{x:1286,y:601,t:1527189017022};\\\", \\\"{x:1286,y:605,t:1527189017037};\\\", \\\"{x:1287,y:611,t:1527189017054};\\\", \\\"{x:1287,y:618,t:1527189017071};\\\", \\\"{x:1287,y:623,t:1527189017088};\\\", \\\"{x:1287,y:627,t:1527189017103};\\\", \\\"{x:1287,y:632,t:1527189017121};\\\", \\\"{x:1287,y:639,t:1527189017137};\\\", \\\"{x:1287,y:649,t:1527189017153};\\\", \\\"{x:1287,y:657,t:1527189017170};\\\", \\\"{x:1287,y:667,t:1527189017187};\\\", \\\"{x:1287,y:671,t:1527189017203};\\\", \\\"{x:1287,y:675,t:1527189017221};\\\", \\\"{x:1286,y:684,t:1527189017238};\\\", \\\"{x:1283,y:696,t:1527189017253};\\\", \\\"{x:1280,y:707,t:1527189017270};\\\", \\\"{x:1279,y:718,t:1527189017287};\\\", \\\"{x:1270,y:740,t:1527189017303};\\\", \\\"{x:1268,y:756,t:1527189017321};\\\", \\\"{x:1265,y:776,t:1527189017337};\\\", \\\"{x:1261,y:798,t:1527189017353};\\\", \\\"{x:1257,y:809,t:1527189017370};\\\", \\\"{x:1248,y:831,t:1527189017387};\\\", \\\"{x:1246,y:847,t:1527189017404};\\\", \\\"{x:1246,y:861,t:1527189017420};\\\", \\\"{x:1246,y:869,t:1527189017437};\\\", \\\"{x:1244,y:876,t:1527189017454};\\\", \\\"{x:1245,y:882,t:1527189017471};\\\", \\\"{x:1248,y:891,t:1527189017487};\\\", \\\"{x:1248,y:894,t:1527189017504};\\\", \\\"{x:1250,y:899,t:1527189017520};\\\", \\\"{x:1252,y:904,t:1527189017537};\\\", \\\"{x:1255,y:910,t:1527189017554};\\\", \\\"{x:1258,y:915,t:1527189017570};\\\", \\\"{x:1261,y:923,t:1527189017587};\\\", \\\"{x:1264,y:929,t:1527189017605};\\\", \\\"{x:1268,y:935,t:1527189017621};\\\", \\\"{x:1273,y:943,t:1527189017638};\\\", \\\"{x:1274,y:948,t:1527189017655};\\\", \\\"{x:1277,y:953,t:1527189017671};\\\", \\\"{x:1278,y:957,t:1527189017687};\\\", \\\"{x:1281,y:962,t:1527189017704};\\\", \\\"{x:1286,y:967,t:1527189017721};\\\", \\\"{x:1288,y:970,t:1527189017738};\\\", \\\"{x:1289,y:972,t:1527189017754};\\\", \\\"{x:1290,y:975,t:1527189017771};\\\", \\\"{x:1292,y:979,t:1527189017787};\\\", \\\"{x:1292,y:977,t:1527189017900};\\\", \\\"{x:1292,y:972,t:1527189017908};\\\", \\\"{x:1292,y:968,t:1527189017923};\\\", \\\"{x:1290,y:958,t:1527189017938};\\\", \\\"{x:1289,y:947,t:1527189017955};\\\", \\\"{x:1286,y:925,t:1527189017972};\\\", \\\"{x:1282,y:906,t:1527189017988};\\\", \\\"{x:1278,y:885,t:1527189018005};\\\", \\\"{x:1274,y:864,t:1527189018022};\\\", \\\"{x:1271,y:853,t:1527189018037};\\\", \\\"{x:1268,y:836,t:1527189018055};\\\", \\\"{x:1264,y:816,t:1527189018071};\\\", \\\"{x:1262,y:797,t:1527189018088};\\\", \\\"{x:1259,y:781,t:1527189018104};\\\", \\\"{x:1259,y:772,t:1527189018122};\\\", \\\"{x:1259,y:765,t:1527189018138};\\\", \\\"{x:1258,y:756,t:1527189018155};\\\", \\\"{x:1255,y:733,t:1527189018171};\\\", \\\"{x:1255,y:721,t:1527189018187};\\\", \\\"{x:1255,y:710,t:1527189018205};\\\", \\\"{x:1255,y:697,t:1527189018222};\\\", \\\"{x:1255,y:686,t:1527189018238};\\\", \\\"{x:1255,y:674,t:1527189018255};\\\", \\\"{x:1255,y:660,t:1527189018271};\\\", \\\"{x:1259,y:649,t:1527189018288};\\\", \\\"{x:1260,y:645,t:1527189018304};\\\", \\\"{x:1261,y:639,t:1527189018322};\\\", \\\"{x:1263,y:631,t:1527189018339};\\\", \\\"{x:1266,y:623,t:1527189018355};\\\", \\\"{x:1274,y:609,t:1527189018372};\\\", \\\"{x:1278,y:601,t:1527189018388};\\\", \\\"{x:1282,y:596,t:1527189018405};\\\", \\\"{x:1283,y:592,t:1527189018422};\\\", \\\"{x:1286,y:587,t:1527189018439};\\\", \\\"{x:1288,y:580,t:1527189018455};\\\", \\\"{x:1290,y:577,t:1527189018471};\\\", \\\"{x:1290,y:574,t:1527189018488};\\\", \\\"{x:1291,y:573,t:1527189018505};\\\", \\\"{x:1291,y:571,t:1527189018522};\\\", \\\"{x:1291,y:568,t:1527189018539};\\\", \\\"{x:1291,y:567,t:1527189018555};\\\", \\\"{x:1291,y:565,t:1527189018572};\\\", \\\"{x:1291,y:564,t:1527189018588};\\\", \\\"{x:1291,y:563,t:1527189018605};\\\", \\\"{x:1290,y:562,t:1527189018622};\\\", \\\"{x:1289,y:561,t:1527189018639};\\\", \\\"{x:1288,y:561,t:1527189018964};\\\", \\\"{x:1287,y:561,t:1527189018971};\\\", \\\"{x:1285,y:561,t:1527189018989};\\\", \\\"{x:1283,y:561,t:1527189019006};\\\", \\\"{x:1282,y:561,t:1527189019021};\\\", \\\"{x:1281,y:561,t:1527189019039};\\\", \\\"{x:1280,y:561,t:1527189019075};\\\", \\\"{x:1278,y:561,t:1527189019100};\\\", \\\"{x:1273,y:561,t:1527189027379};\\\", \\\"{x:1244,y:569,t:1527189027394};\\\", \\\"{x:1211,y:579,t:1527189027411};\\\", \\\"{x:1161,y:587,t:1527189027428};\\\", \\\"{x:1096,y:590,t:1527189027445};\\\", \\\"{x:1031,y:592,t:1527189027461};\\\", \\\"{x:984,y:592,t:1527189027478};\\\", \\\"{x:954,y:592,t:1527189027495};\\\", \\\"{x:930,y:592,t:1527189027513};\\\", \\\"{x:903,y:587,t:1527189027528};\\\", \\\"{x:891,y:585,t:1527189027545};\\\", \\\"{x:887,y:582,t:1527189027563};\\\", \\\"{x:883,y:576,t:1527189027579};\\\", \\\"{x:879,y:566,t:1527189027597};\\\", \\\"{x:876,y:559,t:1527189027614};\\\", \\\"{x:876,y:550,t:1527189027630};\\\", \\\"{x:877,y:539,t:1527189027647};\\\", \\\"{x:878,y:526,t:1527189027663};\\\", \\\"{x:878,y:522,t:1527189027680};\\\", \\\"{x:879,y:518,t:1527189027697};\\\", \\\"{x:878,y:516,t:1527189027716};\\\", \\\"{x:872,y:516,t:1527189027730};\\\", \\\"{x:852,y:513,t:1527189027747};\\\", \\\"{x:826,y:510,t:1527189027764};\\\", \\\"{x:795,y:510,t:1527189027781};\\\", \\\"{x:766,y:509,t:1527189027796};\\\", \\\"{x:738,y:508,t:1527189027813};\\\", \\\"{x:713,y:503,t:1527189027832};\\\", \\\"{x:694,y:501,t:1527189027846};\\\", \\\"{x:689,y:499,t:1527189027864};\\\", \\\"{x:688,y:499,t:1527189027881};\\\", \\\"{x:687,y:499,t:1527189027908};\\\", \\\"{x:685,y:499,t:1527189027987};\\\", \\\"{x:683,y:499,t:1527189027997};\\\", \\\"{x:679,y:499,t:1527189028014};\\\", \\\"{x:670,y:499,t:1527189028031};\\\", \\\"{x:661,y:500,t:1527189028047};\\\", \\\"{x:655,y:500,t:1527189028064};\\\", \\\"{x:651,y:500,t:1527189028081};\\\", \\\"{x:650,y:500,t:1527189028097};\\\", \\\"{x:649,y:501,t:1527189028139};\\\", \\\"{x:649,y:500,t:1527189028412};\\\", \\\"{x:649,y:499,t:1527189028444};\\\", \\\"{x:647,y:499,t:1527189028628};\\\", \\\"{x:644,y:499,t:1527189028636};\\\", \\\"{x:641,y:500,t:1527189028649};\\\", \\\"{x:637,y:500,t:1527189028664};\\\", \\\"{x:636,y:500,t:1527189028681};\\\", \\\"{x:635,y:500,t:1527189028763};\\\", \\\"{x:634,y:500,t:1527189028770};\\\", \\\"{x:633,y:500,t:1527189028780};\\\", \\\"{x:632,y:500,t:1527189028798};\\\", \\\"{x:631,y:500,t:1527189028818};\\\", \\\"{x:630,y:500,t:1527189028831};\\\", \\\"{x:628,y:500,t:1527189028847};\\\", \\\"{x:624,y:500,t:1527189028865};\\\", \\\"{x:622,y:500,t:1527189028881};\\\", \\\"{x:620,y:500,t:1527189028900};\\\", \\\"{x:619,y:501,t:1527189028914};\\\", \\\"{x:618,y:501,t:1527189028995};\\\", \\\"{x:616,y:501,t:1527189029003};\\\", \\\"{x:615,y:501,t:1527189029042};\\\", \\\"{x:614,y:502,t:1527189029051};\\\", \\\"{x:617,y:502,t:1527189029355};\\\", \\\"{x:619,y:502,t:1527189029365};\\\", \\\"{x:623,y:502,t:1527189029382};\\\", \\\"{x:625,y:502,t:1527189029398};\\\", \\\"{x:629,y:502,t:1527189029415};\\\", \\\"{x:635,y:504,t:1527189029432};\\\", \\\"{x:650,y:505,t:1527189029448};\\\", \\\"{x:686,y:511,t:1527189029465};\\\", \\\"{x:759,y:523,t:1527189029483};\\\", \\\"{x:856,y:537,t:1527189029498};\\\", \\\"{x:1020,y:557,t:1527189029516};\\\", \\\"{x:1130,y:567,t:1527189029532};\\\", \\\"{x:1235,y:577,t:1527189029548};\\\", \\\"{x:1317,y:584,t:1527189029565};\\\", \\\"{x:1384,y:586,t:1527189029582};\\\", \\\"{x:1424,y:586,t:1527189029599};\\\", \\\"{x:1446,y:583,t:1527189029615};\\\", \\\"{x:1453,y:579,t:1527189029632};\\\", \\\"{x:1454,y:577,t:1527189029649};\\\", \\\"{x:1454,y:574,t:1527189029665};\\\", \\\"{x:1453,y:570,t:1527189029682};\\\", \\\"{x:1450,y:565,t:1527189029699};\\\", \\\"{x:1446,y:562,t:1527189029715};\\\", \\\"{x:1443,y:558,t:1527189029732};\\\", \\\"{x:1439,y:557,t:1527189029749};\\\", \\\"{x:1432,y:557,t:1527189029765};\\\", \\\"{x:1425,y:557,t:1527189029782};\\\", \\\"{x:1410,y:557,t:1527189029799};\\\", \\\"{x:1393,y:560,t:1527189029815};\\\", \\\"{x:1372,y:566,t:1527189029832};\\\", \\\"{x:1357,y:570,t:1527189029849};\\\", \\\"{x:1345,y:573,t:1527189029865};\\\", \\\"{x:1342,y:573,t:1527189029882};\\\", \\\"{x:1339,y:574,t:1527189029899};\\\", \\\"{x:1338,y:574,t:1527189029916};\\\", \\\"{x:1336,y:574,t:1527189029932};\\\", \\\"{x:1332,y:574,t:1527189029949};\\\", \\\"{x:1329,y:574,t:1527189029966};\\\", \\\"{x:1324,y:574,t:1527189029982};\\\", \\\"{x:1321,y:574,t:1527189030000};\\\", \\\"{x:1318,y:574,t:1527189030016};\\\", \\\"{x:1316,y:574,t:1527189030033};\\\", \\\"{x:1315,y:574,t:1527189030049};\\\", \\\"{x:1313,y:574,t:1527189030066};\\\", \\\"{x:1312,y:574,t:1527189030388};\\\", \\\"{x:1311,y:574,t:1527189030399};\\\", \\\"{x:1309,y:574,t:1527189030416};\\\", \\\"{x:1308,y:574,t:1527189030434};\\\", \\\"{x:1307,y:574,t:1527189030460};\\\", \\\"{x:1306,y:575,t:1527189030467};\\\", \\\"{x:1307,y:578,t:1527189031764};\\\", \\\"{x:1310,y:584,t:1527189031772};\\\", \\\"{x:1312,y:588,t:1527189031784};\\\", \\\"{x:1318,y:602,t:1527189031801};\\\", \\\"{x:1327,y:617,t:1527189031817};\\\", \\\"{x:1335,y:626,t:1527189031835};\\\", \\\"{x:1346,y:639,t:1527189031851};\\\", \\\"{x:1353,y:653,t:1527189031867};\\\", \\\"{x:1357,y:660,t:1527189031884};\\\", \\\"{x:1360,y:666,t:1527189031901};\\\", \\\"{x:1362,y:672,t:1527189031917};\\\", \\\"{x:1365,y:676,t:1527189031935};\\\", \\\"{x:1368,y:682,t:1527189031951};\\\", \\\"{x:1369,y:685,t:1527189031967};\\\", \\\"{x:1369,y:689,t:1527189031985};\\\", \\\"{x:1370,y:692,t:1527189032002};\\\", \\\"{x:1370,y:697,t:1527189032017};\\\", \\\"{x:1370,y:704,t:1527189032035};\\\", \\\"{x:1370,y:712,t:1527189032051};\\\", \\\"{x:1370,y:719,t:1527189032068};\\\", \\\"{x:1370,y:724,t:1527189032084};\\\", \\\"{x:1370,y:727,t:1527189032101};\\\", \\\"{x:1370,y:730,t:1527189032118};\\\", \\\"{x:1370,y:732,t:1527189032135};\\\", \\\"{x:1370,y:735,t:1527189032151};\\\", \\\"{x:1370,y:737,t:1527189032168};\\\", \\\"{x:1370,y:739,t:1527189032184};\\\", \\\"{x:1369,y:740,t:1527189032202};\\\", \\\"{x:1368,y:742,t:1527189032217};\\\", \\\"{x:1367,y:743,t:1527189032234};\\\", \\\"{x:1364,y:746,t:1527189032251};\\\", \\\"{x:1362,y:748,t:1527189032267};\\\", \\\"{x:1361,y:749,t:1527189032284};\\\", \\\"{x:1358,y:754,t:1527189032301};\\\", \\\"{x:1356,y:758,t:1527189032318};\\\", \\\"{x:1353,y:762,t:1527189032334};\\\", \\\"{x:1350,y:766,t:1527189032351};\\\", \\\"{x:1349,y:768,t:1527189032368};\\\", \\\"{x:1348,y:769,t:1527189032384};\\\", \\\"{x:1347,y:771,t:1527189032401};\\\", \\\"{x:1347,y:772,t:1527189032443};\\\", \\\"{x:1347,y:771,t:1527189032595};\\\", \\\"{x:1347,y:770,t:1527189032603};\\\", \\\"{x:1348,y:768,t:1527189032619};\\\", \\\"{x:1348,y:767,t:1527189032634};\\\", \\\"{x:1349,y:764,t:1527189032651};\\\", \\\"{x:1349,y:761,t:1527189032668};\\\", \\\"{x:1349,y:760,t:1527189032684};\\\", \\\"{x:1349,y:758,t:1527189032715};\\\", \\\"{x:1349,y:757,t:1527189033125};\\\", \\\"{x:1347,y:758,t:1527189033136};\\\", \\\"{x:1344,y:760,t:1527189033153};\\\", \\\"{x:1340,y:764,t:1527189033169};\\\", \\\"{x:1337,y:768,t:1527189033185};\\\", \\\"{x:1333,y:776,t:1527189033203};\\\", \\\"{x:1330,y:787,t:1527189033218};\\\", \\\"{x:1326,y:795,t:1527189033236};\\\", \\\"{x:1323,y:800,t:1527189033251};\\\", \\\"{x:1322,y:803,t:1527189033269};\\\", \\\"{x:1319,y:807,t:1527189033286};\\\", \\\"{x:1317,y:808,t:1527189033303};\\\", \\\"{x:1311,y:811,t:1527189033319};\\\", \\\"{x:1303,y:814,t:1527189033335};\\\", \\\"{x:1293,y:815,t:1527189033352};\\\", \\\"{x:1279,y:817,t:1527189033369};\\\", \\\"{x:1268,y:818,t:1527189033385};\\\", \\\"{x:1261,y:820,t:1527189033402};\\\", \\\"{x:1249,y:822,t:1527189033418};\\\", \\\"{x:1244,y:824,t:1527189033436};\\\", \\\"{x:1244,y:825,t:1527189033453};\\\", \\\"{x:1243,y:825,t:1527189034115};\\\", \\\"{x:1243,y:826,t:1527189034131};\\\", \\\"{x:1242,y:826,t:1527189034139};\\\", \\\"{x:1242,y:827,t:1527189034171};\\\", \\\"{x:1241,y:827,t:1527189034187};\\\", \\\"{x:1239,y:827,t:1527189034203};\\\", \\\"{x:1238,y:827,t:1527189034219};\\\", \\\"{x:1235,y:828,t:1527189034237};\\\", \\\"{x:1234,y:828,t:1527189034253};\\\", \\\"{x:1232,y:828,t:1527189034270};\\\", \\\"{x:1230,y:828,t:1527189034286};\\\", \\\"{x:1226,y:828,t:1527189034302};\\\", \\\"{x:1224,y:828,t:1527189034319};\\\", \\\"{x:1219,y:830,t:1527189034336};\\\", \\\"{x:1214,y:831,t:1527189034353};\\\", \\\"{x:1206,y:832,t:1527189034370};\\\", \\\"{x:1203,y:832,t:1527189034387};\\\", \\\"{x:1200,y:832,t:1527189034404};\\\", \\\"{x:1202,y:832,t:1527189034579};\\\", \\\"{x:1203,y:832,t:1527189034595};\\\", \\\"{x:1204,y:832,t:1527189034603};\\\", \\\"{x:1205,y:832,t:1527189034627};\\\", \\\"{x:1206,y:832,t:1527189034772};\\\", \\\"{x:1209,y:831,t:1527189034787};\\\", \\\"{x:1212,y:830,t:1527189034804};\\\", \\\"{x:1213,y:829,t:1527189034820};\\\", \\\"{x:1215,y:828,t:1527189034836};\\\", \\\"{x:1216,y:828,t:1527189034853};\\\", \\\"{x:1219,y:827,t:1527189034871};\\\", \\\"{x:1218,y:824,t:1527189039016};\\\", \\\"{x:1218,y:823,t:1527189039027};\\\", \\\"{x:1216,y:818,t:1527189039043};\\\", \\\"{x:1215,y:816,t:1527189039059};\\\", \\\"{x:1214,y:813,t:1527189039076};\\\", \\\"{x:1212,y:812,t:1527189039094};\\\", \\\"{x:1211,y:811,t:1527189039109};\\\", \\\"{x:1209,y:806,t:1527189039126};\\\", \\\"{x:1208,y:804,t:1527189039144};\\\", \\\"{x:1205,y:800,t:1527189039159};\\\", \\\"{x:1204,y:797,t:1527189039176};\\\", \\\"{x:1201,y:793,t:1527189039193};\\\", \\\"{x:1197,y:786,t:1527189039209};\\\", \\\"{x:1193,y:780,t:1527189039227};\\\", \\\"{x:1191,y:775,t:1527189039243};\\\", \\\"{x:1187,y:770,t:1527189039260};\\\", \\\"{x:1186,y:767,t:1527189039277};\\\", \\\"{x:1185,y:766,t:1527189039293};\\\", \\\"{x:1185,y:765,t:1527189039326};\\\", \\\"{x:1184,y:765,t:1527189039615};\\\", \\\"{x:1184,y:764,t:1527189039626};\\\", \\\"{x:1183,y:764,t:1527189039644};\\\", \\\"{x:1182,y:762,t:1527189039660};\\\", \\\"{x:1181,y:762,t:1527189039676};\\\", \\\"{x:1181,y:761,t:1527189039702};\\\", \\\"{x:1180,y:761,t:1527189039710};\\\", \\\"{x:1178,y:761,t:1527189039734};\\\", \\\"{x:1177,y:761,t:1527189039758};\\\", \\\"{x:1176,y:761,t:1527189039790};\\\", \\\"{x:1176,y:760,t:1527189039805};\\\", \\\"{x:1173,y:760,t:1527189040279};\\\", \\\"{x:1151,y:755,t:1527189040294};\\\", \\\"{x:1121,y:751,t:1527189040311};\\\", \\\"{x:1084,y:744,t:1527189040327};\\\", \\\"{x:1048,y:741,t:1527189040345};\\\", \\\"{x:1009,y:741,t:1527189040360};\\\", \\\"{x:956,y:741,t:1527189040377};\\\", \\\"{x:886,y:741,t:1527189040395};\\\", \\\"{x:825,y:741,t:1527189040410};\\\", \\\"{x:764,y:741,t:1527189040427};\\\", \\\"{x:700,y:741,t:1527189040444};\\\", \\\"{x:638,y:741,t:1527189040460};\\\", \\\"{x:596,y:741,t:1527189040478};\\\", \\\"{x:560,y:741,t:1527189040495};\\\", \\\"{x:539,y:741,t:1527189040511};\\\", \\\"{x:519,y:741,t:1527189040527};\\\", \\\"{x:507,y:741,t:1527189040541};\\\", \\\"{x:478,y:741,t:1527189040558};\\\", \\\"{x:456,y:738,t:1527189040575};\\\", \\\"{x:435,y:733,t:1527189040591};\\\", \\\"{x:422,y:730,t:1527189040607};\\\", \\\"{x:419,y:728,t:1527189040626};\\\", \\\"{x:419,y:727,t:1527189040669};\\\", \\\"{x:424,y:727,t:1527189040710};\\\", \\\"{x:434,y:725,t:1527189040726};\\\", \\\"{x:444,y:725,t:1527189040743};\\\", \\\"{x:459,y:725,t:1527189040761};\\\", \\\"{x:478,y:725,t:1527189040776};\\\", \\\"{x:496,y:725,t:1527189040793};\\\", \\\"{x:503,y:725,t:1527189040810};\\\", \\\"{x:504,y:725,t:1527189040827};\\\", \\\"{x:505,y:725,t:1527189041398};\\\", \\\"{x:507,y:725,t:1527189041410};\\\", \\\"{x:519,y:726,t:1527189041427};\\\", \\\"{x:531,y:728,t:1527189041444};\\\", \\\"{x:551,y:730,t:1527189041460};\\\", \\\"{x:574,y:735,t:1527189041477};\\\", \\\"{x:620,y:737,t:1527189041494};\\\", \\\"{x:662,y:741,t:1527189041511};\\\", \\\"{x:695,y:741,t:1527189041527};\\\", \\\"{x:730,y:741,t:1527189041544};\\\", \\\"{x:757,y:741,t:1527189041561};\\\", \\\"{x:779,y:741,t:1527189041577};\\\", \\\"{x:794,y:741,t:1527189041594};\\\", \\\"{x:799,y:741,t:1527189041611};\\\", \\\"{x:801,y:741,t:1527189041627};\\\" ] }, { \\\"rt\\\": 33575, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 457921, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:802,y:741,t:1527189044614};\\\", \\\"{x:802,y:738,t:1527189044639};\\\", \\\"{x:801,y:735,t:1527189044653};\\\", \\\"{x:801,y:734,t:1527189044663};\\\", \\\"{x:801,y:729,t:1527189044680};\\\", \\\"{x:801,y:719,t:1527189044695};\\\", \\\"{x:801,y:708,t:1527189044713};\\\", \\\"{x:801,y:696,t:1527189044730};\\\", \\\"{x:803,y:685,t:1527189044746};\\\", \\\"{x:808,y:677,t:1527189044763};\\\", \\\"{x:812,y:672,t:1527189044780};\\\", \\\"{x:816,y:667,t:1527189044796};\\\", \\\"{x:832,y:661,t:1527189044813};\\\", \\\"{x:853,y:656,t:1527189044829};\\\", \\\"{x:875,y:651,t:1527189044846};\\\", \\\"{x:890,y:645,t:1527189044863};\\\", \\\"{x:898,y:637,t:1527189044880};\\\", \\\"{x:902,y:632,t:1527189044897};\\\", \\\"{x:904,y:631,t:1527189044914};\\\", \\\"{x:906,y:629,t:1527189044930};\\\", \\\"{x:908,y:623,t:1527189044947};\\\", \\\"{x:913,y:614,t:1527189044963};\\\", \\\"{x:926,y:607,t:1527189044980};\\\", \\\"{x:954,y:597,t:1527189044998};\\\", \\\"{x:961,y:595,t:1527189045013};\\\", \\\"{x:962,y:595,t:1527189045030};\\\", \\\"{x:963,y:595,t:1527189046301};\\\", \\\"{x:963,y:597,t:1527189046349};\\\", \\\"{x:963,y:600,t:1527189047790};\\\", \\\"{x:963,y:601,t:1527189047800};\\\", \\\"{x:966,y:608,t:1527189047815};\\\", \\\"{x:968,y:611,t:1527189047832};\\\", \\\"{x:970,y:614,t:1527189047849};\\\", \\\"{x:973,y:617,t:1527189047866};\\\", \\\"{x:977,y:621,t:1527189047882};\\\", \\\"{x:980,y:624,t:1527189047899};\\\", \\\"{x:984,y:627,t:1527189047917};\\\", \\\"{x:988,y:631,t:1527189047932};\\\", \\\"{x:1002,y:642,t:1527189047949};\\\", \\\"{x:1007,y:646,t:1527189047966};\\\", \\\"{x:1014,y:650,t:1527189047982};\\\", \\\"{x:1018,y:653,t:1527189047999};\\\", \\\"{x:1024,y:659,t:1527189048016};\\\", \\\"{x:1031,y:666,t:1527189048033};\\\", \\\"{x:1040,y:675,t:1527189048049};\\\", \\\"{x:1048,y:685,t:1527189048067};\\\", \\\"{x:1058,y:696,t:1527189048083};\\\", \\\"{x:1068,y:711,t:1527189048099};\\\", \\\"{x:1078,y:725,t:1527189048116};\\\", \\\"{x:1087,y:738,t:1527189048132};\\\", \\\"{x:1098,y:752,t:1527189048149};\\\", \\\"{x:1107,y:764,t:1527189048166};\\\", \\\"{x:1113,y:773,t:1527189048183};\\\", \\\"{x:1119,y:784,t:1527189048199};\\\", \\\"{x:1126,y:793,t:1527189048217};\\\", \\\"{x:1130,y:800,t:1527189048233};\\\", \\\"{x:1132,y:803,t:1527189048250};\\\", \\\"{x:1134,y:806,t:1527189048266};\\\", \\\"{x:1138,y:812,t:1527189048282};\\\", \\\"{x:1140,y:815,t:1527189048300};\\\", \\\"{x:1140,y:817,t:1527189048317};\\\", \\\"{x:1141,y:818,t:1527189048367};\\\", \\\"{x:1141,y:819,t:1527189048383};\\\", \\\"{x:1142,y:820,t:1527189048400};\\\", \\\"{x:1142,y:821,t:1527189048416};\\\", \\\"{x:1142,y:823,t:1527189048434};\\\", \\\"{x:1142,y:824,t:1527189048454};\\\", \\\"{x:1142,y:826,t:1527189048703};\\\", \\\"{x:1142,y:827,t:1527189048726};\\\", \\\"{x:1142,y:829,t:1527189048775};\\\", \\\"{x:1142,y:830,t:1527189048799};\\\", \\\"{x:1143,y:830,t:1527189048806};\\\", \\\"{x:1143,y:831,t:1527189048817};\\\", \\\"{x:1144,y:833,t:1527189048833};\\\", \\\"{x:1145,y:833,t:1527189048851};\\\", \\\"{x:1146,y:833,t:1527189048894};\\\", \\\"{x:1147,y:833,t:1527189048903};\\\", \\\"{x:1148,y:833,t:1527189048917};\\\", \\\"{x:1151,y:833,t:1527189048934};\\\", \\\"{x:1153,y:833,t:1527189048950};\\\", \\\"{x:1154,y:833,t:1527189048967};\\\", \\\"{x:1156,y:833,t:1527189048984};\\\", \\\"{x:1157,y:833,t:1527189052245};\\\", \\\"{x:1163,y:833,t:1527189052253};\\\", \\\"{x:1169,y:830,t:1527189052269};\\\", \\\"{x:1173,y:829,t:1527189052286};\\\", \\\"{x:1176,y:827,t:1527189052303};\\\", \\\"{x:1179,y:827,t:1527189052319};\\\", \\\"{x:1180,y:825,t:1527189052336};\\\", \\\"{x:1181,y:824,t:1527189052352};\\\", \\\"{x:1183,y:824,t:1527189052369};\\\", \\\"{x:1186,y:823,t:1527189052387};\\\", \\\"{x:1188,y:821,t:1527189052402};\\\", \\\"{x:1190,y:820,t:1527189052419};\\\", \\\"{x:1195,y:818,t:1527189052436};\\\", \\\"{x:1196,y:816,t:1527189052452};\\\", \\\"{x:1199,y:814,t:1527189052469};\\\", \\\"{x:1201,y:812,t:1527189052486};\\\", \\\"{x:1202,y:811,t:1527189052503};\\\", \\\"{x:1203,y:808,t:1527189052520};\\\", \\\"{x:1204,y:806,t:1527189052537};\\\", \\\"{x:1204,y:805,t:1527189052552};\\\", \\\"{x:1204,y:804,t:1527189052569};\\\", \\\"{x:1204,y:803,t:1527189052587};\\\", \\\"{x:1204,y:801,t:1527189052622};\\\", \\\"{x:1203,y:801,t:1527189052638};\\\", \\\"{x:1203,y:800,t:1527189052686};\\\", \\\"{x:1203,y:799,t:1527189052734};\\\", \\\"{x:1202,y:798,t:1527189052766};\\\", \\\"{x:1200,y:798,t:1527189055358};\\\", \\\"{x:1197,y:798,t:1527189055372};\\\", \\\"{x:1193,y:798,t:1527189055389};\\\", \\\"{x:1189,y:800,t:1527189055405};\\\", \\\"{x:1183,y:803,t:1527189055422};\\\", \\\"{x:1182,y:803,t:1527189055439};\\\", \\\"{x:1181,y:804,t:1527189055462};\\\", \\\"{x:1180,y:804,t:1527189055486};\\\", \\\"{x:1179,y:806,t:1527189055502};\\\", \\\"{x:1178,y:806,t:1527189055526};\\\", \\\"{x:1178,y:807,t:1527189055550};\\\", \\\"{x:1177,y:807,t:1527189055566};\\\", \\\"{x:1177,y:808,t:1527189055574};\\\", \\\"{x:1176,y:809,t:1527189055589};\\\", \\\"{x:1175,y:811,t:1527189055606};\\\", \\\"{x:1174,y:813,t:1527189055622};\\\", \\\"{x:1173,y:816,t:1527189055639};\\\", \\\"{x:1172,y:818,t:1527189055656};\\\", \\\"{x:1170,y:824,t:1527189055672};\\\", \\\"{x:1170,y:829,t:1527189055689};\\\", \\\"{x:1169,y:833,t:1527189055706};\\\", \\\"{x:1168,y:838,t:1527189055722};\\\", \\\"{x:1167,y:842,t:1527189055739};\\\", \\\"{x:1166,y:846,t:1527189055756};\\\", \\\"{x:1166,y:849,t:1527189055772};\\\", \\\"{x:1165,y:851,t:1527189055790};\\\", \\\"{x:1165,y:854,t:1527189055806};\\\", \\\"{x:1165,y:857,t:1527189055821};\\\", \\\"{x:1165,y:858,t:1527189055839};\\\", \\\"{x:1165,y:859,t:1527189055957};\\\", \\\"{x:1164,y:860,t:1527189055973};\\\", \\\"{x:1163,y:861,t:1527189055988};\\\", \\\"{x:1162,y:861,t:1527189056029};\\\", \\\"{x:1160,y:861,t:1527189056406};\\\", \\\"{x:1162,y:860,t:1527189056429};\\\", \\\"{x:1167,y:858,t:1527189056440};\\\", \\\"{x:1177,y:855,t:1527189056456};\\\", \\\"{x:1187,y:851,t:1527189056473};\\\", \\\"{x:1195,y:850,t:1527189056490};\\\", \\\"{x:1199,y:849,t:1527189056506};\\\", \\\"{x:1199,y:848,t:1527189056622};\\\", \\\"{x:1200,y:848,t:1527189056662};\\\", \\\"{x:1201,y:846,t:1527189056673};\\\", \\\"{x:1202,y:845,t:1527189056690};\\\", \\\"{x:1203,y:843,t:1527189056706};\\\", \\\"{x:1204,y:840,t:1527189056722};\\\", \\\"{x:1205,y:838,t:1527189056739};\\\", \\\"{x:1206,y:835,t:1527189056757};\\\", \\\"{x:1206,y:833,t:1527189056772};\\\", \\\"{x:1208,y:830,t:1527189056790};\\\", \\\"{x:1208,y:829,t:1527189056806};\\\", \\\"{x:1208,y:828,t:1527189056822};\\\", \\\"{x:1208,y:827,t:1527189056839};\\\", \\\"{x:1208,y:826,t:1527189057006};\\\", \\\"{x:1208,y:822,t:1527189057023};\\\", \\\"{x:1208,y:817,t:1527189057040};\\\", \\\"{x:1207,y:809,t:1527189057058};\\\", \\\"{x:1204,y:802,t:1527189057074};\\\", \\\"{x:1202,y:797,t:1527189057090};\\\", \\\"{x:1200,y:794,t:1527189057107};\\\", \\\"{x:1199,y:792,t:1527189057122};\\\", \\\"{x:1199,y:790,t:1527189057140};\\\", \\\"{x:1197,y:789,t:1527189057157};\\\", \\\"{x:1197,y:787,t:1527189057173};\\\", \\\"{x:1196,y:787,t:1527189057189};\\\", \\\"{x:1195,y:785,t:1527189057207};\\\", \\\"{x:1194,y:783,t:1527189057222};\\\", \\\"{x:1193,y:782,t:1527189057239};\\\", \\\"{x:1191,y:779,t:1527189057257};\\\", \\\"{x:1189,y:778,t:1527189057274};\\\", \\\"{x:1188,y:777,t:1527189057290};\\\", \\\"{x:1186,y:776,t:1527189057307};\\\", \\\"{x:1185,y:775,t:1527189057324};\\\", \\\"{x:1184,y:775,t:1527189057340};\\\", \\\"{x:1183,y:774,t:1527189057357};\\\", \\\"{x:1181,y:773,t:1527189057374};\\\", \\\"{x:1180,y:772,t:1527189057397};\\\", \\\"{x:1179,y:772,t:1527189057445};\\\", \\\"{x:1178,y:772,t:1527189057927};\\\", \\\"{x:1178,y:773,t:1527189057942};\\\", \\\"{x:1178,y:776,t:1527189057957};\\\", \\\"{x:1181,y:783,t:1527189057973};\\\", \\\"{x:1184,y:790,t:1527189057991};\\\", \\\"{x:1187,y:797,t:1527189058007};\\\", \\\"{x:1189,y:801,t:1527189058024};\\\", \\\"{x:1191,y:804,t:1527189058040};\\\", \\\"{x:1194,y:809,t:1527189058057};\\\", \\\"{x:1198,y:815,t:1527189058074};\\\", \\\"{x:1204,y:822,t:1527189058090};\\\", \\\"{x:1208,y:828,t:1527189058108};\\\", \\\"{x:1210,y:831,t:1527189058124};\\\", \\\"{x:1213,y:833,t:1527189058141};\\\", \\\"{x:1215,y:835,t:1527189058157};\\\", \\\"{x:1215,y:836,t:1527189058174};\\\", \\\"{x:1217,y:836,t:1527189058191};\\\", \\\"{x:1217,y:837,t:1527189058213};\\\", \\\"{x:1218,y:838,t:1527189058230};\\\", \\\"{x:1218,y:839,t:1527189058246};\\\", \\\"{x:1218,y:838,t:1527189060726};\\\", \\\"{x:1218,y:836,t:1527189060743};\\\", \\\"{x:1218,y:835,t:1527189060759};\\\", \\\"{x:1218,y:833,t:1527189060777};\\\", \\\"{x:1218,y:832,t:1527189060794};\\\", \\\"{x:1217,y:831,t:1527189060830};\\\", \\\"{x:1216,y:829,t:1527189060861};\\\", \\\"{x:1215,y:828,t:1527189061582};\\\", \\\"{x:1213,y:826,t:1527189061594};\\\", \\\"{x:1210,y:824,t:1527189061611};\\\", \\\"{x:1208,y:821,t:1527189061628};\\\", \\\"{x:1205,y:817,t:1527189061644};\\\", \\\"{x:1204,y:815,t:1527189061661};\\\", \\\"{x:1203,y:812,t:1527189061678};\\\", \\\"{x:1200,y:809,t:1527189061693};\\\", \\\"{x:1198,y:805,t:1527189061710};\\\", \\\"{x:1196,y:802,t:1527189061727};\\\", \\\"{x:1195,y:800,t:1527189061744};\\\", \\\"{x:1193,y:797,t:1527189061760};\\\", \\\"{x:1189,y:790,t:1527189061777};\\\", \\\"{x:1184,y:781,t:1527189061795};\\\", \\\"{x:1183,y:778,t:1527189061811};\\\", \\\"{x:1180,y:774,t:1527189061827};\\\", \\\"{x:1179,y:773,t:1527189061844};\\\", \\\"{x:1177,y:769,t:1527189061860};\\\", \\\"{x:1176,y:767,t:1527189061877};\\\", \\\"{x:1175,y:765,t:1527189062213};\\\", \\\"{x:1174,y:765,t:1527189062229};\\\", \\\"{x:1174,y:764,t:1527189062254};\\\", \\\"{x:1173,y:763,t:1527189062277};\\\", \\\"{x:1177,y:763,t:1527189064734};\\\", \\\"{x:1180,y:763,t:1527189064746};\\\", \\\"{x:1182,y:763,t:1527189064763};\\\", \\\"{x:1183,y:763,t:1527189066718};\\\", \\\"{x:1179,y:763,t:1527189069086};\\\", \\\"{x:1166,y:763,t:1527189069101};\\\", \\\"{x:1135,y:760,t:1527189069117};\\\", \\\"{x:1073,y:748,t:1527189069133};\\\", \\\"{x:981,y:729,t:1527189069150};\\\", \\\"{x:925,y:722,t:1527189069167};\\\", \\\"{x:880,y:714,t:1527189069183};\\\", \\\"{x:850,y:709,t:1527189069200};\\\", \\\"{x:828,y:703,t:1527189069216};\\\", \\\"{x:805,y:701,t:1527189069234};\\\", \\\"{x:781,y:697,t:1527189069250};\\\", \\\"{x:757,y:694,t:1527189069266};\\\", \\\"{x:721,y:691,t:1527189069285};\\\", \\\"{x:678,y:684,t:1527189069300};\\\", \\\"{x:612,y:675,t:1527189069316};\\\", \\\"{x:555,y:664,t:1527189069334};\\\", \\\"{x:550,y:658,t:1527189069350};\\\", \\\"{x:545,y:653,t:1527189069366};\\\", \\\"{x:533,y:641,t:1527189069384};\\\", \\\"{x:519,y:624,t:1527189069401};\\\", \\\"{x:504,y:607,t:1527189069416};\\\", \\\"{x:497,y:596,t:1527189069433};\\\", \\\"{x:494,y:586,t:1527189069450};\\\", \\\"{x:494,y:578,t:1527189069466};\\\", \\\"{x:494,y:569,t:1527189069483};\\\", \\\"{x:494,y:568,t:1527189069742};\\\", \\\"{x:494,y:567,t:1527189069750};\\\", \\\"{x:483,y:560,t:1527189069769};\\\", \\\"{x:463,y:554,t:1527189069784};\\\", \\\"{x:441,y:547,t:1527189069800};\\\", \\\"{x:419,y:537,t:1527189069817};\\\", \\\"{x:393,y:526,t:1527189069833};\\\", \\\"{x:369,y:516,t:1527189069851};\\\", \\\"{x:347,y:511,t:1527189069868};\\\", \\\"{x:322,y:503,t:1527189069884};\\\", \\\"{x:296,y:497,t:1527189069900};\\\", \\\"{x:280,y:496,t:1527189069916};\\\", \\\"{x:265,y:492,t:1527189069934};\\\", \\\"{x:256,y:489,t:1527189069950};\\\", \\\"{x:251,y:488,t:1527189069967};\\\", \\\"{x:247,y:488,t:1527189069983};\\\", \\\"{x:242,y:487,t:1527189070000};\\\", \\\"{x:233,y:485,t:1527189070018};\\\", \\\"{x:222,y:484,t:1527189070034};\\\", \\\"{x:215,y:484,t:1527189070050};\\\", \\\"{x:208,y:484,t:1527189070068};\\\", \\\"{x:203,y:484,t:1527189070084};\\\", \\\"{x:199,y:484,t:1527189070100};\\\", \\\"{x:197,y:484,t:1527189070117};\\\", \\\"{x:194,y:484,t:1527189070133};\\\", \\\"{x:191,y:485,t:1527189070151};\\\", \\\"{x:187,y:485,t:1527189070167};\\\", \\\"{x:183,y:487,t:1527189070183};\\\", \\\"{x:175,y:489,t:1527189070200};\\\", \\\"{x:170,y:491,t:1527189070218};\\\", \\\"{x:168,y:492,t:1527189070234};\\\", \\\"{x:167,y:492,t:1527189070250};\\\", \\\"{x:167,y:493,t:1527189070268};\\\", \\\"{x:166,y:493,t:1527189070301};\\\", \\\"{x:166,y:494,t:1527189070317};\\\", \\\"{x:166,y:495,t:1527189070342};\\\", \\\"{x:169,y:496,t:1527189070701};\\\", \\\"{x:184,y:500,t:1527189070717};\\\", \\\"{x:207,y:507,t:1527189070735};\\\", \\\"{x:250,y:519,t:1527189070752};\\\", \\\"{x:305,y:536,t:1527189070768};\\\", \\\"{x:369,y:564,t:1527189070785};\\\", \\\"{x:424,y:588,t:1527189070801};\\\", \\\"{x:470,y:611,t:1527189070818};\\\", \\\"{x:504,y:635,t:1527189070834};\\\", \\\"{x:527,y:656,t:1527189070851};\\\", \\\"{x:542,y:671,t:1527189070868};\\\", \\\"{x:549,y:682,t:1527189070885};\\\", \\\"{x:551,y:689,t:1527189070901};\\\", \\\"{x:552,y:694,t:1527189070919};\\\", \\\"{x:552,y:699,t:1527189070934};\\\", \\\"{x:552,y:705,t:1527189070952};\\\", \\\"{x:552,y:709,t:1527189070968};\\\", \\\"{x:552,y:711,t:1527189070985};\\\", \\\"{x:552,y:713,t:1527189071002};\\\", \\\"{x:551,y:715,t:1527189071018};\\\", \\\"{x:550,y:716,t:1527189071034};\\\", \\\"{x:545,y:719,t:1527189071051};\\\", \\\"{x:540,y:722,t:1527189071070};\\\", \\\"{x:525,y:729,t:1527189071085};\\\", \\\"{x:515,y:734,t:1527189071101};\\\", \\\"{x:507,y:736,t:1527189071118};\\\", \\\"{x:500,y:739,t:1527189071134};\\\", \\\"{x:497,y:741,t:1527189071151};\\\", \\\"{x:494,y:742,t:1527189071169};\\\", \\\"{x:494,y:741,t:1527189075501};\\\" ] }, { \\\"rt\\\": 35747, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 494946, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -F -G -G -M -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:741,t:1527189078350};\\\", \\\"{x:489,y:741,t:1527189078357};\\\", \\\"{x:481,y:739,t:1527189078375};\\\", \\\"{x:479,y:738,t:1527189078392};\\\", \\\"{x:479,y:737,t:1527189078934};\\\", \\\"{x:489,y:733,t:1527189078942};\\\", \\\"{x:508,y:726,t:1527189078959};\\\", \\\"{x:534,y:719,t:1527189078978};\\\", \\\"{x:568,y:709,t:1527189078992};\\\", \\\"{x:602,y:700,t:1527189079008};\\\", \\\"{x:646,y:694,t:1527189079024};\\\", \\\"{x:710,y:686,t:1527189079041};\\\", \\\"{x:808,y:684,t:1527189079058};\\\", \\\"{x:913,y:684,t:1527189079074};\\\", \\\"{x:1010,y:684,t:1527189079091};\\\", \\\"{x:1094,y:684,t:1527189079108};\\\", \\\"{x:1187,y:680,t:1527189079125};\\\", \\\"{x:1214,y:680,t:1527189079141};\\\", \\\"{x:1269,y:680,t:1527189079158};\\\", \\\"{x:1285,y:679,t:1527189079175};\\\", \\\"{x:1290,y:678,t:1527189079191};\\\", \\\"{x:1293,y:678,t:1527189079208};\\\", \\\"{x:1295,y:677,t:1527189079225};\\\", \\\"{x:1296,y:677,t:1527189079253};\\\", \\\"{x:1298,y:677,t:1527189079261};\\\", \\\"{x:1302,y:677,t:1527189079275};\\\", \\\"{x:1308,y:677,t:1527189079290};\\\", \\\"{x:1314,y:677,t:1527189079308};\\\", \\\"{x:1315,y:677,t:1527189079325};\\\", \\\"{x:1317,y:677,t:1527189079357};\\\", \\\"{x:1322,y:685,t:1527189079375};\\\", \\\"{x:1327,y:693,t:1527189079392};\\\", \\\"{x:1332,y:700,t:1527189079408};\\\", \\\"{x:1336,y:704,t:1527189079425};\\\", \\\"{x:1338,y:707,t:1527189079442};\\\", \\\"{x:1339,y:708,t:1527189079458};\\\", \\\"{x:1340,y:709,t:1527189079475};\\\", \\\"{x:1341,y:709,t:1527189079491};\\\", \\\"{x:1341,y:710,t:1527189079508};\\\", \\\"{x:1342,y:710,t:1527189079526};\\\", \\\"{x:1343,y:710,t:1527189079541};\\\", \\\"{x:1344,y:710,t:1527189079590};\\\", \\\"{x:1345,y:710,t:1527189079614};\\\", \\\"{x:1345,y:709,t:1527189079630};\\\", \\\"{x:1345,y:707,t:1527189079642};\\\", \\\"{x:1345,y:704,t:1527189079658};\\\", \\\"{x:1345,y:702,t:1527189079675};\\\", \\\"{x:1345,y:699,t:1527189079695};\\\", \\\"{x:1345,y:697,t:1527189079708};\\\", \\\"{x:1345,y:694,t:1527189079724};\\\", \\\"{x:1346,y:693,t:1527189080302};\\\", \\\"{x:1347,y:693,t:1527189080310};\\\", \\\"{x:1349,y:693,t:1527189080325};\\\", \\\"{x:1350,y:694,t:1527189080342};\\\", \\\"{x:1350,y:696,t:1527189080373};\\\", \\\"{x:1351,y:697,t:1527189080414};\\\", \\\"{x:1353,y:698,t:1527189083262};\\\", \\\"{x:1365,y:702,t:1527189083280};\\\", \\\"{x:1374,y:706,t:1527189083295};\\\", \\\"{x:1393,y:710,t:1527189083312};\\\", \\\"{x:1411,y:712,t:1527189083328};\\\", \\\"{x:1427,y:716,t:1527189083344};\\\", \\\"{x:1445,y:718,t:1527189083361};\\\", \\\"{x:1464,y:724,t:1527189083378};\\\", \\\"{x:1481,y:732,t:1527189083396};\\\", \\\"{x:1496,y:738,t:1527189083412};\\\", \\\"{x:1508,y:743,t:1527189083428};\\\", \\\"{x:1527,y:753,t:1527189083446};\\\", \\\"{x:1541,y:761,t:1527189083462};\\\", \\\"{x:1551,y:770,t:1527189083479};\\\", \\\"{x:1559,y:777,t:1527189083496};\\\", \\\"{x:1564,y:786,t:1527189083511};\\\", \\\"{x:1567,y:793,t:1527189083529};\\\", \\\"{x:1568,y:800,t:1527189083546};\\\", \\\"{x:1570,y:808,t:1527189083561};\\\", \\\"{x:1570,y:815,t:1527189083578};\\\", \\\"{x:1570,y:821,t:1527189083596};\\\", \\\"{x:1570,y:827,t:1527189083611};\\\", \\\"{x:1567,y:833,t:1527189083629};\\\", \\\"{x:1563,y:841,t:1527189083645};\\\", \\\"{x:1560,y:845,t:1527189083661};\\\", \\\"{x:1557,y:849,t:1527189083678};\\\", \\\"{x:1554,y:851,t:1527189083696};\\\", \\\"{x:1550,y:855,t:1527189083711};\\\", \\\"{x:1547,y:858,t:1527189083729};\\\", \\\"{x:1545,y:860,t:1527189083745};\\\", \\\"{x:1543,y:862,t:1527189083762};\\\", \\\"{x:1542,y:862,t:1527189083778};\\\", \\\"{x:1541,y:862,t:1527189083798};\\\", \\\"{x:1540,y:862,t:1527189083855};\\\", \\\"{x:1539,y:862,t:1527189083861};\\\", \\\"{x:1538,y:862,t:1527189083878};\\\", \\\"{x:1537,y:861,t:1527189083896};\\\", \\\"{x:1535,y:860,t:1527189083913};\\\", \\\"{x:1534,y:860,t:1527189083929};\\\", \\\"{x:1533,y:859,t:1527189083945};\\\", \\\"{x:1532,y:858,t:1527189083963};\\\", \\\"{x:1531,y:858,t:1527189083982};\\\", \\\"{x:1531,y:857,t:1527189083998};\\\", \\\"{x:1530,y:857,t:1527189084013};\\\", \\\"{x:1529,y:856,t:1527189084030};\\\", \\\"{x:1528,y:855,t:1527189084054};\\\", \\\"{x:1528,y:854,t:1527189084070};\\\", \\\"{x:1527,y:853,t:1527189084094};\\\", \\\"{x:1526,y:853,t:1527189084102};\\\", \\\"{x:1525,y:852,t:1527189084113};\\\", \\\"{x:1524,y:851,t:1527189084129};\\\", \\\"{x:1522,y:850,t:1527189084146};\\\", \\\"{x:1519,y:849,t:1527189084167};\\\", \\\"{x:1518,y:848,t:1527189084179};\\\", \\\"{x:1516,y:846,t:1527189084195};\\\", \\\"{x:1506,y:841,t:1527189084213};\\\", \\\"{x:1491,y:834,t:1527189084229};\\\", \\\"{x:1457,y:820,t:1527189084246};\\\", \\\"{x:1430,y:804,t:1527189084262};\\\", \\\"{x:1409,y:790,t:1527189084280};\\\", \\\"{x:1385,y:774,t:1527189084295};\\\", \\\"{x:1370,y:764,t:1527189084312};\\\", \\\"{x:1362,y:759,t:1527189084329};\\\", \\\"{x:1359,y:755,t:1527189084346};\\\", \\\"{x:1356,y:750,t:1527189084363};\\\", \\\"{x:1353,y:747,t:1527189084379};\\\", \\\"{x:1351,y:744,t:1527189084396};\\\", \\\"{x:1350,y:741,t:1527189084413};\\\", \\\"{x:1349,y:739,t:1527189084429};\\\", \\\"{x:1349,y:737,t:1527189084445};\\\", \\\"{x:1348,y:736,t:1527189084462};\\\", \\\"{x:1348,y:734,t:1527189084480};\\\", \\\"{x:1348,y:732,t:1527189084495};\\\", \\\"{x:1348,y:729,t:1527189084513};\\\", \\\"{x:1348,y:723,t:1527189084529};\\\", \\\"{x:1348,y:716,t:1527189084546};\\\", \\\"{x:1348,y:712,t:1527189084563};\\\", \\\"{x:1346,y:705,t:1527189084580};\\\", \\\"{x:1345,y:701,t:1527189084596};\\\", \\\"{x:1343,y:697,t:1527189084612};\\\", \\\"{x:1342,y:695,t:1527189084630};\\\", \\\"{x:1342,y:696,t:1527189085094};\\\", \\\"{x:1342,y:697,t:1527189085118};\\\", \\\"{x:1342,y:699,t:1527189085142};\\\", \\\"{x:1342,y:700,t:1527189085158};\\\", \\\"{x:1342,y:701,t:1527189085166};\\\", \\\"{x:1342,y:702,t:1527189085197};\\\", \\\"{x:1343,y:702,t:1527189085222};\\\", \\\"{x:1343,y:704,t:1527189085478};\\\", \\\"{x:1343,y:710,t:1527189085486};\\\", \\\"{x:1346,y:716,t:1527189085496};\\\", \\\"{x:1349,y:724,t:1527189085514};\\\", \\\"{x:1353,y:733,t:1527189085530};\\\", \\\"{x:1356,y:739,t:1527189085547};\\\", \\\"{x:1358,y:744,t:1527189085564};\\\", \\\"{x:1359,y:747,t:1527189085580};\\\", \\\"{x:1360,y:751,t:1527189085597};\\\", \\\"{x:1360,y:757,t:1527189085614};\\\", \\\"{x:1360,y:759,t:1527189085630};\\\", \\\"{x:1360,y:760,t:1527189085647};\\\", \\\"{x:1360,y:763,t:1527189085664};\\\", \\\"{x:1360,y:764,t:1527189085680};\\\", \\\"{x:1360,y:767,t:1527189085697};\\\", \\\"{x:1360,y:769,t:1527189085713};\\\", \\\"{x:1359,y:770,t:1527189085730};\\\", \\\"{x:1359,y:772,t:1527189085750};\\\", \\\"{x:1356,y:772,t:1527189085774};\\\", \\\"{x:1356,y:773,t:1527189085781};\\\", \\\"{x:1355,y:773,t:1527189085805};\\\", \\\"{x:1353,y:773,t:1527189085814};\\\", \\\"{x:1352,y:773,t:1527189085830};\\\", \\\"{x:1351,y:773,t:1527189085846};\\\", \\\"{x:1348,y:773,t:1527189085862};\\\", \\\"{x:1347,y:772,t:1527189085880};\\\", \\\"{x:1345,y:771,t:1527189085896};\\\", \\\"{x:1342,y:770,t:1527189085917};\\\", \\\"{x:1342,y:769,t:1527189085957};\\\", \\\"{x:1341,y:769,t:1527189085996};\\\", \\\"{x:1340,y:768,t:1527189086012};\\\", \\\"{x:1339,y:768,t:1527189086030};\\\", \\\"{x:1339,y:766,t:1527189086052};\\\", \\\"{x:1338,y:766,t:1527189086063};\\\", \\\"{x:1338,y:764,t:1527189086079};\\\", \\\"{x:1337,y:763,t:1527189086096};\\\", \\\"{x:1336,y:762,t:1527189086113};\\\", \\\"{x:1336,y:761,t:1527189086293};\\\", \\\"{x:1337,y:761,t:1527189086301};\\\", \\\"{x:1338,y:761,t:1527189086313};\\\", \\\"{x:1340,y:761,t:1527189086331};\\\", \\\"{x:1342,y:761,t:1527189086347};\\\", \\\"{x:1343,y:761,t:1527189086390};\\\", \\\"{x:1347,y:760,t:1527189086741};\\\", \\\"{x:1353,y:756,t:1527189086750};\\\", \\\"{x:1355,y:754,t:1527189086764};\\\", \\\"{x:1362,y:747,t:1527189086780};\\\", \\\"{x:1366,y:733,t:1527189086797};\\\", \\\"{x:1367,y:729,t:1527189086814};\\\", \\\"{x:1367,y:725,t:1527189086830};\\\", \\\"{x:1367,y:723,t:1527189086847};\\\", \\\"{x:1367,y:719,t:1527189086864};\\\", \\\"{x:1367,y:715,t:1527189086881};\\\", \\\"{x:1366,y:711,t:1527189086897};\\\", \\\"{x:1364,y:709,t:1527189086914};\\\", \\\"{x:1364,y:705,t:1527189086931};\\\", \\\"{x:1362,y:704,t:1527189086947};\\\", \\\"{x:1361,y:702,t:1527189087093};\\\", \\\"{x:1360,y:702,t:1527189087101};\\\", \\\"{x:1359,y:701,t:1527189087114};\\\", \\\"{x:1357,y:699,t:1527189087131};\\\", \\\"{x:1355,y:697,t:1527189087147};\\\", \\\"{x:1351,y:695,t:1527189087164};\\\", \\\"{x:1349,y:694,t:1527189087181};\\\", \\\"{x:1347,y:692,t:1527189087197};\\\", \\\"{x:1346,y:692,t:1527189087221};\\\", \\\"{x:1347,y:692,t:1527189087510};\\\", \\\"{x:1348,y:692,t:1527189087517};\\\", \\\"{x:1350,y:692,t:1527189087532};\\\", \\\"{x:1352,y:691,t:1527189087550};\\\", \\\"{x:1356,y:688,t:1527189087565};\\\", \\\"{x:1364,y:680,t:1527189087581};\\\", \\\"{x:1374,y:666,t:1527189087598};\\\", \\\"{x:1386,y:652,t:1527189087614};\\\", \\\"{x:1394,y:642,t:1527189087632};\\\", \\\"{x:1398,y:634,t:1527189087648};\\\", \\\"{x:1400,y:629,t:1527189087664};\\\", \\\"{x:1401,y:622,t:1527189087681};\\\", \\\"{x:1403,y:615,t:1527189087698};\\\", \\\"{x:1403,y:610,t:1527189087715};\\\", \\\"{x:1403,y:606,t:1527189087732};\\\", \\\"{x:1403,y:601,t:1527189087748};\\\", \\\"{x:1403,y:595,t:1527189087765};\\\", \\\"{x:1403,y:590,t:1527189087781};\\\", \\\"{x:1403,y:587,t:1527189087799};\\\", \\\"{x:1402,y:582,t:1527189087816};\\\", \\\"{x:1401,y:579,t:1527189087831};\\\", \\\"{x:1400,y:577,t:1527189087848};\\\", \\\"{x:1400,y:576,t:1527189087869};\\\", \\\"{x:1400,y:575,t:1527189087882};\\\", \\\"{x:1400,y:574,t:1527189087898};\\\", \\\"{x:1400,y:573,t:1527189087915};\\\", \\\"{x:1400,y:572,t:1527189087932};\\\", \\\"{x:1400,y:569,t:1527189087949};\\\", \\\"{x:1404,y:564,t:1527189087966};\\\", \\\"{x:1406,y:561,t:1527189087981};\\\", \\\"{x:1408,y:559,t:1527189087998};\\\", \\\"{x:1409,y:557,t:1527189088016};\\\", \\\"{x:1410,y:556,t:1527189088032};\\\", \\\"{x:1410,y:554,t:1527189088048};\\\", \\\"{x:1411,y:551,t:1527189088065};\\\", \\\"{x:1412,y:549,t:1527189088082};\\\", \\\"{x:1412,y:548,t:1527189088098};\\\", \\\"{x:1413,y:548,t:1527189088116};\\\", \\\"{x:1413,y:546,t:1527189088131};\\\", \\\"{x:1414,y:546,t:1527189088149};\\\", \\\"{x:1415,y:546,t:1527189088166};\\\", \\\"{x:1419,y:548,t:1527189088183};\\\", \\\"{x:1420,y:551,t:1527189088199};\\\", \\\"{x:1420,y:552,t:1527189088215};\\\", \\\"{x:1422,y:555,t:1527189088233};\\\", \\\"{x:1423,y:557,t:1527189088249};\\\", \\\"{x:1423,y:558,t:1527189088266};\\\", \\\"{x:1423,y:559,t:1527189088302};\\\", \\\"{x:1423,y:560,t:1527189088316};\\\", \\\"{x:1421,y:562,t:1527189088333};\\\", \\\"{x:1421,y:564,t:1527189088349};\\\", \\\"{x:1420,y:566,t:1527189088367};\\\", \\\"{x:1420,y:567,t:1527189088414};\\\", \\\"{x:1419,y:567,t:1527189088432};\\\", \\\"{x:1418,y:567,t:1527189089159};\\\", \\\"{x:1417,y:567,t:1527189089205};\\\", \\\"{x:1416,y:567,t:1527189089446};\\\", \\\"{x:1415,y:567,t:1527189089461};\\\", \\\"{x:1414,y:567,t:1527189089486};\\\", \\\"{x:1413,y:567,t:1527189089501};\\\", \\\"{x:1413,y:568,t:1527189089542};\\\", \\\"{x:1411,y:569,t:1527189089574};\\\", \\\"{x:1410,y:569,t:1527189089846};\\\", \\\"{x:1410,y:570,t:1527189090190};\\\", \\\"{x:1410,y:572,t:1527189090201};\\\", \\\"{x:1412,y:578,t:1527189090217};\\\", \\\"{x:1416,y:588,t:1527189090234};\\\", \\\"{x:1423,y:613,t:1527189090251};\\\", \\\"{x:1430,y:638,t:1527189090267};\\\", \\\"{x:1433,y:661,t:1527189090284};\\\", \\\"{x:1436,y:683,t:1527189090301};\\\", \\\"{x:1438,y:701,t:1527189090317};\\\", \\\"{x:1445,y:725,t:1527189090333};\\\", \\\"{x:1448,y:737,t:1527189090351};\\\", \\\"{x:1450,y:750,t:1527189090367};\\\", \\\"{x:1452,y:760,t:1527189090384};\\\", \\\"{x:1458,y:773,t:1527189090401};\\\", \\\"{x:1461,y:784,t:1527189090417};\\\", \\\"{x:1462,y:791,t:1527189090434};\\\", \\\"{x:1464,y:800,t:1527189090451};\\\", \\\"{x:1467,y:810,t:1527189090467};\\\", \\\"{x:1468,y:819,t:1527189090484};\\\", \\\"{x:1468,y:829,t:1527189090500};\\\", \\\"{x:1468,y:843,t:1527189090518};\\\", \\\"{x:1465,y:856,t:1527189090534};\\\", \\\"{x:1457,y:870,t:1527189090551};\\\", \\\"{x:1448,y:882,t:1527189090568};\\\", \\\"{x:1439,y:892,t:1527189090584};\\\", \\\"{x:1429,y:901,t:1527189090601};\\\", \\\"{x:1417,y:907,t:1527189090618};\\\", \\\"{x:1408,y:911,t:1527189090633};\\\", \\\"{x:1396,y:916,t:1527189090651};\\\", \\\"{x:1388,y:919,t:1527189090668};\\\", \\\"{x:1382,y:921,t:1527189090684};\\\", \\\"{x:1379,y:921,t:1527189090701};\\\", \\\"{x:1375,y:920,t:1527189090717};\\\", \\\"{x:1374,y:919,t:1527189090734};\\\", \\\"{x:1372,y:917,t:1527189090751};\\\", \\\"{x:1372,y:914,t:1527189090768};\\\", \\\"{x:1369,y:908,t:1527189090784};\\\", \\\"{x:1367,y:903,t:1527189090801};\\\", \\\"{x:1366,y:903,t:1527189090818};\\\", \\\"{x:1366,y:902,t:1527189090834};\\\", \\\"{x:1366,y:901,t:1527189090886};\\\", \\\"{x:1366,y:900,t:1527189090901};\\\", \\\"{x:1366,y:897,t:1527189090917};\\\", \\\"{x:1367,y:897,t:1527189090934};\\\", \\\"{x:1368,y:897,t:1527189090951};\\\", \\\"{x:1369,y:896,t:1527189090968};\\\", \\\"{x:1369,y:895,t:1527189091037};\\\", \\\"{x:1370,y:895,t:1527189091053};\\\", \\\"{x:1372,y:895,t:1527189091067};\\\", \\\"{x:1373,y:895,t:1527189091084};\\\", \\\"{x:1374,y:895,t:1527189091101};\\\", \\\"{x:1375,y:894,t:1527189091822};\\\", \\\"{x:1379,y:893,t:1527189091835};\\\", \\\"{x:1393,y:888,t:1527189091852};\\\", \\\"{x:1402,y:885,t:1527189091869};\\\", \\\"{x:1409,y:883,t:1527189091885};\\\", \\\"{x:1414,y:881,t:1527189091902};\\\", \\\"{x:1415,y:881,t:1527189091919};\\\", \\\"{x:1421,y:880,t:1527189091935};\\\", \\\"{x:1427,y:877,t:1527189091952};\\\", \\\"{x:1436,y:874,t:1527189091969};\\\", \\\"{x:1447,y:869,t:1527189091985};\\\", \\\"{x:1459,y:863,t:1527189092002};\\\", \\\"{x:1467,y:859,t:1527189092019};\\\", \\\"{x:1473,y:855,t:1527189092035};\\\", \\\"{x:1477,y:852,t:1527189092052};\\\", \\\"{x:1479,y:849,t:1527189092068};\\\", \\\"{x:1479,y:848,t:1527189092085};\\\", \\\"{x:1480,y:847,t:1527189092102};\\\", \\\"{x:1480,y:845,t:1527189092119};\\\", \\\"{x:1480,y:843,t:1527189092142};\\\", \\\"{x:1480,y:842,t:1527189092158};\\\", \\\"{x:1480,y:841,t:1527189092190};\\\", \\\"{x:1480,y:840,t:1527189092221};\\\", \\\"{x:1481,y:839,t:1527189092236};\\\", \\\"{x:1482,y:838,t:1527189092294};\\\", \\\"{x:1482,y:837,t:1527189092302};\\\", \\\"{x:1484,y:837,t:1527189092319};\\\", \\\"{x:1485,y:836,t:1527189092336};\\\", \\\"{x:1486,y:836,t:1527189092422};\\\", \\\"{x:1488,y:836,t:1527189092436};\\\", \\\"{x:1490,y:837,t:1527189092452};\\\", \\\"{x:1491,y:837,t:1527189092469};\\\", \\\"{x:1493,y:840,t:1527189092486};\\\", \\\"{x:1493,y:838,t:1527189092638};\\\", \\\"{x:1493,y:837,t:1527189092652};\\\", \\\"{x:1493,y:835,t:1527189092669};\\\", \\\"{x:1491,y:833,t:1527189092685};\\\", \\\"{x:1489,y:831,t:1527189092703};\\\", \\\"{x:1487,y:830,t:1527189092719};\\\", \\\"{x:1486,y:830,t:1527189092742};\\\", \\\"{x:1483,y:829,t:1527189092768};\\\", \\\"{x:1482,y:829,t:1527189092786};\\\", \\\"{x:1481,y:829,t:1527189092803};\\\", \\\"{x:1478,y:829,t:1527189092819};\\\", \\\"{x:1477,y:829,t:1527189092836};\\\", \\\"{x:1473,y:829,t:1527189094903};\\\", \\\"{x:1453,y:825,t:1527189094921};\\\", \\\"{x:1423,y:823,t:1527189094938};\\\", \\\"{x:1367,y:815,t:1527189094954};\\\", \\\"{x:1297,y:805,t:1527189094970};\\\", \\\"{x:1200,y:791,t:1527189094987};\\\", \\\"{x:1100,y:777,t:1527189095003};\\\", \\\"{x:998,y:749,t:1527189095021};\\\", \\\"{x:840,y:705,t:1527189095037};\\\", \\\"{x:752,y:680,t:1527189095053};\\\", \\\"{x:690,y:661,t:1527189095070};\\\", \\\"{x:650,y:648,t:1527189095087};\\\", \\\"{x:626,y:634,t:1527189095103};\\\", \\\"{x:608,y:623,t:1527189095122};\\\", \\\"{x:598,y:618,t:1527189095137};\\\", \\\"{x:595,y:616,t:1527189095153};\\\", \\\"{x:594,y:616,t:1527189095170};\\\", \\\"{x:592,y:615,t:1527189095204};\\\", \\\"{x:592,y:613,t:1527189095244};\\\", \\\"{x:592,y:611,t:1527189095253};\\\", \\\"{x:589,y:602,t:1527189095270};\\\", \\\"{x:587,y:596,t:1527189095288};\\\", \\\"{x:584,y:588,t:1527189095304};\\\", \\\"{x:579,y:582,t:1527189095320};\\\", \\\"{x:574,y:578,t:1527189095337};\\\", \\\"{x:571,y:578,t:1527189095355};\\\", \\\"{x:564,y:575,t:1527189095370};\\\", \\\"{x:553,y:575,t:1527189095388};\\\", \\\"{x:534,y:574,t:1527189095404};\\\", \\\"{x:512,y:574,t:1527189095420};\\\", \\\"{x:487,y:573,t:1527189095440};\\\", \\\"{x:472,y:570,t:1527189095454};\\\", \\\"{x:457,y:570,t:1527189095471};\\\", \\\"{x:445,y:569,t:1527189095487};\\\", \\\"{x:438,y:568,t:1527189095504};\\\", \\\"{x:437,y:568,t:1527189095521};\\\", \\\"{x:436,y:568,t:1527189095537};\\\", \\\"{x:434,y:568,t:1527189095565};\\\", \\\"{x:438,y:570,t:1527189095637};\\\", \\\"{x:458,y:576,t:1527189095654};\\\", \\\"{x:484,y:580,t:1527189095671};\\\", \\\"{x:513,y:583,t:1527189095688};\\\", \\\"{x:565,y:585,t:1527189095705};\\\", \\\"{x:618,y:585,t:1527189095722};\\\", \\\"{x:665,y:585,t:1527189095738};\\\", \\\"{x:700,y:585,t:1527189095754};\\\", \\\"{x:725,y:585,t:1527189095772};\\\", \\\"{x:743,y:585,t:1527189095787};\\\", \\\"{x:754,y:585,t:1527189095805};\\\", \\\"{x:764,y:585,t:1527189095821};\\\", \\\"{x:771,y:585,t:1527189095838};\\\", \\\"{x:780,y:586,t:1527189095855};\\\", \\\"{x:795,y:588,t:1527189095871};\\\", \\\"{x:810,y:591,t:1527189095888};\\\", \\\"{x:825,y:593,t:1527189095905};\\\", \\\"{x:834,y:595,t:1527189095922};\\\", \\\"{x:837,y:595,t:1527189095938};\\\", \\\"{x:834,y:595,t:1527189096037};\\\", \\\"{x:827,y:594,t:1527189096045};\\\", \\\"{x:820,y:593,t:1527189096055};\\\", \\\"{x:803,y:590,t:1527189096071};\\\", \\\"{x:785,y:589,t:1527189096088};\\\", \\\"{x:766,y:589,t:1527189096105};\\\", \\\"{x:748,y:589,t:1527189096121};\\\", \\\"{x:737,y:589,t:1527189096139};\\\", \\\"{x:728,y:590,t:1527189096155};\\\", \\\"{x:722,y:590,t:1527189096172};\\\", \\\"{x:715,y:591,t:1527189096189};\\\", \\\"{x:709,y:591,t:1527189096204};\\\", \\\"{x:701,y:591,t:1527189096221};\\\", \\\"{x:694,y:591,t:1527189096239};\\\", \\\"{x:685,y:591,t:1527189096255};\\\", \\\"{x:674,y:590,t:1527189096271};\\\", \\\"{x:664,y:587,t:1527189096288};\\\", \\\"{x:656,y:585,t:1527189096305};\\\", \\\"{x:653,y:585,t:1527189096322};\\\", \\\"{x:652,y:585,t:1527189096339};\\\", \\\"{x:651,y:585,t:1527189096373};\\\", \\\"{x:650,y:585,t:1527189096390};\\\", \\\"{x:649,y:585,t:1527189096405};\\\", \\\"{x:647,y:585,t:1527189096422};\\\", \\\"{x:646,y:585,t:1527189096439};\\\", \\\"{x:645,y:585,t:1527189096454};\\\", \\\"{x:644,y:585,t:1527189096870};\\\", \\\"{x:643,y:585,t:1527189096877};\\\", \\\"{x:640,y:585,t:1527189096889};\\\", \\\"{x:634,y:585,t:1527189096905};\\\", \\\"{x:628,y:585,t:1527189096922};\\\", \\\"{x:625,y:584,t:1527189096938};\\\", \\\"{x:624,y:583,t:1527189096956};\\\", \\\"{x:623,y:583,t:1527189097045};\\\", \\\"{x:622,y:583,t:1527189097056};\\\", \\\"{x:621,y:583,t:1527189097206};\\\", \\\"{x:620,y:583,t:1527189097223};\\\", \\\"{x:619,y:583,t:1527189097240};\\\", \\\"{x:623,y:583,t:1527189097817};\\\", \\\"{x:634,y:585,t:1527189097826};\\\", \\\"{x:689,y:601,t:1527189097844};\\\", \\\"{x:778,y:626,t:1527189097860};\\\", \\\"{x:886,y:656,t:1527189097876};\\\", \\\"{x:1005,y:709,t:1527189097892};\\\", \\\"{x:1105,y:744,t:1527189097910};\\\", \\\"{x:1191,y:783,t:1527189097926};\\\", \\\"{x:1254,y:809,t:1527189097942};\\\", \\\"{x:1310,y:835,t:1527189097960};\\\", \\\"{x:1329,y:843,t:1527189097976};\\\", \\\"{x:1341,y:851,t:1527189097992};\\\", \\\"{x:1350,y:856,t:1527189098010};\\\", \\\"{x:1357,y:859,t:1527189098025};\\\", \\\"{x:1365,y:861,t:1527189098043};\\\", \\\"{x:1373,y:862,t:1527189098060};\\\", \\\"{x:1389,y:864,t:1527189098076};\\\", \\\"{x:1417,y:864,t:1527189098093};\\\", \\\"{x:1459,y:864,t:1527189098110};\\\", \\\"{x:1495,y:861,t:1527189098127};\\\", \\\"{x:1519,y:853,t:1527189098143};\\\", \\\"{x:1540,y:844,t:1527189098160};\\\", \\\"{x:1541,y:840,t:1527189098176};\\\", \\\"{x:1541,y:838,t:1527189098193};\\\", \\\"{x:1541,y:835,t:1527189098210};\\\", \\\"{x:1540,y:834,t:1527189098321};\\\", \\\"{x:1537,y:834,t:1527189098329};\\\", \\\"{x:1532,y:834,t:1527189098344};\\\", \\\"{x:1518,y:834,t:1527189098361};\\\", \\\"{x:1510,y:834,t:1527189098376};\\\", \\\"{x:1502,y:834,t:1527189098393};\\\", \\\"{x:1498,y:834,t:1527189098410};\\\", \\\"{x:1495,y:834,t:1527189098427};\\\", \\\"{x:1495,y:835,t:1527189098442};\\\", \\\"{x:1494,y:835,t:1527189101217};\\\", \\\"{x:1487,y:835,t:1527189101229};\\\", \\\"{x:1445,y:835,t:1527189101247};\\\", \\\"{x:1365,y:835,t:1527189101262};\\\", \\\"{x:1257,y:835,t:1527189101280};\\\", \\\"{x:1134,y:834,t:1527189101296};\\\", \\\"{x:966,y:820,t:1527189101313};\\\", \\\"{x:871,y:805,t:1527189101328};\\\", \\\"{x:801,y:794,t:1527189101345};\\\", \\\"{x:767,y:789,t:1527189101362};\\\", \\\"{x:749,y:787,t:1527189101379};\\\", \\\"{x:744,y:785,t:1527189101396};\\\", \\\"{x:743,y:784,t:1527189101412};\\\", \\\"{x:741,y:784,t:1527189101456};\\\", \\\"{x:740,y:784,t:1527189101464};\\\", \\\"{x:737,y:784,t:1527189101479};\\\", \\\"{x:711,y:782,t:1527189101496};\\\", \\\"{x:683,y:777,t:1527189101512};\\\", \\\"{x:652,y:773,t:1527189101529};\\\", \\\"{x:621,y:765,t:1527189101546};\\\", \\\"{x:591,y:757,t:1527189101562};\\\", \\\"{x:569,y:754,t:1527189101579};\\\", \\\"{x:548,y:752,t:1527189101596};\\\", \\\"{x:533,y:749,t:1527189101613};\\\", \\\"{x:527,y:748,t:1527189101629};\\\", \\\"{x:526,y:748,t:1527189101646};\\\", \\\"{x:525,y:748,t:1527189101664};\\\", \\\"{x:524,y:746,t:1527189101928};\\\", \\\"{x:524,y:743,t:1527189101937};\\\", \\\"{x:524,y:739,t:1527189101946};\\\", \\\"{x:524,y:735,t:1527189101963};\\\", \\\"{x:524,y:734,t:1527189101980};\\\", \\\"{x:524,y:733,t:1527189102273};\\\", \\\"{x:523,y:733,t:1527189113825};\\\", \\\"{x:521,y:733,t:1527189113839};\\\", \\\"{x:503,y:741,t:1527189113856};\\\", \\\"{x:487,y:747,t:1527189113873};\\\", \\\"{x:474,y:752,t:1527189113889};\\\", \\\"{x:461,y:757,t:1527189113906};\\\", \\\"{x:456,y:758,t:1527189113923};\\\", \\\"{x:452,y:760,t:1527189113939};\\\", \\\"{x:450,y:761,t:1527189113955};\\\", \\\"{x:449,y:761,t:1527189113972};\\\", \\\"{x:447,y:763,t:1527189114096};\\\", \\\"{x:446,y:763,t:1527189114111};\\\", \\\"{x:446,y:764,t:1527189114123};\\\" ] }, { \\\"rt\\\": 14771, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 511079, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:437,y:770,t:1527189114289};\\\", \\\"{x:437,y:771,t:1527189114307};\\\", \\\"{x:437,y:772,t:1527189114323};\\\", \\\"{x:436,y:772,t:1527189114368};\\\", \\\"{x:436,y:776,t:1527189118817};\\\", \\\"{x:436,y:780,t:1527189118828};\\\", \\\"{x:436,y:790,t:1527189118843};\\\", \\\"{x:439,y:802,t:1527189118860};\\\", \\\"{x:445,y:814,t:1527189118877};\\\", \\\"{x:455,y:828,t:1527189118893};\\\", \\\"{x:479,y:851,t:1527189118911};\\\", \\\"{x:520,y:877,t:1527189118927};\\\", \\\"{x:568,y:903,t:1527189118943};\\\", \\\"{x:652,y:933,t:1527189118960};\\\", \\\"{x:735,y:954,t:1527189118977};\\\", \\\"{x:833,y:978,t:1527189118993};\\\", \\\"{x:926,y:997,t:1527189119010};\\\", \\\"{x:1010,y:1012,t:1527189119027};\\\", \\\"{x:1053,y:1019,t:1527189119044};\\\", \\\"{x:1077,y:1023,t:1527189119060};\\\", \\\"{x:1086,y:1026,t:1527189119077};\\\", \\\"{x:1091,y:1030,t:1527189119093};\\\", \\\"{x:1092,y:1033,t:1527189119111};\\\", \\\"{x:1093,y:1034,t:1527189119151};\\\", \\\"{x:1093,y:1033,t:1527189119264};\\\", \\\"{x:1094,y:1029,t:1527189119277};\\\", \\\"{x:1103,y:1013,t:1527189119293};\\\", \\\"{x:1111,y:1002,t:1527189119310};\\\", \\\"{x:1119,y:992,t:1527189119327};\\\", \\\"{x:1129,y:981,t:1527189119344};\\\", \\\"{x:1133,y:974,t:1527189119359};\\\", \\\"{x:1136,y:968,t:1527189119378};\\\", \\\"{x:1136,y:966,t:1527189119393};\\\", \\\"{x:1137,y:963,t:1527189119410};\\\", \\\"{x:1137,y:960,t:1527189119427};\\\", \\\"{x:1137,y:957,t:1527189119444};\\\", \\\"{x:1138,y:957,t:1527189119460};\\\", \\\"{x:1142,y:956,t:1527189119681};\\\", \\\"{x:1146,y:956,t:1527189119695};\\\", \\\"{x:1158,y:957,t:1527189119712};\\\", \\\"{x:1173,y:958,t:1527189119727};\\\", \\\"{x:1211,y:963,t:1527189119745};\\\", \\\"{x:1242,y:963,t:1527189119760};\\\", \\\"{x:1270,y:963,t:1527189119777};\\\", \\\"{x:1296,y:963,t:1527189119794};\\\", \\\"{x:1317,y:963,t:1527189119811};\\\", \\\"{x:1338,y:963,t:1527189119827};\\\", \\\"{x:1352,y:963,t:1527189119844};\\\", \\\"{x:1364,y:963,t:1527189119862};\\\", \\\"{x:1375,y:963,t:1527189119877};\\\", \\\"{x:1386,y:963,t:1527189119894};\\\", \\\"{x:1394,y:963,t:1527189119911};\\\", \\\"{x:1400,y:963,t:1527189119927};\\\", \\\"{x:1406,y:963,t:1527189119944};\\\", \\\"{x:1409,y:963,t:1527189119961};\\\", \\\"{x:1410,y:963,t:1527189119977};\\\", \\\"{x:1410,y:962,t:1527189120057};\\\", \\\"{x:1406,y:961,t:1527189120064};\\\", \\\"{x:1396,y:958,t:1527189120078};\\\", \\\"{x:1376,y:956,t:1527189120094};\\\", \\\"{x:1363,y:956,t:1527189120111};\\\", \\\"{x:1355,y:956,t:1527189120128};\\\", \\\"{x:1344,y:956,t:1527189120144};\\\", \\\"{x:1338,y:956,t:1527189120161};\\\", \\\"{x:1337,y:956,t:1527189120178};\\\", \\\"{x:1336,y:956,t:1527189120216};\\\", \\\"{x:1334,y:956,t:1527189120265};\\\", \\\"{x:1334,y:957,t:1527189120345};\\\", \\\"{x:1334,y:958,t:1527189120377};\\\", \\\"{x:1335,y:959,t:1527189120400};\\\", \\\"{x:1336,y:959,t:1527189120411};\\\", \\\"{x:1337,y:960,t:1527189120428};\\\", \\\"{x:1339,y:961,t:1527189120444};\\\", \\\"{x:1341,y:963,t:1527189120461};\\\", \\\"{x:1342,y:964,t:1527189120478};\\\", \\\"{x:1343,y:965,t:1527189120495};\\\", \\\"{x:1344,y:966,t:1527189120511};\\\", \\\"{x:1346,y:967,t:1527189120528};\\\", \\\"{x:1347,y:968,t:1527189120545};\\\", \\\"{x:1348,y:968,t:1527189120698};\\\", \\\"{x:1348,y:967,t:1527189120753};\\\", \\\"{x:1348,y:966,t:1527189120761};\\\", \\\"{x:1348,y:963,t:1527189120778};\\\", \\\"{x:1347,y:959,t:1527189120796};\\\", \\\"{x:1347,y:956,t:1527189120811};\\\", \\\"{x:1347,y:953,t:1527189120828};\\\", \\\"{x:1344,y:950,t:1527189120845};\\\", \\\"{x:1344,y:948,t:1527189120862};\\\", \\\"{x:1343,y:943,t:1527189120878};\\\", \\\"{x:1342,y:939,t:1527189120895};\\\", \\\"{x:1341,y:936,t:1527189120911};\\\", \\\"{x:1340,y:931,t:1527189120928};\\\", \\\"{x:1339,y:925,t:1527189120945};\\\", \\\"{x:1337,y:919,t:1527189120962};\\\", \\\"{x:1336,y:911,t:1527189120978};\\\", \\\"{x:1336,y:907,t:1527189120996};\\\", \\\"{x:1335,y:901,t:1527189121013};\\\", \\\"{x:1334,y:894,t:1527189121028};\\\", \\\"{x:1333,y:888,t:1527189121045};\\\", \\\"{x:1332,y:883,t:1527189121063};\\\", \\\"{x:1332,y:879,t:1527189121078};\\\", \\\"{x:1331,y:875,t:1527189121095};\\\", \\\"{x:1329,y:870,t:1527189121113};\\\", \\\"{x:1329,y:866,t:1527189121129};\\\", \\\"{x:1329,y:860,t:1527189121145};\\\", \\\"{x:1329,y:856,t:1527189121162};\\\", \\\"{x:1329,y:850,t:1527189121178};\\\", \\\"{x:1329,y:845,t:1527189121195};\\\", \\\"{x:1329,y:839,t:1527189121212};\\\", \\\"{x:1329,y:832,t:1527189121228};\\\", \\\"{x:1329,y:826,t:1527189121245};\\\", \\\"{x:1329,y:820,t:1527189121263};\\\", \\\"{x:1329,y:814,t:1527189121279};\\\", \\\"{x:1330,y:810,t:1527189121295};\\\", \\\"{x:1330,y:805,t:1527189121312};\\\", \\\"{x:1330,y:800,t:1527189121328};\\\", \\\"{x:1330,y:798,t:1527189121346};\\\", \\\"{x:1330,y:794,t:1527189121363};\\\", \\\"{x:1330,y:792,t:1527189121380};\\\", \\\"{x:1330,y:790,t:1527189121395};\\\", \\\"{x:1330,y:786,t:1527189121413};\\\", \\\"{x:1331,y:785,t:1527189121429};\\\", \\\"{x:1331,y:782,t:1527189121445};\\\", \\\"{x:1332,y:780,t:1527189121463};\\\", \\\"{x:1333,y:779,t:1527189121480};\\\", \\\"{x:1334,y:776,t:1527189121495};\\\", \\\"{x:1336,y:773,t:1527189121513};\\\", \\\"{x:1340,y:769,t:1527189121529};\\\", \\\"{x:1347,y:767,t:1527189121548};\\\", \\\"{x:1358,y:762,t:1527189121562};\\\", \\\"{x:1361,y:760,t:1527189121579};\\\", \\\"{x:1361,y:759,t:1527189121595};\\\", \\\"{x:1360,y:759,t:1527189121841};\\\", \\\"{x:1359,y:759,t:1527189121857};\\\", \\\"{x:1358,y:759,t:1527189121864};\\\", \\\"{x:1357,y:759,t:1527189121881};\\\", \\\"{x:1356,y:759,t:1527189121897};\\\", \\\"{x:1355,y:759,t:1527189121921};\\\", \\\"{x:1354,y:759,t:1527189121961};\\\", \\\"{x:1352,y:759,t:1527189121994};\\\", \\\"{x:1351,y:759,t:1527189122024};\\\", \\\"{x:1351,y:758,t:1527189122033};\\\", \\\"{x:1349,y:758,t:1527189123602};\\\", \\\"{x:1339,y:758,t:1527189123615};\\\", \\\"{x:1309,y:758,t:1527189123630};\\\", \\\"{x:1267,y:758,t:1527189123647};\\\", \\\"{x:1163,y:753,t:1527189123664};\\\", \\\"{x:1079,y:742,t:1527189123680};\\\", \\\"{x:987,y:727,t:1527189123697};\\\", \\\"{x:879,y:710,t:1527189123715};\\\", \\\"{x:762,y:692,t:1527189123730};\\\", \\\"{x:638,y:680,t:1527189123748};\\\", \\\"{x:519,y:663,t:1527189123765};\\\", \\\"{x:421,y:659,t:1527189123782};\\\", \\\"{x:313,y:659,t:1527189123797};\\\", \\\"{x:202,y:659,t:1527189123815};\\\", \\\"{x:118,y:656,t:1527189123827};\\\", \\\"{x:85,y:656,t:1527189123844};\\\", \\\"{x:83,y:655,t:1527189123860};\\\", \\\"{x:83,y:654,t:1527189123877};\\\", \\\"{x:86,y:653,t:1527189124105};\\\", \\\"{x:89,y:651,t:1527189124112};\\\", \\\"{x:91,y:649,t:1527189124127};\\\", \\\"{x:95,y:643,t:1527189124144};\\\", \\\"{x:98,y:636,t:1527189124162};\\\", \\\"{x:102,y:629,t:1527189124178};\\\", \\\"{x:106,y:621,t:1527189124197};\\\", \\\"{x:111,y:614,t:1527189124215};\\\", \\\"{x:114,y:611,t:1527189124230};\\\", \\\"{x:116,y:607,t:1527189124247};\\\", \\\"{x:116,y:604,t:1527189124263};\\\", \\\"{x:122,y:596,t:1527189124281};\\\", \\\"{x:126,y:591,t:1527189124298};\\\", \\\"{x:130,y:586,t:1527189124315};\\\", \\\"{x:132,y:580,t:1527189124331};\\\", \\\"{x:134,y:576,t:1527189124348};\\\", \\\"{x:138,y:571,t:1527189124365};\\\", \\\"{x:141,y:567,t:1527189124382};\\\", \\\"{x:144,y:562,t:1527189124400};\\\", \\\"{x:148,y:556,t:1527189124415};\\\", \\\"{x:151,y:552,t:1527189124433};\\\", \\\"{x:155,y:547,t:1527189124449};\\\", \\\"{x:156,y:544,t:1527189124464};\\\", \\\"{x:157,y:542,t:1527189124481};\\\", \\\"{x:157,y:541,t:1527189124592};\\\", \\\"{x:158,y:541,t:1527189124832};\\\", \\\"{x:161,y:541,t:1527189124847};\\\", \\\"{x:168,y:541,t:1527189124865};\\\", \\\"{x:177,y:541,t:1527189124881};\\\", \\\"{x:196,y:541,t:1527189124898};\\\", \\\"{x:230,y:541,t:1527189124915};\\\", \\\"{x:294,y:541,t:1527189124932};\\\", \\\"{x:380,y:541,t:1527189124948};\\\", \\\"{x:469,y:541,t:1527189124966};\\\", \\\"{x:555,y:541,t:1527189124981};\\\", \\\"{x:632,y:534,t:1527189124998};\\\", \\\"{x:683,y:526,t:1527189125015};\\\", \\\"{x:709,y:524,t:1527189125031};\\\", \\\"{x:719,y:521,t:1527189125047};\\\", \\\"{x:722,y:521,t:1527189125151};\\\", \\\"{x:730,y:521,t:1527189125165};\\\", \\\"{x:760,y:521,t:1527189125182};\\\", \\\"{x:793,y:516,t:1527189125198};\\\", \\\"{x:824,y:512,t:1527189125214};\\\", \\\"{x:882,y:503,t:1527189125231};\\\", \\\"{x:904,y:501,t:1527189125247};\\\", \\\"{x:913,y:498,t:1527189125264};\\\", \\\"{x:907,y:498,t:1527189125384};\\\", \\\"{x:901,y:498,t:1527189125399};\\\", \\\"{x:890,y:498,t:1527189125415};\\\", \\\"{x:886,y:498,t:1527189125432};\\\", \\\"{x:876,y:501,t:1527189125449};\\\", \\\"{x:864,y:502,t:1527189125467};\\\", \\\"{x:858,y:503,t:1527189125482};\\\", \\\"{x:856,y:503,t:1527189125498};\\\", \\\"{x:852,y:504,t:1527189125515};\\\", \\\"{x:849,y:504,t:1527189125532};\\\", \\\"{x:848,y:504,t:1527189125548};\\\", \\\"{x:846,y:504,t:1527189125577};\\\", \\\"{x:845,y:504,t:1527189125600};\\\", \\\"{x:843,y:504,t:1527189125616};\\\", \\\"{x:841,y:505,t:1527189126065};\\\", \\\"{x:838,y:508,t:1527189126072};\\\", \\\"{x:834,y:516,t:1527189126083};\\\", \\\"{x:828,y:529,t:1527189126100};\\\", \\\"{x:817,y:547,t:1527189126116};\\\", \\\"{x:810,y:564,t:1527189126133};\\\", \\\"{x:799,y:582,t:1527189126149};\\\", \\\"{x:788,y:603,t:1527189126166};\\\", \\\"{x:776,y:625,t:1527189126182};\\\", \\\"{x:762,y:647,t:1527189126200};\\\", \\\"{x:736,y:681,t:1527189126216};\\\", \\\"{x:722,y:701,t:1527189126232};\\\", \\\"{x:706,y:719,t:1527189126249};\\\", \\\"{x:691,y:735,t:1527189126266};\\\", \\\"{x:677,y:746,t:1527189126282};\\\", \\\"{x:665,y:755,t:1527189126299};\\\", \\\"{x:656,y:761,t:1527189126316};\\\", \\\"{x:648,y:768,t:1527189126332};\\\", \\\"{x:638,y:777,t:1527189126350};\\\", \\\"{x:627,y:785,t:1527189126366};\\\", \\\"{x:621,y:789,t:1527189126382};\\\", \\\"{x:616,y:792,t:1527189126400};\\\", \\\"{x:611,y:796,t:1527189126416};\\\", \\\"{x:609,y:797,t:1527189126433};\\\", \\\"{x:608,y:797,t:1527189126449};\\\", \\\"{x:607,y:799,t:1527189126467};\\\", \\\"{x:606,y:799,t:1527189126482};\\\", \\\"{x:605,y:799,t:1527189126499};\\\", \\\"{x:604,y:799,t:1527189126529};\\\", \\\"{x:602,y:800,t:1527189127504};\\\", \\\"{x:599,y:800,t:1527189127517};\\\", \\\"{x:590,y:801,t:1527189127534};\\\", \\\"{x:588,y:801,t:1527189127549};\\\", \\\"{x:586,y:802,t:1527189127566};\\\", \\\"{x:584,y:802,t:1527189127583};\\\", \\\"{x:583,y:803,t:1527189127600};\\\", \\\"{x:582,y:803,t:1527189127681};\\\", \\\"{x:581,y:803,t:1527189127712};\\\", \\\"{x:580,y:803,t:1527189127769};\\\", \\\"{x:579,y:803,t:1527189127817};\\\", \\\"{x:577,y:803,t:1527189127835};\\\", \\\"{x:574,y:803,t:1527189127851};\\\", \\\"{x:571,y:803,t:1527189127867};\\\", \\\"{x:563,y:803,t:1527189127884};\\\", \\\"{x:552,y:803,t:1527189127900};\\\", \\\"{x:537,y:803,t:1527189127917};\\\", \\\"{x:523,y:803,t:1527189127934};\\\", \\\"{x:514,y:803,t:1527189127951};\\\", \\\"{x:505,y:803,t:1527189127967};\\\", \\\"{x:499,y:803,t:1527189127984};\\\", \\\"{x:496,y:803,t:1527189128000};\\\", \\\"{x:495,y:803,t:1527189128016};\\\", \\\"{x:495,y:802,t:1527189128529};\\\", \\\"{x:495,y:798,t:1527189128537};\\\", \\\"{x:495,y:791,t:1527189128550};\\\", \\\"{x:495,y:785,t:1527189128567};\\\", \\\"{x:494,y:777,t:1527189128584};\\\", \\\"{x:493,y:766,t:1527189128600};\\\", \\\"{x:492,y:761,t:1527189128617};\\\", \\\"{x:491,y:759,t:1527189128634};\\\", \\\"{x:491,y:758,t:1527189128651};\\\", \\\"{x:490,y:756,t:1527189128668};\\\", \\\"{x:490,y:755,t:1527189128684};\\\", \\\"{x:490,y:754,t:1527189128730};\\\", \\\"{x:489,y:752,t:1527189128750};\\\", \\\"{x:488,y:750,t:1527189128767};\\\", \\\"{x:488,y:748,t:1527189128782};\\\", \\\"{x:488,y:743,t:1527189128799};\\\", \\\"{x:488,y:737,t:1527189128815};\\\", \\\"{x:488,y:734,t:1527189128832};\\\", \\\"{x:488,y:730,t:1527189128849};\\\", \\\"{x:488,y:729,t:1527189128880};\\\" ] }, { \\\"rt\\\": 9049, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 521371, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:729,t:1527189132129};\\\", \\\"{x:507,y:729,t:1527189132140};\\\", \\\"{x:524,y:729,t:1527189132156};\\\", \\\"{x:542,y:729,t:1527189132174};\\\", \\\"{x:561,y:729,t:1527189132191};\\\", \\\"{x:584,y:729,t:1527189132207};\\\", \\\"{x:630,y:729,t:1527189132223};\\\", \\\"{x:650,y:729,t:1527189132237};\\\", \\\"{x:705,y:729,t:1527189132253};\\\", \\\"{x:778,y:729,t:1527189132270};\\\", \\\"{x:914,y:729,t:1527189132287};\\\", \\\"{x:995,y:725,t:1527189132304};\\\", \\\"{x:1078,y:714,t:1527189132320};\\\", \\\"{x:1144,y:709,t:1527189132338};\\\", \\\"{x:1203,y:701,t:1527189132354};\\\", \\\"{x:1247,y:697,t:1527189132370};\\\", \\\"{x:1276,y:693,t:1527189132387};\\\", \\\"{x:1297,y:691,t:1527189132404};\\\", \\\"{x:1316,y:688,t:1527189132420};\\\", \\\"{x:1341,y:686,t:1527189132438};\\\", \\\"{x:1368,y:682,t:1527189132454};\\\", \\\"{x:1391,y:679,t:1527189132471};\\\", \\\"{x:1416,y:675,t:1527189132488};\\\", \\\"{x:1455,y:669,t:1527189132504};\\\", \\\"{x:1474,y:666,t:1527189132520};\\\", \\\"{x:1483,y:665,t:1527189132538};\\\", \\\"{x:1486,y:665,t:1527189132554};\\\", \\\"{x:1487,y:665,t:1527189132570};\\\", \\\"{x:1485,y:665,t:1527189132697};\\\", \\\"{x:1480,y:665,t:1527189132704};\\\", \\\"{x:1466,y:665,t:1527189132721};\\\", \\\"{x:1456,y:665,t:1527189132738};\\\", \\\"{x:1448,y:665,t:1527189132755};\\\", \\\"{x:1438,y:667,t:1527189132771};\\\", \\\"{x:1423,y:671,t:1527189132788};\\\", \\\"{x:1406,y:678,t:1527189132805};\\\", \\\"{x:1390,y:686,t:1527189132821};\\\", \\\"{x:1374,y:694,t:1527189132838};\\\", \\\"{x:1357,y:700,t:1527189132855};\\\", \\\"{x:1349,y:705,t:1527189132871};\\\", \\\"{x:1348,y:706,t:1527189132887};\\\", \\\"{x:1347,y:707,t:1527189132905};\\\", \\\"{x:1346,y:707,t:1527189132937};\\\", \\\"{x:1345,y:708,t:1527189132953};\\\", \\\"{x:1344,y:709,t:1527189132960};\\\", \\\"{x:1342,y:710,t:1527189132971};\\\", \\\"{x:1340,y:711,t:1527189132988};\\\", \\\"{x:1337,y:713,t:1527189133006};\\\", \\\"{x:1336,y:714,t:1527189133021};\\\", \\\"{x:1333,y:714,t:1527189136289};\\\", \\\"{x:1291,y:714,t:1527189136307};\\\", \\\"{x:1224,y:714,t:1527189136323};\\\", \\\"{x:1136,y:714,t:1527189136340};\\\", \\\"{x:1025,y:714,t:1527189136357};\\\", \\\"{x:884,y:714,t:1527189136374};\\\", \\\"{x:740,y:714,t:1527189136390};\\\", \\\"{x:615,y:711,t:1527189136407};\\\", \\\"{x:450,y:707,t:1527189136425};\\\", \\\"{x:356,y:705,t:1527189136440};\\\", \\\"{x:283,y:705,t:1527189136457};\\\", \\\"{x:232,y:702,t:1527189136474};\\\", \\\"{x:197,y:702,t:1527189136490};\\\", \\\"{x:169,y:702,t:1527189136507};\\\", \\\"{x:144,y:702,t:1527189136524};\\\", \\\"{x:129,y:702,t:1527189136540};\\\", \\\"{x:121,y:702,t:1527189136557};\\\", \\\"{x:119,y:702,t:1527189136574};\\\", \\\"{x:118,y:702,t:1527189136589};\\\", \\\"{x:117,y:701,t:1527189136639};\\\", \\\"{x:117,y:695,t:1527189136657};\\\", \\\"{x:117,y:684,t:1527189136674};\\\", \\\"{x:117,y:669,t:1527189136691};\\\", \\\"{x:120,y:648,t:1527189136706};\\\", \\\"{x:125,y:634,t:1527189136724};\\\", \\\"{x:129,y:621,t:1527189136741};\\\", \\\"{x:132,y:608,t:1527189136758};\\\", \\\"{x:134,y:601,t:1527189136775};\\\", \\\"{x:136,y:597,t:1527189136790};\\\", \\\"{x:139,y:593,t:1527189136808};\\\", \\\"{x:139,y:591,t:1527189136825};\\\", \\\"{x:140,y:589,t:1527189136841};\\\", \\\"{x:142,y:586,t:1527189136858};\\\", \\\"{x:145,y:583,t:1527189136875};\\\", \\\"{x:146,y:581,t:1527189136892};\\\", \\\"{x:148,y:577,t:1527189136907};\\\", \\\"{x:149,y:575,t:1527189136924};\\\", \\\"{x:151,y:572,t:1527189136941};\\\", \\\"{x:153,y:568,t:1527189136958};\\\", \\\"{x:156,y:565,t:1527189136975};\\\", \\\"{x:160,y:560,t:1527189136992};\\\", \\\"{x:163,y:556,t:1527189137008};\\\", \\\"{x:165,y:551,t:1527189137025};\\\", \\\"{x:167,y:548,t:1527189137041};\\\", \\\"{x:167,y:546,t:1527189137058};\\\", \\\"{x:167,y:545,t:1527189137074};\\\", \\\"{x:167,y:544,t:1527189137092};\\\", \\\"{x:167,y:543,t:1527189137109};\\\", \\\"{x:167,y:540,t:1527189137125};\\\", \\\"{x:167,y:539,t:1527189137142};\\\", \\\"{x:167,y:536,t:1527189137158};\\\", \\\"{x:167,y:532,t:1527189137175};\\\", \\\"{x:167,y:531,t:1527189137191};\\\", \\\"{x:167,y:530,t:1527189137209};\\\", \\\"{x:167,y:529,t:1527189137232};\\\", \\\"{x:172,y:529,t:1527189137656};\\\", \\\"{x:183,y:535,t:1527189137664};\\\", \\\"{x:193,y:540,t:1527189137675};\\\", \\\"{x:213,y:552,t:1527189137691};\\\", \\\"{x:232,y:562,t:1527189137709};\\\", \\\"{x:250,y:573,t:1527189137725};\\\", \\\"{x:273,y:585,t:1527189137743};\\\", \\\"{x:304,y:599,t:1527189137759};\\\", \\\"{x:343,y:615,t:1527189137776};\\\", \\\"{x:374,y:627,t:1527189137791};\\\", \\\"{x:398,y:636,t:1527189137809};\\\", \\\"{x:422,y:646,t:1527189137826};\\\", \\\"{x:440,y:655,t:1527189137841};\\\", \\\"{x:459,y:665,t:1527189137859};\\\", \\\"{x:476,y:676,t:1527189137877};\\\", \\\"{x:488,y:682,t:1527189137892};\\\", \\\"{x:500,y:689,t:1527189137909};\\\", \\\"{x:508,y:695,t:1527189137926};\\\", \\\"{x:515,y:699,t:1527189137942};\\\", \\\"{x:518,y:701,t:1527189137959};\\\", \\\"{x:524,y:706,t:1527189137976};\\\", \\\"{x:527,y:710,t:1527189137992};\\\", \\\"{x:530,y:715,t:1527189138009};\\\", \\\"{x:532,y:718,t:1527189138026};\\\", \\\"{x:533,y:722,t:1527189138044};\\\", \\\"{x:535,y:725,t:1527189138059};\\\", \\\"{x:536,y:729,t:1527189138076};\\\", \\\"{x:538,y:735,t:1527189138092};\\\", \\\"{x:539,y:738,t:1527189138109};\\\", \\\"{x:539,y:740,t:1527189138126};\\\", \\\"{x:540,y:742,t:1527189138141};\\\", \\\"{x:540,y:741,t:1527189138553};\\\", \\\"{x:540,y:740,t:1527189138560};\\\" ] }, { \\\"rt\\\": 30462, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 553109, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -Z -04 PM-04 PM-F -B -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:739,t:1527189142521};\\\", \\\"{x:537,y:738,t:1527189142544};\\\", \\\"{x:532,y:738,t:1527189142552};\\\", \\\"{x:520,y:735,t:1527189142568};\\\", \\\"{x:511,y:734,t:1527189142585};\\\", \\\"{x:525,y:734,t:1527189143375};\\\", \\\"{x:538,y:734,t:1527189143386};\\\", \\\"{x:557,y:734,t:1527189143404};\\\", \\\"{x:580,y:734,t:1527189143420};\\\", \\\"{x:622,y:734,t:1527189143437};\\\", \\\"{x:713,y:734,t:1527189143454};\\\", \\\"{x:774,y:734,t:1527189143462};\\\", \\\"{x:993,y:734,t:1527189143479};\\\", \\\"{x:1169,y:712,t:1527189143496};\\\", \\\"{x:1349,y:689,t:1527189143512};\\\", \\\"{x:1529,y:660,t:1527189143530};\\\", \\\"{x:1674,y:647,t:1527189143547};\\\", \\\"{x:1779,y:635,t:1527189143562};\\\", \\\"{x:1836,y:634,t:1527189143580};\\\", \\\"{x:1857,y:631,t:1527189143597};\\\", \\\"{x:1859,y:631,t:1527189143613};\\\", \\\"{x:1856,y:631,t:1527189143751};\\\", \\\"{x:1854,y:631,t:1527189143763};\\\", \\\"{x:1843,y:633,t:1527189143780};\\\", \\\"{x:1834,y:637,t:1527189143797};\\\", \\\"{x:1824,y:638,t:1527189143813};\\\", \\\"{x:1810,y:641,t:1527189143830};\\\", \\\"{x:1791,y:646,t:1527189143847};\\\", \\\"{x:1762,y:651,t:1527189143863};\\\", \\\"{x:1742,y:653,t:1527189143880};\\\", \\\"{x:1719,y:656,t:1527189143897};\\\", \\\"{x:1699,y:658,t:1527189143913};\\\", \\\"{x:1679,y:663,t:1527189143930};\\\", \\\"{x:1668,y:663,t:1527189143947};\\\", \\\"{x:1658,y:665,t:1527189143964};\\\", \\\"{x:1652,y:666,t:1527189143980};\\\", \\\"{x:1648,y:666,t:1527189143997};\\\", \\\"{x:1647,y:666,t:1527189144014};\\\", \\\"{x:1646,y:666,t:1527189144029};\\\", \\\"{x:1645,y:666,t:1527189144055};\\\", \\\"{x:1644,y:666,t:1527189144319};\\\", \\\"{x:1643,y:666,t:1527189144331};\\\", \\\"{x:1641,y:666,t:1527189144347};\\\", \\\"{x:1639,y:665,t:1527189144364};\\\", \\\"{x:1635,y:663,t:1527189144381};\\\", \\\"{x:1634,y:662,t:1527189144397};\\\", \\\"{x:1633,y:662,t:1527189144415};\\\", \\\"{x:1632,y:662,t:1527189144617};\\\", \\\"{x:1630,y:662,t:1527189144633};\\\", \\\"{x:1628,y:662,t:1527189144649};\\\", \\\"{x:1627,y:662,t:1527189144665};\\\", \\\"{x:1622,y:662,t:1527189144682};\\\", \\\"{x:1619,y:662,t:1527189144699};\\\", \\\"{x:1614,y:662,t:1527189144715};\\\", \\\"{x:1608,y:663,t:1527189144732};\\\", \\\"{x:1599,y:664,t:1527189144748};\\\", \\\"{x:1590,y:666,t:1527189144765};\\\", \\\"{x:1580,y:669,t:1527189144783};\\\", \\\"{x:1571,y:670,t:1527189144798};\\\", \\\"{x:1560,y:673,t:1527189144815};\\\", \\\"{x:1548,y:676,t:1527189144831};\\\", \\\"{x:1535,y:680,t:1527189144848};\\\", \\\"{x:1523,y:683,t:1527189144864};\\\", \\\"{x:1512,y:687,t:1527189144881};\\\", \\\"{x:1501,y:690,t:1527189144899};\\\", \\\"{x:1487,y:697,t:1527189144916};\\\", \\\"{x:1473,y:703,t:1527189144932};\\\", \\\"{x:1457,y:710,t:1527189144949};\\\", \\\"{x:1435,y:721,t:1527189144966};\\\", \\\"{x:1418,y:731,t:1527189144982};\\\", \\\"{x:1400,y:741,t:1527189144998};\\\", \\\"{x:1384,y:750,t:1527189145015};\\\", \\\"{x:1373,y:759,t:1527189145032};\\\", \\\"{x:1365,y:768,t:1527189145048};\\\", \\\"{x:1365,y:773,t:1527189145066};\\\", \\\"{x:1365,y:774,t:1527189145082};\\\", \\\"{x:1365,y:776,t:1527189145098};\\\", \\\"{x:1364,y:777,t:1527189146121};\\\", \\\"{x:1363,y:777,t:1527189146136};\\\", \\\"{x:1362,y:777,t:1527189146160};\\\", \\\"{x:1361,y:777,t:1527189146185};\\\", \\\"{x:1360,y:777,t:1527189148297};\\\", \\\"{x:1364,y:775,t:1527189148304};\\\", \\\"{x:1375,y:772,t:1527189148319};\\\", \\\"{x:1407,y:764,t:1527189148335};\\\", \\\"{x:1447,y:753,t:1527189148352};\\\", \\\"{x:1511,y:735,t:1527189148368};\\\", \\\"{x:1543,y:729,t:1527189148386};\\\", \\\"{x:1564,y:723,t:1527189148402};\\\", \\\"{x:1580,y:719,t:1527189148419};\\\", \\\"{x:1589,y:718,t:1527189148436};\\\", \\\"{x:1594,y:716,t:1527189148452};\\\", \\\"{x:1595,y:716,t:1527189148468};\\\", \\\"{x:1597,y:715,t:1527189148486};\\\", \\\"{x:1604,y:714,t:1527189148501};\\\", \\\"{x:1611,y:711,t:1527189148519};\\\", \\\"{x:1615,y:710,t:1527189148536};\\\", \\\"{x:1618,y:708,t:1527189148552};\\\", \\\"{x:1619,y:708,t:1527189148569};\\\", \\\"{x:1619,y:707,t:1527189148697};\\\", \\\"{x:1619,y:706,t:1527189148704};\\\", \\\"{x:1619,y:705,t:1527189148719};\\\", \\\"{x:1619,y:703,t:1527189148736};\\\", \\\"{x:1617,y:701,t:1527189148755};\\\", \\\"{x:1616,y:700,t:1527189148768};\\\", \\\"{x:1615,y:699,t:1527189148816};\\\", \\\"{x:1614,y:699,t:1527189149184};\\\", \\\"{x:1615,y:705,t:1527189149204};\\\", \\\"{x:1615,y:709,t:1527189149220};\\\", \\\"{x:1618,y:717,t:1527189149235};\\\", \\\"{x:1619,y:726,t:1527189149252};\\\", \\\"{x:1622,y:735,t:1527189149270};\\\", \\\"{x:1625,y:743,t:1527189149287};\\\", \\\"{x:1626,y:748,t:1527189149303};\\\", \\\"{x:1627,y:752,t:1527189149319};\\\", \\\"{x:1627,y:758,t:1527189149336};\\\", \\\"{x:1628,y:762,t:1527189149353};\\\", \\\"{x:1628,y:765,t:1527189149370};\\\", \\\"{x:1628,y:769,t:1527189149387};\\\", \\\"{x:1629,y:771,t:1527189149402};\\\", \\\"{x:1629,y:774,t:1527189149419};\\\", \\\"{x:1629,y:777,t:1527189149436};\\\", \\\"{x:1629,y:778,t:1527189149452};\\\", \\\"{x:1629,y:780,t:1527189149470};\\\", \\\"{x:1629,y:782,t:1527189149486};\\\", \\\"{x:1629,y:785,t:1527189149502};\\\", \\\"{x:1629,y:786,t:1527189149520};\\\", \\\"{x:1629,y:792,t:1527189149535};\\\", \\\"{x:1629,y:793,t:1527189149552};\\\", \\\"{x:1629,y:792,t:1527189149697};\\\", \\\"{x:1629,y:789,t:1527189149704};\\\", \\\"{x:1629,y:786,t:1527189149720};\\\", \\\"{x:1629,y:778,t:1527189149736};\\\", \\\"{x:1629,y:773,t:1527189149754};\\\", \\\"{x:1627,y:764,t:1527189149769};\\\", \\\"{x:1626,y:758,t:1527189149786};\\\", \\\"{x:1626,y:753,t:1527189149803};\\\", \\\"{x:1625,y:747,t:1527189149820};\\\", \\\"{x:1622,y:742,t:1527189149837};\\\", \\\"{x:1621,y:737,t:1527189149854};\\\", \\\"{x:1619,y:730,t:1527189149869};\\\", \\\"{x:1617,y:725,t:1527189149887};\\\", \\\"{x:1617,y:719,t:1527189149904};\\\", \\\"{x:1615,y:713,t:1527189149920};\\\", \\\"{x:1614,y:711,t:1527189149937};\\\", \\\"{x:1613,y:708,t:1527189149953};\\\", \\\"{x:1612,y:707,t:1527189149970};\\\", \\\"{x:1611,y:705,t:1527189149987};\\\", \\\"{x:1611,y:704,t:1527189150004};\\\", \\\"{x:1611,y:702,t:1527189150021};\\\", \\\"{x:1611,y:701,t:1527189150041};\\\", \\\"{x:1610,y:700,t:1527189150160};\\\", \\\"{x:1610,y:701,t:1527189150185};\\\", \\\"{x:1610,y:705,t:1527189150192};\\\", \\\"{x:1610,y:706,t:1527189150204};\\\", \\\"{x:1610,y:712,t:1527189150220};\\\", \\\"{x:1610,y:717,t:1527189150237};\\\", \\\"{x:1611,y:723,t:1527189150253};\\\", \\\"{x:1611,y:727,t:1527189150270};\\\", \\\"{x:1611,y:731,t:1527189150287};\\\", \\\"{x:1611,y:735,t:1527189150304};\\\", \\\"{x:1611,y:739,t:1527189150320};\\\", \\\"{x:1611,y:744,t:1527189150337};\\\", \\\"{x:1611,y:748,t:1527189150353};\\\", \\\"{x:1611,y:753,t:1527189150371};\\\", \\\"{x:1611,y:758,t:1527189150387};\\\", \\\"{x:1611,y:764,t:1527189150403};\\\", \\\"{x:1612,y:768,t:1527189150420};\\\", \\\"{x:1612,y:770,t:1527189150437};\\\", \\\"{x:1615,y:776,t:1527189150453};\\\", \\\"{x:1616,y:779,t:1527189150470};\\\", \\\"{x:1617,y:786,t:1527189150487};\\\", \\\"{x:1617,y:790,t:1527189150504};\\\", \\\"{x:1617,y:792,t:1527189150521};\\\", \\\"{x:1619,y:795,t:1527189150538};\\\", \\\"{x:1619,y:797,t:1527189150554};\\\", \\\"{x:1619,y:802,t:1527189150571};\\\", \\\"{x:1619,y:812,t:1527189150587};\\\", \\\"{x:1619,y:820,t:1527189150605};\\\", \\\"{x:1621,y:834,t:1527189150620};\\\", \\\"{x:1621,y:851,t:1527189150637};\\\", \\\"{x:1621,y:862,t:1527189150655};\\\", \\\"{x:1621,y:870,t:1527189150671};\\\", \\\"{x:1621,y:880,t:1527189150688};\\\", \\\"{x:1621,y:886,t:1527189150704};\\\", \\\"{x:1621,y:891,t:1527189150721};\\\", \\\"{x:1621,y:895,t:1527189150738};\\\", \\\"{x:1621,y:899,t:1527189150754};\\\", \\\"{x:1621,y:903,t:1527189150770};\\\", \\\"{x:1622,y:908,t:1527189150787};\\\", \\\"{x:1622,y:911,t:1527189150805};\\\", \\\"{x:1623,y:917,t:1527189150820};\\\", \\\"{x:1624,y:922,t:1527189150837};\\\", \\\"{x:1624,y:925,t:1527189150854};\\\", \\\"{x:1625,y:931,t:1527189150870};\\\", \\\"{x:1626,y:939,t:1527189150888};\\\", \\\"{x:1626,y:944,t:1527189150905};\\\", \\\"{x:1626,y:950,t:1527189150920};\\\", \\\"{x:1626,y:955,t:1527189150937};\\\", \\\"{x:1626,y:958,t:1527189150954};\\\", \\\"{x:1626,y:960,t:1527189150970};\\\", \\\"{x:1626,y:961,t:1527189150988};\\\", \\\"{x:1626,y:964,t:1527189151004};\\\", \\\"{x:1625,y:966,t:1527189151022};\\\", \\\"{x:1625,y:969,t:1527189151038};\\\", \\\"{x:1625,y:975,t:1527189151054};\\\", \\\"{x:1624,y:984,t:1527189151071};\\\", \\\"{x:1623,y:988,t:1527189151088};\\\", \\\"{x:1623,y:989,t:1527189151105};\\\", \\\"{x:1623,y:988,t:1527189151288};\\\", \\\"{x:1623,y:986,t:1527189151305};\\\", \\\"{x:1623,y:984,t:1527189151322};\\\", \\\"{x:1623,y:982,t:1527189151339};\\\", \\\"{x:1623,y:981,t:1527189151355};\\\", \\\"{x:1623,y:979,t:1527189151372};\\\", \\\"{x:1623,y:978,t:1527189151392};\\\", \\\"{x:1623,y:976,t:1527189151408};\\\", \\\"{x:1623,y:975,t:1527189151424};\\\", \\\"{x:1623,y:973,t:1527189151448};\\\", \\\"{x:1623,y:972,t:1527189151481};\\\", \\\"{x:1623,y:971,t:1527189151553};\\\", \\\"{x:1623,y:970,t:1527189151953};\\\", \\\"{x:1623,y:969,t:1527189151960};\\\", \\\"{x:1623,y:967,t:1527189151984};\\\", \\\"{x:1623,y:966,t:1527189151992};\\\", \\\"{x:1623,y:964,t:1527189152041};\\\", \\\"{x:1623,y:963,t:1527189152056};\\\", \\\"{x:1623,y:961,t:1527189152073};\\\", \\\"{x:1623,y:960,t:1527189152096};\\\", \\\"{x:1623,y:958,t:1527189152128};\\\", \\\"{x:1623,y:957,t:1527189152161};\\\", \\\"{x:1622,y:957,t:1527189152173};\\\", \\\"{x:1622,y:955,t:1527189152208};\\\", \\\"{x:1621,y:953,t:1527189152241};\\\", \\\"{x:1621,y:952,t:1527189152257};\\\", \\\"{x:1621,y:951,t:1527189152273};\\\", \\\"{x:1621,y:949,t:1527189152289};\\\", \\\"{x:1620,y:947,t:1527189152307};\\\", \\\"{x:1619,y:944,t:1527189152323};\\\", \\\"{x:1618,y:942,t:1527189152340};\\\", \\\"{x:1617,y:940,t:1527189152356};\\\", \\\"{x:1617,y:938,t:1527189152373};\\\", \\\"{x:1617,y:936,t:1527189152390};\\\", \\\"{x:1614,y:932,t:1527189152405};\\\", \\\"{x:1613,y:928,t:1527189152422};\\\", \\\"{x:1609,y:919,t:1527189152439};\\\", \\\"{x:1606,y:913,t:1527189152456};\\\", \\\"{x:1604,y:907,t:1527189152472};\\\", \\\"{x:1597,y:895,t:1527189152489};\\\", \\\"{x:1588,y:881,t:1527189152505};\\\", \\\"{x:1578,y:867,t:1527189152522};\\\", \\\"{x:1568,y:856,t:1527189152539};\\\", \\\"{x:1556,y:845,t:1527189152555};\\\", \\\"{x:1541,y:834,t:1527189152573};\\\", \\\"{x:1529,y:823,t:1527189152589};\\\", \\\"{x:1511,y:811,t:1527189152606};\\\", \\\"{x:1491,y:796,t:1527189152623};\\\", \\\"{x:1464,y:783,t:1527189152639};\\\", \\\"{x:1445,y:776,t:1527189152655};\\\", \\\"{x:1427,y:769,t:1527189152672};\\\", \\\"{x:1415,y:763,t:1527189152690};\\\", \\\"{x:1405,y:757,t:1527189152707};\\\", \\\"{x:1395,y:752,t:1527189152723};\\\", \\\"{x:1389,y:748,t:1527189152739};\\\", \\\"{x:1384,y:743,t:1527189152757};\\\", \\\"{x:1376,y:737,t:1527189152773};\\\", \\\"{x:1370,y:732,t:1527189152790};\\\", \\\"{x:1367,y:730,t:1527189152806};\\\", \\\"{x:1364,y:725,t:1527189152822};\\\", \\\"{x:1357,y:720,t:1527189152840};\\\", \\\"{x:1353,y:716,t:1527189152856};\\\", \\\"{x:1350,y:713,t:1527189152873};\\\", \\\"{x:1345,y:710,t:1527189152890};\\\", \\\"{x:1342,y:708,t:1527189152907};\\\", \\\"{x:1340,y:706,t:1527189152923};\\\", \\\"{x:1339,y:705,t:1527189152944};\\\", \\\"{x:1338,y:704,t:1527189152968};\\\", \\\"{x:1337,y:703,t:1527189152976};\\\", \\\"{x:1336,y:702,t:1527189153016};\\\", \\\"{x:1337,y:702,t:1527189153216};\\\", \\\"{x:1338,y:702,t:1527189153224};\\\", \\\"{x:1340,y:700,t:1527189153240};\\\", \\\"{x:1341,y:700,t:1527189153265};\\\", \\\"{x:1342,y:700,t:1527189153329};\\\", \\\"{x:1343,y:700,t:1527189153341};\\\", \\\"{x:1343,y:699,t:1527189153357};\\\", \\\"{x:1344,y:699,t:1527189153376};\\\", \\\"{x:1345,y:699,t:1527189153392};\\\", \\\"{x:1346,y:699,t:1527189156216};\\\", \\\"{x:1347,y:699,t:1527189156232};\\\", \\\"{x:1348,y:699,t:1527189156243};\\\", \\\"{x:1351,y:697,t:1527189156260};\\\", \\\"{x:1350,y:697,t:1527189156584};\\\", \\\"{x:1344,y:697,t:1527189156594};\\\", \\\"{x:1330,y:695,t:1527189156611};\\\", \\\"{x:1312,y:691,t:1527189156628};\\\", \\\"{x:1295,y:687,t:1527189156644};\\\", \\\"{x:1274,y:684,t:1527189156660};\\\", \\\"{x:1243,y:679,t:1527189156678};\\\", \\\"{x:1190,y:672,t:1527189156694};\\\", \\\"{x:1124,y:663,t:1527189156711};\\\", \\\"{x:1035,y:652,t:1527189156728};\\\", \\\"{x:895,y:635,t:1527189156745};\\\", \\\"{x:823,y:624,t:1527189156762};\\\", \\\"{x:762,y:617,t:1527189156776};\\\", \\\"{x:709,y:611,t:1527189156794};\\\", \\\"{x:686,y:610,t:1527189156807};\\\", \\\"{x:651,y:604,t:1527189156823};\\\", \\\"{x:643,y:603,t:1527189156841};\\\", \\\"{x:642,y:603,t:1527189156856};\\\", \\\"{x:639,y:602,t:1527189156873};\\\", \\\"{x:638,y:602,t:1527189156890};\\\", \\\"{x:637,y:601,t:1527189156907};\\\", \\\"{x:636,y:601,t:1527189156924};\\\", \\\"{x:635,y:600,t:1527189156942};\\\", \\\"{x:633,y:598,t:1527189156957};\\\", \\\"{x:633,y:595,t:1527189156974};\\\", \\\"{x:632,y:591,t:1527189156992};\\\", \\\"{x:632,y:587,t:1527189157007};\\\", \\\"{x:630,y:583,t:1527189157025};\\\", \\\"{x:630,y:582,t:1527189157040};\\\", \\\"{x:629,y:581,t:1527189157058};\\\", \\\"{x:627,y:581,t:1527189157074};\\\", \\\"{x:618,y:581,t:1527189157090};\\\", \\\"{x:603,y:581,t:1527189157108};\\\", \\\"{x:586,y:581,t:1527189157125};\\\", \\\"{x:564,y:581,t:1527189157140};\\\", \\\"{x:538,y:581,t:1527189157157};\\\", \\\"{x:516,y:581,t:1527189157175};\\\", \\\"{x:494,y:581,t:1527189157191};\\\", \\\"{x:474,y:581,t:1527189157207};\\\", \\\"{x:465,y:581,t:1527189157224};\\\", \\\"{x:455,y:578,t:1527189157241};\\\", \\\"{x:444,y:578,t:1527189157258};\\\", \\\"{x:433,y:578,t:1527189157274};\\\", \\\"{x:419,y:578,t:1527189157290};\\\", \\\"{x:403,y:578,t:1527189157309};\\\", \\\"{x:381,y:578,t:1527189157324};\\\", \\\"{x:370,y:578,t:1527189157341};\\\", \\\"{x:369,y:578,t:1527189157357};\\\", \\\"{x:367,y:578,t:1527189157378};\\\", \\\"{x:364,y:578,t:1527189157394};\\\", \\\"{x:358,y:578,t:1527189157411};\\\", \\\"{x:356,y:578,t:1527189157428};\\\", \\\"{x:355,y:578,t:1527189157444};\\\", \\\"{x:358,y:578,t:1527189157491};\\\", \\\"{x:361,y:578,t:1527189157498};\\\", \\\"{x:362,y:578,t:1527189157511};\\\", \\\"{x:363,y:578,t:1527189157780};\\\", \\\"{x:387,y:577,t:1527189157797};\\\", \\\"{x:465,y:566,t:1527189157811};\\\", \\\"{x:543,y:555,t:1527189157828};\\\", \\\"{x:609,y:547,t:1527189157844};\\\", \\\"{x:660,y:539,t:1527189157861};\\\", \\\"{x:699,y:534,t:1527189157878};\\\", \\\"{x:721,y:529,t:1527189157894};\\\", \\\"{x:729,y:528,t:1527189157912};\\\", \\\"{x:732,y:527,t:1527189157928};\\\", \\\"{x:737,y:526,t:1527189157945};\\\", \\\"{x:740,y:524,t:1527189157962};\\\", \\\"{x:746,y:522,t:1527189157978};\\\", \\\"{x:751,y:520,t:1527189157995};\\\", \\\"{x:752,y:518,t:1527189158012};\\\", \\\"{x:753,y:517,t:1527189158028};\\\", \\\"{x:754,y:517,t:1527189158078};\\\", \\\"{x:763,y:517,t:1527189158094};\\\", \\\"{x:772,y:513,t:1527189158111};\\\", \\\"{x:784,y:511,t:1527189158128};\\\", \\\"{x:798,y:508,t:1527189158145};\\\", \\\"{x:808,y:507,t:1527189158161};\\\", \\\"{x:815,y:506,t:1527189158178};\\\", \\\"{x:824,y:505,t:1527189158195};\\\", \\\"{x:827,y:504,t:1527189158212};\\\", \\\"{x:830,y:503,t:1527189158228};\\\", \\\"{x:831,y:503,t:1527189158250};\\\", \\\"{x:834,y:503,t:1527189158683};\\\", \\\"{x:840,y:504,t:1527189158696};\\\", \\\"{x:859,y:513,t:1527189158713};\\\", \\\"{x:884,y:524,t:1527189158730};\\\", \\\"{x:919,y:537,t:1527189158746};\\\", \\\"{x:974,y:561,t:1527189158763};\\\", \\\"{x:1064,y:599,t:1527189158779};\\\", \\\"{x:1119,y:622,t:1527189158797};\\\", \\\"{x:1161,y:642,t:1527189158813};\\\", \\\"{x:1200,y:659,t:1527189158829};\\\", \\\"{x:1236,y:674,t:1527189158847};\\\", \\\"{x:1270,y:690,t:1527189158862};\\\", \\\"{x:1293,y:699,t:1527189158879};\\\", \\\"{x:1308,y:708,t:1527189158897};\\\", \\\"{x:1317,y:714,t:1527189158913};\\\", \\\"{x:1331,y:724,t:1527189158929};\\\", \\\"{x:1346,y:731,t:1527189158947};\\\", \\\"{x:1360,y:737,t:1527189158962};\\\", \\\"{x:1363,y:737,t:1527189158979};\\\", \\\"{x:1364,y:738,t:1527189159028};\\\", \\\"{x:1365,y:739,t:1527189159092};\\\", \\\"{x:1365,y:740,t:1527189159140};\\\", \\\"{x:1364,y:742,t:1527189159148};\\\", \\\"{x:1363,y:742,t:1527189159163};\\\", \\\"{x:1356,y:745,t:1527189159180};\\\", \\\"{x:1352,y:749,t:1527189159197};\\\", \\\"{x:1346,y:753,t:1527189159212};\\\", \\\"{x:1341,y:757,t:1527189159229};\\\", \\\"{x:1338,y:758,t:1527189159246};\\\", \\\"{x:1336,y:759,t:1527189159263};\\\", \\\"{x:1335,y:760,t:1527189159356};\\\", \\\"{x:1334,y:760,t:1527189159371};\\\", \\\"{x:1332,y:760,t:1527189159379};\\\", \\\"{x:1330,y:761,t:1527189159396};\\\", \\\"{x:1325,y:764,t:1527189159414};\\\", \\\"{x:1319,y:766,t:1527189159429};\\\", \\\"{x:1309,y:768,t:1527189159447};\\\", \\\"{x:1308,y:769,t:1527189159463};\\\", \\\"{x:1303,y:769,t:1527189159479};\\\", \\\"{x:1302,y:769,t:1527189159496};\\\", \\\"{x:1304,y:769,t:1527189160028};\\\", \\\"{x:1310,y:773,t:1527189160036};\\\", \\\"{x:1313,y:773,t:1527189160047};\\\", \\\"{x:1317,y:773,t:1527189160064};\\\", \\\"{x:1320,y:773,t:1527189160081};\\\", \\\"{x:1322,y:773,t:1527189160097};\\\", \\\"{x:1325,y:773,t:1527189160114};\\\", \\\"{x:1331,y:773,t:1527189160131};\\\", \\\"{x:1339,y:773,t:1527189160148};\\\", \\\"{x:1346,y:773,t:1527189160164};\\\", \\\"{x:1356,y:773,t:1527189160180};\\\", \\\"{x:1364,y:773,t:1527189160197};\\\", \\\"{x:1374,y:773,t:1527189160214};\\\", \\\"{x:1384,y:772,t:1527189160231};\\\", \\\"{x:1388,y:771,t:1527189160248};\\\", \\\"{x:1391,y:769,t:1527189160264};\\\", \\\"{x:1395,y:767,t:1527189160281};\\\", \\\"{x:1398,y:765,t:1527189160298};\\\", \\\"{x:1400,y:765,t:1527189160314};\\\", \\\"{x:1401,y:763,t:1527189160331};\\\", \\\"{x:1403,y:762,t:1527189160348};\\\", \\\"{x:1403,y:761,t:1527189160428};\\\", \\\"{x:1397,y:761,t:1527189160436};\\\", \\\"{x:1390,y:761,t:1527189160448};\\\", \\\"{x:1382,y:761,t:1527189160465};\\\", \\\"{x:1379,y:761,t:1527189160481};\\\", \\\"{x:1378,y:761,t:1527189160498};\\\", \\\"{x:1377,y:761,t:1527189160515};\\\", \\\"{x:1375,y:761,t:1527189160530};\\\", \\\"{x:1373,y:761,t:1527189160555};\\\", \\\"{x:1372,y:761,t:1527189160571};\\\", \\\"{x:1370,y:761,t:1527189160586};\\\", \\\"{x:1368,y:761,t:1527189160597};\\\", \\\"{x:1365,y:762,t:1527189160615};\\\", \\\"{x:1362,y:763,t:1527189160630};\\\", \\\"{x:1361,y:764,t:1527189160648};\\\", \\\"{x:1369,y:764,t:1527189161156};\\\", \\\"{x:1382,y:764,t:1527189161165};\\\", \\\"{x:1411,y:764,t:1527189161182};\\\", \\\"{x:1438,y:764,t:1527189161197};\\\", \\\"{x:1462,y:764,t:1527189161215};\\\", \\\"{x:1485,y:764,t:1527189161232};\\\", \\\"{x:1506,y:764,t:1527189161249};\\\", \\\"{x:1521,y:764,t:1527189161265};\\\", \\\"{x:1528,y:765,t:1527189161282};\\\", \\\"{x:1531,y:765,t:1527189161298};\\\", \\\"{x:1530,y:765,t:1527189161475};\\\", \\\"{x:1529,y:765,t:1527189161484};\\\", \\\"{x:1527,y:765,t:1527189161499};\\\", \\\"{x:1526,y:765,t:1527189161540};\\\", \\\"{x:1524,y:765,t:1527189161563};\\\", \\\"{x:1522,y:765,t:1527189161582};\\\", \\\"{x:1519,y:765,t:1527189161598};\\\", \\\"{x:1513,y:765,t:1527189161614};\\\", \\\"{x:1508,y:765,t:1527189161632};\\\", \\\"{x:1501,y:765,t:1527189161648};\\\", \\\"{x:1493,y:765,t:1527189161666};\\\", \\\"{x:1489,y:765,t:1527189161681};\\\", \\\"{x:1488,y:765,t:1527189161699};\\\", \\\"{x:1489,y:763,t:1527189161900};\\\", \\\"{x:1490,y:763,t:1527189161915};\\\", \\\"{x:1490,y:762,t:1527189161932};\\\", \\\"{x:1491,y:761,t:1527189161956};\\\", \\\"{x:1492,y:761,t:1527189161966};\\\", \\\"{x:1492,y:760,t:1527189161996};\\\", \\\"{x:1493,y:760,t:1527189162011};\\\", \\\"{x:1494,y:760,t:1527189162028};\\\", \\\"{x:1495,y:759,t:1527189162036};\\\", \\\"{x:1496,y:759,t:1527189162049};\\\", \\\"{x:1497,y:759,t:1527189162066};\\\", \\\"{x:1498,y:758,t:1527189162083};\\\", \\\"{x:1499,y:758,t:1527189162140};\\\", \\\"{x:1500,y:758,t:1527189162164};\\\", \\\"{x:1502,y:758,t:1527189162172};\\\", \\\"{x:1502,y:759,t:1527189162183};\\\", \\\"{x:1502,y:765,t:1527189162199};\\\", \\\"{x:1502,y:770,t:1527189162216};\\\", \\\"{x:1502,y:777,t:1527189162233};\\\", \\\"{x:1502,y:783,t:1527189162249};\\\", \\\"{x:1502,y:787,t:1527189162266};\\\", \\\"{x:1502,y:791,t:1527189162283};\\\", \\\"{x:1502,y:795,t:1527189162299};\\\", \\\"{x:1500,y:800,t:1527189162315};\\\", \\\"{x:1500,y:803,t:1527189162333};\\\", \\\"{x:1499,y:806,t:1527189162349};\\\", \\\"{x:1497,y:811,t:1527189162366};\\\", \\\"{x:1496,y:813,t:1527189162383};\\\", \\\"{x:1493,y:817,t:1527189162399};\\\", \\\"{x:1492,y:820,t:1527189162416};\\\", \\\"{x:1490,y:824,t:1527189162433};\\\", \\\"{x:1490,y:825,t:1527189162449};\\\", \\\"{x:1490,y:826,t:1527189162468};\\\", \\\"{x:1490,y:828,t:1527189162492};\\\", \\\"{x:1489,y:829,t:1527189162500};\\\", \\\"{x:1489,y:830,t:1527189162981};\\\", \\\"{x:1488,y:832,t:1527189162988};\\\", \\\"{x:1486,y:832,t:1527189163004};\\\", \\\"{x:1484,y:832,t:1527189163017};\\\", \\\"{x:1483,y:833,t:1527189163033};\\\", \\\"{x:1482,y:833,t:1527189163051};\\\", \\\"{x:1481,y:834,t:1527189163140};\\\", \\\"{x:1481,y:835,t:1527189163155};\\\", \\\"{x:1480,y:835,t:1527189163251};\\\", \\\"{x:1480,y:833,t:1527189163611};\\\", \\\"{x:1480,y:832,t:1527189163764};\\\", \\\"{x:1481,y:832,t:1527189164739};\\\", \\\"{x:1483,y:832,t:1527189164764};\\\", \\\"{x:1483,y:833,t:1527189165188};\\\", \\\"{x:1461,y:830,t:1527189165203};\\\", \\\"{x:1387,y:810,t:1527189165219};\\\", \\\"{x:1298,y:783,t:1527189165235};\\\", \\\"{x:1142,y:749,t:1527189165252};\\\", \\\"{x:1038,y:729,t:1527189165268};\\\", \\\"{x:943,y:713,t:1527189165285};\\\", \\\"{x:865,y:702,t:1527189165302};\\\", \\\"{x:823,y:695,t:1527189165318};\\\", \\\"{x:804,y:689,t:1527189165334};\\\", \\\"{x:797,y:684,t:1527189165352};\\\", \\\"{x:796,y:683,t:1527189165367};\\\", \\\"{x:796,y:682,t:1527189165386};\\\", \\\"{x:796,y:680,t:1527189165402};\\\", \\\"{x:796,y:679,t:1527189165419};\\\", \\\"{x:796,y:677,t:1527189165435};\\\", \\\"{x:796,y:674,t:1527189165452};\\\", \\\"{x:796,y:670,t:1527189165469};\\\", \\\"{x:797,y:667,t:1527189165485};\\\", \\\"{x:797,y:662,t:1527189165501};\\\", \\\"{x:798,y:657,t:1527189165519};\\\", \\\"{x:798,y:652,t:1527189165535};\\\", \\\"{x:798,y:647,t:1527189165552};\\\", \\\"{x:797,y:642,t:1527189165569};\\\", \\\"{x:793,y:634,t:1527189165587};\\\", \\\"{x:787,y:630,t:1527189165603};\\\", \\\"{x:777,y:623,t:1527189165618};\\\", \\\"{x:765,y:618,t:1527189165635};\\\", \\\"{x:731,y:611,t:1527189165650};\\\", \\\"{x:701,y:605,t:1527189165667};\\\", \\\"{x:672,y:601,t:1527189165685};\\\", \\\"{x:641,y:596,t:1527189165702};\\\", \\\"{x:614,y:593,t:1527189165718};\\\", \\\"{x:598,y:590,t:1527189165734};\\\", \\\"{x:594,y:588,t:1527189165751};\\\", \\\"{x:591,y:586,t:1527189165769};\\\", \\\"{x:588,y:584,t:1527189165785};\\\", \\\"{x:586,y:582,t:1527189165802};\\\", \\\"{x:584,y:581,t:1527189165818};\\\", \\\"{x:582,y:580,t:1527189165835};\\\", \\\"{x:577,y:578,t:1527189165851};\\\", \\\"{x:575,y:578,t:1527189165869};\\\", \\\"{x:574,y:578,t:1527189165884};\\\", \\\"{x:569,y:578,t:1527189165901};\\\", \\\"{x:562,y:578,t:1527189165919};\\\", \\\"{x:557,y:578,t:1527189165934};\\\", \\\"{x:553,y:578,t:1527189165951};\\\", \\\"{x:547,y:578,t:1527189165969};\\\", \\\"{x:541,y:579,t:1527189165985};\\\", \\\"{x:538,y:580,t:1527189166001};\\\", \\\"{x:537,y:581,t:1527189166019};\\\", \\\"{x:537,y:582,t:1527189166035};\\\", \\\"{x:539,y:582,t:1527189166307};\\\", \\\"{x:551,y:583,t:1527189166318};\\\", \\\"{x:581,y:580,t:1527189166335};\\\", \\\"{x:624,y:579,t:1527189166352};\\\", \\\"{x:651,y:574,t:1527189166369};\\\", \\\"{x:657,y:574,t:1527189166386};\\\", \\\"{x:658,y:574,t:1527189166401};\\\", \\\"{x:649,y:574,t:1527189166532};\\\", \\\"{x:636,y:575,t:1527189166539};\\\", \\\"{x:621,y:576,t:1527189166552};\\\", \\\"{x:588,y:583,t:1527189166568};\\\", \\\"{x:560,y:585,t:1527189166585};\\\", \\\"{x:542,y:586,t:1527189166601};\\\", \\\"{x:540,y:586,t:1527189166618};\\\", \\\"{x:539,y:586,t:1527189166636};\\\", \\\"{x:542,y:586,t:1527189166683};\\\", \\\"{x:545,y:586,t:1527189166691};\\\", \\\"{x:548,y:586,t:1527189166702};\\\", \\\"{x:553,y:586,t:1527189166719};\\\", \\\"{x:556,y:586,t:1527189166736};\\\", \\\"{x:559,y:586,t:1527189166752};\\\", \\\"{x:562,y:586,t:1527189166768};\\\", \\\"{x:564,y:586,t:1527189166786};\\\", \\\"{x:565,y:586,t:1527189166802};\\\", \\\"{x:567,y:586,t:1527189166819};\\\", \\\"{x:568,y:586,t:1527189166836};\\\", \\\"{x:569,y:586,t:1527189166852};\\\", \\\"{x:570,y:586,t:1527189166947};\\\", \\\"{x:571,y:586,t:1527189166955};\\\", \\\"{x:572,y:586,t:1527189166971};\\\", \\\"{x:574,y:586,t:1527189166986};\\\", \\\"{x:577,y:586,t:1527189167003};\\\", \\\"{x:580,y:586,t:1527189167018};\\\", \\\"{x:588,y:586,t:1527189167035};\\\", \\\"{x:596,y:586,t:1527189167052};\\\", \\\"{x:606,y:586,t:1527189167070};\\\", \\\"{x:613,y:584,t:1527189167086};\\\", \\\"{x:619,y:582,t:1527189167102};\\\", \\\"{x:622,y:581,t:1527189167119};\\\", \\\"{x:623,y:581,t:1527189167138};\\\", \\\"{x:624,y:581,t:1527189167195};\\\", \\\"{x:623,y:581,t:1527189167332};\\\", \\\"{x:621,y:581,t:1527189167339};\\\", \\\"{x:620,y:581,t:1527189167353};\\\", \\\"{x:617,y:582,t:1527189167370};\\\", \\\"{x:616,y:582,t:1527189167386};\\\", \\\"{x:615,y:582,t:1527189167804};\\\", \\\"{x:612,y:582,t:1527189167819};\\\", \\\"{x:611,y:582,t:1527189168068};\\\", \\\"{x:614,y:585,t:1527189168091};\\\", \\\"{x:644,y:595,t:1527189168104};\\\", \\\"{x:754,y:617,t:1527189168120};\\\", \\\"{x:889,y:637,t:1527189168137};\\\", \\\"{x:1006,y:655,t:1527189168153};\\\", \\\"{x:1103,y:667,t:1527189168169};\\\", \\\"{x:1189,y:682,t:1527189168187};\\\", \\\"{x:1212,y:686,t:1527189168203};\\\", \\\"{x:1225,y:688,t:1527189168220};\\\", \\\"{x:1229,y:689,t:1527189168237};\\\", \\\"{x:1233,y:691,t:1527189168254};\\\", \\\"{x:1236,y:691,t:1527189168270};\\\", \\\"{x:1240,y:692,t:1527189168286};\\\", \\\"{x:1250,y:695,t:1527189168303};\\\", \\\"{x:1263,y:697,t:1527189168319};\\\", \\\"{x:1281,y:699,t:1527189168336};\\\", \\\"{x:1300,y:702,t:1527189168354};\\\", \\\"{x:1323,y:705,t:1527189168370};\\\", \\\"{x:1347,y:713,t:1527189168387};\\\", \\\"{x:1363,y:721,t:1527189168403};\\\", \\\"{x:1381,y:732,t:1527189168421};\\\", \\\"{x:1405,y:746,t:1527189168437};\\\", \\\"{x:1426,y:755,t:1527189168454};\\\", \\\"{x:1444,y:763,t:1527189168472};\\\", \\\"{x:1473,y:782,t:1527189168487};\\\", \\\"{x:1510,y:800,t:1527189168504};\\\", \\\"{x:1533,y:812,t:1527189168521};\\\", \\\"{x:1546,y:819,t:1527189168537};\\\", \\\"{x:1550,y:823,t:1527189168554};\\\", \\\"{x:1557,y:835,t:1527189168571};\\\", \\\"{x:1559,y:840,t:1527189168586};\\\", \\\"{x:1561,y:846,t:1527189168604};\\\", \\\"{x:1561,y:848,t:1527189168621};\\\", \\\"{x:1561,y:849,t:1527189168637};\\\", \\\"{x:1561,y:850,t:1527189168654};\\\", \\\"{x:1561,y:851,t:1527189168671};\\\", \\\"{x:1557,y:851,t:1527189168687};\\\", \\\"{x:1548,y:854,t:1527189168704};\\\", \\\"{x:1529,y:858,t:1527189168721};\\\", \\\"{x:1512,y:862,t:1527189168737};\\\", \\\"{x:1494,y:865,t:1527189168754};\\\", \\\"{x:1471,y:867,t:1527189168772};\\\", \\\"{x:1467,y:867,t:1527189168787};\\\", \\\"{x:1460,y:867,t:1527189168804};\\\", \\\"{x:1459,y:867,t:1527189168822};\\\", \\\"{x:1458,y:867,t:1527189168884};\\\", \\\"{x:1459,y:866,t:1527189168972};\\\", \\\"{x:1462,y:865,t:1527189168988};\\\", \\\"{x:1468,y:861,t:1527189169004};\\\", \\\"{x:1474,y:857,t:1527189169021};\\\", \\\"{x:1481,y:854,t:1527189169039};\\\", \\\"{x:1486,y:852,t:1527189169054};\\\", \\\"{x:1490,y:851,t:1527189169071};\\\", \\\"{x:1496,y:849,t:1527189169089};\\\", \\\"{x:1499,y:849,t:1527189169104};\\\", \\\"{x:1502,y:849,t:1527189169121};\\\", \\\"{x:1505,y:849,t:1527189169138};\\\", \\\"{x:1508,y:848,t:1527189169154};\\\", \\\"{x:1512,y:847,t:1527189169171};\\\", \\\"{x:1514,y:847,t:1527189169187};\\\", \\\"{x:1515,y:847,t:1527189169205};\\\", \\\"{x:1517,y:847,t:1527189169221};\\\", \\\"{x:1519,y:847,t:1527189169239};\\\", \\\"{x:1525,y:847,t:1527189169254};\\\", \\\"{x:1530,y:847,t:1527189169272};\\\", \\\"{x:1535,y:847,t:1527189169288};\\\", \\\"{x:1544,y:847,t:1527189169304};\\\", \\\"{x:1554,y:848,t:1527189169321};\\\", \\\"{x:1557,y:848,t:1527189169338};\\\", \\\"{x:1559,y:850,t:1527189169356};\\\", \\\"{x:1557,y:853,t:1527189169412};\\\", \\\"{x:1548,y:857,t:1527189169421};\\\", \\\"{x:1516,y:865,t:1527189169438};\\\", \\\"{x:1455,y:880,t:1527189169455};\\\", \\\"{x:1371,y:897,t:1527189169471};\\\", \\\"{x:1276,y:911,t:1527189169488};\\\", \\\"{x:1183,y:917,t:1527189169505};\\\", \\\"{x:1097,y:917,t:1527189169521};\\\", \\\"{x:1000,y:917,t:1527189169538};\\\", \\\"{x:833,y:897,t:1527189169555};\\\", \\\"{x:784,y:890,t:1527189169571};\\\", \\\"{x:691,y:875,t:1527189169588};\\\", \\\"{x:668,y:872,t:1527189169605};\\\", \\\"{x:644,y:866,t:1527189169621};\\\", \\\"{x:618,y:858,t:1527189169638};\\\", \\\"{x:594,y:851,t:1527189169655};\\\", \\\"{x:567,y:846,t:1527189169671};\\\", \\\"{x:539,y:844,t:1527189169688};\\\", \\\"{x:516,y:841,t:1527189169705};\\\", \\\"{x:498,y:839,t:1527189169721};\\\", \\\"{x:479,y:834,t:1527189169738};\\\", \\\"{x:447,y:828,t:1527189169755};\\\", \\\"{x:441,y:825,t:1527189169772};\\\", \\\"{x:441,y:824,t:1527189169788};\\\", \\\"{x:441,y:818,t:1527189169805};\\\", \\\"{x:441,y:808,t:1527189169822};\\\", \\\"{x:441,y:800,t:1527189169838};\\\", \\\"{x:442,y:790,t:1527189169855};\\\", \\\"{x:453,y:772,t:1527189169872};\\\", \\\"{x:470,y:753,t:1527189169889};\\\", \\\"{x:481,y:739,t:1527189169905};\\\", \\\"{x:494,y:731,t:1527189169921};\\\", \\\"{x:498,y:727,t:1527189169938};\\\", \\\"{x:502,y:724,t:1527189169955};\\\", \\\"{x:502,y:723,t:1527189169971};\\\", \\\"{x:502,y:724,t:1527189170107};\\\", \\\"{x:502,y:726,t:1527189170122};\\\", \\\"{x:502,y:727,t:1527189170139};\\\", \\\"{x:502,y:728,t:1527189170155};\\\", \\\"{x:502,y:729,t:1527189170172};\\\", \\\"{x:502,y:730,t:1527189170188};\\\" ] }, { \\\"rt\\\": 50560, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 604920, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:732,t:1527189174412};\\\", \\\"{x:503,y:733,t:1527189174436};\\\", \\\"{x:504,y:734,t:1527189174459};\\\", \\\"{x:505,y:734,t:1527189174483};\\\", \\\"{x:506,y:735,t:1527189174499};\\\", \\\"{x:509,y:735,t:1527189175020};\\\", \\\"{x:530,y:735,t:1527189175031};\\\", \\\"{x:583,y:735,t:1527189175048};\\\", \\\"{x:631,y:735,t:1527189175064};\\\", \\\"{x:666,y:735,t:1527189175081};\\\", \\\"{x:724,y:739,t:1527189175090};\\\", \\\"{x:813,y:752,t:1527189175108};\\\", \\\"{x:915,y:778,t:1527189175123};\\\", \\\"{x:1006,y:806,t:1527189175141};\\\", \\\"{x:1088,y:834,t:1527189175157};\\\", \\\"{x:1157,y:863,t:1527189175174};\\\", \\\"{x:1215,y:889,t:1527189175191};\\\", \\\"{x:1267,y:908,t:1527189175208};\\\", \\\"{x:1308,y:928,t:1527189175224};\\\", \\\"{x:1332,y:938,t:1527189175241};\\\", \\\"{x:1348,y:944,t:1527189175258};\\\", \\\"{x:1357,y:946,t:1527189175274};\\\", \\\"{x:1380,y:950,t:1527189175291};\\\", \\\"{x:1400,y:950,t:1527189175309};\\\", \\\"{x:1418,y:950,t:1527189175324};\\\", \\\"{x:1433,y:950,t:1527189175341};\\\", \\\"{x:1450,y:950,t:1527189175358};\\\", \\\"{x:1473,y:950,t:1527189175374};\\\", \\\"{x:1493,y:950,t:1527189175391};\\\", \\\"{x:1512,y:950,t:1527189175408};\\\", \\\"{x:1525,y:950,t:1527189175424};\\\", \\\"{x:1529,y:950,t:1527189175441};\\\", \\\"{x:1530,y:950,t:1527189175458};\\\", \\\"{x:1532,y:950,t:1527189175531};\\\", \\\"{x:1534,y:950,t:1527189175596};\\\", \\\"{x:1535,y:950,t:1527189175608};\\\", \\\"{x:1538,y:950,t:1527189175624};\\\", \\\"{x:1540,y:951,t:1527189175641};\\\", \\\"{x:1541,y:951,t:1527189175658};\\\", \\\"{x:1542,y:951,t:1527189175675};\\\", \\\"{x:1544,y:951,t:1527189175692};\\\", \\\"{x:1545,y:952,t:1527189175709};\\\", \\\"{x:1545,y:953,t:1527189175725};\\\", \\\"{x:1546,y:955,t:1527189175742};\\\", \\\"{x:1546,y:956,t:1527189175759};\\\", \\\"{x:1546,y:957,t:1527189175775};\\\", \\\"{x:1546,y:958,t:1527189175792};\\\", \\\"{x:1546,y:959,t:1527189175836};\\\", \\\"{x:1546,y:960,t:1527189176164};\\\", \\\"{x:1546,y:961,t:1527189176176};\\\", \\\"{x:1546,y:962,t:1527189176192};\\\", \\\"{x:1546,y:964,t:1527189176209};\\\", \\\"{x:1546,y:965,t:1527189176226};\\\", \\\"{x:1546,y:967,t:1527189176241};\\\", \\\"{x:1546,y:968,t:1527189176267};\\\", \\\"{x:1546,y:969,t:1527189176340};\\\", \\\"{x:1546,y:970,t:1527189176358};\\\", \\\"{x:1547,y:970,t:1527189176444};\\\", \\\"{x:1547,y:969,t:1527189176692};\\\", \\\"{x:1547,y:968,t:1527189176789};\\\", \\\"{x:1547,y:967,t:1527189180764};\\\", \\\"{x:1548,y:965,t:1527189180777};\\\", \\\"{x:1549,y:965,t:1527189180794};\\\", \\\"{x:1549,y:964,t:1527189180810};\\\", \\\"{x:1549,y:963,t:1527189180827};\\\", \\\"{x:1550,y:960,t:1527189182620};\\\", \\\"{x:1550,y:958,t:1527189182628};\\\", \\\"{x:1550,y:957,t:1527189182651};\\\", \\\"{x:1550,y:956,t:1527189182661};\\\", \\\"{x:1550,y:955,t:1527189182677};\\\", \\\"{x:1550,y:957,t:1527189184532};\\\", \\\"{x:1551,y:957,t:1527189184548};\\\", \\\"{x:1551,y:958,t:1527189184964};\\\", \\\"{x:1550,y:958,t:1527189184978};\\\", \\\"{x:1549,y:959,t:1527189185028};\\\", \\\"{x:1548,y:959,t:1527189185076};\\\", \\\"{x:1547,y:960,t:1527189185083};\\\", \\\"{x:1546,y:961,t:1527189185099};\\\", \\\"{x:1545,y:961,t:1527189185140};\\\", \\\"{x:1544,y:961,t:1527189185164};\\\", \\\"{x:1543,y:962,t:1527189185179};\\\", \\\"{x:1542,y:962,t:1527189185252};\\\", \\\"{x:1541,y:962,t:1527189185284};\\\", \\\"{x:1541,y:963,t:1527189185316};\\\", \\\"{x:1540,y:963,t:1527189185328};\\\", \\\"{x:1541,y:963,t:1527189186708};\\\", \\\"{x:1542,y:963,t:1527189186724};\\\", \\\"{x:1544,y:963,t:1527189186731};\\\", \\\"{x:1545,y:963,t:1527189186745};\\\", \\\"{x:1547,y:963,t:1527189186762};\\\", \\\"{x:1548,y:963,t:1527189186778};\\\", \\\"{x:1550,y:963,t:1527189186796};\\\", \\\"{x:1551,y:962,t:1527189190093};\\\", \\\"{x:1549,y:962,t:1527189191892};\\\", \\\"{x:1548,y:962,t:1527189191907};\\\", \\\"{x:1547,y:962,t:1527189191924};\\\", \\\"{x:1546,y:961,t:1527189191931};\\\", \\\"{x:1541,y:956,t:1527189213204};\\\", \\\"{x:1421,y:914,t:1527189213221};\\\", \\\"{x:1251,y:869,t:1527189213237};\\\", \\\"{x:1066,y:824,t:1527189213254};\\\", \\\"{x:848,y:789,t:1527189213270};\\\", \\\"{x:612,y:746,t:1527189213287};\\\", \\\"{x:410,y:714,t:1527189213303};\\\", \\\"{x:252,y:688,t:1527189213320};\\\", \\\"{x:135,y:646,t:1527189213339};\\\", \\\"{x:102,y:619,t:1527189213354};\\\", \\\"{x:101,y:613,t:1527189213369};\\\", \\\"{x:101,y:609,t:1527189213390};\\\", \\\"{x:102,y:608,t:1527189213418};\\\", \\\"{x:102,y:606,t:1527189213434};\\\", \\\"{x:104,y:605,t:1527189213450};\\\", \\\"{x:105,y:604,t:1527189213459};\\\", \\\"{x:108,y:602,t:1527189213473};\\\", \\\"{x:110,y:602,t:1527189213489};\\\", \\\"{x:113,y:598,t:1527189213507};\\\", \\\"{x:116,y:597,t:1527189213524};\\\", \\\"{x:118,y:594,t:1527189213539};\\\", \\\"{x:123,y:590,t:1527189213557};\\\", \\\"{x:125,y:588,t:1527189213573};\\\", \\\"{x:128,y:587,t:1527189213590};\\\", \\\"{x:133,y:584,t:1527189213606};\\\", \\\"{x:140,y:580,t:1527189213624};\\\", \\\"{x:145,y:576,t:1527189213640};\\\", \\\"{x:145,y:575,t:1527189213657};\\\", \\\"{x:146,y:572,t:1527189213674};\\\", \\\"{x:147,y:571,t:1527189213690};\\\", \\\"{x:149,y:567,t:1527189213708};\\\", \\\"{x:150,y:562,t:1527189213724};\\\", \\\"{x:152,y:559,t:1527189213739};\\\", \\\"{x:152,y:555,t:1527189213757};\\\", \\\"{x:152,y:552,t:1527189213774};\\\", \\\"{x:153,y:549,t:1527189213790};\\\", \\\"{x:153,y:548,t:1527189213807};\\\", \\\"{x:153,y:547,t:1527189213823};\\\", \\\"{x:153,y:546,t:1527189213840};\\\", \\\"{x:154,y:545,t:1527189213856};\\\", \\\"{x:154,y:544,t:1527189213874};\\\", \\\"{x:154,y:542,t:1527189213890};\\\", \\\"{x:155,y:540,t:1527189213906};\\\", \\\"{x:156,y:539,t:1527189213931};\\\", \\\"{x:157,y:538,t:1527189214563};\\\", \\\"{x:165,y:538,t:1527189214574};\\\", \\\"{x:188,y:545,t:1527189214591};\\\", \\\"{x:218,y:553,t:1527189214608};\\\", \\\"{x:274,y:566,t:1527189214625};\\\", \\\"{x:340,y:583,t:1527189214641};\\\", \\\"{x:415,y:594,t:1527189214658};\\\", \\\"{x:535,y:618,t:1527189214675};\\\", \\\"{x:628,y:638,t:1527189214691};\\\", \\\"{x:732,y:657,t:1527189214707};\\\", \\\"{x:834,y:671,t:1527189214723};\\\", \\\"{x:925,y:683,t:1527189214741};\\\", \\\"{x:1020,y:698,t:1527189214757};\\\", \\\"{x:1098,y:709,t:1527189214774};\\\", \\\"{x:1163,y:719,t:1527189214790};\\\", \\\"{x:1220,y:724,t:1527189214808};\\\", \\\"{x:1255,y:729,t:1527189214824};\\\", \\\"{x:1277,y:730,t:1527189214841};\\\", \\\"{x:1296,y:733,t:1527189214858};\\\", \\\"{x:1303,y:733,t:1527189214873};\\\", \\\"{x:1306,y:733,t:1527189214891};\\\", \\\"{x:1307,y:733,t:1527189214915};\\\", \\\"{x:1308,y:733,t:1527189214924};\\\", \\\"{x:1310,y:733,t:1527189214941};\\\", \\\"{x:1315,y:733,t:1527189214957};\\\", \\\"{x:1323,y:733,t:1527189214974};\\\", \\\"{x:1337,y:735,t:1527189214991};\\\", \\\"{x:1348,y:737,t:1527189215007};\\\", \\\"{x:1358,y:742,t:1527189215024};\\\", \\\"{x:1370,y:747,t:1527189215041};\\\", \\\"{x:1376,y:752,t:1527189215057};\\\", \\\"{x:1383,y:757,t:1527189215074};\\\", \\\"{x:1388,y:762,t:1527189215090};\\\", \\\"{x:1392,y:764,t:1527189215107};\\\", \\\"{x:1392,y:766,t:1527189215124};\\\", \\\"{x:1393,y:768,t:1527189215147};\\\", \\\"{x:1393,y:769,t:1527189215251};\\\", \\\"{x:1392,y:769,t:1527189215259};\\\", \\\"{x:1391,y:769,t:1527189215275};\\\", \\\"{x:1384,y:769,t:1527189215291};\\\", \\\"{x:1371,y:772,t:1527189215308};\\\", \\\"{x:1368,y:773,t:1527189215325};\\\", \\\"{x:1365,y:774,t:1527189215340};\\\", \\\"{x:1364,y:774,t:1527189215358};\\\", \\\"{x:1364,y:776,t:1527189215524};\\\", \\\"{x:1369,y:784,t:1527189215540};\\\", \\\"{x:1381,y:798,t:1527189215558};\\\", \\\"{x:1398,y:815,t:1527189215574};\\\", \\\"{x:1420,y:834,t:1527189215590};\\\", \\\"{x:1446,y:854,t:1527189215607};\\\", \\\"{x:1467,y:868,t:1527189215623};\\\", \\\"{x:1478,y:880,t:1527189215640};\\\", \\\"{x:1487,y:892,t:1527189215657};\\\", \\\"{x:1495,y:901,t:1527189215673};\\\", \\\"{x:1501,y:907,t:1527189215690};\\\", \\\"{x:1502,y:909,t:1527189215706};\\\", \\\"{x:1504,y:911,t:1527189215723};\\\", \\\"{x:1506,y:913,t:1527189215741};\\\", \\\"{x:1508,y:913,t:1527189215756};\\\", \\\"{x:1512,y:915,t:1527189215773};\\\", \\\"{x:1518,y:918,t:1527189215790};\\\", \\\"{x:1530,y:923,t:1527189215806};\\\", \\\"{x:1542,y:931,t:1527189215824};\\\", \\\"{x:1547,y:936,t:1527189215840};\\\", \\\"{x:1551,y:939,t:1527189215856};\\\", \\\"{x:1556,y:943,t:1527189215873};\\\", \\\"{x:1560,y:945,t:1527189215890};\\\", \\\"{x:1561,y:947,t:1527189215907};\\\", \\\"{x:1564,y:950,t:1527189215924};\\\", \\\"{x:1565,y:951,t:1527189215948};\\\", \\\"{x:1565,y:952,t:1527189215971};\\\", \\\"{x:1566,y:953,t:1527189216012};\\\", \\\"{x:1567,y:954,t:1527189216067};\\\", \\\"{x:1566,y:956,t:1527189216092};\\\", \\\"{x:1564,y:956,t:1527189216106};\\\", \\\"{x:1556,y:961,t:1527189216123};\\\", \\\"{x:1553,y:961,t:1527189216139};\\\", \\\"{x:1552,y:962,t:1527189216156};\\\", \\\"{x:1550,y:962,t:1527189216523};\\\", \\\"{x:1549,y:962,t:1527189216554};\\\", \\\"{x:1546,y:960,t:1527189219711};\\\", \\\"{x:1526,y:952,t:1527189219722};\\\", \\\"{x:1426,y:924,t:1527189219738};\\\", \\\"{x:1321,y:894,t:1527189219754};\\\", \\\"{x:1192,y:868,t:1527189219771};\\\", \\\"{x:1026,y:842,t:1527189219788};\\\", \\\"{x:852,y:815,t:1527189219805};\\\", \\\"{x:716,y:796,t:1527189219821};\\\", \\\"{x:610,y:785,t:1527189219838};\\\", \\\"{x:579,y:780,t:1527189219854};\\\", \\\"{x:572,y:779,t:1527189219871};\\\", \\\"{x:572,y:778,t:1527189220158};\\\", \\\"{x:572,y:776,t:1527189220182};\\\", \\\"{x:572,y:775,t:1527189220190};\\\", \\\"{x:572,y:774,t:1527189220204};\\\", \\\"{x:572,y:773,t:1527189220222};\\\", \\\"{x:572,y:770,t:1527189221142};\\\", \\\"{x:572,y:765,t:1527189221153};\\\", \\\"{x:572,y:760,t:1527189221169};\\\", \\\"{x:572,y:758,t:1527189221186};\\\", \\\"{x:572,y:755,t:1527189221203};\\\", \\\"{x:572,y:754,t:1527189221219};\\\", \\\"{x:572,y:752,t:1527189221236};\\\", \\\"{x:572,y:749,t:1527189222582};\\\", \\\"{x:570,y:746,t:1527189222589};\\\", \\\"{x:568,y:744,t:1527189222601};\\\", \\\"{x:563,y:737,t:1527189222619};\\\", \\\"{x:556,y:732,t:1527189222634};\\\", \\\"{x:551,y:728,t:1527189222650};\\\", \\\"{x:549,y:727,t:1527189222667};\\\", \\\"{x:547,y:727,t:1527189222684};\\\", \\\"{x:544,y:727,t:1527189222700};\\\", \\\"{x:535,y:727,t:1527189222717};\\\", \\\"{x:529,y:730,t:1527189222733};\\\", \\\"{x:524,y:732,t:1527189222750};\\\" ] }, { \\\"rt\\\": 91813, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 697954, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-01 PM-02 PM-X -5-X -X -01 PM-G -G -M -O -03 PM-M -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:733,t:1527189226621};\\\", \\\"{x:515,y:733,t:1527189228246};\\\", \\\"{x:508,y:733,t:1527189228254};\\\", \\\"{x:498,y:733,t:1527189228271};\\\", \\\"{x:505,y:733,t:1527189231397};\\\", \\\"{x:515,y:732,t:1527189231407};\\\", \\\"{x:526,y:732,t:1527189231423};\\\", \\\"{x:541,y:732,t:1527189231440};\\\", \\\"{x:560,y:732,t:1527189231457};\\\", \\\"{x:577,y:732,t:1527189231473};\\\", \\\"{x:589,y:732,t:1527189231490};\\\", \\\"{x:598,y:732,t:1527189231507};\\\", \\\"{x:607,y:732,t:1527189231525};\\\", \\\"{x:617,y:732,t:1527189231540};\\\", \\\"{x:634,y:732,t:1527189231556};\\\", \\\"{x:649,y:732,t:1527189231575};\\\", \\\"{x:672,y:732,t:1527189231590};\\\", \\\"{x:700,y:732,t:1527189231607};\\\", \\\"{x:730,y:732,t:1527189231624};\\\", \\\"{x:773,y:732,t:1527189231640};\\\", \\\"{x:831,y:732,t:1527189231657};\\\", \\\"{x:890,y:732,t:1527189231675};\\\", \\\"{x:948,y:732,t:1527189231691};\\\", \\\"{x:1007,y:732,t:1527189231707};\\\", \\\"{x:1054,y:732,t:1527189231724};\\\", \\\"{x:1097,y:732,t:1527189231741};\\\", \\\"{x:1138,y:739,t:1527189231757};\\\", \\\"{x:1162,y:746,t:1527189231775};\\\", \\\"{x:1185,y:758,t:1527189231790};\\\", \\\"{x:1202,y:768,t:1527189231807};\\\", \\\"{x:1213,y:779,t:1527189231824};\\\", \\\"{x:1218,y:788,t:1527189231840};\\\", \\\"{x:1222,y:798,t:1527189231857};\\\", \\\"{x:1227,y:810,t:1527189231875};\\\", \\\"{x:1232,y:823,t:1527189231890};\\\", \\\"{x:1238,y:841,t:1527189231907};\\\", \\\"{x:1244,y:864,t:1527189231924};\\\", \\\"{x:1248,y:882,t:1527189231941};\\\", \\\"{x:1252,y:907,t:1527189231958};\\\", \\\"{x:1257,y:923,t:1527189231974};\\\", \\\"{x:1260,y:934,t:1527189231992};\\\", \\\"{x:1270,y:949,t:1527189232008};\\\", \\\"{x:1275,y:960,t:1527189232025};\\\", \\\"{x:1279,y:967,t:1527189232042};\\\", \\\"{x:1284,y:975,t:1527189232058};\\\", \\\"{x:1288,y:982,t:1527189232074};\\\", \\\"{x:1291,y:988,t:1527189232092};\\\", \\\"{x:1294,y:997,t:1527189232107};\\\", \\\"{x:1296,y:1002,t:1527189232124};\\\", \\\"{x:1297,y:1008,t:1527189232142};\\\", \\\"{x:1299,y:1011,t:1527189232158};\\\", \\\"{x:1303,y:1017,t:1527189232175};\\\", \\\"{x:1305,y:1022,t:1527189232192};\\\", \\\"{x:1309,y:1025,t:1527189232208};\\\", \\\"{x:1311,y:1027,t:1527189232225};\\\", \\\"{x:1312,y:1028,t:1527189232242};\\\", \\\"{x:1313,y:1028,t:1527189232257};\\\", \\\"{x:1314,y:1028,t:1527189232274};\\\", \\\"{x:1315,y:1028,t:1527189232301};\\\", \\\"{x:1317,y:1028,t:1527189232309};\\\", \\\"{x:1317,y:1027,t:1527189232324};\\\", \\\"{x:1331,y:1022,t:1527189232340};\\\", \\\"{x:1347,y:1016,t:1527189232357};\\\", \\\"{x:1360,y:1009,t:1527189232374};\\\", \\\"{x:1371,y:1005,t:1527189232392};\\\", \\\"{x:1383,y:998,t:1527189232408};\\\", \\\"{x:1396,y:995,t:1527189232424};\\\", \\\"{x:1409,y:991,t:1527189232442};\\\", \\\"{x:1421,y:986,t:1527189232458};\\\", \\\"{x:1430,y:982,t:1527189232475};\\\", \\\"{x:1438,y:979,t:1527189232491};\\\", \\\"{x:1442,y:977,t:1527189232509};\\\", \\\"{x:1447,y:976,t:1527189232524};\\\", \\\"{x:1450,y:975,t:1527189232541};\\\", \\\"{x:1454,y:974,t:1527189232558};\\\", \\\"{x:1456,y:973,t:1527189232574};\\\", \\\"{x:1462,y:971,t:1527189232591};\\\", \\\"{x:1467,y:969,t:1527189232609};\\\", \\\"{x:1472,y:967,t:1527189232625};\\\", \\\"{x:1476,y:965,t:1527189232642};\\\", \\\"{x:1480,y:964,t:1527189232658};\\\", \\\"{x:1482,y:963,t:1527189232674};\\\", \\\"{x:1482,y:962,t:1527189233062};\\\", \\\"{x:1481,y:961,t:1527189233076};\\\", \\\"{x:1480,y:960,t:1527189233092};\\\", \\\"{x:1479,y:960,t:1527189233108};\\\", \\\"{x:1479,y:959,t:1527189233126};\\\", \\\"{x:1478,y:958,t:1527189233142};\\\", \\\"{x:1477,y:957,t:1527189233166};\\\", \\\"{x:1476,y:956,t:1527189233182};\\\", \\\"{x:1476,y:955,t:1527189233262};\\\", \\\"{x:1475,y:954,t:1527189233276};\\\", \\\"{x:1475,y:952,t:1527189233302};\\\", \\\"{x:1475,y:951,t:1527189233318};\\\", \\\"{x:1475,y:949,t:1527189233342};\\\", \\\"{x:1475,y:948,t:1527189233374};\\\", \\\"{x:1475,y:947,t:1527189233398};\\\", \\\"{x:1475,y:946,t:1527189233409};\\\", \\\"{x:1475,y:945,t:1527189233429};\\\", \\\"{x:1475,y:944,t:1527189233446};\\\", \\\"{x:1475,y:943,t:1527189233459};\\\", \\\"{x:1475,y:942,t:1527189233476};\\\", \\\"{x:1475,y:940,t:1527189233493};\\\", \\\"{x:1475,y:937,t:1527189233509};\\\", \\\"{x:1475,y:935,t:1527189233526};\\\", \\\"{x:1475,y:933,t:1527189233543};\\\", \\\"{x:1475,y:931,t:1527189233559};\\\", \\\"{x:1475,y:926,t:1527189233576};\\\", \\\"{x:1475,y:918,t:1527189233593};\\\", \\\"{x:1475,y:911,t:1527189233609};\\\", \\\"{x:1477,y:905,t:1527189233626};\\\", \\\"{x:1477,y:901,t:1527189233643};\\\", \\\"{x:1477,y:897,t:1527189233659};\\\", \\\"{x:1477,y:892,t:1527189233675};\\\", \\\"{x:1477,y:888,t:1527189233693};\\\", \\\"{x:1477,y:883,t:1527189233709};\\\", \\\"{x:1477,y:876,t:1527189233726};\\\", \\\"{x:1477,y:873,t:1527189233743};\\\", \\\"{x:1477,y:870,t:1527189233760};\\\", \\\"{x:1477,y:867,t:1527189233776};\\\", \\\"{x:1477,y:864,t:1527189233793};\\\", \\\"{x:1477,y:861,t:1527189233810};\\\", \\\"{x:1476,y:859,t:1527189233826};\\\", \\\"{x:1476,y:857,t:1527189233846};\\\", \\\"{x:1474,y:855,t:1527189233860};\\\", \\\"{x:1474,y:854,t:1527189233876};\\\", \\\"{x:1474,y:853,t:1527189233893};\\\", \\\"{x:1473,y:852,t:1527189233909};\\\", \\\"{x:1472,y:850,t:1527189233926};\\\", \\\"{x:1472,y:849,t:1527189233942};\\\", \\\"{x:1471,y:847,t:1527189233960};\\\", \\\"{x:1470,y:846,t:1527189233975};\\\", \\\"{x:1470,y:844,t:1527189233996};\\\", \\\"{x:1470,y:843,t:1527189234029};\\\", \\\"{x:1470,y:841,t:1527189234045};\\\", \\\"{x:1469,y:840,t:1527189234060};\\\", \\\"{x:1468,y:838,t:1527189234075};\\\", \\\"{x:1468,y:837,t:1527189234092};\\\", \\\"{x:1467,y:836,t:1527189234109};\\\", \\\"{x:1466,y:834,t:1527189234126};\\\", \\\"{x:1466,y:833,t:1527189234327};\\\", \\\"{x:1466,y:832,t:1527189234343};\\\", \\\"{x:1466,y:831,t:1527189234360};\\\", \\\"{x:1466,y:830,t:1527189236799};\\\", \\\"{x:1467,y:830,t:1527189236812};\\\", \\\"{x:1469,y:830,t:1527189236828};\\\", \\\"{x:1471,y:830,t:1527189236845};\\\", \\\"{x:1472,y:830,t:1527189236861};\\\", \\\"{x:1473,y:830,t:1527189240966};\\\", \\\"{x:1473,y:828,t:1527189241135};\\\", \\\"{x:1473,y:824,t:1527189241148};\\\", \\\"{x:1473,y:820,t:1527189241165};\\\", \\\"{x:1472,y:813,t:1527189241182};\\\", \\\"{x:1472,y:812,t:1527189241198};\\\", \\\"{x:1470,y:811,t:1527189241216};\\\", \\\"{x:1470,y:810,t:1527189242294};\\\", \\\"{x:1470,y:808,t:1527189242310};\\\", \\\"{x:1469,y:807,t:1527189242318};\\\", \\\"{x:1469,y:806,t:1527189242334};\\\", \\\"{x:1469,y:805,t:1527189242349};\\\", \\\"{x:1469,y:804,t:1527189242583};\\\", \\\"{x:1471,y:805,t:1527189242600};\\\", \\\"{x:1473,y:806,t:1527189242617};\\\", \\\"{x:1473,y:807,t:1527189242633};\\\", \\\"{x:1473,y:809,t:1527189242650};\\\", \\\"{x:1473,y:810,t:1527189242666};\\\", \\\"{x:1473,y:812,t:1527189242684};\\\", \\\"{x:1473,y:813,t:1527189242700};\\\", \\\"{x:1473,y:815,t:1527189242717};\\\", \\\"{x:1473,y:816,t:1527189242734};\\\", \\\"{x:1473,y:819,t:1527189242751};\\\", \\\"{x:1473,y:821,t:1527189242766};\\\", \\\"{x:1473,y:823,t:1527189242783};\\\", \\\"{x:1473,y:824,t:1527189242805};\\\", \\\"{x:1473,y:825,t:1527189242821};\\\", \\\"{x:1473,y:826,t:1527189242854};\\\", \\\"{x:1474,y:827,t:1527189242870};\\\", \\\"{x:1474,y:828,t:1527189242918};\\\", \\\"{x:1475,y:829,t:1527189242958};\\\", \\\"{x:1476,y:830,t:1527189242968};\\\", \\\"{x:1477,y:830,t:1527189242982};\\\", \\\"{x:1479,y:831,t:1527189242999};\\\", \\\"{x:1480,y:831,t:1527189250461};\\\", \\\"{x:1478,y:831,t:1527189250476};\\\", \\\"{x:1468,y:829,t:1527189250490};\\\", \\\"{x:1430,y:819,t:1527189250505};\\\", \\\"{x:1361,y:808,t:1527189250522};\\\", \\\"{x:1262,y:785,t:1527189250539};\\\", \\\"{x:1160,y:761,t:1527189250555};\\\", \\\"{x:1048,y:738,t:1527189250573};\\\", \\\"{x:876,y:708,t:1527189250589};\\\", \\\"{x:763,y:693,t:1527189250606};\\\", \\\"{x:663,y:678,t:1527189250622};\\\", \\\"{x:581,y:659,t:1527189250639};\\\", \\\"{x:524,y:649,t:1527189250656};\\\", \\\"{x:495,y:643,t:1527189250674};\\\", \\\"{x:478,y:638,t:1527189250689};\\\", \\\"{x:465,y:634,t:1527189250706};\\\", \\\"{x:456,y:632,t:1527189250723};\\\", \\\"{x:447,y:630,t:1527189250739};\\\", \\\"{x:435,y:626,t:1527189250756};\\\", \\\"{x:422,y:623,t:1527189250773};\\\", \\\"{x:415,y:619,t:1527189250789};\\\", \\\"{x:404,y:612,t:1527189250806};\\\", \\\"{x:395,y:606,t:1527189250823};\\\", \\\"{x:386,y:600,t:1527189250839};\\\", \\\"{x:380,y:595,t:1527189250856};\\\", \\\"{x:375,y:589,t:1527189250873};\\\", \\\"{x:372,y:585,t:1527189250890};\\\", \\\"{x:368,y:579,t:1527189250906};\\\", \\\"{x:365,y:575,t:1527189250924};\\\", \\\"{x:362,y:571,t:1527189250939};\\\", \\\"{x:360,y:568,t:1527189250957};\\\", \\\"{x:359,y:566,t:1527189250974};\\\", \\\"{x:358,y:566,t:1527189251069};\\\", \\\"{x:356,y:566,t:1527189251077};\\\", \\\"{x:352,y:566,t:1527189251090};\\\", \\\"{x:341,y:566,t:1527189251106};\\\", \\\"{x:324,y:566,t:1527189251123};\\\", \\\"{x:300,y:566,t:1527189251141};\\\", \\\"{x:277,y:566,t:1527189251156};\\\", \\\"{x:252,y:567,t:1527189251175};\\\", \\\"{x:241,y:567,t:1527189251190};\\\", \\\"{x:237,y:568,t:1527189251206};\\\", \\\"{x:236,y:569,t:1527189251357};\\\", \\\"{x:236,y:580,t:1527189251374};\\\", \\\"{x:250,y:603,t:1527189251389};\\\", \\\"{x:267,y:619,t:1527189251406};\\\", \\\"{x:271,y:621,t:1527189251423};\\\", \\\"{x:278,y:623,t:1527189251441};\\\", \\\"{x:285,y:623,t:1527189251457};\\\", \\\"{x:295,y:623,t:1527189251473};\\\", \\\"{x:312,y:617,t:1527189251490};\\\", \\\"{x:329,y:610,t:1527189251507};\\\", \\\"{x:356,y:598,t:1527189251524};\\\", \\\"{x:395,y:580,t:1527189251540};\\\", \\\"{x:435,y:564,t:1527189251557};\\\", \\\"{x:447,y:558,t:1527189251573};\\\", \\\"{x:451,y:556,t:1527189251590};\\\", \\\"{x:452,y:554,t:1527189251607};\\\", \\\"{x:453,y:554,t:1527189251623};\\\", \\\"{x:453,y:553,t:1527189251677};\\\", \\\"{x:453,y:551,t:1527189251691};\\\", \\\"{x:459,y:547,t:1527189251707};\\\", \\\"{x:471,y:545,t:1527189251723};\\\", \\\"{x:490,y:541,t:1527189251740};\\\", \\\"{x:505,y:536,t:1527189251758};\\\", \\\"{x:523,y:532,t:1527189251773};\\\", \\\"{x:538,y:530,t:1527189251791};\\\", \\\"{x:554,y:528,t:1527189251807};\\\", \\\"{x:558,y:526,t:1527189251823};\\\", \\\"{x:563,y:525,t:1527189251840};\\\", \\\"{x:569,y:525,t:1527189251857};\\\", \\\"{x:578,y:525,t:1527189251874};\\\", \\\"{x:587,y:525,t:1527189251890};\\\", \\\"{x:599,y:525,t:1527189251907};\\\", \\\"{x:617,y:525,t:1527189251924};\\\", \\\"{x:640,y:525,t:1527189251940};\\\", \\\"{x:683,y:522,t:1527189251957};\\\", \\\"{x:728,y:522,t:1527189251975};\\\", \\\"{x:767,y:522,t:1527189251990};\\\", \\\"{x:798,y:520,t:1527189252007};\\\", \\\"{x:821,y:516,t:1527189252024};\\\", \\\"{x:833,y:514,t:1527189252041};\\\", \\\"{x:834,y:514,t:1527189252468};\\\", \\\"{x:842,y:514,t:1527189252476};\\\", \\\"{x:851,y:514,t:1527189252491};\\\", \\\"{x:874,y:514,t:1527189252507};\\\", \\\"{x:908,y:516,t:1527189252524};\\\", \\\"{x:985,y:537,t:1527189252540};\\\", \\\"{x:1057,y:555,t:1527189252557};\\\", \\\"{x:1113,y:572,t:1527189252574};\\\", \\\"{x:1161,y:596,t:1527189252592};\\\", \\\"{x:1217,y:627,t:1527189252608};\\\", \\\"{x:1256,y:644,t:1527189252625};\\\", \\\"{x:1281,y:656,t:1527189252641};\\\", \\\"{x:1302,y:667,t:1527189252658};\\\", \\\"{x:1313,y:676,t:1527189252675};\\\", \\\"{x:1324,y:686,t:1527189252692};\\\", \\\"{x:1341,y:702,t:1527189252707};\\\", \\\"{x:1357,y:720,t:1527189252724};\\\", \\\"{x:1374,y:745,t:1527189252741};\\\", \\\"{x:1382,y:758,t:1527189252758};\\\", \\\"{x:1391,y:774,t:1527189252775};\\\", \\\"{x:1405,y:794,t:1527189252792};\\\", \\\"{x:1421,y:810,t:1527189252807};\\\", \\\"{x:1438,y:823,t:1527189252824};\\\", \\\"{x:1449,y:832,t:1527189252842};\\\", \\\"{x:1452,y:834,t:1527189252858};\\\", \\\"{x:1454,y:836,t:1527189252910};\\\", \\\"{x:1455,y:836,t:1527189252958};\\\", \\\"{x:1457,y:836,t:1527189252974};\\\", \\\"{x:1464,y:836,t:1527189252991};\\\", \\\"{x:1473,y:835,t:1527189253008};\\\", \\\"{x:1479,y:834,t:1527189253024};\\\", \\\"{x:1484,y:832,t:1527189253042};\\\", \\\"{x:1486,y:831,t:1527189253059};\\\", \\\"{x:1488,y:829,t:1527189253075};\\\", \\\"{x:1487,y:829,t:1527189253350};\\\", \\\"{x:1486,y:829,t:1527189253359};\\\", \\\"{x:1485,y:829,t:1527189253374};\\\", \\\"{x:1483,y:829,t:1527189253391};\\\", \\\"{x:1481,y:829,t:1527189253409};\\\", \\\"{x:1479,y:829,t:1527189253424};\\\", \\\"{x:1478,y:829,t:1527189253442};\\\", \\\"{x:1477,y:829,t:1527189253459};\\\", \\\"{x:1475,y:829,t:1527189253477};\\\", \\\"{x:1474,y:829,t:1527189253494};\\\", \\\"{x:1473,y:829,t:1527189253508};\\\", \\\"{x:1472,y:829,t:1527189253526};\\\", \\\"{x:1469,y:829,t:1527189256398};\\\", \\\"{x:1458,y:829,t:1527189256411};\\\", \\\"{x:1443,y:830,t:1527189256427};\\\", \\\"{x:1432,y:836,t:1527189256444};\\\", \\\"{x:1427,y:843,t:1527189256461};\\\", \\\"{x:1416,y:863,t:1527189256477};\\\", \\\"{x:1413,y:880,t:1527189256494};\\\", \\\"{x:1411,y:897,t:1527189256511};\\\", \\\"{x:1411,y:908,t:1527189256527};\\\", \\\"{x:1411,y:917,t:1527189256544};\\\", \\\"{x:1411,y:929,t:1527189256561};\\\", \\\"{x:1411,y:940,t:1527189256577};\\\", \\\"{x:1411,y:946,t:1527189256594};\\\", \\\"{x:1411,y:955,t:1527189256611};\\\", \\\"{x:1413,y:967,t:1527189256628};\\\", \\\"{x:1416,y:973,t:1527189256645};\\\", \\\"{x:1417,y:977,t:1527189256661};\\\", \\\"{x:1417,y:979,t:1527189256678};\\\", \\\"{x:1417,y:981,t:1527189256694};\\\", \\\"{x:1417,y:977,t:1527189256870};\\\", \\\"{x:1415,y:966,t:1527189256877};\\\", \\\"{x:1403,y:937,t:1527189256894};\\\", \\\"{x:1395,y:918,t:1527189256911};\\\", \\\"{x:1388,y:893,t:1527189256928};\\\", \\\"{x:1380,y:871,t:1527189256944};\\\", \\\"{x:1375,y:848,t:1527189256961};\\\", \\\"{x:1373,y:830,t:1527189256977};\\\", \\\"{x:1373,y:816,t:1527189256994};\\\", \\\"{x:1373,y:807,t:1527189257010};\\\", \\\"{x:1373,y:794,t:1527189257028};\\\", \\\"{x:1373,y:783,t:1527189257044};\\\", \\\"{x:1373,y:760,t:1527189257061};\\\", \\\"{x:1375,y:748,t:1527189257077};\\\", \\\"{x:1376,y:737,t:1527189257094};\\\", \\\"{x:1376,y:727,t:1527189257111};\\\", \\\"{x:1376,y:717,t:1527189257128};\\\", \\\"{x:1376,y:702,t:1527189257144};\\\", \\\"{x:1376,y:690,t:1527189257160};\\\", \\\"{x:1376,y:683,t:1527189257177};\\\", \\\"{x:1376,y:676,t:1527189257195};\\\", \\\"{x:1376,y:670,t:1527189257210};\\\", \\\"{x:1376,y:664,t:1527189257228};\\\", \\\"{x:1374,y:653,t:1527189257245};\\\", \\\"{x:1373,y:647,t:1527189257261};\\\", \\\"{x:1371,y:639,t:1527189257277};\\\", \\\"{x:1369,y:632,t:1527189257295};\\\", \\\"{x:1369,y:628,t:1527189257311};\\\", \\\"{x:1368,y:624,t:1527189257328};\\\", \\\"{x:1368,y:619,t:1527189257345};\\\", \\\"{x:1368,y:615,t:1527189257361};\\\", \\\"{x:1368,y:611,t:1527189257378};\\\", \\\"{x:1368,y:605,t:1527189257395};\\\", \\\"{x:1371,y:599,t:1527189257411};\\\", \\\"{x:1375,y:592,t:1527189257428};\\\", \\\"{x:1380,y:584,t:1527189257445};\\\", \\\"{x:1389,y:573,t:1527189257461};\\\", \\\"{x:1393,y:567,t:1527189257478};\\\", \\\"{x:1398,y:562,t:1527189257495};\\\", \\\"{x:1402,y:555,t:1527189257511};\\\", \\\"{x:1403,y:554,t:1527189257528};\\\", \\\"{x:1404,y:554,t:1527189258397};\\\", \\\"{x:1406,y:554,t:1527189258413};\\\", \\\"{x:1408,y:555,t:1527189258428};\\\", \\\"{x:1410,y:555,t:1527189258445};\\\", \\\"{x:1412,y:557,t:1527189259158};\\\", \\\"{x:1412,y:558,t:1527189259166};\\\", \\\"{x:1412,y:561,t:1527189259179};\\\", \\\"{x:1415,y:567,t:1527189259196};\\\", \\\"{x:1417,y:572,t:1527189259213};\\\", \\\"{x:1424,y:584,t:1527189259229};\\\", \\\"{x:1429,y:594,t:1527189259245};\\\", \\\"{x:1434,y:608,t:1527189259263};\\\", \\\"{x:1442,y:622,t:1527189259279};\\\", \\\"{x:1449,y:640,t:1527189259297};\\\", \\\"{x:1457,y:658,t:1527189259313};\\\", \\\"{x:1466,y:681,t:1527189259329};\\\", \\\"{x:1474,y:708,t:1527189259347};\\\", \\\"{x:1481,y:733,t:1527189259363};\\\", \\\"{x:1489,y:763,t:1527189259379};\\\", \\\"{x:1495,y:784,t:1527189259396};\\\", \\\"{x:1502,y:808,t:1527189259414};\\\", \\\"{x:1506,y:820,t:1527189259429};\\\", \\\"{x:1507,y:827,t:1527189259446};\\\", \\\"{x:1508,y:830,t:1527189259463};\\\", \\\"{x:1508,y:832,t:1527189259480};\\\", \\\"{x:1509,y:833,t:1527189259496};\\\", \\\"{x:1509,y:834,t:1527189259774};\\\", \\\"{x:1509,y:835,t:1527189259782};\\\", \\\"{x:1508,y:835,t:1527189259822};\\\", \\\"{x:1506,y:838,t:1527189260710};\\\", \\\"{x:1505,y:841,t:1527189260718};\\\", \\\"{x:1503,y:844,t:1527189260730};\\\", \\\"{x:1502,y:846,t:1527189260747};\\\", \\\"{x:1501,y:849,t:1527189260763};\\\", \\\"{x:1500,y:850,t:1527189260780};\\\", \\\"{x:1499,y:850,t:1527189260798};\\\", \\\"{x:1497,y:850,t:1527189260813};\\\", \\\"{x:1494,y:850,t:1527189260831};\\\", \\\"{x:1492,y:850,t:1527189260847};\\\", \\\"{x:1489,y:850,t:1527189260864};\\\", \\\"{x:1484,y:850,t:1527189260881};\\\", \\\"{x:1479,y:848,t:1527189260897};\\\", \\\"{x:1473,y:844,t:1527189260914};\\\", \\\"{x:1470,y:841,t:1527189260931};\\\", \\\"{x:1468,y:839,t:1527189260947};\\\", \\\"{x:1468,y:838,t:1527189261166};\\\", \\\"{x:1468,y:837,t:1527189261180};\\\", \\\"{x:1470,y:834,t:1527189261197};\\\", \\\"{x:1472,y:832,t:1527189261214};\\\", \\\"{x:1473,y:831,t:1527189261231};\\\", \\\"{x:1474,y:830,t:1527189261248};\\\", \\\"{x:1467,y:834,t:1527189266679};\\\", \\\"{x:1451,y:847,t:1527189266685};\\\", \\\"{x:1409,y:875,t:1527189266701};\\\", \\\"{x:1376,y:894,t:1527189266718};\\\", \\\"{x:1351,y:910,t:1527189266737};\\\", \\\"{x:1330,y:924,t:1527189266752};\\\", \\\"{x:1318,y:933,t:1527189266767};\\\", \\\"{x:1309,y:940,t:1527189266784};\\\", \\\"{x:1308,y:944,t:1527189266801};\\\", \\\"{x:1308,y:946,t:1527189266817};\\\", \\\"{x:1307,y:947,t:1527189266834};\\\", \\\"{x:1307,y:948,t:1527189266852};\\\", \\\"{x:1307,y:949,t:1527189266867};\\\", \\\"{x:1308,y:949,t:1527189266893};\\\", \\\"{x:1310,y:949,t:1527189266901};\\\", \\\"{x:1320,y:949,t:1527189266918};\\\", \\\"{x:1334,y:949,t:1527189266936};\\\", \\\"{x:1351,y:949,t:1527189266951};\\\", \\\"{x:1369,y:949,t:1527189266968};\\\", \\\"{x:1390,y:949,t:1527189266984};\\\", \\\"{x:1412,y:947,t:1527189267001};\\\", \\\"{x:1434,y:944,t:1527189267017};\\\", \\\"{x:1451,y:941,t:1527189267034};\\\", \\\"{x:1465,y:938,t:1527189267052};\\\", \\\"{x:1474,y:937,t:1527189267068};\\\", \\\"{x:1476,y:937,t:1527189267084};\\\", \\\"{x:1477,y:937,t:1527189267142};\\\", \\\"{x:1478,y:937,t:1527189267158};\\\", \\\"{x:1480,y:937,t:1527189267169};\\\", \\\"{x:1482,y:938,t:1527189267184};\\\", \\\"{x:1484,y:939,t:1527189267202};\\\", \\\"{x:1485,y:940,t:1527189267219};\\\", \\\"{x:1485,y:941,t:1527189267235};\\\", \\\"{x:1487,y:944,t:1527189267251};\\\", \\\"{x:1487,y:948,t:1527189267268};\\\", \\\"{x:1487,y:951,t:1527189267285};\\\", \\\"{x:1487,y:955,t:1527189267302};\\\", \\\"{x:1487,y:958,t:1527189267318};\\\", \\\"{x:1487,y:960,t:1527189267334};\\\", \\\"{x:1487,y:961,t:1527189267364};\\\", \\\"{x:1487,y:963,t:1527189267388};\\\", \\\"{x:1487,y:964,t:1527189267413};\\\", \\\"{x:1487,y:965,t:1527189267868};\\\", \\\"{x:1485,y:965,t:1527189267908};\\\", \\\"{x:1484,y:965,t:1527189267941};\\\", \\\"{x:1483,y:964,t:1527189267980};\\\", \\\"{x:1458,y:925,t:1527189289001};\\\", \\\"{x:1398,y:867,t:1527189289009};\\\", \\\"{x:1342,y:815,t:1527189289020};\\\", \\\"{x:1230,y:708,t:1527189289036};\\\", \\\"{x:1132,y:595,t:1527189289052};\\\", \\\"{x:1037,y:502,t:1527189289070};\\\", \\\"{x:949,y:428,t:1527189289086};\\\", \\\"{x:883,y:384,t:1527189289103};\\\", \\\"{x:847,y:362,t:1527189289119};\\\", \\\"{x:825,y:352,t:1527189289136};\\\", \\\"{x:818,y:350,t:1527189289153};\\\", \\\"{x:815,y:350,t:1527189289184};\\\", \\\"{x:811,y:350,t:1527189289192};\\\", \\\"{x:802,y:358,t:1527189289202};\\\", \\\"{x:785,y:385,t:1527189289220};\\\", \\\"{x:776,y:416,t:1527189289236};\\\", \\\"{x:771,y:445,t:1527189289253};\\\", \\\"{x:771,y:471,t:1527189289270};\\\", \\\"{x:775,y:492,t:1527189289287};\\\", \\\"{x:785,y:511,t:1527189289304};\\\", \\\"{x:796,y:521,t:1527189289319};\\\", \\\"{x:821,y:534,t:1527189289337};\\\", \\\"{x:836,y:538,t:1527189289353};\\\", \\\"{x:848,y:542,t:1527189289371};\\\", \\\"{x:856,y:544,t:1527189289386};\\\", \\\"{x:864,y:547,t:1527189289402};\\\", \\\"{x:866,y:547,t:1527189289424};\\\", \\\"{x:867,y:547,t:1527189289440};\\\", \\\"{x:867,y:548,t:1527189289457};\\\", \\\"{x:868,y:548,t:1527189289511};\\\", \\\"{x:870,y:550,t:1527189289524};\\\", \\\"{x:873,y:554,t:1527189289540};\\\", \\\"{x:878,y:559,t:1527189289557};\\\", \\\"{x:883,y:563,t:1527189289574};\\\", \\\"{x:893,y:570,t:1527189289591};\\\", \\\"{x:903,y:577,t:1527189289608};\\\", \\\"{x:916,y:586,t:1527189289625};\\\", \\\"{x:922,y:590,t:1527189289642};\\\", \\\"{x:925,y:597,t:1527189289657};\\\", \\\"{x:925,y:600,t:1527189289675};\\\", \\\"{x:917,y:601,t:1527189289692};\\\", \\\"{x:914,y:601,t:1527189289707};\\\", \\\"{x:925,y:601,t:1527189293841};\\\", \\\"{x:947,y:606,t:1527189293848};\\\", \\\"{x:971,y:611,t:1527189293864};\\\", \\\"{x:1092,y:641,t:1527189293880};\\\", \\\"{x:1154,y:660,t:1527189293894};\\\", \\\"{x:1372,y:723,t:1527189293911};\\\", \\\"{x:1510,y:760,t:1527189293928};\\\", \\\"{x:1628,y:789,t:1527189293944};\\\", \\\"{x:1730,y:817,t:1527189293962};\\\", \\\"{x:1792,y:836,t:1527189293977};\\\", \\\"{x:1815,y:845,t:1527189293994};\\\", \\\"{x:1820,y:847,t:1527189294012};\\\", \\\"{x:1820,y:849,t:1527189294048};\\\", \\\"{x:1818,y:851,t:1527189294064};\\\", \\\"{x:1817,y:853,t:1527189294079};\\\", \\\"{x:1812,y:860,t:1527189294095};\\\", \\\"{x:1802,y:872,t:1527189294113};\\\", \\\"{x:1794,y:880,t:1527189294128};\\\", \\\"{x:1779,y:892,t:1527189294145};\\\", \\\"{x:1760,y:904,t:1527189294162};\\\", \\\"{x:1733,y:915,t:1527189294178};\\\", \\\"{x:1705,y:926,t:1527189294195};\\\", \\\"{x:1679,y:934,t:1527189294212};\\\", \\\"{x:1662,y:937,t:1527189294229};\\\", \\\"{x:1642,y:938,t:1527189294244};\\\", \\\"{x:1629,y:938,t:1527189294262};\\\", \\\"{x:1619,y:938,t:1527189294279};\\\", \\\"{x:1610,y:936,t:1527189294295};\\\", \\\"{x:1593,y:925,t:1527189294312};\\\", \\\"{x:1577,y:912,t:1527189294328};\\\", \\\"{x:1561,y:895,t:1527189294346};\\\", \\\"{x:1544,y:878,t:1527189294361};\\\", \\\"{x:1521,y:862,t:1527189294379};\\\", \\\"{x:1492,y:844,t:1527189294396};\\\", \\\"{x:1474,y:834,t:1527189294412};\\\", \\\"{x:1468,y:831,t:1527189294429};\\\", \\\"{x:1466,y:829,t:1527189294446};\\\", \\\"{x:1464,y:828,t:1527189294462};\\\", \\\"{x:1464,y:827,t:1527189294480};\\\", \\\"{x:1464,y:820,t:1527189294497};\\\", \\\"{x:1464,y:813,t:1527189294513};\\\", \\\"{x:1464,y:808,t:1527189294529};\\\", \\\"{x:1462,y:799,t:1527189294546};\\\", \\\"{x:1460,y:790,t:1527189294562};\\\", \\\"{x:1460,y:784,t:1527189294578};\\\", \\\"{x:1460,y:778,t:1527189294596};\\\", \\\"{x:1460,y:771,t:1527189294612};\\\", \\\"{x:1460,y:765,t:1527189294629};\\\", \\\"{x:1460,y:760,t:1527189294647};\\\", \\\"{x:1460,y:757,t:1527189294662};\\\", \\\"{x:1460,y:753,t:1527189294679};\\\", \\\"{x:1460,y:748,t:1527189294696};\\\", \\\"{x:1460,y:746,t:1527189294712};\\\", \\\"{x:1461,y:744,t:1527189294729};\\\", \\\"{x:1461,y:743,t:1527189294746};\\\", \\\"{x:1461,y:741,t:1527189294763};\\\", \\\"{x:1461,y:740,t:1527189294779};\\\", \\\"{x:1461,y:739,t:1527189294796};\\\", \\\"{x:1462,y:736,t:1527189294814};\\\", \\\"{x:1462,y:732,t:1527189294829};\\\", \\\"{x:1462,y:728,t:1527189294846};\\\", \\\"{x:1462,y:722,t:1527189294863};\\\", \\\"{x:1459,y:716,t:1527189294879};\\\", \\\"{x:1453,y:702,t:1527189294896};\\\", \\\"{x:1451,y:696,t:1527189294912};\\\", \\\"{x:1446,y:688,t:1527189294930};\\\", \\\"{x:1443,y:681,t:1527189294945};\\\", \\\"{x:1438,y:674,t:1527189294962};\\\", \\\"{x:1434,y:670,t:1527189294978};\\\", \\\"{x:1430,y:666,t:1527189294995};\\\", \\\"{x:1427,y:663,t:1527189295012};\\\", \\\"{x:1425,y:661,t:1527189295030};\\\", \\\"{x:1424,y:659,t:1527189295045};\\\", \\\"{x:1423,y:656,t:1527189295063};\\\", \\\"{x:1420,y:653,t:1527189295080};\\\", \\\"{x:1419,y:652,t:1527189295095};\\\", \\\"{x:1418,y:651,t:1527189295112};\\\", \\\"{x:1417,y:650,t:1527189295130};\\\", \\\"{x:1416,y:650,t:1527189295152};\\\", \\\"{x:1416,y:649,t:1527189295163};\\\", \\\"{x:1417,y:649,t:1527189295817};\\\", \\\"{x:1420,y:649,t:1527189295830};\\\", \\\"{x:1427,y:652,t:1527189295847};\\\", \\\"{x:1443,y:663,t:1527189295865};\\\", \\\"{x:1457,y:677,t:1527189295881};\\\", \\\"{x:1471,y:693,t:1527189295897};\\\", \\\"{x:1485,y:712,t:1527189295914};\\\", \\\"{x:1497,y:733,t:1527189295930};\\\", \\\"{x:1518,y:769,t:1527189295947};\\\", \\\"{x:1541,y:803,t:1527189295963};\\\", \\\"{x:1556,y:826,t:1527189295979};\\\", \\\"{x:1566,y:846,t:1527189295996};\\\", \\\"{x:1572,y:862,t:1527189296014};\\\", \\\"{x:1578,y:883,t:1527189296031};\\\", \\\"{x:1583,y:904,t:1527189296047};\\\", \\\"{x:1585,y:927,t:1527189296063};\\\", \\\"{x:1586,y:938,t:1527189296080};\\\", \\\"{x:1586,y:950,t:1527189296097};\\\", \\\"{x:1586,y:963,t:1527189296114};\\\", \\\"{x:1585,y:970,t:1527189296131};\\\", \\\"{x:1579,y:977,t:1527189296146};\\\", \\\"{x:1575,y:979,t:1527189296164};\\\", \\\"{x:1569,y:982,t:1527189296180};\\\", \\\"{x:1563,y:985,t:1527189296196};\\\", \\\"{x:1562,y:985,t:1527189296214};\\\", \\\"{x:1557,y:985,t:1527189296230};\\\", \\\"{x:1553,y:985,t:1527189296247};\\\", \\\"{x:1545,y:985,t:1527189296264};\\\", \\\"{x:1537,y:984,t:1527189296280};\\\", \\\"{x:1532,y:981,t:1527189296296};\\\", \\\"{x:1526,y:977,t:1527189296314};\\\", \\\"{x:1520,y:973,t:1527189296331};\\\", \\\"{x:1515,y:966,t:1527189296348};\\\", \\\"{x:1507,y:956,t:1527189296364};\\\", \\\"{x:1502,y:950,t:1527189296381};\\\", \\\"{x:1498,y:944,t:1527189296398};\\\", \\\"{x:1497,y:943,t:1527189296414};\\\", \\\"{x:1496,y:941,t:1527189296431};\\\", \\\"{x:1495,y:940,t:1527189296448};\\\", \\\"{x:1494,y:939,t:1527189296481};\\\", \\\"{x:1494,y:938,t:1527189296633};\\\", \\\"{x:1492,y:935,t:1527189296649};\\\", \\\"{x:1492,y:933,t:1527189296664};\\\", \\\"{x:1490,y:929,t:1527189296681};\\\", \\\"{x:1489,y:926,t:1527189296699};\\\", \\\"{x:1488,y:924,t:1527189296715};\\\", \\\"{x:1487,y:921,t:1527189296731};\\\", \\\"{x:1486,y:918,t:1527189296753};\\\", \\\"{x:1485,y:917,t:1527189296768};\\\", \\\"{x:1485,y:916,t:1527189296792};\\\", \\\"{x:1484,y:915,t:1527189296800};\\\", \\\"{x:1484,y:914,t:1527189296816};\\\", \\\"{x:1484,y:913,t:1527189296832};\\\", \\\"{x:1482,y:911,t:1527189296849};\\\", \\\"{x:1482,y:909,t:1527189296865};\\\", \\\"{x:1481,y:908,t:1527189296881};\\\", \\\"{x:1480,y:906,t:1527189296899};\\\", \\\"{x:1481,y:909,t:1527189296993};\\\", \\\"{x:1484,y:913,t:1527189297000};\\\", \\\"{x:1486,y:916,t:1527189297016};\\\", \\\"{x:1492,y:923,t:1527189297031};\\\", \\\"{x:1498,y:935,t:1527189297048};\\\", \\\"{x:1502,y:941,t:1527189297065};\\\", \\\"{x:1504,y:946,t:1527189297082};\\\", \\\"{x:1504,y:947,t:1527189297098};\\\", \\\"{x:1505,y:948,t:1527189297116};\\\", \\\"{x:1505,y:949,t:1527189297176};\\\", \\\"{x:1504,y:949,t:1527189297200};\\\", \\\"{x:1504,y:950,t:1527189297215};\\\", \\\"{x:1501,y:951,t:1527189297231};\\\", \\\"{x:1500,y:951,t:1527189297247};\\\", \\\"{x:1499,y:952,t:1527189297264};\\\", \\\"{x:1499,y:953,t:1527189297319};\\\", \\\"{x:1499,y:954,t:1527189297383};\\\", \\\"{x:1499,y:955,t:1527189297399};\\\", \\\"{x:1499,y:956,t:1527189297415};\\\", \\\"{x:1499,y:958,t:1527189297431};\\\", \\\"{x:1499,y:959,t:1527189297456};\\\", \\\"{x:1499,y:960,t:1527189297496};\\\", \\\"{x:1499,y:961,t:1527189297504};\\\", \\\"{x:1499,y:962,t:1527189297536};\\\", \\\"{x:1499,y:963,t:1527189297552};\\\", \\\"{x:1498,y:963,t:1527189297584};\\\", \\\"{x:1497,y:964,t:1527189297624};\\\", \\\"{x:1496,y:964,t:1527189297673};\\\", \\\"{x:1495,y:964,t:1527189297729};\\\", \\\"{x:1493,y:964,t:1527189297752};\\\", \\\"{x:1492,y:963,t:1527189297768};\\\", \\\"{x:1492,y:962,t:1527189297782};\\\", \\\"{x:1491,y:962,t:1527189297800};\\\", \\\"{x:1488,y:960,t:1527189297816};\\\", \\\"{x:1487,y:959,t:1527189297832};\\\", \\\"{x:1486,y:958,t:1527189297849};\\\", \\\"{x:1484,y:956,t:1527189297866};\\\", \\\"{x:1482,y:956,t:1527189297883};\\\", \\\"{x:1482,y:955,t:1527189297899};\\\", \\\"{x:1481,y:953,t:1527189297916};\\\", \\\"{x:1480,y:953,t:1527189312273};\\\", \\\"{x:1478,y:953,t:1527189312281};\\\", \\\"{x:1477,y:953,t:1527189312298};\\\", \\\"{x:1466,y:942,t:1527189312537};\\\", \\\"{x:1435,y:918,t:1527189312548};\\\", \\\"{x:1377,y:881,t:1527189312565};\\\", \\\"{x:1312,y:847,t:1527189312581};\\\", \\\"{x:1241,y:805,t:1527189312598};\\\", \\\"{x:1151,y:755,t:1527189312615};\\\", \\\"{x:1072,y:707,t:1527189312631};\\\", \\\"{x:959,y:654,t:1527189312649};\\\", \\\"{x:888,y:625,t:1527189312665};\\\", \\\"{x:830,y:602,t:1527189312680};\\\", \\\"{x:818,y:591,t:1527189312698};\\\", \\\"{x:817,y:589,t:1527189312709};\\\", \\\"{x:817,y:587,t:1527189312726};\\\", \\\"{x:818,y:585,t:1527189312742};\\\", \\\"{x:818,y:579,t:1527189312759};\\\", \\\"{x:815,y:573,t:1527189312777};\\\", \\\"{x:806,y:565,t:1527189312793};\\\", \\\"{x:792,y:556,t:1527189312809};\\\", \\\"{x:775,y:547,t:1527189312826};\\\", \\\"{x:765,y:542,t:1527189312843};\\\", \\\"{x:757,y:538,t:1527189312860};\\\", \\\"{x:746,y:529,t:1527189312877};\\\", \\\"{x:736,y:523,t:1527189312893};\\\", \\\"{x:728,y:518,t:1527189312909};\\\", \\\"{x:725,y:517,t:1527189312927};\\\", \\\"{x:709,y:510,t:1527189312944};\\\", \\\"{x:704,y:509,t:1527189312959};\\\", \\\"{x:700,y:507,t:1527189312976};\\\", \\\"{x:695,y:505,t:1527189312993};\\\", \\\"{x:688,y:503,t:1527189313010};\\\", \\\"{x:685,y:502,t:1527189313026};\\\", \\\"{x:683,y:502,t:1527189313044};\\\", \\\"{x:680,y:502,t:1527189313060};\\\", \\\"{x:678,y:502,t:1527189313077};\\\", \\\"{x:676,y:502,t:1527189313094};\\\", \\\"{x:674,y:502,t:1527189313110};\\\", \\\"{x:670,y:502,t:1527189313127};\\\", \\\"{x:664,y:502,t:1527189313144};\\\", \\\"{x:660,y:502,t:1527189313159};\\\", \\\"{x:657,y:502,t:1527189313176};\\\", \\\"{x:653,y:502,t:1527189313194};\\\", \\\"{x:651,y:502,t:1527189313211};\\\", \\\"{x:647,y:503,t:1527189313226};\\\", \\\"{x:646,y:503,t:1527189313244};\\\", \\\"{x:645,y:505,t:1527189313260};\\\", \\\"{x:644,y:505,t:1527189313280};\\\", \\\"{x:645,y:505,t:1527189313496};\\\", \\\"{x:647,y:505,t:1527189313510};\\\", \\\"{x:650,y:505,t:1527189313526};\\\", \\\"{x:654,y:504,t:1527189313543};\\\", \\\"{x:653,y:505,t:1527189313857};\\\", \\\"{x:652,y:505,t:1527189313864};\\\", \\\"{x:651,y:505,t:1527189313877};\\\", \\\"{x:649,y:506,t:1527189314064};\\\", \\\"{x:648,y:507,t:1527189314078};\\\", \\\"{x:645,y:507,t:1527189314093};\\\", \\\"{x:640,y:510,t:1527189314111};\\\", \\\"{x:630,y:514,t:1527189314127};\\\", \\\"{x:626,y:516,t:1527189314144};\\\", \\\"{x:620,y:519,t:1527189314160};\\\", \\\"{x:617,y:520,t:1527189314177};\\\", \\\"{x:614,y:521,t:1527189314194};\\\", \\\"{x:612,y:521,t:1527189314211};\\\", \\\"{x:609,y:522,t:1527189314227};\\\", \\\"{x:606,y:522,t:1527189314244};\\\", \\\"{x:605,y:523,t:1527189314261};\\\", \\\"{x:605,y:529,t:1527189314793};\\\", \\\"{x:605,y:545,t:1527189314811};\\\", \\\"{x:607,y:564,t:1527189314827};\\\", \\\"{x:613,y:585,t:1527189314845};\\\", \\\"{x:618,y:604,t:1527189314862};\\\", \\\"{x:622,y:619,t:1527189314878};\\\", \\\"{x:626,y:631,t:1527189314894};\\\", \\\"{x:629,y:642,t:1527189314911};\\\", \\\"{x:629,y:647,t:1527189314928};\\\", \\\"{x:629,y:652,t:1527189314944};\\\", \\\"{x:630,y:656,t:1527189314962};\\\", \\\"{x:631,y:660,t:1527189314978};\\\", \\\"{x:631,y:664,t:1527189314995};\\\", \\\"{x:631,y:668,t:1527189315011};\\\", \\\"{x:631,y:674,t:1527189315029};\\\", \\\"{x:628,y:679,t:1527189315044};\\\", \\\"{x:626,y:682,t:1527189315062};\\\", \\\"{x:623,y:686,t:1527189315079};\\\", \\\"{x:620,y:691,t:1527189315095};\\\", \\\"{x:613,y:696,t:1527189315112};\\\", \\\"{x:612,y:699,t:1527189315129};\\\", \\\"{x:611,y:702,t:1527189315145};\\\", \\\"{x:609,y:709,t:1527189315161};\\\", \\\"{x:606,y:713,t:1527189315179};\\\", \\\"{x:603,y:717,t:1527189315194};\\\", \\\"{x:603,y:724,t:1527189315211};\\\", \\\"{x:602,y:732,t:1527189315228};\\\", \\\"{x:599,y:738,t:1527189315246};\\\", \\\"{x:598,y:746,t:1527189315261};\\\", \\\"{x:596,y:749,t:1527189315278};\\\", \\\"{x:595,y:753,t:1527189315296};\\\", \\\"{x:591,y:756,t:1527189315311};\\\", \\\"{x:591,y:757,t:1527189315329};\\\", \\\"{x:589,y:760,t:1527189315346};\\\", \\\"{x:589,y:763,t:1527189315361};\\\", \\\"{x:588,y:766,t:1527189315379};\\\", \\\"{x:584,y:767,t:1527189315395};\\\", \\\"{x:580,y:767,t:1527189315412};\\\", \\\"{x:577,y:764,t:1527189315429};\\\", \\\"{x:574,y:763,t:1527189315446};\\\", \\\"{x:573,y:761,t:1527189315462};\\\", \\\"{x:570,y:758,t:1527189315479};\\\", \\\"{x:567,y:758,t:1527189315496};\\\", \\\"{x:565,y:756,t:1527189315512};\\\", \\\"{x:564,y:755,t:1527189315618};\\\", \\\"{x:561,y:755,t:1527189315628};\\\", \\\"{x:551,y:755,t:1527189315645};\\\", \\\"{x:546,y:755,t:1527189315662};\\\", \\\"{x:543,y:755,t:1527189315678};\\\", \\\"{x:535,y:755,t:1527189315696};\\\", \\\"{x:532,y:755,t:1527189315712};\\\", \\\"{x:529,y:755,t:1527189315728};\\\", \\\"{x:526,y:755,t:1527189315745};\\\", \\\"{x:523,y:755,t:1527189315763};\\\", \\\"{x:522,y:754,t:1527189316096};\\\", \\\"{x:522,y:753,t:1527189316136};\\\", \\\"{x:523,y:751,t:1527189316152};\\\", \\\"{x:526,y:750,t:1527189316168};\\\", \\\"{x:529,y:748,t:1527189316178};\\\", \\\"{x:533,y:746,t:1527189316195};\\\", \\\"{x:544,y:746,t:1527189316213};\\\", \\\"{x:573,y:746,t:1527189316229};\\\", \\\"{x:617,y:746,t:1527189316246};\\\", \\\"{x:650,y:746,t:1527189316263};\\\", \\\"{x:683,y:743,t:1527189316278};\\\", \\\"{x:724,y:738,t:1527189316296};\\\", \\\"{x:752,y:733,t:1527189316313};\\\", \\\"{x:780,y:728,t:1527189316329};\\\", \\\"{x:804,y:723,t:1527189316346};\\\", \\\"{x:824,y:717,t:1527189316363};\\\", \\\"{x:837,y:714,t:1527189316379};\\\", \\\"{x:841,y:713,t:1527189316396};\\\", \\\"{x:844,y:712,t:1527189316412};\\\", \\\"{x:844,y:711,t:1527189316696};\\\", \\\"{x:844,y:710,t:1527189316713};\\\", \\\"{x:843,y:708,t:1527189316744};\\\" ] }, { \\\"rt\\\": 45457, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 744947, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find 12 PM on the horizontal line and go straight up to see if there are any points that indicate events that start at 12 pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6017, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 751973, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 12028, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 765026, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7921, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 774301, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ZB1L5\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"ZB1L5\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 235, dom: 917, initialDom: 2511",
  "javascriptErrors": []
}