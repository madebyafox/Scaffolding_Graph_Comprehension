var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5f8991abdf9d1c943e36d81e9f08e029",
  "created": "2018-05-21T10:15:15.9537315-07:00",
  "lastActivity": "2018-05-21T10:15:22.8257315-07:00",
  "pageViews": [
    {
      "id": "05211660ebccc1155a3b51b31a4762ea5c03f5f6",
      "startTime": "2018-05-21T10:15:15.9537315-07:00",
      "endTime": "2018-05-21T10:15:22.8257315-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 6872,
      "engagementTime": 6859,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 6872,
  "engagementTime": 6859,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9BCHA",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7f5ea9e5d90700f999159a02937bbd74",
  "gdpr": false
}