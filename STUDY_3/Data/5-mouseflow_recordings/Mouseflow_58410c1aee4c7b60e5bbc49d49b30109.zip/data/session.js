var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "58410c1aee4c7b60e5bbc49d49b30109",
  "created": "2018-05-15T17:10:31.2288256-07:00",
  "lastActivity": "2018-05-15T17:10:44.36774-07:00",
  "pageViews": [
    {
      "id": "05153177e9a360bf3398b9719690bc117d063527",
      "startTime": "2018-05-15T17:10:31.3950464-07:00",
      "endTime": "2018-05-15T17:10:44.36774-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 13224,
      "engagementTime": 13123,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13224,
  "engagementTime": 13123,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TVQKD",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "27c5d9159405c8c58fe7aed32b8d88a2",
  "gdpr": false
}