var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3eacfefb898184114d4706d4565c8bd6",
  "created": "2018-05-24T12:13:59.4630584-07:00",
  "lastActivity": "2018-05-24T12:14:13.1770584-07:00",
  "pageViews": [
    {
      "id": "052459226dd8e0379ba8d6322db0a53f1fded4ab",
      "startTime": "2018-05-24T12:13:59.4630584-07:00",
      "endTime": "2018-05-24T12:14:13.1770584-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 13714,
      "engagementTime": 13614,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13714,
  "engagementTime": 13614,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FN9LT",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "43a58dba1bc9472074ae95d96726011b",
  "gdpr": false
}