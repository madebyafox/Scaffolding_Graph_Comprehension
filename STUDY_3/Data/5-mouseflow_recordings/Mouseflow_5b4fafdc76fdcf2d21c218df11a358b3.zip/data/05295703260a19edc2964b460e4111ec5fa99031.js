var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05295703260a19edc2964b460e4111ec5fa99031"] = {
  "startTime": "2018-05-29T18:53:57.813082Z",
  "websitePageUrl": "/",
  "visitTime": 20001,
  "engagementTime": 14501,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [],
  "session": {
    "id": "5b4fafdc76fdcf2d21c218df11a358b3",
    "created": "2018-05-29T18:53:57.7860348+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8c9f9dc17a05ed8fc6b54f6d83a853db",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5b4fafdc76fdcf2d21c218df11a358b3/play"
  },
  "events": [
    {
      "t": 70,
      "e": 70,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 402,
      "e": 402,
      "ty": 2,
      "x": 653,
      "y": 232
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 717,
      "y": 620
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 19523,
      "y": 38788,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 882,
      "y": 806
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 893,
      "y": 803
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 29463,
      "y": 53533,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 802,
      "e": 802,
      "ty": 2,
      "x": 910,
      "y": 791
    },
    {
      "t": 902,
      "e": 902,
      "ty": 2,
      "x": 939,
      "y": 768
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 966,
      "y": 751
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 33122,
      "y": 49519,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 1013,
      "y": 734
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 1018,
      "y": 732
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 35962,
      "y": 47963,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 2802,
      "e": 2802,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 3702,
      "e": 3702,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 1,
      "x": 0,
      "y": 2
    },
    {
      "t": 3902,
      "e": 3902,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 720,
      "y": 934
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 488,
      "y": 1020
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 16289,
      "y": 61762,
      "ta": "html > body"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 446,
      "y": 1033
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 257,
      "y": 1059
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 2,
      "x": 220,
      "y": 1077
    },
    {
      "t": 10002,
      "e": 9502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10502,
      "e": 9502,
      "ty": 2,
      "x": 219,
      "y": 1077
    },
    {
      "t": 11102,
      "e": 10102,
      "ty": 2,
      "x": 219,
      "y": 1078
    },
    {
      "t": 11301,
      "e": 10301,
      "ty": 2,
      "x": 231,
      "y": 1075
    },
    {
      "t": 11401,
      "e": 10401,
      "ty": 2,
      "x": 263,
      "y": 1065
    },
    {
      "t": 11502,
      "e": 10502,
      "ty": 2,
      "x": 267,
      "y": 1063
    },
    {
      "t": 11502,
      "e": 10502,
      "ty": 41,
      "x": 8919,
      "y": 64196,
      "ta": "html > body"
    },
    {
      "t": 14752,
      "e": 13752,
      "ty": 41,
      "x": 9986,
      "y": 63466,
      "ta": "html > body"
    },
    {
      "t": 14802,
      "e": 13802,
      "ty": 2,
      "x": 632,
      "y": 934
    },
    {
      "t": 14902,
      "e": 13902,
      "ty": 2,
      "x": 1312,
      "y": 747
    },
    {
      "t": 15002,
      "e": 14002,
      "ty": 2,
      "x": 1554,
      "y": 700
    },
    {
      "t": 15003,
      "e": 14003,
      "ty": 41,
      "x": 65234,
      "y": 45342,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 15102,
      "e": 14102,
      "ty": 2,
      "x": 1555,
      "y": 701
    },
    {
      "t": 15253,
      "e": 14253,
      "ty": 41,
      "x": 65289,
      "y": 45423,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 15302,
      "e": 14302,
      "ty": 2,
      "x": 1571,
      "y": 686
    },
    {
      "t": 15402,
      "e": 14402,
      "ty": 2,
      "x": 1782,
      "y": 364
    },
    {
      "t": 15467,
      "e": 14467,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 15501,
      "e": 14501,
      "ty": 2,
      "x": 1919,
      "y": 14
    },
    {
      "t": 20001,
      "e": 19001,
      "ty": 19,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 214, dom: 214, initialDom: 218",
  "javascriptErrors": []
}