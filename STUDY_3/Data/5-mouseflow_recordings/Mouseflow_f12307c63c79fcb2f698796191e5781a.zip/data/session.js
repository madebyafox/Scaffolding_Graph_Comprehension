var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f12307c63c79fcb2f698796191e5781a",
  "created": "2018-06-04T13:25:28.869099-07:00",
  "lastActivity": "2018-06-04T13:27:59.270099-07:00",
  "pageViews": [
    {
      "id": "06042969070b5e18852b814333b599a0897a183d",
      "startTime": "2018-06-04T13:25:28.869099-07:00",
      "endTime": "2018-06-04T13:27:59.270099-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 150401,
      "engagementTime": 124990,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 150401,
  "engagementTime": 124990,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=TTCWS",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9f37ce493a25c36e31677d927dced574",
  "gdpr": false
}